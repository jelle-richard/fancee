import 'package:fancee_ticketing/src/data/data.dart';
import 'package:test/test.dart';

void main() {
  group('FTEnvironment', () {
    test('local() should have the correct values.', () {
      const environment = FTEnvironment.local();

      expect(environment.apiBaseUrl, equals('https://staging.fanc.ee/api'));
      expect(environment.apiUserAgent, equals('FanceeTicketing/1.0.x'));
      expect(environment.baseUrl, equals('https://staging.fanc.ee'));
      expect(environment.featureFlags, isA<FTFeatureFlags>());
      expect(environment.icon, equals('server'));
      expect(environment.id, equals('anton'));
      expect(environment.name, equals('Anton'));
      expect(environment.prefillLoginEmail, isNotNull);
      expect(environment.prefillLoginPassword, isNotNull);
    });

    test('staging() should have the correct values.', () {
      const environment = FTEnvironment.staging();

      expect(environment.apiBaseUrl, equals('https://staging.fanc.ee/api'));
      expect(environment.apiUserAgent, equals('FanceeTicketing/1.0.x'));
      expect(environment.baseUrl, equals('https://staging.fanc.ee'));
      expect(environment.featureFlags, isA<FTFeatureFlags>());
      expect(environment.icon, equals('star'));
      expect(environment.id, equals('staging'));
      expect(environment.name, equals('Staging'));
      expect(environment.prefillLoginEmail, isNull);
      expect(environment.prefillLoginPassword, isNull);
    });

    test('production() should have the correct values.', () {
      const environment = FTEnvironment.production();

      expect(environment.apiBaseUrl, equals('https://ticketing.wearefancee.com/api'));
      expect(environment.apiUserAgent, equals('FanceeTicketing/1.0.x'));
      expect(environment.baseUrl, equals('https://ticketing.wearefancee.com'));
      expect(environment.featureFlags, isA<FTFeatureFlags>());
      expect(environment.icon, equals('heart'));
      expect(environment.id, equals('production'));
      expect(environment.name, equals('Production'));
      expect(environment.prefillLoginEmail, isNull);
      expect(environment.prefillLoginPassword, isNull);
    });
  });
}
