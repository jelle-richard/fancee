import 'package:fancee_ticketing/src/data/enum/event_type.dart';
import 'package:test/test.dart';

void main() {
  group('FTEventType', () {
    test('fromString() should always return the correct values.', () {
      expect(FTEventType.fromString('Normal'), equals(FTEventType.normal));
    });

    test('fromString() should return "unknown" for non-existing values.', () {
      expect(FTEventType.fromString('unittype'), equals(FTEventType.unknown));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTEventType.normal.toString(), equals('Normal'));
    });
  });
}
