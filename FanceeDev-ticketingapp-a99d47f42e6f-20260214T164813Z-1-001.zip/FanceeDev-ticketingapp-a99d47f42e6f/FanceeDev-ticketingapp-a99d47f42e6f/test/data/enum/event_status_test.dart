import 'package:fancee_ticketing/src/data/enum/event_status.dart';
import 'package:test/test.dart';

void main() {
  group('FTEventStatus', () {
    test('fromString() should always return the correct values.', () {
      expect(FTEventStatus.fromString('Active'), equals(FTEventStatus.active));
      expect(FTEventStatus.fromString('Cancelled'), equals(FTEventStatus.canceled));
      expect(FTEventStatus.fromString('Completed'), equals(FTEventStatus.completed));
      expect(FTEventStatus.fromString('Concluded'), equals(FTEventStatus.concluded));
      expect(FTEventStatus.fromString('SoldOut'), equals(FTEventStatus.soldOut));
      expect(FTEventStatus.fromString('Unpublished'), equals(FTEventStatus.unpublished));
    });

    test('fromString() should return "unknown" for non-existing values.', () {
      expect(FTEventStatus.fromString('unitstatus'), equals(FTEventStatus.unknown));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTEventStatus.active.toString(), equals('Active'));
      expect(FTEventStatus.canceled.toString(), equals('Cancelled'));
      expect(FTEventStatus.completed.toString(), equals('Completed'));
      expect(FTEventStatus.concluded.toString(), equals('Concluded'));
      expect(FTEventStatus.soldOut.toString(), equals('SoldOut'));
      expect(FTEventStatus.unpublished.toString(), equals('Unpublished'));
    });
  });
}
