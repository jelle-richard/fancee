import 'dart:convert';

import 'package:fancee_ticketing/src/data/enum/user_claim.dart';
import 'package:test/test.dart';

void main() {
  group('FTUserClaim', () {
    test('fromString() should always return the correct values.', () {
      expect(FTUserClaim.fromString('unknown'), equals(FTUserClaim.unknown));

      // App Team
      expect(FTUserClaim.fromString('sales'), equals(FTUserClaim.sales));
      expect(FTUserClaim.fromString('scan'), equals(FTUserClaim.scan));
      expect(FTUserClaim.fromString('statistics'), equals(FTUserClaim.statistics));

      // Organizer
      expect(FTUserClaim.fromString('appteam.add'), equals(FTUserClaim.appTeamAdd));
      expect(FTUserClaim.fromString('appteam.details'), equals(FTUserClaim.appTeamDetails));
      expect(FTUserClaim.fromString('appteam.list'), equals(FTUserClaim.appTeamList));
      expect(FTUserClaim.fromString('appteam.remove'), equals(FTUserClaim.appTeamRemove));
      expect(FTUserClaim.fromString('customerinsight.view'), equals(FTUserClaim.customerInsightView));
      expect(FTUserClaim.fromString('event.configure'), equals(FTUserClaim.eventConfigure));
      expect(FTUserClaim.fromString('event.details'), equals(FTUserClaim.eventDetails));
      expect(FTUserClaim.fromString('event.list'), equals(FTUserClaim.eventList));
      expect(FTUserClaim.fromString('event.type.normal'), equals(FTUserClaim.eventTypeNormal));
      expect(FTUserClaim.fromString('invoice.details'), equals(FTUserClaim.invoiceDetails));
      expect(FTUserClaim.fromString('invoice.list'), equals(FTUserClaim.invoiceList));
      expect(FTUserClaim.fromString('preregister.configure'), equals(FTUserClaim.preRegisterConfigure));
      expect(FTUserClaim.fromString('preregister.details'), equals(FTUserClaim.preRegisterDetails));
      expect(FTUserClaim.fromString('preregister.list'), equals(FTUserClaim.preRegisterList));
      expect(FTUserClaim.fromString('profile.details'), equals(FTUserClaim.profileDetails));
      expect(FTUserClaim.fromString('profile.edit'), equals(FTUserClaim.profileEdit));
      expect(FTUserClaim.fromString('refund.accept'), equals(FTUserClaim.refundAccept));
      expect(FTUserClaim.fromString('sale.payments.cash'), equals(FTUserClaim.salePaymentsCash));
      expect(FTUserClaim.fromString('ticket.edit'), equals(FTUserClaim.ticketEdit));
      expect(FTUserClaim.fromString('ticket.scan'), equals(FTUserClaim.ticketScan));
      expect(FTUserClaim.fromString('ticket.statistics'), equals(FTUserClaim.ticketStatistics));
    });

    test('fromString() should return unknown for non existing values.', () {
      expect(FTUserClaim.fromString('unittest'), equals(FTUserClaim.unknown));
    });

    test('toJson() should return the name of the enum case.', () {
      expect(jsonEncode(FTUserClaim.unknown), equals('"unknown"'));

      // App Team
      expect(jsonEncode(FTUserClaim.sales), equals('"sales"'));
      expect(jsonEncode(FTUserClaim.scan), equals('"scan"'));
      expect(jsonEncode(FTUserClaim.statistics), equals('"statistics"'));

      // Organizer
      expect(jsonEncode(FTUserClaim.appTeamAdd), equals('"appteam.add"'));
      expect(jsonEncode(FTUserClaim.appTeamDetails), equals('"appteam.details"'));
      expect(jsonEncode(FTUserClaim.appTeamList), equals('"appteam.list"'));
      expect(jsonEncode(FTUserClaim.appTeamRemove), equals('"appteam.remove"'));
      expect(jsonEncode(FTUserClaim.customerInsightView), equals('"customerinsight.view"'));
      expect(jsonEncode(FTUserClaim.eventConfigure), equals('"event.configure"'));
      expect(jsonEncode(FTUserClaim.eventDetails), equals('"event.details"'));
      expect(jsonEncode(FTUserClaim.eventList), equals('"event.list"'));
      expect(jsonEncode(FTUserClaim.eventTypeNormal), equals('"event.type.normal"'));
      expect(jsonEncode(FTUserClaim.invoiceDetails), equals('"invoice.details"'));
      expect(jsonEncode(FTUserClaim.invoiceList), equals('"invoice.list"'));
      expect(jsonEncode(FTUserClaim.preRegisterConfigure), equals('"preregister.configure"'));
      expect(jsonEncode(FTUserClaim.preRegisterDetails), equals('"preregister.details"'));
      expect(jsonEncode(FTUserClaim.preRegisterList), equals('"preregister.list"'));
      expect(jsonEncode(FTUserClaim.profileDetails), equals('"profile.details"'));
      expect(jsonEncode(FTUserClaim.profileEdit), equals('"profile.edit"'));
      expect(jsonEncode(FTUserClaim.refundAccept), equals('"refund.accept"'));
      expect(jsonEncode(FTUserClaim.salePaymentsCash), equals('"sale.payments.cash"'));
      expect(jsonEncode(FTUserClaim.ticketEdit), equals('"ticket.edit"'));
      expect(jsonEncode(FTUserClaim.ticketScan), equals('"ticket.scan"'));
      expect(jsonEncode(FTUserClaim.ticketStatistics), equals('"ticket.statistics"'));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTUserClaim.unknown.toString(), equals('unknown'));

      // App Team
      expect(FTUserClaim.sales.toString(), equals('sales'));
      expect(FTUserClaim.scan.toString(), equals('scan'));
      expect(FTUserClaim.statistics.toString(), equals('statistics'));

      // Organizer
      expect(FTUserClaim.appTeamAdd.toString(), equals('appteam.add'));
      expect(FTUserClaim.appTeamDetails.toString(), equals('appteam.details'));
      expect(FTUserClaim.appTeamList.toString(), equals('appteam.list'));
      expect(FTUserClaim.appTeamRemove.toString(), equals('appteam.remove'));
      expect(FTUserClaim.customerInsightView.toString(), equals('customerinsight.view'));
      expect(FTUserClaim.eventConfigure.toString(), equals('event.configure'));
      expect(FTUserClaim.eventDetails.toString(), equals('event.details'));
      expect(FTUserClaim.eventList.toString(), equals('event.list'));
      expect(FTUserClaim.eventTypeNormal.toString(), equals('event.type.normal'));
      expect(FTUserClaim.invoiceDetails.toString(), equals('invoice.details'));
      expect(FTUserClaim.invoiceList.toString(), equals('invoice.list'));
      expect(FTUserClaim.preRegisterConfigure.toString(), equals('preregister.configure'));
      expect(FTUserClaim.preRegisterDetails.toString(), equals('preregister.details'));
      expect(FTUserClaim.preRegisterList.toString(), equals('preregister.list'));
      expect(FTUserClaim.profileDetails.toString(), equals('profile.details'));
      expect(FTUserClaim.profileEdit.toString(), equals('profile.edit'));
      expect(FTUserClaim.refundAccept.toString(), equals('refund.accept'));
      expect(FTUserClaim.salePaymentsCash.toString(), equals('sale.payments.cash'));
      expect(FTUserClaim.ticketEdit.toString(), equals('ticket.edit'));
      expect(FTUserClaim.ticketScan.toString(), equals('ticket.scan'));
      expect(FTUserClaim.ticketStatistics.toString(), equals('ticket.statistics'));
    });
  });
}
