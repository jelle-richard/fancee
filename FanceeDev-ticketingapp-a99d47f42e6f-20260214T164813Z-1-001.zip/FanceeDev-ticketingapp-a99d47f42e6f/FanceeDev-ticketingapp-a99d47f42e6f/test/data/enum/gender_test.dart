import 'package:fancee_ticketing/src/data/enum/gender.dart';
import 'package:test/test.dart';

void main() {
  group('FTGender', () {
    test('fromString() should always return the correct values.', () {
      expect(FTGender.fromString('Male'), equals(FTGender.male));
      expect(FTGender.fromString('Female'), equals(FTGender.female));
      expect(FTGender.fromString('Neutral'), equals(FTGender.neutral));
    });

    test('fromString() should return "not specified" for non-existing values.', () {
      expect(FTGender.fromString('unitgender'), equals(FTGender.notSpecified));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTGender.male.toString(), equals('Male'));
      expect(FTGender.female.toString(), equals('Female'));
      expect(FTGender.neutral.toString(), equals('Neutral'));
    });
  });
}
