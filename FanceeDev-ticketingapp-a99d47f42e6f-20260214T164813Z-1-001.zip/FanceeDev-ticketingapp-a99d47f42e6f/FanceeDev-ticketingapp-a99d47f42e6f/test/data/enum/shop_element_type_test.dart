import 'package:fancee_ticketing/src/data/enum/shop_element_type.dart';
import 'package:test/test.dart';

void main() {
  group('FTShopElementType', () {
    test('fromString() should always return the correct values.', () {
      expect(FTShopElementType.fromString('Divider'), equals(FTShopElementType.divider));
      expect(FTShopElementType.fromString('ExternalLink'), equals(FTShopElementType.externalLink));
      expect(FTShopElementType.fromString('Notice'), equals(FTShopElementType.notice));
      expect(FTShopElementType.fromString('Product'), equals(FTShopElementType.product));
      expect(FTShopElementType.fromString('TextBlock'), equals(FTShopElementType.textBlock));
    });

    test('fromString() should return "unknown" for non-existing values.', () {
      expect(FTShopElementType.fromString('unittype'), equals(FTShopElementType.unknown));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTShopElementType.divider.toString(), equals('Divider'));
      expect(FTShopElementType.externalLink.toString(), equals('ExternalLink'));
      expect(FTShopElementType.notice.toString(), equals('Notice'));
      expect(FTShopElementType.product.toString(), equals('Product'));
      expect(FTShopElementType.textBlock.toString(), equals('TextBlock'));
    });
  });
}
