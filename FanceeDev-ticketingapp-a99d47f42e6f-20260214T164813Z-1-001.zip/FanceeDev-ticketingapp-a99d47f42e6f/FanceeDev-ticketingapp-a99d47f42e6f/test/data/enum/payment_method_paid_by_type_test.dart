import 'package:fancee_ticketing/src/data/enum/payment_method_paid_by_type.dart';
import 'package:test/test.dart';

void main() {
  group('FTPaymentMethodPaidByType', () {
    test('fromString() should always return the correct values.', () {
      expect(FTPaymentMethodPaidByType.fromString('Client'), equals(FTPaymentMethodPaidByType.client));
      expect(FTPaymentMethodPaidByType.fromString('Organizer'), equals(FTPaymentMethodPaidByType.organizer));
    });

    test('fromString() should return "unknown" for non-existing values.', () {
      expect(FTPaymentMethodPaidByType.fromString('unittype'), equals(FTPaymentMethodPaidByType.unknown));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTPaymentMethodPaidByType.client.toString(), equals('Client'));
      expect(FTPaymentMethodPaidByType.organizer.toString(), equals('Organizer'));
    });
  });
}
