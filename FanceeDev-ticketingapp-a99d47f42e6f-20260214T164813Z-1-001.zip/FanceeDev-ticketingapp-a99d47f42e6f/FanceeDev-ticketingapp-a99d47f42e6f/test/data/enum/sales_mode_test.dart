import 'package:fancee_ticketing/src/data/enum/sales_mode.dart';
import 'package:test/test.dart';

void main() {
  group('FTSalesMode', () {
    test('fromString() should always return the correct values.', () {
      expect(FTSalesMode.fromString('doorsale'), equals(FTSalesMode.doorsale));
      expect(FTSalesMode.fromString('presale'), equals(FTSalesMode.presale));
    });

    test('fromString() should return "doorsale" for non-existing values.', () {
      expect(FTSalesMode.fromString('unitmode'), equals(FTSalesMode.doorsale));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTSalesMode.doorsale.toString(), equals('doorsale'));
      expect(FTSalesMode.presale.toString(), equals('presale'));
    });
  });
}
