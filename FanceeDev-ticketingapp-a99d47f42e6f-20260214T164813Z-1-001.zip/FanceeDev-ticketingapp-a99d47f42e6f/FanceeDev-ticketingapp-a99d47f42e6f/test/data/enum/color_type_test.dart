import 'package:fancee_ticketing/src/data/enum/color_type.dart';
import 'package:test/test.dart';

void main() {
  group('FTColorType', () {
    test('fromString() should always return the correct values.', () {
      expect(FTColorType.fromString('Primary'), equals(FTColorType.primary));
      expect(FTColorType.fromString('Secondary'), equals(FTColorType.secondary));
      expect(FTColorType.fromString('Success'), equals(FTColorType.success));
      expect(FTColorType.fromString('Warning'), equals(FTColorType.warning));
      expect(FTColorType.fromString('Danger'), equals(FTColorType.danger));
      expect(FTColorType.fromString('Info'), equals(FTColorType.info));
    });

    test('fromString() should return the default secondary color for non-existing values.', () {
      expect(FTColorType.fromString('unitcolor'), equals(FTColorType.secondary));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTColorType.primary.toString(), equals('Primary'));
      expect(FTColorType.secondary.toString(), equals('Secondary'));
      expect(FTColorType.success.toString(), equals('Success'));
      expect(FTColorType.warning.toString(), equals('Warning'));
      expect(FTColorType.danger.toString(), equals('Danger'));
      expect(FTColorType.info.toString(), equals('Info'));
    });
  });
}
