import 'package:fancee_ticketing/src/data/enum/product_type.dart';
import 'package:test/test.dart';

void main() {
  group('FTProductType', () {
    test('fromString() should always return the correct values.', () {
      expect(FTProductType.fromString('Product'), equals(FTProductType.product));
      expect(FTProductType.fromString('Ticket'), equals(FTProductType.ticket));
    });

    test('fromString() should return "unknown" for non-existing values.', () {
      expect(FTProductType.fromString('unittype'), equals(FTProductType.unknown));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTProductType.product.toString(), equals('Product'));
      expect(FTProductType.ticket.toString(), equals('Ticket'));
    });
  });
}
