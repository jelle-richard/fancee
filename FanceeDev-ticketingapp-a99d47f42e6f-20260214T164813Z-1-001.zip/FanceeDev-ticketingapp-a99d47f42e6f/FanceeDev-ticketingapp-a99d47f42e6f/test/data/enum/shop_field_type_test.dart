import 'package:fancee_ticketing/src/data/enum/shop_field_type.dart';
import 'package:test/test.dart';

void main() {
  group('FTShopFieldType', () {
    test('fromString() should always return the correct values.', () {
      expect(FTShopFieldType.fromString('Address'), equals(FTShopFieldType.address));
      expect(FTShopFieldType.fromString('Birthdate'), equals(FTShopFieldType.birthDate));
      expect(FTShopFieldType.fromString('City'), equals(FTShopFieldType.city));
      expect(FTShopFieldType.fromString('Country'), equals(FTShopFieldType.country));
      expect(FTShopFieldType.fromString('Email'), equals(FTShopFieldType.email));
      expect(FTShopFieldType.fromString('FirstName'), equals(FTShopFieldType.firstName));
      expect(FTShopFieldType.fromString('Gender'), equals(FTShopFieldType.gender));
      expect(FTShopFieldType.fromString('LastName'), equals(FTShopFieldType.lastName));
      expect(FTShopFieldType.fromString('Phone'), equals(FTShopFieldType.phoneNumber));
      expect(FTShopFieldType.fromString('Street'), equals(FTShopFieldType.street));
    });

    test('fromString() should return "unknown" for non-existing values.', () {
      expect(FTShopFieldType.fromString('unittype'), equals(FTShopFieldType.unknown));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTShopFieldType.address.toString(), equals('Address'));
      expect(FTShopFieldType.birthDate.toString(), equals('Birthdate'));
      expect(FTShopFieldType.city.toString(), equals('City'));
      expect(FTShopFieldType.country.toString(), equals('Country'));
      expect(FTShopFieldType.email.toString(), equals('Email'));
      expect(FTShopFieldType.firstName.toString(), equals('FirstName'));
      expect(FTShopFieldType.gender.toString(), equals('Gender'));
      expect(FTShopFieldType.lastName.toString(), equals('LastName'));
      expect(FTShopFieldType.phoneNumber.toString(), equals('Phone'));
      expect(FTShopFieldType.street.toString(), equals('Street'));
    });
  });
}
