import 'package:fancee_ticketing/src/data/enum/scan_result_type.dart';
import 'package:test/test.dart';

void main() {
  group('FTScanResultType', () {
    test('fromString() should always return the correct values.', () {
      expect(FTScanResultType.fromString('failed'), equals(FTScanResultType.failed));
      expect(FTScanResultType.fromString('invalid'), equals(FTScanResultType.invalid));
      expect(FTScanResultType.fromString('ok'), equals(FTScanResultType.ok));
      expect(FTScanResultType.fromString('reused'), equals(FTScanResultType.reused));
    });

    test('fromString() should return failed for non existing values.', () {
      expect(FTScanResultType.fromString('unittest'), equals(FTScanResultType.failed));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTScanResultType.failed.toString(), equals('failed'));
      expect(FTScanResultType.invalid.toString(), equals('invalid'));
      expect(FTScanResultType.ok.toString(), equals('ok'));
      expect(FTScanResultType.reused.toString(), equals('reused'));
    });
  });
}
