import 'dart:convert';

import 'package:fancee_ticketing/src/data/enum/scan_state.dart';
import 'package:test/test.dart';

void main() {
  group('FTScanState', () {
    test('fromString() should always return the correct values.', () {
      expect(FTScanState.fromString('Scanned'), equals(FTScanState.scanned));
      expect(FTScanState.fromString('Unscanned'), equals(FTScanState.unscanned));
      expect(FTScanState.fromString('Unknown'), equals(FTScanState.unknown));
    });

    test('fromString() should return unknown for non existing values.', () {
      expect(FTScanState.fromString('unittest'), equals(FTScanState.unknown));
    });

    test('toJson() should return the name of the enum case.', () {
      expect(jsonEncode(FTScanState.scanned), equals('"Scanned"'));
      expect(jsonEncode(FTScanState.unscanned), equals('"Unscanned"'));
      expect(jsonEncode(FTScanState.unknown), equals('"Unknown"'));
    });

    test('toString() should return the name of the enum case.', () {
      expect(FTScanState.scanned.toString(), equals('Scanned'));
      expect(FTScanState.unscanned.toString(), equals('Unscanned'));
      expect(FTScanState.unknown.toString(), equals('Unknown'));
    });
  });
}
