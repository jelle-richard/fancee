import 'package:fancee_ticketing/src/data/model/auth/token_response_model.dart';
import 'package:fancee_ticketing/src/data/model/user/app_team_user_model.dart';
import 'package:fancee_ticketing/src/data/model/user/organizer_user_model.dart';
import 'package:test/test.dart';

void main() {
  group('FTAuthTokenUserResponseModel', () {
    test('fromJson() should return correct values with a valid object.', () {
      final model = FTAuthTokenUserResponseModel.fromJson({
        'token': 'abc',
        'validUntil': '2022-03-13 09:00:04',
        'claims': ['claim1', 'claim2'],
        'user': {
          'id': '0fd3c594-0778-4e15-b16b-de7c4faa4566',
          'email': 'unit@tester.com',
          'firstName': 'Unit',
          'lastName': 'Tester',
          'type': 'Organizer',
          'lastLogin': '2022-03-13 09:00:04',
          'avatarFilePath': null,
        },
      });

      expect(model, isA<FTAuthTokenUserResponseModel>());
      expect(model.accessToken, equals('abc'));

      expect(model.validUntil, isA<DateTime>());
      expect(model.validUntil.toIso8601String(), equals('2022-03-13T09:00:04.000'));

      expect(model.user, isA<FTOrganizerUserModel>());
      expect((model.user as FTOrganizerUserModel).id, equals('0fd3c594-0778-4e15-b16b-de7c4faa4566'));
      expect((model.user as FTOrganizerUserModel).email, equals('unit@tester.com'));
      expect((model.user as FTOrganizerUserModel).firstName, equals('Unit'));
      expect((model.user as FTOrganizerUserModel).lastName, equals('Tester'));
      expect((model.user as FTOrganizerUserModel).type, equals('Organizer'));
      expect((model.user as FTOrganizerUserModel).lastLogin, isA<DateTime>());
      expect((model.user as FTOrganizerUserModel).avatarFilePath, isNull);

      expect(model.user.claims, contains('claim1'));
      expect(model.user.claims, contains('claim2'));
    });

    test('fromJson() should throw when an invalid object is provided.', () {
      expect(
        () => FTAuthTokenUserResponseModel.fromJson({
          'token': 5,
          'validUntil': 'heh',
          'claims': 'claim1',
          'user': {
            'id': '0fd3c594-0778-4e15-b16b-de7c4faa4566',
            'email': 'unit@tester.com',
            'firstName': true,
            'lastName': 'Tester',
            'type': 'Organizer',
            'lastLogin': 'heh',
            'avatarFilePath': null,
          },
        }),
        throwsFormatException,
      );

      expect(
        () => FTAuthTokenUserResponseModel.fromJson({
          'test': 'fails',
        }),
        throwsFormatException,
      );
    });
  });

  group('FTAuthTokenAppTeamResponseModel', () {
    test('fromJson() should return correct values with a valid object.', () {
      final model = FTAuthTokenAppTeamResponseModel.fromJson({
        'token': 'abc',
        'validUntil': '2022-03-13 09:00:04',
        'claims': ['claim1', 'claim2'],
        'id': '0fd3c594-0778-4e15-b16b-de7c4faa4566',
        'name': 'Unit Team',
        'organization': 'Tester Inc.',
      });

      expect(model, isA<FTAuthTokenAppTeamResponseModel>());
      expect(model.accessToken, equals('abc'));

      expect(model.validUntil, isA<DateTime>());
      expect(model.validUntil.toIso8601String(), equals('2022-03-13T09:00:04.000'));

      expect(model.user, isA<FTAppTeamUserModel>());
      expect((model.user as FTAppTeamUserModel).id, equals('0fd3c594-0778-4e15-b16b-de7c4faa4566'));
      expect((model.user as FTAppTeamUserModel).name, equals('Unit Team'));
      expect((model.user as FTAppTeamUserModel).organization, equals('Tester Inc.'));

      expect(model.user.claims, contains('claim1'));
      expect(model.user.claims, contains('claim2'));
    });

    test('fromJson() should throw when an invalid object is provided.', () {
      expect(
        () => FTAuthTokenUserResponseModel.fromJson({
          'token': 60,
          'validUntil': false,
          'claims': 'claim',
          'id': 13,
          'name': 'Unit Team',
          'organization': true,
        }),
        throwsFormatException,
      );

      expect(
        () => FTAuthTokenUserResponseModel.fromJson({
          'test': 'fails',
        }),
        throwsFormatException,
      );
    });
  });
}
