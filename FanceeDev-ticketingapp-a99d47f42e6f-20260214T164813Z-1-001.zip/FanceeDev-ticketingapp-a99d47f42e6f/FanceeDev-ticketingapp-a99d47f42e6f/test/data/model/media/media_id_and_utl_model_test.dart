import 'package:fancee_ticketing/src/data/model/media/media_id_and_url_model.dart';
import 'package:test/test.dart';

void main() {
  group('FTMediaIdAndUrlModel', () {
    test('fromJson() should return correct values with a valid object.', () {
      final model = FTMediaIdAndUrlModel.fromJson({
        'id': 'media id',
        'url': 'media url',
      });

      expect(model, isA<FTMediaIdAndUrlModel>());
      expect(model.id, equals('media id'));
      expect(model.url, equals('media url'));
    });

    test('fromJson() should throw when an invalid object is provided.', () {
      expect(
        () => FTMediaIdAndUrlModel.fromJson({
          'id': 34,
          'blob': 'media blob',
        }),
        throwsFormatException,
      );
    });
  });
}
