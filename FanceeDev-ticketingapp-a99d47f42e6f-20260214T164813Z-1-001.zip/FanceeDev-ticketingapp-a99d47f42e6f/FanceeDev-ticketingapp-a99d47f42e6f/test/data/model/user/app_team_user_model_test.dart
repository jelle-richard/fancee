import 'package:fancee_ticketing/src/data/enum/user_type.dart';
import 'package:fancee_ticketing/src/data/model/user/app_team_user_model.dart';
import 'package:test/test.dart';

void main() {
  group('FTAppTeamUserModel', () {
    test('fromJson() should return correct values with a valid object.', () {
      final model = FTAppTeamUserModel.fromJson({
        'id': '0fd3c594-0778-4e15-b16b-de7c4faa4566',
        'claims': ['claim1', 'claim2'],
        'name': 'Unit Team',
        'organization': 'Tester Inc.',
      });

      expect(model, isA<FTAppTeamUserModel>());
      expect(model.id, equals('0fd3c594-0778-4e15-b16b-de7c4faa4566'));
      expect(model.claims, contains('claim1'));
      expect(model.claims, contains('claim2'));
      expect(model.name, equals('Unit Team'));
      expect(model.organization, equals('Tester Inc.'));
      expect(model.userType, equals(FTUserType.appTeam));
      expect(model.isAppTeam, isTrue);
      expect(model.isOrganizer, isFalse);
      expect(model.displayName, equals('Unit Team'));
      expect(model.displayInfo, equals('Tester Inc.'));
    });
  });
}
