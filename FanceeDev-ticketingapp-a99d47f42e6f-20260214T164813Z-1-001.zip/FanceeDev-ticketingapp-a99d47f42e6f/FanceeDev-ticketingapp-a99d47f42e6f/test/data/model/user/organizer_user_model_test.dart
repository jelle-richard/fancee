import 'package:fancee_ticketing/src/data/enum/user_type.dart';
import 'package:fancee_ticketing/src/data/model/user/organizer_user_model.dart';
import 'package:test/test.dart';

void main() {
  group('FTOrganizerUserModel', () {
    test('fromJson() should return correct values with a valid object.', () {
      final model = FTOrganizerUserModel.fromJson({
        'id': '0fd3c594-0778-4e15-b16b-de7c4faa4566',
        'claims': ['claim1', 'claim2'],
        'email': 'unit@tester.com',
        'firstName': 'Unit',
        'lastName': 'Tester',
        'type': 'Organizer',
        'lastLogin': '2022-03-13 09:00:04',
        'avatarFilePath': null,
      });

      expect(model, isA<FTOrganizerUserModel>());
      expect(model.id, equals('0fd3c594-0778-4e15-b16b-de7c4faa4566'));
      expect(model.claims, contains('claim1'));
      expect(model.claims, contains('claim2'));
      expect(model.email, equals('unit@tester.com'));
      expect(model.firstName, equals('Unit'));
      expect(model.lastName, equals('Tester'));
      expect(model.type, equals('Organizer'));
      expect(model.lastLogin, isA<DateTime>());
      expect(model.lastLogin.toIso8601String(), equals('2022-03-13T09:00:04.000'));
      expect(model.userType, equals(FTUserType.organizer));
      expect(model.isAppTeam, isFalse);
      expect(model.isOrganizer, isTrue);
      expect(model.displayName, equals('Unit Tester'));
      expect(model.displayInfo, equals('unit@tester.com'));
    });
  });
}
