import 'package:fancee_ticketing/src/data/model/media/media.dart';
import 'package:fancee_ticketing/src/data/model/scan/scan_statistic_ticket_model.dart';
import 'package:test/test.dart';

void main() {
  group('FTScanStatisticTicketModel', () {
    test('fromJson() should return correct values with a valid object.', () {
      final model = FTScanStatisticTicketModel.fromJson({
        'id': 'ticket id',
        'name': 'ticket name',
        'media': [
          {
            'id': 'media id',
            'url': 'media url',
          }
        ],
        'amountIssued': 10,
        'amountScanned': 5,
      });

      expect(model, isA<FTScanStatisticTicketModel>());
      expect(model.id, equals('ticket id'));
      expect(model.name, equals('ticket name'));
      expect(model.amountIssued, equals(10));
      expect(model.amountScanned, equals(5));

      expect(model.media, hasLength(1));
      expect(model.media.first, isA<FTMediaIdAndUrlModel>());
      expect(model.media.first.id, equals('media id'));
      expect(model.media.first.url, equals('media url'));
    });

    test('fromJson() should throw when an invalid object is provided.', () {
      expect(
        () => FTScanStatisticTicketModel.fromJson({
          'id': 54,
          'name': 'ticket name',
          'media': [
            {
              'id': 13,
              'url': 'media url',
            }
          ],
          'amountIssued': 'five',
          'amountScanned': 5,
        }),
        throwsFormatException,
      );
    });
  });
}
