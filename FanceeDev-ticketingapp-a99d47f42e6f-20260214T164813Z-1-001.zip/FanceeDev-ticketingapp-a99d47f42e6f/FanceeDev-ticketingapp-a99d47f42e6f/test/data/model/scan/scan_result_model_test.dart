import 'package:fancee_ticketing/src/data/enum/scan_result_type.dart';
import 'package:fancee_ticketing/src/data/model/scan/scan_result_model.dart';
import 'package:test/test.dart';

void main() {
  group('FTScanResult', () {
    test('failed() should not have a message, but should have a reason.', () {
      const model = FTScanResultModel.failed(reason: 'reason');

      expect(model, isA<FTScanResultModel>());
      expect(model.type, FTScanResultType.failed);
      expect(model.message, isNull);
      expect(model.reason, isNotNull);
      expect(model.reason, equals('reason'));
    });

    test('invalid() should not have a message, but should have a reason.', () {
      const model = FTScanResultModel.invalid(reason: 'reason');

      expect(model, isA<FTScanResultModel>());
      expect(model.type, FTScanResultType.invalid);
      expect(model.message, isNull);
      expect(model.reason, isNotNull);
      expect(model.reason, equals('reason'));
    });

    test('ok() should have a message, but should not have a reason.', () {
      const model = FTScanResultModel.ok(message: 'message');

      expect(model, isA<FTScanResultModel>());
      expect(model.type, FTScanResultType.ok);
      expect(model.message, isNotNull);
      expect(model.message, equals('message'));
      expect(model.reason, isNull);
    });

    test('reused() should have a message, but should not have a reason.', () {
      const model = FTScanResultModel.reused(message: 'message');

      expect(model, isA<FTScanResultModel>());
      expect(model.type, FTScanResultType.reused);
      expect(model.message, isNotNull);
      expect(model.message, equals('message'));
      expect(model.reason, isNull);
    });
  });
}
