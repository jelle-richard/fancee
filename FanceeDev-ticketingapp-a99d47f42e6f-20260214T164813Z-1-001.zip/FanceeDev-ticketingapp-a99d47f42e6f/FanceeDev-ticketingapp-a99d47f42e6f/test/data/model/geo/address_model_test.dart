import 'package:fancee_ticketing/src/data/model/geo/address_model.dart';
import 'package:test/test.dart';

void main() {
  group('FTAddressModel', () {
    test('fromJson() should return a model with the correct values when given a valid object.', () {
      final model = FTAddressModel.fromJson({
        'street': 'UnitStreet',
        'houseNumber': '13B',
        'postalCode': '7006 RV',
        'city': 'UnitCity',
        'countryCode': 'NL',
        'venue': 'UnitVenue',
        'latitude': 1.23,
        'longitude': 3.21,
      });

      expect(model, isA<FTAddressModel>());
      expect(model.street, equals('UnitStreet'));
      expect(model.houseNumber, equals('13B'));
      expect(model.postalCode, equals('7006 RV'));
      expect(model.city, equals('UnitCity'));
      expect(model.countryCode, equals('NL'));
      expect(model.venue, equals('UnitVenue'));
      expect(model.latitude, equals(1.23));
      expect(model.longitude, equals(3.21));
    });

    test('fromJson() should return a model with the correct values when given a valid object with nullable values.', () {
      final model = FTAddressModel.fromJson({
        'street': null,
        'houseNumber': '13B',
        'postalCode': '7006 RV',
        'city': null,
        'countryCode': 'NL',
        'venue': null,
        'latitude': 1.23,
        'longitude': 3.21,
      });

      expect(model, isA<FTAddressModel>());
      expect(model.street, equals(null));
      expect(model.houseNumber, equals('13B'));
      expect(model.postalCode, equals('7006 RV'));
      expect(model.city, equals(null));
      expect(model.countryCode, equals('NL'));
      expect(model.venue, equals(null));
      expect(model.latitude, equals(1.23));
      expect(model.longitude, equals(3.21));
    });

    test('fromJson() should throw when given an invalid object.', () {
      expect(
        () => FTAddressModel.fromJson({
          'street': DateTime.now(),
          'houseNumber': 13,
          'postalCode': 7006,
          'city': 'UnitCity',
          'countryCode': 'NL',
          'venue': null,
          'latitude': '1.23',
          'longitude': '3.21',
        }),
        throwsFormatException,
      );
    });
  });
}
