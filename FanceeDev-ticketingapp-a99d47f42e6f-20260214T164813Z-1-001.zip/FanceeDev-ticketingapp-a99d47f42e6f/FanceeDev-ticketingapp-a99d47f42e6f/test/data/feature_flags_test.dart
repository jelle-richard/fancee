import 'package:fancee_ticketing/src/data/data.dart';
import 'package:test/test.dart';

void main() {
  group('FTFeatureFlags', () {
    test('defaults() should only have feature flags that are ready for prime time.', () {
      const features = FTFeatureFlags.defaults();

      expect(features.isEnabled(FTFeatureFlag.authForgotPasswordEnabled), isTrue);
      expect(features.isEnabled(FTFeatureFlag.authScanToSignInEnabled), isTrue);
      expect(features.isEnabled(FTFeatureFlag.dev), isFalse);
      expect(features.isEnabled(FTFeatureFlag.salesEnabled), isTrue);
      expect(features.isEnabled(FTFeatureFlag.scanEnabled), isTrue);
      expect(features.isEnabled(FTFeatureFlag.statisticsEnabled), isTrue);
    });

    test('all() should contain all of the available feature flags.', () {
      const features = FTFeatureFlags.all();

      for (final flag in FTFeatureFlag.values) {
        expect(features.isEnabled(flag), isTrue);
      }
    });
  });
}
