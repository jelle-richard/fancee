import 'dart:convert';

import 'package:fancee_ticketing/src/data/http/errors.dart';
import 'package:test/test.dart';

void main() {
  group('FTHttpError', () {
    test('empty() should be empty.', () {
      var errors = const FTHttpErrors.empty();

      expect(errors.hasErrors, isFalse);
      expect(errors.pairs, isMap);
      expect(errors.pairs, isEmpty);
      expect(errors['FAN-1'], isNull);
    });

    test('fromMap() should have a single value with two messages.', () {
      var errors = const FTHttpErrors.fromMap({
        'FAN-1': ['error 1', 'error 2'],
      });

      expect(errors.hasErrors, isTrue);
      expect(errors.pairs, isMap);
      expect(errors.pairs, isNotEmpty);
      expect(errors.contains('FAN-1'), isTrue);
      expect(errors.contains('FAN-2'), isFalse);
      expect(errors['FAN-1'], isA<String>());
      expect(errors['FAN-1'], equals('error 1\nerror 2'));
      expect(errors.getMessages('FAN-1'), equals(['error 1', 'error 2']));
    });

    test('fromJson() should have a single value with two messages.', () {
      var errors = FTHttpErrors.fromJson(json.decode('{"FAN-1": ["error 1", "error 2"]}'));

      expect(errors.hasErrors, isTrue);
      expect(errors.pairs, isMap);
      expect(errors.pairs, isNotEmpty);
      expect(errors.contains('FAN-1'), isTrue);
      expect(errors.contains('FAN-2'), isFalse);
      expect(errors['FAN-1'], isA<String>());
      expect(errors['FAN-1'], equals('error 1\nerror 2'));
      expect(errors.getMessages('FAN-1'), equals(['error 1', 'error 2']));
    });
  });
}
