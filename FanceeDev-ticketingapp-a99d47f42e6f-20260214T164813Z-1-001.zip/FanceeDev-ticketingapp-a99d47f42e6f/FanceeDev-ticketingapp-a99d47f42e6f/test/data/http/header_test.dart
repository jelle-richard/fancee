import 'package:fancee_ticketing/src/data/http/header.dart';
import 'package:test/test.dart';

void main() {
  group('FTHttpHeader', () {
    test('fromString() should return correct header', () {
      expect(FTHttpHeader.fromString('Authorization'), equals(FTHttpHeader.authorization));
      expect(FTHttpHeader.fromString('Access-Control-Allow-Origin'), equals(FTHttpHeader.accessControlAllowOrigin));
      expect(FTHttpHeader.fromString('accept-language'), equals(FTHttpHeader.acceptLanguage));
      expect(FTHttpHeader.fromString('we / are-fancee'), equals(FTHttpHeader.unknown));
    });

    test('toString() should return correct header name', () {
      expect(FTHttpHeader.authorization.value, equals('authorization'));
      expect(FTHttpHeader.accessControlAllowOrigin.value, equals('access-control-allow-origin'));
      expect(FTHttpHeader.acceptLanguage.value, equals('accept-language'));
      expect(FTHttpHeader.unknown.value, equals('?'));
    });
  });
}
