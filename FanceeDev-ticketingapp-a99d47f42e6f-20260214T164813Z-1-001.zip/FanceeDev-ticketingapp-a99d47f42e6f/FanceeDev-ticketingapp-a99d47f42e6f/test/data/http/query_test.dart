import 'package:fancee_ticketing/src/data/data.dart';
import 'package:test/test.dart';

void main() {
  group('FTHttpQuery', () {
    test('fromPairs() should return the correct query string.', () {
      final query = FTHttpQuery.fromPairs({
        'string': 'hi',
        'int': 10,
        'bool': false
      });

      expect(query.toString(), equals('string=hi&int=10&bool=0'));
    });

    test('fromString() should create the correct instance.', () {
      final query = FTHttpQuery.fromString('string=hi&int=10&bool=0');

      expect(query.toString(), equals('string=hi&int=10&bool=0'));
      expect(query.pairs['string']![0], equals('hi'));
      expect(query.pairs['int']![0], equals('10'));
      expect(query.pairs['bool']![0], equals('0'));
    });
  });
}
