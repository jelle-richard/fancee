import 'package:carrot/carrot.dart';
import 'package:fancee_ticketing/src/config.dart';
import 'package:test/test.dart';

void main() {
  group('FTConfig', () {
    test('Config should have the expected values.', () {
      expect(FTConfig.title, equals('Fancee Ticketing'));
      expect(FTConfig.defaultIconStyle, equals(CarrotIconStyle.regular));
    });
  });
}
