import 'package:carrot/carrot.dart';
import 'package:fancee_ticketing/src/theme.dart';
import 'package:test/test.dart';

void main() {
  group('FTTheme', () {
    test('Theme should return the correct values.', () {
      expect(FTTheme.dark, isA<CarrotThemeData>());
      expect(FTTheme.light, isA<CarrotThemeData>());
    });
  });
}
