import 'package:fancee_ticketing/src/data/data.dart';
import 'package:fancee_ticketing/src/routes.dart';
import 'package:test/test.dart';

void main() {
  group('FTRoutes', () {
    test('Route methods should return the correct values.', () {
      expect(FTRoutes.authForgotPassword(), equals('/forgot-password'));
      expect(FTRoutes.authLogin(), equals('/login'));
      expect(FTRoutes.authScanSignIn(), equals('/scan-sign-in'));
      expect(FTRoutes.more(), equals('/more'));
      expect(FTRoutes.moreDev(), equals('/more/dev'));
      expect(FTRoutes.moreDevUI(), equals('/more/dev/ui'));
      expect(FTRoutes.morePinTerminals(), equals('/more/pin-terminals'));
      expect(FTRoutes.morePrinters(), equals('/more/printers'));
      expect(FTRoutes.moreSettings(), equals('/more/settings'));
      expect(FTRoutes.noticeUnsupportedUser(), equals('/notice/unsupported-user'));
      expect(FTRoutes.sales(), equals('/sales'));
      expect(FTRoutes.salesDetails('event-id', 'shop-code', 'shop name'), equals('/sales/event-id/shop-code/details?shopName=shop+name'));
      expect(FTRoutes.salesOrder('order-id'), equals('/sales/order/order-id'));
      expect(FTRoutes.salesShop('event-id', 'shop-code', 'shop name'), equals('/sales/event-id/shop-code?shopName=shop+name'));
      expect(FTRoutes.salesSummary('event-id', 'shop-code', 'shop name'), equals('/sales/event-id/shop-code/summary?shopName=shop+name'));
      expect(FTRoutes.scan(), equals('/scan'));
      expect(FTRoutes.scanCamera(), equals('/scan/camera'));
      expect(FTRoutes.scanResult(FTScanResultType.ok, 'message', 'reason'), equals('/scan/result/ok?message=message&reason=reason'));
      expect(FTRoutes.statistics(), equals('/statistics'));
      expect(FTRoutes.statisticsEvent('event-id', 'event name'), equals('/statistics/event-id?eventName=event+name'));
    });
  });
}
