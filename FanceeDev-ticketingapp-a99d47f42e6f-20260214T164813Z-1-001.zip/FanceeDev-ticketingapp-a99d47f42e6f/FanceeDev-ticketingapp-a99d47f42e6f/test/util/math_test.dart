import 'package:fancee_ticketing/src/util/math.dart';
import 'package:flutter/animation.dart';
import 'package:test/test.dart';

void main() {
  group('Math utilities', () {
    test('calculateAngle() should calculate the correct angle between to points.', () {
      expect(calculateAngle(const Offset(10, 10), const Offset(20, 20)), equals(45.0));
      expect(calculateAngle(const Offset(20, 20), const Offset(10, 10)), equals(-135.0));
    });

    test('euclideanDistance() should calculate the correct distance between to points.', () {
      expect(euclideanDistance(const Offset(10, 10), const Offset(20, 20)), equals(14.142135623730951));
      expect(euclideanDistance(const Offset(20, 20), const Offset(10, 10)), equals(14.142135623730951));
    });
  });
}
