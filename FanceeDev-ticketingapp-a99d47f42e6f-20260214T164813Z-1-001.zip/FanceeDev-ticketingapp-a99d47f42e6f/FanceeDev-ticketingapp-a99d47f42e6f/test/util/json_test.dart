import 'package:fancee_ticketing/src/util/json.dart';
import 'package:test/test.dart';

/// note: the json utility functions expect dynamic values.
const _true = true as dynamic;
const _false = false as dynamic;
const _double = 1.4 as dynamic;
const _list = ['a', 1, 'b', 2, 'c'] as dynamic;
const _int = 13 as dynamic;
const _string = 'unittest' as dynamic;
const _listBooleans = [true, false, true] as dynamic;
const _listDoubles = [1.1, 2.2, 3.3] as dynamic;
const _listIntegers = [1, 2, 3] as dynamic;
const _listStrings = ['a', 'b', 'c'] as dynamic;

void main() {
  group('Json utilities', () {
    test('toBoolean() should return correctly.', () {
      expect(toBoolean(_true), isTrue);
      expect(toBoolean(_false), isFalse);
      expect(() => toBoolean(null), throwsFormatException);
      expect(() => toBoolean(_double), throwsFormatException);
      expect(() => toBoolean(_int), throwsFormatException);
      expect(() => toBoolean(_list), throwsFormatException);
      expect(() => toBoolean(_string), throwsFormatException);
    });

    test('toDateTime() should return correctly.', () {
      expect(toDateTime('2022-03-13 09:00:04'), isA<DateTime>());
      expect(toDateTime('2022-03-13 09:00:04').toIso8601String(), equals('2022-03-13T09:00:04.000'));
      expect(() => toDateTime(null), throwsFormatException);
      expect(() => toDateTime(_true), throwsFormatException);
      expect(() => toDateTime(_false), throwsFormatException);
      expect(() => toDateTime(_double), throwsFormatException);
      expect(() => toDateTime(_int), throwsFormatException);
      expect(() => toDateTime(_list), throwsFormatException);
      expect(() => toDateTime(_string), throwsFormatException);
    });

    test('toDouble() should return correctly.', () {
      expect(toDouble(_double), equals(1.4));
      expect(toDouble(_int), equals(13));
      expect(() => toDouble(null), throwsFormatException);
      expect(() => toDouble(_true), throwsFormatException);
      expect(() => toDouble(_false), throwsFormatException);
      expect(() => toDouble(_list), throwsFormatException);
      expect(() => toDouble(_string), throwsFormatException);
    });

    test('toInt() should return correctly.', () {
      expect(toInt(_int), equals(13));
      expect(() => toInt(null), throwsFormatException);
      expect(() => toInt(_true), throwsFormatException);
      expect(() => toInt(_false), throwsFormatException);
      expect(() => toInt(_double), throwsFormatException);
      expect(() => toInt(_list), throwsFormatException);
      expect(() => toInt(_string), throwsFormatException);
    });

    test('toList() should return correctly.', () {
      expect(toList(_list), equals(['a', 1, 'b', 2, 'c']));
      expect(() => toList(null), throwsFormatException);
      expect(() => toList(_true), throwsFormatException);
      expect(() => toList(_false), throwsFormatException);
      expect(() => toList(_double), throwsFormatException);
      expect(() => toList(_int), throwsFormatException);
      expect(() => toList(_string), throwsFormatException);
    });

    test('toNullable() should return correctly.', () {
      expect(toNullable(_double, toDouble), equals(1.4));
      expect(toNullable(_int, toInt), equals(13));
      expect(toNullable(_list, toList), equals(['a', 1, 'b', 2, 'c']));
      expect(toNullable(_string, toString), equals('unittest'));
      expect(toNullable(_true, toBoolean), equals(true));

      expect(toNullable(null, toDouble), isNull);
      expect(toNullable(null, toInt), isNull);
      expect(toNullable(null, toList), isNull);
      expect(toNullable(null, toString), isNull);
      expect(toNullable(null, toBoolean), isNull);
    });

    test('toString() should return correctly.', () {
      expect(toString(_string), equals('unittest'));
      expect(() => toString(null), throwsFormatException);
      expect(() => toString(_true), throwsFormatException);
      expect(() => toString(_false), throwsFormatException);
      expect(() => toString(_double), throwsFormatException);
      expect(() => toString(_int), throwsFormatException);
      expect(() => toString(_list), throwsFormatException);
    });

    test('toBooleanList() should return correctly.', () {
      expect(toBooleanList(_listBooleans), equals([true, false, true]));
      expect(() => toBooleanList(_list), throwsFormatException);
    });

    test('toDoubleList() should return correctly.', () {
      expect(toDoubleList(_listDoubles), equals([1.1, 2.2, 3.3]));
      expect(() => toDoubleList(_list), throwsFormatException);
    });

    test('toIntList() should return correctly.', () {
      expect(toIntList(_listIntegers), equals([1, 2, 3]));
      expect(() => toIntList(_list), throwsFormatException);
    });

    test('toStringList() should return correctly.', () {
      expect(toStringList(_listStrings), equals(['a', 'b', 'c']));
      expect(() => toStringList(_listBooleans), throwsFormatException);
    });
  });
}
