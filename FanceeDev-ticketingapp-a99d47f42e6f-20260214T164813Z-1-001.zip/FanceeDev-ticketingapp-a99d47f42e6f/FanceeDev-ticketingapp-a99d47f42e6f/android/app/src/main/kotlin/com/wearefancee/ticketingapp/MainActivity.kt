package com.wearefancee.ticketingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
