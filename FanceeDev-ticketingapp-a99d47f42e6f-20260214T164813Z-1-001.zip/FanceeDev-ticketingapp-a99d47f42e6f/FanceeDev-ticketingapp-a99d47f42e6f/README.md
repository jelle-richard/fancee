# Fancee Ticketing App

A Flutter app for Fancee Ticketing.

### 🔧 Requirements

We're using Flutter to create our app, so let's install that and create our development environment.

1. Follow the installation steps from [the flutter website](https://docs.flutter.dev/get-started/install).
2. You can use your preferred IDE to work with Flutter. Flutter has plugins available for them. For example,
   if you use IntelliJ, you can use the [Flutter IntelliJ plugin](https://flutter.dev/docs/get-started/install/intellij).
3. Install [Android Studio](https://developer.android.com/studio) for the Android SDK.
4. For macOS only: Install xcode and the command line tools for iOS SDKs and Simulators.
5. Run `flutter doctor` in your terminal to check if everything is installed correctly.

### 🚀 Getting started

1. ...

### 📦 Dependencies
- **[carrot](https://github.com/basmilius/flutter-carrot)** - Main UI.
- **[connectivity_plus](https://pub.dev/packages/connectivity_plus)** - To check if there is an internet connection available.
- **[device_info_plus](https://pub.dev/packages/)** - To get information about the running device.
- **[esc_pos_printer](https://pub.dev/packages/esc_pos_printer)** - For connecting to thermal printers.
- **[esc_pos_utils](https://pub.dev/packages/esc_pos_utils)** - For easely creating receipts for the thermal printer.
- **[flutter_bloc](https://pub.dev/packages/flutter_bloc)** - Global state management.
- **[image](https://pub.dev/packages/image)** - For image support to thermal printers.
- **[intl](https://pub.dev/packages/intl)** - Internationalization.
- **[lottie](https://pub.dev/packages/lottie)** - For animations that are used througout the app.
- **[mobile_scanner](https://pub.dev/packages/mobile_scanner)** - Library for scanning Barcodes and QR-codes.
- **[network_info_plus](https://pub.dev/packages/network_info_plus)** - For getting information about the network.
- **[package_info_plus](https://pub.dev/packages/package_info_plus)** - For getting information about the installed app bundle.
- **[permission_handler](https://pub.dev/packages/permission_handler)** - For checking platform permissions.
- **[shared_preferences](https://pub.dev/packages/shared_preferences)** - For saving local preferences to the device.
- **[syncfusion_flutter_charts](https://pub.dev/packages/syncfusion_flutter_charts)** - For customizable charts.
- **[syncfusion_localizations](https://pub.dev/packages/syncfusion_localizations)** - Localizations for syncfusion_flutter_charts.
- **[url_launcher](https://pub.dev/packages/url_launcher)** - For launching urls and apps.

### Definition of done

1. The app builds and has no compile time errors.
2. The official dart coding style is used and forced on all the files you've worked on.
3. 
