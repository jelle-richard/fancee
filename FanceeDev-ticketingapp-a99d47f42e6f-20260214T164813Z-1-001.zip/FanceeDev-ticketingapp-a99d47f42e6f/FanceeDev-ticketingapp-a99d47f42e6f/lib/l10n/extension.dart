import 'package:carrot/carrot.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

extension FTLocaleExtension on BuildContext {
  AppLocalizations get strings => AppLocalizations.of(this)!;
}
