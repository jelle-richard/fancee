import '../../util/util.dart';
import 'pin_terminal_brand.dart';

class FTPinTerminalModel {
  final FTPinTerminalBrand brand;
  final String name;
  final String serial;

  const FTPinTerminalModel({
    required this.brand,
    required this.name,
    required this.serial,
  });

  String get serialNumber => '${brand.id}-$serial';

  factory FTPinTerminalModel.fromJson(dynamic json) => FTPinTerminalModel(
        brand: FTPinTerminalBrand.fromString(toString(json['brand'])),
        name: toString(json['name']),
        serial: toString(json['serial']),
      );

  Map<String, dynamic> toJson() => {
        'brand': brand,
        'name': name,
        'serial': serial,
      };
}
