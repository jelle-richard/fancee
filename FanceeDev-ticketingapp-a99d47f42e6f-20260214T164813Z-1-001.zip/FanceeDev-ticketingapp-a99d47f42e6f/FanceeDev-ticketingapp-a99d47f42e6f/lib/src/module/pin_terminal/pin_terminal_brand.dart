enum FTPinTerminalBrand {
  unknown('unknown', 'unknown', isSelectable: false),
  e280('e280', 'E280'),
  e285('e285', 'E285'),
  e285p('e285p', 'E285p'),
  m400('m400', 'M400'),
  p400Plus('P400Plus', 'P400 Plus'),
  p400cPlus('p400cPlus', 'P400c Plus'),
  s1e('s1e', 'S1E'),
  s1f2('s1f2', 'S1F2'),
  v240mPlus('v240mPlus', 'v240m Plus'),
  v400m('v400m', 'v400m'),
  ux300('ux300', 'UX300'),
  ux410('ux410', 'UX410');

  final String id;
  final String displayName;
  final bool isSelectable;

  const FTPinTerminalBrand(
    this.id,
    this.displayName, {
    this.isSelectable = true,
  });

  factory FTPinTerminalBrand.fromString(String name) => values.firstWhere(
        (brand) => brand.name == name,
        orElse: () => FTPinTerminalBrand.unknown,
      );

  String toJson() => name;

  @override
  String toString() => displayName;
}
