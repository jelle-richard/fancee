import 'package:assets_audio_player/assets_audio_player.dart';

import '../../data/data.dart';

class FTAudio {
  final FTUserState userState;

  const FTAudio(
    this.userState,
  );

  void scannerValid() {
    if (!userState.scannerFeedbackAudio) {
      return;
    }

    AssetsAudioPlayer.playAndForget(
      Audio('assets/audio/scanner_valid.mp3'),
      volume: .5,
    );
  }

  void scannerInvalid() {
    if (!userState.scannerFeedbackAudio) {
      return;
    }

    AssetsAudioPlayer.playAndForget(
      Audio('assets/audio/scanner_invalid.mp3'),
      volume: .5,
    );
  }
}
