import 'package:flutter/services.dart';
import 'package:vibration/vibration.dart';

import '../../data/data.dart';

class FTHaptics {
  final FTUserState userState;

  Future<bool> get hasVibrator async => await Vibration.hasVibrator() ?? false;

  const FTHaptics(
    this.userState,
  );

  void scannerValid() async {
    if (!userState.scannerFeedbackHaptics || !await hasVibrator) {
      return;
    }

    await Future.delayed(const Duration(milliseconds: 300));
    HapticFeedback.mediumImpact();
    await Future.delayed(const Duration(milliseconds: 200));
    HapticFeedback.lightImpact();
  }

  void scannerInvalid() async {
    if (!userState.scannerFeedbackHaptics || !await hasVibrator) {
      return;
    }

    await Future.delayed(const Duration(milliseconds: 300));
    await Vibration.vibrate(duration: 500);
  }
}
