import 'dart:typed_data';

import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:image/image.dart';

class FTThermalPrinterBuilder {
  List<int> _bytes;
  final Generator _generator;

  List<int> get bytes => _bytes;

  FTThermalPrinterBuilder(PaperSize paperSize, CapabilityProfile profile)
      : _bytes = [],
        _generator = Generator(paperSize, profile);

  void reset() {
    _bytes = _generator.reset();
  }

  void rawBytes(List<int> command, {bool isKanji = false}) {
    _bytes += _generator.rawBytes(
      command,
      isKanji: isKanji,
    );
  }

  void setGlobalCodeTable({String? codeTable}) {
    _bytes += _generator.setGlobalCodeTable(codeTable);
  }

  void setGlobalFont(
    PosFontType font, {
    int? maxCharsPerLine,
  }) {
    _bytes += _generator.setGlobalFont(
      font,
      maxCharsPerLine: maxCharsPerLine,
    );
  }

  void setStyles(PosStyles styles, {bool isKanji = false}) {
    _bytes += _generator.setStyles(
      styles,
      isKanji: isKanji,
    );
  }

  void barcode(
    Barcode barcode, {
    int? width,
    int? height,
    BarcodeFont? font,
    BarcodeText text = BarcodeText.below,
    PosAlign align = PosAlign.left,
  }) {
    _bytes += _generator.barcode(
      barcode,
      align: align,
      font: font,
      height: height,
      textPos: text,
      width: width,
    );
  }

  void beep({
    int amount = 3,
    PosBeepDuration duration = PosBeepDuration.beep450ms,
  }) {
    _bytes += _generator.beep(
      n: amount,
      duration: duration,
    );
  }

  void cut({PosCutMode mode = PosCutMode.full}) {
    _bytes += _generator.cut(
      mode: mode,
    );
  }

  void drawer({PosDrawer pin = PosDrawer.pin2}) {
    _bytes += _generator.drawer(
      pin: pin,
    );
  }

  void emptyLines(int lines) {
    _bytes += _generator.emptyLines(lines);
  }

  void feed(int lines) {
    _bytes += _generator.feed(lines);
  }

  void hr({String character = '-', int? length, int linesAfter = 0}) {
    _bytes += _generator.hr(
      ch: character,
      len: length,
      linesAfter: linesAfter,
    );
  }

  void image(
    Image image, {
    PosAlign align = PosAlign.left,
  }) {
    _bytes += _generator.image(
      image,
      align: align,
    );
  }

  void imageRaster(
    Image image, {
    PosAlign align = PosAlign.left,
    bool highDensityHorizontal = true,
    bool highDensityVertical = true,
    PosImageFn imageFunction = PosImageFn.bitImageRaster,
  }) {
    _bytes = _generator.imageRaster(
      image,
      align: align,
      highDensityHorizontal: highDensityHorizontal,
      highDensityVertical: highDensityVertical,
      imageFn: imageFunction,
    );
  }

  void qrcode(
    String text, {
    PosAlign align = PosAlign.left,
    QRSize size = QRSize.Size4,
    QRCorrection correction = QRCorrection.L,
  }) {
    _bytes += _generator.qrcode(
      text,
      align: align,
      cor: correction,
      size: size,
    );
  }

  void reverseFeed(int lines) {
    _bytes += _generator.reverseFeed(lines);
  }

  void row(List<PosColumn> columns) {
    _bytes += _generator.row(columns);
  }

  void text(
    String text, {
    PosStyles styles = const PosStyles(),
    int linesAfter = 0,
    bool containsChinese = false,
    int? maxCharsPerLine,
  }) {
    _bytes += _generator.text(
      text,
      containsChinese: containsChinese,
      linesAfter: linesAfter,
      maxCharsPerLine: maxCharsPerLine,
      styles: styles,
    );
  }

  void textEncoded(Uint8List bytes, {PosStyles styles = const PosStyles(), int linesAfter = 0, int? maxCharsPerLine}) {
    _bytes += _generator.textEncoded(
      bytes,
      linesAfter: linesAfter,
      maxCharsPerLine: maxCharsPerLine,
      styles: styles,
    );
  }

  void printCodeTable({String? codeTable}) {
    _bytes += _generator.printCodeTable(
      codeTable: codeTable,
    );
  }
}
