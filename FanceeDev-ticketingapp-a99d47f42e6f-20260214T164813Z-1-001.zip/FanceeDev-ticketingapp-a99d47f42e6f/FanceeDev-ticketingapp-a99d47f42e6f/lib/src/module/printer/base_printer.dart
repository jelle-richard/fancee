import 'package:carrot/carrot.dart';

import '../../data/data.dart';
import '../../util/util.dart';
import 'result.dart';
import 'thermal_printer.dart';
import 'type.dart';
import 'unknown_printer.dart';

abstract class FTPrinter {
  final FTPrinterType type;
  final String name;
  final String host;
  final int port;

  String get icon;

  const FTPrinter.thermal({
    required this.name,
    required this.host,
    required this.port,
  }) : type = FTPrinterType.thermal;

  const FTPrinter.unknown({
    required this.name,
    required this.host,
    required this.port,
  }) : type = FTPrinterType.unknown;

  /// Adapts the given [json] into a printer instance. An unknown printer is returned
  /// when no implementation is found. Our user settings bloc removes unknown printers
  /// from the local storage.
  factory FTPrinter.fromJson(dynamic json) {
    switch (toString(json['type'])) {
      case 'thermal':
        return FTThermalPrinter(
          name: toString(json['name']),
          host: toString(json['host']),
          port: toInt(json['port']),
        );

      default:
        return FTUnknownPrinter(
          name: toString(json['name']),
        );
    }
  }

  /// Returns the json object for the printer.
  Map<String, dynamic> toJson() => {
        'type': type.name,
        'name': name,
        'host': host,
        'port': port,
      };

  /// Gets the description of the printer.
  String getDescription(BuildContext context);

  /// Returns TRUE if the device is online.
  Future<bool> isOnline();

  /// Prints the given order and returns the print result.
  Future<FTPrintResult> printOrder(Locale locale, FTOrderModel order);

  /// Prints a test ticket with the given [message]. Returns the result.
  Future<FTPrintResult> printTest([String message = 'This is a test']);
}
