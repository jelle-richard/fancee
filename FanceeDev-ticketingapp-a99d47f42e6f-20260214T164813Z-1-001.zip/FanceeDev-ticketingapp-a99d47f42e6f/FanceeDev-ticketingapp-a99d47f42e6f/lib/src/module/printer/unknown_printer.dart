import 'package:carrot/carrot.dart';

import '../../data/data.dart';
import 'base_printer.dart';
import 'result.dart';

class FTUnknownPrinter extends FTPrinter {
  const FTUnknownPrinter({
    required super.name,
  }) : super.unknown(
          host: '',
          port: 0,
        );

  @override
  String get icon => 'circle-question';

  @override
  String getDescription(BuildContext context) {
    return 'Unknown';
  }

  @override
  Future<bool> isOnline() async {
    return false;
  }

  @override
  Future<FTPrintResult> printOrder(Locale locale, FTOrderModel order) async {
    return FTPrintResult.failed;
  }

  @override
  Future<FTPrintResult> printTest([String message = 'This is a test']) async {
    return FTPrintResult.failed;
  }
}
