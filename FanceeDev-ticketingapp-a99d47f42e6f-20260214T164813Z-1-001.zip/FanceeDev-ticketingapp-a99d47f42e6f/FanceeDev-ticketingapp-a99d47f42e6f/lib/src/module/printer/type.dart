enum FTPrinterType {
  thermal,
  unknown,
}
