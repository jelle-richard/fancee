import 'package:carrot/carrot.dart';
import 'package:esc_pos_printer/esc_pos_printer.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart';
import 'package:intl/intl.dart';

import '../../data/data.dart';
import 'base_printer.dart';
import 'result.dart';
import 'thermal_builder.dart';

typedef _PrinterHandler = FTThermalPrinterBuilder Function(NetworkPrinter, PaperSize, CapabilityProfile);

class FTThermalPrinter extends FTPrinter {
  const FTThermalPrinter({
    required super.name,
    required super.host,
    required super.port,
  }) : super.thermal();

  @override
  String get icon => 'receipt';

  Future<FTPrintResult> _usePrinter([_PrinterHandler? handler]) async {
    const paper = PaperSize.mm80;
    final profile = await CapabilityProfile.load();
    final printer = NetworkPrinter(paper, profile);

    final connectionResult = await printer.connect(host, port: port);
    FTPrintResult result = FTPrintResult.failed;

    switch (connectionResult) {
      case PosPrintResult.success:
        if (handler != null) {
          final builder = handler.call(printer, paper, profile);
          printer.rawBytes(builder.bytes);
        }

        result = FTPrintResult.success;
        break;

      case PosPrintResult.printInProgress:
      case PosPrintResult.scanInProgress:
      case PosPrintResult.ticketEmpty:
        result = FTPrintResult.printerInUse;
        break;

      case PosPrintResult.printerNotSelected:
      case PosPrintResult.timeout:
        result = FTPrintResult.failed;
        break;
    }

    printer.disconnect();

    return result;
  }

  @override
  String getDescription(BuildContext context) {
    return '$host:$port';
  }

  @override
  Future<bool> isOnline() async {
    return await _usePrinter() == FTPrintResult.success;
  }

  @override
  Future<FTPrintResult> printOrder(Locale locale, FTOrderModel order) async {
    final logo = await rootBundle.load('assets/images/fancee.png');
    final logoBytes = logo.buffer.asUint8List();
    final logoImage = decodeImage(logoBytes);

    return await _usePrinter((_, paper, profile) {
      final builder = FTThermalPrinterBuilder(paper, profile);

      for (final product in order.products) {
        if (product.type != FTProductType.ticket) {
          continue;
        }

        if (product.issuedTickets.isEmpty) {
          continue;
        }

        for (final issuedTicket in product.issuedTickets) {
          // header
          builder
            ..reset()
            ..text(
              order.event.organizer.name,
              styles: const PosStyles(
                align: PosAlign.center,
              ),
            )
            ..feed(1)
            ..text(
              order.event.name,
              styles: const PosStyles(
                align: PosAlign.center,
                height: PosTextSize.size2,
                width: PosTextSize.size2,
              ),
            )
            ..feed(1)
            ..text(
              DateFormat.yMMMMd().add_Hm().format(order.event.startDate),
              styles: const PosStyles(
                align: PosAlign.center,
              ),
            )
            ..feed(1)
            ..hr(character: '#');

          // qr code
          builder
            ..feed(1)
            ..qrcode(
              issuedTicket.code,
              align: PosAlign.center,
              size: QRSize.Size8,
            )
            ..feed(1)
            ..hr(character: '-');

          // product list
          builder.feed(1);

          for (final product in order.products) {
            builder.row([
              PosColumn(
                text: product.name,
                styles: const PosStyles(
                  bold: true,
                ),
                width: 9,
              ),
              PosColumn(
                text: order.currency.format(
                  locale,
                  product.priceCents,
                  symbol: false,
                ),
                styles: const PosStyles(
                  align: PosAlign.right,
                ),
                width: 3,
              ),
            ]);
          }

          builder.feed(1);
          builder.hr(character: '-');

          // footer
          builder
            ..feed(1)
            ..image(
              logoImage!,
              align: PosAlign.center,
            )
            ..cut();
        }
      }

      return builder;
    });
  }

  @override
  Future<FTPrintResult> printTest([String message = 'This is a test']) async {
    final data = await rootBundle.load('assets/images/fancee.png');
    final bytes = data.buffer.asUint8List();
    final image = decodeImage(bytes);

    return await _usePrinter((_, paper, profile) => FTThermalPrinterBuilder(paper, profile)
      ..image(image!, align: PosAlign.left)
      ..feed(1)
      ..hr(character: '#')
      ..feed(2)
      ..qrcode(
        'Fancee',
        align: PosAlign.left,
        size: QRSize.Size8,
      )
      ..feed(2)
      ..text(
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at nulla libero. Suspendisse fermentum dictum neque eget porta. Integer congue volutpat velit nec cursus. Phasellus scelerisque mollis ultricies. Maecenas tincidunt feugiat quam luctus vehicula. Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        styles: const PosStyles(
          align: PosAlign.left,
        ),
      )
      ..feed(1)
      ..hr()
      ..feed(1)
      ..text(message)
      ..cut());
  }
}
