enum FTPrintResult {
  failed,
  printerInUse,
  success,
}
