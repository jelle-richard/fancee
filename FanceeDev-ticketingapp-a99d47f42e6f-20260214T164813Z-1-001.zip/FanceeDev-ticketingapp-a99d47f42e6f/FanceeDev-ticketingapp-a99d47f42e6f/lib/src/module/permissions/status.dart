enum FTPermissionStatus {
  denied,
  granted,
  limited,
  permanentlyDenied,
  restricted,
}
