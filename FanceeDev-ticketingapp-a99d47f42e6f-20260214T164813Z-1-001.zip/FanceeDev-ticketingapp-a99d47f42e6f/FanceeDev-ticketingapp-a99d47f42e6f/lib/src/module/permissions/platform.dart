import 'package:permission_handler/permission_handler.dart';

import 'status.dart';

class FTPlatformPermissions {
  static Future<FTPermissionStatus> get camera async => convert(await Permission.camera.status);

  static Future<FTPermissionStatus> requestCamera() async => convert(await Permission.camera.request());

  static Future<void> launchAppSettings() async {
    await openAppSettings();
  }

  static FTPermissionStatus convert(PermissionStatus status) {
    return _convertMap[status]!;
  }
}

const _convertMap = {
  PermissionStatus.denied: FTPermissionStatus.denied,
  PermissionStatus.granted: FTPermissionStatus.granted,
  PermissionStatus.limited: FTPermissionStatus.limited,
  PermissionStatus.permanentlyDenied: FTPermissionStatus.permanentlyDenied,
  PermissionStatus.restricted: FTPermissionStatus.restricted,
};
