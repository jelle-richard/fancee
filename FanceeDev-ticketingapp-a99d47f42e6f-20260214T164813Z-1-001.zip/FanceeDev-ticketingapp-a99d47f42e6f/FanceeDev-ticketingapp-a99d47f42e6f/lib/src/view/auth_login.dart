import 'package:carrot/carrot.dart';
import 'package:flutter/services.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/organism/organism.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../config.dart';
import '../data/data.dart';
import '../routes.dart';

class FTViewAuthLogin extends StatefulWidget {
  static final route = FTRoute.auth(
    arguments: const FTShellSettings(
      systemUiStyle: FTSystemUiStyle.auto,
    ),
    path: '/login',
    builder: (context, state) => const FTViewAuthLogin(),
  );

  const FTViewAuthLogin({
    super.key,
  });

  @override
  createState() => _FTViewAuthLoginState();
}

class _FTViewAuthLoginState extends State<FTViewAuthLogin> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  late FTAuthService _authService;
  bool _isLoading = false;
  bool _isPasswordVisible = false;
  String? _signInError;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final environment = FTEnvironment.of(context);
    _authService = FTAuthService(context: context);

    if (_emailController.text.isEmpty) {
      _emailController.text = environment.prefillLoginEmail ?? '';
    }

    if (_passwordController.text.isEmpty) {
      _passwordController.text = environment.prefillLoginPassword ?? '';
    }
  }

  void _clearError() {
    setState(() {
      _signInError = null;
    });
  }

  void _onForgotPasswordTap() {
    _clearError();

    context.carrotRouter.push(FTRoutes.authForgotPassword());
  }

  void _onScanSignInTap() {
    _clearError();

    context.carrotRouter.push(FTRoutes.authScanSignIn());
  }

  void _onSignInTap() async {
    final authBloc = context.read<FTAuthStateBloc>();
    final router = context.carrotRouter;

    setState(() {
      _isLoading = true;
      _signInError = null;
    });

    final response = await _authService.login(
      email: _emailController.text,
      password: _passwordController.text,
    );

    if (response.isOk) {
      final user = response.data!.user;

      if (!user.isOrganizer) {
        router.push(FTRoutes.noticeUnsupportedUser());
      } else {
        authBloc.add(FTAuthStateSetBearerToken(
          bearerToken: response.data!.accessToken,
          user: user,
          validUntil: response.data!.validUntil,
        ));

        router.go(FTRoutes.more());
      }
    } else {
      setState(() {
        _isLoading = false;
        _signInError = response.errors.first;
      });
    }
  }

  void _onLogoLongPressed() async {
    if (!FTConfig.enableEnvironmentSwitching) {
      return;
    }

    HapticFeedback.heavyImpact();

    context.carrotRouter.overlayEntry(
      dismissible: true,
      builder: (bag) => FTEnvironmentSwitcherDialog(close: bag.close),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FTLoadingSubtleOverlay(
      isLoading: _isLoading,
      child: FTLayoutAuth(
        onLogoLongPress: _onLogoLongPressed,
        children: [
          if (_signInError != null)
            CarrotNotice(
              color: context.carrotTheme.defaults.error,
              icon: const CarrotIcon(
                glyph: 'circle-exclamation',
              ),
              message: Text(_signInError!),
              title: Text(context.strings.authSignInError),
            ),
          AutofillGroup(
            child: CarrotColumn(
              gap: 15,
              children: [
                CarrotTextField(
                  autofillHints: const [
                    AutofillHints.username,
                    AutofillHints.email,
                  ],
                  controller: _emailController,
                  maxLines: 1,
                  placeholder: context.strings.authEmail,
                  prefix: const FTLayoutAuthTextFieldIcon.prefix(icon: 'user'),
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                ),
                CarrotTextField(
                  autofillHints: const [
                    AutofillHints.password,
                  ],
                  controller: _passwordController,
                  maxLines: 1,
                  obscureText: !_isPasswordVisible,
                  placeholder: context.strings.authPassword,
                  prefix: const FTLayoutAuthTextFieldIcon.prefix(icon: 'key'),
                  suffix: CarrotBounceTap(
                    child: _isPasswordVisible ? const FTLayoutAuthTextFieldIcon.suffix(icon: 'eye-slash') : const FTLayoutAuthTextFieldIcon.suffix(icon: 'eye'),
                    onTap: () => setState(() {
                      _isPasswordVisible = !_isPasswordVisible;
                    }),
                  ),
                  keyboardType: TextInputType.text,
                  textInputAction: TextInputAction.go,
                  onSubmitted: (_) => _onSignInTap(),
                ),
              ],
            ),
          ),
          FTLayoutAuthProceedButton(
            text: context.strings.authSignIn,
            onTap: _onSignInTap,
          ),
          if (context.isAnyFeatureEnabled([FTFeatureFlag.authScanToSignInEnabled, FTFeatureFlag.authForgotPasswordEnabled]))
            FTLabelledDivider(
              label: Text(context.strings.or),
            ),
          CarrotColumn(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            gap: 12,
            children: [
              if (context.isFeatureEnabled(FTFeatureFlag.authScanToSignInEnabled))
                CarrotTextButton.text(
                  text: Text(context.strings.authWithQr),
                  onTap: _onScanSignInTap,
                ),
              if (context.isFeatureEnabled(FTFeatureFlag.authForgotPasswordEnabled))
                CarrotTextButton.text(
                  text: Text(context.strings.authForgot),
                  onTap: _onForgotPasswordTap,
                ),
            ],
          ),
        ],
      ),
    );
  }
}
