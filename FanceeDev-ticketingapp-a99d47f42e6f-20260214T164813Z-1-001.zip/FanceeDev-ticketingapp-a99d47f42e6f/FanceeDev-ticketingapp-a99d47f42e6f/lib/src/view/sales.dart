import 'package:carrot/carrot.dart';
import 'package:flutter/material.dart' show RefreshIndicator;

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';
import '../routes.dart';
import 'sales_details.dart';
import 'sales_order.dart';
import 'sales_shop.dart';
import 'sales_summary.dart';

class FTViewSales extends StatefulWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.salesTitle,
    path: '/sales',
    builder: (context, state) => const FTViewSales(),
    routes: [
      FTViewSalesDetails.route,
      FTViewSalesOrder.route,
      FTViewSalesShop.route,
      FTViewSalesSummary.route,
    ],
  );

  const FTViewSales({
    super.key,
  });

  @override
  createState() => _FTViewSalesState();
}

class _FTViewSalesState extends State<FTViewSales> {
  final _salesModeSwitcherKey = GlobalKey(debugLabel: 'fancee_app:sales:mode_switcher');
  final _salesSheetView = GlobalKey(debugLabel: 'fancee_app:sales:view');

  late final FTEventService _eventService;
  late final FTShopService _shopService;
  late final FTAppStateBloc _appStateBloc;
  late final FTSalesStateBloc _salesStateBloc;
  late final FTUserStateBloc _userStateBloc;

  bool _isLoading = false;
  bool _isFirstRender = true;

  List<FTEventListingModel> get events => _salesStateBloc.state.events;

  bool get showMissingPinTerminalsNotice => !_appStateBloc.state.didDismissSalesMissingPinTerminalsNotice && _userStateBloc.state.pinTerminals.isEmpty;

  bool get showMissingPrintersNotice => !_appStateBloc.state.didDismissSalesMissingPrintersNotice && _userStateBloc.state.printers.isEmpty;

  FTSalesMode get salesMode => _salesStateBloc.state.mode;

  int get _itemBuilderCount {
    int count = events.length;

    if (showMissingPinTerminalsNotice) {
      ++count;
    }

    if (showMissingPrintersNotice) {
      ++count;
    }

    return count;
  }

  int get _skipItemCount {
    int skip = 0;

    if (showMissingPinTerminalsNotice) {
      ++skip;
    }

    if (showMissingPrintersNotice) {
      ++skip;
    }

    return skip;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _eventService = FTEventService(context: context);
      _shopService = FTShopService(context: context);
      _appStateBloc = context.watch<FTAppStateBloc>();
      _salesStateBloc = context.read<FTSalesStateBloc>();
      _userStateBloc = context.read<FTUserStateBloc>();
      _isFirstRender = false;
    }
  }

  @override
  void initState() {
    super.initState();

    onMounted(() async {
      _loadEventsAndShops();
    });
  }

  Widget _buildMissingPinTerminalsNotice(BuildContext context) {
    return FTSubtleNotice.dismissible(
      key: UniqueKey(),
      icon: 'credit-card',
      margin: const EdgeInsets.only(bottom: 21),
      title: Text(context.strings.salesNoPinTerminalsTitle),
      body: Text(context.strings.salesNoPinTerminalsDescription),
      onDismissed: (_) => _appStateBloc.add(const FTAppStateSetDidDismissSalesMissingPinTerminalsNotice(true)),
      onTap: () => context.carrotRouter.go(FTRoutes.morePinTerminals()),
    );
  }

  Widget _buildMissingPrintersNotice(BuildContext context) {
    return FTSubtleNotice.dismissible(
      key: UniqueKey(),
      icon: 'print',
      margin: const EdgeInsets.only(bottom: 21),
      title: Text(context.strings.salesNoPrintersTitle),
      body: Text(context.strings.salesNoPrintersDescription),
      onDismissed: (_) => _appStateBloc.add(const FTAppStateSetDidDismissSalesMissingPrintersNotice(true)),
      onTap: () => context.carrotRouter.go(FTRoutes.morePrinters()),
    );
  }

  Widget _itemBuilder(BuildContext context, int index) {
    if (showMissingPinTerminalsNotice) {
      if (index == 0) {
        return _buildMissingPinTerminalsNotice(context);
      }

      --index;
    }

    if (showMissingPrintersNotice) {
      if (index == 0) {
        return _buildMissingPrintersNotice(context);
      }

      --index;
    }

    return _Event(
      eventName: events[index].name,
      children: [
        for (final shop in events[index].shops)
          _Shop(
            name: shop.name,
            media: shop.headerMedia.map((media) => media.url).toList(),
            onTap: () => _loadShop(shop),
          ),
      ],
    );
  }

  Future<void> _loadEventsAndShops() async {
    if (events.isEmpty) {
      setState(() {
        _isLoading = true;
      });
    }

    final response = await _eventService.withUserType(
      organizer: (service) async => await service.getList(
        maximumStartDate: DateTime.now().add(const Duration(days: 365)),
        minimumStartDate: DateTime.now().subtract(const Duration(days: 21)),
      ),
      appTeam: (service) async => await service.getListAppTeam(
        maximumStartDate: DateTime.now().add(const Duration(days: 365)),
        minimumStartDate: DateTime.now().subtract(const Duration(days: 21)),
      ),
    );

    if (!mounted) {
      return;
    }

    final filteredEvents = (response.data?.items ?? [])
        .map((event) => FTEventListingModel(
              id: event.id,
              name: event.name,
              date: event.date,
              shops: event.shops.where((shop) => shop.active).toList(),
              status: event.status,
              type: event.type,
            ))
        .where((event) => event.shops.isNotEmpty)
        .toList();

    setState(() {
      _salesStateBloc.add(FTSalesStateSetEvents(filteredEvents));
      _isLoading = false;
    });
  }

  Future<void> _loadShop(FTEventShopListingModel shopListing) async {
    setState(() {
      _isLoading = true;
    });

    final router = context.carrotRouter;
    final response = await _shopService.get(
      shopCode: shopListing.code,
      shopName: shopListing.name,
    );

    if (response.isOk && response.data != null) {
      final shop = response.data!;
      _salesStateBloc.add(FTSalesStateSetShop(shop));
      router.push(
        FTRoutes.salesShop(shop.event.id, shop.code, shop.name),
      );
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _setSalesMode(int index) {
    _salesStateBloc.add(FTSalesStateSetMode(
      FTSalesMode.values[index],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return RefreshIndicator(
      color: carrotTheme.primary,
      strokeWidth: 3,
      edgeOffset: context.carrotScaffold.appBarSize.height,
      onRefresh: _loadEventsAndShops,
      child: FTEmptyViewSwitcher(
        emptyView: FTLayoutEmptyView.illustration(
          explanation: context.strings.salesEmptyViewDescription,
          illustration: 'sales',
          title: context.strings.salesEmptyViewTitle,
        ),
        isEmptyViewVisible: !_isLoading && events.isEmpty,
        child: FTLayoutSheet.listView(
          key: _salesSheetView,
          isLoading: _isLoading,
          padding: const EdgeInsets.all(24),
          headerBuilder: (context) => Padding(
            padding: const EdgeInsets.only(
              top: 15,
              bottom: 42,
            ),
            child: FTTransparentModeSwitcher(
              key: _salesModeSwitcherKey,
              backgroundColor: carrotTheme.primary[carrotTheme.resolve(800, 900)],
              initialIndex: salesMode.index,
              onChange: _setSalesMode,
              children: [
                Text(context.strings.salesTypeDoorsale),
                Text(context.strings.salesTypePreSale),
              ],
            ),
          ),
          itemBuilder: _itemBuilder,
          itemCount: _itemBuilderCount,
          separatorBuilder: (context, index) => CarrotSpacer.vertical(
            size: index < _skipItemCount ? 0 : 21,
          ),
        ),
      ),
    );
  }
}

class _Event extends StatelessWidget {
  final List<Widget> children;
  final String eventName;

  const _Event({
    required this.children,
    required this.eventName,
  });

  @override
  Widget build(BuildContext context) {
    return CarrotColumn(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      gap: 9,
      children: [
        FTLabel(
          child: Text(eventName),
        ),
        ...children,
      ],
    );
  }
}

class _Shop extends StatelessWidget {
  final List<String> media;
  final String name;
  final GestureTapCallback? onTap;

  const _Shop({
    required this.media,
    required this.name,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return CarrotBounceTap(
      onTap: onTap,
      child: DecoratedBox(
        decoration: BoxDecoration(
          border: Border.all(
            color: carrotTheme.gray[100],
            width: 1,
          ),
          borderRadius: carrotTheme.borderRadius,
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 15,
          ),
          child: CarrotRow(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            gap: 18,
            children: [
              if (media.isNotEmpty)
                ClipRRect(
                  borderRadius: carrotTheme.borderRadius / 2,
                  child: SizedBox.square(
                    dimension: 36,
                    child: Image.network(
                      media.first,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              if (media.isEmpty)
                CarrotAvatar.letters(
                  name[0],
                  borderRadius: carrotTheme.borderRadius / 2,
                  size: 36,
                ),
              Expanded(
                child: DefaultTextStyle(
                  style: carrotTheme.typography.headline5,
                  child: Text(name),
                ),
              ),
              FTIcon(
                color: carrotTheme.gray[400],
                margin: const EdgeInsets.symmetric(vertical: 6),
                glyph: 'angle-right',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
