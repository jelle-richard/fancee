import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/layout/auth.dart';
import '../component/routing/routing.dart';
import '../routes.dart';

class FTViewNoticeUnsupportedUser extends StatelessWidget {
  static final route = FTRoute(
    path: '/notice/unsupported-user',
    builder: (_, __) => const FTViewNoticeUnsupportedUser(),
  );

  const FTViewNoticeUnsupportedUser({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FTLayoutAuth(
      children: [
        const CarrotSpacer.vertical(size: 30),
        Text(
          context.strings.noticeUnsupportedUserTitle,
          textAlign: TextAlign.center,
          style: context.carrotTypography.headline4.copyWith(
            color: context.carrotTheme.primary,
          ),
        ),
        Text(
          context.strings.noticeUnsupportedUserDescription,
          textAlign: TextAlign.center,
          style: context.carrotTypography.body2.copyWith(),
        ),
        const CarrotSpacer.vertical(size: 0),
        CarrotTextButton.text(
          icon: 'circle-arrow-left',
          text: Text(context.strings.back),
          onTap: () {
            context.carrotRouter.go(FTRoutes.authLogin());
          },
        ),
      ],
    );
  }
}
