import 'dart:math' as math;

import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';
import '../module/printer/printer.dart';
import '../util/util.dart';

typedef _PrinterActionCallback = void Function(FTPrinter);
typedef _PrinterFromNetworkCallback = void Function(FTNetworkDiscoveryResult);

class FTViewMorePrinters extends StatefulWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.morePrintersTitle,
    path: 'printers',
    builder: (context, state) => const FTViewMorePrinters(),
  );

  const FTViewMorePrinters({
    super.key,
  });

  @override
  createState() => _FTViewMorePrintersState();
}

class _FTViewMorePrintersState extends State<FTViewMorePrinters> {
  late final FTUserStateBloc _userBloc;

  final _printers = <FTPrinter>[];

  bool _isFirstRender = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _userBloc = context.read<FTUserStateBloc>();
      _isFirstRender = false;
      _loadPrinters();
    }
  }

  void _loadPrinters() {
    _printers.clear();
    _printers.addAll(_userBloc.state.printers);
  }

  void _onAddPrinterTap() async {
    await context.carrotRouter.overlay<void>(
      dismissible: true,
      builder: (close) => _PrinterEditDialog(
        close: close,
        onDelete: (_) {},
        onSave: (addedPrinter) {
          _printers.add(addedPrinter);
          _updatePrinterState();
          close();
          // todo(Bas): feedback to the user (printer is added) (FAN-692 / FAN-693)
        },
      ),
    );
  }

  void _onEditPrinterTap(FTPrinter printer) async {
    await context.carrotRouter.overlay<void>(
      dismissible: true,
      builder: (close) => _PrinterEditDialog(
        close: close,
        printer: printer,
        onDelete: (printer) {
          _onPrinterDismissed(printer);
          close();
        },
        onSave: (editedPrinter) {
          _printers.remove(printer);
          _printers.add(editedPrinter);
          _updatePrinterState();
          close();
          // todo(Bas): feedback to the user (printer is edited) (FAN-692 / FAN-693)
        },
      ),
    );
  }

  void _onPrinterDismissed(FTPrinter printer) {
    _printers.remove(printer);
    _updatePrinterState();
  }

  void _updatePrinterState() {
    _userBloc.add(FTUserStateSetPrinters(_printers));
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return FTEmptyViewSwitcher(
      isEmptyViewVisible: _printers.isEmpty,
      emptyView: FTLayoutEmptyView.illustration(
        explanation: context.strings.morePrintersEmptyDescription,
        illustration: 'printers',
        title: context.strings.morePrintersEmptyTitle,
        child: CarrotTextButton.text(
          icon: 'circle-plus',
          text: Text(context.strings.morePrintersAdd),
          onTap: _onAddPrinterTap,
        ),
      ),
      child: _PrinterView(
        printers: _printers,
        onAddPrinterTap: _onAddPrinterTap,
        onEditPrinterTap: _onEditPrinterTap,
        onPrinterDismissed: _onPrinterDismissed,
      ),
    );
  }
}

class _PrinterView extends StatelessWidget {
  final List<FTPrinter> printers;
  final GestureTapCallback onAddPrinterTap;
  final _PrinterActionCallback onEditPrinterTap;
  final _PrinterActionCallback onPrinterDismissed;

  const _PrinterView({
    required this.printers,
    required this.onAddPrinterTap,
    required this.onEditPrinterTap,
    required this.onPrinterDismissed,
  });

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.singleChildScrollView(
      padding: const EdgeInsets.all(24),
      builder: (context) => CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        gap: 15,
        children: [
          FTFlatList(
            children: [
              for (final printer in printers)
                _PrinterListItem(
                  printer: printer,
                  onDismissed: (_) => onPrinterDismissed(printer),
                  onTap: () => onEditPrinterTap(printer),
                )
            ],
          ),
          FTFlatList(
            children: [
              FTFlatListItemButton(
                icon: 'circle-plus',
                onTap: onAddPrinterTap,
                child: Text(context.strings.morePrintersAdd),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PrinterListItem extends StatelessWidget {
  final FTPrinter printer;
  final DismissDirectionCallback onDismissed;
  final GestureTapCallback onTap;

  const _PrinterListItem({
    required this.printer,
    required this.onDismissed,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return FTFlatListItem.dismissible(
      key: ObjectKey(printer),
      icon: printer.icon,
      onDismissed: onDismissed,
      onTap: onTap,
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            printer.name,
            style: context.carrotTypography.body1.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            printer.getDescription(context),
            style: context.carrotTypography.body2.copyWith(
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class _PrinterEditDialog extends CarrotStatefulDialog<void> {
  final FTPrinter? printer;
  final _PrinterActionCallback onDelete;
  final _PrinterActionCallback onSave;

  const _PrinterEditDialog({
    required super.close,
    required this.onDelete,
    required this.onSave,
    this.printer,
  });

  @override
  createState() => _PrinterEditDialogState();
}

class _PrinterEditDialogState extends CarrotStatefulDialogState<void, _PrinterEditDialog> with TickerProviderStateMixin {
  late final TextEditingController _nameController;
  late final TextEditingController _hostController;
  late final TextEditingController _portController;

  late CarrotTabController _tabController;

  bool get hasPrinter => widget.printer != null;

  @override
  void initState() {
    super.initState();

    _nameController = TextEditingController(text: widget.printer?.name);
    _hostController = TextEditingController(text: widget.printer?.host);
    _portController = TextEditingController(text: widget.printer?.port.toString());

    _tabController = CarrotTabController(
      initialIndex: hasPrinter ? 1 : 0,
      length: 3,
      vsync: this,
    );
  }

  @override
  Widget? buildContent(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    return Padding(
      padding: EdgeInsets.only(
        top: math.max(27, headerSize.height),
        bottom: math.max(27, footerSize.height),
      ),
      child: DefaultTextStyle(
        style: context.carrotTypography.body2,
        textAlign: TextAlign.left,
        child: CarrotTabViewWithGap(
          key: GlobalKey(),
          controller: _tabController,
          clipBehavior: Clip.none,
          gap: 27,
          children: [
            _PrinterDialogNetwork(
              close: widget.close,
              onSelect: (result) {
                _nameController.text = result.name ?? '';
                _hostController.text = result.host;
                _portController.text = result.port.toString();
                _tabController.index = 1;
              },
            ),
            _PrinterDialogForm(
              close: widget.close,
              nameController: _nameController,
              hostController: _hostController,
              portController: _portController,
              onDelete: widget.onDelete,
              onSave: widget.onSave,
              printer: widget.printer,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget? buildHeader(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    return FTDialogHeader(
      title: Text(hasPrinter ? context.strings.morePrintersEdit : context.strings.morePrintersAdd),
      body: hasPrinter
          ? null
          : CarrotTabBar(
              controller: _tabController,
              tabs: [
                CarrotTab(
                  child: Text(context.strings.morePrintersAddNetwork),
                ),
                CarrotTab(
                  child: Text(context.strings.morePrintersAddManual),
                ),
              ],
            ),
    );
  }
}

class _PrinterDialogForm extends StatefulWidget {
  final CarrotOverlayBaseClose<void> close;
  final TextEditingController nameController;
  final TextEditingController hostController;
  final TextEditingController portController;
  final _PrinterActionCallback onDelete;
  final _PrinterActionCallback onSave;
  final FTPrinter? printer;

  const _PrinterDialogForm({
    required this.close,
    required this.nameController,
    required this.hostController,
    required this.portController,
    required this.onDelete,
    required this.onSave,
    this.printer,
  });

  @override
  createState() => _PrinterDialogFormState();
}

class _PrinterDialogFormState extends State<_PrinterDialogForm> {
  final _nameFocusNode = FocusNode();
  final _hostFocusNode = FocusNode();
  final _portFocusNode = FocusNode();

  bool get hasPrinter => widget.printer != null;

  bool get isValid => widget.nameController.text.isNotEmpty && widget.hostController.text.isNotEmpty && widget.portController.text.isNotEmpty && int.tryParse(widget.portController.text) != null;

  FTThermalPrinter get newPrinter => FTThermalPrinter(
        name: widget.nameController.text,
        host: widget.hostController.text,
        port: int.tryParse(widget.portController.text) ?? -1,
      );

  void _onCloseTap() {
    widget.close();
  }

  void _onDeleteTap() {
    if (!hasPrinter) {
      // note: Add-mode does not have this button.
      return;
    }

    widget.onDelete(widget.printer!);
  }

  void _onSaveTap() {
    if (!isValid) {
      // todo(Bas): show notice (FAN-692 / FAN-693).
      return;
    }

    widget.onSave(newPrinter);
  }

  void _onTestTap() {
    if (!isValid) {
      // todo(Bas): show notice (FAN-692 / FAN-693).
      return;
    }

    // todo(Bas): feedback to the user (printer test sent) (FAN-692 / FAN-693)
    newPrinter.printTest();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 27),
      child: IntrinsicHeight(
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.max,
          gap: 9,
          children: [
            CarrotTextField(
              autofocus: !hasPrinter,
              controller: widget.nameController,
              focusNode: _nameFocusNode,
              maxLines: 1,
              placeholder: context.strings.morePrintersAddName,
            ),
            CarrotRow(
              gap: 9,
              children: [
                Expanded(
                  flex: 2,
                  child: CarrotTextField(
                    controller: widget.hostController,
                    focusNode: _hostFocusNode,
                    maxLines: 1,
                    placeholder: context.strings.morePrintersAddHost,
                  ),
                ),
                Expanded(
                  child: CarrotTextField(
                    controller: widget.portController,
                    focusNode: _portFocusNode,
                    keyboardType: TextInputType.number,
                    maxLines: 1,
                    placeholder: context.strings.morePrintersAddPort,
                  ),
                ),
              ],
            ),
            CarrotColumn(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              gap: 9,
              children: [
                CarrotRow(
                  gap: 9,
                  children: [
                    if (hasPrinter)
                      Semantics(
                        label: context.strings.delete,
                        child: CarrotTextButtonTheme(
                          data: context.carrotTheme.textButtonTheme.copyWith(
                            foreground: CarrotOptional.of(context.carrotTheme.defaults.error),
                          ),
                          child: CarrotTextButton.icon(
                            icon: 'trash',
                            onTap: _onDeleteTap,
                          ),
                        ),
                      ),
                    Expanded(
                      child: CarrotTextButton.text(
                        text: Text(context.strings.morePrintersTest),
                        onTap: _onTestTap,
                      ),
                    ),
                    Expanded(
                      child: CarrotTextButton.text(
                        text: Text(context.strings.cancel),
                        onTap: _onCloseTap,
                      ),
                    ),
                  ],
                ),
                CarrotContainedButton.text(
                  text: Text(hasPrinter ? context.strings.save : context.strings.add),
                  onTap: _onSaveTap,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _PrinterDialogNetwork extends StatefulWidget {
  final CarrotOverlayBaseClose<void> close;
  final _PrinterFromNetworkCallback onSelect;

  const _PrinterDialogNetwork({
    required this.close,
    required this.onSelect,
  });

  @override
  createState() => _PrinterDialogNetworkState();
}

class _PrinterDialogNetworkState extends State<_PrinterDialogNetwork> {
  final List<FTNetworkDiscoveryResult> _results = [];

  Future<String> _fetchSubnet() async {
    final localIp = await getLocalIPv4Address();

    if (localIp == null) {
      throw StateError('Could not fetch local ip address.');
    }

    return localIp.substring(0, localIp.lastIndexOf('.'));
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _fetchSubnet(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || snapshot.hasError) {
          return const SizedBox();
        }

        return CarrotScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 27),
          scrollController: ScrollController(),
          child: StreamBuilder<FTNetworkDiscoveryResult>(
            stream: discoverNetworkDevices(snapshot.data!, 9100),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.active && snapshot.hasData) {
                _results.add(snapshot.data!);
              }

              if (_results.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(15),
                  child: FTSpinner(
                    size: 24,
                    thickness: 3,
                  ),
                );
              }

              return FTFlatList(
                children: [
                  ..._results.map(
                    (result) => _PrinterDialogNetworkItem(
                      discoveryResult: result,
                      onTap: () => widget.onSelect(result),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class _PrinterDialogNetworkItem extends StatelessWidget {
  final FTNetworkDiscoveryResult discoveryResult;
  final GestureTapCallback onTap;

  const _PrinterDialogNetworkItem({
    required this.discoveryResult,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return FTFlatListItem(
      icon: 'circle-nodes',
      onTap: onTap,
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            discoveryResult.name ?? 'Unknown',
            style: context.carrotTypography.body1.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            '${discoveryResult.host}:${discoveryResult.port}',
            style: context.carrotTypography.body1.copyWith(
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}
