import 'dart:math' as math;

import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';
import '../module/pin_terminal/pin_terminal.dart';

typedef _PinTerminalActionCallback = void Function(FTPinTerminalModel);

class FTViewMorePinTerminals extends StatefulWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.morePinTerminalsTitle,
    path: 'pin-terminals',
    builder: (context, _) => const FTViewMorePinTerminals(),
  );

  const FTViewMorePinTerminals({
    super.key,
  });

  @override
  createState() => _FTViewMorePinTerminalsState();
}

class _FTViewMorePinTerminalsState extends State<FTViewMorePinTerminals> {
  late final FTUserStateBloc _userBloc;

  final _pinTerminals = <FTPinTerminalModel>[];

  bool _isFirstRender = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _userBloc = context.read<FTUserStateBloc>();
      _isFirstRender = false;
      _loadPinTerminals();
    }
  }

  void _loadPinTerminals() {
    _pinTerminals.clear();
    _pinTerminals.addAll(_userBloc.state.pinTerminals);
  }

  void _onAddPinTerminalTap() async {
    await context.carrotRouter.overlay<void>(
      dismissible: true,
      builder: (close) => _PinTerminalFormDialog(
        close: close,
        onDelete: (_) {},
        onSave: (pinTerminal) {
          _pinTerminals.add(pinTerminal);
          _updatePinTerminalsState();
          close();
          // todo(Bas): feedback to the user (pin terminal is added) (FAN-692 / FAN-693)
        },
      ),
    );
  }

  void _onEditPinTerminalTap(FTPinTerminalModel pinTerminal) async {
    await context.carrotRouter.overlay<void>(
      dismissible: true,
      builder: (close) => _PinTerminalFormDialog(
        close: close,
        pinTerminal: pinTerminal,
        onDelete: (pinTerminal) {
          _onPinTerminalDismissed(pinTerminal);
          close();
          // todo(Bas): feedback to the user (pin terminal is removed) (FAN-692 / FAN-693)
        },
        onSave: (editedPinTerminal) {
          _pinTerminals.remove(pinTerminal);
          _pinTerminals.add(editedPinTerminal);
          _updatePinTerminalsState();
          close();
          // todo(Bas): feedback to the user (pin terminal is edited) (FAN-692 / FAN-693)
        },
      ),
    );
  }

  void _onPinTerminalDismissed(FTPinTerminalModel pinTerminal) {
    _pinTerminals.remove(pinTerminal);
    _updatePinTerminalsState();
  }

  void _updatePinTerminalsState() {
    _userBloc.add(FTUserStateSetPinTerminals(_pinTerminals));
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return FTEmptyViewSwitcher(
      isEmptyViewVisible: _pinTerminals.isEmpty,
      emptyView: FTLayoutEmptyView.illustration(
        explanation: context.strings.morePinTerminalsEmptyDescription,
        illustration: 'pin_terminals',
        title: context.strings.morePinTerminalsEmptyTitle,
        child: CarrotTextButton.text(
          icon: 'circle-plus',
          text: Text(context.strings.morePinTerminalsAdd),
          onTap: _onAddPinTerminalTap,
        ),
      ),
      child: _PinTerminalsView(
        pinTerminals: _pinTerminals,
        onAddPinTerminalTap: _onAddPinTerminalTap,
        onEditPinTerminalTap: _onEditPinTerminalTap,
        onPinTerminalDismissed: _onPinTerminalDismissed,
      ),
    );
  }
}

class _PinTerminalsView extends StatelessWidget {
  final List<FTPinTerminalModel> pinTerminals;
  final GestureTapCallback onAddPinTerminalTap;
  final _PinTerminalActionCallback onEditPinTerminalTap;
  final _PinTerminalActionCallback onPinTerminalDismissed;

  const _PinTerminalsView({
    required this.pinTerminals,
    required this.onAddPinTerminalTap,
    required this.onEditPinTerminalTap,
    required this.onPinTerminalDismissed,
  });

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.singleChildScrollView(
      padding: const EdgeInsets.all(24),
      builder: (context) => CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        gap: 15,
        children: [
          FTFlatList(
            children: [
              for (final pinTerminal in pinTerminals)
                _PinTerminalListItem(
                  pinTerminal: pinTerminal,
                  onDismissed: (_) => onPinTerminalDismissed(pinTerminal),
                  onTap: () => onEditPinTerminalTap(pinTerminal),
                ),
            ],
          ),
          FTFlatList(
            children: [
              FTFlatListItemButton(
                icon: 'circle-plus',
                onTap: onAddPinTerminalTap,
                child: Text(context.strings.morePinTerminalsAdd),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PinTerminalListItem extends StatelessWidget {
  final FTPinTerminalModel pinTerminal;
  final DismissDirectionCallback onDismissed;
  final GestureTapCallback onTap;

  const _PinTerminalListItem({
    required this.pinTerminal,
    required this.onDismissed,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTypography = context.carrotTypography;

    return FTFlatListItem.dismissible(
      key: ObjectKey(pinTerminal),
      icon: 'credit-card',
      onDismissed: onDismissed,
      onTap: onTap,
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            pinTerminal.name,
            style: carrotTypography.body1.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            '${pinTerminal.serial} • ${pinTerminal.brand}',
            style: carrotTypography.body2.copyWith(
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class _PinTerminalFormDialog extends CarrotStatefulDialog<void> {
  final FTPinTerminalModel? pinTerminal;
  final _PinTerminalActionCallback onDelete;
  final _PinTerminalActionCallback onSave;

  const _PinTerminalFormDialog({
    required super.close,
    required this.onDelete,
    required this.onSave,
    this.pinTerminal,
  });

  @override
  createState() => _PinTerminalFormDialogState();
}

class _PinTerminalFormDialogState extends CarrotStatefulDialogState<void, _PinTerminalFormDialog> {
  late final CarrotValueController<FTPinTerminalBrand?> _brandController;
  late final TextEditingController _nameController;
  late final TextEditingController _serialController;
  late final FTPaymentService _paymentService;

  final _nameFocusNode = FocusNode();
  final _serialFocusNode = FocusNode();

  final _brandOptions = FTPinTerminalBrand.values
      .where((brand) => brand.isSelectable)
      .map((brand) => CarrotSelectFieldOption<FTPinTerminalBrand>(
            value: brand,
            builder: (content) => Text(brand.displayName),
          ))
      .toList();

  bool _isFirstRender = true;
  bool _isLoading = false;

  bool get hasPinTerminal => widget.pinTerminal != null;

  bool get isValid => _nameController.text.isNotEmpty && _serialController.text.isNotEmpty;

  FTPinTerminalModel get newPinTerminal => FTPinTerminalModel(
        brand: _brandController.value ?? FTPinTerminalBrand.unknown,
        name: _nameController.text,
        serial: _serialController.text,
      );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _paymentService = FTPaymentService(context: context);
      _isFirstRender = false;
    }
  }

  @override
  void initState() {
    super.initState();

    _brandController = CarrotValueController(value: widget.pinTerminal?.brand);
    _nameController = TextEditingController(text: widget.pinTerminal?.name);
    _serialController = TextEditingController(text: widget.pinTerminal?.serial);
  }

  void _onCloseTap() {
    widget.close();
  }

  void _onDeleteTap() {
    if (!hasPinTerminal) {
      // note: Add-mode does not have this button.
      return;
    }

    widget.onDelete(widget.pinTerminal!);
  }

  void _onSaveTap() async {
    if (!isValid) {
      // todo(Bas): show notice (FAN-692 / FAN-693).
      return;
    }

    final router = context.carrotRouter;

    setState(() {
      _isLoading = true;
    });

    final response = await _paymentService.validatePinTerminal(
      serialNumber: newPinTerminal.serialNumber,
    );

    if (response.isOk && response.data == true) {
      widget.onSave(newPinTerminal);
      return;
    }

    setState(() {
      _isLoading = false;
    });

    router.overlay<void>(
      builder: (close) => CarrotAlertDialog(
        close: close,
        title: Text(context.strings.morePinTerminalsValidationFailedTitle),
        content: Text(context.strings.morePinTerminalsValidationFailedContent),
      ),
    );
  }

  @override
  Widget? buildHeader(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    return FTDialogHeader(
      title: Text(hasPinTerminal ? context.strings.morePinTerminalsEdit : context.strings.morePinTerminalsAdd),
    );
  }

  @override
  Widget? buildContent(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    return FTLoadingSubtleOverlay(
      isLoading: _isLoading,
      child: CarrotScrollView(
        child: Padding(
          padding: EdgeInsets.only(
            top: math.max(27, headerSize.height),
            left: 27,
            right: 27,
            bottom: math.max(27, footerSize.height),
          ),
          child: DefaultTextStyle(
            style: context.carrotTypography.body2,
            textAlign: TextAlign.left,
            child: CarrotColumn(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              gap: 15,
              children: [
                CarrotFormGroup(
                  label: Text(context.strings.morePinTerminalsFormBrand),
                  child: CarrotSelectField<FTPinTerminalBrand?>(
                    autofocus: !hasPinTerminal,
                    controller: _brandController,
                    placeholder: context.strings.morePinTerminalsFormBrandPlaceholder,
                    options: _brandOptions,
                  ),
                ),
                CarrotFormGroup(
                  label: Text(context.strings.morePinTerminalsFormName),
                  child: CarrotTextField(
                    controller: _nameController,
                    focusNode: _nameFocusNode,
                    maxLines: 1,
                    placeholder: context.strings.morePinTerminalsFormNamePlaceholder,
                  ),
                ),
                CarrotFormGroup(
                  label: Text(context.strings.morePinTerminalsFormSerial),
                  child: CarrotTextField(
                    controller: _serialController,
                    focusNode: _serialFocusNode,
                    maxLines: 1,
                    keyboardType: TextInputType.number,
                    placeholder: context.strings.morePinTerminalsFormSerialPlaceholder,
                  ),
                ),
                CarrotContainedButton.text(
                  text: Text(hasPinTerminal ? context.strings.save : context.strings.add),
                  onTap: _onSaveTap,
                ),
                CarrotRow(
                  gap: 9,
                  children: [
                    if (hasPinTerminal)
                      Semantics(
                        label: context.strings.delete,
                        child: CarrotTextButtonTheme(
                          data: context.carrotTheme.textButtonTheme.copyWith(
                            foreground: CarrotOptional.of(context.carrotTheme.defaults.error),
                          ),
                          child: CarrotTextButton.icon(
                            icon: 'trash',
                            onTap: _onDeleteTap,
                          ),
                        ),
                      ),
                    Expanded(
                      child: CarrotTextButton.text(
                        text: Text(context.strings.cancel),
                        onTap: _onCloseTap,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
