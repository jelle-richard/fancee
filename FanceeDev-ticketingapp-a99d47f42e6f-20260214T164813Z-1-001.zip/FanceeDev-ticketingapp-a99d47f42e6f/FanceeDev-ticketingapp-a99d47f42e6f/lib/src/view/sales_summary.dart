import 'dart:convert';
import 'dart:math' as math;

import 'package:carrot/carrot.dart';
import 'package:collection/collection.dart';
import 'package:intl/intl.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../module/pin_terminal/pin_terminal.dart';
import '../routes.dart';
import '../util/util.dart';

class FTViewSalesSummary extends StatefulWidget {
  static final route = FTRoute(
    arguments: const FTShellSettings(
      hideBottomBar: true,
    ),
    nameGenerator: (context, state) => state.queryParameters['shopName'],
    path: ':eventId/:shopCode/summary',
    builder: (context, _) => const FTViewSalesSummary(),
  );

  const FTViewSalesSummary({
    super.key,
  });

  @override
  createState() => _FTViewSalesSummaryState();
}

class _FTViewSalesSummaryState extends State<FTViewSalesSummary> {
  late final FTSalesStateBloc _salesBloc;
  late final FTUserStateBloc _userBloc;
  late final FTOrderService _orderService;

  bool _isFirstRender = true;
  bool _isLoading = false;

  bool get canUsePin => pinPaymentMethod != null && pinTerminal != null;

  FTPaymentMethodModel? get pinPaymentMethod => shopModel.event.paymentMethods.firstWhereOrNull((pm) => pm.method.toLowerCase() == 'pin');

  FTPinTerminalModel? get pinTerminal => _userBloc.state.pinTerminals.firstOrNull;

  FTShopFormModel get shopForm => assertedCast(_salesBloc.state.shopForm);

  FTShopModel get shopModel => assertedCast(_salesBloc.state.shop);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _salesBloc = context.read<FTSalesStateBloc>();
      _userBloc = context.read<FTUserStateBloc>();
      _orderService = FTOrderService(context: context);
      _isFirstRender = false;
    }
  }

  Future<void> _placeOrder(Future<FTHttpResponse<FTOrderPlacementResultModel>> Function(FTShopOrderClientModel) apiCall) async {
    assert(_salesBloc.state.reservationReference != null);
    final router = context.carrotRouter;

    setState(() {
      _isLoading = true;
    });

    final response = await apiCall(
      FTShopOrderClientModel(
        email: _salesBloc.state.shopForm.email,
        firstName: _salesBloc.state.shopForm.firstName?.nullable(),
        lastName: _salesBloc.state.shopForm.lastName?.nullable(),
        birthDate: toNullable(_salesBloc.state.shopForm.birthDate?.formatForApi(), toDateTime),
        phoneNumber: _salesBloc.state.shopForm.phoneNumber?.nullable(),
      ),
    );

    if (response.isOk) {
      router.go(
        FTRoutes.salesOrder(response.data!.orderId),
      );

      return;
    }

    if (response.status == FTHttpResponseCode.notFound && response.errors.hasException(FTExceptionId.reservationExpired)) {
      await router.overlay<void>(
        builder: (close) => CarrotAlertDialog(
          close: close,
          title: Text(context.strings.salesErrorReservationExpiredTitle),
          content: Text(context.strings.salesErrorReservationExpiredContent),
        ),
      );

      router.go(FTRoutes.salesShop(
        shopModel.event.id,
        shopModel.code,
        shopModel.name,
      ));

      return;
    }

    debugPrint(response.status.toString());
    debugPrint(jsonEncode(response.data));
    debugPrint(jsonEncode(response.errors));

    setState(() {
      _isLoading = false;
    });
  }

  void _onCancelOrderTap() {
    context.carrotRouter.go(FTRoutes.sales());
  }

  void _onPayWithCashTap() async {
    final result = await context.carrotRouter.overlayEntry<bool>(
      builder: (bag) => _FTSalesSummaryCashConfirmDialog(
        close: bag.close,
        priceCents: _salesBloc.state.productTotalPriceCents,
        shopModel: shopModel,
      ),
    );

    if (result == null || !result) {
      return;
    }

    await _placeOrder((client) async => await _orderService.withUserType(
          organizer: (service) async => await _orderService.orderCash(
            shopCode: shopModel.code,
            order: FTShopOrderModel(
              reservationReference: _salesBloc.state.reservationReference!,
              enableTicketServicePlus: false,
              optInPromotionalEmail: false,
              optInPromotionalSms: false,
              receiveViaSms: false,
              client: client,
            ),
          ),
          appTeam: (service) async => await _orderService.orderAppTeamCash(
            shopCode: shopModel.code,
            order: FTShopOrderModel(
              reservationReference: _salesBloc.state.reservationReference!,
              enableTicketServicePlus: false,
              optInPromotionalEmail: false,
              optInPromotionalSms: false,
              receiveViaSms: false,
              client: client,
            ),
          ),
        ));
  }

  void _onPayWithPinTap() async {
    assert(pinPaymentMethod != null);
    assert(pinTerminal != null);

    await _placeOrder((client) async => await _orderService.orderPin(
          pinSerialNumber: pinTerminal!.serialNumber,
          shopCode: shopModel.code,
          order: FTShopOrderModel(
            reservationReference: _salesBloc.state.reservationReference!,
            enableTicketServicePlus: false,
            optInPromotionalEmail: false,
            optInPromotionalSms: false,
            receiveViaSms: false,
            client: client,
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return FTLayoutSales(
      isLoading: _isLoading,
      footer: _FTSalesSummaryFooter(
        canPayCash: context.userCan(FTUserClaim.salePaymentsCash),
        canPayPin: canUsePin,
        shopModel: shopModel,
        onCancelTap: _onCancelOrderTap,
        onPayCashTap: _onPayWithCashTap,
        onPayPinTap: _onPayWithPinTap,
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          gap: 9,
          children: [
            _FTSalesSummaryInfo(
              shopForm: shopForm,
              shopModel: shopModel,
            ),
            const CarrotSpacer.vertical(size: 15),
            CarrotText.headline5(context.strings.salesShopSummaryProducts),
            _FTSalesSummaryProducts(
              products: _salesBloc.state.products,
              shopForm: shopForm,
              shopModel: shopModel,
            ),
          ],
        ),
      ),
    );
  }
}

class _FTSalesSummaryInfo extends StatelessWidget {
  final FTShopFormModel shopForm;
  final FTShopModel shopModel;

  const _FTSalesSummaryInfo({
    required this.shopForm,
    required this.shopModel,
  });

  bool _containsField(List<FTShopFieldType> fields) {
    for (var shopField in shopModel.fields) {
      if (fields.contains(shopField.field)) {
        return true;
      }
    }

    return false;
  }

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);

    return FTFlatList(
      children: [
        if (_containsField([FTShopFieldType.email]))
          FTFlatListItemInfo(
            icon: 'envelope',
            title: Text(context.strings.salesShopFieldEmailTitle),
            description: Text(shopForm.email),
          ),
        if (_containsField([FTShopFieldType.firstName, FTShopFieldType.lastName]))
          FTFlatListItemInfo(
            icon: 'user',
            title: Text(context.strings.salesShopFieldNameTitle),
            description: Text(shopForm.fullName ?? '-'),
          ),
        if (_containsField([FTShopFieldType.birthDate]))
          FTFlatListItemInfo(
            icon: 'cake',
            title: Text(context.strings.salesShopFieldBirthdateTitle),
            description: Text(DateFormat.yMMMMd(locale.languageCode).format(shopForm.birthDate!)),
          ),
        if (_containsField([FTShopFieldType.phoneNumber]))
          FTFlatListItemInfo(
            icon: 'mobile-notch',
            title: Text(context.strings.salesShopFieldPhoneNumberTitle),
            description: Text(shopForm.phoneNumber ?? '-'),
          ),
        if (_containsField([FTShopFieldType.gender]))
          FTFlatListItemInfo(
            icon: 'mars-and-venus',
            title: Text(context.strings.salesShopFieldGenderTitle),
            description: Text(shopForm.gender?.toString() ?? '-'),
          ),
      ],
    );
  }
}

class _FTSalesSummaryProducts extends StatelessWidget {
  final List<FTShopCartProductModel> products;
  final FTShopFormModel shopForm;
  final FTShopModel shopModel;

  const _FTSalesSummaryProducts({
    required this.products,
    required this.shopForm,
    required this.shopModel,
  });

  @override
  Widget build(BuildContext context) {
    return FTFlatList(
      children: [
        for (final cart in products)
          FTFlatListItemInfo(
            icon: cart.product.type == FTProductType.ticket ? 'ticket-simple' : 'shopping-bag',
            title: Text(cart.product.name),
            description: Text(context.strings.salesShopSummaryAmount(cart.quantity)),
          ),
      ],
    );
  }
}

class _FTSalesSummaryFooter extends StatelessWidget {
  final bool canPayCash;
  final bool canPayPin;
  final FTShopModel shopModel;
  final VoidCallback onCancelTap;
  final VoidCallback onPayCashTap;
  final VoidCallback onPayPinTap;

  const _FTSalesSummaryFooter({
    required this.canPayCash,
    required this.canPayPin,
    required this.shopModel,
    required this.onCancelTap,
    required this.onPayCashTap,
    required this.onPayPinTap,
  });

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    final salesBloc = context.watch<FTSalesStateBloc>();

    return FTSalesBottomBar(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      direction: Axis.vertical,
      children: [
        Expanded(
          child: FTSalesBottomBarPrice(
            label: context.strings.salesShopBottomBarTotal,
            price: shopModel.event.currency.format(locale, salesBloc.state.productTotalPriceCents),
            textAlign: TextAlign.center,
          ),
        ),
        const CarrotSpacer.vertical(size: 15),
        if (canPayCash || canPayPin)
          IntrinsicHeight(
            child: CarrotRow(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              gap: 6,
              children: [
                if (canPayCash)
                  Expanded(
                    child: CarrotContainedButton.text(
                      icon: 'money-bill',
                      text: Text(context.strings.salesBuiltInPaymentMethodsCash),
                      onTap: onPayCashTap,
                    ),
                  ),
                if (canPayPin)
                  Expanded(
                    child: CarrotContainedButton.text(
                      icon: 'credit-card',
                      text: Text(context.strings.salesBuiltInPaymentMethodsPin),
                      onTap: onPayPinTap,
                    ),
                  ),
              ],
            ),
          ),
        CarrotLinkButtonTheme(
          data: context.carrotTheme.linkButtonTheme.copyWith(
            background: CarrotOptional.of(context.carrotTheme.primary[900]),
            backgroundActive: CarrotOptional.of(context.carrotTheme.primary[800]),
            foreground: const CarrotOptional.of(CarrotColors.white),
          ),
          child: CarrotLinkButton.text(
            text: Text(context.strings.cancel),
            onTap: onCancelTap,
          ),
        ),
      ],
    );
  }
}

class _FTSalesSummaryCashConfirmDialog extends CarrotDialog<bool> {
  final int priceCents;
  final FTShopModel shopModel;

  const _FTSalesSummaryCashConfirmDialog({
    required super.close,
    required this.priceCents,
    required this.shopModel,
  });

  @override
  Widget buildContent(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    final locale = Localizations.localeOf(context);
    final priceStr = shopModel.event.currency.format(locale, priceCents);

    return Padding(
      padding: padding.copyWith(
        top: math.max(padding.top, headerSize.height),
        bottom: math.max(padding.top, footerSize.height),
      ),
      child: Text(
        priceStr,
        style: context.carrotTypography.headline1,
      ),
    );
  }

  @override
  Widget? buildFooter(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    return CarrotDialogButtons(
      buttons: [
        CarrotDialogButton.primary(
          label: context.strings.confirm,
          result: true,
        ),
        CarrotDialogButton.secondary(
          label: context.strings.cancel,
          result: false,
        ),
      ],
    );
  }

  @override
  Widget? buildHeader(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    return FTDialogHeader(
      title: Text(context.strings.salesConfirmCashPaymentTitle),
      body: Text(context.strings.salesConfirmCashPaymentMessage),
    );
  }
}
