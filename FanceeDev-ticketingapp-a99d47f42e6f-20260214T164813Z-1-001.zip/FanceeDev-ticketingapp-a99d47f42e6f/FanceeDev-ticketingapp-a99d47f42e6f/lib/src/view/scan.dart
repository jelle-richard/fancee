import 'package:carrot/carrot.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../l10n/l10n.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../routes.dart';
import 'scan_camera.dart';
import 'scan_result.dart';

class FTViewScan extends StatefulWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.scannerTitle,
    path: '/scan',
    builder: (context, state) => const FTViewScan(),
    routes: [
      FTViewScanCamera.route,
      FTViewScanResult.route,
    ],
  );

  const FTViewScan({
    super.key,
  });

  @override
  createState() => _FTViewScanState();
}

class _FTViewScanState extends State<FTViewScan> {
  late final FTAppStateBloc _appState;

  final List<FTScanHistoryEntry> _history = [];

  bool _isLoading = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loadHistory();
  }

  @override
  void dispose() {
    _appState.add(const FTAppStateSetAppBarActions());
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    onMounted(() {
      _appState = context.read<FTAppStateBloc>();
      _loadHistory();
    });
  }

  Future<void> _loadHistory() async {
    final database = FTDatabase.of(context);
    final history = await database.scans.getAll();

    if (!mounted) {
      return;
    }

    if (history.isNotEmpty) {
      _appState.add(FTAppStateSetAppBarActions([
        FTAppBarButton(
          icon: 'trash-list',
          label: context.strings.delete,
          onTap: _onRemoveHistoryTap,
        ),
      ]));
    } else {
      _appState.add(const FTAppStateSetAppBarActions());
    }

    setState(() {
      _history.clear();
      _history.addAll(history);
      _isLoading = false;
    });
  }

  Future<bool> _loadIsSimulator() async {
    final deviceInfo = await DeviceInfoPlugin().deviceInfo;

    if (deviceInfo is IosDeviceInfo) {
      return !deviceInfo.isPhysicalDevice;
    }

    if (deviceInfo is AndroidDeviceInfo) {
      return !deviceInfo.isPhysicalDevice;
    }

    return false;
  }

  void _onRemoveHistoryTap() async {
    setState(() {
      _isLoading = true;
    });

    _appState.add(const FTAppStateSetAppBarActions());
    await FTDatabase.of(context).scans.deleteAll();

    setState(() {
      _history.clear();
      _isLoading = false;
    });
  }

  void _onStartScanningTap() {
    context.carrotRouter.push(FTRoutes.scanCamera());
  }

  Widget _headerBuilder(BuildContext context) {
    return FutureBuilder(
      future: _loadIsSimulator(),
      builder: (context, simulatorSnapshot) => Padding(
        padding: const EdgeInsets.only(
          left: 36,
          right: 36,
          bottom: 36,
        ),
        child: CarrotColumn(
          gap: 15,
          children: [
            if (simulatorSnapshot.hasData && simulatorSnapshot.data == true)
              FTSubtleNotice(
                icon: 'mobile',
                iconColor: context.carrotTheme.defaults.info,
                title: Text(context.strings.scannerSimulatorTitle),
                body: Text(context.strings.scannerSimulatorMessage),
              ),
            Align(
              alignment: Alignment.center,
              child: SizedBox.square(
                dimension: 210,
                child: SvgPicture.asset(
                  'assets/illustrations/scan${context.carrotTheme.isDark ? '_dark' : ''}.svg',
                ),
              ),
            ),
            CarrotContainedButton.text(
              iconAfter: 'circle-arrow-right',
              size: CarrotButtonSize.large,
              text: Text(context.strings.scannerStart),
              onTap: _onStartScanningTap,
            ),
          ],
        ),
      ),
    );
  }

  Widget _itemBuilder(BuildContext context, int index) {
    if (_history.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(60.0),
        child: Align(
          alignment: Alignment.center,
          child: SizedBox.square(
            dimension: 210,
            child: SvgPicture.asset(
              'assets/illustrations/scan_history${context.carrotTheme.isDark ? '_dark' : ''}.svg',
            ),
          ),
        ),
      );
    }

    return FTScanHistoryItem(
      entry: _history[index],
    );
  }

  Widget _separatorBuilder(BuildContext context, int index) {
    return const CarrotSpacer.vertical(size: 15);
  }

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.listView(
      headerBuilder: _headerBuilder,
      isLoading: _isLoading,
      itemBuilder: _itemBuilder,
      itemCount: _history.isEmpty ? 1 : _history.length,
      padding: const EdgeInsets.all(30),
      separatorBuilder: _separatorBuilder,
    );
  }
}
