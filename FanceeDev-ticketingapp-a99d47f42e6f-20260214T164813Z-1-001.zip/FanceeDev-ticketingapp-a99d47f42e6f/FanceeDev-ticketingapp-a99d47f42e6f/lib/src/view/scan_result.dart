import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';
import '../module/audio/audio.dart';
import '../module/haptics/haptics.dart';
import '../routes.dart';

class FTViewScanResult extends StatefulWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.scannerTitle,
    path: 'result/:type',
    builder: (context, state) => FTViewScanResult(
      type: FTScanResultType.fromString(state.pathParameters['type']!),
      message: state.queryParameters['message'],
      reason: state.queryParameters['reason'],
    ),
  );

  final String? message;
  final String? reason;
  final FTScanResultType type;

  const FTViewScanResult({
    super.key,
    required this.type,
    this.message,
    this.reason,
  });

  @override
  createState() => _FTViewScanResultState();
}

class _FTViewScanResultState extends State<FTViewScanResult> {
  late final FTAudio _audioFeedback;
  late final FTHaptics _hapticFeedback;

  bool _isFirstRender = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _audioFeedback = FTAudio(context.read<FTUserStateBloc>().state);
      _hapticFeedback = FTHaptics(context.read<FTUserStateBloc>().state);
      _isFirstRender = false;
    }

    _giveAudioFeedback();
    _giveHapticFeedback();
  }

  void _giveAudioFeedback() {
    switch (widget.type) {
      case FTScanResultType.failed:
      case FTScanResultType.invalid:
        _audioFeedback.scannerInvalid();
        break;

      case FTScanResultType.ok:
      case FTScanResultType.reused:
        _audioFeedback.scannerValid();
        break;
    }
  }

  void _giveHapticFeedback() {
    switch (widget.type) {
      case FTScanResultType.failed:
      case FTScanResultType.invalid:
        _hapticFeedback.scannerInvalid();
        break;

      case FTScanResultType.ok:
      case FTScanResultType.reused:
        _hapticFeedback.scannerValid();
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    late CarrotColor color;
    late String icon;
    late String label;

    switch (widget.type) {
      case FTScanResultType.failed:
        color = context.carrotTheme.defaults.error;
        icon = 'circle-exclamation';
        label = context.strings.scannerResultFailed;
        break;

      case FTScanResultType.invalid:
        color = context.carrotTheme.defaults.error;
        icon = 'circle-xmark';
        label = context.strings.scannerResultInvalid;
        break;

      case FTScanResultType.ok:
        color = context.carrotTheme.defaults.success;
        icon = 'circle-check';
        label = context.strings.scannerResultOk;
        break;

      case FTScanResultType.reused:
        color = context.carrotTheme.defaults.warning;
        icon = 'circle-check';
        label = context.strings.scannerResultReused;
        break;
    }

    return FTLayoutSheet.singleChildScrollView(
      padding: const EdgeInsets.all(24),
      builder: (context) => FTScrollViewConstraints(
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          gap: 30,
          children: [
            const CarrotSpacer.vertical(size: 42),
            CarrotIcon(
              color: color,
              glyph: icon,
              size: 150,
            ),
            Text(
              label,
              textAlign: TextAlign.center,
              style: context.carrotTypography.headline3.copyWith(
                color: color,
              ),
            ),
            if (widget.message != null)
              CarrotText.body2(
                widget.message!,
                textAlign: TextAlign.center,
              ),
            if (widget.reason != null)
              CarrotText.body2(
                widget.reason!,
                textAlign: TextAlign.center,
              ),
            Expanded(
              child: Container(),
            ),
            CarrotContainedButton.text(
              iconAfter: 'circle-arrow-right',
              text: Text(context.strings.scannerStart),
              onTap: () {
                context.carrotRouter.push(FTRoutes.scan());
              },
            ),
          ],
        ),
      ),
    );
  }
}
