import 'dart:async';

import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../routes.dart';

class FTViewSalesOrder extends StatefulWidget {
  static final route = FTRoute(
    arguments: const FTShellSettings(
      hideBottomBar: true,
    ),
    nameGenerator: (context, _) => context.strings.salesOrderCompleteTitle,
    path: 'order/:orderId',
    builder: (context, state) => FTViewSalesOrder(
      orderId: state.pathParameters['orderId']!,
    ),
  );

  final String orderId;

  const FTViewSalesOrder({
    super.key,
    required this.orderId,
  });

  @override
  createState() => _FTViewSalesOrderState();
}

class _FTViewSalesOrderState extends State<FTViewSalesOrder> {
  late final FTOrderService _orderService;
  late final FTUserStateBloc _userStateBloc;

  bool _isFirstRender = true;
  bool _isLoading = false;
  FTOrderModel? _order;
  Timer? _timer;

  bool get _hasPendingProducts => _order == null || _order!.products.any((p) => p.issuedTickets.isEmpty);

  List<_ProductWithIssuedTicket> get _tickets {
    if (_order == null) {
      return [];
    }

    final tickets = <_ProductWithIssuedTicket>[];

    for (final product in _order!.products) {
      for (final issuedTicket in product.issuedTickets) {
        tickets.add(_ProductWithIssuedTicket(
          product: product,
          issuedTicket: issuedTicket,
        ));
      }
    }

    return tickets;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _orderService = FTOrderService(context: context);
      _userStateBloc = context.read<FTUserStateBloc>();
      _isFirstRender = false;
    }
  }

  @override
  void didUpdateWidget(FTViewSalesOrder oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.orderId != oldWidget.orderId) {
      _loadOrder();
    }
  }

  @override
  void dispose() {
    _cancelTimer();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    onMounted(_loadOrder);
  }

  void _loadOrder() async {
    _cancelTimer();

    setState(() {
      _isLoading = true;
    });

    final response = await _orderService.withUserType(
      organizer: (service) async => await service.get(
        orderId: widget.orderId,
      ),
      appTeam: (service) async => await service.appTeamGet(
        orderId: widget.orderId,
      ),
    );

    if (response.isOk) {
      setState(() {
        _isLoading = false;
        _order = response.data;
      });

      if (_hasPendingProducts) {
        _startTimer();
      }
    } else {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _cancelTimer() {
    _timer?.cancel();
    _timer = null;
  }

  void _startTimer() {
    _timer = Timer(const Duration(seconds: 3), _onTimerTick);
  }

  void _onCloseTap() {
    context.carrotRouter.go(
      FTRoutes.sales(),
    );
  }

  void _onPrintTap() {
    assert(_order != null);

    final locale = Localizations.localeOf(context);
    final printers = _userStateBloc.state.printers;

    if (printers.isEmpty) {
      return;
    }

    final printer = printers.first; // todo(Bas): make default option and button to choose printer.
    printer.printOrder(locale, _order!);
  }

  void _onTimerTick() {
    _loadOrder();
  }

  Widget _buildOptions(BuildContext context) {
    return SliverToBoxAdapter(
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        gap: 12,
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_userStateBloc.state.printers.isNotEmpty)
            CarrotContainedButton.text(
              icon: 'receipt',
              size: CarrotButtonSize.large,
              text: Text(context.strings.salesOrderCompletePrint),
              onTap: _onPrintTap,
            ),
          CarrotTextButton.text(
            icon: 'circle-xmark',
            size: CarrotButtonSize.large,
            text: Text(context.strings.salesOrderCompleteClose),
            onTap: _onCloseTap,
          ),
        ],
      ),
    );
  }

  Widget _buildProduct(BuildContext context, int index) {
    assert(_order != null);

    final product = _order!.products[index];

    if (product.type != FTProductType.ticket) {
      return nothing;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 9,
      ),
      child: FTSalesTicket(
        isLoading: true,
        eventName: _order!.event.name,
        eventStartDate: _order!.event.startDate,
        productName: product.name,
      ),
    );
  }

  Widget _buildProducts(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        _buildProduct,
        childCount: _order?.products.length ?? 0,
      ),
    );
  }

  Widget _buildTicket(BuildContext context, int index) {
    assert(_order != null);

    final ticket = _tickets[index];

    if (ticket.product.type != FTProductType.ticket) {
      return nothing;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 9,
      ),
      child: FTSalesTicket(
        eventName: _order!.event.name,
        eventStartDate: _order!.event.startDate,
        productName: ticket.product.name,
        qrData: ticket.issuedTicket.code,
      ),
    );
  }

  Widget _buildTickets(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        _buildTicket,
        childCount: _tickets.length,
      ),
    );
  }

  Widget _buildStatus(BuildContext context) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 60,
        ),
        child: SizedBox.square(
          dimension: 150,
          child: Align(
            alignment: Alignment.center,
            child: Builder(
              builder: _buildStatusSymbol,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusSymbol(BuildContext context) {
    if (_hasPendingProducts) {
      return const FTSpinner(
        size: 60,
        thickness: 9,
      );
    }

    return CarrotIcon(
      color: context.carrotTheme.defaults.success,
      glyph: 'circle-check',
      size: 150,
    );
  }

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.customScrollView(
      isLoading: _isLoading,
      slivers: [
        Builder(
          builder: _buildStatus,
        ),
        if (!_hasPendingProducts)
          SliverPadding(
            padding: const EdgeInsets.only(
              left: 24,
              right: 24,
              bottom: 30,
            ),
            sliver: Builder(
              builder: _buildOptions,
            ),
          ),
        SliverPadding(
          padding: context.safeAreaReal.copyWith(
            top: 0,
          ),
          sliver: Builder(
            builder: _tickets.isEmpty ? _buildProducts : _buildTickets,
          ),
        ),
      ],
    );
  }
}

class _ProductWithIssuedTicket {
  final FTOrderProductModel product;
  final FTOrderProductIssuedTicketModel issuedTicket;

  const _ProductWithIssuedTicket({
    required this.product,
    required this.issuedTicket,
  });
}
