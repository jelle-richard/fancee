import 'package:carrot/carrot.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';

class FTViewStatisticsEvent extends StatefulWidget {
  static final route = FTRoute(
    nameGenerator: (context, state) => state.queryParameters.containsKey('eventName') ? state.queryParameters['eventName'] : context.strings.statistics,
    path: ':eventId',
    builder: (context, state) => FTViewStatisticsEvent(
      eventId: state.pathParameters['eventId']!,
    ),
  );

  final String eventId;

  const FTViewStatisticsEvent({
    super.key,
    required this.eventId,
  });

  @override
  createState() => _FTViewStatisticsEventState();
}

class _FTViewStatisticsEventState extends State<FTViewStatisticsEvent> {
  List<FTScanStatisticTicketModel> _tickets = const [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();

    Future.microtask(() async {
      final response = await FTScanService(context: context).withUserType(
        organizer: (service) => service.getStatistics(
          eventId: widget.eventId,
        ),
        appTeam: (service) => service.getStatisticsAppTeam(
          eventId: widget.eventId,
        ),
      );

      setState(() {
        _isLoading = false;
        _tickets = response.data ?? const [];
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    // note(Bas): header image is disabled for after initial release.
    // final carrotTheme = context.carrotTheme;

    return FTLayoutSheet.singleChildScrollView(
      isLoading: _isLoading,
      // headerBuilder: (context) => Stack(
      //   clipBehavior: Clip.none,
      //   children: [
      //     const AspectRatio(
      //       aspectRatio: 21 / 9,
      //     ),
      //     Positioned(
      //       top: -context.carrotScaffold.appBarSize.height,
      //       left: 0,
      //       right: 0,
      //       bottom: -27,
      //       child: DecoratedBox(
      //         decoration: BoxDecoration(
      //           color: carrotTheme.resolve(carrotTheme.primary[40], carrotTheme.gray[25]),
      //         ),
      //         child: Image.network('https://images.pexels.com/photos/13625508/pexels-photo-13625508.jpeg?auto=compress&cs=tinysrgb&w=1600&lazy=load', fit: BoxFit.cover),
      //       ),
      //     ),
      //     Positioned(
      //       top: -context.carrotScaffold.appBarSize.height,
      //       left: 0,
      //       right: 0,
      //       bottom: -27,
      //       child: DecoratedBox(
      //         decoration: BoxDecoration(
      //           gradient: LinearGradient(
      //             begin: Alignment.topCenter,
      //             end: Alignment.bottomCenter,
      //             colors: [
      //               carrotTheme.primary[900].withOpacity(.95),
      //               carrotTheme.primary[900].withOpacity(.0),
      //               carrotTheme.primary[900].withOpacity(.0),
      //             ],
      //           ),
      //         ),
      //       ),
      //     ),
      //   ],
      // ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(30),
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          gap: 30,
          children: [
            _AllTicketsChart(
              tickets: _tickets,
            ),
            _SoldTicketsChart(
              tickets: _tickets,
            ),
          ],
        ),
      ),
    );
  }
}

class _AllTicketsChart extends StatelessWidget {
  final List<FTScanStatisticTicketModel> tickets;

  List<_TicketAmountEntry> get dataSource {
    List<_TicketAmountEntry> entries = [];

    entries.addAll(tickets.asMap().entries.map(
          (ticket) => _TicketAmountEntry(
            amount: ticket.value.amountScanned,
            color: CarrotColors.colorful[ticket.key],
            name: ticket.value.name,
          ),
        ));

    entries.add(_TicketAmountEntry(
      amount: unscannedTickets,
      name: 'Unscanned',
    ));

    return entries;
  }

  int get unscannedTickets {
    return tickets.fold(0, (value, ticket) => value + (ticket.amountIssued - ticket.amountScanned));
  }

  const _AllTicketsChart({
    required this.tickets,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return FTPaddedDecoratedBox.borderedBoxWithTitle(
      title: Text(context.strings.statisticsTicketsAll),
      child: CarrotRow(
        crossAxisAlignment: CrossAxisAlignment.start,
        gap: 15,
        children: [
          Expanded(
            child: CarrotColumn(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              gap: 6,
              children: [
                ...dataSource.map(
                  (entry) => FTChartLegendColoredLabel(
                    amount: entry.amount,
                    color: entry.color ?? carrotTheme.gray[carrotTheme.resolve(300, 200)],
                    label: entry.name,
                  ),
                ),
              ],
            ),
          ),
          SizedBox.square(
            dimension: 90,
            child: SfCircularChart(
              margin: EdgeInsets.zero,
              tooltipBehavior: TooltipBehavior(enable: false),
              series: [
                DoughnutSeries<_TicketAmountEntry, String>(
                  animationDuration: 300,
                  dataSource: dataSource,
                  strokeColor: carrotTheme.gray[25],
                  strokeWidth: 2,
                  pointColorMapper: (data, _) => data.color ?? carrotTheme.gray[carrotTheme.resolve(300, 200)],
                  xValueMapper: (data, _) => data.name,
                  yValueMapper: (data, _) => data.amount,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SoldTicketsChart extends StatelessWidget {
  final List<FTScanStatisticTicketModel> tickets;

  List<_TicketAmountEntry> get dataSource {
    return tickets
        .asMap()
        .entries
        .map(
          (ticket) => _TicketAmountEntry(
            amount: ticket.value.amountIssued,
            color: CarrotColors.colorful[ticket.key],
            name: ticket.value.name,
          ),
        )
        .toList();
  }

  const _SoldTicketsChart({
    required this.tickets,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return FTPaddedDecoratedBox.borderedBoxWithTitle(
      title: Text(context.strings.statisticsTicketsSold),
      child: CarrotRow(
        crossAxisAlignment: CrossAxisAlignment.start,
        gap: 15,
        children: [
          Expanded(
            child: CarrotColumn(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              gap: 6,
              children: [
                ...dataSource.map(
                  (entry) => FTChartLegendColoredLabel(
                    amount: entry.amount,
                    color: entry.color ?? carrotTheme.gray[carrotTheme.resolve(300, 200)],
                    label: entry.name,
                  ),
                ),
              ],
            ),
          ),
          SizedBox.square(
            dimension: 90,
            child: SfCircularChart(
              margin: EdgeInsets.zero,
              tooltipBehavior: TooltipBehavior(enable: false),
              series: [
                DoughnutSeries<_TicketAmountEntry, String>(
                  animationDuration: 300,
                  dataSource: dataSource,
                  strokeColor: carrotTheme.gray[25],
                  strokeWidth: 2,
                  pointColorMapper: (data, _) => data.color ?? carrotTheme.gray[carrotTheme.resolve(300, 200)],
                  xValueMapper: (data, _) => data.name,
                  yValueMapper: (data, _) => data.amount,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TicketAmountEntry {
  final int amount;
  final Color? color;
  final String name;

  const _TicketAmountEntry({
    required this.amount,
    required this.name,
    this.color,
  });
}

// note: the code below is for hourly scan data, but that's not used
//  at this moment.

// final graph = FTPaddedDecoratedBox.borderedBoxWithTitle(
//   title: const Text('Scans'),
//   child: ConstrainedBox(
//     constraints: const BoxConstraints(
//       maxHeight: 120,
//       minHeight: 120,
//     ),
//     child: SfCartesianChart(
//       key: GlobalKey(),
//       plotAreaBorderWidth: 0,
//       primaryXAxis: DateTimeCategoryAxis(isVisible: false),
//       primaryYAxis: NumericAxis(isVisible: false),
//       tooltipBehavior: FTChartSingleSeriesTooltip.asTooltipBehavior(
//         context: context,
//         data: _chartData,
//         builder: (data) => Text('${DateFormat.Hm().format(data.x)}: ${data.y} scans'),
//       ),
//       series: [
//         ColumnSeries<ExampleData, DateTime>(
//           dataSource: _chartData,
//           xValueMapper: (data, _) => data.x,
//           yValueMapper: (data, _) => data.y,
//           animationDelay: 150,
//           animationDuration: 300,
//           borderRadius: BorderRadius.circular(6),
//           color: CarrotColors.cyan,
//           enableTooltip: true,
//           name: 'Scans',
//         ),
//       ],
//     ),
//   ),
// );
//
// class ExampleData {
//   final DateTime x;
//   final int y;
//
//   const ExampleData(this.x, this.y);
// }
//
// final List<ExampleData> _chartData = [
//   ExampleData(DateTime.parse('2022-09-20 10:00'), 10),
//   ExampleData(DateTime.parse('2022-09-20 11:00'), 20),
//   ExampleData(DateTime.parse('2022-09-20 12:00'), 30),
//   ExampleData(DateTime.parse('2022-09-20 13:00'), 5),
//   ExampleData(DateTime.parse('2022-09-20 14:00'), 50),
//   ExampleData(DateTime.parse('2022-09-20 15:00'), 10),
//   ExampleData(DateTime.parse('2022-09-20 16:00'), 20),
//   ExampleData(DateTime.parse('2022-09-20 17:00'), 30),
//   ExampleData(DateTime.parse('2022-09-20 18:00'), 5),
//   ExampleData(DateTime.parse('2022-09-20 19:00'), 50),
//   ExampleData(DateTime.parse('2022-09-20 20:00'), 10),
//   ExampleData(DateTime.parse('2022-09-20 21:00'), 20),
//   ExampleData(DateTime.parse('2022-09-20 22:00'), 30),
//   ExampleData(DateTime.parse('2022-09-20 23:00'), 5),
//   ExampleData(DateTime.parse('2022-09-21 00:00'), 50),
// ];
