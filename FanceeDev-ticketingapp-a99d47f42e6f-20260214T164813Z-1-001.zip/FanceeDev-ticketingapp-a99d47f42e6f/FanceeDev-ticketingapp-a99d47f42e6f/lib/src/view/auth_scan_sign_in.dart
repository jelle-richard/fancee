import 'package:carrot/carrot.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../l10n/l10n.dart';
import '../component/organism/organism.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../routes.dart';

class FTViewAuthScanSignIn extends StatefulWidget {
  static final route = FTRoute.scanner(
    arguments: const FTShellSettings(
      hideAppBar: true,
      hideBottomBar: true,
    ),
    path: '/scan-sign-in',
    builder: (_, __) => const FTViewAuthScanSignIn(),
  );

  const FTViewAuthScanSignIn({
    super.key,
  });

  @override
  createState() => _FTViewAuthScanSignInState();
}

class _FTViewAuthScanSignInState extends State<FTViewAuthScanSignIn> {
  late FTAuthService _authService;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();

    onMounted(() {
      _authService = FTAuthService(context: context);
    });
  }

  void _onCancelTap() {
    context.carrotRouter.pop();
  }

  void _onScan(Barcode barcode) async {
    if (_isLoading) {
      return;
    }

    final authBloc = context.read<FTAuthStateBloc>();
    final router = context.carrotRouter;

    setState(() {
      _isLoading = true;
    });

    final response = await _authService.loginAppTeam(
      teamId: barcode.rawValue!,
    );

    if (response.isOk) {
      final user = response.data!.user;

      if (!user.isAppTeam) {
        router.push(FTRoutes.noticeUnsupportedUser());
      } else {
        authBloc.add(FTAuthStateSetBearerToken(
          bearerToken: response.data!.accessToken,
          user: user,
          validUntil: response.data!.validUntil,
        ));

        router.go(FTRoutes.more());
      }
    } else {
      router.push(FTRoutes.noticeUnsupportedUser());
    }
  }

  @override
  Widget build(BuildContext context) {
    return FTLoadingOverlay(
      isLoading: _isLoading,
      child: FTScanView(
        actions: [
          FTScanViewAction(
            icon: 'chevron-left',
            label: context.strings.back,
            onTap: _onCancelTap,
          ),
          const CarrotFiller(),
        ],
        canRotateCamera: false,
        canToggleFlashlight: true,
        onRequestBack: _onCancelTap,
        onScan: _onScan,
      ),
    );
  }
}
