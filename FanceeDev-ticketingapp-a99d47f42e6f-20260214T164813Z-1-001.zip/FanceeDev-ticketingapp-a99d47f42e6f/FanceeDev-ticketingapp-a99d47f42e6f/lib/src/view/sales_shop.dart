import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../routes.dart';
import '../util/util.dart';

part '../component/parts/sales_shop_elements.dart';

class FTViewSalesShop extends StatefulWidget {
  static final route = FTRoute(
    arguments: const FTShellSettings(
      hideBottomBar: true,
    ),
    nameGenerator: (context, state) => state.queryParameters['shopName'],
    path: ':eventId/:shopCode',
    builder: (context, _) => const FTViewSalesShop(),
  );

  const FTViewSalesShop({
    super.key,
  });

  @override
  createState() => _FTViewSalesShopState();
}

class _FTViewSalesShopState extends State<FTViewSalesShop> {
  late final FTSalesStateBloc _salesBloc;
  late final FTShopService _shopService;

  bool _isFirstRender = true;
  bool _isLoading = false;

  FTShopModel get shopModel => assertedCast(_salesBloc.state.shop);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _salesBloc = context.read<FTSalesStateBloc>();
      _shopService = FTShopService(context: context);
      _isFirstRender = false;
    }
  }

  @override
  void initState() {
    super.initState();

    onMounted(() {
      _salesBloc.add(const FTSalesStateFormReset());
    });
  }

  void _onNextTap() async {
    setState(() {
      _isLoading = true;
    });

    final router = context.carrotRouter;
    final reservationReference = await _shopService.reserve(
      shopCode: shopModel.code,
      products: _salesBloc.state.cart.entries
          .map(
            (entry) => FTReservedProductModel(productId: entry.key, quantity: entry.value),
          )
          .toList(),
    );

    _salesBloc.add(FTSalesStateSetReservationReference(reservationReference.data));

    setState(() {
      _isLoading = false;
    });

    router.push(FTRoutes.salesDetails(
      shopModel.event.id,
      shopModel.code,
      shopModel.name,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return FTLayoutSales(
      isLoading: _isLoading,
      footer: _FTShopBottomBar(
        shopModel: shopModel,
        onNextTap: _onNextTap,
      ),
      child: _FTShopElementsBuilder(
        shopModel: shopModel,
      ),
    );
  }
}

class _FTShopBottomBar extends StatelessWidget {
  final FTShopModel shopModel;
  final GestureTapCallback onNextTap;

  const _FTShopBottomBar({
    required this.shopModel,
    required this.onNextTap,
  });

  @override
  Widget build(BuildContext context) {
    final salesBloc = context.watch<FTSalesStateBloc>();
    final locale = Localizations.localeOf(context);

    return FTSalesBottomBar(
      children: [
        Expanded(
          child: FTSalesBottomBarPrice(
            label: context.strings.salesShopBottomBarTotal,
            price: shopModel.event.currency.format(locale, salesBloc.state.productTotalPriceCents),
          ),
        ),
        FTSalesBottomBarButton(
          disabled: salesBloc.state.productTotalPriceCents == 0,
          iconAfter: 'circle-arrow-right',
          label: context.strings.salesShopBottomBarNext,
          onTap: onNextTap,
        ),
      ],
    );
  }
}

class _FTShopElementsBuilder extends StatelessWidget {
  final FTShopModel shopModel;

  const _FTShopElementsBuilder({
    required this.shopModel,
  });

  Widget _buildElement(BuildContext context, int index) {
    final element = shopModel.elements[index];

    if (!context.isFeatureEnabled(FTFeatureFlag.salesAllShopElementsEnabled) && element.kind != FTShopElementType.product) {
      return nothing;
    }

    switch (element.kind) {
      case FTShopElementType.unknown:
        return nothing;

      case FTShopElementType.divider:
        return _FTShopElementDivider(
          element: element,
          index: index,
          shop: shopModel,
        );

      case FTShopElementType.externalLink:
        return _FTShopElementExternalLink(
          element: element,
          index: index,
          shop: shopModel,
        );

      case FTShopElementType.notice:
        return _FTShopElementNotice(
          element: element,
          index: index,
          shop: shopModel,
        );

      case FTShopElementType.product:
        return _FTShopElementProduct(
          element: element,
          index: index,
          shop: shopModel,
        );

      case FTShopElementType.textBlock:
        return _FTShopElementTextBlock(
          element: element,
          index: index,
          shop: shopModel,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemBuilder: _buildElement,
      itemCount: shopModel.elements.length,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      shrinkWrap: true,
    );
  }
}
