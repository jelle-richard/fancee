import 'package:carrot/carrot.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../l10n/l10n.dart';
import '../component/molecule/molecule.dart';
import '../component/organism/organism.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../routes.dart';

class FTViewScanCamera extends StatefulWidget {
  static final route = FTRoute.scanner(
    arguments: const FTShellSettings(
      hideAppBar: true,
      hideBottomBar: true,
    ),
    nameGenerator: (context, _) => context.strings.scannerTitle,
    path: 'camera',
    builder: (context, state) => const FTViewScanCamera(),
  );

  const FTViewScanCamera({
    super.key,
  });

  @override
  createState() => _FTViewScanCameraState();
}

class _FTViewScanCameraState extends State<FTViewScanCamera> {
  int _currentMode = 0;
  bool _isLoading = false;

  void _scan(String code) async {
    setState(() {
      _isLoading = true;
    });

    final database = FTDatabase.of(context);
    final mode = _currentMode == 0 ? FTScanState.scanned : FTScanState.unscanned;
    final router = context.carrotRouter;

    final result = await FTScanService(context: context).withUserType(
      organizer: (service) async => await service.setScanState(
        code: code,
        state: mode,
      ),
      appTeam: (service) async => await service.setScanStateAppTeam(
        code: code,
        state: mode,
      ),
    );

    await database.scans.add(FTScanHistoryEntry.fromResponseModel(
      code,
      mode,
      DateTime.now(),
      result.data!,
    ));

    router.go(FTRoutes.scanResult(
      result.data!.type,
      result.data!.message,
      result.data!.reason,
    ));
  }

  void _onScan(Barcode barcode) {
    _scan(barcode.rawValue!);
  }

  void _onCancelTap() {
    context.carrotRouter.pop();
  }

  void _onManualInputTap() async {
    final textController = TextEditingController();
    final isOk = await context.carrotRouter.overlay<bool>(
      defaultValue: false,
      dismissible: true,
      builder: (close) => CarrotDialog(
        close: close,
        content: CarrotFormGroup(
          label: const Text('Barcode'),
          child: CarrotTextField(
            autofocus: true,
            controller: textController,
            placeholder: 'FAN123456789',
          ),
        ),
        footerBuilder: (context, _, __, ___) => Padding(
          padding: const EdgeInsets.all(27),
          child: CarrotColumn(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            gap: 9,
            children: [
              ValueListenableBuilder(
                valueListenable: textController,
                builder: (context, value, __) => CarrotDisabled.opacity(
                  disabled: textController.text.trim().isEmpty,
                  child: CarrotContainedButton.text(
                    text: Text(context.carrotStrings.ok),
                    onTap: () => close(true),
                  ),
                ),
              ),
              CarrotTextButton.text(
                text: Text(context.carrotStrings.cancel),
                onTap: () => close(false),
              ),
            ],
          ),
        ),
        headerBuilder: (context, _, __, ___) => FTDialogHeader(
          title: Text(context.strings.scannerManualInputTitle),
        ),
      ),
    );

    if (isOk == null || !isOk) {
      return;
    }

    _scan(textController.text);
  }

  @override
  Widget build(BuildContext context) {
    return FTLoadingSubtleOverlay(
      backgroundColor: CarrotColors.black,
      backgroundOpacity: .75,
      isLoading: _isLoading,
      child: FTScanView(
        onRequestBack: _onCancelTap,
        onScan: _onScan,
        actions: [
          FTScanViewAction(
            key: const ValueKey('cancel-action'),
            icon: 'chevron-left',
            label: context.strings.back,
            onTap: _onCancelTap,
          ),
          const CarrotFiller(),
          FTScanViewAction(
            key: const ValueKey('manual-input-action'),
            icon: 'pencil',
            onTap: _onManualInputTap,
          ),
        ],
        children: [
          Positioned(
            top: context.safeAreaReal.top + 30,
            left: context.safeAreaReal.left,
            right: context.safeAreaReal.right,
            child: FTTransparentModeSwitcher(
              initialIndex: _currentMode,
              onChange: (mode) => _currentMode = mode,
              children: [
                Text(context.strings.scannerModeCheckIn),
                Text(context.strings.scannerModeCheckOut),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
