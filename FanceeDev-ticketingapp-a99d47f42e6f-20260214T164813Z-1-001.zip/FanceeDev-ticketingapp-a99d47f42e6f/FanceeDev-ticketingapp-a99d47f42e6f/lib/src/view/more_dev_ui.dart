import 'package:carrot/carrot.dart';
import 'package:flutter/services.dart';

import '../component/layout/layout.dart';
import '../component/routing/routing.dart';

/// [FTViewMoreDevUI] is intended for in-app UI testing during
/// development. The view is hidden when the feature flag for
/// development mode is disabled in the environment.
///
/// This view contains a lot of fake and non-optimized code
/// and should be taken with a grain of salt.
class FTViewMoreDevUI extends StatelessWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => 'UI Experiments',
    path: 'ui',
    builder: (context, state) => const FTViewMoreDevUI(),
  );

  const FTViewMoreDevUI({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.singleChildScrollView(
      padding: const EdgeInsets.all(24),
      builder: (_) => const CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        gap: 24,
        children: [
          _FormWidgets(),
        ],
      ),
    );
  }
}

class _FormWidgets extends StatelessWidget {
  const _FormWidgets();

  @override
  Widget build(BuildContext context) {
    return CarrotColumn(
      mainAxisSize: MainAxisSize.min,
      gap: 21,
      children: [
        const CarrotFormGroup(
          label: Text('Text field'),
          error: Text('Error ipsum dolor sit amet, consectetur adipiscing elit. Etiam nec mi in tortor tristique ornare. Suspendisse non magna id erat ultrices aliquam non quis nulla.'),
          hint: Text('Hint ipsum dolor sit amet, consectetur adipiscing elit. Etiam nec mi in tortor tristique ornare. Suspendisse non magna id erat ultrices aliquam non quis nulla.'),
          child: CarrotTextField(
            placeholder: 'Placeholder',
            textCapitalization: TextCapitalization.words,
          ),
        ),
        CarrotFormGroup(
          label: const Text('Date field'),
          child: CarrotDateField(
            // maxDate: DateTime(2022, 12, 25),
            minDate: DateTime(1950, 1, 1),
            placeholder: 'Placeholder',
            controller: CarrotValueController(
              value: null,
              onChanged: (value) => debugPrint('New date value $value'),
            ),
          ),
        ),
        const CarrotFormGroup(
          label: Text('Optional text field'),
          optional: true,
          child: CarrotTextField(
            placeholder: 'Placeholder',
          ),
        ),
        CarrotFormGroup(
          label: const Text('Select field'),
          child: CarrotSelectField<String>(
            controller: CarrotValueController(
              value: null,
              onChanged: (value) => debugPrint('New value $value'),
            ),
            options: const [
              CarrotSelectFieldOption(value: 'A'),
              CarrotSelectFieldOption(value: 'B'),
              CarrotSelectFieldOption(value: 'C'),
              CarrotSelectFieldOption(value: 'D'),
              CarrotSelectFieldOption(value: 'E'),
            ],
            placeholder: 'Placeholder',
          ),
        ),
        CarrotFormGroup(
          label: const Text('Button'),
          child: CarrotRow(
            gap: 9,
            children: [
              CarrotContainedButton.text(
                text: const Text('Button'),
                onTap: () {},
              ),
              CarrotTextButton.text(
                text: const Text('Button'),
                onTap: () {},
              ),
              CarrotLinkButton.text(
                text: const Text('Button'),
                onTap: () {},
              ),
            ],
          ),
        ),
        CarrotFormGroup(
          label: const Text('Toggle'),
          child: CarrotRow(
            gap: 9,
            children: [
              CarrotSwitch(
                value: false,
                onChanged: (value) {},
              ),
              CarrotSwitch(
                value: true,
                onChanged: (value) {},
              ),
            ],
          ),
        ),
      ],
    );
  }
}
