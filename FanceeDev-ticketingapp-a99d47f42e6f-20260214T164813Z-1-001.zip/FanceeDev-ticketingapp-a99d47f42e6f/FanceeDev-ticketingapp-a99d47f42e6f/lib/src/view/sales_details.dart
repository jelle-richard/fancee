import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../routes.dart';
import '../util/util.dart';

class FTViewSalesDetails extends StatefulWidget {
  static final route = FTRoute(
    arguments: const FTShellSettings(
      hideBottomBar: true,
    ),
    nameGenerator: (context, state) => state.queryParameters['shopName'],
    path: ':eventId/:shopCode/details',
    builder: (context, _) => const FTViewSalesDetails(),
  );

  const FTViewSalesDetails({
    super.key,
  });

  @override
  createState() => _FTViewSalesDetailsState();
}

class _FTViewSalesDetailsState extends State<FTViewSalesDetails> {
  late final FTSalesStateBloc _salesBloc;

  bool _isFirstRender = true;
  bool _isLoading = false;

  FTShopModel get shopModel => assertedCast(_salesBloc.state.shop);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _salesBloc = context.read<FTSalesStateBloc>();
      _isFirstRender = false;
    }
  }

  void _onNextTap() async {
    assert(_salesBloc.state.reservationReference != null);

    setState(() {
      _isLoading = true;
    });

    // todo(Bas): form validation

    setState(() {
      _isLoading = false;
    });

    context.carrotRouter.push(FTRoutes.salesSummary(
      shopModel.event.id,
      shopModel.code,
      shopModel.name,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return FTLayoutSales(
      isLoading: _isLoading,
      footer: _FTSalesDetailsFooter(
        shopModel: shopModel,
        onNextTap: _onNextTap,
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: _FTSalesFieldsBuilder(
          shopModel: shopModel,
        ),
      ),
    );
  }
}

class _FTSalesDetailsFooter extends StatelessWidget {
  final FTShopModel shopModel;
  final GestureTapCallback onNextTap;

  const _FTSalesDetailsFooter({
    required this.shopModel,
    required this.onNextTap,
  });

  @override
  Widget build(BuildContext context) {
    final locale = Localizations.localeOf(context);
    final salesBloc = context.watch<FTSalesStateBloc>();

    return FTSalesBottomBar(
      children: [
        Expanded(
          child: FTSalesBottomBarPrice(
            label: context.strings.salesShopBottomBarTotal,
            price: shopModel.event.currency.format(locale, salesBloc.state.productTotalPriceCents),
          ),
        ),
        FTSalesBottomBarButton(
          iconAfter: 'circle-arrow-right',
          label: context.strings.salesShopBottomBarNext,
          onTap: onNextTap,
        ),
      ],
    );
  }
}

class _FTSalesFieldsBuilder extends StatelessWidget {
  final FTShopModel shopModel;

  const _FTSalesFieldsBuilder({
    required this.shopModel,
  });

  Widget _buildField(BuildContext context, int index) {
    final field = shopModel.fields[index];
    final salesBloc = context.read<FTSalesStateBloc>();
    final shopForm = salesBloc.state.shopForm;

    switch (field.field) {
      case FTShopFieldType.email:
        return FTShopFieldEmail(
          field: field,
          index: index,
          shop: shopModel,
          value: shopForm.email,
          onChanged: (email) => salesBloc.add(FTSalesStateFormSetEmail(email)),
        );

      case FTShopFieldType.firstName:
        return FTShopFieldFirstName(
          field: field,
          index: index,
          shop: shopModel,
          value: shopForm.firstName ?? '',
          onChanged: (firstName) => salesBloc.add(FTSalesStateFormSetFirstName(firstName)),
        );

      case FTShopFieldType.lastName:
        return FTShopFieldLastName(
          field: field,
          index: index,
          shop: shopModel,
          value: shopForm.lastName ?? '',
          onChanged: (lastName) => salesBloc.add(FTSalesStateFormSetLastName(lastName)),
        );

      case FTShopFieldType.birthDate:
        return FTShopFieldBirthDate(
          field: field,
          index: index,
          shop: shopModel,
          value: shopForm.birthDate,
          onChanged: (birthDate) => salesBloc.add(FTSalesStateFormSetBirthDate(birthDate)),
        );

      case FTShopFieldType.phoneNumber:
        return FTShopFieldPhoneNumber(
          field: field,
          index: index,
          shop: shopModel,
          value: shopForm.phoneNumber ?? '',
          onChanged: (phoneNumber) => salesBloc.add(FTSalesStateFormSetPhoneNumber(phoneNumber)),
        );

      case FTShopFieldType.gender:
        return FTShopFieldGender(
          field: field,
          index: index,
          shop: shopModel,
          value: shopForm.gender ?? FTGender.notSpecified,
          onChanged: (gender) => salesBloc.add(FTSalesStateFormSetGender(gender)),
        );

      default:
        return CarrotNotice(
          color: context.carrotTheme.defaults.warning,
          icon: const FTIcon(
            glyph: 'circle-exclamation',
          ),
          title: Text(context.strings.salesShopFieldUnsupportedTitle),
          message: Text(context.strings.salesShopFieldUnsupportedMessage(field.field.toString())),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      itemBuilder: _buildField,
      itemCount: shopModel.fields.length,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      separatorBuilder: (context, index) => const SizedBox(height: 24),
      shrinkWrap: true,
    );
  }
}
