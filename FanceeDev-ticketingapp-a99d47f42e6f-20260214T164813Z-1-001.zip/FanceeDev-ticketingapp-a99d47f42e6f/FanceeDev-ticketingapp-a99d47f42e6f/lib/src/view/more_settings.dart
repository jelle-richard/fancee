import 'package:carrot/carrot.dart';

import '../../l10n/l10n.dart';
import '../component/layout/layout.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';

class FTViewMoreSettings extends StatelessWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.settingsTitle,
    path: 'settings',
    builder: (context, state) => FTSettingsProvider(
      bloc: context.read<FTUserStateBloc>(),
      child: const FTViewMoreSettings(),
    ),
  );

  const FTViewMoreSettings({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final inheritedSettings = context.dependOnInheritedWidgetOfExactType<FTSettingsProvider>();

    if (inheritedSettings == null) {
      throw FlutterError.fromParts(<DiagnosticsNode>[
        ErrorSummary('Settings tried to build with a context that does not contain a FTSettingsProvider.'),
      ]);
    }

    return FTLayoutSheet.listView(
      itemBuilder: (context, index) => inheritedSettings.settings[index].build(context),
      itemCount: inheritedSettings.settings.length,
    );
  }
}
