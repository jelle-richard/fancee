import 'package:carrot/carrot.dart';
import 'package:flutter/material.dart' show RefreshIndicator;
import 'package:intl/intl.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';
import '../routes.dart';
import 'statistics_event.dart';

class FTViewStatistics extends StatefulWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.statistics,
    path: '/statistics',
    builder: (context, state) => const FTViewStatistics(),
    routes: [
      FTViewStatisticsEvent.route,
    ],
  );

  const FTViewStatistics({
    super.key,
  });

  @override
  createState() => _FTViewStatisticsState();
}

class _FTViewStatisticsState extends State<FTViewStatistics> {
  late final FTEventService _eventService;

  List<FTEventListingModel> _events = [];
  bool _isFirstRender = true;
  bool _isLoading = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_isFirstRender) {
      _eventService = FTEventService(context: context);
      _isFirstRender = false;
    }
  }

  @override
  void initState() {
    super.initState();
    onMounted(_loadEvents);
  }

  Future<void> _loadEvents() async {
    setState(() {
      _isLoading = true;
    });

    final response = await _eventService.withUserType(
      organizer: (service) async => await service.getList(
        maximumStartDate: DateTime.now().add(const Duration(days: 7)),
        minimumStartDate: DateTime.now().subtract(const Duration(days: 365)),
      ),
      appTeam: (service) async => await service.getListAppTeam(
        maximumStartDate: DateTime.now().add(const Duration(days: 7)),
        minimumStartDate: DateTime.now().subtract(const Duration(days: 365)),
      ),
    );

    setState(() {
      _events = response.data?.items ?? [];
      _events.sort((a, b) => b.date.compareTo(a.date));
      _isLoading = false;
    });
  }

  Widget _buildEvent(BuildContext context, int index) {
    final carrotTheme = context.carrotTheme;
    final event = _events[index];

    if (event.shops.isEmpty) {
      return Container();
    }

    final primaryShop = event.shops.first;

    Widget image;

    if (primaryShop.headerMedia.isNotEmpty) {
      image = Image.network(
        cacheHeight: 210,
        primaryShop.headerMedia.first.url,
        fit: BoxFit.cover,
        errorBuilder: (context, _, __) => FTGridBackground(
          backgroundColor: carrotTheme.defaults.background,
          lineColor: carrotTheme.defaults.background.lighten(.025),
          size: 45,
          child: nothing,
        ),
      );
    } else {
      image = FTGridBackground(
        backgroundColor: carrotTheme.defaults.background,
        lineColor: carrotTheme.defaults.background.lighten(.025),
        size: 45,
        child: nothing,
      );
    }

    return FTImageCard(
      aspectRatio: 24 / 9,
      image: image,
      title: Text(event.name),
      subTitle: Text(DateFormat.yMMMd().add_Hm().format(event.date)),
      onTap: () => context.carrotRouter.push(FTRoutes.statisticsEvent(
        event.id,
        event.name,
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: context.carrotTheme.primary,
      strokeWidth: 3,
      edgeOffset: context.carrotScaffold.appBarSize.height,
      onRefresh: _loadEvents,
      child: FTEmptyViewSwitcher(
        emptyView: FTLayoutEmptyView.illustration(
          explanation: context.strings.statisticsEmptyViewDescription,
          illustration: 'statistics',
          title: context.strings.statisticsEmptyViewTitle,
        ),
        isEmptyViewVisible: !_isLoading && _events.isEmpty,
        child: FTResponsiveBuilder(
          large: (context) => FTLayoutSheet.gridView(
            key: ValueKey(_events.length),
            aspectRadio: 3 / 2,
            columns: 2,
            isLoading: _isLoading,
            itemBuilder: _buildEvent,
            itemCount: _events.length,
            padding: const EdgeInsets.all(24),
            spacing: 24,
          ),
          small: (context) => FTLayoutSheet.listView(
            key: ValueKey(_events.length),
            isLoading: _isLoading,
            itemBuilder: _buildEvent,
            itemCount: _events.length,
            padding: const EdgeInsets.all(24),
            separatorBuilder: (context, index) => const SizedBox(height: 15),
          ),
        ),
      ),
    );
  }
}
