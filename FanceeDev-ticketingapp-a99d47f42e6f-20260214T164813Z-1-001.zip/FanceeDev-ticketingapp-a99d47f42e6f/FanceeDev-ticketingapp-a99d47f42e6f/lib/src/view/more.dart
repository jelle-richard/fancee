import 'package:carrot/carrot.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../l10n/l10n.dart';
import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';
import '../routes.dart';
import '../util/util.dart';
import 'more_dev.dart';
import 'more_pin_terminals.dart';
import 'more_printers.dart';
import 'more_settings.dart';

class FTViewMore extends StatelessWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => context.strings.more,
    path: '/more',
    builder: (context, state) => const FTViewMore(),
    routes: [
      FTViewMoreDev.route,
      FTViewMorePinTerminals.route,
      FTViewMorePrinters.route,
      FTViewMoreSettings.route,
    ],
  );

  const FTViewMore({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.singleChildScrollView(
      headerBuilder: (_) => BlocBuilder<FTAuthStateBloc, FTAuthState>(
        builder: (context, state) => CarrotPreviousStableState<FTBaseUserModel>(
          state: state.user,
          builder: (context, user) => FTLoadingSubtleOverlay(
            backgroundColor: context.carrotTheme.defaults.background,
            spinnerBackgroundColor: context.carrotTheme.defaults.background.darken(.025),
            spinnerPrimaryColor: context.carrotTheme.primary[0],
            spinnerSecondaryColor: context.carrotTheme.primary[400],
            isLoading: user == null,
            child: _FTMoreUserInfo(
              user: user ?? _FakeUser(),
            ),
          ),
        ),
      ),
      builder: (_) => const _FTMoreMenu(),
    );
  }
}

class _FTMoreMenu extends StatelessWidget {
  const _FTMoreMenu();

  @override
  Widget build(BuildContext context) {
    return CarrotMenu(
      gap: 21,
      children: [
        const CarrotSpacer.vertical(size: 9),
        FTMenuGroup(
          children: [
            FTMenuItem(
              icon: 'print',
              iconAfter: 'circle-arrow-right',
              label: Text(context.strings.morePrinters),
              onTap: () => context.carrotRouter.push(FTRoutes.morePrinters()),
            ),
            FTMenuItem(
              icon: 'credit-card-front',
              iconAfter: 'circle-arrow-right',
              label: Text(context.strings.morePinTerminals),
              onTap: () => context.carrotRouter.push(FTRoutes.morePinTerminals()),
            ),
            FTMenuItem(
              icon: 'gear',
              iconAfter: 'circle-arrow-right',
              label: Text(context.strings.moreSettings),
              onTap: () => context.carrotRouter.push(FTRoutes.moreSettings()),
            ),
          ],
        ),
        FTMenuGroup(
          children: [
            FTMenuItem(
              icon: 'book',
              iconAfter: 'circle-arrow-right',
              label: Text(context.strings.moreTerms),
              onTap: () => launchFromString('https://wearefancee.com/algemene-voorwaarden'),
            ),
            FTMenuItem(
              icon: 'shield',
              iconAfter: 'circle-arrow-right',
              label: Text(context.strings.morePrivacy),
              onTap: () => launchFromString('https://wearefancee.com/privacy'),
            ),
          ],
        ),
        FTMenuGroup(
          children: [
            BlocBuilder<FTAuthStateBloc, FTAuthState>(
              builder: (context, state) => FTMenuItem(
                icon: 'arrow-right-from-bracket',
                iconAfter: 'circle-arrow-right',
                label: Text(context.strings.moreSignOff),
                onTap: () {
                  if (state.user is _FakeUser) {
                    return;
                  }

                  context.read<FTAuthStateBloc>().add(const FTAuthStateSetBearerToken());
                  context.carrotRouter.go(FTRoutes.authLogin());
                },
              ),
            ),
          ],
        ),
        if (context.isFeatureEnabled(FTFeatureFlag.dev)) ...[
          FTMenuGroup(
            children: [
              FTMenuItem(
                icon: 'code-simple',
                iconAfter: 'circle-arrow-right',
                label: const Text('Developer'),
                onTap: () => context.carrotRouter.push(FTRoutes.moreDev()),
              ),
            ],
          ),
        ],
        const CarrotSpacer.vertical(size: 9),
        SvgPicture.asset(
          'assets/images/fancee.svg',
          width: 90,
          colorFilter: ColorFilter.mode(context.carrotTheme.primary[700], BlendMode.srcIn),
        ),
        const CarrotSpacer.vertical(size: 30),
      ],
    );
  }
}

class _FTMoreUserInfo extends StatelessWidget {
  final FTBaseUserModel user;

  const _FTMoreUserInfo({
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        top: 48,
        left: 21,
        right: 21,
        bottom: 60,
      ),
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Builder(
            builder: user.buildAvatar,
          ),
          const CarrotSpacer.vertical(size: 18),
          CarrotText.headline4(
            user.displayName,
            style: TextStyle(
              color: context.carrotTheme.primary[0],
            ),
          ),
          CarrotText.body1(
            user.displayInfo,
            style: TextStyle(
              color: context.carrotTheme.primary[300],
            ),
          ),
        ],
      ),
    );
  }
}

class _FakeUser extends FTBaseUserModel {
  @override
  String get displayName => 'Fancee User';

  @override
  String get displayInfo => 'WeAreFancee';

  _FakeUser()
      : super.organizer(
          claims: <String>{},
        );

  @override
  Widget buildAvatar(BuildContext context) {
    return const CarrotAvatar.letters('🚀');
  }
}
