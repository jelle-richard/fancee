import 'package:carrot/carrot.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../component/atom/atom.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/organism/organism.dart';
import '../component/routing/routing.dart';
import '../data/data.dart';
import '../routes.dart';
import '../util/util.dart';
import 'more_dev_ui.dart';

final _connectionStatusLabelMap = {
  ConnectivityResult.bluetooth: 'Bluetooth',
  ConnectivityResult.wifi: 'WiFi',
  ConnectivityResult.ethernet: 'Ethernet',
  ConnectivityResult.mobile: 'Mobile',
  ConnectivityResult.none: 'None',
};

/// [FTViewMoreDev] is intended for providing information during
/// development. The view is hidden when the feature flag for
/// development mode is disabled in the environment.
///
/// This view contains a lot of fake and non-optimized code
/// and should be taken with a grain of salt.
class FTViewMoreDev extends StatelessWidget {
  static final route = FTRoute(
    nameGenerator: (context, _) => 'Developer',
    path: 'dev',
    builder: (context, state) => const FTViewMoreDev(),
    routes: [
      FTViewMoreDevUI.route,
    ],
  );

  const FTViewMoreDev({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.singleChildScrollView(
      builder: (_) => CarrotColumn(
        key: GlobalKey(),
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: const [
          _Info(),
          _Divider(label: 'Tools'),
          CarrotSpacer.vertical(size: 15),
          _Tools(),
          CarrotSpacer.vertical(size: 15),
        ],
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  final String label;

  const _Divider({
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return FTLabelledDivider(
      label: Text(label),
      margin: const EdgeInsets.symmetric(
        horizontal: 30,
      ),
    );
  }
}

class _Info extends StatefulWidget {
  const _Info();

  @override
  createState() => _InfoState();
}

class _InfoState extends State<_Info> {
  String _connectionStatus = '-';
  String _localIp = '-';
  PackageInfo? _packageInfo;

  @override
  void initState() {
    super.initState();

    Future.microtask(() async {
      _connectionStatus = _connectionStatusLabelMap[await getConnectivityState()] ?? 'Unknown';
      _localIp = await getLocalIPv4Address() ?? '-';
      _packageInfo = await PackageInfo.fromPlatform();

      if (!mounted) {
        return;
      }

      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        gap: 3,
        children: [
          FTPaddedDecoratedBox.devNameValue('Bundle', _packageInfo?.packageName ?? '-'),
          FTPaddedDecoratedBox.devNameValue('App', '${_packageInfo?.appName} ${_packageInfo?.version}.${_packageInfo?.buildNumber}'),
          FTPaddedDecoratedBox.devNameValue('Environment', FTEnvironment.of(context).name),
          FTPaddedDecoratedBox.devNameValue('Internal Database Version', FTDatabase.of(context).version.toString()),
          FTPaddedDecoratedBox.devNameValue('Installer Store', _packageInfo?.installerStore ?? '-'),
          FTPaddedDecoratedBox.devNameValue('Network', '$_localIp ($_connectionStatus)'),
        ],
      ),
    );
  }
}

class _Tools extends StatefulWidget {
  const _Tools();

  @override
  createState() => _ToolsState();
}

class _ToolsState extends State<_Tools> {
  void _onSwitchEnvironmentTap() async {
    await context.carrotRouter.overlayEntry(
      dismissible: true,
      builder: (bag) => FTEnvironmentSwitcherDialog(close: bag.close),
    );
  }

  void _onFeatureDetailsTap() {
    context.carrotRouter.overlayEntry(
      builder: (bag) => CarrotAlertDialog(
        close: bag.close,
        title: const FTDialogHeader.notPadded(
          title: Text('Feature Details'),
          body: Text('These are the features that are enabled in the current environment.'),
        ),
        content: BlocBuilder<FTAuthStateBloc, FTAuthState>(
          builder: (context, state) => FTJsonViewer(
            json: {
              'enabled': FTEnvironment.of(context).featureFlags,
              'available': const FTFeatureFlags.all(),
            },
          ),
        ),
      ),
    );
  }

  void _onUserDetailsTap() {
    context.carrotRouter.overlayEntry(
      builder: (bag) => CarrotAlertDialog(
        close: bag.close,
        title: const FTDialogHeader.notPadded(
          title: Text('User Details'),
          body: Text('Information about the current session.'),
        ),
        content: BlocBuilder<FTAuthStateBloc, FTAuthState>(
          builder: (context, state) => FTJsonViewer(
            json: {
              'name': state.user?.displayName,
              'type': state.user?.userType.name,
              'auth': {
                'bearer': state.bearerToken,
                'validUntil': state.validUntil?.toString(),
              },
              'claims': state.user?.claims.toList(),
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return CarrotMenu(
      gap: 21,
      children: [
        FTMenuGroup(
          children: [
            FTMenuItem(
              icon: 'heart',
              label: const Text('UI Experiments'),
              onTap: () => context.carrotRouter.push(
                FTRoutes.moreDevUI(),
              ),
            ),
            FTMenuItem(
              icon: 'server',
              label: const Text('HTTP Requests'),
              onTap: () => context.carrotRouter.push(
                FTRoutes.moreDevUI(),
              ),
            ),
          ],
        ),
        FTMenuGroup(
          children: [
            FTMenuItem(
              icon: 'star',
              label: const Text('Feature Details'),
              onTap: _onFeatureDetailsTap,
            ),
            FTMenuItem(
              icon: 'user',
              label: const Text('User Details'),
              onTap: _onUserDetailsTap,
            ),
          ],
        ),
        FTMenuGroup(
          children: [
            FTMenuItem(
              icon: 'arrow-right-arrow-left',
              label: const Text('Switch Environment'),
              onTap: _onSwitchEnvironmentTap,
            ),
          ],
        ),
      ],
    );
  }
}
