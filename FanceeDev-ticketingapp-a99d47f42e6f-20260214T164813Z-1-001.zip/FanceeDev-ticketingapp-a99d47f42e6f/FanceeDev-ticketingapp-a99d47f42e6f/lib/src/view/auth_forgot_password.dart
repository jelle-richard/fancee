import 'package:carrot/carrot.dart';
import 'package:flutter/services.dart';

import '../../l10n/l10n.dart';
import '../component/layout/layout.dart';
import '../component/molecule/molecule.dart';
import '../component/routing/routing.dart';
import '../component/shell/shell.dart';
import '../data/data.dart';
import '../routes.dart';

class FTViewAuthForgotPassword extends StatefulWidget {
  static final route = FTRoute.auth(
    arguments: const FTShellSettings(
      systemUiStyle: FTSystemUiStyle.auto,
    ),
    path: '/forgot-password',
    builder: (_, __) => const FTViewAuthForgotPassword(),
  );

  const FTViewAuthForgotPassword({
    super.key,
  });

  @override
  createState() => _FTViewAuthForgotPasswordState();
}

class _FTViewAuthForgotPasswordState extends State<FTViewAuthForgotPassword> {
  final TextEditingController _emailController = TextEditingController();

  late FTUserService _userService;
  bool _isLoading = false;
  String? _requestError;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final environment = FTEnvironment.of(context);

    if (_emailController.text.isEmpty) {
      _emailController.text = environment.prefillLoginEmail ?? '';
    }
  }

  @override
  void initState() {
    super.initState();

    onMounted(() {
      _userService = FTUserService(context: context);
    });
  }

  void _onCancelTap() {
    context.carrotRouter.pop();
  }

  void _onRequestPasswordTap() async {
    if (_emailController.text.trim().isEmpty) {
      return;
    }

    final router = context.carrotRouter;

    setState(() {
      _isLoading = true;
      _requestError = null;
    });

    final response = await _userService.requestPasswordReset(
      email: _emailController.text,
    );

    if (response.isOk) {
      setState(() {
        _isLoading = false;
      });

      await router.overlay<void>(
        dismissible: true,
        builder: (close) => CarrotAlertDialog(
          close: close,
          okLabel: context.strings.ok,
          content: Text(context.strings.authRequestPasswordOkMessage),
          title: Text(context.strings.authRequestPasswordOkTitle),
        ),
      );

      router.go(FTRoutes.authLogin());
    } else {
      setState(() {
        _isLoading = false;
        _requestError = response.errors.first;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return FTLoadingSubtleOverlay(
      isLoading: _isLoading,
      child: FTLayoutAuth(
        children: [
          if (_requestError != null)
            CarrotNotice(
              color: context.carrotTheme.defaults.error,
              message: Text(_requestError!),
              title: Text(context.strings.authSignInError),
            ),
          CarrotTextField(
            autofillHints: const [
              AutofillHints.username,
              AutofillHints.email,
            ],
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            maxLines: 1,
            placeholder: context.strings.authEmail,
            prefix: const FTLayoutAuthTextFieldIcon.prefix(icon: 'at'),
            textInputAction: TextInputAction.go,
          ),
          ValueListenableBuilder(
            valueListenable: _emailController,
            builder: (context, value, _) => FTLayoutAuthProceedButton(
              disabled: value.text.trim().isEmpty || !value.text.contains('.') || !value.text.contains('@') || value.text.endsWith('.'),
              text: context.strings.authRequestPassword,
              onTap: _onRequestPasswordTap,
            ),
          ),
          CarrotTextButton.text(
            text: Text(context.strings.goBack),
            onTap: _onCancelTap,
          ),
        ],
      ),
    );
  }
}
