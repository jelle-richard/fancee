import 'package:carrot/carrot.dart';
import 'package:syncfusion_localizations/syncfusion_localizations.dart';

import '../l10n/l10n.dart';
import 'config.dart';
import 'data/data.dart';
import 'router.dart';
import 'theme.dart';

class FTApp extends StatelessWidget {
  const FTApp({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return FTDataProvider(
      child: BlocBuilder<FTUserStateBloc, FTUserState>(
        builder: (context, state) => CarrotApp(
          settings: const CarrotAppSettings(
            color: FTThemeColors.primary,
            title: FTConfig.title,
          ),
          theme: FTThemeUtil.find(context, state.appearanceTheme, FTTheme.light),
          themeDark: FTThemeUtil.find(context, state.appearanceTheme, FTTheme.dark),
          localizationsDelegates: const [
            ...AppLocalizations.localizationsDelegates,
            CarrotLocalizations.delegate,
            SfGlobalLocalizations.delegate,
          ],
          supportedLocales: AppLocalizations.supportedLocales,
          child: const FTAppRouter(),
        ),
      ),
    );
  }
}
