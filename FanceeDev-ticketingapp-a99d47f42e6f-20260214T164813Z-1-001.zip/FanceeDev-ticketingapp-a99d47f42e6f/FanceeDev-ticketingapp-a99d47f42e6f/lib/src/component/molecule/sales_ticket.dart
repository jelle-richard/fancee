import 'package:carrot/carrot.dart';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../../l10n/extension.dart';
import '../atom/atom.dart';

class FTSalesTicket extends StatelessWidget {
  final String? sideText;
  final String eventName;
  final DateTime eventStartDate;
  final bool isLoading;
  final String productName;
  final String? qrData;

  const FTSalesTicket({
    super.key,
    required this.eventName,
    required this.eventStartDate,
    required this.productName,
    this.isLoading = false,
    this.sideText,
    this.qrData,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return CarrotCard(
      borderColor: carrotTheme.primary,
      borderWidth: 1.0,
      shadow: CarrotShadows.none,
      child: IntrinsicHeight(
        child: CarrotRow(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _FTSalesTicketSide(
              text: sideText ?? context.strings.salesTicketSide,
            ),
            Expanded(
              child: Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 15,
                  ),
                  child: CarrotColumn(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    gap: 3,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        eventName,
                        style: carrotTheme.typography.headline3.copyWith(
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        DateFormat.yMMMMd().add_Hm().format(eventStartDate),
                        style: carrotTheme.typography.body2.copyWith(
                          color: carrotTheme.gray[900].withOpacity(.5),
                          fontSize: 15,
                        ),
                      ),
                      const CarrotSpacer.vertical(size: 0),
                      Text(
                        productName,
                        style: carrotTheme.typography.body2.copyWith(
                          color: carrotTheme.gray[900].withOpacity(.5),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (isLoading)
              const Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 18,
                ),
                child: FTSpinner(
                  size: 18,
                  thickness: 3,
                ),
              ),
            if (!isLoading && qrData != null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: SizedBox.square(
                    dimension: 78,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(9),
                        color: CarrotColors.white,
                      ),
                      child: QrImage(
                        data: qrData!,
                        size: 78,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _FTSalesTicketSide extends StatelessWidget {
  final String text;

  const _FTSalesTicketSide({
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        color: carrotTheme.primary,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 18,
        ),
        child: RotatedBox(
          quarterTurns: 3,
          child: Text(
            text,
            style: TextStyle(
              inherit: true,
              color: carrotTheme.primary[0],
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 3,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
