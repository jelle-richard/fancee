import 'package:carrot/carrot.dart';

class FTDialogHeader extends StatelessWidget {
  final Widget title;
  final Widget? body;
  final EdgeInsets padding;

  const FTDialogHeader({
    super.key,
    required this.title,
    this.body,
  }) : padding = const EdgeInsets.only(
          top: 27,
          left: 27,
          right: 27,
          bottom: 15,
        );

  const FTDialogHeader.notPadded({
    super.key,
    required this.title,
    this.body,
  }) : padding = EdgeInsets.zero;

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        color: carrotTheme.defaults.content,
      ),
      child: Padding(
        padding: padding,
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          gap: 6,
          children: [
            DefaultTextStyle(
              style: carrotTheme.typography.headline5,
              child: title,
            ),
            if (body != null) DefaultTextStyle(
              style: carrotTheme.typography.body2,
              child: body!,
            ),
          ],
        ),
      ),
    );
  }
}
