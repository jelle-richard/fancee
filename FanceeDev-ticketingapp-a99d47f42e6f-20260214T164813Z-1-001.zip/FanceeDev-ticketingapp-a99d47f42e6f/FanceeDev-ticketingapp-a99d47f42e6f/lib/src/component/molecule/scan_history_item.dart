import 'package:carrot/carrot.dart';
import 'package:intl/intl.dart';

import '../../data/data.dart';
import '../atom/atom.dart';

class FTScanHistoryItem extends StatelessWidget {
  final FTScanHistoryEntry entry;

  const FTScanHistoryItem({
    super.key,
    required this.entry,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    late CarrotColor color;

    switch (entry.result) {
      case FTScanResultType.failed:
        color = context.carrotTheme.defaults.error;
        break;

      case FTScanResultType.invalid:
        color = context.carrotTheme.defaults.error;
        break;

      case FTScanResultType.ok:
        color = context.carrotTheme.defaults.success;
        break;

      case FTScanResultType.reused:
        color = context.carrotTheme.defaults.warning;
        break;
    }

    return _FTScanHistoryItemCard(
      color: color,
      icon: entry.mode == FTScanState.scanned ? 'right-to-bracket' : 'right-from-bracket',
      children: [
        Text(
          entry.barcode,
          style: carrotTheme.typography.headline3.copyWith(
            fontSize: 14,
          ),
        ),
        Text(
          DateFormat.yMMMMd().add_Hm().format(entry.scannedOn),
          style: carrotTheme.typography.body2.copyWith(
            color: carrotTheme.gray[900].withOpacity(.5),
            fontSize: 13,
          ),
        ),
        if (entry.message != null)
          Text(
            entry.message!,
            style: carrotTheme.typography.body2.copyWith(
              color: carrotTheme.gray[900],
              fontSize: 15,
            ),
          ),
      ],
    );
  }
}

class _FTScanHistoryItemCard extends StatelessWidget {
  final List<Widget> children;
  final CarrotColor color;
  final String icon;

  const _FTScanHistoryItemCard({
    required this.children,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return CarrotCard(
      borderColor: color,
      borderWidth: 1.0,
      shadow: CarrotShadows.none,
      child: IntrinsicHeight(
        child: CarrotRow(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                color: color,
              ),
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Align(
                  alignment: Alignment.topCenter,
                  child: FTIcon(
                    glyph: icon,
                    color: CarrotColors.white,
                    size: 20,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 15,
                  ),
                  child: CarrotColumn(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    gap: 3,
                    mainAxisSize: MainAxisSize.min,
                    children: children,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
