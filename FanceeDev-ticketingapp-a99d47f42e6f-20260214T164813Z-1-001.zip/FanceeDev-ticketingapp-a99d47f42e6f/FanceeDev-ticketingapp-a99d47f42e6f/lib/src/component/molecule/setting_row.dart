import 'package:carrot/carrot.dart';

class FTSettingRow extends StatelessWidget {
  final Widget child;

  const FTSettingRow({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: context.carrotTheme.gray[100],
            width: 1,
          ),
        ),
      ),
      child: child,
    );
  }
}
