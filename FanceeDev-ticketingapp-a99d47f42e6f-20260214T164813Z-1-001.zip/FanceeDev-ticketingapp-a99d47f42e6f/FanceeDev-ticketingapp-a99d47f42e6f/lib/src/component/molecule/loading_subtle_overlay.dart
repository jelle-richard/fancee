import 'package:carrot/carrot.dart';

import '../atom/atom.dart';

class FTLoadingSubtleOverlay extends StatelessWidget {
  final Widget child;
  final Color? backgroundColor;
  final double backgroundOpacity;
  final Color? spinnerBackgroundColor;
  final Color? spinnerPrimaryColor;
  final Color? spinnerSecondaryColor;
  final bool isLoading;

  const FTLoadingSubtleOverlay({
    super.key,
    required this.child,
    required this.isLoading,
    this.backgroundColor,
    this.backgroundOpacity = .95,
    this.spinnerBackgroundColor,
    this.spinnerPrimaryColor,
    this.spinnerSecondaryColor,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) => Stack(
        children: [
          ConstrainedBox(
            constraints: constraints,
            child: child,
          ),
          Positioned.fill(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 360),
              switchInCurve: CarrotCurves.swiftOutCurve,
              switchOutCurve: CarrotCurves.swiftOutCurve,
              child: isLoading
                  ? Container(
                      color: (backgroundColor ?? context.carrotTheme.defaults.content).withOpacity(backgroundOpacity),
                      child: FTSpinner(
                        background: spinnerBackgroundColor,
                        color: spinnerPrimaryColor,
                        colorSecondary: spinnerSecondaryColor,
                        size: 24,
                        thickness: 4,
                      ),
                    )
                  : null,
            ),
          ),
        ],
      ),
    );
  }
}
