import 'package:carrot/carrot.dart';

import 'setting_row.dart';

class FTSettingCaptioned extends StatelessWidget {
  final Widget child;
  final WidgetBuilder title;
  final WidgetBuilder description;

  const FTSettingCaptioned({
    super.key,
    required this.child,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return FTSettingRow(
      child: CarrotRow(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 30,
                vertical: 18,
              ),
              child: CarrotColumn(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                gap: 6,
                children: [
                  DefaultTextStyle(
                    style: context.carrotTypography.headline5.copyWith(
                      color: context.carrotTheme.gray[700],
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    child: title(context),
                  ),
                  DefaultTextStyle(
                    style: context.carrotTypography.body2.copyWith(
                      fontSize: 14,
                    ),
                    child: description(context),
                  ),
                ],
              ),
            ),
          ),
          child,
          const SizedBox.square(
            dimension: 18,
          ),
        ],
      ),
    );
  }
}
