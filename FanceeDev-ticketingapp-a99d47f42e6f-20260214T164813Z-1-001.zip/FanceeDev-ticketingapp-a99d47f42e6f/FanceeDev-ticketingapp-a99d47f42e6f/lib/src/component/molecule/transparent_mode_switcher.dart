import 'package:carrot/carrot.dart';
import 'package:flutter/services.dart';

const _kDuration = Duration(milliseconds: 300);

typedef FTTransparentModeSwitcherChange = void Function(int);

class FTTransparentModeSwitcher extends StatefulWidget {
  final Color? backgroundColor;
  final List<Widget> children;
  final int initialIndex;
  final FTTransparentModeSwitcherChange onChange;

  const FTTransparentModeSwitcher({
    super.key,
    required this.children,
    required this.onChange,
    this.backgroundColor,
    this.initialIndex = 0,
  });

  @override
  createState() => _FTTransparentModeSwitcherState();
}

class _FTTransparentModeSwitcherState extends State<FTTransparentModeSwitcher> with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  final Map<int, double> _widths = {};

  late AnimationController _animationController;
  late Animation<double> _animationOffsetCurved;
  late Tween<double> _animationOffsetTween;
  late Animation<double> _animationWidthCurved;
  late Tween<double> _animationWidthTween;

  double get _pillOffset {
    int i = _currentIndex;
    double offset = 0;

    while (i-- > 0) {
      offset += _widths[i] ?? 0;
    }

    return offset;
  }

  double get _pillWidth => _widths[_currentIndex] ?? 0;

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    _currentIndex = widget.initialIndex;

    _animationController = AnimationController(
      duration: _kDuration,
      vsync: this,
    );

    _animationOffsetTween = Tween<double>(begin: -1, end: _pillOffset);
    _animationWidthTween = Tween<double>(begin: -1, end: _pillWidth);

    _animationOffsetCurved = _animationOffsetTween.animate(_animationController.curved(
      CarrotCurves.swiftOutCurve,
    ));

    _animationWidthCurved = _animationWidthTween.animate(_animationController.curved(
      CarrotCurves.swiftOutCurve,
    ));
  }

  void _activate(int index) {
    setState(() {
      _currentIndex = index;
      _animationOffsetTween.begin = _animationOffsetCurved.value;
      _animationWidthTween.begin = _animationWidthCurved.value;
      _animationController.reset();
      _animationOffsetTween.end = _pillOffset;
      _animationWidthTween.end = _pillWidth;
      _animationController.forward();
    });

    widget.onChange(index);
    HapticFeedback.selectionClick();
  }

  void _activateWithoutAnimation(int index) {
    setState(() {
      _currentIndex = index;
      _animationOffsetTween.begin = _animationOffsetTween.end = _pillOffset;
      _animationWidthTween.begin = _animationWidthTween.end = _pillWidth;
      _animationController.forward();
    });

    widget.onChange(index);
  }

  void _onPanUpdate(DragUpdateDetails details) {
    int index = _currentIndex;
    double offset = details.localPosition.dx;

    for (int i = 0; i < widget.children.length; i++) {
      final width = _widths[i] ?? 0;

      if (offset < width) {
        index = i;
        break;
      }

      offset -= width;
    }

    if (index != _currentIndex) {
      _activate(index);
    }
  }

  void _setWidth(int index, double width) {
    final hadAllWidths = _widths.length == widget.children.length;

    setState(() {
      _widths[index] = width;
    });

    if (!hadAllWidths && index == _currentIndex) {
      _activateWithoutAnimation(_currentIndex);
    }
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: Align(
        alignment: Alignment.center,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(90),
            color: widget.backgroundColor ?? CarrotColors.black.withOpacity(.7),
          ),
          padding: const EdgeInsets.all(3),
          child: GestureDetector(
            onPanUpdate: _onPanUpdate,
            child: Stack(
              clipBehavior: Clip.none,
              fit: StackFit.loose,
              children: [
                Positioned.fill(
                  child: AnimatedBuilder(
                    animation: _animationOffsetCurved,
                    builder: (context, _) => _Pill(
                      offset: _animationOffsetCurved.value,
                      width: _animationWidthCurved.value,
                    ),
                  ),
                ),
                CarrotRow(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (int index = 0; index < widget.children.length; ++index)
                      _Item(
                        isActive: _currentIndex == index,
                        child: widget.children[index],
                        onSizeChange: (size) => _setWidth(index, size.width),
                        onTap: () => _activate(index),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Item extends StatelessWidget {
  final Widget child;
  final bool isActive;
  final CarrotSizeMeasureChildChange onSizeChange;
  final GestureTapCallback onTap;

  const _Item({
    required this.child,
    required this.isActive,
    required this.onSizeChange,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: CarrotSizeMeasureChild(
        onChange: onSizeChange,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 9,
          ),
          child: AnimatedDefaultTextStyle(
            curve: CarrotCurves.swiftOutCurve,
            duration: _kDuration,
            style: context.carrotTypography.headline6.copyWith(
              color: isActive ? (context.carrotTheme.isDark ? CarrotColors.white : CarrotColors.black) : CarrotColors.white,
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final double offset;
  final double width;

  const _Pill({
    required this.offset,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _PillPainter(
        color: context.carrotTheme.gray[25],
        offset: offset,
        width: width,
      ),
    );
  }
}

class _PillPainter extends CustomPainter {
  final Color color;
  final double offset;
  final double width;
  final Paint _pillPaint;

  _PillPainter({
    required this.color,
    required this.offset,
    required this.width,
  }) : _pillPaint = Paint()
          ..color = color
          ..style = PaintingStyle.fill;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(offset, 0, width, size.height),
        const Radius.circular(90),
      ),
      _pillPaint,
    );
  }

  @override
  bool shouldRepaint(_PillPainter oldDelegate) {
    return oldDelegate.offset != offset;
  }
}
