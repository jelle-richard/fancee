import 'package:carrot/carrot.dart';

class FTSalesBottomBar extends StatelessWidget {
  final List<Widget> children;
  final CrossAxisAlignment crossAxisAlignment;
  final Axis direction;

  const FTSalesBottomBar({
    super.key,
    required this.children,
    this.crossAxisAlignment = CrossAxisAlignment.center,
    this.direction = Axis.horizontal,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        boxShadow: CarrotShadows.medium,
        color: carrotTheme.primary[900],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.only(
            top: 15,
            left: 24,
            right: 24,
            bottom: 15,
          ),
          child: IntrinsicHeight(
            child: CarrotFlex(
              crossAxisAlignment: crossAxisAlignment,
              direction: direction,
              gap: 6,
              children: children,
            ),
          ),
        ),
      ),
    );
  }
}

class FTSalesBottomBarButton extends StatelessWidget {
  final bool disabled;
  final String? iconAfter;
  final String? iconBefore;
  final String? label;
  final GestureTapCallback onTap;

  const FTSalesBottomBarButton({
    super.key,
    required this.label,
    required this.onTap,
    this.disabled = false,
    this.iconAfter,
    this.iconBefore,
  });

  const FTSalesBottomBarButton.icon({
    super.key,
    required String icon,
    required this.onTap,
    this.disabled = false,
  })  : iconBefore = icon,
        iconAfter = null,
        label = null;

  Widget _buildButton(BuildContext context) {
    if (iconAfter == null && iconBefore != null && label == null) {
      return CarrotContainedButton(
        icon: iconBefore,
        onTap: onTap,
        children: const [],
      );
    }

    return CarrotContainedButton.text(
      icon: iconBefore,
      iconAfter: iconAfter,
      text: Text(label!),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      ignoring: disabled,
      child: AnimatedOpacity(
        curve: CarrotCurves.swiftOutCurve,
        duration: const Duration(milliseconds: 180),
        opacity: disabled ? .6 : 1,
        child: Builder(
          builder: _buildButton,
        ),
      ),
    );
  }
}

class FTSalesBottomBarPrice extends StatelessWidget {
  final String label;
  final String price;
  final TextAlign textAlign;

  const FTSalesBottomBarPrice({
    super.key,
    required this.label,
    required this.price,
    this.textAlign = TextAlign.left,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return CarrotColumn(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          label,
          style: carrotTheme.typography.body1.copyWith(
            color: carrotTheme.primary[300],
            fontSize: 14,
          ),
          textAlign: textAlign,
        ),
        Text(
          price,
          style: carrotTheme.typography.headline3.copyWith(
            color: carrotTheme.primary[0],
          ),
          textAlign: textAlign,
        ),
      ],
    );
  }
}
