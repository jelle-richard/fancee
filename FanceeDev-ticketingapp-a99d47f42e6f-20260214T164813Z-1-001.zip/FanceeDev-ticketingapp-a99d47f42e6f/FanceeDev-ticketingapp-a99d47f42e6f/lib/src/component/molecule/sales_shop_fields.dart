import 'package:carrot/carrot.dart';
import 'package:flutter/services.dart';

import '../../../l10n/l10n.dart';
import '../../data/data.dart';

typedef FTShopFieldOnChanged<T> = void Function(T);

abstract class FTShopFieldWidget<T> extends StatefulWidget {
  final FTShopFieldModel field;
  final int index;
  final FTShopModel shop;
  final T value;
  final FTShopFieldOnChanged<T> onChanged;

  const FTShopFieldWidget({
    super.key,
    required this.field,
    required this.index,
    required this.shop,
    required this.value,
    required this.onChanged,
  });

  Widget build(BuildContext context, covariant FTShopFieldWidgetState<T> state);
}

abstract class FTShopFieldWidgetState<T> extends State<FTShopFieldWidget<T>> {
  late final CarrotValueController<T> _controller;
  late final FocusNode _focusNode;

  @override
  void didUpdateWidget(FTShopFieldWidget<T> oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.value != oldWidget.value) {
      _controller.value = widget.value;
      _onChanged();
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onChanged);
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _controller = CarrotValueController(value: widget.value);
    _controller.addListener(_onChanged);
    _focusNode = FocusNode();
  }

  void _onChanged() {
    widget.onChanged(_controller.value);
  }

  @override
  Widget build(BuildContext context) {
    return widget.build(context, this);
  }
}

abstract class FTShopFieldDateTimeWidget extends FTShopFieldWidget<DateTime?> {
  const FTShopFieldDateTimeWidget({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  createState() => FTShopFieldDateTimeWidgetState();
}

class FTShopFieldDateTimeWidgetState extends FTShopFieldWidgetState<DateTime?> {
}

abstract class FTShopFieldEnumWidget<E> extends FTShopFieldWidget<E> {
  const FTShopFieldEnumWidget({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  createState() => FTShopFieldEnumWidgetState<E>();
}

class FTShopFieldEnumWidgetState<E> extends FTShopFieldWidgetState<E> {}

abstract class FTShopFieldStringWidget extends FTShopFieldWidget<String> {
  const FTShopFieldStringWidget({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  createState() => FTShopFieldStringWidgetState();
}

class FTShopFieldStringWidgetState extends FTShopFieldWidgetState<String> {
  late final TextEditingController _textController;

  @override
  void didUpdateWidget(FTShopFieldStringWidget oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.value != oldWidget.value) {
      _textController.text = widget.value;
    }
  }

  @override
  void dispose() {
    _textController.removeListener(_onTextChanged);
    _textController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _textController = TextEditingController(text: widget.value);
    _textController.addListener(_onTextChanged);
  }

  @override
  void _onChanged() {
    super._onChanged();

    if (_textController.text == _controller.value) {
      return;
    }

    _textController.text = _controller.value;
  }

  void _onTextChanged() {
    _controller.value = _textController.text;
  }
}

class FTShopFieldEmail extends FTShopFieldStringWidget {
  const FTShopFieldEmail({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  Widget build(BuildContext context, FTShopFieldStringWidgetState state) {
    return CarrotFormGroup(
      label: Text(context.strings.salesShopFieldEmailTitle),
      optional: !field.required,
      child: CarrotTextField(
        controller: state._textController,
        enableIMEPersonalizedLearning: false,
        enableSuggestions: false,
        focusNode: state._focusNode,
        keyboardType: TextInputType.emailAddress,
        placeholder: context.strings.salesShopFieldEmailPlaceholder,
        textCapitalization: TextCapitalization.none,
        textInputAction: TextInputAction.next,
      ),
    );
  }
}

class FTShopFieldGender extends FTShopFieldEnumWidget<FTGender> {
  const FTShopFieldGender({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  Widget build(
      BuildContext context, FTShopFieldEnumWidgetState<FTGender> state) {
    return CarrotFormGroup(
      label: Text(context.strings.salesShopFieldGenderTitle),
      optional: !field.required,
      child: CarrotSelectField(
        controller: state._controller,
        options: FTGender.options,
        placeholder: context.strings.salesShopFieldGenderPlaceholder,
      ),
    );
  }
}

class FTShopFieldFirstName extends FTShopFieldStringWidget {
  const FTShopFieldFirstName({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  Widget build(BuildContext context, FTShopFieldStringWidgetState state) {
    return CarrotFormGroup(
      label: Text(context.strings.salesShopFieldFirstNameTitle),
      optional: !field.required,
      child: CarrotTextField(
        controller: state._textController,
        enableIMEPersonalizedLearning: false,
        enableSuggestions: false,
        focusNode: state._focusNode,
        placeholder: context.strings.salesShopFieldFirstNamePlaceholder,
        textCapitalization: TextCapitalization.words,
        textInputAction: TextInputAction.next,
      ),
    );
  }
}

class FTShopFieldLastName extends FTShopFieldStringWidget {
  const FTShopFieldLastName({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  Widget build(BuildContext context, FTShopFieldStringWidgetState state) {
    return CarrotFormGroup(
      label: Text(context.strings.salesShopFieldLastNameTitle),
      optional: !field.required,
      child: CarrotTextField(
        controller: state._textController,
        enableIMEPersonalizedLearning: false,
        enableSuggestions: false,
        focusNode: state._focusNode,
        placeholder: context.strings.salesShopFieldLastNamePlaceholder,
        textCapitalization: TextCapitalization.words,
        textInputAction: TextInputAction.next,
      ),
    );
  }
}

class FTShopFieldBirthDate extends FTShopFieldDateTimeWidget {
  const FTShopFieldBirthDate({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  Widget build(BuildContext context, FTShopFieldDateTimeWidgetState state) {
    return CarrotFormGroup(
      label: Text(context.strings.salesShopFieldBirthdateTitle),
      optional: !field.required,
      child: CarrotDateField(
        controller: state._controller,
        minDate: DateTime(1950, 1, 1),
        placeholder: context.strings.salesShopFieldBirthdatePlaceholder,
      ),
    );
  }
}

class FTShopFieldPhoneNumber extends FTShopFieldStringWidget {
  const FTShopFieldPhoneNumber({
    super.key,
    required super.field,
    required super.index,
    required super.shop,
    required super.value,
    required super.onChanged,
  });

  @override
  Widget build(BuildContext context, FTShopFieldStringWidgetState state) {
    return CarrotFormGroup(
      label: Text(context.strings.salesShopFieldPhoneNumberTitle),
      optional: !field.required,
      child: CarrotTextField(
        controller: state._textController,
        enableIMEPersonalizedLearning: false,
        enableSuggestions: false,
        focusNode: state._focusNode,
        keyboardType: TextInputType.phone,
        placeholder: context.strings.salesShopFieldPhoneNumberPlaceholder,
        textCapitalization: TextCapitalization.words,
        textInputAction: TextInputAction.next,
      ),
    );
  }
}
