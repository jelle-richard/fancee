import 'package:carrot/carrot.dart';

class FTEmptyViewSwitcher extends StatelessWidget {
  final Widget child;
  final Widget emptyView;
  final bool isEmptyViewVisible;

  const FTEmptyViewSwitcher({
    super.key,
    required this.child,
    required this.emptyView,
    required this.isEmptyViewVisible,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      switchInCurve: CarrotCurves.swiftOutCurve,
      switchOutCurve: CarrotCurves.swiftOutCurve,
      duration: const Duration(milliseconds: 300),
      layoutBuilder: (currentChild, previousChildren) => Stack(
        alignment: Alignment.topLeft,
        children: [
          ...previousChildren,
          if (currentChild != null) Positioned.fill(child: currentChild),
        ],
      ),
      child: isEmptyViewVisible ? emptyView : child,
    );
  }
}
