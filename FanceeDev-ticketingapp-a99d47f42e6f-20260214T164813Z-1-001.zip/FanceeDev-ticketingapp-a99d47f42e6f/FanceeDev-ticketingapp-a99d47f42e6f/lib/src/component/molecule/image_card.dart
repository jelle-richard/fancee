import 'package:carrot/carrot.dart';

class FTImageCard extends StatelessWidget {
  final double aspectRatio;
  final Widget image;
  final Widget title;
  final Widget subTitle;
  final GestureTapCallback? onTap;

  const FTImageCard({
    super.key,
    required this.image,
    required this.title,
    required this.subTitle,
    this.aspectRatio = 16 / 9,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CarrotBounceTap(
        onTap: onTap,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15),
          child: AspectRatio(
            aspectRatio: aspectRatio,
            child: Stack(
              children: [
                Positioned.fill(
                  child: image,
                ),
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          CarrotColors.black.withOpacity(.05),
                          CarrotColors.black.withOpacity(.25),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 18,
                  bottom: 18,
                  child: CarrotColumn(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      DefaultTextStyle(
                        style: context.carrotTypography.headline5.copyWith(
                          color: CarrotColors.white,
                          shadows: CarrotShadows.large,
                        ),
                        child: title,
                      ),
                      DefaultTextStyle(
                        style: context.carrotTypography.subtitle2.copyWith(
                          color: CarrotColors.white,
                          fontSize: 14,
                          height: 1.2,
                          shadows: CarrotShadows.large,
                        ),
                        child: subTitle,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
