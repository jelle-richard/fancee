import 'package:carrot/carrot.dart';

import '../../config.dart';

class FTSubtleNotice extends StatelessWidget {
  final bool _dismissible;
  final String icon;
  final Color? iconColor;
  final CarrotIconStyle iconStyle;
  final EdgeInsets margin;
  final Widget title;
  final Widget body;
  final DismissDirectionCallback? onDismissed;
  final GestureTapCallback? onTap;

  const FTSubtleNotice({
    super.key,
    required this.icon,
    required this.title,
    required this.body,
    this.iconColor,
    this.iconStyle = FTConfig.defaultIconStyle,
    this.margin = EdgeInsets.zero,
    this.onTap,
  })  : _dismissible = false,
        onDismissed = null;

  const FTSubtleNotice.dismissible({
    required super.key,
    required this.icon,
    required this.title,
    required this.body,
    this.iconColor,
    this.iconStyle = FTConfig.defaultIconStyle,
    this.margin = EdgeInsets.zero,
    this.onDismissed,
    this.onTap,
  }) : _dismissible = true;

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    Widget notice = DecoratedBox(
      decoration: BoxDecoration(
        border: Border.all(
          color: carrotTheme.gray[100],
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(15),
        color: carrotTheme.defaults.content,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 15,
        ),
        child: CarrotRow(
          crossAxisAlignment: CrossAxisAlignment.start,
          gap: 15,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: CarrotIcon(
                color: iconColor ?? carrotTheme.defaults.error,
                glyph: icon,
                size: 20,
              ),
            ),
            Expanded(
              child: CarrotColumn(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                gap: 3,
                children: [
                  DefaultTextStyle(
                    style: context.carrotTypography.headline6,
                    child: title,
                  ),
                  DefaultTextStyle(
                    style: context.carrotTypography.body2.copyWith(
                      fontSize: 14,
                    ),
                    child: body,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );

    if (onTap != null) {
      notice = CarrotBounceTap(
        onTap: onTap,
        child: notice,
      );
    }

    if (margin != EdgeInsets.zero) {
      notice = Padding(
        padding: margin,
        child: notice,
      );
    }

    if (_dismissible) {
      notice = Dismissible(
        key: key!,
        direction: DismissDirection.endToStart,
        onDismissed: onDismissed,
        child: notice,
      );
    }

    return notice;
  }
}
