part of '../../view/sales_shop.dart';

abstract class _FTShopElementWidget extends StatelessWidget {
  final FTShopElementModel element;
  final int index;
  final FTShopModel shop;

  FTEventModel get event => shop.event;

  FTShopElementDividerModel get divider => assertedCast(element);

  FTShopElementExternalLinkModel get externalLink => assertedCast(element);

  FTShopElementNoticeModel get notice => assertedCast(element);

  FTShopElementProductModel get product => assertedCast(element);

  FTShopElementTextBlockModel get textBlock => assertedCast(element);

  const _FTShopElementWidget({
    required this.element,
    required this.index,
    required this.shop,
  });

  bool _precededBy(FTShopElementType type) {
    return index > 0 ? shop.elements[index - 1].kind == type : false;
  }
}

class _FTShopElementDivider extends _FTShopElementWidget {
  const _FTShopElementDivider({
    required super.element,
    required super.index,
    required super.shop,
  });

  @override
  Widget build(BuildContext context) {
    final hasPrecedingNotice = _precededBy(FTShopElementType.notice);

    return FTLabelledDivider(
      margin: EdgeInsets.only(
        top: hasPrecedingNotice ? 0 : 18,
        left: 24,
        right: 24,
        bottom: 18,
      ),
      label: Text(
        divider.name,
      ),
    );
  }
}

class _FTShopElementExternalLink extends _FTShopElementWidget {
  const _FTShopElementExternalLink({
    required super.element,
    required super.index,
    required super.shop,
  });

  @override
  Widget build(BuildContext context) {
    final hasPrecedingTextBlock = _precededBy(FTShopElementType.textBlock);

    return Padding(
      padding: EdgeInsets.only(
        top: hasPrecedingTextBlock ? 0 : 24,
        left: 24,
        right: 24,
        bottom: 24,
      ),
      child: CarrotTextButton.text(
        text: Text(externalLink.name),
        onTap: () => launchFromString(externalLink.link),
      ),
    );
  }
}

class _FTShopElementNotice extends _FTShopElementWidget {
  const _FTShopElementNotice({
    required super.element,
    required super.index,
    required super.shop,
  });

  @override
  Widget build(BuildContext context) {
    late final CarrotColor color;
    late final String icon;

    switch (notice.variant) {
      case FTColorType.primary:
        color = context.carrotTheme.primary;
        icon = 'circle-info';
        break;

      case FTColorType.secondary:
        color = context.carrotTheme.secondary;
        icon = 'circle-info';
        break;

      case FTColorType.success:
        color = context.carrotTheme.defaults.success;
        icon = 'circle-check';
        break;

      case FTColorType.warning:
        color = context.carrotTheme.defaults.warning;
        icon = 'circle-exclamation';
        break;

      case FTColorType.danger:
        color = context.carrotTheme.defaults.error;
        icon = 'circle-exclamation';
        break;

      case FTColorType.info:
        color = context.carrotTheme.defaults.info;
        icon = 'circle-info';
        break;
    }

    return Padding(
      padding: const EdgeInsets.all(24),
      child: CarrotNotice(
        color: color,
        icon: FTIcon(
          glyph: icon,
        ),
        message: Text(notice.content),
      ),
    );
  }
}

class _FTShopElementProduct extends _FTShopElementWidget {
  const _FTShopElementProduct({
    required super.element,
    required super.index,
    required super.shop,
  });

  void _onQuantityChanged(BuildContext context, int value) {
    final salesBloc = context.read<FTSalesStateBloc>();
    salesBloc.add(FTSalesStateUpdateCart(product.id, value));
  }

  @override
  Widget build(BuildContext context) {
    bool hasPrecedingProduct = _precededBy(FTShopElementType.product);

    final carrotTheme = context.carrotTheme;
    final locale = Localizations.localeOf(context);
    final salesBloc = context.watch<FTSalesStateBloc>();

    final border = BorderSide(
      color: carrotTheme.gray[carrotTheme.resolve(100, 50)],
      width: 1,
    );

    final fee = event.currency.format(locale, product.feeCents);
    final price = event.currency.format(locale, product.priceCents);

    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border(
          top: hasPrecedingProduct || index == 0 ? BorderSide.none : border,
          bottom: border,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 15,
        ),
        child: CarrotRow(
          gap: 18,
          children: [
            if (product.media.isNotEmpty)
              SizedBox.square(
                dimension: 48,
                child: Image.network(
                  product.media.first.url,
                  fit: BoxFit.contain,
                ),
              ),
            Expanded(
              child: CarrotColumn(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    product.name,
                    style: carrotTheme.typography.headline5,
                  ),
                  Text(
                    '$price (+ $fee)',
                    style: carrotTheme.typography.body2.copyWith(
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            CarrotIncrementStepper(
              max: product.reservableQuantity,
              min: 0,
              value: salesBloc.state.cart[product.id] ?? 0,
              onChanged: (value) => _onQuantityChanged(context, value.toInt()),
            ),
          ],
        ),
      ),
    );
  }
}

class _FTShopElementTextBlock extends _FTShopElementWidget {
  const _FTShopElementTextBlock({
    required super.element,
    required super.index,
    required super.shop,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;
    final hasPrecedingDivider = _precededBy(FTShopElementType.divider);

    return Padding(
      padding: EdgeInsets.only(
        top: hasPrecedingDivider ? 0 : 24,
        left: 24,
        right: 24,
        bottom: 24,
      ),
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        gap: 6,
        children: [
          Text(
            textBlock.title,
            style: carrotTheme.typography.headline4.copyWith(
              color: carrotTheme.primary,
            ),
          ),
          Text(
            textBlock.text,
            style: carrotTheme.typography.body2,
          ),
        ],
      ),
    );
  }
}
