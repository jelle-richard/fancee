import 'package:carrot/carrot.dart';

import 'scaffold_scroll_view.dart';

class FTScaffold extends StatelessWidget {
  final Widget child;
  final bool isWithScrollView;
  final EdgeInsets padding;

  const FTScaffold({
    super.key,
    required this.child,
    this.isWithScrollView = true,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    if (!isWithScrollView) {
      return child;
    }

    return FTScaffoldScrollView(
      scrollController: ScrollController(),
      child: CarrotBodySafeArea(
        extraPadding: padding,
        child: child,
      ),
    );
  }
}
