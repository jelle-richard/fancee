import 'package:carrot/carrot.dart';

import '../../data/data.dart';
import '../atom/atom.dart';

class FTAppBar extends StatefulWidget implements PreferredSizeWidget {
  final bool canPop;
  final String title;
  final bool visible;

  const FTAppBar({
    super.key,
    required this.canPop,
    required this.title,
    this.visible = true,
  });

  @override
  Size get preferredSize => const Size.fromHeight(.0);

  @override
  createState() => _FTAppBarState();
}

class _FTAppBarState extends State<FTAppBar> {
  void _onBackTap() {
    if (widget.canPop) {
      context.carrotRouter.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return BlocBuilder<FTAppStateBloc, FTAppState>(
      builder: (context, state) {
        return AnimatedSlide(
          curve: CarrotCurves.springOverDamped,
          duration: const Duration(milliseconds: 540),
          offset: Offset(0, widget.visible ? 0 : -1),
          child: CarrotAppBar(
            isTransparent: true,
            systemOverlayStyle: CarrotAppBarSystemOverlayStyle.disabled,
            title: DefaultTextStyle(
              style: context.carrotTypography.body2.copyWith(
                color: carrotTheme.primary[carrotTheme.resolve(0, 100)],
                fontWeight: FontWeight.w600,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 60,
                ),
                child: FTSwitcherAnimation(
                  child: Text(
                    widget.title,
                    key: ValueKey(widget.title),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
            before: [
              FTSwitcherAnimation.conditional(
                isVisible: widget.canPop,
                child: _FTAppBarBackButton(
                  onTap: _onBackTap,
                ),
              ),
            ],
            after: [
              _FTAppBarButton(
                button: state.appBarActions.get(0),
                order: 2,
              ),
              _FTAppBarButton(
                button: state.appBarActions.get(1),
                order: 1,
              ),
              _FTAppBarButton(
                button: state.appBarActions.get(2),
                order: 0,
              ),
            ],
          ),
        );
      },
    );
  }
}

class FTAppBarButton {
  final String icon;
  final String label;
  final GestureTapCallback? onTap;

  const FTAppBarButton({
    required this.icon,
    required this.label,
    this.onTap,
  });
}

class _FTAppBarButton extends StatelessWidget {
  final FTAppBarButton? button;
  final int order;

  const _FTAppBarButton({
    required this.button,
    required this.order,
  });

  @override
  Widget build(BuildContext context) {
    return FTSwitcherAnimation(
      switchInDurationExtra: Duration(
        milliseconds: order * 210,
      ),
      child: button != null
          ? CarrotAppBarButton(
              icon: FTIcon(
                glyph: button!.icon,
              ),
              label: button!.label,
              onTap: button!.onTap,
            )
          : Container(),
    );
  }
}

class _FTAppBarBackButton extends StatelessWidget {
  final GestureTapCallback onTap;

  const _FTAppBarBackButton({
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return CarrotAppBarButton(
      icon: const FTIcon(
        glyph: 'circle-arrow-left',
      ),
      label: 'Go back',
      onTap: onTap,
    );
  }
}

extension _FTAppBarListExtension on List<FTAppBarButton> {
  FTAppBarButton? get(int index) {
    if (index < length) {
      return this[index];
    }

    return null;
  }
}
