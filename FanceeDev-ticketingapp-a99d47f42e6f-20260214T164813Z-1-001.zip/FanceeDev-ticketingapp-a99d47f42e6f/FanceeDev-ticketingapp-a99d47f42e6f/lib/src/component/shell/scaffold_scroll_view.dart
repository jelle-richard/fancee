import 'package:carrot/carrot.dart';

class FTScaffoldScrollView extends StatelessWidget {
  final Widget child;
  final ScrollController scrollController;

  const FTScaffoldScrollView({
    super.key,
    required this.child,
    required this.scrollController,
  });

  @override
  Widget build(BuildContext context) {
    return CarrotPrimaryScrollView(
      scrollController: scrollController,
      child: CarrotScrollView(
        physics: const BouncingScrollPhysics(),
        scrollPadding: EdgeInsets.only(
          top: context.carrotScaffold.appBarSize.height - context.safeAreaReal.top,
          bottom: context.carrotScaffold.bottomBarSize.height - context.safeAreaReal.bottom,
        ),
        scrollController: scrollController,
        child: child,
      ),
    );
  }
}
