import 'package:carrot/carrot.dart';

import '../../../l10n/extension.dart';
import '../../data/data.dart';
import '../../routes.dart';
import '../atom/atom.dart';
import 'app_bar.dart';
import 'base.dart';
import 'bottom_bar.dart';
import 'settings.dart';

class FTShellRoot extends FTBaseShell {
  const FTShellRoot({
    super.key,
    required super.child,
  });

  @override
  Widget buildShell(BuildContext context) {
    return FTShellSettingsProvider(
      settings: settings,
      child: FTGridBackground(
        backgroundColor: context.carrotTheme.defaults.background,
        lineColor: context.carrotTheme.defaults.background.lighten(.0125),
        child: CarrotScaffold(
          backgroundColor: CarrotColors.transparent,
          appBar: FTAppBar(
            canPop: navigator.pages.length > 1,
            title: currentPageTitle,
            visible: !settings.hideAppBar,
          ),
          bottomBar: !context.mediaQuery.isPhone ? null : FTBottomBar(
            currentPath: context.carrotRouter.location,
            visible: !settings.hideBottomBar,
          ),
          drawer: context.mediaQuery.isPhone ? null : _buildDrawer,
          child: FTInternetCheck(
            child: child,
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context, BoxConstraints constraints) {
    return CarrotDrawer(
      backgroundColor: CarrotColors.transparent,
      header: const SafeArea(
        child: Padding(
          padding: EdgeInsets.only(
            top: 30,
            left: 24,
            right: 24,
            bottom: 15,
          ),
          child: Align(
            alignment: Alignment.centerLeft,
            child: FTSmallLogo(
              size: 60,
            ),
          ),
        ),
      ),
      child: DefaultTextStyle(
        style: context.carrotTypography.base.copyWith(
          color: CarrotColors.white,
          fontWeight: FontWeight.w500,
        ),
        child: CarrotDrawerMenu(
          items: [
            if (context.isFeatureEnabled(FTFeatureFlag.statisticsEnabled) && context.userHasStatisticsTab)
              CarrotDrawerMenuItem(
                icon: const FTIcon(glyph: 'arrow-trend-up'),
                label: Text(context.strings.statistics),
                onTap: () => context.carrotRouter.go(FTRoutes.statistics()),
              ),
            if (context.isFeatureEnabled(FTFeatureFlag.scanEnabled) && context.userHasScanTab)
              CarrotDrawerMenuItem(
                icon: const FTIcon(glyph: 'qrcode'),
                label: Text(context.strings.scan),
                onTap: () => context.carrotRouter.go(FTRoutes.scan()),
              ),
            if (context.isFeatureEnabled(FTFeatureFlag.salesEnabled) && context.userHasSalesTab)
              CarrotDrawerMenuItem(
                icon: const FTIcon(glyph: 'bag-shopping'),
                label: Text(context.strings.sales),
                onTap: () => context.carrotRouter.go(FTRoutes.sales()),
              ),
            CarrotDrawerMenuItem(
              icon: const FTIcon(glyph: 'ellipsis-h'),
              label: Text(context.strings.more),
              onTap: () => context.carrotRouter.go(FTRoutes.more()),
            ),
          ],
        ),
      ),
    );
  }
}
