import 'package:carrot/carrot.dart';
import 'package:flutter/services.dart';

enum FTSystemUiStyle {
  auto,
  dark,
  light;

  SystemUiOverlayStyle resolve(BuildContext context) {
    if (this == FTSystemUiStyle.auto) {
      return context.carrotTheme.isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark;
    }

    return this == FTSystemUiStyle.dark ? SystemUiOverlayStyle.dark : SystemUiOverlayStyle.light;
  }
}

class FTShellSettings {
  final bool hideAppBar;
  final bool hideBottomBar;
  final FTSystemUiStyle systemUiStyle;

  const FTShellSettings({
    this.hideAppBar = false,
    this.hideBottomBar = false,
    this.systemUiStyle = FTSystemUiStyle.light,
  });

  static FTShellSettings? of(BuildContext context) {
    final provider = context.dependOnInheritedWidgetOfExactType<FTShellSettingsProvider>();
    return provider?.settings;
  }
}

class FTShellSettingsProvider extends InheritedWidget {
  final FTShellSettings settings;

  const FTShellSettingsProvider({
    super.key,
    required super.child,
    required this.settings,
  });

  @override
  bool updateShouldNotify(FTShellSettingsProvider oldWidget) {
    return settings != oldWidget.settings;
  }
}
