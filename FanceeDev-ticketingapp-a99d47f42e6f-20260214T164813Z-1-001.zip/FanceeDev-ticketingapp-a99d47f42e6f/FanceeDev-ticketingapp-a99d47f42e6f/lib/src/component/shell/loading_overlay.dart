import 'package:carrot/carrot.dart';

import '../atom/atom.dart';

class FTLoadingOverlay extends StatelessWidget {
  final Widget child;
  final bool isLoading;

  const FTLoadingOverlay({
    super.key,
    required this.child,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return AnimatedSwitcher(
      switchInCurve: CarrotCurves.swiftOutCurve,
      switchOutCurve: CarrotCurves.swiftOutCurve,
      duration: const Duration(milliseconds: 300),
      layoutBuilder: (currentChild, previousChildren) => Stack(
        alignment: Alignment.topLeft,
        children: [
          ...previousChildren,
          if (currentChild != null) Positioned.fill(child: currentChild),
        ],
      ),
      child: !isLoading
          ? child
          : FTGridBackground(
              backgroundColor: carrotTheme.primary[carrotTheme.resolve(700, 900)],
              lineColor: carrotTheme.primary[carrotTheme.resolve(600, 800)].darken(.04),
              size: 93,
              child: CarrotColumn(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                gap: 150,
                children: [
                  CarrotBasicAnimation.fadeInOffset(
                    curve: CarrotCurves.springUnderDamped,
                    delay: const Duration(milliseconds: 300),
                    duration: const Duration(milliseconds: 900),
                    fromOffset: const Offset(0, -150),
                    child: const FTSmallLogo(),
                  ),
                  CarrotBasicAnimation.fadeIn(
                    curve: CarrotCurves.swiftOutCurve,
                    delay: const Duration(milliseconds: 300),
                    duration: const Duration(milliseconds: 540),
                    child: FTSpinner(
                      background: carrotTheme.primary[carrotTheme.resolve(700, 900)].darken(.04),
                      color: carrotTheme.primary[0],
                      colorSecondary: carrotTheme.primary,
                      size: 36,
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
