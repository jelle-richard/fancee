import 'package:carrot/carrot.dart';
import 'package:flutter/services.dart';

import '../../config.dart';
import 'settings.dart';

abstract class FTBaseShell extends StatelessWidget {
  final Widget child;

  HeroControllerScope get heroControllerScope => child as HeroControllerScope;

  Navigator get navigator => heroControllerScope.child as Navigator;

  Page<dynamic> get currentPage => navigator.pages.last;

  String get currentPageTitle => currentPage.name ?? FTConfig.title;

  FTShellSettings get settings {
    if (currentPage.arguments is FTShellSettings) {
      return currentPage.arguments as FTShellSettings;
    }

    return const FTShellSettings();
  }

  const FTBaseShell({
    super.key,
    required this.child,
  }) : assert(child is HeroControllerScope);

  @override
  Widget build(BuildContext context) {
    _ensureSystemUiOverlayStyle(context);

    return FTShellSettingsProvider(
      settings: settings,
      child: Builder(
        builder: buildShell,
      ),
    );
  }

  Widget buildShell(BuildContext context);

  void _ensureSystemUiOverlayStyle(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(settings.systemUiStyle.resolve(context));
  }
}
