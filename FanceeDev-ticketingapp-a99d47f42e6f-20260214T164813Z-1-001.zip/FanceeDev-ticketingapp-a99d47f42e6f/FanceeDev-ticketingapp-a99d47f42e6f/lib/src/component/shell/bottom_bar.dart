import 'package:carrot/carrot.dart';

import '../../../l10n/l10n.dart';
import '../../data/data.dart';
import '../../routes.dart';
import '../atom/atom.dart';

class FTBottomBar extends StatelessWidget implements PreferredSizeWidget {
  final String currentPath;
  final bool visible;

  const FTBottomBar({
    super.key,
    required this.currentPath,
    this.visible = true,
  });

  @override
  Size get preferredSize => const Size.fromHeight(.0);

  int get activeIndex {
    if (currentPath.startsWith(FTRoutes.statistics())) {
      return 0;
    }

    if (currentPath.startsWith(FTRoutes.scan())) {
      return 1;
    }

    if (currentPath.startsWith(FTRoutes.sales())) {
      return 2;
    }

    if (currentPath.startsWith(FTRoutes.more())) {
      return 3;
    }

    return -1;
  }

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return RepaintBoundary(
      child: BlocBuilder<FTAppStateBloc, FTAppState>(
        builder: (context, state) {
          return AnimatedSlide(
            curve: CarrotCurves.springOverDamped,
            duration: const Duration(milliseconds: 540),
            offset: Offset(0, visible ? 0 : 1),
            child: CarrotIconNav(
              activeIndex: activeIndex,
              curve: CarrotCurves.swiftOutCurve,
              duration: const Duration(milliseconds: 420),
              iconColorActive: carrotTheme.accent,
              labelColorActive: carrotTheme.primary[carrotTheme.resolve(700, 300)],
              shadow: CarrotShadows.medium,
              items: [
                if (context.isFeatureEnabled(FTFeatureFlag.statisticsEnabled) && context.userHasStatisticsTab)
                  CarrotIconNavItem(
                    icon: const FTIcon(glyph: 'arrow-trend-up'),
                    label: Text(context.strings.stats),
                    onTap: () => context.carrotRouter.go(FTRoutes.statistics()),
                  ),
                if (context.isFeatureEnabled(FTFeatureFlag.scanEnabled) && context.userHasScanTab)
                  CarrotIconNavItem(
                    icon: const FTIcon(glyph: 'qrcode'),
                    label: Text(context.strings.scan),
                    onTap: () => context.carrotRouter.go(FTRoutes.scan()),
                  ),
                if (context.isFeatureEnabled(FTFeatureFlag.salesEnabled) && context.userHasSalesTab)
                  CarrotIconNavItem(
                    icon: const FTIcon(glyph: 'bag-shopping'),
                    label: Text(context.strings.sales),
                    onTap: () => context.carrotRouter.go(FTRoutes.sales()),
                  ),
                CarrotIconNavItem(
                  icon: const FTIcon(glyph: 'ellipsis-h'),
                  label: Text(context.strings.more),
                  onTap: () => context.carrotRouter.go(FTRoutes.more()),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
