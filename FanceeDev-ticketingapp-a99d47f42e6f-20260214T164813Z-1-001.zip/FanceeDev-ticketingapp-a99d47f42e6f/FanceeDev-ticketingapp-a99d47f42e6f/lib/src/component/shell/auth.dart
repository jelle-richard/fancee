import 'package:carrot/carrot.dart';

import '../atom/atom.dart';
import 'base.dart';

class FTShellAuth extends FTBaseShell {
  const FTShellAuth({
    super.key,
    required super.child,
  });

  @override
  Widget buildShell(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return FTGridBackground(
      backgroundColor: carrotTheme.defaults.content,
      enableAnimation: true,
      lineColor: carrotTheme.gray[50],
      child: CarrotScaffold(
        backgroundColor: CarrotColors.transparent,
        child: FTScrollViewConstraints(
          child: child,
        ),
      ),
    );
  }
}
