import 'package:carrot/carrot.dart';
import 'package:flutter/gestures.dart';

import '../../component/atom/atom.dart';

class FTLayoutAuth extends StatefulWidget {
  final List<Widget> children;
  final VoidCallback? onLogoLongPress;

  const FTLayoutAuth({
    super.key,
    required this.children,
    this.onLogoLongPress,
  });

  @override
  createState() => _FTLayoutAuthState();
}

class _FTLayoutAuthState extends State<FTLayoutAuth> {
  @override
  Widget build(BuildContext context) {
    return CarrotScrollView(
      physics: const CarrotBouncingScrollPhysics.notAlways(),
      scrollController: ScrollController(),
      padding: context.safeAreaReal.add(const EdgeInsets.symmetric(
        horizontal: 45,
        vertical: 45,
      )) as EdgeInsets,
      child: CarrotContainerTheme(
        data: context.carrotTheme.containerTheme.copyWith(
          width: const CarrotOptional.of(420),
        ),
        child: CarrotContainer(
          child: CarrotColumn(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.start,
            gap: 30,
            children: [
              RawGestureDetector(
                gestures: {
                  LongPressGestureRecognizer: GestureRecognizerFactoryWithHandlers<LongPressGestureRecognizer>(
                        () => LongPressGestureRecognizer(
                      duration: const Duration(seconds: 1),
                    ),
                        (instance) => instance.onLongPress = widget.onLogoLongPress,
                  ),
                },
                child: const _FTLayoutAuthLogo(),
              ),
              ...widget.children,
            ],
          ),
        ),
      ),
    );
  }
}

class FTLayoutAuthProceedButton extends StatelessWidget {
  final bool disabled;
  final String text;
  final GestureTapCallback onTap;

  const FTLayoutAuthProceedButton({
    super.key,
    required this.text,
    required this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    return CarrotDisabled.opacity(
      disabled: disabled,
      child: CarrotContainedButton.text(
        size: CarrotButtonSize.medium,
        iconAfter: 'circle-arrow-right',
        text: Text(text),
        onTap: onTap,
      ),
    );
  }
}

class FTLayoutAuthTextFieldIcon extends StatelessWidget {
  final String icon;
  final bool isPrefix;
  final EdgeInsets margin;

  const FTLayoutAuthTextFieldIcon.prefix({
    super.key,
    required this.icon,
  })  : isPrefix = true,
        margin = const EdgeInsets.only(
          left: 18,
        );

  const FTLayoutAuthTextFieldIcon.suffix({
    super.key,
    required this.icon,
  })  : isPrefix = false,
        margin = const EdgeInsets.only(
          right: 18,
        );

  @override
  Widget build(BuildContext context) {
    return FTIcon(
      color: isPrefix ? context.carrotTheme.primary : context.carrotTheme.gray[400],
      glyph: icon,
      margin: margin,
      size: 18,
    );
  }
}

class _FTLayoutAuthLogo extends StatelessWidget {
  const _FTLayoutAuthLogo();

  @override
  Widget build(BuildContext context) {
    return CarrotColumn(
      gap: 21,
      children: [
        const FTSmallLogo(
          size: 120,
        ),
        Text.rich(
          TextSpan(
              style: TextStyle(
                color: context.carrotTheme.primary[700],
                fontSize: 24,
              ),
              children: const [
                TextSpan(
                  text: 'Fancee',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextSpan(
                  text: 'Ticketing',
                  style: TextStyle(
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ]),
        ),
      ],
    );
  }
}
