import 'package:carrot/carrot.dart';

import '../molecule/molecule.dart';
import 'layout.dart';

class FTLayoutSales extends StatelessWidget {
  final Widget child;
  final Widget footer;
  final bool isLoading;

  const FTLayoutSales({
    super.key,
    required this.child,
    required this.footer,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return FTLoadingSubtleOverlay(
      isLoading: isLoading,
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        gap: 0,
        children: [
          Expanded(
            child: FTLayoutSheet.singleChildScrollView(
              builder: (context) => child,
            ),
          ),
          footer,
        ],
      ),
    );
  }
}
