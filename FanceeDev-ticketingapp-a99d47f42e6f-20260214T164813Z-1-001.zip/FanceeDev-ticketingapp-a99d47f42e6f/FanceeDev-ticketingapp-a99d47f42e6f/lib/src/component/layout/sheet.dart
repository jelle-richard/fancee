import 'package:carrot/carrot.dart';

import '../atom/atom.dart';
import '../molecule/molecule.dart';
import '../shell/shell.dart';

class FTLayoutSheet extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;

  const FTLayoutSheet._({
    super.key,
    required this.child,
    required this.padding,
  });

  factory FTLayoutSheet.customScrollView({
    Key? key,
    // custom scroll view
    required List<Widget> slivers,
    // sheet
    Color? backgroundColor,
    WidgetBuilder? headerBuilder,
    bool isLoading = false,
    EdgeInsets padding = EdgeInsets.zero,
  }) =>
      FTLayoutSheet._(
        key: key,
        padding: padding,
        child: CarrotSheetView(
          backgroundColor: backgroundColor,
          headerBuilder: headerBuilder,
          builder: (context, scrollController) => FTLoadingSubtleOverlay(
            isLoading: isLoading,
            child: CarrotContainer(
              child: CustomScrollView(
                controller: scrollController,
                shrinkWrap: true,
                slivers: slivers,
              ),
            ),
          ),
        ),
      );

  factory FTLayoutSheet.gridView({
    Key? key,
    // grid view
    required IndexedWidgetBuilder itemBuilder,
    required int itemCount,
    double aspectRadio = 1.0,
    int columns = 2,
    FTItemViewHeaderBuilder? listHeaderBuilder,
    bool isReversed = false,
    double spacing = .0,
    // sheet
    Color? backgroundColor,
    WidgetBuilder? headerBuilder,
    bool isLoading = false,
    EdgeInsets padding = EdgeInsets.zero,
  }) =>
      FTLayoutSheet._(
        key: key,
        padding: padding,
        child: CarrotSheetView(
          backgroundColor: backgroundColor,
          headerBuilder: headerBuilder,
          builder: (context, scrollController) => FTLoadingSubtleOverlay(
            isLoading: isLoading,
            child: CarrotContainer(
              child: FTGridView(
                aspectRatio: aspectRadio,
                columns: columns,
                headerBuilder: listHeaderBuilder,
                itemBuilder: itemBuilder,
                itemCount: itemCount,
                isReversed: isReversed,
                padding: padding,
                scrollController: scrollController,
                spacing: spacing,
              ),
            ),
          ),
        ),
      );

  factory FTLayoutSheet.listView({
    Key? key,
    // list view
    required IndexedWidgetBuilder itemBuilder,
    required int itemCount,
    FTItemViewHeaderBuilder? listHeaderBuilder,
    bool isReversed = false,
    IndexedWidgetBuilder? separatorBuilder,
    // sheet
    Color? backgroundColor,
    WidgetBuilder? headerBuilder,
    bool isLoading = false,
    EdgeInsets padding = EdgeInsets.zero,
  }) =>
      FTLayoutSheet._(
        key: key,
        padding: padding,
        child: CarrotSheetView(
          backgroundColor: backgroundColor,
          headerBuilder: headerBuilder,
          builder: (context, scrollController) => FTLoadingSubtleOverlay(
            isLoading: isLoading,
            child: CarrotContainer(
              child: FTListView(
                headerBuilder: listHeaderBuilder,
                itemBuilder: itemBuilder,
                itemCount: itemCount,
                isReversed: isReversed,
                padding: padding,
                separatorBuilder: separatorBuilder,
                scrollController: scrollController,
              ),
            ),
          ),
        ),
      );

  factory FTLayoutSheet.singleChildScrollView({
    Key? key,
    required WidgetBuilder builder,
    Color? backgroundColor,
    WidgetBuilder? headerBuilder,
    bool isLoading = false,
    EdgeInsets padding = EdgeInsets.zero,
  }) =>
      FTLayoutSheet._(
        key: key,
        padding: padding,
        child: CarrotSheetView(
          backgroundColor: backgroundColor,
          headerBuilder: headerBuilder,
          builder: (context, scrollController) => FTLoadingSubtleOverlay(
            isLoading: isLoading,
            child: CarrotScrollView(
              scrollController: scrollController,
              child: CarrotContainer(
                child: Padding(
                  padding: padding,
                  child: Builder(
                    builder: builder,
                  ),
                ),
              ),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final scaffold = context.carrotScaffold;
    final shellSettings = FTShellSettings.of(context);

    return Padding(
      padding: EdgeInsets.only(
        top: scaffold.appBarSize.height,
        bottom: shellSettings?.hideBottomBar == true || context.mediaQuery.viewInsets.bottom > 0 ? 0 : scaffold.bottomBarSize.height,
      ),
      child: child,
    );
  }
}
