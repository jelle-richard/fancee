import 'package:carrot/carrot.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../atom/atom.dart';
import 'sheet.dart';

class FTLayoutEmptyView extends StatelessWidget {
  final String explanation;
  final String title;
  final Widget visual;
  final Widget? child;

  const FTLayoutEmptyView({
    super.key,
    required this.explanation,
    required this.title,
    required this.visual,
    this.child,
  });

  factory FTLayoutEmptyView.illustration({
    required String explanation,
    required String illustration,
    required String title,
    Widget? child,
  }) =>
      FTLayoutEmptyView(
        explanation: explanation,
        title: title,
        visual: Builder(
          builder: (context) => Align(
            alignment: Alignment.center,
            child: SizedBox.square(
              dimension: 210,
              child: SvgPicture.asset(
                'assets/illustrations/$illustration${context.carrotTheme.isDark ? '_dark' : ''}.svg',
              ),
            ),
          ),
        ),
        child: child,
      );

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.singleChildScrollView(
      builder: (_) => FTScrollViewConstraints(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 36),
          child: CarrotColumn(
            mainAxisAlignment: MainAxisAlignment.center,
            gap: 9,
            children: [
              visual,
              CarrotText.headline3(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: context.carrotTheme.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                ),
                child: CarrotText.body2(
                  explanation,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 17,
                  ),
                ),
              ),
              if (child != null) ...[
                const CarrotSpacer.vertical(size: 9),
                child!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}
