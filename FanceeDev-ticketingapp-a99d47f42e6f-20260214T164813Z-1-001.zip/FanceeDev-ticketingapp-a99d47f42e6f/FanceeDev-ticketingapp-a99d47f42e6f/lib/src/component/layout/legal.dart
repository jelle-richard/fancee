import 'package:carrot/carrot.dart';

import 'sheet.dart';

class FTLayoutLegal extends StatelessWidget {
  final List<Widget> children;

  const FTLayoutLegal({
    super.key,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return FTLayoutSheet.singleChildScrollView(
      padding: const EdgeInsets.all(24),
      builder: (_) => CarrotContainer(
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.start,
          gap: 9,
          children: children,
        ),
      ),
    );
  }
}
