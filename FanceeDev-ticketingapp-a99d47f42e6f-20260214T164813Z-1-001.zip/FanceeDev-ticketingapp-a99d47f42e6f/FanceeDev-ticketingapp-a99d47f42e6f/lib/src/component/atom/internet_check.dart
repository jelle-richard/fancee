import 'dart:async';

import 'package:carrot/carrot.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

import '../../../l10n/l10n.dart';
import '../../data/data.dart';
import '../layout/layout.dart';

class FTInternetCheck extends StatefulWidget {
  final Widget child;

  const FTInternetCheck({
    super.key,
    required this.child,
  });

  @override
  createState() => _FTInternetCheckState();
}

class _FTInternetCheckState extends State<FTInternetCheck> {
  final Connectivity connectivity = Connectivity();
  late StreamSubscription<ConnectivityResult> subscription;

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    subscription = connectivity.onConnectivityChanged.listen(_onConnectivityChanged);
  }

  void _onConnectivityChanged(ConnectivityResult result) {
    context.read<FTAppStateBloc>().add(FTAppStateSetInternetAvailable(result != ConnectivityResult.none));
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FTAppStateBloc, FTAppState>(
      builder: (context, state) {
        if (!state.isInternetAvailable) {
          return FTLayoutEmptyView.illustration(
            explanation: context.strings.noInternetMessage,
            illustration: 'internet_check',
            title: context.strings.noInternetTitle,
          );
        }

        return widget.child;
      },
    );
  }
}
