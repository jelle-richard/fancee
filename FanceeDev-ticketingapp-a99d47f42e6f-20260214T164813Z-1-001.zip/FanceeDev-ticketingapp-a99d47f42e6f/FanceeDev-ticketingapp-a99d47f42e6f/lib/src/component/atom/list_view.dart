part of 'item_view.dart';

class FTListView extends _ItemView {
  const FTListView({
    super.key,
    required super.itemBuilder,
    required super.itemCount,
    super.headerBuilder,
    super.isReversed,
    super.padding,
    super.scrollController,
    super.separatorBuilder,
  });

  @override
  Widget _buildView(BuildContext context, _ItemViewState state) {
    if (state.widget.separatorBuilder != null) {
      return ListView.separated(
        itemBuilder: state._itemBuilder,
        itemCount: state._itemCount,
        separatorBuilder: state.widget.separatorBuilder!,
        padding: state.widget.padding,
        controller: state._scrollController,
        physics: const CarrotBouncingScrollPhysics.notAlways(),
        reverse: state.widget.isReversed,
        clipBehavior: Clip.antiAliasWithSaveLayer,
      );
    }

    return ListView.builder(
      itemBuilder: state._itemBuilder,
      itemCount: state._itemCount,
      padding: state.widget.padding,
      controller: state._scrollController,
      physics: const CarrotBouncingScrollPhysics.notAlways(),
      reverse: state.widget.isReversed,
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }
}
