import 'package:carrot/carrot.dart';

class FTMenuItem extends StatelessWidget {
  final String? icon;
  final String? iconAfter;
  final Widget label;
  final GestureTapCallback? onTap;

  const FTMenuItem({
    super.key,
    required this.label,
    this.icon,
    this.iconAfter,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return CarrotMenuItem(
      padding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 15,
      ),
      icon: icon,
      iconAfter: iconAfter,
      iconAfterColor: carrotTheme.gray[300],
      iconColor: carrotTheme.primary[400],
      label: DefaultTextStyle(
        style: carrotTheme.typography.body1.copyWith(
          color: carrotTheme.gray[700],
          fontWeight: FontWeight.w500,
        ),
        child: label,
      ),
      onTap: onTap,
    );
  }
}
