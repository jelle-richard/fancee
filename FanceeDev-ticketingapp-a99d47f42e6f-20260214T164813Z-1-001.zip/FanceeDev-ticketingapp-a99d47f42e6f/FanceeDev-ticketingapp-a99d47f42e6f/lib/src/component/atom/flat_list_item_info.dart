import 'package:carrot/carrot.dart';

import 'flat_list_item.dart';

class FTFlatListItemInfo extends StatelessWidget {
  final Text description;
  final String icon;
  final Text title;

  const FTFlatListItemInfo({
    super.key,
    required this.description,
    required this.icon,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return FTFlatListItem(
      icon: icon,
      child: CarrotColumn(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          DefaultTextStyle(
            style: context.carrotTypography.headline5,
            child: title,
          ),
          DefaultTextStyle(
            style: context.carrotTypography.body2,
            child: description,
          ),
        ],
      ),
    );
  }
}
