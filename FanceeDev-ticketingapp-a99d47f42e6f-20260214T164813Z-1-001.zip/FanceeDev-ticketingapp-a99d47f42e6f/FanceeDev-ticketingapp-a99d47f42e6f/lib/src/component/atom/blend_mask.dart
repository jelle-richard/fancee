import 'package:carrot/carrot.dart';
import 'package:flutter/rendering.dart';

class FTBlendMask extends SingleChildRenderObjectWidget {
  final BlendMode blendMode;
  final double opacity;

  const FTBlendMask({
    super.key,
    required super.child,
    this.blendMode = BlendMode.srcIn,
    this.opacity = 1,
  });

  @override
  RenderObject createRenderObject(BuildContext context) => FTBlendMaskRenderObject(blendMode, opacity);

  @override
  void updateRenderObject(BuildContext context, FTBlendMaskRenderObject renderObject) {
    renderObject
      ..blendMode = blendMode
      ..opacity = opacity;
  }
}

class FTBlendMaskRenderObject extends RenderProxyBox {
  BlendMode blendMode;
  double opacity;

  FTBlendMaskRenderObject(this.blendMode, this.opacity);

  @override
  void paint(PaintingContext context, Offset offset) {
    context.setWillChangeHint();

    context.canvas.saveLayer(
      offset & size,
      Paint()
        ..blendMode = blendMode
        ..color = Color.fromARGB((opacity * 255).round(), 255, 255, 255),
    );

    super.paint(context, offset);

    context.canvas.restore();
  }
}
