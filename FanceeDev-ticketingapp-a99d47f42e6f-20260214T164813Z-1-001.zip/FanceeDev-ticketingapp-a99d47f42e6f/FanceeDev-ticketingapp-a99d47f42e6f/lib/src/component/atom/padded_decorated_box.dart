import 'package:carrot/carrot.dart';

const _kDefaultPadding = EdgeInsets.symmetric(
  horizontal: 18,
  vertical: 12,
);

typedef FTPaddedDecoratedBoxDecorationBuilder = BoxDecoration Function(BuildContext);

class FTPaddedDecoratedBox extends StatelessWidget {
  final Widget child;
  final FTPaddedDecoratedBoxDecorationBuilder decorationBuilder;
  final EdgeInsets padding;

  const FTPaddedDecoratedBox({
    super.key,
    required this.child,
    required this.decorationBuilder,
    required this.padding,
  });

  const FTPaddedDecoratedBox.defaultPadding({
    super.key,
    required this.child,
    required this.decorationBuilder,
  }) : padding = _kDefaultPadding;

  const FTPaddedDecoratedBox.grayBox({
    super.key,
    required this.child,
  })  : decorationBuilder = _grayBoxBuilder,
        padding = _kDefaultPadding;

  const FTPaddedDecoratedBox.borderedBox({
    super.key,
    required this.child,
  })  : decorationBuilder = _borderedBoxBuilder,
        padding = const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 21,
        );

  FTPaddedDecoratedBox.borderedBoxWithTitle({
    Key? key,
    required Widget child,
    required Widget title,
  }) : this.borderedBox(
          key: key,
          child: CarrotColumn(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            gap: 9,
            children: [
              Builder(
                builder: (context) => DefaultTextStyle(
                  style: context.carrotTypography.headline5,
                  child: title,
                ),
              ),
              child,
            ],
          ),
        );

  factory FTPaddedDecoratedBox.devNameValue(String name, String value) => FTPaddedDecoratedBox.grayBox(
        child: CarrotRow(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              name,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
              ),
            ),
            Expanded(
              child: Text(
                value,
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontSize: 15,
                ),
              ),
            ),
          ],
        ),
      );

  factory FTPaddedDecoratedBox.devNameValues(String name, String values) => FTPaddedDecoratedBox.grayBox(
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              name,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              values,
              softWrap: true,
              style: const TextStyle(
                fontSize: 15,
              ),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: decorationBuilder(context),
      child: Padding(
        padding: padding,
        child: child,
      ),
    );
  }
}

BoxDecoration _borderedBoxBuilder(BuildContext context) {
  final carrotTheme = context.carrotTheme;

  return BoxDecoration(
    border: Border.all(
      color: carrotTheme.gray[100],
      width: 2,
    ),
    borderRadius: BorderRadius.circular(9),
  );
}

BoxDecoration _grayBoxBuilder(BuildContext context) {
  final carrotTheme = context.carrotTheme;

  return BoxDecoration(
    border: Border.all(
      color: carrotTheme.gray[100],
    ),
    borderRadius: BorderRadius.circular(9),
    color: carrotTheme.gray[25],
  );
}
