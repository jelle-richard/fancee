import 'package:carrot/carrot.dart';

class FTChartLegendColoredLabel extends StatelessWidget {
  final int amount;
  final Color color;
  final String label;

  const FTChartLegendColoredLabel({
    super.key,
    required this.amount,
    required this.color,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return CarrotRow(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      gap: 9,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: SizedBox.square(
            dimension: 9,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(9),
                color: color,
              ),
            ),
          ),
        ),
        Expanded(
          child: DefaultTextStyle(
            style: context.carrotTypography.body1.copyWith(
              fontSize: 13,
            ),
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: '${amount}x ',
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  TextSpan(
                    text: label,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
