import 'package:carrot/carrot.dart';

class FTIcon extends StatelessWidget {
  final Color? color;
  final String glyph;
  final EdgeInsets? margin;
  final double? size;

  const FTIcon({
    super.key,
    required this.glyph,
    this.color,
    this.margin,
    this.size,
  });

  @override
  Widget build(BuildContext context) {
    final icon = CarrotIcon(
      color: color,
      glyph: glyph,
      size: size,
    );

    if (margin == null) {
      return icon;
    }

    return Padding(
      padding: margin!,
      child: icon,
    );
  }
}
