import 'dart:math';

import 'package:carrot/carrot.dart';

import '../../config.dart';
import '../../theme.dart';
import '../../util/util.dart';

class FTGridBackground extends StatelessWidget {
  final Color backgroundColor;
  final Widget child;
  final bool enableAnimation;
  final Color lineColor;
  final double size;

  const FTGridBackground({
    super.key,
    required this.child,
    required this.backgroundColor,
    required this.lineColor,
    this.enableAnimation = false,
    this.size = 72,
  });

  @override
  Widget build(BuildContext context) {
    if (!enableAnimation) {
      return CustomPaint(
        isComplex: false,
        willChange: false,
        painter: _FTGridBackgroundPainter(
          backgroundColor: backgroundColor,
          lineColor: lineColor,
          size: size,
        ),
        child: child,
      );
    }

    return CarrotContinuousAnimationBuilder(
      builder: (context, animation) => CustomPaint(
        isComplex: false,
        willChange: false,
        painter: _FTGridBackgroundPainter(
          repaint: animation,
          backgroundColor: backgroundColor,
          lineColor: lineColor,
          size: size,
        ),
        child: child,
      ),
    );
  }
}

class _FTGridBackgroundPainter extends CustomPainter {
  static const animationDuration = 200;
  static const animationMax = 3000;

  final Color backgroundColor;
  final Color lineColor;
  final double size;

  final Paint _backgroundPainter;
  final Paint _linePainter;

  final _animations = <int, int>{};
  final _mulberry = Mulberry32(seed: 12);
  int _tick = 0;

  double get _cutoutSize => size / 6;

  _FTGridBackgroundPainter({
    super.repaint,
    required this.backgroundColor,
    required this.lineColor,
    required this.size,
  })  : _backgroundPainter = Paint()
          ..blendMode = BlendMode.srcOver
          ..color = backgroundColor,
        _linePainter = Paint()
          ..color = lineColor
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.miter
          ..strokeWidth = 2
          ..style = PaintingStyle.stroke;

  @override
  void paint(Canvas canvas, Size size) {
    ++_tick;

    final area = Offset.zero & size;

    int columns = (size.width / this.size).ceil();
    int rows = (size.height / this.size).ceil();
    Size diff = Size(
      (columns * this.size - size.width) / 2,
      (rows * this.size - size.height) / 2,
    );

    _drawBackground(
      canvas: canvas,
      area: area,
    );

    if (FTConfig.gridBackgroundPuzzleMode) {
      _drawPuzzle(
        canvas: canvas,
        size: size,
        rows: rows,
        columns: columns,
        diff: diff,
      );
    } else {
      _drawGrid(
        canvas: canvas,
        size: size,
        rows: rows,
        columns: columns,
        diff: diff,
      );
    }

    _drawMask(
      canvas: canvas,
      area: area,
    );
  }

  void _drawBackground({
    required Canvas canvas,
    required Rect area,
  }) {
    canvas.drawRect(area, _backgroundPainter);
  }

  void _drawMask({
    required Canvas canvas,
    required Rect area,
  }) {
    final overlayPainter = Paint()
      ..shader = LinearGradient(
        colors: [
          backgroundColor.withOpacity(0),
          backgroundColor,
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(area);

    canvas.drawRect(area, overlayPainter);
  }

  void _drawGrid({
    required Canvas canvas,
    required Size size,
    required int rows,
    required int columns,
    required Size diff,
  }) {
    for (int column = 0; column < columns; ++column) {
      double x = column * this.size - diff.width;

      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        _linePainter,
      );
    }

    for (int row = 0; row < rows; ++row) {
      double y = row * this.size - diff.height;

      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        _linePainter,
      );
    }
  }

  void _drawPuzzle({
    required Canvas canvas,
    required Size size,
    required int rows,
    required int columns,
    required Size diff,
  }) {
    for (int row = 0; row <= rows; ++row) {
      for (int column = 0; column <= columns; ++column) {
        final start = Point(column * this.size - diff.width, row * this.size - diff.height);
        final end = Point(start.x + this.size, start.y + this.size);
        final center = Point(start.x + this.size / 2, start.y + this.size / 2);

        _drawPuzzlePiece(
          canvas: canvas,
          size: size,
          rows: rows,
          columns: columns,
          diff: diff,
          column: column,
          row: row,
          start: start,
          end: end,
          center: center,
          index: row * columns + column,
        );
      }
    }
  }

  void _drawPuzzlePiece({
    required Canvas canvas,
    required Size size,
    required int rows,
    required int columns,
    required Size diff,
    required int column,
    required int row,
    required Point<double> start,
    required Point<double> end,
    required Point<double> center,
    required int index,
  }) {
    final horizontalPath = _layoutHorizontalPuzzleCutout(
      cutout: _cutoutSize,
      isReversed: index % 2 == 0,
      start: start,
      center: center,
      end: end,
    );

    final verticalPath = _layoutVerticalPuzzleCutout(
      cutout: _cutoutSize,
      isReversed: index % 2 == 0,
      start: start,
      center: center,
      end: end,
    );

    canvas.drawPath(
      horizontalPath,
      _linePainter,
    );

    canvas.drawPath(
      verticalPath,
      _linePainter,
    );

    if (row < 1 || row > 4) {
      return;
    }

    _checkAnimation(_getAnimationStart(index: index), (tickPosition) {
      _drawSparkleOverPath(
        canvas: canvas,
        path: horizontalPath,
        tickPosition: tickPosition,
        isReversed: column > columns / 2,
      );
    });

    _checkAnimation(_getAnimationStart(index: index, row: true), (tickPosition) {
      _drawSparkleOverPath(
        canvas: canvas,
        path: verticalPath,
        tickPosition: tickPosition,
        isReversed: index % 2 == 0,
      );
    });
  }

  void _checkAnimation(int start, void Function(double) animation) {
    final tick = _tick % animationMax;

    if (tick > start && tick < start + animationDuration) {
      animation((tick - start) / animationDuration);
    }
  }

  int _getAnimationStart({
    required int index,
    bool row = false,
  }) {
    if (row) {
      index += 1000;
    }

    return _animations.putIfAbsent(index, () => _mulberry.nextBetween(0, (animationMax - animationDuration).toDouble()).round());
  }

  @override
  bool shouldRepaint(_FTGridBackgroundPainter oldDelegate) {
    return oldDelegate.backgroundColor != backgroundColor || oldDelegate.lineColor != lineColor || oldDelegate.size != size;
  }
}

void _drawSparkleOverPath({
  required Canvas canvas,
  required Path path,
  required double tickPosition,
  required bool isReversed,
}) {
  double position = CarrotCurves.swiftOutCurve.transform(tickPosition);
  double opacity = 1;

  if (tickPosition < .3) {
    opacity = tickPosition / .3;
  }

  if (tickPosition > .5) {
    opacity = (1 - tickPosition) / .5;
  }

  if (isReversed) {
    position = 1 - position;
  }

  final offset = getPathOffsetAt(
    path: path,
    position: position,
  );

  canvas.drawCircle(
    offset,
    2,
    Paint()
      ..color = FTThemeColors.primary.withOpacity(opacity * .25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1),
  );
}

Path _layoutHorizontalPuzzleCutout({
  required double cutout,
  required bool isReversed,
  required Point<double> start,
  required Point<double> center,
  required Point<double> end,
}) {
  final cutoutOffsetH = cutout / (isReversed ? -2 : 2);

  return Path()
    ..moveTo(start.x, start.y)
    ..lineTo(center.x - cutout + 2, start.y)
    ..arcTo(
      Rect.fromPoints(
        Offset(center.x - cutout, start.y + cutoutOffsetH - cutout),
        Offset(center.x + cutout, start.y + cutoutOffsetH + cutout),
      ),
      isReversed ? radians(150) : radians(210),
      isReversed ? radians(240) : radians(-240),
      true,
    )
    ..moveTo(center.x + cutout - 2, start.y)
    ..lineTo(end.x, start.y);
}

Path _layoutVerticalPuzzleCutout({
  required double cutout,
  required bool isReversed,
  required Point<double> start,
  required Point<double> center,
  required Point<double> end,
}) {
  final cutoutOffsetV = cutout / (isReversed ? 2 : -2);

  return Path()
    ..moveTo(start.x, start.y)
    ..lineTo(start.x, center.y - cutout + 2)
    ..arcTo(
      Rect.fromPoints(
        Offset(start.x + cutoutOffsetV - cutout, center.y - cutout),
        Offset(start.x + cutoutOffsetV + cutout, center.y + cutout),
      ),
      isReversed ? radians(240) : radians(300),
      isReversed ? radians(240) : radians(-240),
      true,
    )
    ..moveTo(start.x, center.y + cutout - 2)
    ..lineTo(start.x, end.y);
}
