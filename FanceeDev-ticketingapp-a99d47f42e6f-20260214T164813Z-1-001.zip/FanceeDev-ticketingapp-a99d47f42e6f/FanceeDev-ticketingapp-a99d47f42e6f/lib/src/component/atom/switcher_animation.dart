import 'package:carrot/carrot.dart';

final _kDefaultCurve = CarrotCurves.springCriticallyDamped;
const _kDefaultDuration = Duration(milliseconds: 540);

class FTSwitcherAnimation extends StatelessWidget {
  final Widget? child;
  final Curve? curve;
  final Duration duration;
  final Duration switchInDurationExtra;

  const FTSwitcherAnimation({
    super.key,
    this.child,
    this.curve,
    this.duration = _kDefaultDuration,
    this.switchInDurationExtra = Duration.zero,
  });

  const FTSwitcherAnimation.conditional({
    super.key,
    required Widget child,
    required bool isVisible,
    this.curve,
    this.duration = _kDefaultDuration,
    this.switchInDurationExtra = Duration.zero,
  }) : child = isVisible ? child : null;

  @override
  Widget build(BuildContext context) {
    final curve = this.curve ?? _kDefaultCurve;

    return AnimatedSize(
      alignment: Alignment.center,
      clipBehavior: Clip.none,
      curve: curve,
      duration: duration + switchInDurationExtra,
      child: AnimatedSwitcher(
        duration: duration + switchInDurationExtra,
        reverseDuration: duration,
        switchInCurve: curve,
        switchOutCurve: curve.flipped,
        transitionBuilder: (child, animation) => AnimatedBuilder(
          animation: animation,
          builder: (context, child) => Opacity(
            opacity: animation.value.clamp(0, 1),
            child: Transform.scale(
              scale: animation.value,
              child: child,
            ),
          ),
          child: child,
        ),
        child: child,
      ),
    );
  }
}
