import 'dart:math' as math;

import 'package:carrot/carrot.dart';

part 'grid_view.dart';

part 'list_view.dart';

typedef FTItemViewHeaderBuilder = Widget Function(BuildContext, double);

abstract class _ItemView extends StatefulWidget {
  final FTItemViewHeaderBuilder? headerBuilder;
  final IndexedWidgetBuilder itemBuilder;
  final int itemCount;
  final bool isReversed;
  final EdgeInsets padding;
  final ScrollController? scrollController;
  final IndexedWidgetBuilder? separatorBuilder;

  const _ItemView({
    super.key,
    required this.itemBuilder,
    required this.itemCount,
    this.headerBuilder,
    this.isReversed = false,
    this.padding = EdgeInsets.zero,
    this.scrollController,
    this.separatorBuilder,
  });

  Widget _buildView(BuildContext context, _ItemViewState state);

  @override
  createState() => _ItemViewState();
}

class _ItemViewState extends State<_ItemView> {
  double _headerExtend = 0;
  late IndexedWidgetBuilder _itemBuilder;
  late int _itemCount;
  late ScrollController _scrollController;

  @override
  void didUpdateWidget(_ItemView oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.itemBuilder != oldWidget.itemBuilder || widget.itemCount != oldWidget.itemCount) {
      _initItemBuilder();
    }

    if (widget.scrollController != oldWidget.scrollController) {
      if (oldWidget.scrollController != null) {
        _scrollController.dispose();
      }

      _initScrollController();
    }

    setState(() {});
  }

  @override
  void dispose() {
    if (widget.scrollController == null) {
      _scrollController.dispose();
    }

    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _initItemBuilder();
    _initScrollController(false);

    onMounted(() {
      _scrollController.position.addListener(_onScrollPositionChanged);
    });
  }

  void _initItemBuilder() {
    _itemBuilder = widget.itemBuilder;
    _itemCount = widget.itemCount;

    if (widget.headerBuilder == null) {
      return;
    }

    ++_itemCount;

    _itemBuilder = (context, index) {
      if (index == 0) {
        return widget.headerBuilder!(context, math.max(0, _headerExtend));
      }

      return widget.itemBuilder(context, index - 1);
    };
  }

  void _initScrollController([bool addListener = true]) {
    _scrollController = widget.scrollController ?? ScrollController();

    if (addListener) {
      _scrollController.position.addListener(_onScrollPositionChanged);
    }
  }

  void _onScrollPositionChanged() {
    if (widget.headerBuilder == null) {
      return;
    }

    setState(() {
      _headerExtend = -_scrollController.position.pixels;
    });
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CarrotScrollbar(
        controller: _scrollController,
        child: widget._buildView(context, this),
      ),
    );
  }
}
