import 'package:carrot/carrot.dart';

class FTSmallLogo extends StatelessWidget {
  final double size;

  const FTSmallLogo({
    super.key,
    this.size = 150,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border.all(
          color: CarrotColors.grayBlue[850],
          width: 2.0,
        ),
        borderRadius: BorderRadius.circular(size * .25),
        boxShadow: CarrotShadows.xl,
      ),
      child: SizedBox(
        height: size,
        width: size,
        child: Padding(
          padding: const EdgeInsets.all(1),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(size * .24),
            clipBehavior: Clip.antiAlias,
            child: Image.asset(
              'assets/images/appicon.png',
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }
}
