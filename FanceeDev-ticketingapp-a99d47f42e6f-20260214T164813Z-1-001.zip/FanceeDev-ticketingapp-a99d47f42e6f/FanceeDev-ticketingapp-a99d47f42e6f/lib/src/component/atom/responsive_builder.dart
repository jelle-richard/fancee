import 'package:carrot/carrot.dart';

class FTResponsiveBuilder extends StatelessWidget {
  final WidgetBuilder large;
  final WidgetBuilder small;

  const FTResponsiveBuilder({
    super.key,
    required this.large,
    required this.small,
  });

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: context.mediaQuery.isPhone ? small : large,
    );
  }
}
