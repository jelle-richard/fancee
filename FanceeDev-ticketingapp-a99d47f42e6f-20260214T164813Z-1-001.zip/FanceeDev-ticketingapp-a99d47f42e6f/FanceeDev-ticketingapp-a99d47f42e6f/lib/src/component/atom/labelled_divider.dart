import 'package:carrot/carrot.dart';

class FTLabelledDivider extends StatelessWidget {
  final Color? color;
  final Widget label;
  final EdgeInsets margin;
  final double thickness;

  const FTLabelledDivider({
    super.key,
    required this.label,
    this.color,
    this.margin = const EdgeInsets.symmetric(
      horizontal: 0,
      vertical: 0,
    ),
    this.thickness = 2,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;
    final dividerColor = color ?? carrotTheme.gray[100];

    final divider = Expanded(
      child: CarrotMenuDivider.horizontal(
        color: dividerColor,
        margin: EdgeInsets.zero,
        thickness: thickness,
      ),
    );

    return Padding(
      padding: margin,
      child: CarrotRow(
        gap: 15,
        children: [
          divider,
          DefaultTextStyle(
            style: context.carrotTypography.body2.copyWith(
              color: carrotTheme.gray[400],
              fontSize: 12,
            ),
            child: label,
          ),
          divider,
        ],
      ),
    );
  }
}
