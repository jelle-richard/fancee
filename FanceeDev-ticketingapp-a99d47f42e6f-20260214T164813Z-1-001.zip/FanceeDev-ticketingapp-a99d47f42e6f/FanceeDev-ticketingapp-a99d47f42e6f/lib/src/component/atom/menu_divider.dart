import 'package:carrot/carrot.dart';

class FTMenuDivider extends StatelessWidget {
  final EdgeInsets margin;
  final double thickness;

  const FTMenuDivider({
    super.key,
    this.margin = const EdgeInsets.symmetric(
      horizontal: 30,
      vertical: 6,
    ),
    this.thickness = 2.0,
  });

  const FTMenuDivider.zero({
    super.key,
    this.margin = EdgeInsets.zero,
    this.thickness = 1.0,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return CarrotMenuDivider.horizontal(
      color: carrotTheme.gray[carrotTheme.resolve(100, 50)],
      margin: margin,
      thickness: thickness,
    );
  }
}
