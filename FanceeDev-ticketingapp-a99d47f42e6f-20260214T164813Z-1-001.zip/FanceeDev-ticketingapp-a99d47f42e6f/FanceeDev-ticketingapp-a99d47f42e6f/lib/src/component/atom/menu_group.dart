import 'package:carrot/carrot.dart';

class FTMenuGroup extends StatelessWidget {
  final List<Widget> children;

  const FTMenuGroup({
    super.key,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 21,
      ),
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: carrotTheme.borderRadius + BorderRadius.circular(1.5),
          color: carrotTheme.gray[100],
        ),
        child: Padding(
          padding: const EdgeInsets.all(1),
          child: ClipRRect(
            borderRadius: carrotTheme.borderRadius,
            child: CarrotColumn(
              children: children,
            ),
          ),
        ),
      ),
    );
  }
}
