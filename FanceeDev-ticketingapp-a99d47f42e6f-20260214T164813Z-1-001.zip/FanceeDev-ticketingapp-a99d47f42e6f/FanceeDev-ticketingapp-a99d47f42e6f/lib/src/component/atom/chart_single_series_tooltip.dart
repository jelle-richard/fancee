import 'package:carrot/carrot.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

typedef FTChartSingleSeriesTooltipBuilder<Data> = Widget Function(Data);

class FTChartSingleSeriesTooltip<Data> extends StatelessWidget {
  final FTChartSingleSeriesTooltipBuilder<Data> builder;
  final Data data;

  const FTChartSingleSeriesTooltip({
    super.key,
    required this.data,
    this.builder = _defaultBuilder,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        boxShadow: CarrotShadows.medium,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 9,
        ),
        child: DefaultTextStyle(
          style: TextStyle(
            color: context.carrotTheme.gray[25],
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
          child: builder(data),
        ),
      ),
    );
  }

  static TooltipBehavior asTooltipBehavior<Data>({
    required BuildContext context,
    required FTChartSingleSeriesTooltipBuilder<Data> builder,
    required List<Data> data,
  }) {
    return TooltipBehavior(
      color: context.carrotTheme.gray[900].withOpacity(.9),
      enable: true,
      shared: true,
      shouldAlwaysShow: true,
      builder: (_, __, ___, pointIndex, ____) => FTChartSingleSeriesTooltip<Data>(
        data: data[pointIndex],
        builder: builder,
      ),
    );
  }
}

Widget _defaultBuilder(dynamic data) {
  return Text(data.toString());
}
