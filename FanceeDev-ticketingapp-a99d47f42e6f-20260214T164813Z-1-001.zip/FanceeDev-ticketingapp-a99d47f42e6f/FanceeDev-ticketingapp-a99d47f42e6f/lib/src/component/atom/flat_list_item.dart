import 'package:carrot/carrot.dart';

const _kDefaultPadding = EdgeInsets.symmetric(
  horizontal: 21,
  vertical: 18,
);

class FTFlatListItem extends StatelessWidget {
  final bool _dismissible;
  final Widget child;
  final String? icon;
  final String? iconAfter;
  final EdgeInsets padding;
  final DismissDirectionCallback? onDismissed;
  final GestureTapCallback? onTap;

  const FTFlatListItem({
    super.key,
    required this.child,
    this.icon,
    this.iconAfter,
    this.padding = _kDefaultPadding,
    this.onTap,
  })  : _dismissible = false,
        onDismissed = null;

  const FTFlatListItem.dismissible({
    required super.key,
    required this.child,
    this.icon,
    this.iconAfter,
    this.padding = _kDefaultPadding,
    this.onDismissed,
    this.onTap,
  }) : _dismissible = true;

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    Widget content = CarrotBackgroundTap(
      background: carrotTheme.defaults.content,
      backgroundTap: carrotTheme.gray[50],
      curve: CarrotCurves.swiftOutCurve,
      duration: const Duration(milliseconds: 360),
      onTap: onTap,
      child: Padding(
        padding: padding,
        child: CarrotRow(
          crossAxisAlignment: CrossAxisAlignment.start,
          gap: 15,
          children: [
            if (icon != null)
              Padding(
                padding: const EdgeInsets.only(
                  top: 2,
                  bottom: 2,
                ),
                child: CarrotIcon(
                  color: carrotTheme.gray[400],
                  glyph: icon!,
                  size: 20,
                ),
              ),
            Expanded(
              child: child,
            ),
            if (iconAfter != null)
              Padding(
                padding: const EdgeInsets.only(
                  top: 2,
                  bottom: 2,
                ),
                child: CarrotIcon(
                  color: carrotTheme.gray[400],
                  glyph: iconAfter!,
                  size: 20,
                ),
              ),
          ],
        ),
      ),
    );

    if (_dismissible) {
      content = ClipRRect(
        borderRadius: BorderRadius.circular(3),
        clipBehavior: Clip.hardEdge,
        child: Dismissible(
          key: key!,
          background: DecoratedBox(
            decoration: BoxDecoration(
              color: carrotTheme.defaults.error,
            ),
          ),
          direction: DismissDirection.endToStart,
          onDismissed: onDismissed,
          child: content,
        ),
      );
    }

    return content;
  }
}

class FTFlatListItemButton extends StatelessWidget {
  final Widget child;
  final String? icon;
  final String? iconAfter;
  final GestureTapCallback? onTap;

  const FTFlatListItemButton({
    super.key,
    required this.child,
    this.icon,
    this.iconAfter,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return FTFlatListItem(
      icon: icon,
      iconAfter: iconAfter,
      onTap: onTap,
      child: DefaultTextStyle(
        style: context.carrotTypography.body2.copyWith(
          fontWeight: FontWeight.w600,
        ),
        child: child,
      ),
    );
  }
}
