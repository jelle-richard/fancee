import 'package:carrot/carrot.dart';

/// This widget should only be used when a view is not quite ready
/// due to some missing widgets. Before release, all occurrences of
/// this widget should be replaced by the actual widgets.
class FTPlaceholder extends StatelessWidget {
  final String reason;

  const FTPlaceholder({
    super.key,
    required this.reason,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: FTPlaceholderInline(
        reason: reason,
      ),
    );
  }
}

/// This widget should only be used when a view is not quite ready
/// due to some missing widgets. Before release, all occurrences of
/// this widget should be replaced by the actual widgets.
class FTPlaceholderInline extends StatelessWidget {
  final String reason;

  const FTPlaceholderInline({
    super.key,
    required this.reason,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border.all(
          color: carrotTheme.resolve(carrotTheme.primary[100], carrotTheme.gray[100]),
          style: BorderStyle.solid,
          width: 1,
        ),
        borderRadius: BorderRadius.circular(12),
        color: carrotTheme.resolve(carrotTheme.primary[50], carrotTheme.gray[50]),
      ),
      child: Padding(
        padding: const EdgeInsets.all(42),
        child: Center(
          child: Text(
            'Placeholder — $reason',
            style: TextStyle(
              color: carrotTheme.primary,
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
