import 'dart:math' as math;

import 'package:carrot/carrot.dart';

class FTSpinner extends StatefulWidget {
  final Color? background;
  final Color? color;
  final Color? colorSecondary;
  final double size;
  final double thickness;

  const FTSpinner({
    super.key,
    this.background,
    this.color,
    this.colorSecondary,
    this.size = 30,
    this.thickness = 6,
  });

  @override
  createState() => _FTSpinnerState();
}

class _FTSpinnerState extends State<FTSpinner> with TickerProviderStateMixin {
  late AnimationController _primaryController;
  late AnimationController _secondaryController;
  late Animation<double> _primaryAnimation;
  late Animation<double> _secondaryAnimation;

  @override
  void dispose() {
    _primaryController.dispose();
    _secondaryController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    _primaryController = AnimationController(
      duration: const Duration(milliseconds: 840),
      vsync: this,
    );

    _secondaryController = AnimationController(
      duration: const Duration(milliseconds: 840),
      vsync: this,
    );

    _primaryAnimation = Tween(begin: 0.0, end: 1.0).animate(_primaryController.curved(
      CarrotCurves.swiftOutCurve,
    ));

    _secondaryAnimation = Tween(begin: 0.0, end: 1.0).animate(_secondaryController.curved(
      CarrotCurves.swiftOutCurve,
    ));

    Future.delayed(const Duration(milliseconds: 1), () {
      if (!mounted) {
        return;
      }

      _primaryController.repeat();
    });

    Future.delayed(const Duration(milliseconds: 150), () {
      if (!mounted) {
        return;
      }

      _secondaryController.repeat();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: RepaintBoundary(
        child: CustomPaint(
          painter: _FTSpinnerPainter(
            primaryAnimation: _primaryAnimation,
            secondaryAnimation: _secondaryAnimation,
            background: widget.background ?? context.carrotTheme.gray[200],
            color: widget.color ?? context.carrotTheme.primary,
            colorSecondary: widget.colorSecondary ?? context.carrotTheme.primary[200].withOpacity(.5),
            thickness: widget.thickness,
          ),
          child: SizedBox.square(
            dimension: widget.size,
          ),
        ),
      ),
    );
  }
}

class _FTSpinnerPainter extends CustomPainter {
  final Animation<double> primaryAnimation;
  final Animation<double> secondaryAnimation;
  final Color background;
  final Color color;
  final Color colorSecondary;
  final double thickness;

  final Paint _backgroundPaint;
  final Paint _primaryStrokePaint;
  final Paint _secondaryStrokePaint;

  _FTSpinnerPainter({
    required this.primaryAnimation,
    required this.secondaryAnimation,
    required this.background,
    required this.color,
    required this.colorSecondary,
    required this.thickness,
  })  : _backgroundPaint = Paint()
          ..color = background
          ..isAntiAlias = true
          ..strokeCap = StrokeCap.round
          ..strokeWidth = thickness
          ..style = PaintingStyle.stroke,
        _primaryStrokePaint = Paint()
          ..color = color
          ..isAntiAlias = true
          ..strokeCap = StrokeCap.round
          ..strokeWidth = thickness
          ..style = PaintingStyle.stroke,
        _secondaryStrokePaint = Paint()
          ..color = colorSecondary
          ..isAntiAlias = true
          ..strokeCap = StrokeCap.round
          ..strokeWidth = thickness
          ..style = PaintingStyle.stroke,
        super(repaint: primaryAnimation);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromPoints(Offset.zero, Offset(size.width, size.height));
    final arc = _radians(60);
    final rotation = _radians(primaryAnimation.value * 360 - 60);
    final rotationSecondary = _radians(secondaryAnimation.value * 360 - 60);

    canvas.drawArc(rect, 0, _radians(360), false, _backgroundPaint);
    canvas.drawArc(rect, rotationSecondary, -arc, false, _secondaryStrokePaint);
    canvas.drawArc(rect, rotation, -arc, false, _primaryStrokePaint);
  }

  @override
  bool shouldRepaint(_FTSpinnerPainter oldDelegate) {
    return false;
  }
}

/// Calculates the radians of the given [angle].
double _radians(double angle) {
  return math.pi / 180 * angle;
}
