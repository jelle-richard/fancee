import 'dart:convert';
import 'dart:io';

import 'package:carrot/carrot.dart';

/// The widget [FTJsonViewer] is not actually used, but useful
/// while developing the app.
class FTJsonViewer extends StatelessWidget {
  final dynamic json;

  const FTJsonViewer({
    super.key,
    required this.json,
  });

  @override
  Widget build(BuildContext context) {
    const encoder = JsonEncoder.withIndent('  ');
    final formatted = encoder.convert(json);

    return Text(
      formatted,
      style: TextStyle(
        color: context.carrotTheme.gray[700],
        fontFamily: Platform.isIOS ? 'Courier' : 'monospace',
        fontSize: 10,
        height: 1.4,
      ),
      textAlign: TextAlign.left,
    );
  }
}
