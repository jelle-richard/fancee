part of 'item_view.dart';

class FTGridView extends _ItemView {
  final double aspectRatio;
  final int columns;
  final double spacing;

  const FTGridView({
    super.key,
    required super.itemBuilder,
    required super.itemCount,
    super.headerBuilder,
    super.isReversed,
    super.padding,
    super.scrollController,
    this.aspectRatio = 1,
    this.columns = 2,
    this.spacing = 0,
  })  : assert(columns > 1),
        assert(spacing >= 0);

  @override
  Widget _buildView(BuildContext context, _ItemViewState state) {
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        childAspectRatio: aspectRatio,
        crossAxisCount: columns,
        crossAxisSpacing: spacing,
        mainAxisSpacing: spacing,
      ),
      itemBuilder: state._itemBuilder,
      itemCount: state._itemCount,
      padding: state.widget.padding,
      controller: state._scrollController,
      physics: const CarrotBouncingScrollPhysics.notAlways(),
      reverse: state.widget.isReversed,
      clipBehavior: Clip.antiAliasWithSaveLayer,
    );
  }
}
