import 'package:carrot/carrot.dart';

class FTLabel extends StatelessWidget {
  final Widget child;
  final Color? backgroundColor;
  final Color? borderColor;
  final Color? foregroundColor;

  const FTLabel({
    super.key,
    required this.child,
    this.backgroundColor,
    this.borderColor,
    this.foregroundColor,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border.all(
          color: borderColor ?? carrotTheme.gray[150],
          width: 1,
        ),
        borderRadius: BorderRadius.circular(18),
        color: backgroundColor ?? carrotTheme.gray[100],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 15,
          vertical: 9,
        ),
        child: DefaultTextStyle(
          style: carrotTheme.typography.body1.copyWith(
            color: foregroundColor ?? carrotTheme.gray[700],
            fontSize: 12,
            fontWeight: FontWeight.w700,
            height: 1.4,
            overflow: TextOverflow.ellipsis,
          ),
          child: child,
        ),
      ),
    );
  }
}
