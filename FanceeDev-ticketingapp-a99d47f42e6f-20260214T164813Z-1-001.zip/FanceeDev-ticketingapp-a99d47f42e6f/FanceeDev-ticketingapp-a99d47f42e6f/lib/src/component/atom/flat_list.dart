import 'package:carrot/carrot.dart';

class FTFlatList extends StatelessWidget {
  final List<Widget> children;

  const FTFlatList({
    super.key,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border.all(
          color: carrotTheme.gray[100],
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: const EdgeInsets.all(1),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15),
          clipBehavior: Clip.hardEdge,
          child: ListView.separated(
            itemBuilder: (context, index) => children[index],
            itemCount: children.length,
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (context, index) => const CarrotMenuDivider.horizontal(
              margin: EdgeInsets.zero,
              thickness: 1.0,
            ),
          ),
        ),
      ),
    );
  }
}
