import 'package:carrot/carrot.dart';

import '../layout/layout.dart';

class FTScrollViewConstraints extends StatelessWidget {
  final Widget child;

  const FTScrollViewConstraints({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final scaffold = context.carrotScaffold;
    final screen = MediaQuery.of(context).size;

    double height = screen.height - scaffold.appBarSize.height - scaffold.bottomBarSize.height;

    final safeAreaWidget = context.findAncestorWidgetOfExactType<CarrotBodySafeArea>();
    if (safeAreaWidget != null) {
      height -= safeAreaWidget.extraPadding.vertical;
    }

    final sheetLayoutWidget = context.findAncestorWidgetOfExactType<FTLayoutSheet>();
    if (sheetLayoutWidget != null) {
      height -= sheetLayoutWidget.padding.vertical;
    }

    return ConstrainedBox(
      constraints: BoxConstraints(
        minHeight: height.clamp(0, double.infinity),
      ),
      child: IntrinsicHeight(
        child: child,
      ),
    );
  }
}
