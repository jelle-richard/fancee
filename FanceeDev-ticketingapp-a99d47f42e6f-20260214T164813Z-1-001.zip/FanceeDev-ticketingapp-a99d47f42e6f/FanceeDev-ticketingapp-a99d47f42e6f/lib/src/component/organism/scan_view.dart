import 'package:carrot/carrot.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../../l10n/l10n.dart';
import '../../data/data.dart';
import '../../module/permissions/permissions.dart';
import '../../util/util.dart';
import '../atom/atom.dart';

typedef FTScanViewScanCallback = Function(Barcode);

class FTScanView extends StatefulWidget {
  final bool canRotateCamera;
  final bool canToggleFlashlight;
  final List<Widget> actions;
  final List<Widget> children;
  final GestureTapCallback onRequestBack;
  final FTScanViewScanCallback onScan;

  const FTScanView({
    super.key,
    required this.onRequestBack,
    required this.onScan,
    this.canRotateCamera = true,
    this.canToggleFlashlight = true,
    this.actions = const [],
    this.children = const [],
  });

  @override
  createState() => _FTScanViewState();
}

class _FTScanViewState extends State<FTScanView> {
  final List<Offset> _barcodeOffsets = [];
  MobileScannerController? _controller;
  bool _isCameraAccessDenied = false;
  bool _isProcessing = false;

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _init();
  }

  void _init() async {
    var cameraPermissionStatus = await FTPlatformPermissions.camera;

    if (cameraPermissionStatus == FTPermissionStatus.denied) {
      cameraPermissionStatus = await FTPlatformPermissions.requestCamera();
    }

    if (cameraPermissionStatus != FTPermissionStatus.granted) {
      setState(() {
        _isCameraAccessDenied = true;
      });
    } else {
      setState(() {
        _initScanController();
      });
    }
  }

  void _initScanController() {
    final userSettings = context.read<FTUserStateBloc>();

    _controller = MobileScannerController(
      autoStart: false,
      detectionSpeed: DetectionSpeed.noDuplicates,
      facing: userSettings.state.scannerCameraFrontFacing ? CameraFacing.front : CameraFacing.back,
      formats: [
        BarcodeFormat.qrCode,
      ],
      torchEnabled: false,
    );

    if (!_controller!.isStarting) {
      _controller!.start();
    }

    if (userSettings.state.scannerCameraFlashlight) {
      /// note(Bas): The delay is needed here, because the mobile_scanner
      ///  package turns the flashlight off immediately when loading the
      ///  camera view.
      Future.delayed(const Duration(milliseconds: 300), () {
        _controller!.toggleTorch();
      });
    }
  }

  void _onBarcodeDetected(BarcodeCapture capture) {
    if (capture.barcodes.isEmpty || _isProcessing) {
      return;
    }

    final barcode = capture.barcodes.first;

    if (barcode.rawValue == null) {
      return;
    }

    _isProcessing = true;
    _controller!.stop();

    setState(() {
      _barcodeOffsets.clear();
      _barcodeOffsets.addAll(barcode.corners!);
    });

    widget.onScan(barcode);
  }

  void _onRotateCameraTap() async {
    if (_controller!.facing == CameraFacing.back && _controller!.torchState.value == TorchState.on) {
      await _controller!.toggleTorch();
    }

    await _controller!.switchCamera();
  }

  void _onToggleFlashlightTap() async {
    await _controller!.toggleTorch();
  }

  @override
  Widget build(BuildContext context) {
    if (_isCameraAccessDenied) {
      return _FTPermissionNeededView(
        onRequestBack: widget.onRequestBack,
      );
    }

    if (_controller == null) {
      // note: probably loading or waiting for a permission request.
      return const DecoratedBox(
        decoration: BoxDecoration(
          color: CarrotColors.black,
        ),
      );
    }

    return DecoratedBox(
      decoration: const BoxDecoration(
        color: CarrotColors.black,
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: _FTCamera(
              barcodeOffsets: const [],
              controller: _controller!,
              onBarcodeDetected: _onBarcodeDetected,
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: ValueListenableBuilder(
              valueListenable: _controller!.torchState,
              builder: (context, torchState, _) => ValueListenableBuilder(
                valueListenable: _controller!.cameraFacingState,
                builder: (controller, facingState, _) => _FTActions(
                  children: [
                    ...widget.actions,
                    FTSwitcherAnimation.conditional(
                      isVisible: widget.canToggleFlashlight && facingState == CameraFacing.back,
                      child: FTScanViewAction(
                        key: const ValueKey('flashlight-toggle'),
                        icon: torchState == TorchState.off ? 'bolt' : 'bolt-slash',
                        onTap: _onToggleFlashlightTap,
                      ),
                    ),
                    FTSwitcherAnimation.conditional(
                      isVisible: widget.canRotateCamera,
                      child: FTScanViewAction(
                        key: const ValueKey('camera-facing-toggle'),
                        icon: facingState == CameraFacing.back ? 'image-polaroid-user' : 'image-polaroid',
                        onTap: _onRotateCameraTap,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          ...widget.children,
        ],
      ),
    );
  }
}

class FTScanViewAction extends StatelessWidget {
  final String? icon;
  final String? label;
  final GestureTapCallback? onTap;

  const FTScanViewAction({
    super.key,
    this.icon,
    this.label,
    this.onTap,
  }) : assert(!(icon == null && label == null));

  @override
  Widget build(BuildContext context) {
    return CarrotBounceTap(
      onTap: onTap,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: context.carrotTheme.gray[25],
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FTSwitcherAnimation(
            child: CarrotRow(
              key: ValueKey('$icon $label'),
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              gap: 3,
              children: [
                if (icon != null)
                  CarrotIcon(
                    glyph: icon!,
                    size: 20,
                  ),
                if (label != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 3),
                      child: Text(
                        label!,
                        style: context.carrotTypography.body1.copyWith(
                          fontWeight: FontWeight.w700,
                          height: 1,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FTActions extends StatelessWidget {
  final List<Widget> children;

  const _FTActions({
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: context.safeAreaReal.add(const EdgeInsets.symmetric(
        horizontal: 30,
        vertical: 21,
      )),
      child: CarrotRow(
        gap: 9,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: children,
      ),
    );
  }
}

class _FTCamera extends StatelessWidget {
  final List<Offset> barcodeOffsets;
  final MobileScannerController controller;
  final Function(BarcodeCapture) onBarcodeDetected;

  const _FTCamera({
    required this.barcodeOffsets,
    required this.controller,
    required this.onBarcodeDetected,
  });

  @override
  Widget build(BuildContext context) {
    final orientation = context.mediaQuery.orientation;
    double angle = 0;

    switch (orientation) {
      case Orientation.portrait:
        break;
      case Orientation.landscape:
        angle = radians(-90);
        break;
    }

    return ValueListenableBuilder<MobileScannerArguments?>(
      valueListenable: controller.startArguments,
      builder: (context, value, _) {
        final viewSize = MediaQuery.of(context).size;
        final size = value?.size ?? viewSize;
        final ratio = size.height / size.width;

        return FittedBox(
          alignment: Alignment.center,
          clipBehavior: Clip.hardEdge,
          fit: BoxFit.contain,
          child: SizedBox(
            height: ratio * viewSize.width,
            width: viewSize.width,
            child: Transform.rotate(
              angle: angle,
              child: MobileScanner(
                controller: controller,
                onDetect: onBarcodeDetected,
              ),
            ),
          ),
        );
      },
    );
  }
}

class _FTPermissionNeededView extends StatelessWidget {
  final GestureTapCallback onRequestBack;

  const _FTPermissionNeededView({
    required this.onRequestBack,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        color: CarrotColors.black,
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Padding(
              padding: const EdgeInsets.all(30),
              child: CarrotColumn(
                gap: 15,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CarrotIcon(
                    color: CarrotColors.white,
                    glyph: 'camera-slash',
                    size: 30,
                  ),
                  Text(
                    context.strings.scannerPermissionNeededTitle,
                    style: context.carrotTypography.headline4.copyWith(
                      color: CarrotColors.white,
                    ),
                  ),
                  Text(
                    context.strings.scannerPermissionNeededDescription,
                    textAlign: TextAlign.center,
                    style: context.carrotTypography.body1.copyWith(
                      color: CarrotColors.white,
                    ),
                  ),
                  const CarrotSpacer.vertical(
                    size: 15,
                  ),
                  FTScanViewAction(
                    icon: 'circle-arrow-up-right',
                    label: context.strings.scannerPermissionNeededLaunchSettings,
                    onTap: () async {
                      await FTPlatformPermissions.launchAppSettings();
                    },
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: _FTActions(
              children: [
                const CarrotFiller(),
                FTScanViewAction(
                  icon: 'chevron-left',
                  label: 'Back',
                  onTap: onRequestBack,
                ),
                const CarrotFiller(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
