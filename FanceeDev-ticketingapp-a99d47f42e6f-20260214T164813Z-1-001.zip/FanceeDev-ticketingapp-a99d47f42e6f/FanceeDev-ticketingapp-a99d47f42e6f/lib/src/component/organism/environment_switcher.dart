import 'package:carrot/carrot.dart';

import '../../data/data.dart';
import '../molecule/molecule.dart';

class FTEnvironmentSwitcherDialog extends CarrotDialog<void> {
  const FTEnvironmentSwitcherDialog({
    super.key,
    required super.close,
  });

  @override
  Widget? buildFooter(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    final environment = FTEnvironment.of(context);

    return Padding(
      padding: const EdgeInsets.only(
        bottom: 12,
      ),
      child: CarrotMenu(
        children: FTEnvironment.all
            .map((env) => CarrotMenuItem(
                  icon: env.icon,
                  iconAfter: 'circle-arrow-right',
                  label: Text(
                    env.name,
                    style: context.carrotTypography.body1.copyWith(
                      fontWeight: env == environment ? FontWeight.w700 : FontWeight.w400,
                    ),
                  ),
                  onTap: () {
                    _switchEnvironment(context, env);
                    close();
                  },
                ))
            .toList(),
      ),
    );
  }

  @override
  Widget? buildHeader(BuildContext context, ScrollController scrollController, Size headerSize, Size footerSize) {
    return const FTDialogHeader(
      title: Text('Switch Environment'),
      body: Text('Choose which environment to use. When the environment is changed, you will be signed off.'),
    );
  }

  void _switchEnvironment(BuildContext context, FTEnvironment environment) {
    context.read<FTAppStateBloc>().add(FTAppStateSetEnvironment(environment));
  }
}
