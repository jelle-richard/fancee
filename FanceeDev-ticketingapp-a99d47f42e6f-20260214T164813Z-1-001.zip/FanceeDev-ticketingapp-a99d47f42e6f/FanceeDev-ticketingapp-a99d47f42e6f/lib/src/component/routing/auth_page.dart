import 'package:carrot/carrot.dart';

class FTAuthPage<T> extends CarrotPage<T> {
  const FTAuthPage({
    super.key,
    required super.child,
    super.arguments,
    super.name,
    super.restorationId,
    super.barrierColor,
    super.barrierDismissible,
    super.barrierLabel,
    super.fullscreenDialog,
    super.maintainState,
    super.opaque,
    super.transitionDuration,
  });

  @override
  Route<T> createRoute(BuildContext context) => FTAuthPageRoute<T>(this);
}

class FTAuthPageRoute<T> extends CarrotPageRoute<T> {
  static final _offsetTween = TweenSequence<Offset>([
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(Offset.zero)),
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: const Offset(15, 0), end: Offset.zero)),
  ]);

  static final _opacityTween = TweenSequence<double>([
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(.0)),
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: 0, end: 1)),
  ]);

  static final _reverseOffsetTween = TweenSequence<Offset>([
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: Offset.zero, end: const Offset(-15, 0))),
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(Offset.zero)),
  ]);

  static final _reverseOpacityTween = TweenSequence<double>([
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: 1, end: 0)),
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(0)),
  ]);

  FTAuthPageRoute(super.page);

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation, Widget child) {
    if (fullscreenDialog) {
      return child;
    }

    final reverse = animation.status == AnimationStatus.completed;
    final controller = (reverse ? secondaryAnimation : animation).curved(CarrotCurves.swiftOutCurve);

    return AnimatedBuilder(
      animation: controller,
      child: CarrotBackGestureDetector(
        enabledCallback: () => isPopGestureEnabled,
        onStartPopGesture: startPopGesture,
        child: child,
      ),
      builder: (context, child) {
        final offset = (reverse ? _reverseOffsetTween : _offsetTween).evaluate(controller);
        final opacity = (reverse ? _reverseOpacityTween : _opacityTween).evaluate(controller);

        return Opacity(
          opacity: opacity,
          child: Transform.translate(
            offset: offset,
            child: child,
          ),
        );
      },
    );
  }
}
