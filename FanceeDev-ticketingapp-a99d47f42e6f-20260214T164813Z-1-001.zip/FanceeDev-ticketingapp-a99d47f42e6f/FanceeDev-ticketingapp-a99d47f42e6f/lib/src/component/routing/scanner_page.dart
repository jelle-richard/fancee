import 'package:carrot/carrot.dart';

class FTScannerPage<T> extends CarrotPage<T> {
  const FTScannerPage({
    super.key,
    required super.child,
    super.arguments,
    super.name,
    super.restorationId,
    super.barrierColor,
    super.barrierDismissible,
    super.barrierLabel,
    super.fullscreenDialog,
    super.maintainState,
    super.opaque,
    super.transitionDuration,
  });

  @override
  Route<T> createRoute(BuildContext context) => FTScannerPageRoute<T>(this);
}

class FTScannerPageRoute<T> extends CarrotPageRoute<T> {
  static final _scaleTween = TweenSequence<double>([
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(1.1)),
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: 1.1, end: 1)),
  ]);

  static final _opacityTween = TweenSequence<double>([
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(.0)),
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: 0, end: 1)),
  ]);

  static final _reverseScaleTween = TweenSequence<double>([
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: 1, end: 1.1)),
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(1.1)),
  ]);

  static final _reverseOpacityTween = TweenSequence<double>([
    TweenSequenceItem(weight: 50.0, tween: Tween(begin: 1, end: 0)),
    TweenSequenceItem(weight: 50.0, tween: ConstantTween(0)),
  ]);

  FTScannerPageRoute(super.page);

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation, Widget child) {
    if (fullscreenDialog) {
      return child;
    }

    final reverse = animation.status == AnimationStatus.completed;
    final controller = (reverse ? secondaryAnimation : animation).curved(CarrotCurves.swiftOutCurve);

    return AnimatedBuilder(
      animation: controller,
      child: CarrotBackGestureDetector(
        enabledCallback: () => isPopGestureEnabled,
        onStartPopGesture: startPopGesture,
        child: child,
      ),
      builder: (context, child) {
        final opacity = (reverse ? _reverseOpacityTween : _opacityTween).evaluate(controller);
        final scale = (reverse ? _reverseScaleTween : _scaleTween).evaluate(controller);

        return Opacity(
          opacity: opacity,
          child: Transform.scale(
            scale: scale,
            child: child,
          ),
        );
      },
    );
  }
}
