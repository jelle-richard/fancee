import 'package:carrot/carrot.dart';

import 'auth_page.dart';
import 'scanner_page.dart';

class FTRoute extends CarrotRoute {
  FTRoute({
    required super.builder,
    required super.path,
    super.arguments,
    super.nameGenerator,
    super.parentNavigatorKey,
    super.redirect,
    super.routes,
  }) : super.defaultTransition();

  FTRoute.auth({
    required CarrotRouteWidgetBuilder builder,
    required super.path,
    super.redirect,
    super.routes = const [],
    super.name,
    super.parentNavigatorKey,
    Object? arguments,
    CarrotRouteNameGenerator? nameGenerator,
  }) : super.customPage(
          pageBuilder: (context, state) => FTAuthPage<void>(
            key: state.pageKey,
            arguments: arguments,
            name: nameGenerator?.call(context, state),
            child: builder(context, state),
          ),
        );

  FTRoute.scanner({
    required CarrotRouteWidgetBuilder builder,
    required super.path,
    super.redirect,
    super.routes = const [],
    super.name,
    super.parentNavigatorKey,
    Object? arguments,
    CarrotRouteNameGenerator? nameGenerator,
  }) : super.customPage(
          pageBuilder: (context, state) => FTScannerPage<void>(
            key: state.pageKey,
            arguments: arguments,
            name: nameGenerator?.call(context, state),
            child: builder(context, state),
          ),
        );
}
