import 'package:intl/intl.dart';

final _apiFormat = DateFormat('yyyy-MM-dd HH:mm:ss');

extension FTDateTimeExtension on DateTime {
  String formatForApi() => _apiFormat.format(this);
}

String formatForApi(DateTime dateTime) {
  return _apiFormat.format(dateTime);
}
