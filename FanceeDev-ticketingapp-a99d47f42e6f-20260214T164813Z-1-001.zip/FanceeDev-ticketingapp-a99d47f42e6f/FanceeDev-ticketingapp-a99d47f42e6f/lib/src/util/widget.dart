import 'package:carrot/carrot.dart';

class FTFoundWidget {
  final Offset offset;
  final Size size;

  const FTFoundWidget({
    required this.offset,
    required this.size,
  });

  const FTFoundWidget.empty()
      : this(
          offset: Offset.zero,
          size: Size.zero,
        );
}

/// Finds the position and size of the widget with the given key.
FTFoundWidget findWidget(GlobalKey key) {
  final renderBox = key.currentContext?.findRenderObject() as RenderBox?;

  if (renderBox == null) {
    return const FTFoundWidget.empty();
  }

  return FTFoundWidget(
    offset: renderBox.localToGlobal(Offset.zero),
    size: renderBox.size,
  );
}

// Finds the position of the widget with the given key.
Offset findWidgetOffset(GlobalKey key) {
  return findWidget(key).offset;
}

// Finds the size of the widget with the given key.
Size findWidgetSize(GlobalKey key) {
  return findWidget(key).size;
}
