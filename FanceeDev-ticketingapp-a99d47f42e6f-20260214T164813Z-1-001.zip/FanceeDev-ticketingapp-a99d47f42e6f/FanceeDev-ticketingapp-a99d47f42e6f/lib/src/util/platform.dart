import 'dart:io' show Platform;

/// Returns TRUE if we're unit testing.
bool isUnitTesting() {
  return Platform.environment.containsKey('FLUTTER_TEST');
}
