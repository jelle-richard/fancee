import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:network_info_plus/network_info_plus.dart';

import 'platform.dart';

const _kDefaultTimeout = Duration(milliseconds: 500);

final _connectivity = Connectivity();
final _networkInfo = NetworkInfo();

/// Gets the current connectivity state.
Future<ConnectivityResult> getConnectivityState() async {
  return await _connectivity.checkConnectivity();
}

/// Gets the local IPv4 address, but only when the device is connected
/// via ethernet or wifi.
Future<String?> getLocalIPv4Address() async {
  if (!isUnitTesting()) {
    final connectivity = await _connectivity.checkConnectivity();

    if (connectivity == ConnectivityResult.ethernet || connectivity == ConnectivityResult.wifi) {
      return _networkInfo.getWifiIP();
    }
  }

  return null;
}

/// Gets all the devices in the subnet of the given [localIp]. The devices
/// must be online and listen to the given [port]. When the given [timeout]
/// is past, the device is assumed offline.
Future<List<String>> getLocalIPv4Devices(String localIp, int port, [Duration timeout = _kDefaultTimeout]) async {
  final devices = <String>[];
  final subnet = localIp.substring(0, localIp.lastIndexOf('.'));
  final addresses = List<String>.generate(256, (index) => '$subnet.$index');
  final results = await Future.wait(addresses.map((address) => isHostUp(address, port, timeout)));

  for (int i = 0; i < 256; ++i) {
    if (!results[i]) {
      continue;
    }

    devices.add(addresses[i]);
  }

  return devices;
}

/// Returns TRUE if the given [host] is online on port [port]. The host is
/// assumed offline after the given [timeout] period.
Future<bool> isHostUp(String ipAddress, int port, [Duration timeout = _kDefaultTimeout]) async {
  try {
    final socket = await Socket.connect(
      ipAddress,
      port,
      timeout: timeout,
    );
    await socket.close();
    socket.destroy();

    return true;
  } catch (_) {
    return false;
  }
}

/// Finds devices in the given [subnet] that listen on the given [port]. When [localIp]
/// is not null, that particular ip address will not be checked.
Stream<FTNetworkDiscoveryResult> discoverNetworkDevices(
  String subnet,
  int port, {
  String? localIp,
  Duration timeout = _kDefaultTimeout,
}) async* {
  final addresses = List<String>.generate(256, (index) => '$subnet.$index').where((address) => address != localIp).toList();
  final results = await Future.wait(addresses.map((address) => isHostUp(address, port, timeout)));

  for (int i = 0; i < 256; ++i) {
    final address = addresses[i];
    final up = results[i];

    if (!up) {
      continue;
    }

    try {
      final ia = InternetAddress(address);
      final dns = await ia.reverse();

      yield FTNetworkDiscoveryResult(
        host: address,
        port: port,
        name: dns.host,
      );
    } on SocketException {
      yield FTNetworkDiscoveryResult(
        host: address,
        port: port,
      );
    }

    await Future.delayed(const Duration(milliseconds: 10));
  }
}

class FTNetworkDiscoveryResult {
  final String host;
  final int port;
  final String? name;

  const FTNetworkDiscoveryResult({
    required this.host,
    required this.port,
    this.name,
  });
}
