extension FTStringExtension on String {
  String? nullable() {
    return trim().isEmpty ? null : this;
  }
}
