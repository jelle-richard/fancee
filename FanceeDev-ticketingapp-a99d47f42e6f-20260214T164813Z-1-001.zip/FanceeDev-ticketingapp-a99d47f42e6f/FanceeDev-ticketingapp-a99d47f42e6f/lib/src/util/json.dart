import 'dart:ui';

/// Returns the given [value] as a [boolean].
bool toBoolean(dynamic value) {
  if (value is! bool) {
    throw const FormatException('The given value is not a boolean');
  }

  return value == true;
}

/// Returns the given [value] as a [Color].
Color toColor(dynamic value) {
  return Color(int.parse(toString(value), radix: 16));
}

/// Returns the given [value] as a [DateTime].
DateTime toDateTime(dynamic value) {
  return DateTime.parse(toString(value));
}

/// Returns the given [value] as a [double].
double toDouble(dynamic value) {
  if (value is int) {
    /// note: integers are accepted and casted to doubles.
    value = value.toDouble();
  }

  if (value is! double) {
    throw const FormatException('The given value is not a double.');
  }

  return value;
}

/// Returns the given [value] as an enum.
T toEnum<T>(dynamic value, T Function(String) fromString) {
  return fromString(toString(value));
}

/// Returns the given [value] as an [int].
int toInt(dynamic value) {
  if (value is! int) {
    throw const FormatException('The given value is not an int.');
  }

  return value;
}

/// Returns the given [value] as a [List] with [dynamic] values.
List<dynamic> toList(dynamic value) {
  if (value is! List) {
    throw const FormatException('The given value is not a list.');
  }

  return value;
}

/// Returns the given [value] as a [Set] with [dynamic] values. If
/// the incoming [value] is not a [List], a [FormatException] is thrown.
Set<dynamic> toSet(dynamic value) {
  if (value is! List) {
    throw const FormatException('The given value is not a list.');
  }

  return value.toSet();
}

/// Returns null if the given [value] is null, otherwise it passes
/// the value to the given [converter].
T? toNullable<T>(dynamic value, T Function(dynamic) converter) {
  if (value == null) {
    return null;
  }

  return converter(value);
}

/// Returns null if the given [value] is null, otherwise it passes
/// the value to the given [fromString] function, which returns
/// the enum value.
T? toNullableEnum<T>(dynamic value, T Function(String) fromString) {
  if (value == null) {
    return null;
  }

  return fromString(toString(value));
}

/// Returns the given [value] as a [string].
String toString(dynamic value) {
  if (value is! String) {
    throw const FormatException('The given value is not a string.');
  }

  return value;
}

/// Returns the given [value] as a [List] with [bool] values.
List<bool> toBooleanList(dynamic value) {
  return toList(value).map(toBoolean).toList(growable: false);
}

/// Returns the given [value] as a [List] with [double] values.
List<double> toDoubleList(dynamic value) {
  return toList(value).map(toDouble).toList(growable: false);
}

/// Returns the given [value] as a [List] with [int] values.
List<int> toIntList(dynamic value) {
  return toList(value).map(toInt).toList(growable: false);
}

/// Returns the given [value] as a [List] with [String] values.
List<String> toStringList(dynamic value) {
  return toList(value).map(toString).toList(growable: false);
}

/// Returns the given [value] as a [Set] with [bool] values.
Set<bool> toBooleanSet(dynamic value) {
  return toSet(value).map(toBoolean).toSet();
}

/// Returns the given [value] as a [Set] with [double] values.
Set<double> toDoubleSet(dynamic value) {
  return toSet(value).map(toDouble).toSet();
}

/// Returns the given [value] as a [Set] with [int] values.
Set<int> toIntSet(dynamic value) {
  return toSet(value).map(toInt).toSet();
}

/// Returns the given [value] as a [Set] with [String] values.
Set<String> toStringSet(dynamic value) {
  return toSet(value).map(toString).toSet();
}
