import 'dart:math';

import 'package:carrot/carrot.dart' show Offset;

/// Calculates the angle between [a] and [b].
double calculateAngle(Offset a, Offset b) {
  return atan2(b.dy - a.dy, b.dx - a.dx) * 180 / pi;
}

/// Calculates a new line end point based on the angle of [a] and [b] using [length].
Offset calculateAngledLine(Offset a, Offset b, double length) {
  final angle = calculateAngle(a, b);

  return Offset(
    a.dx + cos(pi * angle / 180) * length,
    a.dy + sin(pi * angle / 180) * length,
  );
}

/// Calculates the offset of a line that is angled at [angle] degrees from [a] to [b].
Offset calculateAngledLineOffset(Offset a, Offset b, double offset) {
  final angle = calculateAngle(a, b);
  final distance = euclideanDistance(a, b);

  return Offset(
    a.dx + cos(pi * angle / 180) * (distance + offset),
    a.dy + sin(pi * angle / 180) * (distance + offset),
  );
}

/// Calculates the euclidean distance between the two given points [a] and [b].
/// The euclidean distance is the straight line distance between two points and is
/// calculated using the formula: `sqrt((x2 - x1)^2 + (y2 - y1)^2)`.
double euclideanDistance(Offset a, Offset b) {
  return sqrt(pow(b.dx - a.dx, 2) + pow(b.dy - a.dy, 2));
}

/// Returns the amount of radians for the given [angle].
double radians(double angle) {
  return pi / 180 * angle;
}
