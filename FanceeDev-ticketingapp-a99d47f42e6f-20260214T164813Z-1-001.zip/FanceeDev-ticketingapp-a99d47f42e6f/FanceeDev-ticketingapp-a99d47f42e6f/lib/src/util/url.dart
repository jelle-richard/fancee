import 'package:url_launcher/url_launcher.dart';

/// Launches the given [url] in the default browser.
Future<void> launchUri(Uri uri) async {
  if (await canLaunchUrl(uri)) {
    await launchUrl(
      uri,
      mode: LaunchMode.inAppWebView,
    );
  } else {
    throw 'Could not launch $uri';
  }
}

/// Parses the given string url into a [Uri] and calls [launchUri].
Future<void> launchFromString(String url) async {
  try {
    final uri = Uri.parse(url);
    await launchUri(uri);
  } on FormatException {
    throw 'Could not parse $url';
  }
}
