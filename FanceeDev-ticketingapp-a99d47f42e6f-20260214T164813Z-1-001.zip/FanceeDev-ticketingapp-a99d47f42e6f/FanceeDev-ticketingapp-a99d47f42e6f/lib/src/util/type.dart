/// Asserts that the given [value] is of the provided [T]ype
/// and returns it.
T assertedCast<T>(dynamic value) {
  assert(value is T);
  return value as T;
}
