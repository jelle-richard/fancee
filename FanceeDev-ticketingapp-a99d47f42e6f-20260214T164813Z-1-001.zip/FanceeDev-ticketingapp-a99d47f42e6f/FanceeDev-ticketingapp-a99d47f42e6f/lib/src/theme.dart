import 'package:carrot/carrot.dart';

enum FTThemeId {
  auto,
  dark,
  light,
}

class FTTheme {
  // Theme: Dark
  static final dark = _FTThemeBase.dark.copyWith(
    appBarTheme: CarrotAppBarThemeData.dark(
      _FTThemeBase.dark,
      shadow: CarrotShadows.none,
    ),
    textButtonTheme: CarrotTextButtonThemeData.dark(
      _FTThemeBase.dark,
      shadow: CarrotShadows.none,
    ),
  );

  // Theme: Light
  static final light = _FTThemeBase.light.copyWith(
    appBarTheme: CarrotAppBarThemeData.light(
      _FTThemeBase.light,
      shadow: CarrotShadows.none,
    ),
    textButtonTheme: CarrotTextButtonThemeData.light(
      _FTThemeBase.light,
      shadow: CarrotShadows.none,
    ),
  );
}

class FTThemeUtil {
  static CarrotThemeData find(BuildContext context, FTThemeId themeId, CarrotThemeData defaultTheme) {
    switch (themeId) {
      case FTThemeId.auto:
        return defaultTheme;

      case FTThemeId.dark:
        return FTTheme.dark;

      case FTThemeId.light:
        return FTTheme.light;
    }
  }
}

class _FTThemeBase {
  static final dark = CarrotThemeData.dark(
    defaults: CarrotThemeDataDefaults.dark(
      FTThemeColors.gray.reversed,
      background: FTThemeColors.gray[900].darken(.05),
      content: FTThemeColors.gray[900].darken(.025),
      scrim: FTThemeColors.gray[900].darken(.05).withOpacity(.9),
    ),
    typography: CarrotTypography(
      FTThemeColors.gray.reversed,
      FTThemeColors.primary,
      fontFamily: 'manrope',
      textHeightBehavior: defaultTextHeightBehavior,
    ),
    radius: const Radius.circular(15),
    gray: FTThemeColors.gray.reversed,
    primary: FTThemeColors.primary,
  );

  static final light = CarrotThemeData.light(
    defaults: CarrotThemeDataDefaults.light(
      FTThemeColors.gray,
      background: FTThemeColors.primary[700],
      scrim: FTThemeColors.primary[900].withOpacity(.9),
    ),
    typography: CarrotTypography(
      FTThemeColors.gray,
      FTThemeColors.primary,
      fontFamily: 'manrope',
      textHeightBehavior: defaultTextHeightBehavior,
    ),
    radius: const Radius.circular(15),
    gray: FTThemeColors.gray,
    primary: FTThemeColors.primary,
  );

  // Text
  static const defaultTextHeightBehavior = TextHeightBehavior(
    applyHeightToFirstAscent: false,
    applyHeightToLastDescent: true,
    leadingDistribution: TextLeadingDistribution.even,
  );
}

class FTThemeColors {
  static const gray = CarrotColors.grayModern;

  static const primary = CarrotColor(0xff6071b5, {
    25: CarrotSwatch(0xffffffff, Color(0xff6071b5)),
    50: CarrotSwatch(0xfff3f6fb, Color(0xff6071b5)),
    100: CarrotSwatch(0xffe5e9f4, Color(0xff6071b5)),
    200: CarrotSwatch(0xffc4cbe4, Color(0xff6071b5)),
    300: CarrotSwatch(0xffa3add5, CarrotColors.white),
    400: CarrotSwatch(0xff818fc5, CarrotColors.white),
    500: CarrotSwatch(0xff6071b5, CarrotColors.white),
    600: CarrotSwatch(0xff53619b, CarrotColors.white),
    700: CarrotSwatch(0xff455080, CarrotColors.white),
    800: CarrotSwatch(0xff384066, CarrotColors.white),
    900: CarrotSwatch(0xff2a2f4b, CarrotColors.white),
  });
}
