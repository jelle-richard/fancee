enum FTScanState {
  scanned('Scanned'),
  unscanned('Unscanned'),
  unknown('Unknown');

  final String value;

  const FTScanState(this.value);

  factory FTScanState.fromString(String value) {
    return values.firstWhere(
      (state) => state.value.toLowerCase() == value.toLowerCase(),
      orElse: () => FTScanState.unknown,
    );
  }

  String toJson() => value;

  @override
  String toString() => value;
}
