import 'package:carrot/carrot.dart';

import '../../../l10n/l10n.dart';
import '../../component/atom/atom.dart';

enum FTGender {
  male('Male', 'mars'),
  female('Female', 'venus'),
  neutral('Neutral', 'genderless'),
  notSpecified(null, 'genderless');

  static List<CarrotSelectFieldOption<FTGender>> get options => values
      .map(
        (value) => CarrotSelectFieldOption(
          value: value,
          builder: (context) => CarrotRow(
            crossAxisAlignment: CrossAxisAlignment.center,
            gap: 15,
            children: [
              FTIcon(
                color: context.carrotTheme.primary,
                glyph: value.icon,
                size: 18,
              ),
              Text(value.getLabel(context)),
            ],
          ),
        ),
      )
      .toList();

  final String icon;
  final String? value;

  const FTGender(
    this.value,
    this.icon,
  );

  factory FTGender.fromString(String? value) {
    return values.firstWhere(
      (gender) => gender.value == value,
      orElse: () => FTGender.notSpecified,
    );
  }

  String getLabel(BuildContext context) {
    switch (this) {
      case FTGender.male:
        return context.strings.genderMale;

      case FTGender.female:
        return context.strings.genderFemale;

      case FTGender.neutral:
        return context.strings.genderNeutral;

      case FTGender.notSpecified:
        return context.strings.genderNotSpecified;
    }
  }

  String? toJson() => value;

  @override
  String toString() => value ?? name;
}
