enum FTScanResultType {
  failed,
  invalid,
  ok,
  reused;

  factory FTScanResultType.fromString(String value) {
    return values.firstWhere(
      (type) => type.name == value,
      orElse: () => FTScanResultType.failed,
    );
  }

  @override
  String toString() => name;
}
