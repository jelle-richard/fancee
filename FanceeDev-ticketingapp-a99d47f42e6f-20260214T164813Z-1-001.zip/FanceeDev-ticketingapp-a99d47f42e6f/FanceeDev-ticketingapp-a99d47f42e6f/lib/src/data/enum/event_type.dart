enum FTEventType {
  unknown('unknown'),
  normal('Normal');

  final String value;

  const FTEventType(this.value);

  factory FTEventType.fromString(String value) => values.firstWhere(
        (type) => type.value == value,
        orElse: () => FTEventType.unknown,
      );

  String toJson() => value;

  @override
  String toString() => value;
}
