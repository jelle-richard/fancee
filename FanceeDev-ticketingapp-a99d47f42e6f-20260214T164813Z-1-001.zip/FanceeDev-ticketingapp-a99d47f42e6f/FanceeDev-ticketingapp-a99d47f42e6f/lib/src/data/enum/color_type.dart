enum FTColorType {
  primary('Primary'),
  secondary('Secondary'),
  success('Success'),
  warning('Warning'),
  danger('Danger'),
  info('Info');

  final String value;

  const FTColorType(this.value);

  factory FTColorType.fromString(String value) => values.firstWhere(
        (color) => color.value == value,
        orElse: () => FTColorType.secondary,
      );

  String toJson() => value;

  @override
  String toString() => value;
}
