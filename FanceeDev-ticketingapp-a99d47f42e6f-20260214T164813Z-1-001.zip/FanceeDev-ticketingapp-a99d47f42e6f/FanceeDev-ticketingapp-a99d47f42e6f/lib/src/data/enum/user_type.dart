enum FTUserType {
  appTeam,
  organizer,
}
