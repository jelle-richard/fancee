enum FTShopFieldType {
  unknown('unknown'),
  address('Address'),
  birthDate('Birthdate'),
  city('City'),
  country('Country'),
  email('Email'),
  firstName('FirstName'),
  gender('Gender'),
  lastName('LastName'),
  phoneNumber('Phone'),
  street('Street');

  final String value;

  const FTShopFieldType(this.value);

  factory FTShopFieldType.fromString(String value) => values.firstWhere(
        (type) => type.value == value,
        orElse: () => FTShopFieldType.unknown,
      );

  String toJson() => value;

  @override
  String toString() => value;
}
