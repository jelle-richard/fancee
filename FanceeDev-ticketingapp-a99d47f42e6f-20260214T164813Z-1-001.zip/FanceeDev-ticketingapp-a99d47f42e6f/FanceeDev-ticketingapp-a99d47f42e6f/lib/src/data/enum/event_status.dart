enum FTEventStatus {
  unknown('unknown'),
  active('Active'),
  canceled('Cancelled'),
  completed('Completed'),
  concluded('Concluded'),
  soldOut('SoldOut'),
  unpublished('Unpublished');

  final String value;

  const FTEventStatus(this.value);

  factory FTEventStatus.fromString(String value) => values.firstWhere(
        (state) => state.value == value,
        orElse: () => FTEventStatus.unknown,
      );

  String toJson() => value;

  @override
  String toString() => value;
}
