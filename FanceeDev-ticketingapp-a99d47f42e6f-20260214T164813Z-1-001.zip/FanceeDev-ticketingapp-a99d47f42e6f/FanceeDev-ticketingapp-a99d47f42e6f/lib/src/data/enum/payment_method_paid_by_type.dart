enum FTPaymentMethodPaidByType {
  unknown('unknown'),
  client('Client'),
  organizer('Organizer');

  final String value;

  const FTPaymentMethodPaidByType(this.value);

  factory FTPaymentMethodPaidByType.fromString(String value) => values.firstWhere(
        (method) => method.value == value,
        orElse: () => FTPaymentMethodPaidByType.unknown,
      );

  String toJson() => value;

  @override
  String toString() => value;
}
