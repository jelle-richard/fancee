enum FTProductType {
  unknown('unknown'),
  product('Product'),
  ticket('Ticket');

  final String value;

  const FTProductType(this.value);

  factory FTProductType.fromString(String value) => values.firstWhere(
        (type) => type.value == value,
        orElse: () => FTProductType.unknown,
      );

  String toJson() => value;

  @override
  String toString() => value;
}
