enum FTUserClaim {
  unknown('unknown'),

  // app team
  sales('sales'),
  scan('scan'),
  statistics('statistics'),

  // organizer
  appTeamAdd('appteam.add'),
  appTeamDetails('appteam.details'),
  appTeamList('appteam.list'),
  appTeamRemove('appteam.remove'),
  customerInsightView('customerinsight.view'),
  eventConfigure('event.configure'),
  eventDetails('event.details'),
  eventList('event.list'),
  eventTypeNormal('event.type.normal'),
  invoiceDetails('invoice.details'),
  invoiceList('invoice.list'),
  preRegisterConfigure('preregister.configure'),
  preRegisterDetails('preregister.details'),
  preRegisterList('preregister.list'),
  profileDetails('profile.details'),
  profileEdit('profile.edit'),
  refundAccept('refund.accept'),
  salePaymentsCash('sale.payments.cash'),
  ticketEdit('ticket.edit'),
  ticketScan('ticket.scan'),
  ticketStatistics('ticket.statistics');

  final String name;

  const FTUserClaim(this.name);

  factory FTUserClaim.fromString(String name) {
    return values.firstWhere(
      (claim) => claim.name == name,
      orElse: () => FTUserClaim.unknown,
    );
  }

  String toJson() => name;

  @override
  String toString() => name;
}
