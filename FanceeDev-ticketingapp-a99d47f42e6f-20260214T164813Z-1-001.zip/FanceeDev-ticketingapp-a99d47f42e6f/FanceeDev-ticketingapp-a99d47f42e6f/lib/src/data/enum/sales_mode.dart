enum FTSalesMode {
  doorsale,
  presale;

  factory FTSalesMode.fromString(String value) {
    return values.firstWhere(
      (mode) => mode.name == value,
      orElse: () => FTSalesMode.doorsale,
    );
  }

  String toJson() => name;

  @override
  String toString() => name;
}
