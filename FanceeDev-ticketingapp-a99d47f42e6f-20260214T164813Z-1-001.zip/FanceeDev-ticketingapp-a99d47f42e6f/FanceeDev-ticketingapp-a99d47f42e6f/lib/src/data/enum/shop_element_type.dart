enum FTShopElementType {
  unknown('unknown'),
  divider('Divider'),
  externalLink('ExternalLink'),
  notice('Notice'),
  product('Product'),
  textBlock('TextBlock');

  final String value;

  const FTShopElementType(this.value);

  factory FTShopElementType.fromString(String value) => values.firstWhere(
        (type) => type.value == value,
        orElse: () => FTShopElementType.unknown,
      );

  String toJson() => value;

  @override
  String toString() => value;
}
