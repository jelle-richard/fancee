import 'errors.dart';
import 'headers.dart';
import 'response_code.dart';

class FTHttpResponse<T> {
  final T? data;
  final FTHttpErrors errors;
  final FTHttpHeaders headers;
  final FTHttpResponseCode status;

  bool get isOk => status.isOk && !errors.hasErrors;

  bool get isUnsanctioned => status == FTHttpResponseCode.unauthorized || status == FTHttpResponseCode.forbidden;

  const FTHttpResponse({
    required this.headers,
    required this.status,
    this.data,
    this.errors = const FTHttpErrors.empty(),
  });

  const FTHttpResponse.fromData({
    required this.data,
    required this.headers,
    required this.status,
  }) : errors = const FTHttpErrors.empty();

  const FTHttpResponse.fromErrors({
    required this.errors,
    required this.headers,
    required this.status,
  }) : data = null;

  const FTHttpResponse.invalidFanceeResponse({
    required this.headers,
    required this.status,
  })  : data = null,
        errors = const FTHttpErrors.fromMap({
          'FAN-333-1': ['The response is not a valid Fancee response.'],
        });

  FTHttpResponse<Data> copyWithData<Data>({
    required Data data,
    FTHttpErrors? errors,
    FTHttpHeaders? headers,
    FTHttpResponseCode? status,
  }) =>
      FTHttpResponse(
        data: data,
        errors: errors ?? this.errors,
        headers: headers ?? this.headers,
        status: status ?? this.status,
      );
}
