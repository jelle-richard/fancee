enum FTHttpResponseCode {
  unknown(-1, 'unknown'),

  // Protocol-level response codes.
  hContinue(100, 'Continue'), // note(Bas): h prefix is for "http" and is required because dart uses "continue" as a reserved keyword.
  switchingProtocols(101, 'Switching Protocols'),
  processing(102, 'Processing'),

  // OK
  ok(200, 'OK'),
  created(201, 'Created'),
  accepted(202, 'Accepted'),
  nonAuthoritativeInformation(203, 'Non Authoritative Information'),
  noContent(204, 'No Content'),
  resetContent(205, 'Reset Content'),
  partialContent(206, 'Partial Content'),
  multiStatus(207, 'Multi Status'),
  alreadyReported(208, 'Already Reported'),
  imUsed(226, 'I\'m Used'),

  // Redirect
  multipleChoices(300, 'Multiple Choices'),
  movedPermanently(301, 'Moved Permanently'),
  found(302, 'Found'),
  seeOther(303, 'See Other'),
  notModified(304, 'Not Modified'),
  useProxy(305, 'Use Proxy'),
  switchProxy(306, 'Switch Proxy'),
  temporaryRedirect(307, 'Temporary Redirect'),
  permanentRedirect(308, 'Permanent Redirect'),

  // Client Error
  badRequest(400, 'Bad Request'),
  unauthorized(401, 'Unauthorized'),
  paymentRequired(402, 'Payment Required'),
  forbidden(403, 'Forbidden'),
  notFound(404, 'Not Found'),
  methodNotAllowed(405, 'Method Not Allowed'),
  notAcceptable(406, 'Not Acceptable'),
  proxyAuthenticationRequired(407, 'Proxy Authentication Required'),
  requestTimeout(408, 'Request Timeout'),
  conflict(409, 'Conflict'),
  gone(410, 'Gone'),
  lengthRequired(411, 'Length Required'),
  preconditionFailed(412, 'Precondition Failed'),
  requestEntityTooLarge(413, 'Request Entity Too Large'),
  requestURITooLong(414, 'Request URI Too Long'),
  unsupportedMediaType(415, 'Unsupported Media Type'),
  requestedRangeNotSatisfiable(416, 'Requested Range Not Satisfiable'),
  expectationFailed(417, 'Expectation Failed'),
  imATeapot(418, 'I\'m A Teapot'),
  authenticationTimeout(419, 'Authentication Timeout'),
  enhanceYourCalm(420, 'Enhance Your Calm'),
  misdirectedRequest(421, 'Misdirected Request'),
  unprocessableEntity(422, 'Unprocessable Entity'),
  locked(423, 'Locked'),
  failedDependency(424, 'Failed Dependency'),
  upgradeRequired(426, 'Upgrade Required'),
  preconditionRequired(428, 'Precondition Required'),
  tooManyRequests(429, 'Too Many Requests'),
  requestHeaderFieldsTooLarge(431, 'Request Header Fields Too Large'),
  unavailableForLegalReasons(451, 'Unavailable For Legal Reasons'),

  // Server Error
  internalServerError(500, 'Internal Server Error'),
  notImplemented(501, 'Not Implemented'),
  badGateway(502, 'Bad Gateway'),
  serviceUnavailable(503, 'Service Unavailable'),
  gatewayTimeout(504, 'Gateway Timeout'),
  httpVersionNotSupported(505, 'HTTP Version Not Supported'),
  variantAlsoNegotiates(506, 'Variant Also Negotiates'),
  insufficientStorage(507, 'Insufficient Storage'),
  loopDetected(508, 'Loop Detected'),
  notExtended(510, 'Not Extended'),
  networkAuthenticationRequired(511, 'Network Authentication Required');

  final int value;
  final String name;

  bool get isOk => value >= 200 && value <= 226;

  const FTHttpResponseCode(this.value, this.name);

  factory FTHttpResponseCode.fromStatusCode(int statusCode) {
    for (final code in values) {
      if (code.value == statusCode) {
        return code;
      }
    }

    return FTHttpResponseCode.unknown;
  }
}
