import 'dart:convert';
import 'dart:typed_data';

import 'package:carrot/carrot.dart';

import '../environment.dart';
import 'header.dart';
import 'headers.dart';
import 'method.dart';
import 'query.dart';

class FTHttpRequest {
  final BuildContext context;
  final FTEnvironment environment;
  final Uri uri;
  final String userAgent;
  FTHttpHeaders headers;
  FTHttpMethod method;
  FTHttpQuery query;

  Uint8List _body;

  String? get bearerToken => headers.has(FTHttpHeader.authorization) ? headers.value(FTHttpHeader.authorization)?.split(' ').last : null;

  String get body => utf8.decode(_body);

  Uint8List get bodyBytes => _body;

  FTHttpQuery get bodyFields => FTHttpQuery.fromString(body);

  String? get contentType => headers[FTHttpHeader.contentType];

  set bearerToken(String? value) {
    if (value == null) {
      headers.remove(FTHttpHeader.authorization);
    } else {
      headers.set(FTHttpHeader.authorization, 'Bearer $value');
    }
  }

  set body(String value) {
    _body = _toUint8List(utf8.encode(value));
  }

  set bodyFields(FTHttpQuery query) {
    body = query.toString();
  }

  set bodyJson(dynamic json) {
    body = jsonEncode(json);
    contentType = 'application/json';
  }

  set contentType(String? value) {
    if (value == null) {
      headers.remove(FTHttpHeader.contentType);
    } else {
      headers.set(FTHttpHeader.contentType, value.toString());
    }
  }

  FTHttpRequest({
    required this.context,
    required this.environment,
    required this.userAgent,
    required this.uri,
  })  : _body = Uint8List(0),
        headers = FTHttpHeaders(),
        method = FTHttpMethod.get,
        query = FTHttpQuery();

  void header(FTHttpHeader name, String value) {
    headers[name] = value;
  }

  factory FTHttpRequest.fromPath(BuildContext context, FTEnvironment environment, String path) {
    return FTHttpRequest(
      context: context,
      environment: environment,
      userAgent: environment.apiBaseUrl,
      uri: Uri.parse(environment.apiBaseUrl + path),
    );
  }
}

Uint8List _toUint8List(List<int> input) {
  if (input is Uint8List) {
    return input;
  }

  if (input is TypedData) {
    return Uint8List.view((input as TypedData).buffer);
  }

  return Uint8List.fromList(input);
}
