import '../exception_id.dart';

class FTHttpErrors {
  final Map<String, List<String>> _errors;

  bool get hasErrors => _errors.isNotEmpty;

  String? get first => hasErrors ? this[keys.first] : null;

  String? get last => hasErrors ? this[keys.last] : null;

  Set<String> get keys => _errors.keys.toSet();

  Map<String, List<String>> get pairs => _errors;

  FTHttpErrors._(this._errors);

  const FTHttpErrors.empty() : _errors = const {};

  const FTHttpErrors.fromMap(this._errors);

  factory FTHttpErrors.fromJson(dynamic obj) {
    Map<String, List<String>> errors = {};

    if (obj is Map) {
      obj.forEach((key, value) {
        if (key is String && value is List) {
          errors[key] = value.cast<String>();
        }
      });
    }

    return FTHttpErrors._(errors);
  }

  String? operator [](String key) {
    final values = _errors[key];

    if (values == null) {
      return null;
    }

    return values.join('\n');
  }

  bool contains(String key) => _errors.containsKey(key);

  bool hasException(FTExceptionId id) => contains(id.value);

  List<String> getMessages(String key) {
    assert(_errors.containsKey(key), 'Key $key not found.');

    return _errors[key]!;
  }

  toJson() => _errors;
}
