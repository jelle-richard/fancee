import 'package:collection/collection.dart';

class FTHttpQuery {
  final Map<String, List<String>> _pairs = {};

  bool get isEmpty => _pairs.isEmpty;

  bool get isNotEmpty => _pairs.isNotEmpty;

  Map<String, List<String>> get pairs => _pairs;

  FTHttpQuery();

  FTHttpQuery.fromPairs(Map<String, dynamic> pairs) {
    pairs.forEach((key, value) {
      if (value is List<String>) {
        for (var val in value) {
          add(key, val);
        }
      } else {
        add(key, value);
      }
    });
  }

  FTHttpQuery.fromString(String query) {
    query.split('&').map((p) => p.split('=')).forEach((pair) {
      final key = pair[0];
      final value = pair[1];
      _pairs.putIfAbsent(key, () => []).add(value);
    });
  }

  void add(String key, dynamic value) {
    if (value is bool) {
      addBoolean(key, value);
    } else if (value is double) {
      addDouble(key, value);
    } else if (value is int) {
      addInteger(key, value);
    } else if (value != null) {
      addString(key, value.toString());
    }
  }

  void addBoolean(String key, bool value) {
    _pairs.putIfAbsent(key, () => []).add(value ? '1' : '0');
  }

  void addDouble(String key, double value) {
    _pairs.putIfAbsent(key, () => []).add(value.toString());
  }

  void addInteger(String key, int value) {
    _pairs.putIfAbsent(key, () => []).add(value.toString());
  }

  void addString(String key, String value) {
    _pairs.putIfAbsent(key, () => []).add(value);
  }

  @override
  String toString() {
    return _pairs.entries.map((e) => e.value.map((v) => '${e.key}=${Uri.encodeQueryComponent(v)}')).flattened.join('&');
  }
}
