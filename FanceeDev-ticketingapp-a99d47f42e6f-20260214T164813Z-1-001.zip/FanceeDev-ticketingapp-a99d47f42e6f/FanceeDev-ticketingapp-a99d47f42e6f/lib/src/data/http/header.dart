enum FTHttpHeader {
  unknown('?'),
  accept('accept'),
  acceptCharset('accept-charset'),
  acceptEncoding('accept-encoding'),
  acceptLanguage('accept-language'),
  acceptRanges('accept-ranges'),
  accessControlAllowCredentials('access-control-allow-credentials'),
  accessControlAllowHeaders('access-control-allow-headers'),
  accessControlAllowMethods('access-control-allow-methods'),
  accessControlAllowOrigin('access-control-allow-origin'),
  accessControlExposeHeaders('access-control-expose-headers'),
  accessControlMaxAge('access-control-max-age'),
  accessControlRequestHeaders('access-control-request-headers'),
  accessControlRequestMethod('access-control-request-method'),
  age('age'),
  allow('allow'),
  authorization('authorization'),
  cacheControl('cache-control'),
  connection('connection'),
  contentDisposition('content-disposition'),
  contentEncoding('content-encoding'),
  contentLanguage('content-language'),
  contentLength('content-length'),
  contentLocation('content-location'),
  contentMD5('content-md5'),
  contentRange('content-range'),
  contentType('content-type'),
  cookie('cookie'),
  date('date'),
  etag('etag'),
  expect('expect'),
  expires('expires'),
  from('from'),
  host('host'),
  ifMatch('if-match'),
  ifModifiedSince('if-modified-since'),
  ifNoneMatch('if-none-match'),
  ifRange('if-range'),
  ifUnmodifiedSince('if-unmodified-since'),
  lastModified('last-modified'),
  link('link'),
  location('location'),
  maxForwards('max-forwards'),
  pragma('pragma'),
  proxyAuthenticate('proxy-authenticate'),
  proxyAuthorization('proxy-authorization'),
  range('range'),
  referer('referer'),
  refresh('refresh'),
  retryAfter('retry-after'),
  server('server'),
  te('te'),
  trailer('trailer'),
  transferEncoding('transfer-encoding'),
  upgrade('upgrade'),
  userAgent('user-agent'),
  vary('vary'),
  via('via'),
  warning('warning'),
  wwwAuthenticate('www-authenticate'),
  xForwardedFor('x-forwarded-for'),
  xForwardedHost('x-forwarded-host'),
  xForwardedProto('x-forwarded-proto'),
  xPoweredBy('x-powered-by'),
  xRequestId('x-request-id'),
  xRequestedWith('x-requested-with'),
  xUid('x-uid'),
  xUserAgent('x-user-agent'),
  xVersion('x-version');

  final String value;

  const FTHttpHeader(this.value);

  factory FTHttpHeader.fromString(String value) {
    for (final header in values) {
      if (header.value == value.toLowerCase()) {
        return header;
      }
    }

    return FTHttpHeader.unknown;
  }

  @override
  String toString() => value;
}
