import '../../util/util.dart';

typedef FTPaginatedAdapter<T> = T Function(dynamic);

class FTPaginated<T> {
  final List<T> items;
  final int page;
  final int pageSize;
  final int pages;
  final int totalItems;

  const FTPaginated({
    required this.items,
    required this.page,
    required this.pageSize,
    required this.pages,
    required this.totalItems,
  });

  factory FTPaginated.fromJson(dynamic json, FTPaginatedAdapter<T> adapter) => FTPaginated<T>(
        items: toList(json['items']).map(adapter).toList(),
        page: toInt(json['page']),
        pageSize: toInt(json['pageSize']),
        pages: toInt(json['pages']),
        totalItems: toInt(json['totalItems']),
      );

  Map<String, dynamic> toJson() => {
        'items': items,
        'page': page,
        'pageSize': pageSize,
        'pages': pages,
        'totalItems': totalItems,
      };
}
