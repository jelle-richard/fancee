import 'dart:io';

import 'header.dart';

class FTHttpHeaders {
  final Map<FTHttpHeader, String> _headers = {};

  FTHttpHeaders();

  FTHttpHeaders.fromHttp(HttpHeaders headers) {
    headers.forEach((name, values) {
      var header = FTHttpHeader.fromString(name);
      _headers[header] = values.join('|');
    });
  }

  bool get isEmpty => _headers.isEmpty;

  bool get isNotEmpty => _headers.isNotEmpty;

  String? operator [](FTHttpHeader name) => value(name);

  void operator []=(FTHttpHeader name, String value) {
    set(name, value);
  }

  void add(FTHttpHeader name, String value) {
    _headers.addAll({name: value});
  }

  void addAll(Map<FTHttpHeader, String> headers) {
    _headers.addAll(headers);
  }

  void forEach(void Function(FTHttpHeader, String) f) {
    _headers.forEach(f);
  }

  bool has(FTHttpHeader name) {
    return _headers.containsKey(name);
  }

  void remove(FTHttpHeader name) {
    _headers.remove(name);
  }

  void removeAll(Iterable<FTHttpHeader> names) {
    _headers.removeWhere((key, value) => names.contains(key));
  }

  void set(FTHttpHeader name, String value) {
    _headers[name] = value;
  }

  String? value(FTHttpHeader name) {
    return _headers[name];
  }
}
