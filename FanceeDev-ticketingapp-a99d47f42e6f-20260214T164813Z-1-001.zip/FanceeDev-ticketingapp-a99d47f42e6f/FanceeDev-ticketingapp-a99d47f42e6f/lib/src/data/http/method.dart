enum FTHttpMethod {
  delete('DELETE'),
  get('GET'),
  head('HEAD'),
  options('OPTIONS'),
  patch('PATCH'),
  post('POST'),
  put('PUT');

  final String value;

  const FTHttpMethod(this.value);
}
