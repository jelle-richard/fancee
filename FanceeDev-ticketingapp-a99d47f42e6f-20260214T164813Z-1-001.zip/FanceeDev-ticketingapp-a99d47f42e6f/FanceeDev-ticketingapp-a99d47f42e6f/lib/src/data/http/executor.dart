import 'dart:convert';
import 'dart:io';

import '../../config.dart';
import '../database/database.dart';
import 'errors.dart';
import 'headers.dart';
import 'method.dart';
import 'request.dart';
import 'response.dart';
import 'response_code.dart';

class FTHttpExecutor {
  static Future<FTHttpResponse<dynamic>> makeRequest(
      FTHttpRequest request) async {
    try {
      final database = FTDatabase.of(request.context);
      var uri = _makeUri(request);
      var clientRequest = await _makeRequest(request, uri);

      if (request.headers.isNotEmpty) {
        request.headers.forEach((name, value) {
          clientRequest.headers.set(name.toString(), value);
        });
      }

      if (request.body.isNotEmpty) {
        clientRequest.add(request.bodyBytes);
      }

      final response = await clientRequest.close();
      final body = await utf8.decodeStream(response);

      if (FTConfig.debugHttpRequests) {
        database.httpRequests.add(FTLoggedHttpRequest.fromResponse(
          uri.toString(),
          body,
          response.statusCode,
        ));
      }

      if (_isInvalidFanceeResponse(response, body)) {
        return FTHttpResponse.invalidFanceeResponse(
          headers: FTHttpHeaders.fromHttp(response.headers),
          status: FTHttpResponseCode.fromStatusCode(response.statusCode),
        );
      }

      final jsonData = json.decode(body);

      if (jsonData is Map) {
        dynamic data = {};
        FTHttpErrors? errors;

        if (jsonData.containsKey('data')) {
          data = jsonData['data'];
        }

        if (jsonData.containsKey('errors')) {
          errors = FTHttpErrors.fromJson(jsonData['errors']);
        }

        return FTHttpResponse(
          data: data,
          errors: errors ?? const FTHttpErrors.empty(),
          headers: FTHttpHeaders.fromHttp(response.headers),
          status: FTHttpResponseCode.fromStatusCode(response.statusCode),
        );
      }
    } on FormatException {
      // invalid fancee response.
    } on SocketException {
      // invalid fancee response.
    }

    return FTHttpResponse.invalidFanceeResponse(
      headers: FTHttpHeaders(),
      status: FTHttpResponseCode.enhanceYourCalm,
    );
  }

  static bool _isInvalidFanceeResponse(
      HttpClientResponse response, String body) {
    const statusCodes = [
      FTHttpResponseCode.badRequest,
      FTHttpResponseCode.notFound,
      FTHttpResponseCode.unsupportedMediaType,
    ];

    final statusCode = FTHttpResponseCode.fromStatusCode(response.statusCode);

    if (!statusCodes.contains(statusCode)) {
      return false;
    }

    return body.isEmpty || body[0] != '{';
  }

  static Future<HttpClientRequest> _makeRequest(
      FTHttpRequest request, Uri uri) async {
    final client = HttpClient()
      ..autoUncompress = true
      ..connectionTimeout = const Duration(seconds: 5)
      ..idleTimeout = const Duration(seconds: 5)
      ..userAgent = request.userAgent;

    switch (request.method) {
      case FTHttpMethod.delete:
        return await client.deleteUrl(uri);

      case FTHttpMethod.get:
        return await client.getUrl(uri);

      case FTHttpMethod.head:
        return await client.headUrl(uri);

      case FTHttpMethod.patch:
        return await client.patchUrl(uri);

      case FTHttpMethod.post:
        return await client.postUrl(uri);

      case FTHttpMethod.put:
        return await client.putUrl(uri);

      case FTHttpMethod.options:
        throw UnsupportedError('Http options requests are not supported.');

      default:
        throw ArgumentError('Http method not supported.');
    }
  }

  static Uri _makeUri(FTHttpRequest request) {
    final uri = request.uri;

    if (request.query.isNotEmpty) {
      return Uri.parse('$uri?${request.query}');
    }

    return uri;
  }
}
