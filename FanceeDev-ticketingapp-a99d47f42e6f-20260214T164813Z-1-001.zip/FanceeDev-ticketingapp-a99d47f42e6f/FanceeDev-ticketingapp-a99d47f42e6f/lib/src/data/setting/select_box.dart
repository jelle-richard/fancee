import 'package:carrot/carrot.dart';

import '../../component/molecule/molecule.dart';
import 'base.dart';

class FTSelectBoxSetting<T> extends FTBaseSetting<T> {
  final List<CarrotSelectFieldEntry<T>> options;

  FTSelectBoxSetting(
    super.bloc, {
    required super.getter,
    required super.setter,
    required super.title,
    required super.description,
    required this.options,
  });

  @override
  Widget builder(BuildContext context) {
    return FTSettingCaptioned(
      title: title,
      description: description,
      child: SizedBox(
        width: 138,
        child: _FTSelectBox<T>(
          options: options,
          value: value,
          onChanged: (val) => value = val,
        ),
      ),
    );
  }
}

class _FTSelectBox<T> extends StatefulWidget {
  final List<CarrotSelectFieldEntry<T>> options;
  final T value;
  final void Function(T) onChanged;

  const _FTSelectBox({
    required this.options,
    required this.value,
    required this.onChanged,
  });

  @override
  createState() => _FTSelectBoxState<T>();
}

class _FTSelectBoxState<T> extends State<_FTSelectBox<T>> {
  late final CarrotValueController<T> _controller;

  @override
  void dispose() {
    _controller.removeListener(_onValueChanged);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _controller = CarrotValueController<T>(value: widget.value);
    _controller.addListener(_onValueChanged);
  }

  void _onValueChanged() {
    widget.onChanged(_controller.value);
  }

  @override
  Widget build(BuildContext context) {
    return CarrotSelectField(
        controller: _controller,
        options: widget.options,
    );
  }
}
