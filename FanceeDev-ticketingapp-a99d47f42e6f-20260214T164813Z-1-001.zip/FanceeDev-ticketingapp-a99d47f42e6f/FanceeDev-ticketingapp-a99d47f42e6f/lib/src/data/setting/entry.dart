import 'package:carrot/carrot.dart';

abstract class FTSettingEntry {
  Widget build(BuildContext context);
}
