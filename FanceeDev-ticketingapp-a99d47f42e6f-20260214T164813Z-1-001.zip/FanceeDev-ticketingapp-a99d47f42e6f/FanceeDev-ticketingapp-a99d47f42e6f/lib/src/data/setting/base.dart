import 'package:carrot/carrot.dart';

import '../bloc/bloc.dart';
import 'entry.dart';

typedef FTSettingGetter<Value> = Value Function(FTUserState);

typedef FTSettingSetter<Value> = FTUserStateEvent Function(Value);

abstract class FTBaseSetting<Value> implements FTSettingEntry {
  final FTUserStateBloc _bloc;
  final FTSettingGetter<Value> getter;
  final FTSettingSetter<Value> setter;
  final WidgetBuilder title;
  final WidgetBuilder description;

  FTUserState get state => _bloc.state;

  Value get value => getter(state);

  set value(Value value) => _bloc.add(setter(value));

  const FTBaseSetting(
    this._bloc, {
    required this.getter,
    required this.setter,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder(
      bloc: _bloc,
      builder: (context, _) => builder(context),
    );
  }

  Widget builder(BuildContext context);
}
