import 'package:carrot/carrot.dart';

import 'entry.dart';

class FTSettingGroup implements FTSettingEntry {
  final WidgetBuilder title;
  final WidgetBuilder? description;
  final List<FTSettingEntry> settings;

  const FTSettingGroup({
    required this.title,
    required this.settings,
    this.description,
  });

  @override
  Widget build(BuildContext context) {
    final carrotTheme = context.carrotTheme;

    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 9,
      ),
      child: DecoratedBox(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: carrotTheme.gray[100],
              width: 1,
            ),
          ),
        ),
        child: CarrotColumn(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 30,
                vertical: 21,
              ),
              child: CarrotColumn(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  DefaultTextStyle(
                    style: context.carrotTypography.body1.copyWith(
                      color: carrotTheme.primary,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    child: title(context),
                  ),
                  if (description != null)
                    DefaultTextStyle(
                      style: context.carrotTypography.body2.copyWith(
                        fontSize: 14,
                      ),
                      child: description!(context),
                    ),
                ],
              ),
            ),
            ...settings.map((setting) => setting.build(context)),
          ],
        ),
      ),
    );
  }
}
