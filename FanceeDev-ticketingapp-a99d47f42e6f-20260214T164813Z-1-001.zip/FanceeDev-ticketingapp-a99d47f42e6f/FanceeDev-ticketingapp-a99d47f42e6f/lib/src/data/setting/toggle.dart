import 'package:carrot/carrot.dart';

import '../../component/molecule/molecule.dart';
import 'base.dart';

class FTToggleSetting extends FTBaseSetting<bool> {
  FTToggleSetting(
    super.bloc, {
    required super.getter,
    required super.setter,
    required super.title,
    required super.description,
  });

  @override
  Widget builder(BuildContext context) {
    return FTSettingCaptioned(
      title: title,
      description: description,
      child: CarrotSwitch(
        value: value,
        onChanged: (val) => value = val,
      ),
    );
  }
}
