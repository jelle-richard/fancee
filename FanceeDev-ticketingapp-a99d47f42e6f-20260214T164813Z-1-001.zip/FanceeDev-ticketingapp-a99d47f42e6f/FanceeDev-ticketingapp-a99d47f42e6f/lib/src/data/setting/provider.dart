import 'package:carrot/carrot.dart';

import '../../../l10n/l10n.dart';
import '../../theme.dart';
import '../bloc/bloc.dart';
import 'entry.dart';
import 'group.dart';
import 'select_box.dart';
import 'toggle.dart';

class FTSettingsProvider extends InheritedWidget {
  final FTUserStateBloc bloc;
  final List<FTSettingEntry> settings;

  FTSettingsProvider({
    super.key,
    required this.bloc,
    required super.child,
  }) : settings = [
          FTSettingGroup(
            title: (context) => Text(context.strings.settingsAppearance),
            settings: [
              FTSelectBoxSetting<FTThemeId>(
                bloc,
                title: (context) => Text(context.strings.settingsAppearanceThemeTitle),
                description: (context) => Text(context.strings.settingsAppearanceThemeDescription),
                getter: (state) => state.appearanceTheme,
                setter: (value) => FTUserStateSetAppearanceTheme(value),
                options: [
                  CarrotSelectFieldOption(
                    builder: (context) => Text(context.strings.themeAuto),
                    value: FTThemeId.auto,
                  ),
                  CarrotSelectFieldOption(
                    builder: (context) => Text(context.strings.themeLight),
                    value: FTThemeId.light,
                  ),
                  CarrotSelectFieldOption(
                    builder: (context) => Text(context.strings.themeDark),
                    value: FTThemeId.dark,
                  ),
                ],
              ),
            ],
          ),
          FTSettingGroup(
            title: (context) => Text(context.strings.settingsScanner),
            settings: [
              FTToggleSetting(
                bloc,
                title: (context) => Text(context.strings.settingsScannerCameraFacingTitle),
                description: (context) => Text(context.strings.settingsScannerCameraFacingDescription),
                getter: (state) => state.scannerCameraFrontFacing,
                setter: (value) => FTUserStateSetScannerCameraFrontFacing(value),
              ),
              FTToggleSetting(
                bloc,
                title: (context) => Text(context.strings.settingsScannerCameraFlashlightTitle),
                description: (context) => Text(context.strings.settingsScannerCameraFlashlightDescription),
                getter: (state) => state.scannerCameraFlashlight,
                setter: (value) => FTUserStateSetScannerCameraFlashlight(value),
              ),
              FTToggleSetting(
                bloc,
                title: (context) => Text(context.strings.settingsScannerFeedbackAudioTitle),
                description: (context) => Text(context.strings.settingsScannerFeedbackAudioDescription),
                getter: (state) => state.scannerFeedbackAudio,
                setter: (value) => FTUserStateSetScannerFeedbackAudio(value),
              ),
              FTToggleSetting(
                bloc,
                title: (context) => Text(context.strings.settingsScannerFeedbackHapticsTitle),
                description: (context) => Text(context.strings.settingsScannerFeedbackHapticsDescription),
                getter: (state) => state.scannerFeedbackHaptics,
                setter: (value) => FTUserStateSetScannerFeedbackHaptics(value),
              ),
            ],
          ),
        ];

  @override
  bool updateShouldNotify(FTSettingsProvider oldWidget) {
    return false;
  }
}
