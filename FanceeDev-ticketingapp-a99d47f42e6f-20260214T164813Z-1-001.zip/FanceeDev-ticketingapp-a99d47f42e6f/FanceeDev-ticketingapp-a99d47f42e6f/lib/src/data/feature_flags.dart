enum FTFeatureFlag {
  authForgotPasswordEnabled,
  authScanToSignInEnabled,
  dev,
  salesEnabled,
  salesAllShopElementsEnabled,
  scanEnabled,
  statisticsEnabled,
}

/// Controls which features of the app are enabled.
class FTFeatureFlags {
  final Set<FTFeatureFlag> _flags;

  const FTFeatureFlags(this._flags);

  const FTFeatureFlags.defaults()
      : _flags = const {
          FTFeatureFlag.authForgotPasswordEnabled,
          FTFeatureFlag.authScanToSignInEnabled,
          FTFeatureFlag.salesEnabled,
          FTFeatureFlag.salesAllShopElementsEnabled,
          FTFeatureFlag.scanEnabled,
          FTFeatureFlag.statisticsEnabled,
        };

  const FTFeatureFlags.staging()
      : _flags = const {
          FTFeatureFlag.authForgotPasswordEnabled,
          FTFeatureFlag.authScanToSignInEnabled,
          FTFeatureFlag.dev,
          FTFeatureFlag.salesEnabled,
          FTFeatureFlag.salesAllShopElementsEnabled,
          FTFeatureFlag.scanEnabled,
          FTFeatureFlag.statisticsEnabled,
        };

  const FTFeatureFlags.all()
      : _flags = const {
          FTFeatureFlag.authForgotPasswordEnabled,
          FTFeatureFlag.authScanToSignInEnabled,
          FTFeatureFlag.dev,
          FTFeatureFlag.salesEnabled,
          FTFeatureFlag.salesAllShopElementsEnabled,
          FTFeatureFlag.scanEnabled,
          FTFeatureFlag.statisticsEnabled,
        };

  /// Returns TRUE if the given [flag] is enabled.
  bool isEnabled(FTFeatureFlag flag) => _flags.contains(flag);

  /// Returns TRUE if all of the given [flags] are enabled.
  bool isAllEnabled(Iterable<FTFeatureFlag> flags) => flags.every(isEnabled);

  /// Returns TRUE if any of the given [flags] are enabled.
  bool isAnyEnabled(Iterable<FTFeatureFlag> flags) => flags.any(isEnabled);

  List<String> toJson() => _flags.map((f) => f.name).toList();
}
