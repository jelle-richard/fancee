import 'package:carrot/carrot.dart';

import 'bloc/bloc.dart';
import 'enum/enum.dart';
import 'environment.dart';
import 'feature_flags.dart';

extension FTClaimsExtension on BuildContext {
  /// Checks if the current user has the given [claim].
  bool userCan(FTUserClaim claim) {
    return read<FTAuthStateBloc>().state.user?.can(claim.name) ?? false;
  }

  /// Checks if the user has any of the given [claims].
  bool userCanAny(Iterable<FTUserClaim> claims) {
    return read<FTAuthStateBloc>().state.user?.canAny(claims.map((claim) => claim.name)) ?? false;
  }

  /// Checks if the user has all of the given [claims].
  bool userCanEvery(Iterable<FTUserClaim> claims) {
    return read<FTAuthStateBloc>().state.user?.canEvery(claims.map((claim) => claim.name)) ?? false;
  }

  bool get userHasSalesTab {
    if (read<FTAuthStateBloc>().state.user?.isOrganizer ?? false) {
      return true;
    }

    return userCan(FTUserClaim.sales);
  }

  bool get userHasScanTab {
    return userCanAny([FTUserClaim.scan, FTUserClaim.ticketScan]);
  }

  bool get userHasStatisticsTab {
    return userCanAny([FTUserClaim.statistics, FTUserClaim.ticketStatistics]);
  }
}

extension FTFeatureFlagsExtension on BuildContext {
  /// Returns TRUE if the given [flag] is enabled.
  bool isFeatureEnabled(FTFeatureFlag flag) {
    return FTEnvironment.of(this).featureFlags.isEnabled(flag);
  }

  /// Returns true if all of the given [flags] are enabled.
  bool isAllFeaturesEnabled(Iterable<FTFeatureFlag> flags) {
    return FTEnvironment.of(this).featureFlags.isAllEnabled(flags);
  }

  /// Returns TRUE if any of the given [flags] are enabled.
  bool isAnyFeatureEnabled(Iterable<FTFeatureFlag> flags) {
    return FTEnvironment.of(this).featureFlags.isAnyEnabled(flags);
  }
}
