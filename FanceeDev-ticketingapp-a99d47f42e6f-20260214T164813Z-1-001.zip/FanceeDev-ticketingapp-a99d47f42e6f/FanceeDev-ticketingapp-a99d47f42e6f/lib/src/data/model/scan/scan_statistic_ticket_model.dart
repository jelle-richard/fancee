import '../../../util/util.dart';
import '../media/media.dart';

class FTScanStatisticTicketModel {
  final String id;
  final String name;
  final List<FTMediaIdAndUrlModel> media;
  final int amountIssued;
  final int amountScanned;

  const FTScanStatisticTicketModel({
    required this.id,
    required this.name,
    required this.media,
    required this.amountIssued,
    required this.amountScanned,
  });

  factory FTScanStatisticTicketModel.fromJson(dynamic json) => FTScanStatisticTicketModel(
        id: toString(json['id']),
        name: toString(json['name']),
        media: toList(json['media']).map(FTMediaIdAndUrlModel.fromJson).toList(),
        amountIssued: toInt(json['amountIssued']),
        amountScanned: toInt(json['amountScanned']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'media': media,
        'amountIssued': amountIssued,
        'amountScanned': amountScanned,
      };
}
