import '../../../util/util.dart';
import '../../enum/enum.dart';
import 'scan_result_model.dart';

class FTScanHistoryEntry {
  final String barcode;
  final String? message;
  final FTScanState mode;
  final DateTime scannedOn;
  final FTScanResultType result;

  const FTScanHistoryEntry({
    required this.barcode,
    required this.mode,
    required this.scannedOn,
    required this.result,
    this.message,
  });

  factory FTScanHistoryEntry.fromDatabase(Map<String, dynamic> record) => FTScanHistoryEntry(
        barcode: toString(record['barcode']),
        message: toNullable(record['message'], toString),
        mode: FTScanState.fromString(toString(record['mode'])),
        scannedOn: toDateTime(record['scanned_on']),
        result: FTScanResultType.fromString(toString(record['result'])),
      );

  factory FTScanHistoryEntry.fromResponseModel(String barcode, FTScanState mode, DateTime scannedOn, FTScanResultModel model) => FTScanHistoryEntry(
        barcode: barcode,
        message: model.message ?? model.reason,
        mode: mode,
        scannedOn: scannedOn,
        result: model.type,
      );

  Map<String, dynamic> toDatabase() => {
        'barcode': barcode,
        'message': message,
        'mode': mode.value,
        'result': result.name,
        'scanned_on': scannedOn.toIso8601String(),
      };
}
