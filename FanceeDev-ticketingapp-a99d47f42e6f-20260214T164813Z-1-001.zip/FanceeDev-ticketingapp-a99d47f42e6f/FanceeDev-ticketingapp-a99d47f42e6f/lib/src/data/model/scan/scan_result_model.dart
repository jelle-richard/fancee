import '../../enum/enum.dart';

class FTScanResultModel {
  final FTScanResultType type;
  final String? message;
  final String? reason;

  const FTScanResultModel.failed({
    required this.reason,
  })  : type = FTScanResultType.failed,
        message = null;

  const FTScanResultModel.invalid({
    required this.reason,
  })  : type = FTScanResultType.invalid,
        message = null;

  const FTScanResultModel.ok({
    required this.message,
  })  : type = FTScanResultType.ok,
        reason = null;

  const FTScanResultModel.reused({
    required this.message,
  })  : type = FTScanResultType.reused,
        reason = null;
}
