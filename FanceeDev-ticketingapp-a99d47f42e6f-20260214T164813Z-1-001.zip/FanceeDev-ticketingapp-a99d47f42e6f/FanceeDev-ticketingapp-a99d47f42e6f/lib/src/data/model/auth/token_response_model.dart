import '../../../util/util.dart';
import '../model.dart';

abstract class FTAuthTokenResponseModel {
  final String accessToken;
  final FTBaseUserModel user;
  final DateTime validUntil;

  const FTAuthTokenResponseModel({
    required this.accessToken,
    required this.user,
    required this.validUntil,
  });

  Map<String, dynamic> toJson() => {
        'accessToken': accessToken,
        'user': user,
        'validUntil': validUntil.toString(),
      };
}

class FTAuthTokenAppTeamResponseModel extends FTAuthTokenResponseModel {
  const FTAuthTokenAppTeamResponseModel({
    required super.accessToken,
    required super.validUntil,
    required super.user,
  });

  factory FTAuthTokenAppTeamResponseModel.fromJson(dynamic json) => FTAuthTokenAppTeamResponseModel(
        accessToken: toString(json['token']),
        validUntil: toDateTime(json['validUntil']),
        user: FTAppTeamUserModel.fromJson({
          'id': toString(json['id']),
          'claims': json['claims'],
          'name': toString(json['name']),
          'organization': toString(json['organization']),
        }),
      );
}

class FTAuthTokenUserResponseModel extends FTAuthTokenResponseModel {
  const FTAuthTokenUserResponseModel({
    required super.accessToken,
    required super.validUntil,
    required super.user,
  });

  factory FTAuthTokenUserResponseModel.fromJson(dynamic json) => FTAuthTokenUserResponseModel(
        accessToken: toString(json['token']),
        validUntil: toDateTime(json['validUntil']),
        user: FTOrganizerUserModel.fromJson({
          'claims': json['claims'],
          ...(json['user'] as Map),
        }),
      );
}
