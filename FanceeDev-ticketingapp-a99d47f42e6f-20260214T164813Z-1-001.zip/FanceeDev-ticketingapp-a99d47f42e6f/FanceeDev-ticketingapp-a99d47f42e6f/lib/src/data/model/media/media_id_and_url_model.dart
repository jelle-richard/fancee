import '../../../util/util.dart';

class FTMediaIdAndUrlModel {
  final String id;
  final String url;

  const FTMediaIdAndUrlModel({
    required this.id,
    required this.url,
  });

  factory FTMediaIdAndUrlModel.fromJson(dynamic json) => FTMediaIdAndUrlModel(
        id: toString(json['id']),
        url: toString(json['url']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'url': url,
      };
}
