import '../../../util/util.dart';

class FTAddressModel {
  final String? street;
  final String? houseNumber;
  final String? postalCode;
  final String? city;
  final String? countryCode;
  final String? venue;
  final double? latitude;
  final double? longitude;

  const FTAddressModel({
    this.street,
    this.houseNumber,
    this.postalCode,
    this.city,
    this.countryCode,
    this.venue,
    this.latitude,
    this.longitude,
  });

  factory FTAddressModel.fromJson(dynamic json) => FTAddressModel(
        street: toNullable(json['street'], toString),
        houseNumber: toNullable(json['houseNumber'], toString),
        postalCode: toNullable(json['postalCode'], toString),
        city: toNullable(json['city'], toString),
        countryCode: toNullable(json['countryCode'], toString),
        venue: toNullable(json['venue'], toString),
        latitude: toNullable(json['latitude'], toDouble),
        longitude: toNullable(json['longitude'], toDouble),
      );

  Map<String, dynamic> toJson() => {
        'street': street,
        'houseNumber': houseNumber,
        'postalCode': postalCode,
        'city': city,
        'countryCode': countryCode,
        'venue': venue,
        'latitude': latitude,
        'longitude': longitude,
      };
}
