import '../../../util/util.dart';
import '../../enum/enum.dart';
import '../media/media.dart';
import 'order_product_issued_ticket_model.dart';

class FTOrderProductModel {
  final String name;
  final int priceCents;
  final List<FTMediaIdAndUrlModel> media;
  final FTProductType type;
  final List<FTOrderProductIssuedTicketModel> issuedTickets;

  const FTOrderProductModel({
    required this.name,
    required this.priceCents,
    required this.media,
    required this.type,
    required this.issuedTickets,
  });

  factory FTOrderProductModel.fromJson(dynamic json) => FTOrderProductModel(
        name: toString(json['name']),
        priceCents: toInt(json['priceCents']),
        media: toList(json['media']).map(FTMediaIdAndUrlModel.fromJson).toList(),
        type: FTProductType.fromString(toString(json['type'])),
        issuedTickets: toList(json['issuedTickets']).map(FTOrderProductIssuedTicketModel.fromJson).toList(),
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'priceCents': priceCents,
        'media': media,
        'type': type,
        'issuedTickets': issuedTickets,
      };
}
