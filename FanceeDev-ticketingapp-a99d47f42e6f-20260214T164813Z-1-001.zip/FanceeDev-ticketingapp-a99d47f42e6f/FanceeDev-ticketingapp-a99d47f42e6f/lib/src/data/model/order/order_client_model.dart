import '../../../util/util.dart';
import '../../enum/enum.dart';
import '../geo/geo.dart';

class FTOrderClientModel {
  final String email;
  final String? firstName;
  final String? lastName;
  final String? phoneNumber;
  final FTAddressModel? address;
  final DateTime? birthDate;
  final FTGender? gender;
  final bool optInPromotionalEmail;
  final bool optInPromotionalSms;
  final int receiveViaSmsCostCents;
  final int ticketServicePlusCostCents;

  const FTOrderClientModel({
    required this.email,
    required this.optInPromotionalEmail,
    required this.optInPromotionalSms,
    required this.receiveViaSmsCostCents,
    required this.ticketServicePlusCostCents,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.address,
    this.birthDate,
    this.gender,
  });

  factory FTOrderClientModel.fromJson(dynamic json) => FTOrderClientModel(
        email: toString(json['email']),
        optInPromotionalEmail: toBoolean(json['optInPromotionalEmail']),
        optInPromotionalSms: toBoolean(json['optInPromotionalSms']),
        receiveViaSmsCostCents: toInt(json['receiveViaSmsCostCents']),
        ticketServicePlusCostCents: toInt(json['ticketServicePlusCostCents']),
        firstName: toNullable(json['firstName'], toString),
        lastName: toNullable(json['lastName'], toString),
        phoneNumber: toNullable(json['phoneNumber'], toString),
        address: toNullable(json['address'], FTAddressModel.fromJson),
        birthDate: toNullable(json['birthdate'], toDateTime),
        gender: toNullableEnum(json['gender'], FTGender.fromString),
      );

  Map<String, dynamic> toJson() => {
        'email': email,
        'optInPromotionalEmails': optInPromotionalEmail,
        'optInPromotionalSms': optInPromotionalSms,
        'receiveViaSmsCostCents': receiveViaSmsCostCents,
        'ticketServicePlusCostCents': ticketServicePlusCostCents,
        'firstName': firstName,
        'lastName': lastName,
        'phoneNumber': phoneNumber,
        'address': address,
        'birthDate': birthDate?.toString(),
        'gender': gender,
      };
}
