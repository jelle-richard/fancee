import '../../../util/util.dart';
import 'order_event_organizer_model.dart';

class FTOrderEventModel {
  final String name;
  final DateTime startDate;
  final FTOrderEventOrganizerModel organizer;

  const FTOrderEventModel({
    required this.name,
    required this.startDate,
    required this.organizer,
  });

  factory FTOrderEventModel.fromJson(dynamic json) => FTOrderEventModel(
        name: toString(json['name']),
        startDate: toDateTime(json['startDate']),
        organizer: FTOrderEventOrganizerModel.fromJson(json['organizer']),
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'startDate': startDate.toString(),
        'organizer': organizer,
      };
}
