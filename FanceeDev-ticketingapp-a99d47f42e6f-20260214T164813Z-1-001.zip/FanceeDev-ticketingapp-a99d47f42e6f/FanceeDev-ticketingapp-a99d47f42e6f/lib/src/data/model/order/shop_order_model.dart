import '../../../util/util.dart';
import 'shop_order_client_model.dart';

class FTShopOrderModel {
  final String reservationReference;
  final FTShopOrderClientModel client;
  final String paymentMethodId;
  final bool receiveViaSms;
  final bool optInPromotionalEmail;
  final bool optInPromotionalSms;
  final bool enableTicketServicePlus;

  const FTShopOrderModel({
    required this.reservationReference,
    required this.client,
    required this.receiveViaSms,
    required this.optInPromotionalEmail,
    required this.optInPromotionalSms,
    required this.enableTicketServicePlus,
    this.paymentMethodId = '00000000-0000-0000-0000-000000000000',
  });

  factory FTShopOrderModel.fromJson(dynamic json) => FTShopOrderModel(
        reservationReference: toString(json['reservationReference']),
        client: FTShopOrderClientModel.fromJson(json['orderClient']),
        paymentMethodId: toString(json['paymentMethodId']),
        receiveViaSms: toBoolean(json['receiveViaSms']),
        optInPromotionalEmail: toBoolean(json['optInPromotionalEmail']),
        optInPromotionalSms: toBoolean(json['optInPromotionalSms']),
        enableTicketServicePlus: toBoolean(json['enabledTicketServicePlus']),
      );

  FTShopOrderModel copyWith({
    String? reservationReference,
    FTShopOrderClientModel? client,
    String? paymentMethodId,
    bool? receiveViaSms,
    bool? optInPromotionalEmail,
    bool? optInPromotionalSms,
    bool? enableTicketServicePlus,
  }) =>
      FTShopOrderModel(
        reservationReference: reservationReference ?? this.reservationReference,
        client: client ?? this.client,
        paymentMethodId: paymentMethodId ?? this.paymentMethodId,
        receiveViaSms: receiveViaSms ?? this.receiveViaSms,
        optInPromotionalEmail: optInPromotionalEmail ?? this.optInPromotionalEmail,
        optInPromotionalSms: optInPromotionalSms ?? this.optInPromotionalSms,
        enableTicketServicePlus: enableTicketServicePlus ?? this.enableTicketServicePlus,
      );

  Map<String, dynamic> toJson() => {
        'reservationReference': reservationReference,
        'orderClient': client,
        'paymentMethodId': paymentMethodId,
        'receiveViaSms': receiveViaSms,
        'optInPromotionalEmail': optInPromotionalEmail,
        'optInPromotionalSms': optInPromotionalSms,
        'enabledTicketServicePlus': enableTicketServicePlus,
      };
}
