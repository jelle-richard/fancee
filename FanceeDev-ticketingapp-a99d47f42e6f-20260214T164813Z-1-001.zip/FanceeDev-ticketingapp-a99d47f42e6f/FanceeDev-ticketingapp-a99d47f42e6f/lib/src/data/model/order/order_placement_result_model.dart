import '../../../util/util.dart';

class FTOrderPlacementResultModel {
  final String orderId;
  final String? redirectUrl;

  const FTOrderPlacementResultModel({
    required this.orderId,
    this.redirectUrl,
  });

  factory FTOrderPlacementResultModel.fromJson(dynamic json) => FTOrderPlacementResultModel(
        orderId: toString(json['orderId']),
        redirectUrl: toNullable(json['redirectUrl'], toString),
      );

  Map<String, dynamic> toJson() => {
        'orderId': orderId,
        'redirectUrl': redirectUrl,
      };
}
