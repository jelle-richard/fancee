import '../../../util/util.dart';

class FTReservedProductModel {
  final String productId;
  final int quantity;

  const FTReservedProductModel({
    required this.productId,
    required this.quantity,
  });

  factory FTReservedProductModel.fromJson(dynamic json) => FTReservedProductModel(
        productId: toString(json['productId']),
        quantity: toInt(json['quantity']),
      );

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'quantity': quantity,
      };
}
