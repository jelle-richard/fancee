import '../../../util/util.dart';

class FTOrderEventOrganizerModel {
  final String name;
  final int productFeeCents;
  final int ticketFeeCents;

  const FTOrderEventOrganizerModel({
    required this.name,
    required this.productFeeCents,
    required this.ticketFeeCents,
  });

  factory FTOrderEventOrganizerModel.fromJson(dynamic json) => FTOrderEventOrganizerModel(
        name: toString(json['name']),
        productFeeCents: toInt(json['productFeeCents']),
        ticketFeeCents: toInt(json['ticketFeeCents']),
      );

  Map<String, dynamic> toJson() => {
        'name': name,
        'productFeeCents': productFeeCents,
        'ticketFeeCents': ticketFeeCents,
      };
}
