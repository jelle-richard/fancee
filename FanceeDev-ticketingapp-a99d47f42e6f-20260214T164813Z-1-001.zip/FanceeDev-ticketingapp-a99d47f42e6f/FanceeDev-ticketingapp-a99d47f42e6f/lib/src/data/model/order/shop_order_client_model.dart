import '../../../util/util.dart';
import '../../enum/enum.dart';
import '../geo/geo.dart';

class FTShopOrderClientModel {
  final String email;
  final String? firstName;
  final String? lastName;
  final String? phoneNumber;
  final DateTime? birthDate;
  final FTGender? gender;
  final FTAddressModel? address;

  const FTShopOrderClientModel({
    required this.email,
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.birthDate,
    this.gender,
    this.address,
  });

  factory FTShopOrderClientModel.fromJson(dynamic json) => FTShopOrderClientModel(
        email: toString(json['email']),
        firstName: toNullable(json['firstName'], toString),
        lastName: toNullable(json['lastName'], toString),
        phoneNumber: toNullable(json['phoneNumber'], toString),
        birthDate: toNullable(json['birthDate'], toDateTime),
        gender: FTGender.fromString(toNullable(json['gender'], toString)),
        address: FTAddressModel.fromJson(json['address']),
      );

  FTShopOrderClientModel copyWith({
    String? email,
    String? firstName,
    String? lastName,
    String? phoneNumber,
    DateTime? birthDate,
    FTGender? gender,
    FTAddressModel? address,
  }) =>
      FTShopOrderClientModel(
        email: email ?? this.email,
        firstName: firstName ?? this.firstName,
        lastName: lastName ?? this.lastName,
        phoneNumber: phoneNumber ?? this.phoneNumber,
        birthDate: birthDate ?? this.birthDate,
        gender: gender ?? this.gender,
        address: address ?? this.address,
      );

  Map<String, dynamic> toJson() => {
        'email': email,
        'firstName': firstName,
        'lastName': lastName,
        'phoneNumber': phoneNumber,
        'birthDate': birthDate?.formatForApi(),
        'gender': gender,
        'address': address,
      };
}
