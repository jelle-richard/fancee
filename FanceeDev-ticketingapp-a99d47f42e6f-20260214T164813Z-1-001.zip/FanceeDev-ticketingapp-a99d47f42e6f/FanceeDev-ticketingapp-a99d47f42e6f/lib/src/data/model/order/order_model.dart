import '../../../util/util.dart';
import '../finance/finance.dart';
import 'order_client_model.dart';
import 'order_event_model.dart';
import 'order_product_model.dart';

class FTOrderModel {
  final String id;
  final int costCents;
  final String paymentMethod;
  final DateTime placedOn;
  final String? pspReference;
  final String transactionStatus;
  final FTOrderClientModel client;
  final FTCurrencyModel currency;
  final FTOrderEventModel event;
  final List<FTOrderProductModel> products;

  const FTOrderModel({
    required this.id,
    required this.costCents,
    required this.paymentMethod,
    required this.placedOn,
    required this.transactionStatus,
    required this.client,
    required this.currency,
    required this.event,
    required this.products,
    this.pspReference,
  });

  factory FTOrderModel.fromJson(dynamic json) => FTOrderModel(
        id: toString(json['id']),
        costCents: toInt(json['costCents']),
        paymentMethod: toString(json['paymentMethod']),
        placedOn: toDateTime(json['placedOn']),
        pspReference: toNullable(json['pspReference'], toString),
        transactionStatus: toString(json['transactionStatus']),
        client: FTOrderClientModel.fromJson(json['client']),
        currency: FTCurrencyModel.fromJson(json['currency']),
        event: FTOrderEventModel.fromJson(json['event']),
        products: toList(json['products']).map(FTOrderProductModel.fromJson).toList(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'costCents': costCents,
        'paymentMethod': paymentMethod,
        'placedOn': placedOn.toString(),
        'pspReference': pspReference,
        'transactionStatus': transactionStatus,
        'client': client,
        'currency': currency,
        'event': event,
        'products': products,
      };
}
