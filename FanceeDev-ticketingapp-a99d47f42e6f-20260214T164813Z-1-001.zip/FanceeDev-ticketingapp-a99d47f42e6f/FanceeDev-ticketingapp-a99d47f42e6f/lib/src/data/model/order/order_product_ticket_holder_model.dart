import '../../../util/util.dart';
import '../../enum/enum.dart';

class FTOrderProductTicketHolderModel {
  final String code;
  final String email;
  final String? firstName;
  final String? lastName;
  final FTGender? gender;
  final DateTime personalizedOn;

  const FTOrderProductTicketHolderModel({
    required this.code,
    required this.email,
    required this.personalizedOn,
    this.firstName,
    this.lastName,
    this.gender,
  });

  factory FTOrderProductTicketHolderModel.fromJson(dynamic json) => FTOrderProductTicketHolderModel(
        code: toString(json['code']),
        email: toString(json['email']),
        personalizedOn: toDateTime(json['personalizedOn']),
        firstName: toNullable(json['firstName'], toString),
        lastName: toNullable(json['lastName'], toString),
        gender: toNullableEnum(json['gender'], FTGender.fromString),
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'email': email,
        'personalizedOn': personalizedOn.toString(),
        'firstName': firstName,
        'lastName': lastName,
        'gender': gender,
      };
}
