import '../../../util/util.dart';
import 'order_product_ticket_holder_model.dart';

class FTOrderProductIssuedTicketModel {
  final String code;
  final FTOrderProductTicketHolderModel holder;

  const FTOrderProductIssuedTicketModel({
    required this.code,
    required this.holder,
  });

  factory FTOrderProductIssuedTicketModel.fromJson(dynamic json) => FTOrderProductIssuedTicketModel(
        code: toString(json['code']),
        holder: FTOrderProductTicketHolderModel.fromJson(json['holder']),
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'holder': holder,
      };
}
