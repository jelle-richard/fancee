import 'package:carrot/carrot.dart';

import '../../../util/util.dart';
import 'base_user_model.dart';

class FTAppTeamUserModel extends FTBaseUserModel {
  final String id;
  final String name;
  final String organization;

  @override
  String get displayName => name;

  @override
  String get displayInfo => organization;

  const FTAppTeamUserModel({
    required super.claims,
    required this.id,
    required this.name,
    required this.organization,
  }) : super.appTeam();

  factory FTAppTeamUserModel.fromJson(dynamic json) => FTAppTeamUserModel(
        id: toString(json['id']),
        claims: toStringSet(json['claims'] ?? []),
        name: toString(json['name']),
        organization: toString(json['organization']),
      );

  FTAppTeamUserModel copyWith({
    Set<String>? claims,
    String? id,
    String? name,
    String? organization,
  }) =>
      FTAppTeamUserModel(
        id: id ?? this.id,
        claims: claims ?? this.claims,
        name: name ?? this.name,
        organization: organization ?? this.organization,
      );

  @override
  Map<String, dynamic> toJson() => {
        ...super.toJson(),
        'id': id,
        'name': name,
        'organization': organization,
      };

  @override
  Widget buildAvatar(BuildContext context) {
    return const CarrotAvatar.letters('📳');
  }
}
