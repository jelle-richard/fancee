import 'package:carrot/carrot.dart';

import '../../../util/util.dart';
import 'base_user_model.dart';

class FTOrganizerUserModel extends FTBaseUserModel {
  final String id;
  final String email;
  final String firstName;
  final String lastName;
  final String type;
  final String? avatarFilePath;
  final DateTime lastLogin;

  @override
  bool get isOrganizer => super.isOrganizer && type == 'Organizer';

  @override
  String get displayName => '$firstName $lastName';

  @override
  String get displayInfo => email;

  const FTOrganizerUserModel({
    required super.claims,
    required this.id,
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.type,
    required this.lastLogin,
    this.avatarFilePath,
  }) : super.organizer();

  factory FTOrganizerUserModel.fromJson(dynamic json) => FTOrganizerUserModel(
        id: toString(json['id']),
        claims: toStringSet(json['claims'] ?? []),
        email: toString(json['email']),
        firstName: toString(json['firstName']),
        lastName: toString(json['lastName']),
        type: toString(json['type']),
        lastLogin: toDateTime(json['lastLogin']),
        avatarFilePath: toNullable(json['avatarFilePath'], toString),
      );

  FTOrganizerUserModel copyWith({
    Set<String>? claims,
    String? id,
    String? email,
    String? firstName,
    String? lastName,
    String? type,
    String? avatarFilePath,
    DateTime? lastLogin,
  }) =>
      FTOrganizerUserModel(
        id: id ?? this.id,
        claims: claims ?? this.claims,
        email: email ?? this.email,
        firstName: firstName ?? this.firstName,
        lastName: lastName ?? this.lastName,
        type: type ?? this.type,
        avatarFilePath: avatarFilePath ?? this.avatarFilePath,
        lastLogin: lastLogin ?? this.lastLogin,
      );

  @override
  Map<String, dynamic> toJson() => {
        ...super.toJson(),
        'id': id,
        'email': email,
        'firstName': firstName,
        'lastName': lastName,
        'type': type,
        'lastLogin': lastLogin.toString(),
        'avatarFilePath': avatarFilePath,
      };

  @override
  Widget buildAvatar(BuildContext context) {
    // todo(Bas): Uncomment and update hardcoded url when FAN-647 is done.
    // if (avatarFilePath != null) {
    //   return const CarrotAvatar.image(NetworkImage('https://imgproxy.glybe.nl/240,q75,jpg/1-b38d42e52f851f0ec94d118fad965277e3915b89da1012cef7e58674e3cf219a-img1386.jpeg'));
    // }

    late String letters;

    if (firstName.isNotEmpty && lastName.isNotEmpty) {
      letters = '${firstName[0]}${lastName[0]}';
    } else if (firstName.isNotEmpty) {
      letters = firstName[0];
    } else if (lastName.isNotEmpty) {
      letters = lastName[0];
    } else {
      letters = '❤';
    }

    return CarrotAvatar.letters(letters);
  }
}
