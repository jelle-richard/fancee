import 'package:carrot/carrot.dart';

import '../../enum/enum.dart';
import 'app_team_user_model.dart';
import 'organizer_user_model.dart';

abstract class FTBaseUserModel {
  final Set<String> claims;
  final FTUserType userType;

  bool get isAppTeam => userType == FTUserType.appTeam;

  bool get isOrganizer => userType == FTUserType.organizer;

  String get displayName;

  String get displayInfo;

  const FTBaseUserModel.appTeam({
    required this.claims,
  }) : userType = FTUserType.appTeam;

  const FTBaseUserModel.organizer({
    required this.claims,
  }) : userType = FTUserType.organizer;

  factory FTBaseUserModel.fromJson(dynamic json) {
    if (json is! Map || !json.containsKey('_type')) {
      throw ArgumentError('Invalid json.');
    }

    switch (json['_type']) {
      case 'appTeam':
        return FTAppTeamUserModel.fromJson(json);

      case 'organizer':
        return FTOrganizerUserModel.fromJson(json);
    }

    throw ArgumentError('Invalid user type in json.');
  }

  /// Checks if the user has the given [claim].
  bool can(String claim) => claims.contains(claim);

  /// Checks if the user has any of the given [claims].
  bool canAny(Iterable<String> claims) => this.claims.any(claims.contains);

  /// Checks if the user has all of the given [claims].
  bool canEvery(Iterable<String> claims) => this.claims.every(claims.contains);

  /// Returns a [Widget] that represents the user's avatar.
  Widget buildAvatar(BuildContext context);

  Map<String, dynamic> toJson() => {
        '_type': userType.name,
        'claims': claims.toList(),
      };
}
