import '../../../util/util.dart';
import '../../enum/enum.dart';

class FTPaymentMethodModel {
  final String id;
  final String method;
  final int position;
  final FTPaymentMethodPaidByType paidBy;
  final double? feePercent;
  final int? feeStaticCents;

  const FTPaymentMethodModel({
    required this.id,
    required this.method,
    required this.position,
    required this.paidBy,
    this.feePercent,
    this.feeStaticCents,
  });

  factory FTPaymentMethodModel.fromJson(dynamic json) => FTPaymentMethodModel(
        id: toString(json['id']),
        method: toString(json['method']),
        position: toInt(json['position']),
        paidBy: FTPaymentMethodPaidByType.fromString(toString(json['paidBy'])),
        feePercent: toNullable(json['feePercent'], toDouble),
        feeStaticCents: toNullable(json['feeStaticCents'], toInt),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'method': method,
        'position': position,
        'paidBy': paidBy,
        'feePercent': feePercent,
        'feeStaticCents': feeStaticCents,
      };
}
