import 'package:carrot/carrot.dart';
import 'package:intl/intl.dart';

import '../../../util/util.dart';

class FTCurrencyModel {
  final String character;
  final String name;
  final String shortcode;

  const FTCurrencyModel({
    required this.character,
    required this.name,
    required this.shortcode,
  });

  factory FTCurrencyModel.fromJson(dynamic json) => FTCurrencyModel(
        character: toString(json['character']),
        name: toString(json['name']),
        shortcode: toString(json['shortcode'] ?? json['shortCode']),
      );

  Map<String, dynamic> toJson() => {
        'character': character,
        'name': name,
        'shortcode': shortcode,
      };

  String format(Locale locale, int cents, {bool symbol = true}) => NumberFormat.currency(
        decimalDigits: 2,
        locale: locale.countryCode ?? locale.languageCode,
        symbol: symbol ? character : null,
      ).format(cents / 100.0);
}
