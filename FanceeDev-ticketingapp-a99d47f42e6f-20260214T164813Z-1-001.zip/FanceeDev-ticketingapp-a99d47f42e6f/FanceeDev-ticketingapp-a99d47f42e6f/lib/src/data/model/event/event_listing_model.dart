import '../../../util/util.dart';
import '../../enum/enum.dart';
import 'event_shop_listing_model.dart';

class FTEventListingModel {
  final String id;
  final String name;
  final DateTime date;
  final List<FTEventShopListingModel> shops;
  final FTEventStatus status;
  final FTEventType type;

  const FTEventListingModel({
    required this.id,
    required this.name,
    required this.date,
    required this.shops,
    required this.status,
    required this.type,
  });

  factory FTEventListingModel.fromJson(dynamic json) => FTEventListingModel(
        id: toString(json['id']),
        name: toString(json['name']),
        date: toDateTime(json['date']),
        shops: toList(json['shops']).map(FTEventShopListingModel.fromJson).toList(),
        status: FTEventStatus.fromString(toString(json['status'])),
        type: FTEventType.fromString(toString(json['type'])),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'date': date.toString(),
        'shops': shops,
        'status': status,
        'type': type,
      };
}
