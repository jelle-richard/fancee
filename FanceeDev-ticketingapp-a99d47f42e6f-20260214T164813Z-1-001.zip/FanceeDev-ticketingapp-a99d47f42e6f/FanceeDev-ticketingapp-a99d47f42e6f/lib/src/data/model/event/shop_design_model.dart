import 'dart:ui';

import '../../../util/util.dart';
import '../media/media.dart';

class FTShopDesignModel {
  final Color backdropColor;
  final Color backgroundColor;
  final dynamic backgroundMedia;
  final List<FTMediaIdAndUrlModel> headerMedia;
  final Color linkColor;
  final Color primaryColor;
  final Color textColor;

  const FTShopDesignModel({
    required this.backdropColor,
    required this.backgroundColor,
    required this.backgroundMedia,
    required this.headerMedia,
    required this.linkColor,
    required this.primaryColor,
    required this.textColor,
  });

  factory FTShopDesignModel.fromJson(dynamic json) => FTShopDesignModel(
        backdropColor: toColor(json['backdropColor']),
        backgroundColor: toColor(json['backgroundColor']),
        backgroundMedia: json['backgroundMedia'],
        headerMedia: toList(json['headerMedia']).map(FTMediaIdAndUrlModel.fromJson).toList(),
        linkColor: toColor(json['linkColor']),
        primaryColor: toColor(json['primaryColor']),
        textColor: toColor(json['textColor']),
      );

  Map<String, dynamic> toJson() => {
        'backdropColor': backdropColor.value.toRadixString(16),
        'backgroundColor': backgroundColor.value.toRadixString(16),
        'backgroundMedia': backgroundMedia,
        'headerMedia': headerMedia,
        'linkColor': linkColor.value.toRadixString(16),
        'primaryColor': primaryColor.value.toRadixString(16),
        'textColor': textColor.value.toRadixString(16),
      };
}
