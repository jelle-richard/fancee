import '../../../util/util.dart';
import 'event_model.dart';
import 'shop_design_model.dart';
import 'shop_element_model.dart';
import 'shop_field_model.dart';

class FTShopModel {
  final String code;
  final String name;
  final FTEventModel event;
  final List<FTShopElementModel> elements;
  final FTShopDesignModel design;
  final List<FTShopFieldModel> fields;
  final bool isQueueEnabled;
  final bool isReservationShop;
  final bool isSecured;
  final String layout; // Ticketshop, Webshop, List (not needed in app (at least for now), so no dedicated enum)
  final DateTime startDate;
  final DateTime endDate;
  final int platformSmsCostCents;
  final int platformTicketServicePlusCostCents;

  const FTShopModel({
    required this.code,
    required this.name,
    required this.event,
    required this.elements,
    required this.design,
    required this.fields,
    required this.isQueueEnabled,
    required this.isReservationShop,
    required this.isSecured,
    required this.layout,
    required this.startDate,
    required this.endDate,
    required this.platformSmsCostCents,
    required this.platformTicketServicePlusCostCents,
  });

  factory FTShopModel.fromJson(dynamic json, String code, String name) => FTShopModel(
        code: code,
        name: name,
        event: FTEventModel.fromJson(json['event']),
        elements: toList(json['elements']).map(FTShopElementModel.fromJson).toList(),
        design: FTShopDesignModel.fromJson(json['design']),
        fields: toList(json['shopFields']).map(FTShopFieldModel.fromJson).toList(),
        isQueueEnabled: toBoolean(json['queueEnabled']),
        isReservationShop: toBoolean(json['isReservationShop']),
        isSecured: toBoolean(json['secured']),
        layout: toString(json['layout']),
        startDate: toDateTime(json['startDate']),
        endDate: toDateTime(json['endDate']),
        platformSmsCostCents: toInt(json['platformSmsCostCents']),
        platformTicketServicePlusCostCents: toInt(json['platformTicketServicePlusCostCents']),
      );

  Map<String, dynamic> toJson() => {
        'code': code,
        'name': name,
        'event': event,
        'elements': elements,
        'design': design,
        'shopFields': fields,
        'queueEnabled': isQueueEnabled,
        'isReservationShop': isReservationShop,
        'secured': isSecured,
        'layout': layout,
        'startDate': startDate.toString(),
        'endDate': endDate.toString(),
        'platformSmsCostCents': platformSmsCostCents,
        'platformTicketServicePlusCostCents': platformTicketServicePlusCostCents,
      };
}
