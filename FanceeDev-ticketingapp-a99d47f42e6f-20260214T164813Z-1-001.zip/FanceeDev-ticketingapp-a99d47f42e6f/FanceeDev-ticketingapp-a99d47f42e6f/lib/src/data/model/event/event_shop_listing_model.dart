import '../../../util/util.dart';
import '../media/media.dart';

class FTEventShopListingModel {
  final bool active;
  final String code;
  final String name;
  final List<FTMediaIdAndUrlModel> headerMedia;

  const FTEventShopListingModel({
    required this.active,
    required this.code,
    required this.name,
    required this.headerMedia,
  });

  factory FTEventShopListingModel.fromJson(dynamic json) => FTEventShopListingModel(
        active: toBoolean(json['active']),
        code: toString(json['code']),
        name: toString(json['name']),
        headerMedia: toList(json['headerMedia']).map(FTMediaIdAndUrlModel.fromJson).toList(),
      );

  Map<String, dynamic> toJson() => {
        'active': active,
        'code': code,
        'name': name,
        'headerMedia': headerMedia,
      };
}
