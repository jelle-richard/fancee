import '../../../util/util.dart';
import '../../enum/enum.dart';

class FTShopFormModel {
  final String email;
  final String? firstName;
  final String? lastName;
  final DateTime? birthDate;
  final String? phoneNumber;
  final FTGender? gender;

  String? get fullName {
    if (firstName == null && lastName == null) {
      return null;
    }

    if (firstName != null && lastName != null) {
      return '$firstName $lastName';
    }

    return firstName ?? lastName;
  }

  const FTShopFormModel({
    this.email = '',
    this.firstName,
    this.lastName,
    this.phoneNumber,
    this.birthDate,
    this.gender,
  });

  FTShopFormModel copyWith({
    String? email,
    String? firstName,
    String? lastName,
    DateTime? birthDate,
    String? phoneNumber,
    FTGender? gender,
  }) =>
      FTShopFormModel(
        email: email ?? this.email,
        firstName: firstName ?? this.firstName,
        lastName: lastName ?? this.lastName,
        birthDate: birthDate ?? this.birthDate,
        phoneNumber: phoneNumber ?? this.phoneNumber,
        gender: gender ?? this.gender,
      );

  Map<String, dynamic> toJson() => {
        'email': email,
        'firstName': firstName,
        'lastName': lastName,
        'birthDate': birthDate?.formatForApi(),
        'phoneNumber': phoneNumber,
        'gender': gender,
      };
}
