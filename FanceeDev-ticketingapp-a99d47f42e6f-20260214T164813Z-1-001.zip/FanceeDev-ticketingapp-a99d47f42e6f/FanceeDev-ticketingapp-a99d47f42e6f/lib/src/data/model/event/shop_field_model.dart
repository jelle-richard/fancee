import '../../../util/util.dart';
import '../../enum/enum.dart';

class FTShopFieldModel {
  final FTShopFieldType field;
  final bool enabled;
  final bool required;

  const FTShopFieldModel({
    required this.field,
    required this.enabled,
    required this.required,
  });

  factory FTShopFieldModel.fromJson(dynamic json) => FTShopFieldModel(
        field: FTShopFieldType.fromString(toString(json['field'])),
        enabled: toBoolean(json['enabled']),
        required: toBoolean(json['required']),
      );

  Map<String, dynamic> toJson() => {
        'field': field,
        'enabled': enabled,
        'required': required,
      };
}
