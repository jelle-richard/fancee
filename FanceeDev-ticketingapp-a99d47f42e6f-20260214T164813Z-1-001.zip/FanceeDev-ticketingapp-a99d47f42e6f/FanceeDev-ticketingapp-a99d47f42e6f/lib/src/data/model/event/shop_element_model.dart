import '../../../util/util.dart';
import '../../enum/enum.dart';
import '../media/media.dart';

class FTShopElementModel {
  final FTShopElementType kind;

  const FTShopElementModel.unknown() : kind = FTShopElementType.unknown;

  const FTShopElementModel.divider() : kind = FTShopElementType.divider;

  const FTShopElementModel.externalLink() : kind = FTShopElementType.externalLink;

  const FTShopElementModel.notice() : kind = FTShopElementType.notice;

  const FTShopElementModel.product() : kind = FTShopElementType.product;

  const FTShopElementModel.textBlock() : kind = FTShopElementType.textBlock;

  factory FTShopElementModel.fromJson(dynamic json) {
    final kind = FTShopElementType.fromString(toString(json['kind']));

    switch (kind) {
      case FTShopElementType.unknown:
        return const FTShopElementUnknownModel();

      case FTShopElementType.divider:
        return FTShopElementDividerModel.fromJson(json);

      case FTShopElementType.externalLink:
        return FTShopElementExternalLinkModel.fromJson(json);

      case FTShopElementType.notice:
        return FTShopElementNoticeModel.fromJson(json);

      case FTShopElementType.product:
        return FTShopElementProductModel.fromJson(json);

      case FTShopElementType.textBlock:
        return FTShopElementTextBlockModel.fromJson(json);
    }
  }

  Map<String, dynamic> toJson() => {
        'kind': kind,
      };
}

class FTShopElementUnknownModel extends FTShopElementModel {
  const FTShopElementUnknownModel() : super.unknown();
}

class FTShopElementDividerModel extends FTShopElementModel {
  final String name;

  const FTShopElementDividerModel({
    required this.name,
  }) : super.divider();

  factory FTShopElementDividerModel.fromJson(dynamic json) => FTShopElementDividerModel(
        name: toString(json['name']),
      );

  @override
  Map<String, dynamic> toJson() => {
        ...super.toJson(),
        'name': name,
      };
}

class FTShopElementExternalLinkModel extends FTShopElementModel {
  final String link;
  final String name;

  const FTShopElementExternalLinkModel({
    required this.link,
    required this.name,
  }) : super.externalLink();

  factory FTShopElementExternalLinkModel.fromJson(dynamic json) => FTShopElementExternalLinkModel(
        link: toString(json['link']),
        name: toString(json['name']),
      );

  @override
  Map<String, dynamic> toJson() => {
        ...super.toJson(),
        'link': link,
        'name': name,
      };
}

class FTShopElementNoticeModel extends FTShopElementModel {
  final String content;
  final FTColorType variant;

  const FTShopElementNoticeModel({
    required this.content,
    required this.variant,
  }) : super.notice();

  factory FTShopElementNoticeModel.fromJson(dynamic json) => FTShopElementNoticeModel(
        content: toString(json['content']),
        variant: FTColorType.fromString(toString(json['variant'])),
      );

  @override
  Map<String, dynamic> toJson() => {
        ...super.toJson(),
        'content': content,
        'variant': variant,
      };
}

class FTShopElementProductModel extends FTShopElementModel {
  final String id;
  final String description;
  final String name;
  final int priceCents;
  final int feeCents;
  final int packQuantity;
  final int reservableQuantity;
  final FTProductType type;
  final List<FTMediaIdAndUrlModel> media;

  const FTShopElementProductModel({
    required this.id,
    required this.description,
    required this.name,
    required this.priceCents,
    required this.feeCents,
    required this.packQuantity,
    required this.reservableQuantity,
    required this.type,
    required this.media,
  }) : super.product();

  factory FTShopElementProductModel.fromJson(dynamic json) => FTShopElementProductModel(
        id: toString(json['id']),
        description: toNullable(json['description'], toString) ?? '',
        name: toString(json['name']),
        priceCents: toInt(json['priceCents']),
        feeCents: toInt(json['feeCents']),
        packQuantity: toInt(json['packQuantity']),
        reservableQuantity: toInt(json['reservableQuantity']),
        type: FTProductType.fromString(toString(json['type'])),
        media: toList(json['media']).map(FTMediaIdAndUrlModel.fromJson).toList(),
      );

  @override
  Map<String, dynamic> toJson() => {
        ...super.toJson(),
        'id': id,
        'description': description,
        'name': name,
        'priceCents': priceCents,
        'feeCents': feeCents,
        'packQuantity': packQuantity,
        'reservableQuantity': reservableQuantity,
        'type': type,
        'media': media,
      };
}

class FTShopElementTextBlockModel extends FTShopElementModel {
  final String text;
  final String title;

  const FTShopElementTextBlockModel({
    required this.text,
    required this.title,
  }) : super.textBlock();

  factory FTShopElementTextBlockModel.fromJson(dynamic json) => FTShopElementTextBlockModel(
        text: toString(json['text']),
        title: toString(json['title']),
      );

  @override
  Map<String, dynamic> toJson() => {
        ...super.toJson(),
        'text': text,
        'title': title,
      };
}
