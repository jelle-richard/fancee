import 'shop_element_model.dart';

class FTShopCartProductModel {
  final FTShopElementProductModel product;
  final int quantity;

  const FTShopCartProductModel({
    required this.product,
    required this.quantity,
  });
}
