import '../../../util/util.dart';
import '../../enum/enum.dart';
import '../finance/finance.dart';
import '../geo/geo.dart';

class FTEventModel {
  final String id;
  final String name;
  final String description;
  final String organization;
  final FTEventStatus status;
  final FTEventType type;
  final DateTime startDate;
  final DateTime endDate;
  final FTAddressModel? address;
  final FTCurrencyModel currency;
  final List<FTPaymentMethodModel> paymentMethods;
  final int? minimumAge;

  const FTEventModel({
    required this.id,
    required this.name,
    required this.description,
    required this.organization,
    required this.status,
    required this.type,
    required this.startDate,
    required this.endDate,
    required this.address,
    required this.currency,
    required this.paymentMethods,
    required this.minimumAge,
  });

  factory FTEventModel.fromJson(dynamic json) => FTEventModel(
        id: toString(json['id']),
        name: toString(json['name']),
        description: toString(json['description']),
        organization: toString(json['organization']),
        status: FTEventStatus.fromString(toString(json['status'])),
        type: FTEventType.fromString(toString(json['type'])),
        startDate: toDateTime(json['startDate']),
        endDate: toDateTime(json['endDate']),
        address: toNullable(json['address'], FTAddressModel.fromJson),
        currency: FTCurrencyModel.fromJson(json['currency']),
        paymentMethods: toList(json['paymentMethods']).map(FTPaymentMethodModel.fromJson).toList(),
        minimumAge: toNullable(json['minimumAge'], toInt),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'organization': organization,
        'status': status,
        'type': type,
        'startDate': startDate.toString(),
        'endDate': endDate.toString(),
        'address': address,
        'currency': currency,
        'paymentMethods': paymentMethods,
        'minimumAge': minimumAge,
      };
}
