import '../../../l10n/extension.dart';
import '../enum/enum.dart';
import '../http/http.dart';
import '../model/model.dart';
import 'base_service.dart';

class FTScanService extends FTBaseService<FTScanService> {
  const FTScanService({
    required super.context,
  });

  Future<FTHttpResponse<List<FTScanStatisticTicketModel>>> getStatistics({
    required String eventId,
  }) async =>
      await sendListAdapter(
        adapter: FTScanStatisticTicketModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/scan/statistics/$eventId')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken,
      );

  Future<FTHttpResponse<List<FTScanStatisticTicketModel>>> getStatisticsAppTeam({
    required String eventId,
  }) async =>
      await sendListAdapter(
        adapter: FTScanStatisticTicketModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/scan/statistics/app-team/$eventId')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken,
      );

  Future<FTHttpResponse<FTScanResultModel>> setScanState({
    required String code,
    required FTScanState state,
  }) async =>
      _handleSetScanStateResponse(
        await send(
            request: FTHttpRequest.fromPath(context, environment, '/scan/${Uri.encodeComponent(code)}')
              ..method = FTHttpMethod.post
              ..bearerToken = bearerToken
              ..bodyJson = {
                'state': state,
              }),
      );

  Future<FTHttpResponse<FTScanResultModel>> setScanStateAppTeam({
    required String code,
    required FTScanState state,
  }) async =>
      _handleSetScanStateResponse(
        await send(
            request: FTHttpRequest.fromPath(context, environment, '/scan/app-team/${Uri.encodeComponent(code)}')
              ..method = FTHttpMethod.post
              ..bearerToken = bearerToken
              ..bodyJson = {
                'state': state,
              }),
      );

  FTHttpResponse<FTScanResultModel> _handleSetScanStateResponse(FTHttpResponse<dynamic> response) {
    // todo(Bas): handle properly (with messages and reasons) after FAN-638.

    if (response.status == FTHttpResponseCode.ok) {
      return response.copyWithData(
        data: const FTScanResultModel.ok(
          message: null,
        ),
      );
    }

    if (response.status == FTHttpResponseCode.badRequest) {
      return response.copyWithData(
        data: const FTScanResultModel.reused(
          message: null,
        ),
      );
    }

    if (response.status == FTHttpResponseCode.notFound) {
      return response.copyWithData(
        data: FTScanResultModel.invalid(
          reason: context.strings.scannerResultReasonNotFound,
        ),
      );
    }

    return response.copyWithData(
      data: FTScanResultModel.failed(
        reason: context.strings.scannerResultReasonUnexpectedResponse,
      ),
    );
  }
}
