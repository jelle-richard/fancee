import '../../util/util.dart';
import '../http/http.dart';
import '../model/event/event.dart';
import '../model/order/order.dart';
import 'base_service.dart';

class FTShopService extends FTBaseService<FTShopService> {
  const FTShopService({
    required super.context,
  });

  Future<FTHttpResponse<FTShopModel>> get({
    required String shopCode,
    required String shopName,
  }) async =>
      await sendAdapter(
        adapter: (data) => FTShopModel.fromJson(data, shopCode, shopName),
        request: FTHttpRequest.fromPath(context, environment, '/shop/$shopCode')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken,
      );

  Future<FTHttpResponse<String>> reserve({
    required String shopCode,
    required List<FTReservedProductModel> products,
  }) async =>
      await sendAdapter(
        adapter: (data) => toString(data['reference']),
        request: FTHttpRequest.fromPath(context, environment, '/reserve/$shopCode')
          ..method = FTHttpMethod.post
          ..bodyJson = {
            'products': products,
          },
      );
}
