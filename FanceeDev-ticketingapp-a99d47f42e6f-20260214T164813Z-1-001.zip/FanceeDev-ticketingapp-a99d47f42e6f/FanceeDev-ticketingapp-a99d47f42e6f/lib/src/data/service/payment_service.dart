import '../../util/util.dart';
import '../http/http.dart';
import 'base_service.dart';

class FTPaymentService extends FTBaseService<FTPaymentService> {
  const FTPaymentService({
    required super.context,
  });

  Future<FTHttpResponse<bool>> validatePinTerminal({
    required String serialNumber,
  }) async =>
      await sendAdapter(
        adapter: toBoolean,
        request: FTHttpRequest.fromPath(context, environment, '/payment/pin/terminals/$serialNumber')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken,
      );
}
