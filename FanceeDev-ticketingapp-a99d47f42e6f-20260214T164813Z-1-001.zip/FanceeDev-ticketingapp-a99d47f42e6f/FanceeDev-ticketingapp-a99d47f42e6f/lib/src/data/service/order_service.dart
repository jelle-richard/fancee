import '../http/http.dart';
import '../model/model.dart';
import 'base_service.dart';

class FTOrderService extends FTBaseService<FTOrderService> {
  const FTOrderService({
    required super.context,
  });

  Future<FTHttpResponse<FTOrderModel>> get({
    required String orderId,
  }) async =>
      await sendAdapter(
        adapter: FTOrderModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/order/$orderId')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken,
      );

  Future<FTHttpResponse<FTOrderModel>> appTeamGet({
    required String orderId,
  }) async =>
      await sendAdapter(
        adapter: FTOrderModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/order/app-team/$orderId')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken,
      );

  Future<FTHttpResponse<FTOrderPlacementResultModel>> order({
    required String shopCode,
    required FTShopOrderModel order,
  }) async =>
      await sendAdapter(
        adapter: FTOrderPlacementResultModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/order/$shopCode')
          ..method = FTHttpMethod.post
          ..bodyJson = order,
      );

  Future<FTHttpResponse<FTOrderPlacementResultModel>> orderCash({
    required String shopCode,
    required FTShopOrderModel order,
  }) async =>
      await sendAdapter(
        adapter: FTOrderPlacementResultModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/order/$shopCode/cash')
          ..method = FTHttpMethod.post
          ..bearerToken = bearerToken
          ..bodyJson = order,
      );

  Future<FTHttpResponse<FTOrderPlacementResultModel>> orderAppTeamCash({
    required String shopCode,
    required FTShopOrderModel order,
  }) async =>
      await sendAdapter(
        adapter: FTOrderPlacementResultModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/order/app-team/$shopCode/cash')
          ..method = FTHttpMethod.post
          ..bearerToken = bearerToken
          ..bodyJson = order,
      );

  Future<FTHttpResponse<FTOrderPlacementResultModel>> orderPin({
    required String shopCode,
    required FTShopOrderModel order,
    required String pinSerialNumber,
  }) async =>
      await sendAdapter(
        adapter: FTOrderPlacementResultModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/order/$shopCode/pin/terminals/$pinSerialNumber')
          ..method = FTHttpMethod.post
          ..bodyJson = order,
      );
}
