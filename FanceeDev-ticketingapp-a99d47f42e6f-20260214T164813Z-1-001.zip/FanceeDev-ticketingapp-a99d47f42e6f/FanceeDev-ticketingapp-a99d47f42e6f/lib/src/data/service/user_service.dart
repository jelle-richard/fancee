import '../../util/util.dart';
import '../http/http.dart';
import 'base_service.dart';

class FTUserService extends FTBaseService<FTUserService> {
  const FTUserService({
    required super.context,
  });

  Future<FTHttpResponse<String>> requestPasswordReset({
    required String email,
  }) async {
    return await sendAdapter(
      adapter: toString,
      request: FTHttpRequest.fromPath(context, environment, '/user/forgot-password?email=$email'),
    );
  }
}
