import 'package:carrot/carrot.dart';

import '../bloc/bloc.dart';
import '../environment.dart';
import '../http/http.dart';
import '../model/model.dart';

typedef FTBaseServiceWithUserTypeCallback<T, S> = Future<FTHttpResponse<T>> Function(S);

abstract class FTBaseService<S> {
  final BuildContext context;

  FTAuthState get _authState => context.read<FTAuthStateBloc>().state;

  String? get bearerToken => _authState.bearerToken;

  FTEnvironment get environment => FTEnvironment.of(context, listen: false);

  FTBaseUserModel? get user => _authState.user;

  const FTBaseService({
    required this.context,
  });

  /// Sends the given [request].
  @protected
  Future<FTHttpResponse<dynamic>> send({
    required FTHttpRequest request,
  }) async =>
      await FTHttpExecutor.makeRequest(
        request,
      );

  /// Sends the given [request] and pipes the response
  /// through the given [adapter].
  @protected
  Future<FTHttpResponse<T>> sendAdapter<T>({
    required FTHttpRequest request,
    required T Function(dynamic) adapter,
  }) async {
    final safeAdapter = _safeAdapter(adapter);
    final response = await FTHttpExecutor.makeRequest(
      request,
    );

    return FTHttpResponse<T>(
      data: response.data != null ? safeAdapter(response.data) : null,
      errors: response.errors,
      headers: response.headers,
      status: response.status,
    );
  }

  /// Sends the given [request] and pipes every item in
  /// the array response through the given [adapter].
  @protected
  Future<FTHttpResponse<List<T>>> sendListAdapter<T>({
    required FTHttpRequest request,
    required T Function(dynamic) adapter,
  }) async {
    final safeAdapter = _safeAdapter(adapter);
    final response = await FTHttpExecutor.makeRequest(
      request,
    );

    return FTHttpResponse<List<T>>(
      data: response.data is List ? (response.data as List).map(safeAdapter).toList() : null,
      errors: response.errors,
      headers: response.headers,
      status: response.status,
    );
  }

  /// Sends the given [request] and adapters it to a
  /// paginated response. Every item is piped through
  /// the given [adapter].
  @protected
  Future<FTHttpResponse<FTPaginated<T>>> sendPaginatedAdapter<T>({
    required FTHttpRequest request,
    required T Function(dynamic) adapter,
  }) async {
    final safeAdapter = _safeAdapter(adapter);
    final safePaginatedAdapter = _safeAdapter((data) => FTPaginated.fromJson(data, safeAdapter));
    final response = await FTHttpExecutor.makeRequest(
      request,
    );

    return FTHttpResponse<FTPaginated<T>>(
      data: safePaginatedAdapter(response.data),
      errors: response.errors,
      headers: response.headers,
      status: response.status,
    );
  }

  /// Calls the given function based on the type of the active user.
  Future<FTHttpResponse<T>> withUserType<T>({
    required FTBaseServiceWithUserTypeCallback<T, S> organizer,
    required FTBaseServiceWithUserTypeCallback<T, S> appTeam,
  }) async {
    if (user == null) {
      throw StateError('There is currently no user active in auth state.');
    }

    if (user!.isAppTeam) {
      return await appTeam(this as S);
    }

    return organizer(this as S);
  }
}

T Function(dynamic) _safeAdapter<T>(T Function(dynamic) adapter) => (data) {
      try {
        return adapter(data);
      } on NoSuchMethodError {
        throw StateError('Badly formatted response from API.');
      } catch (err) {
        debugPrint(err.toString());
        rethrow;
      }
    };
