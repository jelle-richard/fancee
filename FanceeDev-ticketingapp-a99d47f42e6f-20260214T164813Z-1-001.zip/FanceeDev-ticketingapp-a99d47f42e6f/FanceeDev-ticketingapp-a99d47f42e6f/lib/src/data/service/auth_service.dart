import '../../util/util.dart';
import '../http/http.dart';
import '../model/model.dart';
import 'base_service.dart';

class FTAuthService extends FTBaseService<FTAuthService> {
  const FTAuthService({
    required super.context,
  });

  Future<FTHttpResponse<Iterable<String>>> claims() async {
    return await sendAdapter(
      adapter: (dynamic data) => toStringList(data['claims']),
      request: FTHttpRequest.fromPath(context, environment, '/auth/claims/user')
        ..method = FTHttpMethod.get
        ..bearerToken = bearerToken,
    );
  }

  Future<FTHttpResponse<Iterable<String>>> claimsAppTeam() async {
    return await sendAdapter(
      adapter: (dynamic data) => toStringList(data['claims']),
      request: FTHttpRequest.fromPath(context, environment, '/auth/claims/app-team')
        ..method = FTHttpMethod.get
        ..bearerToken = bearerToken,
    );
  }

  Future<FTHttpResponse<FTAuthTokenUserResponseModel>> login({
    required String email,
    required String password,
  }) async {
    return await sendAdapter(
      adapter: FTAuthTokenUserResponseModel.fromJson,
      request: FTHttpRequest.fromPath(context, environment, '/auth/token')
        ..method = FTHttpMethod.post
        ..bodyJson = {
          'email': email,
          'password': password,
        },
    );
  }

  Future<FTHttpResponse<FTAuthTokenAppTeamResponseModel>> loginAppTeam({
    required String teamId,
  }) async {
    return await sendAdapter(
      adapter: (dynamic data) => FTAuthTokenAppTeamResponseModel.fromJson({
        ...(data as Map),
        'id': teamId,
      }),
      request: FTHttpRequest.fromPath(context, environment, '/auth/app-team/token')
        ..method = FTHttpMethod.post
        ..bodyJson = {
          'teamId': teamId,
        },
    );
  }

  Future<FTHttpResponse<FTAuthTokenUserResponseModel>> refresh({
    required String token,
  }) async {
    return await sendAdapter(
      adapter: FTAuthTokenUserResponseModel.fromJson,
      request: FTHttpRequest.fromPath(context, environment, '/auth/token/refresh')
        ..method = FTHttpMethod.post
        ..bodyJson = {
          'token': token,
        },
    );
  }

  Future<FTHttpResponse<FTAuthTokenAppTeamResponseModel>> refreshAppTeam({
    required String token,
  }) async {
    return await sendAdapter(
      adapter: FTAuthTokenAppTeamResponseModel.fromJson,
      request: FTHttpRequest.fromPath(context, environment, '/auth/app-team/token/refresh')
        ..method = FTHttpMethod.post
        ..bodyJson = {
          'token': token,
        },
    );
  }
}
