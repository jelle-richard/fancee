import '../../util/util.dart';
import '../enum/enum.dart';
import '../http/http.dart';
import '../model/model.dart';
import 'base_service.dart';

class FTEventService extends FTBaseService<FTEventService> {
  const FTEventService({
    required super.context,
  });

  Future<FTHttpResponse<FTPaginated<FTEventListingModel>>> getList({
    DateTime? maximumStartDate,
    DateTime? minimumStartDate,
    int page = 1,
    int pageSize = 100,
    String? searchQuery,
    List<FTEventStatus>? states,
  }) async =>
      await sendPaginatedAdapter(
        adapter: FTEventListingModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/events/list')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken
          ..query = FTHttpQuery.fromPairs({
            'Options.MaximumStartDate': maximumStartDate?.formatForApi(),
            'Options.MinimumStartDate': minimumStartDate?.formatForApi(),
            'Options.SearchQuery': searchQuery,
            'Page': page,
            'PageSize': pageSize,
          }),
      );

  Future<FTHttpResponse<FTPaginated<FTEventListingModel>>> getListAppTeam({
    DateTime? maximumStartDate,
    DateTime? minimumStartDate,
    int page = 1,
    int pageSize = 100,
    String? searchQuery,
    List<FTEventStatus>? states,
  }) async =>
      await sendPaginatedAdapter(
        adapter: FTEventListingModel.fromJson,
        request: FTHttpRequest.fromPath(context, environment, '/events/app-team/list')
          ..method = FTHttpMethod.get
          ..bearerToken = bearerToken
          ..query = FTHttpQuery.fromPairs({
            'Options.MaximumStartDate': maximumStartDate?.formatForApi(),
            'Options.MinimumStartDate': minimumStartDate?.formatForApi(),
            'Options.SearchQuery': searchQuery,
            'Page': page,
            'PageSize': pageSize,
          }),
      );
}
