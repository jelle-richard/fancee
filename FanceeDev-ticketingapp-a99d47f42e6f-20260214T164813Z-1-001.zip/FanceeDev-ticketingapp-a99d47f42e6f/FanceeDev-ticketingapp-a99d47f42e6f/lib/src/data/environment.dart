import 'package:carrot/carrot.dart';

import 'bloc/bloc.dart';
import 'feature_flags.dart';

class FTEnvironment {
  static List<FTEnvironment> all = [
    const FTEnvironment.production(),
    const FTEnvironment.staging(),
    const FTEnvironment.local(),
    const FTEnvironment.bas(),
    const FTEnvironment.jorden(),
  ];

  final String id;
  final String icon;
  final String name;
  final FTFeatureFlags featureFlags;
  final String apiBaseUrl;
  final String apiUserAgent;
  final String baseUrl;
  final String? prefillLoginEmail;
  final String? prefillLoginPassword;
  final String? prefillSalesEmail;
  final String? prefillSalesFirstName;
  final String? prefillSalesLastName;

  const FTEnvironment._({
    required this.id,
    required this.name,
    this.icon = 'heart',
    this.featureFlags = const FTFeatureFlags.defaults(),
    this.apiBaseUrl = 'https://ticketing.wearefancee.com/api',
    this.apiUserAgent = 'FanceeTicketing/1.0.x', // todo(Bas): find a way to get this from the app bundle. (FAN-764)
    this.baseUrl = 'https://ticketing.wearefancee.com',
    this.prefillLoginEmail,
    this.prefillLoginPassword,
    this.prefillSalesEmail,
    this.prefillSalesFirstName,
    this.prefillSalesLastName,
  });

  const FTEnvironment.production()
      : this._(
          id: 'production',
          name: 'Production',
        );

  const FTEnvironment.staging()
      : this._(
          id: 'staging',
          icon: 'star',
          name: 'Staging',
          apiBaseUrl: 'https://staging.fanc.ee/api',
          baseUrl: 'https://staging.fanc.ee',
          featureFlags: const FTFeatureFlags.staging(),
        );

  const FTEnvironment.local()
      : this._(
          id: 'anton',
          icon: 'server',
          name: 'Anton',
          apiBaseUrl: 'https://staging.fanc.ee/api',
          baseUrl: 'https://staging.fanc.ee',
          featureFlags: const FTFeatureFlags.all(),
          prefillLoginEmail: 'bas@tibbaa.com',
          prefillLoginPassword: 'hallo123',
          prefillSalesEmail: 'bas@tibbaa.com',
          prefillSalesFirstName: 'Bas',
          prefillSalesLastName: 'Milius',
        );

  const FTEnvironment.bas()
      : this._(
          id: 'bas',
          icon: 'face-awesome',
          name: 'Development (MacBook Bas)',
          apiBaseUrl: 'http://macbook-pro-van-bas.local',
          featureFlags: const FTFeatureFlags.all(),
        );

  const FTEnvironment.jorden()
      : this._(
          id: 'jorden',
          icon: 'face-awesome',
          name: 'Development (MacBook Jorden)',
          apiBaseUrl: 'http://jordens-macbook-pro.local',
          featureFlags: const FTFeatureFlags.all(),
        );

  @override
  int get hashCode => name.hashCode;

  @override
  bool operator ==(Object other) {
    return other is FTEnvironment && other.name == name;
  }

  /// Returns the current [FTEnvironment] from the [BuildContext].
  static FTEnvironment of(BuildContext context, {bool listen = true}) {
    if (listen) {
      return context.watch<FTAppStateBloc>().state.environment;
    } else {
      return context.read<FTAppStateBloc>().state.environment;
    }
  }
}
