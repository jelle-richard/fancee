enum FTExceptionId {
  reservationExpired('FAN-89707');

  final String value;

  const FTExceptionId(this.value);

  String toJson() => value;

  @override
  String toString() => value;
}
