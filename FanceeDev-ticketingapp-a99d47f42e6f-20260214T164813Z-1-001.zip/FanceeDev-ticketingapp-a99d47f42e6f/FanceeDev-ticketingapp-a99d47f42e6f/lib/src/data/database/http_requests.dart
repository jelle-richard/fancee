part of 'database.dart';

class FTDatabaseTableHttpRequests extends _FTDatabaseTable {
  const FTDatabaseTableHttpRequests(super.database) : super(name: 'http_requests');

  @override
  Future<void> onCreate(Database db, Batch batch, int version) async {
    batch.execute('''
    create table $name (
      id integer primary key autoincrement,
      url text not null,
      response text,
      status_code integer not null,
      executed_on text not null
    )
    ''');
  }

  @override
  Future<void> onUpgrade(Database db, Batch batch, int oldVersion, int newVersion) async {
    if (oldVersion == 1) {
      batch.execute('''
      create table $name (
        id integer primary key autoincrement,
        url text not null,
        response text,
        status_code integer not null
      )
      ''');
    }

    if (oldVersion == 2) {
      batch.execute('''
      alter table $name
        add column executed_on text not null
      ''');
    }
  }

  Future<void> add(FTLoggedHttpRequest request) async => await _insert(request.toDatabase());

  Future<void> deleteAll() async => await _delete();

  Future<List<FTLoggedHttpRequest>> getAll([
    int offset = 0,
    int limit = 100,
  ]) async =>
      await _query(
        adapter: FTLoggedHttpRequest.fromDatabase,
        limit: limit,
        offset: offset,
        orderBy: 'id desc',
      );
}

class FTLoggedHttpRequest {
  final DateTime executedOn;
  final String response;
  final FTHttpResponseCode statusCode;
  final String url;

  const FTLoggedHttpRequest({
    required this.executedOn,
    required this.response,
    required this.statusCode,
    required this.url,
  });

  factory FTLoggedHttpRequest.fromDatabase(Map<String, dynamic> record) => FTLoggedHttpRequest(
        executedOn: toDateTime(record['executed_on']),
        response: toString(record['response']),
        statusCode: FTHttpResponseCode.fromStatusCode(toInt(record['status_code'])),
        url: toString(record['url']),
      );

  factory FTLoggedHttpRequest.fromResponse(String url, String response, int statusCode) => FTLoggedHttpRequest(
        executedOn: DateTime.now(),
        response: response,
        statusCode: FTHttpResponseCode.fromStatusCode(statusCode),
        url: url,
      );

  Map<String, dynamic> toDatabase() => {
        'executed_on': executedOn.toIso8601String(),
        'response': response,
        'status_code': statusCode.value,
        'url': url,
      };
}
