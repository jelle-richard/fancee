part of 'database.dart';

class FTDatabaseTableScans extends _FTDatabaseTable {
  const FTDatabaseTableScans(super.database) : super(name: 'scans');

  @override
  Future<void> onCreate(Database db, Batch batch, int version) async {
    batch.execute('''
    create table $name (
      id integer primary key autoincrement,
      barcode text not null,
      message text,
      mode text not null,
      result text not null,
      scanned_on text not null
    )
    ''');
  }

  @override
  Future<void> onUpgrade(Database db, Batch batch, int oldVersion, int newVersion) async {}

  Future<void> add(FTScanHistoryEntry entry) async => await _insert(entry.toDatabase());

  Future<void> deleteAll() async => await _delete();

  Future<List<FTScanHistoryEntry>> getAll([
    int offset = 0,
    int limit = 100,
  ]) async =>
      await _query(
        adapter: FTScanHistoryEntry.fromDatabase,
        limit: limit,
        offset: offset,
        orderBy: 'id desc',
      );
}
