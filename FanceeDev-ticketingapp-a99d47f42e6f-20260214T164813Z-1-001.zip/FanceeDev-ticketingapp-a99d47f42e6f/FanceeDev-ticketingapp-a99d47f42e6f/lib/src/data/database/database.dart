import 'package:carrot/carrot.dart';
import 'package:sqflite/sqflite.dart';

import '../../util/util.dart';
import '../http/http.dart';
import '../model/model.dart';

part 'http_requests.dart';

part 'scans.dart';

const _kDatabaseName = 'ticketing.db';
const _kDatabaseVersion = 3;

/// The local database of the app. Some local state is saved here
/// instead of in our key-value pair store.
class FTDatabase {
  late final Database _connection;
  late final FTDatabaseTableHttpRequests httpRequests;
  late final FTDatabaseTableScans scans;

  int get version => _kDatabaseVersion;

  FTDatabase() {
    httpRequests = FTDatabaseTableHttpRequests(this);
    scans = FTDatabaseTableScans(this);
  }

  /// Closes the database.
  Future<void> close() async {
    await _connection.close();
  }

  /// Opens the database.
  Future<void> open() async {
    _connection = await openDatabase(
      _kDatabaseName,
      version: _kDatabaseVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  /// This function is executed when creating the database
  /// for the first time.
  Future<void> _onCreate(Database db, int version) async {
    final batch = db.batch();
    await httpRequests.onCreate(db, batch, version);
    await scans.onCreate(db, batch, version);
    await batch.commit();
  }

  /// This function is executed when a database upgrade is
  /// needed. The old version and the new version are given
  /// to determine which queries to run.
  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    final batch = db.batch();
    await httpRequests.onUpgrade(db, batch, oldVersion, newVersion);
    await scans.onUpgrade(db, batch, oldVersion, newVersion);
    await batch.commit();
  }

  /// Returns the database instance within the given
  /// build [context].
  static FTDatabase of(BuildContext context) {
    final provider = context.dependOnInheritedWidgetOfExactType<FTDatabaseProvider>();

    assert(provider != null, 'A database provider was not found in the widget tree.');

    return provider!.database;
  }
}

/// The [FTDatabaseProvider] provides a [FTDatabase] instance to
/// the underlying widget tree.
class FTDatabaseProvider extends InheritedWidget {
  final FTDatabase database;

  const FTDatabaseProvider({
    super.key,
    required super.child,
    required this.database,
  });

  @override
  bool updateShouldNotify(FTDatabaseProvider oldWidget) {
    return database != oldWidget.database;
  }
}

/// Abstractions for a database table.
abstract class _FTDatabaseTable {
  final FTDatabase _database;
  final String name;

  const _FTDatabaseTable(
    this._database, {
    required this.name,
  });

  /// Creates the database table when the database is created for
  /// the first time.
  Future<void> onCreate(Database db, Batch batch, int version);

  /// Upgrades the database table from the given [oldVersion] to
  /// the given [newVersion].
  Future<void> onUpgrade(Database db, Batch batch, int oldVersion, int newVersion);

  /// Convenience method for deleting records within the table. This
  /// will produce the following query:
  ///
  /// delete from [name]
  Future<void> _delete({
    String? where,
    List<Object?>? whereArgs,
  }) async =>
      await _database._connection.delete(
        name,
        where: where,
        whereArgs: whereArgs,
      );

  /// Convenience method for inserting records to the table. This will
  /// produce the following query:
  ///
  /// insert into [name] (...columns...) values ([values])
  Future<void> _insert(Map<String, dynamic> values) async => await _database._connection.insert(name, values);

  /// Convenience method for quering the table. This will produce a
  /// select query based on the given arguments. The results from the
  /// query will go through the given [adapter].
  Future<List<T>> _query<T>({
    required T Function(Map<String, dynamic>) adapter,
    List<String>? columns,
    bool? distinct,
    String? groupBy,
    String? having,
    int? limit,
    int? offset,
    String? orderBy,
    String? where,
    List<Object?>? whereArgs,
  }) async {
    final records = await _database._connection.query(
      name,
      columns: columns,
      distinct: distinct,
      groupBy: groupBy,
      having: having,
      limit: limit,
      offset: offset,
      orderBy: orderBy,
      where: where,
      whereArgs: whereArgs,
    );

    return records.map(adapter).toList();
  }
}
