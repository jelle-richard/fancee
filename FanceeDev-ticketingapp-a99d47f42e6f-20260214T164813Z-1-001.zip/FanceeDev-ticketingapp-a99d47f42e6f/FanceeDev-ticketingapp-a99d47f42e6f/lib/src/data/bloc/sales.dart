import 'package:collection/collection.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../enum/enum.dart';
import '../model/model.dart';
import 'bloc.dart';

class FTSalesStateBloc extends Bloc<FTSalesStateEvent, FTSalesState> {
  final SharedPreferences preferences;

  FTSalesStateBloc(this.preferences, FTSalesState state) : super(state) {
    on<FTSalesStateSetEvents>(_onSetEvents);
    on<FTSalesStateSetMode>(_onSetMode);
    on<FTSalesStateSetReservationReference>(_onSetReservationReference);
    on<FTSalesStateSetShop>(_onSetShop);
    on<FTSalesStateUpdateCart>(_onUpdateCart);
    on<FTSalesStateFormSetEmail>(_onUpdateFormEmail);
    on<FTSalesStateFormSetFirstName>(_onUpdateFormFirstName);
    on<FTSalesStateFormSetLastName>(_onUpdateFormLastName);
    on<FTSalesStateFormSetBirthDate>(_onUpdateFormBirthDate);
    on<FTSalesStateFormSetPhoneNumber>(_onUpdateFormPhoneNumber);
    on<FTSalesStateFormSetGender>(_onUpdateFormGender);
    on<FTSalesStateFormReset>(_onFormReset);
  }

  void _onSetEvents(FTSalesStateSetEvents event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(events: event.events));
  }

  void _onSetMode(FTSalesStateSetMode event, Emitter<FTSalesState> emit) async {
    emit(state.copyWith(mode: event.mode));

    await preferences.setString('sales_mode', event.mode.name);
  }

  void _onSetReservationReference(FTSalesStateSetReservationReference event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      reservationReference: event.reservationReference,
      allowReservationReferenceReset: true,
    ));
  }

  void _onSetShop(FTSalesStateSetShop event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      cart: const {},
      shop: event.shop,
      allowShopReset: true,
    ));
  }

  void _onUpdateCart(FTSalesStateUpdateCart event, Emitter<FTSalesState> emit) {
    final cart = Map<String, int>.from(state.cart);
    cart[event.productId] = event.quantity;

    emit(state.copyWith(
      cart: cart,
    ));
  }

  void _onUpdateFormEmail(FTSalesStateFormSetEmail event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      shopForm: state.shopForm.copyWith(
        email: event.email,
      ),
    ));
  }

  void _onUpdateFormFirstName(FTSalesStateFormSetFirstName event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      shopForm: state.shopForm.copyWith(
        firstName: event.firstName,
      ),
    ));
  }

  void _onUpdateFormLastName(FTSalesStateFormSetLastName event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      shopForm: state.shopForm.copyWith(
        lastName: event.lastName,
      ),
    ));
  }

  void _onUpdateFormBirthDate(FTSalesStateFormSetBirthDate event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      shopForm: state.shopForm.copyWith(
        birthDate: event.birthDate,
      ),
    ));
  }

  void _onUpdateFormPhoneNumber(FTSalesStateFormSetPhoneNumber event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      shopForm: state.shopForm.copyWith(
        phoneNumber: event.phoneNumber,
      ),
    ));
  }

  void _onUpdateFormGender(FTSalesStateFormSetGender event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      shopForm: state.shopForm.copyWith(
        gender: event.gender,
      ),
    ));
  }

  void _onFormReset(FTSalesStateFormReset event, Emitter<FTSalesState> emit) {
    emit(state.copyWith(
      shopForm: const FTShopFormModel(),
    ));
  }
}

class FTSalesState {
  final Map<String, int> cart;
  final List<FTEventListingModel> events;
  final FTSalesMode mode;
  final String? reservationReference;
  final FTShopModel? shop;
  final FTShopFormModel shopForm;

  List<FTShopCartProductModel> get products {
    List<FTShopCartProductModel> products = [];

    cart.forEach((productId, quantity) {
      final product = shop!.elements.firstWhereOrNull((element) => element.kind == FTShopElementType.product && (element as FTShopElementProductModel).id == productId) as FTShopElementProductModel?;

      if (product == null) {
        return;
      }

      products.add(FTShopCartProductModel(
        product: product,
        quantity: quantity,
      ));
    });

    return products;
  }

  int get productTotalPriceCents {
    if (shop == null) {
      return 0;
    }

    int price = 0;

    cart.forEach((productId, quantity) {
      final product = shop!.elements.firstWhereOrNull((element) => element.kind == FTShopElementType.product && (element as FTShopElementProductModel).id == productId) as FTShopElementProductModel?;
      assert(product != null);

      price += (product!.priceCents + product.feeCents) * quantity;
    });

    return price;
  }

  const FTSalesState({
    this.cart = const {},
    this.events = const [],
    this.mode = FTSalesMode.doorsale,
    this.reservationReference,
    this.shop,
    this.shopForm = const FTShopFormModel(),
  });

  factory FTSalesState.load(SharedPreferences preferences) {
    return FTSalesState(
      mode: FTSalesMode.fromString(preferences.getString('sales_mode') ?? FTSalesMode.doorsale.name),
    );
  }

  FTSalesState copyWith({
    Map<String, int>? cart,
    List<FTEventListingModel>? events,
    FTSalesMode? mode,
    String? reservationReference,
    FTShopModel? shop,
    FTShopFormModel? shopForm,
    bool allowReservationReferenceReset = false,
    bool allowShopReset = false,
  }) =>
      FTSalesState(
        cart: cart ?? this.cart,
        events: events ?? this.events,
        mode: mode ?? this.mode,
        reservationReference: reservationReference ?? (allowReservationReferenceReset ? null : this.reservationReference),
        shop: shop ?? (allowShopReset ? null : this.shop),
        shopForm: shopForm ?? this.shopForm,
      );
}

abstract class FTSalesStateEvent {
  const FTSalesStateEvent();
}

class FTSalesStateSetEvents extends FTSalesStateEvent {
  final List<FTEventListingModel> events;

  const FTSalesStateSetEvents(this.events);
}

class FTSalesStateSetMode extends FTSalesStateEvent {
  final FTSalesMode mode;

  const FTSalesStateSetMode(this.mode);
}

class FTSalesStateSetReservationReference extends FTSalesStateEvent {
  final String? reservationReference;

  const FTSalesStateSetReservationReference(this.reservationReference);
}

class FTSalesStateSetShop extends FTSalesStateEvent {
  final FTShopModel? shop;

  const FTSalesStateSetShop(this.shop);
}

class FTSalesStateUpdateCart extends FTSalesStateEvent {
  final String productId;
  final int quantity;

  const FTSalesStateUpdateCart(this.productId, this.quantity);
}

class FTSalesStateFormSetEmail extends FTSalesStateEvent {
  final String email;

  const FTSalesStateFormSetEmail(this.email);
}

class FTSalesStateFormSetFirstName extends FTSalesStateEvent {
  final String firstName;

  const FTSalesStateFormSetFirstName(this.firstName);
}

class FTSalesStateFormSetLastName extends FTSalesStateEvent {
  final String lastName;

  const FTSalesStateFormSetLastName(this.lastName);
}

class FTSalesStateFormSetBirthDate extends FTSalesStateEvent {
  final DateTime? birthDate;

  const FTSalesStateFormSetBirthDate(this.birthDate);
}

class FTSalesStateFormSetPhoneNumber extends FTSalesStateEvent {
  final String phoneNumber;

  const FTSalesStateFormSetPhoneNumber(this.phoneNumber);
}

class FTSalesStateFormSetGender extends FTSalesStateEvent {
  final FTGender? gender;

  const FTSalesStateFormSetGender(this.gender);
}

class FTSalesStateFormReset extends FTSalesStateEvent {
  const FTSalesStateFormReset();
}
