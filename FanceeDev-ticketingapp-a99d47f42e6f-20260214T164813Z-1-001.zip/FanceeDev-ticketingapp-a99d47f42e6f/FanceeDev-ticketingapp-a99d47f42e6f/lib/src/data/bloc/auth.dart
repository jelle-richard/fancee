import 'dart:convert';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/model.dart';

class FTAuthStateBloc extends Bloc<FTAuthStateEvent, FTAuthState> {
  final SharedPreferences preferences;

  FTAuthStateBloc(this.preferences, FTAuthState state) : super(state) {
    on<FTAuthStateSetBearerToken>(_setBearerToken);
    on<FTAuthStateSetUser>(_setUser);
  }

  void _setBearerToken(FTAuthStateSetBearerToken event, Emitter<FTAuthState> emit) async {
    emit(state.copyWith(
      bearerToken: event.bearerToken,
      user: event.user,
      validUntil: event.validUntil,
    ));

    if (event.bearerToken != null && event.user != null && event.validUntil != null) {
      await preferences.setString('auth_bearer_token', event.bearerToken!);
      await preferences.setString('auth_user', jsonEncode(event.user!));
      await preferences.setString('auth_valid_until', event.validUntil!.toString());
      return;
    }

    await preferences.remove('auth_bearer_token');
    await preferences.remove('auth_user');
    await preferences.remove('auth_valid_until');
  }

  void _setUser(FTAuthStateSetUser event, Emitter<FTAuthState> emit) async {
    emit(state.copyWith(
      bearerToken: state.bearerToken,
      user: event.user,
      validUntil: state.validUntil,
    ));

    if (event.user != null) {
      await preferences.setString('auth_user', jsonEncode(event.user!));
      return;
    }

    await preferences.remove('auth_user');
  }
}

class FTAuthState {
  final String? bearerToken;
  final FTBaseUserModel? user;
  final DateTime? validUntil;

  bool get isSignedIn => bearerToken != null && user != null && validUntil != null;

  const FTAuthState({
    this.bearerToken,
    this.user,
    this.validUntil,
  });

  factory FTAuthState.load(SharedPreferences preferences) {
    String? bearerToken;
    FTBaseUserModel? user;
    DateTime? validUntil;

    try {
      if (preferences.containsKey('auth_bearer_token') && preferences.containsKey('auth_user') && preferences.containsKey('auth_valid_until')) {
        bearerToken = preferences.getString('auth_bearer_token');
        user = FTBaseUserModel.fromJson(jsonDecode(preferences.getString('auth_user')!));
        validUntil = DateTime.parse(preferences.getString('auth_valid_until')!);
      }
    } on ArgumentError {
      // invalid user type, nothing to fear, we just don't use saved data.
    }

    return FTAuthState(
      bearerToken: bearerToken,
      user: user,
      validUntil: validUntil,
    );
  }

  FTAuthState copyWith({
    String? bearerToken,
    FTBaseUserModel? user,
    DateTime? validUntil,
  }) =>
      FTAuthState(
        bearerToken: bearerToken,
        user: user,
        validUntil: validUntil,
      );
}

abstract class FTAuthStateEvent {
  const FTAuthStateEvent();
}

class FTAuthStateSetBearerToken extends FTAuthStateEvent {
  final String? bearerToken;
  final FTBaseUserModel? user;
  final DateTime? validUntil;

  const FTAuthStateSetBearerToken({
    this.bearerToken,
    this.user,
    this.validUntil,
  });
}

class FTAuthStateSetUser extends FTAuthStateEvent {
  final FTBaseUserModel? user;

  const FTAuthStateSetUser(this.user);
}
