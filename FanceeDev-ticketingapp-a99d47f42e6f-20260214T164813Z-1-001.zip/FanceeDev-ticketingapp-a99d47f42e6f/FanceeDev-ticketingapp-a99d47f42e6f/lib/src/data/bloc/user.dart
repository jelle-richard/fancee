import 'dart:convert';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../module/pin_terminal/pin_terminal.dart';
import '../../module/printer/printer.dart';
import '../../theme.dart';
import 'bloc.dart';

class FTUserStateBloc extends Bloc<FTUserStateEvent, FTUserState> {
  final SharedPreferences preferences;

  FTUserStateBloc(this.preferences, FTUserState state) : super(state) {
    on<FTUserStateSetPinTerminals>(_onSetPinTerminals);
    on<FTUserStateSetPrinters>(_onSetPrinters);
    on<FTUserStateSetAppearanceTheme>(_onSetAppearanceTheme);
    on<FTUserStateSetScannerCameraFrontFacing>(_onSetScannerCameraFrontFacing);
    on<FTUserStateSetScannerCameraFlashlight>(_onSetScannerCameraFlashlight);
    on<FTUserStateSetScannerFeedbackAudio>(_onSetScannerFeedbackAudio);
    on<FTUserStateSetScannerFeedbackHaptics>(_onSetScannerFeedbackHaptics);
  }

  void _onSetPinTerminals(FTUserStateSetPinTerminals event, Emitter<FTUserState> emit) async {
    emit(state.copyWith(pinTerminals: event.pinTerminals));

    await preferences.setStringList('user_pin_terminals', event.pinTerminals.map((pinTerminal) => jsonEncode(pinTerminal)).toList());
  }

  void _onSetPrinters(FTUserStateSetPrinters event, Emitter<FTUserState> emit) async {
    emit(state.copyWith(printers: event.printers));

    await preferences.setStringList('user_printers', event.printers.map((printer) => jsonEncode(printer)).toList());
  }

  void _onSetAppearanceTheme(FTUserStateSetAppearanceTheme event, Emitter<FTUserState> emit) async {
    emit(state.copyWith(appearanceTheme: event.theme));

    await preferences.setString('user_appearance_theme', event.theme.name);
  }

  void _onSetScannerCameraFrontFacing(FTUserStateSetScannerCameraFrontFacing event, Emitter<FTUserState> emit) async {
    emit(state.copyWith(scannerCameraFrontFacing: event.scannerCameraFrontFacing));

    await preferences.setBool('user_scanner_camera_front_facing', event.scannerCameraFrontFacing);
  }

  void _onSetScannerCameraFlashlight(FTUserStateSetScannerCameraFlashlight event, Emitter<FTUserState> emit) async {
    emit(state.copyWith(scannerCameraFlashlight: event.scannerCameraFlashlight));

    await preferences.setBool('user_scanner_camera_flashlight', event.scannerCameraFlashlight);
  }

  void _onSetScannerFeedbackAudio(FTUserStateSetScannerFeedbackAudio event, Emitter<FTUserState> emit) async {
    emit(state.copyWith(scannerFeedbackAudio: event.scannerFeedbackAudio));

    await preferences.setBool('user_scanner_feedback_audio', event.scannerFeedbackAudio);
  }

  void _onSetScannerFeedbackHaptics(FTUserStateSetScannerFeedbackHaptics event, Emitter<FTUserState> emit) async {
    emit(state.copyWith(scannerFeedbackHaptics: event.scannerFeedbackHaptics));

    await preferences.setBool('user_scanner_feedback_haptics', event.scannerFeedbackHaptics);
  }
}

class FTUserState {
  final List<FTPinTerminalModel> pinTerminals;
  final List<FTPrinter> printers;
  final FTThemeId appearanceTheme;
  final bool scannerCameraFrontFacing;
  final bool scannerCameraFlashlight;
  final bool scannerFeedbackAudio;
  final bool scannerFeedbackHaptics;

  const FTUserState({
    this.pinTerminals = const [],
    this.printers = const [],
    this.appearanceTheme = FTThemeId.auto,
    this.scannerCameraFrontFacing = false,
    this.scannerCameraFlashlight = false,
    this.scannerFeedbackAudio = false,
    this.scannerFeedbackHaptics = true,
  });

  factory FTUserState.load(SharedPreferences preferences) {
    final pinTerminalsJson = preferences.getStringList('user_pin_terminals') ?? const [];
    final pinTerminals = pinTerminalsJson.map(jsonDecode).map(FTPinTerminalModel.fromJson);

    final printersJson = preferences.getStringList('user_printers') ?? const [];
    final printers = printersJson.map(jsonDecode).map(FTPrinter.fromJson);

    return FTUserState(
      pinTerminals: pinTerminals.where((pinTerminal) => pinTerminal.brand != FTPinTerminalBrand.unknown).toList(),
      printers: printers.where((printer) => printer.type != FTPrinterType.unknown).toList(),
      appearanceTheme: FTThemeId.values.firstWhere(
        (t) => t.name == preferences.getString('user_appearance_theme'),
        orElse: () => FTThemeId.auto,
      ),
      scannerCameraFrontFacing: preferences.getBool('user_scanner_camera_front_facing') ?? false,
      scannerCameraFlashlight: preferences.getBool('user_scanner_camera_flashlight') ?? false,
      scannerFeedbackAudio: preferences.getBool('user_scanner_feedback_audio') ?? false,
      scannerFeedbackHaptics: preferences.getBool('user_scanner_feedback_haptics') ?? true,
    );
  }

  FTUserState copyWith({
    List<FTPinTerminalModel>? pinTerminals,
    List<FTPrinter>? printers,
    FTThemeId? appearanceTheme,
    bool? scannerCameraFrontFacing,
    bool? scannerCameraFlashlight,
    bool? scannerFeedbackAudio,
    bool? scannerFeedbackHaptics,
  }) =>
      FTUserState(
        pinTerminals: pinTerminals ?? this.pinTerminals,
        printers: printers ?? this.printers,
        appearanceTheme: appearanceTheme ?? this.appearanceTheme,
        scannerCameraFrontFacing: scannerCameraFrontFacing ?? this.scannerCameraFrontFacing,
        scannerCameraFlashlight: scannerCameraFlashlight ?? this.scannerCameraFlashlight,
        scannerFeedbackAudio: scannerFeedbackAudio ?? this.scannerFeedbackAudio,
        scannerFeedbackHaptics: scannerFeedbackHaptics ?? this.scannerFeedbackHaptics,
      );
}

abstract class FTUserStateEvent {
  const FTUserStateEvent();
}

class FTUserStateSetPinTerminals extends FTUserStateEvent {
  final List<FTPinTerminalModel> pinTerminals;

  const FTUserStateSetPinTerminals(this.pinTerminals);
}

class FTUserStateSetPrinters extends FTUserStateEvent {
  final List<FTPrinter> printers;

  const FTUserStateSetPrinters(this.printers);
}

class FTUserStateSetAppearanceTheme extends FTUserStateEvent {
  final FTThemeId theme;

  const FTUserStateSetAppearanceTheme(this.theme);
}

class FTUserStateSetScannerCameraFrontFacing extends FTUserStateEvent {
  final bool scannerCameraFrontFacing;

  const FTUserStateSetScannerCameraFrontFacing(this.scannerCameraFrontFacing);
}

class FTUserStateSetScannerCameraFlashlight extends FTUserStateEvent {
  final bool scannerCameraFlashlight;

  const FTUserStateSetScannerCameraFlashlight(this.scannerCameraFlashlight);
}

class FTUserStateSetScannerFeedbackAudio extends FTUserStateEvent {
  final bool scannerFeedbackAudio;

  const FTUserStateSetScannerFeedbackAudio(this.scannerFeedbackAudio);
}

class FTUserStateSetScannerFeedbackHaptics extends FTUserStateEvent {
  final bool scannerFeedbackHaptics;

  const FTUserStateSetScannerFeedbackHaptics(this.scannerFeedbackHaptics);
}
