import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../component/shell/shell.dart';
import '../environment.dart';

class FTAppStateBloc extends Bloc<FTAppStateEvent, FTAppState> {
  final SharedPreferences preferences;

  FTAppStateBloc(this.preferences, FTAppState state) : super(state) {
    on<FTAppStateSetAppBarActions>(_onSetAppBarActions);
    on<FTAppStateSetDidDismissSalesMissingPinTerminalsNotice>(_onSetDidDismissSalesMissingPinTerminalsNotice);
    on<FTAppStateSetDidDismissSalesMissingPrintersNotice>(_onSetDidDismissSalesMissingPrintersNotice);
    on<FTAppStateSetEnvironment>(_onSetEnvironment);
    on<FTAppStateSetInternetAvailable>(_onSetInternetAvailable);
  }

  void _onSetAppBarActions(FTAppStateSetAppBarActions event, Emitter<FTAppState> emit) {
    if (event.appBarActions.length > 3) {
      throw ArgumentError('There should be 3 or less actions in the app bar.', 'appBarActions');
    }

    emit(state.copyWith(appBarActions: event.appBarActions));
  }

  void _onSetDidDismissSalesMissingPinTerminalsNotice(FTAppStateSetDidDismissSalesMissingPinTerminalsNotice event, Emitter<FTAppState> emit) async {
    emit(state.copyWith(
      didDismissSalesMissingPinTerminalsNotice: event.didDismissSalesMissingPinTerminalsNotice,
    ));

    await preferences.setBool('did_dismiss_missing_pin_terminals_notice', event.didDismissSalesMissingPinTerminalsNotice);
  }

  void _onSetDidDismissSalesMissingPrintersNotice(FTAppStateSetDidDismissSalesMissingPrintersNotice event, Emitter<FTAppState> emit) async {
    emit(state.copyWith(
      didDismissSalesMissingPrintersNotice: event.didDismissSalesMissingPrintersNotice,
    ));

    await preferences.setBool('did_dismiss_missing_printers_notice', event.didDismissSalesMissingPrintersNotice);
  }

  void _onSetEnvironment(FTAppStateSetEnvironment event, Emitter<FTAppState> emit) async {
    emit(state.copyWith(environment: event.environment));

    await preferences.setString('environment_id', event.environment.id);
  }

  void _onSetInternetAvailable(FTAppStateSetInternetAvailable event, Emitter<FTAppState> emit) {
    emit(state.copyWith(isInternetAvailable: event.isInternetAvailable));
  }
}

class FTAppState {
  final List<FTAppBarButton> appBarActions;
  final bool didDismissSalesMissingPinTerminalsNotice;
  final bool didDismissSalesMissingPrintersNotice;
  final FTEnvironment environment;
  final bool isInternetAvailable;

  const FTAppState({
    this.appBarActions = const [],
    this.didDismissSalesMissingPinTerminalsNotice = false,
    this.didDismissSalesMissingPrintersNotice = false,
    this.environment = const FTEnvironment.production(),
    this.isInternetAvailable = true,
  });

  factory FTAppState.load(SharedPreferences preferences) {
    FTEnvironment environment = const FTEnvironment.production();

    if (preferences.containsKey('environment_id')) {
      final environmentId = preferences.getString('environment_id');
      environment = FTEnvironment.all.firstWhere(
        (env) => env.id == environmentId,
        orElse: () => const FTEnvironment.production(),
      );
    }

    return FTAppState(
      didDismissSalesMissingPinTerminalsNotice: preferences.getBool('did_dismiss_missing_pin_terminals_notice') ?? false,
      didDismissSalesMissingPrintersNotice: preferences.getBool('did_dismiss_missing_printers_notice') ?? false,
      environment: environment,
    );
  }

  FTAppState copyWith({
    List<FTAppBarButton>? appBarActions,
    bool? didDismissSalesMissingPinTerminalsNotice,
    bool? didDismissSalesMissingPrintersNotice,
    FTEnvironment? environment,
    bool? isInternetAvailable,
  }) =>
      FTAppState(
        appBarActions: appBarActions ?? this.appBarActions,
        didDismissSalesMissingPinTerminalsNotice: didDismissSalesMissingPinTerminalsNotice ?? this.didDismissSalesMissingPinTerminalsNotice,
        didDismissSalesMissingPrintersNotice: didDismissSalesMissingPrintersNotice ?? this.didDismissSalesMissingPrintersNotice,
        environment: environment ?? this.environment,
        isInternetAvailable: isInternetAvailable ?? this.isInternetAvailable,
      );
}

abstract class FTAppStateEvent {
  const FTAppStateEvent();
}

class FTAppStateSetAppBarActions extends FTAppStateEvent {
  final List<FTAppBarButton> appBarActions;

  const FTAppStateSetAppBarActions([this.appBarActions = const []]);
}

class FTAppStateSetDidDismissSalesMissingPinTerminalsNotice extends FTAppStateEvent {
  final bool didDismissSalesMissingPinTerminalsNotice;

  const FTAppStateSetDidDismissSalesMissingPinTerminalsNotice(this.didDismissSalesMissingPinTerminalsNotice);
}

class FTAppStateSetDidDismissSalesMissingPrintersNotice extends FTAppStateEvent {
  final bool didDismissSalesMissingPrintersNotice;

  const FTAppStateSetDidDismissSalesMissingPrintersNotice(this.didDismissSalesMissingPrintersNotice);
}

class FTAppStateSetEnvironment extends FTAppStateEvent {
  final FTEnvironment environment;

  const FTAppStateSetEnvironment(this.environment);
}

class FTAppStateSetInternetAvailable extends FTAppStateEvent {
  final bool isInternetAvailable;

  const FTAppStateSetInternetAvailable(this.isInternetAvailable);
}
