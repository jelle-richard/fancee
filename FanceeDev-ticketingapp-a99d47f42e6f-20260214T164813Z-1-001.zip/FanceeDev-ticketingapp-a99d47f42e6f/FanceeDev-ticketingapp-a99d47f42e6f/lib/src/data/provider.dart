import 'dart:async';

import 'package:carrot/carrot.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../router.dart';
import '../routes.dart';
import 'bloc/bloc.dart';
import 'database/database.dart';
import 'enum/enum.dart';
import 'environment.dart';
import 'http/http.dart';
import 'model/model.dart';
import 'service/service.dart';

/// [FTDataProvider] is the widget that provides the app state for our
/// entire app. This will handle state registration using Bloc and is
/// responsible for initial data loading.
///
/// This widget should only be used once in the entire app. Using this
/// widget multiple times will cause damages to persistent data.
class FTDataProvider extends StatelessWidget {
  final Widget child;

  const FTDataProvider({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _DataLoader.wait(),
      builder: (_, snapshot) {
        if (!snapshot.hasData) {
          // todo(Bas): if we need more data loading in the future, we could introduce a
          //  loading view here.
          return nothing;
        }

        final data = snapshot.data!;

        return MultiBlocProvider(
          providers: [
            BlocProvider<FTAppStateBloc>(
              create: (context) => FTAppStateBloc(data.preferences, data.appState),
            ),
            BlocProvider<FTAuthStateBloc>(
              create: (context) => FTAuthStateBloc(data.preferences, data.authState),
            ),
            BlocProvider<FTSalesStateBloc>(
              create: (context) => FTSalesStateBloc(data.preferences, data.salesState),
            ),
            BlocProvider<FTUserStateBloc>(
              create: (context) => FTUserStateBloc(data.preferences, data.userState),
            ),
          ],
          child: _BlocChangeListeners(
            child: FTDatabaseProvider(
              database: data.database,
              child: _DataScheduler(
                child: child,
              ),
            ),
          ),
        );
      },
    );
  }
}

/// [_BlocChangeListeners] is a widget that listens to state changes in
/// the complete state of the app.
///
/// - Resets authentication when the [FTEnvironment] changes.
class _BlocChangeListeners extends StatelessWidget {
  final Widget child;

  const _BlocChangeListeners({
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return BlocListener<FTAppStateBloc, FTAppState>(
      listenWhen: (previousState, state) => previousState.environment != state.environment,
      listener: (context, state) {
        final auth = context.read<FTAuthStateBloc>();

        if (auth.state.bearerToken != null) {
          auth.add(const FTAuthStateSetBearerToken());
          FTAppRouter.instance.go(FTRoutes.authLogin());
        }
      },
      child: child,
    );
  }
}

/// [_DataLoader] is responsible for preparing our app state. This will load
/// state from persistent storage and sets everything up.
///
/// [_DataLoader.wait] will alter the loaded state before returning it to
/// the state provider. This will prevent flashes where previous state is
/// shown and immediately changed in the next frame.
class _DataLoader {
  final FTDatabase database;
  final SharedPreferences preferences;
  final FTAppState appState;
  final FTAuthState authState;
  final FTSalesState salesState;
  final FTUserState userState;

  const _DataLoader({
    required this.database,
    required this.preferences,
    required this.appState,
    required this.authState,
    required this.salesState,
    required this.userState,
  });

  /// Preloads all the data the app needs before showing content.
  /// This also alters the state before is is given to the bloc provider, this
  /// will prevent flashes where previous state is shown.
  static Future<_DataLoader> wait() async {
    final database = FTDatabase();
    await database.open();

    final preferences = await SharedPreferences.getInstance();
    var appState = FTAppState.load(preferences);
    var authState = FTAuthState.load(preferences);
    var salesState = FTSalesState.load(preferences);
    var userState = FTUserState.load(preferences);

    return _DataLoader(
      database: database,
      preferences: preferences,
      appState: appState,
      authState: authState,
      salesState: salesState,
      userState: userState,
    );
  }
}

/// [_DataScheduler] is responsible for scheduled tasks within our app. It
/// will pull user claims every 5 minutes and checks if the user is still
/// logged in.
class _DataScheduler extends StatefulWidget {
  final Widget child;

  const _DataScheduler({
    required this.child,
  });

  @override
  createState() => _DataSchedulerState();
}

class _DataSchedulerState extends State<_DataScheduler> {
  late Timer timer;

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    timer = Timer.periodic(const Duration(seconds: 15), _onTick);

    onMounted(() {
      _onTick(timer);
    });
  }

  void _onTick(Timer _) {
    // every minute.
    if (timer.tick % 4 == 0) {
      _updateUserClaims();
    }

    // more tasks eventually...
  }

  void _refreshAuthToken() async {
    final bloc = context.read<FTAuthStateBloc>();

    if (!bloc.state.isSignedIn) {
      return;
    }

    final authService = FTAuthService(context: context);
    final user = bloc.state.user!;
    FTHttpResponse<FTAuthTokenResponseModel>? tokenResponse;

    switch (user.userType) {
      case FTUserType.appTeam:
        tokenResponse = await authService.refreshAppTeam(
          token: bloc.state.bearerToken!,
        );
        break;

      case FTUserType.organizer:
        tokenResponse = await authService.refresh(
          token: bloc.state.bearerToken!,
        );
        break;
    }

    if (tokenResponse.isOk) {
      bloc.add(FTAuthStateSetBearerToken(
        bearerToken: tokenResponse.data!.accessToken,
        user: tokenResponse.data!.user,
        validUntil: tokenResponse.data!.validUntil,
      ));
    } else {
      bloc.add(const FTAuthStateSetBearerToken());
      FTAppRouter.instance.go(FTRoutes.authLogin());
    }
  }

  void _updateUserClaims() async {
    final bloc = context.read<FTAuthStateBloc>();

    if (!bloc.state.isSignedIn) {
      return;
    }

    final authService = FTAuthService(context: context);
    final user = bloc.state.user!;
    FTBaseUserModel? newUser;

    switch (user.userType) {
      case FTUserType.appTeam:
        final response = await authService.claimsAppTeam();

        if (response.isUnsanctioned) {
          _refreshAuthToken();
          return;
        }

        if (!response.isOk) {
          return;
        }

        newUser = (user as FTAppTeamUserModel).copyWith(
          claims: response.data!.toSet(),
        );
        break;

      case FTUserType.organizer:
        final response = await authService.claims();

        if (response.isUnsanctioned) {
          _refreshAuthToken();
          return;
        }

        if (!response.isOk) {
          return;
        }

        newUser = (user as FTOrganizerUserModel).copyWith(
          claims: response.data!.toSet(),
        );
        break;

      default:
        return;
    }

    bloc.add(FTAuthStateSetUser(newUser));
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (_) => widget.child,
    );
  }
}
