import 'package:carrot/carrot.dart';

class FTConfig {
  // App
  static const title = 'Fancee Ticketing';

  // Defaults
  static const defaultIconStyle = CarrotIconStyle.regular;

  // Flags
  static const debugHttpRequests = false;
  static const enableEnvironmentSwitching = true;
  static const gridBackgroundPuzzleMode = true;
}
