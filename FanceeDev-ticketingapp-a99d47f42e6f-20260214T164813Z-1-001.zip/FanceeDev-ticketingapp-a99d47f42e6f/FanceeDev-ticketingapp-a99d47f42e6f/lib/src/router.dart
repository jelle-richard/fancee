import 'package:carrot/carrot.dart';

import 'component/shell/shell.dart';
import 'data/data.dart';
import 'routes.dart';
import 'view/view.dart';

late CarrotRouter _router;

class FTAppRouter extends StatefulWidget {
  static CarrotRouter get instance => _router;

  const FTAppRouter({
    super.key,
  });

  @override
  createState() => _FTAppRouterState();
}

class _FTAppRouterState extends State<FTAppRouter> {
  static final _key = GlobalKey(debugLabel: 'fancee_app:router');

  @override
  void initState() {
    super.initState();

    final auth = context.read<FTAuthStateBloc>();

    _router = CarrotRouter(
      initialLocation: auth.state.isSignedIn ? FTRoutes.more() : FTRoutes.authLogin(),
      routes: [
        CarrotShellRoute.defaultTransition(
          builder: (context, state, child) => FTShellAuth(
            child: child,
          ),
          routes: [
            FTViewAuthForgotPassword.route,
            FTViewAuthLogin.route,
            FTViewAuthScanSignIn.route,
          ],
        ),
        CarrotShellRoute.defaultTransition(
          builder: (context, state, child) => FTShellRoot(
            child: child,
          ),
          routes: [
            FTViewMore.route,
            FTViewNoticeUnsupportedUser.route,
            FTViewSales.route,
            FTViewScan.route,
            FTViewStatistics.route,
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Router(
      key: _key,
      backButtonDispatcher: _router.backButtonDispatcher,
      restorationScopeId: 'fancee_app:router',
      routeInformationProvider: _router.routeInformationProvider,
      routeInformationParser: _router.routeInformationParser,
      routerDelegate: _router.routerDelegate,
    );
  }
}
