import 'data/data.dart';

class FTRoutes {
  static String authForgotPassword() => '/forgot-password';

  static String authLogin() => '/login';

  static String authScanSignIn() => '/scan-sign-in';

  static String more() => '/more';

  static String moreDev() => '/more/dev';

  static String moreDevUI() => '/more/dev/ui';

  static String morePinTerminals() => '/more/pin-terminals';

  static String morePrinters() => '/more/printers';

  static String moreSettings() => '/more/settings';

  static String noticeUnsupportedUser() => '/notice/unsupported-user';

  static String sales() => '/sales';

  static String salesDetails(String eventId, String shopCode, String shopName) => '/sales/$eventId/$shopCode/details?${_query({
            'shopName': shopName,
          })}';

  static String salesOrder(String orderId) => '/sales/order/$orderId';

  static String salesShop(String eventId, String shopCode, String shopName) => '/sales/$eventId/$shopCode?${_query({
            'shopName': shopName,
          })}';

  static String salesSummary(String eventId, String shopCode, String shopName) => '/sales/$eventId/$shopCode/summary?${_query({
            'shopName': shopName,
          })}';

  static String scan() => '/scan';

  static String scanCamera() => '/scan/camera';

  static String scanResult(FTScanResultType type, [String? message, String? reason]) => '/scan/result/$type?${_query({
            'message': message,
            'reason': reason,
          })}';

  static String statistics() => '/statistics';

  static String statisticsEvent(String eventId, String eventName) => '/statistics/$eventId?${_query({
            'eventName': eventName,
          })}';
}

String _query(Map<String, dynamic> query) {
  return FTHttpQuery.fromPairs(query).toString();
}
