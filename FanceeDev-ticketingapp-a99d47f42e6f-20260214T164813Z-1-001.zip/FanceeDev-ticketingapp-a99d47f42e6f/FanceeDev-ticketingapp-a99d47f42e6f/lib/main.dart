import 'package:carrot/carrot.dart';
import 'package:flutter/foundation.dart';
import 'package:rollbar_flutter/rollbar.dart';

import 'src/app.dart';

Future<void> main() async {
  if (kDebugMode) {
    runApp(const FTApp());
  } else {
    await RollbarFlutter.run(
      const Config(
        // note(Bas): This access token is an event write-only access token
        //  and is therefore allowed to be in the source.
        accessToken: 'f54e9061657848c6b7d7ac15f072868f',
        handleUncaughtErrors: true,
        includePlatformLogs: false,
        package: 'TicketingApp',
        persistenceLifetime: Duration(
          hours: 1,
        ),
      ),
      () => runApp(const FTApp()),
    );
  }
}
