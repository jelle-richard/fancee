using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class EngagementSumItem : SumItem
{
    public int Shares { get; set; } = 0;

    public int Comments { get; set; } = 0;

    public int Likes { get; set; } = 0;
}