using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class GainedAndLostSumGroup : SumGroup<GainedAndLostSumItem>
{
    public int TotalGained { get; set; }
    public int TotalLost { get; set; }
    public int Total { get; set; }

    public GainedAndLostSumGroup(string date, IEnumerable<GainedAndLostSumItem> values) : base(date, values) => CalculateTotals();

    private void CalculateTotals()
    {
        Total = Values.Sum(v => v.Value ?? 0);
        TotalLost = Values.Sum(v => v.Lost);
        TotalGained = Values.Sum(v => v.Gained);
    }
}