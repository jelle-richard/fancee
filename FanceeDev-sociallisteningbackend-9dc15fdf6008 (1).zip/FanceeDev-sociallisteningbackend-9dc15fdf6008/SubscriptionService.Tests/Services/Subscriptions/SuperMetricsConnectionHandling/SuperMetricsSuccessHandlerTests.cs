using System.Dynamic;
using System.Net;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence.Entries;
using SocialListeningCore.Services.Scheduler;
using SubscriptionService.Persistence.Channels;
using SubscriptionService.Persistence.Subscriptions;
using SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;

namespace SubscriptionService.Tests.Services.Subscriptions.SuperMetricsConnectionHandling;

public class SuperMetricsSuccessHandlerTests
{
    private const string ChannelId = "ChannelId";
    private const string SubscriptionId = "SubscriptionId";
    private static readonly Input Input = SubscriptionType.FBPD_PAGE.ToInput();

    private readonly Channel _errChannel = new()
    {
        Id = ChannelId,
        CreatedOn = default,
        UpdatedOn = default,
        ChannelType = ChannelType.FACEBOOK,
        Status = ChannelStatus.Error,
        HasError = true,
        Name = "SocialMediaPlatformWeAllHateDearly",
        Request = null,
        RequestDisplayName = null,
        UserId = default,
        Owner = null
    };

    private readonly Channel _nonErrChannel = new()
    {
        Id = ChannelId,
        CreatedOn = default,
        UpdatedOn = default,
        ChannelType = ChannelType.FACEBOOK,
        Status = ChannelStatus.Active,
        HasError = false,
        Name = "SocialMediaPlatformWeAllHateDearly",
        Request = null,
        RequestDisplayName = null,
        UserId = default,
        Owner = null
    };

    private readonly Subscription _subscription = new()
    {
        Id = "SubscriptionId",
        Input = SubscriptionType.FBPD_PAGE.ToInput(),
        SubscriptionType = SubscriptionType.FBPD_PAGE,
        ChannelId = ChannelId,
        Cron = "* * * * *"
    };

    private readonly Connection _connection = new()
    {
        Id = "ConnectionId",
        SubscriptionId = SubscriptionId,
        Data = GetTestingData(),
        Input = Input
    };

    private readonly Connection _historyConnection = new()
    {
        Id = "ConnectionId",
        SubscriptionId = SubscriptionId,
        Data = GetTestingData(),
        Input = Input
    };

    private readonly SuperMetricsSuccessHandler _sut;
    private readonly Mock<ISubscriptionsDao> _mockedSubscriptionsDao = new();
    private readonly Mock<IGenericEntriesDao> _mockedGenericEntriesDao = new();
    private readonly Mock<IChannelDao> _mockedChannelDao = new();
    private readonly Mock<ISchedulerService<Subscription>> _mockedSchedulerService = new();
    private readonly Mock<ILoggerFactory> _mockedLoggerFactory = new();
    private readonly Mock<ILogger> _mockedLogger = new();

    public SuperMetricsSuccessHandlerTests()
    {
        _mockedLoggerFactory.Setup(lf => lf.CreateLogger(It.IsAny<string>()))
            .Returns(_mockedLogger.Object);

        dynamic meta = new ExpandoObject();
        meta.query = new ExpandoObject();
        meta.query.fields = GetTestingFields();

        _connection.Meta = meta;
        _historyConnection.Meta = meta;

        _sut = new(
            _mockedSubscriptionsDao.Object,
            _mockedGenericEntriesDao.Object,
            _mockedChannelDao.Object,
            _mockedSchedulerService.Object,
            _mockedLoggerFactory.Object
        );
    }

    [Fact]
    public void TestThatSuperMetricsSuccessHandlingHasStatusCodeOk() => Assert.Contains(HttpStatusCode.OK, _sut.StatusCode);

    [Fact]
    public async Task TestThatCallServerAsyncReturnsConnectionWhenSuccessful()
    {
        _mockedGenericEntriesDao.Setup(ged => ged.UpdateAsync(
                It.IsAny<GenericEntry>(),
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(new GenericEntry(SubscriptionType.FBPD_PAGE));

        _mockedChannelDao.Setup(cd => cd.GetAsync(_subscription.ChannelId!))
            .ReturnsAsync(_nonErrChannel);

        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(_subscription);

        var actual = await _sut.HandleAsync(_connection, _subscription);

        _mockedGenericEntriesDao.Verify(ged =>
                ged.UpdateAsync(
                    It.IsAny<GenericEntry>(),
                    It.IsAny<FilterDefinition<GenericEntry>>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()
                ),
            Times.Exactly(GetTestingData().Count - 1)
        );
        _mockedSubscriptionsDao.Verify(sd => sd.UpdateFieldsAsync(_subscription), Times.Exactly(1));
        _mockedChannelDao.Verify(cd => cd.GetAsync(_subscription.ChannelId!), Times.Exactly(1));

        _mockedChannelDao.Verify(cd => cd.UpdateStatusAndMailStatusAsync(_subscription.ChannelId!, ChannelStatus.Active, false), Times.Exactly(1));
        _mockedSchedulerService.Verify(ss => ss.AddOrUpdateSchedule(_subscription), Times.Exactly(1));

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatHandleStopsJobWhenChannelIsNull()
    {
        _mockedGenericEntriesDao.Setup(ged => ged.UpdateAsync(
                It.IsAny<GenericEntry>(),
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(new GenericEntry(SubscriptionType.FBPD_PAGE));

        _mockedChannelDao.Setup(cd => cd.GetAsync(_subscription.ChannelId!))
            .ReturnsAsync(() => null);

        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(_subscription);

        await Assert.ThrowsAsync<ChannelNotFoundException>(() => _sut.HandleAsync(_connection, _subscription));

        _mockedGenericEntriesDao.Verify(ged =>
                ged.UpdateAsync(
                    It.IsAny<GenericEntry>(),
                    It.IsAny<FilterDefinition<GenericEntry>>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()
                ),
            Times.Exactly(GetTestingData().Count - 1)
        );
        _mockedSubscriptionsDao.Verify(sd => sd.UpdateFieldsAsync(_subscription), Times.Exactly(1));
        _mockedChannelDao.Verify(cd => cd.GetAsync(_subscription.ChannelId!), Times.Exactly(1));

        _mockedSchedulerService.Verify(ss => ss.StopJob(_subscription.Name!), Times.Exactly(1));

        _mockedChannelDao.Verify(cd => cd.UpdateStatusAndMailStatusAsync(_subscription.ChannelId!, ChannelStatus.Active, false), Times.Exactly(0));
        _mockedSchedulerService.Verify(ss => ss.AddOrUpdateSchedule(_subscription), Times.Exactly(0));
    }

    [Fact]
    public async Task TestThatHandleDoesNotCallUpdateFieldsAsync()
    {
        _mockedGenericEntriesDao.Setup(ged => ged.UpdateAsync(
                It.IsAny<GenericEntry>(),
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(new GenericEntry(SubscriptionType.FBPD_PAGE));

        _mockedChannelDao.Setup(cd => cd.GetAsync(_subscription.ChannelId!))
            .ReturnsAsync(_nonErrChannel);

        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(_subscription);

        _subscription.Fields = new List<Field>();
        var actual = await _sut.HandleAsync(_connection, _subscription);

        _mockedGenericEntriesDao.Verify(ged =>
                ged.UpdateAsync(
                    It.IsAny<GenericEntry>(),
                    It.IsAny<FilterDefinition<GenericEntry>>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()
                ),
            Times.Exactly(GetTestingData().Count - 1)
        );
        _mockedSubscriptionsDao.Verify(sd => sd.UpdateFieldsAsync(_subscription), Times.Exactly(0));
        _mockedChannelDao.Verify(cd => cd.GetAsync(_subscription.ChannelId!), Times.Exactly(1));

        _mockedChannelDao.Verify(cd => cd.UpdateStatusAndMailStatusAsync(_subscription.ChannelId!, ChannelStatus.Active, false), Times.Exactly(1));
        _mockedSchedulerService.Verify(ss => ss.AddOrUpdateSchedule(_subscription), Times.Exactly(1));

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatHandleUpdatesChannelWithPartialStatus()
    {
        _mockedGenericEntriesDao.Setup(ged => ged.UpdateAsync(
                It.IsAny<GenericEntry>(),
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(new GenericEntry(SubscriptionType.FBPD_PAGE));

        _mockedChannelDao.Setup(cd => cd.GetAsync(_subscription.ChannelId!))
            .ReturnsAsync(_errChannel);

        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(_subscription);

        var actual = await _sut.HandleAsync(_connection, _subscription);

        _mockedGenericEntriesDao.Verify(ged =>
                ged.UpdateAsync(
                    It.IsAny<GenericEntry>(),
                    It.IsAny<FilterDefinition<GenericEntry>>(),
                    It.IsAny<string>(),
                    It.IsAny<bool>()
                ),
            Times.Exactly(GetTestingData().Count - 1)
        );
        _mockedSubscriptionsDao.Verify(sd => sd.UpdateFieldsAsync(_subscription), Times.Exactly(1));
        _mockedChannelDao.Verify(cd => cd.GetAsync(_subscription.ChannelId!), Times.Exactly(1));

        _mockedChannelDao.Verify(cd => cd.UpdateStatusAndMailStatusAsync(_subscription.ChannelId!, ChannelStatus.PartiallyActive, true), Times.Exactly(1));
        _mockedSchedulerService.Verify(ss => ss.AddOrUpdateSchedule(_subscription), Times.Exactly(1));

        Assert.NotNull(actual);
    }

    // Unit test helpers
    private static List<dynamic> GetTestingFields() =>
    [
        CreateExpandoObject("today", "string.time.date"),
        CreateExpandoObject("Date", "string.time.date"),
        CreateExpandoObject("date", "string.time.date"),
        CreateExpandoObject("post_created_time_of_day", "string.text.value"),
        CreateExpandoObject("post_message", "string.text.value"),
        CreateExpandoObject("timestamp", "string.time.datetime"),
        CreateExpandoObject("media_caption", "string.text.value")
    ];

    private static dynamic CreateExpandoObject(string fieldId, string dataType)
    {
        dynamic expando = new ExpandoObject();
        var expandoDictionary = (IDictionary<string, object>)expando;

        expandoDictionary["field_id"] = fieldId;
        expandoDictionary["data_type"] = dataType;
        expandoDictionary["field_name"] = string.Empty;

        return expando;
    }

    private static List<object[]> GetTestingData()
    {
        var message = "Testing message #test1 #test2 @test3 @test4 TEST5 TEST6 👁👄👁";
        var date = "2022-01-01";
        var time = "12:34:56";
        var dateTime = $"{date} {time}";
        var list = new List<object[]>
        {
            new object[]
            {
                "Date",
                "Date for GT",
                "Date for FB",
                "Time for FB_POSTS",
                "Content for FB_POSTS",
                "DateTime for IGI_MEDIA",
                "Content for IGI_MEDIA"
            }
        };

        list.AddRange(
            Enumerable.Repeat(
                new object[]
                {
                    date,
                    date,
                    date,
                    time,
                    message,
                    dateTime,
                    message
                },
                120
            )
        );

        return list;
    }
}