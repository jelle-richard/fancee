using System.Net;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Services.Scheduler;
using SocialListeningCore.Utils.Cron;
using SubscriptionService.Persistence.Channels;
using SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Services.Subscriptions.SuperMetricsConnectionHandling;

public class SuperMetricsErrorHandlerTests
{
    private static readonly Channel ErrChannel = new()
    {
        Id = "channelId",
        CreatedOn = default,
        UpdatedOn = default,
        ChannelType = ChannelType.FACEBOOK,
        Status = ChannelStatus.Active,
        HasError = true,
        Name = "SocialMediaPlatformWeAllHateDearly",
        Request = null,
        RequestDisplayName = null,
        UserId = Guid.NewGuid(),
        Owner = null
    };

    private static readonly Channel NonErrChannel = new()
    {
        Id = "channelId",
        CreatedOn = default,
        UpdatedOn = default,
        ChannelType = ChannelType.FACEBOOK,
        Status = ChannelStatus.Active,
        HasError = false,
        Name = "SocialMediaPlatformWeAllHateDearly",
        Request = null,
        RequestDisplayName = null,
        UserId = Guid.NewGuid(),
        Owner = null
    };

    private static readonly Subscription Subscription = new()
    {
        Id = "subId",
        CreatedOn = default,
        UpdatedOn = default,
        Cron = CronConstants.CronRunEvery5Minutes,
        Active = true,
        RunOnce = false,
        ChannelId = ErrChannel.Id,
        SubscriptionType = SubscriptionType.FA_CAMPAIGN
    };

    private static readonly Connection FailedConn = new()
    {
        Id = "connId",
        CreatedOn = default,
        UpdatedOn = default,
        SubscriptionId = Subscription.Id,
        Error = new()
        {
            Code = "QUERY_ERROR"
        },
        SubscriptionType = SubscriptionType.FA_CAMPAIGN
    };

    private readonly SuperMetricsErrorHandler _sut;
    private readonly Mock<IChannelDao> _mockedChannelDao = new();
    private readonly Mock<ISchedulerService<Subscription>> _mockedSubscriptionSchedulerService = new();
    private readonly Mock<ILoggerFactory> _mockedLoggerFactory = new();
    private readonly Mock<ILogger> _mockedLogger = new();

    public SuperMetricsErrorHandlerTests()
    {
        _mockedLoggerFactory.Setup(lf => lf.CreateLogger(It.IsAny<string>()))
            .Returns(_mockedLogger.Object);

        _sut = new(_mockedChannelDao.Object, _mockedSubscriptionSchedulerService.Object, _mockedLoggerFactory.Object);
    }

    [Fact]
    public void TestThatSuperMetricsErrorHandlingHasStatusCodeInternalServerError() => Assert.Contains(HttpStatusCode.InternalServerError, _sut.StatusCode);

    [Fact]
    public async Task TestThatHandleCallsUnderlyingMethodsAndStopsJob()
    {
        _mockedChannelDao.Setup(cd => cd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(NonErrChannel);

        await _sut.HandleAsync(FailedConn, Subscription);

        _mockedChannelDao.Verify(cd => cd.UpdateStatusAndMailStatusAsync(ErrChannel.Id!, ChannelStatus.Error, true), Times.Exactly(1));
        _mockedSubscriptionSchedulerService.Verify(cd => cd.StopJob(Subscription.Name), Times.Exactly(1));
        _mockedLogger.VerifyLogging(
            $"Failed to call server for subscription {Subscription.Id} of {ErrChannel.Name}: {FailedConn.Error.ToJson()}",
            LogLevel.Warning,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatHandleCallsDoesNotUpdateChannelButStopsJob()
    {
        _mockedChannelDao.Setup(cd => cd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(ErrChannel);

        await _sut.HandleAsync(FailedConn, Subscription);

        _mockedChannelDao.Verify(cd => cd.UpdateStatusAndMailStatusAsync(ErrChannel.Id!, ChannelStatus.Error, true), Times.Exactly(0));
        _mockedSubscriptionSchedulerService.Verify(cd => cd.StopJob(Subscription.Name), Times.Exactly(1));
        _mockedLogger.VerifyLogging(
            $"Failed to call server for subscription {Subscription.Id} of {ErrChannel.Name}: {FailedConn.Error.ToJson()}",
            LogLevel.Warning,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatHandleThrowsChannelNotFoundException()
    {
        _mockedChannelDao.Setup(cd => cd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<ChannelNotFoundException>(() => _sut.HandleAsync(FailedConn, Subscription));

        _mockedChannelDao.Verify(cd => cd.UpdateStatusAndMailStatusAsync(ErrChannel.Id!, ChannelStatus.Error, true), Times.Exactly(0));
        _mockedSubscriptionSchedulerService.Verify(cd => cd.StopJob(Subscription.Name), Times.Exactly(1));
        _mockedLogger.VerifyLogging(
            $"Failed to call server for subscription {Subscription.Id} of {ErrChannel.Name}: {FailedConn.Error.ToJson()}",
            LogLevel.Warning,
            Times.Exactly(0));
    }
}