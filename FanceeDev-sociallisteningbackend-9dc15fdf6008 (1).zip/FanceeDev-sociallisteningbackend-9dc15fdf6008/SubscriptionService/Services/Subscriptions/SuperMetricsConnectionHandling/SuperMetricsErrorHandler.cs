using System.Net;
using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Services.Scheduler;
using SubscriptionService.Exceptions;
using SubscriptionService.Persistence.Channels;

namespace SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;

public class SuperMetricsErrorHandler(
    IChannelDao channelDao,
    ISchedulerService<Subscription> schedulerServiceService,
    ILoggerFactory loggerFactory) : ISuperMetricsHandler
{
    public HttpStatusCode[] StatusCode => [HttpStatusCode.InternalServerError, HttpStatusCode.Forbidden];
    private readonly ILogger _logger = loggerFactory.CreateLogger<SuperMetricsSuccessHandler>();

    public async Task<Connection> HandleAsync(Connection conn, Subscription subscription)
    {
        var channel = await channelDao.GetAsync(subscription.ChannelId!);

        if (channel is null)
        {
            schedulerServiceService.StopJob(subscription.Name);
            throw new ChannelNotFoundException(subscription.ChannelId!);
        }
        if(conn.Error?.Code is null)
            throw new UnknownSuperMetricsErrorException();
        
        if (conn.Error.Code.Contains("QUERY_ERROR") && !channel.HasError)
                await channelDao.UpdateStatusAndMailStatusAsync(channel.Id!, ChannelStatus.Error, true);

        if (conn.Error.Code.Contains("QUERY_AUTH_UNAVAILABLE") && !channel.HasError)
                await channelDao.UpdateStatusAndMailStatusAsync(channel.Id!, ChannelStatus.Expired, true);
        

        schedulerServiceService.StopJob(subscription.Name);
        _logger.LogWarning("Failed to call server for subscription {subscriptionId} of {channel}: {error}", subscription.Id, channel.Name, conn.Error.ToJson());

        return conn;
    }
}