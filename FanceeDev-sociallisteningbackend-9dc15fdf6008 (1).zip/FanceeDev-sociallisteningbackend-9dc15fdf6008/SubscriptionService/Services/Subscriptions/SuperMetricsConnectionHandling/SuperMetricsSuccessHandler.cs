using System.Net;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence.Entries;
using SocialListeningCore.Services;
using SocialListeningCore.Services.Scheduler;
using SocialListeningCore.Settings;
using SubscriptionService.Persistence.Channels;
using SubscriptionService.Persistence.Subscriptions;

namespace SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;

public class SuperMetricsSuccessHandler(
    ISubscriptionsDao subscriptionsDao,
    IGenericEntriesDao genericEntriesDao,
    IChannelDao channelDao,
    ISchedulerService<Subscription> schedulerServiceService,
    ILoggerFactory loggerFactory)
    : MongoService<Subscription, ISubscriptionsDao>(subscriptionsDao), ISuperMetricsHandler
{
    public HttpStatusCode[] StatusCode => [HttpStatusCode.OK];
    private readonly ILogger _logger = loggerFactory.CreateLogger<SuperMetricsSuccessHandler>();
    private readonly ChannelStatus[] _failedStatus = [ChannelStatus.Error, ChannelStatus.Expired, ChannelStatus.PartiallyActive];
    private readonly ISubscriptionsDao _subscriptionsDao = subscriptionsDao;

    public async Task<Connection> HandleAsync(Connection conn, Subscription subscription)
    {
        await conn.TransformDataAsync(genericEntriesDao, CollectionSettings.GetCollectionName(conn.SubscriptionType), subscription.IsHistory, _logger);

        if (subscription.Fields is null)
        {
            subscription.Fields = ConnectionHelper.FieldsToList(conn.Meta!.query.fields);
            await _subscriptionsDao.UpdateFieldsAsync(subscription);
        }

        var channel = await channelDao.GetAsync(subscription.ChannelId!);

        if (channel is null)
        {
            schedulerServiceService.StopJob(subscription.Name);
            throw new ChannelNotFoundException(subscription.ChannelId!);
        }

        if (_failedStatus.Contains(channel.Status))
            await channelDao.UpdateStatusAndMailStatusAsync(channel.Id!, ChannelStatus.PartiallyActive, channel.HasError);
        else
            await channelDao.UpdateStatusAndMailStatusAsync(subscription.ChannelId!, ChannelStatus.Active, false);

        if (!subscription.IsHistory)
            schedulerServiceService.AddOrUpdateSchedule(subscription);

        return conn;
    }
}