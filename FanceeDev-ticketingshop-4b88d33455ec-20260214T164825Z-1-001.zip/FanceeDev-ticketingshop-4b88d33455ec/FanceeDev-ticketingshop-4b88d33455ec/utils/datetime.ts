import { DateTime } from 'luxon';

export function formatDateTimeLocal(dateTime?: DateTime | string | null, locale?: string): string {
    dateTime ??= DateTime.now();

    if (typeof dateTime === 'string') {
        dateTime = parseDateTimeFromUTC(dateTime);
    }

    return dateTime.toLocaleString(DateTime.DATETIME_MED, {
        locale
    });
}

export function parseDateTimeFromUTC(dateTime: string): DateTime {
    return DateTime.fromSQL(dateTime, {zone: 'UTC'});
}
