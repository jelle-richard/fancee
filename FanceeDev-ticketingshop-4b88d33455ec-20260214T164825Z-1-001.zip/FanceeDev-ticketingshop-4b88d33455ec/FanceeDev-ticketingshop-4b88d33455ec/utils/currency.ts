import { Currency } from '@fancee/data';

export function formatCentsToMoney(cents: number, currency: Currency, locale?: string): string {
    return new Intl.NumberFormat(locale ?? navigator.language, {
        currency: currency.shortCode,
        style: 'currency'
    }).format(cents / Math.pow(10, currency.decimals));
}
