export function downloadBlob(blob: Blob, filename: string): void {
    const url = URL.createObjectURL(blob);
    downloadUrl(url, filename);
    URL.revokeObjectURL(url);
}

export function downloadUrl(url: string, filename: string): void {
    const anchor = document.createElement('a');
    anchor.download = filename;
    anchor.href = url;

    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
}
