<template>
    <Html v-bind="head.htmlAttrs">
    <Head>
        <Title>Fancee</Title>

        <template
            v-for="link of head.link"
            :key="link.id">
            <Link
                :id="link.id"
                :rel="link.rel"
                :href="link.href"
                :hreflang="link.hreflang"/>
        </template>

        <template
            v-for="meta of head.meta"
            :key="meta.id">
            <Meta
                :id="meta.id"
                :property="meta.property"
                :content="meta.content"/>
        </template>

        <Style
            type="text/css"
            :children="`body { --background: ${backgroundColor}; font-size: 15px; }`"/>
    </Head>
    <Body>
    <main :class="[$style.agendaContainer, {'is-small': isSmall}]">
        <slot/>
    </main>
    </Body>
    </Html>
</template>

<script
    lang="ts"
    setup>
    useTracking(false);

    const head = useLocaleHead({
        addDirAttribute: true,
        addSeoAttributes: true,
        identifierAttribute: 'id'
    });
    const route = useRoute();

    const agendaRef = useAgenda();
    const backgroundColor = useAgendaDesignColor('backgroundColor', undefined, undefined, agendaRef);

    const isSmall = computed(() => route.meta.small === true);
</script>

<style
    lang="scss"
    module>
    .agendaContainer {
        padding: 18px 0;
        margin: 0 auto 90px;
        max-width: 840px;

        &.isSmall {
            max-width: 600px;
        }

        @media (max-width: 900px) {
            margin-bottom: 0;
        }
    }
</style>
