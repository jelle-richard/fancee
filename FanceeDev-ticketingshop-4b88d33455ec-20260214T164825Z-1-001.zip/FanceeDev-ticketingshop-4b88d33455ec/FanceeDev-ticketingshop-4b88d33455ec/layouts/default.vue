<template>
    <Html v-bind="head.htmlAttrs">
    <Head>
        <template
            v-for="link in head.link"
            :key="link.id">
            <Link
                :id="link.id"
                :rel="link.rel"
                :href="link.href"
                :hreflang="link.hreflang"/>
        </template>

        <template
            v-for="meta in head.meta"
            :key="meta.id">
            <Meta
                :id="meta.id"
                :property="meta.property"
                :content="meta.content"/>
        </template>
    </Head>
    <Body>
    <slot/>
    </Body>
    </Html>
</template>

<script setup>
    const head = useLocaleHead({
        addDirAttribute: true,
        addSeoAttributes: true,
        identifierAttribute: 'id'
    });
</script>
