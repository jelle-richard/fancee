import { resolve } from 'path';

export default defineNuxtConfig({
    modules: [
        '@nuxtjs/i18n',
        '@pinia/nuxt'
    ],
    app: {
        baseURL: process.env.BASE_URL ?? '/',
        layoutTransition: false
    },
    devtools: {
        enabled: false
    },
    i18n: {
        baseUrl: 'https://shop.wearefancee.com',
        defaultLocale: 'en',
        detectBrowserLanguage: {
            cookieKey: 'waf_language',
            fallbackLocale: 'en',
            redirectOn: 'all',
            useCookie: true
        },
        locales: [
            {code: 'en', iso: 'en-US', name: 'English'},
            {code: 'nl', iso: 'nl-NL', name: 'Nederlands'},
            {code: 'de', iso: 'de-DE', name: 'Deutsch'},
            {code: 'fr', iso: 'fr-FR', name: 'Français'}
        ],
        skipSettingLocaleOnNavigate: false,
        strategy: 'no_prefix'
    },
    nitro: {
        alias: {
            '@seatsio/seatsio-vue': resolve(
                __dirname,
                './node_modules/@seatsio/seatsio-vue/dist/seatsio-vue.js'
            )
        },
        minify: true,
        preset: 'node-cluster',
        esbuild: {
            options: {
                tsconfigRaw: {
                    compilerOptions: {
                        experimentalDecorators: true
                    }
                }
            }
        }
    },
    runtimeConfig: {
        apiUrl: process.env.API_URL_SERVER ?? 'https://dev.fanc.ee/api',
        public: {
            adyenClientKey: process.env.ADYEN_CLIENT_KEY ?? 'test_73YFBZRYAVHGTLKE566RRSCVJA6ESR5Y',
            adyenEnvironment: process.env.ADYEN_ENVIRONMENT ?? 'test',
            apiUrl: process.env.API_URL ?? 'https://dev.fanc.ee/api',
            baseUrl: process.env.BASE_URL ?? '/',
            headers: {
                'CF-Access-Client-Id': process.env.CF_ACCESS_CLIENT_ID,
                'CF-Access-Client-Secret': process.env.CF_ACCESS_CLIENT_SECRET
            } as Record<string, string>,
            seatsIoWorkspaceKey: process.env.SEATSIO_WORKSPACE_KEY ?? 'c6a3c143-4a46-44b2-9d76-75d675932402'
        }
    },
    vite: {
        build: {
            minify: false,
            rollupOptions: {
                preserveEntrySignatures: 'strict'
            }
        },
        define: {
            __VUE_I18N_FULL_INSTALL__: false,
            __VUE_I18N_LEGACY_API__: false,
            __INTLIFY_PROD_DEVTOOLS__: false
        },
        server: {
            fs: {
                allow: ['..']
            }
        }
    }
});
