#!/usr/bin/env sh
set -e

if [[ -z "$1" ]]; then
  echo "No tag provided"
  exit 1
fi

if [[ -z "$2" ]]; then
  echo "No server api url provided"
  exit 1
fi

if [[ -z "$3" ]]; then
  echo "No client api url provided"
  exit 1
fi

if [[ -z "$4" ]]; then
  echo "No base url provided"
  exit 1
fi

if [[ -z "$5" ]]; then
  echo "No adyen environment provided"
  exit 1
fi

if [[ -z "$6" ]]; then
  echo "No adyen client key provided"
  exit 1
fi

if [[ -z "$7" ]]; then
  echo "No seatsio worksapce key provided"
  exit 1
fi

docker build \
  --build-arg api_url="$3" \
  --build-arg api_url_server="$2" \
  --build-arg base_url="$4" \
  --build-arg adyen_environment="$5" \
  --build-arg adyen_client_key="$6" \
  --build-arg seatsio_workspace_key="$7" \
  --build-arg npm_auth_token="$FANCEE_NPM_AUTH_TOKEN" \
  --build-arg fontawesome_auth_token="$FONTAWESOME_NPM_AUTH_TOKEN" \
  -t packages.fanc.ee/p/main/docker/frontend-shop:"$1" \
  .

docker image push packages.fanc.ee/p/main/docker/frontend-shop:"$1"
docker rmi packages.fanc.ee/p/main/docker/frontend-shop:"$1"
