<template>
    <component
        :is="tag"
        class="checkout-selectable"
        :class="{'is-selected': selected}">
        <slot/>
    </component>
</template>

<script
    lang="ts"
    setup>
    export interface Props {
        readonly selected: boolean;
        readonly tag?: 'div' | 'label';
    }

    withDefaults(defineProps<Props>(), {
        tag: 'div'
    });

    const background = useShopColor('backdropColor', {l: 6});
    const backgroundHighlight = useShopColor('backdropColor', {l: 9});
    const backgroundHover = useShopColor('backdropColor', {l: 7});
    const outlineColor = useShopColor('backdropColor', {l: 15});
</script>

<style
    lang="scss"
    scoped>
    .checkout-selectable {
        background: v-bind(background);
        border-radius: calc(var(--radius) / 2);
        cursor: pointer;
        outline: 2px solid transparent;
        outline-offset: 0;
        user-select: none;
        transition: 180ms var(--swift-out);
        transition-property: background, outline-color, outline-offset;

        &:hover {
            background: v-bind(backgroundHover);
        }

        &.is-selected {
            background: v-bind(backgroundHighlight);
            outline: 2px solid v-bind(outlineColor);
            outline-offset: 2px;
        }
    }
</style>
