<template>
    <CheckoutBox
        class="checkout-totals"
        :is-loading="orderCostLoading"
        :title="t('total')">
        <template
            v-if="orderCost"
            #header>
            <span class="checkout-totals-price">{{ formatCentsToMoney(orderCost.totalOrderCostCents, currencyRef, locale) }}</span>
        </template>

        <table class="checkout-totals-table">
            <tbody>
            <template v-if="orderCost">
                <template
                    v-for="product of cartStore.selectedProducts"
                    :key="product.id">
                    <CheckoutTotalsProduct
                        v-if="!product.seatLabels"
                        :discount="orderCost.discount?.productDiscounts.find(pd => pd.id === product.id)"
                        :product="product"/>

                    <template
                        v-else
                        v-for="seatLabel of product.seatLabels"
                        :key="seatLabel">
                        <CheckoutTotalsSeat
                            :discount="orderCost.discount?.productDiscounts.find(pd => pd.id === product.id)"
                            :product="product"
                            :seat-label="seatLabel"/>
                    </template>
                </template>

                <tr>
                    <th colspan="3">
                        <FluxSeparator/>
                    </th>
                </tr>

                <tr>
                    <td>
                        <FluxIcon
                            :size="16"
                            variant="coin"/>
                    </td>
                    <td>{{ t('fee') }}</td>
                    <td><span>{{ formatCentsToMoney(orderCost.ticketFeeCents + orderCost.productFeeCents + orderCost.seatedTicketFeeCents, currencyRef, locale) }}</span></td>
                </tr>

                <tr v-if="orderCost.paymentFeeCents > 0">
                    <td>
                        <FluxIcon
                            :size="16"
                            variant="coin"/>
                    </td>
                    <td>{{ t('payment') }}</td>
                    <td><span>{{ formatCentsToMoney(orderCost.paymentFeeCents, currencyRef, locale) }}</span></td>
                </tr>

                <tr v-if="orderCost.ticketServicePlusCents > 0">
                    <td>
                        <FluxIcon
                            :size="16"
                            variant="coin"/>
                    </td>
                    <td>{{ t('ticket_service_plus') }}</td>
                    <td><span>{{ formatCentsToMoney(orderCost.ticketServicePlusCents, currencyRef, locale) }}</span></td>
                </tr>
            </template>

            <template v-if="orderCost && orderCost.discount">
                <tr>
                    <th colspan="3">
                        <FluxSeparator/>
                    </th>
                </tr>
                <tr>
                    <td>
                        <FluxIcon
                            :size="16"
                            variant="badge-percent"/>
                    </td>
                    <td>{{ t('discount', {code: appliedDiscountCode}) }}</td>
                    <td><span>-{{ formatCentsToMoney(orderCost.discount!.totalDiscountCents, currencyRef, locale) }}</span></td>
                </tr>
            </template>

            <template v-else>
                <tr>
                    <th colspan="3">
                        <FluxSeparator/>
                    </th>
                </tr>
                <tr>
                    <th colspan="3">
                        <FluxFormInputGroup class="checkout-totals-discount">
                            <FluxFormInput
                                v-model="discountCode"
                                :is-disabled="isApplyingDiscountCode"
                                :placeholder="t('discount_code')"
                                @keydown.enter="apply"/>

                            <FluxSecondaryButton
                                :disabled="discountCode === '' || isApplyingDiscountCode"
                                :is-loading="isApplyingDiscountCode"
                                :label="t('apply')"
                                @click="apply"
                                @keydown.enter="apply"/>
                        </FluxFormInputGroup>
                    </th>
                </tr>
            </template>
            </tbody>
        </table>
    </CheckoutBox>
</template>

<script
    lang="ts"
    setup>
    import { DiscountService, OrderService } from '@fancee/api';
    import { OrderCost } from '@fancee/data';
    import { FluxFormInput, FluxFormInputGroup, FluxIcon, FluxSecondaryButton, FluxSeparator, showSnackbar } from '@fancee/flux';

    const {locale, t} = useI18n();
    const {apply: applyDiscountCode} = useService(DiscountService);
    const {getCost} = useService(OrderService);
    const cartStore = useCartStore();
    const currencyRef = useCurrency();
    const reserveStore = useReserveStore();
    const {order} = storeToRefs(reserveStore);

    const discountCode = ref('');
    const isApplyingDiscountCode = ref(false);
    const orderCost = ref<OrderCost | null>(null);
    const orderCostLoading = ref(true);

    const appliedDiscountCode = computed(() => unref(order)?.discountCode ?? '-');

    async function apply(): Promise<void> {
        if (!reserveStore.reference) {
            return;
        }

        isApplyingDiscountCode.value = true;

        try {
            const {data} = await applyDiscountCode(reserveStore.reference, unref(discountCode));
            reserveStore.order!.discountCode = unref(discountCode);
            reserveStore.setDiscount(data);
            await getOrderCost();
        } catch (err) {
            showSnackbar({
                color: 'danger',
                duration: 9000,
                icon: 'circle-exclamation',
                message: t('discount_code_failed_message'),
                title: t('discount_code_failed')
            });

            discountCode.value = '';
            reserveStore.order!.discountCode = null;
            reserveStore.setDiscount(null);
        }

        isApplyingDiscountCode.value = false;
    }

    async function getOrderCost(): Promise<void> {
        if (!reserveStore.order || !reserveStore.reference) {
            return;
        }

        orderCostLoading.value = true;

        const {data} = await getCost(
            reserveStore.reference,
            reserveStore.order.paymentMethodId,
            reserveStore.order.receiveViaSms,
            reserveStore.order.enabledTicketServicePlus
        );

        orderCost.value = data;
        orderCostLoading.value = false;
    }

    watchEffect(getOrderCost);

    const inputBackground = useShopColor('backdropColor');
    const inputBorder = useShopColor('backdropColor', {l: 12});
    const tableCell = useShopColor('backdropColor', {l: 6});
    const tableCellHighlight = useShopColor('backdropColor', {l: 9});
</script>

<style
    lang="scss"
    scoped>
    .checkout-totals {
        ::v-deep(.flux-form-input) {
            background: v-bind(inputBackground);
            border-color: v-bind(inputBorder);
            font-weight: 500;
        }

        ::v-deep(.flux-icon) {
            display: block;
        }

        &-price {
            color: var(--foreground);
            font-size: 21px;
            font-weight: 700;
            font-variant: tabular-nums;
        }

        &-table {
            margin: -9px;
            width: calc(100% + 18px);
            border: 0;
            border-spacing: 0 3px;
            font-size: 15px;

            ::v-deep(.flux-separator) {
                margin-top: 6px;
                margin-bottom: 6px;
            }

            ::v-deep(td) {
                padding: 9px 12px;
                background: v-bind(tableCell);
                line-height: 1;

                &:first-child,
                &:last-child {
                    width: 0;
                    white-space: nowrap;
                }

                &:first-child {
                    background: v-bind(tableCellHighlight);
                    border-top-left-radius: calc(var(--radius) / 2);
                    border-bottom-left-radius: calc(var(--radius) / 2);
                    font-size: 14px;
                    font-weight: 700;
                }

                &:last-child {
                    border-top-right-radius: calc(var(--radius) / 2);
                    border-bottom-right-radius: calc(var(--radius) / 2);
                    text-align: right;
                }
            }
        }
    }
</style>

<i18n lang="yaml">
en:
    apply: "Apply"
    discount: "Discount {code}"
    discount_code: "Discount code"
    discount_code_failed: "Discount Code Application Failed"
    discount_code_failed_message: "Oops! The discount code you entered is invalid. Please double-check and try again. For help, contact support. Thank you!"
    fee: "Administration costs"
    payment: "Payment costs"
    ticket_service_plus: "Ticket Service Plus"
    total: "Total"

nl:
    apply: "Toepassen"
    discount: "Kortingscode {code}"
    discount_code: "Kortingscode"
    discount_code_failed: "Kortingcode Toepassing Mislukt"
    discount_code_failed_message: "Oeps! De kortingcode die je hebt ingevoerd is ongeldig. Controleer de code en probeer het opnieuw. Neem bij vragen contact op met de klantenservice. Bedankt!"
    fee: "Administratiekosten"
    payment: "Betaalkosten"
    ticket_service_plus: "Ticket Service Plus"
    total: "Totaal"

de:
    apply: "Anwenden"
    discount: "Rabatt {code}"
    discount_code: "Rabattcode"
    discount_code_failed: "Rabattcode-Anwendung fehlgeschlagen"
    discount_code_failed_message: "Hoppla! Der eingegebene Rabattcode ist ungültig. Bitte überprüfen Sie ihn und versuchen Sie es erneut. Für Hilfe kontaktieren Sie den Support. Vielen Dank!"
    fee: "Verwaltungskosten"
    payment: "Zahlungskosten"
    ticket_service_plus: "Ticket Service Plus"
    total: "Gesamt"

fr:
    apply: "Appliquer"
    discount: "Réduction {code}"
    discount_code: "Code de réduction"
    discount_code_failed: "Échec de l'application du code de réduction"
    discount_code_failed_message: "Oups ! Le code de réduction que vous avez saisi est invalide. Veuillez vérifier et réessayer. Pour obtenir de l'aide, contactez le support. Merci !"
    fee: "Frais d'administration"
    payment: "Frais de paiement"
    ticket_service_plus: "Service Plus pour les billets"
    total: "Total"
</i18n>
