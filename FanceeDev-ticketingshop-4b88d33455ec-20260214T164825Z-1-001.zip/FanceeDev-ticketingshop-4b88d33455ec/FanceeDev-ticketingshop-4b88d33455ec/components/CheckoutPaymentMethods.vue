<template>
    <CheckoutBox
        v-if="subTotal > 0"
        :span="2"
        :title="t('payment_method')">
        <div class="payment-methods">
            <template
                v-for="paymentMethod of paymentMethods"
                :key="paymentMethod.id">
                <CheckoutPaymentMethod :payment-method="paymentMethod"/>
            </template>
        </div>
    </CheckoutBox>
</template>

<script
    lang="ts"
    setup>
    const {t} = useI18n();
    const {subTotal} = useShopTotals();
    const shopRef = useShopInjection();
    const reserveStore = useReserveStore();
    const {order} = storeToRefs(reserveStore);

    const paymentMethods = computed(() => (unref(shopRef)?.event.paymentMethods ?? []).toSorted((a, b) => a.position - b.position));

    watch(subTotal, (subTotal, _, onCleanup) => {
        const o = unref(order);
        const pms = unref(paymentMethods);

        if (!o || pms.length !== 1 || subTotal === 0) {
            return;
        }

        o.paymentMethodId = pms[0].id;

        onCleanup(() => o.paymentMethodId = null);
    }, {immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .payment-methods {
        display: grid;
        gap: 9px;
        grid-template-columns: repeat(2, 1fr);

        @media (max-width: 720px) {
            grid-template-columns: 1fr;
        }
    }
</style>

<i18n lang="yaml">
en:
    payment_method: "Payment method"

nl:
    payment_method: "Betaalmethode"

de:
    payment_method: "Zahlungsmethode"

fr:
    payment_method: "Moyen de paiement"
</i18n>
