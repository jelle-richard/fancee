<template>
    <ShopPaneFooter class="navigation-mount">
        <slot name="start"/>

        <ShopPaneFooterRow class="navigation">
            <slot name="content">
                <ClientOnly>
                    <div
                        v-if="cartStore.hasSelectedProducts"
                        class="navigation-total">
                        <template v-if="route.name !== 'code-summary'">
                            <template v-if="total > 0">
                                <span class="navigation-price">{{ formatCentsToMoney(total, currencyRef, locale) }}</span>
                                <span class="navigation-fee">{{ t('fee', {fee: formatCentsToMoney(feeTotal, currencyRef, locale)}) }}</span>
                            </template>

                            <template v-else>
                                <span class="navigation-price">{{ t('free') }}</span>
                            </template>
                        </template>

                        <template v-if="reserveStore.reference">
                            <small class="navigation-timer">{{ t('timer', {time: timer}) }}</small>
                        </template>
                    </div>

                    <FluxSpacer/>

                    <FluxButtonStack>
                        <slot name="buttons"/>
                    </FluxButtonStack>
                </ClientOnly>
            </slot>
        </ShopPaneFooterRow>

        <ShopPaneFooterRow v-if="$slots.end">
            <slot name="end"/>
        </ShopPaneFooterRow>
    </ShopPaneFooter>
</template>

<script
    lang="ts"
    setup>
    import { FluxButtonStack, FluxSpacer, useInterval } from '@fancee/flux';

    const {locale, t} = useI18n();
    const {feeTotal, total} = useShopTotals();
    const currencyRef = useCurrency();
    const cartStore = useCartStore();
    const reserveStore = useReserveStore();
    const route = useRoute();
    const router = useRouter();
    const shopCodeRef = useShopCodeInjection();

    const timer = ref('');

    useInterval(1000, () => {
        if (!reserveStore.expirationDate) {
            return;
        }

        const diff = reserveStore.expirationDate.diffNow().normalize();

        if (diff.toMillis() <= 0) {
            reserveStore.reset();
            router.push(`/${unref(shopCodeRef)}`);
        }

        timer.value = diff.toFormat('mm:ss');
    });
</script>

<style
    lang="scss"
    scoped>
    .navigation {
        position: sticky;
        bottom: 0;

        &-mount {
            display: contents;
        }

        &-total {
            display: flex;
            margin-top: -3px;
            margin-bottom: -3px;
            align-items: flex-start;
            flex-flow: column;
            gap: 9px;
            line-height: 1;
        }

        &-price {
            color: var(--foreground-prominent);
            font-size: 21px;
            font-weight: 700;
        }

        &-fee {
            font-size: 15px;
        }

        &-timer {
            margin-top: 6px;
            font-size: 14px;
            font-variant: tabular-nums;
        }

        @media (max-width: 720px) {
            position: relative;

            &-total {
                margin-bottom: 15px;
            }

            ::v-deep(.flux-stack) {
                flex-flow: column-reverse;
            }
        }
    }
</style>

<i18n lang="yaml">
en:
    fee: "Including {fee} administration costs"
    free: "Free"
    timer: "{time} left to complete your order."

nl:
    fee: "Inclusief {fee} administratiekosten"
    free: "Gratis"
    timer: "Nog {time} om je bestelling af te ronden."

de:
    fee: "Inklusive {fee} Verwaltungskosten"
    free: "Kostenlos"
    timer: "Noch {time} Zeit, um Ihre Bestellung abzuschließen."

fr:
    fee: "Frais d'administration inclus {fee}"
    free: "Gratuit"
    timer: "Il vous reste {time} pour finaliser votre commande."
</i18n>
