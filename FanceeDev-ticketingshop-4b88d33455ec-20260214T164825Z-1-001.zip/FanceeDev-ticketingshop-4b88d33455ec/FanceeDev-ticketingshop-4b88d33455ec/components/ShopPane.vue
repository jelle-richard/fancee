<template>
    <FluxPane
        class="pane"
        :style="{
            '--background': background,
            '--border': border,
            '--foreground': foreground,
            '--foreground-prominent': foregroundProminent,
            '--foreground-secondary': foregroundSecondary,
            '--foreground-placeholder': foregroundPlaceholder,
            '--quantity-selector-input-background': quantitySelectorInputBackground,
            '--primary-button-background': primaryButtonBackground,
            '--primary-button-background-active': primaryButtonBackgroundActive,
            '--primary-button-background-hover': primaryButtonBackgroundHover,
            '--primary-button-border': primaryButtonBorder,
            '--primary-button-foreground': primaryButtonForeground,
            '--primary-button-icon': primaryButtonIcon,
            '--secondary-button-background': secondaryButtonBackground,
            '--secondary-button-background-active': secondaryButtonBackgroundActive,
            '--secondary-button-background-hover': secondaryButtonBackgroundHover,
            '--secondary-button-border': secondaryButtonBorder,
            '--secondary-button-foreground': secondaryButtonForeground,
            '--secondary-button-icon': secondaryButtonIcon
        }"
        :is-loading="isLoading">
        <slot/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { FluxPane } from '@fancee/flux';

    export interface Props {
        readonly isLoading?: boolean;
    }

    withDefaults(defineProps<Props>(), {
        isLoading: false
    });

    const background = useShopColor('backdropColor');
    const border = useShopColor('backdropColor', {l: 9});
    const foreground = useShopColor('textColor');
    const foregroundProminent = useShopColor('textColor', {l: -10});
    const foregroundSecondary = useShopColor('textColor', {l: 10});
    const foregroundPlaceholder = useShopColor('textColor', {l: 10}, .5);
    const quantitySelectorInputBackground = useShopColor('backdropColor');

    const primaryButtonBackground = useShopColor('primaryColor');
    const primaryButtonBackgroundActive = useShopColor('primaryColor', {l: 6});
    const primaryButtonBackgroundHover = useShopColor('primaryColor', {l: 3});
    const primaryButtonBorder = useShopColor('primaryColor', {l: 6});
    const primaryButtonForeground = useShopColor('primaryColor', {l: -45});
    const primaryButtonIcon = useShopColor('primaryColor', {l: -45});

    const secondaryButtonBackground = useShopColor('backdropColor', {l: 3});
    const secondaryButtonBackgroundActive = useShopColor('backdropColor', {l: 9});
    const secondaryButtonBackgroundHover = useShopColor('backdropColor', {l: 6});
    const secondaryButtonBorder = useShopColor('backdropColor', {l: 9});
    const secondaryButtonForeground = useShopColor('textColor');
    const secondaryButtonIcon = useShopColor('textColor');
</script>

<style
    lang="scss"
    scoped>
    .pane {
        --shop-gutter: 15px;
        --shop-margin: 0px;

        background: var(--background);
        border-color: var(--border);
        border-radius: calc(var(--radius) * 3);
        box-shadow: 0 3px 6px -3px var(--background);
        color: var(--foreground);
        contain: paint;

        ::v-deep(.flux-form-input-native)::placeholder {
            color: var(--foreground-placeholder);
        }

        ::v-deep(.flux-primary-button) {
            --button-background: var(--primary-button-background);
            --button-background-active: var(--primary-button-background-active);
            --button-background-hover: var(--primary-button-background-hover);
            --button-foreground: var(--primary-button-foreground);
            --button-icon: var(--primary-button-icon);
            --button-stroke: var(--primary-button-border);
        }

        ::v-deep(.flux-secondary-button) {
            --button-background: var(--secondary-button-background);
            --button-background-active: var(--secondary-button-background-active);
            --button-background-hover: var(--secondary-button-background-hover);
            --button-foreground: var(--secondary-button-foreground);
            --button-icon: var(--secondary-button-icon);
            --button-stroke: var(--secondary-button-border);
        }

        ::v-deep(.flux-quantity-selector) {
            border-color: var(--secondary-button-border);
        }

        ::v-deep(.flux-quantity-selector-input) {
            background: var(--quantity-selector-input-background);
            border-color: var(--secondary-button-border);
        }

        ::v-deep(.flux-separator) {
            background: var(--border);
        }

        @media (max-width: 900px) {
            --shop-gutter: 3px;
            --shop-margin: -12px;

            border-left: 0;
            border-right: 0;
            border-radius: 0;
        }
    }
</style>
