<template>
    <CheckoutSelectable
        class="payment-method"
        :selected="isSelected"
        @click="select">
        <img
            class="payment-method-image"
            :src="imageUrl"
            :alt="paymentMethod.method"/>

        <div class="payment-method-caption">
            <strong>{{ paymentMethod.method }}</strong>
            <span>{{ cost }}</span>
        </div>

        <FluxIcon
            :size="16"
            :variant="isSelected ? 'circle-check' : 'flux-empty'"/>
    </CheckoutSelectable>
</template>

<script
    lang="ts"
    setup>
    import { PaidByType, PaymentMethod } from '@fancee/data';
    import { FluxIcon } from '@fancee/flux';
    import * as paymentMethodImages from '~/assets/payment_methods';

    export interface Props {
        readonly paymentMethod: PaymentMethod;
    }

    const props = defineProps<Props>();

    const {locale, t} = useI18n();
    const {subTotal, ticketServicePlusTotal} = useShopTotals();
    const currencyRef = useCurrency();
    const reserveStore = useReserveStore();
    const {order} = storeToRefs(reserveStore);

    const imageUrl = computed(() => paymentMethodImages[props.paymentMethod.brandCode]);
    const isSelected = computed(() => unref(order)?.paymentMethodId === props.paymentMethod.id);

    const cost = computed(() => {
        const {feePercent, feeStaticCents, paidBy} = props.paymentMethod;
        unref(ticketServicePlusTotal); // note(Bas): this is here so that ticket service plus is tracked correctly.

        if (paidBy === PaidByType.Organization) {
            return t('free');
        }

        if (feePercent && feeStaticCents) {
            return formatCentsToMoney(unref(subTotal) * (feePercent / 100) + feeStaticCents, unref(currencyRef), unref(locale));
        }

        if (feePercent) {
            return formatCentsToMoney(unref(subTotal) * (feePercent / 100), unref(currencyRef), unref(locale));
        }

        if (feeStaticCents) {
            return formatCentsToMoney(feeStaticCents, unref(currencyRef), unref(locale));
        }

        return t('free');
    });

    function select(): void {
        const o = unref(order);

        if (!o) {
            return;
        }

        o.paymentMethodId = props.paymentMethod.id;
    }
</script>

<style
    lang="scss"
    scoped>
    .payment-method {
        display: flex;
        padding: 12px 15px;
        align-items: center;
        gap: 15px;

        &-caption {
            display: flex;
            flex-flow: column;
            flex-grow: 1;
            gap: 6px;
            line-height: 1;

            strong {
                font-size: 15px;
            }

            span {
                font-size: 14px;
            }
        }

        &-image {
            height: 36px;
            width: 36px;
            object-fit: contain;
            object-position: center;
        }
    }
</style>

<i18n lang="yaml">
en:
    free: "Free"

nl:
    free: "Gratis"

de:
    free: "Kostenlos"

fr:
    free: "Gratuit"
</i18n>
