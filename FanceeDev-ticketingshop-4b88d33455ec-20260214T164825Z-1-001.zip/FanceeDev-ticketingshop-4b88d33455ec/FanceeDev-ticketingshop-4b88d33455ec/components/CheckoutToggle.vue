<template>
    <CheckoutSelectable
        class="checkout-toggle"
        tag="label"
        :selected="localValue">
        <input
            v-model="localValue"
            type="checkbox"
            class="checkout-toggle-input"/>

        <FluxIcon
            class="checkout-toggle-icon"
            :variant="icon"/>

        <span class="checkout-toggle-caption">
            <strong>{{ title }}</strong>

            <span v-if="description">{{ description }}</span>

            <a
                v-if="moreInfoUrl"
                class="checkout-toggle-more-info"
                :href="moreInfoUrl"
                rel="noopener"
                target="_blank">
                <span>{{ t('more_info') }}</span>
                <FluxIcon
                    :size="14"
                    variant="arrow-up-right-from-square"/>
            </a>
        </span>

        <FluxIcon
            v-if="isMandatory  && !localValue"
            class="checkout-toggle-mandatory"
            variant="circle-exclamation"/>
    </CheckoutSelectable>
</template>

<script
    lang="ts"
    setup>
    import { FluxIcon } from '@fancee/flux';

    export interface Emits {
        (e: 'update:modelValue', value: boolean): void;
    }

    export interface Props {
        readonly modelValue: boolean;
        readonly title: string;
        readonly description?: string;
        readonly moreInfoUrl?: string;
        readonly isMandatory?: boolean;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {t} = useI18n();

    const localValue = ref(props.modelValue);

    const icon = computed(() => unref(localValue) ? 'circle-check' : 'circle');

    watch(() => props.modelValue, value => localValue.value = value);
    watch(localValue, localValue => emit('update:modelValue', localValue));

    const linkForeground = useShopColor('primaryColor', {l: 9});
    const linkForegroundHover = useShopColor('primaryColor', {l: 6});
</script>

<style
    lang="scss"
    scoped>
    .checkout-toggle {
        display: flex;
        padding: 15px 18px;
        align-items: flex-start;
        gap: 15px;

        &-caption {
            display: flex;
            align-items: flex-start;
            flex-flow: column;
            flex-grow: 1;

            span {
                font-size: 14px;
            }
        }

        &-icon {
            margin-top: 3px;
        }

        &-input {
            display: none;
        }

        &-mandatory {
            color: rgb(var(--danger-7));
        }

        &-more-info {
            display: inline-flex;
            margin-top: 3px;
            align-items: center;
            gap: 9px;
            color: v-bind(linkForeground);
            text-decoration: underline;
            text-underline-offset: 3px;

            ::v-deep(.flux-icon) {
                translate: 0 1px;
            }

            &:hover {
                color: v-bind(linkForegroundHover);
                text-decoration: none;
            }
        }
    }
</style>

<i18n lang="yaml">
en:
    more_info: "More info"

nl:
    more_info: "Meer informatie"

de:
    more_info: "Weitere Informationen"

fr:
    more_info: "Plus d'informations"
</i18n>
