<template>
    <div
        v-if="!isHidden"
        class="product"
        :class="{'is-selected': element.selectedQuantity > 0}">
        <FluxFader
            v-if="element.media.length > 0"
            class="product-fader">
            <FluxFaderItem v-for="media of element.media">
                <FluxFocalPointImage
                    alt=""
                    :focal-point="media.focalPoint"
                    :src="media.url"/>
            </FluxFaderItem>
        </FluxFader>

        <div class="product-meta">
            <div class="product-header">
                <h3 class="product-name">{{ element.name }}</h3>
                <span
                    v-if="productPriceCents > 0"
                    class="product-price">
                    {{ formatCentsToMoney(productPriceCents, currencyRef, locale) }}
                </span>

                <span
                    v-else
                    class="product-price">
                    {{ t('free') }}
                </span>
            </div>

            <p
                v-if="element.feeCents > 0"
                class="product-fee">
                {{ t('fee', {fee: formatCentsToMoney(element.feeCents, currencyRef, locale)}) }}
            </p>

            <p
                v-if="element.description && element.description.trim().length > 0"
                class="product-description">
                {{ element.description }}
            </p>
        </div>

        <template v-if="isPending">
            <div class="product-pending">
                {{ t('pending', [formatDateTimeLocal(element.saleSpan.start)]) }}
            </div>
        </template>

        <template v-else-if="element.reservableQuantity > 0">
            <div class="product-quantity">
                <FluxQuantitySelector
                    v-model="element.selectedQuantity"
                    key="client-quantity-selector"
                    :min="0"
                    :max="element.reservableQuantity"/>

                <small>{{ t('max', {value: element.reservableQuantity}) }}</small>
            </div>
        </template>

        <template v-else-if="element.hasPendingReservations">
            <div class="product-sold-out">
                {{ t('pending_stock') }}
            </div>
        </template>

        <template v-else>
            <div class="product-sold-out">
                {{ t('sold_out') }}
            </div>
        </template>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { ShopElementProduct } from '@fancee/data';
    import { FluxFader, FluxFaderItem, FluxFocalPointImage, FluxQuantitySelector } from '@fancee/flux';
    import { DateTime } from 'luxon';

    export interface Props {
        readonly element: ShopElementProduct;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const {locale, t} = useI18n();
    const {total} = useShopTotals();
    const cartStore = useCartStore();
    const currencyRef = useCurrency();
    const shopCodeRef = useShopCodeInjection();
    const tracking = useTracking();

    const isHidden = computed(() => unref(element).saleSpan.end && unref(element).saleSpan.end <= DateTime.now());
    const isPending = computed(() => unref(element).saleSpan.start && unref(element).saleSpan.start > DateTime.now());
    const productPriceCents = computed(() => unref(element).priceCents + unref(element).feeCents);
    const selectedQuantity = computed(() => unref(element).selectedQuantity);

    watch(() => cartStore.products, () => {
        const product = unref(element);
        product.selectedQuantity = cartStore.products[product.id]?.[0] ?? 0;
    }, {deep: true, immediate: true});

    watch(selectedQuantity, () => {
        const {id, selectedQuantity} = unref(element);
        cartStore.updateProduct(unref(shopCodeRef), id, selectedQuantity);
    });

    watch(selectedQuantity, (newQuantity, oldQuantity) => {
        const product = unref(element);

        if (newQuantity > oldQuantity) {
            tracking.addToCart(unref(total), product);
        } else {
            tracking.removeFromCart(unref(total), product);
        }
    }, {flush: 'post'});

    const background = useShopColor('backdropColor', {l: 3});
    const border = useShopColor('backdropColor', {l: 6});
    const mediaOutline = useShopColor('backdropColor', {l: 9});
    const faderBackground = useShopColor('backdropColor');
</script>

<style
    lang="scss"
    scoped>
    .product {
        display: grid;
        margin: 0 var(--shop-margin);
        padding: 15px;
        gap: 15px;
        grid-template-columns: auto 1fr auto;
        background: v-bind(background);
        border: 1px solid v-bind(border);
        border-radius: var(--radius);
        outline: 2px solid transparent;
        outline-offset: 3px;
        transition: 210ms var(--swift-out);
        transition-property: border, outline-color, outline-offset;

        &.is-selected {
            border-color: transparent;
            outline-color: v-bind(mediaOutline);
            outline-offset: 2px;
        }

        ::v-deep(.flux-fader) {
            width: 72px;
            aspect-ratio: 1;

            &::after {
                position: absolute;
                display: block;
                inset: 0;
                content: '';
                border: 1px solid v-bind(mediaOutline);
                border-radius: inherit;
            }
        }

        &-meta {
            padding-top: 9px;
            padding-bottom: 9px;

            &:first-child {
                grid-column: span 2;
            }
        }

        &-header {
            line-height: 1.4;
        }

        &-name {
            display: inline;
            color: var(--foreground-prominent);
            font-size: 18px;
        }

        &-price {
            display: inline;
            font-weight: 600;

            &::before {
                content: ' • ';
            }
        }

        &-fader {
            background: v-bind(faderBackground);
        }

        &-icon {
            display: flex;
            height: 100%;
            width: 100%;
            align-items: center;
            justify-content: center;
            color: v-bind(mediaOutline);
        }

        &-fee {
            margin-top: 3px;
            color: var(--foreground);
            font-size: 14px;
        }

        &-description {
            margin-top: 6px;
            font-size: 15px;
        }

        &-quantity {
            display: flex;
            align-items: center;
            flex-flow: column;
            gap: 6px;
        }

        &-pending,
        &-sold-out {
            max-width: 180px;
            color: var(--foreground-prominent);
            font-weight: 700;
            text-align: right;
        }

        @media (max-width: 900px) {
            grid-template-columns: auto 1fr;

            ::v-deep(.flux-fader) {
                grid-row: 1 / span 2;
            }

            &-meta {
                grid-column: unset;
            }

            &-quantity {
                justify-self: flex-start;
            }
        }
    }

    .product + .product {
        margin-top: -9px;
    }
</style>

<i18n lang="yaml">
en:
    fee: "Including {fee} administration costs"
    free: "Free"
    max: "Max {value}"
    pending: "Available from {0}"
    sold_out: "Sold out"
    pending_stock: "Tickets will become available again if current purchases are not completed."

nl:
    fee: "Inclusief {fee} administratiekosten"
    free: "Gratis"
    max: "Maximaal {value}"
    pending: "Beschikbaar vanaf {0}"
    sold_out: "Uitverkocht"
    pending_stock: "Tickets komen opnieuw beschikbaar als huidige aankopen niet worden voltooid."

de:
    fee: "Inklusive {fee} Verwaltungskosten"
    free: "Kostenlos"
    max: "Maximal {value}"
    pending: "Verfügbar ab {0}"
    sold_out: "Ausverkauft"
    pending_stock: "Tickets werden wieder verfügbar, wenn aktuelle Käufe nicht abgeschlossen werden."

fr:
    fee: "Frais d'administration inclus {fee}"
    free: "Gratuit"
    max: "Max {value}"
    pending: "Disponible depuis {0}"
    sold_out: "Épuisé"
    pending_stock: "Les billets seront à nouveau disponibles si les achats en cours ne sont pas terminés."
</i18n>
