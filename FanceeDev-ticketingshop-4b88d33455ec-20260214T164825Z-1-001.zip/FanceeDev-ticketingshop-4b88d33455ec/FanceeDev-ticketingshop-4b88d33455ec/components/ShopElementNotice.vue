<template>
    <FluxNotice
        class="notice"
        :icon="icon"
        :message="element.content"
        :variant="element.variant"/>
</template>

<script
    lang="ts"
    setup>
    import type { ShopElementNotice } from '@fancee/data';
    import { FluxNotice, type IconNames } from '@fancee/flux';

    export interface Props {
        readonly element: ShopElementNotice;
    }

    const props = defineProps<Props>();

    const icon = computed<IconNames>(() => {
        switch (props.element.variant) {
            case 'danger':
            case 'warning':
                return 'circle-exclamation';

            case 'info':
            case 'primary':
                return 'circle-info';

            default:
                return 'circle-check';
        }
    });
</script>

<style
    lang="scss"
    scoped>
    .notice {
        margin: 0 var(--shop-margin);
    }
</style>
