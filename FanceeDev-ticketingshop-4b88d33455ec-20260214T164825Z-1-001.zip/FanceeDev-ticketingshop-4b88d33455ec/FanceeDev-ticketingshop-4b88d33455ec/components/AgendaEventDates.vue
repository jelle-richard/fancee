<template>
    <div :class="$style.eventDate">
        <div :class="$style.eventDateStart">
            <strong>{{ event.startDate.toFormat('dd') }}</strong>
            <span>{{ event.startDate.toFormat('LLL') }}</span>
        </div>
        <div :class="$style.eventDateEnd">
            <strong>{{ event.endDate.toFormat('dd') }}</strong>
            <span>{{ event.endDate.toFormat('LLL') }}</span>
        </div>
    </div>
</template>

<script
    setup
    lang="ts">
    import { AgendaOverviewLinkedEvent } from '@fancee/data';

    export interface Props {
        readonly event: AgendaOverviewLinkedEvent;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    .eventDateStart {
        background: var(--backdrop-color-thirdly);
        color: var(--textColor-prominent);
    }

    .eventDateEnd {
        background: var(--backdrop-color-fourthly);
        color: var(--foreground-prominent);
        border: 1px solid var(--backdrop-border);
    }

    .eventDate {
        display: flex;
        flex-flow: column;
        gap: 3px;
        margin-left: auto;
    }

    .eventDateStart,
    .eventDateEnd {
        display: flex;
        flex-flow: column;
        align-items: center;
        border-radius: var(--radius);
        height: 48px;
        width: 48px;
        padding-top: 3px;

        & > span {
            font-size: 12px;
            font-weight: 800;
        }
    }
</style>
