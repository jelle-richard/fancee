<template>
    <FluxPaneBody
        class="pane-footer"
        :style="{
            '--background': background
        }">
        <slot/>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { FluxPaneBody } from '@fancee/flux';

    const background = useShopColor('backdropColor', {l: -2});
</script>

<style
    lang="scss"
    scoped>
    .pane-footer {
        padding: 0;
        background: var(--background);
    }
</style>
