<template>
    <main class="stage">
        <img
            class="illustration"
            :src="assetUrl"
            alt=""/>

        <h1>{{ title }}</h1>
        <p class="content">{{ content }}</p>
        <p class="info">{{ info }}</p>
        <slot/>
    </main>
</template>

<script
    lang="ts"
    setup>
    export interface Props {
        readonly assetUrl: string;
        readonly content: string;
        readonly info?: string;
        readonly title: string;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .stage {
        display: flex;
        height: 100dvh;
        width: 100dvw;
        align-items: center;
        flex-flow: column;
        justify-content: center;
    }

    .illustration {
        display: block;
        margin-top: -90px;
        margin-bottom: 30px;
        max-width: calc(100dvh - 150px);
        width: 240px;
    }

    h1, p {
        max-width: calc(100dvw - 90px);
        width: 480px;
        text-align: center;
        text-wrap: balance;
    }

    h1 {
        font-size: 21px;
        letter-spacing: 1px;
        text-transform: uppercase;
    }

    p.content {
        font-size: 18px;
        font-weight: 300;
    }

    p.info {
        color: var(--foreground-secondary);
        font-size: 14px;
        font-weight: 300;
    }
</style>
