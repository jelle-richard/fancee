<template>
    <div class="checkout-column">
        <slot/>
    </div>
</template>

<style
    lang="scss"
    scoped>
    .checkout-column {
        display: flex;
        flex-flow: column;
        gap: 9px;
    }
</style>
