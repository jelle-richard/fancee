<template>
    <FluxFlyout>
        <template #opener="{open}">
            <FluxSecondaryButton
                :label="currentLocale.name"
                @click="open">
                <template #before>
                    <img
                        class="flag"
                        :src="flags[currentLocale.code]"
                        :alt="currentLocale.name"/>
                </template>
            </FluxSecondaryButton>
        </template>

        <template #default="{close}">
            <FluxMenu>
                <FluxMenuGroup>
                    <template v-for="locale of availableLocales">
                        <FluxMenuItem
                            :image-url="flags[locale.code]"
                            :is-highlighted="locale.code === currentLocale.code"
                            :label="locale.name!"
                            @click="onLocaleClick(locale.code, close)"/>
                    </template>
                </FluxMenuGroup>
            </FluxMenu>
        </template>
    </FluxFlyout>
</template>

<script
    lang="ts"
    setup>
    import { FluxFlyout, FluxMenu, FluxMenuGroup, FluxMenuItem, FluxSecondaryButton } from '@fancee/flux';
    import type { LocaleObject } from 'vue-i18n-routing';
    import * as flags from '~/assets/language';

    const {locale, locales, setLocale} = useI18n();

    const availableLocales = computed(() => unref(locales) as LocaleObject[]);
    const currentLocale = computed(() => unref(availableLocales).find(l => l.code === unref(locale))!);

    function onLocaleClick(code: string, close: Function): void {
        setLocale(code);
        close();
    }
</script>

<style
    lang="scss"
    scoped>
    .flag {
        display: block;
        height: 20px;
        width: 20px;
    }
</style>
