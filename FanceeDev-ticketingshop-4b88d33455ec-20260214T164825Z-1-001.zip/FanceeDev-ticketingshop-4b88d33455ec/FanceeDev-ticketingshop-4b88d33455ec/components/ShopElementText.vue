<template>
    <section class="text-block">
        <h2>{{ element.title }}</h2>
        <p>{{ element.text }}</p>
    </section>
</template>

<script
    lang="ts"
    setup>
    import type { ShopElementTextBlock } from '@fancee/data';

    export interface Props {
        readonly element: ShopElementTextBlock;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .text-block {
        margin-left: var(--shop-gutter);
        margin-right: var(--shop-gutter);
    }

    h2 {
        color: var(--foreground-prominent);
    }

    p {
        color: var(--foreground);
    }
</style>
