<template>
    <ShopField
        :is-single-field="isSingleField"
        :is-optional="!requirement.required"
        :label="label"
        :validation-rules="validationRules"
        :value="localValue">
        <FluxFormDateInput
            v-model="localValue"
            :auto-complete="autoComplete"
            :auto-focus="autoFocus"
            :placeholder="placeholder"
            type="datetime"/>

        <slot/>
    </ShopField>
</template>

<script
    lang="ts"
    setup>
    import type { ShopFieldRequirement } from '@fancee/data';
    import { FluxFormDateInput } from '@fancee/flux';
    import type { ValidationRuleCollection } from '@vuelidate/core';
    import { DateTime } from 'luxon';

    export interface Emits {
        (e: 'update:modelValue', value: DateTime | null): void;
    }

    export interface Props {
        readonly autoComplete?: string;
        readonly autoFocus?: boolean;
        readonly isSingleField?: boolean;
        readonly label: string;
        readonly modelValue: DateTime | null;
        readonly placeholder: string;
        readonly requirement: ShopFieldRequirement;
        readonly validationRules?: ValidationRuleCollection;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {modelValue} = toRefs(props);

    const localValue = ref<DateTime | null>(null);

    watch(modelValue, modelValue => localValue.value = modelValue, {immediate: true});
    watch(localValue, localValue => emit('update:modelValue', localValue));

    const datePickerButtonIcon = useShopColor('backdropColor', {l: 50});
    const datePickerDateHover = useShopColor('backdropColor', {l: 3});
    const datePickerHeaderBackground = useShopColor('backdropColor', {l: 6});
    const popupBackground = useShopColor('backdropColor', {l: 9});
    const popupBorder = useShopColor('backdropColor', {l: 15});
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-surface) {
        background: v-bind(popupBackground);
        border-color: v-bind(popupBorder);
    }

    ::v-deep(.flux-date-picker-date) {
        &:hover {
            background: v-bind(datePickerDateHover);
        }
    }

    ::v-deep(.flux-date-picker-header) {
        background: v-bind(datePickerHeaderBackground);
        border-color: v-bind(popupBorder);
    }

    ::v-deep(.flux-date-picker-header-view) button {
        color: var(--foreground-prominent);

        &:hover {
            color: v-bind(datePickerButtonIcon);
        }
    }
</style>
