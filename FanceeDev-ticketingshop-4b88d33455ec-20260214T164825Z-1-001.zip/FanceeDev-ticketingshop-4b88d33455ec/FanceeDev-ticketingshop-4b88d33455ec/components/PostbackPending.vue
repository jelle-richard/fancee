<template>
    <FluxPaneBody is-larger-padded>
        <img
            :src="isDark ? illustrationDarkSvg : illustrationSvg"
            alt="">
    </FluxPaneBody>

    <FluxPaneBody is-larger-padded>
        <h1>{{ t('title') }}</h1>
        <p>{{ t('info') }}</p>
        <p>{{ t('close_window') }}</p>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { FluxPaneBody } from '@fancee/flux';
    import illustrationSvg from '~/assets/payment-pending.svg';
    import illustrationDarkSvg from '~/assets/payment-pending-dark.svg';

    const {t} = useI18n();
    const pane = useShopColor('backdropColor');

    const isDark = computed(() => hexToHSL(unref(pane)!)[2] < 50);
</script>

<i18n lang="yaml">
en:
    title: "Processing..."
    info: "It appears that our payment provider is currently processing your payment, and this shouldn't take much longer. We'll send you an email notification as soon as the payment has been successfully processed."
    close_window: "Feel free to navigate away from this page."

nl:
    title: "Verwerken..."
    info: "Het lijkt erop dat onze betalingsprovider momenteel de betaling verwerkt, dit zou niet veel langer moeten duren. U ontvangt een e-mailmelding zodra de betaling succesvol is verwerkt."
    close_window: "Je kunt deze pagina verlaten."

de:
    title: "Verarbeitung..."
    info: "Es sieht so aus, als ob unser Zahlungsanbieter derzeit Ihre Zahlung verarbeitet, und dies sollte nicht mehr allzu lange dauern. Sobald die Zahlung erfolgreich bearbeitet wurde, senden wir Ihnen eine E-Mail-Benachrichtigung."
    close_window: "Sie können diese Seite ohne Bedenken verlassen."

fr:
    title: "Traitement en cours..."
    info: "Il semble que notre fournisseur de paiement traite actuellement votre paiement, et cela ne devrait pas prendre beaucoup plus de temps. Dès que le paiement sera traité avec succès, nous vous enverrons une notification par e-mail."
    close_window: "N'hésitez pas à quitter cette page."
</i18n>
