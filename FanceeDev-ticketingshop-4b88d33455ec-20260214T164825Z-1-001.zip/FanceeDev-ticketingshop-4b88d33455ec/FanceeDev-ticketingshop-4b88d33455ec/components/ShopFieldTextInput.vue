<template>
    <ShopField
        :is-single-field="isSingleField"
        :is-optional="!requirement.required"
        :label="label"
        :validation-rules="validationRules"
        :value="localValue">
        <FluxFormInput
            v-model="localValue"
            :auto-complete="autoComplete"
            :auto-focus="autoFocus"
            :placeholder="placeholder"
            :type="type"/>

        <slot/>
    </ShopField>
</template>

<script
    lang="ts"
    setup>
    import type { ShopFieldRequirement } from '@fancee/data';
    import { FluxFormInput } from '@fancee/flux';
    import type { ValidationRuleCollection } from '@vuelidate/core';

    export interface Emits {
        (e: 'update:modelValue', value: string): void;
    }

    export interface Props {
        readonly autoComplete?: string;
        readonly autoFocus?: boolean;
        readonly isSingleField?: boolean;
        readonly label: string;
        readonly modelValue: string;
        readonly placeholder: string;
        readonly requirement: ShopFieldRequirement;
        readonly type?: 'color' | 'date' | 'datetime-local' | 'email' | 'file' | 'month' | 'number' | 'password' | 'search' | 'tel' | 'text' | 'time' | 'url' | 'week';
        readonly validationRules?: ValidationRuleCollection;
    }

    const emit = defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        type: 'text'
    });
    const {modelValue} = toRefs(props);

    const localValue = ref('');

    watch(modelValue, modelValue => localValue.value = modelValue, {immediate: true});
    watch(localValue, localValue => emit('update:modelValue', localValue));
</script>
