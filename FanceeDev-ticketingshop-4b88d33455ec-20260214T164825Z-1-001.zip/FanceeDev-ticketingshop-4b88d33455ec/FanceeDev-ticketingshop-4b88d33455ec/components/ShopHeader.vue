<template>
    <header class="header">
        <FluxTooltip :content="t('powered_by')">
            <a
                class="header-logo"
                href="https://wearefancee.com"
                aria-label="Powered by WeAreFancee"
                rel="noopener nofollow"
                target="_blank"/>
        </FluxTooltip>

        <FluxSpacer/>

        <LanguageSwitcher/>
    </header>
</template>

<script
    setup
    lang="ts">
    import { truncateText } from '@fancee/data';
    import { FluxSpacer, FluxTooltip } from '@fancee/flux';

    const {t} = useI18n();
    const shopRef = useShopInjection();

    const buttonBackground = useShopColor('backgroundColor', {l: 3});
    const buttonBackgroundActive = useShopColor('backgroundColor', {l: 9});
    const buttonBackgroundHover = useShopColor('backgroundColor', {l: 6});
    const buttonBorder = useShopColor('backgroundColor', {l: 12});
    const buttonForeground = useShopColor('backgroundColor', {l: 40});
    const buttonIcon = useShopColor('backgroundColor', {l: 50});

    const logoColor = useShopColor('backgroundColor', {s: 15, l: 15});
    const logoColorHover = useShopColor('backgroundColor', {s: 15, l: 24});

    useSeoMeta({
        description: () => truncateText(stripTags(unref(shopRef).event.description), 50),
        ogDescription: () => truncateText(stripTags(unref(shopRef).event.description), 50),
        ogImage: () => unref(shopRef).design.headerMedia[0]?.url,
        ogTitle: () => unref(shopRef).event.name,
        twitterTitle: () => unref(shopRef).event.name,
        twitterDescription: () => truncateText(stripTags(unref(shopRef).event.description), 50),
        twitterImage: () => unref(shopRef).design.headerMedia[0]?.url,
        twitterCard: () => 'summary'
    });

    useServerSeoMeta({
        description: () => truncateText(stripTags(unref(shopRef).event.description), 50),
        publisher: () => unref(shopRef).event.organization
    });
</script>

<style
    lang="scss"
    scoped>
    .header {
        display: flex;
        height: 84px;
        padding-left: 21px;
        padding-right: 21px;
        align-items: center;

        &-logo {
            display: block;
            height: 18px;
            width: 115px;
            outline: 0;
            background: v-bind(logoColor);
            mask: url(~/assets/wearefancee.svg) no-repeat center center / cover;
            transition: background 150ms var(--swift-out);

            &:hover {
                background: v-bind(logoColorHover);
            }
        }

        @media (min-width: 1200px) {
            position: sticky;
            top: 0;
        }
    }

    ::v-deep(.flux-secondary-button) {
        --button-background: v-bind(buttonBackground);
        --button-background-active: v-bind(buttonBackgroundActive);
        --button-background-hover: v-bind(buttonBackgroundHover);
        --button-foreground: v-bind(buttonForeground);
        --button-icon: v-bind(buttonIcon);
        --button-stroke: v-bind(buttonBorder);
    }
</style>

<i18n lang="yaml">
en:
    powered_by: "Ticket sale powered by WeAreFancee Ticketing."

nl:
    powered_by: "Ticketverkoop mogelijk gemaakt door WeAreFancee Ticketing."

de:
    powered_by: "Ticketverkauf ermöglicht durch WeAreFancee Ticketing."

fr:
    powered_by: "Vente de billets alimentée par WeAreFancee Ticketing."
</i18n>
