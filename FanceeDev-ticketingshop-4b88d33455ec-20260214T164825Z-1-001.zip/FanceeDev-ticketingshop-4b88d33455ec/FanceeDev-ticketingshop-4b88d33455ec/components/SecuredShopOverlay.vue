<template>
    <FluxOverlay>
        <FluxPane
            v-if="shouldAskSecureCode"
            :class="$style.pane"
            :style="{
                '--foreground': paneForeground,
                '--foreground-prominent': paneForegroundProminent,
                '--foreground-secondary': paneForegroundSecondary,
                backgroundColor: paneBackground,
                borderColor: paneBorder
            }">
            <FluxPaneBody
                is-larger-padded
                :class="$style.icon">
                <FluxIcon
                    :size="30"
                    variant="lock"/>
            </FluxPaneBody>

            <FluxPaneBody is-larger-padded>
                <h2>{{ t('secured_shop_title') }}</h2>
                <p>{{ t('secured_shop_explanation') }}</p>
            </FluxPaneBody>

            <FluxPaneBody is-larger-padded>
                <FluxFormColumn>
                    <FluxNotice
                        v-if="isInvalid"
                        icon="circle-exclamation"
                        is-small
                        :message="t('secured_shop_invalid')"
                        variant="danger"/>

                    <FluxFormField :label="t('secured_shop_code')">
                        <FluxFormInput
                            v-model="state.code"
                            :style="{
                                backgroundColor: inputBackground,
                                borderColor: inputBorder
                            }"
                            @keyup.enter="submit()"/>
                    </FluxFormField>

                    <FluxPrimaryButton
                        :disabled="invalid"
                        icon-before="circle-check"
                        :is-loading="isLoading"
                        :label="t('secured_shop_submit')"
                        :style="{
                            '--button-background': buttonBackground,
                            '--button-background-active': buttonBackgroundActive,
                            '--button-background-hover': buttonBackgroundHover,
                            '--button-stroke': buttonBackgroundActive
                        }"
                        @click="submit()"/>
                </FluxFormColumn>
            </FluxPaneBody>
        </FluxPane>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { SecureCodeService } from '@fancee/api';
    import { FluxFormColumn, FluxFormField, FluxFormInput, FluxIcon, FluxNotice, FluxOverlay, FluxPane, FluxPaneBody, FluxPrimaryButton } from '@fancee/flux';

    const {t} = useI18n();
    const {isApplicable} = useService(SecureCodeService);
    const secureShopStore = useSecureShop();
    const {shouldAskSecureCode} = storeToRefs(secureShopStore);
    const shopCodeRef = useShopCodeInjection();

    const isInvalid = ref(false);
    const isLoading = ref(false);
    const state = reactive({
        code: ''
    });

    const invalid = computed(() => state.code.trim() === '');

    async function submit(): Promise<void> {
        if (unref(invalid)) {
            return;
        }

        isInvalid.value = false;
        isLoading.value = true;

        try {
            await isApplicable(unref(shopCodeRef), state.code);
            secureShopStore.setSecureCode(state.code);
        } catch (_) {
            isInvalid.value = true;
        }

        isLoading.value = false;
    }

    const paneBackground = useShopColor('backdropColor');
    const paneBorder = useShopColor('backdropColor', {l: 9});
    const paneForeground = useShopColor('textColor');
    const paneForegroundProminent = useShopColor('textColor', {l: -15});
    const paneForegroundSecondary = useShopColor('textColor', {l: -6});
    const buttonBackground = useShopColor('primaryColor');
    const buttonBackgroundActive = useShopColor('primaryColor', {l: 6});
    const buttonBackgroundHover = useShopColor('primaryColor', {l: 3});
    const inputBackground = useShopColor('backdropColor', {l: 9});
    const inputBorder = useShopColor('backdropColor', {l: 15});
</script>

<style
    lang="scss"
    module>
    .pane {
        color: var(--foreground);
        text-align: center;
    }

    .icon {
        align-items: center;
        color: var(--foreground-secondary);
    }
</style>

<i18n lang="yaml">
en:
    secured_shop_title: "This shop is secured"
    secured_shop_explanation: "Please enter the code that you've received to access this shop."
    secured_shop_code: "Code"
    secured_shop_submit: "Submit"
    secured_shop_invalid: "The given code is invalid."

nl:
    secured_shop_title: "Deze winkel is beveiligd"
    secured_shop_explanation: "Voer de code in die je hebt ontvangen om toegang te krijgen tot deze winkel."
    secured_shop_code: "Code"
    secured_shop_submit: "Verzenden"
    secured_shop_invalid: "De opgegeven code is ongeldig."

de:
    secured_shop_title: "Dieser Shop ist gesichert"
    secured_shop_explanation: "Bitte geben Sie den Code ein, den Sie erhalten haben, um auf diesen Shop zuzugreifen."
    secured_shop_code: "Code"
    secured_shop_submit: "Absenden"
    secured_shop_invalid: "Der angegebene Code ist ungültig."

fr:
    secured_shop_title: "Cette boutique est sécurisée"
    secured_shop_explanation: "Veuillez entrer le code que vous avez reçu pour accéder à cette boutique."
    secured_shop_code: "Code"
    secured_shop_submit: "Soumettre"
    secured_shop_invalid: "Le code fourni est invalide."
</i18n>
