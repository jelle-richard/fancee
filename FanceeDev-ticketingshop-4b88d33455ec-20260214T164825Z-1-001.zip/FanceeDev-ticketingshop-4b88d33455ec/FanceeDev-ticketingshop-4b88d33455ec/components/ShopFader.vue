<template>
    <FluxPaneBody v-if="shopRef.design.headerMedia.length > 0">
        <FluxFader class="fader">
            <FluxFaderItem v-for="media of shopRef.design.headerMedia">
                <FluxFocalPointImage
                    :focal-point="media.focalPoint"
                    :src="media.url"
                    alt=""/>
            </FluxFaderItem>
        </FluxFader>
    </FluxPaneBody>
</template>

<script
    setup
    lang="ts">
    import { FluxFader, FluxFaderItem, FluxFocalPointImage, FluxPaneBody } from '@fancee/flux';

    const shopRef = useShopInjection();
</script>

<style
    lang="scss"
    scoped>
    .fader {
        aspect-ratio: 21 / 9;

        @media (max-width: 900px) {
            margin-top: -9px;
            margin-left: -9px;
            margin-right: -9px;
        }
    }
</style>
