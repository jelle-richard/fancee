<template>
    <FluxSecondaryButton
        class="external-link"
        icon-before="arrow-up-right-from-square"
        :href="element.link"
        :label="element.name"
        rel="noopener"
        target="_blank"
        type="link"/>
</template>

<script
    lang="ts"
    setup>
    import type { ShopElementExternalLink } from '@fancee/data';
    import { FluxSecondaryButton } from '@fancee/flux';

    export interface Props {
        readonly element: ShopElementExternalLink;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .external-link {
        margin-left: var(--shop-gutter);
        margin-right: var(--shop-gutter);
        align-self: start;
    }
</style>
