<template>
    <div :class="$style.seatingMap">
        <SeatsioSeatingChart
            :key="locale"
            :class="$style.seatingMapChart"
            :workspaceKey="seatsIoWorkspaceKey"
            :event="shopRef.event.seatsIoEventId"
            :language="locale"
            :maxSelectedObjects="seatedProductsRef.map(sp => ({
                category: sp.seatsIoCategoryId,
                quantity: sp.reservableQuantity
            }))"
            :objectTooltip="{
                showActionHint: false
            }"
            :priceFormatter="formatPrice"
            :pricing="seatedProductsRef.map(sp => ({
                category: sp.seatsIoCategoryId,
                price: sp.priceCents + sp.feeCents
            }))"
            session="continue"
            :showFullScreenButton="false"
            :showLegend="true"
            :showSeatLabels="true"
            :tooltipInfo="generateTooltipInfo"
            mode="normal"
            region="eu"
            @objectDeselected="onObjectDeselected"
            @objectSelected="onObjectSelected"
            @renderStarted="onRenderStarted"/>
    </div>
</template>

<script
    lang="ts"
    setup>
    import type { SeatedProduct } from '@fancee/data';
    import type { SeatsioChartInstance } from '@seatsio/seatsio-vue';
    import { SeatsioSeatingChart } from '@seatsio/seatsio-vue';
    import type { BookableObjectProps, SelectableObjectProps } from '@seatsio/seatsio-types';

    const {locale} = useI18n();
    const {public: {seatsIoWorkspaceKey}} = useRuntimeConfig();
    const cartStore = useCartStore();
    const currencyRef = useCurrency();
    const seatedProductsRef = useSeatedProducts();
    const shopRef = useShopInjection();
    const shopCodeRef = useShopCodeInjection();

    const chart = ref<SeatsioChartInstance | null>(null);

    function formatPrice(cents: number): string {
        return formatCentsToMoney(cents, unref(currencyRef));
    }

    function getProductBySeatsioCategory(categeory: string | number): SeatedProduct | null {
        return unref(seatedProductsRef).find(sp => sp.seatsIoCategoryId === categeory.toString()) ?? null;
    }

    function generateTooltipInfo(object: BookableObjectProps): string {
        if (!object.category) {
            return '';
        }

        const product = getProductBySeatsioCategory(object.category?.key);

        return product?.description ?? '';
    }

    function onObjectDeselected(object: BookableObjectProps): void {
        if (!object.category) {
            return;
        }

        const product = getProductBySeatsioCategory(object.category.key);

        if (!product) {
            return;
        }

        cartStore.removeSeat(unref(shopCodeRef), product.productId, object.label);
    }

    function onObjectSelected(object: SelectableObjectProps): void {
        if (!object.category) {
            return;
        }

        const product = getProductBySeatsioCategory(object.category.key);

        if (!product) {
            return;
        }

        cartStore.addSeat(unref(shopCodeRef), product.productId, object.label);
    }

    function onRenderStarted(instance: SeatsioChartInstance): void {
        chart.value = instance;
    }
</script>

<style
    lang="scss"
    module>
    .seatingMap {
        position: relative;
        margin-left: -21px;
        margin-right: -21px;
        aspect-ratio: 5 / 4;
        border-top: 1px solid var(--border);
        border-bottom: 1px solid var(--border);
    }

    .seatingMapChart {
        position: absolute;
        inset: 0;
    }
</style>
