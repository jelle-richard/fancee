<template>
    <FluxPaneBody is-larger-padded>
        <img
            :src="isDark ? illustrationDarkSvg : illustrationSvg"
            alt="">
    </FluxPaneBody>

    <FluxPaneBody is-larger-padded>
        <h1>{{ t('title') }}</h1>
        <p>{{ t('info') }}</p>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { FluxPaneBody } from '@fancee/flux';
    import illustrationSvg from '~/assets/payment-canceled.svg';
    import illustrationDarkSvg from '~/assets/payment-canceled-dark.svg';

    const {t} = useI18n();
    const pane = useShopColor('backdropColor');

    const isDark = computed(() => hexToHSL(unref(pane)!)[2] < 50);
</script>

<i18n lang="yaml">
en:
    title: "Canceled"
    info: "You've canceled your order. If you'd like to create a new one, simply click the button below."

nl:
    title: "Geannuleerd"
    info: "Je hebt je bestelling geannuleerd. Als je een nieuwe wilt plaatsen, klik dan op de knop hieronder."

de:
    title: "Abgebrochen"
    info: "Du hast deine Bestellung abgebrochen. Wenn du eine neue erstellen möchtest, klicke einfach auf die Schaltfläche unten."

fr:
    title: "Annulé"
    info: "Vous avez annulé votre commande. Si vous souhaitez en créer une nouvelle, il vous suffit de cliquer sur le bouton ci-dessous"
</i18n>
