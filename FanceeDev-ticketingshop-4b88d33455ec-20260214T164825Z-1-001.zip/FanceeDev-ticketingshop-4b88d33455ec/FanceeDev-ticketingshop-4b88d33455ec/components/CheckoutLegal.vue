<template>
    <CheckoutBox
        :span="2"
        :title="t('legal')">
        <CheckoutToggles>
            <CheckoutToggle
                is-mandatory
                :title="t('terms_and_conditions')"
                :more-info-url="termsAndConditionsPdf"
                :model-value="termsAndConditionsAccepted"
                @update:model-value="value => $emit('update:termsAndConditionsAccepted', value)"/>
        </CheckoutToggles>
    </CheckoutBox>
</template>

<script
    lang="ts"
    setup>
    import termsAndConditionsPdf from '~/assets/documents/en/TermsAndConditions.pdf?url';

    export interface Emits {
        (e: 'update:termsAndConditionsAccepted', value: boolean): void;
    }

    export interface Props {
        readonly termsAndConditionsAccepted: boolean;
    }

    defineEmits<Emits>();
    defineProps<Props>();

    const {t} = useI18n();
</script>

<i18n lang="yaml">
en:
    legal: "Legal"
    terms_and_conditions: "Terms & Conditions"

nl:
    legal: "Legaal"
    terms_and_conditions: "Algemene voorwaarden"

de:
    legal: "Rechtlich"
    terms_and_conditions: "Allgemeine Geschäftsbedingungen"

fr:
    legal: "Légal"
    terms_and_conditions: "Conditions Générales"
</i18n>
