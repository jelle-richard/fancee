<template>
    <div class="pane-footer-row">
        <slot/>
    </div>
</template>

<script
    lang="ts"
    setup>
    const border = useShopColor('backdropColor', {l: 6});
</script>

<style
    lang="scss"
    scoped>
    .pane-footer-row {
        display: flex;
        padding: 21px;
        align-items: center;
        background: inherit;

        &:first-child {
            margin-top: -1px;
            border-top: 1px solid v-bind(border);
        }

        &:not(:first-child) {
            padding-top: 0;
        }

        ::v-deep(.flux-notice) {
            flex-grow: 1;
        }

        @media (max-width: 720px) {
            align-items: stretch;
            flex-flow: column;
        }
    }
</style>
