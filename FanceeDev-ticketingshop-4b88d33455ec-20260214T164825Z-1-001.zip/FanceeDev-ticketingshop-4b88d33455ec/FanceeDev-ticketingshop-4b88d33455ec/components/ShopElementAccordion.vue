<template>
    <FluxExpandable
        class="accordion"
        :is-opened="element.opened">
        <template #header="{isOpen, toggle}">
            <button
                class="accordion-header"
                @click="toggle">
                <span class="accordion-icon">
                    <FluxIcon
                        :size="24"
                        :variant="element.icon as IconNames"/>
                </span>

                <span class="accordion-title">
                    {{ element.title }}
                </span>

                <span class="accordion-state">
                    <FluxIcon :variant="isOpen ? 'angle-down' : 'angle-right'"/>
                </span>
            </button>
        </template>

        <template #body>
            <ShopElements
                class="accordion-body"
                :elements="element.elements"/>
        </template>
    </FluxExpandable>
</template>

<script
    lang="ts"
    setup>
    import type { ShopElementAccordion } from '@fancee/data';
    import { FluxExpandable, FluxIcon, type IconNames } from '@fancee/flux';

    export interface Props {
        readonly element: ShopElementAccordion;
    }

    defineProps<Props>();

    const background = useShopColor('backdropColor', {l: 2});
    const backgroundHover = useShopColor('backdropColor', {l: 4});
    const border = useShopColor('backdropColor', {l: 6});
    const iconBackground = useShopColor('primaryColor');
    const iconForeground = useShopColor('primaryColor', {l: -90});
</script>

<style
    lang="scss"
    scoped>
    .accordion {
        position: relative;
        background: v-bind(background);
        border: 1px solid v-bind(border);
        border-radius: var(--radius);
        overflow: hidden;
        transition: 300ms var(--swift-out);
        transition-property: margin, background, border, border-radius;

        &-body {
            padding: 21px 18px 18px 42px;

            ::v-deep(.text-block):last-child {
                margin-bottom: 15px;
            }
        }

        &-header {
            position: relative;
            display: flex;
            padding: 15px;
            align-items: center;
            gap: 21px;
            background: transparent;
            border: 0;
            color: var(--foreground-prominent);
            cursor: pointer;
            font-weight: 700;
            outline: 0;
            text-align: left;
            transition: background 150ms var(--swift-out), padding 300ms var(--swift-out);

            &:hover {
                background: v-bind(backgroundHover);
            }
        }

        &-title {
            flex-grow: 1;
        }

        &-icon,
        &-state {
            display: flex;
            height: 42px;
            width: 42px;
            align-items: center;
            justify-content: center;
        }

        &-icon {
            background: v-bind(iconBackground);
            border-radius: var(--radius);
            color: v-bind(iconForeground);
        }

        &-state {
            color: v-bind(iconBackground);
        }

        &.is-open {
            margin-left: -22px;
            margin-right: -22px;
            background: transparent;
            border-left-color: transparent;
            border-right-color: transparent;
            border-radius: 0;
        }

        &.is-open &-header {
            padding: 21px;
        }
    }

    .accordion:not(.is-open) + .accordion:not(.is-open) {
        margin-top: -16px;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
    }

    .accordion:has(+ .accordion:not(.is-open)) {
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
    }

    .text-block + .accordion {
        margin-top: 21px;
    }
</style>
