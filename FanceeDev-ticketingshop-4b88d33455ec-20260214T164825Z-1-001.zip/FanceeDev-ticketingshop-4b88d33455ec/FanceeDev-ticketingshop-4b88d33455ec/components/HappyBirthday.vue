<template>
    <section class="happy-birthday">
        <canvas ref="canvasRef"/>

        <img
            class="happy-birthday-illustration"
            :src="happyBirthdaySvg"
            :alt="t('alt')"/>

        <div class="happy-birthday-content">
            <h3>{{ t('title') }}</h3>
            <p>{{ randomMessage }}</p>
        </div>
    </section>
</template>

<script
    lang="ts"
    setup>
    import { ConfettiCannon } from '~/utils/confetti';
    import happyBirthdaySvg from '~/assets/happy-birthday.svg';

    const {t} = useI18n();

    const canvasRef = ref<HTMLCanvasElement>();
    const cannonRef = ref<ConfettiCannon>();

    const randomMessage = computed(() => t(`message.${Math.floor(Math.random() * 4)}`));

    onMounted(() => {
        cannonRef.value = markRaw(new ConfettiCannon(unref(canvasRef)!, {}));
        requestAnimationFrame(biem);
    });

    async function biem(): Promise<void> {
        if (!cannonRef.value) {
            return;
        }

        await wait(250);
        cannonRef.value?.fire();
        cannonRef.value?.fire({
            spread: 90,
            angle: 270,
            xRandom: true,
            y: -2,
            decay: 0.9,
            startVelocity: 15
        });

        await wait(500);
        cannonRef.value?.fire({x: .25});
        cannonRef.value?.fire({x: .75});

        await wait(1000);
        requestAnimationFrame(biem);
    }

    async function wait(ms: number): Promise<void> {
        await new Promise(resolve => setTimeout(() => requestAnimationFrame(resolve), ms));
    }

    const background = useShopColor('backdropColor', {l: 3});
</script>

<style
    lang="scss"
    scoped>
    .happy-birthday {
        position: relative;
        display: flex;
        padding: 24px;
        align-items: flex-start;
        gap: 21px;
        grid-column: 1 / span 2;
        order: 1;
        background: v-bind(background);
        border-radius: var(--radius);

        &-content {
            display: flex;
            align-self: center;
            flex-flow: column;
            gap: 3px;

            h3,
            p {
                margin: 0;
            }

            h3 {
                font-size: 16px;
            }

            p {
                font-size: 15px;
            }
        }

        &-illustration {
            height: 54px;
            width: 54px;
        }

        canvas {
            position: absolute;
            inset: 0;
            height: 100%;
            width: 100%;
        }
    }
</style>

<i18n lang="yaml">
en:
    alt: "Illustration: Happy birthday"
    title: "Happy birthday!"
    message:
        - "🎈🎂🎉 Let's make this day unforgettable! Have an incredible birthday celebration! 🎉🎂🎈"
        - "🎉 Sending you virtual hugs, good vibes, and best wishes on your birthday! 🎉"
        - "🥳 Happy birthday to an amazing person. Cheers to another year of accomplishments and beautiful moments! 🥳"
        - "🎁 Here's to a year filled with exciting adventures and dreams come true. Happy birthday, dear friend! 🎁"

nl:
    alt: "Illustratie: Fijne verjaardag"
    title: "Fijne verjaardag!"
    message:
        - "🎈🎂🎉 Laten we deze dag onvergetelijk maken! Geniet van een geweldig verjaardagsfeest! 🎉🎂🎈"
        - "🎉 Stuur je virtuele knuffels, goede vibes en de beste wensen op je verjaardag! 🎉"
        - "🥳 Gelukkige verjaardag voor een geweldig persoon. Proost op weer een jaar vol prestaties en mooie momenten! 🥳"
        - "🎁 Hier is een jaar vol spannende avonturen en dromen die uitkomen. Gelukkige verjaardag, lieve vriend(in)! 🎁"

de:
    alt: "Illustration: Herzlichen Glückwunsch zum Geburtstag"
    title: "Herzlichen Glückwunsch zum Geburtstag!"
    message:
        - "🎈🎂🎉 Lass uns diesen Tag unvergesslich machen! Hab eine unglaubliche Geburtstagsfeier! 🎉🎂🎈"
        - "🎉 Wir schicken dir virtuelle Umarmungen, gute Vibes und die besten Wünsche zu deinem Geburtstag! 🎉"
        - "🥳 Herzlichen Glückwunsch an eine erstaunliche Person. Auf ein weiteres Jahr voller Erfolge und schöner Momente! 🥳"
        - "🎁 Auf ein Jahr voller aufregender Abenteuer und Träume, die wahr werden. Alles Gute zum Geburtstag, lieber Freund! 🎁"

fr:
    alt: "Illustration : Joyeux anniversaire"
    title: "Joyeux anniversaire !"
    message:
        - "🎈🎂🎉 Faisons de cette journée un moment inoubliable ! Passe une incroyable fête d'anniversaire ! 🎉🎂🎈"
        - "🎉 Nous t'envoyons des câlins virtuels, des bonnes ondes et nos meilleurs vœux pour ton anniversaire ! 🎉"
        - "🥳 Joyeux anniversaire à une personne incroyable. À une nouvelle année pleine de réussites et de beaux moments ! 🥳"
        - "🎁 Que cette année soit remplie d'aventures passionnantes et de rêves qui se réalisent. Joyeux anniversaire, cher ami ! 🎁"
</i18n>
