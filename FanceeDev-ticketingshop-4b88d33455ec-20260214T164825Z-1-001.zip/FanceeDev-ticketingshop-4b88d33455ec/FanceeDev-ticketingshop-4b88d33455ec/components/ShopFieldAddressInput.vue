<template>
    <ShopField
        :is-single-field="isSingleField"
        :is-optional="!requirement.required"
        :label="label"
        :validation-rules="validationRules"
        :value="modelValue.formatted">
        <GooglePlacesAutocomplete
            v-if="appStore.isGoogleMapsReady"
            :auto-complete="autoComplete"
            :auto-focus="autoFocus"
            :value="modelValue.formatted"
            @address-changed="onAddressChanged"/>

        <FluxNotice
            v-else
            icon="circle-exclamation"
            :message="t('loading_failed')"
            variant="warning"/>

        <slot/>
    </ShopField>
</template>

<script
    lang="ts"
    setup>
    import { Address, type ShopFieldRequirement } from '@fancee/data';
    import { FluxNotice } from '@fancee/flux';
    import type { ValidationRuleCollection } from '@vuelidate/core';

    export interface Emits {
        (e: 'update:modelValue', value: Address): void;
    }

    export interface Props {
        readonly autoComplete?: string;
        readonly autoFocus?: boolean;
        readonly isSingleField?: boolean;
        readonly label: string;
        readonly modelValue: Address;
        readonly placeholder: string;
        readonly requirement: ShopFieldRequirement;
        readonly validationRules?: ValidationRuleCollection;
    }

    const emit = defineEmits<Emits>();
    defineProps<Props>();

    const appStore = useAppStore();
    const {t} = useI18n();

    function onAddressChanged(address: Address): void {
        emit('update:modelValue', address);
    }
</script>

<i18n lang="yaml">
en:
    loading_failed: "Uh-oh! The address field didn't load properly. WeAreFancee uses a Google service here, please check if it's blocked by an ad blocker."

nl:
    loading_failed: "Uh-oh! Het adresveld is niet goed geladen. WeAreFancee gebruikt hier een Google-service, controleer of deze geblokkeerd is door een adblocker."

de:
    loading_failed: "Uh-oh! Das Adressfeld wurde nicht richtig geladen. WeAreFancee verwendet hier einen Google-Dienst. Bitte überprüfen Sie, ob er von einem Werbeblocker blockiert wird."

fr:
    loading_failed: "Uh-oh! Le champ d'adresse n'a pas été chargé correctement. WeAreFancee utilise un service Google ici, veuillez vérifier s'il est bloqué par un bloqueur de publicités."
</i18n>
