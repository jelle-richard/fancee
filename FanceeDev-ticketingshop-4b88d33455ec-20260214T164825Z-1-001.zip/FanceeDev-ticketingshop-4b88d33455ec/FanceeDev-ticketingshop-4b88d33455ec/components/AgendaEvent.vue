<template>
    <div :class="$style.event">
        <AgendaEventImage :event="event"/>

        <AgendaEventInfo :event="event"/>

        <AgendaEventDates :event="event"/>
    </div>
</template>

<script
    setup
    lang="ts">
    import { AgendaOverviewLinkedEvent } from '@fancee/data';

    export interface Props {
        readonly event: AgendaOverviewLinkedEvent;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    .event {
        background: var(--backdrop-color-secondary);
        border: 1px solid var(--backdrop-border);
        margin: 15px 0;
        padding: 15px;
        gap: 30px;
        border-radius: var(--radius);
        display: grid;
        grid-template-columns: auto 1fr auto;
    }

    .event:hover {
        background: var(--backdrop-hover);
        cursor: pointer;
    }

    @media (max-width: 900px) {
        .event {
            grid-template-columns: auto 1fr;
        }
    }
</style>
