<template>
    <FluxFormField
        class="shop-field"
        :class="{'is-single-field': isSingleField}"
        :current-length="currentLength"
        :error="error"
        :hint="hint"
        :is-optional="isOptional"
        :label="label"
        :max-length="maxLength">
        <slot/>
    </FluxFormField>
</template>

<script
    lang="ts"
    setup>
    import { FluxFormField } from '@fancee/flux';
    import { useVuelidate, type ValidationRuleCollection } from '@vuelidate/core';

    export interface Props {
        readonly currentLength?: number;
        readonly hint?: string;
        readonly isOptional?: boolean;
        readonly isSingleField?: boolean;
        readonly label: string;
        readonly maxLength?: number;
        readonly validationRules?: ValidationRuleCollection;
        readonly value?: any;
    }

    const props = withDefaults(defineProps<Props>(), {
        validationRules: () => ({}),
        value: null
    });
    const {validationRules, value} = toRefs(props);

    const v$ = useVuelidate(
        {localValue: validationRules},
        {localValue: value}
    );

    const error = computed(() => {
        if (Object.entries(unref(validationRules)).length === 0) {
            return undefined;
        }

        const localValue = unref(v$).localValue;

        if (!localValue.$error) {
            return undefined;
        }

        return localValue.$errors.map(e => e.$message).join(' ');
    });

    const fieldBackground = useShopColor('backdropColor', {l: 3});
    const inputBackground = useShopColor('backdropColor');
    const inputBorder = useShopColor('backdropColor', {l: 12});
</script>

<style
    lang="scss"
    scoped>
    .shop-field {
        padding: 9px 15px 15px;
        background: v-bind(fieldBackground);
        border-radius: var(--radius);

        ::v-deep(.flux-form-input) {
            background: v-bind(inputBackground);
            border-color: v-bind(inputBorder);
        }
    }
</style>
