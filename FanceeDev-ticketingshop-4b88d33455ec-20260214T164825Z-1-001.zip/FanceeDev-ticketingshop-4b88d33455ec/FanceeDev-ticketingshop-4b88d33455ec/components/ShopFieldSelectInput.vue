<template>
    <ShopField
        :is-single-field="isSingleField"
        :is-optional="!requirement.required"
        :label="label"
        :validation-rules="validationRules"
        :value="modelValue">
        <FluxFormSelect
            v-model="localValue"
            :options="options"
            :placeholder="placeholder"/>

        <slot/>
    </ShopField>
</template>

<script
    lang="ts"
    setup>
    import type { ShopFieldRequirement } from '@fancee/data';
    import { FluxFormSelect, type FluxFormSelectOption } from '@fancee/flux';
    import type { ValidationRuleCollection } from '@vuelidate/core';

    export interface Emits {
        (e: 'update:modelValue', value: string | null): void;
    }

    export interface Props {
        readonly isSingleField?: boolean;
        readonly label: string;
        readonly modelValue: string | null;
        readonly options: FluxFormSelectOption[];
        readonly placeholder: string;
        readonly requirement: ShopFieldRequirement;
        readonly validationRules?: ValidationRuleCollection;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {modelValue} = toRefs(props);

    const localValue = ref<string | null>('');

    watch(modelValue, modelValue => localValue.value = modelValue, {immediate: true});
    watch(localValue, localValue => emit('update:modelValue', localValue));

    const menuItemHoverBackground = useShopColor('backdropColor', {l: 12});
    const popupBackground = useShopColor('backdropColor', {l: 9});
    const popupBorder = useShopColor('backdropColor', {l: 15});
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-form-select-popup) {
        background: v-bind(popupBackground);
        border-color: v-bind(popupBorder);
    }

    ::v-deep(.flux-form-select-selected) {
        margin: 1px;
    }

    ::v-deep(.flux-menu-item:not(.flux-form-select-selected)) {
        background: v-bind(popupBackground);
        color: var(--foreground-prominent);

        &:active,
        &:focus-visible,
        &:hover {
            background: v-bind(menuItemHoverBackground);
        }
    }
</style>
