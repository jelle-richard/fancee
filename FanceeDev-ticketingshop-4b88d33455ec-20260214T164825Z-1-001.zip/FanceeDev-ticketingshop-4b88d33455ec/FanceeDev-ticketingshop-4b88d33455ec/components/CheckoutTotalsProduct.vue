<template>
    <tr>
        <td>{{ product.quantity }}x</td>
        <td>{{ product.name }}</td>
        <td v-if="discount">
            <div class="price">
                <span class="discounted">{{ formatCentsToMoney(discount.discountCentsTotal, currencyRef, locale) }}</span>
                <span>{{ formatCentsToMoney(product.quantity * product.priceCents - discount.discountCentsTotal, currencyRef, locale) }}</span>
            </div>
        </td>
        <td v-else>
            <div class="price">
                <span>{{ formatCentsToMoney(product.quantity * product.priceCents, currencyRef, locale) }}</span>
            </div>
        </td>
    </tr>
</template>

<script
    lang="ts"
    setup>
    import { OrderCostProductDiscount } from '@fancee/data';

    export interface Props {
        readonly discount?: OrderCostProductDiscount;
        readonly product: SelectedProduct;
    }

    defineProps<Props>();

    const {locale} = useI18n();
    const currencyRef = useCurrency();

    const discountBackground = useShopColor('backdropColor', {l: 18});
    const discountForeground = useShopColor('backdropColor', {l: 60});
</script>

<style
    lang="scss"
    scoped>
    .price {
        display: flex;
        align-items: center;
        gap: 9px;
        justify-content: flex-end;
    }

    .discounted {
        margin-top: -3px;
        margin-bottom: -3px;
        padding: 3px 6px;
        background: v-bind(discountBackground);
        border-radius: calc(var(--radius) / 2);
        color: v-bind(discountForeground);
        font-size: 12px;
        font-weight: 700;

        &::before {
            content: '- ';
        }
    }
</style>
