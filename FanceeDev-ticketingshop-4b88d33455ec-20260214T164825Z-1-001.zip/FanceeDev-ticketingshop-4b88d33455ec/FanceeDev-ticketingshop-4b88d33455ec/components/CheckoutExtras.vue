<template>
    <CheckoutBox
        v-if="order && shopRef"
        :span="2"
        :title="t('extras')">
        <CheckoutToggles>
            <CheckoutToggle
                v-if="tspEligible"
                v-model="order.enabledTicketServicePlus"
                :description="t('ticket_service_plus_description', {cost: formatCentsToMoney(shopRef.platformTicketServicePlusCostCents, currencyRef, locale)})"
                :title="t('ticket_service_plus')"
                :more-info-url="ticketServicePlusPdf"/>

            <CheckoutToggle
                v-model="order.optInPromotionalEmail"
                :description="t('promotional_email_description')"
                :title="t('promotional_email')"/>
        </CheckoutToggles>
    </CheckoutBox>
</template>

<script
    lang="ts"
    setup>
    import ticketServicePlusPdf from '~/assets/documents/en/TicketServicePlus.pdf?url';

    const {locale, t} = useI18n();
    const currencyRef = useCurrency();
    const shopRef = useShopInjection();
    const cartStore = useCartStore();
    const reserveStore = useReserveStore();
    const {order} = storeToRefs(reserveStore);

    const tspEligible = computed(() => cartStore.selectedProducts.some(p => p.type === 'ticket'));
</script>

<i18n lang="yaml">
en:
    extras: "Extras"
    promotional_email: "Promotional Email"
    promotional_email_description: "Opt-in to receive promotional email."
    ticket_service_plus: "Ticket Service Plus"
    ticket_service_plus_description: "Upgrade your tickets to Service Plus tickets for {cost} per ticket."

nl:
    extras: "Extra's"
    promotional_email: "Promotionele E-mail"
    promotional_email_description: "Geef toestemming om promotionele e-mails te ontvangen."
    ticket_service_plus: "Ticket Service Plus"
    ticket_service_plus_description: "Upgrade je tickets naar Service Plus tickets voor {cost} per ticket."

de:
    extras: "Zusätze"
    promotional_email: "Werbemail"
    promotional_email_description: "Opt-In, um Werbemails zu erhalten."
    ticket_service_plus: "Ticket-Service Plus"
    ticket_service_plus_description: "Werten Sie Ihre Tickets zu Service-Plus-Tickets für {cost} pro Ticket auf."

fr:
    extras: "Extras"
    promotional_email: "E-mail promotionnel"
    promotional_email_description: "Optez pour la réception d'e-mails promotionnels."
    ticket_service_plus: "Service Plus pour les billets"
    ticket_service_plus_description: "Mettez à niveau vos billets en billets Service Plus pour {cost} par billet."
</i18n>
