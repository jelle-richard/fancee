<template>
    <FluxPane
        :is-loading="isLoading"
        :class="$style.eventBackdrop"
        :style="{
            '--primary-button-background': primaryButtonBackground,
            '--primary-button-background-active': primaryButtonBackgroundActive,
            '--primary-button-background-hover': primaryButtonBackgroundHover,
            '--primary-button-border': primaryButtonBorder,
            '--primary-button-foreground': primaryButtonForeground,
            '--primary-button-icon': primaryButtonIcon,
            '--background-color': backgroundColor,
            '--backdrop-color': backdropColor,
            '--backdrop-color-secondary': backdropColorSecondary,
            '--backdrop-color-thirdly': backdropColorThirdly,
            '--backdrop-color-fourthly': backdropColorFourthly,
            '--backdrop-border': backdropBorder,
            '--backdrop-hover': backdropHover,
            '--foreground': textColor,
            '--foreground-prominent': textColorProminent,
            '--foreground-secondary': textColorSecondary
        }">
        <slot/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { FluxPane } from '@fancee/flux';

    export interface Props {
        readonly isLoading?: boolean;
    }

    withDefaults(defineProps<Props>(), {
        isLoading: false
    });

    const primaryButtonBackground = useAgendaDesignColor('primaryColor');
    const primaryButtonBackgroundActive = useAgendaDesignColor('primaryColor', {lightness: 6});
    const primaryButtonBackgroundHover = useAgendaDesignColor('primaryColor', {lightness: 3});
    const primaryButtonBorder = useAgendaDesignColor('primaryColor', {lightness: 6});
    const primaryButtonForeground = useAgendaDesignColor('primaryColor', {lightness: -45});
    const primaryButtonIcon = useAgendaDesignColor('primaryColor', {lightness: -45});

    const backgroundColor = useAgendaDesignColor('backgroundColor');

    const backdropColor = useAgendaDesignColor('backdropColor');
    const backdropColorSecondary = useAgendaDesignColor('backdropColor', {lightness: 3});
    const backdropColorThirdly = useAgendaDesignColor('backdropColor', {lightness: 15});
    const backdropColorFourthly = useAgendaDesignColor('backdropColor', {lightness: 9});
    const backdropBorder = useAgendaDesignColor('backdropColor', {lightness: 15});
    const backdropHover = useAgendaDesignColor('backdropColor', {lightness: 6});

    const textColor = useAgendaDesignColor('textColor', {lightness: -9});
    const textColorProminent = useAgendaDesignColor('textColor');
    const textColorSecondary = useAgendaDesignColor('textColor', {lightness: 9});
</script>

<style
    lang="scss"
    module>
    .eventBackdrop {
        background: var(--backdrop-color);
        border-color: var(--backdropBorder);
        color: var(--foreground);
    }
</style>
