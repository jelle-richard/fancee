<template>
    <FluxPaneBody
        v-if="order"
        class="shop-form">
        <template
            v-for="requirement of fieldsRef"
            :key="requirement.field">
            <ShopFieldTextInput
                v-if="requirement.field === FieldType.Email"
                v-model="order.orderClient.email"
                auto-complete="off"
                auto-focus
                is-single-field
                :label="t('email.label')"
                :placeholder="t('email.placeholder')"
                :requirement="requirement"
                :validation-rules="{required, email, maxLength: maxLength(254)}"
                type="email"/>

            <ShopFieldTextInput
                v-else-if="requirement.field === FieldType.FirstName"
                v-model="order.orderClient.firstName"
                auto-complete="given-name"
                :is-single-field="!hasBothFirstAndLastnameFields"
                :label="t('first_name.label')"
                :placeholder="t('first_name.placeholder')"
                :requirement="requirement"
                :validation-rules="{required: requiredField(FieldType.FirstName), minLength: minLength(2), maxLength: maxLength(40)}"/>

            <ShopFieldTextInput
                v-else-if="requirement.field === FieldType.LastName"
                v-model="order.orderClient.lastName"
                auto-complete="family-name"
                :is-single-field="!hasBothFirstAndLastnameFields"
                :label="t('last_name.label')"
                :placeholder="t('last_name.placeholder')"
                :requirement="requirement"
                :validation-rules="{required: requiredField(FieldType.LastName), minLength: minLength(2), maxLength: maxLength(40)}"/>

            <ShopFieldTextInput
                v-else-if="requirement.field === FieldType.Phone"
                v-model="order.orderClient.phoneNumber"
                auto-complete="tel"
                is-single-field
                :label="t('phone_number.label')"
                :placeholder="t('phone_number.placeholder')"
                :requirement="requirement"
                :validation-rules="{required: requiredField(FieldType.Phone)}"/>

            <template v-else-if="requirement.field === FieldType.Birthdate">
                <ShopFieldDateInput
                    v-model="order.orderClient.birthDate"
                    auto-complete="bday"
                    :is-single-field="!hasBothBirthdateAndGenderFields"
                    :label="t('birthdate.label')"
                    :placeholder="t('birthdate.placeholder')"
                    :requirement="requirement"
                    :validation-rules="{required: requiredField(FieldType.Birthdate), notTooOld: notTooOld(), oldEnoughAt: oldEnoughAt(eventStartDate, shopRef.event.minimumAge)}"/>

                <ClientOnly v-if="isHappyBirthdayVisible">
                    <HappyBirthday/>
                </ClientOnly>
            </template>

            <ShopFieldSelectInput
                v-else-if="requirement.field === FieldType.Gender"
                v-model="order.orderClient.gender"
                :is-single-field="!hasBothBirthdateAndGenderFields"
                :label="t('gender.label')"
                :placeholder="t('gender.placeholder')"
                :options="genderOptionsRef"
                :requirement="requirement"
                :validation-rules="{required: requiredField(FieldType.Gender)}"/>

            <ShopFieldAddressInput
                v-else-if="requirement.field === FieldType.Address"
                v-model="order.orderClient.address"
                is-single-field
                :label="t('address.label')"
                :placeholder="t('address.placeholder')"
                :requirement="requirement"
                :validation-rules="{required: requiredField(FieldType.Address)}"/>

            <ShopFieldCityInput
                v-else-if="requirement.field === FieldType.City"
                v-model="order.orderClient.address"
                is-single-field
                :label="t('city.label')"
                :placeholder="t('city.placeholder')"
                :requirement="requirement"
                :validation-rules="{required: requiredField(FieldType.City)}"/>
        </template>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { Gender, ShopField as FieldType } from '@fancee/data';
    import { type FluxFormSelectOption, FluxPaneBody } from '@fancee/flux';
    import { type ValidationRuleWithoutParams } from '@vuelidate/core';
    import { DateTime } from 'luxon';

    const predeterminedOrder = [
        FieldType.Email,
        FieldType.FirstName,
        FieldType.LastName,
        FieldType.Phone,
        FieldType.Birthdate,
        FieldType.Gender,
        FieldType.Address,
        FieldType.City
    ];

    const {t} = useI18n();
    const {email, maxLength, minLength, notTooOld, oldEnoughAt, required, requiredIf} = useValidators();
    const shopRef = useShopInjection();
    const reserveStore = useReserveStore();
    const {order} = storeToRefs(reserveStore);

    const eventStartDate = computed(() => unref(shopRef).event.startDate);
    const fieldsRef = computed(() => unref(shopRef).shopFields
        .toSorted((a, b) => predeterminedOrder.indexOf(a.field) - predeterminedOrder.indexOf(b.field))
        .filter(sf => sf.enabled));

    const genderOptionsRef = computed(() => {
        const options: FluxFormSelectOption[] = [
            {id: Gender.Male, icon: 'mars', label: t('gender.options.male')},
            {id: Gender.Female, icon: 'venus', label: t('gender.options.female')},
            {id: Gender.Neutral, icon: 'genderless', label: t('gender.options.neutral')}
        ];

        const requirement = unref(fieldsRef).find(f => f.field === FieldType.Gender);

        if (!requirement?.required) {
            options.unshift({id: null as unknown as Gender, icon: 'genderless', label: t('gender.options.empty')});
        }

        return options;
    });

    const hasBothFirstAndLastnameFields = computed(() => {
        const hasFirstname = !!unref(fieldsRef).find(requirement => requirement.field === FieldType.FirstName);
        const hasLastname = !!unref(fieldsRef).find(requirement => requirement.field === FieldType.LastName);

        return hasFirstname && hasLastname;
    });

    const hasBothBirthdateAndGenderFields = computed(() => {
        const hasBirthdate = !!unref(fieldsRef).find(requirement => requirement.field === FieldType.Birthdate);
        const hasGender = !!unref(fieldsRef).find(requirement => requirement.field === FieldType.Gender);

        return hasBirthdate && hasGender;
    });

    const isHappyBirthdayVisible = computed(() => {
        const hasBirthdate = !!unref(fieldsRef).find(requirement => requirement.field === FieldType.Birthdate);
        const client = unref(order)?.orderClient;

        if (!hasBirthdate || !client || !client.birthDate) {
            return false;
        }

        const now = DateTime.now();
        const birthDate = client.birthDate;

        return now.month === birthDate.month && now.day === birthDate.day;
    });

    function requiredField(fieldType: FieldType): ValidationRuleWithoutParams {
        return requiredIf(unref(fieldsRef).find(f => f.field === fieldType)?.required === true);
    }
</script>

<style
    lang="scss"
    scoped>
    .shop-form {
        position: relative;
        display: grid;
        gap: 9px;
        grid-template-columns: repeat(2, 1fr);

        ::v-deep(.is-single-field) {
            grid-column: auto / span 2;
        }

        @media (max-width: 720px) {
            grid-template-columns: 1fr;

            ::v-deep(.is-single-field) {
                grid-column: 1;
            }
        }
    }
</style>

<i18n lang="yaml">
en:
    email:
        label: "Email"
        placeholder: "E.g. john.doe{'@'}icloud.com"
    first_name:
        label: "First name"
        placeholder: "E.g. John"
    last_name:
        label: "Last name"
        placeholder: "E.g. Doe"
    phone_number:
        label: "Phone number"
        placeholder: "E.g. +1 (123) 456-7890"
    birthdate:
        label: "Birthdate"
        placeholder: "E.g. March 13, 1996"
    gender:
        label: "Gender"
        placeholder: "Select your Gender"
        options:
            empty: "Prefer not to say"
            male: "Male"
            female: "Female"
            neutral: "Neutral"
    address:
        label: "Address"
        placeholder: "Search for your address..."
    city:
        label: "City"
        placeholder: "Search for your city..."

nl:
    email:
        label: "E-mail"
        placeholder: "Bijv. jan.jansen{'@'}icloud.com"
    first_name:
        label: "Voornaam"
        placeholder: "Bijv. Jan"
    last_name:
        label: "Achternaam"
        placeholder: "Bijv. Jansen"
    phone_number:
        label: "Telefoonnummer"
        placeholder: "Bijv. +31 6 12345678"
    birthdate:
        label: "Geboortedatum"
        placeholder: "Bijv. 13 maart 1996"
    gender:
        label: "Gender"
        placeholder: "Selecteer je Gender"
        options:
            empty: "Geef liever geen antwoord"
            male: "Man"
            female: "Vrouw"
            neutral: "Neutraal"
    address:
        label: "Adres"
        placeholder: "Zoek naar je adres..."
    city:
        label: "Stad"
        placeholder: "Zoek naar je stad..."

de:
    email:
        label: "E-Mail"
        placeholder: "Z.B. john.doe{'@'}icloud.com"
    first_name:
        label: "Vorname"
        placeholder: "Z.B. John"
    last_name:
        label: "Nachname"
        placeholder: "Z.B. Doe"
    phone_number:
        label: "Telefonnummer"
        placeholder: "Z.B. +1 (123) 456-7890"
    birthdate:
        label: "Geburtsdatum"
        placeholder: "Z.B. 13. März 1996"
    gender:
        label: "Geschlecht"
        placeholder: "Wählen Sie Ihr Geschlecht"
        options:
            empty: "Möchte ich nicht angeben"
            male: "Männlich"
            female: "Weiblich"
            neutral: "Neutral"
    address:
        label: "Adresse"
        placeholder: "Suchen Sie nach Ihrer Adresse..."
    city:
        label: "Stadt"
        placeholder: "Suchen Sie nach Ihrer Stadt..."

fr:
    email:
        label: "E-mail"
        placeholder: "Par exemple, john.doe{'@'}icloud.com"
    first_name:
        label: "Prénom"
        placeholder: "Par exemple, John"
    last_name:
        label: "Nom de famille"
        placeholder: "Par exemple, Doe"
    phone_number:
        label: "Numéro de téléphone"
        placeholder: "Par exemple, +1 (123) 456-7890"
    birthdate:
        label: "Date de naissance"
        placeholder: "Par exemple, 13 mars 1996"
    gender:
        label: "Genre"
        placeholder: "Sélectionnez votre genre"
        options:
            empty: "Préfère ne pas dire"
            male: "Homme"
            female: "Femme"
            neutral: "Neutre"
    address:
        label: "Adresse"
        placeholder: "Recherchez votre adresse..."
    city:
        label: "Ville"
        placeholder: "Recherchez votre ville..."
</i18n>
