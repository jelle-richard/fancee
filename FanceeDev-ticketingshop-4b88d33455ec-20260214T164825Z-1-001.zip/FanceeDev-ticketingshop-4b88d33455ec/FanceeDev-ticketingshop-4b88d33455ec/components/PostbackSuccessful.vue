<template>
    <FluxPaneBody>
        <img
            :src="isDark ? illustrationDarkSvg : illustrationSvg"
            alt="">
    </FluxPaneBody>

    <FluxPaneBody is-larger-padded>
        <h1>{{ t('title') }}</h1>
        <p>{{ t('info') }}</p>
    </FluxPaneBody>

    <FluxPaneBody is-larger-padded>
        <FluxNotice
            v-if="isDownloading"
            is-loading
            is-small
            :message="t('downloading')"/>

        <FluxNotice
            v-else-if="downloadFailed && !isSealedOrder"
            icon="circle-exclamation"
            is-small
            :message="t('download_exceeded_message')"
            variant="warning"/>

        <div v-else-if="isSealedOrder">
            <FluxNotice
                icon="circle-exclamation"
                is-small
                :message="t('sealed_purchase', [sealTimeHours])"
                variant="info"/>

            <FluxDivider/>

            <FluxPrimaryButton
                v-if="orderContainsSwappableProducts"
                type="link"
                :href="`https://www.ticketswap.com/sell/tickets/Fancee/${orderId}`"
                :label="t('sell_on_ticketswap')"/>
        </div>

        <FluxNotice
            v-else
            icon="circle-check"
            is-small
            :message="t('downloaded')"/>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { OrderService } from '@fancee/api';
    import { HttpStatusCode, isRequestError } from '@fancee/client';
    import { FluxNotice, FluxPrimaryButton, FluxPaneBody, FluxDivider } from '@fancee/flux';
    import illustrationSvg from '~/assets/payment-successful.svg';
    import illustrationDarkSvg from '~/assets/payment-successful-dark.svg';

    const {t} = useI18n();
    const {downloadTicketsPdf} = useService(OrderService);
    const route = useRoute();
    const pane = useShopColor('backdropColor');

    const downloadAttempts = ref(0);
    const downloadFailed = ref(false);
    const downloadLimit = ref(30);
    const sealTimeHours = ref(24);
    const isDownloading = ref(false);
    const isSealedOrder = ref(false);

    const clientId = computed(() => route.query.c as string);
    const orderId = computed(() => route.query.o as string);
    const orderContainsSwappableProducts = computed(() => (route.query.orderContainsSwppableProducts as string).toLowerCase() === 'true');
    const isDark = computed(() => hexToHSL(unref(pane)!)[2] < 50);

    async function download(): Promise<void> {
        downloadFailed.value = false;
        isDownloading.value = true;

        await new Promise(resolve => setTimeout(resolve, 1000));

        try {
            const {blob, name} = await downloadTicketsPdf(unref(orderId), unref(clientId));
            downloadBlob(blob, name);
            isDownloading.value = false;
        } catch (err) {
            ++downloadAttempts.value;

            //Todo: Bas FAN-3000 find a nicer way to do this ghetto sealed error check.
            let responseErrors = Object.values(err.errors);
            responseErrors.forEach((re: string[]) => {
                if (re[0] === 'Order file not found because event is sealed') {
                    isSealedOrder.value = true;
                    downloadAttempts.value = 30;
                    isDownloading.value = false;
                    return false;
                }
            });

            if (!isRequestError(err)) {
                return;
            }

            if (unref(downloadAttempts) >= unref(downloadLimit) || err.statusCode !== HttpStatusCode.NotFound) {
                downloadFailed.value = true;
                isDownloading.value = false;
                return;
            }

            await new Promise(resolve => setTimeout(resolve, 6000));
            await download();
        }
    }

    watch([clientId, orderId], ([clientId, orderId]) => {
        if (!clientId || !orderId) {
            return;
        }

        downloadAttempts.value = 0;
        download();
    }, {immediate: true});
</script>

<i18n lang="yaml">
en:
    title: "Thank you!"
    info: "You'll get a confirmation of your order in your email soon. If you bought digital goods like tickets, they'll be right there in the same email for you. 😊"
    downloading: "Your ticket PDF is on its way, just a moment!"
    download_exceeded_message: "We encountered a slight issue while downloading your ticket(s). Don't worry; you'll still receive them in your email shortly."
    downloaded: "Your ticket PDF has been downloaded! Check your download folder to view your tickets."
    sell_on_ticketswap: "Sell on TicketSwap"
    sealed_purchase: "You've purchased tickets for a sealed event, tickets will be delivered to you {0} hours before the event"

nl:
    title: "Bedankt!"
    info: "Je krijgt binnenkort een bevestiging van je bestelling in je e-mail. Als je digitale goederen zoals tickets hebt gekocht, zullen ze direct in dezelfde e-mail voor je beschikbaar zijn. 😊"
    downloading: "Je ticket PDF is onderweg, nog even geduld!"
    download_exceeded_message: "We hebben wat problemen ondervonden bij het downloaden van je ticket(s). Maak je geen zorgen; je ontvangt ze binnenkort nog steeds in je mailbox."
    downloaded: "Je ticket-PDF is gedownload! Controleer je downloadmap om je tickets te bekijken."
    sell_on_ticketswap: "Verkoop op TicketSwap"
    sealed_purchase: "Je hebt een aankoop gedaan voor een verzegeld evenement, je zal de tickets {0} uur voor aanvang ontvangen"

de:
    title: "Vielen Dank!"
    info: "Du erhältst in Kürze eine Bestätigung deiner Bestellung per E-Mail. Wenn du digitale Güter wie Tickets gekauft hast, findest du sie gleich in derselben E-Mail. 😊"
    downloading: "Dein Ticket-PDF ist unterwegs, nur einen Moment!"
    download_exceeded_message: "Wir haben beim Herunterladen deiner Ticket(s) ein kleines Problem festgestellt. Keine Sorge, du erhältst sie dennoch in Kürze per E-Mail."
    downloaded: "Ihr Ticket-PDF wurde heruntergeladen! Überprüfen Sie Ihren Download-Ordner, um Ihre Tickets anzuzeigen."
    sell_on_ticketswap: "Verkaufen Sie auf TicketSwap"
    sealed_purchase: "Sie haben Tickets für eine versiegelte Veranstaltung gekauft. Die Tickets werden Ihnen {0} Stunden vor der Veranstaltung zugestellt"

fr:
    title: "Merci !"
    info: "Vous recevrez bientôt une confirmation de votre commande par e-mail. Si vous avez acheté des biens numériques tels que des billets, vous les trouverez dans le même e-mail. 😊"
    downloading: "Votre PDF de billet est en route, juste un instant !"
    download_exceeded_message: "Nous avons rencontré un léger problème lors du téléchargement de votre/vos billet(s). Ne vous inquiétez pas ; vous les recevrez toujours par e-mail sous peu."
    downloaded: "Votre billet PDF a été téléchargé! Vérifiez votre dossier de téléchargement pour voir vos billets."
    sell_on_ticketswap: "Vendre sur TicketSwap"
    sealed_purchase: "Vous avez acheté des billets pour un événement scellé, les billets vous seront livrés {0} heures avant l'événement."
</i18n>
