<template>
    <FluxPaneBody class="checkout-grid">
        <slot/>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { FluxPaneBody } from '@fancee/flux';
</script>

<style
    lang="scss"
    scoped>
    .checkout-grid {
        display: grid;
        align-items: start;
        gap: 18px 9px;
        grid-template-columns: repeat(2, 1fr);

        @media (max-width: 720px) {
            grid-template-columns: 1fr;
        }
    }
</style>
