<template>
</template>

<script
    lang="ts"
    setup>
    import { ShopAnalytics } from '@fancee/data';
    import type { Noscript, Script } from '@unhead/vue';

    export interface Props {
        readonly analytics: ShopAnalytics;
    }

    const props = defineProps<Props>();

    useHead({
        noscript: computed(() => {
            const noscripts: Noscript[] = [];

            if (props.analytics.googleTagManagerId) {
                noscripts.push({
                    tagPosition: 'bodyOpen',
                    innerHTML: `
                    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=${props.analytics.googleTagManagerId}" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
                    `
                });
            }

            return noscripts;
        }),
        script: computed(() => {
            const scripts: Script[] = [];

            if (props.analytics.googleAnalyticsId) {
                scripts.push({
                    async: true,
                    src: `https://www.googletagmanager.com/gtag/js?id=${props.analytics.googleAnalyticsId}`
                });

                scripts.push({
                    innerHTML: `
                    window.dataLayer = window.dataLayer || [];
                    function gtag() {
                        dataLayer.push(arguments);
                    }
                    gtag("js", new Date());
                    gtag("config", "${props.analytics.googleAnalyticsId}");
                    `
                });
            } else {
                scripts.push({
                    innerHTML: 'function gtag() {}'
                });
            }

            if (props.analytics.googleTagManagerId) {
                scripts.push({
                    tagPosition: 'head',
                    innerHTML: `
                    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                    })(window,document,'script','dataLayer','${props.analytics.googleTagManagerId}');
                    `
                });
            }

            if (props.analytics.tiktokPixelId) {
                scripts.push({
                    innerHTML: `
                    !function (w, d, t) {
                        w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};
                        ttq.load('${props.analytics.tiktokPixelId}');
                        ttq.page();
                    }(window, document, 'ttq');
                    `
                })
            } else {
                scripts.push({
                    innerHTML: 'var ttq = { track() {} };'
                });
            }

            return scripts;
        })
    });
</script>
