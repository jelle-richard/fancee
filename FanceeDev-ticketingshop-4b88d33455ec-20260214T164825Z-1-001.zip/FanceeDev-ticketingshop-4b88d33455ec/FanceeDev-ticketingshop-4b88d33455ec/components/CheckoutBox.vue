<template>
    <div class="checkout-box">
        <div
            v-if="isLoading"
            class="checkout-box-loading">
            <FluxSpinner/>
        </div>

        <header
            v-if="title"
            class="checkout-box-header">
            <span class="checkout-box-header-title">{{ title }}</span>
            <slot name="header"/>
        </header>

        <div class="checkout-box-body">
            <slot/>
        </div>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { FluxSpinner } from '@fancee/flux';

    export interface Props {
        readonly isLoading?: boolean;
        readonly span?: number;
        readonly title?: string;
    }

    withDefaults(defineProps<Props>(), {
        span: 1
    });

    const background = useShopColor('backdropColor', {l: 3});
    const backgroundLoader = useShopColor('backdropColor', {l: 3}, .8);
    const border = useShopColor('backdropColor', {l: 9});
    const headerBackground = useShopColor('backdropColor', {l: 5});
    const headerForeground = useShopColor('backdropColor', {l: 60});
    const spinnerTrack = useShopColor('backdropColor', {l: 10});
    const spinnerValue = useShopColor('primaryColor');
</script>

<style
    lang="scss"
    scoped>
    .checkout-box {
        position: relative;
        grid-column: span v-bind(span);
        background: v-bind(background);
        border: 1px solid v-bind(border);
        border-radius: var(--radius);
        overflow: hidden;
        z-index: 0;

        &-loading {
            position: absolute;
            display: flex;
            inset: 0;
            align-items: center;
            justify-content: center;
            background: v-bind(backgroundLoader);
            z-index: 100;

            --spinner-track: v-bind(spinnerTrack);
            --spinner-value: v-bind(spinnerValue);
        }

        &-header {
            display: flex;
            height: 51px;
            padding: 0 18px;
            align-items: center;
            justify-content: space-between;
            background: v-bind(headerBackground);
            border-bottom: 1px solid v-bind(border);
            color: v-bind(headerForeground);

            &-title {
                font-weight: 500;
            }
        }

        &-body {
            padding: 18px;
        }

        @media (max-width: 720px) {
            grid-column: span 1;
        }
    }
</style>
