<template>
    <div
        v-if="element.name.trim().length === 0"
        class="divider"/>

    <div
        v-else
        class="text-divider">
        <h2>{{ element.name }}</h2>
    </div>
</template>

<script
    lang="ts"
    setup>
    import type { ShopElementDivider } from '@fancee/data';

    export interface Props {
        readonly element: ShopElementDivider;
    }

    defineProps<Props>();

    const dividerColor = useShopColor('backdropColor', {l: 3});
</script>

<style
    lang="scss"
    scoped>
    .divider {
        height: 3px;
        margin: 12px var(--shop-gutter);
        background: v-bind(dividerColor);
    }

    .text-divider {
        margin-top: 24px;
        padding: 0 var(--shop-gutter);
    }
</style>
