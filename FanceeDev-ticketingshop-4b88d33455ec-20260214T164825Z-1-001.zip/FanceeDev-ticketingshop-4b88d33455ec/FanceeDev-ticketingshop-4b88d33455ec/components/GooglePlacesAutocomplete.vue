<template>
    <FluxFormInput
        v-model="autocompleteText"
        ref="inputRef"
        class="google-places-autocomplete"
        auto-complete="off"
        :is-disabled="isDisabled"
        :placeholder="placeholder"/>
</template>

<script
    lang="ts"
    setup>
    import { Address, type CountryCode } from '@fancee/data';
    import { FluxFormInput } from '@fancee/flux';
    import { type ComponentPublicInstance, computed, onMounted, ref, unref, watch } from 'vue';

    export interface Emits {
        (e: 'address-changed', address: Address): void;

        (e: 'change', value: string): void;

        (e: 'no-results-found'): void;

        (e: 'place-changed', place: google.maps.places.PlaceResult, address: Address): void;
    }

    export interface Props {
        readonly isDisabled?: boolean;
        readonly placeholder?: string;
        readonly types?: string[];
        readonly value?: string;
    }

    const emit = defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        types: () => ['address']
    });

    const autocomplete = ref<google.maps.places.Autocomplete>();
    const autocompleteText = ref<string>('');
    const inputRef = ref<ComponentPublicInstance>();

    const inputElement = computed(() => unref(inputRef)!.$el.querySelector('input') as HTMLInputElement);

    onMounted(() => {
        const googleMapsAutocomplete = new google.maps.places.Autocomplete(unref(inputElement), {
            types: props.types
        });

        googleMapsAutocomplete.setFields(['address_components', 'adr_address', 'alt_id', 'formatted_address', 'geometry', 'icon', 'id', 'name', 'business_status', 'photo', 'place_id', 'scope', 'type', 'url', 'utc_offset_minutes', 'vicinity']);
        googleMapsAutocomplete.addListener('place_changed', onPlaceChanged);

        autocomplete.value = googleMapsAutocomplete;
        autocompleteText.value = props.value ?? '';
    });

    function onPlaceChanged(): void {
        const place: google.maps.places.PlaceResult = autocomplete.value!.getPlace();

        if (!place.geometry || !place.address_components) {
            emit('no-results-found');
            return;
        }

        const address = convertPlaceToAddress(place);

        emit('address-changed', address);
        emit('place-changed', place, address);

        autocompleteText.value = unref(unref(inputElement)).value;
    }

    function convertPlaceToAddress(place: google.maps.places.PlaceResult): Address {
        const value = (type: string, variant: 'long_name' | 'short_name'): string | null => {
            const index = place.address_components!.findIndex(ac => ac.types.includes(type));

            if (index === -1) {
                return null;
            }

            return place.address_components![index][variant];
        };

        const result = Address.empty();
        result.latitude = place.geometry?.location?.lat() || null;
        result.longitude = place.geometry?.location?.lng() || null;
        result.street = value('route', 'long_name');
        result.houseNumber = value('street_number', 'long_name');
        result.city = value('locality', 'long_name');
        result.postalCode = value('postal_code', 'long_name');

        const countryCode = value('country', 'short_name');
        if (countryCode) {
            result.countryCode = countryCode as CountryCode;
        }

        return result;
    }

    watch(autocompleteText, autocompleteText => emit('change', autocompleteText));
</script>

<style lang="scss">
    .pac-container {
        padding-top: 3px;
        background: rgb(var(--gray-0));
        background-clip: padding-box;
        border: 1px solid rgb(var(--gray-3));
        border-radius: var(--radius);
        box-shadow: var(--shadow-sm);
        font: inherit;
        translate: 0 9px;

        &::after {
            height: 39px;
            margin-right: 12px;
            padding: 0;
        }

        .pac-item {
            display: flex;
            height: 42px;
            padding: 0 21px;
            align-items: center;
            gap: 12px;
            border: 0;
            font-size: 14px;
            line-height: 1.4em;

            .pac-icon {
                margin: 0;
                flex: 0 0 auto;
            }

            .pac-item-query {
                padding: 0;
                flex: 0 0 auto;
                font-size: inherit;
            }

            &:hover {
                background: rgb(var(--gray-2));
            }
        }

        .pac-item + .pac-item {
            border-top: 1px dashed rgb(var(--gray-3));
        }

        .pac-item:last-of-type {
            border-bottom: 1px dashed rgb(var(--gray-3));
        }
    }
</style>
