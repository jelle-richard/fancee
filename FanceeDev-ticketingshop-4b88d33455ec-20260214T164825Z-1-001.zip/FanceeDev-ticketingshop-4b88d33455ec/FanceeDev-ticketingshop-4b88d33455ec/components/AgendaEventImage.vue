<template>
    <FluxAspectRatio
        v-if="agendaRef.design.showHeaders"
        :class="$style.eventImage"
        :aspect-ratio="4 / 3">

        <FluxFader v-if="event.headerImages.length > 0">
            <FluxFaderItem
                v-for="{id, focalPoint, url} of event.headerImages"
                :key="id">
                <FluxFocalPointImage
                    :focal-point="focalPoint"
                    :src="url"
                    alt=""/>
            </FluxFaderItem>
        </FluxFader>

        <img
            v-else
            :class="$style.placeholderImage"
            src="~/assets/fancee-placeholder.svg"
            alt="Fancee logo placeholder">
    </FluxAspectRatio>
</template>

<script
    setup
    lang="ts">
    import { AgendaOverviewLinkedEvent } from '@fancee/data';
    import { FluxAspectRatio, FluxFader, FluxFaderItem, FluxFocalPointImage } from '@fancee/flux';

    export interface Props {
        readonly event: AgendaOverviewLinkedEvent;
    }

    defineProps<Props>();

    const agendaRef = useAgendaInjection();
</script>

<style
    lang="scss"
    module>
    .eventImage {
        height: 100px;
        width: 150px;
    }

    .placeholderImage {
        border-radius: var(--radius);
    }

    @media (max-width: 900px) {
        .eventImage {
            grid-column: 1 / span 2;
            width: 100%;
            height: 100%;
        }
    }
</style>
