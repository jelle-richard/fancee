<template>
    <FluxPaneBody is-larger-padded>
        <img
            :src="isDark ? illustrationDarkSvg : illustrationSvg"
            alt="">
    </FluxPaneBody>

    <FluxPaneBody is-larger-padded>
        <h1>{{ t('title') }}</h1>
        <p>{{ t('info') }}</p>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { FluxPaneBody } from '@fancee/flux';
    import illustrationSvg from '~/assets/payment-refused.svg';
    import illustrationDarkSvg from '~/assets/payment-refused-dark.svg';

    const {t} = useI18n();
    const pane = useShopColor('backdropColor');

    const isDark = computed(() => hexToHSL(unref(pane)!)[2] < 50);
</script>

<i18n lang="yaml">
en:
    title: "Order refused"
    info: "Unfortunately, our payment provider either declined or was unable to process your payment, resulting in the cancellation of your order."

nl:
    title: "Bestelling geweigerd"
    info: "Helaas heeft onze betalingsprovider uw betaling ofwel geweigerd of kon deze niet verwerken, waardoor de bestelling is geannuleerd."

de:
    title: "Bestellung abgelehnt"
    info: "Leider hat unser Zahlungsanbieter entweder Ihre Zahlung abgelehnt oder konnte sie nicht verarbeiten, was zur Stornierung Ihrer Bestellung führte."

fr:
    title: "Commande refusée"
    info: "Malheureusement, notre fournisseur de paiement a soit refusé soit été incapable de traiter votre paiement, entraînant l'annulation de votre commande."
</i18n>
