<template>
    <div class="checkout-toggles">
        <slot/>
    </div>
</template>

<style
    lang="scss"
    scoped>
    .checkout-toggles {
        display: flex;
        margin: -3px;
        flex-flow: column;
        gap: 15px;
    }
</style>
