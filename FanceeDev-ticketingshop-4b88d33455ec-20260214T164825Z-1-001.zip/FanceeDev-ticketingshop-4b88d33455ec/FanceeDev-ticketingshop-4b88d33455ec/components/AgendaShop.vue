<template>
    <div :class="$style.shop">
        <FluxAspectRatio
            v-if="agendaRef.design.showHeaders"
            :class="$style.shopImage"
            :aspect-ratio="4 / 3">

            <FluxFader v-if="shop.headerImageUrl !== null">
                <FluxFocalPointImage
                    :focal-point="null"
                    :src="shop.headerImageUrl"
                    alt=""/>
            </FluxFader>

            <img
                v-else
                :class="$style.placeholderImage"
                src="~/assets/fancee-placeholder.svg"
                alt="Fancee logo placeholder">
        </FluxAspectRatio>

        <div :class="$style.shopCaption">
            <h1>{{ shop.name }}</h1>
        </div>
    </div>
</template>

<script
    setup
    lang="ts">
    import { AgendaOverviewShop } from '@fancee/data';
    import { FluxAspectRatio, FluxFader, FluxFaderItem, FluxFocalPointImage } from '@fancee/flux';

    export interface Props {
        readonly shop: AgendaOverviewShop;
    }

    defineProps<Props>();

    const agendaRef = useAgendaInjection();
</script>

<style
    lang="scss"
    module>
    .shop {
        background: var(--backdrop-color-secondary);
        border: 1px solid var(--backdrop-border);
        margin: 15px 0;
        display: flex;
        padding: 15px;
        gap: 30px;
        border-radius: var(--radius);
    }

    .shop:hover {
        background: var(--backdrop-hover);
        cursor: pointer;
    }

    .shopCaption {
        display: flex;
        flex-flow: column;
        flex-grow: 1;
        gap: 3px;
        align-self: center;

        h1 {
            color: var(--foreground-prominent);
            font-size: 23px;
        }
    }

    .shopImage {
        height: 50px;
        width: 75px;
    }

    .placeholderImage {
        border-radius: var(--radius);
    }
</style>
