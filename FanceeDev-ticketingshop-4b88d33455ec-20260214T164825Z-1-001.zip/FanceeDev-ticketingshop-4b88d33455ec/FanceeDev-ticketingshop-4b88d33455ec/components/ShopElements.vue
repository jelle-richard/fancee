<template>
    <FluxPaneBody class="shop-elements">
        <template v-for="element of elements">
            <template v-if="ShopElement.isAccordion(element) && element.elements.length > 0">
                <ShopElementAccordion :element="element"/>
            </template>

            <template v-else-if="ShopElement.isDivider(element)">
                <ShopElementDivider :element="element"/>
            </template>

            <template v-else-if="ShopElement.isExternalLink(element)">
                <ShopElementExternalLink :element="element"/>
            </template>

            <template v-else-if="ShopElement.isNotice(element)">
                <ShopElementNotice :element="element"/>
            </template>

            <template v-else-if="ShopElement.isProduct(element)">
                <ShopElementProduct :element="element"/>
            </template>

            <template v-else-if="ShopElement.isSeatingMap(element)">
                <ShopElementSeatingMap :element="element"/>
            </template>

            <template v-else-if="ShopElement.isTextBlock(element)">
                <ShopElementText :element="element"/>
            </template>
        </template>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { ShopElement } from '@fancee/data';
    import { FluxPaneBody } from '@fancee/flux';

    export interface Props {
        readonly elements: ShopElement[];
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .shop-elements {
        display: flex;
        flex-flow: column;
        gap: 15px;
    }
</style>
