<template>
    <CheckoutBox
        v-if="client && order"
        :title="t('personal_details')">
        <p>
            <template v-if="fullName">
                <span>{{ fullName }}</span><br/>
            </template>

            <span>{{ client.email }}</span><br/>

            <template v-if="client.phoneNumber.length > 0">
                <span>{{ client.phoneNumber }}</span><br/>
            </template>
        </p>

        <template v-if="client.address?.isEmpty === false">
            <p v-if="client.address.formatted.length > 0">
                <strong>{{ t('address') }}</strong><br/>
                {{ client.address.formatted }}
            </p>
            <p v-else>
                <strong>{{ t('City') }}</strong><br/>
                {{ client.address.formattedCity }}
            </p>
        </template>
    </CheckoutBox>
</template>

<script
    lang="ts"
    setup>
    const {t} = useI18n();
    const reserveStore = useReserveStore();
    const {order} = storeToRefs(reserveStore);

    const client = computed(() => unref(order)?.orderClient);

    const fullName = computed(() => {
        const c = unref(client);

        if (!c) {
            return null;
        }

        const {firstName, lastName} = c;

        if (firstName.length > 0 && lastName.length > 0) {
            return `${firstName} ${lastName}`;
        }

        if (firstName.length > 0) {
            return firstName;
        }

        if (lastName.length > 0) {
            return lastName;
        }

        return null;
    });
</script>

<i18n lang="yaml">
en:
    address: "Address"
    personal_details: "Personal details"

nl:
    address: "Adres"
    personal_details: "Persoonlijke gegevens"

de:
    address: "Adresse"
    personal_details: "Persönliche Angaben"

fr:
    address: "Adresse"
    personal_details: "Coordonnées personnelles"
</i18n>
