<template>
    <div :class="$style.eventCaption">
        <h2>{{ event.name }}</h2>
        <h5 v-if="!(event.address?.isEmpty ?? true)">
            <span>{{ event.address!.formatted }}</span>
        </h5>
        <ClientOnly>
            <p v-html="truncateString(event.description ?? '', 100)"/>
        </ClientOnly>
    </div>
</template>

<script
    setup
    lang="ts">
    import { AgendaOverviewLinkedEvent, truncateString } from '@fancee/data';

    export interface Props {
        readonly event: AgendaOverviewLinkedEvent;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    .eventCaption {
        display: flex;
        flex-flow: column;
        flex-grow: 1;
        gap: 3px;

        h2 {
            color: var(--foreground-prominent);
            font-size: 16px;
        }

        p {
            margin-top: 0;
        }
    }
</style>
