<template>
</template>

<script
    lang="ts"
    setup>
    const {setGoogleMapsReady} = useAppStore();

    useHead({
        script: [
            {
                async: true,
                defer: true,
                src: 'https://maps.googleapis.com/maps/api/js?key=AIzaSyBMKX9jwN7QRPzQrC4egBXh-zLA-yIQevM&libraries=places&callback=onGoogleMapsReady'
            }
        ]
    });

    Object.defineProperty(window, 'onGoogleMapsReady', {
        value: setGoogleMapsReady
    });
</script>
