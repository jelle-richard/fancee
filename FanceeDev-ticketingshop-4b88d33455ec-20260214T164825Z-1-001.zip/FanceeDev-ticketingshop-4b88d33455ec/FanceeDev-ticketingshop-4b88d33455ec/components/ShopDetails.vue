<template>
    <FluxPaneBody
        class="details"
        :style="{
            '--event-name-color': eventNameColor,
            '--info-icon-color': infoIconColor
        }">
        <h1>{{ shopRef.event.name }}</h1>

        <div
            class="details-description"
            v-html="shopRef.event.description"/>

        <FluxInfoStack class="details-info">
            <FluxInfo icon="calendar-arrow-up">
                <ClientOnly fallback="-">{{ formatDateTimeLocal(shopRef.event.startDate, locale) }}</ClientOnly>
            </FluxInfo>

            <FluxInfo icon="calendar-arrow-down">
                <ClientOnly fallback="-">{{ formatDateTimeLocal(shopRef.event.endDate, locale) }}</ClientOnly>
            </FluxInfo>

            <FluxInfo
                v-if="shopRef.event.address"
                icon="location-dot">
                {{ shopRef.event.address.venue }}
                <br v-if="shopRef.event.address.formatted && shopRef.event.address.venue"/>
                {{ shopRef.event.address.formatted }}
            </FluxInfo>

            <FluxInfo
                v-if="shopRef.event.minimumAge"
                icon="circle-exclamation">
                {{ t('age', {age: shopRef.event.minimumAge}) }}
            </FluxInfo>
        </FluxInfoStack>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { FluxInfo, FluxInfoStack, FluxPaneBody } from '@fancee/flux';

    const {locale, t} = useI18n();
    const shopRef = useShopInjection();

    const eventNameColor = useShopColor('textColor', {l: -10});
    const infoIconColor = useShopColor('backdropColor', {s: -30, l: 15});
</script>

<style
    lang="scss"
    scoped>
    .details {
        display: grid;
        padding: calc(21px + var(--shop-gutter));
        gap: 12px 21px;
        grid-auto-rows: auto;
        grid-template-columns: 1fr 240px;
        text-wrap: balance;

        ::v-deep(.flux-info-icon) {
            color: var(--info-icon-color);
        }

        h1 {
            grid-column: 1 / span 2;
            color: var(--event-name-color);
        }

        ::v-deep(*) {
            background: unset !important;
            color: unset !important;
        }

        @media (max-width: 900px) {
            margin-bottom: 15px;
            grid-template-columns: 1fr;

            h1 {
                grid-column: 1;
                font-size: 24px;
            }

            ::v-deep(.flux-info:first-child) {
                margin-top: 15px;
            }
        }
    }

    .details-description {
        max-height: 240px;
        overflow-y: auto;
    }
</style>

<i18n lang="yaml">
en:
    age: "Age {age}+"

nl:
    age: "Leeftijd {age}+"

de:
    age: "Alter {age}+"

fr:
    age: "Âge {age}+"
</i18n>
