export { default as de } from './de.svg';
export { default as en } from './en.svg';
export { default as fr } from './fr.svg';
export { default as nl } from './nl.svg';
