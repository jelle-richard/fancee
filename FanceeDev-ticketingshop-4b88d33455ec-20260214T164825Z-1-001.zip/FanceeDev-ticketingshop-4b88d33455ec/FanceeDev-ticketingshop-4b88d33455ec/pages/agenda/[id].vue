<template>
    <AgendaPane
        v-if="agendaRef"
        :is-loading="isLoading">
        <div :class="$style.eventElements">
            <template v-if="selectedEventId === null">
                <AgendaEvent
                    v-for="event in events"
                    :key="event.id"
                    :event="event"
                    @click="handleEventClick(event)"/>
            </template>

            <template v-else>
                <AgendaShop
                    v-for="shop in eventShops"
                    :key="shop.code"
                    :shop="shop"
                    @click="openShop(shop.code)"/>
                <FluxButtonStack>
                    <FluxSecondaryButton
                        :class="$style.backButton"
                        icon-before="arrow-circle-left"
                        @click="selectedEventId = null"/>
                </FluxButtonStack>
            </template>
        </div>
    </AgendaPane>
</template>

<script
    setup
    lang="ts">
    import { AgendaLinkedEvent, AgendaOverviewShop } from '@fancee/data';
    import { FluxButtonStack, FluxSecondaryButton } from '@fancee/flux';

    definePageMeta({
        layout: 'agenda'
    });

    const agendaRef = useAgendaInjection();
    const {app: {baseURL}} = useRuntimeConfig();

    const selectedEventId = ref<string | null>(null);
    const eventShops = ref<AgendaOverviewShop[]>([]);
    const isLoading = ref(false);

    watch(selectedEventId, () => {
        if (unref(selectedEventId) === null) {
            eventShops.value = [];
            return;
        }

        eventShops.value = unref(agendaRef).linkedEvents!.find(e => e.id === unref(selectedEventId))!.shops;
    });

    const events = computed(() => agendaRef.value.linkedEvents?.toSorted((a: AgendaLinkedEvent, b: AgendaLinkedEvent) => a.startDate.toMillis() - b.startDate.toMillis()) ?? []);

    function handleEventClick(event: AgendaLinkedEvent): void {
        if (event.shops.length > 1) {
            selectedEventId.value = event.id;
        } else {
            openShop(event.shops[0].code);
        }
    }

    function openShop(code: string): void {
        isLoading.value = true;
        window.location.href = `${baseURL.replace(/\/$/, '')}/${code}`;
    }
</script>

<style
    lang="scss"
    module>
    .backButton {
        --button-background: var(--primary-button-background);
        --button-background-active: var(--primary-button-background-active);
        --button-background-hover: var(--primary-button-background-hover);
        --button-foreground: var(--primary-button-foreground);
        --button-icon: var(--primary-button-icon);
        --button-stroke: var(--primary-button-border);
        margin-bottom: 9px;
    }

    .eventElements {
        position: relative;
        display: flex;
        margin: 6px 21px;
        min-height: 90px;
        padding: 0;
        flex-flow: column;
        z-index: 1;
    }
</style>
