<template>
    <!-- empty because vue needs a render function -->
</template>

<script
    lang="ts"
    setup>
    throw createError({
        statusCode: 404
    });
</script>
