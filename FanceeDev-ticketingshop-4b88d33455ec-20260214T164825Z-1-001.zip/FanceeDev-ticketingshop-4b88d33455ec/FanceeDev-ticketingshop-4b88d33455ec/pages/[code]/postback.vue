<template>
    <ClientOnly>
        <ShopPane
            v-if="shopRef"
            :is-loading="isLoading"
            :style="{
                '--notice-background': noticeBackground,
                '--notice-border': noticeBorder,
                '--notice-spinner': noticeSpinner,
                '--title-color': titleColor
            }">
            <template v-if="paymentStatus">
                <PostbackPending v-if="[PaymentStatus.Unknown, PaymentStatus.PresentToShopper, PaymentStatus.ChallengeShopper, PaymentStatus.Received, PaymentStatus.RedirectShopper, PaymentStatus.AuthenticationFinished, PaymentStatus.AuthenticationNotRequired, PaymentStatus.IdentifyShopper].includes(paymentStatus)"/>
                <PostbackSuccessful v-else-if="[PaymentStatus.Authorised, PaymentStatus.PartiallyAuthorised].includes(paymentStatus)"/>
                <PostbackCanceled v-else-if="[PaymentStatus.Cancelled, PaymentStatus.Expired].includes(paymentStatus)"/>
                <PostbackRefused v-else-if="[PaymentStatus.Refused, PaymentStatus.Error, PaymentStatus.Blocked].includes(paymentStatus)"/>
                <PostbackUnexpectedResult v-else-if="!isLoading"/>
            </template>

            <template v-else-if="isCostlessOrder">
                <PostbackSuccessful/>
            </template>

            <ShopNavigation #content>
                <FluxButtonStack
                    axis="vertical"
                    is-fill>
                    <FluxPrimaryButton
                        v-if="appUri"
                        :label="t('back_to_app')"
                        size="large"
                        @click="onBackToAppClick"/>

                    <FluxSecondaryButton
                        :label="t('place_another')"
                        size="large"
                        @click="onPlaceAnotherClick"/>
                </FluxButtonStack>
            </ShopNavigation>
        </ShopPane>
    </ClientOnly>
</template>

<script
    lang="ts"
    setup>
    import { default as initializeAdyenCheckout } from '@adyen/adyen-web';
    import { PaymentAdapter, PaymentStatus } from '@fancee/data';
    import { FluxButtonStack, FluxPrimaryButton, FluxSecondaryButton } from '@fancee/flux';

    definePageMeta({
        layout: 'shop',
        small: true
    });

    const {t} = useI18n();
    const {public: {adyenClientKey, adyenEnvironment}} = useRuntimeConfig();
    const {discountTotal, ticketServicePlusTotal, total} = useShopTotals();
    const cartStore = useCartStore();
    const router = useRouter();
    const shopRef = useShopInjection();
    const shopCodeRef = useShopCodeInjection();
    const tracking = useTracking();

    const isLoading = ref(false);
    const paymentStatus = ref<PaymentStatus | null>(null);

    const appUri = useRouteQueryParam('appUri');
    const redirectResult = useRouteQueryParam('redirectResult');
    const sessionId = useRouteQueryParam('sessionId');
    const statusRaw = useRouteQueryParam('status');

    const isCostlessOrder = computed(() => !unref(sessionId) || !unref(redirectResult));
    const status = computed(() => {
        const raw = unref(statusRaw);
        return raw ? PaymentAdapter.parsePaymentStatus(raw) : null;
    });

    function onBackToAppClick(): void {
        window.location.href = unref(appUri)!;
    }

    function onPlaceAnotherClick(): void {
        router.push(`/${unref(shopCodeRef)}`);
    }

    watch([isCostlessOrder, redirectResult, sessionId, status], async ([isCostlessOrder, redirectResult, sessionId, status]) => {
        if (isCostlessOrder || process.server) {
            if (status) {
                paymentStatus.value = status;
            }

            return;
        }

        isLoading.value = true;

        try {
            await new Promise(resolve => setTimeout(resolve, 1));

            const checkout = await initializeAdyenCheckout({
                clientKey: adyenClientKey,
                environment: adyenEnvironment,
                analytics: {
                    enabled: false
                },
                session: {id: sessionId},
                onError: (err, ...args) => console.error(err, args),
                onPaymentCompleted: result => paymentStatus.value = PaymentAdapter.parsePaymentStatus(result.resultCode)
            });

            checkout.submitDetails({
                details: {
                    redirectResult
                }
            });

            tracking.completePayment(unref(total), cartStore.selectedProducts, unref(discountTotal), unref(ticketServicePlusTotal));
        } catch (err) {
            console.error(err);
        }

        isLoading.value = false;
    }, {immediate: true});

    const noticeBackground = useShopColor('backdropColor', {l: 3});
    const noticeBorder = useShopColor('backdropColor', {l: 9});
    const noticeSpinner = useShopColor('primaryColor');

    const titleColor = useShopColor('textColor', {l: -3});
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(h1) {
        color: var(--title-color);
        font-size: 21px;
    }

    ::v-deep(img) {
        max-height: 150px;
        max-width: 150px;
        mix-blend-mode: luminosity;
        outline: 0;
    }

    ::v-deep(.flux-stack) {
        margin-left: auto;
        margin-right: auto;
        max-width: 300px;
    }

    ::v-deep(.flux-notice) {
        background: var(--notice-background);
        border: 1px solid var(--notice-border);
    }

    ::v-deep(.flux-notice.is-warning) {
        background: rgb(var(--warning-3) / .5);
        border: 1px solid rgb(var(--warning-4) / .75);
    }

    ::v-deep(.flux-spinner) {
        --spinner-track: var(--notice-border);
        --spinner-value: var(--notice-spinner);
    }
</style>

<i18n lang="yaml">
en:
    back_to_app: "Back to App"
    place_another: "Place another order"

nl:
    back_to_app: "Terug naar de App"
    place_another: "Plaats een nieuwe bestelling"

de:
    back_to_app: "Zurück zur App"
    place_another: "Eine weitere Bestellung aufgeben"

fr:
    back_to_app: "Retour à l'application"
    place_another: "Passer une autre commande"
</i18n>
