<template>
    <ShopPane>
        <ShopDetails/>

        <CheckoutGrid>
            <CheckoutColumn>
                <CheckoutSummary/>
            </CheckoutColumn>

            <CheckoutColumn>
                <CheckoutTotals/>
            </CheckoutColumn>

            <CheckoutExtras/>
            <CheckoutLegal v-model:terms-and-conditions-accepted="termsAndConditionsAccepted"/>
            <CheckoutPaymentMethods/>
        </CheckoutGrid>

        <ShopNavigation>
            <template #buttons>
                <FluxSecondaryButton
                    :disabled="isPlacingOrder"
                    :label="t('back')"
                    @click="onBackClicked"/>

                <FluxPrimaryButton
                    :disabled="!canCheckout || isPlacingOrder"
                    :is-loading="isPlacingOrder"
                    icon-after="circle-arrow-right"
                    :label="subTotal === 0 ? t('place_order') : t('checkout')"
                    @click="onNextClicked"/>
            </template>
        </ShopNavigation>
    </ShopPane>
</template>

<script
    lang="ts"
    setup>
    import { ShopService } from '@fancee/api';
    import { isRequestError } from '@fancee/client';
    import { ShopOrder } from '@fancee/data';
    import { FluxPrimaryButton, FluxSecondaryButton, showSnackbar } from '@fancee/flux';

    definePageMeta({
        layout: 'shop'
    });

    useShopCodeGuard();

    const {t} = useI18n();
    const {order: placeOrder} = useService(ShopService);
    const {discountTotal, subTotal, ticketServicePlusTotal, total} = useShopTotals();
    const router = useRouter();
    const shopCodeRef = useShopCodeInjection();
    const tracking = useTracking();
    const cartStore = useCartStore();
    const reserveStore = useReserveStore();
    const {order} = storeToRefs(reserveStore);

    const isPlacingOrder = ref(false);
    const termsAndConditionsAccepted = ref(false);

    const canCheckout = computed(() => unref(termsAndConditionsAccepted) && (unref(total) === 0 || !!unref(order)?.paymentMethodId));

    async function onBackClicked(): Promise<void> {
        await router.replace(`/${unref(shopCodeRef)}/details`);
    }

    async function onNextClicked(): Promise<void> {
        isPlacingOrder.value = true;

        tracking.addPaymentInfo(unref(total));
        tracking.placeAnOrder(
            unref(total),
            cartStore.selectedProducts,
            unref(discountTotal),
            unref(ticketServicePlusTotal)
        );

        try {
            const {data} = await placeOrder(unref(shopCodeRef), unref(order) as ShopOrder);
            openUrl(data.redirectUrl);
        } catch (err) {
            isPlacingOrder.value = false;

            if (isRequestError(err)) {
                const messages = Object.values(err.errors).flat();

                showSnackbar({
                    color: 'danger',
                    duration: 9000,
                    icon: 'circle-exclamation',
                    message: t('order_failed_message'),
                    subMessage: messages.join(' // '),
                    title: t('order_failed')
                });
            } else {
                showSnackbar({
                    color: 'danger',
                    duration: 9000,
                    icon: 'circle-exclamation',
                    message: t('order_failed_message'),
                    subMessage: err instanceof Error ? err.message : undefined,
                    title: t('order_failed')
                });
            }
        }
    }
</script>

<i18n lang="yaml">
en:
    checkout: "Checkout"
    order_failed: "Order Placement Failed"
    order_failed_message: "We apologize for the inconvenience, but it seems that there was an issue processing your order. Please try again later or contact our support team for assistance. Thank you!"
    place_order: "Place order"

nl:
    checkout: "Afrekenen"
    order_failed: "Bestelling Plaatsen Mislukt"
    order_failed_message: "Onze excuses voor het ongemak, maar er lijkt een probleem te zijn opgetreden bij het verwerken van je bestelling. Probeer het later opnieuw of neem contact op met onze klantenservice voor hulp. Bedankt!"
    place_order: "Plaats order"

de:
    checkout: "Zur Kasse"
    order_failed: "Bestellungsplatzierung fehlgeschlagen"
    order_failed_message: "Wir entschuldigen uns für die Unannehmlichkeiten, aber es scheint, dass es ein Problem bei der Bearbeitung Ihrer Bestellung gibt. Bitte versuchen Sie es später erneut oder kontaktieren Sie unser Support-Team für Unterstützung. Vielen Dank!"
    place_order: "Bestellung aufgeben"

fr:
    checkout: "Paiement"
    order_failed: "Échec de la passation de commande"
    order_failed_message: "Nous nous excusons pour la gêne occasionnée, mais il semble qu'il y ait eu un problème lors du traitement de votre commande. Veuillez réessayer plus tard ou contacter notre équipe de support pour obtenir de l'aide. Merci !"
    place_order: "Passer la commande"
</i18n>
