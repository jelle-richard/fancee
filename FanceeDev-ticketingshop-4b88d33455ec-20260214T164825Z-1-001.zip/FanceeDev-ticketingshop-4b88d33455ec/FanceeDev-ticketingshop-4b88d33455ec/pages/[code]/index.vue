<template>
    <ShopPane v-if="shopRef">
        <ShopFader/>
        <ShopDetails/>
        <ShopElements :elements="shopRef.elements"/>

        <FluxSeparator/>

        <ShopNavigation>
            <template #buttons>
                <FluxPrimaryButton
                    :disabled="isLoading || !cartStore.hasSelectedProducts"
                    :is-loading="isLoading"
                    icon-after="circle-arrow-right"
                    :label="t('next')"
                    @click="onNextClicked"/>
            </template>

            <template
                v-if="notice"
                #end>
                <FluxNotice
                    ref="noticeRef"
                    :icon="notice.icon"
                    :message="notice.message"
                    :title="notice.title"
                    :variant="notice.variant"/>
            </template>
        </ShopNavigation>
    </ShopPane>

    <ClientOnly>
        <SecuredShopOverlay/>
    </ClientOnly>
</template>

<script
    lang="ts"
    setup>
    import { FluxNotice, FluxPrimaryButton, FluxSeparator } from '@fancee/flux';
    import type { ComponentPublicInstance } from 'vue';
    import type { Notice } from '~/data';

    definePageMeta({
        layout: 'shop'
    });

    const {t} = useI18n();
    const cartStore = useCartStore();
    const reserveStore = useReserveStore();
    const router = useRouter();
    const shopRef = useShopInjection();
    const shopCodeRef = useShopCodeInjection();
    const tracking = useTracking();

    const isLoading = ref(false);
    const notice = ref<Notice | null>(null);
    const noticeRef = ref<ComponentPublicInstance>();

    onMounted(() => {
        cartStore.reset();
        reserveStore.reset();
    });

    const onNextClicked = withErrorHandler(
        async () => {
            tracking.clickButton('listing_next');

            notice.value = null;
            await cartStore.reserve();
            await router.push(`/${unref(shopCodeRef)}/details`);
        },
        isLoading,
        notice
    );

    watch(noticeRef, notice => notice?.$el.scrollIntoView({
        behavior: 'smooth'
    }));
</script>
