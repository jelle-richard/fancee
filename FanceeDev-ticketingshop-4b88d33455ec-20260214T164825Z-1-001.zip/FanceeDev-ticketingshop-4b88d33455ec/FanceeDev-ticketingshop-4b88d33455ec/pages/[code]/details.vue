<template>
    <ShopPane>
        <ShopDetails/>
        <ShopForm/>

        <ShopNavigation>
            <template #buttons>
                <FluxSecondaryButton
                    :label="t('back')"
                    @click="onBackClicked"/>

                <FluxPrimaryButton
                    :disabled="invalid"
                    icon-after="circle-arrow-right"
                    :label="t('next')"
                    @click="onNextClicked"/>
            </template>
        </ShopNavigation>
    </ShopPane>
</template>

<script
    lang="ts"
    setup>
    import { FluxPrimaryButton, FluxSecondaryButton } from '@fancee/flux';
    import { useVuelidate } from '@vuelidate/core';

    definePageMeta({
        layout: 'shop'
    });

    useShopCodeGuard();

    const {t} = useI18n();
    const router = useRouter();
    const shopCodeRef = useShopCodeInjection();
    const tracking = useTracking();
    const v$ = useVuelidate();

    const invalid = computed(() => unref(v$).$errors.length > 0);

    async function onBackClicked(): Promise<void> {
        tracking.clickButton('details_back');

        await router.replace(`/${unref(shopCodeRef)}`);
    }

    async function onNextClicked(): Promise<void> {
        if (!await unref(v$).$validate()) {
            return;
        }

        tracking.clickButton('details_next');

        await router.push(`/${unref(shopCodeRef)}/summary`);
    }
</script>
