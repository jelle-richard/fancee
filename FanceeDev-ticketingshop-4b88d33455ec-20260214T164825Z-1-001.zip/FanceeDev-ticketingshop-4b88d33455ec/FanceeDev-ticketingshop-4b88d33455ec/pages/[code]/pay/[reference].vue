<template>
    <ShopPane
        v-if="shopRef"
        :is-loading="isLoading"
        :style="{
            contain: 'none',
            '--background': background,
            '--background-hover': backgroundHover,
            '--background-secondary': backgroundSecondary,
            '--border': border,
            '--event-name-color': eventNameColor,
            '--primary-button-background': primaryButtonBackground,
            '--primary-button-background-active': primaryButtonBackgroundActive,
            '--primary-button-background-hover': primaryButtonBackgroundHover,
            '--primary-button-foreground': primaryButtonForeground
        }">
        <ShopFader/>

        <FluxPaneBody is-larger-padded>
            <h1>{{ shopRef.event.name }}</h1>
            <p>{{ t('info') }}</p>
        </FluxPaneBody>

        <FluxPaneBody>
            <FluxNotice
                v-if="noticeMessage"
                icon="circle-exclamation"
                is-small
                :message="t(noticeMessage)"
                :variant="noticeVariant"/>

            <div id="adyen-dropin"/>
        </FluxPaneBody>
    </ShopPane>
</template>

<script
    lang="ts"
    setup>
    import { PaymentService } from '@fancee/api';
    import { isRequestError } from '@fancee/client';
    import { FluxNotice, FluxPaneBody } from '@fancee/flux';
    import { default as initializeAdyenCheckout } from '@adyen/adyen-web';
    import type { ComputedRef } from 'vue';

    definePageMeta({
        layout: 'shop',
        small: true
    });

    const knownExceptions: Record<string, ['danger' | 'success' | 'warning', string]> = {
        'FAN-89714': ['success', 'order_already_paid'],
        'FAN-89715': ['warning', 'order_processing'],
        'FAN-89716': ['danger', 'order_expired'],
        'FAN-89717': ['danger', 'order_canceled'],
        'FAN-89718': ['danger', 'order_blocked'],
        'FAN-89719': ['danger', 'order_refused']
    };

    const {createSession} = useService(PaymentService);
    const {t} = useI18n();
    const {public: {adyenClientKey, adyenEnvironment}} = useRuntimeConfig();
    const reservationReference = useRouteParam('reference') as ComputedRef<string>;
    const router = useRouter();
    const shopRef = useShopInjection();
    const shopCodeRef = useShopCodeInjection();
    const tracking = useTracking();

    const isLoading = ref(true);
    const noticeMessage = ref<string | null>(null);
    const noticeVariant = ref<'danger' | 'success' | 'warning'>('danger');

    watch(reservationReference, async reservationReference => {
        isLoading.value = true;

        try {
            const {data: session} = await createSession(reservationReference);
            const returnUrl = new URL((session as Record<string, string>).returnUrl);

            const dropin = await initializeAdyenCheckout({
                clientKey: adyenClientKey,
                environment: adyenEnvironment,
                locale: t('adyen_locale'),
                session,
                paymentMethodsConfiguration: {},
                onError: err => console.error(err),
                onPaymentCompleted({resultCode}) {
                    router.replace(`/${unref(shopCodeRef)}/postback?${returnUrl.searchParams.toString()}&status=${resultCode}`);
                }
            });

            tracking.initiateCheckout();

            dropin
                .create('dropin')
                .mount('#adyen-dropin');
        } catch (err) {
            noticeVariant.value = 'danger';

            if (!isRequestError(err)) {
                noticeMessage.value = 'something_went_wrong';
            } else {
                const key = Object.keys(err.errors)[0] ?? null;

                if (key in knownExceptions) {
                    const [variant, message] = knownExceptions[key];
                    noticeMessage.value = message;
                    noticeVariant.value = variant;
                } else {
                    noticeMessage.value = 'something_went_wrong';
                    noticeVariant.value = 'danger';
                }
            }
        }

        isLoading.value = false;
    }, {immediate: true});

    const background = useShopColor('backdropColor', {l: -3});
    const backgroundHover = useShopColor('backdropColor');
    const backgroundSecondary = useShopColor('backdropColor', {l: 3});
    const border = useShopColor('backdropColor', {l: 9});

    const eventNameColor = useShopColor('textColor', {l: -6});

    const primaryButtonBackground = useShopColor('primaryColor');
    const primaryButtonBackgroundActive = useShopColor('primaryColor', {l: 6});
    const primaryButtonBackgroundHover = useShopColor('primaryColor', {l: 3});
    const primaryButtonForeground = useShopColor('primaryColor', {l: -45});
</script>

<style
    lang="scss"
    scoped>
    h1 {
        margin-top: 9px;
        color: var(--event-name-color);
        font-size: 21px;
    }
</style>

<style lang="scss">
    @import '@adyen/adyen-web/dist/adyen.css';

    .adyen-checkout__dropin {
        font-size: 16px;
    }

    .adyen-checkout__payment-method {
        max-height: unset;
        background: var(--background-secondary);
        border-color: var(--border);
    }

    .adyen-checkout__payment-method--selected {
        margin: 15px 0;
        background: var(--background);
    }

    .adyen-checkout__payment-method--selected + .adyen-checkout__payment-method,
    .adyen-checkout__payment-method:first-child {
        border-top-left-radius: var(--radius);
        border-top-right-radius: var(--radius);
    }

    .adyen-checkout__payment-method--next-selected,
    .adyen-checkout__payment-method:last-child {
        border-bottom-left-radius: var(--radius);
        border-bottom-right-radius: var(--radius);
    }

    .adyen-checkout__payment-method__image__wrapper {
        height: 54px;
        width: 54px;
        margin-right: 15px;
        z-index: 0;

        &::after {
            background: #fff;
            border-color: var(--border);
            border-radius: calc(var(--radius) / 2);
        }

        img {
            position: relative;
            margin: 1px;
            height: calc(100% - 2px);
            width: calc(100% - 2px);
            z-index: 1;
        }
    }

    .adyen-checkout__payment-method__header {
        padding: 15px !important;

        &__title {
            padding: 0;
            color: var(--foreground);
        }
    }

    .adyen-checkout__payment-method__name--selected {
        font-weight: 700;
    }

    .adyen-checkout__payment-method__details {
        padding: 0 15px 15px;

        &__content {
            margin-bottom: 0;
        }
    }

    .adyen-checkout__dropdown {
        &__button {
            height: 42px;
            border-color: var(--border);
        }

        &__list {
            padding: 9px;
            flex-flow: column;
            background: var(--background);
            border: 1px solid var(--border);
            box-shadow: var(--shadow-xl);
            color: var(--foreground);

            &--active {
                display: flex;
            }
        }

        &__element {
            margin: 0;
            padding: 9px;
            border-radius: calc(var(--radius) / 2);
            font-size: 15px;
            line-height: 21px;

            &--active {
                background: var(--background-hover) !important;
            }

            &__icon {
                height: 36px;
                width: 36px;
                max-height: unset;
                max-width: unset;
                margin-top: -3px;
                margin-right: 15px;
                margin-bottom: -3px;
                background: #fff;
                border: 1px solid rgb(var(--gray-4));
                border-radius: inherit;
            }
        }
    }

    .adyen-checkout__button {
        height: 42px;
        padding-left: 15px;
        padding-right: 15px;
        background: var(--primary-button-background);
        box-shadow: var(--shadow-sm);
        color: var(--primary-button-foreground);
        font-weight: 700;
        outline: 2px solid transparent;
        transition: 210ms var(--swift-out);

        &:hover {
            background: var(--primary-button-background-hover);
            box-shadow: var(--shadow-sm);
        }

        &:active {
            background: var(--primary-button-background-active);
            box-shadow: var(--shadow-sm);
        }

        &:focus {
            box-shadow: var(--shadow-sm);
            outline: 2px solid var(--primary-button-background);
            outline-offset: 2px;
        }

        &:focus:hover {
            box-shadow: var(--shadow-sm);
        }

        &.adyen-checkout__button--pay {
            margin-top: 15px;
        }
    }
</style>

<i18n lang="yaml">
en:
    adyen_locale: "en-US"
    info: "To proceed with your order, please complete the payment process. Thank you for choosing us!"
    order_already_paid: "You've already paid! Unless you want to pay us again, you don't need to do anything ❤️"
    order_processing: "A payment is still processing. Please wait a few minutes."
    order_expired: "The payment has expired. Place another order."
    order_canceled: "The payment has been canceled."
    order_blocked: "The payment has been blocked."
    order_refused: "The payment was refused."
    something_went_wrong: "We're sorry to say that our payment system hit a small snag and couldn't complete your payment. 😔 No worries! Our tech wizards are on it, and we'll have it sorted ASAP. Thanks for your understanding!"

nl:
    adyen_locale: "nl-NL"
    info: "Om verder te gaan met je bestelling, voltooi de betalingsprocedure. Bedankt dat je voor ons hebt gekozen!"
    order_already_paid: "Je hebt al betaald! Tenzij je ons nog een keer wilt betalen, hoef je niks te doen ❤️"
    order_processing: "Een betaling wordt nog verwerkt. Wacht alstublieft een paar minuten."
    order_expired: "De betaling is verlopen. Plaats een nieuwe bestelling."
    order_canceled: "De betaling is geannuleerd."
    order_blocked: "De betaling is geblokkeerd."
    order_refused: "De betaling is geweigerd."
    something_went_wrong: "Het spijt ons te moeten zeggen dat ons betalingssysteem een klein probleempje tegenkwam en je betaling niet kon voltooien. 😔 Geen zorgen! Onze technische tovenaars werken eraan, en we zullen het zo snel mogelijk oplossen. Bedankt voor je begrip!"

de:
    adyen_locale: "de-DE"
    info: "Um mit Ihrer Bestellung fortzufahren, schließen Sie bitte den Zahlungsvorgang ab. Vielen Dank, dass Sie uns gewählt haben!"
    order_already_paid: "Sie haben bereits bezahlt! Es sei denn, Sie möchten uns noch einmal bezahlen, Sie müssen nichts tun ❤️"
    order_processing: "Eine Zahlung wird noch bearbeitet. Bitte warten Sie ein paar Minuten."
    order_expired: "Die Zahlung ist abgelaufen. Bitte geben Sie eine neue Bestellung auf."
    order_canceled: "Die Zahlung wurde storniert."
    order_blocked: "Die Zahlung wurde blockiert."
    order_refused: "Die Zahlung wurde abgelehnt."
    something_went_wrong: "Es tut uns leid zu sagen, dass unser Zahlungssystem auf ein kleines Problem gestoßen ist und Ihre Zahlung nicht abschließen konnte. 😔 Keine Sorge! Unsere Technikexperten kümmern sich darum, und wir werden es so schnell wie möglich erledigen. Vielen Dank für Ihr Verständnis!"

fr:
    adyen_locale: "fr-FR"
    info: "Pour continuer avec votre commande, veuillez compléter le processus de paiement. Merci de nous avoir choisis !"
    order_already_paid: "Vous avez déjà payé ! À moins que vous ne souhaitiez nous payer à nouveau, vous n'avez rien à faire ❤️"
    order_processing: "Un paiement est encore en cours de traitement. Veuillez patienter quelques minutes."
    order_expired: "Le paiement a expiré. Veuillez passer une nouvelle commande."
    order_canceled: "Le paiement a été annulé."
    order_blocked: "Le paiement a été bloqué."
    order_refused: "Le paiement a été refusé."
    something_went_wrong: "Nous sommes désolés de dire que notre système de paiement a rencontré un petit problème et n'a pas pu terminer votre paiement. 😔 Pas de souci ! Nos experts techniques s'en occupent, et nous réglerons cela au plus vite. Merci pour votre compréhension !"
</i18n>
