import '@fancee/flux/style.css';

import { fluxRegisterIcons, useId } from '@fancee/flux';
import type { Ref } from 'vue';
import { icons } from '~/data';

export default defineNuxtPlugin(() => {
    fluxRegisterIcons(icons);

    let id = 0;

    useId.generate = function (): Ref<string> {
        return ref(`flux:${++id}`);
    };
});
