import { GoogleAnalytics, TiktokPixel, Tracking } from '~/data/tracking';

export default defineNuxtPlugin(() => {
    const tracking = new Tracking(
        new GoogleAnalytics(),
        new TiktokPixel()
    );

    return {
        provide: {tracking}
    };
});
