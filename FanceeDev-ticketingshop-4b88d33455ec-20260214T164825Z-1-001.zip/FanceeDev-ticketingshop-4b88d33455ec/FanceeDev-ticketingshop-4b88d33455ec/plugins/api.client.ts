import { FanceeClient, RequestBuilder } from '@fancee/client';
import { Address } from '@fancee/data';

export default defineNuxtPlugin(() => {
    const {public: {apiUrl, headers}} = useRuntimeConfig();

    if (headers) {
        class CustomFanceeClient extends FanceeClient {
            constructor(authToken: string | null, baseUrl: string) {
                super(authToken, baseUrl);
            }

            onRequest(request: RequestBuilder): RequestBuilder {
                Object.entries(headers).forEach(([name, value]) => request = request.header(name, value));

                return request;
            }
        }

        FanceeClient.register(new CustomFanceeClient(null, apiUrl));
    } else {
        FanceeClient.register(new FanceeClient(null, apiUrl));
    }

    // note(Bas): Sorry, but this is required to keep @fancee/data on the client, so that Dto restoration works.
    Address.empty();
});
