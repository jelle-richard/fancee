import { DateTime } from 'luxon';

export default definePayloadPlugin(() => {
    definePayloadReducer('DateTime', data => data && DateTime.isDateTime(data) && data.toISO());
    definePayloadReviver('DateTime', data => DateTime.fromISO(data));
});
