import { isDto } from '@fancee/client';
import { deserialize, serialize } from '@fancee/serializer';

export default definePayloadPlugin(() => {
    definePayloadReducer('Dto', data => isDto(data) && serialize(data));
    definePayloadReviver('Dto', data => deserialize(data));
});
