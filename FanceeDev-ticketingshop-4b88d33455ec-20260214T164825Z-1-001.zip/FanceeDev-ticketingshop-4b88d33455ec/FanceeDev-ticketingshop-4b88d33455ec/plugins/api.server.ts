import { FanceeClient, RequestBuilder } from '@fancee/client';

export default defineNuxtPlugin(() => {
    const headers = useRequestHeaders();
    const {apiUrl, public: {headers: configHeaders}} = useRuntimeConfig();

    class FanceeShopClient extends FanceeClient {
        onRequest(request: RequestBuilder): RequestBuilder {
            const ip = headers['x-forwarded-for'] ?? null;
            const userAgent = headers['user-agent'] ?? null;

            userAgent && (request = request.header('user-agent', userAgent));
            ip && (request = request.header('x-forwarded-for', ip));

            if (configHeaders) {
                Object.entries(configHeaders).forEach(([name, value]) => request = request.header(name, value));
            }

            return request;
        }
    }

    FanceeClient.register(new FanceeShopClient(null, apiUrl as string));
});
