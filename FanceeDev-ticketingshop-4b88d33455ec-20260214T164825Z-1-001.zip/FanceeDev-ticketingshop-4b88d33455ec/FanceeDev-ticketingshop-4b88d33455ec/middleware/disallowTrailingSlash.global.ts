export default defineNuxtRouteMiddleware(to => {
    if (to.path === '/' || !to.path.endsWith('/')) {
        return;
    }

    const {hash, path, query} = to;
    const nextPath = path.replace(/\/+$/, '') || '/';
    const nextRoute = {path: nextPath, hash, query};

    return navigateTo(nextRoute, {
        redirectCode: 301
    });
});
