export default defineI18nConfig(() => ({
    legacy: false,
    messages: {
        en: {
            'flux.noItems': 'There are no items left.',
            'flux.optional': 'Optional',
            js_error: 'Something went wrong. Please refresh the page and try again. Information about the error: {message}',
            unknown_error: 'An unknown error occurred. Please refresh the page and try again.',
            internal_server_error: 'Something went wrong on our side. Please try again later.',
            service_unavailable: 'WeAreFancee Ticketing is currently unavailable. Please come back in a minute.',
            back: 'Back',
            next: 'Next',
            validations: {
                email: 'Invalid email address. Please enter a valid email address.',
                maxLength: 'Too long. A maximum of {max} characters is allowed.',
                minLength: 'Too short. A minimum of {min} characters is required.',
                notTooOld: 'Guiness book of records award: oldest person alive!',
                oldEnoughAt: 'Unfortunately, you\'re not old enough at the time the event starts. Minimum age required: {minAge} years.',
                required: 'Required field.'
            },
            error: {
                shop: {
                    insufficient_stock: 'Stock insufficient for the requested quantities. Please adjust or check later.',
                    secure_code_invalid: 'The secure code is invalid, expired or has reached its limit.'
                }
            }
        },
        nl: {
            'flux.noItems': 'Er zijn geen resultaten meer.',
            'flux.optional': 'Optioneel',
            js_error: 'Er ging iets mis. Probeer de pagina opnieuw te laden en probeer het opnieuw. Informatie over de foutmelding: {message}',
            unknown_error: 'Er ging iets mis. Probeer de pagina opnieuw te laden en probeer het opnieuw.',
            internal_server_error: 'Er ging iets mis aan onze kant. Probeer het later opnieuw.',
            service_unavailable: 'WeAreFancee Ticketing is momenteel even niet beschikbaar. Kom later nog eens terug.',
            back: 'Terug',
            next: 'Volgende',
            validations: {
                email: 'Ongeldig e-mailadres. Voer een geldig e-mailadres in.',
                maxLength: 'Te lang. Er is een maximum van {max} karakters toegestaan.',
                minLength: 'Te kort. Er is een minimum van {min} karakters vereist.',
                notTooOld: 'Guinness Book of Records prijs; oudste levende persoon!',
                oldEnoughAt: 'Helaas. Je bent niet oud genoeg bij aanvang van het evenement. Minimale leeftijd: {minAge} jaar vereist.',
                required: 'Verplicht veld.'
            },
            error: {
                shop: {
                    insufficient_stock: 'Onvoldoende voorraad voor de gevraagde hoeveelheden. Pas aan of controleer later.',
                    secure_code_invalid: 'De beveiligingscode is ongeldig, verlopen of heeft zijn limiet bereikt.'
                }
            }
        },
        de: {
            'flux.noItems': 'Es gibt keine weiteren Ergebnisse.',
            'flux.optional': 'Optional',
            js_error: 'Etwas ist schiefgelaufen. Versuchen Sie die Seite erneut zu laden und wiederholen Sie den Versuch. Informationen zur Fehlermeldung: {message}',
            unknown_error: 'Etwas ist schiefgelaufen. Versuchen Sie die Seite erneut zu laden und wiederholen Sie den Versuch.',
            internal_server_error: 'Etwas ist bei uns schiefgelaufen. Bitte versuchen Sie es später erneut.',
            service_unavailable: 'WeAreFancee Ticketing ist derzeit nicht verfügbar. Bitte versuchen Sie es später erneut.',
            back: 'Zurück',
            next: 'Weiter',
            validations: {
                email: 'Ungültige E-Mail-Adresse. Bitte geben Sie eine gültige E-Mail-Adresse ein.',
                maxLength: 'Zu lang. Es sind maximal {max} Zeichen erlaubt.',
                minLength: 'Zu kurz. Es sind mindestens {min} Zeichen erforderlich.',
                notTooOld: 'Guinness-Buch der Rekorde: Älteste lebende Person!',
                oldEnoughAt: 'Leider sind Sie bei Veranstaltungsbeginn nicht alt genug. Mindestalter: {minAge} Jahre erforderlich.',
                required: 'Pflichtfeld.'
            },
            error: {
                shop: {
                    insufficient_stock: 'Nicht genügend Lagerbestand für die angeforderten Mengen. Passen Sie an oder überprüfen Sie es später.',
                    secure_code_invalid: 'Der Sicherheitscode ist ungültig, abgelaufen oder hat sein Limit erreicht.'
                }
            }
        },
        fr: {
            'flux.noItems': 'Il n\'y a plus de résultats.',
            'flux.optional': 'Facultatif',
            js_error: 'Une erreur s\'est produite. Veuillez recharger la page et réessayer. Informations sur l\'erreur : {message}',
            unknown_error: 'Une erreur s\'est produite. Veuillez recharger la page et réessayer.',
            internal_server_error: 'Une erreur s\'est produite de notre côté. Veuillez réessayer ultérieurement.',
            service_unavailable: 'WeAreFancee Ticketing n\'est actuellement pas disponible. Revenez plus tard.',
            back: 'Retour',
            next: 'Suivant',
            validations: {
                email: 'Adresse e-mail invalide. Veuillez saisir une adresse e-mail valide.',
                maxLength: 'Trop long. Un maximum de {max} caractères est autorisé.',
                minLength: 'Trop court. Un minimum de {min} caractères est requis.',
                notTooOld: 'Record du Livre Guinness: personne la plus âgée en vie !',
                oldEnoughAt: 'Désolé, vous n\'avez pas l\'âge requis au début de l\'événement. Âge minimum requis : {minAge} ans.',
                required: 'Champ obligatoire.'
            },
            error: {
                shop: {
                    insufficient_stock: 'Stock insuffisant pour les quantités demandées. Ajustez ou vérifiez ultérieurement.',
                    secure_code_invalid: 'Le code sécurisé est invalide, a expiré ou a atteint sa limite.'
                }
            }
        }
    }
}));
