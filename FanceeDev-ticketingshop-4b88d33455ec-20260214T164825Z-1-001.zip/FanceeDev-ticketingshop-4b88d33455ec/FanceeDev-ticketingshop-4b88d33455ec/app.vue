<template>
    <FluxRoot>
        <NuxtLayout>
            <NuxtPage/>
        </NuxtLayout>
    </FluxRoot>
</template>

<script
    lang="ts"
    setup>
    import { FluxRoot } from '@fancee/flux';

    const {app: {baseURL}} = useRuntimeConfig();

    useHead({
        link: [
            {rel: 'icon', type: 'image/x-icon', href: `${baseURL === '/' ? '' : baseURL}/favicon.ico`},
            {rel: 'icon', type: 'image/svg+xml', href: `${baseURL === '/' ? '' : baseURL}/favicon.svg`},
            {rel: 'stylesheet', href: 'https://font.bmcdn.nl/css2?family=manrope-variable'}
        ],
        titleTemplate: chunk => chunk ? `${chunk} | WeAreFancee.com` : 'WeAreFancee.com'
    });

    useServerSeoMeta({
        applicationName: 'WeAreFancee Ticketshop',
        author: 'WeAreFancee.com',
        robots: 'index, follow'
    });
</script>
