import type { Currency } from '@fancee/data';

export interface TrackingInterface {
    addPaymentInfo(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number): void;

    addToCart(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, product: SelectedProduct): void;

    clickButton(eventId: string | null, shopCode: string | null, buttonName: string): void;

    completePayment(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, products: SelectedProduct[], discountCents: number, ticketServicePlusCostCents: number): void;

    initiateCheckout(eventId: string | null, shopCode: string | null): void;

    placeAnOrder(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, products: SelectedProduct[], discountCents: number, ticketServicePlusCostCents: number): void;

    removeFromCart(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, product: SelectedProduct): void;
}
