import type { Currency } from '@fancee/data';
import type { GoogleAnalytics, TiktokPixel } from '.';

export class Tracking {
    get currency(): Currency | null {
        return this.#currency;
    }

    set currency(value: Currency | null) {
        this.#currency = value;
    }

    get eventId(): string | null {
        return this.#eventId;
    }

    set eventId(value: string | null) {
        this.#eventId = value;
    }

    get shopCode(): string | null {
        return this.#shopCode;
    }

    set shopCode(value: string | null) {
        this.#shopCode = value;
    }

    readonly #googleAnalytics: GoogleAnalytics;
    readonly #tiktok: TiktokPixel;
    #currency: Currency | null = null;
    #eventId: string | null = null;
    #shopCode: string | null = null;

    constructor(googleAnalytics: GoogleAnalytics, tiktok: TiktokPixel) {
        this.#googleAnalytics = googleAnalytics;
        this.#tiktok = tiktok;
    }

    addPaymentInfo(totalCents: number): void {
        if (!this.currency) {
            return;
        }

        this.#log('addPaymentInfo', [this.eventId, this.shopCode, this.currency, totalCents]);
        this.#googleAnalytics.addPaymentInfo(this.eventId, this.shopCode, this.currency, totalCents);
        this.#tiktok.addPaymentInfo(this.eventId, this.shopCode);
    }

    addToCart(totalCents: number, product: SelectedProduct): void {
        if (!this.currency) {
            return;
        }

        this.#log('addToCart', [this.eventId, this.shopCode, this.currency, totalCents, product]);
        this.#googleAnalytics.addToCart(this.eventId, this.shopCode, this.currency, totalCents, product);
        this.#tiktok.addToCart(this.eventId, this.shopCode, this.currency, totalCents, product);
    }

    clickButton(buttonName: string): void {
        this.#log('clickButton', [this.eventId, this.shopCode, buttonName]);
        this.#googleAnalytics.clickButton(this.eventId, this.shopCode, buttonName);
        this.#tiktok.clickButton(this.eventId, this.shopCode, buttonName);
    }

    completePayment(totalCents: number, products: SelectedProduct[], discountCents: number, ticketServicePlusCostCents: number): void {
        if (!this.currency) {
            return;
        }

        this.#log('completePayment', [this.eventId, this.shopCode, this.currency, totalCents, products]);
        this.#googleAnalytics.completePayment(this.eventId, this.shopCode, this.currency, totalCents, products, discountCents, ticketServicePlusCostCents);
        this.#tiktok.completePayment(this.eventId, this.shopCode, this.currency, totalCents, products);
    }

    initiateCheckout(): void {
        this.#log('initiateCheckout', [this.eventId, this.shopCode]);
        this.#googleAnalytics.initiateCheckout(this.eventId, this.shopCode);
        this.#tiktok.initiateCheckout(this.eventId, this.shopCode);
    }

    placeAnOrder(totalCents: number, products: SelectedProduct[], discountCents: number, ticketServicePlusCostCents: number): void {
        if (!this.currency) {
            return;
        }

        this.#log('placeAnOrder', [this.eventId, this.shopCode, this.currency, totalCents, products, discountCents, ticketServicePlusCostCents]);
        this.#googleAnalytics.placeAnOrder(this.eventId, this.shopCode, this.currency, totalCents, products, discountCents, ticketServicePlusCostCents);
        this.#tiktok.placeAnOrder(this.eventId, this.shopCode, this.currency, totalCents, products, discountCents, ticketServicePlusCostCents);
    }

    removeFromCart(totalCents: number, product: SelectedProduct): void {
        if (!this.currency) {
            return;
        }

        this.#log('removeFromCart', [this.eventId, this.shopCode, this.currency, totalCents, product]);
    }

    #log(...data: any[]): void {
        // so that shop owners van see which events are sent.
        console.log('%c[tracking]', 'color: #059669', ...data);
    }
}
