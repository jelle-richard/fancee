import type { Currency } from '@fancee/data';
import type { TrackingInterface } from '~/data/tracking';

// noinspection DuplicatedCode
export class TiktokPixel implements TrackingInterface {
    addPaymentInfo(eventId: string | null, shopCode: string | null): void {
        ttq?.track('AddPaymentInfo', {
            content_id: eventId,
            content_name: shopCode
        });
    }

    addToCart(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, product: SelectedProduct): void {
        ttq?.track('AddToCart', {
            contents: [{
                content_id: product.id,
                content_name: product.name,
                quantity: product.quantity,
                price: Math.floor((product.priceCents + product.feeCents) * product.quantity / Math.pow(10, currency.decimals))
            }],
            content_id: eventId,
            content_name: shopCode,
            content_type: 'product',
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals))
        });
    }

    clickButton(eventId: string | null, shopCode: string | null, buttonName: string): void {
        ttq?.track('ClickButton', {
            content_id: eventId,
            content_name: shopCode,
            content_category: buttonName
        });
    }

    completePayment(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, products: SelectedProduct[]): void {
        ttq?.track('CompletePayment', {
            contents: products.map(p => ({
                content_id: p.id,
                content_name: p.name,
                quantity: p.quantity,
                price: Math.floor((p.priceCents + p.feeCents) * p.quantity / Math.pow(10, currency.decimals))
            })),
            content_id: eventId,
            content_name: shopCode,
            content_type: 'product',
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals))
        });
    }

    initiateCheckout(eventId: string | null, shopCode: string | null): void {
        ttq?.track('InitiateCheckout', {
            content_id: eventId,
            content_name: shopCode
        });
    }

    placeAnOrder(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, products: SelectedProduct[], discountCents: number, ticketServicePlusCostCents: number): void {
        const contents = products.map(p => ({
            content_id: p.id,
            content_name: p.name,
            quantity: p.quantity,
            price: Math.floor((p.priceCents + p.feeCents) * p.quantity / Math.pow(10, currency.decimals))
        }));

        if (discountCents > 0) {
            contents.push({
                content_id: 'discount-code',
                content_name: 'discount-code',
                quantity: 1,
                price: -Math.floor(discountCents / Math.pow(10, currency.decimals))
            });
        }

        if (ticketServicePlusCostCents > 0) {
            contents.push({
                content_id: 'ticket-warranty',
                content_name: 'ticket-warranty',
                quantity: products.reduce((curr, acc) => acc.quantity + curr, 0),
                price: Math.floor(ticketServicePlusCostCents / Math.pow(10, currency.decimals))
            });
        }

        ttq?.track('PlaceAnOrder', {
            contents,
            content_id: eventId,
            content_name: shopCode,
            content_type: 'product',
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals))
        });
    }

    removeFromCart(): void {
    }
}
