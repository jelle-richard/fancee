import type { Currency } from '@fancee/data';
import type { TrackingInterface } from '~/data/tracking';

const affiliation = 'WeAreFancee Ticket Shop';

// noinspection DuplicatedCode
export class GoogleAnalytics implements TrackingInterface {
    public addPaymentInfo(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number): void {
        gtag?.('event', 'add_payment_info', {
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals))
        });
    }

    public addToCart(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, product: SelectedProduct): void {
        gtag?.('event', 'add_to_cart', {
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals)),
            items: [{
                affiliation,
                item_id: product.id,
                item_name: product.name,
                quantity: product.quantity,
                price: Math.floor((product.priceCents + product.feeCents) * product.quantity / Math.pow(10, currency.decimals))
            }]
        });
    }

    public clickButton(eventId: string | null, shopCode: string | null, buttonName: string): void {
        gtag?.('event', 'button_click', {
            event_id: eventId,
            shop_code: shopCode,
            button_name: buttonName
        });
    }

    public completePayment(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, products: SelectedProduct[], discountCents: number, ticketServicePlusCostCents: number): void {
        const items = products.map(p => ({
            affiliation,
            item_id: p.id,
            item_name: p.name,
            quantity: p.quantity,
            price: Math.floor((p.priceCents + p.feeCents) * p.quantity / Math.pow(10, currency.decimals))
        }));

        if (discountCents > 0) {
            items.push({
                affiliation,
                item_id: 'discount-code',
                item_name: 'discount-code',
                quantity: 1,
                price: -Math.floor(discountCents / Math.pow(10, currency.decimals))
            });
        }

        if (ticketServicePlusCostCents > 0) {
            items.push({
                affiliation,
                item_id: 'ticket-warranty',
                item_name: 'ticket-warranty',
                quantity: 1,
                price: Math.floor(ticketServicePlusCostCents / Math.pow(10, currency.decimals))
            });
        }

        gtag?.('event', 'purchase', {
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals)),
            items
        });
    }

    public initiateCheckout(eventId: string | null, shopCode: string | null): void {
    }

    public placeAnOrder(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, products: SelectedProduct[], discountCents: number, ticketServicePlusCostCents: number): void {
        const items = products.map(p => ({
            affiliation,
            item_id: p.id,
            item_name: p.name,
            quantity: p.quantity,
            price: Math.floor((p.priceCents + p.feeCents) * p.quantity / Math.pow(10, currency.decimals))
        }));

        if (discountCents > 0) {
            items.push({
                affiliation,
                item_id: 'discount-code',
                item_name: 'discount-code',
                quantity: 1,
                price: -Math.floor(discountCents / Math.pow(10, currency.decimals))
            });
        }

        if (ticketServicePlusCostCents > 0) {
            items.push({
                affiliation,
                item_id: 'ticket-warranty',
                item_name: 'ticket-warranty',
                quantity: 1,
                price: Math.floor(ticketServicePlusCostCents / Math.pow(10, currency.decimals))
            });
        }

        gtag?.('event', 'begin_checkout', {
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals)),
            items
        });
    }

    public removeFromCart(eventId: string | null, shopCode: string | null, currency: Currency, totalCents: number, product: SelectedProduct): void {
        gtag?.('event', 'remove_from_cart', {
            currency: currency.shortCode,
            value: Math.floor(totalCents / Math.pow(10, currency.decimals)),
            items: [{
                affiliation,
                item_id: product.id,
                item_name: product.name,
                quantity: product.quantity,
                price: Math.floor((product.priceCents + product.feeCents) * product.quantity / Math.pow(10, currency.decimals))
            }]
        });
    }
}
