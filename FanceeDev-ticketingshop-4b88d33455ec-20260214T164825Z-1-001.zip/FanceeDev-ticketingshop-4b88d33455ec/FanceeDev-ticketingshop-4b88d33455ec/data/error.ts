import type { IconNames } from '@fancee/flux';

export type Notice = {
    readonly icon: IconNames;
    readonly message: string;
    readonly title?: string;
    readonly variant: NoticeVariant;
};

type NoticeVariant = 'info' | 'warning' | 'primary' | 'danger' | 'success' | 'gray';
