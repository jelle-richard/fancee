import type { AgendaOverview, ShopDetails } from '@fancee/data';
import type { InjectionKey } from '@vue/runtime-core';
import type { Ref } from 'vue';

export const SHOP_INJECTION: InjectionKey<Ref<ShopDetails>> = Symbol();
export const SHOP_CODE_INJECTION: InjectionKey<Ref<string>> = Symbol();
export const CAMPAIGN_CODE_INJECTION: InjectionKey<Ref<string>> = Symbol();
export const AGENDA_INJECTION: InjectionKey<Ref<AgendaOverview>> = Symbol();
export const AGENDA_ID_INJECTION: InjectionKey<Ref<string>> = Symbol();
