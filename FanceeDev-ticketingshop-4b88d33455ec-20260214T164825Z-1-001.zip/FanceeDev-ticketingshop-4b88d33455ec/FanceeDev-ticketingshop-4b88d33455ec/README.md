# Ticketing Shops

This repository contains the source code for the ticket shops of WeAreFancee Ticketing. Please
read the following instructions and checks in order to get started.

## ☝🏼 Requirements

- An installation of Node.js of at lease version 20.
- The pnpm package manager. To install this, follow "Install Pnpm" as described in this document.
- Both `FANCEE_NPM_AUTH_TOKEN` and `FONTAWESOME_NPM_AUTH_TOKEN` environment variables. The values
  can be found in Lastpass.
- WebStorm, in order to have our forced code style applied.

## 🚀 Development

- Run `pnpm install` to ensure that the correct dependencies are installed.
- Run `pnpm dev` to start the development server.
- Open `http://localhost:3000` in your browser and start working.

## ⑆ Git usage

Commit messages and branches must be in English.

### Branches

- `main` Contains the latest stable release and is the exact code that is running on the
  production environment.
- `staging` Contains the next stable release and is the exact code that is running on the
  staging environment.
- `develop` Contains the next staging release and is the exact code that is running on the
  development environment.
- `feat/*` New features should have their own feature branch. Once the feature is complete
  it should be merged in the `develop` branch.
- `fix/*` Bugfixes should have their own bugfix branch. Once the bug is fixed it should be
  merged in the `develop` branch.
- `hotfix/*` Critical bugs should have their own branch, based on the branch where the
  hotfix should be fixed. For example: When a critical bug is found on `main`, a hotfix
  branch based on `main` should be created. Once complete the hotfix should be merged
  into the branch it was based on.

### Commit messages

All commit messages should follow the following format: `<type>(<part?>)[<issue?>]: <message>`.

#### Examples

- feat(summary)[FAN-1234]: adds a discount field.
- fix(routing): fixes that users are not redirected after placing a costless order.

#### Allowed types

| Type     | Description                                                 |
|----------|-------------------------------------------------------------|
| feat     | when adding new features.                                   |
| fix      | when fixing bugs.                                           |
| docs     | when adding or changing documentation.                      |
| style    | when formatting of code has changed, but not functionality. |
| refactor | when the changed code is a refactor of some kind.           |
| test     | when adding or changing (unit) tests.                       |
| chore    | for all other types of commits.                             |

## 🎨 Code style

Code style is mainly forced by our `.editorconfig` file. Before commiting your work, please
perform `Refactor code` in WebStorm to ensure that the correct coding style is applied.

## ⭐️ Icons

This project uses the lovely icons from [Font Awesome](https://fontawesome.com). We have
a license for _Font Awesome Pro_, which means that we can use all their icons. To use an
icon, please do the following:

- Ensure that the icon is not already declared in `~/data/icons.ts`.
- Find the icon you want to use at https://fontawesome.com. Make sure that the icon has
  the classic regular style or is a brand icon.
- Copy the name of the icon, for example `fa-user`.
- Add the icon to one of the exports in `~/data/icons.ts` by using its camelCase name.
- Use the icon with the `<FluxIcon/>` component, the name of the icon is without the `fa-`.
  For example: `<FluxIcon variant="user"/>`

## ✅ Definition of Done

- The deliverable adheres to all the requirements of the Coding style.
- The deliverable follows the provided GIT branching structure.
- The deliverable branch is up-to-date with its origin/parent branch.
- The deliverable should be production ready and not contain: (console logs, todo comments
  and/or other development related code).
- The deliverable branch should be attached to a corresponding Jira issue and only contain
  the needed changes as stated in said issue.
- The deliverable has no type errors in the build.
- The deliverable has a PR in BitBucket which is connected to a Jira issue.
- The deliverable PR passed all merge checks.
- The deliverable branch should be deleted after the PR is merged.
- All new text has been translated in every language the dashboard offers.
