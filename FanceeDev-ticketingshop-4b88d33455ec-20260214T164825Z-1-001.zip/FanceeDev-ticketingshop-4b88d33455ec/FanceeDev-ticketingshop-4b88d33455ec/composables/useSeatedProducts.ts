import { SeatedProduct } from '@fancee/data';
import type { ComputedRef } from 'vue';

export function useSeatedProducts(): ComputedRef<SeatedProduct[]> {
    const shopRef = useShopInjection();

    return computed(() => {
        const shop = unref(shopRef);

        if (shop.seatedProducts) {
            return shop.seatedProducts;
        }

        return [];
    });
}
