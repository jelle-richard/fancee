export function useLocalStorage<T extends object>(key: string, initialValue: T): T {
    const state: T = reactive(getLocalStorageJson(key) ?? initialValue) as T;

    watch(state, newState => localStorage.setItem(key, JSON.stringify(newState)), {deep: true});

    return state;
}

function getLocalStorageJson<T extends object>(key: string): T | null {
    try {
        if (key in localStorage) {
            return JSON.parse(localStorage.getItem(key)!);
        }
    } catch (_) {
    }

    return null;
}
