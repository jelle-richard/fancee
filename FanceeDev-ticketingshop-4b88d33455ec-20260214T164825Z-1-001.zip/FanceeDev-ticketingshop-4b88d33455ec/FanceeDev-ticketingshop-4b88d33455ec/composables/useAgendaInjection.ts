import { type AgendaOverview } from '@fancee/data';
import type { Ref } from 'vue';
import { AGENDA_INJECTION } from '~/data';

export function useAgendaInjection(): Ref<AgendaOverview> {
    const agendaRef = inject(AGENDA_INJECTION);

    if (!agendaRef) {
        throw showError({
            statusCode: 500,
            statusMessage: 'No agenda injection was found in the current context.'
        });
    }

    return agendaRef;
}
