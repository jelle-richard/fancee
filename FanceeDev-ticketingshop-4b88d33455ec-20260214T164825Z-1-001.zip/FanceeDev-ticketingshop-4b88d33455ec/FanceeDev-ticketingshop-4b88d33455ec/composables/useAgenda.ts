import { AgendaService } from '@fancee/api';
import { type AgendaOverview } from '@fancee/data';
import type { ComputedRef, Ref } from 'vue';
import { AGENDA_ID_INJECTION, AGENDA_INJECTION } from '~/data';

export function useAgenda(): Ref<AgendaOverview> {
    const {getPublic: getAgenda} = useService(AgendaService);

    const agendaIdRef = useRouteParam('id') as ComputedRef<string>;

    const {data: agendaRef} = useServiceApi('agenda-overview', () => getAgenda(unref(agendaIdRef)), {
        watch: [agendaIdRef]
    });

    provide(AGENDA_INJECTION, agendaRef);
    provide(AGENDA_ID_INJECTION, agendaIdRef);

    return agendaRef;
}
