import type { Ref } from 'vue';
import { SHOP_CODE_INJECTION } from '~/data';

export function useShopCodeInjection(): Ref<string> {
    const shopCodeRef = inject(SHOP_CODE_INJECTION);

    if (!shopCodeRef) {
        throw showError({
            statusCode: 500,
            statusMessage: 'No shop code injection was found in the current context.'
        });
    }

    return shopCodeRef;
}
