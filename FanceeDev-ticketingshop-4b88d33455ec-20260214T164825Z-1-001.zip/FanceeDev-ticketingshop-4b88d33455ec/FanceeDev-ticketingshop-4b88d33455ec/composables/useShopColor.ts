import { ShopDetails } from '@fancee/data';
import type { Ref } from 'vue';

type Adjustments = {
    s?: number;
    l?: number;
};

type ColorKey = 'backdropColor'
    | 'backgroundColor'
    | 'primaryColor'
    | 'textColor';

export function useShopColor(key: ColorKey, adjustments?: Adjustments, opacity?: number, shopRef?: Ref<ShopDetails>): Ref<string | null> {
    shopRef ??= useShopInjection();

    return computed(() => {
        const design = unref(shopRef)?.design;

        if (!design) {
            return null;
        }

        const color = design[key] ?? null;

        if (!color || !adjustments) {
            return color;
        }

        let [h, s, l] = hexToHSL(color);

        if (adjustments.s) {
            s += s > 50 ? -adjustments.s : adjustments.s;
        }

        if (adjustments.l) {
            l += l > 25 ? -adjustments.l : adjustments.l;
        }

        if (opacity) {
            return `hsl(${h}deg ${s}% ${l}% / ${opacity})`;
        }

        return `hsl(${h}deg ${s}% ${l}%)`;
    });
}
