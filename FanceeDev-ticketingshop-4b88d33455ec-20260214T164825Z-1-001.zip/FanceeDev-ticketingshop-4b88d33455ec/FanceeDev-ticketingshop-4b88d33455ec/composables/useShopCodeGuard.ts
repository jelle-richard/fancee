export function useShopCodeGuard(): void {
    const router = useRouter();
    const shopCodeRef = useShopCodeInjection();
    const reserveStore = useReserveStore();

    onMounted(() => {
        if (unref(shopCodeRef) === reserveStore.shopCode) {
            return;
        }

        reserveStore.reset();
        router.push(`/${unref(shopCodeRef)}`).then();
    });
}
