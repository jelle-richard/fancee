import { HttpStatusCode, isRequestError } from '@fancee/client';
import type { Ref } from 'vue';
import type { Notice } from '~/data';

type _Fn = (...args: unknown[]) => Promise<unknown>;

const ERROR_MAP: Record<string, string> = {
    'FAN-89707': 'error.shop.insufficient_stock',
    'FAN-89708': 'error.shop.secure_code_invalid'
};

export function withErrorHandler<TFunc extends _Fn>(fn: TFunc, isLoadingRef: Ref<boolean>, noticeRef: Ref<Notice | null>): TFunc {
    const {t} = useI18n();

    function onError(notice: Notice): void {
        isLoadingRef.value = false;
        noticeRef.value = notice;
    }

    const hof = async (...args: Parameters<TFunc>) => {
        try {
            noticeRef.value = null;
            isLoadingRef.value = true;
            await fn(...args);
            isLoadingRef.value = false;
        } catch (err) {
            if (!isRequestError(err)) {
                if (err instanceof Error) {
                    return onError({
                        icon: 'circle-exclamation',
                        message: t('js_error', {message: err.message}),
                        variant: 'danger'
                    });
                }

                return onError({
                    icon: 'circle-exclamation',
                    message: t('unknown_error'),
                    variant: 'danger'
                });
            }

            switch (err.statusCode) {
                case HttpStatusCode.InternalServerError:
                    return onError({
                        icon: 'circle-exclamation',
                        message: t('internal_server_error'),
                        variant: 'danger'
                    });

                case HttpStatusCode.ServiceUnavailable:
                    return onError({
                        icon: 'circle-exclamation',
                        message: t('service_unavailable'),
                        variant: 'danger'
                    });

                default:
                    break;
            }

            const errorKeys = Object.keys(err.errors);

            if (errorKeys.length > 0) {
                const errorTranslationKey = ERROR_MAP[errorKeys[0]] ?? 'unknown';

                return onError({
                    icon: 'circle-exclamation',
                    message: t(errorTranslationKey),
                    variant: 'warning'
                });
            }

            return onError({
                icon: 'circle-exclamation',
                message: 'api error',
                variant: 'danger'
            });
        }
    };

    return hof as TFunc;
}
