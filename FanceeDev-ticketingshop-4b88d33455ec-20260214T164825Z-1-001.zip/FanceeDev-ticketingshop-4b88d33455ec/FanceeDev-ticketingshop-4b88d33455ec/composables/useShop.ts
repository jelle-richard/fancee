import { ShopService } from '@fancee/api';
import { ShopDetails } from '@fancee/data';
import type { ComputedRef, Ref } from 'vue';
import { SHOP_CODE_INJECTION, SHOP_INJECTION, CAMPAIGN_CODE_INJECTION } from '~/data';

export function useShop(): Ref<ShopDetails> {
    const {get: getShop} = useService(ShopService);

    const campaignCodeRef = useRouteQueryParam('campaignCode');
    const shopCodeRef = useRouteParam('code') as ComputedRef<string>;

    const {data: shopRef} = useServiceApi('shop-details', () => getShop(unref(shopCodeRef), unref(campaignCodeRef)), {
        watch: [campaignCodeRef, shopCodeRef]
    });

    provide(SHOP_INJECTION, shopRef);
    provide(SHOP_CODE_INJECTION, shopCodeRef);
    provide(CAMPAIGN_CODE_INJECTION, campaignCodeRef);

    return shopRef;
}
