import { AgendaOverview } from '@fancee/data';
import type { Ref } from 'vue';

type Adjustments = {
    saturation?: number;
    lightness?: number;
};

type ColorKey = 'backdropColor'
    | 'backgroundColor'
    | 'primaryColor'
    | 'textColor';

export function useAgendaDesignColor(key: ColorKey, adjustments?: Adjustments, opacity?: number, agendaRef?: Ref<AgendaOverview>): Ref<string | null> {
    agendaRef ??= useAgendaInjection();

    return computed(() => {
        const design = unref(agendaRef)?.design;

        if (!design) {
            return null;
        }

        const color = design[key] ?? null;

        if (!color || !adjustments) {
            return color;
        }

        let [hue, saturation, lightness] = hexToHSL(color);

        if (adjustments.saturation) {
            saturation += saturation > 50 ? -adjustments.saturation : adjustments.saturation;
        }

        if (adjustments.lightness) {
            lightness += lightness > 25 ? -adjustments.lightness : adjustments.lightness;
        }

        if (opacity) {
            return `hsl(${hue}deg ${saturation}% ${lightness}% / ${opacity})`;
        }

        return `hsl(${hue}deg ${saturation}% ${lightness}%)`;
    });
}
