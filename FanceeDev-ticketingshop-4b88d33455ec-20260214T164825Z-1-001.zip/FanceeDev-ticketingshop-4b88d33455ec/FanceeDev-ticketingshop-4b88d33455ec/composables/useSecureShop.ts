export const useSecureShop = defineStore('waf_ticketing_secure_shop', () => {
    const shopRef = useShopInjection();
    const secureCode = ref(null);

    const shouldAskSecureCode = computed(() => unref(shopRef).secured && !unref(secureCode));

    function setSecureCode(code: string): void {
        secureCode.value = code;
    }

    return {
        secureCode,
        shouldAskSecureCode,
        setSecureCode
    };
});
