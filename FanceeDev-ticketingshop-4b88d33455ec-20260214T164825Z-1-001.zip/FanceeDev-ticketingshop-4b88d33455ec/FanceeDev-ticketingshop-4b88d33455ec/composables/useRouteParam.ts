import type { ComputedRef } from 'vue';

type _Convert = (value?: string | string[]) => string | null;

const _defaultConvert: _Convert = value => value ? (Array.isArray(value) ? value[0] : value) : null;

export function useRouteParam(key: string, convert: _Convert = _defaultConvert): ComputedRef<string | null> {
    const route = useRoute();

    return computed(() => convert(route.params[key]));
}
