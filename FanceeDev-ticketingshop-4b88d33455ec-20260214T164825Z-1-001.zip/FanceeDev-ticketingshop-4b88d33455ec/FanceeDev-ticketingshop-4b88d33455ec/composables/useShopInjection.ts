import { ShopDetails } from '@fancee/data';
import type { Ref } from 'vue';
import { SHOP_INJECTION } from '~/data';

export function useShopInjection(): Ref<ShopDetails> {
    const shopRef = inject(SHOP_INJECTION);

    if (!shopRef) {
        throw showError({
            statusCode: 500,
            statusMessage: 'No shop injection was found in the current context.'
        });
    }

    return shopRef;
}
