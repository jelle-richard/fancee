import { ShopService } from '@fancee/api';
import { ProductType, ReservedProduct, SeatedProduct, ShopElementProduct } from '@fancee/data';

type ProductEntry = [quantity: number, seatLabels: string[]];

export const useCartStore = defineStore('waf_ticketing_cart', () => {
    const productsRef = useShopProducts();
    const seatedProductsRef = useSeatedProducts();
    const shopCodeRef = useShopCodeInjection();
    const campaignCodeRef = useCampaignCodeInjection();

    const {setReservation} = useReserveStore();
    const secureShopStore = useSecureShop();
    const {secureCode} = storeToRefs(secureShopStore);
    const {reserve: reserveApi} = useService(ShopService);

    const products = useLocalStorage<Record<string, ProductEntry>>('cart-products', {});

    const selectedProducts = computed<SelectedProduct[]>(() => Object
        .entries(products)
        .map<SelectedProduct | null>(([productId, [quantity, seatLabels]]) => {
            let product: ShopElementProduct | SeatedProduct | undefined;
            let type: 'ticket' | 'product';

            if (productId in unref(productsRef)) {
                product = unref(productsRef)[productId];
                type = product.type === ProductType.Ticket ? 'ticket' : 'product';
            } else {
                product = unref(seatedProductsRef).find(sp => sp.productId === productId);
                type = 'ticket';
            }

            if (!product) {
                return null;
            }

            return {
                id: productId,
                type: type,
                name: product.name,
                quantity: quantity,
                seatLabels: seatLabels.length === 0 ? undefined : seatLabels,
                feeCents: product.feeCents,
                priceCents: product.priceCents
            };
        })
        .filter<SelectedProduct>((sp: SelectedProduct | null): sp is SelectedProduct => !!sp));

    const hasSelectedProducts = computed(() => unref(selectedProducts).length > 0);

    async function reserve(): Promise<void> {
        if (!unref(shopCodeRef)) {
            throw new Error('There was no shop selected in the cart store.');
        }

        const products = unref(selectedProducts)
            .filter(sp => sp.quantity > 0)
            .map(sp => new ReservedProduct(sp.id, sp.quantity, sp.seatLabels ?? []));

        const {data} = await reserveApi(unref(shopCodeRef)!, products, unref(campaignCodeRef), unref(secureCode));

        setReservation(data.reference, data.secondsRemaining, unref(shopCodeRef)!);
    }

    function updateProduct(shop: string, productId: string, quantity: number): void {
        validate(shop);

        if (quantity <= 0) {
            delete products[productId];
            return;
        }

        products[productId] = [quantity, []];
    }

    function addSeat(shop: string, productId: string, seatLabel: string): void {
        validate(shop);

        if (productId in products) {
            const [quantity, seatLabels] = products[productId];

            if (seatLabels.includes(seatLabel)) {
                return;
            }

            products[productId] = [quantity + 1, [...seatLabels, seatLabel].toSorted((a, b) => a.localeCompare(b))];
        } else {
            products[productId] = [1, [seatLabel]];
        }
    }

    function removeSeat(shop: string, productId: string, seatLabel: string): void {
        validate(shop);

        if (!(productId in products)) {
            return;
        }

        const [quantity, seatLabels] = products[productId];

        if (quantity === 1) {
            delete products[productId];
            return;
        }

        products[productId] = [quantity - 1, seatLabels.filter(sl => sl !== seatLabel)];
    }

    function reset(): void {
        for (let productId in products) {
            delete products[productId];
        }
    }

    function validate(shop: string): void {
        if (shop === unref(shopCodeRef)) {
            return;
        }

        reset();
    }

    return {
        products,
        hasSelectedProducts,
        selectedProducts,

        reserve,
        reset,
        updateProduct,

        addSeat,
        removeSeat
    };
});
