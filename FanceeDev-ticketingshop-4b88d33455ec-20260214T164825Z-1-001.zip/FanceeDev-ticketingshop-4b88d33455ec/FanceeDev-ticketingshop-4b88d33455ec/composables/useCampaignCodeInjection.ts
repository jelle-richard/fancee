import type { Ref } from 'vue';
import { CAMPAIGN_CODE_INJECTION } from '~/data';

export function useCampaignCodeInjection(): Ref<string> {
    return inject(CAMPAIGN_CODE_INJECTION);
}
