import { ApplicableDiscount, ShopOrder } from '@fancee/data';
import { DateTime } from 'luxon';

export const useReserveStore = defineStore('waf_ticketing_reserve', () => {
    const discount = ref<ApplicableDiscount | null>(null);
    const expirationDate = ref<DateTime | null>(null);
    const reference = ref<string | null>(null);
    const order = ref<ShopOrder | null>(null);
    const shopCode = ref('');

    function createEmptyOrder(reservationReference: string): void {
        order.value = ShopOrder.default(reservationReference);
    }

    function reset(): void {
        discount.value = null;
        expirationDate.value = null;
        order.value = null;
        reference.value = null;
        shopCode.value = '';
    }

    function setDiscount(applicableDiscount: ApplicableDiscount | null): void {
        discount.value = applicableDiscount;
    }

    function setReservation(reservationReference: string, secondsRemaining: number, reservationShopCode: string): void {
        reference.value = reservationReference;
        shopCode.value = reservationShopCode;
        expirationDate.value = DateTime.now().plus({
            second: secondsRemaining - 1
        });

        createEmptyOrder(reservationReference);
        setDiscount(null);
    }

    return {
        discount,
        expirationDate,
        reference,
        order,
        shopCode,

        reset,
        setDiscount,
        setReservation
    };
});
