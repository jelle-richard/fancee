import { Tracking } from '~/data/tracking';

export function useTracking(withRefs: boolean = true): Tracking {
    const {$tracking} = useNuxtApp();

    if (withRefs) {
        const currencyRef = useCurrency();
        const shopRef = useShopInjection();
        const shopCodeRef = useShopCodeInjection();

        $tracking.currency = toRaw(unref(currencyRef));
        $tracking.eventId = unref(shopRef).event.id;
        $tracking.shopCode = unref(shopCodeRef);
    }

    return $tracking;
}
