export const useAppStore = defineStore('waf_app_store', () => {
    const isGoogleMapsReady = ref(false);

    function setGoogleMapsReady(): void {
        isGoogleMapsReady.value = true;
    }

    return {
        isGoogleMapsReady,

        setGoogleMapsReady
    };
});
