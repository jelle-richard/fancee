import { PaidByType } from '@fancee/data';
import type { ComputedRef } from 'vue';

export function useShopTotals(): UseShopTotals {
    const cartStore = useCartStore();
    const reserveStore = useReserveStore();
    const shopRef = useShopInjection();

    const discountTotal = computed(() => {
        const d = reserveStore.discount;
        const pt = unref(paymentTotal);
        const st = unref(subTotal);

        if (!d || !st) {
            return 0;
        }

        const {amountPercentual, amountStaticCents} = d;
        const percentual = (amountPercentual ?? 0) / 100 * (st + pt);

        return percentual + (amountStaticCents ?? 0);
    });

    const feeTotal = computed(() => {
        return cartStore.selectedProducts
            .filter(sp => sp.quantity > 0)
            .map(sp => sp.quantity * sp.feeCents)
            .reduce((curr, acc) => curr + acc, 0);
    });

    const paymentTotal = computed(() => {
        const o = reserveStore.order;
        const st = unref(subTotal);

        if (!o || !o.paymentMethodId) {
            return 0;
        }

        const pm = unref(shopRef)?.event.paymentMethods.find(pm => pm.id === o.paymentMethodId);

        if (!pm || pm.paidBy === PaidByType.Organization) {
            return 0;
        }

        const feePercent = (pm.feePercent ?? 0) / 100 * st;
        const feeStaticCents = pm.feeStaticCents ?? 0;

        return feePercent + feeStaticCents;
    });

    const subTotal = computed(() => {
        const subTotal = cartStore.selectedProducts
            .map(sp => sp.quantity * (sp.priceCents + sp.feeCents))
            .reduce((curr, acc) => curr + acc, 0);

        return subTotal + unref(ticketServicePlusTotal);
    });

    const ticketServicePlusTotal = computed(() => {
        const o = reserveStore.order;

        if (o?.enabledTicketServicePlus) {
            const ticketAmount = cartStore.selectedProducts
                .filter(sp => sp.type === 'ticket')
                .map(sp => sp.quantity)
                .reduce((curr, acc) => curr + acc, 0);

            return ticketAmount * (unref(shopRef)?.platformTicketServicePlusCostCents ?? 0);
        }

        return 0;
    });

    const total = computed(() => unref(subTotal) + unref(paymentTotal) - unref(discountTotal));

    return {
        discountTotal,
        feeTotal,
        paymentTotal,
        subTotal,
        ticketServicePlusTotal,
        total
    };
}

interface UseShopTotals {
    readonly discountTotal: ComputedRef<number>;
    readonly feeTotal: ComputedRef<number>;
    readonly paymentTotal: ComputedRef<number>;
    readonly subTotal: ComputedRef<number>;
    readonly ticketServicePlusTotal: ComputedRef<number>;
    readonly total: ComputedRef<number>;
}
