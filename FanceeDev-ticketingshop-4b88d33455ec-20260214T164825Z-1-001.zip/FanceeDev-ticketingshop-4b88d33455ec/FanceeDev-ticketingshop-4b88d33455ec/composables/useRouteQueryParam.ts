import type { ComputedRef } from 'vue';
import type { LocationQueryValue } from 'vue-router';

type _Convert = (value?: LocationQueryValue | LocationQueryValue[]) => string | null;

const _defaultConvert: _Convert = value => value ? (Array.isArray(value) ? value[0] : value) : null;

export function useRouteQueryParam(key: string, convert: _Convert = _defaultConvert): ComputedRef<string | null> {
    const route = useRoute();

    return computed(() => convert(route.query[key]));
}
