import { BaseResponse, isRequestError } from '@fancee/client';
import type { AsyncData, AsyncDataOptions, NuxtError } from '#app';

export function useServiceApi<T>(key: string, handler: () => Promise<BaseResponse<T>>, options: AsyncDataOptions<T> = {}): AsyncData<T, NuxtError> {
    return useAsyncData<T>(key, () => handler()
        .then(r => toRaw(r.data))
        .catch(err => {
            if (isRequestError(err)) {
                let message = err.message;
                let errorMessages = Object.entries(err.errors)
                    .map(([, messages]) => messages
                        .map(message => message.endsWith('.') ? message : `${message}.`)
                        .join(' '));

                if (errorMessages.length > 0) {
                    message = errorMessages.join(' - ');
                }

                throw showError({
                    message: message,
                    statusCode: err.statusCode
                });
            }

            throw showError(err);
        }), options) as AsyncData<T, NuxtError>;
}
