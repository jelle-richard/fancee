import { ShopElement, ShopElementProduct } from '@fancee/data';
import type { ComputedRef } from 'vue';

export function useShopProducts(): ComputedRef<Record<string, ShopElementProduct>> {
    const shopRef = useShopInjection();

    return computed(() => {
        const elements = unref(shopRef)?.elements ?? [];
        const products: Record<string, ShopElementProduct> = {};

        for (const element of elements) {
            if (ShopElement.isAccordion(element)) {
                const accordionProducts = element.elements.filter(ShopElement.isProduct);

                for (const product of accordionProducts) {
                    products[product.id] = product;
                }
            } else if (ShopElement.isProduct(element)) {
                products[element.id] = element;
            }
        }

        return products;
    });
}
