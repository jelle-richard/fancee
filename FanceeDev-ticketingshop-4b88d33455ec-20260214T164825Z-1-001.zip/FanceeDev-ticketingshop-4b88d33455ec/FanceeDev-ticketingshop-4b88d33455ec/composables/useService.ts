import type { BaseService } from '@fancee/client';

type _ServiceClass<T extends BaseService> = {
    new(): T;
};

export function useService<T extends BaseService>(service: _ServiceClass<T>): T {
    const instance: T = new service;
    const methods = Object.getOwnPropertyNames(service.prototype)
        .filter(m => m !== 'constructor');

    const functions = {};

    for (const method of methods) {
        functions[method] = (async function (...args: unknown[]): Promise<unknown> {
            return await instance[method](...args);
        }).bind(instance);
    }

    return functions as T;
}
