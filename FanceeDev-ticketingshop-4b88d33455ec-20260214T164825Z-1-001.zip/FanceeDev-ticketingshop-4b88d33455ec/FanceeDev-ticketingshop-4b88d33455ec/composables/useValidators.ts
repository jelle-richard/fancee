import type { ValidationRuleWithParams } from '@vuelidate/core';
import { alpha, alphaNum, and, between, createI18nMessage, decimal, email, integer, ipAddress, macAddress, maxLength, maxValue, minLength, minValue, not, numeric, or, required, requiredIf, requiredUnless, sameAs, url } from '@vuelidate/validators';
import { DateTime } from 'luxon';

export function useValidators() {
    const {t} = useI18n();
    const withI18n = createI18nMessage({t});

    return {
        required: withI18n(required),
        requiredIf: withI18n(requiredIf, {withArguments: true}),
        requiredUnless: withI18n(requiredUnless, {withArguments: true}),
        maxLength: withI18n(maxLength, {withArguments: true}),
        minLength: withI18n(minLength, {withArguments: true}),
        maxValue: withI18n(maxValue, {withArguments: true}),
        minValue: withI18n(minValue, {withArguments: true}),
        between: withI18n(between, {withArguments: true}),
        alpha: withI18n(alpha),
        alphaNum: withI18n(alphaNum),
        decimal: withI18n(decimal),
        email: withI18n(email),
        integer: withI18n(integer),
        ipAddress: withI18n(ipAddress),
        numeric: withI18n(numeric),
        macAddress: withI18n(macAddress, {withArguments: true}),
        sameAs: withI18n(sameAs, {withArguments: true}),
        url: withI18n(url),
        and: withI18n(and, {withArguments: true}),
        not: withI18n(not, {withArguments: true}),
        or: withI18n(or, {withArguments: true}),
        notTooOld: withI18n(notTooOld, {withArguments: true}),
        oldEnoughAt: withI18n(oldEnoughAt, {withArguments: true})
    };
}

function notTooOld(): ValidationRuleWithParams<{}> {
    return {
        $message: (): string => 'validations.notTooOld',
        $params: {},
        $validator: (value: unknown) => {
            if (!DateTime.isDateTime(value)) {
                return true;
            }

            return Math.abs(value.diffNow().as('years')) <= 120;
        }
    };
}

function oldEnoughAt(date: DateTime, minAge: number): ValidationRuleWithParams<{ date: DateTime; minAge: number; }> {
    return {
        $message: (): string => 'validations.oldEnoughAt',
        $params: {date, minAge},
        $validator: (value: unknown) => {
            if (!DateTime.isDateTime(value)) {
                return true;
            }

            let age = date.year - value.year;
            let m = date.month - value.month;

            if (m < 0 || (m === 0 && date.day < value.day)) {
                --age;
            }

            return age >= minAge;
        }
    };
}
