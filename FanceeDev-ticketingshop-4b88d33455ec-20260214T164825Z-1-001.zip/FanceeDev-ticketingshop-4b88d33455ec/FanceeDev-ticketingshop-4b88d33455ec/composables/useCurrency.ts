import { Currency } from '@fancee/data';
import type { ComputedRef } from 'vue';

export function useCurrency(): ComputedRef<Currency> {
    const shopRef = useShopInjection();

    return computed(() => unref(shopRef)?.event.currency ?? new Currency('Unknown', 'U', 'UNK', 2));
}
