export {}

export * from '@types/google.maps';

declare global {
    type SelectedProduct = {
        readonly type: 'ticket' | 'product';
        readonly id: string;
        readonly name: string;
        readonly feeCents: number;
        readonly priceCents: number;
        readonly quantity: number;
        readonly seatLabels?: string[];
    };
}

declare global {
    let gtag: GTag | undefined;
    let ttq: TTQ | undefined;
}

interface GTag {
    (type: 'event', eventName: 'add_payment_info', props: {
        currency: string;
        value: number;
    }): void;

    (type: 'event', eventName: 'add_to_cart', props: {
        currency: string;
        value: number;
        items: {
            affiliation: string;
            item_id: string;
            item_name: string;
            price: number;
            quantity: number;
        }[];
    }): void;

    (type: 'event', eventName: 'begin_checkout', props: {
        currency: string;
        value: number;
        items: {
            affiliation: string;
            item_id: string;
            item_name: string;
            price: number;
            quantity: number;
        }[];
    }): void;

    (type: 'event', eventName: 'button_click', props: {
        event_id: string | null;
        shop_code: string | null;
        button_name: string;
    }): void;

    (type: 'event', eventName: 'purchase', props: {
        currency: string;
        value: number;
        items: {
            affiliation: string;
            item_id: string;
            item_name: string;
            price: number;
            quantity: number;
        }[];
    }): void;

    (type: 'event', eventName: 'remove_from_cart', props: {
        currency: string;
        value: number;
        items: {
            affiliation: string;
            item_id: string;
            item_name: string;
            price: number;
            quantity: number;
        }[];
    }): void;
}

interface TTQ {
    track(type: 'AddPaymentInfo', props: {
        content_id: string | null;
        content_name: string | null;
    }): void;

    track(type: 'AddToCart', props: {
        contents: {
            content_id: string;
            content_name: string;
            quantity: number;
            price: number;
        }[];
        content_id: string | null;
        content_name: string | null;
        content_type: 'product';
        currency: string;
        value: number;
    }): void;

    track(type: 'ClickButton', props: {
        content_id: string | null;
        content_name: string | null;
        content_category: string;
    }): void;

    track(type: 'CompletePayment', props: {
        contents: {
            content_id: string;
            content_name: string;
            quantity: number;
            price: number;
        }[];
        content_id: string | null;
        content_name: string | null;
        content_type: 'product';
        currency: string;
        value: number;
    }): void;

    track(type: 'InitiateCheckout', props: {
        content_id: string | null;
        content_name: string | null;
    }): void;

    track(type: 'PlaceAnOrder', props: {
        contents: {
            content_id: string;
            content_name: string;
            quantity: number;
            price: number;
        }[];
        content_id: string | null;
        content_name: string | null;
        content_type: 'product';
        currency: string;
        value: number;
    }): void;
}
