<template>
    <FluxRoot v-if="error">
        <template v-if="error.statusCode === HttpStatusCode.BadRequest || error.statusCode === HttpStatusCode.Forbidden">
            <Head>
                <Title>{{ t('not_active.title') }}</Title>
            </Head>

            <IllustrationPage
                :asset-url="notActiveSvg"
                :title="t('not_active.title')"
                :content="t('not_active.content')"
                :info="error.message"/>
        </template>

        <template v-else-if="error.statusCode === HttpStatusCode.NotFound">
            <Head>
                <Title>{{ t('not_found.title') }}</Title>
            </Head>

            <IllustrationPage
                :asset-url="nothingHereSvg"
                :title="t('not_found.title')"
                :content="t('not_found.content')"/>
        </template>

        <template v-else-if="error.statusCode === HttpStatusCode.BadGateway || error.statusCode === HttpStatusCode.ServiceUnavailable">
            <Head>
                <Title>{{ t('unavailable.title') }}</Title>
            </Head>

            <IllustrationPage
                :asset-url="notActiveSvg"
                :title="t('unavailable.title')"
                :content="t('unavailable.content')"/>
        </template>

        <template v-else>
            <IllustrationPage
                :asset-url="notActiveSvg"
                title="Internal Exception"
                :content="error.message">
                <div
                    class="error-stack"
                    v-html="error.stack"/>
            </IllustrationPage>
        </template>
    </FluxRoot>
</template>

<script
    lang="ts"
    setup>
    import { HttpStatusCode } from '@fancee/client';
    import { FluxRoot } from '@fancee/flux';
    import type { NuxtError } from '#app';
    import type { Ref } from 'vue';
    import notActiveSvg from '~/assets/not-active.svg?url';
    import nothingHereSvg from '~/assets/nothing-here.svg?url';

    const {app: {baseURL}} = useRuntimeConfig();

    defineOptions({
        inheritAttrs: false
    });

    useHead({
        link: [
            {rel: 'icon', type: 'image/x-icon', href: `${baseURL === '/' ? '' : baseURL}/favicon.ico`},
            {rel: 'icon', type: 'image/svg+xml', href: `${baseURL === '/' ? '' : baseURL}/favicon.svg`},
            {rel: 'stylesheet', href: 'https://font.bmcdn.nl/css2?family=manrope-variable'}
        ]
    });

    useSeoMeta({
        robots: 'noindex, nofollow'
    });

    const {t} = useI18n();
    const error = useError() as Ref<NuxtError>;
</script>

<style
    lang="scss"
    scoped>
    .error-stack {
        max-width: 100dvw;
        margin-top: 30px;
        padding-left: 30px;
        padding-right: 30px;
        font-size: 12px;
        overflow: auto;
    }
</style>

<i18n lang="yaml">
en:
    not_active:
        title: "Not available"
        content: "This shop is currently not available. Please check back later."

    not_found:
        title: "Not found"
        content: "No shop was found on this link."

    unavailable:
        title: "Unavailable"
        content: "The shop is momentarily unavailable due to system maintenance, please check back at a later stage."

nl:
    not_active:
        title: "Niet beschikbaar"
        content: "Deze shop is op dit moment niet beschikbaar. Probeer het later nog eens."

    not_found:
        title: "Niet gevonden"
        content: "Er is geen shop gevonden op de deze link."

    unavailable:
        title: "Niet beschikbaar"
        content: "De shop is tijdelijk niet beschikbaar vanwege systeemonderhoud, kom later terug."

de:
    not_active:
        title: "Nicht verfügbar"
        content: "Diese Shop ist im Moment nicht verfügbar. Bitte versuchen Sie es später erneut."

    not_found:
        title: "Nicht gefunden"
        content: "Es wurde keine Shop über diesen Link gefunden."

    unavailable:
        title: "Nicht verfügbar"
        content: "Der Shop ist vorübergehend aufgrund von Wartungsarbeiten nicht verfügbar. Bitte versuchen Sie es später erneut."


fr:
    not_active:
        title: "Indisponible"
        content: "Cette boutique n'est actuellement pas disponible. Veuillez réessayer ultérieurement."

    not_found:
        title: "Non trouvé"
        content: "Aucune boutique n'a été trouvée via ce lien."

    unavailable:
        title: "Indisponible"
        content: "La boutique est temporairement indisponible en raison de travaux de maintenance. Revenez plus tard."
</i18n>
