import { IssuedNormalProduct, IssuedTicket, Media } from '@/dto';
import { ProductType } from '@/enum';

export abstract class IssuedProduct {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get productId(): string {
        return this.#productId;
    }

    set productId(value: string) {
        this.#productId = value;
    }

    get orderId(): string {
        return this.#orderId;
    }

    set orderId(value: string) {
        this.#orderId = value;
    }

    get type(): ProductType {
        return this.#type;
    }

    set type(value: ProductType) {
        this.#type = value;
    }

    get quantity(): number {
        return this.#quantity;
    }

    set quantity(value: number) {
        this.#quantity = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get media(): Media | null {
        return this.#media;
    }

    set media(value: Media | null) {
        this.#media = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    get costCents(): number {
        return this.#costCents;
    }

    set costCents(value: number) {
        this.#costCents = value;
    }

    #id: string;
    #productId: string;
    #orderId: string;
    #type: ProductType;
    #quantity: number;
    #name: string;
    #media: Media | null;
    #productFeeCents: number;
    #costCents: number;

    protected constructor(id: string, productId: string, orderId: string, type: ProductType, quantity: number, name: string, media: Media | null, productFeeCents: number, costCents: number) {
        this.#id = id;
        this.#productId = productId;
        this.#orderId = orderId;
        this.#type = type;
        this.#quantity = quantity;
        this.#name = name;
        this.#media = media;
        this.#productFeeCents = productFeeCents;
        this.#costCents = costCents;
    }

    public static isProduct(product: IssuedProduct): product is IssuedNormalProduct {
        return product.type === ProductType.Product;
    }

    public static isTicket(product: IssuedProduct): product is IssuedTicket {
        return product.type === ProductType.Ticket;
    }
}
