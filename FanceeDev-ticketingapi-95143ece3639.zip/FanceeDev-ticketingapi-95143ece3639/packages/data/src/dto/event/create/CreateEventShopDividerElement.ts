import { Dto } from '@fancee/client';
import { CreateEventShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class CreateEventShopDividerElement extends CreateEventShopElement {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    #name: string;

    constructor(name: string) {
        super(ShopElementKind.Divider);
        this.#name = name;
    }
}
