import { Dto } from '@fancee/client';
import { CreateEventShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class CreateEventShopExternalLinkElement extends CreateEventShopElement {
    get link(): string {
        return this.#link;
    }

    set link(value: string) {
        this.#link = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    #link: string;
    #name: string;

    constructor(link: string, name: string) {
        super(ShopElementKind.ExternalLink);
        this.#link = link;
        this.#name = name;
    }
}
