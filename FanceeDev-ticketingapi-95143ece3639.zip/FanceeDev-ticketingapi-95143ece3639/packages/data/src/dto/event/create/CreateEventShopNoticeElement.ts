import { Dto } from '@fancee/client';
import { CreateEventShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';
import { ColorType } from '@/type';

@Dto
export class CreateEventShopNoticeElement extends CreateEventShopElement {
    get content(): string {
        return this.#content;
    }

    set content(value: string) {
        this.#content = value;
    }

    get variant(): ColorType {
        return this.#variant;
    }

    set variant(value: ColorType) {
        this.#variant = value;
    }

    #content: string;
    #variant: ColorType;

    constructor(content: string, variant: ColorType) {
        super(ShopElementKind.Notice);
        this.#content = content;
        this.#variant = variant;
    }
}
