import { Dto } from '@fancee/client';
import { CreateEventShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class CreateEventShopTextBlockElement extends CreateEventShopElement {
    get text(): string {
        return this.#text;
    }

    set text(value: string) {
        this.#text = value;
    }

    get title(): string {
        return this.#title;
    }

    set title(value: string) {
        this.#title = value;
    }

    #text: string;
    #title: string;

    constructor(text: string, title: string) {
        super(ShopElementKind.TextBlock);
        this.#text = text;
        this.#title = title;
    }
}
