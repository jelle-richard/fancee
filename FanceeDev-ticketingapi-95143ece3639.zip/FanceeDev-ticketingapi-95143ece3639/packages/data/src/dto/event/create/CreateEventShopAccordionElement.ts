import { Dto } from '@fancee/client';
import { CreateEventShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class CreateEventShopAccordionElement extends CreateEventShopElement {
    get elements(): CreateEventShopElement[] {
        return this.#elements;
    }

    set elements(value: CreateEventShopElement[]) {
        this.#elements = value;
    }

    get icon(): string {
        return this.#icon;
    }

    set icon(value: string) {
        this.#icon = value;
    }

    get opened(): boolean {
        return this.#opened;
    }

    set opened(value: boolean) {
        this.#opened = value;
    }

    get title(): string {
        return this.#title;
    }

    set title(value: string) {
        this.#title = value;
    }

    #elements: CreateEventShopElement[];
    #icon: string;
    #opened: boolean;
    #title: string;

    constructor(elements: CreateEventShopElement[], icon: string, opened: boolean, title: string) {
        super(ShopElementKind.Accordion);
        this.#elements = elements;
        this.#icon = icon;
        this.#opened = opened;
        this.#title = title;
    }
}
