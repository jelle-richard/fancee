import { Dto } from '@fancee/client';
import { TicketDesignElement } from '@/dto';
import { generateUuidV4 } from '@/util';

@Dto
export class TicketDesign {
    get internalId(): string {
        return this.#internalId;
    }

    get elements(): TicketDesignElement[] {
        return this.#elements;
    }

    set elements(value: TicketDesignElement[]) {
        this.#elements = value;
    }

    get ticketIds(): string[] {
        return this.#ticketIds;
    }

    set ticketIds(value: string[]) {
        this.#ticketIds = value;
    }

    readonly #internalId: string;
    #elements: TicketDesignElement[];
    #ticketIds: string[];

    constructor(elements: TicketDesignElement[], ticketIds: string[]) {
        this.#internalId = generateUuidV4();
        this.#elements = elements;
        this.#ticketIds = ticketIds;
    }
}
