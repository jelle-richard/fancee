import { Dto } from '@fancee/client';
import { DateTimeSpan, EventProduct, Media } from '@/dto';
import { ProductType, SalesFlow } from '@/enum';

@Dto
export class EventNormalProduct extends EventProduct {
    constructor(id: string, name: string, description: string, isSharedCapacityEligible: boolean, markSoldOutWhenSaleSpanExpired: boolean, maximumPurchasePerCustomer: number, maximumPurchasePerOrder: number, media: Media[], packQuantity: number, priceCents: number | null, feeCents: number | null, salesFlow: SalesFlow, saleSpan: DateTimeSpan, stock: number, type: ProductType, waveLinkedProductId: string | null, deletable: boolean, hasReservationsOrSales: boolean) {
        super(id, name, description, isSharedCapacityEligible, markSoldOutWhenSaleSpanExpired, maximumPurchasePerCustomer, maximumPurchasePerOrder, media, packQuantity, priceCents, feeCents, salesFlow, saleSpan, stock, type, waveLinkedProductId, deletable, hasReservationsOrSales);
    }
}
