import { TicketDesignElementKind } from '@/enum';
import { TicketDesignMediaElement, TicketDesignQrElement, TicketDesignUpcomingEventsElement } from '@/dto';
import { generateUuidV4 } from '@/util';

export abstract class TicketDesignElement {
    get internalId(): string {
        return this.#internalId;
    }

    get kind(): TicketDesignElementKind {
        return this.#kind;
    }

    get column(): number {
        return this.#column;
    }

    set column(value: number) {
        this.#column = value;
    }

    get columnSpan(): number {
        return this.#columnSpan;
    }

    set columnSpan(value: number) {
        this.#columnSpan = value;
    }

    get row(): number {
        return this.#row;
    }

    set row(value: number) {
        this.#row = value;
    }

    get rowSpan(): number {
        return this.#rowSpan;
    }

    set rowSpan(value: number) {
        this.#rowSpan = value;
    }

    readonly #internalId: string;
    readonly #kind: TicketDesignElementKind;
    #column: number;
    #columnSpan: number;
    #row: number;
    #rowSpan: number;

    protected constructor(kind: TicketDesignElementKind, column: number = 1, columnSpan: number = 1, row: number = 1, rowSpan: number = 1) {
        this.#internalId = generateUuidV4();
        this.#kind = kind;
        this.#column = column;
        this.#columnSpan = columnSpan;
        this.#row = row;
        this.#rowSpan = rowSpan;
    }

    public static isMedia(element: TicketDesignElement): element is TicketDesignMediaElement {
        return element.kind === TicketDesignElementKind.Media;
    }

    public static isQr(element: TicketDesignElement): element is TicketDesignQrElement {
        return element.kind === TicketDesignElementKind.Qr;
    }

    public static isUpcomingEvents(element: TicketDesignElement): element is TicketDesignUpcomingEventsElement {
        return element.kind === TicketDesignElementKind.UpcomingEvents;
    }
}
