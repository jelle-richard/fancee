import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class EventProductSummary {
    get id(): string {
        return this.#id;
    }

    get name(): string {
        return this.#name;
    }

    get media(): Media {
        return this.#media;
    }

    get shops(): string[] {
        return this.#shops;
    }

    readonly #id: string;
    readonly #name: string;
    readonly #media: Media;
    readonly #shops: string[];

    constructor(id: string, name: string, media: Media, shops: string[]) {
        this.#id = id;
        this.#name = name;
        this.#media = media;
        this.#shops = shops;
    }
}
