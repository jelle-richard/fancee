import { DateTimeSpan, EventNormalProduct, EventTicketProduct, Media } from '@/dto';
import { ProductType, SalesFlow } from '@/enum';

export abstract class EventProduct {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get isSharedCapacityEligible(): boolean {
        return this.#isSharedCapacityEligible;
    }

    set isSharedCapacityEligible(value: boolean) {
        this.#isSharedCapacityEligible = value;
    }

    get markSoldOutWhenSaleSpanExpired(): boolean {
        return this.#markSoldOutWhenSaleSpanExpired;
    }

    set markSoldOutWhenSaleSpanExpired(value: boolean) {
        this.#markSoldOutWhenSaleSpanExpired = value;
    }

    get maximumPurchasePerCustomer(): number {
        return this.#maximumPurchasePerCustomer;
    }

    set maximumPurchasePerCustomer(value: number) {
        this.#maximumPurchasePerCustomer = value;
    }

    get maximumPurchasePerOrder(): number {
        return this.#maximumPurchasePerOrder;
    }

    set maximumPurchasePerOrder(value: number) {
        this.#maximumPurchasePerOrder = value;
    }

    get media(): Media[] {
        return this.#media;
    }

    set media(value: Media[]) {
        this.#media = value;
    }

    get packQuantity(): number {
        return this.#packQuantity;
    }

    set packQuantity(value: number) {
        this.#packQuantity = value;
    }

    get priceCents(): number | null {
        return this.#priceCents;
    }

    set priceCents(value: number | null) {
        this.#priceCents = value;
    }

    get feeCents(): number | null {
        return this.#feeCents;
    }

    set feeCents(value: number | null) {
        this.#feeCents = value;
    }

    get salesFlow(): SalesFlow {
        return this.#salesFlow;
    }

    set salesFlow(value: SalesFlow) {
        this.#salesFlow = value;
    }

    get saleSpan(): DateTimeSpan {
        return this.#saleSpan;
    }

    set saleSpan(value: DateTimeSpan) {
        this.#saleSpan = value;
    }

    get stock(): number {
        return this.#stock;
    }

    set stock(value: number) {
        this.#stock = value;
    }

    get type(): ProductType {
        return this.#type;
    }

    set type(value: ProductType) {
        this.#type = value;
    }

    get waveLinkedProductId(): string | null {
        return this.#waveLinkedProductId;
    }

    set waveLinkedProductId(value: string | null) {
        this.#waveLinkedProductId = value;
    }

    get deletable(): boolean {
        return this.#deletable;
    }

    set deletable(value: boolean) {
        this.#deletable = value;
    }

    get hasReservationsOrSales(): boolean {
        return this.#hasReservationsOrSales;
    }

    set hasReservationsOrSales(value: boolean) {
        this.#hasReservationsOrSales = value;
    }

    #id: string;
    #name: string;
    #description: string;
    #isSharedCapacityEligible: boolean;
    #markSoldOutWhenSaleSpanExpired: boolean;
    #maximumPurchasePerCustomer: number;
    #maximumPurchasePerOrder: number;
    #media: Media[];
    #packQuantity: number;
    #priceCents: number | null;
    #feeCents: number | null;
    #salesFlow: SalesFlow;
    #saleSpan: DateTimeSpan;
    #stock: number;
    #type: ProductType;
    #waveLinkedProductId: string | null;
    #deletable: boolean;
    #hasReservationsOrSales: boolean;

    protected constructor(id: string, name: string, description: string, isSharedCapacityEligible: boolean, markSoldOutWhenSaleSpanExpired: boolean, maximumPurchasePerCustomer: number, maximumPurchasePerOrder: number, media: Media[], packQuantity: number, priceCents: number | null, feeCents: number | null, salesFlow: SalesFlow, saleSpan: DateTimeSpan, stock: number, type: ProductType, waveLinkedProductId: string | null, deletable: boolean, hasReservationsOrSales: boolean) {
        this.#id = id;
        this.#name = name;
        this.#description = description;
        this.#isSharedCapacityEligible = isSharedCapacityEligible;
        this.#markSoldOutWhenSaleSpanExpired = markSoldOutWhenSaleSpanExpired;
        this.#maximumPurchasePerCustomer = maximumPurchasePerCustomer;
        this.#maximumPurchasePerOrder = maximumPurchasePerOrder;
        this.#media = media;
        this.#packQuantity = packQuantity;
        this.#priceCents = priceCents;
        this.#feeCents = feeCents;
        this.#salesFlow = salesFlow;
        this.#saleSpan = saleSpan;
        this.#stock = stock;
        this.#type = type;
        this.#waveLinkedProductId = waveLinkedProductId;
        this.#deletable = deletable;
        this.#hasReservationsOrSales = hasReservationsOrSales;
    }

    public static isProduct(product: EventProduct): product is EventNormalProduct {
        return product.type === ProductType.Product;
    }

    public static isTicket(product: EventProduct): product is EventTicketProduct {
        return product.type === ProductType.Ticket;
    }

    public static isSeatedTicket(product: EventProduct): product is EventTicketProduct {
        return product.type === ProductType.SeatedTicket;
    }
}
