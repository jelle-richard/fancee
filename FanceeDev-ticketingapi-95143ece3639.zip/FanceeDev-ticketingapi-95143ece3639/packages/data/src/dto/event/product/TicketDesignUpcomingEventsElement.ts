import { Dto } from '@fancee/client';
import { TicketDesignElement } from '@/dto';
import { TicketDesignElementKind } from '@/enum';

@Dto
export class TicketDesignUpcomingEventsElement extends TicketDesignElement {
    get amount(): number {
        return this.#amount;
    }

    set amount(value: number) {
        this.#amount = value;
    }

    #amount: number;

    constructor(amount: number, column: number = 1, columnSpan: number = 1, row: number = 1, rowSpan: number = 1) {
        super(TicketDesignElementKind.UpcomingEvents, column, columnSpan, row, rowSpan);
        this.#amount = amount;
    }
}
