import { Dto } from '@fancee/client';
import { DateTimeSpan, EventProduct, Media, TicketOptions } from '@/dto';
import { ProductType, SalesFlow } from '@/enum';

@Dto
export class EventTicketProduct extends EventProduct {
    get ticketOptions(): TicketOptions {
        return this.#ticketOptions;
    }

    set ticketOptions(value: TicketOptions) {
        this.#ticketOptions = value;
    }

    #ticketOptions: TicketOptions;

    constructor(id: string, name: string, description: string, isSharedCapacityEligible: boolean, markSoldOutWhenSaleSpanExpired: boolean, maximumPurchasePerCustomer: number, maximumPurchasePerOrder: number, media: Media[], packQuantity: number, priceCents: number | null, feeCents: number | null, salesFlow: SalesFlow, saleSpan: DateTimeSpan, stock: number, type: ProductType, waveLinkedProductId: string | null, deletable: boolean, hasReservationsOrSales: boolean, ticketOptions: TicketOptions) {
        super(id, name, description, isSharedCapacityEligible, markSoldOutWhenSaleSpanExpired, maximumPurchasePerCustomer, maximumPurchasePerOrder, media, packQuantity, priceCents, feeCents, salesFlow, saleSpan, stock, type, waveLinkedProductId, deletable, hasReservationsOrSales);
        this.#ticketOptions = ticketOptions;
    }
}
