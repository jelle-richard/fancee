import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class AgendaLinkedEvent {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    set startDate(value: DateTime) {
        this.#startDate = value;
    }

    get endDate(): DateTime {
        return this.#endDate;
    }

    set endDate(value: DateTime) {
        this.#endDate = value;
    }

    get type(): string {
        return this.#type;
    }

    set type(value: string) {
        this.#type = value;
    }

    #name: string;
    #startDate: DateTime;
    #endDate: DateTime;
    #type: string;

    constructor(name: string, startDate: DateTime, endDate: DateTime, type: string) {
        this.#name = name;
        this.#startDate = startDate;
        this.#endDate = endDate;
        this.#type = type;
    }
}
