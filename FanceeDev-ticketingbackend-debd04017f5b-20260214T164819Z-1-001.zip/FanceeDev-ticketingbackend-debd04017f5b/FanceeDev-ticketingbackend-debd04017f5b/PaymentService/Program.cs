using Adyen;
using Adyen.Constants;
using Fs.PixelTracking;
using PaymentService.BackgroundTasks.MessageBus;
using PaymentService.Configurations.Adyen;
using PaymentService.Persistence.Currency;
using PaymentService.Persistence.Discount;
using PaymentService.Persistence.Order;
using PaymentService.Persistence.PaymentMethod;
using PaymentService.Persistence.Product;
using PaymentService.Persistence.Refund;
using PaymentService.Persistence.Reservation;
using PaymentService.Persistence.Shop;
using PaymentService.Persistence.Wallet;
using PaymentService.Services.Discount;
using PaymentService.Services.Order;
using PaymentService.Services.Payment;
using PaymentService.Services.Pin;
using PaymentService.Services.Refund;
using PaymentService.Services.Tracking;
using PaymentService.Services.Wallet;
using WebApiCore;
using ZipUtils.Utils;
using Environment = Adyen.Model.Enum.Environment;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "PaymentService",
        EndpointName = "PaymentService v1"
    },
    UseS3Storage = true,
    UseAuthenticationAndAuthorization = true
};

var isProduction = builder.Environment.IsProduction();

var adyenApiKey = builder.Configuration.GetValue<string>("AdyenSecrets:XApiKey");

var config = new Config
{
    XApiKey = adyenApiKey,
    Environment = isProduction ? Environment.Live : Environment.Test,
    CloudApiEndPoint = isProduction ? ClientConfig.CloudApiEndPointEULive : ClientConfig.CloudApiEndPointTest,
    PosTerminalManagementEndpoint = isProduction ? ClientConfig.PosTerminalManagementEndpointLive : ClientConfig.PosTerminalManagementEndpointTest
};

var adyenClient = new Client(config);

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddZipUtils()
        .AddPixelTracking();
};

builder.AddDependency<IAdyenPaymentService, AdyenPaymentService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderService, OrderService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderDao, OrderDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICurrencyDao, CurrencyDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPaymentMethodDao, PaymentMethodDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPaymentMethodService, PaymentMethodService>(ServiceLifetime.Scoped);
builder.AddDependency<ICheckoutService>(_ => new AdyenCheckoutService(
    new(
        adyenApiKey,
        builder.Environment.IsProduction() ? Environment.Live : Environment.Test,
        builder.Environment.IsProduction() ? builder.Configuration.GetValue<string>("AdyenSecrets:LiveUrlPrefix") : null)
), ServiceLifetime.Scoped);
builder.AddDependency<IPosTerminalManagementService>(_ => new AdyenPosTerminalManagementService(adyenClient), ServiceLifetime.Scoped);
builder.AddDependency<IPosPaymentCloudApi>(_ => new AdyenPosPaymentCloudApi(adyenClient), ServiceLifetime.Scoped);
builder.AddDependency<IRefundService, RefundService>(ServiceLifetime.Scoped);
builder.AddDependency<IRefundDao, RefundDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPinService, PinService>(ServiceLifetime.Scoped);
builder.AddDependency<ValidPinTerminalListener>(sp => new(sp), ServiceLifetime.Singleton);
builder.AddDependency<StartPinTerminalTransactionListener>(sp => new(sp), ServiceLifetime.Singleton);
builder.AddDependency<IWalletService, WalletService>(ServiceLifetime.Scoped);
builder.AddDependency<IWalletDao, WalletDao>(ServiceLifetime.Scoped);
builder.AddDependency<IDiscountService, DiscountService>(ServiceLifetime.Scoped);
builder.AddDependency<IDiscountDao, DiscountDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDao, ShopDao>(ServiceLifetime.Scoped);
builder.AddDependency<IProductDao, ProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<ITrackingService, MetaTrackingService>(ServiceLifetime.Scoped);
builder.AddDependency<IReservationDao, ReservationDao>(ServiceLifetime.Scoped);

builder.AddDependency<AdyenConfiguration>(_ => AdyenConfiguration.FromConfiguration(builder.Configuration), ServiceLifetime.Singleton);

builder.AddHostedService<ValidPinTerminalListener>();
builder.AddHostedService<StartPinTerminalTransactionListener>();

var app = builder.Build();

app.Run();