using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Dtos.Response.PaymentMethod;
using PaymentService.Services.Payment;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Requests.Filters.Pagination;
using WebApiCore.Dtos.Responses;
using WebApiCore.Services.Logging;
using WebApiCore.Utils.HttpContext;

namespace PaymentService.Controllers;

[ApiController]
[Route("/[controller]")]
public class PaymentMethodsController : ControllerBase
{
    private readonly IPaymentMethodService _paymentMethodService;
    private readonly IUserLoggingService _userLoggingService;

    public PaymentMethodsController(IPaymentMethodService paymentMethodService, IUserLoggingService userLoggingService)
    {
        _paymentMethodService = paymentMethodService;
        _userLoggingService = userLoggingService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(AdminPaymentMethodPermission.List)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<PaymentMethodListResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<PaymentMethodListResponse>>>> GetPaymentMethods([FromQuery] PaginatedRequest<SearchQueryFilter> request)
    {
        await _userLoggingService.LogAsync(User.GetUserId(), "Has taken a look at the payment methods overview");

        var result = await _paymentMethodService.ActivePaymentMethodsAsync(request);

        return Ok(new ApiResponse<PaginatedResponse<PaymentMethodListResponse>>
        {
            Data = new()
            {
                Items = result.Items,
                Page = request.Page,
                PageSize = request.PageSize,
                TotalItems = result.TotalItems
            }
        });
    }

    [HttpGet]
    [Route("export/csv")]
    [Authorize(AdminPaymentMethodPermission.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> ExportPaymentMethods([FromQuery] SearchQueryFilter request)
    {
        var file = await _paymentMethodService.ActivePaymentMethodsAsCsvAsync(request);

        return File(file.FileContents, "text/csv", $"PaymentMethods-export-{DateTime.UtcNow}-UTC.csv");
    }
}