﻿using System.Text.Json;
using Adyen.Model.Checkout;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Dtos.Requests.Payment;
using PaymentService.Services.Order;
using PaymentService.Services.Payment;
using PaymentService.Services.Payment.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils.String;

namespace PaymentService.Controllers;

[ApiController]
[Route("/[controller]")]
public class PaymentController : ControllerBase
{
    private readonly IAdyenPaymentService _adyenPaymentService;
    private readonly IOrderService _orderService;

    public PaymentController(IAdyenPaymentService adyenPaymentService, IOrderService orderService)
    {
        _adyenPaymentService = adyenPaymentService;
        _orderService = orderService;
    }

    [HttpPost]
    [Route("session")]
    public async Task<ActionResult<ApiResponse<CreateCheckoutSessionResponse>>> CreateSession([FromBody] SessionRequest request) =>
        Ok(new ApiResponse<CreateCheckoutSessionResponse>
        {
            Data = await _adyenPaymentService.CreateSessionAsync(request.ReservationReference)
        });

    [HttpPost]
    [Route("combi-session")]
    public async Task<ActionResult<ApiResponse<CreateCheckoutSessionResponse>>> CreateCombiSession([FromBody] CombiSessionRequest request) =>
        Ok(new ApiResponse<CreateCheckoutSessionResponse>
        {
            Data = await _adyenPaymentService.CreateSessionAsync(request.Base64EncodedOrderIds)
        });

    [HttpGet]
    [Route("paymentMethods")]
    public async Task<ActionResult<PaymentMethodsResponse>> PaymentMethods() => Ok(await _adyenPaymentService.PaymentMethods());

    [HttpPost]
    [Route("postback")]
    public async Task<ActionResult> NotificationPostback([FromBody] object request)
    {
        var notificationRequest = JsonSerializer.Serialize(request);

        //Note parsing should happen after auth checks,
        //This is a temporary fix for an Adyen bug regarding no HMACs on Pending notifications 
        var notification = _adyenPaymentService.ParseNotification(notificationRequest);

        if (notification == null)
            throw new UnparsableNotificationException();

        if (notification.NotificationItem.EventCode != "PENDING")
        {
            var isValidAuthToken = _adyenPaymentService.ValidateAuthorizationToken(Request.Headers);
            var isValidHmac = _adyenPaymentService.ValidateHmacKey(notificationRequest);

            if (!isValidAuthToken || !isValidHmac)
                return Unauthorized();
        }

        var isValidGuid = Guid.TryParse(notification.NotificationItem.MerchantReference, out var merchantReference);
        bool isCombiOrderReference = !isValidGuid && StringUtils.IsBase64String(notification.NotificationItem.MerchantReference);
        
        //In case merchantReference doesn't contain ReservationReference or CombiReference it's an Adyen web-hook test, we just return OK
        if (!isValidGuid && !isCombiOrderReference)
            return Ok("[accepted]");

        if (isValidGuid)
            await _orderService.UpdateOrderPaymentAsync(merchantReference, notification.NotificationItem.PspReference, notification.NotificationItem.EventCode, notification.NotificationItem.Success, notification.NotificationItem.Reason, notification.NotificationItem.Amount);

        if (isCombiOrderReference)
            await _orderService.UpdateCombiOrderPaymentAsync(notification.NotificationItem.MerchantReference, notification.NotificationItem.PspReference, notification.NotificationItem.EventCode, notification.NotificationItem.Success, notification.NotificationItem.Reason);

        return Ok("[accepted]");
    }
}