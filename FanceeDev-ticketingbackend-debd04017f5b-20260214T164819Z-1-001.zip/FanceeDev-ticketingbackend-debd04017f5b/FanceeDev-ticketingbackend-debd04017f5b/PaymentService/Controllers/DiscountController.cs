using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Dtos.Requests.Discount;
using PaymentService.Dtos.Response.Discount;
using PaymentService.Services.Discount;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace PaymentService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class DiscountController : ControllerBase
{
    private readonly IDiscountService _discountService;

    public DiscountController(IDiscountService discountService)
    {
        _discountService = discountService;
    }

    [HttpGet]
    [Route("{discountId:guid}")]
    [Authorize(OrganizationDiscountPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<DiscountResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<DiscountResponse>>> Get(Guid discountId) =>
        Ok(new ApiResponse<DiscountResponse>
        {
            Data = await _discountService.ByIdAsync(Request.GetOrganizationId(), discountId)
        });

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationDiscountPermissions.Add)]
    [ProducesResponseType(typeof(ApiResponse<DiscountCreateResponse>), StatusCodes.Status201Created)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<DiscountCreateResponse>>> Create([FromBody] DiscountRequest request)
    {
        var discountId = await _discountService.CreateAsync(Request.GetOrganizationId(), request);

        return CreatedAtAction(nameof(Get), new { discountId }, new ApiResponse<DiscountCreateResponse>
        {
            Data = new()
            {
                Id = discountId
            }
        });
    }

    [HttpPut]
    [Route("{discountId:guid}")]
    [Authorize(OrganizationDiscountPermissions.Add)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Update(Guid discountId, [FromBody] DiscountRequest request)
    {
        await _discountService.UpdateAsync(Request.GetOrganizationId(), discountId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("{discountId:guid}")]
    [Authorize(OrganizationDiscountPermissions.Remove)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult> Delete(Guid discountId)
    {
        await _discountService.RemoveAsync(Request.GetOrganizationId(), discountId);

        return Ok();
    }
}