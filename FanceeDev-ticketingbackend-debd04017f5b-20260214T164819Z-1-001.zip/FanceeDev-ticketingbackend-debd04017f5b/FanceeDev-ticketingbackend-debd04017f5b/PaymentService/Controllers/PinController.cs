using Adyen.ApiSerialization;
using Adyen.Model.Nexo;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Configurations.Adyen;
using PaymentService.Services.Order;
using PaymentService.Services.Pin;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions;
using WebApiCore.Utils;

namespace PaymentService.Controllers;

[ApiController]
[Route("/payment/[controller]")]
public class PinController : ControllerBase
{
    /// <summary>
    /// Matches: TerminalName-SerialNumber
    /// Examples: P400Plus-123456789
    /// Note: the following characters need to be escaped (by doubling them): []{}
    /// </summary>
    public const string TerminalRegex = @"^[[A-z\d]]{{1,20}}-\d{{9}}$";

    private readonly IPinService _pinService;
    private readonly IOrderService _orderService;
    private readonly AdyenConfiguration _adyenConfiguration;
    private readonly ILogger<PinController> _logger;

    public PinController(IPinService pinService, IOrderService orderService, AdyenConfiguration adyenConfiguration, ILogger<PinController> logger)
    {
        _pinService = pinService;
        _orderService = orderService;
        _adyenConfiguration = adyenConfiguration;
        _logger = logger;
    }

    [HttpGet]
    [Route($"terminals/{{serialNumber:regex({TerminalRegex})}}")]
    public async Task<ActionResult<ApiResponse<bool>>> ValidTerminal(string serialNumber) =>
        Ok(new ApiResponse<bool>
        {
            Data = await _pinService.ValidTerminalAsync(serialNumber)
        });

    [HttpPost]
    [Route("postback")]
    public async Task<ActionResult> Postback()
    {
        var response = await ParsePostbackResponseAsync();

        if (response?.MessagePayload is PaymentResponse paymentResponse)
            await HandlePinPaymentResponse(paymentResponse);

        return Ok("[accepted]");
    }

    [HttpPost]
    [Route("display")]
    public async Task<ActionResult> Display()
    {
        var response = await ParsePostbackResponseAsync();

        if (response?.MessagePayload is DisplayRequest displayRequest)
        {
            //todo: implement once https://github.com/Adyen/adyen-dotnet-api-library/issues/661 is fixed.
        }

        return Ok("[accepted]");
    }

    private async Task HandlePinPaymentResponse(PaymentResponse paymentResponse)
    {
        var transactionId = paymentResponse.SaleData.SaleTransactionID.TransactionID;

        if (!Guid.TryParse(transactionId, out var transactionGuid))
            return;

        var resultType = paymentResponse.Response.Result;
        var pspReference = paymentResponse.PaymentResult.PaymentAcquirerData.AcquirerTransactionID.TransactionID;

        await _orderService.UpdateOrderPaymentAsync(
            transactionGuid,
            pspReference,
            resultType
        );
    }

    /// <summary>
    /// Parses the <see cref="SaleToPOIResponse" /> from the request.
    /// </summary>
    /// <returns></returns>
    private async Task<SaleToPOIResponse?> ParsePostbackResponseAsync()
    {
        var notificationUsername = _adyenConfiguration.PinNotificationUsername;
        var notificationPassword = _adyenConfiguration.PinNotificationPassword;

        if (notificationUsername == null || notificationPassword == null)
            throw new MissingRequiredConfigurationEntryException("AdyenSecrets", "PinNotificationUsername / PinNotificationPassword");

        if (!Request.Headers.ValidBasicAuthorization(notificationUsername, notificationPassword))
            return null;

        var requestJson = await Request.ReadRawRequestAsync();

        if (!(requestJson?.StartsWith("{") ?? false) || !requestJson.EndsWith("}"))
            return null;

        try
        {
            return new SaleToPoiMessageSerializer().Deserialize(requestJson);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not deserialize Pin Postback request JSON: {RawJson}", requestJson);

            return null;
        }
    }
}