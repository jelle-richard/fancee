using System.Net.Mime;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Dtos.Requests.Wallet;
using PaymentService.Dtos.Response.Wallet;
using PaymentService.Services.Wallet;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Services.Organization;
using WebApiCore.Utils;
using WebApiCore.Utils.Adapter;

namespace PaymentService.Controllers;

[ApiController]
[Route("/payment/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status403Forbidden)]
public class WalletController : ControllerBase
{
    private const int MaximumBalanceDateRangeDays = 30;

    private readonly IWalletService _walletService;
    private readonly IOrganizationService _organizationService;

    public WalletController(IWalletService walletService, IOrganizationService organizationService)
    {
        _walletService = walletService;
        _organizationService = organizationService;
    }

    [HttpGet]
    [Route("balance")]
    [Authorize(OrganizationWalletPermissions.Insights)]
    [ProducesResponseType(typeof(ApiResponse<BalanceResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<BalanceResponse>>> OrganizationBalance() => await BalanceAsync(Request.GetOrganizationId());

    [HttpGet]
    [Route("balance/{start:datetime}/{end:datetime}")]
    [Authorize(OrganizationWalletPermissions.Insights)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<DailyBalanceResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<DailyBalanceResponse>>>> OrganizationBalanceByDateRange(DateTime start, DateTime end) => await BalanceByDateRangeAsync(Request.GetOrganizationId(), start, end);

    [HttpPost]
    [Route("payout/request")]
    [Authorize(OrganizationWalletPermissions.PayOut)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> PayoutRequest([FromBody] PayoutRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.WalletEnabledAsync(organizationId))
            throw new FeatureNotEnabledException("wallet");

        await _walletService.AddPayoutRequestAsync(organizationId, request.Cents);

        return Created(string.Empty, new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("payout/download-receipt/{fileId:guid}")]
    [Authorize(OrganizationWalletPermissions.PayOut)]
    [ProducesResponseType(typeof(FileStreamResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    public async Task<FileStreamResult> OrganizationDownloadPayOutReceipt([FromRoute] Guid fileId) => await DownloadPayOutReceiptAsync(Request.GetOrganizationId(), fileId);

    [HttpGet]
    [Route("transaction/list")]
    [Authorize(OrganizationWalletPermissions.Insights)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<WalletTransactionItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<WalletTransactionItemResponse>>>> OrganizationTransactionList([FromQuery] PaginatedRequest<WalletTransactionFilter> request) => await TransactionListAsync(Request.GetOrganizationId(), request);

    [HttpGet]
    [Route("transaction/export/csv")]
    [Authorize(OrganizationWalletPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<FileResult> OrganizationExportTransactionsAsCsv([FromQuery] WalletTransactionFilter request) => await ExportTransactionsAsCsvAsync(Request.GetOrganizationId(), request);

    [HttpGet]
    [Route("organization/{organizationId:guid}/balance")]
    [Authorize(AdminWalletPermissions.Insights)]
    [ProducesResponseType(typeof(ApiResponse<BalanceResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<BalanceResponse>>> AdminBalance(Guid organizationId) => await BalanceAsync(organizationId);

    [HttpGet]
    [Route("organization/{organizationId:guid}/balance/{start:datetime}/{end:datetime}")]
    [Authorize(AdminWalletPermissions.Insights)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<DailyBalanceResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<DailyBalanceResponse>>>> AdminBalanceByDateRange(Guid organizationId, DateTime start, DateTime end) => await BalanceByDateRangeAsync(organizationId, start, end);

    [HttpGet]
    [Route("organization/{organizationId:guid}/payout/download-receipt/{fileId:guid}")]
    [Authorize(AdminWalletPermissions.PayOut)]
    [ProducesResponseType(typeof(FileStreamResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<FileStreamResult> AdminDownloadPayOutReceipt(Guid organizationId, [FromRoute] Guid fileId) => await DownloadPayOutReceiptAsync(organizationId, fileId);

    [HttpGet]
    [Route("organization/{organizationId:guid}/transaction/list")]
    [Authorize(AdminWalletPermissions.Insights)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<WalletTransactionItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<WalletTransactionItemResponse>>>> AdminTransactionList(Guid organizationId, [FromQuery] PaginatedRequest<WalletTransactionFilter> request) => await TransactionListAsync(organizationId, request);

    [HttpGet]
    [Route("organization/{organizationId:guid}/transaction/export/csv")]
    [Authorize(AdminWalletPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> AdminExportTransactionsAsCsv(Guid organizationId, [FromQuery] WalletTransactionFilter request) => await ExportTransactionsAsCsvAsync(organizationId, request);

    private async Task<ActionResult<ApiResponse<BalanceResponse>>> BalanceAsync(Guid organizationId) =>
        Ok(new ApiResponse<BalanceResponse>
        {
            Data = await _walletService.BalanceAsync(organizationId)
        });

    private async Task<ActionResult<ApiResponse<IEnumerable<DailyBalanceResponse>>>> BalanceByDateRangeAsync(Guid organizationId, DateTime start, DateTime end)
    {
        if (start >= end)
            throw new InvalidDateRangeException();

        start = start.SetStartOfDay();
        end = end.SetEndOfDay();

        if ((end - start).Days > MaximumBalanceDateRangeDays)
            throw new ExceededDateRangeException(MaximumBalanceDateRangeDays);

        return Ok(new ApiResponse<IEnumerable<DailyBalanceResponse>>
        {
            Data = await _walletService.DailyBalanceAsync(organizationId, start, end)
        });
    }

    private async Task<FileStreamResult> DownloadPayOutReceiptAsync(Guid organizationId, Guid fileId)
    {
        if (!await _organizationService.WalletEnabledAsync(organizationId))
            throw new FeatureNotEnabledException("wallet");

        var stream = await _walletService.DownloadPayOutReceiptAsync(organizationId, fileId);

        return File(stream, MediaTypeNames.Application.Pdf, "Pay Out Receipt.pdf");
    }

    private async Task<ActionResult<ApiResponse<PaginatedResponse<WalletTransactionItemResponse>>>> TransactionListAsync(Guid organizationId, PaginatedRequest<WalletTransactionFilter> request)
    {
        if (!await _organizationService.WalletEnabledAsync(organizationId))
            throw new FeatureNotEnabledException("wallet");

        var result = await _walletService.WalletTransactionsAsync(organizationId, request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    private async Task<FileResult> ExportTransactionsAsCsvAsync(Guid organizationId, WalletTransactionFilter request)
    {
        var file = await _walletService.WalletTransactionsAsCsvAsync(organizationId, request);

        return File(file.FileContents, "text/csv", $"Wallet-transactions-export-{DateTime.UtcNow}-UTC.csv");
    }
}