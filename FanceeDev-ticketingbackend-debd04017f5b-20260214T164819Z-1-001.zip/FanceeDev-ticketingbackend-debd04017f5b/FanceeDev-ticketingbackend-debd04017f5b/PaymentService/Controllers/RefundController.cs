using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Dtos.Requests.Refund;
using PaymentService.Services.Refund;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace PaymentService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class RefundController : ControllerBase
{
    private readonly IRefundService _refundService;

    public RefundController(IRefundService refundService)
    {
        _refundService = refundService;
    }

    [HttpPost]
    [Route("{orderId:guid}")]
    [Authorize(OrganizationRefundPermissions.Accept)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult> IssueRefund(Guid orderId, [FromBody] RefundOrderRequest request)
    {
        await _refundService.IssueRefundAsync(orderId, Request.GetOrganizationId(), request);

        return Ok();
    }
}