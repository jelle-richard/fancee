using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Dtos.Requests.Discount;
using PaymentService.Dtos.Response.Discount;
using PaymentService.Services.Discount;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;
using WebApiCore.Utils.Adapter;

namespace PaymentService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
[UseOrganizationHeader]
public class DiscountsController : ControllerBase
{
    private readonly IDiscountService _discountService;

    public DiscountsController(IDiscountService discountService)
    {
        _discountService = discountService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(OrganizationDiscountPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<DiscountListItemResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<DiscountListItemResponse>>>> List([FromQuery] PaginatedRequest<DiscountFilter> request)
    {
        var result = await _discountService.ListAsync(Request.GetOrganizationId(), request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("export/csv")]
    [Authorize(OrganizationDiscountPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> Export([FromQuery] DiscountFilter request)
    {
        var file = await _discountService.ExportAsync(Request.GetOrganizationId(), request);

        return File(file.FileContents, "text/csv", $"Discounts-export-{DateTime.UtcNow}-UTC.csv");
    }
}