using WebApiCore.Exceptions;

namespace ShopService.Services.Exceptions;

public class AgendaIframeNotFoundException()
    : NotFoundApiException("Iframe not found");