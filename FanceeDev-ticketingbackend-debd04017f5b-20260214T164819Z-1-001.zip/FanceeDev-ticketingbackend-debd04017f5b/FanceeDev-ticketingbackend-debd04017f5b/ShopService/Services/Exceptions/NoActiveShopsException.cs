using WebApiCore.Exceptions;
using WebApiCore.Utils;

namespace ShopService.Services.Exceptions;

public class NoActiveShopsException()
    : BadRequestApiException("Event has no active shops", ErrorCode.ExceptionInvalidConfiguration);