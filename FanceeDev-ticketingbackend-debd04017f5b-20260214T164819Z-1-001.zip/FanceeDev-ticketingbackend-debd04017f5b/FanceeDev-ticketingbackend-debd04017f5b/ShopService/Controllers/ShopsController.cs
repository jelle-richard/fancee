﻿using Microsoft.AspNetCore.Mvc;
using ShopService.Dtos.Responses.Shops;
using ShopService.Services.Shops;
using ShopService.Utils.ShopPromoCalculator;
using ShopService.Utils.ShopPromoCalculator.Strategies;
using WebApiCore.Dtos.Responses;

namespace ShopService.Controllers;

[ApiController]
[Route("/[controller]")]
public class ShopsController : ControllerBase
{
    private readonly IShopsService _shopsService;

    public ShopsController(IShopsService shopsService)
    {
        _shopsService = shopsService;
    }

    [HttpGet]
    [Route("promo")]
    public async Task<ActionResult<ApiResponse<PromoShopsResponse>>> Get()
    {
        var context = new PromoCalculationContext(new RecentActivityPromoCalculationStrategy(), _shopsService);
        await context.CalculateAsync();

        return Ok(new ApiResponse<PromoShopsResponse>
        {
            Data = await context.PromoShopsAsync()
        });
    }
}