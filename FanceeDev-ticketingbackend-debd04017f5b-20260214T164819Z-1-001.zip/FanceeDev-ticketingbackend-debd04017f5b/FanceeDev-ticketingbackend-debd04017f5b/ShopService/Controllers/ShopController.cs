﻿using System.Text.Json;
using System.Text.Json.Serialization;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using ShopService.Dtos.Responses.Shop;
using ShopService.Services.Campaign;
using ShopService.Services.Shop;
using ShopService.Services.Tracking;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared.ShopElement;
using WebApiCore.Services.Cache;
using WebApiCore.Utils.Converter;
using WebApiCore.Utils.Validation;

namespace ShopService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class ShopController : ControllerBase
{
    private readonly IShopService _shopService;
    private readonly ICacheService _cacheService;
    private readonly ICampaignService _campaignService;
    private readonly IEnumerable<ITrackingService> _trackingServices;

    public ShopController(IShopService shopService, ICacheService cacheService, ICampaignService campaignService, IEnumerable<ITrackingService> trackingServices)
    {
        _shopService = shopService;
        _cacheService = cacheService;
        _campaignService = campaignService;
        _trackingServices = trackingServices;

        //todo: this is not the way. Should somehow be injected. Works for testing.
        _cacheService.SetJsonSerializerOptions(new()
        {
            Converters = { new DateTimeConverter(), new JsonStringEnumConverter(), new ShopElementDtoConverter<ShopProductDetailsElementDto>() },
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });
    }

    [HttpGet]
    [Route($"{{code:length({Shop.CodeLengthAttribute})}}")]
    [ProducesResponseType(typeof(ApiResponse<ShopResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<ShopResponse>>> Get(string code, [FromQuery] string? campaignCode)
    {
        var trackableShopResponse = await _cacheService.GetCachedObjectAsync<TrackableShopResponseWrapper>(code);

        if (trackableShopResponse == null)
        {
            trackableShopResponse = await _shopService.ByCodeAsync(code);
            await _cacheService.CacheObjectAsync(code, trackableShopResponse, 1);
        }

        trackableShopResponse.ShopResponse = await _shopService.UpdateShopResponseProductMaxOrderQuantitiesAsync(trackableShopResponse.ShopResponse);
        trackableShopResponse.ShopResponse.Secured = await _shopService.IsShopSecuredAsync(code);

        if (!string.IsNullOrEmpty(campaignCode) && await _shopService.IsShopLinkedToCampaign(code, campaignCode))
            await _campaignService.AddClickToCampaignAsync(code, campaignCode);

        await RegisterTrackingViews(trackableShopResponse, code);

        return Ok(new ApiResponse<ShopResponse>
        {
            Data = trackableShopResponse.ShopResponse
        });
    }

    private async Task RegisterTrackingViews(TrackableShopResponseWrapper trackableShopResponse, string code)
    {
        if (trackableShopResponse.FacebookPixelId == null || trackableShopResponse.FacebookAccessCode == null)
            return;

        foreach (var trackingService in _trackingServices)
            await trackingService.RegisterViewAsync(code, trackableShopResponse);
    }
}