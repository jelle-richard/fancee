using System.Text.Json.Serialization;
using Fs.PixelTracking;
using ShopService.Persistence.AgendaIframe;
using ShopService.Persistence.Campaign;
using ShopService.Persistence.CombinedShop;
using ShopService.Persistence.Event;
using ShopService.Persistence.Organization;
using ShopService.Persistence.PreRegister;
using ShopService.Persistence.SecureCode;
using ShopService.Persistence.Shop;
using ShopService.Persistence.Shops;
using ShopService.Services.AgendaIframe;
using ShopService.Services.Campaign;
using ShopService.Services.CombinedShop;
using ShopService.Services.Event;
using ShopService.Services.Organization;
using ShopService.Services.PreRegister;
using ShopService.Services.SecureCode;
using ShopService.Services.Shop;
using ShopService.Services.Shops;
using ShopService.Services.Tracking;
using ShopService.Utils.ShopPromoCalculator.Strategies;
using WebApiCore;
using WebApiCore.Dtos.Shared.ShopElement;
using WebApiCore.Persistence.SecureCode;
using WebApiCore.Utils.Converter;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "ShopService",
        EndpointName = "ShopService v1"
    },
    JsonConverters = new List<JsonConverter>
    {
        new ShopElementDtoConverter<ShopProductDetailsElementDto>()
    }
};

builder.OnConfigureServices += (_, collection) => collection.AddPixelTracking();

builder.AddDependency<IShopService, ShopService.Services.Shop.ShopService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopsService, ShopsService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDao, ShopDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopsDao, ShopsDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPromoCalculationStrategy, OrderCountingPromoCalculationStrategy>(ServiceLifetime.Scoped);
builder.AddDependency<IPromoCalculationStrategy, PercentageSoldOutPromoCalculationStrategy>(ServiceLifetime.Scoped);
builder.AddDependency<ICampaignService, CampaignService>(ServiceLifetime.Scoped);
builder.AddDependency<ICampaignDao, CampaignDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopCampaignDao, ShopCampaignDao>(ServiceLifetime.Scoped);
builder.AddDependency<IAgendaIframeService, AgendaIframeService>(ServiceLifetime.Scoped);
builder.AddDependency<IAgendaIframeDao, AgendaIframeDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);
builder.AddDependency<ITrackingService, MetaTrackingService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventService, EventService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopSecureCodeService, ShopSecureCodeService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopSecureCodeDao, ShopSecureCodeDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISecureCodeDao, SecureCodeDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPreRegisterDao, PreRegisterDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPreRegisterService, PreRegisterService>(ServiceLifetime.Scoped);
builder.AddDependency<ICombinedShopService, CombinedShopService>(ServiceLifetime.Scoped);
builder.AddDependency<ICombinedShopDao, CombinedShopDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationService, OrganizationService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationDao, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICombinedShopMediaDao, CombinedShopMediaDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISharedShopService, SharedShopService>(ServiceLifetime.Scoped);
builder.AddDependency<ISharedShopDao, SharedShopDao>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();