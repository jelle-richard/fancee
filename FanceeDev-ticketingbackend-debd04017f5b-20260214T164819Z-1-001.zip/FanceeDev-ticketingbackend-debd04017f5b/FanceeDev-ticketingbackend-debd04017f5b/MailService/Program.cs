using MailKit.Net.Smtp;
using MailService.BackgroundTasks.MessageBus;
using MailService.Dtos.MailProvider;
using MailService.Persistence.MailQueue;
using MailService.Providers.MailProvider;
using MailService.Services.Queue;
using Mandrill;
using sib_api_v3_sdk.Api;
using WebApiCore;
using WebApiCore.Dtos.MailProvider;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "MailService",
        EndpointName = "MailService v1"
    }
};

builder.AddDependency<ISmtpClient, SmtpClient>(ServiceLifetime.Scoped);
builder.AddDependency<IMandrillApi>(_ => new MandrillApi(builder.Configuration.GetValue<string>("Mailchimp:TransactionalApiKey")), ServiceLifetime.Scoped);
builder.AddDependency<ITransactionalEmailsApi, TransactionalEmailsApi>(ServiceLifetime.Scoped);
builder.AddDependency<IMailProvider, SmtpMailProvider>(ServiceLifetime.Scoped);
builder.AddDependency<IMailProvider, MailchimpMailProvider>(ServiceLifetime.Scoped);
builder.AddDependency<IMailProvider, SendinblueMailProvider>(ServiceLifetime.Scoped);
builder.AddDependency<IMailQueueDao, MailQueueDao>(ServiceLifetime.Scoped);
builder.AddDependency<IQueueService<Mail, StoredMail>, MailQueueService>(ServiceLifetime.Scoped);

builder.AddDependency(x => new SendMailQueueListener(x), ServiceLifetime.Singleton);
builder.AddDependency(x => new AddMailListener(x), ServiceLifetime.Singleton);
builder.AddDependency(x => new RemoveSentMailsListener(x), ServiceLifetime.Singleton);

builder.AddHostedService<SendMailQueueListener>();
builder.AddHostedService<AddMailListener>();
builder.AddHostedService<RemoveSentMailsListener>();

var app = builder.Build();
app.Run();