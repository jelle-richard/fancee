using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace ReserveService.Persistence;

public class ProductDao : IProductDao
{
    private readonly TicketingContext _dbContext;

    public ProductDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<Dictionary<Guid, int?>> ProductPricesAsync(IEnumerable<Guid> productIds)
    {
        return await _dbContext.Products.Where(p => productIds.Contains(p.Id))
            .ToDictionaryAsync(p => p.Id, p => p.PriceCents);
    }
}