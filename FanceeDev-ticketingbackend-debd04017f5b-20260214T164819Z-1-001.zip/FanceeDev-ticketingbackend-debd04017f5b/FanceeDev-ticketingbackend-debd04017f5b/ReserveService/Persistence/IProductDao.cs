namespace ReserveService.Persistence;

public interface IProductDao
{
    /// <summary>
    /// Gets the prices for the given products.
    /// </summary>
    /// <param name="productIds"></param>
    /// <returns></returns>
    public Task<Dictionary<Guid, int?>> ProductPricesAsync(IEnumerable<Guid> productIds);
}