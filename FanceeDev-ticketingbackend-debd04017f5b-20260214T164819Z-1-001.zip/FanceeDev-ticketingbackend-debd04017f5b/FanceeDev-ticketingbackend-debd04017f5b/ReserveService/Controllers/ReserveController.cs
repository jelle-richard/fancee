﻿using System.ComponentModel.DataAnnotations;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using ReserveService.Dtos.Requests.Reserve;
using ReserveService.Dtos.Responses.Reserve;
using ReserveService.Services.Reserve;
using WebApiCore.Dtos.Responses;

namespace ReserveService.Controllers;

[ApiController]
[Route("/[controller]")]
public class ReserveController : ControllerBase
{
    private readonly IReserveService _reserveService;

    public ReserveController(IReserveService reserveService)
    {
        _reserveService = reserveService;
    }

    [HttpPost]
    [Route($"{{code:length({Shop.CodeLengthAttribute})}}")]
    [ProducesResponseType<ApiResponse<ReserveResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiResponse<EmptyResponse>>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<ReserveResponse>>> Reserve(string code, [FromBody] ReserveRequest request, [FromQuery] string? campaignCode, [FromQuery] string? appUri, [FromQuery] string? secureCode) =>
        Ok(new ApiResponse<ReserveResponse>
        {
            Data = await _reserveService.ReserveAsync(code, request.Products, campaignCode, appUri, secureCode)
        });

    [HttpPut]
    [Route("{reservationReference:guid}/discount")]
    [ProducesResponseType<ApiResponse<AppliedDiscountResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiResponse<EmptyResponse>>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<AppliedDiscountResponse>>> ApplyDiscount([FromRoute] Guid reservationReference, [FromQuery] [Required] string discountCode) =>
        Ok(new ApiResponse<AppliedDiscountResponse>
        {
            Data = await _reserveService.ApplyDiscountAsync(reservationReference, discountCode)
        });

    [HttpDelete]
    [Route("{reservationReference:guid}/discount")]
    [ProducesResponseType<ApiResponse<EmptyResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiResponse<EmptyResponse>>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> RemoveDiscount([FromRoute] Guid reservationReference)
    {
        await _reserveService.RemoveDiscountAsync(reservationReference);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route($"combined/{{code:length({CombinedShop.CodeLengthAttribute})}}")]
    [ProducesResponseType<ApiResponse<IEnumerable<ReserveResponse>>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiResponse<EmptyResponse>>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ReserveResponse>>>> CombiReserve(string code, [FromBody] CombinedReserveRequest request)
    {
        var reservationResponses = new List<ReserveResponse>();
        foreach (var shopReservation in request.Reservations)
            reservationResponses.Add(await _reserveService.ReserveAsync(shopReservation.ShopCode, shopReservation.Products, null, null, null, code));

        return Ok(new ApiResponse<IEnumerable<ReserveResponse>>
        {
            Data = reservationResponses
        });
    }
}