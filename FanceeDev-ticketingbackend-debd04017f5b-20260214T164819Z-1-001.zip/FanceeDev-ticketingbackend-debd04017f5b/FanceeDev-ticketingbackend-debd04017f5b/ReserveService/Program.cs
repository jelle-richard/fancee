using Fs.PixelTracking;
using Fs.SeatingUtils.Config;
using Fs.SeatingUtils.Providers;
using Fs.SeatingUtils.Utils;
using ReserveService.Persistence;
using ReserveService.Persistence.Discount;
using ReserveService.Persistence.Reservation;
using ReserveService.Persistence.Shop;
using ReserveService.Services.Reserve;
using ReserveService.Services.Tracking;
using WebApiCore;
using WebApiCore.Exceptions;
using WebApiCore.Persistence.SecureCode;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "ReserveService",
        EndpointName = "ReserveService v1"
    },
    UseS3Storage = false,
    UseRabbitMq = false
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddPixelTracking();

    if (builder.IsCiCd)
        return;

    collection.AddSeatingUtils(new SeatsIoConfiguration
    {
        Region = builder.Configuration.GetValue<string>("SeatsIo:Region") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "Region"),
        SecretKey = builder.Configuration.GetValue<string>("SeatsIo:SecretKey") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "SecretKey")
    });
};

builder.AddDependency<IReserveService, ReserveService.Services.Reserve.ReserveService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDao, ShopDao>(ServiceLifetime.Scoped);
builder.AddDependency<IReservationDao, ReservationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IDiscountDao, DiscountDao>(ServiceLifetime.Scoped);
builder.AddDependency<ITrackingService, MetaTrackingService>(ServiceLifetime.Scoped);
builder.AddDependency<IProductDao, ProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISeatsIoProvider, SeatsIoProvider>(ServiceLifetime.Scoped);
builder.AddDependency<ISecureCodeDao, SecureCodeDao>(ServiceLifetime.Scoped);

var app = builder.Build();

app.Run();