using Microsoft.Extensions.DependencyInjection;

namespace ViewRenderer.Tests;

public class ViewRendererExtensionsTests
{
    [Fact]
    public void TestThatAddViewRendererAddsScopedViewRendererDependency()
    {
        var mockedServiceCollection = new Mock<ServiceCollection>();
        mockedServiceCollection.SetupAllProperties();

        mockedServiceCollection.Object.AddViewRenderer();

        Assert.Single(mockedServiceCollection.Object);
        Assert.Equal(typeof(ViewRenderer), mockedServiceCollection.Object[0].ImplementationType);
    }
}