﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using ViewRenderer.Exceptions;

namespace ViewRenderer.Tests;

[SuppressMessage("ReSharper", "Mvc.ViewNotResolved")]
public class ViewRendererTests
{
    private readonly ViewRenderer _sut;
    private readonly Mock<IRazorViewEngine> _mockedRazorViewEngine = new();
    private readonly Mock<ITempDataProvider> _mockedTempDataProvider = new();
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();

    public ViewRendererTests()
    {
        _sut = new(_mockedRazorViewEngine.Object, _mockedTempDataProvider.Object, _mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatFindViewThrowsInvalidViewExceptionOnInvalidView()
    {
        _mockedRazorViewEngine.Setup(rve => rve.GetView(null, It.IsAny<string>(), true))
            .Returns(ViewEngineResult.NotFound("invalid", Enumerable.Empty<string>()));
        _mockedRazorViewEngine.Setup(rve => rve.FindView(It.IsAny<ActionContext>(), It.IsAny<string>(), true))
            .Returns(ViewEngineResult.NotFound("invalid", new[] { "/Views" }));

        await Assert.ThrowsAsync<InvalidViewException>(async () => await _sut.RenderViewAsync("invalid", new UnitTestModel()));
    }

    [Fact]
    public async Task TestThatFindViewReturnsViewOfGetViewCall()
    {
        _mockedRazorViewEngine.Setup(rve => rve.GetView(null, "~/Views/valid.cshtml", true))
            .Returns(ViewEngineResult.Found("~/Views/valid.cshtml", new Mock<IView>().Object));

        var actual = await _sut.RenderViewAsync("valid", new UnitTestModel());

        Assert.Equal(string.Empty, actual);
        _mockedRazorViewEngine.Verify(rve => rve.GetView(null, "~/Views/valid.cshtml", true), Times.Once);
        _mockedRazorViewEngine.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatFindViewReturnsViewOfFindViewCall()
    {
        _mockedRazorViewEngine.Setup(rve => rve.GetView(null, "~/Views/valid.cshtml", true))
            .Returns(ViewEngineResult.NotFound("valid", Enumerable.Empty<string>()));
        _mockedRazorViewEngine.Setup(rve => rve.FindView(It.IsAny<ActionContext>(), "~/Views/valid.cshtml", true))
            .Returns(ViewEngineResult.Found("valid", new Mock<IView>().Object));

        var actual = await _sut.RenderViewAsync("valid", new UnitTestModel());

        Assert.Equal(string.Empty, actual);
        _mockedRazorViewEngine.Verify(rve => rve.GetView(null, "~/Views/valid.cshtml", true), Times.Once);
        _mockedRazorViewEngine.Verify(rve => rve.FindView(It.IsAny<ActionContext>(), "~/Views/valid.cshtml", true), Times.Once);
    }

    #region Unit Test Classes

    public class UnitTestModel
    {
    }

    #endregion
}