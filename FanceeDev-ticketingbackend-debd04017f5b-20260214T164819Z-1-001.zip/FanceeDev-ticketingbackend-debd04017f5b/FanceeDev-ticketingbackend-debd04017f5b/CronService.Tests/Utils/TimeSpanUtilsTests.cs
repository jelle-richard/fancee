﻿using System;
using CronService.Utils;
using Microsoft.Extensions.Configuration;
using TestCore.Mocks;

namespace CronService.Tests.Utils;

public class TimeSpanUtilsTests
{
    [Fact]
    public void TestThatGetTimeSpanReturnsDefaultValueOnNull()
    {
        var defaultTimeSpan = TimeSpan.FromMinutes(1);
        IConfiguration? config = null;

        var actual = config.GetTimeSpan("unit:test", defaultTimeSpan);

        Assert.Equal(TimeSpan.FromMinutes(1), actual);
    }

    [Fact]
    public void TestThatGetTimeSpanReturnsCorrectValue()
    {
        var configuration = ConfigurationMockUtils.Create(new() { { "unit:test", "0.00:00:42" } });

        var actual = configuration.GetTimeSpan("unit:test", TimeSpan.FromHours(2));

        Assert.Equal(TimeSpan.FromSeconds(42), actual);
    }

    [Theory]
    [InlineData("invalid")]
    [InlineData("0.25:00:00")]
    [InlineData("0.00:-10:00")]
    public void TestThatGetTimeSpanReturnsDefaultValueOnInvalidFormat(string value)
    {
        var configuration = ConfigurationMockUtils.Create(new() { { "unit:test", value } });

        var actual = configuration.GetTimeSpan("unit:test", TimeSpan.FromHours(2));

        Assert.Equal(TimeSpan.FromHours(2), actual);
    }
}