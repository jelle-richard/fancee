﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("AccountingUtils.Tests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
