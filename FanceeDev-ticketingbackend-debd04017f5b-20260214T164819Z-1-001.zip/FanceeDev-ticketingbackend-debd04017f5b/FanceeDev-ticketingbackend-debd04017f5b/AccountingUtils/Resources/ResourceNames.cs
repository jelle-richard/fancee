namespace AccountingUtils.Resources;

internal static class ResourceNames
{
    internal const string IngPayoutTemplate = $"{nameof(AccountingUtils)}.{nameof(Resources)}.ing-payout-template.xlsx";
}