namespace AccountingUtils.Utils.Exceptions;

public class MissingResourceException(string fileName)
    : Exception($"Resource '{fileName}' does not exist or cannot be read");