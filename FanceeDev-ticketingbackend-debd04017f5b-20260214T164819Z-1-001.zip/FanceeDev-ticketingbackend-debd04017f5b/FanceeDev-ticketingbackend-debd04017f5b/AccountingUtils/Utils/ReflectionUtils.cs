using System.Reflection;
using System.Text.Json.Serialization;

namespace AccountingUtils.Utils;

public static class ReflectionUtils
{
    /// <summary>
    /// Converts all public properties in the instance to a dictionary.
    /// Renames entries with the <see cref="JsonPropertyNameAttribute"/>.
    /// </summary>
    /// <param name="instance"></param>
    /// <returns></returns>
    public static Dictionary<string, string> ToDictionary(object instance)
    {
        return instance.GetType()
            .GetProperties(BindingFlags.Instance | BindingFlags.Public)
            .ToDictionary(
                prop => prop.GetCustomAttribute<JsonPropertyNameAttribute>()?.Name ?? prop.Name,
                prop => prop.GetValue(instance)?.ToString() ?? default!
            );
    }
}