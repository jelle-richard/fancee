using System.Net.Mime;
using AccountingUtils.Config;
using AccountingUtils.Providers.Accounting.Exact;
using AccountingUtils.Providers.Bank;
using AccountingUtils.Providers.Bank.Ing;
using AccountingUtils.Providers.Excel;
using ClosedXML.Excel;
using ClosedXML.Graphics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Net.Http.Headers;

namespace AccountingUtils.Utils;

public static class AccountingUtilsExtensions
{
    private const string FallbackFont = "DejaVu Sans";

    public static IServiceCollection AddAccountingUtils(this IServiceCollection serviceCollection, IExactConfiguration exactConfiguration)
    {
        LoadOptions.DefaultGraphicEngine = new DefaultGraphicEngine(FallbackFont);

        serviceCollection.AddHttpClient("Exact", httpClient =>
        {
            httpClient.BaseAddress = new Uri($"{exactConfiguration.BaseUrl}/");
            httpClient.DefaultRequestHeaders.Add(HeaderNames.Accept, MediaTypeNames.Application.Json);
        });

        return serviceCollection.AddScoped<IExactProvider, ExactProvider>()
            .AddScoped(_ => exactConfiguration)
            .AddScoped<IBankExportProvider>(x => new IngBankExportProvider(x.GetRequiredService<IExcelProvider>()))
            .AddScoped<IExcelProvider, ExcelProvider>();
    }
}