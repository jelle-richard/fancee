using System.Reflection;
using AccountingUtils.Utils.Exceptions;

namespace AccountingUtils.Utils;

public static class ResourceUtils
{
    public static Stream Get(string fileName)
    {
        var assembly = Assembly.GetExecutingAssembly();
        
        return assembly.GetManifestResourceStream(fileName) ?? throw new MissingResourceException(fileName);
    }
}