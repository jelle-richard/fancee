namespace AccountingUtils.Config;

public class ExactConfiguration : IExactConfiguration
{
    public string BaseUrl { get; init; } = default!;
    public string ClientId { get; init; } = default!;
    public string ClientSecret { get; init; } = default!;
    public string OAuthRedirectDomain { get; init; } = default!;
}