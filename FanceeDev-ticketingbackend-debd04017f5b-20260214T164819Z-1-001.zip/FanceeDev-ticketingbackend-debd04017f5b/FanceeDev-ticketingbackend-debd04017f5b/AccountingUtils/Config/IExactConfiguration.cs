namespace AccountingUtils.Config;

public interface IExactConfiguration
{
    public string BaseUrl { get; init; }
    public string ClientId { get; init; }
    public string ClientSecret { get; init; }
    public string OAuthRedirectDomain { get; init; }
}