using System;
using System.Threading.Tasks;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PaymentService.BackgroundTasks.MessageBus;
using PaymentService.Dtos.Shared.Reservation;
using PaymentService.Services.Order;
using PaymentService.Services.Pin;
using RabbitMQ.Client;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.PinTerminal;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace PaymentService.Tests.BackgroundTasks.MessageBus;

public class StartPinTerminalTransactionListenerTests
{
    private readonly StartPinTerminalTransactionListener _sut;
    private readonly Mock<StartPinTerminalTransactionSubscriber> _mockedSubscriber;
    private readonly Mock<ILogger<StartPinTerminalTransactionListener>> _mockedLogger = new();
    private readonly Mock<IPinService> _mockedPinService = new();
    private readonly Mock<IOrderService> _mockedOrderService = new();

    public StartPinTerminalTransactionListenerTests()
    {
        var mockedScope = new Mock<IServiceScope>();
        var mockedScopeFactory = new Mock<IServiceScopeFactory>();
        var mockedServiceProvider = new Mock<IServiceProvider>();
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedScopeFactory.Object);
        mockedScopeFactory.Setup(sf => sf.CreateScope()).Returns(mockedScope.Object);

        var mockedConnection = new Mock<IConnection>();
        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);
        _mockedSubscriber = new(mockedConnection.Object);

        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<StartPinTerminalTransactionMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<StartPinTerminalTransactionListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IPinService))).Returns(_mockedPinService.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IOrderService))).Returns(_mockedOrderService.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToMessageSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.Callback);

        _mockedLogger.VerifyCalled(LogLevel.Information, "[StartPinTerminalTransactionListener] Started");
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsFromMessageSubscriber()
    {
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.Callback);

        _mockedLogger.VerifyCalled(LogLevel.Information, "[StartPinTerminalTransactionListener] Stopped");
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageDoesNothingIfTotalCostCentsIsNull()
    {
        var message = new StartPinTerminalTransactionMessage
        {
            ReservationReference = Guid.NewGuid(),
            TerminalSerialNumber = "test"
        };

        _mockedOrderService.Setup(os => os.ReservationCostCentsAsync(message.ReservationReference)).ReturnsAsync(new ReservationCost
        {
            CurrencyShortCode = null,
            TotalCostCents = null
        });

        await _sut.StartAsync(default);
        _mockedSubscriber.Object.Callback?.Invoke(message);

        _mockedOrderService.Verify(os => os.ReservationCostCentsAsync(message.ReservationReference), Times.Once);
        _mockedPinService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageCallsPinServiceStartTransactionAsync()
    {
        var message = new StartPinTerminalTransactionMessage
        {
            ReservationReference = Guid.NewGuid(),
            TerminalSerialNumber = "test"
        };

        _mockedOrderService.Setup(os => os.ReservationCostCentsAsync(message.ReservationReference)).ReturnsAsync(new ReservationCost
        {
            CurrencyShortCode = "USD",
            TotalCostCents = 1200
        });

        await _sut.StartAsync(default);
        _mockedSubscriber.Object.Callback?.Invoke(message);

        _mockedOrderService.Verify(os => os.ReservationCostCentsAsync(message.ReservationReference), Times.Once);
        _mockedPinService.Verify(ps => ps.StartTransactionAsync(message.TerminalSerialNumber, 1200, "USD", message.ReservationReference.ToString()), Times.Once);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageUsesEurAsFallbackCurrency()
    {
        var message = new StartPinTerminalTransactionMessage
        {
            ReservationReference = Guid.NewGuid(),
            TerminalSerialNumber = "test"
        };

        _mockedOrderService.Setup(os => os.ReservationCostCentsAsync(message.ReservationReference)).ReturnsAsync(new ReservationCost
        {
            CurrencyShortCode = null,
            TotalCostCents = 1200
        });

        await _sut.StartAsync(default);
        _mockedSubscriber.Object.Callback?.Invoke(message);

        _mockedOrderService.Verify(os => os.ReservationCostCentsAsync(message.ReservationReference), Times.Once);
        _mockedPinService.Verify(ps => ps.StartTransactionAsync(message.TerminalSerialNumber, 1200, "EUR", message.ReservationReference.ToString()), Times.Once);
    }
}