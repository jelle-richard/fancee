using System;
using System.Threading.Tasks;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PaymentService.BackgroundTasks.MessageBus;
using PaymentService.Services.Pin;
using RabbitMQ.Client;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.PinTerminal;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace PaymentService.Tests.BackgroundTasks.MessageBus;

public class ValidPinTerminalListenerTests
{
    private readonly ValidPinTerminalListener _sut;
    private readonly Mock<ValidPinTerminalSubscriber> _mockedSubscriber;
    private readonly Mock<ILogger<ValidPinTerminalListener>> _mockedLogger = new();
    private readonly Mock<IPinService> _mockedPinService = new();

    public ValidPinTerminalListenerTests()
    {
        var mockedScope = new Mock<IServiceScope>();
        var mockedScopeFactory = new Mock<IServiceScopeFactory>();
        var mockedServiceProvider = new Mock<IServiceProvider>();
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedScopeFactory.Object);
        mockedScopeFactory.Setup(sf => sf.CreateScope()).Returns(mockedScope.Object);

        var mockedConnection = new Mock<IConnection>();
        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);
        _mockedSubscriber = new(mockedConnection.Object);

        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<ValidPinTerminalMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<ValidPinTerminalListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IPinService))).Returns(_mockedPinService.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToMessageSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.RpcCallback);

        _mockedLogger.VerifyCalled(LogLevel.Information, "[ValidPinTerminalListener] Started");
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsFromMessageSubscriber()
    {
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.RpcCallback);

        _mockedLogger.VerifyCalled(LogLevel.Information, "[ValidPinTerminalListener] Stopped");
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageCallsPinServiceValidTerminalAsync()
    {
        var message = new ValidPinTerminalMessage { SerialNumber = "test" };

        _mockedPinService.Setup(ps => ps.ValidTerminalAsync(message.SerialNumber)).ReturnsAsync(true);

        await _sut.StartAsync(default);

        var actual = await _mockedSubscriber.Object.RpcCallback!.Invoke(message);

        Assert.NotNull(actual);
        Assert.IsType<ValidPinTerminalResponseMessage>(actual);
        Assert.True(((ValidPinTerminalResponseMessage)actual).Valid);

        _mockedPinService.Verify(ps => ps.ValidTerminalAsync(message.SerialNumber), Times.Once);
    }
}