using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Adyen.Model.Nexo;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using PaymentService.Configurations.Adyen;
using PaymentService.Controllers;
using PaymentService.Services.Order;
using PaymentService.Services.Pin;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions;

namespace PaymentService.Tests.Controllers;

public class PinControllerTests
{
    private static readonly string ValidAuthHeader = $"Basic {Convert.ToBase64String("t:p"u8.ToArray())}";

    private readonly PinController _sut;
    private readonly Mock<IPinService> _mockedPinService = new();
    private readonly Mock<IOrderService> _mockedOrderService = new();
    private readonly Mock<ILogger<PinController>> _mockedLogger = new();

    public PinControllerTests()
    {
        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "AdyenSecrets:PinNotificationUsername", "t" },
            { "AdyenSecrets:PinNotificationPassword", "p" }
        });

        _sut = new(_mockedPinService.Object, _mockedOrderService.Object, AdyenConfiguration.FromConfiguration(mockedConfiguration), _mockedLogger.Object);
    }

    [Theory]
    [InlineData("P400Plus-123456789", true)]
    [InlineData("e285-000999888", true)]
    [InlineData("e285-000-999-888", false)]
    [InlineData("P400Plus 000-999-888", false)]
    [InlineData("P400Plus 000999888", false)]
    [InlineData("P400Plus abcdefghi", false)]
    [InlineData("Random text", false)]
    [InlineData("", false)]
    [InlineData("    ", false)]
    [InlineData("VeryLongDeviceNameThatExceedsTwentyCharacters-123456789", false)]
    public void TestThatTerminalRegexParsesExpectedValues(string input, bool expected)
    {
        // We have to un-escape the regex value, as the HTTP-route constraint needs it escaped.
        var actualRegex = PinController.TerminalRegex.Replace("{{", "{")
            .Replace("}}", "}")
            .Replace("[[", "[")
            .Replace("]]", "]");

        var actual = Regex.IsMatch(input, actualRegex);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatValidTerminalCallsPinServiceValidTerminalAsync()
    {
        _mockedPinService.Setup(ps => ps.ValidTerminalAsync("P400Plus-123456789")).ReturnsAsync(true);

        var actual = await _sut.ValidTerminal("P400Plus-123456789");

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<bool>>(((OkObjectResult)actual.Result!).Value);
        Assert.True(((ApiResponse<bool>)((OkObjectResult)actual.Result!).Value!).Data);

        _mockedPinService.Verify(ps => ps.ValidTerminalAsync("P400Plus-123456789"), Times.Once);
    }

    [Fact]
    public async Task TestThatDisplayReturnsAcceptedString()
    {
        _sut.ControllerContext = new()
        {
            HttpContext = new DefaultHttpContext
            {
                Request = { Body = new MemoryStream() }
            }
        };

        var actual = await _sut.Display();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual);
        Assert.Equal("[accepted]", ((OkObjectResult)actual).Value);
    }

    [Fact]
    public async Task TestThatParsePostbackResponseAsyncThrowsMissingRequiredConfigurationEntryExceptionOnMissingConfiguration()
    {
        var mockedConfiguration = ConfigurationMockUtils.Create(new() { { "AdyenSecrets", "" } });

        var sut = new PinController(_mockedPinService.Object, _mockedOrderService.Object, AdyenConfiguration.FromConfiguration(mockedConfiguration), _mockedLogger.Object);

        await Assert.ThrowsAsync<MissingRequiredConfigurationEntryException>(sut.Postback);
    }

    [Fact]
    public async Task TestThatPostbackDoesNothingOnInvalidAuthHeader()
    {
        _sut.ControllerContext = new()
        {
            HttpContext = new DefaultHttpContext
            {
                Request =
                {
                    Headers = { { HeaderNames.Authorization, "" } }
                }
            }
        };

        var actual = await _sut.Postback();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual);
        Assert.Equal("[accepted]", ((OkObjectResult)actual).Value);

        _mockedOrderService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatPostbackDoesNothingOnInvalidStringRequest()
    {
        _sut.ControllerContext = new()
        {
            HttpContext = new DefaultHttpContext
            {
                Request =
                {
                    Headers = { { HeaderNames.Authorization, ValidAuthHeader } },
                    Body = new MemoryStream(Encoding.UTF8.GetBytes("invalid"))
                }
            }
        };

        var actual = await _sut.Postback();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual);
        Assert.Equal("[accepted]", ((OkObjectResult)actual).Value);

        _mockedOrderService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatPostbackDoesNothingOnInvalidJsonRequest()
    {
        _sut.ControllerContext = new()
        {
            HttpContext = new DefaultHttpContext
            {
                Request =
                {
                    Headers = { { HeaderNames.Authorization, ValidAuthHeader } },
                    Body = new MemoryStream(Encoding.UTF8.GetBytes("{\"random\": 3}"))
                }
            }
        };

        var actual = await _sut.Postback();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual);
        Assert.Equal("[accepted]", ((OkObjectResult)actual).Value);

        _mockedLogger.VerifyCalled(LogLevel.Warning, "Could not deserialize Pin Postback request JSON: {\"random\": 3}");
        _mockedOrderService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatPostbackDoesNothingIfTransactionIdIsNotValidGuid()
    {
        _sut.ControllerContext = new()
        {
            HttpContext = new DefaultHttpContext
            {
                Request =
                {
                    Headers = { { HeaderNames.Authorization, ValidAuthHeader } },
                    Body = new MemoryStream(Encoding.UTF8.GetBytes(
                        "{\"SaleToPOIResponse\":{\"PaymentResponse\":{\"SaleData\":{\"SaleTransactionID\":{\"TimeStamp\":\"2018-06-20T09:51:35.000Z\",\"TransactionID\":\"not a guid\"}}},\"MessageHeader\":" +
                        "{\"ProtocolVersion\":\"3.0\",\"SaleID\":\"\",\"MessageClass\":\"Service\",\"MessageCategory\":\"Payment\",\"ServiceID\":\"20095135\",\"POIID\":\"\",\"MessageType\":\"Response\"}}}"
                    ))
                }
            }
        };

        var actual = await _sut.Postback();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual);
        Assert.Equal("[accepted]", ((OkObjectResult)actual).Value);

        _mockedOrderService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatPostbackCallsOrderServiceUpdateOrderPaymentAsync()
    {
        _sut.ControllerContext = new()
        {
            HttpContext = new DefaultHttpContext
            {
                Request =
                {
                    Headers = { { HeaderNames.Authorization, ValidAuthHeader } },
                    Body = new MemoryStream(Encoding.UTF8.GetBytes(
                        "{\"SaleToPOIResponse\":{\"PaymentResponse\":{\"SaleData\":{\"SaleTransactionID\":{\"TransactionID\":\"29835d55-67f1-42da-8cd7-668e85840112\"}},\"PaymentResult\":{\"PaymentAcquirerData\":{\"AcquirerTransactionID\":{\"TransactionID\":\"psp\"}}},\"Response\":" +
                        "{\"Result\":\"Success\"}},\"MessageHeader\":{\"ProtocolVersion\":\"3.0\",\"SaleID\":\"\",\"MessageClass\":\"Service\",\"MessageCategory\":\"Payment\",\"ServiceID\":\"20095135\",\"POIID\":\"\",\"MessageType\":\"Response\"}}}"
                    ))
                }
            }
        };

        var expectedTransactionId = Guid.Parse("29835d55-67f1-42da-8cd7-668e85840112");

        var actual = await _sut.Postback();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual);
        Assert.Equal("[accepted]", ((OkObjectResult)actual).Value);

        _mockedOrderService.Verify(os => os.UpdateOrderPaymentAsync(expectedTransactionId, "psp", ResultType.Success));
    }
}