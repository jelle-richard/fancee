using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Controllers;
using PaymentService.Dtos.Requests.Discount;
using PaymentService.Dtos.Response.Discount;
using PaymentService.Services.Discount;
using TestCore.Mocks;

namespace PaymentService.Tests.Controllers;

public class DiscountControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidDiscountId = Guid.NewGuid();

    private readonly DiscountController _sut;
    private readonly Mock<IDiscountService> _mockedDiscountService = new();

    public DiscountControllerTests()
    {
        _sut = new(_mockedDiscountService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatGetCallsDiscountServiceByIdAsync()
    {
        _mockedDiscountService.Setup(ds => ds.ByIdAsync(ValidOrganizationId, ValidDiscountId))
            .ReturnsAsync(new DiscountResponse());

        var actual = await _sut.Get(ValidDiscountId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDiscountService.Verify(ds => ds.ByIdAsync(ValidOrganizationId, ValidDiscountId), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateCallsDiscountServiceCreateAsync()
    {
        _mockedDiscountService.Setup(ds => ds.CreateAsync(ValidOrganizationId, It.IsAny<DiscountRequest>()))
            .ReturnsAsync(Guid.NewGuid);

        var actual = await _sut.Create(new());

        Assert.IsType<CreatedAtActionResult>(actual.Result);

        _mockedDiscountService.Verify(ds => ds.CreateAsync(ValidOrganizationId, It.IsAny<DiscountRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateCallsDiscountServiceUpdateAsync()
    {
        _mockedDiscountService.Setup(ds => ds.UpdateAsync(ValidOrganizationId, ValidDiscountId, It.IsAny<DiscountRequest>()));

        var actual = await _sut.Update(ValidDiscountId, new());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDiscountService.Verify(ds => ds.UpdateAsync(ValidOrganizationId, ValidDiscountId, It.IsAny<DiscountRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteCallsDiscountServiceRemoveAsync()
    {
        _mockedDiscountService.Setup(ds => ds.RemoveAsync(ValidOrganizationId, ValidDiscountId));

        var actual = await _sut.Delete(ValidDiscountId);

        Assert.IsType<OkResult>(actual);

        _mockedDiscountService.Verify(ds => ds.RemoveAsync(ValidOrganizationId, ValidDiscountId), Times.Once);
    }
}