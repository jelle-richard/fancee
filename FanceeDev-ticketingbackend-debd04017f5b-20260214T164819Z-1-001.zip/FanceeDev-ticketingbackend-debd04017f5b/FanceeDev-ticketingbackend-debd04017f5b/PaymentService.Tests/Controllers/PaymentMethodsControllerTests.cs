using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Controllers;
using PaymentService.Dtos.Response.PaymentMethod;
using PaymentService.Services.Payment;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Requests.Filters.Pagination;
using WebApiCore.Dtos.Shared;
using WebApiCore.Services.Logging;

namespace PaymentService.Tests.Controllers;

public class PaymentMethodsControllerTests
{
    private static readonly Guid ValidAdminId = Guid.NewGuid();

    private readonly PaymentMethodsController _sut;
    private readonly Mock<IPaymentMethodService> _mockedPaymentMethodService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();

    public PaymentMethodsControllerTests()
    {
        _sut = new(_mockedPaymentMethodService.Object, _mockedUserLoggingService.Object);

        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());
    }

    [Fact]
    public async Task TestThatGetPaymentMethodsCallsPaymentMethodServiceActivePaymentMethodsAsync()
    {
        var request = new PaginatedRequest<SearchQueryFilter>
        {
            Page = 1,
            PageSize = 10,
            Options = new() { SearchQuery = string.Empty }
        };

        _mockedPaymentMethodService.Setup(pms => pms.ActivePaymentMethodsAsync(request))
            .ReturnsAsync(new PaginatedResultSet<PaymentMethodListResponse>
            {
                Items = new List<PaymentMethodListResponse>
                {
                    new()
                    {
                        Name = "UnitIdeal"
                    }
                },
                TotalItems = 1
            });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.GetPaymentMethods(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedPaymentMethodService.Verify(pms => pms.ActivePaymentMethodsAsync(request), Times.Once);
        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExportPaymentMethodsCallsPaymentMethodServiceActivePaymentMethodsAsCsvAsyncAndServesFile()
    {
        _mockedPaymentMethodService.Setup(pms => pms.ActivePaymentMethodsAsCsvAsync(It.IsAny<SearchQueryFilter>()))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportPaymentMethods(new());

        Assert.Equal("text/csv", actual.ContentType);
        _mockedPaymentMethodService.Verify(pms => pms.ActivePaymentMethodsAsCsvAsync(It.IsAny<SearchQueryFilter>()), Times.Once);
    }
}