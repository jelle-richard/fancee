using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net.Mime;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Controllers;
using PaymentService.Dtos.Requests.Wallet;
using PaymentService.Dtos.Response.Wallet;
using PaymentService.Dtos.Shared.Wallet;
using PaymentService.Services.Wallet;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Services.Organization;

namespace PaymentService.Tests.Controllers;

public class WalletControllerTests
{
    public static readonly object[][] BalanceByDateRangeTestData =
    {
        new object[] { DateTime.ParseExact("2022-11-24 22:00:34", "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture), DateTime.ParseExact("2022-11-24 22:00:34", "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) },
        new object[] { new DateTime(2020, 3, 22), new DateTime(2019, 2, 22) }
    };

    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly WalletController _sut;
    private readonly Mock<IWalletService> _mockedWalletService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    public WalletControllerTests()
    {
        _sut = new(_mockedWalletService.Object, _mockedOrganizationService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatOrganizationBalanceCallsWalletServiceBalanceAsync()
    {
        var actual = await _sut.OrganizationBalance();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<BalanceResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedWalletService.Verify(ws => ws.BalanceAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatPayoutRequestThrowsFeatureNotEnabledExceptionIfWalletIsNotEnabledForOrganization()
    {
        await Assert.ThrowsAsync<FeatureNotEnabledException>(async () => await _sut.PayoutRequest(new() { Cents = 100 }));

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(It.IsAny<Guid>()), Times.Once);
        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatPayoutRequestCallsWalletServiceAddPayoutRequestAsync()
    {
        _mockedOrganizationService.Setup(os => os.WalletEnabledAsync(ValidOrganizationId)).ReturnsAsync(true);

        var actual = await _sut.PayoutRequest(new() { Cents = 100 });

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.Verify(ws => ws.AddPayoutRequestAsync(ValidOrganizationId, 100), Times.Once);
    }

    [Fact]
    public async Task TestThatOrganizationBalanceByDateRangeThrowsExceededDateRangeExceptionIfDateRangeExceedsMaximumBalanceDateRangeDays()
    {
        var start = DateTime.UtcNow.AddYears(-1);
        var end = DateTime.UtcNow;

        await Assert.ThrowsAsync<ExceededDateRangeException>(async () => await _sut.OrganizationBalanceByDateRange(start, end));

        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Theory]
    [MemberData(nameof(BalanceByDateRangeTestData))]
    public async Task TestThatOrganizationBalanceByDateRangeThrowsInvalidDateRangeExceptionIfStartDateIsAfterOrEqualEndDate(DateTime start, DateTime end)
    {
        await Assert.ThrowsAsync<InvalidDateRangeException>(async () => await _sut.OrganizationBalanceByDateRange(start, end));

        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatOrganizationBalanceByDateRangeCallsWalletServiceDailyBalanceAsync()
    {
        var start = DateTime.ParseExact("2022-11-24 22:00:34", "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
        var end = DateTime.ParseExact("2022-11-30 14:24:08", "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

        var actual = await _sut.OrganizationBalanceByDateRange(start, end);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<DailyBalanceResponse>>>(((OkObjectResult)actual.Result!).Value);

        _mockedWalletService.Verify(ws => ws.DailyBalanceAsync(ValidOrganizationId,
            It.Is<DateTime>(dt => dt.ToString("yyyy-MM-dd HH:mm:ss") == "2022-11-24 00:00:00"),
            It.Is<DateTime>(dt => dt.ToString("yyyy-MM-dd HH:mm:ss") == "2022-11-30 23:59:59")
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatOrganizationTransactionListThrowsFeatureNotEnabledExceptionIfOrganizationHasWalletDisabled()
    {
        await Assert.ThrowsAsync<FeatureNotEnabledException>(async () => await _sut.OrganizationTransactionList(new()));

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatOrganizationTransactionListCallsWalletServiceWalletTransactionsAsync()
    {
        var request = new PaginatedRequest<WalletTransactionFilter>();

        _mockedOrganizationService.Setup(os => os.WalletEnabledAsync(ValidOrganizationId)).ReturnsAsync(true);
        _mockedWalletService.Setup(ws => ws.WalletTransactionsAsync(ValidOrganizationId, request)).ReturnsAsync(new PaginatedResultSet<WalletTransactionItemResponse>
        {
            TotalItems = 1,
            Items = new WalletTransactionItemResponse[]
            {
                new()
                {
                    Id = Guid.Empty,
                    AmountCents = 100,
                    RequestedOn = DateTime.UtcNow,
                    Type = WalletTransactionType.Credit,
                    Currency = new()
                }
            }
        });

        var actual = await _sut.OrganizationTransactionList(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<PaginatedResponse<WalletTransactionItemResponse>>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.Verify(ws => ws.WalletTransactionsAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatOrganizationDownloadPayOutReceiptThrowsFeatureNotEnabledExceptionIfWalletIsNotEnabled()
    {
        await Assert.ThrowsAsync<FeatureNotEnabledException>(async () => await _sut.OrganizationDownloadPayOutReceipt(Guid.Empty));

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatOrganizationDownloadPayOutReceiptCallsWalletServiceDownloadPayOutReceiptAsync()
    {
        var fileId = Guid.NewGuid();
        var stream = new MemoryStream("file"u8.ToArray());

        _mockedOrganizationService.Setup(os => os.WalletEnabledAsync(ValidOrganizationId)).ReturnsAsync(true);
        _mockedWalletService.Setup(ws => ws.DownloadPayOutReceiptAsync(ValidOrganizationId, fileId)).ReturnsAsync(stream);

        var actual = await _sut.OrganizationDownloadPayOutReceipt(fileId);

        Assert.NotNull(actual);
        Assert.IsType<FileStreamResult>(actual);
        Assert.Equal(MediaTypeNames.Application.Pdf, actual.ContentType);
        Assert.Equal("Pay Out Receipt.pdf", actual.FileDownloadName);
        Assert.Equal(stream, actual.FileStream);

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.Verify(ws => ws.DownloadPayOutReceiptAsync(ValidOrganizationId, fileId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatOrganizationExportTransactionsAsCsvCallsWalletServiceWalletTransactionsAsCsvAsyncAndServesFile()
    {
        var request = new WalletTransactionFilter();

        _mockedWalletService.Setup(ws => ws.WalletTransactionsAsCsvAsync(ValidOrganizationId, request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.OrganizationExportTransactionsAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedWalletService.Verify(ws => ws.WalletTransactionsAsCsvAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminBalanceCallsWalletServiceBalanceAsync()
    {
        var actual = await _sut.AdminBalance(ValidOrganizationId);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<BalanceResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedWalletService.Verify(ws => ws.BalanceAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminBalanceByDateRangeThrowsExceededDateRangeExceptionIfDateRangeExceedsMaximumBalanceDateRangeDays()
    {
        var start = DateTime.UtcNow.AddYears(-1);
        var end = DateTime.UtcNow;

        await Assert.ThrowsAsync<ExceededDateRangeException>(async () => await _sut.AdminBalanceByDateRange(ValidOrganizationId, start, end));

        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Theory]
    [MemberData(nameof(BalanceByDateRangeTestData))]
    public async Task TestThatAdminBalanceByDateRangeThrowsInvalidDateRangeExceptionIfStartDateIsAfterOrEqualEndDate(DateTime start, DateTime end)
    {
        await Assert.ThrowsAsync<InvalidDateRangeException>(async () => await _sut.AdminBalanceByDateRange(ValidOrganizationId, start, end));

        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAdminBalanceByDateRangeCallsWalletServiceDailyBalanceAsync()
    {
        var start = DateTime.ParseExact("2022-11-24 22:00:34", "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
        var end = DateTime.ParseExact("2022-11-30 14:24:08", "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

        var actual = await _sut.AdminBalanceByDateRange(ValidOrganizationId, start, end);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<DailyBalanceResponse>>>(((OkObjectResult)actual.Result!).Value);

        _mockedWalletService.Verify(ws => ws.DailyBalanceAsync(ValidOrganizationId,
            It.Is<DateTime>(dt => dt.ToString("yyyy-MM-dd HH:mm:ss") == "2022-11-24 00:00:00"),
            It.Is<DateTime>(dt => dt.ToString("yyyy-MM-dd HH:mm:ss") == "2022-11-30 23:59:59")
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminTransactionListThrowsFeatureNotEnabledExceptionIfOrganizationHasWalletDisabled()
    {
        await Assert.ThrowsAsync<FeatureNotEnabledException>(async () => await _sut.AdminTransactionList(ValidOrganizationId, new()));

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAdminTransactionListCallsWalletServiceWalletTransactionsAsync()
    {
        var request = new PaginatedRequest<WalletTransactionFilter>();

        _mockedOrganizationService.Setup(os => os.WalletEnabledAsync(ValidOrganizationId)).ReturnsAsync(true);
        _mockedWalletService.Setup(ws => ws.WalletTransactionsAsync(ValidOrganizationId, request)).ReturnsAsync(new PaginatedResultSet<WalletTransactionItemResponse>
        {
            TotalItems = 1,
            Items = new WalletTransactionItemResponse[]
            {
                new()
                {
                    Id = Guid.Empty,
                    AmountCents = 100,
                    RequestedOn = DateTime.UtcNow,
                    Type = WalletTransactionType.Credit,
                    Currency = new()
                }
            }
        });

        var actual = await _sut.AdminTransactionList(ValidOrganizationId, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<PaginatedResponse<WalletTransactionItemResponse>>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.Verify(ws => ws.WalletTransactionsAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminDownloadPayOutReceiptThrowsFeatureNotEnabledExceptionIfWalletIsNotEnabled()
    {
        await Assert.ThrowsAsync<FeatureNotEnabledException>(async () => await _sut.AdminDownloadPayOutReceipt(ValidOrganizationId, Guid.Empty));

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAdminDownloadPayOutReceiptCallsWalletServiceDownloadPayOutReceiptAsync()
    {
        var fileId = Guid.NewGuid();
        var stream = new MemoryStream("file"u8.ToArray());

        _mockedOrganizationService.Setup(os => os.WalletEnabledAsync(ValidOrganizationId)).ReturnsAsync(true);
        _mockedWalletService.Setup(ws => ws.DownloadPayOutReceiptAsync(ValidOrganizationId, fileId)).ReturnsAsync(stream);

        var actual = await _sut.AdminDownloadPayOutReceipt(ValidOrganizationId, fileId);

        Assert.NotNull(actual);
        Assert.IsType<FileStreamResult>(actual);
        Assert.Equal(MediaTypeNames.Application.Pdf, actual.ContentType);
        Assert.Equal("Pay Out Receipt.pdf", actual.FileDownloadName);
        Assert.Equal(stream, actual.FileStream);

        _mockedOrganizationService.Verify(os => os.WalletEnabledAsync(ValidOrganizationId), Times.Once);
        _mockedWalletService.Verify(ws => ws.DownloadPayOutReceiptAsync(ValidOrganizationId, fileId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedWalletService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAdminExportTransactionsAsCsvCallsWalletServiceWalletTransactionsAsCsvAsyncAndServesFile()
    {
        var request = new WalletTransactionFilter();

        _mockedWalletService.Setup(ws => ws.WalletTransactionsAsCsvAsync(ValidOrganizationId, request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.AdminExportTransactionsAsCsv(ValidOrganizationId, request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedWalletService.Verify(ws => ws.WalletTransactionsAsCsvAsync(ValidOrganizationId, request), Times.Once);
    }
}