﻿using System;
using System.Threading.Tasks;
using Adyen.Model.Checkout;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Controllers;
using PaymentService.Dtos.Requests.Payment;
using PaymentService.Dtos.Shared.Reservation;
using PaymentService.Services.Order;
using PaymentService.Services.Payment;
using WebApiCore.Dtos.Responses;

namespace PaymentService.Tests.Controllers;

/// <summary>
/// Note that NotificationPostback cannot be unit tested at this time due to the inability of mocking the Request.Headers
/// </summary>
public class PaymentControllerTests
{
    private readonly PaymentController _sut;
    private readonly Mock<IAdyenPaymentService> _mockedAdyenPaymentService;
    private readonly Mock<IOrderService> _mockedOrderService;

    private readonly SessionRequest _sessionRequest = new()
    {
        ReservationReference = new()
    };

    public PaymentControllerTests()
    {
        _mockedAdyenPaymentService = new();
        _mockedOrderService = new();

        _sut = new(_mockedAdyenPaymentService.Object, _mockedOrderService.Object);
    }

    [Fact]
    public async Task TestThatValidReferenceReturnsCreateCheckoutSessionResponse()
    {
        _mockedOrderService.Setup(os => os.ReservationCostCentsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new ReservationCost { CurrencyShortCode = "EUR", TotalCostCents = 1000 });

        _mockedAdyenPaymentService.Setup(aps => aps.CreateSessionAsync(Guid.NewGuid()))
            .ReturnsAsync(new CreateCheckoutSessionResponse(
                amount: new("EUR", 1000L),
                merchantAccount: "unitMerchant",
                reference: "unitRef",
                returnUrl: "unittest.com/shop/shopCode/postback",
                expiresAt: DateTime.UtcNow.AddMinutes(15)
            ));

        var actual = await _sut.CreateSession(_sessionRequest);
        Assert.IsType<ApiResponse<CreateCheckoutSessionResponse>>(((OkObjectResult)actual.Result!).Value);
    }

    [Fact]
    public async Task TestThatPaymentMethodsReturnsPaymentMethodsResponse()
    {
        _mockedAdyenPaymentService.Setup(aps => aps.PaymentMethods())
            .ReturnsAsync(new PaymentMethodsResponse(new()
            {
                new()
                {
                    Brand = "ideal",
                    Name = "iDeal"
                }
            }));

        var actual = await _sut.PaymentMethods();
        Assert.IsType<PaymentMethodsResponse>(((OkObjectResult)actual.Result!).Value);
    }
}