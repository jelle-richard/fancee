using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PaymentService.Controllers;
using PaymentService.Dtos.Requests.Discount;
using PaymentService.Dtos.Response.Discount;
using PaymentService.Services.Discount;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;

namespace PaymentService.Tests.Controllers;

public class DiscountsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly DiscountsController _sut;
    private readonly Mock<IDiscountService> _mockedDiscountService = new();

    public DiscountsControllerTests()
    {
        _sut = new(_mockedDiscountService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatListCallsDiscountServiceListAsync()
    {
        _mockedDiscountService.Setup(ds => ds.ListAsync(ValidOrganizationId, It.IsAny<PaginatedRequest<DiscountFilter>>()))
            .ReturnsAsync(new PaginatedResultSet<DiscountListItemResponse>());

        var actual = await _sut.List(new());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDiscountService.Verify(ds => ds.ListAsync(ValidOrganizationId, It.IsAny<PaginatedRequest<DiscountFilter>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExportCallsDiscountServiceExportAsyncAndServesCsv()
    {
        _mockedDiscountService.Setup(ds => ds.ExportAsync(ValidOrganizationId, It.IsAny<DiscountFilter>()))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.Export(new());

        Assert.Equal("text/csv", actual.ContentType);

        _mockedDiscountService.Verify(ds => ds.ExportAsync(ValidOrganizationId, It.IsAny<DiscountFilter>()), Times.Once);
    }
}