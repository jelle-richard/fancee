using PaymentService.Controllers;
using PaymentService.Services.Refund;

namespace PaymentService.Tests.Controllers;

public class RefundControllerTests
{
    private readonly RefundController _sut;
    private readonly Mock<IRefundService> _mockedRefundService = new();

    public RefundControllerTests()
    {
        _sut = new(_mockedRefundService.Object);
    }
}