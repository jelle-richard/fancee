using AuthService.Dtos.Responses.Auth;
using FanceeData.Models.Ticketing;

namespace AuthService.Dtos;

public class CreateTokenResult
{
    public TokenResponse Token { get; init; }
    public User User { get; init; }
}