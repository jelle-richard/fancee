using AuthService.Persistence.Claims;
using AuthService.Persistence.User;
using AuthService.Services.Auth;
using AuthService.Services.Claims;
using AuthService.Services.User;
using AuthService.Utils.Token;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using WebApiCore;
using WebApiCore.Services.Country;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "AuthService",
        EndpointName = "AuthService v1"
    },
    UseS3Storage = false,
    UseSignalR = false
};

builder.AddDependency<IAuthService, AuthService.Services.Auth.AuthService>(ServiceLifetime.Scoped);
builder.AddDependency<IUserDao, UserDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserContactInfoDao, UserContactInfoDao>(ServiceLifetime.Scoped);
builder.AddDependency<IJwtTokenProvider, AppTeamJwtTokenProvider>(ServiceLifetime.Scoped);
builder.AddDependency<IClaimsService, ClaimsService>(ServiceLifetime.Scoped);
builder.AddDependency<IClaimsDao, ClaimsDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserService, UserService>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();