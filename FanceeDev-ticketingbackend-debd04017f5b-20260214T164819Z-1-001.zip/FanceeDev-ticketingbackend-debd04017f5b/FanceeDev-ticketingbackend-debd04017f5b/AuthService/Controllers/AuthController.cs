﻿using System;
using System.Threading.Tasks;
using AuthService.Dtos.Requests.Auth;
using AuthService.Dtos.Responses.Auth;
using AuthService.Services.Auth;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions.User;
using WebApiCore.Utils;
using WebApiCore.Utils.HttpContext;

namespace AuthService.Controllers;

/// <summary>
/// Contains all the endpoints related to authentication.
/// </summary>
[ApiController]
[Route("/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;

    /// <summary>
    /// AuthController constructor.
    /// </summary>
    /// <param name="authService"></param>
    public AuthController(IAuthService authService)
    {
        _authService = authService;
    }

    /// <summary>
    /// Gets a new token for the user with the given username and password
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [HttpPost]
    [Route("token")]
    [ProducesResponseType(typeof(ApiResponse<TokenResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status429TooManyRequests)]
    public async Task<ActionResult<ApiResponse<TokenResponse>>> Token([FromBody] TokenRequest request)
    {
        var tokenResponse = await _authService.TokenAsync(request.Email, request.Password);

        return Ok(new ApiResponse<TokenResponse>
        {
            Data = tokenResponse
        });
    }

    [HttpPost]
    [Route("token/refresh")]
    [ProducesResponseType(typeof(ApiResponse<TokenResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status429TooManyRequests)]
    public async Task<ActionResult<ApiResponse<TokenResponse>>> RefreshToken([FromBody] TokenRefreshRequest request) =>
        Ok(new ApiResponse<TokenResponse>
        {
            Data = await _authService.RefreshTokenAsync(request.Token)
        });

    [HttpPost]
    [Route("app-team/token")]
    [ProducesResponseType(typeof(ApiResponse<AppTeamTokenResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<AppTeamTokenResponse>>> AppTeamToken([FromBody] AppTeamTokenRequest request) =>
        Ok(new ApiResponse<AppTeamTokenResponse>
        {
            Data = await _authService.TokenAsync((Guid)request.TeamId!)
        });

    [HttpPost]
    [Route("app-team/token/refresh")]
    [ProducesResponseType(typeof(ApiResponse<AppTeamTokenResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<AppTeamTokenResponse>>> RefreshAppTeamToken([FromBody] TokenRefreshRequest request) =>
        Ok(new ApiResponse<AppTeamTokenResponse>
        {
            Data = await _authService.RefreshAppTeamTokenAsync(request.Token)
        });

    [HttpPost]
    [Route("admin/auth/takeover")]
    [Authorize(AdminCrmPermissions.AccountTakeover)]
    [ProducesResponseType(typeof(ApiResponse<TokenResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<TokenResponse>>> AdminTakeover([FromBody] TakeoverRequest request)
    {
        // We check user type here explicitly so only admins can use this endpoint, even if someone
        // gave another user type the takeover permission.
        if (!User.IsAdmin())
            throw new UserNotFoundException();

        return Ok(new ApiResponse<TokenResponse>
        {
            Data = await _authService.TakeoverTokenAsync(request, User.GetFanceeUsersId(), User.GetUserId())
        });
    }
}