using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AuthService.Dtos.Responses.Sessions;
using AuthService.Services.Auth;
using AuthService.Services.User;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils.HttpContext;

namespace AuthService.Controllers;

[ApiController]
[Route("/auth/[controller]")]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class SessionsController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly IUserService _userService;

    public SessionsController(IAuthService authService, IUserService userService)
    {
        _authService = authService;
        _userService = userService;
    }

    [HttpGet]
    [Route("")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<SessionResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<SessionResponse>>>> GetSessions() =>
        Ok(new ApiResponse<IEnumerable<SessionResponse>>
        {
            Data = await _authService.ValidSessionsAsync(User.GetFanceeUsersId())
        });

    [HttpGet]
    [Route("user/{userId:guid}")]
    [Authorize(AdminSessionManagementPermission.List)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<SessionResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<SessionResponse>>>> GetUserSessions(Guid userId)
    {
        var fanceeUsersId = await _userService.FanceeUsersIdAsync(userId);

        return Ok(new ApiResponse<IEnumerable<SessionResponse>>
        {
            Data = await _authService.ValidSessionsAsync(fanceeUsersId)
        });
    }
}