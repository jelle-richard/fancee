﻿using System;
using System.Threading.Tasks;
using AuthService.Services.Auth;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;

namespace AuthService.Controllers;

[ApiController]
[Route("/auth/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class SessionController : ControllerBase
{
    private readonly IAuthService _authService;

    public SessionController(IAuthService authService)
    {
        _authService = authService;
    }

    [HttpDelete]
    [Route("{token}")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteSession(string token)
    {
        await _authService.InvalidateAsync(token);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("user/{userId:guid}/{token}")]
    [Authorize(AdminSessionManagementPermission.Remove)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteUserSession(Guid userId, string token)
    {
        await _authService.InvalidateByAdminAsync(token, userId);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}