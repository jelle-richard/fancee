using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AuthService.Dtos.Requests.Claims;
using AuthService.Dtos.Responses.Claims;
using AuthService.Services.Claims;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.Claim;
using WebApiCore.Dtos.Shared;
using WebApiCore.Utils.HttpContext;

namespace AuthService.Controllers;

[ApiController]
[Route("/auth/[controller]")]
public class ClaimsController : ControllerBase
{
    private readonly IClaimsService _claimsService;

    public ClaimsController(IClaimsService claimsService)
    {
        _claimsService = claimsService;
    }

    [HttpGet]
    [Route("platform")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ClaimHierarchyCategoriesResponse>>), StatusCodes.Status200OK)]
    [Authorize(AdminClaimManagementPermissions.List)]
    public ActionResult<ApiResponse<IEnumerable<ClaimHierarchyCategoriesResponse>>> ListPlatformClaims() =>
        Ok(new ApiResponse<IEnumerable<ClaimHierarchyCategoriesResponse>>
        {
            Data = _claimsService.ListPlatformClaims(null)
        });

    [HttpGet]
    [Route("organization")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ClaimHierarchyCategoriesResponse>>), StatusCodes.Status200OK)]
    [Authorize(ProfilePermissions.Details)]
    public ActionResult<ApiResponse<IEnumerable<ClaimHierarchyCategoriesResponse>>> ListOrganizationClaims() =>
        Ok(new ApiResponse<IEnumerable<ClaimHierarchyCategoriesResponse>>
        {
            Data = _claimsService.ListPlatformClaims(UserType.Organization)
        });

    [HttpGet]
    [Route("{userId:guid}")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<string>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [Authorize(AdminClaimManagementPermissions.List)]
    public async Task<ActionResult<ApiResponse<IEnumerable<string>>>> UserClaims(Guid userId) =>
        Ok(new ApiResponse<IEnumerable<string>>
        {
            Data = await _claimsService.UserClaimsAsync(userId)
        });

    [HttpPost]
    [Route("{userId:guid}")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [Authorize(AdminClaimManagementPermissions.Alter)]
    public async Task<ActionResult> AlterClaims(Guid userId, [FromBody] AlterClaimsRequest request)
    {
        await _claimsService.AlterUserClaimsAsync(userId, request.Claims, null);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("user")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<ClaimsResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<ApiResponse<ClaimsResponse>>> UserTokenClaims() =>
        Ok(new ApiResponse<ClaimsResponse>
        {
            Data = new()
            {
                Claims = await _claimsService.UserClaimsAsync(User.GetUserId())
            }
        });

    [HttpGet]
    [Route("app-team")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<ClaimsResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<ApiResponse<ClaimsResponse>>> AppTeamTokenClaims() =>
        Ok(new ApiResponse<ClaimsResponse>
        {
            Data = new()
            {
                Claims = await _claimsService.AppTeamClaimsAsync(User.GetAppTeamId())
            }
        });
}