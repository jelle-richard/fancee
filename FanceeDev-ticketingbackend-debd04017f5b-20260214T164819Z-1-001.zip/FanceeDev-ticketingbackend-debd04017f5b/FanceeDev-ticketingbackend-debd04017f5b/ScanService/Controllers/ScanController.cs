using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ScanService.Dtos.Requests.Scan;
using ScanService.Dtos.Responses.Scan;
using ScanService.Services.AppTeam;
using ScanService.Services.Event;
using ScanService.Services.Scan;
using ScanService.Services.Scan.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Services.Organization.Exceptions;
using WebApiCore.Utils;
using WebApiCore.Utils.HttpContext;

namespace ScanService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
public class ScanController : ControllerBase
{
    private readonly IScanService _scanService;
    private readonly IOrganizationService _organizationService;
    private readonly IAppTeamService _appTeamService;
    private readonly IEventService _eventService;

    public ScanController(IScanService scanService, IOrganizationService organizationService, IAppTeamService appTeamService, IEventService eventService)
    {
        _scanService = scanService;
        _organizationService = organizationService;
        _appTeamService = appTeamService;
        _eventService = eventService;
    }

    [HttpPost]
    [Route($"{{code:length({IssuedTicket.CodeLengthAttribute})}}")]
    [Authorize(OrganizationTicketPermissions.Scan, AuthenticationSchemes = Schemes.FanceeUsersScheme)]
    [ProducesResponseType(typeof(ApiResponse<ScanResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<ScanResponse>>> SetScanState([FromBody] ScanStateRequestModel request, string code)
    {
        Guid? appTeamId = null;

        if (User.IsAppTeam())
        {
            await ValidateAppTeamScanPermission(code);
            appTeamId = User.GetAppTeamId();
        }
        else
            await ValidateIssuerOfIssuedTicketAsync(code);

        return Ok(new ApiResponse<ScanResponse>
        {
            Data = await _scanService.SetScanStateAsync(code, appTeamId, request)
        });
    }

    [HttpPost]
    [Route($"app-team/{{code:length({IssuedTicket.CodeLengthAttribute})}}")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<ScanResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ScanResponse>>> SetScanStateByAppTeam([FromBody] ScanStateRequestModel request, string code) => await SetScanState(request, code);

    [HttpGet]
    [Route("statistics/{eventId:guid}")]
    [Authorize(OrganizationTicketPermissions.Statistics)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TicketScanStatisticsResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<TicketScanStatisticsResponse>>>> TicketScanStatistics(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new InvalidOrganizationException();

        return Ok(new ApiResponse<IEnumerable<TicketScanStatisticsResponse>>
        {
            Data = await _scanService.EventTicketScansAsync(eventId)
        });
    }

    [HttpGet]
    [Route("statistics/{eventId:guid}/app-team/{appTeamId:guid}")]
    [Authorize(OrganizationTicketPermissions.Statistics)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TicketScanStatistics>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<TicketScanStatistics>>>> EventAppTeamScanStatistics(Guid eventId, Guid appTeamId, [FromQuery] DateTime date)
    {
        if (!await _eventService.EventExists(eventId))
            throw new EventNotFoundException();

        if (!await _appTeamService.IsOwnerOfAppTeam(Request.GetOrganizationId(), appTeamId))
            throw new UnauthorizedAccessException();

        return Ok(new ApiResponse<IEnumerable<TicketScanStatistics>>
        {
            Data = await _scanService.EventAppTeamTicketScansAsync(eventId, appTeamId, date)
        });
    }

    [HttpGet]
    [Route("statistics/app-team/{eventId:guid}")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TicketScanStatisticsResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<TicketScanStatisticsResponse>>>> AppTeamProductScanStatistics(Guid eventId)
    {
        if (!await _eventService.EventExists(eventId))
            throw new EventNotFoundException();

        var productIds = await _appTeamService.ProductsForEventAsync(eventId, User.GetAppTeamId());

        return Ok(new ApiResponse<IEnumerable<TicketScanStatisticsResponse>>
        {
            Data = await _scanService.AppTeamTicketScansAsync(User.GetAppTeamId(), productIds)
        });
    }

    /// <summary>
    /// Checks if the organization is the issuer of the issued ticket.
    /// </summary>
    /// <param name="code"></param>
    /// <exception cref="IssuedTicketNotFoundException"></exception>
    private async Task ValidateIssuerOfIssuedTicketAsync(string code)
    {
        if (!await _scanService.IsIssuerOfIssuedTicketAsync(Request.GetOrganizationId(), code))
            throw new IssuedTicketNotFoundException();
    }

    /// <summary>
    /// Checks if the app team has the rights to scan the issued ticket.
    /// </summary>
    /// <param name="code"></param>
    /// <exception cref="IssuedTicketNotFoundException"></exception>
    private async Task ValidateAppTeamScanPermission(string code)
    {
        if (!await _scanService.IsAppTeamAssignedToTicketForScanningAsync(User.GetAppTeamId(), code))
            throw new IssuedTicketNotFoundException();
    }
}