using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace ScanService.Persistence.Event;

public class EventDao : IEventDao
{
    private readonly TicketingContext _dbContext;

    public EventDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<bool> EventExists(Guid eventId)
    {
        return await _dbContext.Events.AnyAsync(e => e.Id == eventId);
    }
}