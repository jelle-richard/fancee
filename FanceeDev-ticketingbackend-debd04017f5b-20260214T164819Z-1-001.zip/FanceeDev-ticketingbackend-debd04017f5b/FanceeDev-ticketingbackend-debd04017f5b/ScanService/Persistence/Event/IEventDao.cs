namespace ScanService.Persistence.Event;

public interface IEventDao
{
    /// <summary>
    /// Returns whether an event exists with the specified Id.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> EventExists(Guid eventId);
}