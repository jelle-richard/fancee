using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace ScanService.Persistence.AppTeam;

public class AppTeamDao : IAppTeamDao
{
    private readonly TicketingContext _dbContext;

    public AppTeamDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<bool> IsOwnerOfAppTeamAsync(Guid userId, Guid appTeamId)
    {
        return await _dbContext.AppTeams.AnyAsync(at => at.Id == appTeamId && at.OrganizationId == userId);
    }

    public async Task<bool> HasGuestlistScanningEnabledAsync(Guid appTeamId)
    {
        return await _dbContext.AppTeams.AnyAsync(at => at.Id == appTeamId && at.ScanGuestlistEnabled);
    }

    public async Task<IEnumerable<Guid>> ProductsForEventAsync(Guid eventId, Guid appTeamId)
    {
        return await _dbContext.Products.Where(p => p.EventId == eventId)
            .Where(p => p.AppTeams.Any(at => at.Id == appTeamId))
            .Select(p => p.Id)
            .ToListAsync();
    }
}