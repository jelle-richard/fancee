namespace ScanService.Persistence.AppTeam;

public interface IAppTeamDao
{
    /// <summary>
    /// Returns whether the specified user is the owner of the appteam.
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="appTeamId"></param>
    /// <returns></returns>
    public Task<bool> IsOwnerOfAppTeamAsync(Guid userId, Guid appTeamId);

    /// <summary>
    /// Checks if the app team may scan guestlist tickets.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <returns></returns>
    public Task<bool> HasGuestlistScanningEnabledAsync(Guid appTeamId);

    /// <summary>
    /// Returns the products for the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="appTeamId"></param>
    /// <returns></returns>
    public Task<IEnumerable<Guid>> ProductsForEventAsync(Guid eventId, Guid appTeamId);
}