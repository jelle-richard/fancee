using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace ScanService.Persistence.Organization;

public class OrganizationDao : IOrganizationDao
{
    private readonly TicketingContext _dbContext;

    public OrganizationDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<bool> OwnerOfEventAsync(Guid organizationId, Guid eventId)
    {
        return await _dbContext.Events.Where(e => e.Id == eventId)
            .Where(e => e.OrganizationId == organizationId)
            .AnyAsync();
    }
}