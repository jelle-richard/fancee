using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using ScanService.Dtos.Responses.Scan;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Responses.File;

namespace ScanService.Persistence.Ticket;

public class TicketDao : ITicketDao
{
    private readonly TicketingContext _dbContext;

    public TicketDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IssuedTicket?> IssuedTicketAsync(string code)
    {
        return await _dbContext.IssuedTickets.Where(it => it.Code == code)
            .Include(it => it.IssuedProduct.Product.Event.Organization.User)
            .Include(it => it.IssuedProduct.Product.TicketOption)
            .Include(it => it.TicketScans)
            .FirstOrDefaultAsync();
    }

    public async Task<bool> IsIssuerOfIssuedTicketAsync(Guid organizationId, string code)
    {
        return await _dbContext.IssuedTickets.Where(it => it.Code == code)
            .Where(it => it.IssuedProduct.Product.Event.OrganizationId == organizationId)
            .AnyAsync();
    }

    public async Task<bool> IsAppTeamAssignedToProductsForScanningAsync(Guid appTeamId, string issuedTicketCode)
    {
        var issuedProduct = await _dbContext.IssuedTickets.Where(it => it.Code == issuedTicketCode)
            .Select(it => it.IssuedProduct)
            .FirstOrDefaultAsync();

        if (issuedProduct == null)
            return false;

        return await _dbContext.AppTeams.Where(at => at.Id == appTeamId)
            .Where(at => at.ScanningEnabled)
            .Where(at => issuedProduct.Type != IssuedProductType.GuestTicket || at.ScanGuestlistEnabled)
            .Where(at => at.Products.Any(p => p.Id == issuedProduct.ProductId))
            .AnyAsync();
    }

    public async Task<IEnumerable<TicketScanStatisticsResponse>> EventTicketScansAsync(Guid eventId, HostedDeploymentEnvironment env)
    {
        var query = _dbContext.Products.Where(p => p.EventId == eventId);

        return await TicketScanStatistics(query, env);
    }

    public async Task<IEnumerable<TicketScanStatisticsResponse>> AppTeamTicketScansAsync(Guid appTeamId, IEnumerable<Guid> productIds, HostedDeploymentEnvironment env)
    {
        var query = _dbContext.Products.Where(p => productIds.Contains(p.Id));

        return await TicketScanStatistics(query, env);
    }

    public async Task<IEnumerable<TicketScanStatistics>> EventAppTeamTicketScansAsync(Guid eventId, Guid appTeamId, DateTime date)
    {
        // Disclaimer: This query won't win any beauty contest.
        // Multiple people have looked over this and struggled to get the double groupBy to play ball with the LINQ to Entities translation layer to SQL.
        // In this state the query should compile down to just a handful of lines of SQL.
        return await Task.Run(() =>
            _dbContext.TicketScans
                .Where(ts => ts.IssuedTicket.IssuedProduct.Product.EventId == eventId)
                .Where(ts => ts.AppTeamId == appTeamId)
                .Where(ts => ts.DateTime >= date)
                .OrderBy(ts => ts.DateTime)
                .Select(ts => new
                {
                    ts.DateTime,
                    ts.State,
                    IssuedTicket = new { IssuedProduct = new { ts.IssuedTicket.IssuedProduct.ProductId } }
                })
                .AsEnumerable()
                .GroupBy(ts => ts.IssuedTicket.IssuedProduct.ProductId)
                .SelectMany(groupedTs => groupedTs.GroupBy(ts => new { ts.DateTime.Year, ts.DateTime.Month, ts.DateTime.Day, ts.DateTime.Hour }),
                    (groupedTs, groupedDates) => new
                    {
                        groupedTicketScan = groupedTs,
                        IntervalScans = new TicketIntervalScanStatistics
                        {
                            TimeInterval = new(groupedDates.Key.Year, groupedDates.Key.Month, groupedDates.Key.Day, groupedDates.Key.Hour, 0, 0),
                            TicketsScanned = groupedDates.Count(ts => ts.State == ScanState.Scanned),
                            TicketsUnscanned = groupedDates.Count(ts => ts.State == ScanState.Unscanned)
                        }
                    })
                .GroupBy(t => t.groupedTicketScan.Key, t => t.IntervalScans)
                .Select(g => new TicketScanStatistics
                {
                    Name = _dbContext.Products.Where(p => p.Id == g.Key).Select(p => p.Name).First(),
                    IntervalScans = g
                })
                .ToList()
        );
    }

    public async Task<bool> IsGuestTicketAsync(string code)
    {
        return await _dbContext.IssuedProducts.AnyAsync(ip => ip.IssuedTicket.Code == code && ip.Type == IssuedProductType.GuestTicket);
    }

    private async Task<IEnumerable<TicketScanStatisticsResponse>> TicketScanStatistics(IQueryable<Product> productQuery, HostedDeploymentEnvironment env)
    {
        return await productQuery
            .Select(p => new TicketScanStatisticsResponse
            {
                Id = p.Id,
                Name = p.Name,
                Media = p.ProductMedia == null
                    ? Array.Empty<FileResponse>()
                    : p.ProductMedia.Select(pm => new FileResponse
                    {
                        Id = pm.File.Id,
                        Url = $"{env.Scheme}://{env.ContentDeliveryNetworkBaseUrl}/{pm.File.Path}"
                    }),
                AmountIssued = _dbContext.IssuedTickets.Count(it => it.IssuedProduct.ProductId == p.Id),
                AmountScanned = _dbContext.IssuedTickets.Where(it => it.IssuedProduct.ProductId == p.Id)
                    .Count(it => it.TicketScans.Any())
            })
            .ToListAsync();
    }
}