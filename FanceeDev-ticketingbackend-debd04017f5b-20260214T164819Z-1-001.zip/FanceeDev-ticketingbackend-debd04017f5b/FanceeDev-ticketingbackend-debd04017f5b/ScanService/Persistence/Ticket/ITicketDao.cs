using FanceeData.Models.Ticketing;
using ScanService.Dtos.Responses.Scan;
using WebApiCore.Dtos.Environment;

namespace ScanService.Persistence.Ticket;

public interface ITicketDao
{
    /// <summary>
    /// Gets a issued ticket by its code
    /// </summary>
    /// <param name="code"></param>
    /// <returns></returns>
    public Task<IssuedTicket?> IssuedTicketAsync(string code);

    /// <summary>
    /// Checks if organization is issuer of ticket.
    /// </summary>
    /// <returns></returns>
    public Task<bool> IsIssuerOfIssuedTicketAsync(Guid organizationId, string code);

    /// <summary>
    /// Checks if the team is assigned to the issued ticket.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <param name="issuedTicketCode"></param>
    /// <returns></returns>
    public Task<bool> IsAppTeamAssignedToProductsForScanningAsync(Guid appTeamId, string issuedTicketCode);

    /// <summary>
    /// Gets the ticket scan statistics of the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="env"></param>
    /// <returns></returns>
    public Task<IEnumerable<TicketScanStatisticsResponse>> EventTicketScansAsync(Guid eventId, HostedDeploymentEnvironment env);

    /// <summary>
    /// Gets the ticket scan statistics of the event for tickets bound to the app team.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <param name="productIds"></param>
    /// <param name="env"></param>
    /// <returns></returns>
    public Task<IEnumerable<TicketScanStatisticsResponse>> AppTeamTicketScansAsync(Guid appTeamId, IEnumerable<Guid> productIds, HostedDeploymentEnvironment env);

    /// <summary>
    /// Gets an event's ticket scan statistics for the specified app team for the given date and onward.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="appTeamId"></param>
    /// <param name="date"></param>
    /// <returns></returns>
    public Task<IEnumerable<TicketScanStatistics>> EventAppTeamTicketScansAsync(Guid eventId, Guid appTeamId, DateTime date);

    /// <summary>
    /// Checks if the issued ticket is a guestlist ticket.
    /// </summary>
    /// <param name="code"></param>
    /// <returns></returns>
    public Task<bool> IsGuestTicketAsync(string code);
}