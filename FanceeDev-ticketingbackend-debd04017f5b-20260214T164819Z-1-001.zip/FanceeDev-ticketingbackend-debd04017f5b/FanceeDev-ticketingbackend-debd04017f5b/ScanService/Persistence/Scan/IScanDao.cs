using FanceeData.Models.Ticketing;

namespace ScanService.Persistence.Scan;

public interface IScanDao
{
    /// <summary>
    /// Sets a scan state for a ticket by its code
    /// </summary>
    /// <param name="code"></param>
    /// <param name="appTeamId"></param>
    /// <param name="scanState"></param>
    /// <returns></returns>
    public Task InsertScanAsync(string code, Guid? appTeamId, ScanState scanState);
}