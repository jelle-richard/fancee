using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace ScanService.Persistence.Scan;

public class ScanDao : IScanDao
{
    private readonly TicketingContext _dbContext;

    public ScanDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task InsertScanAsync(string code, Guid? appTeamId, ScanState scanState)
    {
        var ticketScan = new TicketScan
        {
            IssuedTicketCode = code,
            DateTime = DateTime.UtcNow,
            AppTeamId = appTeamId,
            State = scanState
        };

        await _dbContext.TicketScans.AddAsync(ticketScan);
        await _dbContext.SaveChangesAsync();
    }
}