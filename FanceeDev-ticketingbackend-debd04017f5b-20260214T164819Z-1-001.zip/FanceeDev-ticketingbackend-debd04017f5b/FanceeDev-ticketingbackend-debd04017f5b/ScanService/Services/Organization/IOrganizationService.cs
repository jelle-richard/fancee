﻿namespace ScanService.Services.Organization;

public interface IOrganizationService
{
    /// <summary>
    /// Returns whether the organization is the owner of the event.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> OwnerOfEventAsync(Guid organizationId, Guid eventId);
}