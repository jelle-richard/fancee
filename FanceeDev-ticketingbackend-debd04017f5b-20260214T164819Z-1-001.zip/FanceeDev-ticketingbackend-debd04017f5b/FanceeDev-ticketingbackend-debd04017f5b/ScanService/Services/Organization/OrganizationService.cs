using ScanService.Persistence.Organization;

namespace ScanService.Services.Organization;

public class OrganizationService : IOrganizationService
{
    private readonly IOrganizationDao _organizationDao;

    public OrganizationService(IOrganizationDao organizationDao)
    {
        _organizationDao = organizationDao;
    }

    public async Task<bool> OwnerOfEventAsync(Guid organizationId, Guid eventId) => await _organizationDao.OwnerOfEventAsync(organizationId, eventId);
}