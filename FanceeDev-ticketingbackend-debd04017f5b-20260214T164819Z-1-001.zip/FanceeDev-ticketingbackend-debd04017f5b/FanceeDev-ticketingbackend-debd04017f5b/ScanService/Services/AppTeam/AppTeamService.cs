using ScanService.Persistence.AppTeam;

namespace ScanService.Services.AppTeam;

public class AppTeamService : IAppTeamService
{
    private readonly IAppTeamDao _appTeamDao;

    public AppTeamService(IAppTeamDao appTeamDao)
    {
        _appTeamDao = appTeamDao;
    }

    public async Task<IEnumerable<Guid>> ProductsForEventAsync(Guid eventId, Guid appTeamId) => await _appTeamDao.ProductsForEventAsync(eventId, appTeamId);

    public async Task<bool> IsOwnerOfAppTeam(Guid userId, Guid appTeamId) => await _appTeamDao.IsOwnerOfAppTeamAsync(userId, appTeamId);
}