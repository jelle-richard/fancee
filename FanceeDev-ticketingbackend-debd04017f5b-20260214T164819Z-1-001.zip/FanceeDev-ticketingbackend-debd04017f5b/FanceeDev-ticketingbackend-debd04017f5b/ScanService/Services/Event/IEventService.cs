namespace ScanService.Services.Event;

public interface IEventService
{
    /// <summary>
    /// Returns whether an event exists with the specified id.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> EventExists(Guid eventId);
}