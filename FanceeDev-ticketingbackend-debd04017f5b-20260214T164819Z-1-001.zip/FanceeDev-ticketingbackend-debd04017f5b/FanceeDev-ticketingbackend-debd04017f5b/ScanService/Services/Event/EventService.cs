using ScanService.Persistence.Event;

namespace ScanService.Services.Event;

public class EventService : IEventService
{
    private readonly IEventDao _eventDao;

    public EventService(IEventDao eventDao)
    {
        _eventDao = eventDao;
    }

    public async Task<bool> EventExists(Guid eventId) => await _eventDao.EventExists(eventId);
}