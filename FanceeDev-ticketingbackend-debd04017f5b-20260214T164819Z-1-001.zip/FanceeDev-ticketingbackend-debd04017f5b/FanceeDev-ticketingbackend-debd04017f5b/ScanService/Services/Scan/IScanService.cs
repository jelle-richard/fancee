using ScanService.Dtos.Requests.Scan;
using ScanService.Dtos.Responses.Scan;

namespace ScanService.Services.Scan;

public interface IScanService
{
    /// <summary>
    /// Scans a ticket by setting a scan state.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="appTeamId"></param>
    /// <param name="code"></param>
    /// <returns></returns>
    public Task<ScanResponse> SetScanStateAsync(string code, Guid? appTeamId, ScanStateRequestModel request);

    /// <summary>
    /// Checks if organization is issuer of ticket.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="code"></param>
    /// <returns></returns>
    public Task<bool> IsIssuerOfIssuedTicketAsync(Guid organizationId, string code);

    /// <summary>
    /// Checks if the team is assigned to the issued ticket.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <param name="code"></param>
    /// <returns></returns>
    public Task<bool> IsAppTeamAssignedToTicketForScanningAsync(Guid appTeamId, string code);

    /// <summary>
    /// Gets the ticket scan statistics of the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<IEnumerable<TicketScanStatisticsResponse>> EventTicketScansAsync(Guid eventId);

    /// <summary>
    /// Gets the ticket scan statistics of the shop bound to the app team.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <param name="productIds"></param>
    /// <returns></returns>
    public Task<IEnumerable<TicketScanStatisticsResponse>> AppTeamTicketScansAsync(Guid appTeamId, IEnumerable<Guid> productIds);

    /// <summary>
    /// Gets an event's ticket scan statistics for the specified app team from the given date onward.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="appTeamId"></param>
    /// <param name="date"></param>
    /// <returns></returns>
    public Task<IEnumerable<TicketScanStatistics>> EventAppTeamTicketScansAsync(Guid eventId, Guid appTeamId, DateTime date);
}