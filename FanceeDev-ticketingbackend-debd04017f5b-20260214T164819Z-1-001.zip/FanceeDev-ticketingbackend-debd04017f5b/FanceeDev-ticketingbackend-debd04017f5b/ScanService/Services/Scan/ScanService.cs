using FanceeData.Models.Ticketing;
using ScanService.Dtos.Requests.Scan;
using ScanService.Dtos.Responses.Scan;
using ScanService.Persistence.AppTeam;
using ScanService.Persistence.Scan;
using ScanService.Persistence.Ticket;
using ScanService.Services.Scan.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.DeploymentEnvironment;

namespace ScanService.Services.Scan;

public class ScanService : IScanService
{
    private readonly IScanDao _scanDao;
    private readonly ITicketDao _ticketDao;
    private readonly IDeploymentEnvironmentService _deploymentEnvironmentService;
    private readonly IAppTeamDao _appTeamDao;

    public ScanService(IScanDao scanDao, ITicketDao ticketDao, IDeploymentEnvironmentService deploymentEnvironmentService, IAppTeamDao appTeamDao)
    {
        _scanDao = scanDao;
        _ticketDao = ticketDao;
        _deploymentEnvironmentService = deploymentEnvironmentService;
        _appTeamDao = appTeamDao;
    }

    public async Task<ScanResponse> SetScanStateAsync(string code, Guid? appTeamId, ScanStateRequestModel request)
    {
        var issuedTicket = await _ticketDao.IssuedTicketAsync(code);

        if (issuedTicket == null)
            throw new IssuedTicketNotFoundException();

        var eventStartDate = CalculateEventStartDate(issuedTicket);
        if (eventStartDate > DateTime.UtcNow)
            throw new TicketScanOccuredBeforeEventStartException(eventStartDate);

        if (issuedTicket.State != TicketState.Active)
            throw new InvalidIssuedTicketStateException(issuedTicket.State.ToString());

        if (issuedTicket.IssuedProduct.Product.Event.EndDate < DateTime.UtcNow || issuedTicket.IssuedProduct.Product.Event.Status != EventStatus.Active)
            throw new EventNotActiveException();

        if (!issuedTicket.IssuedProduct.Product.Event.Organization.IsProfileComplete)
            throw new OrganizationNotVerifiedException();

        var lastTicketScan = issuedTicket.TicketScans?.MaxBy(ts => ts.DateTime);
        if (lastTicketScan != null && lastTicketScan.State == request.State!)
            throw new TicketAlreadyBearsStateException();

        await _scanDao.InsertScanAsync(code, appTeamId, (ScanState)request.State!);

        return new()
        {
            Notification = issuedTicket.IssuedProduct.Product.TicketOption?.ScanNotification
        };
    }

    public async Task<bool> IsIssuerOfIssuedTicketAsync(Guid organizationId, string code) => await _ticketDao.IsIssuerOfIssuedTicketAsync(organizationId, code);

    public async Task<bool> IsAppTeamAssignedToTicketForScanningAsync(Guid appTeamId, string code) =>
        await _ticketDao.IsAppTeamAssignedToProductsForScanningAsync(appTeamId, code);

    public async Task<IEnumerable<TicketScanStatisticsResponse>> EventTicketScansAsync(Guid eventId) => await _ticketDao.EventTicketScansAsync(eventId, await _deploymentEnvironmentService.GetAsync());

    public async Task<IEnumerable<TicketScanStatisticsResponse>> AppTeamTicketScansAsync(Guid appTeamId, IEnumerable<Guid> productIds) => await _ticketDao.AppTeamTicketScansAsync(appTeamId, productIds, await _deploymentEnvironmentService.GetAsync());

    public async Task<IEnumerable<TicketScanStatistics>> EventAppTeamTicketScansAsync(Guid eventId, Guid appTeamId, DateTime date) => await _ticketDao.EventAppTeamTicketScansAsync(eventId, appTeamId, date);

    private static DateTime CalculateEventStartDate(IssuedTicket issuedTicket) =>
        issuedTicket.IssuedProduct.Product.Event.StartDate.AddMinutes(-(issuedTicket.IssuedProduct.Product.TicketOption?.MaximumPreArrivalTimeMinutes ?? 0));
}