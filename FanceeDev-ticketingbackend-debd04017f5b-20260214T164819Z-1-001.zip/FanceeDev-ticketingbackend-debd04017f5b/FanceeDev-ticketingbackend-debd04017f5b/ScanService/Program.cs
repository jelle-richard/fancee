using ScanService.Persistence.AppTeam;
using ScanService.Persistence.Event;
using ScanService.Persistence.Scan;
using ScanService.Persistence.Ticket;
using ScanService.Services.AppTeam;
using ScanService.Services.Event;
using ScanService.Services.Scan;
using WebApiCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "ScanService",
        EndpointName = "ScanService v1"
    },
    UseAuthenticationAndAuthorization = true,
    UseS3Storage = false,
    UseRabbitMq = false,
    UseSignalR = false
};

builder.AddDependency<IScanService, ScanService.Services.Scan.ScanService>(ServiceLifetime.Scoped);
builder.AddDependency<IScanDao, ScanDao>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketDao, TicketDao>(ServiceLifetime.Scoped);
builder.AddDependency<IAppTeamDao, AppTeamDao>(ServiceLifetime.Scoped);
builder.AddDependency<IAppTeamService, AppTeamService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventService, EventService>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();