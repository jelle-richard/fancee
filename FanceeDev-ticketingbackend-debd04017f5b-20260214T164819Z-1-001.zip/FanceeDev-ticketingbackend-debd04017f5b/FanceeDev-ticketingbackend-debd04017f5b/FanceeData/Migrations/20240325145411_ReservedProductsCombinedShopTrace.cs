﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FanceeData.Migrations
{
    /// <inheritdoc />
    public partial class ReservedProductsCombinedShopTrace : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CombinedShopCode",
                table: "ReservedProducts",
                type: "varchar(25)",
                unicode: false,
                maxLength: 25,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ReservedProducts_CombinedShopCode",
                table: "ReservedProducts",
                column: "CombinedShopCode");

            migrationBuilder.AddForeignKey(
                name: "FK_ReservedProducts_CombinedShops_CombinedShopCode",
                table: "ReservedProducts",
                column: "CombinedShopCode",
                principalTable: "CombinedShops",
                principalColumn: "Code");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReservedProducts_CombinedShops_CombinedShopCode",
                table: "ReservedProducts");

            migrationBuilder.DropIndex(
                name: "IX_ReservedProducts_CombinedShopCode",
                table: "ReservedProducts");

            migrationBuilder.DropColumn(
                name: "CombinedShopCode",
                table: "ReservedProducts");
        }
    }
}
