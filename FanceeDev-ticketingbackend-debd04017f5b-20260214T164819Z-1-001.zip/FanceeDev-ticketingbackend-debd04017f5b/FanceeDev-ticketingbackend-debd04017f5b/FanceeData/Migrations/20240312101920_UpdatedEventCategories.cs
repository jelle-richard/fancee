﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace FanceeData.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedEventCategories : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Acupuncture");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Drum 'n Bass");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Judo");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Massage saloon");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rock & Roll");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Soccer");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Social");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Spa");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Spiritual");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Surfing");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Wellness");

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Art",
                column: "Order",
                value: 0);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Business",
                column: "Order",
                value: 3);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Circus",
                column: "Order",
                value: 1);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Fair",
                column: "Order",
                value: 4);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hard Techno",
                column: "Order",
                value: 39);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hardcore",
                column: "Order",
                value: 40);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hardstyle",
                column: "Order",
                value: 41);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "HipHop",
                column: "Order",
                value: 42);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hits",
                column: "Order",
                value: 43);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "House",
                column: "Order",
                value: 44);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "IDM",
                column: "Order",
                value: 45);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Indie",
                column: "Order",
                value: 46);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Italo",
                column: "Order",
                value: 47);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Jazz",
                column: "Order",
                value: 48);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Jungle",
                column: "Order",
                value: 49);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "K-Pop",
                column: "Order",
                value: 50);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kart racing",
                column: "Order",
                value: 28);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kayaking",
                column: "Order",
                value: 29);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kickboxing",
                column: "Order",
                value: 30);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kite Surfing",
                column: "Order",
                value: 31);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Korfball",
                column: "Order",
                value: 32);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kuduro",
                column: "Order",
                value: 51);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Latin",
                column: "Order",
                value: 52);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Leisure",
                column: "Order",
                value: 2);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Lifestyle",
                column: "Order",
                value: 4);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Lounge",
                column: "Order",
                value: 53);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Marathon",
                column: "Order",
                value: 33);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Merengue",
                column: "Order",
                value: 54);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Metal",
                column: "Order",
                value: 55);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Minimal",
                column: "Order",
                value: 56);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "MMA",
                column: "Order",
                value: 34);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Moombahton",
                column: "Order",
                value: 57);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Motorcycling",
                column: "Order",
                value: 35);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Musical",
                column: "Order",
                value: 8);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nederhop",
                column: "Order",
                value: 58);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nederlandstalig",
                column: "Order",
                value: 59);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nederpop",
                column: "Order",
                value: 60);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nu Jazz",
                column: "Order",
                value: 61);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Other",
                column: "Order",
                value: 5);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Pachanga",
                column: "Order",
                value: 62);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Paddle",
                column: "Order",
                value: 36);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Paintball",
                column: "Order",
                value: 37);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Paragliding",
                column: "Order",
                value: 38);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Polo",
                column: "Order",
                value: 29);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Pop",
                column: "Order",
                value: 63);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Progressive",
                column: "Order",
                value: 64);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Psy Trance",
                column: "Order",
                value: 65);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Punk",
                column: "Order",
                value: 66);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Racing",
                column: "Order",
                value: 40);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rafting",
                column: "Order",
                value: 41);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rally",
                column: "Order",
                value: 42);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rap",
                column: "Order",
                value: 67);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Reggae",
                column: "Order",
                value: 68);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Reggaeton",
                column: "Order",
                value: 69);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "RnB",
                column: "Order",
                value: 70);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rock",
                column: "Order",
                value: 71);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rollerblading",
                column: "Order",
                value: 43);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rowing",
                column: "Order",
                value: 44);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rugby",
                column: "Order",
                value: 45);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Running",
                column: "Order",
                value: 46);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Sailin",
                column: "Order",
                value: 47);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Skateboarding",
                column: "Order",
                value: 48);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Skating",
                column: "Order",
                value: 49);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Skiing",
                column: "Order",
                value: 50);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Snooker",
                column: "Order",
                value: 51);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Snowboarding",
                column: "Order",
                value: 52);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Softball",
                column: "Order",
                value: 53);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Squash",
                column: "Order",
                value: 54);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Swimming",
                column: "Order",
                value: 55);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Table Tennis",
                column: "Order",
                value: 56);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Tennis",
                column: "Order",
                value: 57);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Theatre",
                column: "Order",
                value: 11);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Theme park",
                column: "Order",
                value: 12);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Triathlon",
                column: "Order",
                value: 58);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Volleyball",
                column: "Order",
                value: 59);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Wakeboarding",
                column: "Order",
                value: 60);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Waterpolo",
                column: "Order",
                value: 61);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Watersport",
                column: "Order",
                value: 62);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Wrestling",
                column: "Order",
                value: 63);

            migrationBuilder.InsertData(
                table: "EventCategories",
                columns: new[] { "Name", "Active", "Order", "Parent" },
                values: new object[,]
                {
                    { "Drum-n-Bass", true, 25, "Music" },
                    { "Entertainment", true, 3, "Leisure" },
                    { "Getaway", true, 5, "Leisure" },
                    { "Grime", true, 38, "Music" },
                    { "Movie", true, 6, "Leisure" },
                    { "Museum", true, 7, "Leisure" },
                    { "Short trip", true, 9, "Leisure" },
                    { "Show", true, 10, "Leisure" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Drum-n-Bass");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Entertainment");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Getaway");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Grime");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Movie");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Museum");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Short trip");

            migrationBuilder.DeleteData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Show");

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Art",
                column: "Order",
                value: 4);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Business",
                column: "Order",
                value: 4);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Circus",
                column: "Order",
                value: 3);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Fair",
                column: "Order",
                value: 5);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hard Techno",
                column: "Order",
                value: 38);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hardcore",
                column: "Order",
                value: 39);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hardstyle",
                column: "Order",
                value: 40);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "HipHop",
                column: "Order",
                value: 41);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Hits",
                column: "Order",
                value: 42);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "House",
                column: "Order",
                value: 43);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "IDM",
                column: "Order",
                value: 44);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Indie",
                column: "Order",
                value: 45);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Italo",
                column: "Order",
                value: 46);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Jazz",
                column: "Order",
                value: 47);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Jungle",
                column: "Order",
                value: 48);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "K-Pop",
                column: "Order",
                value: 49);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kart racing",
                column: "Order",
                value: 29);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kayaking",
                column: "Order",
                value: 30);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kickboxing",
                column: "Order",
                value: 31);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kite Surfing",
                column: "Order",
                value: 32);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Korfball",
                column: "Order",
                value: 33);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Kuduro",
                column: "Order",
                value: 50);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Latin",
                column: "Order",
                value: 51);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Leisure",
                column: "Order",
                value: 3);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Lifestyle",
                column: "Order",
                value: 5);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Lounge",
                column: "Order",
                value: 52);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Marathon",
                column: "Order",
                value: 34);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Merengue",
                column: "Order",
                value: 53);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Metal",
                column: "Order",
                value: 54);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Minimal",
                column: "Order",
                value: 55);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "MMA",
                column: "Order",
                value: 35);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Moombahton",
                column: "Order",
                value: 56);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Motorcycling",
                column: "Order",
                value: 36);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Musical",
                column: "Order",
                value: 0);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nederhop",
                column: "Order",
                value: 57);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nederlandstalig",
                column: "Order",
                value: 58);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nederpop",
                column: "Order",
                value: 59);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Nu Jazz",
                column: "Order",
                value: 60);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Other",
                column: "Order",
                value: 6);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Pachanga",
                column: "Order",
                value: 61);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Paddle",
                column: "Order",
                value: 37);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Paintball",
                column: "Order",
                value: 38);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Paragliding",
                column: "Order",
                value: 39);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Polo",
                column: "Order",
                value: 40);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Pop",
                column: "Order",
                value: 62);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Progressive",
                column: "Order",
                value: 63);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Psy Trance",
                column: "Order",
                value: 64);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Punk",
                column: "Order",
                value: 65);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Racing",
                column: "Order",
                value: 41);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rafting",
                column: "Order",
                value: 42);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rally",
                column: "Order",
                value: 43);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rap",
                column: "Order",
                value: 66);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Reggae",
                column: "Order",
                value: 67);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Reggaeton",
                column: "Order",
                value: 68);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "RnB",
                column: "Order",
                value: 69);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rock",
                column: "Order",
                value: 70);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rollerblading",
                column: "Order",
                value: 44);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rowing",
                column: "Order",
                value: 45);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Rugby",
                column: "Order",
                value: 46);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Running",
                column: "Order",
                value: 47);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Sailin",
                column: "Order",
                value: 48);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Skateboarding",
                column: "Order",
                value: 49);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Skating",
                column: "Order",
                value: 50);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Skiing",
                column: "Order",
                value: 51);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Snooker",
                column: "Order",
                value: 52);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Snowboarding",
                column: "Order",
                value: 53);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Softball",
                column: "Order",
                value: 55);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Squash",
                column: "Order",
                value: 56);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Swimming",
                column: "Order",
                value: 58);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Table Tennis",
                column: "Order",
                value: 59);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Tennis",
                column: "Order",
                value: 60);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Theatre",
                column: "Order",
                value: 1);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Theme park",
                column: "Order",
                value: 6);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Triathlon",
                column: "Order",
                value: 61);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Volleyball",
                column: "Order",
                value: 62);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Wakeboarding",
                column: "Order",
                value: 63);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Waterpolo",
                column: "Order",
                value: 64);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Watersport",
                column: "Order",
                value: 65);

            migrationBuilder.UpdateData(
                table: "EventCategories",
                keyColumn: "Name",
                keyValue: "Wrestling",
                column: "Order",
                value: 66);

            migrationBuilder.InsertData(
                table: "EventCategories",
                columns: new[] { "Name", "Active", "Order", "Parent" },
                values: new object[,]
                {
                    { "Drum 'n Bass", true, 25, "Music" },
                    { "Judo", true, 28, "Sports" },
                    { "Rock & Roll", true, 71, "Music" },
                    { "Soccer", true, 54, "Sports" },
                    { "Surfing", true, 57, "Sports" },
                    { "Wellness", true, 2, null },
                    { "Acupuncture", true, 2, "Wellness" },
                    { "Massage saloon", true, 1, "Wellness" },
                    { "Social", true, 4, "Wellness" },
                    { "Spa", true, 0, "Wellness" },
                    { "Spiritual", true, 3, "Wellness" }
                });
        }
    }
}
