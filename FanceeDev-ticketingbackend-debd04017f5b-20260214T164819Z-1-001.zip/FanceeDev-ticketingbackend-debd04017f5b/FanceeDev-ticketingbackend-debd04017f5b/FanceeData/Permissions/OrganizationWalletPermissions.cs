using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Organization wallet")]
[LimitPermission(UserType.Organization)]
public class OrganizationWalletPermissions : IPermissions
{
    [Description("Allows insights in the wallet")]
    public const string Insights = "organization.wallet.insights";

    [Description("Enabled wallet pay outs")]
    [DependsOn(Insights)]
    public const string PayOut = "organization.wallet.payout";

    [Description("Allows wallet payout exports")]
    [DependsOn(Insights)]
    public const string Export = "organization.wallet.export";
}