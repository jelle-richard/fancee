using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Organization refunds")]
[LimitPermission(UserType.Organization)]
public class OrganizationRefundPermissions : IPermissions
{
    [Description("Request refunds")]
    public const string Request = "organization.refund.request";

    [Description("Accept refund requests")]
    public const string Accept = "organization.refund.accept";
}