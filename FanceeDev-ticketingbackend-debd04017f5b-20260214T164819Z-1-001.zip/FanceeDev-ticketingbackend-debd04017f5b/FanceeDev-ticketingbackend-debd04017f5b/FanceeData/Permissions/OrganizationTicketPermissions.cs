using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Tickets")]
[LimitPermission(UserType.Organization)]
public class OrganizationTicketPermissions : IPermissions
{
    [Description("Scan tickets")]
    public const string Scan = "organization.ticket.scan";

    [Description("View ticket statistics")]
    public const string Statistics = "organization.ticket.statistics";

    [Description("Edit tickets")]
    public const string Edit = "organization.ticket.edit";
}