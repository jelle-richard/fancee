using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin contract handling")]
public class AdminContractPermissions : IPermissions
{
    [Description("List organization contracts")]
    public const string AdminList = "admin.organization.contract.list";

    [Description("View organization contract")]
    [DependsOn(AdminList)]
    public const string AdminDetails = "admin.organization.contract.details";

    [Description("Alter organization invoice/contract")]
    [DependsOn(AdminDetails)]
    public const string AdminAlter = "admin.organization.contract.alter";
}