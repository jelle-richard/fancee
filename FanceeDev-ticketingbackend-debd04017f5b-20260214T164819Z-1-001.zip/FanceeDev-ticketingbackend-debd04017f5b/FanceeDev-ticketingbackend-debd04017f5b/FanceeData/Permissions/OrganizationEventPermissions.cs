﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Events")]
[LimitPermission(UserType.Organization)]
public class OrganizationEventPermissions : IPermissions
{
    [Description("View event listings & agenda")]
    public const string List = "organization.event.list";

    [Description("View event insights")]
    [DependsOn(List)]
    public const string Details = "organization.event.details";

    [Description("Export event listings & agenda")]
    [DependsOn(List)]
    public const string Export = "organization.event.export";

    [Description("Create and Configure event")]
    [DependsOn(Details)]
    public const string Configure = "organization.event.configure";

    [Description("Allow event type normal")]
    [DependsOn(Configure)]
    public const string TypeNormal = "organization.event.type.normal";

    [Description("Allow event type timeslotted")]
    [DependsOn(Configure)]
    public const string TypeTimeslotted = "organization.event.type.timeslotted";

    [Description("Allow event type seating")]
    [DependsOn(Configure)]
    public const string TypeSeating = "organization.event.type.seating";

    [Description("Allow creation of event cancellation requests")]
    public const string Cancel = "organization.event.cancellation.create";
}