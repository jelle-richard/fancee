using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Customer insights")]
[LimitPermission(UserType.Organization)]
public class OrganizationCustomerInsightPermissions : IPermissions
{
    [Description("View customer details")]
    public const string View = "organization.customerinsight.view";

    [Description("Export customer details")]
    [DependsOn(View)]
    public const string Export = "organization.customerinsight.export";
}