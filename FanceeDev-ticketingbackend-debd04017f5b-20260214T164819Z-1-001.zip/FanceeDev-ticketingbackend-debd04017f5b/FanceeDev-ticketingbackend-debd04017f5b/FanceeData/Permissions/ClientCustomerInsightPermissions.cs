using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Customer insights")]
[LimitPermission(UserType.Client)]
public class ClientCustomerInsightPermissions : IPermissions
{
    [Description("View customer details")]
    public const string View = "client.customerinsight.view";

    [Description("Export customer details")]
    [DependsOn(View)]
    public const string Export = "client.customerinsight.export";
}