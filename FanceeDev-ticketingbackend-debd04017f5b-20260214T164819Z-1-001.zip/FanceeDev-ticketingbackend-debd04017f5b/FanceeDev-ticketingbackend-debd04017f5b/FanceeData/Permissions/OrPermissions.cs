namespace FanceeData.Permissions;

public static class OrPermissions
{
    public const string ViewInvoicePermission = $"{OrganizationInvoicePermissions.Details},{AdminInvoicePermissions.Details}";
    public const string ViewCustomerInsightPermission = $"{ClientCustomerInsightPermissions.View},{OrganizationCustomerInsightPermissions.View},{AdminCustomerInsightPermissions.View}";
    public const string EditTicketPermissions = $"{ClientTicketPermissions.Edit},{OrganizationTicketPermissions.Edit}";
}