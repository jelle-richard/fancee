using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Managing of organization secure shops")]
[LimitPermission(UserType.Organization)]
public class OrganizationSecureShopPermissions : IPermissions
{
    [Description("Viewing the secure codes of a shop")]
    public const string List = "organization.secureshop.list";

    [DependsOn(List)]
    [Description("Exporting secure codes of a shop")]
    public const string Export = "organization.secureshop.export";

    [DependsOn(List)]
    [Description("Adding new secure codes to a shop")]
    public const string Add = "organization.secureshop.add";

    [DependsOn(List)]
    [Description("Altering existing secure codes of a shop")]
    public const string Alter = "organization.secureshop.alter";

    [DependsOn(List)]
    [Description("Deleting secure codes of a shop")]
    public const string Delete = "organization.secureshop.delete";
}