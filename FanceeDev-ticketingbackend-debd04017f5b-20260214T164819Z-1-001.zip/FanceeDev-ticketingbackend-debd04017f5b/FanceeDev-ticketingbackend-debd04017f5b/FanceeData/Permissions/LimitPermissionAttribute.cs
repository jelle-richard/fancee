using System;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[AttributeUsage(AttributeTargets.Class)]
public class LimitPermissionAttribute : Attribute
{
    public UserType LimitTo { get; private set; }

    public LimitPermissionAttribute(UserType limitTo)
    {
        LimitTo = limitTo;
    }
}