﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin invoice rules")]
public class AdminRulePermissions : IPermissions
{
    [Description("View custom rules")]
    public const string Details = "admin.rule.details";

    [Description("Configure custom rules")]
    [DependsOn(Details)]
    public const string Configure = "admin.rule.configure";
}