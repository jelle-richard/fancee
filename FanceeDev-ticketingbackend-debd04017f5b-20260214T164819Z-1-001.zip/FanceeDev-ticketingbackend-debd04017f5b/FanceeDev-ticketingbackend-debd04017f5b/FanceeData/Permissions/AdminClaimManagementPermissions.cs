using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Claim management")]
public class AdminClaimManagementPermissions : IPermissions
{
    [Description("Viewing claims")]
    public const string List = "admin.claims.list";

    [Description("Altering user claims")]
    [DependsOn(List)]
    public const string Alter = "admin.claims.alter";
}