﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin invoicing")]
public class AdminInvoicePermissions : IPermissions
{
    [Description("List views")]
    public const string List = "admin.invoice.list";

    [Description("Export invoice details")]
    [DependsOn(List)]
    public const string Export = "admin.invoice.export";

    [Description("Detailed insights")]
    [DependsOn(List)]
    public const string Details = "admin.invoice.details";

    [Description("New invoice booking")]
    [DependsOn(List)]
    public const string Add = "admin.invoice.add";
}