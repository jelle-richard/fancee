﻿using System;

namespace FanceeData.Permissions;

[AttributeUsage(AttributeTargets.Field)]
public class DependsOnAttribute : Attribute
{
    public string[] Permissions { get; }

    public DependsOnAttribute(params string[] permissions)
    {
        Permissions = permissions;
    }
}