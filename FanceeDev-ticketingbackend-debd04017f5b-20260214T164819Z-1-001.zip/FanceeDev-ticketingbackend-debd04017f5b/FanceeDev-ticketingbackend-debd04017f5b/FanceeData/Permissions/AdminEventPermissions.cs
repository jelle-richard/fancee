using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin events")]
public class AdminEventPermissions : IPermissions
{
    [Description("View event listings & agenda")]
    public const string List = "admin.event.list";

    [Description("View event insights")]
    [DependsOn(List)]
    public const string Details = "admin.event.details";

    [Description("Export event listings & agenda")]
    [DependsOn(List)]
    public const string Export = "admin.event.export";
}