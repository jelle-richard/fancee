using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Campaigns")]
[LimitPermission(UserType.Organization)]
public class OrganizationCampaignPermissions : IPermissions
{
    [Description("View campaign listings")]
    public const string List = "organization.campaigns.list";

    [Description("Create and configure campaigns")]
    [DependsOn(List)]
    public const string Configure = "organization.campaigns.configure";

    [Description("Export campaign listings")]
    [DependsOn(List)]
    public const string Export = "organization.campaigns.export";
}