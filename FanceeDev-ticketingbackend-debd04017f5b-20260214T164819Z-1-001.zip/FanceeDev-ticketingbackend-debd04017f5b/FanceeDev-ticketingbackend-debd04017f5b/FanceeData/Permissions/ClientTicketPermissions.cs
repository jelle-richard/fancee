using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Tickets")]
[LimitPermission(UserType.Client)]
public class ClientTicketPermissions : IPermissions
{
    [Description("Edit tickets")]
    public const string Edit = "client.ticket.edit";
}