﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Organization)]
[Description("Organization Agenda Iframes")]
public class OrganizationAgendaIframePermissions : IPermissions
{
    [Description("List Agenda Iframes")]
    public const string List = "organization.agenda.iframe.list";

    [Description("View Agenda Iframe")]
    public const string View = "organization.agenda.iframe.view";

    [Description("Edit Agenda Iframe")]
    public const string Edit = "organization.agenda.iframe.edit";

    [Description("Create Agenda Iframe")]
    public const string Create = "organization.agenda.iframe.create";

    [Description("Delete Agenda Iframe")]
    public const string Delete = "organization.agenda.iframe.delete";
}