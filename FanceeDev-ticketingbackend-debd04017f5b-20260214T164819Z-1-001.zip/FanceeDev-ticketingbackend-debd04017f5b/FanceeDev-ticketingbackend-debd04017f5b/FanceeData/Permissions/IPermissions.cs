﻿namespace FanceeData.Permissions;

public interface IPermissions;