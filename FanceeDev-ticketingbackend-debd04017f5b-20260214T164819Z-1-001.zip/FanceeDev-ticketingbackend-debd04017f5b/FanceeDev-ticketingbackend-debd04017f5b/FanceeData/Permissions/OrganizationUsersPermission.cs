using System.ComponentModel;

namespace FanceeData.Permissions;

[Description("Managing organization users")]
public class OrganizationUsersPermissions : IPermissions
{
    [DependsOn(List)]
    [Description("Add new organization users")]
    public const string Add = "organization.users.add";

    [DependsOn(List)]
    [Description("Delete a organzation users")]
    public const string Delete = "organization.users.delete";

    [Description("View organization users")]
    public const string List = "organization.users.list";
}