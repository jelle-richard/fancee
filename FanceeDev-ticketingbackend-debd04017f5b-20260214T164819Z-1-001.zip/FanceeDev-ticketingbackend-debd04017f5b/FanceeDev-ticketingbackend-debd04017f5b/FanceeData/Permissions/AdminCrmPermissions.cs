using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Crm management")]
public class AdminCrmPermissions : IPermissions
{
    [Description("User creation")]
    public const string CreateUser = "admin.crm.create.user";

    [Description("Retrieve CRM admins")]
    public const string ListAdmins = "admin.crm.list.admin";

    [Description("Creation of a customer service employee admin")]
    public const string CreateCustomerServiceEmployee = "admin.crm.create.customerserviceemployee";

    [Description("Creation of a country manager admin")]
    public const string CreateCountryManager = "admin.crm.create.countrymanager";

    [Description("View growth statistics")]
    public const string Growth = "admin.crm.growth";

    [Description("Alter growth targets")]
    public const string GrowthEdit = "admin.crm.growthedit";

    [Description("Setup 3rd party integrations")]
    public const string IntegrateSoftware = "admin.crm.integratesoftware";

    [Description("Assigning customer service employees to country manager")]
    public const string AssignCountryManager = "admin.crm.countrymanager.assign";

    [Description("Create and download pay out exports")]
    public const string PayOutExport = "admin.crm.payout.export";

    [Description("Allows an admin to take over other (non-admin) accounts")]
    public const string AccountTakeover = "admin.crm.account.takeover";

    [Description("Block users")]
    public const string BlockUser = "admin.crm.block.user";

    [Description("List events balances mutations")]
    public const string ListEventBalancesMutations = "admin.crm.events.balances.list";

    [Description("Yearly balance insights")]
    public const string BalanceInsights = "admin.crm.balance";
}