using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Contract handling")]
[LimitPermission(UserType.Organization)]
public class OrganizationContractPermissions : IPermissions
{
    [Description("List own contracts")]
    public const string List = "organization.contract.list";

    [Description("View own contract")]
    [DependsOn(List)]
    public const string Details = "organization.contract.details";
}