using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Guest list")]
[LimitPermission(UserType.Organization)]
public class OrganizationGuestListPermissions : IPermissions
{
    [Description("View guest list details")]
    public const string Details = "organization.guestlist.details";

    [DependsOn(Details)]
    [Description("Allows guest list import")]
    public const string Import = "organization.guestlist.import";
}