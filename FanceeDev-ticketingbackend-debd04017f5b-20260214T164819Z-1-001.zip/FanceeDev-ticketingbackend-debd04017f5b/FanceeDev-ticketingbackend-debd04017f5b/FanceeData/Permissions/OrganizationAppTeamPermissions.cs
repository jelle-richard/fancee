using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("App teams")]
[LimitPermission(UserType.Organization)]
public class OrganizationAppTeamPermissions : IPermissions
{
    [Description("View team listings")]
    public const string List = "organization.appteam.list";

    [Description("Team specific insights")]
    [DependsOn(List)]
    public const string Details = "organization.appteam.details";

    [Description("Adding teams")]
    [DependsOn(List)]
    public const string Add = "organization.appteam.add";

    [Description("Removing teams")]
    [DependsOn(List)]
    public const string Remove = "organization.appteam.remove";
}