using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Discounts")]
[LimitPermission(UserType.Organization)]
public class OrganizationDiscountPermissions : IPermissions
{
    [Description("View created discounts")]
    public const string List = "organization.discount.list";

    [Description("Discount specific insights")]
    [DependsOn(List)]
    public const string Details = "organization.discount.details";

    [Description("Export rights")]
    [DependsOn(Details)]
    public const string Export = "organization.discount.export";

    [Description("Adding discounts")]
    [DependsOn(List)]
    public const string Add = "organization.discount.add";

    [Description("Removing discounts")]
    [DependsOn(List)]
    public const string Remove = "organization.discount.remove";
}