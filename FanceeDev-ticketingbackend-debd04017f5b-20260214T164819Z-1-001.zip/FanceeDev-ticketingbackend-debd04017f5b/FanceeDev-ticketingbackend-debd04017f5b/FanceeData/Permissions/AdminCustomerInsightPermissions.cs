using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Customer insights for admins")]
public class AdminCustomerInsightPermissions : IPermissions
{
    [Description("View customer details")]
    public const string View = "admin.customerinsight.view";
}