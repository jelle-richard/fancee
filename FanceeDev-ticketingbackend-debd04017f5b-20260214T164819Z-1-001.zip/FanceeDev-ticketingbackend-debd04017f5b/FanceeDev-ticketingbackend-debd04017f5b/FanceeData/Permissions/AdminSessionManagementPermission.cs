using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin sessions")]
public class AdminSessionManagementPermission : IPermissions
{
    [Description("Listing sessions")]
    public const string List = "admin.sessionmanagement.list";

    [Description("Removing sessions")]
    [DependsOn(List)]
    public const string Remove = "admin.sessionmanagement.remove";
}