using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Combined shops")]
[LimitPermission(UserType.Organization)]
public class OrganizationCombinedShopPermissions : IPermissions
{
    [Description("View combined shop listings")]
    public const string List = "organization.combinedshop.list";

    [Description("Share shops for combined shops usage")]
    public const string Share = "organization.combinedshop.share";

    [Description("Export combined shops")]
    [DependsOn(List)]
    public const string Export = "organization.combinedshop.export";

    [Description("View combined shop insights")]
    [DependsOn(List)]
    public const string Details = "organization.combinedshop.details";

    [Description("Add combined shops")]
    [DependsOn(List)]
    public const string Add = "organization.combinedshop.add";

    [Description("Alter combined shops")]
    [DependsOn(List)]
    public const string Alter = "organization.combinedshop.alter";

    [Description("Deleting combined shops")]
    [DependsOn(List)]
    public const string Delete = "organization.combinedshop.delete";
}