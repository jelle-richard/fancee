using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin orders")]
public class AdminOrderPermissions : IPermissions
{
    [Description("Listing orders")]
    public const string List = "admin.order.list";

    [DependsOn(List)]
    [Description("Listing orders")]
    public const string Export = "admin.order.export";

    [DependsOn(List)]
    [Description("Explicit resend of orders")]
    public const string Resend = "admin.order.resend";
}