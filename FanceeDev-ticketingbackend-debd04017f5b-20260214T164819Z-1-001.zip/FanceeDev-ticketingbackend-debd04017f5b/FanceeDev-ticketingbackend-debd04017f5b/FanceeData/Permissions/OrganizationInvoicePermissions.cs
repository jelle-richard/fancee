﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Invoices")]
[LimitPermission(UserType.Organization)]
public class OrganizationInvoicePermissions : IPermissions
{
    [Description("View invioce listings")]
    public const string List = "organization.invoice.list";

    [Description("View invoice details")]
    [DependsOn(List)]
    public const string Details = "organization.invoice.details";

    [Description("Export invoice details")]
    [DependsOn(List)]
    public const string Export = "organization.invoice.export";
}