using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Sale permissions")]
[LimitPermission(UserType.Organization)]
public class OrganizationSalePermissions : IPermissions
{
    [Description("Sets if cash payments are allowed")]
    public const string AllowCashPayments = "organization.sale.payments.cash";
}