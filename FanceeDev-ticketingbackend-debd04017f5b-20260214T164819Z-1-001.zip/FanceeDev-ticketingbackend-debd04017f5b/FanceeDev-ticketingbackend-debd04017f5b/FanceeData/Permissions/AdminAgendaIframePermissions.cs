﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin Agenda Iframes")]
public class AdminAgendaIframePermissions : IPermissions
{
    [Description("List Agenda Iframes")]
    public const string List = "admin.agenda.iframe.list";

    [Description("Edit Agenda Iframe")]
    public const string Edit = "admin.agenda.iframe.edit";

    [Description("View Agenda Iframe")]
    public const string View = "admin.agenda.iframe.view";
}