using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin organization wallets")]
public class AdminWalletPermissions : IPermissions
{
    [Description("Allows insights in the wallet")]
    public const string Insights = "admin.organization.wallet.insights";

    [Description("Enabled wallet pay outs")]
    [DependsOn(Insights)]
    public const string PayOut = "admin.organization.wallet.payout";

    [Description("Allows wallet payout exports")]
    [DependsOn(Insights)]
    public const string Export = "admin.organization.wallet.export";
}