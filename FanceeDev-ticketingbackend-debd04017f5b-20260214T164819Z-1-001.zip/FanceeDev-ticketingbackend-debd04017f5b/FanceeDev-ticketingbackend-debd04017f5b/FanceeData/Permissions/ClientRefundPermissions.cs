using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Client refunds")]
[LimitPermission(UserType.Client)]
public class ClientRefundPermissions : IPermissions
{
    [Description("Request refunds")]
    public const string Request = "client.refund.request";
}