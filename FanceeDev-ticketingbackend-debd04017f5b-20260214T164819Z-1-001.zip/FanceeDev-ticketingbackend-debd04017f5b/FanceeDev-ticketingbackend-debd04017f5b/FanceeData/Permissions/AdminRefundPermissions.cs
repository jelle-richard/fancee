using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin refund permissions")]
public class AdminRefundPermissions : IPermissions
{
    [Description("Grant refunds")]
    public const string Grant = "admin.refund.grant";
}