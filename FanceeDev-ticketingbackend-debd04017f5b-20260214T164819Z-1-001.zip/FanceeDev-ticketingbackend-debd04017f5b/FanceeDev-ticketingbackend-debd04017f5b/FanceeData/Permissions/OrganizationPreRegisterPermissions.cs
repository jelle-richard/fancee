﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[Description("Pre registers")]
[LimitPermission(UserType.Organization)]
public class OrganizationPreRegisterPermissions : IPermissions
{
    [Description("View pre register listings")]
    public const string List = "organization.preregister.list";

    [Description("Export pre registers")]
    [DependsOn(List)]
    public const string Export = "organization.preregister.export";

    [Description("View pre register details")]
    [DependsOn(List)]
    public const string Details = "organization.preregister.details";

    [Description("Create and configure pre register")]
    [DependsOn(Details)]
    public const string Configure = "organization.preregister.configure";
}