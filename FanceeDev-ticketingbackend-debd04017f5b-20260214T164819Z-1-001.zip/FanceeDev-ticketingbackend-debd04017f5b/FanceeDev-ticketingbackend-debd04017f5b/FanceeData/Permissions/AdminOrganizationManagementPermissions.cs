﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin organizations")]
public class AdminOrganizationManagementPermissions : IPermissions
{
    [Description("Listing organizations")]
    public const string List = "admin.organizationmanagement.list";

    [DependsOn(List)]
    [Description("Viewing organization details")]
    public const string Details = "admin.organizationmanagement.details";

    [DependsOn(Details)]
    [Description("Exporting organizations")]
    public const string Export = "admin.organizationmanagement.export";

    [DependsOn(Details)]
    [Description("Editing organizations")]
    public const string Edit = "admin.organizationmanagement.edit";
}