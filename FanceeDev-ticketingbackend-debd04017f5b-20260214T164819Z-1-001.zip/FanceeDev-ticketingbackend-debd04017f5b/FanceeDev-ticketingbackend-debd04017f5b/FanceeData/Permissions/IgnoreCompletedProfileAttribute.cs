using System;

namespace FanceeData.Permissions;

[AttributeUsage(AttributeTargets.Field | AttributeTargets.Class)]
public class IgnoreCompletedProfileAttribute : Attribute
{
}