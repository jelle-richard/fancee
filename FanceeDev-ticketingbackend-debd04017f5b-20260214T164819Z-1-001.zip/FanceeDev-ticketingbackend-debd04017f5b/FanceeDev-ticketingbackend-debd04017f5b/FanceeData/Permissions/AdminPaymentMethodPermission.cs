using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[LimitPermission(UserType.Admin)]
[Description("Admin payment provider")]
public class AdminPaymentMethodPermission : IPermissions
{
    [Description("Listing payment methods")]
    public const string List = "admin.paymentmethod.list";

    [Description("Export payment methods")]
    [DependsOn(List)]
    public const string Export = "admin.paymentmethod.export";
}