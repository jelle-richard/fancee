﻿using System.ComponentModel;
using FanceeData.Models.Ticketing;

namespace FanceeData.Permissions;

[IgnoreCompletedProfile]
[LimitPermission(UserType.All)]
[Description("Profile permissions")]
public class ProfilePermissions : IPermissions
{
    [Description("View profile details")]
    public const string Details = "profile.details";

    [Description("Edit profile")]
    [DependsOn(Details)]
    public const string Edit = "profile.edit";
}