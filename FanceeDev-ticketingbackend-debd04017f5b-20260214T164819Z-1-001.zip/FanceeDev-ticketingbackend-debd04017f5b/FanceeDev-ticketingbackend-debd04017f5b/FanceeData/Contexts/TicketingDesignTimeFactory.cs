using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace FanceeData.Contexts;

/// <summary>
/// This class enables creating the TicketingContext on design time without specifying a --startup-project.
/// Note: make sure the connection string is available in the user secrets for FanceeData.
/// </summary>
public class TicketingDesignTimeFactory : IDesignTimeDbContextFactory<TicketingContext>
{
    public TicketingContext CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .AddUserSecrets<TicketingDesignTimeFactory>(false)
            .Build();

        var builder = new DbContextOptionsBuilder<TicketingContext>();
        var connectionString = configuration.GetConnectionString("FanceeData");
        builder.UseSqlServer(connectionString);

        return new(builder.Options);
    }
}