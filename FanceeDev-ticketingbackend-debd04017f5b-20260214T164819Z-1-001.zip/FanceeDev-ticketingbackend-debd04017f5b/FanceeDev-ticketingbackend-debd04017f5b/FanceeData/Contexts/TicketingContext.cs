using System;
using System.Collections.Generic;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Exact;
using FanceeData.Models.Ticketing.Invoicing;
using FanceeData.Models.Ticketing.Messaging;
using FanceeData.Models.Ticketing.Rules;
using FanceeData.Seeders;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using OrderPspHistory = FanceeData.Models.Ticketing.OrderPspHistory;
using TicketDesign = FanceeData.Models.Ticketing.TicketDesign;

// ReSharper disable UnusedMember.Global

namespace FanceeData.Contexts;

public class TicketingContext : DbContext
{
    public const string SchemaMessaging = "messaging";
    public const string SchemaInvoicing = "invoicing";
    public const string SchemaRules = "rules";
    public const string SchemaExact = "exact";

    private const string DefaultDiscriminatorName = "Discriminator";

    public virtual DbSet<AccordionElement> AccordionElements { get; set; }
    public virtual DbSet<AccordionShopElement> AccordionShopElements { get; set; }
    public virtual DbSet<Address> Addresses { get; set; }
    public virtual DbSet<Admin> Admins { get; set; }
    public virtual DbSet<AgendaIframe> AgendaIframes { get; set; }
    public virtual DbSet<AgendaIframeDesign> AgendaIframeDesigns { get; set; }
    public virtual DbSet<Ambassador> Ambassadors { get; set; }
    public virtual DbSet<AppTeam> AppTeams { get; set; }
    public virtual DbSet<AuditLog> AuditLogs { get; set; }
    public virtual DbSet<BlockedEmail> BlockedEmails { get; set; }
    public virtual DbSet<Campaign> Campaigns { get; set; }
    public virtual DbSet<Changelog> Changelogs { get; set; }
    public virtual DbSet<Claim> Claims { get; set; }
    public virtual DbSet<Client> Clients { get; set; }
    public virtual DbSet<ClientOrder> ClientOrders { get; set; }
    public virtual DbSet<CombinedShop> CombinedShops { get; set; }
    public virtual DbSet<CombinedShopDesign> CombinedShopDesigns { get; set; }
    public virtual DbSet<CombinedShopMedia> CombinedShopMedia { get; set; }
    public virtual DbSet<CombinedShopPaymentMethod> CombinedShopPaymentMethods { get; set; }
    public virtual DbSet<ShopColorPalette> ShopColorPalettes { get; set; }
    public virtual DbSet<Country> Countries { get; set; }
    public virtual DbSet<CountryManager> CountryManagers { get; set; }
    public virtual DbSet<Currency> Currencies { get; set; }
    public virtual DbSet<CurrencyExchangeRate> CurrencyExchangeRates { get; set; }
    public virtual DbSet<CustomerServiceEmployee> CustomerServiceEmployees { get; set; }
    public virtual DbSet<DeploymentEnvironment> DeploymentEnvironments { get; set; }
    public virtual DbSet<DividerElement> DividerElements { get; set; }
    public virtual DbSet<Discount> Discounts { get; set; }
    public virtual DbSet<DiscountApplicableTo> DiscountApplicableTo { get; set; }
    public virtual DbSet<Event> Events { get; set; }
    public virtual DbSet<EventCancellation> EventCancellations { get; set; }
    public virtual DbSet<EventCategory> EventCategories { get; set; }
    public virtual DbSet<EventMail> EventMails { get; set; }
    public virtual DbSet<EventMedia> EventMedia { get; set; }
    public virtual DbSet<EventPaymentMethod> EventsPaymentMethods { get; set; }
    public virtual DbSet<EventSetting> EventSettings { get; set; }
    public virtual DbSet<EventTag> EventTags { get; set; }
    public virtual DbSet<ExternalLinkElement> ExternalLinkElements { get; set; }
    public virtual DbSet<File> Files { get; set; }
    public virtual DbSet<GrowthTarget> GrowthTargets { get; set; }
    public virtual DbSet<IssuedProduct> IssuedProducts { get; set; }
    public virtual DbSet<IssuedTicket> IssuedTickets { get; set; }
    public virtual DbSet<IssuedTicketSwap> IssuedTicketSwaps { get; set; }
    public virtual DbSet<ItemInShop> ItemsInShops { get; set; }
    public virtual DbSet<NoticeElement> NoticeElements { get; set; }
    public virtual DbSet<OAuthProviderToken> OAuthProviderTokens { get; set; }
    public virtual DbSet<Order> Orders { get; set; }
    public virtual DbSet<OrderPspHistory> OrderPspHistories { get; set; }
    public virtual DbSet<OrderReceiptsFile> OrderReceiptsFiles { get; set; }
    public virtual DbSet<OrderTicketsFile> OrderTicketsFiles { get; set; }
    public virtual DbSet<Organization> Organizations { get; set; }
    public virtual DbSet<OrganizationShopShare> OrganizationShopShares { get; set; }
    public virtual DbSet<OrganizationCommerceWarning> CommerceWarnings { get; set; }
    public virtual DbSet<OrganizationContactInfo> OrganizationContactInfos { get; set; }
    public virtual DbSet<OrganizationContract> OrganizationContracts { get; set; }
    public virtual DbSet<OrganizationContractAddendum> OrganizationContractAddenda { get; set; }
    public virtual DbSet<OrganizationDefaultPaymentMethod> OrganizationDefaultPaymentMethods { get; set; }
    public virtual DbSet<OrganizationDefaultShopField> OrganizationDefaultShopFields { get; set; }
    public virtual DbSet<OrganizationNote> OrganizationNotes { get; set; }
    public virtual DbSet<OrganizationUser> OrganizationUsers { get; set; }
    public virtual DbSet<OrganizationUserClaim> OrganizationUserClaims { get; set; }
    public virtual DbSet<PasswordReset> PasswordResets { get; set; }
    public virtual DbSet<PaymentMethod> PaymentMethods { get; set; }
    public virtual DbSet<PreRegister> PreRegisters { get; set; }
    public virtual DbSet<PreRegisterSignUp> PreRegisterSignUps { get; set; }
    public virtual DbSet<Product> Products { get; set; }
    public virtual DbSet<ProductMedia> ProductMedia { get; set; }
    public virtual DbSet<ProductPriceHistory> ProductPriceHistories { get; set; }
    public virtual DbSet<Profanity> Profanities { get; set; }
    public virtual DbSet<ReservationReference> ReservationReferences { get; set; }
    public virtual DbSet<ReservedProduct> ReservedProducts { get; set; }
    public virtual DbSet<SeatingMapElement> SeatingMapElements { get; set; }
    public virtual DbSet<Shop> Shops { get; set; }
    public virtual DbSet<ShopQueue> ShopQueues { get; set; }
    public virtual DbSet<ShopCampaign> ShopCampaigns { get; set; }
    public virtual DbSet<ShopDesign> ShopDesigns { get; set; }
    public virtual DbSet<ShopDesignHeaderMedia> ShopDesignHeaderMedia { get; set; }
    public virtual DbSet<ShopElement> ShopElements { get; set; }
    public virtual DbSet<ShopSecureCode> ShopSecureCodes { get; set; }
    public virtual DbSet<ShopInCombinedShop> ShopsInCombinedShops { get; set; }
    public virtual DbSet<ShopFieldRequirement> ShopFieldRequirements { get; set; }
    public virtual DbSet<ShopMail> ShopMails { get; set; }
    public virtual DbSet<ShopTag> ShopTags { get; set; }
    public virtual DbSet<ShopQuestion> ShopQuestions { get; set; }
    public virtual DbSet<ShopQuestionAnswer> ShopQuestionAnswers { get; set; }
    public virtual DbSet<ShopQuestionChoice> ShopQuestionChoices { get; set; }
    public virtual DbSet<TextBlockElement> TextBlockElements { get; set; }
    public virtual DbSet<TicketDesign> TicketDesigns { get; set; }
    public virtual DbSet<TicketDesignElement> TicketDesignElements { get; set; }
    public virtual DbSet<TicketDesignMedia> TicketDesignMedia { get; set; }
    public virtual DbSet<TicketDesignMediaElement> TicketDesignMediaElements { get; set; }
    public virtual DbSet<TicketDesignQrElement> TicketDesignQrElements { get; set; }
    public virtual DbSet<TicketDesignUpcomingEventsElement> TicketDesignUpcomingEventsElements { get; set; }
    public virtual DbSet<TicketHolder> TicketHolders { get; set; }
    public virtual DbSet<TicketOption> TicketOptions { get; set; }
    public virtual DbSet<TicketScan> TicketScans { get; set; }
    public virtual DbSet<User> Users { get; set; }
    public virtual DbSet<UserClaim> UserClaim { get; set; }
    public virtual DbSet<UserContactInfo> UserContactInfos { get; set; }
    public virtual DbSet<UserMedia> UserMedia { get; set; }

    private readonly List<ISeeder> _seeders =
    [
        new CurrencySeeder(),
        new CurrencyExchangeRateSeeder(),
        new EventCategorySeeder(),
        new DeploymentEnvironmentSeeder(),
        new CountrySeeder(),
        new InvoiceUnitSeeder(),
        new InvoiceRowSpecificationSeeder(),
        new PaymentMethodSeeder(),
        new ClaimSeeder(),
        new ProfanitySeeder()
    ];

    public TicketingContext()
    {
    }

    public TicketingContext(DbContextOptions<TicketingContext> options) : base(options)
    {
    }

    public static long? DateDiffSecondBig(DateTime startDate, DateTime endDate) => (long)(endDate - startDate).TotalSeconds;

    public virtual void SetEntityState(object entity, EntityState state) =>
        Entry(entity).State = state;

    public new virtual EntityEntry Entry(object entity) =>
        base.Entry(entity);

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDbFunction(typeof(TicketingContext).GetMethod(nameof(DateDiffSecondBig))!)
            .HasTranslation(args => new SqlFunctionExpression(
                "DATEDIFF_BIG",
                new[] { new SqlFragmentExpression("second"), args[0], args[1] },
                false,
                [false, false],
                typeof(long),
                null
            ));

        modelBuilder.Entity<ShopCampaign>()
            .HasOne(sc => sc.Shop)
            .WithMany(s => s.ShopCampaigns)
            .HasForeignKey(cs => cs.ShopCode)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<ShopCampaign>()
            .HasOne(cs => cs.Campaign)
            .WithMany(c => c.CampaignShops)
            .HasForeignKey(cs => cs.CampaignCode)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<CustomerServiceEmployee>()
            .HasOne<Admin>()
            .WithOne()
            .HasForeignKey<CustomerServiceEmployee>(cse => cse.UserId)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<Organization>()
            .HasOne(o => o.User)
            .WithOne(u => u.Organization)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<ItemInShop>()
            .HasOne(iis => iis.Shop)
            .WithMany(s => s.ItemsInShop)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<ItemInShop>()
            .HasOne(iis => iis.Product)
            .WithMany(p => p.ItemInShops)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<ItemInShop>()
            .HasOne(iis => iis.ShopElement)
            .WithOne(se => se.ItemInShop)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<Invoice>()
            .HasOne(i => i.ReceiverContactDetails)
            .WithMany(icd => icd.ReceiverInvoices)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<Invoice>()
            .HasOne(i => i.SenderContactDetails)
            .WithMany(icd => icd.SenderInvoices)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<RuleExpression>()
            .HasOne(re => re.LeftCondition)
            .WithOne(rc => rc.LeftRuleExpression)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<AppTeam>()
            .HasOne(at => at.Organization)
            .WithMany(o => o.AppTeams)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<Ambassador>()
            .HasIndex(a => a.Code)
            .IsUnique();

        modelBuilder.Entity<EventTag>()
            .HasKey(et => new { et.Name, et.EventId });

        modelBuilder.Entity<GrowthTarget>()
            .HasKey(gt => new { gt.Date, gt.CountryCode });

        modelBuilder.Entity<PreRegisterSignUp>()
            .HasKey(prsu => new { prsu.PreRegisterCode, prsu.Email });

        modelBuilder.Entity<User>()
            .HasIndex(u => u.Email)
            .IsUnique();

        modelBuilder.Entity<TicketDesignElement>(builder =>
        {
            builder.HasDiscriminator<string>(DefaultDiscriminatorName);

            builder.Property(DefaultDiscriminatorName)
                .HasMaxLength(100);
        });

        modelBuilder.Entity<TicketDesignQrElement>()
            .Property(tdqe => tdqe.FileId)
            .HasColumnName(nameof(TicketDesignQrElement.FileId));

        modelBuilder.Entity<TicketDesignMediaElement>()
            .Property(tdme => tdme.FileId)
            .HasColumnName(nameof(TicketDesignMediaElement.FileId));

        modelBuilder.Entity<AccordionElement>()
            .Property(ae => ae.Title)
            .HasColumnName(nameof(AccordionElement.Title));

        modelBuilder.Entity<TextBlockElement>()
            .Property(tbe => tbe.Title)
            .HasColumnName(nameof(TextBlockElement.Title));

        modelBuilder.Entity<Changelog>()
            .Property(e => e.AppliesToUserType)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<UserType>(v));

        modelBuilder.Entity<OrganizationContract>()
            .Property(e => e.PackageType)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<OrganizationPackageType>(v));

        modelBuilder.Entity<Admin>()
            .Property(a => a.Role)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<AdminRole>(v));

        modelBuilder.Entity<Event>(builder =>
        {
            builder.Property(e => e.Status)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<EventStatus>(v));

            builder.Property(e => e.Type)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<EventType>(v));

            builder.HasIndex(e => e.EndDate)
                .IncludeProperties(e => e.Status);
        });

        modelBuilder.Entity<Shop>()
            .Property(s => s.Layout)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ShopLayout>(v));

        modelBuilder.Entity<ShopFieldRequirement>()
            .Property(s => s.Field)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ShopField>(v));

        modelBuilder.Entity<Order>(builder =>
        {
            builder.HasIndex(o => o.CreatedAt)
                .IncludeProperties(o => new { o.PaymentMethodId, o.ReservationReference });

            builder.Property(o => o.PaymentStatus)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<PaymentStatus>(v));

            builder.Property(o => o.PaymentFeePaidBy)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<PaidBy>(v));
        });

        modelBuilder.Entity<CombinedShopPaymentMethod>()
            .Property(cspm => cspm.PaidBy)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<PaidBy>(v));

        modelBuilder.Entity<OrderPspHistory>(builder =>
        {
            builder.Property(s => s.PaymentStatus)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<PaymentStatus>(v));
        });

        modelBuilder.Entity<Invoice>()
            .Property(i => i.Type)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<InvoiceType>(v));

        modelBuilder.Entity<ClientOrder>()
            .Property(co => co.Gender)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<Gender>(v));

        modelBuilder.Entity<IssuedProduct>(builder =>
        {
            builder.HasIndex(ip => new { ip.Origin, ip.CreatedOn })
                .IncludeProperties(ip => new { ip.ProductId, ip.Type });

            builder.HasIndex(ip => new { ip.ProductId, ip.Origin })
                .IncludeProperties(ip => ip.Type);

            builder.Property(ip => ip.Type)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<IssuedProductType>(v));

            builder.Property(ip => ip.Origin)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<IssuedProductOrigin>(v));
        });

        modelBuilder.Entity<IssuedTicket>()
            .Property(it => it.State)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<TicketState>(v));

        modelBuilder.Entity<TicketScan>()
            .Property(ts => ts.State)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ScanState>(v));

        modelBuilder.Entity<NoticeElement>()
            .Property(ne => ne.Variant)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<NoticeVariant>(v));

        modelBuilder.Entity<TicketHolder>()
            .Property(th => th.Gender)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<Gender>(v));

        modelBuilder.Entity<Product>()
            .Property(p => p.Type)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ProductType>(v));

        modelBuilder.Entity<OrganizationContactInfo>()
            .Property(oci => oci.Role)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ContactInfoRole>(v));

        modelBuilder.Entity<Claim>()
            .Property(c => c.Type)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ClaimType>(v));

        modelBuilder.Entity<UserClaim>()
            .Property(uc => uc.ClaimType)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ClaimType>(v));

        modelBuilder.Entity<OAuthProviderToken>()
            .Property(oapt => oapt.Provider)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<OAuthProvider>(v));

        modelBuilder.Entity<WalletPayment>()
            .Property(wp => wp.Type)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<WalletPaymentType>(v));

        modelBuilder.Entity<PayOutExport>()
            .Property(poe => poe.Status)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<PayOutExportStatus>(v));

        modelBuilder.Entity<ShopMail>(builder =>
        {
            builder.Property(sm => sm.Type)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<ShopMailType>(v));

            builder.HasKey(sm => new { sm.ShopCode, sm.Type });
        });

        modelBuilder.Entity<ShopTag>()
            .HasKey(et => new { et.Name, et.ShopCode });

        modelBuilder.Entity<EventMail>(builder =>
        {
            builder.Property(em => em.Type)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<EventMailType>(v));

            builder.HasKey(em => new { em.EventId, em.Type });
        });

        modelBuilder.Entity<EventMedia>()
            .HasKey(pm => new { pm.EventId, pm.FileId });

        modelBuilder.Entity<Claim>()
            .HasKey(c => new { c.Type, c.Value });

        modelBuilder.Entity<UserClaim>()
            .HasKey(uc => new { uc.UserId, uc.ClaimType, uc.ClaimValue });

        modelBuilder.Entity<ProductMedia>()
            .HasKey(pm => new { pm.ProductId, pm.FileId });

        modelBuilder.Entity<ProductPriceHistory>()
            .HasKey(pph => new { pph.ProductId, pph.Date });

        modelBuilder.Entity<ShopSecureCode>()
            .HasKey(ssc => new { ssc.Code, ssc.ShopCode });

        modelBuilder.Entity<ShopDesignHeaderMedia>()
            .HasKey(sdhm => new { sdhm.ShopCode, sdhm.FileId });

        modelBuilder.Entity<OrganizationDefaultPaymentMethod>(builder =>
        {
            builder.Property(epm => epm.PaidBy)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<PaidBy>(v));

            builder.HasKey(epm => new { epm.OrganizationId, epm.PaymentMethodId });
        });

        modelBuilder.Entity<EventPaymentMethod>(builder =>
        {
            builder.Property(epm => epm.PaidBy)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<PaidBy>(v));

            builder.HasKey(epm => new { epm.EventId, epm.PaymentMethodId });
        });

        modelBuilder.Entity<ItemInShop>()
            .HasIndex(iis => new { iis.ShopCode, iis.ShopElementId, iis.ProductId })
            .IsUnique();

        modelBuilder.Entity<ItemMapping>()
            .HasIndex(im => new { im.InvoiceRowSpecificationName, im.CountryCode })
            .IsUnique();

        modelBuilder.Entity<MailQueue>()
            .Property(mq => mq.MailProvider)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<MailProvider>(v));

        modelBuilder.Entity<MailAddress>()
            .Property(mr => mr.Type)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<MailAddressType>(v));

        modelBuilder.Entity<Queue>()
            .Property(q => q.CreatedOn)
            .HasDefaultValueSql("getutcdate()");

        modelBuilder.Entity<MailQueue>()
            .HasOne(mq => mq.From)
            .WithMany(ma => ma.FromMailQueues)
            .HasForeignKey(mq => mq.FromMailAddressId)
            .OnDelete(DeleteBehavior.ClientCascade);

        modelBuilder.Entity<Invoice>()
            .HasOne(i => i.Organization)
            .WithMany(p => p.Invoices)
            .HasForeignKey(i => i.OrganizationId)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<AccordionShopElement>()
            .HasOne(ase => ase.ShopElement)
            .WithMany(se => se.AccordionElements)
            .HasForeignKey(ase => ase.ShopElementId)
            .OnDelete(DeleteBehavior.ClientCascade);

        modelBuilder.Entity<CurrencyExchangeRate>()
            .ToTable("CurrencyExchangeRates", b => b.IsTemporal());

        modelBuilder.Entity<OrganizationContract>()
            .ToTable("OrganizationContracts", b => b.IsTemporal());

        modelBuilder.Entity<Invoice>(builder =>
        {
            builder.HasIndex(i => i.ReceiverContactDetailsId)
                .IsUnique(false);

            builder.HasIndex(i => i.SenderContactDetailsId)
                .IsUnique(false);
        });

        modelBuilder.Entity<RuleGroupExpression>()
            .Property(rge => rge.Mode)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<RuleGroupExpressionMode>(v));

        modelBuilder.Entity<RuleExpression>()
            .Property(re => re.Operator)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<RuleExpressionOperator>(v));

        modelBuilder.Entity<DiscountStatement>()
            .Property(ds => ds.Strategy)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<RuleDiscountStrategy>(v));

        modelBuilder.Entity<RuleBaseExpression>(builder =>
        {
            builder.HasDiscriminator<string>(DefaultDiscriminatorName);

            builder.Property(DefaultDiscriminatorName)
                .HasMaxLength(100);
        });

        modelBuilder.Entity<RuleStatement>(builder =>
        {
            builder.HasDiscriminator<string>(DefaultDiscriminatorName);

            builder.Property(DefaultDiscriminatorName)
                .HasMaxLength(100);
        });

        modelBuilder.Entity<RuleCondition>(builder =>
        {
            builder.HasDiscriminator<string>(DefaultDiscriminatorName);

            builder.Property(DefaultDiscriminatorName)
                .HasMaxLength(100);
        });

        modelBuilder.Entity<RuleGroupExpression>()
            .Navigation(rge => rge.Expressions)
            .AutoInclude();

        modelBuilder.Entity<RuleExpression>(builder =>
        {
            builder.Navigation(re => re.LeftCondition)
                .AutoInclude();

            builder.Navigation(re => re.RightCondition)
                .AutoInclude();
        });

        modelBuilder.Entity<PaymentMethod>(builder =>
        {
            builder.HasIndex(pm => new { pm.Name, pm.Provider })
                .IsUnique();

            builder.Property(pm => pm.Provider)
                .HasConversion(
                    v => v.ToString(),
                    v => Enum.Parse<PaymentProvider>(v));
        });

        modelBuilder.Entity<ShopQuestion>()
            .Property(sq => sq.Type)
            .HasConversion(
                v => v.ToString(),
                v => Enum.Parse<ShopQuestionType>(v));

        modelBuilder.Entity<ShopQuestionChoice>()
            .HasKey(sqc => new { sqc.ShopQuestionId, sqc.Value });

        modelBuilder.Entity<ShopQuestionAnswer>()
            .HasKey(sqa => new { sqa.ShopQuestionId, sqa.OrderId });

        modelBuilder.Entity<UserMedia>()
            .HasKey(pm => new { pm.UserId, pm.FileId });

        modelBuilder.Entity<OrganizationContractAddendum>()
            .HasOne(oca => oca.Contract)
            .WithMany(oc => oc.Addenda)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<Organization>()
            .HasOne(o => o.User)
            .WithOne(u => u.Organization)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<ShopInCombinedShop>()
            .HasOne(sics => sics.Shop)
            .WithMany(s => s.ShopsInCombinedShop)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<ShopInCombinedShop>()
            .HasOne(sics => sics.CombinedShop)
            .WithMany(cs => cs.ShopsInCombinedShop)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<OrganizationShopShare>()
            .HasOne(oss => oss.Shop)
            .WithMany(s => s.SharedShops)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<OrganizationShopShare>()
            .HasOne(oss => oss.Organization)
            .WithMany(s => s.SharedShops)
            .OnDelete(DeleteBehavior.NoAction);

        modelBuilder.Entity<Organization>()
            .HasIndex(o => o.PublicCode)
            .IsUnique();

        modelBuilder.Entity<AgendaIframe>()
            .HasMany(ai => ai.LinkedEvents)
            .WithMany(le => le.LinkedIframes)
            .UsingEntity<Dictionary<string, object>>("AgendaIframeEvents",
                e => e.HasOne<Event>().WithMany().OnDelete(DeleteBehavior.NoAction),
                ai => ai.HasOne<AgendaIframe>().WithMany().OnDelete(DeleteBehavior.Cascade)
            );

        modelBuilder.Entity<EventCancellation>()
            .HasOne(ec => ec.Organization)
            .WithMany(o => o.EventCancellations)
            .OnDelete(DeleteBehavior.NoAction);

        Seed(modelBuilder);
    }

    private void Seed(ModelBuilder modelBuilder)
    {
        foreach (var seeder in _seeders)
            seeder.Seed(modelBuilder);
    }

    #region Messaging schema

    public virtual DbSet<MailAddress> MailAddresses { get; set; }
    public virtual DbSet<MailAttachment> MailAttachments { get; set; }
    public virtual DbSet<MailHeader> MailHeaders { get; set; }
    public virtual DbSet<MailQueue> MailQueue { get; set; }
    public virtual DbSet<Queue> Queue { get; set; }

    #endregion

    #region Invoicing schema

    public virtual DbSet<AdditionalCost> AdditionalCosts { get; set; }
    public virtual DbSet<EventPaymentWithholdSettings> EventPaymentWithholdSettings { get; set; }
    public virtual DbSet<Invoice> Invoices { get; set; }
    public virtual DbSet<InvoiceContactDetails> InvoiceContactDetails { get; set; }
    public virtual DbSet<InvoiceContactDetailsPaymentSettings> InvoiceContactDetailsPaymentSettings { get; set; }
    public virtual DbSet<InvoiceRow> InvoiceRows { get; set; }
    public virtual DbSet<InvoiceRowSpecification> InvoiceRowSpecifications { get; set; }
    public virtual DbSet<InvoiceUnit> InvoiceUnits { get; set; }
    public virtual DbSet<OrganizationPaymentSettings> OrganizationPaymentSettings { get; set; }
    public virtual DbSet<PayOutExport> PayOutExports { get; set; }
    public virtual DbSet<WalletPayment> WalletPayments { get; set; }
    public virtual DbSet<WalletPayoutSettings> WalletPayoutSettings { get; set; }

    #endregion

    #region Rules schema

    public virtual DbSet<DiscountStatement> DiscountStatements { get; set; }
    public virtual DbSet<InvoiceRule> InvoiceRules { get; set; }
    public virtual DbSet<Rule> Rules { get; set; }
    public virtual DbSet<RuleCondition> RuleConditions { get; set; }
    public virtual DbSet<RuleExpression> RuleExpressions { get; set; }
    public virtual DbSet<RuleGroupExpression> RuleGroupExpressions { get; set; }
    public virtual DbSet<RuleInvoiceStatementCondition> RuleInvoiceStatementsConditions { get; set; }
    public virtual DbSet<RuleBoolValueCondition> RuleBoolValueConditions { get; set; }
    public virtual DbSet<RuleDecimalValueCondition> RuleDecimalValueConditions { get; set; }
    public virtual DbSet<RuleDoubleValueCondition> RuleDoubleValueConditions { get; set; }
    public virtual DbSet<RuleStatement> RuleStatements { get; set; }
    public virtual DbSet<RuleIntValueCondition> RuleIntValueConditions { get; set; }

    #endregion

    #region Exact schema

    public virtual DbSet<ExactConfiguration> ExactConfigurations { get; set; }
    public virtual DbSet<ExactUser> ExactUsers { get; set; }
    public virtual DbSet<ItemMapping> ItemMappings { get; set; }

    #endregion
}