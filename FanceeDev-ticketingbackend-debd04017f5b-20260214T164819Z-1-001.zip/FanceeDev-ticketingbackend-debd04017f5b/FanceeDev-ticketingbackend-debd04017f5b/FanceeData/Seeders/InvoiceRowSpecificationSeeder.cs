﻿using FanceeData.Models.Ticketing.Invoicing;
using Microsoft.EntityFrameworkCore;

namespace FanceeData.Seeders;

internal class InvoiceRowSpecificationSeeder : ISeeder
{
    public void Seed(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<InvoiceRowSpecification>()
            .HasData(
                new() { Name = "Ticket fee" },
                new() { Name = "Product fee" },
                new() { Name = "Payment fee" },
                new() { Name = "Bulk SMS costs" },
                new() { Name = "Ticket service plus costs" },
                new() { Name = "Text message costs" },
                new() { Name = "Payout" },
                new() { Name = "Discount" },
                new() { Name = "Additional cost" },
                new() { Name = "Top up" },
                new() { Name = "Guest list fee" },
                new() { Name = "Seating fee" });
    }
}