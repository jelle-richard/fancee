using System;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace FanceeData.Seeders;

internal class DeploymentEnvironmentSeeder : ISeeder
{
    public void Seed(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DeploymentEnvironment>()
            .HasData(
                new() { Id = Guid.Parse("bda237ef-f151-4baf-b384-f870773a0db6"), Domain = "127.0.0.1", Name = "localhost", FrontendBaseUrl = "http://127.0.0.1:8080", ContentDeliveryNetworkBaseUrl = "127.0.0.1" },
                new() { Id = Guid.Parse("48672c9b-f950-4920-927c-9ee400dbca39"), Domain = "localhost", Name = "localhost", FrontendBaseUrl = "http://localhost:8080", ContentDeliveryNetworkBaseUrl = "localhost" },
                new() { Id = Guid.Parse("01ad9b31-b85a-4637-a33d-a6ae92ad580b"), Domain = "staging.fanc.ee", Name = "Staging", FrontendBaseUrl = "https://staging.fanc.ee", IsHttps = true, ContentDeliveryNetworkBaseUrl = "staging.fanc.ee" });
    }
}