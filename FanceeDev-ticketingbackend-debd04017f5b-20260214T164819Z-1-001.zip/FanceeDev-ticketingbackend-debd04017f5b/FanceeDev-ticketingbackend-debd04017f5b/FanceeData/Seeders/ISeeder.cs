﻿using Microsoft.EntityFrameworkCore;

namespace FanceeData.Seeders;

internal interface ISeeder
{
    /// <summary>
    /// Seeds the <see cref="ModelBuilder" /> with initial data.
    /// </summary>
    /// <param name="modelBuilder"></param>
    public void Seed(ModelBuilder modelBuilder);
}