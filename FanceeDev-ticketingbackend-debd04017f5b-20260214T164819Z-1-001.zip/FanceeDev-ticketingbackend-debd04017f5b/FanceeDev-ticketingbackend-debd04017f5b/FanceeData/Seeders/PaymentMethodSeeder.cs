﻿using System;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace FanceeData.Seeders;

internal class PaymentMethodSeeder : ISeeder
{
    public void Seed(ModelBuilder modelBuilder)
    {
        // @formatter:off
        modelBuilder.Entity<PaymentMethod>()
            .HasData(
                new() { Id = Guid.Parse("1CD06068-286D-4689-9044-6E67E364A627"), Name = "IDeal", Provider = PaymentProvider.Adyen, BrandCode = "ideal", IsChargebackProne = false, SettlementDays = 3, FeePercentage = null, FeeStaticCents = 50, Active = true,  Order = 1 },
                new() { Id = Guid.Parse("16F90322-7F91-4DEB-92F3-B7194B417B88"), Name = "American Express", Provider = PaymentProvider.Adyen, BrandCode = "amex", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 4.00m, FeeStaticCents = 30, Active = true,  Order = 2 },
                new() { Id = Guid.Parse("F8A94A98-04D3-41C7-802D-3500554237E8"), Name = "Bancontact", Provider = PaymentProvider.Adyen, BrandCode = "bcmc", IsChargebackProne = false, SettlementDays = 90, FeePercentage = 0.85m, FeeStaticCents = 30, Active = true,  Order = 3 },
                new() { Id = Guid.Parse("308F1D9B-F2DB-418F-9384-1022E4828835"), Name = "Carte Bancaire", Provider = PaymentProvider.Adyen, BrandCode = "cartebancaire", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 3.00m, FeeStaticCents = 30, Active = true,  Order = 4 },
                new() { Id = Guid.Parse("CE1C95D5-6AC1-4FC9-930F-7277718B4226"), Name = "Electronic Payment Service", Provider = PaymentProvider.Adyen, BrandCode = "eps", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 2.00m, FeeStaticCents = 25, Active = true,  Order = 5 },
                new() { Id = Guid.Parse("19EA84C4-18E6-4270-BA2D-0E35FAD7B8E9"), Name = "Entercash", Provider = PaymentProvider.Adyen, BrandCode = "entercash", IsChargebackProne = true, SettlementDays = 90, FeePercentage = null, FeeStaticCents = null, Active = false,  Order = 6 },
                new() { Id = Guid.Parse("3C4237B2-30F6-455F-A97B-9EF3B89AF847"), Name = "Giropay", Provider = PaymentProvider.Adyen, BrandCode = "giropay", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 3.00m, FeeStaticCents = 40, Active = false,  Order = 7 },
                new() { Id = Guid.Parse("021DA9A4-9F76-4DAD-93B7-0F2F1F1665CD"), Name = "Google Pay", Provider = PaymentProvider.Adyen, BrandCode = "paywithgoogle", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 5.00m, FeeStaticCents = 50, Active = false,  Order = 8 },
                new() { Id = Guid.Parse("D45F1AE7-03FB-492A-8758-1FA50852EC0C"), Name = "Klarna Pay Now", Provider = PaymentProvider.Adyen, BrandCode = "klarna_paynow", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 1.00m, FeeStaticCents = 60, Active = true,  Order = 9 },
                new() { Id = Guid.Parse("25BC0952-36E5-4C8E-851C-122A5F0EB0B4"), Name = "Maestro", Provider = PaymentProvider.Adyen, BrandCode = "maestro", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 3.00m, FeeStaticCents = 30, Active = true,  Order = 10 },
                new() { Id = Guid.Parse("23C28288-8A00-48B8-ACCB-BB5855EFFB65"), Name = "Mastercard", Provider = PaymentProvider.Adyen, BrandCode = "mc", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 3.00m, FeeStaticCents = 30, Active = true,  Order = 11 },
                new() { Id = Guid.Parse("DA9A6B58-E53A-4BA5-BE5D-E14CD1E44B2C"), Name = "Multibanco", Provider = PaymentProvider.Adyen, BrandCode = "multibanco", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 4.00m, FeeStaticCents = 20, Active = true,  Order = 12 },
                new() { Id = Guid.Parse("176AB9E6-FB42-4322-AC96-985C6895D799"), Name = "Paypal", Provider = PaymentProvider.Adyen, BrandCode = "paypal", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 3.50m, FeeStaticCents = 30, Active = false,  Order = 13 },
                new() { Id = Guid.Parse("890FAB3B-249C-4B96-B4AD-5F4100EE4DF8"), Name = "PaySafeCard", Provider = PaymentProvider.Adyen, BrandCode = "paysafecard", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 15.00m, FeeStaticCents = null, Active = true,  Order = 14 },
                new() { Id = Guid.Parse("ABB691E8-E064-4487-A3C3-0B27935798B5"), Name = "Sofort (by Klarna)", Provider = PaymentProvider.Adyen, BrandCode = "klarna", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 1.00m, FeeStaticCents = 60, Active = true,  Order = 15 },
                new() { Id = Guid.Parse("DAF895B0-1174-4609-BD4A-727623C67971"), Name = "Swish", Provider = PaymentProvider.Adyen, BrandCode = "swish", IsChargebackProne = true, SettlementDays = 90, FeePercentage = null, FeeStaticCents = 40, Active = true,  Order = 16 },
                new() { Id = Guid.Parse("55F9397B-FAD8-46AD-81A7-75FC48D8C6A5"), Name = "Visa", Provider = PaymentProvider.Adyen, BrandCode = "visa", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 3.00m, FeeStaticCents = 30, Active = true,  Order = 17 },
                new() { Id = Guid.Parse("522E9056-7FDB-43D8-85CE-8AEA9EF9A3A9"), Name = "VisaDankort", Provider = PaymentProvider.Adyen, BrandCode = "visadankort", IsChargebackProne = true, SettlementDays = 90, FeePercentage = 3.00m, FeeStaticCents = 30, Active = true,  Order = 18 },
                new() { Id = Guid.Parse("813209AD-96C7-41DA-9EDA-3C93EED2CEEB"), Name = "Cash", Provider = PaymentProvider.Platform, BrandCode = "cash", IsChargebackProne = false, SettlementDays = 1, FeePercentage = 0, FeeStaticCents = 0, Active = true,  Order = 19 },
                new() { Id = Guid.Parse("851DEC38-CD04-42C7-883D-5091631A178D"), Name = "Pin", Provider = PaymentProvider.Adyen, BrandCode = "pin", IsChargebackProne = false, SettlementDays = 1, FeePercentage = 0, FeeStaticCents = 30, Active = true,  Order = 20 });
        // @formatter:on
    }
}