﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.EntityFrameworkCore;

namespace FanceeData.Seeders;

internal class ClaimSeeder : ISeeder
{
    public void Seed(ModelBuilder modelBuilder)
    {
        var claims = new List<Claim>();

        var implementations = typeof(IPermissions)
            .Assembly.GetTypes()
            .Where(t => !t.IsAbstract && t.IsAssignableTo(typeof(IPermissions)));

        foreach (var implementation in implementations)
        {
            var constants = implementation.GetFields(BindingFlags.Public | BindingFlags.Static)
                .Where(fi => fi.IsLiteral && !fi.IsInitOnly);

            claims.AddRange(constants.Select(constant => new Claim
            {
                Type = ClaimType.Permission,
                Value = constant.GetRawConstantValue() as string
            }));
        }

        modelBuilder.Entity<Claim>()
            .HasData(claims);
    }
}