﻿using FanceeData.Models.Ticketing.Invoicing;
using Microsoft.EntityFrameworkCore;

namespace FanceeData.Seeders;

internal class InvoiceUnitSeeder : ISeeder
{
    public void Seed(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<InvoiceUnit>()
            .HasData(
                new() { Name = "Hour" },
                new() { Name = "Piece" },
                new() { Name = "Batch" });
    }
}