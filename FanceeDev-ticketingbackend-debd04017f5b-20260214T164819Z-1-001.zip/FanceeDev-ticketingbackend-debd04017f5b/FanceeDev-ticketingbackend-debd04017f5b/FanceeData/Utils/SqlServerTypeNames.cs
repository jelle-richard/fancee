namespace FanceeData.Utils;

public class SqlServerTypeNames
{
    public const string Date = "date";
}