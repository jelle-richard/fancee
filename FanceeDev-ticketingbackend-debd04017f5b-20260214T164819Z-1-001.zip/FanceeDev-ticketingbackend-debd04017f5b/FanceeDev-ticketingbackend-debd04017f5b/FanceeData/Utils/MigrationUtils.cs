﻿using System.Collections.Generic;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using Microsoft.EntityFrameworkCore.Migrations.Operations.Builders;

namespace FanceeData.Utils;

public static class MigrationUtils
{
    /// <summary>
    /// Renames a (primary/foreign) key.
    /// Note: only works for SqlServer.
    /// </summary>
    /// <param name="builder"></param>
    /// <param name="name"></param>
    /// <param name="schema"></param>
    /// <param name="newName"></param>
    /// <returns></returns>
    public static OperationBuilder<SqlOperation> RenameKey(this MigrationBuilder builder, string name, string schema, string newName)
    {
        name = name.Trim('[', ']');
        schema = schema.Trim('[', ']');
        newName = newName.Trim('[', ']');

        return builder.Sql($"EXEC sp_rename '[{schema}].[{name}]', '{newName}';");
    }

    /// <summary>
    /// Inserts permissions for existing users.
    /// Format: UserType => [ Permission1, Permission2 ]
    /// </summary>
    /// <param name="builder"></param>
    /// <param name="userClaims"></param>
    /// <returns></returns>
    public static MigrationBuilder InsertUserPermissions(this MigrationBuilder builder, Dictionary<int, string[]> userClaims)
    {
        var transformedUserClaims = new Dictionary<string, string[]>();

        foreach (var (userType, claims) in userClaims)
            transformedUserClaims[userType.ToString()] = claims;

        return builder.InsertUserPermissions(transformedUserClaims);
    }

    /// <summary>
    /// Inserts permissions for existing users.
    /// Format: UserType => [ Permission1, Permission2 ]
    /// </summary>
    /// <param name="builder"></param>
    /// <param name="userClaims"></param>
    /// <returns></returns>
    public static MigrationBuilder InsertUserPermissions(this MigrationBuilder builder, Dictionary<string, string[]> userClaims)
    {
        const string baseSql = """
                               INSERT INTO [dbo].[UserClaim] ([UserId], [ClaimType], [ClaimValue])
                               SELECT [u].[Id] [UserId], 'Permission' [ClaimType], '{claim}' [ClaimValue]
                               FROM [dbo].[Users] [u]
                               WHERE [u].[Type] = '{type}';
                               """;

        foreach (var (type, claims) in userClaims)
        {
            var typeSql = baseSql.Replace("{type}", type);

            foreach (var claim in claims)
            {
                var insertSql = typeSql.Replace("{claim}", claim);

                builder.Sql(insertSql);
            }
        }

        return builder;
    }

    public static MigrationBuilder UpdateMissingPermissions(this MigrationBuilder builder, string missingPermission, UserType userType)
    {
        var sql =
            $"""
             INSERT INTO [dbo].[UserClaim]
                 SELECT UsersWithNoPerm.UserId, 'Permission', '{missingPermission}'
                 FROM (
                     SELECT [UC].[UserId] FROM [dbo].[UserClaim] [UC]
                         INNER JOIN [dbo].[Users] [U] ON [UC].[UserId] = [U].[Id]
                     WHERE [U].[Type] = {(int)userType}
                     AND NOT EXISTS (
                         SELECT 1 FROM [dbo].[UserClaim] [UC2]
                             INNER JOIN [dbo].[Users] [U2] ON [UC2].[UserId] = [U2].[Id]
                         WHERE [UC2].[ClaimValue] = '{missingPermission}'
                         AND [U2].[Type] = {(int)userType}
                         AND [UC2].[UserId] = [UC].[UserId]
                 ) GROUP BY [UC].[UserId], [U].[Email]
             ) AS UsersWithNoPerm
             """;

        builder.Sql(sql);
        return builder;
    }
}