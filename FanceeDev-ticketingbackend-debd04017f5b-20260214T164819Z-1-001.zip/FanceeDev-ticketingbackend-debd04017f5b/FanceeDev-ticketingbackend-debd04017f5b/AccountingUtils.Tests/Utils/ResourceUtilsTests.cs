using AccountingUtils.Utils;
using AccountingUtils.Utils.Exceptions;

namespace AccountingUtils.Tests.Utils;

public class ResourceUtilsTests
{
    [Fact]
    public void TestThatGetThrowsMissingResourceExceptionOnInvalidResource()
    {
        Assert.Throws<MissingResourceException>(() => ResourceUtils.Get("invalid"));
    }

    [Fact]
    public void TestThatGetReturnsStreamOfResource()
    {
        var actual = ResourceUtils.Get("AccountingUtils.Resources.ing-payout-template.xlsx");

        Assert.NotNull(actual);
        Assert.True(actual.Length > 0);

        actual.Close();
    }
}