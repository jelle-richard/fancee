using AccountingUtils.Config;
using AccountingUtils.Providers.Accounting.Exact;
using AccountingUtils.Utils;
using Microsoft.Extensions.DependencyInjection;

namespace AccountingUtils.Tests.Utils;

public class AccountingUtilsExtensionsTests
{
    [Fact]
    public void TestThatAddAccountingUtilsRegistersHttpClientAndExactProvider()
    {
        var serviceCollection = new ServiceCollection();
        var exactConfiguration = new ExactConfiguration { BaseUrl = "https://base" };

        var actual = serviceCollection.AddAccountingUtils(exactConfiguration);

        var provider = serviceCollection.BuildServiceProvider();

        Assert.NotNull(actual);
        Assert.NotNull(provider.GetRequiredService<IHttpClientFactory>().CreateClient("Exact"));
        Assert.IsType<ExactProvider>(provider.GetService<IExactProvider>());
        Assert.Equal(exactConfiguration, provider.GetService<IExactConfiguration>());
    }
}