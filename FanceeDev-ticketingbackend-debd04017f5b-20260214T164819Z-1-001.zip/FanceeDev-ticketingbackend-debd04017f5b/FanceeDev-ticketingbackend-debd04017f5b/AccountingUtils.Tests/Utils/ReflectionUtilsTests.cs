using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;
using AccountingUtils.Utils;

namespace AccountingUtils.Tests.Utils;

public class ReflectionUtilsTests
{
    [Fact]
    public void TestThatToDictionaryConvertsObjectToDictionary()
    {
        var actual = ReflectionUtils.ToDictionary(new UnitTestClass());

        Assert.True(actual.ContainsKey("IntTest"));
        Assert.True(actual.ContainsKey("StringTest"));
        Assert.True(actual.ContainsKey("bool_test"));
        Assert.True(actual.ContainsKey("Nullable"));
        Assert.Equal("3", actual["IntTest"]);
        Assert.Equal("Str", actual["StringTest"]);
        Assert.Equal("True", actual["bool_test"]);
        Assert.Null(actual["Nullable"]);
    }

    #region Unit Test Classes

    [SuppressMessage("ReSharper", "UnusedMember.Local")]
    private class UnitTestClass
    {
        public int IntTest => 3;
        public string StringTest => "Str";

        [JsonPropertyName("bool_test")]
        public bool BoolTest => true;

        public string? Nullable => null;
    }

    #endregion
}