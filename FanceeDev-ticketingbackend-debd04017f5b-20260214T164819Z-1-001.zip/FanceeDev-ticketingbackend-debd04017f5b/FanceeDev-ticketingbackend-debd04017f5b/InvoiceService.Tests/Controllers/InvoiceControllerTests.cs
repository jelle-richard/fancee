﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Invoicing;
using Fs.MessageBus.Publishers;
using InvoiceService.Controllers;
using InvoiceService.Dtos.Request.Invoice;
using InvoiceService.Dtos.Request.InvoiceRule;
using InvoiceService.Dtos.Response.InvoiceRule;
using InvoiceService.Dtos.Shared.Invoice;
using InvoiceService.Dtos.Shared.InvoiceRule;
using InvoiceService.Services.Invoice;
using InvoiceService.Services.Invoice.Exceptions;
using InvoiceService.Services.InvoiceRule;
using InvoiceService.Services.InvoiceRule.Exceptions;
using InvoiceService.Services.Wallet;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Logging;

namespace InvoiceService.Tests.Controllers;

public class InvoiceControllerTests
{
    private readonly InvoiceController _sut;
    private readonly Mock<IInvoiceService> _mockedInvoiceService = new();
    private readonly Mock<IWalletService> _mockedWalletService = new();
    private readonly Mock<IInvoiceRuleService> _mockedInvoiceRuleService = new();
    private readonly Mock<IMessagePublisher<IGeneratePdfMessage>> _mockedGeneratePdfPublisher = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();
    private readonly Mock<ICreateInvoiceService> _mockedCreateInvoiceService = new();
    private readonly Mock<IHostEnvironment> _mockedHostEnvironemnt = new();

    private readonly CreateInvoiceRequest _validRequest = new()
    {
        IsWalletPayment = false,
        OrganizationId = Guid.NewGuid(),
        Type = CreateInvoiceType.Payout,
        Rows = new List<CreateInvoiceRowRequest>
        {
            new() { Amount = 10, SpecificationName = "Ticket fee", Unit = "Piece", UnitPriceCents = 100 }
        }
    };

    public InvoiceControllerTests()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment
        {
            Id = Guid.NewGuid(),
            Domain = "localhost",
            IsHttps = false,
            RemoteIpAddress = IPAddress.Parse("127.0.0.1"),
            Name = "UnitTest"
        });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        _sut = new(
            _mockedInvoiceService.Object,
            _mockedWalletService.Object,
            _mockedInvoiceRuleService.Object,
            _mockedGeneratePdfPublisher.Object,
            _mockedDeploymentEnvironmentService.Object,
            _mockedUserLoggingService.Object,
            _mockedCreateInvoiceService.Object,
            _mockedHostEnvironemnt.Object
        );
    }

    [Fact]
    public async Task TestThatAddCallsInvoiceService()
    {
        var invoice = new Invoice
        {
            Id = 20202020
        };

        _mockedInvoiceService.Setup(@is => @is.AddInvoiceAsync(_validRequest)).ReturnsAsync(invoice);

        var actual = await _sut.Add(_validRequest);

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);

        _mockedInvoiceService.Verify(@is => @is.AddInvoiceAsync(_validRequest), Times.Once);
        _mockedWalletService.VerifyNoOtherCalls();
        _mockedGeneratePdfPublisher.Verify(gpp => gpp.Publish(It.Is<GenerateInvoicePdfMessage>(m => m.InvoiceNumber == invoice.Id)), Times.Once);
    }

    [Fact]
    public async Task TestThatAddCallsWalletServiceIfIsWalletPaymentIsTrue()
    {
        _validRequest.IsWalletPayment = true;

        var invoice = new Invoice();

        _mockedInvoiceService.Setup(@is => @is.AddInvoiceAsync(_validRequest)).ReturnsAsync(invoice);

        var actual = await _sut.Add(_validRequest);

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);

        _mockedInvoiceService.Verify(@is => @is.AddInvoiceAsync(_validRequest), Times.Once);
        _mockedWalletService.Verify(ws => ws.AddWalletPaymentAsync(invoice), Times.Once);
    }

    [Fact]
    public async Task TestThatAddRuleReturnsCreatedInvoiceRuleId()
    {
        var request = new CreateInvoiceRuleRequest
        {
            IsGlobal = true,
            OrganizationIds = new List<Guid>(),
            Name = "UnitTest",
            DiscountStatement = new(),
            Expressions = new List<InvoiceRuleBaseExpressionDto>()
        };

        var actual = await _sut.AddRule(request);

        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<Guid>>(((CreatedResult)actual.Result!).Value);
    }

    [Fact]
    public async Task TestThatGetRuleCallsGetsIdentifiedInvoiceRuleResponse()
    {
        var id = Guid.NewGuid();

        _mockedInvoiceRuleService.Setup(irs => irs.ByIdAsync(id)).ReturnsAsync(new IdentifiedInvoiceRuleResponse { Id = id });

        var actual = await _sut.GetRule(id);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;
        Assert.IsType<ApiResponse<IdentifiedInvoiceRuleResponse>>(actualResult.Value);
        Assert.Equal(id, ((ApiResponse<IdentifiedInvoiceRuleResponse>)actualResult.Value!).Data.Id);

        _mockedInvoiceRuleService.Verify(irs => irs.ByIdAsync(id), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteRuleThrowsInvalidInvoiceRuleExceptionOnInvalidId()
    {
        var id = Guid.NewGuid();

        _mockedInvoiceRuleService.Setup(irs => irs.ExistsAsync(id)).ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidInvoiceRuleException>(async () => await _sut.DeleteRule(id));

        _mockedInvoiceRuleService.Verify(irs => irs.ExistsAsync(id), Times.Once);
        _mockedInvoiceRuleService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteRuleCallsInvoiceRuleServiceDeleteAsyncAndReturnsExpectedResult()
    {
        var id = Guid.NewGuid();

        _mockedInvoiceRuleService.Setup(irs => irs.ExistsAsync(id)).ReturnsAsync(true);

        var actual = await _sut.DeleteRule(id);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedInvoiceRuleService.Verify(irs => irs.ExistsAsync(id), Times.Once);
        _mockedInvoiceRuleService.Verify(irs => irs.DeleteAsync(id), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadFileThrowsInvoiceNotFoundExceptionIfOrganizationIsNotOwnerOfInvoice()
    {
        _sut.SetupHttpContext(organizationId: Guid.NewGuid(), userType: UserType.Organization.ToString());

        _mockedInvoiceService.Setup(@is => @is.OwnerOfInvoiceAsync(It.IsAny<int>(), It.IsAny<Guid>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<InvoiceNotFoundException>(async () => await _sut.DownloadFile(1924359));

        _mockedInvoiceService.Verify(@is => @is.OwnerOfInvoiceAsync(It.IsAny<int>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadFileDownloadsFileForOrganization()
    {
        const int invoiceNr = 29519853;
        var organizationId = Guid.NewGuid();

        _sut.SetupHttpContext(organizationId: organizationId, userType: UserType.Organization.ToString());

        _mockedInvoiceService.Setup(@is => @is.OwnerOfInvoiceAsync(invoiceNr, organizationId)).ReturnsAsync(true);
        _mockedInvoiceService.Setup(@is => @is.DownloadAsync(invoiceNr)).ReturnsAsync(new FileStreamResult(new MemoryStream(), "application/pdf"));

        var actual = await _sut.DownloadFile(invoiceNr);

        Assert.NotNull(actual);
        Assert.IsType<FileStreamResult>(actual);

        _mockedInvoiceService.Verify(@is => @is.OwnerOfInvoiceAsync(invoiceNr, organizationId), Times.Once);
        _mockedInvoiceService.Verify(@is => @is.DownloadAsync(invoiceNr), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadFileDownloadsFileForAdmin()
    {
        _sut.SetupHttpContext(UserType.Admin.ToString(), Guid.NewGuid());

        const int invoiceNr = 29519853;

        _mockedInvoiceService.Setup(@is => @is.DownloadAsync(invoiceNr)).ReturnsAsync(new FileStreamResult(new MemoryStream(), "application/pdf"));

        var actual = await _sut.DownloadFile(invoiceNr);

        Assert.NotNull(actual);
        Assert.IsType<FileStreamResult>(actual);

        _mockedInvoiceService.Verify(@is => @is.DownloadAsync(invoiceNr), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadFileThrowsInvalidUserTypeExceptionOnInvalidUserType()
    {
        _sut.SetupHttpContext(UserType.Client.ToString());

        await Assert.ThrowsAsync<InvalidUserTypeException>(async () => await _sut.DownloadFile(1284));

        _mockedInvoiceService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGenerateInvoiceThrowsSystemFeatureNotEnabledExceptionIfEnvironmentIsProduction()
    {
        _mockedHostEnvironemnt.Setup(he => he.EnvironmentName).Returns("production");

        await Assert.ThrowsAsync<SystemFeatureNotEnabledException>(async () => await _sut.GenerateInvoice(Guid.Empty, new()
        {
            Month = 7,
            Year = 2024
        }));

        _mockedHostEnvironemnt.Verify(he => he.EnvironmentName, Times.Once);
        _mockedCreateInvoiceService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGenerateInvoiceCallsCreateInvoiceServiceCreateInvoiceAsync()
    {
        var organizationId = Guid.NewGuid();

        _mockedHostEnvironemnt.Setup(he => he.EnvironmentName).Returns("development");
        _mockedCreateInvoiceService.Setup(cis => cis.CreateInvoiceAsync(
            organizationId,
            It.Is<DateTime>(dt => dt.Year == 2023 && dt.Month == 7 && dt.Day == 1),
            It.Is<DateTime>(dt => dt.Year == 2023 && dt.Month == 7 && dt.Day == 31)
        )).ReturnsAsync(202335154);

        var request = new GenerateInvoiceRequest
        {
            Year = 2023,
            Month = 7
        };

        _ = request.Validate(new(_sut)).ToList();

        var actual = await _sut.GenerateInvoice(organizationId, request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedAtActionResult>(actual.Result);
        Assert.IsType<ApiResponse<int>>(((CreatedAtActionResult)actual.Result!).Value);

        var actualResponse = (ApiResponse<int>)((CreatedAtActionResult)actual.Result!).Value!;

        Assert.Equal(202335154, actualResponse.Data);

        _mockedHostEnvironemnt.Verify(he => he.EnvironmentName, Times.Once);
        _mockedCreateInvoiceService.Verify(cis => cis.CreateInvoiceAsync(organizationId, It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
        _mockedCreateInvoiceService.VerifyNoOtherCalls();
    }
}