﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using InvoiceService.Controllers;
using InvoiceService.Dtos.Request.Filters;
using InvoiceService.Dtos.Response.Invoice;
using InvoiceService.Services.Invoice;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Services.Country;
using WebApiCore.Services.Logging;

namespace InvoiceService.Tests.Controllers;

public class InvoicesControllerTests
{
    private static readonly Guid ValidAdminId = Guid.NewGuid();

    private readonly InvoicesController _sut;
    private readonly Mock<IInvoiceService> _mockedInvoiceService = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();

    public InvoicesControllerTests()
    {
        _sut = new(_mockedInvoiceService.Object, _mockedCountryService.Object, _mockedUserLoggingService.Object);

        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());
    }

    [Fact]
    public async Task TestThatAvailableInvoicesCallsInvoiceService()
    {
        var organizationId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedCountryService.Setup(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<string>>())).ReturnsAsync(value: null);

        _mockedInvoiceService.Setup(@is => @is.InvoicesAsync(organizationId, eventId, 10, 0, "123", null)).ReturnsAsync(new PaginatedResultSet<AvailableInvoiceResponse>
        {
            TotalItems = 1,
            Items = new AvailableInvoiceResponse[] { new() }
        });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var request = new PaginatedRequest<AdminInvoicesFilter>
        {
            Options = new() { OrganizationId = organizationId, EventId = eventId, SearchQuery = "123" },
            Page = 1,
            PageSize = 10
        };

        var actual = await _sut.AvailableInvoices(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<PaginatedResponse<AvailableInvoiceResponse>>>(actualResult.Value);

        _mockedCountryService.Verify(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<string>>()), Times.Once);
        _mockedInvoiceService.Verify(@is => @is.InvoicesAsync(organizationId, eventId, 10, 0, "123", null), Times.Once);
        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAvailableOrganizationInvoicesCallsInvoiceService()
    {
        var organizationId = Guid.NewGuid();

        _sut.SetupHttpContext(organizationId: organizationId);

        _mockedInvoiceService.Setup(@is => @is.InvoicesAsync(organizationId, null, 10, 0, "123", null)).ReturnsAsync(new PaginatedResultSet<AvailableInvoiceResponse>
        {
            TotalItems = 1,
            Items = new AvailableInvoiceResponse[] { new() }
        });

        var request = new PaginatedRequest<InvoicesFilter>
        {
            Page = 1,
            PageSize = 10,
            Options = new() { EventId = null, SearchQuery = "123" }
        };

        var actual = await _sut.AvailableOrganizationInvoices(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<PaginatedResponse<AvailableInvoiceResponse>>>(actualResult.Value);

        _mockedInvoiceService.Verify(@is => @is.InvoicesAsync(organizationId, null, 10, 0, "123", null), Times.Once);
    }

    [Fact]
    public async Task TestThatExportOrganizationInvoicesAsCsvCallsInvoiceServiceInvoicesAsCsvAsyncAndServesFile()
    {
        var organizationId = Guid.NewGuid();

        _sut.SetupHttpContext(organizationId: organizationId);

        _mockedInvoiceService.Setup(@is => @is.InvoicesAsCsvAsync(organizationId, null, null, null))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportOrganizationInvoicesAsCsv(new()
        {
            SearchQuery = null
        });

        Assert.Equal("text/csv", actual.ContentType);
        _mockedInvoiceService.Verify(@is => @is.InvoicesAsCsvAsync(organizationId, null, null, null), Times.Once);
    }

    [Fact]
    public async Task TestThatExportPlatformInvoicesAsCsvCallsInvoiceServiceInvoicesAsCsvAsyncAndServesFile()
    {
        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());

        _mockedCountryService.Setup(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<string>>())).ReturnsAsync(value: null);

        _mockedInvoiceService.Setup(@is => @is.InvoicesAsCsvAsync(null, null, null, null))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.ExportPlatformInvoicesAsCsv(new());

        Assert.Equal("text/csv", actual.ContentType);
        _mockedCountryService.Verify(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<string>>()), Times.Once);
        _mockedInvoiceService.Verify(@is => @is.InvoicesAsCsvAsync(null, null, null, null), Times.Once);
        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
    }
}