﻿using System;
using System.Linq.Expressions;
using InvoiceService.Utils;

namespace InvoiceService.Tests.Utils;

public class ExpressionUtilsTests
{
    [Fact]
    public void TestThatPromoteReturnsIfTypeCodesAreTheSame()
    {
        Expression lhs = Expression.Constant(4.5m);
        Expression rhs = Expression.Constant(95.113m);

        ExpressionUtils.Promote(ref lhs, ref rhs);

        Assert.True(lhs is ConstantExpression);
        Assert.True(rhs is ConstantExpression);
    }

    [Fact]
    public void TestThatPromotePromotesLeftSide()
    {
        Expression lhs = Expression.Constant(10);
        Expression rhs = Expression.Constant(20d);

        ExpressionUtils.Promote(ref lhs, ref rhs);

        Assert.True(lhs is UnaryExpression);
        Assert.True(rhs is ConstantExpression);
    }

    [Fact]
    public void TestThatPromotePromotesRightSide()
    {
        Expression lhs = Expression.Constant(20d);
        Expression rhs = Expression.Constant(10);

        ExpressionUtils.Promote(ref lhs, ref rhs);

        Assert.True(lhs is ConstantExpression);
        Assert.True(rhs is UnaryExpression);
    }

    [Fact]
    public void TestThatRoundCreatesIntCastedMathRoundCall()
    {
        var actual = ExpressionUtils.Round(Expression.Constant(20.5918m));

        Assert.True(actual is UnaryExpression);
        Assert.Equal(typeof(int), ((UnaryExpression)actual).Type);

        var actualRoundExpression = ((UnaryExpression)actual).Operand;
        VerifyRoundCall(actualRoundExpression, 20.5918m, 0);
    }

    [Fact]
    public void TestThatRoundWithPrecisionCreatesMathRoundCall()
    {
        var actual = ExpressionUtils.Round(Expression.Constant(20.5918m), 2);

        Assert.NotNull(actual);
        VerifyRoundCall(actual, 20.5918m, 2);
    }

    private static void VerifyRoundCall(Expression actual, decimal input, int precision)
    {
        Assert.True(actual is MethodCallExpression);
        Assert.Equal(nameof(Math), ((MethodCallExpression)actual).Method.DeclaringType?.Name);
        Assert.Equal(nameof(Math.Round), ((MethodCallExpression)actual).Method.Name);
        Assert.Equal(2, ((MethodCallExpression)actual).Arguments.Count);
        Assert.True(((MethodCallExpression)actual).Arguments[0] is ConstantExpression);
        Assert.Equal(input, ((ConstantExpression)((MethodCallExpression)actual).Arguments[0]).Value);
        Assert.True(((MethodCallExpression)actual).Arguments[1] is ConstantExpression);
        Assert.Equal(precision, ((ConstantExpression)((MethodCallExpression)actual).Arguments[1]).Value);
    }
}