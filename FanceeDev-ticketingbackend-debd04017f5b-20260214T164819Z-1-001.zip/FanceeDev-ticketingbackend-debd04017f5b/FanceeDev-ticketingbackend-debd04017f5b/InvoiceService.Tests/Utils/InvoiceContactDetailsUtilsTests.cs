﻿using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Invoicing;
using InvoiceService.Dtos.Shared.Invoice;
using InvoiceService.Utils;
using JetBrains.Annotations;
using WebApiCore.Settings;

namespace InvoiceService.Tests.Utils;

[TestSubject(typeof(InvoiceContactDetailsUtils))]
public class InvoiceContactDetailsUtilsTests
{
    public static readonly object[][] IsEqualOrganizationTestData =
    {
        new object[]
        {
            new InvoiceContactDetails
            {
                FirstName = "Unit",
                LastName = "Test",
                Organization = "Unit Test B.V.",
                PaymentSettings = new() { Iban = "NLIBAN", VatCode = "1234", BankAccountNumber = "1234", Bic = "BIC" },
                Address = new()
                {
                    CountryCode = "NL",
                    PostalCode = "1234AB",
                    Street = "Apenstraat",
                    City = "Amsterdam",
                    HouseNumber = "24a"
                }
            },
            new Organization
            {
                User = new()
                {
                    UserContactInfo = new()
                    {
                        FirstName = "Unit",
                        LastName = "Test",
                        Address = new()
                        {
                            CountryCode = "NL",
                            PostalCode = "1234AB",
                            Street = "Apenstraat",
                            City = "Amsterdam",
                            HouseNumber = "24a"
                        }
                    }
                },
                Name = "Unit Test B.V.",
                PaymentSettings = new() { Iban = "NLIBAN", VatCode = "1234", BankAccountNumber = "1234", Bic = "BIC" }
            },
            true
        },
        new object[]
        {
            new InvoiceContactDetails
            {
                FirstName = "Unit",
                LastName = "Test",
                Organization = "Unit Test B.V.",
                PaymentSettings = new() { Iban = "NLIBAN", VatCode = "1234" },
                Address = new()
                {
                    CountryCode = "NL",
                    PostalCode = "1234AB",
                    Street = "Apenstraat",
                    City = "Amsterdam",
                    HouseNumber = "24a"
                }
            },
            new Organization
            {
                User = new()
                {
                    UserContactInfo = new()
                    {
                        FirstName = "Unit",
                        LastName = "Test",
                        Address = new()
                        {
                            CountryCode = "NL",
                            PostalCode = "1234AB",
                            Street = "Apenstraat",
                            City = "Amsterdam",
                            HouseNumber = "24a"
                        }
                    }
                },
                Name = "Unit Test B.V.",
                PaymentSettings = new() { Iban = "DEIBAN", VatCode = "1234", BankAccountNumber = "1234", Bic = "BIC" }
            },
            false
        }
    };

    public static readonly object[][] IsEqualOrganizationDetailsTestData =
    {
        new object[]
        {
            new InvoiceContactDetails
            {
                Organization = "Unit Test B.V.",
                PaymentSettings = new() { Iban = "NLIBAN", VatCode = "1234" },
                Address = new()
                {
                    CountryCode = "NL",
                    PostalCode = "1234AB",
                    Street = "Apenstraat",
                    City = "Amsterdam",
                    HouseNumber = "24a"
                },
                ChamberOfCommerceIdentifier = "C95283"
            },
            new OrganizationDetailsSettings
            {
                Address = new()
                {
                    CountryCode = "NL",
                    PostalCode = "1234AB",
                    Street = "Apenstraat",
                    City = "Amsterdam",
                    HouseNumber = "24a"
                },
                Name = "Unit Test B.V.",
                Iban = "NLIBAN",
                VatCode = "1234",
                ChamberOfCommerceIdentifier = "C95283",
                PlatformBaseCurrency = "EUR"
            },
            true
        },
        new object[]
        {
            new InvoiceContactDetails
            {
                Organization = "Unit Test B.V.",
                PaymentSettings = new() { Iban = "NLIBAN", VatCode = "1234" },
                Address = new()
                {
                    CountryCode = "NL",
                    PostalCode = "1234AB",
                    Street = "Apenstraat",
                    City = "Amsterdam",
                    HouseNumber = "24a"
                },
                ChamberOfCommerceIdentifier = "C95283"
            },
            new OrganizationDetailsSettings
            {
                Address = new()
                {
                    CountryCode = "NL",
                    PostalCode = "1234AB",
                    Street = "Apenstraat",
                    City = "Amsterdam",
                    HouseNumber = "24a"
                },
                Name = "Unit Test B.V.",
                Iban = "DEIBAN",
                VatCode = "1234",
                ChamberOfCommerceIdentifier = "C95283",
                PlatformBaseCurrency = "EUR"
            },
            false
        }
    };

    private readonly InvoiceContactDetails _organizationContactDetails = new()
    {
        FirstName = "Unit",
        LastName = "Test",
        Organization = "UnitTest B.V.",
        PaymentSettings = new() { Iban = "NL99TEST12345678" },
        Address = new() { CountryCode = "NL" }
    };

    private readonly Organization _organization = new()
    {
        User = new()
        {
            UserContactInfo = new()
            {
                FirstName = "Unit",
                LastName = "Test",
                Address = new() { CountryCode = "NL" }
            }
        },
        Name = "UnitTest B.V.",
        PaymentSettings = new() { Iban = "NL99TEST12345678" }
    };

    private readonly InvoiceContactDetails _organizationDetails = new()
    {
        Organization = "UnitTest B.V.",
        PaymentSettings = new() { Iban = "NL99TEST12345678" },
        Address = new() { CountryCode = "NL" }
    };

    private readonly OrganizationDetailsSettings _organizationDetailsSettings = new()
    {
        Name = "UnitTest B.V.",
        Iban = "NL99TEST12345678",
        Address = new() { CountryCode = "NL" }
    };

    [Theory]
    [MemberData(nameof(IsEqualOrganizationTestData))]
    public void TestThatIsEqualWithOrganizationReturnsExpectedResult(InvoiceContactDetails source, Organization organization, bool expected)
    {
        var actual = source.IsEqual(organization);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [MemberData(nameof(IsEqualOrganizationDetailsTestData))]
    public void TestThatIsEqualWithOrganizationDetailsSettingsReturnsExpectedResult(InvoiceContactDetails source, OrganizationDetailsSettings organization, bool expected)
    {
        var actual = source.IsEqual(organization);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatFromOrganizationDetailsReturnsNewObjectIfItIsNotEqual()
    {
        _organizationDetailsSettings.Iban = "DE99TEST12345678";
        _organizationDetailsSettings.Address.CountryCode = "DE";
        _organizationDetailsSettings.Name = "UnitTest GMBH";

        var actual = InvoiceContactDetailsUtils.FromOrganizationDetails(_organizationDetails, _organizationDetailsSettings);

        Assert.NotSame(_organizationDetails, actual);
    }

    [Fact]
    public void TestThatFromOrganizationDetailsReturnsExistingObjectIfItIsEqual()
    {
        var actual = InvoiceContactDetailsUtils.FromOrganizationDetails(_organizationDetails, _organizationDetailsSettings);

        Assert.Same(_organizationDetails, actual);
    }

    [Fact]
    public void TestThatFromOrganizationReturnsNewObjectIfItIsNotEqual()
    {
        _organization.PaymentSettings.Iban = "DE99TEST12345678";
        _organization.PaymentSettings.BankAccountNumber = "BANK01";
        _organization.PaymentSettings.Bic = "BIC01";
        _organization.User.UserContactInfo.Address.CountryCode = "DE";
        _organization.Name = "UnitTest GMBH";

        var actual = InvoiceContactDetailsUtils.FromOrganization(_organizationContactDetails, _organization);

        Assert.NotSame(_organizationContactDetails, actual);
    }

    [Fact]
    public void TestThatFromOrganizationReturnsExistingObjectIfItIsEqual()
    {
        var actual = InvoiceContactDetailsUtils.FromOrganization(_organizationContactDetails, _organization);

        Assert.Same(_organizationContactDetails, actual);
    }

    [Fact]
    public void TestThatUpdateDetailsUpdatesTheDetails()
    {
        var lastDetails = new LastInvoiceContactDetails
        {
            Sender = _organizationDetails,
            Receiver = _organizationContactDetails
        };

        _organization.User.UserContactInfo.Address.CountryCode = "BE";
        _organizationDetailsSettings.Address.CountryCode = "DE";

        var actual = lastDetails.UpdateDetails(_organization, _organizationDetailsSettings);

        Assert.Equal("BE", actual.Receiver!.Address.CountryCode);
        Assert.Equal("DE", actual.Sender!.Address.CountryCode);
    }
}