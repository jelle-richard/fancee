﻿using System;
using System.Collections.Generic;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Invoicing;
using InvoiceService.Utils;

namespace InvoiceService.Tests.Utils;

public class AddressUtilsTests
{
    [Fact]
    public void TestThatCloneCreatesCopyOfAddressWithoutPrimaryKey()
    {
        var source = new Address
        {
            Id = Guid.NewGuid(),
            City = "UnitCity",
            CountryCode = "NL",
            HouseNumber = "29b",
            Latitude = 42.59m,
            Longitude = 1.1m,
            PostalCode = "1234AB",
            Street = "UnitStreet",
            Venue = "UnitVenue",
            CountryCodeNavigation = new() { Code = "NL" },
            ClientOrders = new List<ClientOrder>(),
            Events = new List<Event>(),
            InvoiceContactDetails = new List<InvoiceContactDetails>(),
            UserContactInfos = new List<UserContactInfo>()
        };

        var actual = source.Copy();

        Assert.Equal(Guid.Empty, actual.Id);
        Assert.Equal("UnitCity", actual.City);
        Assert.Equal("NL", actual.CountryCode);
        Assert.Equal("29b", actual.HouseNumber);
        Assert.Equal(42.59m, actual.Latitude);
        Assert.Equal(1.1m, actual.Longitude);
        Assert.Equal("1234AB", actual.PostalCode);
        Assert.Equal("UnitStreet", actual.Street);
        Assert.Equal("UnitVenue", actual.Venue);
        Assert.Null(actual.CountryCodeNavigation);
        Assert.Null(actual.ClientOrders);
        Assert.Null(actual.Events);
        Assert.Null(actual.InvoiceContactDetails);
        Assert.Null(actual.UserContactInfos);
    }
}