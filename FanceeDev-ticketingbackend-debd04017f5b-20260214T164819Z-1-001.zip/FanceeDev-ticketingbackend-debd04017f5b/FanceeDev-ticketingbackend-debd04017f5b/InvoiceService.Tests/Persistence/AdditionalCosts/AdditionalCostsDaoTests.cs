using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Invoicing;
using InvoiceService.Persistence.AdditionalCosts;

namespace InvoiceService.Tests.Persistence.AdditionalCosts;

public class AdditionalCostsDaoTests
{
    private static readonly Guid[] OrganizationIds = { Guid.NewGuid(), Guid.NewGuid() };
    private static readonly Guid[] AdditionalCostIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private readonly AdditionalCostsDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public AdditionalCostsDaoTests()
    {
        _mockedContext.Setup(c => c.AdditionalCosts).ReturnsDbSet(new List<AdditionalCost>
        {
            new()
            {
                Id = AdditionalCostIds[0],
                OrganizationId = OrganizationIds[0],
                BilledOn = DateTime.Parse("2022-07-26 10:20:00")
            },
            new()
            {
                Id = AdditionalCostIds[1],
                OrganizationId = OrganizationIds[0],
                BilledOn = DateTime.Parse("2022-08-23 12:12:12")
            },
            new()
            {
                Id = AdditionalCostIds[2],
                OrganizationId = OrganizationIds[1],
                BilledOn = DateTime.Parse("2022-08-15 00:40:00")
            },
            new()
            {
                Id = AdditionalCostIds[3],
                OrganizationId = OrganizationIds[0],
                BilledOn = DateTime.Parse("2022-08-01 23:49:22")
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAllInDateRangeByOrganizationIdReturnsAllAdditionalCostsInDateRangeForOrganization()
    {
        var start = DateTime.Parse("2022-08-01 00:00:00");
        var end = DateTime.Parse("2022-08-31 23:59:59");

        var actual = (await _sut.AllInDateRangeByOrganizationId(OrganizationIds[0], start, end)).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal(AdditionalCostIds[1], actual[0].Id);
        Assert.Equal(AdditionalCostIds[3], actual[1].Id);
    }

    [Fact]
    public async Task TestThatInsertAsyncInsertsAdditionalCost()
    {
        var additionalCost = new AdditionalCost();

        await _sut.InsertAsync(additionalCost);

        _mockedContext.Verify(c => c.AdditionalCosts.AddAsync(additionalCost, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}