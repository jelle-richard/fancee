using DataSynchronisationService.BackgroundTasks.MessageBus;
using DataSynchronisationService.Persistence.Client;
using DataSynchronisationService.Persistence.Event;
using DataSynchronisationService.Persistence.Orders;
using DataSynchronisationService.Services.DataMessageStrategy;
using WebApiCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "DataSynchronisationService",
        EndpointName = "DataSynchronisationService v1"
    }
};

builder.AddHostedService<RequestTicketingDataListener>();
builder.AddDependency(sp => new RequestTicketingDataListener(sp), ServiceLifetime.Singleton);

builder.AddDependency<IDataMessageStrategy, UserDataStrategy>(ServiceLifetime.Scoped);
builder.AddDependency<IDataMessageStrategy, EventDataStrategy>(ServiceLifetime.Scoped);
builder.AddDependency<IDataMessageStrategy, OrderDataStrategy>(ServiceLifetime.Scoped);
builder.AddDependency<IClientDao, ClientDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderDao, OrderDao>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();