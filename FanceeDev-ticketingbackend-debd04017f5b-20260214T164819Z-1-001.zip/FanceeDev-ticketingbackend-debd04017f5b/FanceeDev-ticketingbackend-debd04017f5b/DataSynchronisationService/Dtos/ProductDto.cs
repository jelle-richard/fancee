using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Dtos;

public class ProductDto
{
    public Guid ProductId { get; set; }
    public Guid EventId { get; set; }
    public string? Name { get; set; }
    public int? PriceCents { get; set; }
    public int? FeeCents { get; set; }
    public string? Description { get; set; }
    public int MaximumPurchaseOrder { get; set; }
    public int PackQuantity { get; set; }
    public ProductType Type { get; set; }
    public IList<ProductPriceHistoryDto> ProductPriceHistory { get; set; } = [];
}