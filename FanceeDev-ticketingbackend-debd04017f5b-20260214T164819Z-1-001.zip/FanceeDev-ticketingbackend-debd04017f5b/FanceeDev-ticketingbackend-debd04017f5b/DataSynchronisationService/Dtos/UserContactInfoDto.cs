namespace DataSynchronisationService.Dtos;

public class UserContactInfoDto
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public Guid? AddressId { get; set; }
    public string? PhoneNumber { get; set; }
    public AddressDto? Address { get; set; }
}