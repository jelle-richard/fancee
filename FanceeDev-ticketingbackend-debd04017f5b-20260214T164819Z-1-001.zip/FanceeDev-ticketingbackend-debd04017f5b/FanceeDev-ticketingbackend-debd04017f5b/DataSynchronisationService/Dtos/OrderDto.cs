using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Dtos;

public class OrderDto
{
    public Guid OrderId { get; set; }
    public PaymentStatus PaymentStatus { get; set; }
    public Guid? PaymentMethodId { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime UpdatedOn { get; set; }
    public DateTime? PaidOn { get; set; }
    public string? CurrencyCode { get; set; }
    public string? PspReference { get; set; }
    public Guid? ReservationReferenceId { get; set; }
    public int? TotalCostCents { get; set; }
    public int? PaymentFeeCents { get; set; }
    public PaidBy? PaymentFeePaidBy { get; set; }
    public PaymentRefusalReason? PaymentRefusalReason { get; set; }
    public IList<IssuedProductDto> IssuedProducts { get; set; } = [];
    public ReservationReferenceDto? ReservationReference { get; set; }
    public CurrencyDto? Currency { get; set; }
    public Guid? EventId { get; set; }
}