using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Dtos;

public class EventDto
{
    public Guid EventId { get; set; }
    public Guid OrganizationId { get; set; }
    public string? Name { get; set; }
    public EventType Type { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public EventStatus Status { get; set; }
    public string? Description { get; set; }
    public Guid? AddressId { get; set; }
    public int? MinimumAge { get; set; }
    public int ReservationTimeMinutes { get; set; }
    public AddressDto? Address { get; set; }
    public IList<string> Tags { get; set; } = [];
    public IList<ShopDto> Shops { get; set; } = [];
    public IList<ProductDto> Products { get; set; } = [];
    public DateTime CreatedOn { get; set; }
}