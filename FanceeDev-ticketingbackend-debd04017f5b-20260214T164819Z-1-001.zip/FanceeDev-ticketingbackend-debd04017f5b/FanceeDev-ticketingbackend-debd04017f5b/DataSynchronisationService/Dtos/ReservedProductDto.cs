namespace DataSynchronisationService.Dtos;

public class ReservedProductDto
{
    public Guid ReservedProductId { get; set; }
    public Guid ReservationReferenceId { get; set; }
    public Guid ProductId { get; set; }
    public int Quantity { get; set; }
    public string? ShopCode { get; set; }
}