namespace DataSynchronisationService.Dtos;

public class ReservationReferenceDto
{
    public Guid ReservationReferenceId { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime ExpiresOn { get; set; }
    public Guid? DiscountId { get; set; }
    public string? ShopCode { get; set; }
    public IList<ReservedProductDto> ReservedProducts { get; set; } = [];
}