using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Dtos;

public class IssuedProductDto
{
    public Guid IssuedProductId { get; set; }
    public Guid? ReservedProductId { get; set; }
    public Guid ProductId { get; set; }
    public Guid? OrderId { get; set; }
    public IssuedProductType Type { get; set; }
    public DateTime CreatedOn { get; set; }
}