namespace DataSynchronisationService.Dtos;

public class ClientDto
{
    public Guid UserId { get; set; }
    public string? FacebookId { get; set; }
    public string? Referer { get; set; }
    public required UserDto User { get; set; }
    public DateTime CreatedOn { get; set; }
    public IList<ClientOrderDto> ClientOrders { get; set; } = [];
}