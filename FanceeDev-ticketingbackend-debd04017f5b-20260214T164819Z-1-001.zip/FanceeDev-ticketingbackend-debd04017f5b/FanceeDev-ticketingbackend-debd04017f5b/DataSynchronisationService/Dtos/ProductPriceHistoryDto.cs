namespace DataSynchronisationService.Dtos;

public class ProductPriceHistoryDto
{
    public Guid ProductId { get; set; }
    public DateTime Date { get; set; }
    public int? PriceCents { get; set; }
    public int? FeeCents { get; set; }
}