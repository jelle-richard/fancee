namespace DataSynchronisationService.Dtos;

public class CurrencyDto
{
    public required string CurrencyCode { get; set; }
    public required string Character { get; set; }
    public required string Name { get; set; }
    public int Decimals { get; set; }
    public bool Active { get; set; }
}