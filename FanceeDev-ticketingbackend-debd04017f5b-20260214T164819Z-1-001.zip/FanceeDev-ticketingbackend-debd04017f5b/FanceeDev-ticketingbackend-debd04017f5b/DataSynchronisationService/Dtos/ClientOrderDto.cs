using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Dtos;

public class ClientOrderDto
{
    public Guid OrderId { get; set; }
    public Guid ClientId { get; set; }
    public Guid? AddressId { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? PhoneNumber { get; set; }
    public bool OptInPromotionalSms { get; set; }
    public bool OptInPromotionalEmail { get; set; }
    public int ReceiveViaSmsCostCents { get; set; }
    public int TicketServicePlusCostCents { get; set; }
    public DateTime? Birthdate { get; set; }
    public Gender? Gender { get; set; }
    public AddressDto? Address { get; set; }
}