using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Dtos;

public class UserDto
{
    public Guid UserId { get; set; }
    public Guid? FanceeUsersId { get; set; }
    public UserType Type { get; set; } = UserType.None;
    public required string Email { get; set; }
    public DateTime? LastLogin { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public Guid? AccountVerifyId { get; set; }
    public UserContactInfoDto? UserContactInfo { get; set; }
}