namespace DataSynchronisationService.Persistence;

public interface ISynchronisationDao<TEntityModel> where TEntityModel : class
{
    /// <summary>
    /// Retrieves all the newly created records from the given DateTime to now.
    /// If no DateTime is given, will return all the existing records in the database.
    /// </summary>
    /// <param name="from"></param>
    /// <returns></returns>
    public Task<IEnumerable<TEntityModel>> NewlyCreatedAsync(DateTime? from);

    /// <summary>
    /// Retrieves all the records with existing Id's in the given list from the given DateTime to now.
    /// If no DateTime is given, will return all existing records with existing Id's in given list.
    /// </summary>
    /// <param name="modelIds"></param>
    /// <param name="until"></param>
    /// <returns></returns>
    public Task<IEnumerable<TEntityModel>> UpdatedSinceAsync(IList<Guid> modelIds, DateTime? until);
}