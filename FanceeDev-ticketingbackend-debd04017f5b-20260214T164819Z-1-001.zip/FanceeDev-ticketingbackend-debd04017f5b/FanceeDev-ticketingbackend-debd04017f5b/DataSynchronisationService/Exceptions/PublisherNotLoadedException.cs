namespace DataSynchronisationService.Exceptions;

public class PublisherNotLoadedException : Exception;