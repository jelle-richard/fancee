namespace DataSynchronisationService.Exceptions;

public class StrategiesNotLoadedException : Exception;