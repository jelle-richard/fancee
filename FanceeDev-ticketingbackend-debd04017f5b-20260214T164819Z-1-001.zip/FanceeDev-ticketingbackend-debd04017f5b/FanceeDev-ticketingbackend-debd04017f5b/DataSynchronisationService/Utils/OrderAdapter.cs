using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class OrderAdapter
{
    public static IList<OrderDto> ToDto(this IEnumerable<Order> orders) => orders.Select(ToDto).ToList();

    public static OrderDto ToDto(this Order order) =>
        new()
        {
            OrderId = order.Id,
            PaymentStatus = order.PaymentStatus,
            PaymentMethodId = order.PaymentMethodId,
            CreatedOn = order.CreatedAt,
            UpdatedOn = order.LastAlteration,
            CurrencyCode = order.Currency,
            PspReference = order.PspReference,
            ReservationReferenceId = order.ReservationReference,
            TotalCostCents = order.TotalCostCents,
            PaymentFeeCents = order.PaymentFeeCents,
            PaymentFeePaidBy = order.PaymentFeePaidBy,
            PaymentRefusalReason = order.PaymentRefusalReason,
            PaidOn = order.PaidOn,
            IssuedProducts = order.IssuedProducts.ToDto(),
            ReservationReference = order.ReservationReferenceNavigation.ToDto(),
            Currency = order.CurrencyNavigation.ToDto(),
            EventId = order.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId
        };
}