using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class ProductPriceHistoryAdapter
{
    public static List<ProductPriceHistoryDto> ToDto(this IEnumerable<ProductPriceHistory> productPriceHistories) =>
        productPriceHistories.Select(ToDto).ToList();

    public static ProductPriceHistoryDto ToDto(this ProductPriceHistory productPriceHistory) =>
        new()
        {
            ProductId = productPriceHistory.ProductId,
            Date = productPriceHistory.Date,
            PriceCents = productPriceHistory.PriceCents,
            FeeCents = productPriceHistory.FeeCents
        };
}