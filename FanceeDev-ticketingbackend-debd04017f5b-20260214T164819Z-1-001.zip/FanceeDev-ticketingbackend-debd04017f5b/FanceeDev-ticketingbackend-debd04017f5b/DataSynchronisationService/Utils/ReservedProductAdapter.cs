using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class ReservedProductAdapter
{
    public static IList<ReservedProductDto> ToDto(this IEnumerable<ReservedProduct> reservedProducts) => reservedProducts.Select(ToDto).ToList();

    public static ReservedProductDto ToDto(this ReservedProduct reservedProduct) =>
        new()
        {
            ReservedProductId = reservedProduct.Id,
            ReservationReferenceId = reservedProduct.ReservationReference,
            ProductId = reservedProduct.ProductId,
            Quantity = reservedProduct.Quantity,
            ShopCode = reservedProduct.ShopCode
        };
}