using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class ShopAdapter
{
    public static List<ShopDto> ToDto(this IEnumerable<Shop> shops) => shops.Select(ToDto).ToList();

    public static ShopDto ToDto(this Shop shop) =>
        new()
        {
            Code = shop.Code,
            EventId = shop.EventId,
            Name = shop.Name,
            Active = shop.Active,
            StartDate = shop.StartDate,
            EndDate = shop.EndDate,
            IsReservationShop = shop.IsReservationShop,
            IsSecuredUntil = shop.IsSecuredUntil,
            NumberOfViews = shop.NumberOfViews,
            Tags = shop.Tags.Select(t => t.Name).ToList()
        };
}