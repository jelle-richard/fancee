using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class CurrencyAdapter
{
    public static CurrencyDto ToDto(this Currency currency) =>
        new()
        {
            CurrencyCode = currency.ShortCode,
            Character = currency.Character,
            Name = currency.Name,
            Decimals = currency.Decimals,
            Active = currency.Active
        };
}