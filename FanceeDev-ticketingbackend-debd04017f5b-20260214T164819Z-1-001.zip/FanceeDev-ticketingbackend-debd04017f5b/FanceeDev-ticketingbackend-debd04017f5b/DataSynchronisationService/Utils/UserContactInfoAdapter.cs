using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class UserContactInfoAdapter
{
    public static UserContactInfoDto ToDto(this UserContactInfo userContactInfo) =>
        new()
        {
            FirstName = userContactInfo.FirstName,
            LastName = userContactInfo.LastName,
            AddressId = userContactInfo.AddressId,
            PhoneNumber = userContactInfo.PhoneNumber,
            Address = userContactInfo.Address?.ToDto()
        };
}