using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class ReservationReferenceAdapter
{
    public static ReservationReferenceDto ToDto(this ReservationReference reservationReference) =>
        new()
        {
            ReservationReferenceId = reservationReference.Reference,
            CreatedOn = reservationReference.CreatedOn,
            ExpiresOn = reservationReference.ExpiresOn,
            DiscountId = reservationReference.DiscountId,
            ShopCode = reservationReference.ShopCode,
            ReservedProducts = reservationReference.ReservedProducts?.ToDto() ?? []
        };
}