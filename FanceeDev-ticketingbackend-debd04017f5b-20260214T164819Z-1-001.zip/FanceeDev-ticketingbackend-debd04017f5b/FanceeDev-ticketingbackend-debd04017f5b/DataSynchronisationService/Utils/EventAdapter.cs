using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class EventAdapter
{
    public static IEnumerable<EventDto> ToDto(this IEnumerable<Event> events) =>
        events.Select(ToDto).ToList();

    public static EventDto ToDto(this Event @event) =>
        new()
        {
            EventId = @event.Id,
            OrganizationId = @event.OrganizationId,
            Name = @event.Name,
            Type = @event.Type,
            StartDate = @event.StartDate,
            EndDate = @event.EndDate,
            Status = @event.Status,
            Description = @event.Description,
            AddressId = @event.AddressId,
            MinimumAge = @event.MinimumAge,
            ReservationTimeMinutes = @event.ReservationTimeMinutes,
            Address = @event.Address?.ToDto() ?? null,
            Tags = @event.Tags.Select(t => t.Name).ToList(),
            Shops = @event.Shops.ToDto(),
            Products = @event.Products.ToDto(),
            CreatedOn = @event.CreatedOn
        };
}