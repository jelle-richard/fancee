using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class UserAdapter
{
    public static UserDto ToDto(this User user) =>
        new()
        {
            UserId = user.Id,
            FanceeUsersId = user.FanceeUsersId,
            Type = user.Type,
            Email = user.Email,
            LastLogin = user.LastLogin,
            CreatedOn = user.CreatedOn,
            DateOfBirth = user.DateOfBirth,
            AccountVerifyId = user.AccountVerifyId,
            UserContactInfo = user.UserContactInfo?.ToDto()
        };
}