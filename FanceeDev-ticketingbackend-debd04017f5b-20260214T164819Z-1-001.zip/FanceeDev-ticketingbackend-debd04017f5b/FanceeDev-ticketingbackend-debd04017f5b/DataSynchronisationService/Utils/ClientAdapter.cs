using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class ClientAdapter
{
    public static IList<ClientDto> ToDto(this IEnumerable<Client> clients) =>
        clients.Select(ToDto).ToList();

    public static ClientDto ToDto(this Client client) =>
        new()
        {
            UserId = client.UserId,
            FacebookId = client.FacebookId,
            Referer = client.Referer,
            User = client.User.ToDto(),
            CreatedOn = client.User.CreatedOn,
            ClientOrders = client.ClientOrders.ToDto()
        };
}