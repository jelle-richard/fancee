using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class ClientOrderAdapter
{
    public static IList<ClientOrderDto> ToDto(this IEnumerable<ClientOrder> clientOrders) => clientOrders.Select(ToDto).ToList();

    public static ClientOrderDto ToDto(this ClientOrder clientOrder) =>
        new()
        {
            OrderId = clientOrder.OrderId,
            ClientId = clientOrder.ClientId,
            AddressId = clientOrder.AddressId,
            FirstName = clientOrder.FirstName,
            LastName = clientOrder.LastName,
            PhoneNumber = clientOrder.PhoneNumber,
            OptInPromotionalSms = clientOrder.OptInPromotionalEmail,
            OptInPromotionalEmail = clientOrder.OptInPromotionalEmail,
            ReceiveViaSmsCostCents = clientOrder.ReceiveViaSmsCostCents,
            TicketServicePlusCostCents = clientOrder.TicketServicePlusCostCents,
            Birthdate = clientOrder.Birthdate,
            Gender = clientOrder.Gender,
            Address = clientOrder.Address?.ToDto() ?? null
        };
}