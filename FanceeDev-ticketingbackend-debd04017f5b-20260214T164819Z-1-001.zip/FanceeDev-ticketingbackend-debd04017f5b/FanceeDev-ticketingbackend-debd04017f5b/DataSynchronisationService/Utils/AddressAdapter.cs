using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class AddressAdapter
{
    public static AddressDto ToDto(this Address address) =>
        new()
        {
            Id = address.Id,
            AddressId = address.Id,
            CountryCode = address.CountryCode,
            PostalCode = address.PostalCode,
            Street = address.Street,
            City = address.City,
            HouseNumber = address.HouseNumber,
            Venue = address.Venue,
            Latitude = address.Latitude,
            Longitude = address.Longitude
        };
}