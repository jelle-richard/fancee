using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class IssuedProductAdapter
{
    public static IList<IssuedProductDto> ToDto(this IEnumerable<IssuedProduct> issuedProducts) => issuedProducts.Select(ToDto).ToList();

    public static IssuedProductDto ToDto(this IssuedProduct issuedProduct) =>
        new()
        {
            IssuedProductId = issuedProduct.Id,
            ReservedProductId = issuedProduct.ReservedProductId,
            ProductId = issuedProduct.ProductId,
            OrderId = issuedProduct.OrderId,
            Type = issuedProduct.Type,
            CreatedOn = issuedProduct.CreatedOn
        };
}