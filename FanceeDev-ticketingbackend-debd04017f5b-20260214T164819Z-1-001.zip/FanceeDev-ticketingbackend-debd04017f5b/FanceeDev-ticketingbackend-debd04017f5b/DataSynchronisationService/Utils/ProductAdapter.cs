using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Utils;

public static class ProductAdapter
{
    public static List<ProductDto> ToDto(this IEnumerable<Product> products) => products.Select(ToDto).ToList();

    public static ProductDto ToDto(this Product product) =>
        new()
        {
            ProductId = product.Id,
            EventId = product.EventId,
            Name = product.Name,
            PriceCents = product.PriceCents,
            FeeCents = product.FeeCents,
            Description = product.Description,
            MaximumPurchaseOrder = product.MaximumPurchasePerOrder,
            PackQuantity = product.PackQuantity,
            Type = product.Type,
            ProductPriceHistory = product.PriceHistories.ToDto()
        };
}