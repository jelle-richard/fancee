#!/usr/bin/env bash
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

if [[ -z "$1" ]]; then
  echo "No tag provided"
  exit 1
fi

if [[ -z "$2" ]]; then
  echo "No service provided"
  exit 1
fi

# Runs the given command until it succeeds (with a maximum of 15 attempts)
run() {
  local max_attempts=15
  local attempt=0
  local cmd=$1
  
  # Makes sure to cancel all other attempts if CTRL+C is pressed.
  trap 'echo -e "$RED[🛑] Stopping...$NC"; exit 1' INT
  
  echo -e "$CYAN[🚀] Running command: $cmd $NC"
  
  until $cmd
  do
    local exit_status=$?
    attempt=$((attempt + 1))
    
    if [ $attempt -eq $max_attempts ]
    then
      echo -e "$RED[🤬] Failed running command after $max_attempts attempts$NC"
      return $exit_status
    fi
    
    echo -e "$YELLOW[↻] Failed running command, retrying ($(($attempt + 1))/$max_attempts)...$NC"
  done
  
  echo -e "$GREEN[✔] Command finished after $(($attempt + 1)) attempt(s)$NC"
}

if [ "$2" = "all" ]; then
  # We have to publish MigrationRunner seperatly as it does not inherit ASP.NET Web SDK
  run "dotnet publish --os linux --arch x64 -c Release -p:PublishProfile=DefaultContainer -p:ContainerImageTag=$1 ticketingbackend.sln"
  run "dotnet publish --os linux --arch x64 -c Release /t:PublishContainer -p:ContainerImageTag=$1 MigrationRunner/MigrationRunner.csproj"
elif [ "$2" = "MigrationRunner" ]; then
  run "dotnet publish --os linux --arch x64 -c Release /t:PublishContainer -p:ContainerImageTag=$1 $2/$2.csproj"
else
  run "dotnet publish --os linux --arch x64 -c Release -p:PublishProfile=DefaultContainer -p:ContainerImageTag=$1 $2/$2.csproj"
fi
