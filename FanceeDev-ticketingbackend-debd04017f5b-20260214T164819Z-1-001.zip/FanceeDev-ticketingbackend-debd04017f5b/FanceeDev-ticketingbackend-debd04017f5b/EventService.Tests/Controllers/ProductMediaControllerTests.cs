﻿using System;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Requests.Media;
using EventService.Dtos.Requests.Product.Media;
using EventService.Services.Product;
using EventService.Services.Product.Exceptions;
using EventService.Services.Shop;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using Claim = System.Security.Claims.Claim;

namespace EventService.Tests.Controllers;

public class ProductMediaControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ProductMediaController _sut;
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();
    private readonly Mock<IShopService> _mockedShopService = new();

    public ProductMediaControllerTests()
    {
        _sut = new(_mockedProductService.Object, _mockedOrganizationService.Object, _mockedShopService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatUploadMediaThrowsEventNotFoundExceptionIfAuthorizedUserIsNotOwnerOfEvent()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.UploadMedia(eventId, Guid.NewGuid(), new()));
    }

    [Fact]
    public async Task TestThatUploadMediaThrowsProductNotFoundExceptionIfAuthorizedUserIsNotOwnerOfProduct()
    {
        var productId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () =>
            await _sut.UploadMedia(eventId, productId, new()));
    }

    [Fact]
    public async Task TestThatUploadMediaReturnsUrlWithCreatedResource()
    {
        var productId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        var request = new UploadProductMediaRequest();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.UploadMediaAsync(productId, request))
            .ReturnsAsync(new UploadedFile { Id = It.IsAny<Guid>(), Url = "http://localhost/uploads/test.png" });

        var actual = await _sut.UploadMedia(eventId, productId, request);

        Assert.NotNull(actual);
        Assert.IsType<ActionResult<ApiResponse<Guid>>>(actual);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(productId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.UploadMediaAsync(productId, request), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteMediaThrowsEventNotFoundExceptionOnInvalidEvent()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.DeleteMedia(eventId, Guid.NewGuid(), Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatDeleteMediaThrowsProductNotFoundExceptionOnInvalidProduct()
    {
        var productId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () =>
            await _sut.DeleteMedia(eventId, productId, Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatDeleteMediaThrowsMediaNotFoundExceptionOnInvalidFile()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, productId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.DeleteMedia(eventId, productId, fileId));
    }

    [Fact]
    public async Task TestThatDeleteMediaCallsDeleteMediaAsync()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, productId)).ReturnsAsync(true);

        var actual = await _sut.DeleteMedia(eventId, productId, fileId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedProductService.Verify(ps => ps.DeleteMediaAsync(productId, eventId, fileId), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointThrowsEventNotFoundExceptionWhenOwnerOfEventAsyncReturnsFalse()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.UpdateMediaFocalPoint(eventId, Guid.NewGuid(), Guid.NewGuid(), new()));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointThrowsProductNotFoundExceptionWhenBelongsToEventReturnsFalse()
    {
        var eventId = Guid.NewGuid();
        var productId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () =>
            await _sut.UpdateMediaFocalPoint(eventId, productId, Guid.NewGuid(), new()));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(productId, eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointThrowsMediaNotFoundExceptionWhenOwnerOfMediaReturnsFalse()
    {
        var eventId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, productId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.UpdateMediaFocalPoint(eventId, productId, fileId, new()));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(productId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, productId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointCallsProductServiceUpdateMediaFocalPointAsyncAndInvalidatesCaches()
    {
        var eventId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, productId))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps =>
            ps.UpdateMediaFocalPointAsync(productId, fileId, It.IsAny<FocalPointRequest>()));

        var actual = await _sut.UpdateMediaFocalPoint(eventId, productId, fileId, new()
        {
            FocalPointHeightPercentage = 55,
            FocalPointWidthPercentage = 40
        });

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(productId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, productId), Times.Once);
        _mockedProductService.Verify(
            ps => ps.UpdateMediaFocalPointAsync(productId, fileId, It.IsAny<FocalPointRequest>()), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatRepositionMediaThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        var eventId = Guid.Empty;

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.RepositionMedia(eventId, Guid.Empty, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedProductService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRepositionMediaThrowsProductNotFoundExceptionIfProductDoesNotBelongToEvent()
    {
        var productId = Guid.Empty;
        var eventId = Guid.Empty;

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () =>
            await _sut.RepositionMedia(eventId, productId, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(productId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedProductService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRepositionMediaCallsProductServiceRepositionMediaAsync()
    {
        var productId = Guid.Empty;
        var eventId = Guid.NewGuid();
        var request = new RepositionMediaRequest
        {
            Positions = new[] { Guid.Empty }
        };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(productId, eventId)).ReturnsAsync(true);

        var actual = await _sut.RepositionMedia(eventId, productId, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(productId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.RepositionMediaAsync(productId, request.Positions), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedProductService.VerifyNoOtherCalls();
    }
}