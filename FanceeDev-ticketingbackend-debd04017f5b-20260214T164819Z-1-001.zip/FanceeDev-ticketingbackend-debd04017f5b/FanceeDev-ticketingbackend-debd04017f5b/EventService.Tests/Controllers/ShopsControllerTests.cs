﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Responses.Shops;
using EventService.Services.Shop;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using Claim = System.Security.Claims.Claim;

namespace EventService.Tests.Controllers;

public class ShopsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ShopsController _sut;
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();
    private readonly Mock<IShopService> _mockedShopService = new();

    public ShopsControllerTests()
    {
        _sut = new(_mockedOrganizationService.Object, _mockedShopService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatListThrowsEventNotFoundExceptionIfUserIsNotOwnerOfEvent()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.List(eventId));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatListReturnsListOfShopListItemResponse()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.ListAsync(ValidOrganizationId, eventId)).ReturnsAsync(new List<ShopListItemResponse>
        {
            new() { Code = "ShopCodeeventId", Name = "Shop Name eventId" }
        });

        var actual = await _sut.List(eventId);

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<ShopListItemResponse>>>(((OkObjectResult)actual.Result!).Value);

        var actualResponse = (ApiResponse<IEnumerable<ShopListItemResponse>>)((OkObjectResult)actual.Result).Value!;
        Assert.Equal("ShopCodeeventId", actualResponse!.Data.FirstOrDefault()?.Code);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedShopService.Verify(ss => ss.ListAsync(ValidOrganizationId, eventId), Times.Once);
    }
}