using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Responses.Product;
using EventService.Services.Product;
using TestCore.Mocks;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;

namespace EventService.Tests.Controllers;

public class ProductsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ProductsController _sut;
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    public ProductsControllerTests()
    {
        _sut = new(_mockedProductService.Object, _mockedOrganizationService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatEventProductSalesThrowsEventNotFoundExceptionOnInvalidOrganizationEventLink()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.EventProductSales(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatEventProductSalesCallsProductServiceEventProductSalesAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.EventProductSalesAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<ProductSalesResponse>());

        await _sut.EventProductSales(Guid.NewGuid());

        _mockedProductService.Verify(ps => ps.EventProductSalesAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatProductsShopInfoThrowsEventNotFoundExceptionOnInvalidOrganizationEventLink()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.EventProductsShopInfo(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatProductsShopInfoCallsProductServiceProductShopsAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.ProductShopsAsync(It.IsAny<Guid>(), ValidOrganizationId))
            .ReturnsAsync(new List<EventProductShopsResponse>());

        await _sut.EventProductsShopInfo(Guid.NewGuid());

        _mockedProductService.Verify(ps => ps.ProductShopsAsync(It.IsAny<Guid>(), ValidOrganizationId), Times.Once);
    }
}