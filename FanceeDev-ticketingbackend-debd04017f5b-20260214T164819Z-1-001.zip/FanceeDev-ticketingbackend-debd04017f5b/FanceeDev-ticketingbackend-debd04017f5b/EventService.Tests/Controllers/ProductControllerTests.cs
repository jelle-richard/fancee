﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Requests.Product.Item;
using EventService.Dtos.Responses.Product;
using EventService.Services.Product;
using EventService.Services.Product.Exceptions;
using EventService.Services.Shop;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using Claim = System.Security.Claims.Claim;

namespace EventService.Tests.Controllers;

public class ProductControllerTests
{
    private static readonly Guid[] MockedProductIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    public static readonly object[][] CircularWaveLinkTestData =
    {
        new object[] { new List<IdentifiedProductDto> { new() { Id = MockedProductIds[0], WaveLinkedProductId = MockedProductIds[0] } } },
        new object[] { new List<IdentifiedProductDto> { new() { Id = MockedProductIds[0], WaveLinkedProductId = MockedProductIds[1] }, new() { Id = MockedProductIds[1], WaveLinkedProductId = MockedProductIds[1] } } },
        new object[]
        {
            new List<IdentifiedProductDto>
            {
                new() { Id = MockedProductIds[0], WaveLinkedProductId = MockedProductIds[1] }, new() { Id = MockedProductIds[1], WaveLinkedProductId = MockedProductIds[2] },
                new() { Id = MockedProductIds[2], WaveLinkedProductId = MockedProductIds[1] }
            }
        },
        new object[]
        {
            new List<IdentifiedProductDto>
            {
                new() { Id = MockedProductIds[0], WaveLinkedProductId = MockedProductIds[1] }, new() { Id = MockedProductIds[1], WaveLinkedProductId = MockedProductIds[2] },
                new() { Id = MockedProductIds[2], WaveLinkedProductId = MockedProductIds[2] }
            }
        }
    };

    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ProductController _sut;
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();
    private readonly Mock<IShopService> _mockedShopService = new();

    public ProductControllerTests()
    {
        _sut = new(_mockedProductService.Object, _mockedOrganizationService.Object, _mockedShopService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatGetThrowsEventNotFoundExceptionWhenAuthenticatedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, Guid.NewGuid())).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Get(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatCreateThrowsEventNotFoundExceptionWhenAuthenticatedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, Guid.NewGuid())).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Create(Guid.NewGuid(), new()));
    }

    [Fact]
    public async Task TestThatUpdateThrowsEventNotFoundExceptionWhenAuthenticatedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, Guid.NewGuid())).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Update(Guid.NewGuid(), new List<IdentifiedProductDto>()));
    }

    [Fact]
    public async Task TestThatSingleUpdateThrowsEventNotFoundExceptionWhenAuthenticatedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, Guid.NewGuid())).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Update(Guid.NewGuid(), Guid.NewGuid(), new()));
    }

    [Fact]
    public async Task TestThatDeleteThrowsEventNotFoundExceptionWhenAuthenticatedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, Guid.NewGuid())).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Delete(Guid.NewGuid(), MockedProductIds[0]));
    }

    [Fact]
    public async Task TestThatGetCallsOrganizationService()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var actual = await _sut.Get(eventId);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;
        Assert.IsType<ApiResponse<IEnumerable<IdentifiedProductDto>>>(actualResult.Value);

        _mockedProductService.Verify(ps => ps.GetAllAsync(eventId, It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateCallsProductServiceInsertAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var model = new PostProductDto();
        var actual = await _sut.Create(eventId, model);

        Assert.NotNull(actual);
        Assert.IsType<CreatedAtActionResult>(actual.Result);

        var actualResult = (CreatedAtActionResult)actual.Result!;
        Assert.IsType<ApiResponse<CreateProductResponse>>(actualResult.Value);

        _mockedProductService.Verify(ps => ps.InsertAsync(model, eventId), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteThrowsProductNotFoundExceptionWhenAuthenticatedUserIsNotOwnerOfProduct()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(MockedProductIds[0], eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.Delete(eventId, MockedProductIds[0]));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(MockedProductIds[0], eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteCallsProductServiceDeleteAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(MockedProductIds[0], eventId)).ReturnsAsync(true);

        var actual = await _sut.Delete(eventId, MockedProductIds[0]);

        Assert.IsType<OkResult>(actual);
        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.BelongsToEvent(MockedProductIds[0], eventId), Times.Once);
        _mockedProductService.Verify(ps => ps.DeleteAsync(MockedProductIds[0]), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateThrowsProductNotFoundExceptionWhenNoProductsAreGiven()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.Update(eventId, new List<IdentifiedProductDto>()));
    }

    [Fact]
    public async Task TestThatSingleUpdateThrowsProductNotFoundExceptionWhenInvalidProductsIsGiven()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.Update(eventId, Guid.NewGuid(), new()));
    }

    [Fact]
    public async Task TestThatUpdateThrowsProductNotFoundExceptionWhenAuthenticatedUserIsNotOwnerOfProducts()
    {
        var eventId = Guid.NewGuid();

        var model = new IdentifiedProductDto
        {
            Id = MockedProductIds[0],
            Name = "UnitTicket"
        };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.Update(eventId, new[] { model }));
    }

    [Fact]
    public async Task TestThatSingleUpdateThrowsProductNotFoundExceptionWhenAuthenticatedUserIsNotOwnerOfProduct()
    {
        var eventId = Guid.NewGuid();

        var model = new IdentifiedProductDto
        {
            Id = MockedProductIds[0],
            Name = "UnitTicket"
        };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.Update(eventId, model.Id, model));
    }

    [Fact]
    public async Task TestThatUpdateCallsProductServiceUpdateAsync()
    {
        var eventId = Guid.NewGuid();

        var model = new List<IdentifiedProductDto>
        {
            new() { Id = MockedProductIds[0], Name = "UnitTicket" },
            new() { Id = MockedProductIds[2], Name = "UnitProduct" }
        };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);

        var actual = await _sut.Update(eventId, model);

        Assert.IsType<OkResult>(actual);
        _mockedProductService.Verify(ps => ps.UpdateAsync(model, It.IsAny<Guid>()));
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatSingleUpdateCallsProductServiceUpdateAsync()
    {
        var eventId = Guid.NewGuid();

        var model = new IdentifiedProductDto
        {
            Id = MockedProductIds[0],
            Name = "UnitTicket"
        };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);

        var actual = await _sut.Update(eventId, model.Id, model);

        Assert.IsType<ActionResult<ApiResponse<EmptyResponse>>>(actual);
        _mockedProductService.Verify(ps => ps.UpdateAsync(new[] { model }, It.IsAny<Guid>()));
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteThrowsProductInUseExceptionWhenProductHasSalesOrReservations()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(MockedProductIds[0], eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.HasSalesOrReservations(MockedProductIds[0])).ReturnsAsync(true);

        await Assert.ThrowsAsync<ProductInUseException>(async () => await _sut.Delete(eventId, MockedProductIds[0]));

        _mockedProductService.Verify(ps => ps.DeleteAsync(MockedProductIds[0]), Times.Never);
    }

    [Theory]
    [MemberData(nameof(CircularWaveLinkTestData))]
    public async Task TestThatUpdateThrowsCircularWaveLinkedProductsExceptionIfWaveLinkContainsCircularReference(IList<IdentifiedProductDto> request)
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.GetAllExcludingAsync(eventId, Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new List<IdentifiedProductDto>());

        await Assert.ThrowsAsync<CircularWaveLinkedProductsException>(async () => await _sut.Update(eventId, request));
    }

    [Fact]
    public async Task TestThatSingleUpdateThrowsCircularWaveLinkedProductsExceptionIfWaveLinkContainsCircularReference()
    {
        var eventId = Guid.NewGuid();
        var product = new IdentifiedProductDto { Id = MockedProductIds[0], WaveLinkedProductId = MockedProductIds[0] };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(It.IsAny<Guid>(), It.IsAny<Guid>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.GetAllExcludingAsync(eventId, ValidOrganizationId, It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync(new List<IdentifiedProductDto>
            {
                product
            });

        await Assert.ThrowsAsync<CircularWaveLinkedProductsException>(async () => await _sut.Update(eventId, product.Id, product));
    }

    [Fact]
    public async Task TestThatUpdateDoesNotThrowWaveLinkedProductsExceptionIfRequestDoesNotContainCircularWaveLink()
    {
        var eventId = Guid.NewGuid();

        var request = new List<IdentifiedProductDto>
        {
            new() { Id = MockedProductIds[0], WaveLinkedProductId = MockedProductIds[1] },
            new() { Id = MockedProductIds[1], WaveLinkedProductId = MockedProductIds[2] },
            new() { Id = MockedProductIds[2], WaveLinkedProductId = null }
        };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.GetAllExcludingAsync(eventId, ValidOrganizationId, new[] { MockedProductIds[0], MockedProductIds[1] })).ReturnsAsync(new List<IdentifiedProductDto>
        {
            new() { Id = MockedProductIds[2] }
        });

        var actual = await _sut.Update(eventId, request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSingleUpdateDoesNotThrowCircularWaveLinkedProductsExceptionIfWaveLinkDoesNotContainCircularReference()
    {
        var eventId = Guid.NewGuid();
        var product = new IdentifiedProductDto { Id = MockedProductIds[0] };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(It.IsAny<Guid>(), It.IsAny<Guid>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.GetAllExcludingAsync(eventId, Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new List<IdentifiedProductDto>());

        var actual = await _sut.Update(eventId, product.Id, product);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatCreateThrowsWaveLinkedProductNotFoundExceptionIfAuthenticatedUserIsNotOwnerOfWaveLinkedProduct()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.BelongsToEvent(MockedProductIds[0], Guid.NewGuid())).ReturnsAsync(false);

        await Assert.ThrowsAsync<WaveLinkedProductNotFoundException>(async () => await _sut.Create(eventId, new()
        {
            WaveLinkedProductId = MockedProductIds[2]
        }));
    }
}