using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Requests.Media;
using EventService.Dtos.Requests.Shop;
using EventService.Dtos.Responses.Shop;
using EventService.Services.Event;
using EventService.Services.Shop;
using EventService.Services.Shop.Exceptions;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.ShopElement;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Exceptions.Shop;
using WebApiCore.Services.Cache;
using WebApiCore.Services.Organization;
using WebApiCore.Services.Profanity;
using InvalidDateRangeException = WebApiCore.Exceptions.InvalidDateRangeException;

namespace EventService.Tests.Controllers;

public class ShopControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid[] MockedEventIds = { Guid.NewGuid(), Guid.NewGuid() };
    
    private readonly ShopController _sut;
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();
    private readonly Mock<IShopService> _mockedShopService = new();
    private readonly Mock<IEventService> _mockedEventService = new();
    private readonly Mock<IShopMailService> _mockedShopMailService = new();
    private readonly Mock<IShopQuestionService> _mockedShopQuestionService = new();
    private readonly Mock<IProfanityService> _mockedProfanityService = new();
    private readonly Mock<IShopCacheService> _mockedShopCacheService = new();

    public ShopControllerTests()
    {
        _sut = new(
            _mockedOrganizationService.Object,
            _mockedShopService.Object,
            _mockedEventService.Object,
            _mockedShopMailService.Object,
            _mockedShopQuestionService.Object,
            _mockedProfanityService.Object,
            _mockedShopCacheService.Object
        );

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatCreateThrowsEventNotFoundExceptionIfUserIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0])).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Create(MockedEventIds[0], new()));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0]), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateThrowsInvalidDateRangeExceptionIfDateRangesAreIncorrect()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0])).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(-5),
            EndDate = DateTime.UtcNow.AddMinutes(-2)
        });

        await Assert.ThrowsAsync<InvalidDateRangeException>(async () =>
            await _sut.Create(MockedEventIds[0], new()
            {
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddMinutes(-4)
            }));

        await Assert.ThrowsAsync<InvalidDateRangeException>(async () =>
            await _sut.Create(MockedEventIds[0], new()
            {
                StartDate = DateTime.UtcNow.AddMinutes(-4),
                EndDate = DateTime.UtcNow
            }));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0]), Times.Exactly(2));
        _mockedEventService.Verify(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId), Times.Exactly(2));
    }

    [Fact]
    public async Task TestThatCreateThrowsShopNameInUseExceptionWhenShopNameIsAlreadyInUse()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0])).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20)
        });
        _mockedShopService.Setup(ss => ss.UniqueNameForEventAsync("InUse", MockedEventIds[0])).ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNameInUseException>(async () => await _sut.Create(MockedEventIds[0], new()
        {
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow,
            Name = "InUse"
        }));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0]), Times.Once);
        _mockedEventService.Verify(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId), Times.Once);
        _mockedShopService.Verify(ss => ss.UniqueNameForEventAsync("InUse", MockedEventIds[0]), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateReturnsCreatedAtAction()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0])).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            MinAge = 18
        });
        _mockedShopService.Setup(ss => ss.UniqueNameForEventAsync("NotInUse", MockedEventIds[0])).ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.CreateAsync(It.IsAny<ConfigureShopRequest>(), MockedEventIds[0]))
            .ReturnsAsync("NewShopCode");
        _mockedProfanityService.Setup(ps => ps.FilterProfanityAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<string>());

        var actual = await _sut.Create(MockedEventIds[0], new()
        {
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow,
            Name = "NotInUse",
            ShopFields = new List<ShopFieldRequirementRequest>()
        });

        Assert.NotNull(actual);
        Assert.IsType<CreatedAtActionResult>(actual.Result);
        Assert.IsType<ApiResponse<string>>(((CreatedAtActionResult)actual.Result!).Value);

        var actualResponse = (ApiResponse<string>)((CreatedAtActionResult)actual.Result).Value!;
        Assert.Equal("NewShopCode", actualResponse!.Data);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, MockedEventIds[0]), Times.Once);
        _mockedEventService.Verify(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId), Times.Once);
        _mockedShopService.Verify(ss => ss.UniqueNameForEventAsync("NotInUse", MockedEventIds[0]), Times.Once);
    }

    [Fact]
    public async Task TestThatGetThrowsShopNotFoundExceptionIfUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "invalid", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.Get(MockedEventIds[0], "invalid"));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "invalid", MockedEventIds[0]),
            Times.Once);
    }

    [Fact]
    public async Task TestThatGetReturnsShop()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]))
            .ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.ByCodeAsync("valid")).ReturnsAsync(value: new()
        {
            Code = "valid",
            Name = "Valid shop"
        });

        var actual = await _sut.Get(MockedEventIds[0], "valid");

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<ShopResponse>>(((OkObjectResult)actual.Result!).Value);

        var actualResponse = (ApiResponse<ShopResponse>)((OkObjectResult)actual.Result).Value!;

        Assert.Equal("valid", actualResponse.Data.Code);
        Assert.Equal("Valid shop", actualResponse.Data.Name);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]), Times.Once);
        _mockedShopService.Verify(ss => ss.ByCodeAsync("valid"), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateThrowsShopNotFoundExceptionIfUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "invalid", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.Update(MockedEventIds[0], "invalid", new()));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "invalid", MockedEventIds[0]),
            Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateThrowsInvalidDateRangeExceptionIfDateRangeIsInvalid()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]))
            .ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(-5),
            EndDate = DateTime.UtcNow.AddMinutes(-2)
        });

        await Assert.ThrowsAsync<InvalidDateRangeException>(async () =>
            await _sut.Update(MockedEventIds[0], "valid", new()
            {
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddMinutes(-4)
            }));

        await Assert.ThrowsAsync<InvalidDateRangeException>(async () =>
            await _sut.Update(MockedEventIds[0], "valid", new()
            {
                StartDate = DateTime.UtcNow.AddMinutes(-4),
                EndDate = DateTime.UtcNow
            }));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]),
            Times.Exactly(2));
        _mockedEventService.Verify(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId), Times.Exactly(2));
    }

    [Fact]
    public async Task TestThatUpdateReturnsOkResult()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]))
            .ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20)
        });
        _mockedProfanityService.Setup(ps => ps.FilterProfanityAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<string>());

        var actual = await _sut.Update(MockedEventIds[0], "valid", new()
        {
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddMinutes(5)
        });

        Assert.NotNull(actual);
        Assert.IsType<OkResult>(actual);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]), Times.Once);
        _mockedEventService.Verify(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId), Times.Once);
        _mockedShopService.Verify(ss => ss.UpdateAsync(It.IsAny<ConfigureShopRequest>(), "valid", MockedEventIds[0]), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAddsBirthdateShopFieldIfEventHasMinAge()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]))
            .ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            MinAge = 42
        });
        _mockedProfanityService.Setup(ps => ps.FilterProfanityAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<string>());

        var actual = await _sut.Update(MockedEventIds[0], "valid", new()
        {
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddMinutes(5),
            ShopFields = new List<ShopFieldRequirementRequest>()
        });

        Assert.NotNull(actual);
        Assert.IsType<OkResult>(actual);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]), Times.Once);
        _mockedEventService.Verify(es => es.GetAsync(MockedEventIds[0], ValidOrganizationId), Times.Once);
        _mockedShopService.Verify(ss => ss.UpdateAsync(
            It.Is<ConfigureShopRequest>(csr =>
                csr.ShopFields.Any(sf => sf.Field == ShopField.Birthdate && sf.Required == true && sf.Enabled == true)
            ),
            "valid",
            MockedEventIds[0]
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteThrowsShopNotFoundExceptionIfUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "invalid", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.Delete(MockedEventIds[0], "invalid"));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "invalid", MockedEventIds[0]),
            Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteReturnsOkResult()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]))
            .ReturnsAsync(true);

        await _sut.Delete(MockedEventIds[0], "valid");

        _mockedOrganizationService.Verify(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "valid", MockedEventIds[0]), Times.Once);
        _mockedShopService.Verify(ss => ss.DeleteAsync("valid"), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignBackgroundMediaThrowsShopNotFoundExceptionIfAuthorizedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.AssignBackgroundMedia(MockedEventIds[1], "UnitShop", new()));
    }

    [Fact]
    public async Task TestThatAssignBackgroundMediaCallsShopService()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(true);
        _mockedShopService.Setup(ss =>
                ss.UploadBackgroundMediaAsync("UnitShop", It.IsAny<UploadBackgroundMediaRequest>()))
            .ReturnsAsync(new UploadedFile { Id = It.IsAny<Guid>(), Url = "http://localhost/uploads/test.png" });

        var actual = await _sut.AssignBackgroundMedia(MockedEventIds[1], "UnitShop", new());

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);

        var actualResponse = (CreatedResult)actual.Result!;

        Assert.Equal("http://localhost/uploads/test.png", actualResponse.Location);
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaThrowsShopNotFoundExceptionIfAuthenticatedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.DeleteBackgroundMedia(MockedEventIds[1], "UnitShop"));
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaCallsShopService()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(true);

        var actual = await _sut.DeleteBackgroundMedia(MockedEventIds[1], "UnitShop");

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResponse = (OkObjectResult)actual.Result!;
        Assert.IsType<ApiResponse<EmptyResponse>>(actualResponse.Value);

        _mockedShopService.Verify(ss => ss.DeleteBackgroundMediaAsync("UnitShop"), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignHeaderMediaThrowsShopNotFoundExceptionIfAuthorizedUserIsNotOwner()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.AssignHeaderMedia(MockedEventIds[1], "UnitShop", new()));
    }

    [Fact]
    public async Task TestThatAssignHeaderMediaCallsShopService()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.UploadHeaderMediaAsync("UnitShop", It.IsAny<UploadHeaderMediaRequest>()))
            .ReturnsAsync(new UploadedFile { Id = It.IsAny<Guid>(), Url = "http://localhost/uploads/test.png" });

        var actual = await _sut.AssignHeaderMedia(MockedEventIds[1], "UnitShop", new());

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);

        var actualResponse = (CreatedResult)actual.Result!;
        Assert.Equal("http://localhost/uploads/test.png", actualResponse.Location);

        _mockedShopService.Verify(ss => ss.UploadHeaderMediaAsync("UnitShop", It.IsAny<UploadHeaderMediaRequest>()),
            Times.Once);
    }

    [Fact]
    public async Task TestThatInheritHeaderMediaThrowsShopNotFoundExceptionIfUserIsNotOwnerOfShop()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.InheritHeaderMedia(Guid.NewGuid(), "BogusShopCode"));
    }

    [Fact]
    public async Task TestThatInheritHeaderMediaCallsShopServiceInheritHeaderMediaAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        await _sut.InheritHeaderMedia(Guid.NewGuid(), "ShopCode");

        _mockedShopService.Verify(ss => ss.InheritHeaderMediaAsync("ShopCode"));
    }

    [Fact]
    public async Task TestThatDeleteHeaderMediaThrowsShopNotFoundExceptionIsAuthorizedUserIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.DeleteHeaderMedia(MockedEventIds[1], "UnitShop", Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatDeleteHeaderMediaThrowsMediaNotFoundExceptionIfAuthorizedUserIsNotOwnerOfMedia()
    {
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.OwnerOfHeaderMediaAsync(fileId, "UnitShop", ValidOrganizationId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.DeleteHeaderMedia(MockedEventIds[1], "UnitShop", fileId));
    }

    [Fact]
    public async Task TestThatDeleteHeaderMediaCallsShopService()
    {
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.OwnerOfHeaderMediaAsync(fileId, "UnitShop", ValidOrganizationId)).ReturnsAsync(true);

        var actual = await _sut.DeleteHeaderMedia(MockedEventIds[1], "UnitShop", fileId);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResponse = (OkObjectResult)actual.Result!;
        Assert.IsType<ApiResponse<EmptyResponse>>(actualResponse.Value);

        _mockedShopService.Verify(ss => ss.DeleteHeaderMediaAsync("UnitShop", fileId), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignElementsReturnsValidationErrorIfInvalidRequestIsGiven()
    {
        var mockedValidator = new Mock<IObjectModelValidator>();
        mockedValidator.Setup(o => o.Validate(It.IsAny<ActionContext>(), It.IsAny<ValidationStateDictionary>(),
                It.IsAny<string>(), It.IsAny<object>()))
            .Callback((ActionContext context, ValidationStateDictionary _, string _, object _) => { context.ModelState.AddModelError("Kind", "Kind is missing"); });
        _sut.ObjectValidator = mockedValidator.Object;

        var request = new List<ShopElementDto>
        {
            new TextBlockElementDto { Text = "Hello, UnitTest!", Title = "Warning!" }
        };

        var actual = await _sut.AssignElements(MockedEventIds[1], "UnitShop", request);

        Assert.NotNull(actual);
        Assert.IsType<UnprocessableEntityObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatAssignElementsThrowsShopNotFoundExceptionIfAuthenticatedUserIsNotOwnerOfShop()
    {
        var mockedValidator = new Mock<IObjectModelValidator>();
        mockedValidator.Setup(o => o.Validate(It.IsAny<ActionContext>(), It.IsAny<ValidationStateDictionary>(),
            It.IsAny<string>(), It.IsAny<object>()));
        _sut.ObjectValidator = mockedValidator.Object;

        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(false);

        var request = new List<ShopElementDto>
        {
            new TextBlockElementDto { Kind = ElementKind.TextBlock, Text = "Hello, UnitTest!", Title = "Warning!" }
        };

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.AssignElements(MockedEventIds[1], "UnitShop", request));
    }

    [Fact]
    public async Task TestThatAssignElementsCallsShopService()
    {
        var mockedValidator = new Mock<IObjectModelValidator>();
        mockedValidator.Setup(o => o.Validate(It.IsAny<ActionContext>(), It.IsAny<ValidationStateDictionary>(),
            It.IsAny<string>(), It.IsAny<object>()));
        _sut.ObjectValidator = mockedValidator.Object;

        _mockedOrganizationService.Setup(ps => ps.OwnerOfShopAsync(ValidOrganizationId, "UnitShop", MockedEventIds[1]))
            .ReturnsAsync(true);

        var request = new List<ShopElementDto>
        {
            new TextBlockElementDto { Kind = ElementKind.TextBlock, Text = "Hello, UnitTest!", Title = "Warning!" }
        };

        var actual = await _sut.AssignElements(MockedEventIds[1], "UnitShop", request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedAtActionResult>(actual.Result);

        var actualResponse = (CreatedAtActionResult)actual.Result!;
        Assert.Equal("Get", actualResponse.ActionName);

        _mockedShopService.Verify(ss => ss.CreateElementAsync(request, "UnitShop", ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatUpdateShopMailThrowsShopNotFoundExceptionIfOrganizationIsNotOwnerOfShop()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.UpdateShopMail(MockedEventIds[0], "shop", new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedShopMailService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateShopMailCallsShopMailServiceUpdateMailAsync()
    {
        var request = new UpdateShopMailRequest
        {
            Content = "<h1>!</h1>",
            SenderName = "UnitTester",
            Type = UpdateShopMailRequest.MailType.Purchase
        };

        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        var actual = await _sut.UpdateShopMail(MockedEventIds[0], "shop", request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedShopMailService.Verify(sms => sms.AddOrUpdateAsync("shop", request), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateBackgroundMediaFocalPointThrowsShopNotFoundExceptionIfOwnerOfShopReturnsFalse()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.UpdateBackgroundMediaFocalPoint(MockedEventIds[0], "shop", new()));
    }

    [Fact]
    public async Task TestThatUpdateBackgroundMediaFocalPointCallsShopServiceUpdateBackgroundMediaFocalPointAsync()
    {
        var shopCode = "ShopCode123";
        var request = new FocalPointRequest
        {
            FocalPointHeightPercentage = 40,
            FocalPointWidthPercentage = 60
        };

        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, shopCode, MockedEventIds[0]))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.UpdateBackgroundMediaFocalPointAsync(shopCode, request));

        var actual = await _sut.UpdateBackgroundMediaFocalPoint(MockedEventIds[0], shopCode, request);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedShopService.Verify(ss => ss.UpdateBackgroundMediaFocalPointAsync(shopCode, request), Times.Once);
        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, shopCode, MockedEventIds[0]), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateHeaderMediaFocalPointThrowsShopNotFoundExceptionWhenOwnerOfShopAsyncReturnsFalse()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.UpdateHeaderMediaFocalPoint(MockedEventIds[0], "shop", Guid.NewGuid(),
                new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateHeaderMediaFocalPointThrowsMediaNotFoundExceptionForUnknownHeaderMedia()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.OwnerOfHeaderMediaAsync(It.IsAny<Guid>(), "shop", ValidOrganizationId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.UpdateHeaderMediaFocalPoint(MockedEventIds[0], "shop", Guid.NewGuid(),
                new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedShopService.Verify(ss => ss.OwnerOfHeaderMediaAsync(It.IsAny<Guid>(), "shop", ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateHeaderMediaFocalPointCallsShopServiceUpdateHeaderMediaFocalPointAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.OwnerOfHeaderMediaAsync(It.IsAny<Guid>(), "shop", ValidOrganizationId))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss =>
            ss.UpdateHeaderMediaFocalPointAsync("shop", It.IsAny<Guid>(), It.IsAny<FocalPointRequest>()));

        var actual =
            await _sut.UpdateHeaderMediaFocalPoint(MockedEventIds[0], "shop", Guid.NewGuid(), new());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedShopService.Verify(ss => ss.OwnerOfHeaderMediaAsync(It.IsAny<Guid>(), "shop", ValidOrganizationId), Times.Once);
        _mockedShopService.Verify(
            ss => ss.UpdateHeaderMediaFocalPointAsync("shop", It.IsAny<Guid>(), It.IsAny<FocalPointRequest>()),
            Times.Once);
    }

    [Fact]
    public async Task TestThatRepositionMediaThrowsShopNotFoundExceptionIfUserIsNotOwnerOfShop()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.RepositionMedia(MockedEventIds[0], "shop", new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedShopService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRepositionMediaCallsShopServiceRepositionHeaderMediaAsync()
    {
        var request = new RepositionMediaRequest
        {
            Positions = new[] { Guid.Empty }
        };

        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        var actual = await _sut.RepositionMedia(MockedEventIds[0], "shop", request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedShopService.Verify(ss => ss.RepositionHeaderMediaAsync("shop", request.Positions), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedShopService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatElementsThrowsShopNotFoundExceptionIfOrganizationIsNotOwnerOfShop()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.Elements(MockedEventIds[0], "shop"));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedShopService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatElementsCallsShopServiceElementsAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        var actual = await _sut.Elements(MockedEventIds[0], "shop");

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<ShopElementDto>>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedShopService.Verify(ss => ss.ElementsAsync("shop"), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedShopService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCreateShopQuestionsThrowsShopNotFoundExceptionIfOrganizationIsNotOwnerOfShop()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.CreateShopQuestions(MockedEventIds[0], "shop", new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedShopQuestionService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCreateShopQuestionsCallsShopQuestionServiceAddAsync()
    {
        var shopQuestionRequests = new List<ShopQuestionRequest>
        {
            new()
            {
                Required = false,
                Question = "Of je worst lust",
                Type = ShopQuestionType.YesNo
            }
        };

        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        var actual = await _sut.CreateShopQuestions(MockedEventIds[0], "shop", shopQuestionRequests);

        Assert.IsType<ActionResult<ApiResponse<EmptyResponse>>>(actual);

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedShopQuestionService.Verify(sqs => sqs.AddAsync(It.IsAny<string>(), shopQuestionRequests));
    }

    [Fact]
    public async Task TestThatDeleteShopQuestionThrowsShopNotFoundExceptionIfOrganizationIsNotOwnerOfShop()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.DeleteShopQuestion(MockedEventIds[0], "shop", Guid.NewGuid()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedShopQuestionService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteShopQuestionCallsShopQuestionServiceDeleteAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        await _sut.DeleteShopQuestion(MockedEventIds[0], "shop", Guid.NewGuid());

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();

        _mockedShopQuestionService.Verify(sqs => sqs.DeleteAsync(It.IsAny<Guid>()));
        _mockedShopQuestionService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateShopQuestionThrowsShopNotFoundExceptionIfOrganizationIsNotOwnerOfShop()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.UpdateShopQuestion(MockedEventIds[0], "shop", Guid.NewGuid(), new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedShopQuestionService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateShopQuestionCallsShopQuestionServiceUpdateAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]))
            .ReturnsAsync(true);

        await _sut.UpdateShopQuestion(MockedEventIds[0], "shop", Guid.NewGuid(), new());

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", MockedEventIds[0]), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();

        _mockedShopQuestionService.Verify(sqs => sqs.UpdateAsync("shop", It.IsAny<Guid>(), It.IsAny<ShopQuestionRequest>()), Times.Once);
        _mockedShopQuestionService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCreateCallsFilterProfanityAsync()
    {
        var request = new ConfigureShopRequest { Name = "valid", Tags = new[] { "Tag" } };
        var eventId = MockedEventIds[0];

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(eventId, ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(-5),
            EndDate = DateTime.UtcNow.AddMinutes(-2)
        });
        _mockedShopService.Setup(ss => ss.UniqueNameForEventAsync(request.Name, eventId)).ReturnsAsync(true);
        _mockedProfanityService.Setup(ps => ps.FilterProfanityAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<string>());

        await _sut.Create(eventId, request);

        _mockedProfanityService.Verify(ps => ps.FilterProfanityAsync(It.IsAny<IEnumerable<string>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateCallsFilterProfanityAsync()
    {
        var request = new ConfigureShopRequest { Name = "valid", Tags = new[] { "Tag" } };
        var eventId = MockedEventIds[0];

        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, request.Name, eventId)).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.GetAsync(eventId, ValidOrganizationId)).ReturnsAsync(value: new()
        {
            StartDate = DateTime.UtcNow.AddMinutes(-5),
            EndDate = DateTime.UtcNow.AddMinutes(-2)
        });
        _mockedShopService.Setup(ss => ss.ByCodeAsync(request.Name)).ReturnsAsync(value: new() { Tags = new[] { "Tag" } });
        _mockedProfanityService.Setup(ps => ps.FilterProfanityAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<string>());

        await _sut.Update(eventId, request.Name, request);

        _mockedProfanityService.Verify(ps => ps.FilterProfanityAsync(It.IsAny<IEnumerable<string>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateViewsCallsShopServiceUpdateViewsAsync()
    {
        var eventId = MockedEventIds[0];

        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", eventId)).ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.UpdateViewsAsync(1, "shop"));

        await _sut.UpdateViews(eventId, "shop");

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", eventId), Times.Once);
        _mockedShopService.Verify(ss => ss.UpdateViewsAsync(1, "shop"), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateViewsThrowsShopNotFoundExceptionIfOrganizationIsNotOwnerOfShop()
    {
        var eventId = MockedEventIds[0];

        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(ValidOrganizationId, "shop", eventId)).ReturnsAsync(true);
        _mockedShopService.Setup(ss => ss.UpdateViewsAsync(1, "shop"));

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.UpdateViews(eventId, "invalid"));
    }

    [Fact]
    public async Task TestThatUpdateSecureStateThrowsShopNotFoundExceptionIfNotOwner()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.UpdateSecureState(Guid.NewGuid(), "UnitShopCode", new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateSecureStateCallsShopServiceSetShopSecureState()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfShopAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.SetShopSecureStateAsync(It.IsAny<string>(), It.IsAny<ShopSecureStateRequest>()));

        var actual = await _sut.UpdateSecureState(Guid.NewGuid(), "UnitShopCode", new());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationService.Verify(os => os.OwnerOfShopAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<Guid>()), Times.Once);
        _mockedShopService.Verify(ss => ss.SetShopSecureStateAsync(It.IsAny<string>(), It.IsAny<ShopSecureStateRequest>()), Times.Once);
    }
}