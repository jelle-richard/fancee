﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Requests.Product;
using EventService.Dtos.Requests.Shop;
using EventService.Dtos.Responses.Event;
using EventService.Dtos.Responses.Events;
using EventService.Dtos.Responses.Product;
using EventService.Services.Event;
using EventService.Services.Product;
using EventService.Services.Shop;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Filters;
using WebApiCore.Services.Country;
using WebApiCore.Services.Logging;

namespace EventService.Tests.Controllers;

public class EventsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidAppTeamId = Guid.NewGuid();
    private static readonly Guid ValidAdminId = Guid.NewGuid();

    private static readonly PaginatedRequest<EventsBalanceMutationsRequestFilter> EventsBalanceMutationsRequestFilter = new()
    {
        PageSize = 10,
        Page = 1,
        Options = new()
        {
            SearchQuery = null,
            DateRange = It.IsAny<RangeFilter<DateTime>>(),
            CountryCodes = It.IsAny<List<string>>()
        }
    };

    private readonly EventsController _sut;
    private readonly Mock<IEventsService> _mockedEventsService = new();
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();
    private readonly Mock<IEventService> _mockedEventService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();
    private readonly Mock<IShopsService> _mockedShopsService = new();
    private readonly Mock<IProductsService> _mockedProductsService = new();

    private readonly PaginatedRequest<EventsRequestFilter> _request = new()
    {
        Page = 1,
        PageSize = 10,
        Options = new()
        {
            SearchQuery = string.Empty,
            DateRange = new(),
            EventStates = Array.Empty<EventStatus>()
        }
    };

    public EventsControllerTests()
    {
        _sut = new(_mockedEventsService.Object, _mockedProductService.Object, _mockedCountryService.Object, _mockedEventService.Object, _mockedUserLoggingService.Object, _mockedShopsService.Object, _mockedProductsService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatAppTeamListCallsEventServiceListAppTeamEventsAsync()
    {
        _sut.SetupHttpContext(appTeamId: ValidAppTeamId);

        _mockedEventsService.Setup(es => es.ListAppTeamEventsAsync(_request, ValidAppTeamId)).ReturnsAsync(
            new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 4,
                Items = new List<EventListItemResponse> { new() { Id = Guid.NewGuid() } }
            });

        var actual = await _sut.AppTeamList(_request);

        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatListReturnsResponse()
    {
        _mockedEventsService.Setup(es => es.ListEventsAsync(_request, ValidOrganizationId)).ReturnsAsync(
            new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 4,
                Items = new List<EventListItemResponse> { new() { Id = Guid.NewGuid() } }
            });

        var actual = await _sut.List(_request);

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<PaginatedResponse<EventListItemResponse>>>(actualResult.Value);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);

        var actualResponse = (ApiResponse<PaginatedResponse<EventListItemResponse>>)actualResult.Value!;

        Assert.Single(actualResponse.Data.Items);
        Assert.Equal(_request.Page, actualResponse.Data.Page);
        Assert.Equal(1, actualResponse.Data.Pages);
    }

    [Fact]
    public async Task TestThatAdminListForOrganizationReturnsResponse()
    {
        _sut.SetupHttpContext(UserType.Admin.ToString(), Guid.NewGuid());

        _mockedEventsService.Setup(es => es.ListEventsAsync(_request, ValidOrganizationId)).ReturnsAsync(
            new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 4,
                Items = new List<EventListItemResponse> { new() { Id = Guid.NewGuid() } }
            });

        var actual = await _sut.List(ValidOrganizationId, _request);

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<PaginatedResponse<EventListItemResponse>>>(actualResult.Value);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);

        var actualResponse = (ApiResponse<PaginatedResponse<EventListItemResponse>>)actualResult.Value!;

        Assert.Single(actualResponse.Data.Items);
        Assert.Equal(_request.Page, actualResponse.Data.Page);
        Assert.Equal(1, actualResponse.Data.Pages);
    }

    [Fact]
    public async Task TestThatAdminListForPlatformReturnsResponse()
    {
        _sut.SetupHttpContext(platformUserId: Guid.NewGuid(), userType: UserType.Admin.ToString());

        _mockedEventsService.Setup(es => es.ListEventsAsync(_request)).ReturnsAsync(
            new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 8,
                Items = new List<EventListItemResponse> { new() { Id = Guid.NewGuid() } }
            });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.ListAll(_request);

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<PaginatedResponse<EventListItemResponse>>>(actualResult.Value);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);

        var actualResponse = (ApiResponse<PaginatedResponse<EventListItemResponse>>)actualResult.Value!;

        Assert.Single(actualResponse.Data.Items);
        Assert.Equal(_request.Page, actualResponse.Data.Page);
        Assert.Equal(1, actualResponse.Data.Pages);

        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAgendaCallsEventsServiceEventsAgendaAsync()
    {
        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());

        _mockedEventsService.Setup(es => es.EventsAgendaAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<AgendaEventResponse>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Name = "Unit event"
                }
            });

        var actual = await _sut.Agenda(DateTime.UtcNow.AddDays(-20), DateTime.UtcNow);

        _mockedEventsService.Verify(es => es.EventsAgendaAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()), Times.Once);
        Assert.IsType<ActionResult<ApiResponse<IEnumerable<AgendaEventResponse>>>>(actual);
    }

    [Fact]
    public async Task TestThatGlobalStatisticsCallsEventServiceGlobalStatisticsAsync()
    {
        _mockedEventsService.Setup(es => es.GlobalStatisticsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new GlobalEventStatisticsResponse());

        var actual = await _sut.GlobalStatistics();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedEventsService.Verify(es => es.GlobalStatisticsAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGlobalPlatformStatisticsCallsEventsServiceGlobalPlatformStatisticsAsync()
    {
        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());

        _mockedEventsService.Setup(es => es.GlobalPlatformStatisticsAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new GlobalEventStatisticsResponse());

        var actual = await _sut.GlobalPlatformStatistics(DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedEventsService.Verify(es => es.GlobalPlatformStatisticsAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRevenuesCallsEventsServiceRevenuesAsync()
    {
        _mockedEventService.Setup(es => es.RevenuesAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new RevenueResponse());

        var actual = await _sut.Revenues();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedEventService.Verify(es => es.RevenuesAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpcomingProductsOfEventsCallsProductServiceUpcomingEventProductsAsync()
    {
        _mockedProductService.Setup(ps => ps.UpcomingEventProductsAsync(ValidOrganizationId))
            .ReturnsAsync(new List<EventProductsResponse>());

        var actual = await _sut.UpcomingProductsOfEvents();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedProductService.Verify(ps => ps.UpcomingEventProductsAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatExportOrganizationEventsAsCsvCallsEventsServiceOrganizationEventsAsCsvAsyncAndServesCsvFile()
    {
        var request = new EventsRequestFilter();
        _mockedEventsService.Setup(es => es.OrganizationEventsAsCsvAsync(ValidOrganizationId, request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportOrganizationEventsAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedEventsService.Verify(es => es.OrganizationEventsAsCsvAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminExportPlatformEventsAsCsvCallsEventsServicePlatformEventsAsCsvAsyncAndServesCsvFile()
    {
        _sut.SetupHttpContext(UserType.Admin.ToString(), ValidAdminId);

        var request = new EventsRequestFilter();
        _mockedEventsService.Setup(es => es.PlatformEventsAsCsvAsync(request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.AdminExportPlatformEventsAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedEventsService.Verify(es => es.PlatformEventsAsCsvAsync(request), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminExportOrganizationEventsAsCsvCallsEventsServiceOrganizationEventsAsCsvAsyncAndServesCsvFile()
    {
        _sut.SetupHttpContext(UserType.Admin.ToString(), ValidAdminId);

        var request = new EventsRequestFilter();
        _mockedEventsService.Setup(es => es.PlatformEventsAsCsvAsync(ValidOrganizationId, request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.AdminExportOrganizationEventsAsCsv(ValidOrganizationId, request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedEventsService.Verify(es => es.PlatformEventsAsCsvAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatBalanceEventsCallsBalanceEventsAsync()
    {
        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());

        _mockedEventsService.Setup(es => es.BalanceMutationsAsync(It.IsAny<PaginatedRequest<EventsBalanceMutationsRequestFilter>>()))
            .ReturnsAsync(new PaginatedResultSet<EventBalanceResponse>
            {
                TotalItems = 1,
                Items = new List<EventBalanceResponse>
                {
                    new()
                    {
                        EventId = Guid.NewGuid(),
                        EventName = "UnitTestEvent",
                        UserId = Guid.NewGuid(),
                        UserEmail = "unit@test.nl",
                        CountryCode = "NL",
                        TotalAmountOfIssuedTickets = 100,
                        TotalAmountOfScannedTickets = 0,
                        OrganizationCurrencyEventBalanceCentsReceivedResponse = new()
                        {
                            TotalAmountOfTicketFeeCentsReceived = 10000,
                            TotalAmountOfPaymentFeeCentsReceived = 0,
                            TotalAmountOfOrderTotalCostsCentsReceived = 0,
                            Currency = new()
                            {
                                ShortCode = "EUR",
                                Character = "€",
                                Name = "Euro",
                                Decimals = 2
                            }
                        },
                        PlatformCurrencyEventBalanceCentsReceivedResponse = new()
                        {
                            TotalAmountOfTicketFeeCentsReceived = 10000,
                            TotalAmountOfPaymentFeeCentsReceived = 0,
                            TotalAmountOfOrderTotalCostsCentsReceived = 0,
                            Currency = new()
                            {
                                ShortCode = "EUR",
                                Character = "€",
                                Name = "Euro",
                                Decimals = 2
                            }
                        }
                    }
                }
            });

        var actual = await _sut.BalanceMutations(EventsBalanceMutationsRequestFilter);

        _mockedEventsService.Verify(es => es.BalanceMutationsAsync(It.IsAny<PaginatedRequest<EventsBalanceMutationsRequestFilter>>()), Times.Once);
        Assert.IsType<ActionResult<ApiResponse<PaginatedResponse<EventBalanceResponse>>>>(actual);
    }

    [Fact]
    public async Task TestThatListSelectOptionsCallsEventServiceListSelectOptionsAsync()
    {
        var request = new SelectOptionsRequest<Guid>();

        _mockedEventsService.Setup(es => es.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<SelectOptionsRequest<Guid>>()))
            .ReturnsAsync([]);

        var actual = await _sut.ListSelectOptions(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(((OkObjectResult)actual.Result!).Value);

        _mockedEventsService.Verify(es => es.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<SelectOptionsRequest<Guid>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminListSelectOptionsCallsEventServiceListSelectOptionsAsync()
    {
        var request = new SelectOptionsRequest<Guid>();

        _mockedEventsService.Setup(es => es.ListSelectOptionsAsync(It.IsAny<SelectOptionsRequest<Guid>>()))
            .ReturnsAsync([]);

        var actual = await _sut.AdminListSelectOptions(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(((OkObjectResult)actual.Result!).Value);

        _mockedEventsService.Verify(es => es.ListSelectOptionsAsync(request), Times.Once);
    }

    [Fact]
    public async Task TestThatListShopSelectOptionsCallsShopsServiceListSelectOptionsAsync()
    {
        var request = new ShopSelectOptionsRequest();

        _mockedShopsService.Setup(es => es.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<ShopSelectOptionsRequest>()))
            .ReturnsAsync([]);

        var actual = await _sut.ListShopSelectOptions(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<SelectOptionResponse<string>>>>(((OkObjectResult)actual.Result!).Value);

        _mockedShopsService.Verify(es => es.ListSelectOptionsAsync(It.IsAny<Guid>(), request), Times.Once);
    }

    [Fact]
    public async Task TestThatListProductSelectOptionsCallsShopsServiceListSelectOptionsAsync()
    {
        var request = new ProductSelectOptionsRequest();

        _mockedProductsService.Setup(ps => ps.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<ProductSelectOptionsRequest>()))
            .ReturnsAsync([]);

        var actual = await _sut.ListProductSelectOptions(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(((OkObjectResult)actual.Result!).Value);

        _mockedProductsService.Verify(ps => ps.ListSelectOptionsAsync(It.IsAny<Guid>(), request), Times.Once);
    }
}