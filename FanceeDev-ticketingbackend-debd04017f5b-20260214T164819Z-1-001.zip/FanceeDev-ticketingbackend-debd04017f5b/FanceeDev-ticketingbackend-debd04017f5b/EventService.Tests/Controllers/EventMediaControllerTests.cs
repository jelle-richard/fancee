using System;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Requests.Event.Media;
using EventService.Dtos.Requests.Media;
using EventService.Services.Event;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;

namespace EventService.Tests.Controllers;

public class EventMediaControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly EventMediaController _sut;
    private readonly Mock<IEventService> _mockedEventService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    public EventMediaControllerTests()
    {
        _sut = new(_mockedOrganizationService.Object, _mockedEventService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatUploadMediaThrowsEventNotFoundExceptionIfAuthorizedUserIsNotOwnerOfEvent()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.UploadMedia(eventId, new()));
    }

    [Fact]
    public async Task TestThatUploadMediaReturnsUrlWithCreatedResource()
    {
        var eventId = Guid.NewGuid();

        var request = new UploadEventMediaRequest();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedEventService.Setup(ps => ps.UploadMediaAsync(eventId, request))
            .ReturnsAsync(new UploadedFile { Id = It.IsAny<Guid>(), Url = "http://localhost/uploads/test.png" });

        var actual = await _sut.UploadMedia(eventId, request);

        Assert.NotNull(actual);
        Assert.IsType<ActionResult<ApiResponse<Guid>>>(actual);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventService.Verify(es => es.UploadMediaAsync(eventId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteMediaThrowsEventNotFoundExceptionOnInvalidEvent()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.DeleteMedia(eventId, Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatDeleteMediaThrowsMediaNotFoundExceptionOnInvalidFile()
    {
        var eventId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.OwnerOfMediaAsync(ValidOrganizationId, fileId, eventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.DeleteMedia(eventId, fileId));
    }

    [Fact]
    public async Task TestThatDeleteMediaCallsDeleteMediaAsync()
    {
        var eventId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.OwnerOfMediaAsync(ValidOrganizationId, fileId, eventId)).ReturnsAsync(true);

        var actual = await _sut.DeleteMedia(eventId, fileId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedEventService.Verify(es => es.DeleteMediaAsync(eventId, fileId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointThrowsEventNotFoundExceptionWhenOwnerOfEventAsyncReturnsFalse()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.UpdateMediaFocalPoint(eventId, Guid.NewGuid(), new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointThrowsMediaNotFoundExceptionWhenOwnerOfMediaReturnsFalse()
    {
        var eventId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(true);

        _mockedEventService.Setup(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, eventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.UpdateMediaFocalPoint(eventId, fileId, new()));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventService.Verify(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointCallsEventServiceUpdateMediaFocalPointAsyncAndInvalidatesCaches()
    {
        var eventId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(true);

        _mockedEventService.Setup(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, eventId))
            .ReturnsAsync(true);

        _mockedEventService.Setup(ps =>
            ps.UpdateMediaFocalPointAsync(eventId, fileId, It.IsAny<FocalPointRequest>()));

        var actual = await _sut.UpdateMediaFocalPoint(eventId, fileId, new()
        {
            FocalPointHeightPercentage = 55,
            FocalPointWidthPercentage = 40
        });

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventService.Verify(ps => ps.OwnerOfMediaAsync(ValidOrganizationId, fileId, eventId), Times.Once);
        _mockedEventService.Verify(
            ps => ps.UpdateMediaFocalPointAsync(eventId, fileId, It.IsAny<FocalPointRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRepositionMediaThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        var eventId = Guid.Empty;

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () =>
            await _sut.RepositionMedia(eventId, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedEventService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRepositionMediaCallsEventServiceRepositionMediaAsync()
    {
        var eventId = Guid.Empty;
        var request = new RepositionMediaRequest
        {
            Positions = new[] { Guid.Empty }
        };

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var actual = await _sut.RepositionMedia(eventId, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventService.Verify(ps => ps.RepositionMediaAsync(eventId, request.Positions), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedEventService.VerifyNoOtherCalls();
    }
}