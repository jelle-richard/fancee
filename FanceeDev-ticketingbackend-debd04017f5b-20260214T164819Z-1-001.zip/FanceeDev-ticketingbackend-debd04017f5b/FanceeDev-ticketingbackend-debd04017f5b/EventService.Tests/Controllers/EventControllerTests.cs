using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Responses.Event;
using EventService.Dtos.Shared.Event;
using EventService.Services.Category;
using EventService.Services.Event;
using EventService.Services.Event.Status;
using EventService.Services.SeatsIo;
using EventService.Services.Shop;
using FanceeData.Models.Ticketing;
using Fs.SeatingUtils.Providers;
using JetBrains.Annotations;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.Dtos.Requests.Event;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.Event;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Country;
using WebApiCore.Services.CountryManager;
using WebApiCore.Services.Organization;
using WebApiCore.Services.Profanity;

namespace EventService.Tests.Controllers;

[TestSubject(typeof(EventController))]
public class EventControllerTests
{
    private const string UnitTimezone = "Europe/Amsterdam";
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly CopyEventRequest _copyEventRequest = new()
    {
        CopyCategories = true,
        CopyProducts = true,
        CopyShops = true,
        CopyTags = true,
        CopyPaymentMethods = true
    };

    private readonly Mock<ICategoryService> _mockedCategoryService;
    private readonly Mock<ICountryManagerService> _mockedCountryManagerService = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();
    private readonly Mock<IEventMailService> _mockedEventMailService = new();
    private readonly Mock<IEventService> _mockedEventService;
    private readonly Mock<IEventStatusService> _mockedEventStatusService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService;
    private readonly Mock<IShopService> _mockedShopService = new();
    private readonly Mock<IProfanityService> _mockedProfanityService = new();
    private readonly Mock<IEventCancellationService> _mockedEventCancellationService = new();
    private readonly Mock<ISeatsIoService> _mockedSeatsIoService = new();
    private readonly Mock<ISeatsIoProvider> _mockedSeatsIoProvider = new();

    private readonly EventController _sut;

    private readonly AssignPaymentMethodsRequestModel _validAssignPaymentMethodsRequestModel = new()
    {
        PaymentMethods = new PaymentMethodRequestModel[]
        {
            new() { Id = Guid.NewGuid(), PaidBy = PaidByDto.Client },
            new() { Id = Guid.NewGuid(), PaidBy = PaidByDto.Organization }
        }
    };

    public EventControllerTests()
    {
        _mockedEventService = new();
        _mockedOrganizationService = new();
        _mockedCategoryService = new();

        _mockedCategoryService.Setup(c => c.GetAllActiveSubCategories()).ReturnsAsync(new List<EventCategory>
        {
            new() { Name = "Pop" },
            new() { Name = "Metal" },
            new() { Name = "Dance" }
        });

        _sut = new(
            _mockedEventService.Object,
            _mockedOrganizationService.Object,
            _mockedCategoryService.Object,
            _mockedEventStatusService.Object,
            _mockedShopService.Object,
            _mockedCountryService.Object,
            _mockedEventMailService.Object,
            _mockedCountryManagerService.Object,
            _mockedProfanityService.Object,
            _mockedEventCancellationService.Object,
            _mockedSeatsIoService.Object,
            _mockedSeatsIoProvider.Object
        );

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatCreateEventCancellationReturns200Ok()
    {
        var request = new EventCancelRequest
        {
            Reason = "Unit test",
            PreferredRefundOption = EventCancellationRefundOption.FullRefund
        };

        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(true);

        var actual = await _sut.CreateEventCancellation(eventId, request);

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<EmptyResponse>>(actualResult.Value!);

        var actualResponse = (ApiResponse<EmptyResponse>)actualResult.Value!;

        Assert.NotNull(actualResponse);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);
        Assert.Null(actualResponse.Errors);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventCancellationService.Verify(ecs => ecs.CreateAsync(eventId, ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateEventCancellationReturns404NotFound()
    {
        var request = new EventCancelRequest
        {
            Reason = "Unit test",
            PreferredRefundOption = EventCancellationRefundOption.FullRefund
        };

        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(() => _sut.CreateEventCancellation(eventId, request));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventCancellationService.Verify(ecs => ecs.CreateAsync(eventId, ValidOrganizationId, request), Times.Never);
    }

    [Fact]
    public async Task TestThatCreateReturnsBadRequestOnInvalidCategory()
    {
        var request = new EventRequest
        {
            Categories = new[] { "poP", "METAL", "rap" }
        };

        var actual = await _sut.Create(request);

        Assert.IsType<BadRequestObjectResult>(actual.Result);

        var actualResult = (BadRequestObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<CreateEventResponse>>(actualResult.Value!);

        var actualResponse = (ApiResponse<CreateEventResponse>)actualResult.Value!;

        Assert.NotNull(actualResponse);
        Assert.Equal((int)HttpStatusCode.BadRequest, actualResult.StatusCode);
        Assert.NotEmpty(actualResponse.Errors);

        _mockedCategoryService.Verify(c => c.GetAllActiveSubCategories(), Times.Once);
        _mockedEventService.Verify(e => e.CreateAsync(It.IsAny<EventRequest>()), Times.Never);
    }

    [Fact]
    public async Task TestThatCreateReturnsBadRequestOnInvalidCountryCode()
    {
        _mockedCountryService.Setup(cs => cs.ValidAsync("INV")).ReturnsAsync(false);

        var request = new EventRequest
        {
            Categories = new[] { "Metal" },
            Address = new() { CountryCode = "INV" }
        };

        var actual = await _sut.Create(request);

        Assert.NotNull(actual);
        Assert.IsType<BadRequestObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<CreateEventResponse>>(((BadRequestObjectResult)actual.Result!).Value);

        var actualResponse = (ApiResponse<CreateEventResponse>)((BadRequestObjectResult)actual.Result!).Value!;

        Assert.NotEmpty(actualResponse.Errors);

        _mockedCountryService.Verify(cs => cs.ValidAsync("INV"), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateReturnsBadRequestOnInvalidSeatsIoEventId()
    {
        var seatsIoEventId = Guid.Empty;

        var request = new EventRequest
        {
            Type = EventType.Seating,
            SeatsIoEventId = seatsIoEventId,
            Categories = Array.Empty<string>()
        };

        _mockedSeatsIoProvider.Setup(sp => sp.ValidEventIdAsync(seatsIoEventId.ToString()))
            .ReturnsAsync(false);

        var actual = await _sut.Create(request);

        Assert.NotNull(actual);
        Assert.IsType<BadRequestObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<CreateEventResponse>>(((BadRequestObjectResult)actual.Result!).Value);

        var actualResponse = (ApiResponse<CreateEventResponse>)((BadRequestObjectResult)actual.Result!).Value!;

        Assert.NotEmpty(actualResponse.Errors);

        _mockedSeatsIoProvider.Verify(sp => sp.ValidEventIdAsync(It.IsAny<string>()), Times.Once);
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCreateCallsEventServiceCreate()
    {
        _mockedCountryService.Setup(cs => cs.ValidAsync("NL")).ReturnsAsync(true);
        _mockedProfanityService.Setup(ps => ps.ListProfanitiesInTextAsync(It.IsAny<string>()))
            .ReturnsAsync(new List<Profanity>());

        var request = new EventRequest
        {
            Categories = new[] { "Metal" },
            Tags = new[] { "TestTag1" },
            Name = "TestEvent",
            Description = "IdentifiedItemDto event for unittesting",
            StartDate = DateTime.Now.AddMinutes(5),
            TimezoneIdentification = UnitTimezone,
            Address = new() { CountryCode = "NL" }
        };

        var actual = await _sut.Create(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<CreateEventResponse>>(actualResult.Value!);

        var actualResponse = (ApiResponse<CreateEventResponse>)actualResult.Value!;

        Assert.NotNull(actualResponse);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);
        Assert.Null(actualResponse.Errors);

        _mockedCategoryService.Verify(c => c.GetAllActiveSubCategories(), Times.Once);
        _mockedEventService.Verify(e => e.CreateAsync(It.IsAny<EventRequest>()), Times.Once);
        _mockedCountryService.Verify(cs => cs.ValidAsync("NL"), Times.Once);
    }

    [Fact]
    public async Task TestThatGetCallsEventServiceGetAsync()
    {
        var eventId = Guid.NewGuid();

        var actual = await _sut.Get(eventId);

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EventResponse>>(((OkObjectResult)actual.Result!).Value);
        _mockedEventService.Verify(es => es.GetAsync(eventId, ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateReturnsBadRequestOnInvalidCategory()
    {
        var request = new UpdateEventRequest
        {
            Categories = new[] { "poP", "METAL", "rap" }
        };

        var actual = await _sut.Update(Guid.NewGuid(), request);

        Assert.IsType<BadRequestObjectResult>(actual.Result);

        var actualResult = (BadRequestObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<EmptyResponse>>(actualResult.Value);

        var actualResponse = (ApiResponse<EmptyResponse>)actualResult.Value!;

        Assert.NotNull(actualResponse);
        Assert.Equal((int)HttpStatusCode.BadRequest, actualResult.StatusCode);
        Assert.NotEmpty(actualResponse.Errors);

        _mockedCategoryService.Verify(c => c.GetAllActiveSubCategories(), Times.Once);
        _mockedEventService.Verify(e => e.UpdateAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<EventRequest>()), Times.Never);
    }

    [Fact]
    public async Task TestThatUpdateCallsEventServiceUpdate()
    {
        var request = new UpdateEventRequest
        {
            Categories = new[] { "Metal" },
            Name = "TestEvent",
            Description = "IdentifiedItemDto event for unittesting",
            TimezoneIdentification = UnitTimezone,
            StartDate = DateTime.Now.AddMinutes(5)
        };

        var eventId = Guid.NewGuid();

        var actual = await _sut.Update(eventId, request);

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;

        Assert.IsType<ApiResponse<EmptyResponse>>(actualResult.Value);

        var actualResponse = (ApiResponse<EmptyResponse>)actualResult.Value!;

        Assert.NotNull(actualResponse);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);
        Assert.Null(actualResponse.Errors);

        _mockedCategoryService.Verify(c => c.GetAllActiveSubCategories(), Times.Once);
        _mockedEventService.Verify(e => e.UpdateAsync(ValidOrganizationId, eventId, It.IsAny<EventRequest>()), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteEventOnNonExistingEventThrowsEventNotFoundException()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Delete(eventId));
    }

    [Fact]
    public async Task TestThatDeleteEventCallsEventServiceDeleteAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        var actual = await _sut.Delete(eventId);

        Assert.IsType<OkResult>(actual);
        _mockedEventService.Verify(es => es.DeleteAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatGetPaymentMethodsThrowsEventNotFoundExceptionOnInvalidEventId()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.GetPaymentMethods(eventId));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGetPaymentMethodsCallsEventServiceAvailablePaymentMethodsAsync()
    {
        var eventId = Guid.NewGuid();
        var paymentMethodId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);
        _mockedEventService.Setup(es => es.AvailablePaymentMethodsAsync(eventId)).ReturnsAsync(new List<AvailablePaymentMethodResponse>
        {
            new() { FeePercentage = 1, FeeStaticCents = 10, Id = paymentMethodId, PaidBy = PaidByDto.Client, Name = "IDeal", Provider = PaymentProviderDto.Adyen }
        });

        var actual = await _sut.GetPaymentMethods(eventId);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result!;
        Assert.IsType<ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>>(actualResult.Value);

        var actualResultResponse = (ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>)actualResult.Value!;
        Assert.Equal(paymentMethodId, actualResultResponse.Data.First().Id);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventService.Verify(es => es.AvailablePaymentMethodsAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignPaymentMethodsThrowsEventNotFoundExceptionOnInvalidEventId()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.AssignPaymentMethods(eventId, _validAssignPaymentMethodsRequestModel));

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedEventService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAssignPaymentMethodsCallsEventServiceAssignPaymentMethodsAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var actual = await _sut.AssignPaymentMethods(eventId, _validAssignPaymentMethodsRequestModel);

        Assert.NotNull(actual);
        Assert.IsType<OkResult>(actual);

        _mockedOrganizationService.Verify(ps => ps.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventService.Verify(es => es.AssignPaymentMethodsAsync(eventId, ValidOrganizationId, _validAssignPaymentMethodsRequestModel.PaymentMethods!), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatValidateEventThrowsEventNotFoundExceptionOnInvalidEventId()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.ValidateEvent(eventId));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedEventService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatValidateEventCallsEventServiceValidateAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var actual = await _sut.ValidateEvent(eventId);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EventValidationResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedEventService.Verify(es => es.ValidateAsync(eventId, ValidOrganizationId), Times.Once);
        _mockedEventService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatChangeEventStatusThrowsEventNotFoundExceptionOnInvalidEventId()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.ChangeEventStatus(eventId, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedEventService.VerifyNoOtherCalls();
        _mockedEventStatusService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatChangeEventStatusCallsEventStatusServiceChangeStatusAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var actual = await _sut.ChangeEventStatus(eventId, new() { Status = ChangeableEventStatus.Active });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedEventStatusService.Verify(ess => ess.ChangeStatusAsync(eventId, ValidOrganizationId, ChangeableEventStatus.Active), Times.Once);
        _mockedEventStatusService.VerifyNoOtherCalls();
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatCopyEventThrowsEventNotFoundExceptionOnInvalidUseR()
    {
        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.CopyEvent(new(), _copyEventRequest));
    }

    [Fact]
    public async Task TestThatCopyEventThrowsUserNotFoundExceptionOnInvalidUser()
    {
        _sut.SetupHttpContext(organizationId: Guid.Empty);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.CopyEvent(new(), _copyEventRequest));
    }

    [Fact]
    public async Task TestThatCopyEventCallsEventServiceCopyEventAsync()
    {
        var eventId = Guid.NewGuid();
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        _mockedEventService.Setup(es => es.CopyEventAsync(It.IsAny<Guid>(), _copyEventRequest))
            .ReturnsAsync(new Guid());

        var actual = await _sut.CopyEvent(eventId, _copyEventRequest);

        _mockedEventService.Verify(es => es.CopyEventAsync(It.IsAny<Guid>(), _copyEventRequest), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatStatisticsThrowsEventNotFoundExceptionOnUnknownEventToOrganizationLink()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Statistics(new()));
    }

    [Fact]
    public async Task TestThatStatisticsCallsEventServiceStatisticsAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        var actual = await _sut.Statistics(eventId);

        _mockedEventService.Verify(es => es.StatisticsAsync(eventId), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatRevenuesThrowsEventNotFoundExceptionOnUnknownEventToOrganizationLink()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Revenues(new()));
    }

    [Fact]
    public async Task TestThatRevenuesCallsEventServiceEventRevenuesAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), eventId))
            .ReturnsAsync(true);

        var actual = await _sut.Revenues(eventId);

        _mockedEventService.Verify(es => es.RevenuesAsync(eventId, It.IsAny<Guid>()), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatUpdateMailThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.UpdateMail(eventId, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventMailService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateMailCallsEventMailServiceAddOrUpdateAsync()
    {
        var eventId = Guid.NewGuid();
        var request = new UpdateEventMailRequest();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var actual = await _sut.UpdateMail(eventId, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventMailService.Verify(ems => ems.AddOrUpdateAsync(eventId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatMailThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.GetMail(eventId, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventMailService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGetMailCallsEventMailServiceEventMailAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId))
            .ReturnsAsync(true);

        _mockedEventMailService.Setup(ems => ems.EventMailAsync(eventId, It.IsAny<EventMailRequest>()))
            .ReturnsAsync(new EventMailResponse
            {
                Content = "Custom content",
                SenderName = "UnitTester",
                Type = MailType.DefaultShopMail
            });

        var actual = await _sut.GetMail(eventId, new()
        {
            Type = MailType.DefaultShopMail
        });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EventMailResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedEventMailService.Verify(ems => ems.EventMailAsync(eventId, It.IsAny<EventMailRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatReviewMailThrowsIfUserIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()));

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.Review(It.IsAny<Guid>()));
    }

    [Fact]
    public async Task TestThatReviewCallsEventMailServiceSendEventReviewMailAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        _mockedCountryManagerService.Setup(cms => cms.CountryManagerEmailsForOrganization(It.IsAny<Guid>())).ReturnsAsync(new List<MailAddress>());

        await _sut.Review(eventId);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
        _mockedCountryManagerService.Verify(cms => cms.CountryManagerEmailsForOrganization(It.IsAny<Guid>()), Times.Once);
        _mockedEventMailService.Verify(ems => ems.SendEventReviewMailAsync(eventId, ValidOrganizationId, It.IsAny<MailAddress>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateCallsListProfanitiesInTextAsync()
    {
        var profanity = new Profanity { Word = "test", Language = "nl" };
        var tags = new[] { "Tag", "Test" };

        _mockedProfanityService.Setup(ps => ps.ListProfanitiesInTextAsync(string.Join(' ', tags))).ReturnsAsync(new[] { profanity });

        await _sut.Create(new()
        {
            Categories = Array.Empty<string>(),
            Tags = tags
        });

        _mockedProfanityService.Verify(ps => ps.ListProfanitiesInTextAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateCallsListProfanitiesInTextAsync()
    {
        var profanity = new Profanity { Word = "test", Language = "nl" };
        var tags = new[] { "Tag", "Test" };
        var eventId = Guid.NewGuid();

        _mockedProfanityService.Setup(ps => ps.ListProfanitiesInTextAsync(string.Join(' ', tags))).ReturnsAsync(new[] { profanity });

        await _sut.Update(eventId, new()
        {
            Categories = Array.Empty<string>(),
            Tags = tags
        });

        _mockedProfanityService.Verify(ps => ps.ListProfanitiesInTextAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCountryStatisticsThrowsEventNotFoundExceptionIfUserIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()));

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.CountryStatistics(It.IsAny<Guid>()));
    }

    [Fact]
    public async Task TestThatCountryStatisticsCallsEventServiceCustomerCountryStatisticsAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        var actual = await _sut.CountryStatistics(eventId);

        _mockedEventService.Verify(es => es.CustomerCountryStatisticsAsync(eventId), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatCityStatisticsThrowsEventNotFoundExceptionIfUserIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()));

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.CityStatistics(It.IsAny<Guid>(), It.IsAny<string>()));
    }

    [Fact]
    public async Task TestThatCityStatisticsCallsEventServiceCustomerCityStatisticsAsync()
    {
        var eventId = Guid.NewGuid();
        var countryCode = "NL";

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        var actual = await _sut.CityStatistics(eventId, countryCode);

        _mockedEventService.Verify(es => es.CustomerCityStatisticsAsync(eventId, countryCode), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatValidateSeatsIoEventIdCallsSeatsIoProviderValidEventIdAsync()
    {
        var seatsIoEventId = Guid.Empty;

        _mockedSeatsIoProvider.Setup(sp => sp.ValidEventIdAsync(seatsIoEventId.ToString()))
            .ReturnsAsync(true);

        var actual = await _sut.ValidateSeatsIoEventId(seatsIoEventId);

        Assert.NotNull(actual);
        Assert.NotNull(actual.Result);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<bool>>(((OkObjectResult)actual.Result).Value);
        Assert.True(((ApiResponse<bool>)((OkObjectResult)actual.Result).Value!).Data);

        _mockedSeatsIoProvider.Verify(sp => sp.ValidEventIdAsync(seatsIoEventId.ToString()), Times.Once);
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncSeatsIoCategoriesCallsSeatsIoServiceSyncCategoriesAsync()
    {
        var eventId = Guid.NewGuid();

        var actual = await _sut.SyncSeatsIoCategories(eventId);

        Assert.NotNull(actual);
        Assert.NotNull(actual.Result);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedSeatsIoService.Verify(ss => ss.SyncCategoriesAsync(eventId, ValidOrganizationId), Times.Once);
        _mockedShopService.Verify(ss => ss.InvalidateShopCacheByEventIdAsync(eventId), Times.Once);
        _mockedSeatsIoService.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
        _mockedShopService.VerifyNoOtherCalls();
    }
}