using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Controllers;
using EventService.Dtos.Requests.Product.Media;
using EventService.Dtos.Shared.Ticket;
using EventService.Services.Product.Ticket;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using Claim = System.Security.Claims.Claim;

namespace EventService.Tests.Controllers;

public class TicketControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly TicketController _sut;
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();
    private readonly Mock<ITicketDesignService> _mockedTicketDesignService = new();

    public TicketControllerTests()
    {
        _sut = new(_mockedOrganizationService.Object, _mockedTicketDesignService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatTicketDesignThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.TicketDesign(Guid.Empty));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatTicketDesignCallsTicketDesignServiceGetAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(true);
        _mockedTicketDesignService.Setup(tds => tds.GetAsync(Guid.Empty)).ReturnsAsync(new TicketDesignDto[] { new() });

        var actual = await _sut.TicketDesign(Guid.Empty);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<TicketDesignDto>>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.GetAsync(Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateTicketDesignThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        var eventId = Guid.Empty;

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.AddOrUpdateTicketDesign(eventId, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateTicketDesignCallsTicketDesignServiceAddOrUpdateDesignAsync()
    {
        var eventId = Guid.Empty;
        var request = new TicketDesignDto();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId)).ReturnsAsync(true);

        var actual = await _sut.AddOrUpdateTicketDesign(eventId, request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, eventId), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.AddOrUpdateDesignAsync(ValidOrganizationId, eventId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatUploadMediaThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.UploadMedia(Guid.Empty, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUploadMediaCallsTicketDesignServiceUploadMediaAsync()
    {
        var request = new UploadTicketDesignMediaRequest
        {
            FocalPointHeightPercentage = 50,
            FocalPointWidthPercentage = 45,
            Media = null
        };

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(true);
        _mockedTicketDesignService.Setup(tds => tds.UploadMediaAsync(Guid.Empty, request)).ReturnsAsync(new UploadedFile
        {
            Id = Guid.Empty,
            Url = "https://unit.test/image.png"
        });

        var actual = await _sut.UploadMedia(Guid.Empty, request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<Guid>>(((CreatedResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.UploadMediaAsync(Guid.Empty, request), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteMediaThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.DeleteMedia(Guid.Empty, Guid.Empty));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteMediaThrowsMediaNotFoundExceptionIfMediaDoesNotBelongToEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(true);
        _mockedTicketDesignService.Setup(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () => await _sut.DeleteMedia(Guid.Empty, Guid.Empty));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteMediaCallsTicketDesignServiceDeleteMediaAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(true);
        _mockedTicketDesignService.Setup(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(true);

        var actual = await _sut.DeleteMedia(Guid.Empty, Guid.Empty);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.DeleteMediaAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointThrowsEventNotFoundExceptionIfOrganizationIsNotOwnerOfEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.UpdateMediaFocalPoint(Guid.Empty, Guid.Empty, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointThrowsMediaNotFoundExceptionIfMediaDoesNotBelongToEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(true);
        _mockedTicketDesignService.Setup(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () => await _sut.UpdateMediaFocalPoint(Guid.Empty, Guid.Empty, new()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointCallsTicketDesignServiceUpdateMediaFocalPointAsync()
    {
        var request = new FocalPointRequest();

        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(true);
        _mockedTicketDesignService.Setup(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(true);

        var actual = await _sut.UpdateMediaFocalPoint(Guid.Empty, Guid.Empty, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedTicketDesignService.Verify(tds => tds.UpdateMediaFocalPointAsync(Guid.Empty, Guid.Empty, request), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
        _mockedTicketDesignService.VerifyNoOtherCalls();
    }
}