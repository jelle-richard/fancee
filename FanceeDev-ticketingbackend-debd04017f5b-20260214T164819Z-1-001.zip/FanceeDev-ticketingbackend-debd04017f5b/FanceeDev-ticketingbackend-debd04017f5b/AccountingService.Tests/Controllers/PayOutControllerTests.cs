using System.Net.Mime;
using AccountingService.Controllers;
using AccountingService.Dtos.Requests.PayOut;
using AccountingService.Dtos.Responses.PayOut;
using AccountingService.Services.PayOut;
using FanceeData.Models.Ticketing.Invoicing;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;

namespace AccountingService.Tests.Controllers;

public class PayOutControllerTests
{
    private readonly PayOutController _sut;
    private readonly Mock<IPayOutService> _mockedPayOutService = new();

    public PayOutControllerTests()
    {
        _sut = new(_mockedPayOutService.Object);
    }

    [Fact]
    public async Task TestThatCreateExportCallsPayOutServiceCreateExportAsync()
    {
        var result = new CreatePayOutExportResponse
        {
            Id = Guid.NewGuid()
        };

        _mockedPayOutService.Setup(pos => pos.CreateExportAsync()).ReturnsAsync(result);

        var actual = await _sut.CreateExport();

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<CreatePayOutExportResponse>>(((CreatedResult)actual.Result!).Value);

        var actualValue = (ApiResponse<CreatePayOutExportResponse>)((CreatedResult)actual.Result!).Value!;

        Assert.Equal(result.Id, actualValue.Data.Id);

        _mockedPayOutService.Verify(pos => pos.CreateExportAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadExportCallsPayOutServiceDownloadFileAsync()
    {
        var exportId = Guid.NewGuid();
        var stream = new MemoryStream("file"u8.ToArray());

        _mockedPayOutService.Setup(pos => pos.DownloadFileAsync(exportId)).ReturnsAsync(stream);

        var actual = await _sut.DownloadExport(exportId);

        Assert.NotNull(actual);
        Assert.IsType<FileStreamResult>(actual);
        Assert.Equal(MediaTypeNames.Application.Zip, actual.ContentType);
        Assert.Equal("PayOut Export.zip", actual.FileDownloadName);
        Assert.Equal(stream, actual.FileStream);

        _mockedPayOutService.Verify(pos => pos.DownloadFileAsync(exportId), Times.Once);
    }

    [Fact]
    public async Task TestThatChangeStatusToProcessedCallsPayOutServiceChangeStatusAsync()
    {
        var actual = await _sut.ChangeStatusToProcessed(Guid.Empty);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedPayOutService.Verify(pos => pos.ChangeStatusAsync(Guid.Empty, PayOutExportStatus.Processed), Times.Once);
    }

    [Fact]
    public async Task TestThatExportListCallsPayOutServiceListAsync()
    {
        var request = new PaginatedRequest<PayOutExportFilter>
        {
            Page = 1,
            PageSize = 10,
            Options = new()
        };

        _mockedPayOutService.Setup(pos => pos.ListAsync(request)).ReturnsAsync(new PaginatedResultSet<PayOutExportItemResponse>
        {
            TotalItems = 1,
            Items = new PayOutExportItemResponse[] { new() }
        });

        var actual = await _sut.ExportList(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<PaginatedResponse<PayOutExportItemResponse>>>(((OkObjectResult)actual.Result!).Value);

        _mockedPayOutService.Verify(pos => pos.ListAsync(request), Times.Once);
    }

    [Fact]
    public async Task TestThatPendingPayoutsCallsPayOutServicePendingPayoutsAsync()
    {
        _mockedPayOutService.Setup(ps => ps.PendingPayoutsAsync())
            .ReturnsAsync(11);

        var actual = await _sut.PendingPayouts();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedPayOutService.Verify(ps => ps.PendingPayoutsAsync(), Times.Once);
    }
}