using AccountingService.Controllers;
using AccountingService.Dtos.Requests.Exact;
using AccountingService.Dtos.Responses.Exact;
using AccountingService.Services.Exact;
using AccountingService.Services.ItemMapping;
using AccountingService.Services.OAuth;
using AccountingUtils.Config;
using AccountingUtils.Providers.Accounting.Exact;
using AccountingUtils.Providers.Accounting.Exact.Responses;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Services.DeploymentEnvironment;
using ExactConfiguration = FanceeData.Models.Ticketing.Exact.ExactConfiguration;

namespace AccountingService.Tests.Controllers;

public class ExactControllerTests
{
    private readonly ExactController _sut;
    private readonly Mock<IExactProvider> _mockedExactProvider = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IOAuthProviderTokenService> _mockedOAuthProviderTokenService = new();
    private readonly Mock<IExactConfiguration> _mockedExactConfiguration = new();
    private readonly Mock<IItemMappingService> _mockedItemMappingService = new();
    private readonly Mock<IExactService> _mockedExactService = new();

    public ExactControllerTests()
    {
        _mockedExactConfiguration.Setup(ec => ec.OAuthRedirectDomain).Returns("https://redirect");

        _sut = new(
            _mockedExactProvider.Object,
            _mockedDeploymentEnvironmentService.Object,
            _mockedOAuthProviderTokenService.Object,
            _mockedExactConfiguration.Object,
            _mockedItemMappingService.Object,
            _mockedExactService.Object
        );
    }

    [Fact]
    public void TestThatAuthenticateReturnsRedirectUrl()
    {
        _mockedExactProvider.Setup(ep => ep.OAuthRedirectUrl(It.IsAny<string>()))
            .Returns("https://unit.test/exact");

        var actual = _sut.Authenticate();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<string>>(((OkObjectResult)actual.Result!).Value);

        var actualResult = (ApiResponse<string>)((OkObjectResult)actual.Result!).Value!;

        Assert.Equal("https://unit.test/exact", actualResult.Data);

        _mockedExactProvider.Verify(ep => ep.OAuthRedirectUrl("https://redirect/accounting/integrations/exact/token"), Times.Once);
    }

    [Fact]
    public async Task TestThatEnabledCallsOAuthProviderTokenServiceExistsAsync()
    {
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ExistsAsync(OAuthProvider.Exact, 30)).ReturnsAsync(true);

        var actual = await _sut.Enabled();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<bool>>(((OkObjectResult)actual.Result!).Value);

        var actualResult = (ApiResponse<bool>)((OkObjectResult)actual.Result!).Value!;

        Assert.True(actualResult.Data);

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ExistsAsync(OAuthProvider.Exact, 30), Times.Once);
    }

    [Fact]
    public async Task TestThatTokenThrowsInvalidOAuthCodeExceptionOnInvalidToken()
    {
        _mockedExactProvider.Setup(ep => ep.TokenAsync("invalid", It.IsAny<string>())).ThrowsAsync(new());

        await Assert.ThrowsAsync<InvalidOAuthCodeException>(async () => await _sut.Token("invalid"));

        _mockedExactProvider.Verify(ap => ap.TokenAsync("invalid", "https://redirect/accounting/integrations/exact/token"), Times.Once);
    }

    [Fact]
    public async Task TestThatTokenRedirectsToFrontendBaseUrl()
    {
        var tokenResponse = new TokenResponse { AccessToken = "access-token" };

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment { FrontendBaseUrl = "https://frontend" });
        _mockedExactProvider.Setup(ep => ep.TokenAsync("valid", It.IsAny<string>())).ReturnsAsync(tokenResponse);

        var actual = await _sut.Token("valid");

        Assert.IsType<RedirectResult>(actual);
        Assert.Equal("https://frontend/crm/integrations/exact", ((RedirectResult)actual).Url);

        _mockedExactProvider.Verify(ep => ep.TokenAsync("valid", "https://redirect/accounting/integrations/exact/token"), Times.Once);
        _mockedOAuthProviderTokenService.Verify(oapts => oapts.AddOrUpdateAsync(tokenResponse), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatItemsCallsExactProviderItemsAsync()
    {
        const int division = 123987;
        var items = new List<ItemResponse>
        {
            new() { Code = "test" }
        };

        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Token = "token", ValidUntil = DateTime.UtcNow.AddDays(1) });
        _mockedExactService.Setup(es => es.ConfigurationAsync())
            .ReturnsAsync(new ExactConfiguration { Division = division });
        _mockedExactProvider.Setup(es => es.ItemsAsync(division))
            .ReturnsAsync(items);

        var actual = await _sut.Items();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<MinimalItemResponse>>>(((OkObjectResult)actual.Result!).Value);

        var actualResult = (ApiResponse<IEnumerable<MinimalItemResponse>>)((OkObjectResult)actual.Result!).Value!;

        Assert.Single(actualResult.Data);
        Assert.Equal("test", actualResult.Data.First().Code);

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken("token"), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken("token"), Times.Once);
        _mockedExactService.Verify(es => es.ConfigurationAsync(), Times.Once);
        _mockedExactProvider.Verify(ep => ep.ItemsAsync(division), Times.Once);
    }

    [Fact]
    public async Task TestThatJournalsCallsExactProviderJournalsAsync()
    {
        const int division = 456654;
        var items = new JournalResponse[] { new() { Code = "t3stc0d3" } };

        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Token = "token", ValidUntil = DateTime.UtcNow.AddDays(1) });
        _mockedExactService.Setup(es => es.ConfigurationAsync())
            .ReturnsAsync(new ExactConfiguration { Division = division, Journal = "test-journal" });
        _mockedExactProvider.Setup(ep => ep.JournalsAsync(division))
            .ReturnsAsync(items);

        var actual = await _sut.Journals();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<MinimalJournalResponse>>>(((OkObjectResult)actual.Result!).Value);

        var actualResult = (ApiResponse<IEnumerable<MinimalJournalResponse>>)((OkObjectResult)actual.Result!).Value!;

        Assert.Single(actualResult.Data);
        Assert.Equal("t3stc0d3", actualResult.Data.First().Code);

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken("token"), Times.Once);
        _mockedExactService.Verify(es => es.ConfigurationAsync(), Times.Once);
        _mockedExactProvider.Verify(ep => ep.JournalsAsync(division), Times.Once);
    }

    [Fact]
    public async Task TestThatConfigureCallsExactServiceSetConfigurationAsync()
    {
        const int division = 978123;

        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Token = "token", ValidUntil = DateTime.UtcNow.AddDays(1) });
        _mockedExactProvider.Setup(ep => ep.CurrentDivisionAsync())
            .ReturnsAsync(division);

        var actual = await _sut.Configure(new() { Journal = "test-journal" });

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken("token"), Times.Once);
        _mockedExactProvider.Verify(ep => ep.CurrentDivisionAsync(), Times.Once);
        _mockedExactService.Verify(es => es.SetConfigurationAsync(division, "test-journal"), Times.Once);
    }

    [Fact]
    public async Task TestThatConfigureItemsCallsItemMappingServiceAddAsync()
    {
        var request = new ConfigureItemsRequest
        {
            Items = new ConfigureItemRequest[]
            {
                new()
                {
                    PlatformItem = "test",
                    CountryItems = new CountryItem[]
                    {
                        new() { CountryCode = CountryCode.NL, ExactItemCode = Guid.NewGuid() }
                    }
                }
            }
        };

        var actual = await _sut.ConfigureItems(request);

        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedItemMappingService.Verify(iis => iis.AddAsync(request.Items), Times.Once);
    }

    [Fact]
    public async Task TestThatConfigurationCallsExactServiceConfigurationAsyncAndItemMappingServiceMappingsAsync()
    {
        var exactItemCode = Guid.NewGuid();

        _mockedExactService.Setup(es => es.ConfigurationAsync()).ReturnsAsync(new ExactConfiguration { Journal = "TestJournal" });
        _mockedItemMappingService.Setup(ims => ims.MappingsAsync()).ReturnsAsync(new List<ConfiguredItemResponse>
        {
            new()
            {
                PlatformItem = "TestItem",
                CountryItems = new CountryItem[] { new() { ExactItemCode = exactItemCode, CountryCode = CountryCode.NL } }
            }
        });

        var actual = await _sut.Configuration();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<ConfigurationResponse>>(((OkObjectResult)actual.Result!).Value);

        var actualResponse = ((OkObjectResult)actual.Result!).Value as ApiResponse<ConfigurationResponse>;
        Assert.NotNull(actualResponse);
        Assert.Equal("TestJournal", actualResponse.Data.Journal);
        Assert.Equal("TestItem", actualResponse.Data.Items.First().PlatformItem);

        _mockedExactService.Verify(es => es.ConfigurationAsync(), Times.Once);
        _mockedItemMappingService.Verify(ims => ims.MappingsAsync(), Times.Once);
        _mockedExactService.VerifyNoOtherCalls();
        _mockedItemMappingService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatTokenAsyncRefreshesToken()
    {
        const int division = 978123;

        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Token = "token", ValidUntil = DateTime.UtcNow.AddSeconds(-45) });
        _mockedExactService.Setup(es => es.RefreshTokenAsync(It.IsAny<OAuthProviderToken>()))
            .ReturnsAsync("Refresh");
        _mockedExactProvider.Setup(ep => ep.CurrentDivisionAsync())
            .ReturnsAsync(division);

        var actual = await _sut.Configure(new() { Journal = "test-journal" });

        Assert.NotNull(actual);

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedExactService.Verify(es => es.RefreshTokenAsync(It.IsAny<OAuthProviderToken>()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken("Refresh"), Times.Once);
    }
}