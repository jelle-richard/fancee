using AccountingService.Controllers;
using JetBrains.Annotations;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Services.Country;

namespace AccountingService.Tests.Controllers;

[TestSubject(typeof(VatController))]
public class VatControllerTests
{
    private static readonly Dictionary<string, bool> CountryMap = new()
    {
        { "NL", true },
        { "AU", false }
    };

    private readonly VatController _sut;
    private readonly Mock<ICountryService> _mockedCountryService = new();

    public VatControllerTests()
    {
        _sut = new(_mockedCountryService.Object);
    }

    [Fact]
    public async Task TestThatVatCountriesCallsCountryServiceVatMapAsync()
    {
        _mockedCountryService.Setup(cs => cs.VatMapAsync())
            .ReturnsAsync(CountryMap);

        var actual = await _sut.VatCountries();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<Dictionary<string, bool>>>(((OkObjectResult)actual.Result!).Value);
        Assert.Equal(CountryMap, (((OkObjectResult)actual.Result).Value as ApiResponse<Dictionary<string, bool>>)?.Data);

        _mockedCountryService.Verify(cs => cs.VatMapAsync(), Times.Once);
        _mockedCountryService.VerifyNoOtherCalls();
    }
}