using AccountingService.Controllers;
using AccountingService.Services.Invoice;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;

namespace AccountingService.Tests.Controllers;

public class InvoiceControllerTests
{
    private readonly Mock<IInvoiceRowSpecificationService> _mockedInvoiceRowSpecificationService = new();
    private readonly InvoiceController _sut;

    public InvoiceControllerTests()
    {
        _sut = new(_mockedInvoiceRowSpecificationService.Object);
    }

    [Fact]
    public async Task TestThatInvoiceSpecificationNamesCallsInvoiceRowSpecificationServiceNamesAsync()
    {
        _mockedInvoiceRowSpecificationService.Setup(irss => irss.NamesAsync())
            .ReturnsAsync(new[] { "Name 1" });

        var actual = await _sut.InvoiceSpecificationNames();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<string>>>(((OkObjectResult)actual.Result!).Value);

        var actualResult = ((OkObjectResult)actual.Result!).Value as ApiResponse<IEnumerable<string>>;
        Assert.NotNull(actualResult);
        Assert.Single(actualResult.Data);
        Assert.Equal("Name 1", actualResult.Data.First());

        _mockedInvoiceRowSpecificationService.Verify(irss => irss.NamesAsync(), Times.Once);
    }
}