using System.Text;
using System.Text.Json;
using Fs.MessageBus.Models;
using Fs.MessageBus.Publishers;
using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;

namespace Fs.MessageBus.Tests.Publishers;

public class RabbitMessagePublisherTests
{
    private const string TestExchange = "UnitTestExchange";
    private const string TestRoutingKey = "UnitTestRoutingKey";
    private const string TestQueue = "UnitTestQueue";

    private readonly Mock<IModel> _mockedModel;
    private readonly Mock<IConnection> _mockedConnection;

    public RabbitMessagePublisherTests()
    {
        _mockedConnection = new();
        _mockedModel = new();

        _mockedConnection.Setup(c => c.CreateModel()).Returns(_mockedModel.Object);
    }

    [Fact]
    public void TestThatSetOptionsSetsTheCorrectOptionsByCloning()
    {
        var options = new RabbitOptions
        {
            Exchange = TestExchange,
            Arguments = new Dictionary<string, object>
            {
                { "arg1", "val1" },
                { "arg2", true }
            },
            ExchangeType = ExchangeType.Direct,
            QueueOptions = new() { Name = TestQueue }
        };

        var sut = new UnitTestPublisher(_mockedConnection.Object, options);

        Assert.NotSame(options, sut.Options);
        Assert.Equal(options.Exchange, sut.Options.Exchange);
        Assert.Equal(2, sut.Options.Arguments.Count);
        Assert.Equal(options.ExchangeType, sut.Options.ExchangeType);
        Assert.Equal(options.QueueOptions.Name, sut.Options.QueueOptions.Name);

        _mockedModel.Verify(m => m.ExchangeDeclare(TestExchange, ExchangeType.Direct, false, false, It.IsAny<Dictionary<string, object>>()));
    }

    [Fact]
    public void TestThatPublishPublishesTheGivenModel()
    {
        var mockedProperties = new Mock<IBasicProperties>();
        mockedProperties.SetupAllProperties();

        var message = new UnitTestMessage { Message = "Test!" };

        _mockedModel.Setup(m => m.CreateBasicProperties()).Returns(mockedProperties.Object);

        var sut = new UnitTestPublisher(_mockedConnection.Object, new()
        {
            AdditionalHeaders = new Dictionary<string, object> { { "header1", "value1" } },
            Exchange = TestExchange,
            RoutingKey = TestRoutingKey,
            QueueOptions = new() { Name = TestQueue }
        });

        sut.Publish(message);

        _mockedModel.Verify(m => m.CreateBasicProperties());
        _mockedModel.Verify(m => m.BasicPublish(TestExchange, TestRoutingKey, false, It.IsAny<IBasicProperties>(), It.IsAny<ReadOnlyMemory<byte>>()));
    }

    [Fact]
    public void TestThatCallReturnsResponseOfRpcCall()
    {
        var guid = Guid.NewGuid();

        var sut = new UnitTestPublisher(_mockedConnection.Object, new() { QueueOptions = new(), CorrelationId = guid });

        var mockedProperties = new Mock<IBasicProperties>();
        mockedProperties.SetupAllProperties();
        mockedProperties.Object.CorrelationId = guid.ToString();
        mockedProperties.Object.ReplyTo = "testqueue";

        _mockedModel.Setup(m => m.QueueDeclare("", false, true, true, It.IsAny<Dictionary<string, object>>())).Returns(new QueueDeclareOk("testqueue", 0, 0));
        _mockedModel.Setup(m => m.CreateBasicProperties()).Returns(mockedProperties.Object);

        sut.ConfigureRpc();
        sut.RpcQueue.Add("ok");

        var actual = sut.Call(new());

        Assert.Equal("ok", actual);
    }

    [Fact]
    public void TestThatCleanUpSetsConsumerToNull()
    {
        var sut = new UnitTestPublisher(_mockedConnection.Object, new()
        {
            QueueOptions = new(),
            ReplyTo = "me",
            CorrelationId = Guid.NewGuid()
        });

        sut.ConfigureRpc();

        Assert.NotNull(sut.Consumer);

        sut.Dispose();

        Assert.Null(sut.Consumer);
    }

    [Fact]
    public void TestThatCallWithIMessageReturnsCastMessage()
    {
        var guid = Guid.NewGuid();
        var message = new UnitTestMessage { Message = "Ping" };
        var reply = new UnitTestMessage { Message = "Pong" };

        var mockedProperties = new Mock<IBasicProperties>();
        mockedProperties.SetupAllProperties();
        mockedProperties.Object.CorrelationId = guid.ToString();
        mockedProperties.Object.ReplyTo = "testqueue";

        _mockedModel.Setup(m => m.QueueDeclare("", false, true, true, It.IsAny<Dictionary<string, object>>())).Returns(new QueueDeclareOk("testqueue", 0, 0));
        _mockedModel.Setup(m => m.CreateBasicProperties()).Returns(mockedProperties.Object);

        var sut = new UnitTestPublisher(_mockedConnection.Object, new()
        {
            QueueOptions = new(),
            CorrelationId = guid
        });

        sut.ConfigureRpc();
        sut.RpcQueue.Add(reply);

        var actual = sut.Call<UnitTestMessage>(message);

        Assert.NotNull(actual);
        Assert.Equal(reply.Message, actual.Message);
    }

    [Fact]
    public void TestThatHandleRpcMessageDoesNothingIfCorrelationIdDoesNotMatch()
    {
        var sut = new UnitTestPublisher(_mockedConnection.Object, new()
        {
            QueueOptions = new(),
            CorrelationId = Guid.NewGuid()
        });

        var mockedProperties = new Mock<IBasicProperties>();
        mockedProperties.Setup(p => p.CorrelationId).Returns(Guid.NewGuid().ToString);

        Assert.Empty(sut.RpcQueue);

        sut.HandleRpcMessage(null, new("", 1, false, "", "", mockedProperties.Object, Array.Empty<byte>()));

        Assert.Empty(sut.RpcQueue);
    }

    [Fact]
    public void TestThatHandleRpcMessageAddsResultToQueue()
    {
        var guid = Guid.NewGuid();

        var sut = new UnitTestPublisher(_mockedConnection.Object, new()
        {
            QueueOptions = new(),
            CorrelationId = guid
        });

        var mockedProperties = new Mock<IBasicProperties>();
        mockedProperties.Setup(p => p.CorrelationId).Returns(guid.ToString);

        Assert.Empty(sut.RpcQueue);

        sut.HandleRpcMessage(null, new("", 1, false, "", "", mockedProperties.Object, Encoding.UTF8.GetBytes("ok")));

        Assert.Single(sut.RpcQueue);
    }

    [Fact]
    public void TestThatHandleRpcMessageDecodesIMessage()
    {
        var guid = Guid.NewGuid();

        var sut = new UnitTestPublisher(_mockedConnection.Object, new()
        {
            QueueOptions = new(),
            CorrelationId = guid
        });

        var mockedProperties = new Mock<IBasicProperties>();
        mockedProperties.Setup(p => p.CorrelationId).Returns(guid.ToString);
        mockedProperties.Setup(p => p.Headers).Returns(new Dictionary<string, object>
        {
            { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes(typeof(UnitTestMessage).FullName!) }
        });

        var json = JsonSerializer.Serialize(new UnitTestMessage { Message = "ok" });

        Assert.Empty(sut.RpcQueue);

        sut.HandleRpcMessage(null, new("", 1, false, "", "", mockedProperties.Object, Encoding.UTF8.GetBytes(json)));

        Assert.Single(sut.RpcQueue);

        var obj = sut.RpcQueue.Take();

        Assert.IsType<UnitTestMessage>(obj);
        Assert.Equal("ok", ((UnitTestMessage)obj).Message);
    }

    #region Unit test classes

    public class UnitTestMessage : IMessage
    {
        public string? Message { get; set; }
    }

    public class UnitTestPublisher : RabbitMessagePublisher<UnitTestMessage>
    {
        public UnitTestPublisher(IConnection connection, RabbitOptions options) : base(connection, options)
        {
        }
    }

    #endregion
}