using System.Text;
using System.Text.Json;
using Fs.MessageBus.Models;
using Fs.MessageBus.Subscribers;
using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;

namespace Fs.MessageBus.Tests.Subscribers;

public class RabbitMessageSubscriberTests
{
    private const string UnitTestExchange = "UnitTestExchange";
    private const string UnitTestQueue = "UnitTestQueue";
    private const string UnitTestRoutingKey = "UnitTestRoutingKey";

    private readonly Mock<IModel> _mockedModel;
    private readonly RabbitMessageSubscriber<UnitTestModel> _sut;

    public RabbitMessageSubscriberTests()
    {
        _mockedModel = new();
        var mockedConnection = new Mock<IConnection>();
        mockedConnection.Setup(c => c.CreateModel()).Returns(_mockedModel.Object);

        _sut = new UnitTestSubscriber(mockedConnection.Object, UnitTestExchange, UnitTestQueue, UnitTestRoutingKey);
    }

    [Fact]
    public void TestThatBindConsumesTheRabbitConnection()
    {
        _sut.Bind(_ => Task.CompletedTask);

        Assert.NotNull(_sut.Callback);

        _mockedModel.Verify(m => m.BasicConsume(UnitTestQueue, true, string.Empty, false, false, null, It.IsAny<IBasicConsumer>()), Times.Once);
    }

    [Fact]
    public void TestThatBindBindsRpcCallback()
    {
        _sut.Bind(async _ =>
        {
            await Task.Delay(0);

            return new UnitTestModel();
        });

        Assert.NotNull(_sut.RpcCallback);

        _mockedModel.Verify(m => m.BasicConsume(UnitTestQueue, true, string.Empty, false, false, null, It.IsAny<IBasicConsumer>()), Times.Once);
    }

    [Fact]
    public void TestThatBindDoesNotBindTwice()
    {
        _sut.Bind(_ => Task.CompletedTask);
        _sut.Bind(async _ =>
        {
            await Task.Delay(0);

            return new UnitTestModel();
        });

        Assert.NotNull(_sut.Callback);
        Assert.NotNull(_sut.RpcCallback);

        _mockedModel.Verify(m => m.BasicConsume(UnitTestQueue, true, string.Empty, false, false, null, It.IsAny<IBasicConsumer>()), Times.Once);
    }

    [Fact]
    public void TestThatDisposeDisposesOfChannel()
    {
        _sut.Bind(_ => Task.CompletedTask);

        _sut.Dispose();

        Assert.Null(_sut.Callback);
        _mockedModel.Verify(m => m.Dispose(), Times.Once);
    }

    [Fact]
    public void TestThatDisposeDoesNotDisposeMultipleTimes()
    {
        _sut.Bind(_ => Task.CompletedTask);

        _sut.Dispose();
        _sut.Dispose();

        Assert.Null(_sut.Callback);
        _mockedModel.Verify(m => m.Dispose(), Times.Once);
    }

    [Fact]
    public void TestThatHandleMessageDoesNotReplyWhenNoCorrelationIdIsFound()
    {
        var callbackInvoked = false;

        _sut.Bind(_ =>
        {
            callbackInvoked = true;
            return Task.CompletedTask;
        });

        var model = new UnitTestModel();

        var mockedProps = new Mock<IBasicProperties>();
        mockedProps.SetupAllProperties();
        mockedProps.Object.Headers = new Dictionary<string, object> { { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes(model.GetType().FullName!) } };
        mockedProps.Object.CorrelationId = null;
        mockedProps.Object.ReplyTo = "replyTo";

        var bodyJson = JsonSerializer.Serialize(model);

        _sut.HandleMessageAsync(this, new("consumer", 1, false, "", "route", mockedProps.Object, Encoding.UTF8.GetBytes(bodyJson)));

        Assert.True(callbackInvoked);

        _mockedModel.Verify(m => m.BasicPublish(string.Empty, "replyTo", false, It.IsAny<IBasicProperties>(), It.IsAny<ReadOnlyMemory<byte>>()), Times.Never);
    }

    [Fact]
    public void TestThatHandleMessageDoesNotReplyWhenNoReplyToIsFound()
    {
        var callbackInvoked = false;

        _sut.Bind(_ =>
        {
            callbackInvoked = true;
            return Task.CompletedTask;
        });

        var model = new UnitTestModel();

        var mockedProps = new Mock<IBasicProperties>();
        mockedProps.SetupAllProperties();
        mockedProps.Object.Headers = new Dictionary<string, object> { { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes(model.GetType().FullName!) } };
        mockedProps.Object.CorrelationId = Guid.NewGuid().ToString();
        mockedProps.Object.ReplyTo = null;

        var bodyJson = JsonSerializer.Serialize(model);

        _sut.HandleMessageAsync(this, new("consumer", 1, false, "", "route", mockedProps.Object, Encoding.UTF8.GetBytes(bodyJson)));

        Assert.True(callbackInvoked);

        _mockedModel.Verify(m => m.BasicPublish(string.Empty, "replyTo", false, It.IsAny<IBasicProperties>(), It.IsAny<ReadOnlyMemory<byte>>()), Times.Never);
    }

    [Fact]
    public void TestThatHandleMessageRepliesIfCorrelationIdAndReplyToAreSet()
    {
        var callbackInvoked = false;

        _sut.Bind(_ =>
        {
            callbackInvoked = true;
            return Task.CompletedTask;
        });

        var model = new UnitTestModel();

        var mockedProps = new Mock<IBasicProperties>();
        mockedProps.SetupAllProperties();
        mockedProps.Object.Headers = new Dictionary<string, object> { { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes(model.GetType().FullName!) } };
        mockedProps.Object.CorrelationId = Guid.NewGuid().ToString();
        mockedProps.Object.ReplyTo = "replyTo";

        _mockedModel.Setup(m => m.CreateBasicProperties()).Returns(new Mock<IBasicProperties>().Object);

        var bodyJson = JsonSerializer.Serialize(model);

        _sut.HandleMessageAsync(this, new("consumer", 1, false, "", "route", mockedProps.Object, Encoding.UTF8.GetBytes(bodyJson)));

        Assert.True(callbackInvoked);

        _mockedModel.Verify(m => m.BasicPublish(string.Empty, "replyTo", false, It.IsAny<IBasicProperties>(), It.IsAny<ReadOnlyMemory<byte>>()), Times.Once);
        _mockedModel.Verify(m => m.BasicAck(1, false), Times.Once);
    }

    [Fact]
    public void TestThatHandleMessageIgnoresMessagesThatAreNotTheSameType()
    {
        var callbackInvoked = false;

        _sut.Bind(_ =>
        {
            callbackInvoked = true;
            return Task.CompletedTask;
        });

        var model = new RabbitMessageSubscriberTests();

        var mockedProps = new Mock<IBasicProperties>();
        mockedProps.SetupAllProperties();
        mockedProps.Object.Headers = new Dictionary<string, object> { { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes(model.GetType().FullName!) } };

        _mockedModel.Setup(m => m.CreateBasicProperties()).Returns(new Mock<IBasicProperties>().Object);

        var bodyJson = JsonSerializer.Serialize(model);

        _sut.HandleMessageAsync(this, new("consumer", 1, false, "", "route", mockedProps.Object, Encoding.UTF8.GetBytes(bodyJson)));

        Assert.False(callbackInvoked);

        _mockedModel.Verify(m => m.BasicPublish(string.Empty, "replyTo", false, It.IsAny<IBasicProperties>(), It.IsAny<ReadOnlyMemory<byte>>()), Times.Never);
    }

    [Fact]
    public void TestThatHandleMessageCallsRpcCallback()
    {
        var rpcCallbackResult = string.Empty;
        var model = new UnitTestModel { Message = "Test" };
        var reply = new UnitTestModel { Message = "Reply" };

        var mockedProps = new Mock<IBasicProperties>();
        mockedProps.SetupAllProperties();
        mockedProps.Object.Headers = new Dictionary<string, object> { { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes(model.GetType().FullName!) } };
        mockedProps.Object.CorrelationId = Guid.NewGuid().ToString();
        mockedProps.Object.ReplyTo = "replyTo";

        _mockedModel.Setup(m => m.CreateBasicProperties()).Returns(new Mock<IBasicProperties>().Object);

        var bodyJson = JsonSerializer.Serialize(model);

        _sut.Bind(async message =>
        {
            await Task.Delay(0);

            rpcCallbackResult = message?.Message;

            return reply;
        });

        _sut.HandleMessageAsync(this, new("consumer", 1, false, "", "route", mockedProps.Object, Encoding.UTF8.GetBytes(bodyJson)));

        Assert.Equal("Test", rpcCallbackResult);

        var expectedBytes = Encoding.UTF8.GetBytes(
            JsonSerializer.Serialize(reply, reply.GetType(), RabbitConfig.JsonOptions)
        );

        _mockedModel.Verify(m => m.BasicPublish(
                string.Empty,
                mockedProps.Object.ReplyTo,
                false,
                It.IsAny<IBasicProperties?>(),
                It.Is<ReadOnlyMemory<byte>>(b => b.ToArray().SequenceEqual(expectedBytes))
            ), Times.Once
        );
        _mockedModel.Verify(m => m.BasicAck(It.IsAny<ulong>(), false));
    }

    #region Unit test classes

    public class UnitTestModel : IMessage
    {
        public string? Message { get; set; }
    }

    public class UnitTestSubscriber : RabbitMessageSubscriber<UnitTestModel>
    {
        public UnitTestSubscriber(IConnection connection, string exchange, string queue, string routingKey) : base(connection, new()
        {
            Exchange = exchange,
            RoutingKey = routingKey,
            QueueOptions = new() { Name = queue },
            QosOptions = new() { Global = false, PrefetchCount = 0, PrefetchSize = 1 }
        })
        {
        }
    }

    #endregion
}