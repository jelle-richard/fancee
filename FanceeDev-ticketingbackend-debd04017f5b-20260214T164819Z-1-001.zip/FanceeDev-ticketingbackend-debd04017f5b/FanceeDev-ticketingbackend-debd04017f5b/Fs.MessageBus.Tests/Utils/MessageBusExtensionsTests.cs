using Fs.MessageBus.Models;
using Fs.MessageBus.Publishers;
using Fs.MessageBus.Subscribers;
using Fs.MessageBus.Utils;
using Microsoft.Extensions.DependencyInjection;
using RabbitMQ.Client;

namespace Fs.MessageBus.Tests.Utils;

public class MessageBusExtensionsTests
{
    [Fact]
    public void TestThatAddMessageBusRegistersIConnection()
    {
        var mockedServiceCollection = new Mock<IServiceCollection>();

        var actual = mockedServiceCollection.Object.AddMessageBus("connection-string");

        Assert.NotNull(actual);

        mockedServiceCollection.Verify(sc => sc.Add(
            It.Is<ServiceDescriptor>(sd => sd.ServiceType == typeof(IConnection) && sd.Lifetime == ServiceLifetime.Singleton)
        ), Times.Once);
    }

    [Fact]
    public void TestThatRegisterMessageRegistersMessage()
    {
        var mockedServiceCollection = new Mock<IServiceCollection>();

        mockedServiceCollection.Object.RegisterMessage<TestMessage, TestMessagePublisher, TestMessageSubscriber>();

        mockedServiceCollection.Verify(sc => sc.Add(
            It.Is<ServiceDescriptor>(sd =>
                sd.ServiceType == typeof(IMessagePublisher<TestMessage>) &&
                sd.ImplementationType == typeof(TestMessagePublisher) &&
                sd.Lifetime == ServiceLifetime.Singleton
            )
        ), Times.Once);

        mockedServiceCollection.Verify(sc => sc.Add(
            It.Is<ServiceDescriptor>(sd =>
                sd.ServiceType == typeof(IMessageSubscriber<TestMessage>) &&
                sd.ImplementationType == typeof(TestMessageSubscriber) &&
                sd.Lifetime == ServiceLifetime.Singleton
            )
        ), Times.Once);
    }

    #region Unit Test Classes

    // ReSharper disable once ClassNeverInstantiated.Local
    private class TestMessage : IMessage;

    // ReSharper disable once ClassNeverInstantiated.Local
    private class TestMessageSubscriber : RabbitMessageSubscriber<TestMessage>
    {
        protected TestMessageSubscriber(IConnection connection) : base(connection, new())
        {
        }
    }

    // ReSharper disable once ClassNeverInstantiated.Local
    private class TestMessagePublisher : RabbitMessagePublisher<TestMessage>
    {
        protected TestMessagePublisher(IConnection connection) : base(connection, new())
        {
        }
    }

    #endregion
}