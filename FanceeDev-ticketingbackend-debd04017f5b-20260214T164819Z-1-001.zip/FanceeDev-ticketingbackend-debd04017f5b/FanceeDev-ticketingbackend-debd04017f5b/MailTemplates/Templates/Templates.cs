﻿namespace MailTemplates.Templates;

public static class Templates
{
    public const string PasswordReset = "English/User/PasswordReset";
    public const string PasswordResetSubject = "Reset your %platformName% password";

    public const string NewInvoice = "English/Invoice/NewInvoice";
    public const string NewInvoiceSubject = "Your %platformName% invoice";

    public const string PayOutReceipt = "English/Receipt/PayOutReceipt";
    public const string PayOutReceiptSubject = "Your pay out recipt";

    public const string VerifyOrganization = "English/User/VerifyOrganization";
    public const string VerifyOrganizationSubject = "Verify your %platformName% account";

    public const string VerifyClient = "English/User/VerifyClient";
    public const string VerifyClientSubject = "Verify your %platformName% account";

    public const string CrmMessage = "English/Crm/CrmMessage";

    public const string ContractProposal = "English/User/Organization/ContractProposal";
    public const string ContractProposalSubject = "Your %platformName% contract proposal";
    public const string ContractProposalAlterationSubject = "Your %platformName% contract proposal has been updated";

    public const string ContractSigned = "English/User/Organization/ContractSigned";
    public const string ContractSignedSubject = "Copy of your signed %platformName% contract";

    public const string ContractAddendum = "English/User/Organization/ContractAddendum";
    public const string ContractAddendumSubject = "Copy of your %platformName% contract addendum";

    public const string ShopPurchase = "English/Shop/Purchase";
    public const string ShopPurchaseSubject = "Your tickets for %eventName%";

    public const string OrganizationNoteTagNotification = "English/Crm/OrganizationNoteTagNotification";
    public const string OrganizationNoteTagNotificationSubject = "A new organization note has been added or updated";

    public const string OrganizationUserAdded = "English/User/Organization/OrganizationUserAdded";
    public const string OrganizationUserAddedSubject = "You have been added to %organizationName%";

    public const string OrganizationUserRemoved = "English/User/Organization/OrganizationUserRemoved";
    public const string OrganizationUserRemovedSubject = "You have been removed from %organizationName%";

    public const string CreateAccountForFirstTimeTicketBuyer = "English/User/CreateClientAfterTicketSale";
    public const string CreateAccountForFirstTimeTicketBuyerSubject = "Create your %platformName% account";

    public const string CrmEventCancellationNotice = "English/Event/CrmCancellationNotice";
    public const string CrmEventCancellationNoticeSubject = "%organization% %country% cancelled of %event%";

    public const string ClientEventCancellationNotice = "English/Event/ClientCancellationNotice";
    public const string ClientEventCancellationNoticeSubject = "Important Notice: %event% cancelled";

    public const string SuperMetricsLostConnectionNotice = "English/Analytics/SuperMetricsLostConnectionNotice";
    public const string SuperMetricsLostConnectionNoticeSubject = "Failed authentication while retrieving data for %organizationName% in %platformName%";

    public const string SuperMetricsErrorInChannelNotice = "English/Analytics/SuperMetricsErrorInChannelNotice";
    public const string SuperMetricsErrorInChannelNoticeSubject = "An error occurred while retrieving data for %organizationName% in %platformName%";

    public const string IssuedRefund = "English/Order/IssuedRefund";
    public const string IssuedRefundSubject = "A refund has been issued";

    public const string InvalidateTicket = "English/Order/InvalidateTicket";
    public const string InvalidateTicketSubject = "One of your tickets has been revoked";

    public const string SealedTickets = "English/Shop/SealedTickets";
    public const string SealedTicketsSubject = "Your tickets for %eventName%";
}