﻿namespace MailTemplates.Models;

public abstract class MailModel
{
    public string Title { get; set; } = default!;
    public string PlatformName { get; set; } = default!;
    public string PlatformUrl { get; set; } = default!;
    public string PlatformLogoUrl { get; set; } = default!;
    public List<SocialMediaEntryInfo> Socials { get; set; } = new();
    public string SupportEmail { get; set; } = default!;

    public SocialMediaEntryInfo Facebook => Socials.First(s => s.Name == "Facebook");
    public SocialMediaEntryInfo Twitter => Socials.First(s => s.Name == "Twitter");
    public SocialMediaEntryInfo Instagram => Socials.First(s => s.Name == "Instagram");

    public class SocialMediaEntryInfo
    {
        public string Name { get; set; } = default!;
        public string Url { get; set; } = default!;
        public string LogoUrl { get; set; } = default!;
    }
}
