using System.Globalization;

namespace MailTemplates.Utils;

public static class DateTimeUtils
{
    private const string MonthNameFormat = "MMMM";

    /// <summary>
    /// Gets the localized month name of the <see cref="DateTime"/> instance.
    /// </summary>
    /// <param name="dateTime"></param>
    /// <param name="cultureName"></param>
    /// <returns></returns>
    public static string MonthName(this DateOnly dateTime, string cultureName) =>
        dateTime.ToString(MonthNameFormat, new CultureInfo(cultureName));
}