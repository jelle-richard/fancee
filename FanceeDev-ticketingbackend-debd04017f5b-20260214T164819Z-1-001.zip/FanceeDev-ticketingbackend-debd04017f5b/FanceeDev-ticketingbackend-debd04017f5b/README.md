# README

## TicketingBackend

This repository contains all the code for running the backend.

## 💡 Notes

1. It is important that you **<u>do not</u>** clone the repository in a folder that contains a `#` (e.g. a folder named `C#`) sign. This will cause the debugging of docker compose projects to fail.
2. While debugging in Rider is possible, it is very slow to start the docker containers. For this reason it is recommended that you use Visual Studio for debugging purposes.

## 🪵 Git usage

### Branches

The repository works via the following structure:

###### Main branch

Contains the latest stable release and is the exact code that is running on the live environment.

###### Develop branch

This branch contains the latest stable release marked for the next deployment and is the exact code that is running on the staging environment.

###### Feature branches

Any new feature should have it's own feature branch. Once complete, the feature branch should be merged to the develop branch and the feature branch should be deleted.

###### Bugfix branches

If a bug is found, it should be fixed within a bugfix branch. Once complete, the bugfix branch should be merged to the branch it originated from and the bugfix branch should be deleted.

### Commit messages

All commit messages should follow the following template: `<type>{(<jira-issue>)}: <subject>`
Parts between `{ }` are optional.

The following types are allowed:

| Type     | Description                                                                                                                                        |
|----------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| feat     | for when a new feature has been added                                                                                                              |
| fix      | for when a bugfix has been made                                                                                                                    |
| docs     | for when documentation has changed                                                                                                                 |
| style    | for when formatting has been changed (for example: missing semicolon, removed/added brackets etc. - no actual code functionality has been changed) |
| refactor | for when the changed code is a refactor of some kind                                                                                               |
| test     | for when adding (unit) tests                                                                                                                       |
| chore    | for all other type of commits                                                                                                                      |

## 🚀 Installation guide

### 🍎 macOS / 🐧 Linux

1. Install the latest version of Visual Studio (mac) ([download](https://visualstudio.microsoft.com/downloads/)) or Rider (mac and Linux - [download](https://www.jetbrains.com/toolbox-app/))
    1. When running on a ARM-based mac with Rider, you may need to install Rosetta after installing git (a popup when opening Rider will guide you through the installation).
2. Install docker desktop ([download](https://www.docker.com/get-started))
    1. If running on macOS make sure to add the following path to your Docker 'Settings' -> 'Resources' -> 'File Sharing' options: `/usr/local/share/dotnet/sdk/NuGetFallbackFolder`
    2. Uncheck 'Use Docker Compose V2' in the Docker Desktop 'General' settings
   3. On the command line, run: `docker login packages.fanc.ee -u db275888-4aca-4fbb-a23a-3e01c8cc190c` and provide the password that is stored in LastPass
3. Clone this repository (see [notes](#markdown-header-notes))
4. Create an `.env` file in the root of the project with the following content: `APPDATA=/Users/{USERNAME}` and replace `{USERNAME}` with your username
5. Run: `ln -s ~/.microsoft ~/Microsoft`
6. Run: `ln -s ~/.microsoft/usersecrets ~/Microsoft/UserSecrets`
7. Make sure the following entry exists in `/etc/hosts`: `127.0.0.1 host.docker.internal`
8. Make sure the user secrets are set up correctly (see [secrets](#markdown-header-secrets))
9. Make sure the database is up and running (see [running database locally](#markdown-header-running-database-locally))
10. Make sure you have configured the private NuGet Feed (see [configuring the feed](#markdown-header-configuring-the-feed))
11. Open the project in Visual Studio (`ticketingbackend.sln`)
12. Make sure the startup project is set to `docker-compose`
13. Run the project by pressing `F5` or the play button in the menu bar

### 🪟 Windows

1. Install the latest version of Visual Studio ([download](https://visualstudio.microsoft.com/downloads/)) or Rider ([download](https://www.jetbrains.com/toolbox-app/))
    1. For Visual Studio, select at least the following workloads:
        1. ASP.NET and web development
        2. Data storage and processing
        3. .NET cross-platform development
    2. For Visual Studio, select at least the following individual components:
        1. .NET 7.0 Runtime
2. Windows 10 (buildnumber >= 2004) / Windows 11
    1. Open the terminal
    2. Run `wsl --install -d Debian`
    3. Reboot the computer to finish the installation
3. Install docker desktop ([download](https://www.docker.com/get-started))
    1. Make sure to choose the WSL backend
    2. On the command line, run: `docker login packages.fanc.ee -u db275888-4aca-4fbb-a23a-3e01c8cc190c` and provide the password that is stored in LastPass
4. Clone this repository (see [notes](#markdown-header-notes))
5. Make sure the startup project is set to `docker-compose`
6. Make sure the user secrets are set up correctly (see [secrets](#markdown-header-secrets))
7. Make sure the database is up and running (see [running database locally](#markdown-header-running-database-locally))
8. Make sure you have configured the private NuGet Feed (see [configuring the feed](#markdown-header-configuring-the-feed))
9. Open the project in Visual Studio (`ticketingbackend.sln`)
10. Make sure the startup project is set to `docker-compose`
11. Run the project by pressing `F5` or the play button in the menu bar

### NuGet

#### Configuring the feed

This project uses NuGet packages from a private registry. To be able to build the project, you need to add the NuGet feed.
On the command line:

1. Add the NuGet feed using the dotnet command (replace `{PASS}` in the command with the password in LastPass):
    1. Windows: `dotnet nuget add source https://packages.fanc.ee/nuget/p/main/nuget/v3/index.json -n space-nuget -u db275888-4aca-4fbb-a23a-3e01c8cc190c -p {PASS}`
    2. macOS/Linux: `dotnet nuget add source https://packages.fanc.ee/nuget/p/main/nuget/v3/index.json -n space-nuget -u db275888-4aca-4fbb-a23a-3e01c8cc190c -p {PASS} --store-password-in-clear-text`

#### Creating and pushing packages

When creating a new package, you should set the following values in the `.csproj` file of the project:

| Property    | Value                   |
|-------------|-------------------------|
| ID          | Fs.{PROJECT_NAME}       |
| Version     | 0.1.0                   |
| Title       | {PROJECT_NAME}          |
| Authors     | WeAreFancee             |
| Description | A brief description     |
| Copyright   | WeAreFancee             |
| Project URL | https://wearefancee.com |

Visual Studio (Windows) and Rider have build-in tools to edit these values.

- Right click the project
- Click on `Properties`
    - Visual Studio: Click on `Package`
    - Rider: Click on `NuGet`

For both editors, make sure you check `Generate NuGet package on build`/`Generate a NuGet package during the build`

When updating a package, make sure you increment the version number.

To create a package, `cd` to the project folder and run the following commands:

- `dotnet build {PROJECT_NAME}.csproj --configuration Release`

To push a package, `cd` to the project folder and run `dotnet nuget push -s https://packages.fanc.ee/nuget/p/main/nuget/v3/index.json bin/Release/Fs.{PROJECT_NAME}.{VERSION}.nupkg`

Replace `{PROJECT_NAME}`, `{VERSION}` and `{API_KEY}` with your own values. The api key can be found in LastPass.

### Secrets

The project stores connection strings and other secrets (API keys etc.) in the `secret.json` files on your local machine.
These files are managed by Visual Studio (right click project -> Manage User Secrets) or via the `dotnet user-secrets` cli tool ([info](https://docs.microsoft.com/en-us/aspnet/core/security/app-secrets?view=aspnetcore-6.0&tabs=windows#how-the-secret-manager-tool-works)).  
In order to know which values to set in these files, a scaffold need to be available in the `appsettings.Development.json` files with empty values.
These values will be overridden with the secret values when the project is running.

#### Example

**appsettings.Development.json**

```json
{
  "ExternalApiSettings": {
    "Url": "example.com",
    "ApiKey": ""
  }
}
```

**secrets.json**

```json
{
  "ExternalApiSettings": {
    "ApiKey": "SecretValue"
  }
}
```

#### Sharing secrets

If you have the need of storing a secret that is the same for all development machines (e.g. API keys), please share them in the company LastPass vault.  
In LastPass, there is a template for adding a new secret (App Secret). Please add new secrets in the shared folder: `Shared-Fancee dev -> App Secrets`.  
Complicated secret objects (e.g. Adyen) can be added as a secure note.

#### Staging/ Production secrets

When you've added a new secret to the project, it should also be added to the staging and production environments. These values are stored on the target machine.
Loading of these files is handled by docker-compose. The location of these files are defined in the `docker-compose.override.{ENV}.yml` file.  
Please contact the system administrator to add new values.

### Running database locally

It is possible to run the database locally for development purposes.

Run the following commands and replace "{PWD}" (including { and }) with a password that has:

- Atleast 8 characters
- Uppercase letters
- Lowercase letters
- Digits (0-9)
- Symbols (!@#$%ˆ...)

#### Windows/Linux/macOS (Intel)

1. `docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD={PWD}" --name FanceeSqlServer -p "1433:1433" -d mcr.microsoft.com/mssql/server:2019-latest`

#### macOS (ARM)

1. `docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD={PWD}" --name FanceeSqlServer -p "1433:1433" -d mcr.microsoft.com/azure-sql-edge`

#### Restoring database

1. Download and install Azure Data Studio ([download](https://learn.microsoft.com/en-us/sql/azure-data-studio/download-azure-data-studio)) for your platform.
2. Install the following plugins (via the last icon in the menu bar on the left):
    - SQL Server Dacpac

If you have a backup file (*.bacpac) that you would like to use, follow the following steps:

1. In Azure Data Studio, click "Create a connection" on the "Welcome" screen
2. Fill the following:
    - Connection type: Microsoft SQL Server
    - Server: `127.0.0.1`
    - Authentication type: SQL Login
    - User name: `sa`
    - Password: Your password that you chose in [Running database locally](#markdown-header-running-database-locally)
    - Database: `<Default>`
    - Encrypt: `Mandatory (True)`
    - Trust server certificate: `True`
    - Server group: `<Default>`
3. Click 'Connect'
4. In the 'Connection list' on the left, expand the server and right click on 'Databases'
5. Click on 'Data-tier application wizard'
6. Select the `Create a database from a .bacpac file [Import Bacpac]` radio button and click 'Next'
7. Browse for the backup file and leave the 'Target Server' and 'Target Database' with their default values
8. Click 'Next' and wait for the import to complete

Repeat the steps above for any other database backup files you may have (e.g. FanceeUsers).

#### Setting up the database for first use

This repo requires access to two databases, FanceeData (TicketingContext) and FanceeUsers (FanceeUsersContext).

When the database server is running, you can run the MigrationRunner project to create and/or update the database instances.
Make sure the MigrationRunner project is set as the startup project and set the following environment variables in the run settings:

- `ConnectionStrings__FanceeData`
- `ConnectionStrings__FanceeUsers`

The connection string values can be found in one of the user secret files, or in LastPass.

How to set the environment variables depends on your IDE:

- Rider:
    1. Edit the run configuration for MigrationRunner
    2. Click the button in the input field for `Environment variables`
    3. Click the '+' icon to add a new *user system variable*
- Visual Studio (Windows):
    1. Right click the MigrationRunner project
    2. Click Properties
    3. Navigate to `Debug`
    4. Under the 'Environment variables' section, click the `Add` button
- Visual Studio (mac):
    1. Right click the MigrationRunner project
    2. Click Properties
    3. Navigate to `Run -> Configurations -> Default`
    4. Click `Add` to add the environment variables
    5. Make sure 'User-specific configuration' is checked

You are now able to run the MigrationRunner project.

## 🧪 Create test project

This repository contains a 'base project' for test projects (TestCore). TestCore contains the base references to xUnit and Moq(.EntityFrameworkCore).
When creating a new test project, you should include the reference to TestCore and remove all xUnit and coverlet references in your new project.
Other test references such as `Microsoft.NET.Test.SDK` and `coverlet.collector` are automatically included by the `Directory.Build.props` file
in the root of the project.

Creating a new project:

1. Create a new project with the xUnit template
2. Remove all packages in the `.csproj`
4. Add a reference to `TestCore`
5. Add a reference to the project you are testing

## 🏃 Run tests

This project contains unit tests to verify correctness of the code. These tests can be run in several ways depending on your configuration.

### Command line

Execute: `dotnet test .\ticketingbackend.sln`

### ReSharper

Press: `CTRL + T, L`
Menubar: `Extensions` > `ReSharper` > `Unit Tests` > `Run All Tests from Solution`

### Visual Studio 2022

Press: `CTRL + R, A`
Menubar: `Test` > `Run All Tests`

## 📚 Alter database

First, make sure you have the `dotnet-ef` tool installed. This can be done by executing the following command via your terminal:
`dotnet tool install --global dotnet-ef`

For the commands below, make sure your working directory is: `ticketingbackend\FanceeData`.
Also, make sure to add the connection string to the user secrets of the `FanceeData` project.

When changes have been made to the FanceeData database context a migration has to be made.
In order to make this migration execute the following command:
`dotnet ef migrations add NameOfChangeInCamelCase`

Once the migrations completed successfully you may update the database with the following command:
`dotnet ef database update`

## Use shared settings

When you want to use the sharedsettings(.Development).json file in a new project, make sure you add the following to the `.csproj` file (inside the <Project> block):

```xml
<ItemGroup>
    <Content Include="..\sharedsettings*.json" CopyToOutputDirectory="PreserveNewest" LinkBase=""/>
</ItemGroup>
```

Next, make sure the value of `UseSharedSettings` in your `Program.cs` when creating a new `Startup` object is set to `true` (default).

## 📝 Code style

### C# #

- Use `PascalCase` for:
    - File names
    - Class/interface/enum names
    - Method names
    - Enum members
    - Public properties
    - Readonly properties
    - Constants
- Use `_camelCase` for:
    - Private variables
- Use `camelCase` for:
    - Variables in methods
- Avoid using (unless actually needed):
    - `object` as type
    - `dynamic` as type
    - `go to` statements
- Prefer wrapper objects instead of returning `Tuple<T, T2>`
- Use a tab indent of 4 spaces
- Prefer LINQ methods over the QUERY-syntax (`from _myCollection select ... where ...`)
- Format code according to the ReSharper profile (CTRL + ALT + L)
- Classes should have the following structure:
    - Constants
    - Properties
    - Class variables
    - Constructor
    - Methods
- Members in classes should have the following access modifier order:
    - Public
    - Protected
    - Private
- Files should use file-scoped namespaces
- Avoid using boxed variants of primitive types:

| Boxed   | Primitive |
|---------|-----------|
| Int16   | short     |
| Int32   | int       |
| Int64   | long      |
| String  | string    |
| Boolean | bool      |
| Double  | double    |
| Decimal | decimal   |
| Char    | char      |

## 🏁 Definition of Done

- The deliverable should adhere to:
    - The deliverable adheres to all the requirements of the [code style](#markdown-header-code style)
    - The deliverable follows the git [branching structure](#markdown-header-branches)
    - The deliverable branch is up-to-date with it's orgin/parent branch
    - The deliverable should be production ready and not contain:
        - `Debugger.Break()` statements
        - Todo comments that should be resolved within the scope of the branch
        - Other development related comments that do not provide explanations
    - The deliverable should be linked to a Jira issue and only contain changes stated in the issue
    - The deliverable is buildable
    - The deliverable is provided as a BitBucket Pull Request
    - The deliverable passes the merge checks:
        - Pipeline runs successfully
        - SonarQube quality report passes:
            - Code coverage on new code: >= 80%
            - Quality reports should pass with an 'A'
            - Code duplication should be <= 2%
        - Code is approved by at least one other developer
        - All unittests succeed
    - The deliverable branch should be deleted after the pull request is merged
    - Code specific to the platform insights should exclude demo users
