#!/usr/bin/env bash
set -e

export CI_CD=true

# Function to join multiple strings with a seperator (e.g. ,)
# Usage (strings):  join_by {seperator} {str1} {str2} {str...}
# Usage (array):    join_by {seperator} "${array[@]}"
function join_by { local IFS="$1"; shift; echo "$*"; }

excluded_services=("CronService") # Exclude Swaggerless services to avoid .NET exceptions
services=()
inputs=()
title_line="  title: Fancee API" # Swagger title (top of page)

# Enumerate all microservices excluding 'excluded_services'
while IFS= read -r -d '' folder; do
  if [[ ! " ${excluded_services[@]} " =~ " $(basename "$folder") " ]]; then
    services+=("${folder#./}")
  fi
done < <(find . -type d -name '*Service' -print0)

# Fetch the swagger YAML 
for service in "${services[@]}"; do
  echo "info: Fetching Swagger YAML for '$service'..."
  
  swagger tofile --output "${service}.yaml" --yaml "./${service}/bin/Release/net8.0/${service}.dll" v1
  
  inputs+=("{\"inputFile\":\"./${service}.yaml\"}")
done

# Create a config file for the openapi-merge tool
inputs_str=$(join_by , "${inputs[@]}")
cat <<END >./openapi-merge.json
{
  "inputs": [${inputs_str}],
  "output": "./artifact/swagger.yaml"
}
END

mkdir ./artifact

echo "info: Merging Swagger YAML files..."
openapi-merge-cli --config ./openapi-merge.json

# Replace the document title with a new one
if [ "$(uname)" == "Darwin" ]; then
  sed -i '' "3s|.*|${title_line}|" artifact/swagger.yaml
else
  sed -i'' "3s|.*|${title_line}|" artifact/swagger.yaml
fi

echo "info: Finished."