﻿using Microsoft.Extensions.Logging;

namespace TestCore.Mocks;

public static class LoggerMockUtils
{
    public static Mock<ILogger<T>> VerifyCalled<T>(this Mock<ILogger<T>> logger, LogLevel logLevel, string? expectedMessage)
    {
        Func<object, Type, bool> state;

        if (expectedMessage == null)
            state = (_, _) => true;
        else
            state = (v, _) => string.Compare(v.ToString(), expectedMessage, StringComparison.Ordinal) == 0;

        logger.Verify(l => l.Log(
            It.Is<LogLevel>(ll => ll == logLevel), It.IsAny<EventId>(),
            It.Is<It.IsAnyType>((v, t) => state(v, t)), It.IsAny<Exception>(),
            It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)));

        return logger;
    }
}