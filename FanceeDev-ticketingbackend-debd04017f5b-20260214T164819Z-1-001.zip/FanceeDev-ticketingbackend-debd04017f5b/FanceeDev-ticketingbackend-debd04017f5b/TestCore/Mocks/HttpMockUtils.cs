using System.Linq.Expressions;
using Moq.Language.Flow;
using Moq.Protected;

namespace TestCore.Mocks;

public static class HttpMockUtils
{
    /// <summary>
    /// Creates a setup for the protected SendAsync method.
    /// </summary>
    /// <param name="mock"></param>
    /// <param name="requestExpression"></param>
    /// <returns></returns>
    public static ISetup<HttpMessageHandler, Task<HttpResponseMessage>> SetupSendAsync(this Mock<HttpMessageHandler> mock, Expression? requestExpression = null)
    {
        requestExpression ??= ItExpr.IsAny<HttpRequestMessage>();

        return mock.Protected().Setup<Task<HttpResponseMessage>>(
            "SendAsync",
            requestExpression,
            ItExpr.IsAny<CancellationToken>()
        );
    }

    public static ISetup<HttpMessageHandler, Task<HttpResponseMessage>> SetupSendAsync(this Mock<HttpMessageHandler> mock, string containsUri)
    {
        return mock.SetupSendAsync(
            ItExpr.Is<HttpRequestMessage>(hrm => hrm.RequestUri!.ToString().Contains(containsUri))
        );
    }

    /// <summary>
    /// Verifies that the protected SendAsync method has been called.
    /// </summary>
    /// <param name="mock"></param>
    /// <param name="times"></param>
    /// <param name="requestExpression"></param>
    public static void VerifySendAsync(this Mock<HttpMessageHandler> mock, Times times, Expression? requestExpression = null)
    {
        requestExpression ??= ItExpr.IsAny<HttpRequestMessage>();

        mock.Protected().Verify(
            "SendAsync",
            times,
            requestExpression,
            ItExpr.IsAny<CancellationToken>()
        );
    }

    /// <summary>
    /// Verifies that the protected SendAsync method has been called with the <see cref="containsUri" /> in the request URI.
    /// </summary>
    /// <param name="mock"></param>
    /// <param name="times"></param>
    /// <param name="containsUri"></param>
    public static void VerifySendAsync(this Mock<HttpMessageHandler> mock, Times times, string containsUri)
    {
        mock.VerifySendAsync(
            times,
            ItExpr.Is<HttpRequestMessage>(hrm => hrm.RequestUri!.ToString().Contains(containsUri))
        );
    }

    /// <summary>
    /// Verifies that the protected SendAsync method has been called with the <see cref="containsUri" /> in the request URI with
    /// the ability to include your own predicate.
    /// </summary>
    /// <param name="mock"></param>
    /// <param name="times"></param>
    /// <param name="containsUri"></param>
    public static void VerifySendAsync(this Mock<HttpMessageHandler> mock, Times times, string containsUri, Func<HttpRequestMessage, bool> predicate)
    {
        mock.VerifySendAsync(
            times,
            ItExpr.Is<HttpRequestMessage>(hrm => hrm.RequestUri!.ToString().Contains(containsUri) && predicate(hrm))
        );
    }
}