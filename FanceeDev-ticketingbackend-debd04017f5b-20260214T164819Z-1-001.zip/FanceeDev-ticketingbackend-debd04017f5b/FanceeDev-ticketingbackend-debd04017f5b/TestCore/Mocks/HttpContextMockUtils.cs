using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace TestCore.Mocks;

public static class HttpContextMockUtils
{
    /// <summary>
    /// Sets up a mock for the HttpContext in a Controller.
    /// </summary>
    /// <param name="controllerBase"></param>
    /// <param name="userType"></param>
    /// <param name="platformUserId"></param>
    /// <param name="organizationId"></param>
    /// <param name="fanceeUsersId"></param>
    /// <param name="appTeamId"></param>
    public static Mock<HttpContext> SetupHttpContext(
        this ControllerBase controllerBase,
        string? userType = null,
        Guid? platformUserId = null,
        Guid? organizationId = null,
        Guid? fanceeUsersId = null,
        Guid? appTeamId = null)
    {
        var mock = new Mock<HttpContext>();

        var claims = new List<Claim>();
        var headers = new HeaderDictionary();

        if (fanceeUsersId != null)
            claims.Add(new("user", ((Guid)fanceeUsersId).ToString()));

        if (platformUserId != null)
            claims.Add(new("platformUserId", ((Guid)platformUserId).ToString()));

        if (userType != null)
            claims.Add(new("type", userType));

        if (appTeamId != null)
        {
            claims.Add(new("team", ((Guid)appTeamId).ToString()));
            claims.Add(new("scheme", "appTeamScheme"));

            mock.Setup(hc => hc.User.HasClaim("scheme", "appTeamScheme")).Returns(true);
        }

        if (organizationId != null)
            headers.Add(new("X-Organization-Id", ((Guid)organizationId).ToString()));

        mock.Setup(hc => hc.User.Claims).Returns(claims);
        mock.Setup(hc => hc.Request.Headers).Returns(headers);

        controllerBase.ControllerContext = new(new(mock.Object, new(), new ControllerActionDescriptor()));

        return mock;
    }
}