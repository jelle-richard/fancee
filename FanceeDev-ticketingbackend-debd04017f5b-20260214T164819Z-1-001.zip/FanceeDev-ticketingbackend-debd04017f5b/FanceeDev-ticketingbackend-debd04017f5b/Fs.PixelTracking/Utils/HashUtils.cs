using System.Security.Cryptography;
using System.Text;

namespace Fs.PixelTracking.Utils;

internal static class HashUtils
{
    /// <summary>
    /// Hashes the <see cref="input" /> with SHA256 and returns it as a string.
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static string Sha256(string input)
    {
        var hashBuilder = new StringBuilder();

        foreach (var b in SHA256.HashData(Encoding.UTF8.GetBytes(input)))
            hashBuilder.Append(b.ToString("x2"));

        return hashBuilder.ToString();
    }
}