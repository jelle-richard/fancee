using Fs.PixelTracking.Configuration;
using Fs.PixelTracking.Models;

namespace Fs.PixelTracking;

public interface ITracker
{
    /// <summary>
    /// Sets the tracker specific configuration (e.g. API/access tokens and pixel ids).
    /// </summary>
    /// <param name="configuration"></param>
    /// <returns></returns>
    public ITracker SetConfiguration(ITrackerConfiguration configuration);

    /// <summary>
    /// Tracks a content view.
    /// </summary>
    /// <param name="information"></param>
    /// <returns></returns>
    public Task ViewContentAsync(TrackingInformation information);

    /// <summary>
    /// Tracks a change to the shopping cart.
    /// </summary>
    /// <param name="information"></param>
    /// <param name="items"></param>
    /// <returns></returns>
    public Task UpdateCartAsync(TrackingInformation information, IList<CartItem> items);

    /// <summary>
    /// Tracks a checkout (start order).
    /// </summary>
    /// <param name="information"></param>
    /// <param name="items"></param>
    /// <returns></returns>
    public Task CheckoutAsync(TrackingInformation information, IList<CartItem> items);

    /// <summary>
    /// Tracks the completion of a checkout (order complete).
    /// </summary>
    /// <param name="information"></param>
    /// <param name="items"></param>
    /// <returns></returns>
    public Task CompletePurchaseAsync(TrackingInformation information, IList<CartItem> items);
}