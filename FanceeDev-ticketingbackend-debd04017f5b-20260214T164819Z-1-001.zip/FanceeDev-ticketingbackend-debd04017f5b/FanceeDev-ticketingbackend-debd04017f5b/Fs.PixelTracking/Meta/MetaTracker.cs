using System.Text.Json;
using Fs.PixelTracking.Configuration;
using Fs.PixelTracking.Meta.Exceptions;
using Fs.PixelTracking.Meta.Models.Request;
using Fs.PixelTracking.Models;
using Microsoft.Extensions.Logging;

namespace Fs.PixelTracking.Meta;

public sealed class MetaTracker : IMetaTracker
{
    internal MetaConfiguration? Configuration { get; private set; }

    private readonly ILogger<MetaTracker> _logger;
    private readonly HttpClient _httpClient;

    public MetaTracker(ILogger<MetaTracker> logger, IHttpClientFactory httpClientFactory)
    {
        _logger = logger;
        _httpClient = httpClientFactory.CreateClient("Meta");
    }

    public ITracker SetConfiguration(ITrackerConfiguration configuration)
    {
        Configuration = configuration as MetaConfiguration;

        return this;
    }

    public async Task ViewContentAsync(TrackingInformation information) =>
        await BuildAndSendRequest(information, null, MetaEventName.ViewContent);

    public async Task UpdateCartAsync(TrackingInformation information, IList<CartItem> items) =>
        await BuildAndSendRequest(information, items, MetaEventName.AddToCart);

    public async Task CheckoutAsync(TrackingInformation information, IList<CartItem> items) =>
        await BuildAndSendRequest(information, items, MetaEventName.InitiateCheckout);

    public async Task CompletePurchaseAsync(TrackingInformation information, IList<CartItem> items) =>
        await BuildAndSendRequest(information, items, MetaEventName.Purchase);

    private async Task BuildAndSendRequest(TrackingInformation information, IList<CartItem>? items, MetaEventName eventName)
    {
        var request = GetEventRequestModel(information, items, eventName);

        await SendAndForgetAsync(request);
    }

    /// <summary>
    /// Returns a <see cref="EventRequestModel" /> based on the input for sending to the Meta API.
    /// </summary>
    /// <param name="information"></param>
    /// <param name="items"></param>
    /// <param name="eventName"></param>
    /// <returns></returns>
    private static EventRequestModel GetEventRequestModel(TrackingInformation information, IList<CartItem>? items, MetaEventName eventName) =>
        new()
        {
            EventName = eventName.ToString(),
            EventTime = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
            UserData = GetUserData(information),
            CustomData = items == null
                ? null
                : GetCustomData(information, items)
        };

    private static UserDataRequestModel GetUserData(TrackingInformation information) =>
        new()
        {
            ClientIpAddress = information.IpAddress.ToString(),
            ClientUserAgent = information.UserAgent,
            Email = information.Email
        };

    private static CustomDataRequestModel GetCustomData(TrackingInformation information, IList<CartItem> items) =>
        new()
        {
            Currency = information.Currency,
            Value = (float)items.Sum(ci => ci.Quantity * (ci.ItemPrice ?? 0m)),
            OrderId = information.OrderId,
            FanceeEventId = information.EventId.ToString(),
            FanceeShopCode = information.ShopCode,
            Contents = items.Select(ci => new ProductContentRequestModel
                {
                    ItemPrice = (float?)ci.ItemPrice,
                    Quantity = ci.Quantity,
                    ProductId = ci.ProductId.ToString()
                })
                .ToArray<CustomDataContent>()
        };

    /// <summary>
    /// Sends the request to Meta and forgets about it. We don't care about the result.
    /// </summary>
    /// <param name="requestBody"></param>
    private async Task SendAndForgetAsync(MetaRequest requestBody)
    {
        try
        {
            if (Configuration == null)
                throw new MissingMetaConfigurationException();

            var request = new HttpRequestMessage(HttpMethod.Post, $"/{Configuration.PixelId}/events");
            var content = new MultipartFormDataContent();

            content.Add(new StringContent(Configuration.AccessCode), "access_token");
            content.Add(new StringContent(JsonSerializer.Serialize(new[] { requestBody })), "data");

            request.Content = content;

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();
        }
        catch (Exception ex)
        {
            // We log and suppress any exceptions, as tracking is not a critical part of the flow.
            _logger.LogError(ex, "Meta conversion tracking request failed!");
        }
    }
}