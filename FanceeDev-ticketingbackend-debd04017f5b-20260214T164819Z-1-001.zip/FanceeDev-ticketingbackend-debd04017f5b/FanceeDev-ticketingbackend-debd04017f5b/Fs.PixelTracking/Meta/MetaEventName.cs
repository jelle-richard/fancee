namespace Fs.PixelTracking.Meta;

internal enum MetaEventName
{
    ViewContent,
    AddToCart,
    InitiateCheckout,
    Purchase
}