namespace Fs.PixelTracking.Meta;

public interface IMetaTracker : ITracker
{
}