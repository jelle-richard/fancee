namespace Fs.PixelTracking.Configuration;

public interface ITrackerConfiguration
{
}