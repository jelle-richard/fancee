namespace Fs.PixelTracking.Configuration;

public class MetaConfiguration : ITrackerConfiguration
{
    public required string PixelId { get; init; }
    public required string AccessCode { get; init; }
}