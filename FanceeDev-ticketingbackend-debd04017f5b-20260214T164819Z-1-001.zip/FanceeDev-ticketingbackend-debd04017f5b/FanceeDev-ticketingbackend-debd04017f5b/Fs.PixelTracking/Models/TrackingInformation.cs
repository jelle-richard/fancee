using System.Net;

namespace Fs.PixelTracking.Models;

public sealed class TrackingInformation
{
    public required IPAddress IpAddress { get; init; }
    public required string UserAgent { get; init; }
    public required Guid EventId { get; init; }
    public required string ShopCode { get; init; }
    public string? Email { get; init; }
    public string? OrderId { get; set; }
    public string? Currency { get; set; }
}