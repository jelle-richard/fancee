namespace Fs.PixelTracking.Models;

public sealed class CartItem
{
    public required Guid ProductId { get; init; }

    public required int Quantity { get; init; }

    /// <summary>
    /// Note: this should be in the local format, not cents. E.g. 5.36 EUR or 1200 YEN.
    /// </summary>
    public decimal? ItemPrice { get; init; }
}