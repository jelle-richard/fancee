using Fs.PixelTracking.Meta;
using Microsoft.Extensions.DependencyInjection;

namespace Fs.PixelTracking;

public static class PixelTrackingExtensions
{
    private const string MetaBaseUrl = "https://graph.facebook.com/v18.0";

    public static IServiceCollection AddPixelTracking(this IServiceCollection serviceCollection)
    {
        serviceCollection.AddScoped<ITracker, MetaTracker>();
        serviceCollection.AddScoped<IMetaTracker, MetaTracker>();
        serviceCollection.AddHttpClient("Meta", httpClient => { httpClient.BaseAddress = new(MetaBaseUrl); });

        return serviceCollection;
    }
}