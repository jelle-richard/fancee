using System.Runtime.CompilerServices;

// The two assembly lines below are for unit testing internal classes (project and Moq)
[assembly: InternalsVisibleTo("Fs.PixelTracking.Tests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]