using Fs.SeatingUtils.Services.SeatsIo;
using Microsoft.Extensions.Logging;
using SeatsioDotNet;
using SeatsioDotNet.EventReports;
using SeatsioDotNet.Events;
using SeatsioDotNet.Reports.Charts;

namespace Fs.SeatingUtils.Providers;

public class SeatsIoProvider : ISeatsIoProvider
{
    private static readonly string[] HandledEventErrorCodes = { "EVENT_NOT_FOUND" };

    private readonly ISeatsIoClient _client;
    private readonly ILogger<SeatsIoProvider> _logger;

    public SeatsIoProvider(ISeatsIoClient client, ILogger<SeatsIoProvider> logger)
    {
        _client = client;
        _logger = logger;
    }

    public async Task<bool> ValidEventIdAsync(string eventId)
    {
        return await Task.Run(() =>
        {
            try
            {
                return _client.Events.Retrieve(eventId) != null;
            }
            catch (SeatsioException ex)
            {
                LogSeatsIoError(ex);

                return false;
            }
        });
    }

    public async Task<Event?> EventAsync(string eventId)
    {
        return await Task.Run(() =>
        {
            try
            {
                return _client.Events.Retrieve(eventId);
            }
            catch (SeatsioException ex)
            {
                LogSeatsIoError(ex);

                return null;
            }
        });
    }

    public async Task<Dictionary<string, ChartReportSummaryItem>?> SummaryReportAsync(string chartKey)
    {
        return await Task.Run(() =>
        {
            try
            {
                return _client.ChartReports.SummaryByCategoryKey(chartKey, "chart");
            }
            catch (SeatsioException ex)
            {
                LogSeatsIoError(ex);

                return null;
            }
        });
    }

    public async Task<Dictionary<string, EventObjectInfo>?> ObjectInfosAsync(string eventId, string[] labels)
    {
        return await Task.Run(() =>
        {
            try
            {
                return _client.Events.RetrieveObjectInfos(eventId, labels);
            }
            catch (SeatsioException ex)
            {
                LogSeatsIoError(ex);

                return null;
            }
        });
    }

    public async Task<ChangeObjectStatusResult?> ReleaseObjectsAsync(string eventId, string[] labels)
    {
        return await Task.Run(() =>
        {
            try
            {
                return _client.Events.Release(eventId, labels);
            }
            catch (SeatsioException ex)
            {
                LogSeatsIoError(ex);

                return null;
            }
        });
    }

    public async Task BookObjectsAsync(string eventId, string[] labels)
    {
        await Task.Run(() =>
        {
            try
            {
                _client.Events.Book(eventId, labels);
            }
            catch (SeatsioException ex)
            {
                LogSeatsIoError(ex);
            }
        });
    }

    /// <summary>
    /// Logs unknown SeatsIO errors.
    /// </summary>
    /// <param name="exception"></param>
    private void LogSeatsIoError(SeatsioException exception)
    {
        if (exception.Errors == null || exception.Errors.All(e => !HandledEventErrorCodes.Contains(e.Code)))
            _logger.LogError(exception, "An unknown SeatsIO error occured");
    }
}