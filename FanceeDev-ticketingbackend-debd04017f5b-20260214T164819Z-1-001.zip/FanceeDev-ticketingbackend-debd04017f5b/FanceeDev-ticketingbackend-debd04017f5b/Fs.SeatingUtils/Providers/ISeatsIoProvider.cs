using SeatsioDotNet.EventReports;
using SeatsioDotNet.Events;
using SeatsioDotNet.Reports.Charts;

namespace Fs.SeatingUtils.Providers;

public interface ISeatsIoProvider
{
    /// <summary>
    /// Validates the given event id.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> ValidEventIdAsync(string eventId);

    /// <summary>
    /// Gets the event by id.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<Event?> EventAsync(string eventId);

    /// <summary>
    /// Gets the summary report by category key.
    /// </summary>
    /// <param name="chartKey"></param>
    /// <returns></returns>
    public Task<Dictionary<string, ChartReportSummaryItem>?> SummaryReportAsync(string chartKey);

    /// <summary>
    /// Gets the object info for the given labels.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="labels"></param>
    /// <returns></returns>
    public Task<Dictionary<string, EventObjectInfo>?> ObjectInfosAsync(string eventId, string[] labels);

    /// <summary>
    /// Releases the given objects.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="labels"></param>
    /// <returns></returns>
    public Task<ChangeObjectStatusResult?> ReleaseObjectsAsync(string eventId, string[] labels);

    /// <summary>
    /// Books seats for an event by their labels.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="labels"></param>
    /// <returns></returns>
    public Task BookObjectsAsync(string eventId, string[] labels);
}