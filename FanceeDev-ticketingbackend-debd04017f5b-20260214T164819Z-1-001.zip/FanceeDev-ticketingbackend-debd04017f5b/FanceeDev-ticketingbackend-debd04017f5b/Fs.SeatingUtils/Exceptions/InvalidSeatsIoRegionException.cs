namespace Fs.SeatingUtils.Exceptions;

public class InvalidSeatsIoRegionException()
    : Exception("Invalid SeatsIO region. Available options: eu, na, sa, oc");