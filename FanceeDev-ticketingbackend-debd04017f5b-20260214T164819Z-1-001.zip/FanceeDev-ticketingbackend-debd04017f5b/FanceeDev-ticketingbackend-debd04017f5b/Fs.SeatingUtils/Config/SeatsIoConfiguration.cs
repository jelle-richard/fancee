using Fs.SeatingUtils.Exceptions;
using SeatsioDotNet;

namespace Fs.SeatingUtils.Config;

public class SeatsIoConfiguration : ISeatsIoConfiguration
{
    public Region SeatsIoRegion => Region.ToLowerInvariant() switch
    {
        "eu" => SeatsioDotNet.Region.EU(),
        "na" => SeatsioDotNet.Region.NA(),
        "sa" => SeatsioDotNet.Region.SA(),
        "oc" => SeatsioDotNet.Region.OC(),
        var _ => throw new InvalidSeatsIoRegionException()
    };

    public required string Region { get; set; }
    public required string SecretKey { get; set; }
}