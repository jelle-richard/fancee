using SeatsioDotNet;

namespace Fs.SeatingUtils.Config;

public interface ISeatsIoConfiguration
{
    public string Region { get; set; }
    public string SecretKey { get; set; }
    public Region SeatsIoRegion { get; }
}