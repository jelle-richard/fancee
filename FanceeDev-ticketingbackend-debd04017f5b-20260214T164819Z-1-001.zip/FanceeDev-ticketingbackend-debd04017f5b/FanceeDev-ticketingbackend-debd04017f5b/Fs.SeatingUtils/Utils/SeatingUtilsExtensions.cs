using Fs.SeatingUtils.Config;
using Fs.SeatingUtils.Providers;
using Fs.SeatingUtils.Services.SeatsIo;
using Microsoft.Extensions.DependencyInjection;

namespace Fs.SeatingUtils.Utils;

public static class SeatingUtilsExtensions
{
    public static IServiceCollection AddSeatingUtils(this IServiceCollection serviceCollection, ISeatsIoConfiguration configuration) =>
        serviceCollection.AddScoped<ISeatsIoProvider, SeatsIoProvider>()
            .AddScoped<ISeatsIoClient, SeatsIoClient>()
            .AddSingleton(configuration);
}