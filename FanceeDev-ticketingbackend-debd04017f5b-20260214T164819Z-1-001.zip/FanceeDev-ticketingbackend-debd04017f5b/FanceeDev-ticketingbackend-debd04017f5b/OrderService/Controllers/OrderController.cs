﻿using System.Net.Mime;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OrderService.Dtos.Requests.Order;
using OrderService.Dtos.Responses.Event;
using OrderService.Dtos.Responses.Order;
using OrderService.Services.AppTeam;
using OrderService.Services.Order;
using OrderService.Services.Order.Exceptions;
using OrderService.Services.Shop;
using OrderService.Utils.Adapter;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Shop;
using WebApiCore.Services.Logging;
using WebApiCore.Utils;
using WebApiCore.Utils.HttpContext;

namespace OrderService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class OrderController : ControllerBase
{
    /// <summary>
    /// Matches: TerminalName-SerialNumber
    /// Example: P400Plus-123456789
    /// Note: the following characters need to be escaped (by doubling them): []{}
    /// </summary>
    private const string TerminalRegex = @"^[[A-z\d]]{{1,20}}-\d{{9}}$";

    private readonly IOrderService _orderService;
    private readonly IShopService _shopService;
    private readonly IAppTeamService _appTeamService;
    private readonly IUserLoggingService _userLoggingService;

    public OrderController(IOrderService orderService, IShopService shopService, IAppTeamService appTeamService, IUserLoggingService userLoggingService)
    {
        _orderService = orderService;
        _shopService = shopService;
        _appTeamService = appTeamService;
        _userLoggingService = userLoggingService;
    }

    [HttpGet]
    [Route("cost")]
    [ProducesResponseType(typeof(ApiResponse<OrderCostResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<OrderCostResponse>>> Cost([FromQuery] OrderCostRequest request) =>
        Ok(new ApiResponse<OrderCostResponse>
        {
            Data = await _orderService.TotalOrderCostAsync(request.ReservationReference, request.PaymentMethodId, request.ReceiveViaSms, request.EnabledTicketServicePlus)
        });

    [HttpGet]
    [Route("combined/cost")]
    [ProducesResponseType(typeof(ApiResponse<OrderCostResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<OrderCostResponse>>> CombinedCost([FromQuery] CombinedOrderCostRequest request)
    {
        var orderCostResponses = new List<OrderCostResponse>();
        foreach (var reservationReference in request.ReservationReferences)
            orderCostResponses.Add(await _orderService.TotalOrderCostAsync(reservationReference, request.PaymentMethodId, request.ReceiveViaSms, request.EnabledTicketServicePlus));

        return Ok(new ApiResponse<OrderCostResponse>
        {
            Data = orderCostResponses.FlattenOrderCostCollection()
        });
    }

    [HttpPost]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}")]
    [ProducesResponseType(typeof(ApiResponse<OrderCompleteResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<OrderCompleteResponse>>> Order(string shopCode, [FromBody] OrderRequest request) =>
        Ok(new ApiResponse<OrderCompleteResponse>
        {
            Data = await _orderService.PlaceOrderAsync(shopCode, request)
        });

    [HttpPost]
    [Route($"combined/{{combinedShopCode:length({CombinedShop.CodeLengthAttribute})}}")]
    [ProducesResponseType(typeof(ApiResponse<CombinedOrderCompleteResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<CombinedOrderCompleteResponse>>> Order(string combinedShopCode, [FromBody] CombinedOrderRequest request) =>
        Ok(new ApiResponse<CombinedOrderCompleteResponse>
        {
            Data = await _orderService.PlaceCombinedOrderAsync(combinedShopCode, request)
        });

    [HttpPost]
    [Route($"{{code:length({Shop.CodeLengthAttribute})}}/pin/terminals/{{serialNumber:regex({TerminalRegex})}}")]
    [ProducesResponseType(typeof(ApiResponse<PinOrderCompleteResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PinOrderCompleteResponse>>> Order(string code, string serialNumber, [FromBody] OrderRequest request) =>
        Ok(new ApiResponse<PinOrderCompleteResponse>
        {
            Data = await _orderService.PlaceOrderAsync(code, request, serialNumber)
        });

    [HttpPost]
    [Route($"{{code:length({Shop.CodeLengthAttribute})}}/cash")]
    [Authorize(OrganizationSalePermissions.AllowCashPayments)]
    [ProducesResponseType(typeof(ApiResponse<OrderCompleteResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<OrderCompleteResponse>>> CashOrder(string code, [FromBody] OrderRequest request)
    {
        if (!User.IsAppTeam() && !await _shopService.OwnerOfShopAsync(Request.GetOrganizationId(), code))
            throw new ShopNotFoundException();

        return Ok(new ApiResponse<OrderCompleteResponse>
        {
            Data = await _orderService.PlaceCashOrderAsync(code, request)
        });
    }

    [HttpPost]
    [Route($"app-team/{{code:length({Shop.CodeLengthAttribute})}}/cash")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<OrderCompleteResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<OrderCompleteResponse>>> AppTeamCashOrder(string code, [FromBody] OrderRequest request)
    {
        if (!await _appTeamService.HasSalesAndCashEnabledForReservationAsync(User.GetAppTeamId(), request.ReservationReference))
            throw new ShopNotFoundException();

        return await CashOrder(code, request);
    }

    [HttpGet]
    [Route("tickets")]
    [Authorize(ClientCustomerInsightPermissions.View)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EventOrderResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<EventOrderResponse>>>> GetOrderTickets()
    {
        if (!User.IsClient())
            throw new InvalidUserTypeException();

        var result = await _orderService.UpcomingClientEventOrdersAsync(User.GetUserId());

        return Ok(new ApiResponse<IEnumerable<EventOrderResponse>>
        {
            Data = result
        });
    }

    [HttpGet]
    [Route("{orderId:guid}")]
    [Authorize(OrPermissions.ViewCustomerInsightPermission)]
    [ProducesResponseType(typeof(ApiResponse<OrderResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader(false)]
    public async Task<ActionResult<ApiResponse<OrderResponse>>> GetOrder(Guid orderId)
    {
        var userId = User.TryGetUserId();
        var organizationId = Request.TryGetOrganizationId();

        var userType = User.GetUserType() ?? throw new OrderNotFoundException();
        if (!await _orderService.HasAccessAsync(orderId, userId, organizationId, userType))
            throw new OrderNotFoundException();

        var order = await _orderService.OrderAsync(orderId);

        if (userType.IsAdmin())
            await _userLoggingService.LogAsync(User.GetUserId(), $"Has taken a look at the following order: {order.PspReference ?? order.Id.ToString()} placed on {order.PlacedOn} of the buyer {order.Client.Email}");

        return Ok(new ApiResponse<OrderResponse>
        {
            Data = order
        });
    }

    [HttpGet]
    [Route("app-team/{orderId:guid}")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<OrderResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<OrderResponse>>> GetOrderAsAppTeam(Guid orderId) =>
        Ok(new ApiResponse<OrderResponse>
        {
            Data = await _orderService.OrderAsync(orderId, User.GetAppTeamId())
        });

    /// <summary>
    /// Note: c stands for clientId due to obfuscation of the query params.
    /// This measure has been taken to reduce brute forcing of downloading ticketPdfs in combination with removing the files after 15 minutes.
    /// </summary>
    /// <param name="orderId"></param>
    /// <param name="clientId"></param>
    /// <returns></returns>
    [HttpGet]
    [Route("file/{orderId:guid}")]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> DownloadOrderTicketsPdf(Guid orderId, [FromQuery(Name = "c")] Guid clientId)
    {
        if (!await _orderService.ClientBelongsToOrderAsync(orderId, clientId))
            throw new InvalidOrderTicketPdfRequestException();

        if (!await _orderService.OrderHasTicketsFileAsync(orderId))
            throw new OrderTicketFileNotFoundException();

        if (await _orderService.IsOrderOfSealedEventOrWithinSealtimeAsync(orderId))
            throw new OrderSealedException();

        var stream = await _orderService.DownloadTicketPdfAsync(orderId);

        return File(stream, MediaTypeNames.Application.Pdf, "Tickets.pdf");
    }

    [HttpPost]
    [Route("regenerate/lost/ticket")]
    [ProducesResponseType(typeof(ApiResponse<RegenerateTicketResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<RegenerateTicketResponse>>> RegenerateOrderTicketPdf([FromBody] RegenerateTicketRequest request) => Ok(new ApiResponse<RegenerateTicketResponse>
    {
        Data = await _orderService.RegenerateAndDownloadTicketPdfAsync(request.PspReference, request.PaidOnDate)
    });

    [HttpGet]
    [Route("regenerate/{orderId:guid}")]
    [Authorize(AdminOrderPermissions.Export)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> RegenerateOrderTicketPdf(Guid orderId)
    {
        await _orderService.RegenerateAndDownloadTicketPdfAsync(orderId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{orderId:guid}/receipt/generate")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> GenerateReceipt(Guid orderId)
    {
        if (!await _orderService.ExistsAsync(orderId))
            throw new OrderNotFoundException();

        _orderService.GenerateReceiptAsync(orderId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{orderId:guid}/receipt")]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> DownloadOrderReceiptPdf(Guid orderId)
    {
        if (!await _orderService.HasReceiptAsync(orderId))
            throw new OrderReceiptNotFoundException();

        var stream = await _orderService.DownloadReceiptPdfAsync(orderId);

        return File(stream, MediaTypeNames.Application.Pdf, "Receipt.pdf");
    }

    [HttpPost]
    [Route("resend/{orderId:guid}")]
    [Authorize(OrPermissions.ViewCustomerInsightPermission)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader(false)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Resend(Guid orderId)
    {
        var userId = User.TryGetUserId();
        var organizationId = Request.TryGetOrganizationId();

        var userType = User.GetUserType() ?? throw new OrderNotFoundException();
        if (!await _orderService.HasAccessAsync(orderId, userId, organizationId, userType))
            throw new OrderNotFoundException();

        if (userType.IsAdmin())
            await _userLoggingService.LogAsync(User.GetUserId(), $"Has resent the following order: {orderId}");

        await _orderService.ResendOrderAsync(orderId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("resend/{orderId:guid}/explicit")]
    [Authorize(AdminOrderPermissions.Resend)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ExplicitResend(Guid orderId, [FromBody] EmailRequest request)
    {
        var userType = User.GetUserType() ?? throw new OrderNotFoundException();
        if (!await _orderService.HasAccessAsync(orderId, User.GetUserId(), null, userType))
            throw new OrderNotFoundException();

        await _userLoggingService.LogAsync(User.GetUserId(), $"Has resent order: {orderId} to the new email: {request.EmailAddress}");

        await _orderService.ResendOrderAsync(orderId, request.EmailAddress);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}