using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OrderService.Dtos.Requests.Order;
using OrderService.Dtos.Responses.Order;
using OrderService.Services.Event;
using OrderService.Services.Order;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Country;
using WebApiCore.Services.Logging;
using WebApiCore.Utils;
using WebApiCore.Utils.Adapter;
using WebApiCore.Utils.HttpContext;

namespace OrderService.Controllers;

[ApiController]
[Route("/[controller]")]
public class OrdersController : ControllerBase
{
    private const int DailySalesMaxDays = 30;

    private readonly IOrderService _orderService;
    private readonly IEventService _eventService;
    private readonly ICountryService _countryService;
    private readonly IUserLoggingService _userLoggingService;

    public OrdersController(IOrderService orderService, IEventService eventService, ICountryService countryService, IUserLoggingService userLoggingService)
    {
        _orderService = orderService;
        _eventService = eventService;
        _countryService = countryService;
        _userLoggingService = userLoggingService;
    }

    [HttpGet]
    [Route("event/{eventId:guid}/daily")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<DailyOrdersResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<DailyOrdersResponse>>>> DailyEventOrders(Guid eventId, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
    {
        if (!await _eventService.BelongsToOrganizationAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        VerifyDailyOrderDateRange(startDate, endDate);

        return Ok(new ApiResponse<IEnumerable<DailyOrdersResponse>>
        {
            Data = await _orderService.DailyEventOrdersAsync(eventId, startDate, endDate)
        });
    }

    [HttpGet]
    [Route("daily")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<DailyOrdersResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<DailyOrdersResponse>>>> DailyOrders([FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
    {
        VerifyDailyOrderDateRange(startDate, endDate);

        return Ok(new ApiResponse<IEnumerable<DailyOrdersResponse>>
        {
            Data = await _orderService.DailyOrdersAsync(Request.GetOrganizationId(), startDate, endDate)
        });
    }

    [HttpGet]
    [Route("client/list")]
    [Authorize(ClientCustomerInsightPermissions.View)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<OrderListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<OrderListItemResponse>>>> GetClientOrders([FromQuery] PaginatedRequest<OrdersRequestFilter> request)
    {
        if (!User.IsClient())
            throw new InvalidUserTypeException();

        var result = await _orderService.ListClientOrdersAsync(User.GetUserId(), request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("client/export/csv")]
    [Authorize(ClientCustomerInsightPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> ExportClientOrdersAsCsv([FromQuery] OrdersRequestFilter request)
    {
        var file = await _orderService.ClientOrdersAsCsvAsync(User.GetUserId(), request);

        return File(file.FileContents, "text/csv", $"Order-export-{DateTime.UtcNow}-UTC.csv");
    }

    [HttpGet]
    [Route("organization/list")]
    [Authorize(OrganizationCustomerInsightPermissions.View)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<OrderListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<OrderListItemResponse>>>> GetOrganizationOrders([FromQuery] PaginatedRequest<OrdersRequestFilter> request)
    {
        var result = await _orderService.ListOrganizationOrdersAsync(Request.GetOrganizationId(), request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("organization/export/csv")]
    [Authorize(OrganizationCustomerInsightPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<FileResult> ExportOrganizationOrdersAsCsv([FromQuery] OrdersRequestFilter request)
    {
        var file = await _orderService.OrganizationOrdersCsvAsync(Request.GetOrganizationId(), request);

        return File(file.FileContents, "text/csv", $"Order-export-{DateTime.UtcNow}-UTC.csv");
    }

    [HttpGet]
    [Route("platform/list")]
    [Authorize(AdminOrderPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<OrderListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<OrderListItemResponse>>>> GetPlatformOrders([FromQuery] PaginatedRequest<OrdersRequestFilter> request)
    {
        await _userLoggingService.LogAsync(User.GetUserId(), "Has taken a look at the platform orders overview");

        request.Options.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.Options.CountryCodes);

        var result = await _orderService.ListPlatformOrdersAsync(request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("platform/export/csv")]
    [Authorize(AdminOrderPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> ExportPlatformOrdersAsCsv([FromQuery] OrdersRequestFilter request)
    {
        request.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.CountryCodes);

        var file = await _orderService.PlatformOrdersAsCsvAsync(request);

        return File(file.FileContents, "text/csv", $"Order-export-{DateTime.UtcNow}-UTC.csv");
    }

    private static void VerifyDailyOrderDateRange(DateTime startDate, DateTime endDate)
    {
        if (startDate > endDate)
            throw new InvalidDateRangeException();

        if ((endDate - startDate).Days > DailySalesMaxDays)
            throw new ExceededDateRangeException(DailySalesMaxDays);
    }
}