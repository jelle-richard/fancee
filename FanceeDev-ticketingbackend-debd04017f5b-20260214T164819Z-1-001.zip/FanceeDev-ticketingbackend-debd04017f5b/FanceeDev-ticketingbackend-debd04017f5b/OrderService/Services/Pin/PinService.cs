using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.PinTerminal;

namespace OrderService.Services.Pin;

public class PinService : IPinService
{
    private readonly IMessagePublisher<ValidPinTerminalMessage> _validPinTerminalPublisher;
    private readonly IMessagePublisher<StartPinTerminalTransactionMessage> _startPinTerminalTransactionPublisher;

    public PinService(IMessagePublisher<ValidPinTerminalMessage> validPinTerminalPublisher, IMessagePublisher<StartPinTerminalTransactionMessage> startPinTerminalTransactionPublisher)
    {
        _validPinTerminalPublisher = validPinTerminalPublisher;
        _startPinTerminalTransactionPublisher = startPinTerminalTransactionPublisher;
    }

    public async Task<bool> ValidTerminalAsync(string terminalSerialNumber)
    {
        var isValidTerminal = await Task.Run(() =>
            _validPinTerminalPublisher.Call<ValidPinTerminalResponseMessage>(new() { SerialNumber = terminalSerialNumber })
        );

        return isValidTerminal is { Valid: true };
    }

    public void StartTransaction(StartPinTerminalTransactionMessage request)
    {
        _startPinTerminalTransactionPublisher.Publish(request);
    }
}