namespace OrderService.Services;

public interface ITrackingService
{
    /// <summary>
    /// Registers a checkout.
    /// </summary>
    /// <param name="shopCode"></param>
    /// <param name="reservationReference"></param>
    /// <returns></returns>
    public Task RegisterCheckoutAsync(string shopCode, Guid reservationReference);

    /// <summary>
    /// Registers a purchase.
    /// </summary>
    /// <param name="shopCode"></param>
    /// <param name="reservationReference"></param>
    /// <returns></returns>
    public Task RegisterPurchaseAsync(string shopCode, Guid reservationReference);
}