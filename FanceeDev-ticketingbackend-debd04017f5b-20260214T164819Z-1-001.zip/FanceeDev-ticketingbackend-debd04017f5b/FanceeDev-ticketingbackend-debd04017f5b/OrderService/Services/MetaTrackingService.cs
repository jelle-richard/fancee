using System.Net;
using Fs.PixelTracking;
using Fs.PixelTracking.Configuration;
using Fs.PixelTracking.Meta;
using Fs.PixelTracking.Models;
using Microsoft.EntityFrameworkCore;
using OrderService.Persistence.Shop;
using WebApiCore.Persistence.Reservation;
using WebApiCore.Services.Currency;
using WebApiCore.Utils;

namespace OrderService.Services;

/// <summary>
/// todo(technical debt FAN-2244): we need to apply some caching here, because right now it does the same work twice for costless orders.
/// </summary>
public class MetaTrackingService : ITrackingService
{
    private readonly Dictionary<string, FanceeData.Models.Ticketing.Shop?> _shopCache = new();

    private readonly ITracker _metaTracker;
    private readonly IReservationDao _reservationDao;
    private readonly IShopDao _shopDao;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ICurrencyService _currencyService;

    // ReSharper disable once SuggestBaseTypeForParameterInConstructor -- note: we need to make sure we get a MetaTracker implementation
    public MetaTrackingService(IMetaTracker metaTracker, IReservationDao reservationDao, IShopDao shopDao, IHttpContextAccessor httpContextAccessor, ICurrencyService currencyService)
    {
        _metaTracker = metaTracker;
        _reservationDao = reservationDao;
        _shopDao = shopDao;
        _httpContextAccessor = httpContextAccessor;
        _currencyService = currencyService;
    }

    public async Task RegisterCheckoutAsync(string shopCode, Guid reservationReference) =>
        await RegisterAsync(shopCode, reservationReference, _metaTracker.CheckoutAsync);

    public async Task RegisterPurchaseAsync(string shopCode, Guid reservationReference) =>
        await RegisterAsync(shopCode, reservationReference, _metaTracker.CompletePurchaseAsync);

    private async Task RegisterAsync(string shopCode, Guid reservationReference, Func<TrackingInformation, IList<CartItem>, Task> methodToCall)
    {
        var userAgent = _httpContextAccessor.HttpContext.TryGetUserAgent();
        if (userAgent == null)
            return;

        if (!_shopCache.TryGetValue(shopCode, out var shop))
        {
            shop = await _shopDao.ByCodeAsync(shopCode);
            _shopCache.Add(shopCode, shop);
        }

        if (shop is not { FacebookAccessCode: not null, FacebookPixelId: not null })
            return;

        var reservation = await _reservationDao.ReservationAsync(reservationReference, q =>
            q.Include(rp => rp.ReservedProducts)
                .ThenInclude(rp => rp.Product.Event.Organization)
                .Include(rp => rp.OrderReference)
        );

        if (reservation == null || !reservation.ReservedProducts.Any())
            return;

        var cartItems = new List<CartItem>();

        foreach (var rp in reservation.ReservedProducts)
        {
            cartItems.Add(new()
            {
                ProductId = rp.ProductId,
                Quantity = rp.Quantity,
                ItemPrice = await _currencyService.CentsToDecimalAsync(rp.Product.Event.Organization.Currency, rp.Product.PriceCents ?? 0)
            });
        }

        _metaTracker.SetConfiguration(new MetaConfiguration
        {
            PixelId = shop.FacebookPixelId,
            AccessCode = shop.FacebookAccessCode
        });

        await methodToCall(new()
        {
            IpAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress ?? IPAddress.None,
            UserAgent = userAgent,
            EventId = shop.EventId,
            ShopCode = shopCode,
            Currency = reservation.ReservedProducts.First().Product.Event.Organization.Currency,
            OrderId = reservation.OrderReference?.Id.ToString() ?? null
        }, cartItems);
    }
}