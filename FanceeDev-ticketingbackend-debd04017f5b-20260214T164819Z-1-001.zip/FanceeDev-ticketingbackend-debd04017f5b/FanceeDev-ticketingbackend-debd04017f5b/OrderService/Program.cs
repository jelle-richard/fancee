using Fs.PixelTracking;
using Fs.SeatingUtils.Config;
using Fs.SeatingUtils.Utils;
using OrderService.Persistence.AppTeam;
using OrderService.Persistence.Event;
using OrderService.Persistence.Order;
using OrderService.Persistence.OrganizationBlockedEmail;
using OrderService.Persistence.PaymentMethod;
using OrderService.Persistence.Reservation;
using OrderService.Persistence.Shop;
using OrderService.Persistence.User;
using OrderService.Services;
using OrderService.Services.AppTeam;
using OrderService.Services.CombinedShop;
using OrderService.Services.Event;
using OrderService.Services.Order;
using OrderService.Services.PaymentMethod;
using OrderService.Services.Pin;
using OrderService.Services.Shop;
using WebApiCore;
using WebApiCore.Exceptions;
using WebApiCore.Services.Country;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "OrderService",
        EndpointName = "OrderService v1"
    },
    UseS3Storage = true,
    UseRabbitMq = true
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddPixelTracking();

    if (builder.IsCiCd)
        return;

    collection.AddSeatingUtils(new SeatsIoConfiguration
    {
        Region = builder.Configuration.GetValue<string>("SeatsIo:Region") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "Region"),
        SecretKey = builder.Configuration.GetValue<string>("SeatsIo:SecretKey") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "SecretKey")
    });
};

builder.AddDependency<IOrderService, OrderService.Services.Order.OrderService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderDao, OrderDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventService, EventService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);
builder.AddDependency<IReservationDao, ReservationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDao, ShopDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserDao, UserDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPaymentMethodService, PaymentMethodService>(ServiceLifetime.Scoped);
builder.AddDependency<IPaymentMethodDao, PaymentMethodDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPinService, PinService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopService, ShopService>(ServiceLifetime.Scoped);
builder.AddDependency<IAppTeamService, AppTeamService>(ServiceLifetime.Scoped);
builder.AddDependency<IAppTeamDao, AppTeamDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopQuestionDao, ShopQuestionDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopQuestionService, ShopQuestionService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationBlockedEmailDao, OrganizationBlockedEmailDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICountryService, CountryService>(ServiceLifetime.Scoped);
builder.AddDependency<ITrackingService, MetaTrackingService>(ServiceLifetime.Scoped);
builder.AddDependency<ICombinedShopDao, CombinedShopDao>(ServiceLifetime.Scoped);

var app = builder.Build();

app.Run();