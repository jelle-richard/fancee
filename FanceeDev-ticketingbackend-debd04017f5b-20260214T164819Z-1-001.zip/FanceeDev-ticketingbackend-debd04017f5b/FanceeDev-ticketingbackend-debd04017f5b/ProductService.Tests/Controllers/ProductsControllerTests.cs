﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductService.Controllers;
using ProductService.Dtos.Requests.Tickets;
using ProductService.Dtos.Responses.Products;
using ProductService.Dtos.Responses.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.Organization;
using ProductService.Services.Product;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.File;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions.Event;

namespace ProductService.Tests.Controllers;

public class ProductsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidAppTeamId = Guid.NewGuid();

    private readonly ProductsController _sut;
    private readonly Mock<IIssuedTicketService> _mockedIssuedTicketService = new();
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    public ProductsControllerTests()
    {
        _sut = new(_mockedIssuedTicketService.Object, _mockedProductService.Object, _mockedOrganizationService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId, appTeamId: ValidAppTeamId);
    }

    [Fact]
    public async Task TestThatGetOrganizationTicketsCallsIssuedTicketsByOrganizationAsync()
    {
        var request = new PaginatedRequest<TicketsRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _mockedIssuedTicketService.Setup(its => its.IssuedTicketsByOrganizationAsync(ValidOrganizationId, request)).ReturnsAsync(new PaginatedResultSet<TicketListResponse>
        {
            Items = new TicketListResponse[] { new() { Email = "unit@test.com" }, new() { Email = "test@unit.nl" } },
            TotalItems = 20
        });

        var actual = await _sut.GetOrganizationTickets(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualType = (OkObjectResult)actual.Result!;
        Assert.IsType<ApiResponse<PaginatedResponse<TicketListResponse>>>(actualType.Value);

        var actualValue = (ApiResponse<PaginatedResponse<TicketListResponse>>)actualType.Value!;
        Assert.Equal(2, actualValue.Data.Page);
        Assert.Equal(3, actualValue.Data.PageSize);
        Assert.Equal(20, actualValue.Data.TotalItems);
        Assert.Equal(2, actualValue.Data.Items.Count());

        _mockedIssuedTicketService.Verify(its => its.IssuedTicketsByOrganizationAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAppTeamOrganizationTicketsCallsIssuedTicketsIssuedTicketsByAppTeamAsync()
    {
        var request = new PaginatedRequest<TicketsRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _mockedIssuedTicketService.Setup(its => its.IssuedTicketsByAppTeamAsync(ValidAppTeamId, request)).ReturnsAsync(new PaginatedResultSet<TicketListResponse>
        {
            Items = new TicketListResponse[] { new() { Email = "unit@test.com" }, new() { Email = "test@unit.nl" } },
            TotalItems = 20
        });

        var actual = await _sut.GetAppTeamOrganizationTickets(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        var actualType = (OkObjectResult)actual.Result!;
        Assert.IsType<ApiResponse<PaginatedResponse<TicketListResponse>>>(actualType.Value);

        var actualValue = (ApiResponse<PaginatedResponse<TicketListResponse>>)actualType.Value!;
        Assert.Equal(2, actualValue.Data.Page);
        Assert.Equal(3, actualValue.Data.PageSize);
        Assert.Equal(20, actualValue.Data.TotalItems);
        Assert.Equal(2, actualValue.Data.Items.Count());

        _mockedIssuedTicketService.Verify(its => its.IssuedTicketsByAppTeamAsync(ValidAppTeamId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatGetBestSellersCallsProductServiceBestSellingProductsAsync()
    {
        _mockedProductService.Setup(ps => ps.BestSellingProductsAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<BestSellingProductResponse>
            {
                new()
                {
                    Media = Array.Empty<FileResponse>(),
                    AmountSold = 14,
                    EventName = "UnitEvent",
                    ProductId = Guid.NewGuid(),
                    ProductName = "UnitProduct"
                }
            });

        var actual = await _sut.GetBestSellers(10, DateTime.UtcNow.AddDays(-2), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedProductService.Verify(ps => ps.BestSellingProductsAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetEventBestSellersThrowsEventNotFoundExceptionOnUnknownOrganizationEventLink()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.GetEventBestSellers(Guid.NewGuid(), 10, DateTime.UtcNow.AddDays(-2), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatGetEventBestSellersCallsProductServiceBestSellingEventProductsAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedProductService.Setup(ps => ps.BestSellingEventProductsAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<BestSellingProductResponse>
            {
                new()
                {
                    Media = Array.Empty<FileResponse>(),
                    AmountSold = 14,
                    EventName = "UnitEvent",
                    ProductId = Guid.NewGuid(),
                    ProductName = "UnitProduct"
                }
            });

        var actual = await _sut.GetEventBestSellers(Guid.NewGuid(), 10, DateTime.UtcNow.AddDays(-2), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedProductService.Verify(ps => ps.BestSellingEventProductsAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExportOrganizationTicketsAsCsvCallsIssuedTicketServiceExportIssuedTicketsByOrganizationAsCsvAsync()
    {
        _mockedIssuedTicketService.Setup(its => its.ExportIssuedTicketsByOrganizationAsCsvAsync(It.IsAny<Guid>(), It.IsAny<TicketsRequestFilter>()))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportOrganizationTicketsAsCsv(new());

        _mockedIssuedTicketService.Verify(its => its.ExportIssuedTicketsByOrganizationAsCsvAsync(It.IsAny<Guid>(), It.IsAny<TicketsRequestFilter>()), Times.Once);
        Assert.Equal("text/csv", actual.ContentType);
    }

    [Fact]
    public async Task TestThatEventProductsCallsProductServiceProductsByEventIdsAsync()
    {
        _mockedProductService.Setup(ps => ps.ProductsByEventIdsAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync(new List<EventProductsResponse>());

        var actual = await _sut.EventProducts(new());

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedProductService.Verify(ps => ps.ProductsByEventIdsAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<Guid>>()), Times.Once);
    }
}