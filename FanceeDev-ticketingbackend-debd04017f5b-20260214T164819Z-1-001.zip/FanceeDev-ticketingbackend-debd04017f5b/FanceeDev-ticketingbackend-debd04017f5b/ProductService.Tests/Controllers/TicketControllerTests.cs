using System;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using ProductService.Controllers;
using ProductService.Dtos.Requests.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.Product.Exceptions;
using TestCore.Mocks;

namespace ProductService.Tests.Controllers;

public class TicketControllerTests
{
    private const string IssuedTicketCode = "UNITTICKETCODE";
    private static readonly Guid ValidClientId = Guid.NewGuid();

    private static readonly TicketHolderRequest Request = new()
    {
        Email = "unit@email.com",
        FirstName = "FirstName",
        LastName = "LastName",
        PhoneNumber = "0612345678",
        Birthdate = DateTime.Now,
        Gender = Gender.Female
    };

    private readonly TicketController _sut;
    private readonly Mock<IIssuedTicketService> _mockedIssuedTicketService = new();

    public TicketControllerTests()
    {
        _sut = new(_mockedIssuedTicketService.Object);

        _sut.SetupHttpContext(platformUserId: ValidClientId, userType: UserType.Client.ToString());
    }

    [Fact]
    public async Task TestThatUpdateTicketHolderThrowsProductNotFoundExceptionOnNonOrganizationOrBuyerUser()
    {
        _sut.SetupHttpContext(organizationId: ValidClientId, userType: UserType.Admin.ToString());

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.UpdateTicketHolder(IssuedTicketCode, Request));
    }

    [Fact]
    public async Task TestThatUpdateTicketHolderThrowsProductNotFoundExceptionOnNoTicketAccess()
    {
        _sut.SetupHttpContext(platformUserId: ValidClientId, userType: UserType.Client.ToString());

        _mockedIssuedTicketService.Setup(its => its.HasAccessAsync(IssuedTicketCode, ValidClientId, null))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.UpdateTicketHolder(IssuedTicketCode, Request));
        _mockedIssuedTicketService.Verify(its => its.HasAccessAsync(IssuedTicketCode, ValidClientId, null), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateTicketHolderThrowsProductNotFoundExceptionIfUserIdAndOrganizationIdAreNull()
    {
        _sut.SetupHttpContext();

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.UpdateTicketHolder("code", new()));

        _mockedIssuedTicketService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateTicketHolderCallsIssuedTicketServiceUpdateTicketHolderAsync()
    {
        _mockedIssuedTicketService.Setup(its => its.HasAccessAsync(IssuedTicketCode, ValidClientId, null))
            .ReturnsAsync(true);

        var actual = await _sut.UpdateTicketHolder(IssuedTicketCode, Request);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedIssuedTicketService.Verify(its => its.UpdateTicketHolderAsync(IssuedTicketCode, Request), Times.Once);
    }
}