using System;
using System.Threading.Tasks;
using ProductService.Controllers;
using ProductService.Dtos.Requests.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.Product;
using ProductService.Services.Product.Exceptions;
using TestCore.Mocks;
using WebApiCore.Dtos.Shared.Csv;

namespace ProductService.Tests.Controllers;

public class TicketsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidProductId = Guid.NewGuid();

    private readonly TicketsController _sut;
    private readonly Mock<IIssuedTicketService> _mockedTicketIssuedService = new();
    private readonly Mock<IProductService> _mockedProductService = new();

    public TicketsControllerTests()
    {
        _sut = new(_mockedTicketIssuedService.Object, _mockedProductService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatImportIssuedTicketsThrowsProductNotFoundExceptionOnInvalidOwner()
    {
        _mockedProductService.Setup(ps => ps.OwnerOfProductAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.ImportIssuedTickets(Guid.NewGuid(), new()
        {
            CodeFieldIndex = 0,
            Delimiter = Delimiter.Semicolon,
            HasHeader = true,
            EmailFieldIndex = null,
            FirstnameFieldIndex = null,
            LastnameFieldIndex = null
        }));
    }

    [Fact]
    public async Task TestThatImportIssuedTicketsCallsIssuedTicketServiceImportIssuedTicketsAsync()
    {
        _mockedProductService.Setup(ps => ps.OwnerOfProductAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        await _sut.ImportIssuedTickets(Guid.NewGuid(), new()
        {
            CodeFieldIndex = 0,
            Delimiter = Delimiter.Semicolon,
            EmailFieldIndex = null,
            FirstnameFieldIndex = null,
            LastnameFieldIndex = null,
            HasHeader = true
        });

        _mockedTicketIssuedService.Verify(tis => tis.ImportIssuedTicketsAsync(It.IsAny<Guid>(), It.IsAny<IssuedTicketsImportRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateBarcodeCallsIssuedTicketServiceGenerateCodeAndInsertAsync()
    {
        var amount = 100;

        _mockedProductService.Setup(ps => ps.OwnerOfProductAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);
        _mockedTicketIssuedService.Setup(tis => tis.GenerateCodeAndInsertAsync(ValidOrganizationId, ValidProductId, amount));

        await _sut.GenerateBarcode(ValidProductId, amount);

        _mockedTicketIssuedService.Verify(tis => tis.GenerateCodeAndInsertAsync(ValidOrganizationId, ValidProductId, amount), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateBarcodeThrowsProductNotFoundExceptionOnInvalidOwner()
    {
        var amount = 100;

        _mockedProductService.Setup(ps => ps.OwnerOfProductAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.GenerateBarcode(ValidProductId, amount));
    }
}