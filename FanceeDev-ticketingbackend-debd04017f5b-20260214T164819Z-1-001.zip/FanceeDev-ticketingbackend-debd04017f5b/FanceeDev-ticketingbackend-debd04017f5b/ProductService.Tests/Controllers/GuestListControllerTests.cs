using System;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using ProductService.Controllers;
using ProductService.Dtos.Requests.Tickets.GuestList;
using ProductService.Services.GuestList;
using ProductService.Services.Product;
using ProductService.Services.Product.Exceptions;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared.Csv;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.DeploymentEnvironment;

namespace ProductService.Tests.Controllers;

public class GuestListControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidProductId = Guid.NewGuid();

    private readonly GuestListController _sut;
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<IGuestListService> _mockedGuestListService = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();

    public GuestListControllerTests()
    {
        _sut = new(_mockedProductService.Object, _mockedGuestListService.Object, _mockedDeploymentEnvironmentService.Object);

        _sut.SetupHttpContext(UserType.Client.ToString(), organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatImportGuestListThrowsProductNotFoundExceptionIfUserIsNotOwnerOfProduct()
    {
        _mockedProductService.Setup(ps => ps.OwnerOfProductAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(false);
        _mockedProductService.Setup(ps => ps.EventActiveAsync(It.IsAny<Guid>())).ReturnsAsync(true);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.ImportGuestList(Guid.Empty, new()));

        _mockedProductService.Verify(ps => ps.OwnerOfProductAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedGuestListService.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatImportGuestListThrowsEventNotActiveExceptionIfEventOfProductIsNotActive()
    {
        _mockedProductService.Setup(ps => ps.OwnerOfProductAsync(ValidOrganizationId, Guid.Empty)).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.EventActiveAsync(It.IsAny<Guid>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotActiveException>(async () => await _sut.ImportGuestList(Guid.Empty, new()));

        _mockedProductService.Verify(ps => ps.OwnerOfProductAsync(ValidOrganizationId, Guid.Empty), Times.Once);
        _mockedProductService.Verify(ps => ps.EventActiveAsync(It.IsAny<Guid>()), Times.Once);
        _mockedGuestListService.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatImportGuestListCallsGuestListServiceImportAsync()
    {
        var request = new ImportGuestListRequest
        {
            Delimiter = Delimiter.Comma,
            HasHeader = true,
            EmailFieldIndex = 0,
            TicketAmountFieldIndex = 1,
            FirstNameFieldIndex = 2,
            LastNameFieldIndex = 3,
            DeductStock = true
        };
        var env = new HostedDeploymentEnvironment();

        _mockedProductService.Setup(ps => ps.OwnerOfProductAsync(ValidOrganizationId, ValidProductId)).ReturnsAsync(true);
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(env);
        _mockedProductService.Setup(ps => ps.EventActiveAsync(It.IsAny<Guid>())).ReturnsAsync(true);

        var actual = await _sut.ImportGuestList(ValidProductId, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedProductService.Verify(ps => ps.OwnerOfProductAsync(ValidOrganizationId, ValidProductId), Times.Once);
        _mockedGuestListService.Verify(gls => gls.ImportAsync(ValidOrganizationId, ValidProductId, request, env), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
        _mockedProductService.Verify(ps => ps.EventActiveAsync(It.IsAny<Guid>()), Times.Once);
    }
}