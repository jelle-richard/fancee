﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductService.Controllers;
using ProductService.Dtos.Responses.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.IssuedTicket.Exceptions;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;

namespace ProductService.Tests.Controllers;

public class ProductControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ProductController _sut;
    private readonly Mock<IIssuedTicketService> _mockedIssuedTicketService = new();

    public ProductControllerTests()
    {
        _sut = new(_mockedIssuedTicketService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatDetailsCallsIssuedTicketServiceDetailsAsync()
    {
        var code = "skdfjsldkf9gjgjwJFj";

        _mockedIssuedTicketService.Setup(its => its.DetailsAsync(code, ValidOrganizationId)).ReturnsAsync(new TicketResponse());

        var actual = await _sut.Details(code);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<TicketResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedIssuedTicketService.Verify(its => its.DetailsAsync(code, ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatChangeTicketStateThrowsInvalidTicketCodeExceptionIfOrganizationDoesNotOwnTicket()
    {
        _mockedIssuedTicketService.Setup(its => its.HasAccessAsync("invalid", null, ValidOrganizationId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidTicketCodeException>(async () => await _sut.ChangeTicketState("invalid", new() { Reason = null, ReturnToStock = false }));

        _mockedIssuedTicketService.Verify(its => its.HasAccessAsync("invalid", null, ValidOrganizationId), Times.Once);
        _mockedIssuedTicketService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatChangeTicketStateCallsIssuedTicketServiceInvalidateAsync()
    {
        _mockedIssuedTicketService.Setup(its => its.HasAccessAsync("valid", null, ValidOrganizationId))
            .ReturnsAsync(true);

        var actual = await _sut.ChangeTicketState("valid", new() { Reason = null, ReturnToStock = true });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedIssuedTicketService.Verify(its => its.HasAccessAsync("valid", null, ValidOrganizationId), Times.Once);
        _mockedIssuedTicketService.Verify(its => its.InvalidateAsync(ValidOrganizationId, "valid", null, true), Times.Once);
        _mockedIssuedTicketService.VerifyNoOtherCalls();
    }
}