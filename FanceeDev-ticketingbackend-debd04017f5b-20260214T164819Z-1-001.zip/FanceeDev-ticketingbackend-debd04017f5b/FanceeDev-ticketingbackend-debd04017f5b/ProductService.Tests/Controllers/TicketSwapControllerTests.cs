using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ProductService.Controllers;
using ProductService.Dtos.Requests.TicketSwap;
using ProductService.Dtos.Responses.TicketSwap;
using ProductService.Services.TicketSwap;
using ProductService.Services.TicketSwap.Exceptions;
using TestCore.Mocks;
using WebApiCore.Exceptions;

namespace ProductService.Tests.Controllers;

public class TicketSwapControllerTests
{
    private const string AccessToken = "UnitAccessKey";

    private TicketSwapController _sut;
    private readonly Mock<ITicketSwapService> _mockedTicketSwapService = new();
    private IConfiguration _configuration;

    public TicketSwapControllerTests()
    {
        _configuration = ConfigurationMockUtils.Create(new()
        {
            { "TicketSwap:AccessKey", AccessToken }
        });

        _sut = new(_mockedTicketSwapService.Object, _configuration);
    }

    [Fact]
    public async Task TestThatValidateThrowsMissingRequiredConfigurationEntryExceptionForMissingConfigurationEntry()
    {
        _configuration = ConfigurationMockUtils.Create(new());
        var localSut = new TicketSwapController(_mockedTicketSwapService.Object, _configuration);

        await Assert.ThrowsAsync<MissingRequiredConfigurationEntryException>(async () => await localSut.Validate("CODE123", "AccessKey"));
    }

    [Fact]
    public async Task TestThatValidateThrowsTicketSwapUnauthorizedExceptionForWrongAccessKey()
    {
        await Assert.ThrowsAsync<TicketSwapUnauthorizedException>(async () => await _sut.Validate("CODE123", "WrongAccessKey"));
    }

    [Fact]
    public async Task TestThatSwapThrowsMissingRequiredConfigurationEntryExceptionForMissingConfigurationEntry()
    {
        _configuration = ConfigurationMockUtils.Create(new());
        var localSut = new TicketSwapController(_mockedTicketSwapService.Object, _configuration);

        await Assert.ThrowsAsync<MissingRequiredConfigurationEntryException>(async () => await localSut.Swap(new()
        {
            Customer = new()
            {
                Email = "unit@email.com"
            },
            Ticket = new()
        }, "AccessKey"));
    }

    [Fact]
    public async Task TestThatSwapThrowsTicketSwapUnauthorizedExceptionForWrongAccessKey()
    {
        await Assert.ThrowsAsync<TicketSwapUnauthorizedException>(async () => await _sut.Swap(new()
        {
            Ticket = new(),
            Customer = new()
            {
                Email = "unit@email.com"
            }
        }, "AccessKey"));
    }

    [Fact]
    public async Task TestThatValidateCallsTicketSwapServiceValidateSwapSpecificationAsync()
    {
        const string code = "UnitCode";
        _mockedTicketSwapService.Setup(tss => tss.ValidateSwapSpecificationAsync(code))
            .ReturnsAsync(new ValidateResponse
            {
                Code = "NewCode",
                Swappable = true,
                Event = new()
                {
                    Id = Guid.NewGuid(),
                    Name = "Name"
                },
                Type = new()
                {
                    CurrencyShortCode = "EUR",
                    ProductName = "Name",
                    ProductPrice = "10,00",
                    TicketFee = "0,50",
                },
                IsValid = true,
                IssuedProductId = Guid.NewGuid()
            });

        var actual = await _sut.Validate(code, AccessToken);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedTicketSwapService.Verify(tss => tss.ValidateSwapSpecificationAsync(code), Times.Once);
    }

    [Fact]
    public async Task TestThatSwapCallsTicketSwapServiceSwapTicketAsync()
    {
        var request = new SwapRequest
        {
            Customer = new()
            {
                Email = "unit@mail.com",
                FirstName = "John",
                LastName = "Doe",
                LanguageLocale = "NL"
            },
            Ticket = new()
            {
                Code = "TsUnitCode"
            }
        };

        _mockedTicketSwapService.Setup(tss => tss.SwapTicketAsync(request))
            .ReturnsAsync(new SwapResponse
            {
                Code = "newCode",
                IssuedProductId = Guid.NewGuid(),
                PdfUrl = "url/to/ticket.pdf"
            });

        var actual = await _sut.Swap(request, AccessToken);

        Assert.IsType<CreatedResult>(actual.Result);

        _mockedTicketSwapService.Verify(tss => tss.SwapTicketAsync(request), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadSwapPdfCallsTicketSwapServiceDownloadSwapPdfAsync()
    {
        var previousCode = "FAN-previous";
        var swappedCode = "TS-swapped";

        _mockedTicketSwapService.Setup(tss => tss.DownloadSwapPdfAsync(previousCode, swappedCode))
            .ReturnsAsync(new MemoryStream("I'm a PDF!"u8.ToArray()));

        var actual = await _sut.DownloadSwapPdf(previousCode, swappedCode);

        Assert.Equal("application/pdf", actual.ContentType);
        _mockedTicketSwapService.Verify(tss => tss.DownloadSwapPdfAsync(previousCode, swappedCode), Times.Once);
    }

    [Fact]
    public async Task TestThatSealedTicketsCallsTicketSwapServiceSealedTicketsOrderResponseByOrderIdAsync()
    {
        _mockedTicketSwapService.Setup(tss => tss.SealedTicketsOrderResponseByOrderIdAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<TicketsOfOrderResponse>());

        var actual = await _sut.SealedTickets(Guid.NewGuid(), AccessToken);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedTicketSwapService.Verify(tss => tss.SealedTicketsOrderResponseByOrderIdAsync(It.IsAny<Guid>()), Times.Once);
    }
}