using FanceeData.Models.Ticketing;
using ProductService.Settings;
using TestCore.Mocks;
using WebApiCore.Exceptions;
using WebApiCore.Settings;

namespace ProductService.Tests.Settings;

public class GuestListSettingsTests
{
    [Fact]
    public void TestThatFromConfigurationThrowsMissingRequiredConfigurationEntryExceptionOnMissingSection()
    {
        var configuration = ConfigurationMockUtils.Create();

        Assert.Throws<MissingRequiredConfigurationEntryException>(() => OrganizationDetailsSettings.FromConfiguration(configuration));
    }
}