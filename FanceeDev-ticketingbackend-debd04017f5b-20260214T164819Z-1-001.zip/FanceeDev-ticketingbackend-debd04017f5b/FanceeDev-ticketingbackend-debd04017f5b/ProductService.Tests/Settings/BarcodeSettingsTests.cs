using ProductService.Settings;
using TestCore.Mocks;
using WebApiCore.Exceptions;

namespace ProductService.Tests.Settings;

public class BarcodeSettingsTests
{
    [Fact]
    public void TestThatFromConfigurationThrowsMissingRequiredConfigurationEntryExceptionOnMissingSection()
    {
        var configuration = ConfigurationMockUtils.Create();

        Assert.Throws<MissingRequiredConfigurationEntryException>(() => BarcodeSettings.FromConfiguration(configuration));
    }

    [Fact]
    public void TestThatFromConfigurationGetsSettingsFromConfiguration()
    {
        var configuration = ConfigurationMockUtils.Create(new()
        {
            { "Barcode:CostCents", "10" },
            { "Barcode:FreeLimit", "500" }
        });

        var actual = BarcodeSettings.FromConfiguration(configuration);

        Assert.NotNull(actual);
        Assert.Equal(10, actual.CostCents);
        Assert.Equal(500, actual.FreeLimit);
    }
}