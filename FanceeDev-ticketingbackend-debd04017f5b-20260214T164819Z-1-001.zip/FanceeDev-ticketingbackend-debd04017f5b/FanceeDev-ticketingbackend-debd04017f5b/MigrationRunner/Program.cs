﻿using FanceeData.Contexts;
using FanceeUsers.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

const string title = "----<==== Migration Runner ====>----";

Console.Out.WriteLine(title);

try
{
    var configBuilder = new ConfigurationBuilder()
        .AddEnvironmentVariables()
        .Build();

    var serviceCollection = new ServiceCollection()
        .AddLogging()
        .AddDbContext<TicketingContext>(options =>
            options.UseSqlServer(configBuilder.GetConnectionString("FanceeData") + ";TrustServerCertificate=true"))
        .AddDbContext<FanceeUsersContext>(options =>
            options.UseSqlServer(configBuilder.GetConnectionString("FanceeUsers") + ";TrustServerCertificate=true"));

    var serviceProvider = serviceCollection.BuildServiceProvider();

    var contexts = new List<DbContext>
    {
        serviceProvider.GetRequiredService<TicketingContext>(),
        serviceProvider.GetRequiredService<FanceeUsersContext>()
    };

    Console.Out.WriteLine("> Running migrations...");
    Console.Out.WriteLine();

    var index = 0;
    var total = contexts.Count;

    foreach (var context in contexts)
    {
        Console.Out.WriteLine($"-> Running migrations for {context.GetType().Name}... ({++index}/{total})");

        var pendingMigrations = context.Database.GetPendingMigrations().ToList();

        if (pendingMigrations.Any())
        {
            Console.Out.Write($"> Applying the following migrations:{Environment.NewLine}  - ");
            Console.Out.WriteLine(string.Join($"{Environment.NewLine}  - ", pendingMigrations));
        }

        await context.Database.MigrateAsync();

        Console.Out.WriteLine();
    }

    Console.Out.WriteLine("> Done.");
}
catch (Exception ex)
{
    Console.Out.WriteLine("> Unable to apply migrations. See exception for details:");
    Console.Out.WriteLine(ex);
    Console.Out.WriteLine(title);

    return -1;
}

Console.Out.WriteLine(title);

return 0;