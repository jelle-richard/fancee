﻿using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace CommerceUtils.Utils;

public class CustomCertificateHttpClient : ICustomCertificateHttpClient
{
    protected readonly HttpClientHandler Handler;

    private readonly X509Certificate2Collection _certificates = new();
    private readonly Dictionary<string, string> _headers = new();
    private TimeSpan? _timeout;

    public CustomCertificateHttpClient()
    {
        Handler = new();
    }

    public ICustomCertificateHttpClient AddCertificate(string filename)
    {
        _certificates.Add(LoadCertificateFromFile(filename));

        return this;
    }

    public ICustomCertificateHttpClient SetTimeout(TimeSpan timeout)
    {
        _timeout = timeout;

        return this;
    }

    public ICustomCertificateHttpClient AddDefaultHeader(string key, string value)
    {
        _headers.Add(key, value);

        return this;
    }

    public HttpClient Build()
    {
        if (_certificates.Any())
            Handler.ServerCertificateCustomValidationCallback = CertificateCallback;

        var client = new HttpClient(Handler);

        if (_timeout != null)
            client.Timeout = (TimeSpan)_timeout;

        foreach (var (key, value) in _headers)
            client.DefaultRequestHeaders.Add(key, value);

        return client;
    }

    /// <summary>
    /// Gets called when the <see cref="HttpClient"/> needs to validate a certificate.
    /// </summary>
    /// <param name="httpRequestMessage"></param>
    /// <param name="cert"></param>
    /// <param name="chain"></param>
    /// <param name="sslPolicyErrors"></param>
    /// <returns></returns>
    private bool CertificateCallback(HttpRequestMessage? httpRequestMessage, X509Certificate2? cert, X509Chain? chain, SslPolicyErrors sslPolicyErrors)
    {
        if (cert == null || chain == null)
            return false;

        chain.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;
        chain.ChainPolicy.CustomTrustStore.AddRange(_certificates);

        return chain.Build(cert);
    }

    /// <summary>
    /// Loads the certificate with the given filename from the Certificates folder.
    /// </summary>
    /// <param name="filename"></param>
    /// <returns></returns>
    private static X509Certificate2 LoadCertificateFromFile(string filename)
    {
        return new X509Certificate2(File.ReadAllBytes($"{AppDomain.CurrentDomain.BaseDirectory}/Certificates/{filename}"));
    }
}