﻿namespace CommerceUtils.Utils;

public interface ICustomCertificateHttpClient
{
    /// <summary>
    /// Adds a certificate to the HTTP Client.
    /// </summary>
    /// <param name="filename"></param>
    /// <returns></returns>
    public ICustomCertificateHttpClient AddCertificate(string filename);

    /// <summary>
    /// Sets the timeout for the request.
    /// </summary>
    /// <param name="timeout"></param>
    /// <returns></returns>
    public ICustomCertificateHttpClient SetTimeout(TimeSpan timeout);

    /// <summary>
    /// Adds a new default header to the HTTP client
    /// </summary>
    /// <param name="key"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public ICustomCertificateHttpClient AddDefaultHeader(string key, string value);

    /// <summary>
    /// Builds the custom HTTP Client.
    /// </summary>
    /// <returns></returns>
    public HttpClient Build();
}