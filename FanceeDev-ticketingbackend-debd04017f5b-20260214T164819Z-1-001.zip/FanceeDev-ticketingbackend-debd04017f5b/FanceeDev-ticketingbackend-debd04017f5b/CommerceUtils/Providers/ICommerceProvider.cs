﻿using CommerceUtils.Providers.Models;

namespace CommerceUtils.Providers;

public interface ICommerceProvider
{
    /// <summary>
    /// Gets the country code of which the implementation can be used.
    /// </summary>
    /// <returns></returns>
    public CountryCode SupportedCountry();

    /// <summary>
    /// Returns whether a connection can be made to the external API.
    /// </summary>
    /// <returns></returns>
    public Task<bool> ServiceHealthyAsync();

    /// <summary>
    /// Returns whether the given identifier is valid.
    /// </summary>
    /// <param name="identifier"></param>
    /// <returns></returns>
    public Task<bool> IsValidAsync(string identifier);

    /// <summary>
    /// Gets the info associated to the identifier.
    /// </summary>
    /// <param name="identifier"></param>
    /// <returns></returns>
    public Task<CompanyInfo?> InfoAsync(string identifier);
}