﻿#nullable enable

using System.Threading.Tasks;
using Fs.MessageBus.Models;

namespace WebApiCore.BackgroundTasks;

public interface IRpcMessageBus<in TMessage> : IMessageBusType where TMessage : IMessage
{
    bool IMessageBusType.IsRpc => true;

    public Task<IMessage> ProcessAsync(TMessage? message);
}