﻿namespace WebApiCore.BackgroundTasks;

public interface IMessageBusType
{
    public bool IsRpc { get; }
}