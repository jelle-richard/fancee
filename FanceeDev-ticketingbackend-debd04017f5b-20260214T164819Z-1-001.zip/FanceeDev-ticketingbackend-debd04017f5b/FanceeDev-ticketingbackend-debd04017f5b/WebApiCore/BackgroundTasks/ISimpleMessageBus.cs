﻿#nullable enable

using System.Threading.Tasks;
using Fs.MessageBus.Models;

namespace WebApiCore.BackgroundTasks;

public interface ISimpleMessageBus<in TMessage> : IMessageBusType where TMessage : IMessage
{
    bool IMessageBusType.IsRpc => false;

    public Task ProcessAsync(TMessage? message);
}