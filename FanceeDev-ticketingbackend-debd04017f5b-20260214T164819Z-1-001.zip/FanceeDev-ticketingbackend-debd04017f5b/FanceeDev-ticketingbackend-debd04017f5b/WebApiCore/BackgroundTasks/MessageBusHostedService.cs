#nullable enable

using System;
using System.Threading;
using System.Threading.Tasks;
using Fs.MessageBus.Models;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace WebApiCore.BackgroundTasks;

public abstract class MessageBusHostedService<TMessage, TImpl> : IHostedService
    where TMessage : IMessage
    where TImpl : MessageBusHostedService<TMessage, TImpl>, IMessageBusType
{
    protected abstract string LogPrefix { get; }

    protected IServiceProvider ServiceProvider { get; private set; }
    protected readonly ILogger<TImpl> Logger;

    private readonly IMessageSubscriber<TMessage> _subscriber;
    private readonly SemaphoreSlim _semaphoreSlim = new(1, 1);
    private readonly IServiceProvider _originalServiceProvider;

    protected MessageBusHostedService(IServiceProvider serviceProvider)
    {
        _originalServiceProvider = serviceProvider;
        ServiceProvider = serviceProvider.CreateScope().ServiceProvider;

        Logger = ServiceProvider.GetRequiredService<ILogger<TImpl>>();
        _subscriber = ServiceProvider.GetRequiredService<IMessageSubscriber<TMessage>>();
    }

    public virtual Task StartAsync(CancellationToken cancellationToken)
    {
        if (((IMessageBusType)this).IsRpc)
            _subscriber.Bind(HandleReceivedRpcMessage);
        else
            _subscriber.Bind(HandleReceivedMessage);

        Logger.LogInformation("{Prefix} Started", LogPrefix);

        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _subscriber.Unbind();

        Logger.LogInformation("{Prefix} Stopped", LogPrefix);

        return Task.CompletedTask;
    }

    /// <summary>
    /// Used for unit testing.
    /// </summary>
    public void UnitTestRegisterDependencies() => RegisterDependencies();

    /// <summary>
    /// Registers the required dependencies for the Listener.
    /// Will be called before each 'ProcessAsync' call.
    /// </summary>
    protected virtual void RegisterDependencies()
    {
    }

    private async Task HandleReceivedMessage(TMessage? message)
    {
        await _semaphoreSlim.WaitAsync();

        try
        {
            RegisterCleanDependencies();
            await ((ISimpleMessageBus<TMessage>)this).ProcessAsync(message);
        }
        finally
        {
            _semaphoreSlim.Release();
        }
    }

    private async Task<IMessage> HandleReceivedRpcMessage(TMessage? message)
    {
        await _semaphoreSlim.WaitAsync();

        try
        {
            RegisterCleanDependencies();
            return await ((IRpcMessageBus<TMessage>)this).ProcessAsync(message);
        }
        finally
        {
            _semaphoreSlim.Release();
        }
    }

    private void RegisterCleanDependencies()
    {
        ServiceProvider = _originalServiceProvider.CreateScope().ServiceProvider;
        RegisterDependencies();
    }
}