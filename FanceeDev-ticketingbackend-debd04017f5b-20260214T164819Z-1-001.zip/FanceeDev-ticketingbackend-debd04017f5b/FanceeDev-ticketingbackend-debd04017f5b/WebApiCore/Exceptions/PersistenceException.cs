﻿using System;

namespace WebApiCore.Exceptions;

/// <summary>
/// Used for throwing exceptions in the persistence layer
/// </summary>
public abstract class PersistenceException(string message) : Exception(message);