namespace WebApiCore.Exceptions;

public class CountryAccessRestrictedException()
    : ForbiddenApiException("Access to this country is restricted");