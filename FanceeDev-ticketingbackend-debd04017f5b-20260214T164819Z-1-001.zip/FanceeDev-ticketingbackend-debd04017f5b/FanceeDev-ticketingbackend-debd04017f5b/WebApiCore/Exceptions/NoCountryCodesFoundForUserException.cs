namespace WebApiCore.Exceptions;

public class NoCountryCodesFoundForUserException()
    : InternalServerErrorApiException("No valid country codes are found for this user");