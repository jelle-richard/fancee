﻿namespace WebApiCore.Exceptions;

public class InvalidUserTypeException()
    : ForbiddenApiException("The user is not of the correct type");