﻿namespace WebApiCore.Exceptions;

public class ApiRequestFailedException(string api)
    : ServiceUnavailableApiException($"The request to the API '{api}' failed");