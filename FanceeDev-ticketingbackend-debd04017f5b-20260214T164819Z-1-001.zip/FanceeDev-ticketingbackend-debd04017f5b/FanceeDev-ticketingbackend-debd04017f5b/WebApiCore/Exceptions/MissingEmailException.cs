namespace WebApiCore.Exceptions;

public class MissingEmailException()
    : BadRequestApiException("A supplied email was either null or empty");