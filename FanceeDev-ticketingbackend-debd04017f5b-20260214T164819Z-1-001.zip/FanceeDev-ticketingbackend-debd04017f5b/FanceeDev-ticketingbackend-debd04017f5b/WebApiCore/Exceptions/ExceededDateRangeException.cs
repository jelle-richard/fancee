namespace WebApiCore.Exceptions;

public class ExceededDateRangeException(int rangeSizeDays)
    : BadRequestApiException($"The maximum date range is {rangeSizeDays} days");