namespace WebApiCore.Exceptions;

public class InvalidOAuthCodeException()
    : ServiceUnavailableApiException("The OAuth code was invalid or has expired");