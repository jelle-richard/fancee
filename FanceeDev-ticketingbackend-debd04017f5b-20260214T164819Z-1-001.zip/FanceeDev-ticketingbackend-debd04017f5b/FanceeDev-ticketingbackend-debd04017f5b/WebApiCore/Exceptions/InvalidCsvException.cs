namespace WebApiCore.Exceptions;

public class InvalidCsvException(int fieldIndex, string fieldValue, string validationMessage, int row)
    : BadRequestApiException($"The field with index \'{fieldIndex}\' and value '{fieldValue}' on row {row} is invalid due to the following reason: '{validationMessage}'");