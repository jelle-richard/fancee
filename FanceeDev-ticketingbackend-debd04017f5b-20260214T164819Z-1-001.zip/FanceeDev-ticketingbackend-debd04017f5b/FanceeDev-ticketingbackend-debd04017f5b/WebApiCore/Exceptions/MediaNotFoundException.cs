﻿using WebApiCore.Utils;

namespace WebApiCore.Exceptions;

public class MediaNotFoundException()
    : NotFoundApiException("Media does not exist or belong to the authorized user", ErrorCode.ExceptionInvalidData);