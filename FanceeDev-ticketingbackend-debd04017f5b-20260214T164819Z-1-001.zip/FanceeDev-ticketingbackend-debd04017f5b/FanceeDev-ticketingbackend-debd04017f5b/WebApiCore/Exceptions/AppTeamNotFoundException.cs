namespace WebApiCore.Exceptions;

public class AppTeamNotFoundException()
    : NotFoundApiException("The app team either does not exist or is not owned by the organization");