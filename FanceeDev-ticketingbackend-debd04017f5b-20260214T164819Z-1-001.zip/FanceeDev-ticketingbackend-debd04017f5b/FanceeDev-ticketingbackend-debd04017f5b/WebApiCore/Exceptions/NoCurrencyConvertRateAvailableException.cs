namespace WebApiCore.Exceptions;

public class NoCurrencyConvertRateAvailableException(string currency)
    : NotFoundApiException($"No conversion information available for currency '{currency}'");