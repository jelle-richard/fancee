namespace WebApiCore.Exceptions;

public class CurrencyNotFoundException(string currency)
    : NotFoundApiException($"Currency with shortcode '{currency}' could not be found");