using WebApiCore.Utils;

namespace WebApiCore.Exceptions;

public class FeatureNotEnabledException(string featureName)
    : BadRequestApiException($"The feature '{featureName}' is not enabled for the user", ErrorCode.ExceptionFeatureNotEnabled);