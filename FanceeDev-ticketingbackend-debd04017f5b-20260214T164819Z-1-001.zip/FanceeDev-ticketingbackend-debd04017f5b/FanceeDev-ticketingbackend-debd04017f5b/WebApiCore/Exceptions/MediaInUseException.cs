using WebApiCore.Utils;

namespace WebApiCore.Exceptions;

public class MediaInUseException() :
    BadRequestApiException("Media cannot be modified as it is in use", ErrorCode.ExceptionObjectInUse);