namespace WebApiCore.Exceptions;

public class TooManyRequestsException()
    : TooManyRequestsApiException("Too many requests. Please try again later");