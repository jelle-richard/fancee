namespace WebApiCore.Exceptions;

public class InvalidDateRangeException()
    : BadRequestApiException("The provided date range is invalid");