﻿namespace WebApiCore.Exceptions;

public class InvalidApiKeyException()
    : ServiceUnavailableApiException("The provided API key is invalid");