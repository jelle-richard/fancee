using WebApiCore.Utils;

namespace WebApiCore.Exceptions;

public class SystemFeatureNotEnabledException(string featureName)
    : ForbiddenApiException($"The feature '{featureName}' is not enabled on the current environment", ErrorCode.ExceptionFeatureNotEnabled);