using System;
using System.Net;
using System.Net.Mime;
using WebApiCore.Utils;

namespace WebApiCore.Exceptions;

/// <summary>
/// Base exception class for TicketSwap exception conform the following spec:
/// https://ticketswap.notion.site/SecureSwap-error-codes-a977b8823d604b88aa81aca9471be95d
/// </summary>
public class TicketSwapException : Exception
{
    public HttpStatusCode StatusCode { get; set; }
    public string ContentType { get; set; } = MediaTypeNames.Application.Json;
    public bool Valid { get; set; }
    public bool Swappable { get; set; }
    public TicketSwapErrorCode ErrorCode { get; set; }

    protected TicketSwapException()
    {
    }

    protected TicketSwapException(string message) : base(message)
    {
    }
}