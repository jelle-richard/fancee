﻿using Microsoft.Extensions.Configuration;
using WebApiCore.Exceptions;

namespace WebApiCore.Settings;

#nullable enable

public class OrganizationDetailsSettings
{
    private const string OrganizationDetailsSectionName = "OrganizationDetails";

    public string Name { get; set; } = default!;
    public string PlatformName { get; set; } = default!;
    public string PlatformLogoUrl { get; set; } = default!;
    public string Website { get; set; } = default!;
    public string SignUpEmail { get; set; } = default!;
    public string FinanceEmail { get; set; } = default!;
    public string SupportEmail { get; set; } = default!;
    public string SupportPhoneNumber { get; set; } = default!;
    public string? ChamberOfCommerceIdentifier { get; set; }
    public string Iban { get; set; } = default!;
    public string? VatCode { get; set; }
    public AddressSettings Address { get; set; } = default!;
    public string PlatformBaseCurrency { get; set; } = default!;
    public SocialMedia Socials { get; set; } = new();
    public PackageConfigurations PackageSettings { get; set; } = new();

    public static OrganizationDetailsSettings FromConfiguration(IConfiguration configuration)
    {
        var model = new OrganizationDetailsSettings();
        var section = configuration.GetSection(OrganizationDetailsSectionName);

        if (!section.Exists())
            throw new MissingRequiredConfigurationEntryException(OrganizationDetailsSectionName);

        section.Bind(model);

        return model;
    }

    public class AddressSettings
    {
        public string Street { get; set; } = default!;
        public string HouseNumber { get; set; } = default!;
        public string PostalCode { get; set; } = default!;
        public string City { get; set; } = default!;
        public string CountryCode { get; set; } = default!;
    }

    public class SocialMedia
    {
        public string? FacebookUrl { get; set; }
        public string? TwitterUrl { get; set; }
        public string? InstagramUrl { get; set; }
    }

    public class PackageConfigurations
    {
        public PackageConfiguration Light { get; set; } = new();
        public PackageConfiguration Medium { get; set; } = new();
        public PackageConfiguration Custom { get; set; } = new();
    }

    public class PackageConfiguration
    {
        public int DefaultProductFeeCents { get; set; } = default!;
        public decimal DefaultProductFeePercentage { get; set; } = default!;
        public int DefaultTicketFeeCents { get; set; } = default!;
        public decimal DefaultTicketFeePercentage { get; set; } = default!;
        public int DefaultSeatedTicketFeeCents { get; set; } = default!;
        public decimal DefaultSeatedTicketFeePercentage { get; set; } = default!;
        public int? MinimumAnnualSalesAmount { get; set; }
        public int GuestListFeeCents { get; set; } = default!;
    }
}