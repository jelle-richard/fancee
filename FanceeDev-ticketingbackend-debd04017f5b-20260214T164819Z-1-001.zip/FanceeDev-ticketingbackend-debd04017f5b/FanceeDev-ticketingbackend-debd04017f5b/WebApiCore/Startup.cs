using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ViewRenderer;
using WebApiCore.Bootstrap.Conventions;
using WebApiCore.Bootstrap.Modules;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Middleware;
using WebApiCore.Persistence.CombinedShop;
using WebApiCore.Persistence.Contract;
using WebApiCore.Persistence.Country;
using WebApiCore.Persistence.CountryManager;
using WebApiCore.Persistence.Currency;
using WebApiCore.Persistence.DeploymentEnvironment;
using WebApiCore.Persistence.Discount;
using WebApiCore.Persistence.Logging;
using WebApiCore.Persistence.Order;
using WebApiCore.Persistence.PaymentMethod;
using WebApiCore.Persistence.Product;
using WebApiCore.Persistence.Profanity;
using WebApiCore.Persistence.Reservation;
using WebApiCore.Persistence.User;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.Contract;
using WebApiCore.Services.Country;
using WebApiCore.Services.CountryManager;
using WebApiCore.Services.Currency;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Discount;
using WebApiCore.Services.Logging;
using WebApiCore.Services.Organization;
using WebApiCore.Services.PaymentMethod;
using WebApiCore.Services.Profanity;
using WebApiCore.Services.User;
using WebApiCore.Settings;
using WebApiCore.Utils.Authorization;
using WebApiCore.Utils.Commerce;
using WebApiCore.Utils.Converter;
using WebApiCore.Utils.Http;
using WebApiCore.Utils.Validation;

namespace WebApiCore;

public class Startup(WebApplicationBuilder builder)
{
    public ConfigurationManager Configuration => builder.Configuration;
    public IWebHostEnvironment Environment => builder.Environment;
    public bool IsCiCd => builder.Configuration.GetValue<bool?>("CI_CD") == true;

    public event EventHandler<WebApplication> OnConfigureSignalREndpoints;
    public event EventHandler<IServiceCollection> OnConfigureServices;
    private const string ViesVatBaseUrl = "https://ec.europa.eu";

    public bool UseRabbitMq { get; set; } = true;
    public bool UseAuthenticationAndAuthorization { get; set; } = true;
    public bool UseRedis { get; set; } = true;
    public bool UseS3Storage { get; set; } = true;
    public bool UseSignalR { get; set; } = false;
    public bool UseSharedSettings { get; set; } = true;
    public SwaggerOptions SwaggerOptions { get; set; }
    public IEnumerable<JsonConverter> JsonConverters { get; set; } = Enumerable.Empty<JsonConverter>();

    public IEnumerable<IApplicationModelConvention> Conventions { get; } = new List<IApplicationModelConvention>
    {
        new RouteTokenTransformerConvention(new KebabParameterTransformer())
    };

    private readonly RollbarStartupModule _rollbarModule = new();

    private List<IStartupModule> _startupModules;

    /// <summary>
    /// Adds a new service.
    /// </summary>
    /// <param name="lifetime"></param>
    /// <typeparam name="TService"></typeparam>
    public void AddDependency<TService>(ServiceLifetime lifetime) where TService : class
    {
        if (lifetime == ServiceLifetime.Scoped)
            builder.Services.AddScoped<TService>();
        else if (lifetime == ServiceLifetime.Singleton)
            builder.Services.AddSingleton<TService>();
        else if (lifetime == ServiceLifetime.Transient)
            builder.Services.AddTransient<TService>();
    }

    /// <summary>
    /// Adds a new service.
    /// </summary>
    /// <typeparam name="TService"></typeparam>
    /// <typeparam name="TImplementation"></typeparam>
    /// <param name="lifetime"></param>
    public void AddDependency<TService, TImplementation>(ServiceLifetime lifetime)
        where TService : class where TImplementation : class, TService
    {
        if (lifetime == ServiceLifetime.Scoped)
            builder.Services.AddScoped<TService, TImplementation>();
        else if (lifetime == ServiceLifetime.Singleton)
            builder.Services.AddSingleton<TService, TImplementation>();
        else if (lifetime == ServiceLifetime.Transient)
            builder.Services.AddTransient<TService, TImplementation>();
    }

    /// <summary>
    /// Adds a new service.
    /// </summary>
    /// <typeparam name="TService"></typeparam>
    /// <param name="dependency"></param>
    /// <param name="lifetime"></param>
    public void AddDependency<TService>(Func<IServiceProvider, TService> dependency, ServiceLifetime lifetime)
        where TService : class
    {
        if (lifetime == ServiceLifetime.Scoped)
            builder.Services.AddScoped(dependency);
        else if (lifetime == ServiceLifetime.Singleton)
            builder.Services.AddSingleton(dependency);
        else if (lifetime == ServiceLifetime.Transient)
            builder.Services.AddTransient(dependency);
    }

    /// <summary>
    /// Adds a new hosted service.
    /// </summary>
    /// <typeparam name="THostedService"></typeparam>
    public void AddHostedService<THostedService>() where THostedService : class, IHostedService
    {
        if (IsCiCd)
            return;

        builder.Services.AddHostedService<THostedService>();
    }

    /// <summary>
    /// Configures the builder services and configures the WebApplication.
    /// Returns the built WebApplication instance.
    /// </summary>
    /// <returns></returns>
    public WebApplication Build()
    {
        _startupModules = new()
        {
            new CorsStartupModule(),
            new SwaggerStartupModule(SwaggerOptions, UseAuthenticationAndAuthorization),
            new SignalRStartupModule(UseSignalR),
            new S3StorageStartupModule(UseS3Storage, IsCiCd),
            new RedisStartupModule(UseRedis),
            new DatabaseStartupModule(),
            new MessageBrokerStartupModule(UseRabbitMq, IsCiCd),
            new AuthenticationAndAuthorizationStartupModule(UseAuthenticationAndAuthorization)
        };

        ConfigureSettings();
        ConfigureServices();

        var app = builder.Build();

        Configure(app);

        return app;
    }

    private void ConfigureSettings()
    {
        if (!UseSharedSettings)
            return;

        builder.WebHost.AddSharedSettings("sharedsettings.json");
    }

    private void Configure(WebApplication app)
    {
        _rollbarModule.Configure(app);

        app.UseForwardedHeaders();

        if (!app.Environment.IsProduction())
            app.UseDeveloperExceptionPage();

        app.UseRouting()
            .UseApiExceptionMiddleware();

        foreach (var startupModule in _startupModules)
        {
            if (startupModule is IConfigurableStartupModule configurableModule)
                configurableModule.Configure(app);
        }

        app.MapControllers();

        if (UseSignalR)
            OnConfigureSignalREndpoints?.Invoke(this, app);
    }

    private void ConfigureServices()
    {
        _rollbarModule.Build(builder);

        builder.Services.AddControllers(options =>
            {
                foreach (var convention in Conventions)
                    options.Conventions.Add(convention);
            })
            .AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new DateTimeConverter());
                options.JsonSerializerOptions.Converters.Add(new IpAddressConverter());

                foreach (var jsonConverter in JsonConverters)
                    options.JsonSerializerOptions.Converters.Add(jsonConverter);

                foreach (var startupModule in _startupModules)
                {
                    if (startupModule is IJsonSerializerModule jsonModule)
                        jsonModule.SetJsonSerializerOptions(options);
                }
            });

        ConfigureApiBehaviorOptions();
        builder.Services.AddHttpContextAccessor();

        foreach (var startupModule in _startupModules)
            startupModule.Build(builder);

        OnConfigureServices?.Invoke(this, builder.Services);

        ConfigureDependencies();
    }

    private void ConfigureApiBehaviorOptions()
    {
        builder.Services.Configure<ApiBehaviorOptions>(options =>
        {
            options.InvalidModelStateResponseFactory =
                actionContext => new BadRequestObjectResult(new ApiResponse<object>
                {
                    Data = null,
                    Errors = actionContext.ModelState.ToDictionaryList()
                });
        });
    }

    private void ConfigureDependencies()
    {
        builder.Services.AddViewRenderer();
        builder.Services.AddHttpClient();
        builder.Services.AddScoped<IJsonHttpClient, JsonHttpClient>();
        builder.Services.AddScoped<IDeploymentEnvironmentService, DeploymentEnvironmentService>();
        builder.Services.AddScoped<IDeploymentEnvironmentDao, DeploymentEnvironmentDao>();

        if (UseAuthenticationAndAuthorization)
            builder.Services.AddScoped<IAuthorizationHandler, PermissionAuthorizationHandler>();

        builder.Services.AddScoped<IUserDao, UserDao>();
        builder.Services.AddScoped<ICountryDao, CountryDao>();
        builder.Services.AddScoped<IUserService, UserService>();
        builder.Services.AddScoped<ICountryService, CountryService>();
        builder.Services.AddScoped<ICurrencyDao, CurrencyDao>();
        builder.Services.AddScoped<ICurrencyService, CurrencyService>();
        builder.Services.AddScoped<IOrganizationService, OrganizationService>();
        builder.Services.AddScoped<IOrganizationDao, OrganizationDao>();
        builder.Services.AddScoped<IOrderDao, OrderDao>();
        builder.Services.AddScoped<IProductDao, ProductDao>();
        builder.Services.AddScoped<ICountryManagerDao, CountryManagerDao>();
        builder.Services.AddScoped<ICountryManagerService, CountryManagerService>();
        builder.Services.AddScoped<IPaymentMethodService, PaymentMethodService>();
        builder.Services.AddScoped<IPaymentMethodDao, PaymentMethodDao>();
        builder.Services.AddScoped<IProfanityDao, ProfanityDao>();
        builder.Services.AddScoped<IProfanityService, ProfanityService>();
        builder.Services.AddScoped<IContractDao, ContractDao>();
        builder.Services.AddScoped<IOrganizationUserClaimService, OrganizationUserClaimService>();
        builder.Services.AddScoped<IOrganizationUserClaimDao, OrganizationUserClaimDao>();
        builder.Services.AddScoped<IContractService, ContractService>();
        builder.Services.AddScoped<IUserLoggingService, UserLoggingService>();
        builder.Services.AddScoped<IUserLoggingDao, UserLoggingDao>();
        builder.Services.AddScoped<IDiscountService, DiscountService>();
        builder.Services.AddScoped<IDiscountDao, DiscountDao>();
        builder.Services.AddScoped<IReservationDao, ReservationDao>();
        builder.Services.AddScoped<IVatValidator, VatValidator>();
        builder.Services.AddHttpClient("Vat", httpClient => { httpClient.BaseAddress = new(ViesVatBaseUrl); });
        builder.Services.AddScoped<ICombinedShopDao, CombinedShopDao>();

        builder.Services.AddRazorPages();
    }
}