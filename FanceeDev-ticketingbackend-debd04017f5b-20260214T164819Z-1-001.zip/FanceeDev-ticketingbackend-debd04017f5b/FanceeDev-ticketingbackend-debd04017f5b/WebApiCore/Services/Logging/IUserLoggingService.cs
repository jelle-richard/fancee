using System;
using System.Threading.Tasks;

namespace WebApiCore.Services.Logging;

public interface IUserLoggingService
{
    /// <summary>
    /// Saves an audit log record.
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="description"></param>
    public Task LogAsync(Guid userId, string description);
}