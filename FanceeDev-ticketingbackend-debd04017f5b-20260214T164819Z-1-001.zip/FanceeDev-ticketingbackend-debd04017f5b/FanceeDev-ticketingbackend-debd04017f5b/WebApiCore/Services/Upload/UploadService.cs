﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;
using WebApiCore.Persistence.File;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload.Exceptions;
using File = FanceeData.Models.Ticketing.File;

namespace WebApiCore.Services.Upload;

public class UploadService(IFileDao fileDao, IStorageService storageService, IDeploymentEnvironmentService deploymentEnvironmentService, ILogger<UploadService> logger)
    : IUploadService
{
    public async Task<UploadedFile> UploadAsync(UploadMediaRequest request, string pool, string folder, Func<File, Task> uploadedCallback)
    {
        await using var ms = new MemoryStream();
        await request.Media.CopyToAsync(ms);

        return await UploadAsync(ms, pool, folder, request.GetFileExtension(), request.GetMimeType(), true, uploadedCallback);
    }

    public async Task<UploadedFile> UploadAsync(Stream stream, string pool, string folder, string fileExtension, string mimeType, bool isPublic, Func<File, Task> uploadedCallback)
    {
        var environment = await deploymentEnvironmentService.GetAsync();

        return await UploadAsync(stream, pool, folder, fileExtension, mimeType, null, isPublic, environment, uploadedCallback);
    }

    public async Task<UploadedFile> UploadAsync(UploadMediaRequest request, string pool, string folder, string fileExtension, string mimeType, bool isPublic, Func<File, Task> uploadedCallback)
    {
        var environment = await deploymentEnvironmentService.GetAsync();

        await using var ms = new MemoryStream();
        await request.Media.CopyToAsync(ms);

        return await UploadAsync(ms, pool, folder, fileExtension, mimeType, null, isPublic, environment, uploadedCallback);
    }

    public async Task<UploadedFile> UploadAsync(UploadMediaRequest request, string pool, string folder, string fileExtension, string mimeType, string originalFileName, bool isPublic, Func<File, Task> uploadedCallback)
    {
        var environment = await deploymentEnvironmentService.GetAsync();

        await using var ms = new MemoryStream();
        await request.Media.CopyToAsync(ms);

        return await UploadAsync(ms, pool, folder, fileExtension, mimeType, originalFileName, isPublic, environment, uploadedCallback);
    }

    public async Task<UploadedFile> UploadAsync(Stream stream, string pool, string folder, string fileExtension,
        string mimeType, string originalFileName, bool isPublic, HostedDeploymentEnvironment environment,
        Func<File, Task> uploadedCallback)
    {
        string internalFileName;
        do
            internalFileName = Path.GetRandomFileName();
        while (await fileDao.FileNameExistsAsync(internalFileName));

        var path = string.IsNullOrEmpty(folder) ? string.Empty : $"{folder}/";
        var filePath = $"{path}{internalFileName}.{fileExtension}";

        try
        {
            await storageService.CreateStoragePoolAsync(pool, isPublic);
            await storageService.UploadFileAsync(pool, filePath, mimeType, stream);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to upload media: {Message}", ex.Message);

            throw new UploadFailedException();
        }

        var file = new File
        {
            Name = internalFileName,
            OriginalFileName = originalFileName,
            MimeType = mimeType,
            Path = Path.Combine("uploads", pool, filePath),
            DeploymentEnvironmentId = environment.Id
        };

        if (uploadedCallback != null)
            await uploadedCallback.Invoke(file);

        return new() { Id = file.Id, Url = $"{environment.Scheme}://{environment.Domain}/{file.Path.Replace("\\", "/")}" };
    }
}