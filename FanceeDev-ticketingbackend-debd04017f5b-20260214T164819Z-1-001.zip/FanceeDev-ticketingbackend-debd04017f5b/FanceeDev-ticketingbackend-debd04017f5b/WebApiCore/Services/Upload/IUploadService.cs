﻿using System;
using System.IO;
using System.Threading.Tasks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;
using File = FanceeData.Models.Ticketing.File;

namespace WebApiCore.Services.Upload;

public interface IUploadService
{
    /// <summary>
    /// Uploads media to the specified pool and folder.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="pool"></param>
    /// <param name="folder"></param>
    /// <param name="uploadedCallback">Gets called if the upload was successful with the newly created file.</param>
    /// <returns></returns>
    public Task<UploadedFile> UploadAsync(UploadMediaRequest request, string pool, string folder, Func<File, Task> uploadedCallback);

    /// <summary>
    /// Uploads media to the specified pool and folder.
    /// </summary>
    /// <param name="stream"></param>
    /// <param name="pool"></param>
    /// <param name="folder"></param>
    /// <param name="fileExtension"></param>
    /// <param name="mimeType"></param>
    /// <param name="isPublic"></param>
    /// <param name="uploadedCallback"></param>
    /// <returns></returns>
    public Task<UploadedFile> UploadAsync(Stream stream, string pool, string folder, string fileExtension, string mimeType, bool isPublic, Func<File, Task> uploadedCallback);

    /// <summary>
    /// Uploads media to the specified pool and folder.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="pool"></param>
    /// <param name="folder"></param>
    /// <param name="fileExtension"></param>
    /// <param name="mimeType"></param>
    /// <param name="isPublic"></param>
    /// <param name="uploadedCallback"></param>
    /// <returns></returns>
    public Task<UploadedFile> UploadAsync(UploadMediaRequest request, string pool, string folder, string fileExtension, string mimeType, bool isPublic, Func<File, Task> uploadedCallback);

    /// <summary>
    /// Uploads media to the specified pool and folder.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="pool"></param>
    /// <param name="folder"></param>
    /// <param name="fileExtension"></param>
    /// <param name="mimeType"></param>
    /// <param name="originalFileName"></param>
    /// <param name="isPublic"></param>
    /// <param name="uploadedCallback"></param>
    /// <returns></returns>
    public Task<UploadedFile> UploadAsync(UploadMediaRequest request, string pool, string folder, string fileExtension, string mimeType, string originalFileName, bool isPublic, Func<File, Task> uploadedCallback);

    /// <summary>
    /// Uploads media to the specified pool and folder.
    /// </summary>
    /// <param name="stream"></param>
    /// <param name="pool"></param>
    /// <param name="folder"></param>
    /// <param name="fileExtension"></param>
    /// <param name="mimeType"></param>
    /// <param name="originalFileName"></param>
    /// <param name="isPublic"></param>
    /// <param name="environment"></param>
    /// <param name="uploadedCallback"></param>
    /// <returns></returns>
    public Task<UploadedFile> UploadAsync(Stream stream, string pool, string folder, string fileExtension, string mimeType, string originalFileName, bool isPublic, HostedDeploymentEnvironment environment, Func<File, Task> uploadedCallback);
}