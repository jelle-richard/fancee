using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Dtos.Requests.Event;
using WebApiCore.Exceptions.Payment;
using WebApiCore.Persistence.PaymentMethod;

namespace WebApiCore.Services.PaymentMethod;

public class PaymentMethodService(IPaymentMethodDao paymentMethodDao) : IPaymentMethodService
{
    public void ValidatePaymentMethodAssignmentConfiguration(IEnumerable<PaymentMethodRequestModel> requestedMethods, IList<FanceeData.Models.Ticketing.PaymentMethod> paymentMethods)
    {
        requestedMethods = requestedMethods.ToList();

        if (paymentMethods.Count != requestedMethods.Count())
            throw new PaymentMethodNotFoundException();

        if (paymentMethods.GroupBy(pmv => pmv.Name).Any(pmv => pmv.Count() > 1))
            throw new InvalidPaymentMethodConfigurationException();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.PaymentMethod>> ByIdsAsync(IEnumerable<Guid> ids) =>
        await paymentMethodDao.ByIdsAsync(ids);
}