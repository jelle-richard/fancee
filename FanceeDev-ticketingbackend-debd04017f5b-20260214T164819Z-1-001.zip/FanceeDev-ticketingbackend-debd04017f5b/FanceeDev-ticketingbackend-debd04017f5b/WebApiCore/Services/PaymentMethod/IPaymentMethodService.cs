using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApiCore.Dtos.Requests.Event;

namespace WebApiCore.Services.PaymentMethod;

public interface IPaymentMethodService
{
    /// <summary>
    /// Validates if the requested payment methods adhere to the assignment configuration.
    /// </summary>
    /// <param name="requestedMethods"></param>
    /// <param name="paymentMethods"></param>
    public void ValidatePaymentMethodAssignmentConfiguration(IEnumerable<PaymentMethodRequestModel> requestedMethods, IList<FanceeData.Models.Ticketing.PaymentMethod> paymentMethods);

    /// <summary>
    /// Gets payment methods by ids.
    /// </summary>
    /// <param name="ids"></param>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.PaymentMethod>> ByIdsAsync(IEnumerable<Guid> ids);
}