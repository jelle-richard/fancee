using System;
using System.Threading.Tasks;
using WebApiCore.Persistence.User;

namespace WebApiCore.Services.User;

public class OrganizationUserClaimService(IOrganizationUserClaimDao organizationUserClaimDao) : IOrganizationUserClaimService
{
    public async Task<bool> HasPermissionAsync(Guid fanceeUsersId, Guid organizationId, string permission, bool ignoreCompletedProfile)
        => await organizationUserClaimDao.HasPermissionAsync(fanceeUsersId, organizationId, permission, ignoreCompletedProfile);
}