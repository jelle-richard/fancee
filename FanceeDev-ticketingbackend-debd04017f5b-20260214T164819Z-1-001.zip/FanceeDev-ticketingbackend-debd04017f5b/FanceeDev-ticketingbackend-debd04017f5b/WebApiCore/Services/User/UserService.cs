﻿using System;
using System.Threading.Tasks;
using WebApiCore.Persistence.User;

namespace WebApiCore.Services.User;

public class UserService(IUserDao userDao) : IUserService
{
    public async Task<bool> HasPermissionAsync(Guid fanceeUsersId, string permission, bool ignoreCompletedProfile)
        => await userDao.HasPermissionAsync(fanceeUsersId, permission, ignoreCompletedProfile);

    public async Task<bool> HasPermissionByUserIdAsync(Guid userId, string permission, bool ignoreCompletedProfile)
        => await userDao.HasPermissionByUserIdAsync(userId, permission, ignoreCompletedProfile);
}