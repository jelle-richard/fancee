using System;
using System.Threading.Tasks;

namespace WebApiCore.Services.User;

public interface IOrganizationUserClaimService
{
    /// <summary>
    /// Returns whether the user has permission.
    /// </summary>
    /// <param name="fanceeUsersId"></param>
    /// <param name="organizationId"></param>
    /// <param name="permission"></param>
    /// <param name="ignoreCompletedProfile"></param>
    /// <returns></returns>
    public Task<bool> HasPermissionAsync(Guid fanceeUsersId, Guid organizationId, string permission, bool ignoreCompletedProfile);
}