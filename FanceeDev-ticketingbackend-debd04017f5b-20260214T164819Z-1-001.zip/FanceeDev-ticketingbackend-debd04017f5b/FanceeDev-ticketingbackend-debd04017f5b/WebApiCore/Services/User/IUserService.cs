﻿using System;
using System.Threading.Tasks;

namespace WebApiCore.Services.User;

public interface IUserService
{
    /// <summary>
    /// Returns whether the user has permission.
    /// </summary>
    /// <param name="fanceeUsersId"></param>
    /// <param name="permission"></param>
    /// <param name="ignoreCompletedProfile"></param>
    /// <returns></returns>
    public Task<bool> HasPermissionAsync(Guid fanceeUsersId, string permission, bool ignoreCompletedProfile);

    /// <summary>
    /// Returns whether the user has permission.
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="permission"></param>
    /// <param name="ignoreCompletedProfile"></param>
    /// <returns></returns>
    public Task<bool> HasPermissionByUserIdAsync(Guid userId, string permission, bool ignoreCompletedProfile);
}