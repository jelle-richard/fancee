﻿using Fs.MessageBus.Publishers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using ViewRenderer;
using WebApiCore.MessageBus.Messages.Mail;
using WebApiCore.Services.Mail.Exceptions;

namespace WebApiCore.Services.Mail;

public class Mailer(IMessagePublisher<AddMailMessage> publisher, IObjectModelValidator validator, IViewRenderer viewRenderer) : IMailer
{
    public IViewRenderer ViewRenderer { get; } = viewRenderer;

    public void Send(Dtos.MailProvider.Mail mail)
    {
        var context = new ControllerContext();
        validator.Validate(context, null, string.Empty, mail);

        if (!context.ModelState.IsValid)
            throw new InvalidMailException(context.ModelState);

        publisher.Publish(new() { Mail = mail });
    }
}