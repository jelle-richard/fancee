﻿using ViewRenderer;

namespace WebApiCore.Services.Mail;

public interface IMailer
{
    public IViewRenderer ViewRenderer { get; }

    public void Send(Dtos.MailProvider.Mail mail);
}