using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebApiCore.Services.Profanity;

public interface IProfanityService
{
    /// <summary>
    /// Checks whether <paramref name="text" /> contains profanity.
    /// </summary>
    /// <param name="text"></param>
    /// <returns></returns>
    Task<bool> ContainsProfanityAsync(string text);

    /// <summary>
    /// Checks whether <paramref name="text" /> contains profanity.
    /// </summary>
    /// <param name="text"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    Task<bool> ContainsProfanityAsync(string text, string language);

    /// <summary>
    /// Gets a list of profanities found in <paramref name="text" />.
    /// </summary>
    /// <param name="text"></param>
    /// <returns></returns>
    Task<IList<FanceeData.Models.Ticketing.Profanity>> ListProfanitiesInTextAsync(string text);

    /// <summary>
    /// Gets a list of profanities found in <paramref name="text" />.
    /// </summary>
    /// <param name="text"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    Task<IList<FanceeData.Models.Ticketing.Profanity>> ListProfanitiesInTextAsync(string text, string language);

    /// <summary>
    /// Filters out profanities found in <paramref name="text" />
    /// </summary>
    /// <param name="text"></param>
    /// <returns></returns>
    Task<string> FilterProfanityAsync(string text);

    /// <summary>
    /// Filters out profanities found in <paramref name="text" />
    /// </summary>
    /// <param name="text"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    Task<string> FilterProfanityAsync(string text, string language);

    /// <summary>
    /// Filters out profanities found in <paramref name="texts" />
    /// </summary>
    /// <param name="texts"></param>
    /// <returns></returns>
    Task<IList<string>> FilterProfanityAsync(IEnumerable<string> texts);

    /// <summary>
    /// Filters out profanities found in <paramref name="texts" />
    /// </summary>
    /// <param name="texts"></param>
    /// <param name="language"></param>
    /// <returns></returns>
    Task<IList<string>> FilterProfanityAsync(IEnumerable<string> texts, string language);
}