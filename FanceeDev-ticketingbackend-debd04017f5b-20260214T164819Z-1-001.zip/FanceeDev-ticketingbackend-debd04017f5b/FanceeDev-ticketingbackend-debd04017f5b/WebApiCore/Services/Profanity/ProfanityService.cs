using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Persistence.Profanity;

namespace WebApiCore.Services.Profanity;

public class ProfanityService(IProfanityDao profanityDao) : IProfanityService
{
    private const string FallbackLanguage = "nl";

    public async Task<bool> ContainsProfanityAsync(string text)
        => await ContainsProfanityAsync(text, FallbackLanguage);

    public async Task<bool> ContainsProfanityAsync(string text, [MinLength(2)] [MaxLength(2)] string language)
        => await profanityDao.ContainsProfanityAsync(text, language);

    public async Task<IList<FanceeData.Models.Ticketing.Profanity>> ListProfanitiesInTextAsync(string text)
        => await ListProfanitiesInTextAsync(text, FallbackLanguage);

    public async Task<IList<FanceeData.Models.Ticketing.Profanity>> ListProfanitiesInTextAsync(string text, [MinLength(2)] [MaxLength(2)] string language)
        => await profanityDao.ListProfanitiesInTextAsync(text, language);

    public async Task<string> FilterProfanityAsync(string text, [MinLength(2)] [MaxLength(2)] string language)
        => await profanityDao.FilterProfanity(text, language);

    public async Task<IList<string>> FilterProfanityAsync(IEnumerable<string> texts, [MinLength(2)] [MaxLength(2)] string language)
    {
        var textList = texts.ToList();
        var profanities = await ListProfanitiesInTextAsync(string.Join(' ', textList), language);

        return textList.Select(text => profanities.Aggregate(text, (current, profanity) => current.Replace(profanity.Word, string.Empty, StringComparison.InvariantCultureIgnoreCase))).ToList();
    }

    public async Task<string> FilterProfanityAsync(string text)
        => await FilterProfanityAsync(text, FallbackLanguage);

    public async Task<IList<string>> FilterProfanityAsync(IEnumerable<string> texts)
        => await FilterProfanityAsync(texts, FallbackLanguage);
}