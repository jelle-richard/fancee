﻿using System.IO;
using System.Threading.Tasks;

namespace WebApiCore.Services.Storage;

public interface IStorageService
{
    public const string ProductMediaStoragePool = "products";
    public const string ShopMediaStoragePool = "shops";
    public const string PreRegisterMediaStoragePool = "preregisters";
    public const string PreRegisterHeaderMediaStoragePath = "headers";
    public const string ShopBackgroundMediaStoragePath = "backgrounds";
    public const string ShopHeaderMediaStoragePath = "headers";
    public const string InvoiceMediaStoragePool = "invoices";
    public const string ContractStoragePool = "contracts";
    public const string ContractAddendaStoragePool = "contractaddenda";
    public const string ReceiptMediaStoragePool = "receipts";
    public const string PayOutStoragePool = "payouts";
    public const string TicketPdfStoragePool = "ticketpdfs";
    public const string OrderReceiptPdfStoragePool = "orderreceiptpdfs";
    public const string OrganizationNoteStoragePool = "organizernotefiles"; // note: do not update the value to 'organization' as we need to move all existing files
    public const string UserAvatarStoragePool = "useravatars";
    public const string EventMediaStoragePool = "events";
    public const string TicketDesignMediaStoragePool = "ticketdesigns";

    public const int TicketPdfRetentionTimeMinutes = 15;
    public const int ReceiptPdfRetentionTimeInMinutes = 15;

    /// <summary>
    /// Uploads a file to the specified pool and file path.
    /// </summary>
    /// <param name="pool"></param>
    /// <param name="filePath"></param>
    /// <param name="contentType"></param>
    /// <param name="fileStream"></param>
    /// <returns></returns>
    public Task UploadFileAsync(string pool, string filePath, string contentType, Stream fileStream);

    /// <summary>
    /// Deletes a file from the given pool and file path.
    /// </summary>
    /// <param name="pool"></param>
    /// <param name="filePath"></param>
    /// <returns></returns>
    public Task DeleteFileAsync(string pool, string filePath);

    /// <summary>
    /// Downloads a file from the pool and file path.
    /// </summary>
    /// <param name="pool"></param>
    /// <param name="filePath"></param>
    /// <returns></returns>
    public Task<Stream> DownloadFileAsync(string pool, string filePath);

    /// <summary>
    /// Creates a new storage pool.
    /// </summary>
    /// <param name="name"></param>
    /// <param name="isPublic"></param>
    /// <returns></returns>
    public Task CreateStoragePoolAsync(string name, bool isPublic);
}