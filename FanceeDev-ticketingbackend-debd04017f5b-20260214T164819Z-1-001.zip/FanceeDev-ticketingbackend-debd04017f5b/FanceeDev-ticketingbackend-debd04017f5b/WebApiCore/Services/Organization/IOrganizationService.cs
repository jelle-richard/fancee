﻿using System;
using System.Threading.Tasks;

namespace WebApiCore.Services.Organization;

public interface IOrganizationService
{
    /// <summary>
    /// Gets the organization currency short code.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<string> CurrencyShortCodeAsync(Guid organizationId);

    /// <summary>
    /// Returns whether the wallet is enabled for the organization.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<bool> WalletEnabledAsync(Guid organizationId);

    /// <summary>
    /// Returns whether the organization is the owner of the given event.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> OwnerOfEventAsync(Guid organizationId, Guid eventId);

    /// <summary>
    /// Returns whether the organization is the owner of the given shop.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="shopCode"></param>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> OwnerOfShopAsync(Guid organizationId, string shopCode, Guid eventId);

    /// <summary>
    /// Gets the organization by its Id.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.Organization> ByIdForVatCalculationsAsync(Guid organizationId);

    /// <summary>
    /// Gets the organization by its id.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.Organization> ByIdAsync(Guid organizationId);

    /// <summary>
    /// Gets the VAT percentage for the organization by id.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<decimal> GetVatPercentageAsync(Guid organizationId);

    /// <summary>
    /// Gets the VAT percentage for the organization.
    /// </summary>
    /// <param name="organization"></param>
    /// <returns></returns>
    public decimal GetVatPercentageAsync(FanceeData.Models.Ticketing.Organization organization);

    /// <summary>
    /// Returns whether VAT should be calculated for the organization.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="platformCountryCode"></param>
    /// <returns></returns>
    public Task<bool> ShouldCalculateVatAsync(Guid organizationId, string platformCountryCode);
}