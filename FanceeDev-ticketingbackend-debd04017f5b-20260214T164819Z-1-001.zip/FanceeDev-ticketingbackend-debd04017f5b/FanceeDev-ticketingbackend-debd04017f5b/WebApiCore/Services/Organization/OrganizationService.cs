﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WebApiCore.Exceptions.Organization;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.Organization.Exceptions;

namespace WebApiCore.Services.Organization;

public class OrganizationService(IOrganizationDao organizationDao, IConfiguration configuration) : IOrganizationService
{
    private const string VatConfigSection = "Vat";
    private const string PercentageKey = "Percentage";
    private readonly Dictionary<Guid, decimal?> _cachedVatPercentages = new();

    public async Task<decimal> GetVatPercentageAsync(Guid organizationId)
    {
        var vat = RetrieveVatFromCache(organizationId);
        if (vat is not null)
            return (decimal)vat;

        var organization = await organizationDao.ByIdAsync(organizationId,
            q => q
                .Include(o => o.User.UserContactInfo.Address.CountryCodeNavigation)
        ) ?? throw new OrganizationNotFoundException();

        return GetVatPercentageAsync(organization);
    }

    public decimal GetVatPercentageAsync(FanceeData.Models.Ticketing.Organization organization)
    {
        var vat = RetrieveVatFromCache(organization.Id);
        if (vat is not null)
            return (decimal)vat;

        var country = organization.User.UserContactInfo.Address?.CountryCodeNavigation ?? throw new OrganizationAddressMissingException(organization.User.Email);

        var vatPercentage = country.CalculateVat ? configuration.GetValue<decimal>($"{VatConfigSection}:{PercentageKey}") : 0;

        _cachedVatPercentages.Add(organization.Id, vatPercentage);

        return vatPercentage;
    }

    public async Task<bool> ShouldCalculateVatAsync(Guid organizationId, string platformCountryCode) =>
        await organizationDao.ShouldCalculateVatAsync(organizationId, platformCountryCode);

    public async Task<string> CurrencyShortCodeAsync(Guid organizationId)
    {
        return await organizationDao.FieldAsync(organizationId, o => o.Currency) ?? throw new InvalidOrganizationException();
    }

    public async Task<bool> WalletEnabledAsync(Guid organizationId)
    {
        return await organizationDao.FieldAsync(organizationId, o => (bool?)o.WalletPayoutSettings.Enabled) ?? throw new InvalidOrganizationException();
    }

    public async Task<bool> OwnerOfEventAsync(Guid organizationId, Guid eventId) => await organizationDao.OwnerOfEventAsync(organizationId, eventId);

    public async Task<bool> OwnerOfShopAsync(Guid organizationId, string shopCode, Guid eventId) => await organizationDao.OwnerOfShopAsync(organizationId, shopCode, eventId);

    public async Task<FanceeData.Models.Ticketing.Organization> ByIdForVatCalculationsAsync(Guid organizationId) =>
        await organizationDao.ByIdAsync(organizationId,
            q => q
                .Include(o => o.User.UserContactInfo.Address.CountryCodeNavigation)
                .Include(o => o.PaymentSettings)
        ) ?? throw new OrganizationNotFoundException();

    public async Task<FanceeData.Models.Ticketing.Organization> ByIdAsync(Guid organizationId) => await organizationDao.ByIdAsync(organizationId) ?? throw new InvalidOrganizationException();

    private decimal? RetrieveVatFromCache(Guid organizationId)
    {
        _cachedVatPercentages.TryGetValue(organizationId, out var vat);
        return vat;
    }
}