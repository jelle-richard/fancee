using System.Security.Claims;
using FanceeData.Models.Ticketing;
using WebApiCore.Utils.HttpContext;

namespace WebApiCore.Utils;

public static class UserUtils
{
    /// <summary>
    /// Returns whether the user is an organization.
    /// </summary>
    /// <param name="userType"></param>
    /// <returns></returns>
    public static bool IsOrganization(this UserType userType) => userType.Is(UserType.Organization);

    /// <summary>
    /// Returns whether the user is an organization.
    /// </summary>
    /// <param name="user"></param>
    /// <returns></returns>
    public static bool IsOrganization(this User user) => user.Is(UserType.Organization);

    /// <summary>
    /// Returns whether the user is an organization.
    /// </summary>
    /// <param name="claimsPrincipal"></param>
    /// <returns></returns>
    public static bool IsOrganization(this ClaimsPrincipal claimsPrincipal) =>
        claimsPrincipal.GetUserType()?.Is(UserType.Organization) ?? false;

    /// <summary>
    /// Returns whether the user is an admin.
    /// </summary>
    /// <param name="userType"></param>
    /// <returns></returns>
    public static bool IsAdmin(this UserType userType) => userType.Is(UserType.Admin);

    /// <summary>
    /// Returns whether the user is an admin.
    /// </summary>
    /// <param name="claimsPrincipal"></param>
    /// <returns></returns>
    public static bool IsAdmin(this ClaimsPrincipal claimsPrincipal) =>
        claimsPrincipal.GetUserType()?.Is(UserType.Admin) ?? false;

    /// <summary>
    /// Returns whether the user is a client.
    /// </summary>
    /// <param name="userType"></param>
    /// <returns></returns>
    public static bool IsClient(this UserType userType) => userType.Is(UserType.Client);

    /// <summary>
    /// Returns whether the user is a client.
    /// </summary>
    /// <param name="claimsPrincipal"></param>
    /// <returns></returns>
    public static bool IsClient(this ClaimsPrincipal claimsPrincipal) =>
        claimsPrincipal.GetUserType()?.Is(UserType.Client) ?? false;

    /// <summary>
    /// Returns whether the user is a <see cref="UserType" />.
    /// </summary>
    /// <param name="user"></param>
    /// <param name="userType"></param>
    /// <returns></returns>
    private static bool Is(this User user, UserType userType) => user.Type.HasFlag(userType);

    /// <summary>
    /// Returns whether the user is a <see cref="UserType" />.
    /// </summary>
    /// <param name="user"></param>
    /// <param name="userType"></param>
    /// <returns></returns>
    private static bool Is(this UserType user, UserType userType) => user.HasFlag(userType);
}