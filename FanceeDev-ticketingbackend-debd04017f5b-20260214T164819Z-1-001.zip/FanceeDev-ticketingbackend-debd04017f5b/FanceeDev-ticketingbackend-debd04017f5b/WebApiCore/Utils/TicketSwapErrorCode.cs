using System.Runtime.Serialization;

namespace WebApiCore.Utils;

public enum TicketSwapErrorCode
{
    [EnumMember(Value = "RESELL_NOT_ALLOWED")]
    ResellNotAllowed,
    [EnumMember(Value = "UNAUTHORIZED")] 
    Unauthorized,
    [EnumMember(Value = "TICKET_NOT_FOUND")]
    TicketNotFound,
    [EnumMember(Value = "TICKET_ALREADY_SWAPPED")]
    TicketAlreadySwapped,
    [EnumMember(Value = "TICKET_ALREADY_SCANNED")]
    TicketAlreadyScanned,
    [EnumMember(Value = "ORDER_CANCELLED")]
    OrderCancelled
}