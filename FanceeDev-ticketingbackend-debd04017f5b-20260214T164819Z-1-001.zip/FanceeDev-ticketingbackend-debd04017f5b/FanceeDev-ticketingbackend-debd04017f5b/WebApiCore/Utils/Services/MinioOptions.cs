﻿using System;
using Amazon;

namespace WebApiCore.Utils.Services;

public class MinioOptions
{
    public string Endpoint { get; set; }
    public string AccessKey { get; set; }
    public string SecretKey { get; set; }
    public string Region { get; set; } = string.Empty;

    public static MinioOptions FromConnectionString(string connectionString)
    {
        if (string.IsNullOrWhiteSpace(connectionString))
            return null;

        var parts = connectionString.Split(';', 4, StringSplitOptions.RemoveEmptyEntries);

        if (parts.Length != 3 && parts.Length != 4)
            return null;

        if (parts.Length == 3)
        {
            return new()
            {
                Endpoint = parts[0],
                Region = RegionEndpoint.EUCentral1.SystemName,
                AccessKey = parts[1],
                SecretKey = parts[2]
            };
        }

        return new()
        {
            Endpoint = parts[0],
            Region = parts[1],
            AccessKey = parts[2],
            SecretKey = parts[3]
        };
    }
}