﻿using Amazon.Runtime;
using Amazon.S3;
using Microsoft.Extensions.DependencyInjection;

namespace WebApiCore.Utils.Services;

internal static class MinioServiceExtensions
{
    internal static IServiceCollection AddMinio(this IServiceCollection services, MinioOptions options)
    {
        var client = new AmazonS3Client(new BasicAWSCredentials(options.AccessKey, options.SecretKey), new AmazonS3Config
        {
            AuthenticationRegion = options.Region,
            ServiceURL = options.Endpoint,
            ForcePathStyle = true
        });

        return services.AddSingleton<IAmazonS3>(client);
    }
}