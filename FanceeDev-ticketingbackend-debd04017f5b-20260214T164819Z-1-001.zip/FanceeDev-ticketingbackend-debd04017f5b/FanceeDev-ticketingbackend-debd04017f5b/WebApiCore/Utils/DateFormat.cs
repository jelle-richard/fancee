namespace WebApiCore.Utils;

/// <summary>
/// Contains commonly used date formats.
/// </summary>
public static class DateFormat
{
    public const string YearMonthDayHourMinuteSecond = "yyyy-MM-dd HH:mm:ss";
    public const string DefaultApiResponse = YearMonthDayHourMinuteSecond;
    public const string DayMonthYearHourMinute = "dd-MM-yyyy HH:mm";
    public const string DayMonthYear = "dd-MM-yyyy";
    public const string DayMonthYearWrittenEnglish = "MMM/dd/yyyy";
    public const string DayMonthYearHourMinuteWrittenEnglish = "MMM/dd/yyyy HH:mm";
    public const string DayMonthYearWrittenDutch = "dd-MMM-yyyy";
    public const string DayMonthYearHourMinuteWrittenDutch = "dd-MMM-yyyy HH:mm";
    public const string YearMonthDay = "yyyy-MM-dd";
    public const string YearMonth = "yyyy-MM";
    public const string HourMinute = "HH:mm";
    public const string Invoice = "MMMM dd, yyyy";
}