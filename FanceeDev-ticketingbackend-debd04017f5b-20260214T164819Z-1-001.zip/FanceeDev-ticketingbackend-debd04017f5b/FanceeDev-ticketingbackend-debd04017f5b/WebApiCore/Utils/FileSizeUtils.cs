namespace WebApiCore.Utils;

public static class FileSizeUtils
{
    public const int Kilobyte = 1024;
    public const int Megabyte = Kilobyte * 1024;
    public const long Gigabyte = Megabyte * 1024;
}