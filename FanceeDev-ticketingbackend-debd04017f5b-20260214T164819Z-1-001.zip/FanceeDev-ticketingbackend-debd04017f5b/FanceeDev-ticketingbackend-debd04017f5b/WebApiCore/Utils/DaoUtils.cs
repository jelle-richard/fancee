using System;
using System.Collections.Generic;
using WebApiCore.Dtos.Shared;

namespace WebApiCore.Utils;

public static class DaoUtils
{
    /// <summary>
    /// Builds a list of <see cref="TModel" /> for each date in the start-end range.
    /// </summary>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="setEndOfDay"></param>
    /// <typeparam name="TModel"></typeparam>
    /// <returns></returns>
    public static IEnumerable<TModel> BuildDateRange<TModel>(DateTime startDate, DateTime endDate, bool setEndOfDay = false) where TModel : IDailyDto, new()
    {
        var diff = endDate - startDate;

        for (var i = 0; i <= diff.Days; i++)
        {
            var newStartDate = setEndOfDay
                ? startDate.SetEndOfDay(i)
                : startDate.AddDays(i);

            yield return new() { Date = newStartDate };
        }
    }
}