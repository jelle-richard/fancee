namespace WebApiCore.Utils;

public static class CacheKeys
{
    public const string PlatformBaseCurrency = "platform-base-currency";
    public const string ActiveCurrencies = "active-currencies";
    public const string CountryCodes = "country-codes";
    public const string ReceivedBalance = "received-balance";
    public const string RevenueBalance = "revenue-balance";
    public const string NonDemoOrganizationIds = "non-demo-organization-ids";
    public static readonly string EventBalanceMutations = "event-balance-mutations";

    public static string CombinedShop(string code) => $"combined-{code}";
}