#nullable enable

using System;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using WebApiCore.Exceptions.Organization;
using WebApiCore.Utils.HttpContext;

namespace WebApiCore.Utils;

public static class RequestUtils
{
    public const string Basic = "Basic";
    internal const string OrganizationIdHeader = "X-Organization-Id";

    /// <summary>
    /// Reads the request body and returns the raw string.
    /// </summary>
    /// <returns></returns>
    public static async Task<string> ReadRawRequestAsync(this HttpRequest request)
    {
        using var reader = new StreamReader(request.Body, Encoding.UTF8);

        return await reader.ReadToEndAsync();
    }

    /// <summary>
    /// Checks if the headers contain a valid Basic authorization header.
    /// </summary>
    /// <param name="headers"></param>
    /// <param name="username"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    public static bool ValidBasicAuthorization(this IHeaderDictionary headers, string username, string password)
    {
        if (!headers.TryGetValue(HeaderNames.Authorization, out var authHeaders))
            return false;

        var authHeader = authHeaders.FirstOrDefault();

        if (string.IsNullOrWhiteSpace(authHeader))
            return false;

        var encodedUsernamePassword = authHeader[Basic.Length..].Trim();

        if (string.IsNullOrWhiteSpace(encodedUsernamePassword))
            return false;

        var encoding = Encoding.GetEncoding("iso-8859-1");
        var usernamePassword = encoding.GetString(Convert.FromBase64String(encodedUsernamePassword));
        var separatorIndex = usernamePassword.IndexOf(':');

        var tokenUsername = usernamePassword[..separatorIndex];
        var tokenPassword = usernamePassword[(separatorIndex + 1)..];

        return tokenUsername == username && tokenPassword == password;
    }

    /// <summary>
    /// Gets the organization id from the request headers.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    /// <exception cref="UnauthorizedOrganizationException"></exception>
    public static Guid GetOrganizationId(this HttpRequest request)
    {
        if (request.Headers.TryGetValue(OrganizationIdHeader, out var header) && Guid.TryParse(header.FirstOrDefault(), out var id))
            return id;

        throw new UnauthorizedOrganizationException();
    }

    public static Guid? TryGetUserId(this ClaimsPrincipal claimsPrincipal) => TryGetGuid(claimsPrincipal.GetUserId);

    public static Guid? TryGetOrganizationId(this HttpRequest httpRequest) => TryGetGuid(httpRequest.GetOrganizationId);

    /// <summary>
    /// Tries to get the User-Agent (or X-Forwarded-User-Agent as fallback) header from the request.
    /// </summary>
    /// <param name="httpContext"></param>
    /// <returns></returns>
    public static string? TryGetUserAgent(this Microsoft.AspNetCore.Http.HttpContext? httpContext)
    {
        if (httpContext == null)
            return null;

        return TryGetHeader("User-Agent", httpContext.Request.Headers) ??
               TryGetHeader("X-Forwarded-User-Agent", httpContext.Request.Headers);
    }

    private static string? TryGetHeader(string header, IHeaderDictionary headers) =>
        headers.TryGetValue(header, out var headerValues)
            ? headerValues.FirstOrDefault()
            : null;

    /// <summary>
    /// Tries to execute the given method that returns a guid.
    /// Caught exceptions will cause null to be returned.
    /// </summary>
    /// <param name="method"></param>
    /// <returns></returns>
    private static Guid? TryGetGuid(Func<Guid> method)
    {
        try
        {
            return method();
        }
        catch
        {
            return null;
        }
    }
}