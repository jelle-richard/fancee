using System.Threading.Tasks;

namespace WebApiCore.Utils.Commerce;

public interface IVatValidator
{
    /// <summary>
    /// Validates a VAT code.
    /// </summary>
    /// <param name="vatCode"></param>
    /// <returns></returns>
    public Task<bool> IsVatCodeValidAsync(string vatCode);

    /// <summary>
    /// Converts a country code to the VAT-variant of a country code.
    /// </summary>
    /// <param name="countryCode"></param>
    /// <returns></returns>
    public string ConvertCountryCodeToVatCode(string countryCode);
}