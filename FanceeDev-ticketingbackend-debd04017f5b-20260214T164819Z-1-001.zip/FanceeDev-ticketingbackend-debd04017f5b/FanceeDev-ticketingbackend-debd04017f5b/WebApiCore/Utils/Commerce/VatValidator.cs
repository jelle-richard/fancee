using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using WebApiCore.Dtos.Shared;

namespace WebApiCore.Utils.Commerce;

public class VatValidator : IVatValidator
{
    private const string XmlMediaType = "text/xml";
    private const string Valid = "<ns2:valid>true</ns2:valid>";
    private const string VatPlaceholder = "VATPLACEHOLDER";
    private const string CountryCodePlaceholder = "COUNTRYCODEPLACEHOLDER";

    private const string ViesFormat =
        $"""
             <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
                 <soapenv:Header/>
                 <soapenv:Body>
                     <ns2:checkVat xmlns:ns2="urn:ec.europa.eu:taxud:vies:services:checkVat:types">
                     <ns2:countryCode>{CountryCodePlaceholder}</ns2:countryCode>
                     <ns2:vatNumber>{VatPlaceholder}</ns2:vatNumber>
                     </ns2:checkVat>
                 </soapenv:Body>
             </soapenv:Envelope>
         """;

    private static readonly Dictionary<CountryCode, string> CountryCodeDivergentVatCountryCode = new()
    {
        { CountryCode.GR, "EL" },
        { CountryCode.IE, "XI" }
    };

    private readonly HttpClient _httpClient;

    public VatValidator(IHttpClientFactory httpClientFactory)
    {
        _httpClient = httpClientFactory.CreateClient("Vat");
    }

    public async Task<bool> IsVatCodeValidAsync(string vatCode)
    {
        var countryCode = vatCode[..2];
        var vatCodeWithoutCountryCode = vatCode.Substring(2, vatCode.Length - 2);

        if (!IsValidEuropeanVatCode(countryCode))
            return false;

        _httpClient.DefaultRequestHeaders.Accept.Add(new(XmlMediaType));

        var format = ViesFormat.Replace(VatPlaceholder, vatCodeWithoutCountryCode);
        format = format.Replace(CountryCodePlaceholder, countryCode);

        var requestMessage = new HttpRequestMessage(HttpMethod.Post, "/taxation_customs/vies/services/checkVatService");
        requestMessage.Content = new StringContent(format);

        requestMessage.Content.Headers.ContentType = new(XmlMediaType);
        requestMessage.Headers.Add("SOAPAction", string.Empty);

        var responseMessage = await _httpClient.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead).ConfigureAwait(false);
        responseMessage.EnsureSuccessStatusCode();

        var responseContent = await responseMessage.Content.ReadAsStringAsync().ConfigureAwait(false);

        return responseContent.Contains(Valid);
    }

    public string ConvertCountryCodeToVatCode(string countryCode) =>
        CountryCodeDivergentVatCountryCode.GetValueOrDefault(Enum.Parse<CountryCode>(countryCode), countryCode);

    private static bool IsValidEuropeanVatCode(string countryCode) => Enum.TryParse<VatCountryPrefixes>(countryCode, out var _);
}