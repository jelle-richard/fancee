﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mime;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Rollbar;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions;
using WebApiCore.Utils;
using WebApiCore.Utils.Reflection;

namespace WebApiCore.Middleware;

public class ApiExceptionMiddleware(RequestDelegate next, IHostEnvironment environment, ILogger<ApiExceptionMiddleware> logger)
{
    public const string UnitTestExceptionMessage = "UnitTestMessage";

    public async Task Invoke(HttpContext httpContext)
    {
        try
        {
            await next(httpContext);
        }
        catch (ApiException ex)
        {
            if (httpContext.Response.HasStarted)
                throw;

            if (environment.IsProduction() && ex.StatusCode == HttpStatusCode.BadRequest && ex.Message != UnitTestExceptionMessage)
                LogRollbarError(ex, httpContext);

            var response = new ApiResponse<object>();
            response.AddError(ex.ErrorCode, ex.Message);

            await SendErrorAsync(httpContext, response, (int)ex.StatusCode, ex.ContentType, typeof(ApiResponse<object>));
        }
        catch (TicketSwapException ex)
        {
            if (httpContext.Response.HasStarted)
                throw;

            if (environment.IsProduction() && ex.StatusCode == HttpStatusCode.BadRequest && ex.Message != UnitTestExceptionMessage)
                LogRollbarError(ex, httpContext);

            var response = new TicketSwapErrorResponse
            {
                Swappable = ex.Swappable,
                Valid = ex.Valid,
                Error = ex.ErrorCode.GetEnumMemberValue()
            };

            await SendErrorAsync(httpContext, response, (int)ex.StatusCode, ex.ContentType, typeof(TicketSwapErrorResponse));
        }
        catch (Exception ex)
        {
            if (httpContext.Response.HasStarted)
                throw;

            var errorMessage = "Internal server error has occurred. Please try again later.";
            if (!environment.IsProduction())
                errorMessage = $"EXCEPTION ({ex.Source}): {ex.Message}";

            logger.LogError(ex, "An unknown error has occured. See details for more info");

            var response = new ApiResponse<object>();
            response.AddError(ErrorCode.ExceptionExternalService, errorMessage);

            await SendErrorAsync(httpContext, response, (int)HttpStatusCode.InternalServerError, MediaTypeNames.Application.Json, typeof(ApiResponse<object>));
        }
    }

    private static void LogRollbarError(Exception ex, HttpContext httpContext)
    {
        RollbarLocator.RollbarInstance.Error(ex, new Dictionary<string, object>
        {
            { "method", httpContext.Request.Method },
            { "scheme", httpContext.Request.Scheme },
            { "path", httpContext.Request.Path.ToString() },
            { "querystring", httpContext.Request.QueryString.ToString() },
            { "headers", httpContext.Request.Headers }
        });
    }

    private static async Task SendErrorAsync(HttpContext httpContext, IResponse response, int statusCode, string contentType, Type responseType)
    {
        httpContext.Response.Clear();
        httpContext.Response.StatusCode = statusCode;
        httpContext.Response.ContentType = contentType;

        await httpContext.Response.WriteAsync(JsonSerializer.Serialize(response, responseType, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            Converters = { new JsonStringEnumConverter() }
        }));
    }
}

/// <summary>
/// Extension method used to add the middleware to the HTTP request pipeline.
/// </summary>
public static class ApiExceptionMiddlewareExtensions
{
    public static IApplicationBuilder UseApiExceptionMiddleware(this IApplicationBuilder builder) => builder.UseMiddleware<ApiExceptionMiddleware>();
}