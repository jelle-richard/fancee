namespace WebApiCore.Dtos;

public enum SynchronisationType
{
    FetchNewlyCreated = 0,
    ValidateExistingAndOrUpdate = 1
}