namespace WebApiCore.Dtos;

public enum TicketingDataType
{
    Clients = 0,
    Events = 1,
    Orders = 2
}