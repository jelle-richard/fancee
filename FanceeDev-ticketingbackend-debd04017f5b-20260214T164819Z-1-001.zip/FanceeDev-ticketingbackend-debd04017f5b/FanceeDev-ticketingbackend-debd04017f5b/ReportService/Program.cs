using ReportService.Persistence.Report;
using ReportService.Persistence.Revenue;
using ReportService.Persistence.System;
using ReportService.Persistence.Ticket;
using ReportService.Services.Report;
using ReportService.Services.Revenue;
using ReportService.Services.System;
using WebApiCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "ReportService",
        EndpointName = "ReportService v1"
    },
    UseS3Storage = false,
    UseRabbitMq = true,
    UseAuthenticationAndAuthorization = true
};

builder.AddDependency<IReportService, ReportService.Services.Report.ReportService>(ServiceLifetime.Scoped);
builder.AddDependency<IReportDao, ReportDao>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketDao, TicketDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISystemService, SystemService>(ServiceLifetime.Scoped);
builder.AddDependency<ISystemDao, SystemDao>(ServiceLifetime.Scoped);
builder.AddDependency<IRevenueService, RevenueService>(ServiceLifetime.Scoped);
builder.AddDependency<IRevenueDao, RevenueDao>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();