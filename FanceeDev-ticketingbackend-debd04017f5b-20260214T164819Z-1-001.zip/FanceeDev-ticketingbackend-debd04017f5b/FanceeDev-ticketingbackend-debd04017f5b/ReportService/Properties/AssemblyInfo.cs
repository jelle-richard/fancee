﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ReportService.Tests")]