﻿using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using CommerceUtils.Utils;

namespace CommerceUtils.Tests.Utils;

public class CustomCertificateHttpClientTests
{
    private const string CertificateFilename = "Staat_der_Nederlanden_Private_Root_CA_-_G1.cer";

    private readonly UnitHttpClient _sut;

    public CustomCertificateHttpClientTests()
    {
        _sut = new();
    }

    [Fact]
    public void TestThatSetTimeoutSetsTheTimeoutForHttpClient()
    {
        var actual = _sut.SetTimeout(TimeSpan.FromSeconds(12))
            .Build();

        Assert.NotNull(actual);
        Assert.Equal(TimeSpan.FromSeconds(12), actual.Timeout);
    }

    [Fact]
    public void TestThatAddCertificateAddsCertificate()
    {
        var actual = (UnitHttpClient)_sut.AddCertificate(CertificateFilename);

        actual.Build();

        Assert.NotNull(actual.GetHandler().ServerCertificateCustomValidationCallback);
    }

    [Fact]
    public void TestThatCertificateCallbackReturnsFalseOnNullValues()
    {
        var builder = (UnitHttpClient)_sut.AddCertificate(CertificateFilename);

        builder.Build();

        var actual = builder.GetHandler().ServerCertificateCustomValidationCallback?.Invoke(null!, null, null, SslPolicyErrors.RemoteCertificateNotAvailable);

        Assert.False(actual);
    }

    [Fact]
    public void TestThatCertificateCallbackAddsCertificates()
    {
        var cert = new X509Certificate2(File.ReadAllBytes($"{AppDomain.CurrentDomain.BaseDirectory}/Certificates/{CertificateFilename}"));
        var chain = new X509Chain();

        var builder = (UnitHttpClient)_sut.AddCertificate(CertificateFilename);

        builder.Build();

        var actual = builder.GetHandler().ServerCertificateCustomValidationCallback?.Invoke(null!, cert, chain, SslPolicyErrors.RemoteCertificateNotAvailable);

        Assert.True(actual);

        Assert.Equal(X509ChainTrustMode.CustomRootTrust, chain.ChainPolicy.TrustMode);
        Assert.Single(chain.ChainPolicy.CustomTrustStore);
    }

    [Fact]
    public void TestThatAddDefaultHeaderAddsHeaderToRequest()
    {
        var actual = _sut.AddDefaultHeader("apikey", "testvalue")
            .Build();

        Assert.Single(actual.DefaultRequestHeaders);
        Assert.Equal("apikey", actual.DefaultRequestHeaders.First().Key);
        Assert.Equal("testvalue", actual.DefaultRequestHeaders.First().Value.First());
    }

    #region Unit test classes

    public class UnitHttpClient : CustomCertificateHttpClient
    {
        public HttpClientHandler GetHandler() => Handler;
    }

    #endregion
}