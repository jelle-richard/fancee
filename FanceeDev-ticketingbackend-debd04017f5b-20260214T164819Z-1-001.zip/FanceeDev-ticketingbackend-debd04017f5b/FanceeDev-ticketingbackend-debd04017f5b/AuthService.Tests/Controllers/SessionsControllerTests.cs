﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AuthService.Controllers;
using AuthService.Dtos.Responses.Sessions;
using AuthService.Services.Auth;
using AuthService.Services.User;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;

namespace AuthService.Tests.Controllers;

public class SessionsControllerTests
{
    private static readonly Guid ValidClientId = Guid.NewGuid();

    private readonly SessionsController _sut;
    private readonly Mock<IAuthService> _mockedAuthService = new();
    private readonly Mock<IUserService> _mockedUserService = new();

    public SessionsControllerTests()
    {
        _sut = new(_mockedAuthService.Object, _mockedUserService.Object);

        _sut.SetupHttpContext(fanceeUsersId: ValidClientId, userType: UserType.Client.ToString());
    }

    [Fact]
    public async Task TestThatGetSessionsCallsAuthServiceSessionsAsync()
    {
        _mockedAuthService.Setup(@as => @as.ValidSessionsAsync(ValidClientId)).ReturnsAsync(new List<SessionResponse>());

        var actual = await _sut.GetSessions();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<SessionResponse>>>(((OkObjectResult)actual.Result).Value);

        _mockedAuthService.Verify(@as => @as.ValidSessionsAsync(ValidClientId), Times.Once);
    }

    [Fact]
    public async Task TestThatGetUserSessionsCallsAuthServiceSessionsAsync()
    {
        var userId = Guid.NewGuid();
        var fanceeUsersId = Guid.NewGuid();

        _mockedUserService.Setup(us => us.FanceeUsersIdAsync(userId)).ReturnsAsync(fanceeUsersId);
        _mockedAuthService.Setup(@as => @as.ValidSessionsAsync(userId)).ReturnsAsync(new List<SessionResponse>());

        var actual = await _sut.GetUserSessions(userId);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<SessionResponse>>>(((OkObjectResult)actual.Result).Value);

        _mockedUserService.Verify(us => us.FanceeUsersIdAsync(userId), Times.Once);
        _mockedAuthService.Verify(@as => @as.ValidSessionsAsync(fanceeUsersId), Times.Once);
    }
}