﻿using System;
using System.Threading.Tasks;
using AuthService.Controllers;
using AuthService.Services.Auth;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;

namespace AuthService.Tests.Controllers;

public class SessionControllerTests
{
    private readonly SessionController _sut;
    private readonly Mock<IAuthService> _mockedAuthService = new();

    public SessionControllerTests()
    {
        _sut = new(_mockedAuthService.Object);
    }

    [Fact]
    public async Task TestThatDeleteSessionCallsAuthServiceInvalidateAsync()
    {
        var actual = await _sut.DeleteSession("token");

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedAuthService.Verify(@as => @as.InvalidateAsync("token"), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteUserSessionCallsAuthServiceInvalidateByAdminAsync()
    {
        var userId = Guid.NewGuid();

        var actual = await _sut.DeleteUserSession(userId, "token");

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedAuthService.Verify(@as => @as.InvalidateByAdminAsync("token", userId), Times.Once);
    }
}