using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AuthService.Controllers;
using AuthService.Services.Claims;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses.Claim;

namespace AuthService.Tests.Controllers;

public class ClaimsControllerTests
{
    private static readonly Guid ValidUserId = Guid.NewGuid();
    private static readonly Guid ValidAppTeamId = Guid.NewGuid();

    private readonly ClaimsController _sut;
    private readonly Mock<IClaimsService> _mockedClaimsService = new();

    public ClaimsControllerTests()
    {
        _sut = new(_mockedClaimsService.Object);
    }

    [Fact]
    public void TestThatListPlatformClaimsCallsClaimsServiceListPlatformClaimsWithNoLimitBy()
    {
        _mockedClaimsService.Setup(cs => cs.ListPlatformClaims(null))
            .Returns(new List<ClaimHierarchyCategoriesResponse>());

        var actual = _sut.ListPlatformClaims();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedClaimsService.Verify(cs => cs.ListPlatformClaims(null), Times.Once);
    }

    [Fact]
    public void TestThatListOrganizationClaimsCallsClaimsServiceListPlatformClaimsWithLimitByOrganization()
    {
        _mockedClaimsService.Setup(cs => cs.ListPlatformClaims(UserType.Organization))
            .Returns(new List<ClaimHierarchyCategoriesResponse>());

        var actual = _sut.ListOrganizationClaims();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedClaimsService.Verify(cs => cs.ListPlatformClaims(UserType.Organization), Times.Once);
    }

    [Fact]
    public async Task TestThatUserClaimsCallsClaimsServiceUserClaimsAsync()
    {
        _mockedClaimsService.Setup(cs => cs.UserClaimsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<string>());

        var actual = await _sut.UserClaims(Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedClaimsService.Verify(cs => cs.UserClaimsAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAlterClaimsCallsClaimsServiceAlterUserClaims()
    {
        _sut.SetupHttpContext(UserType.Organization.ToString());

        var userId = Guid.NewGuid();
        var claims = new HashSet<string>
        {
            "claim1",
            "claim2"
        };

        _mockedClaimsService.Setup(cs => cs.AlterUserClaimsAsync(userId, claims, null));

        await _sut.AlterClaims(userId, new()
        {
            Claims = claims
        });

        _mockedClaimsService.Verify(cs => cs.AlterUserClaimsAsync(userId, claims, null), Times.Once);
    }

    [Fact]
    public async Task TestThatUserTokenClaimsCallsClaimsServiceUserClaimsAsync()
    {
        _sut.SetupHttpContext(platformUserId: ValidUserId);

        _mockedClaimsService.Setup(cs => cs.UserClaimsAsync(ValidUserId))
            .ReturnsAsync(new[] { "userclaim1", "userclaim2" });

        var actual = await _sut.UserTokenClaims();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedClaimsService.Verify(cs => cs.UserClaimsAsync(ValidUserId), Times.Once);
    }

    [Fact]
    public async Task TestThatAppTeamTokenClaimsCallsClaimsServiceAppTeamClaimsAsync()
    {
        _sut.SetupHttpContext(appTeamId: ValidAppTeamId);

        _mockedClaimsService.Setup(cs => cs.AppTeamClaimsAsync(ValidAppTeamId))
            .ReturnsAsync(new[] { "teamclaim1", "teamclaim2" });

        var actual = await _sut.AppTeamTokenClaims();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedClaimsService.Verify(cs => cs.AppTeamClaimsAsync(ValidAppTeamId), Times.Once);
    }
}