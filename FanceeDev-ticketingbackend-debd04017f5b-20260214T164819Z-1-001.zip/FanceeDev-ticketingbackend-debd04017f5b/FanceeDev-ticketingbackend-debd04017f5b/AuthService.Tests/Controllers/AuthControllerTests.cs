﻿using System;
using System.Net;
using System.Threading.Tasks;
using AuthService.Controllers;
using AuthService.Dtos.Requests.Auth;
using AuthService.Dtos.Responses.Auth;
using AuthService.Services.Auth;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions.User;

namespace AuthService.Tests.Controllers;

public class AuthControllerTests
{
    private readonly AuthController _sut;
    private readonly Mock<IAuthService> _mockedAuthService;

    public AuthControllerTests()
    {
        _mockedAuthService = new();

        _sut = new(_mockedAuthService.Object);
    }

    [Fact]
    public async Task TestThatTokenReturnsExpectedResponse()
    {
        const string email = "unit@test.com";
        const string password = "UnitT3ster!";
        const string token = "TestToken";

        _mockedAuthService.Setup(a => a.TokenAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(new TokenResponse
            {
                Token = token,
                ValidUntil = DateTime.Now,
                Claims = Array.Empty<string>(),
                User = new() { Id = Guid.NewGuid() }
            });

        var actual = await _sut.Token(new() { Email = email, Password = password });

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result;

        Assert.IsType<ApiResponse<TokenResponse>>(actualResult.Value);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);

        var actualResponse = (ApiResponse<TokenResponse>)actualResult.Value;

        Assert.Equal(token, actualResponse.Data.Token);
        Assert.True(DateTime.Now >= actualResponse.Data.ValidUntil);
        Assert.Empty(actualResponse.Data.Claims);
    }

    [Fact]
    public async Task TestThatAppTeamTokenCallsAuthServiceTokenAsync()
    {
        var appTeamId = Guid.NewGuid();

        _mockedAuthService.Setup(@as => @as.TokenAsync(appTeamId)).ReturnsAsync(new AppTeamTokenResponse
        {
            Token = "Valid",
            ValidUntil = DateTime.UtcNow.AddHours(2),
            Claims = new[] { "scanning", "sales" },
            Name = "Unit test team",
            Organization = "Club Unit B.V."
        });

        var actual = await _sut.AppTeamToken(new() { TeamId = appTeamId });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<AppTeamTokenResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedAuthService.Verify(@as => @as.TokenAsync(appTeamId), Times.Once);
    }

    [Fact]
    public async Task TestThatRefreshTokenCallsAuthServiceRefreshTokenAsync()
    {
        _mockedAuthService.Setup(@as => @as.RefreshTokenAsync("token"))
            .ReturnsAsync(new TokenResponse { Token = "new-token" });

        var actual = await _sut.RefreshToken(new() { Token = "token" });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<TokenResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedAuthService.Verify(@as => @as.RefreshTokenAsync("token"), Times.Once);
    }

    [Fact]
    public async Task TestThatRefreshAppTeamTokenCallsAuthServiceRefreshAppTeamTokenAsync()
    {
        _mockedAuthService.Setup(@as => @as.RefreshAppTeamTokenAsync("token"))
            .ReturnsAsync(new AppTeamTokenResponse { Token = "new-token" });

        var actual = await _sut.RefreshAppTeamToken(new() { Token = "token" });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<AppTeamTokenResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedAuthService.Verify(@as => @as.RefreshAppTeamTokenAsync("token"), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminTakeoverThrowsUserNotFoundExceptionIfUserIsNotAdmin()
    {
        var request = new TakeoverRequest
        {
            AccountId = Guid.NewGuid(),
            AdminPassword = "Test"
        };

        _sut.SetupHttpContext(platformUserId: Guid.Empty, fanceeUsersId: Guid.Empty, userType: UserType.Organization.ToString());

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.AdminTakeover(request));

        _mockedAuthService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAdminTakeoverCallsAuthServiceTakeoverTokenAsync()
    {
        var adminFanceeUsersId = Guid.NewGuid();
        var request = new TakeoverRequest
        {
            AccountId = Guid.NewGuid(),
            AdminPassword = "Test"
        };

        _sut.SetupHttpContext(platformUserId: Guid.Empty, fanceeUsersId: adminFanceeUsersId, userType: UserType.Admin.ToString());

        var actual = await _sut.AdminTakeover(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<TokenResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedAuthService.Verify(@as => @as.TakeoverTokenAsync(request, adminFanceeUsersId, It.IsAny<Guid>()), Times.Once);
    }
}