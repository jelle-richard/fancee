﻿using System.Net.Mime;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PreRegisterService.Dtos.Response.PreRegisters;
using PreRegisterService.Services.PreRegister;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Requests.Filters.Pagination;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace PreRegisterService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class PreRegistersController : ControllerBase
{
    private readonly IPreRegisterService _preRegisterService;

    public PreRegistersController(IPreRegisterService preRegisterService)
    {
        _preRegisterService = preRegisterService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(OrganizationPreRegisterPermissions.List)]
    [Produces(MediaTypeNames.Application.Json)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<PreRegisterListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<PreRegisterListItemResponse>>>> List([FromQuery] PaginatedRequest<SearchQueryFilter> request)
    {
        var (items, totalItems) = await _preRegisterService.ListPreRegistersAsync(request, Request.GetOrganizationId());

        return Ok(new ApiResponse<PaginatedResponse<PreRegisterListItemResponse>>
        {
            Data = new()
            {
                Items = items,
                TotalItems = totalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("organization/export/csv")]
    [Authorize(OrganizationCustomerInsightPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> ExportPreRegistersAsCsv([FromQuery] SearchQueryFilter request)
    {
        var file = await _preRegisterService.PreRegistersCsvAsync(Request.GetOrganizationId(), request);

        return File(file.FileContents, "text/csv", $"PreRegisters-export-{DateTime.UtcNow}-UTC.csv");
    }
}