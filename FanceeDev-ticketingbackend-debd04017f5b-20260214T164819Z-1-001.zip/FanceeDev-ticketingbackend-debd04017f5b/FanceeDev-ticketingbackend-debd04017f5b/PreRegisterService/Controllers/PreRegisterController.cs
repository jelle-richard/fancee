﻿using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PreRegisterService.Dtos.Requests.PreRegister;
using PreRegisterService.Dtos.Requests.SignUp;
using PreRegisterService.Dtos.Response.PreRegister;
using PreRegisterService.Dtos.Response.PreRegisterSignUp;
using PreRegisterService.Services.Exceptions;
using PreRegisterService.Services.PreRegister;
using PreRegisterService.Services.SignUp;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace PreRegisterService.Controllers;

[ApiController]
[Route("/[controller]")]
public class PreRegisterController : ControllerBase
{
    private readonly IPreRegisterSignUpService _preRegisterSignUpService;
    private readonly IPreRegisterService _preRegisterService;

    public PreRegisterController(IPreRegisterSignUpService preRegisterSignUpService, IPreRegisterService preRegisterService)
    {
        _preRegisterSignUpService = preRegisterSignUpService;
        _preRegisterService = preRegisterService;
    }

    [HttpPost]
    [Route("sign-up")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> RegisterSignUp([FromBody] PreRegisterSignUpRequestModel request)
    {
        if (!await _preRegisterService.ExistsAsync((Guid)request.Code!))
            throw new PreRegisterNotFoundException();

        if (await _preRegisterService.HasPreRegisterExpiredAsync((Guid)request.Code!))
            throw new PreRegisterExpiredException();

        // note: in order to not expose which emails have already registered, we return Created() even though the user did not register again.
        if (await _preRegisterSignUpService.IsRegisteredAsync((Guid)request.Code!, request.Email!))
            return Created(string.Empty, new ApiResponse<EmptyResponse>());

        await _preRegisterSignUpService.CreateAsync(request);

        return Created(string.Empty, new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{code:guid}")]
    [ProducesResponseType(typeof(ApiResponse<PreRegisterResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ApiResponse<PreRegisterResponse>>> Get(Guid code) =>
        Ok(new ApiResponse<PreRegisterResponse>
        {
            Data = await _preRegisterService.GetAsync(code)
        });

    [HttpDelete]
    [Route("{code:guid}")]
    [Authorize(OrganizationPreRegisterPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Delete(Guid code)
    {
        await _preRegisterService.DeleteAsync(code, Request.GetOrganizationId());

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Authorize(OrganizationPreRegisterPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<PreRegisterCreateResponse>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<PreRegisterCreateResponse>>> Create([FromBody] PreRegisterConfigureRequest request)
    {
        var code = await _preRegisterService.CreateAsync(request.Name, request.Description, request.ExpiresOn, Request.GetOrganizationId());

        return CreatedAtAction(nameof(Get), new { code }, new ApiResponse<PreRegisterCreateResponse>
        {
            Data = new()
            {
                Code = code
            }
        });
    }

    [HttpPut]
    [Route("{code:guid}")]
    [Authorize(OrganizationPreRegisterPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Edit(Guid code, [FromBody] PreRegisterConfigureRequest request)
    {
        await _preRegisterService.UpdateAsync(code, request.Name, request.Description, request.ExpiresOn, Request.GetOrganizationId());

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("{code:guid}/media/header")]
    [Authorize(OrganizationPreRegisterPermissions.Configure)]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status503ServiceUnavailable)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<Guid>>> AssignHeaderMedia(Guid code, [FromForm] UploadHeaderMediaRequest request)
    {
        var uploadedFile = await _preRegisterService.UploadHeaderMediaAsync(code, Request.GetOrganizationId(), request);

        return Created(uploadedFile.Url, new ApiResponse<Guid> { Data = uploadedFile.Id });
    }

    [HttpDelete]
    [Route("{code:guid}/media/header")]
    [Authorize(OrganizationPreRegisterPermissions.Configure)]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteHeaderMedia(Guid code)
    {
        await _preRegisterService.DeleteHeaderMediaAsync(code, Request.GetOrganizationId());

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{code:guid}/sign-ups")]
    [Authorize(OrganizationPreRegisterPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<PreRegisterSignUpResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<PreRegisterSignUpResponse>>>> SignUps(Guid code)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _preRegisterService.OwnerOfPreRegisterAsync(code, organizationId))
            throw new PreRegisterNotFoundException();

        return Ok(new ApiResponse<IEnumerable<PreRegisterSignUpResponse>>
        {
            Data = await _preRegisterSignUpService.DetailsAsync(code, organizationId)
        });
    }
}