using PreRegisterService.Persistence.PreRegister;
using PreRegisterService.Persistence.SignUp;
using PreRegisterService.Services.PreRegister;
using PreRegisterService.Services.SignUp;
using WebApiCore;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.DeploymentEnvironment;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "PreRegisterService",
        EndpointName = "PreRegisterService v1"
    },
    UseAuthenticationAndAuthorization = true,
    UseSignalR = false,
    UseS3Storage = true
};

builder.AddDependency<IPreRegisterService, PreRegisterService.Services.PreRegister.PreRegisterService>(ServiceLifetime.Scoped);
builder.AddDependency<IPreRegisterSignUpService, PreRegisterSignUpService>(ServiceLifetime.Scoped);
builder.AddDependency<IPreRegisterDao, PreRegisterDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPreRegisterSignUpDao, PreRegisterSignUpDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationDao, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IDeploymentEnvironmentService, DeploymentEnvironmentService>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();