﻿using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using QueueService.Persistence;

namespace QueueService.Tests.Persistence;

public class ShopQueueDaoTests
{
    private readonly ShopQueueDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public ShopQueueDaoTests()
    {
        _mockedContext = new();

        _mockedContext.Setup(mc => mc.ShopQueues)
            .ReturnsDbSet(new List<ShopQueue>
            {
                new()
                {
                    Enabled = true,
                    FlowThroughPerMinute = 60,
                    ShopCode = "unitcode1"
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsNullOnInvalidShopCode()
    {
        var actual = await _sut.ByCodeAsync("invalidCode");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsShopQueueOnValidCode()
    {
        var actual = await _sut.ByCodeAsync("unitcode1");

        Assert.NotNull(actual);
        Assert.IsType<ShopQueue>(actual);
    }
}