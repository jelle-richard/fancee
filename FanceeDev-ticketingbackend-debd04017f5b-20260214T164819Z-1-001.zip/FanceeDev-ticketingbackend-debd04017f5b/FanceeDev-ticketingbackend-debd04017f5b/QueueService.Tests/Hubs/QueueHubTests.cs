﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using QueueService.Dtos.Responses.Queue;
using QueueService.Hubs;
using QueueService.Services.Queue;

namespace QueueService.Tests.Hubs;

public class QueueHubTests
{
    private readonly QueueHub _sut;
    private readonly Mock<IHubContext<QueueHub>> _mockedHubContext;
    private readonly Mock<IQueueService> _mockedQueueService;
    private readonly Mock<IHubCallerClients> _mockedClients;

    public QueueHubTests()
    {
        _mockedHubContext = new();
        _mockedQueueService = new();

        _mockedClients = new();
        var mockClientProxy = new Mock<IClientProxy>();
        _mockedClients.Setup(clients => clients.All)
            .Returns(mockClientProxy.Object);
        _mockedClients.Setup(clients => clients.Caller)
            .Returns(new Mock<ISingleClientProxy>().Object);

        _sut = new(_mockedHubContext.Object, _mockedQueueService.Object);
        _sut.Clients = _mockedClients.Object;
    }

    [Fact]
    public async Task TestThatEnqueueCallsShopServiceShopQueueAsync()
    {
        _mockedQueueService.Setup(mqs => mqs.ShopQueueAsync("unitcode1"))
            .ReturnsAsync(new ShopQueueResponse
            {
                Enabled = true,
                FlowThroughPerMinute = 60,
                ShopCode = "unitcode1"
            });

        await _sut.Enqueue("unitcode1");

        _mockedQueueService.Verify(mqs => mqs.ShopQueueAsync("unitcode1"), Times.Once);
    }

    [Fact]
    public async Task TestThatEnqueueSendsQueueErrorResponseForQueueOnNonEnabledQueue()
    {
        _mockedQueueService.Setup(mqs => mqs.ShopQueueAsync("unitcode1"))
            .ReturnsAsync(new ShopQueueResponse
            {
                Enabled = false,
                FlowThroughPerMinute = 60,
                ShopCode = "unitcode1"
            });

        await _sut.Enqueue("unitcode1");

        _mockedClients.Verify(mhc => mhc.Caller.SendCoreAsync("ReceiveEnqueueResponse", It.IsAny<object[]>(), default), Times.Once);
    }
}