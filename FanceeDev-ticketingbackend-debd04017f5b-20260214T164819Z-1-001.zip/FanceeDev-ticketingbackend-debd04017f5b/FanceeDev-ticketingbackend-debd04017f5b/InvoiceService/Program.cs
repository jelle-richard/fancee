using System.Text.Json.Serialization;
using InvoiceService.BackgroundTasks.MessageBus;
using InvoiceService.Persistence.AdditionalCosts;
using InvoiceService.Persistence.Event;
using InvoiceService.Persistence.Invoice;
using InvoiceService.Persistence.InvoiceRule;
using InvoiceService.Persistence.Organization;
using InvoiceService.Persistence.Wallet;
using InvoiceService.Services.AdditionalCosts;
using InvoiceService.Services.Invoice;
using InvoiceService.Services.InvoiceRule;
using InvoiceService.Services.Wallet;
using InvoiceService.Utils.Converter;
using WebApiCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "InvoiceService",
        EndpointName = "InvoiceService v1"
    },
    JsonConverters = new List<JsonConverter>
    {
        new CreateInvoiceRuleBaseExpressionRequestConverter(),
        new CreateInvoiceRuleConditionRequestConverter(),
        new InvoiceRuleDiscountValueDtoConverter()
    }
};

builder.AddDependency<IInvoiceService, InvoiceService.Services.Invoice.InvoiceService>(ServiceLifetime.Scoped);
builder.AddDependency<IWalletService, WalletService>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceRuleService, InvoiceRuleService>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceDao, InvoiceDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationDao, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IWalletPaymentDao, WalletPaymentDao>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceRowSpecificationDao, InvoiceRowSpecificationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceUnitDao, InvoiceUnitDao>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceRuleDao, InvoiceRuleDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICreateInvoiceService, CreateInvoiceService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);
builder.AddDependency<IAdditionalCostsService, AdditionalCostsService>(ServiceLifetime.Scoped);
builder.AddDependency<IAdditionalCostsDao, AdditionalCostsDao>(ServiceLifetime.Scoped);

builder.AddDependency<CreateWalletPaymentListener>(sp => new(sp), ServiceLifetime.Singleton);
builder.AddDependency<CreateInvoicesListener>(sp => new(sp), ServiceLifetime.Singleton);
builder.AddDependency<AddAdditionalCostListener>(sp => new(sp), ServiceLifetime.Singleton);

builder.AddHostedService<CreateWalletPaymentListener>();
builder.AddHostedService<CreateInvoicesListener>();
builder.AddHostedService<AddAdditionalCostListener>();

var app = builder.Build();
app.Run();