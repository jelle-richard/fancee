using WebApiCore.Exceptions;

namespace ProductService.Exceptions;

public class DuplicateFileContentException()
    : BadRequestApiException("Csv file contains one or more duplicate barcodes");