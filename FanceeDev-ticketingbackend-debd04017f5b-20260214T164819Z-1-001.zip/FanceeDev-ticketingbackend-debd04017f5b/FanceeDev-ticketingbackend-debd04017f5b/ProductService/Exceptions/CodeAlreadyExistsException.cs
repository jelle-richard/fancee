using WebApiCore.Exceptions;

namespace ProductService.Exceptions;

public class CodeAlreadyExistsException()
    : BadRequestApiException("Csv file contains a barcode for an already existing issued product");