using System.Net.Mime;
using Microsoft.AspNetCore.Mvc;
using ProductService.Dtos.Requests.TicketSwap;
using ProductService.Dtos.Responses.TicketSwap;
using ProductService.Services.TicketSwap;
using ProductService.Services.TicketSwap.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions;

namespace ProductService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class TicketSwapController : ControllerBase
{
    private const string AccessKeyConfigurationName = "TicketSwap";
    private readonly ITicketSwapService _ticketSwapService;
    private readonly IConfiguration _configuration;

    public TicketSwapController(ITicketSwapService ticketSwapService, IConfiguration configuration)
    {
        _ticketSwapService = ticketSwapService;
        _configuration = configuration;
    }

    [HttpGet]
    [Route("validate")]
    [ProducesResponseType(typeof(ApiResponse<ValidateResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ValidateResponse>>> Validate([FromQuery] string barcode, [FromQuery(Name = "access_token")] string accessToken)
    {
        ValidateAccessToken(accessToken);

        return Ok(new ApiResponse<ValidateResponse>
        {
            Data = await _ticketSwapService.ValidateSwapSpecificationAsync(barcode)
        });
    }

    [HttpPost]
    [Route("swap")]
    [ProducesResponseType(typeof(ApiResponse<SwapResponse>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<SwapResponse>>> Swap([FromBody] SwapRequest request, [FromQuery(Name = "access_token")] string accessToken)
    {
        ValidateAccessToken(accessToken);

        return Created(string.Empty, await _ticketSwapService.SwapTicketAsync(request));
    }

    [HttpGet]
    [Route("file/{previousTicketCode}/{swappedTicketCode}")]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> DownloadSwapPdf(string previousTicketCode, string swappedTicketCode)
    {
        var stream = await _ticketSwapService.DownloadSwapPdfAsync(previousTicketCode, swappedTicketCode);

        return File(stream, MediaTypeNames.Application.Pdf, "TicketSwapTicket.pdf");
    }

    [HttpGet]
    [Route("tickets/{orderId:guid}")]
    [ProducesResponseType(typeof(ApiResponse<TicketsOfOrderResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<TicketsOfOrderResponse>>>> SealedTickets(Guid orderId, [FromQuery(Name = "access_token")] string accessToken)
    {
        ValidateAccessToken(accessToken);

        return Ok(new ApiResponse<IEnumerable<TicketsOfOrderResponse>>
        {
            Data = await _ticketSwapService.SealedTicketsOrderResponseByOrderIdAsync(orderId)
        });
    }

    private void ValidateAccessToken(string accessToken)
    {
        var section = _configuration.GetSection(AccessKeyConfigurationName);

        if (!section.Exists())
            throw new MissingRequiredConfigurationEntryException(AccessKeyConfigurationName);

        if (accessToken != section.GetValue<string>("AccessKey"))
            throw new TicketSwapUnauthorizedException();
    }
}