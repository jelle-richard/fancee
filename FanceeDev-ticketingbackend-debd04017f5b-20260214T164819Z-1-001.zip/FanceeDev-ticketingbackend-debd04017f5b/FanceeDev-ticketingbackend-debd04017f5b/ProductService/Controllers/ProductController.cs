﻿using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductService.Dtos.Requests.Tickets;
using ProductService.Dtos.Responses.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.IssuedTicket.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace ProductService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[UseOrganizationHeader]
public class ProductController : ControllerBase
{
    private readonly IIssuedTicketService _issuedTicketService;

    public ProductController(IIssuedTicketService issuedTicketService)
    {
        _issuedTicketService = issuedTicketService;
    }

    [HttpGet]
    [Route("ticket/{code}")]
    [Authorize(OrganizationCustomerInsightPermissions.View)]
    [ProducesResponseType(typeof(ApiResponse<TicketResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<TicketResponse>>> Details(string code) =>
        Ok(new ApiResponse<TicketResponse>
        {
            Data = await _issuedTicketService.DetailsAsync(code, Request.GetOrganizationId())
        });

    [HttpPut]
    [Route("ticket/{code}/state/invalidate")]
    [Authorize(OrganizationTicketPermissions.Edit)]
    [ProducesResponseType<ApiResponse<EmptyResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ApiResponse<EmptyResponse>>(StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ChangeTicketState(string code, [FromBody] ChangeTicketStateRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _issuedTicketService.HasAccessAsync(code, null, organizationId))
            throw new InvalidTicketCodeException();

        await _issuedTicketService.InvalidateAsync(organizationId, code, request.Reason, request.ReturnToStock);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}