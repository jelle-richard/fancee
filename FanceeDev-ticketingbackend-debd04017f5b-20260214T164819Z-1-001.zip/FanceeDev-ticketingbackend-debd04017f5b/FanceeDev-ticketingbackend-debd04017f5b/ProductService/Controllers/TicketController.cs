using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductService.Dtos.Requests.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.Product.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace ProductService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class TicketController : ControllerBase
{
    private readonly IIssuedTicketService _issuedTicketService;

    public TicketController(IIssuedTicketService issuedTicketService)
    {
        _issuedTicketService = issuedTicketService;
    }

    [HttpPut]
    [Route("{code}/holder")]
    [Authorize(OrPermissions.EditTicketPermissions)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader(false)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateTicketHolder(string code, [FromBody] TicketHolderRequest request)
    {
        var userId = User.TryGetUserId();
        var organizationId = Request.TryGetOrganizationId();

        if (userId == null && organizationId == null)
            throw new ProductNotFoundException();

        if (!await _issuedTicketService.HasAccessAsync(code, userId, organizationId))
            throw new ProductNotFoundException();

        await _issuedTicketService.UpdateTicketHolderAsync(code, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}