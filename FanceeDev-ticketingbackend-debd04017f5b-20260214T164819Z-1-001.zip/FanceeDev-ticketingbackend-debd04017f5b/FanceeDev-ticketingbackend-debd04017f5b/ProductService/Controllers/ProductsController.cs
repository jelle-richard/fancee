﻿using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductService.Dtos.Requests.Products;
using ProductService.Dtos.Requests.Tickets;
using ProductService.Dtos.Responses.Products;
using ProductService.Dtos.Responses.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.Organization;
using ProductService.Services.Product;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions.Event;
using WebApiCore.Utils;
using WebApiCore.Utils.Adapter;
using WebApiCore.Utils.HttpContext;

namespace ProductService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class ProductsController : ControllerBase
{
    private readonly IIssuedTicketService _issuedTicketService;
    private readonly IProductService _productService;
    private readonly IOrganizationService _organizationService;

    public ProductsController(IIssuedTicketService issuedTicketService, IProductService productService, IOrganizationService organizationService)
    {
        _issuedTicketService = issuedTicketService;
        _productService = productService;
        _organizationService = organizationService;
    }

    [HttpGet]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EventProductsResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<EventProductsResponse>>>> EventProducts([FromQuery] EventProductsRequestFilter request) =>
        Ok(new ApiResponse<IEnumerable<EventProductsResponse>>
        {
            Data = await _productService.ProductsByEventIdsAsync(Request.GetOrganizationId(), request.EventIds)
        });

    [HttpGet]
    [Route("ticket/list")]
    [Authorize(OrganizationCustomerInsightPermissions.View)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<TicketListResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<TicketListResponse>>>> GetOrganizationTickets([FromQuery] PaginatedRequest<TicketsRequestFilter> request)
    {
        var result = await _issuedTicketService.IssuedTicketsByOrganizationAsync(Request.GetOrganizationId(), request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("ticket/app-team/list")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<TicketListResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<TicketListResponse>>>> GetAppTeamOrganizationTickets([FromQuery] PaginatedRequest<TicketsRequestFilter> request)
    {
        var result = await _issuedTicketService.IssuedTicketsByAppTeamAsync(User.GetAppTeamId(), request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("ticket/export/csv")]
    [Authorize(OrganizationCustomerInsightPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<FileResult> ExportOrganizationTicketsAsCsv([FromQuery] TicketsRequestFilter request)
    {
        var file = await _issuedTicketService.ExportIssuedTicketsByOrganizationAsCsvAsync(Request.GetOrganizationId(), request);

        return File(file.FileContents, "text/csv", $"Tickets-export-{DateTime.UtcNow}-UTC.csv");
    }

    [HttpGet]
    [Route("best-selling")]
    [Authorize(OrganizationCustomerInsightPermissions.View)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<BestSellingProductResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<BestSellingProductResponse>>>> GetBestSellers([FromQuery] int limit, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) =>
        Ok(new ApiResponse<IEnumerable<BestSellingProductResponse>>
        {
            Data = await _productService.BestSellingProductsAsync(Request.GetOrganizationId(), limit, startDate, endDate)
        });

    [HttpGet]
    [Route("{eventId:guid}/best-selling")]
    [Authorize(OrganizationCustomerInsightPermissions.View)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<BestSellingProductResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<BestSellingProductResponse>>>> GetEventBestSellers(Guid eventId, [FromQuery] int limit, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<BestSellingProductResponse>>
        {
            Data = await _productService.BestSellingEventProductsAsync(eventId, limit, startDate, endDate)
        });
    }
}