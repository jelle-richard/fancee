using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductService.Dtos.Requests.Tickets;
using ProductService.Services.IssuedTicket;
using ProductService.Services.Product;
using ProductService.Services.Product.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace ProductService.Controllers;

[ApiController]
[Route("/[controller]/{productId:guid}")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[UseOrganizationHeader]
public class TicketsController : ControllerBase
{
    private readonly IIssuedTicketService _issuedTicketService;
    private readonly IProductService _productService;

    public TicketsController(IIssuedTicketService issuedTicketService, IProductService productService)
    {
        _issuedTicketService = issuedTicketService;
        _productService = productService;
    }

    [HttpPost]
    [Route("import")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ImportIssuedTickets(Guid productId, [FromForm] IssuedTicketsImportRequest request)
    {
        if (!await _productService.OwnerOfProductAsync(Request.GetOrganizationId(), productId))
            throw new ProductNotFoundException();

        await _issuedTicketService.ImportIssuedTicketsAsync(productId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("generate-barcode")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> GenerateBarcode(Guid productId, [FromQuery] int amount)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _productService.OwnerOfProductAsync(organizationId, productId))
            throw new ProductNotFoundException();

        await _issuedTicketService.GenerateCodeAndInsertAsync(organizationId, productId, amount);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}