using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductService.Dtos.Requests.Tickets.GuestList;
using ProductService.Services.GuestList;
using ProductService.Services.Product;
using ProductService.Services.Product.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Utils;

namespace ProductService.Controllers;

[ApiController]
[Route("/tickets/{productId:guid}/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class GuestListController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly IGuestListService _guestListService;
    private readonly IDeploymentEnvironmentService _deploymentEnvironmentService;

    public GuestListController(IProductService productService, IGuestListService guestListService, IDeploymentEnvironmentService deploymentEnvironmentService)
    {
        _productService = productService;
        _guestListService = guestListService;
        _deploymentEnvironmentService = deploymentEnvironmentService;
    }

    [HttpPost]
    [Route("import")]
    [Authorize(OrganizationGuestListPermissions.Import)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ImportGuestList(Guid productId, [FromForm] ImportGuestListRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _productService.OwnerOfProductAsync(organizationId, productId))
            throw new ProductNotFoundException();

        if (!await _productService.EventActiveAsync(productId))
            throw new EventNotActiveException();
        
        var env = await _deploymentEnvironmentService.GetAsync();

        await _guestListService.ImportAsync(organizationId, productId, request, env);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}