using Fs.SeatingUtils.Config;
using Fs.SeatingUtils.Utils;
using ProductService.BackgroundTasks.MessageBus;
using ProductService.Persistence.Event;
using ProductService.Persistence.IssuedProduct;
using ProductService.Persistence.IssuedTicket;
using ProductService.Persistence.Order;
using ProductService.Persistence.Product;
using ProductService.Persistence.ReservationReference;
using ProductService.Persistence.ReservedProduct;
using ProductService.Services.GuestList;
using ProductService.Services.IssuedProduct;
using ProductService.Services.IssuedTicket;
using ProductService.Services.Order;
using ProductService.Services.Product;
using ProductService.Services.TicketSwap;
using WebApiCore;
using WebApiCore.Exceptions;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.Organization;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "ProductService",
        EndpointName = "ProductService v1"
    },
    UseAuthenticationAndAuthorization = true,
    UseSignalR = false,
    UseS3Storage = true
};

builder.OnConfigureServices += (_, collection) =>
{
    if (builder.IsCiCd)
        return;

    collection.AddSeatingUtils(new SeatsIoConfiguration
    {
        Region = builder.Configuration.GetValue<string>("SeatsIo:Region") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "Region"),
        SecretKey = builder.Configuration.GetValue<string>("SeatsIo:SecretKey") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "SecretKey")
    });
};

builder.AddDependency<IIssuedProductService, IssuedProductTicketService>(ServiceLifetime.Scoped);
builder.AddDependency<IIssuedProductService, IssuedProductService>(ServiceLifetime.Scoped);
builder.AddDependency<IIssuedProductDao, IssuedProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<IIssuedTicketDao, IssuedTicketDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderDao, OrderDao>(ServiceLifetime.Scoped);
builder.AddDependency<IIssuedTicketService, IssuedTicketService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationService, OrganizationService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationDao, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IProductService, ProductService.Services.Product.ProductService>(ServiceLifetime.Scoped);
builder.AddDependency<IProductDao, ProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<ProductService.Services.Organization.IOrganizationService, ProductService.Services.Organization.OrganizationService>(ServiceLifetime.Scoped);
builder.AddDependency<ProductService.Persistence.Organization.IOrganizationDao, ProductService.Persistence.Organization.OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderService, OrderService>(ServiceLifetime.Scoped);
builder.AddDependency<IIssuedProductDao, IssuedProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<IReservedProductDao, ReservedProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<IReservationReferenceDao, ReservationReferenceDao>(ServiceLifetime.Scoped);
builder.AddDependency<IGuestListService, GuestListService>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketSwapService, TicketSwapService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);

builder.AddDependency(x => new IssueProductListener(x), ServiceLifetime.Singleton);
builder.AddDependency(x => new UnlockReservedProductsListener(x), ServiceLifetime.Singleton);

builder.AddHostedService<IssueProductListener>();
builder.AddHostedService<UnlockReservedProductsListener>();

var app = builder.Build();
app.Run();