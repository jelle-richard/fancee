using WebApiCore.Exceptions;

namespace ProductService.Settings;

public class BarcodeSettings
{
    private const string BarcodeSectionName = "Barcode";

    public int FreeLimit { get; set; } = 500;
    public int CostCents { get; set; } = 10;

    public static BarcodeSettings FromConfiguration(IConfiguration configuration)
    {
        var model = new BarcodeSettings();
        var section = configuration.GetSection(BarcodeSectionName);

        if (!section.Exists())
            throw new MissingRequiredConfigurationEntryException(BarcodeSectionName);

        section.Bind(model);

        return model;
    }
}