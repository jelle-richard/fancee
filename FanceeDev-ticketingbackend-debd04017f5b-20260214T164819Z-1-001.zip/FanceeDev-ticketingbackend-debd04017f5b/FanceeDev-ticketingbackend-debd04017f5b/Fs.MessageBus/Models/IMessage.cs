namespace Fs.MessageBus.Models;

public interface IMessage
{
}