using Fs.MessageBus.Models;
using Fs.MessageBus.Publishers;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using RabbitMQ.Client;

namespace Fs.MessageBus.Utils;

public static class MessageBusExtensions
{
    public static IServiceCollection AddMessageBus(this IServiceCollection serviceCollection, string connectionString)
    {
        serviceCollection.AddSingleton(_ =>
            new ConnectionFactory { Uri = new(connectionString) }
                .CreateConnection()
        );

        return serviceCollection;
    }

    public static IServiceCollection RegisterMessage<TMessage, TPublisherImpl, TSubscriberImpl>(this IServiceCollection serviceCollection)
        where TMessage : IMessage
        where TPublisherImpl : RabbitMessagePublisher<TMessage>
        where TSubscriberImpl : RabbitMessageSubscriber<TMessage> =>
        serviceCollection.AddSingleton<IMessagePublisher<TMessage>, TPublisherImpl>()
            .AddSingleton<IMessageSubscriber<TMessage>, TSubscriberImpl>();

    public static IServiceCollection RegisterMessagePublisher<TMessage, TPublisherImpl>(this IServiceCollection serviceCollection)
        where TMessage : IMessage
        where TPublisherImpl : RabbitMessagePublisher<TMessage> =>
        serviceCollection.AddSingleton<IMessagePublisher<TMessage>, TPublisherImpl>();

    public static IServiceCollection RegisterMessageSubscriber<TMessage, TSubscriberImpl>(this IServiceCollection serviceCollection)
        where TMessage : IMessage
        where TSubscriberImpl : RabbitMessageSubscriber<TMessage> =>
        serviceCollection.AddSingleton<IMessageSubscriber<TMessage>, TSubscriberImpl>();
}