using System;
using System.Collections.Generic;
using System.Linq;
using WebApiCore.Dtos.Shared;
using WebApiCore.Utils;

namespace WebApiCore.Tests.Utils;

public class DaoUtilsTests
{
    [Fact]
    public void TestThatBuildDateRangeAddsModelsToList()
    {
        var start = new DateTime(2022, 1, 10);
        var end = new DateTime(2022, 1, 15);

        var actual = DaoUtils.BuildDateRange<UnitDailyDto>(start, end)
            .ToList();

        Assert.IsAssignableFrom<IEnumerable<UnitDailyDto>>(actual);
        Assert.Equal(6, actual.Count);
    }

    [Fact]
    public void TestThatBuildDateRangeDoesNothingOnNegativeRange()
    {
        var start = new DateTime(2022, 1, 20);
        var end = new DateTime(2022, 1, 15);

        var actual = DaoUtils.BuildDateRange<UnitDailyDto>(start, end)
            .ToList();

        Assert.Empty(actual);
    }

    [Fact]
    public void TestThatBuildDateRangeSetsNewDateToEndOfDay()
    {
        var start = new DateTime(2022, 1, 10);
        var end = new DateTime(2022, 1, 15);

        var actual = DaoUtils.BuildDateRange<UnitDailyDto>(start, end, true)
            .ToList();

        Assert.IsAssignableFrom<IEnumerable<UnitDailyDto>>(actual);
        Assert.Equal(6, actual.Count);
        Assert.All(actual, dto => Assert.True(dto.Date is { Hour: 23, Minute: 59, Second: 59 }));
    }

    #region Unit Test Classes

    private class UnitDailyDto : IDailyDto
    {
        public DateTime Date { get; set; }
    }

    #endregion
}