using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Net.Http.Headers;
using WebApiCore.Utils;

namespace WebApiCore.Tests.Utils;

public class RequestUtilsTests
{
    private const string UserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/119.0";

    [Fact]
    public void TestThatBasicReturnsBasicPartOfAuthorization()
    {
        Assert.Equal("Basic", RequestUtils.Basic);
    }

    [Fact]
    public async Task TestThatReadRawRequestReturnsRawBodyOfRequest()
    {
        var body = "{\"message\": \"test\"}";

        var mockedRequest = new Mock<HttpRequest>();
        mockedRequest.Setup(r => r.Body).Returns(new MemoryStream(Encoding.UTF8.GetBytes(body)));

        var actual = await mockedRequest.Object.ReadRawRequestAsync();

        Assert.Equal(body, actual);
    }

    [Fact]
    public void TestThatValidBasicAuthorizationReturnsFalseOnMissingHeader()
    {
        var headers = new HeaderDictionary();

        var actual = headers.ValidBasicAuthorization("", "");

        Assert.False(actual);
    }

    [Fact]
    public void TestThatValidBasicAuthorizationReturnsFalseOnMissingHeaderValue()
    {
        var headers = new HeaderDictionary
        {
            { HeaderNames.Authorization, (string)null! }
        };

        var actual = headers.ValidBasicAuthorization("", "");

        Assert.False(actual);
    }

    [Fact]
    public void TestThatValidBasicAuthorizationHeaderReturnsFalseOnInvalidUsername()
    {
        const string username = "test";
        const string password = "s3cur3!";

        var headers = new HeaderDictionary
        {
            { HeaderNames.Authorization, $"Basic {Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}"))}" }
        };

        var actual = headers.ValidBasicAuthorization("invalid", password);

        Assert.False(actual);
    }

    [Fact]
    public void TestThatValidBasicAuthorizationHeaderReturnsFalseOnInvalidPassword()
    {
        const string username = "test";
        const string password = "s3cur3!";

        var headers = new HeaderDictionary
        {
            { HeaderNames.Authorization, $"Basic {Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}"))}" }
        };

        var actual = headers.ValidBasicAuthorization(username, "invalid");

        Assert.False(actual);
    }

    [Fact]
    public void TestThatValidBasicAuthorizationHeaderReturnsTrueOnValidHeaderValue()
    {
        const string username = "test";
        const string password = "s3cur3!";

        var headers = new HeaderDictionary
        {
            { HeaderNames.Authorization, $"Basic {Convert.ToBase64String(Encoding.UTF8.GetBytes($"{username}:{password}"))}" }
        };

        var actual = headers.ValidBasicAuthorization(username, password);

        Assert.True(actual);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("Basic")]
    [InlineData("Basic   ")]
    public void TestThatInvalidHeadersReturnFalse(string input)
    {
        var headers = new HeaderDictionary
        {
            { HeaderNames.Authorization, input }
        };

        var actual = headers.ValidBasicAuthorization("user", "pass");

        Assert.False(actual);
    }

    [Fact]
    public void TestThatTryGetUserAgentReturnsNullIfHttpContextIsNull()
    {
        Microsoft.AspNetCore.Http.HttpContext httpContext = null;

        // ReSharper disable once ExpressionIsAlwaysNull
        Assert.Null(httpContext.TryGetUserAgent());
    }

    [Fact]
    public void TestThatTryGetUserAgentReturnsUserAgent()
    {
        var mockedHttpContextAccessor = new Mock<IHttpContextAccessor>();
        mockedHttpContextAccessor.Setup(hca => hca.HttpContext.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        var actual = mockedHttpContextAccessor.Object.HttpContext.TryGetUserAgent();

        Assert.Equal(UserAgent, actual);
    }

    [Fact]
    public void TestThatTryGetUserAgentReturnsForwardedUserAgent()
    {
        var mockedHttpContextAccessor = new Mock<IHttpContextAccessor>();
        mockedHttpContextAccessor.Setup(hca => hca.HttpContext.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "X-Forwarded-User-Agent", UserAgent }
            });

        var actual = mockedHttpContextAccessor.Object.HttpContext.TryGetUserAgent();

        Assert.Equal(UserAgent, actual);
    }
}