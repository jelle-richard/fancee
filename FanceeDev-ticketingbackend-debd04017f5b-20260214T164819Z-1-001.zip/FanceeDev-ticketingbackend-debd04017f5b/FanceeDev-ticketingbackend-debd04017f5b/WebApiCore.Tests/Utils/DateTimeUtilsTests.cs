﻿using System;
using WebApiCore.Utils;

namespace WebApiCore.Tests.Utils;

public class DateTimeUtilsTests
{
    public static readonly object[][] FromUnixTimestampTestData =
    {
        new object[] { 0, new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc) },
        new object[] { 1652796799, new DateTime(2022, 5, 17, 14, 13, 19, DateTimeKind.Utc) },
        new object[] { -1000, new DateTime(1969, 12, 31, 23, 43, 20, DateTimeKind.Utc) }
    };

    public static readonly object[][] GetAgeTestData =
    {
        new object[] { new DateOnly(1997, 5, 17), 25 },
        new object[] { new DateOnly(2000, 5, 18), 21 },
        new object[] { new DateOnly(2023, 1, 1), -1 }
    };

    public static readonly object[][] MinTestData =
    {
        new object[] { ParseDateTime("2022-12-31 10:00:00"), ParseDateTime("2022-12-31 11:00:00"), ParseDateTime("2022-12-31 10:00:00") },
        new object[] { ParseDateTime("2022-12-31 10:00:00"), ParseDateTime("2021-12-31 07:45:00"), ParseDateTime("2021-12-31 07:45:00") }
    };

    private static readonly DateOnly Now = new(2022, 5, 17);

    [Theory]
    [MemberData(nameof(FromUnixTimestampTestData))]
    public void TestThatFromUnixTimestampConvertsTimestampToExpectedDateTime(long timestamp, DateTime expected)
    {
        var actual = DateTimeUtils.FromUnixTimestamp(timestamp);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatToDateOnlyConvertsDateTimeToDateOnly()
    {
        var dt = new DateTime(2022, 5, 17, 10, 23, 45, DateTimeKind.Utc);

        var actual = dt.ToDateOnly();

        Assert.Equal(new(2022, 5, 17), actual);
    }

    [Theory]
    [MemberData(nameof(GetAgeTestData))]
    public void TestThatGetAgeReturnsExpectedResult(DateOnly input, int expected)
    {
        var actual = input.GetAge(Now);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatGetAgeWithDateTimeConvertsToDateOnly()
    {
        var dateTime = new DateTime(1997, 5, 17, 15, 33, 2);

        var actual = dateTime.GetAge(Now);

        Assert.Equal(25, actual);
    }

    [Fact]
    public void TestThatGetMonthRangeGetsFirstAndLastDayOfMonth()
    {
        var dt = DateTime.Parse("2022-08-23 14:09:20");

        var actual = DateTimeUtils.GetMonthRange(dt);

        var expectedStart = DateTime.Parse("2022-08-01 00:00:00");
        var expectedEnd = DateTime.Parse("2022-09-01 00:00:00").AddTicks(-1);

        Assert.Equal(expectedStart, actual.Start);
        Assert.Equal(expectedEnd, actual.End);
    }

    [Fact]
    public void TestThatGetMonthRangeGetsFirstAndLastDayOfMonthForCurrentDate()
    {
        var actual = DateTimeUtils.GetMonthRange();

        Assert.Equal(1, actual.Start.Day);
        Assert.Equal(0, actual.Start.Hour);
        Assert.Equal(0, actual.Start.Minute);
        Assert.Equal(0, actual.Start.Second);
        Assert.InRange(actual.End.Day, 28, 31);
        Assert.Equal(23, actual.End.Hour);
        Assert.Equal(59, actual.End.Minute);
        Assert.Equal(59, actual.End.Second);
    }

    [Fact]
    public void TestThatSetStartOfDaySetsDateTimeToBeginningOfDay()
    {
        var actual = new DateTime(2023, 1, 4, 15, 40, 22).SetStartOfDay();

        Assert.Equal(2023, actual.Year);
        Assert.Equal(1, actual.Month);
        Assert.Equal(4, actual.Day);
        Assert.Equal(0, actual.Hour);
        Assert.Equal(0, actual.Minute);
        Assert.Equal(0, actual.Second);
        Assert.Equal(0, actual.Millisecond);
        Assert.Equal(0, actual.Microsecond);
    }

    [Fact]
    public void TestThatSetEndOfDaySetsDateTimeToEndOfDay()
    {
        var actual = new DateTime(2023, 1, 4, 15, 40, 22).SetEndOfDay();

        Assert.Equal(2023, actual.Year);
        Assert.Equal(1, actual.Month);
        Assert.Equal(4, actual.Day);
        Assert.Equal(23, actual.Hour);
        Assert.Equal(59, actual.Minute);
        Assert.Equal(59, actual.Second);
        Assert.Equal(999, actual.Millisecond);
        Assert.Equal(999, actual.Microsecond);
    }

    [Fact]
    public void TestThatSetEndOfDayAddsDays()
    {
        var actual = new DateTime(2023, 1, 4, 15, 40, 22).SetEndOfDay(2);

        Assert.Equal(2023, actual.Year);
        Assert.Equal(1, actual.Month);
        Assert.Equal(6, actual.Day);
        Assert.Equal(23, actual.Hour);
        Assert.Equal(59, actual.Minute);
        Assert.Equal(59, actual.Second);
        Assert.Equal(999, actual.Millisecond);
        Assert.Equal(999, actual.Microsecond);
    }

    [Theory]
    [MemberData(nameof(MinTestData))]
    public void TestThatMinReturnsExpectedResult(DateTime inputA, DateTime inputB, DateTime expected)
    {
        var actual = DateTimeUtils.Min(inputA, inputB);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatIsCurrentYearAndMonthReturnsTrueForCurrentYearAndMonth()
    {
        var currentDate = DateTime.UtcNow;

        var actual = DateTimeUtils.IsCurrentYearAndMonth(currentDate.Year, currentDate.Month);

        Assert.True(actual);
    }

    [Fact]
    public void TestThatIsCurrentYearAndMonthReturnsFalseDateThatDoesNotMatchCurrentYearAndMonthCombination()
    {
        var currentDate = DateTime.UtcNow;

        var actual = DateTimeUtils.IsCurrentYearAndMonth(currentDate.Year - 1, currentDate.Month);

        Assert.False(actual);
    }

    [Fact]
    public void TestThatIsFutureMonthReturnsTrueForDateTimeInFutureMonth()
    {
        var futureDate = DateTime.UtcNow.AddMonths(3);

        var actual = DateTimeUtils.IsFutureMonth(futureDate.Year, futureDate.Month);

        Assert.True(actual);
    }

    [Fact]
    public void TestThatIsFutureMonthReturnsFalseForDateTimeThatHasPassed()
    {
        var futureDate = DateTime.UtcNow.AddMonths(-7);

        var actual = DateTimeUtils.IsFutureMonth(futureDate.Year, futureDate.Month);

        Assert.False(actual);
    }

    [Theory]
    [InlineData(-7)]
    [InlineData(-12)]
    [InlineData(-1)]
    [InlineData(-18)]
    public void TestThatIsHistoricMonthReturnsTrueForMonthBeforeNow(int months)
    {
        var pastDate = DateTime.UtcNow.AddMonths(months);

        var actual = DateTimeUtils.IsHistoricMonth(pastDate.Year, pastDate.Month);

        Assert.True(actual);
    }

    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    [InlineData(18)]
    public void TestThatIsHistoricMonthReturnsFalseForFutureMonth(int months)
    {
        var futureDate = DateTime.UtcNow.AddMonths(months);

        var actual = DateTimeUtils.IsHistoricMonth(futureDate.Year, futureDate.Month);

        Assert.False(actual);
    }

    [Fact]
    public void TestThatAllTimeZoneIdentificationsAreConvertable()
    {
        foreach (var ti in DateTimeUtils.TimezoneIdentifications)
        {
            var parsedDateTime = DateTimeUtils.ConvertToTimezone(DateTime.UtcNow, ti);
            Assert.IsType<DateTime>(parsedDateTime);
        }
    }

    #region Utility Methods

    private static DateTime ParseDateTime(string dt) => DateTime.ParseExact(dt, DateFormat.DefaultApiResponse, null);

    #endregion
}