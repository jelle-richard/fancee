﻿using TestCore.Mocks;
using WebApiCore.Exceptions;
using WebApiCore.Settings;

namespace WebApiCore.Tests.Settings;

public class OrganizationDetailsSettingsTests
{
    [Fact]
    public void TestThatFromConfigurationGetsSettingsFromConfiguration()
    {
        var configuration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:PlatformName", "UnitTest (test)" },
            { "OrganizationDetails:PlatformLogoUrl", "http://unit.test/logo.png" }
        });

        var actual = OrganizationDetailsSettings.FromConfiguration(configuration);

        Assert.Equal("UnitTest B.V.", actual.Name);
        Assert.Equal("83493845", actual.ChamberOfCommerceIdentifier);
        Assert.Equal("NL92TEST483399991243", actual.Iban);
        Assert.Equal("3582935", actual.VatCode);
        Assert.Equal("EUR", actual.PlatformBaseCurrency);
        Assert.Equal("Hamburgerstraße", actual.Address.Street);
        Assert.Equal("843-855", actual.Address.HouseNumber);
        Assert.Equal("4921DB", actual.Address.PostalCode);
        Assert.Equal("München", actual.Address.City);
        Assert.Equal("DE", actual.Address.CountryCode);
        Assert.Equal("UnitTest (test)", actual.PlatformName);
        Assert.Null(actual.Socials.FacebookUrl);
        Assert.Null(actual.Socials.TwitterUrl);
        Assert.Null(actual.Socials.InstagramUrl);
        Assert.Equal("http://unit.test/logo.png", actual.PlatformLogoUrl);
    }

    [Fact]
    public void TestThatFromConfigurationHandlesOptionalParameters()
    {
        var configuration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:Socials:FacebookUrl", "https://facebook.com/unit_test" },
            { "OrganizationDetails:Socials:TwitterUrl", "https://twitter.com/unit_test" },
            { "OrganizationDetails:Socials:InstagramUrl", "https://instagram.com/unit_test" }
        });

        var actual = OrganizationDetailsSettings.FromConfiguration(configuration);

        Assert.Null(actual.ChamberOfCommerceIdentifier);
        Assert.Null(actual.VatCode);
        Assert.Equal("https://facebook.com/unit_test", actual.Socials.FacebookUrl);
        Assert.Equal("https://twitter.com/unit_test", actual.Socials.TwitterUrl);
        Assert.Equal("https://instagram.com/unit_test", actual.Socials.InstagramUrl);
    }

    [Fact]
    public void TestThatFromConfigurationThrowsMissingRequiredConfigurationEntryExceptionOnMissingSection()
    {
        var configuration = ConfigurationMockUtils.Create();

        Assert.Throws<MissingRequiredConfigurationEntryException>(() => OrganizationDetailsSettings.FromConfiguration(configuration));
    }
}