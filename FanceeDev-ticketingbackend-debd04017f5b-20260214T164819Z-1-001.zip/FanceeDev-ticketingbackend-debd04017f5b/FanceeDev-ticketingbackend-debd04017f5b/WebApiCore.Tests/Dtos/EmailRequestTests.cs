using System.Linq;
using WebApiCore.Dtos.Shared;

namespace WebApiCore.Tests.Dtos;

public class EmailRequestTests
{
    [Fact]
    public void TestThatValidEmailDoesNotReturnMessage()
    {
        var request = new EmailRequest
        {
            EmailAddress = "unit@test.com"
        };

        var actual = request.Validate(new(request)).ToList();
        Assert.Empty(actual);
    }

    [Fact]
    public void TestThatValidEmailDoesReturnMessage()
    {
        var request = new EmailRequest
        {
            EmailAddress = ""
        };

        var actual = request.Validate(new(request)).ToList();
        Assert.Single(actual);
        Assert.Equal($"{request.EmailAddress} is not a valid email address", actual.First().ErrorMessage);
    }
}