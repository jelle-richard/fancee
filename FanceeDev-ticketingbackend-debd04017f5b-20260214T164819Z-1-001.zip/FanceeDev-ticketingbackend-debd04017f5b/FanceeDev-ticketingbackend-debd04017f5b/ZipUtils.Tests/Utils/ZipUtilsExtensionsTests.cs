using Microsoft.Extensions.DependencyInjection;
using ZipUtils.Providers.Zip;
using ZipUtils.Utils;

namespace ZipUtils.Tests.Utils;

public class ZipUtilsExtensionsTests
{
    private readonly Mock<IServiceCollection> _mockedServiceCollection = new();

    [Fact]
    public void TestThatAddZipUtilsRegistersDependencyInjection()
    {
        var actual = _mockedServiceCollection.Object.AddZipUtils();

        Assert.NotNull(actual);

        _mockedServiceCollection.Verify(sc =>
                sc.Add(It.Is<ServiceDescriptor>(sd => sd.ServiceType == typeof(IZipProvider))),
            Times.Once);
    }
}