using System.IO.Compression;
using ZipUtils.Dtos;
using ZipUtils.Providers.Zip;

namespace ZipUtils.Tests.Providers.Zip;

public class ZipProviderTests
{
    private static readonly byte[] ExpectedZipBytes =
    {
        0x50, 0x4B, 0x03, 0x04
    };

    private readonly ZipProvider _sut;

    public ZipProviderTests()
    {
        _sut = new();
    }

    [Fact]
    public void TestThatAddFileAddsFile()
    {
        _sut.AddFile(new() { FileName = "test.txt", Bytes = new byte[] { 0x3A, 0x44 } });

        Assert.Single(_sut.GetEntries());
        Assert.Equal("test.txt", _sut.GetEntries()[0].FileName);
    }

    [Fact]
    public void TestThatAddFilesAddsMultipleFiles()
    {
        _sut.AddFiles(new ZipEntry[]
        {
            new() { FileName = "one.txt", Bytes = new byte[] { 0x3A, 0x44 } },
            new() { FileName = "two.txt", Bytes = new byte[] { 0x3A, 0x2D, 0x70 } }
        });

        Assert.Equal(2, _sut.GetEntries().Count);
        Assert.Equal("one.txt", _sut.GetEntries()[0].FileName);
        Assert.Equal("two.txt", _sut.GetEntries()[1].FileName);
    }

    [Fact]
    public void TestThatSetCompressionLevelSetsCompressionLevel()
    {
        _sut.SetCompressionLevel(CompressionLevel.Fastest);

        Assert.Equal(CompressionLevel.Fastest, _sut.GetCompressionLevel());
    }

    [Fact]
    public void TestThatDefaultCompressionLevelIsOptimal()
    {
        Assert.Equal(CompressionLevel.Optimal, _sut.GetCompressionLevel());
    }

    [Fact]
    public async Task TestThatCompressAsyncCompressesFiles()
    {
        _sut.AddFile(new()
        {
            FileName = "foo.txt",
            Bytes = Enumerable.Repeat((byte)0x61, 200).ToArray() // Generate 'a' 200 times
        });

        var actual = await _sut.CompressAsync();

        Assert.NotEmpty(actual);
        Assert.Equal(ExpectedZipBytes, actual.Take(4)); // We only check the file header, as the other bytes can differ between runs
    }
}