using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedClients
{
    public static readonly DateTime Now = DateTime.UtcNow;

    public static readonly Guid[] UserIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] FanceeUserIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] AddressIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] AccountVerifyIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Client[] Clients =
    [
        new()
        {
            UserId = UserIds[0],
            User = new()
            {
                Id = UserIds[0],
                FanceeUsersId = FanceeUserIds[0],
                Type = UserType.Client,
                Email = "email@unit.test.com",
                LastLogin = default,
                CreatedOn = Now.AddYears(-1).AddDays(10),
                DateOfBirth = default,
                AccountVerifyId = AccountVerifyIds[0],
                UserContactInfo = new()
                {
                    FirstName = "unit",
                    LastName = "test",
                    AddressId = AddressIds[0],
                    PhoneNumber = "0612345678",
                    Address = new()
                    {
                        Id = AddressIds[0],
                        CountryCode = "NL",
                        PostalCode = "0000AA",
                        Street = "Straatweggetje",
                        City = "Amsterdam",
                        HouseNumber = "200"
                    }
                }
            }
        },
        new()
        {
            UserId = UserIds[1],
            User = new()
            {
                Id = UserIds[1],
                FanceeUsersId = FanceeUserIds[1],
                Type = UserType.Client,
                Email = "email@unit.test.com",
                LastLogin = default,
                CreatedOn = Now.AddYears(-1).AddDays(100),
                DateOfBirth = default,
                AccountVerifyId = AccountVerifyIds[1],
                UserContactInfo = new()
                {
                    FirstName = "unit",
                    LastName = "test",
                    AddressId = AddressIds[1],
                    PhoneNumber = "0612345678",
                    Address = new()
                    {
                        Id = AddressIds[1],
                        CountryCode = "NL",
                        PostalCode = "0000AA",
                        Street = "Straatweggetje",
                        City = "Amsterdam",
                        HouseNumber = "200"
                    }
                }
            }
        }
    ];

    public static readonly ClientDto[] ClientsDto =
    [
        new()
        {
            UserId = UserIds[0],
            CreatedOn = Now.AddYears(-1).AddDays(10),
            User = new()
            {
                UserId = UserIds[0],
                FanceeUsersId = FanceeUserIds[0],
                Type = UserType.Client,
                Email = "email@unit.test.com",
                LastLogin = default,
                CreatedOn = Now.AddYears(-1).AddDays(10),
                DateOfBirth = default,
                AccountVerifyId = AccountVerifyIds[0],
                UserContactInfo = new()
                {
                    FirstName = "unit",
                    LastName = "test",
                    AddressId = AddressIds[0],
                    PhoneNumber = "0612345678",
                    Address = new()
                    {
                        AddressId = AddressIds[0],
                        Id = AddressIds[0],
                        CountryCode = "NL",
                        PostalCode = "0000AA",
                        Street = "Straatweggetje",
                        City = "Amsterdam",
                        HouseNumber = "200"
                    }
                }
            }
        },
        new()
        {
            UserId = UserIds[1],
            CreatedOn = Now.AddYears(-1).AddDays(100),
            User = new()
            {
                UserId = UserIds[1],
                FanceeUsersId = FanceeUserIds[1],
                Type = UserType.Client,
                Email = "email@unit.test.com",
                LastLogin = default,
                CreatedOn = Now.AddYears(-1).AddDays(100),
                DateOfBirth = default,
                AccountVerifyId = AccountVerifyIds[1],
                UserContactInfo = new()
                {
                    FirstName = "unit",
                    LastName = "test",
                    AddressId = AddressIds[1],
                    PhoneNumber = "0612345678",
                    Address = new()
                    {
                        AddressId = AddressIds[1],
                        Id = AddressIds[1],
                        CountryCode = "NL",
                        PostalCode = "0000AA",
                        Street = "Straatweggetje",
                        City = "Amsterdam",
                        HouseNumber = "200"
                    }
                }
            }
        }
    ];
}