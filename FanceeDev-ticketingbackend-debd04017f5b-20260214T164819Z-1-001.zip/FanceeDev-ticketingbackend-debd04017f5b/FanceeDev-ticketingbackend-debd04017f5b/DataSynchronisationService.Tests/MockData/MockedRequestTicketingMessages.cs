using WebApiCore.Dtos;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedRequestTicketingMessages
{
    public static readonly RequestTicketingUserDataMessage CreateMessage = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = DateTime.UtcNow.AddDays(-20)
    };

    public static readonly RequestTicketingUserDataMessage UpdateMessage = new()
    {
        SyncType = SynchronisationType.ValidateExistingAndOrUpdate,
        RequestCreatedFrom = DateTime.UtcNow.AddDays(-20),
        RequestUpdateFor = MockedClients.UserIds
    };
}