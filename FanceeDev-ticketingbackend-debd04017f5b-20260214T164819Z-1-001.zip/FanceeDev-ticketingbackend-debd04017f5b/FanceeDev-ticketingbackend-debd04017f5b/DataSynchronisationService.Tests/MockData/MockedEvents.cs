using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedEvents
{
    public static readonly DateTime Now = DateTime.UtcNow;

    public static readonly Guid[] EventIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] OrganizationIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] AddressIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] PaymentMethodIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] ProductIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly string[] ShopCodes =
    [
        "ShopCode A",
        "ShopCode B"
    ];

    public static readonly Event[] Events =
    [
        new()
        {
            Id = EventIds[0],
            OrganizationId = OrganizationIds[0],
            CreatedOn = Now.AddYears(-1).AddDays(10),
            Name = "Base Event",
            Type = EventType.Normal,
            StartDate = default,
            EndDate = default,
            Status = EventStatus.Active,
            Description = "Description of event",
            AddressId = AddressIds[0],
            MinimumAge = 18,
            ReservationTimeMinutes = 30,
            TimezoneIdentification = "Europe/Amsterdam",
            SeatsIoEventId = null,
            Categories = new List<EventCategory>
            {
                new()
                {
                    Name = "Category A",
                    Active = true,
                    Order = 0
                }
            },
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    EventId = EventIds[0],
                    PaymentMethodId = PaymentMethodIds[0],
                    PaidBy = PaidBy.Client,
                    PaymentMethod = new()
                    {
                        Id = PaymentMethodIds[0],
                        Name = "UnitTestPaymentMethod",
                        Provider = PaymentProvider.Adyen,
                        BrandCode = "IDeal",
                        IsChargebackProne = false,
                        SettlementDays = 0,
                        FeePercentage = null,
                        FeeStaticCents = 50,
                        Active = true
                    }
                }
            },
            Address = new()
            {
                Id = AddressIds[0],
                CountryCode = "NL",
                PostalCode = "0000AA",
                Street = "Street",
                City = "City",
                HouseNumber = "420",
                Venue = "Venue",
                Events = null,
                ClientOrders = null,
                InvoiceContactDetails = null,
                OrganizationCommerceWarnings = null,
                Organizations = null
            },
            Organization = new()
            {
                Id = OrganizationIds[0],
                UserId = Guid.NewGuid(),
                Name = "Organisation"
            },
            Products = new List<Product>
            {
                new()
                {
                    Id = ProductIds[0],
                    EventId = EventIds[0],
                    Name = "Product A",
                    Stock = 10,
                    PriceCents = 1000,
                    FeeCents = 50,
                    Description = "Description of Product A",
                    MaximumPurchasePerOrder = 10,
                    PackQuantity = 2,
                    Type = ProductType.Product,
                    PriceHistories = new List<ProductPriceHistory>
                    {
                        new()
                        {
                            ProductId = ProductIds[0],
                            Date = Now.AddDays(-20),
                            PriceCents = 950,
                            FeeCents = 50
                        }
                    }
                }
            },
            Shops = new List<Shop>
            {
                new()
                {
                    Code = ShopCodes[0],
                    EventId = EventIds[0],
                    Name = "Shop A",
                    Active = true,
                    Layout = ShopLayout.List,
                    ItemsInShop = new List<ItemInShop>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            ShopCode = ShopCodes[0],
                            ProductId = ProductIds[0],
                            Position = 0
                        }
                    }
                }
            },
            Tags = new List<EventTag>
            {
                new()
                {
                    Name = "Raggae",
                    EventId = EventIds[0]
                }
            }
        },
        new()
        {
            Id = EventIds[1],
            OrganizationId = OrganizationIds[1],
            Name = "Base Event",
            Type = EventType.Normal,
            StartDate = default,
            EndDate = default,
            Status = EventStatus.Active,
            Description = "Description of event",
            AddressId = AddressIds[1],
            MinimumAge = 18,
            ReservationTimeMinutes = 30,
            CreatedOn = Now.AddYears(-1).AddDays(100),
            TimezoneIdentification = "Europe/Amsterdam",
            SeatsIoEventId = null,
            Categories = new List<EventCategory>
            {
                new()
                {
                    Name = "Category A",
                    Active = true,
                    Order = 0
                }
            },
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    EventId = EventIds[1],
                    PaymentMethodId = PaymentMethodIds[1],
                    PaidBy = PaidBy.Client,
                    PaymentMethod = new()
                    {
                        Id = PaymentMethodIds[1],
                        Name = "UnitTestPaymentMethod",
                        Provider = PaymentProvider.Adyen,
                        BrandCode = "IDeal",
                        IsChargebackProne = false,
                        SettlementDays = 0,
                        FeePercentage = null,
                        FeeStaticCents = 50,
                        Active = true
                    }
                }
            },
            Address = new()
            {
                Id = AddressIds[1],
                CountryCode = "NL",
                PostalCode = "0000AA",
                Street = "Street",
                City = "City",
                HouseNumber = "420",
                Venue = "Venue",
                Events = null,
                ClientOrders = null,
                InvoiceContactDetails = null,
                OrganizationCommerceWarnings = null,
                Organizations = null
            },
            Organization = new()
            {
                Id = OrganizationIds[1],
                UserId = Guid.NewGuid(),
                Name = "Organisation"
            },
            Products = new List<Product>
            {
                new()
                {
                    Id = ProductIds[1],
                    EventId = EventIds[1],
                    Name = "Product A",
                    Stock = 10,
                    PriceCents = 1000,
                    FeeCents = 50,
                    Description = "Description of Product A",
                    MaximumPurchasePerOrder = 10,
                    PackQuantity = 2,
                    Type = ProductType.Product,
                    PriceHistories = new List<ProductPriceHistory>
                    {
                        new()
                        {
                            ProductId = ProductIds[1],
                            Date = Now.AddDays(-20),
                            PriceCents = 950,
                            FeeCents = 50
                        }
                    }
                }
            },
            Shops = new List<Shop>
            {
                new()
                {
                    Code = ShopCodes[1],
                    EventId = EventIds[1],
                    Name = "Shop A",
                    Active = true,
                    Layout = ShopLayout.List,
                    ItemsInShop = new List<ItemInShop>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            ShopCode = ShopCodes[1],
                            ProductId = ProductIds[1],
                            Position = 0
                        }
                    }
                }
            },
            Tags = new List<EventTag>
            {
                new()
                {
                    Name = "Raggae",
                    EventId = EventIds[1]
                }
            }
        }
    ];

    public static readonly EventDto[] EventDtos =
    [
        new()
        {
            EventId = EventIds[0],
            OrganizationId = OrganizationIds[0],
            Name = "Base Event",
            Type = EventType.Normal,
            StartDate = default,
            EndDate = default,
            Status = EventStatus.Active,
            Description = "Description of event",
            AddressId = AddressIds[0],
            MinimumAge = 18,
            ReservationTimeMinutes = 30,
            CreatedOn = Now.AddYears(-1).AddDays(10),
            Address = new()
            {
                AddressId = AddressIds[0],
                Id = AddressIds[0],
                CountryCode = "NL",
                PostalCode = "0000AA",
                Street = "Street",
                City = "City",
                HouseNumber = "420",
                Venue = "Venue"
            },
            Products =
            [
                new()
                {
                    ProductId = ProductIds[0],
                    EventId = EventIds[0],
                    Name = "Product A",
                    PriceCents = 1000,
                    FeeCents = 50,
                    Description = "Description of Product A",
                    MaximumPurchaseOrder = 10,
                    PackQuantity = 2,
                    Type = ProductType.Product,
                    ProductPriceHistory =
                    [
                        new()
                        {
                            ProductId = ProductIds[0],
                            Date = Now.AddDays(-20),
                            PriceCents = 950,
                            FeeCents = 50
                        }
                    ]
                }
            ],
            Shops =
            [
                new()
                {
                    Code = ShopCodes[0],
                    EventId = EventIds[0],
                    Name = "Shop A",
                    Active = true
                }
            ],
            Tags = ["Raggae"]
        },
        new()
        {
            EventId = EventIds[1],
            OrganizationId = OrganizationIds[1],
            Name = "Base Event",
            Type = EventType.Normal,
            StartDate = default,
            EndDate = default,
            Status = EventStatus.Active,
            Description = "Description of event",
            AddressId = AddressIds[1],
            MinimumAge = 18,
            ReservationTimeMinutes = 30,
            CreatedOn = Now.AddYears(-1).AddDays(100),
            Address = new()
            {
                AddressId = AddressIds[1],
                Id = AddressIds[1],
                CountryCode = "NL",
                PostalCode = "0000AA",
                Street = "Street",
                City = "City",
                HouseNumber = "420",
                Venue = "Venue"
            },
            Products =
            [
                new()
                {
                    ProductId = ProductIds[1],
                    EventId = EventIds[1],
                    Name = "Product A",
                    PriceCents = 1000,
                    FeeCents = 50,
                    Description = "Description of Product A",
                    MaximumPurchaseOrder = 10,
                    PackQuantity = 2,
                    Type = ProductType.Product,
                    ProductPriceHistory =
                    [
                        new()
                        {
                            ProductId = ProductIds[1],
                            Date = Now.AddDays(-20),
                            PriceCents = 950,
                            FeeCents = 50
                        }
                    ]
                }
            ],
            Shops =
            [
                new()
                {
                    Code = ShopCodes[1],
                    EventId = EventIds[1],
                    Name = "Shop A",
                    Active = true
                }
            ],
            Tags = ["Raggae"]
        }
    ];
}