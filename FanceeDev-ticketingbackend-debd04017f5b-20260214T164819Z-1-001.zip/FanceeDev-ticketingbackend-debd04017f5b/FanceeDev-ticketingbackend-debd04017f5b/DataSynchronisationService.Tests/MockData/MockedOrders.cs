using DataSynchronisationService.Dtos;
using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedOrders
{
    public static readonly DateTime Now = DateTime.Now;

    public static readonly Guid[] OrderIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] ReservationReferences =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly string[] ShopCodes =
    [
        "ShopCode A",
        "ShopCode B",
        "ShopCode C"
    ];

    public static readonly Guid[] ReservedProductIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] ProductIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] IssuedProductIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid EventId = Guid.NewGuid();

    public static readonly IEnumerable<Order> Orders = new List<Order>
    {
        new()
        {
            Id = OrderIds[0],
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethodId = null,
            CreatedAt = Now.AddYears(-1),
            LastAlteration = default,
            UseGoogleAnalyticsOnOrderComplete = false,
            Currency = "EUR",
            PspReference = "RandomPSPRef",
            ReservationReference = ReservationReferences[0],
            TotalCostCents = 1000,
            PaymentFeeCents = 50,
            PaymentFeePaidBy = PaidBy.Organization,
            PaidOn = Now.AddYears(-1),
            PaymentRefusalReason = null,
            ReservationReferenceNavigation = new()
            {
                Reference = ReservationReferences[0],
                CreatedOn = Now.AddYears(-1),
                ShopCode = ShopCodes[0],
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Id = ReservedProductIds[0],
                        ReservationReference = ReservationReferences[0],
                        ProductId = ProductIds[0],
                        Quantity = 1,
                        ShopCode = ShopCodes[0],
                        Product = new()
                        {
                            Id = ProductIds[0],
                            EventId = EventId
                        }
                    }
                }
            },
            CurrencyNavigation = new()
            {
                ShortCode = "EUR",
                Character = "$",
                Name = "EuroDollars",
                Decimals = 0,
                Active = false
            },
            IssuedProducts = new List<IssuedProduct>
            {
                new()
                {
                    Id = IssuedProductIds[0],
                    ReservedProductId = ReservedProductIds[0],
                    ProductId = ProductIds[0],
                    OrderId = OrderIds[0],
                    Type = IssuedProductType.HardcopyTicket,
                    CreatedOn = Now.AddYears(-1),
                    DeductStock = true
                }
            }
        },
        new()
        {
            Id = OrderIds[1],
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethodId = null,
            CreatedAt = Now.AddYears(-1),
            LastAlteration = default,
            UseGoogleAnalyticsOnOrderComplete = false,
            Currency = "EUR",
            PspReference = "RandomPSPRef",
            ReservationReference = ReservationReferences[1],
            TotalCostCents = 1000,
            PaymentFeeCents = 50,
            PaymentFeePaidBy = PaidBy.Organization,
            PaidOn = Now.AddYears(-1),
            PaymentRefusalReason = null,
            ReservationReferenceNavigation = new()
            {
                Reference = ReservationReferences[1],
                CreatedOn = Now.AddYears(-1),
                ShopCode = ShopCodes[1],
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Id = ReservedProductIds[1],
                        ReservationReference = ReservationReferences[1],
                        ProductId = ProductIds[1],
                        Quantity = 1,
                        ShopCode = ShopCodes[1],
                        Product = new()
                        {
                            Id = ProductIds[1],
                            EventId = EventId
                        }
                    }
                }
            },
            CurrencyNavigation = new()
            {
                ShortCode = "EUR",
                Character = "$",
                Name = "EuroDollars",
                Decimals = 0,
                Active = false
            },
            IssuedProducts = new List<IssuedProduct>
            {
                new()
                {
                    Id = IssuedProductIds[1],
                    ReservedProductId = ReservedProductIds[1],
                    ProductId = ProductIds[1],
                    OrderId = OrderIds[1],
                    Type = IssuedProductType.HardcopyTicket,
                    CreatedOn = Now.AddYears(-1),
                    DeductStock = true
                }
            }
        },
        new()
        {
            Id = OrderIds[2],
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethodId = null,
            CreatedAt = Now.AddYears(-1).AddDays(100),
            LastAlteration = default,
            UseGoogleAnalyticsOnOrderComplete = false,
            Currency = "EUR",
            PspReference = "RandomPSPRef",
            ReservationReference = ReservationReferences[2],
            TotalCostCents = 1000,
            PaymentFeeCents = 50,
            PaymentFeePaidBy = PaidBy.Organization,
            PaidOn = Now.AddYears(-1),
            PaymentRefusalReason = null,
            ReservationReferenceNavigation = new()
            {
                Reference = ReservationReferences[2],
                CreatedOn = Now.AddYears(-1).AddDays(100),
                ShopCode = ShopCodes[2],
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Id = ReservedProductIds[2],
                        ReservationReference = ReservationReferences[2],
                        ProductId = ProductIds[2],
                        Quantity = 1,
                        ShopCode = ShopCodes[2],
                        Product = new()
                        {
                            Id = ProductIds[2],
                            EventId = EventId
                        }
                    }
                }
            },
            CurrencyNavigation = new()
            {
                ShortCode = "EUR",
                Character = "$",
                Name = "EuroDollars",
                Decimals = 0,
                Active = false
            },
            IssuedProducts = new List<IssuedProduct>
            {
                new()
                {
                    Id = IssuedProductIds[2],
                    ReservedProductId = ReservedProductIds[2],
                    ProductId = ProductIds[2],
                    OrderId = OrderIds[2],
                    Type = IssuedProductType.HardcopyTicket,
                    CreatedOn = Now.AddYears(-1).AddDays(100),
                    DeductStock = true
                }
            }
        }
    };

    public static readonly IEnumerable<OrderDto> OrderDtos = new List<OrderDto>
    {
        new()
        {
            OrderId = OrderIds[0],
            EventId = EventId,
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethodId = null,
            CreatedOn = Now.AddYears(-1),
            UpdatedOn = default,
            CurrencyCode = "EUR",
            Currency = new()
            {
                CurrencyCode = "EUR",
                Character = "$",
                Name = "EuroDollars",
                Decimals = 0,
                Active = false
            },
            PspReference = "RandomPSPRef",
            ReservationReferenceId = ReservationReferences[0],
            ReservationReference = new()
            {
                ReservationReferenceId = ReservationReferences[0],
                CreatedOn = Now.AddYears(-1),
                ShopCode = ShopCodes[0],
                ReservedProducts = new List<ReservedProductDto>
                {
                    new()
                    {
                        ReservedProductId = ReservedProductIds[0],
                        ReservationReferenceId = ReservationReferences[0],
                        ProductId = ProductIds[0],
                        Quantity = 1,
                        ShopCode = ShopCodes[0]
                    }
                }
            },
            TotalCostCents = 1000,
            PaymentFeeCents = 50,
            PaymentFeePaidBy = PaidBy.Organization,
            PaidOn = Now.AddYears(-1),
            PaymentRefusalReason = null,
            IssuedProducts = new List<IssuedProductDto>
            {
                new()
                {
                    IssuedProductId = IssuedProductIds[0],
                    ReservedProductId = ReservedProductIds[0],
                    ProductId = ProductIds[0],
                    OrderId = OrderIds[0],
                    Type = IssuedProductType.HardcopyTicket,
                    CreatedOn = Now.AddYears(-1)
                }
            }
        },
        new()
        {
            OrderId = OrderIds[1],
            EventId = EventId,
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethodId = null,
            CreatedOn = Now.AddYears(-1),
            UpdatedOn = default,
            CurrencyCode = "EUR",
            Currency = new()
            {
                CurrencyCode = "EUR",
                Character = "$",
                Name = "EuroDollars",
                Decimals = 0,
                Active = false
            },
            PspReference = "RandomPSPRef",
            ReservationReferenceId = ReservationReferences[1],
            TotalCostCents = 1000,
            PaymentFeeCents = 50,
            PaymentFeePaidBy = PaidBy.Organization,
            PaidOn = Now.AddYears(-1),
            PaymentRefusalReason = null,
            ReservationReference = new()
            {
                ReservationReferenceId = ReservationReferences[1],
                CreatedOn = Now.AddYears(-1),
                ShopCode = ShopCodes[1],
                ReservedProducts = new List<ReservedProductDto>
                {
                    new()
                    {
                        ReservedProductId = ReservedProductIds[1],
                        ReservationReferenceId = ReservationReferences[1],
                        ProductId = ProductIds[1],
                        Quantity = 1,
                        ShopCode = ShopCodes[1]
                    }
                }
            },
            IssuedProducts = new List<IssuedProductDto>
            {
                new()
                {
                    IssuedProductId = IssuedProductIds[1],
                    ReservedProductId = ReservedProductIds[1],
                    ProductId = ProductIds[1],
                    OrderId = OrderIds[1],
                    Type = IssuedProductType.HardcopyTicket,
                    CreatedOn = Now.AddYears(-1)
                }
            }
        },
        new()
        {
            OrderId = OrderIds[2],
            EventId = EventId,
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethodId = null,
            CreatedOn = Now.AddYears(-1).AddDays(100),
            UpdatedOn = default,
            CurrencyCode = "EUR",
            Currency = new()
            {
                CurrencyCode = "EUR",
                Character = "$",
                Name = "EuroDollars",
                Decimals = 0,
                Active = false
            },
            PspReference = "RandomPSPRef",
            ReservationReferenceId = ReservationReferences[2],
            TotalCostCents = 1000,
            PaymentFeeCents = 50,
            PaymentFeePaidBy = PaidBy.Organization,
            PaidOn = Now.AddYears(-1),
            PaymentRefusalReason = null,
            ReservationReference = new()
            {
                ReservationReferenceId = ReservationReferences[2],
                CreatedOn = Now.AddYears(-1).AddDays(100),
                ShopCode = ShopCodes[2],
                ReservedProducts = new List<ReservedProductDto>
                {
                    new()
                    {
                        ReservedProductId = ReservedProductIds[2],
                        ReservationReferenceId = ReservationReferences[2],
                        ProductId = ProductIds[2],
                        Quantity = 1,
                        ShopCode = ShopCodes[2]
                    }
                }
            },
            IssuedProducts = new List<IssuedProductDto>
            {
                new()
                {
                    IssuedProductId = IssuedProductIds[2],
                    ReservedProductId = ReservedProductIds[2],
                    ProductId = ProductIds[2],
                    OrderId = OrderIds[2],
                    Type = IssuedProductType.HardcopyTicket,
                    CreatedOn = Now.AddYears(-1).AddDays(100)
                }
            }
        }
    };
}