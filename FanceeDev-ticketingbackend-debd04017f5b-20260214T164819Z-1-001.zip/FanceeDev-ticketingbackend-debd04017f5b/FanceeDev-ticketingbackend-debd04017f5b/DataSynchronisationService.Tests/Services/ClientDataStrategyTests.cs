using System.Text.Json;
using DataSynchronisationService.Persistence.Client;
using DataSynchronisationService.Services.DataMessageStrategy;
using DataSynchronisationService.Tests.MockData;
using WebApiCore.Dtos;

namespace DataSynchronisationService.Tests.Services;

public class UserDataStrategyTests
{
    private readonly Mock<IClientDao> _mockedClientDao = new();
    private readonly UserDataStrategy _sut;

    public UserDataStrategyTests()
    {
        _sut = new(_mockedClientDao.Object);
    }

    [Fact]
    public void TestThatDataClientStrategyIsOfTicketingDataTypesClient()
    {
        Assert.Equal(TicketingDataType.Clients, _sut.Type);
    }

    [Fact]
    public async Task TestThatExecuteCreateMessageCallsUnderlyingMethodsAndReturnsMessage()
    {
        _mockedClientDao.Setup(cd => cd.NewlyCreatedAsync(It.IsAny<DateTime>()))
            .ReturnsAsync(MockedClients.Clients);

        var actual = await _sut.ExecuteAsync(MockedRequestTicketingMessages.CreateMessage);

        Assert.NotNull(actual.SerializedCreatedData);
        Assert.Equal(JsonSerializer.Serialize(MockedClients.ClientsDto), actual.SerializedCreatedData);
    }

    [Fact]
    public async Task TestThatExecuteUpdateMessageCallsUnderlyingMethodsAndReturnsMessage()
    {
        _mockedClientDao.Setup(cd => cd.UpdatedSinceAsync(MockedClients.UserIds, It.IsAny<DateTime>()))
            .ReturnsAsync(MockedClients.Clients);

        var actual = await _sut.ExecuteAsync(MockedRequestTicketingMessages.UpdateMessage);

        Assert.NotNull(actual.SerializedUpdatedData);
        Assert.Equal(JsonSerializer.Serialize(MockedClients.ClientsDto), actual.SerializedUpdatedData);
    }
}