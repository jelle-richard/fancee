using System.Text.Json;
using DataSynchronisationService.Persistence.Event;
using DataSynchronisationService.Services.DataMessageStrategy;
using DataSynchronisationService.Tests.MockData;
using WebApiCore.Dtos;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Tests.Services;

public class EventDataStrategyTests
{
    private static readonly RequestTicketingUserDataMessage CreateMessage = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = MockedEvents.Now.AddDays(-20)
    };

    private static readonly RequestTicketingUserDataMessage UpdateMessage = new()
    {
        SyncType = SynchronisationType.ValidateExistingAndOrUpdate,
        RequestCreatedFrom = MockedEvents.Now.AddDays(-20),
        RequestUpdateFor = MockedEvents.EventIds
    };

    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly EventDataStrategy _sut;

    public EventDataStrategyTests()
    {
        _sut = new(_mockedEventDao.Object);
    }

    [Fact]
    public void TestThatDataClientStrategyIsOfTicketingDataTypesClient()
    {
        Assert.Equal(TicketingDataType.Events, _sut.Type);
    }

    [Fact]
    public async Task TestThatExecuteCreateMessageCallsUnderlyingMethodsAndReturnsMessage()
    {
        _mockedEventDao.Setup(cd => cd.NewlyCreatedAsync(It.IsAny<DateTime>()))
            .ReturnsAsync(MockedEvents.Events);

        var actual = await _sut.ExecuteAsync(CreateMessage);

        Assert.NotNull(actual.SerializedCreatedData);
        Assert.Equal(JsonSerializer.Serialize(MockedEvents.EventDtos), actual.SerializedCreatedData);
    }

    [Fact]
    public async Task TestThatExecuteUpdateMessageCallsUnderlyingMethodsAndReturnsMessage()
    {
        _mockedEventDao.Setup(cd => cd.UpdatedSinceAsync(MockedEvents.EventIds, It.IsAny<DateTime>()))
            .ReturnsAsync(MockedEvents.Events);

        var actual = await _sut.ExecuteAsync(UpdateMessage);

        Assert.NotNull(actual.SerializedUpdatedData);
        Assert.Equal(JsonSerializer.Serialize(MockedEvents.EventDtos), actual.SerializedUpdatedData);
    }
}