using System.Text.Json;
using DataSynchronisationService.Persistence.Orders;
using DataSynchronisationService.Services.DataMessageStrategy;
using DataSynchronisationService.Tests.MockData;
using WebApiCore.Dtos;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Tests.Services;

public class OrderDataStrategyTests
{
    private static readonly RequestTicketingUserDataMessage CreateMessage = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = MockedEvents.Now.AddDays(-20)
    };

    private static readonly RequestTicketingUserDataMessage UpdateMessage = new()
    {
        SyncType = SynchronisationType.ValidateExistingAndOrUpdate,
        RequestCreatedFrom = MockedEvents.Now.AddDays(-20),
        RequestUpdateFor = MockedEvents.EventIds
    };

    private readonly Mock<IOrderDao> _mockedEventDao = new();
    private readonly OrderDataStrategy _sut;

    public OrderDataStrategyTests()
    {
        _sut = new(_mockedEventDao.Object);
    }

    [Fact]
    public void TestThatDataClientStrategyIsOfTicketingDataTypesClient()
    {
        Assert.Equal(TicketingDataType.Orders, _sut.Type);
    }

    [Fact]
    public async Task TestThatExecuteCreateMessageCallsUnderlyingMethodsAndReturnsMessage()
    {
        _mockedEventDao.Setup(cd => cd.NewlyCreatedAsync(It.IsAny<DateTime>()))
            .ReturnsAsync(MockedOrders.Orders);

        var actual = await _sut.ExecuteAsync(CreateMessage);

        Assert.NotNull(actual.SerializedCreatedData);
        Assert.Equal(JsonSerializer.Serialize(MockedOrders.OrderDtos), actual.SerializedCreatedData);
    }

    [Fact]
    public async Task TestThatExecuteUpdateMessageCallsUnderlyingMethodsAndReturnsMessage()
    {
        _mockedEventDao.Setup(cd => cd.UpdatedSinceAsync(MockedEvents.EventIds, It.IsAny<DateTime>()))
            .ReturnsAsync(MockedOrders.Orders);

        var actual = await _sut.ExecuteAsync(UpdateMessage);

        Assert.NotNull(actual.SerializedUpdatedData);
        Assert.Equal(JsonSerializer.Serialize(MockedOrders.OrderDtos), actual.SerializedUpdatedData);
    }
}