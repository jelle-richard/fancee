using DataSynchronisationService.Persistence.Client;
using DataSynchronisationService.Tests.MockData;
using FanceeData.Contexts;

namespace DataSynchronisationService.Tests.Persistence;

public class ClientDaoTests
{
    private static readonly DateTime DateTime = DateTime.UtcNow.AddYears(-1).AddDays(90);
    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly ClientDao _sut;

    public ClientDaoTests()
    {
        _mockedContext.Setup(c => c.Clients)
            .ReturnsDbSet(MockedClients.Clients);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatNewlyCreatedReturnsNewlyCreatedUntilGivenDateTime()
    {
        var actual = (await _sut.NewlyCreatedAsync(DateTime)).ToList();

        Assert.Single(actual);
        Assert.True(actual[0].User.CreatedOn > DateTime);
    }

    [Fact]
    public async Task TestThatUpdatedSinceAsyncReturnsRecordsUntilGivenDateTimeAndOnlyForGivenIds()
    {
        var actual = (await _sut.UpdatedSinceAsync(MockedClients.UserIds, DateTime)).ToList();
        Assert.Single(actual);
        Assert.True(actual[0].User.CreatedOn < DateTime);
    }
}