using DataSynchronisationService.Persistence.Orders;
using DataSynchronisationService.Tests.MockData;
using FanceeData.Contexts;

namespace DataSynchronisationService.Tests.Persistence;

public class OrderDaoTests
{
    private static readonly DateTime DateTime = DateTime.UtcNow.AddYears(-1).AddDays(90);
    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly OrderDao _sut;

    public OrderDaoTests()
    {
        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(MockedOrders.Orders);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatNewlyCreatedReturnsNewlyCreatedUntilGivenDateTime()
    {
        var actual = (await _sut.NewlyCreatedAsync(DateTime)).ToList();

        Assert.Single(actual);
        Assert.True(actual[0].CreatedAt > DateTime);
    }

    [Fact]
    public async Task TestThatUpdatedSinceAsyncReturnsRecordsUntilGivenDateTime()
    {
        var actual = (await _sut.UpdatedSinceAsync([MockedOrders.OrderIds[0], MockedOrders.OrderIds[1]], DateTime)).ToList();
        Assert.Equal(2, actual.Count);
        Assert.True(actual[0].CreatedAt < DateTime);
    }

    [Fact]
    public async Task TestThatUpdatedSinceAsyncReturnsRecordsUntilGivenDateTimeAndOnlyForGivenIds()
    {
        var actual = (await _sut.UpdatedSinceAsync([MockedOrders.OrderIds[0]], DateTime)).ToList();
        Assert.Single(actual);
        Assert.True(actual[0].CreatedAt < DateTime);
    }
}