using DataSynchronisationService.Persistence.Event;
using DataSynchronisationService.Tests.MockData;
using FanceeData.Contexts;

namespace DataSynchronisationService.Tests.Persistence;

public class EventDaoTests
{
    private static readonly DateTime DateTime = DateTime.UtcNow.AddYears(-1).AddDays(90);
    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly EventDao _sut;

    public EventDaoTests()
    {
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(MockedEvents.Events);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatNewlyCreatedReturnsNewlyCreatedUntilGivenDateTime()
    {
        var actual = (await _sut.NewlyCreatedAsync(DateTime)).ToList();

        Assert.Single(actual);
        Assert.True(actual[0].CreatedOn > DateTime);
    }

    [Fact]
    public async Task TestThatUpdatedSinceAsyncReturnsRecordsUntilGivenDateTimeAndOnlyForGivenIds()
    {
        var actual = (await _sut.UpdatedSinceAsync(MockedEvents.EventIds, DateTime)).ToList();
        Assert.Single(actual);
        Assert.True(actual[0].CreatedOn < DateTime);
    }
}