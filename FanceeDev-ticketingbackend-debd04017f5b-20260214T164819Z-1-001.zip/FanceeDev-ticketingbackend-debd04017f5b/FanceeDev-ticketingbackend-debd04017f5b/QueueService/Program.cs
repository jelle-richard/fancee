using System.Text.Json.Serialization;
using QueueService.Hubs;
using QueueService.Persistence;
using QueueService.Services.Queue;
using QueueService.Utils.Json.Queue;
using WebApiCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    UseSignalR = true,
    SwaggerOptions = new()
    {
        Title = "QueueService",
        EndpointName = "QueueService v1"
    },
    UseS3Storage = false,
    UseRabbitMq = false,
    UseAuthenticationAndAuthorization = false,
    JsonConverters = new List<JsonConverter>
    {
        new DequeuedQueuesJsonConverter()
    }
};

builder.OnConfigureSignalREndpoints += (_, webApplication) => { webApplication.MapHub<QueueHub>("/queue"); };

builder.AddDependency<IQueueService, QueueService.Services.Queue.QueueService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopQueueDao, ShopQueueDao>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();