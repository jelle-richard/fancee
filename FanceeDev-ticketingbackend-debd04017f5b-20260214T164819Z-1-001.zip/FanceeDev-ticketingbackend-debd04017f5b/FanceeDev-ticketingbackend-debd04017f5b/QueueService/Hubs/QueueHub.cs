﻿using System.Collections.Concurrent;
using Microsoft.AspNetCore.SignalR;
using QueueService.Dtos.Responses.Queue;
using QueueService.Services.Queue;
using Timer = System.Timers.Timer;

namespace QueueService.Hubs;

public class QueueHub : Hub
{
    private const int MinuteFlowThroughSplit = 4;
    private const int FlowThroughIntervalMs = 60000 / MinuteFlowThroughSplit;
    private static IQueueService _queueService = default!;
    private static IHubContext<QueueHub> _hubContext = default!;
    private static readonly Dictionary<string, ConcurrentQueue<Guid>> Queues = new();

    static QueueHub()
    {
        var timer = new Timer(FlowThroughIntervalMs);
        timer.Start();
        timer.Elapsed += (sender, args) =>
        {
            if (Queues.Count == 0)
                return;

            Task.Run(Dequeue)
                .Wait();
        };
    }

    public QueueHub(IHubContext<QueueHub> hubContext, IQueueService queueService)
    {
        _hubContext = hubContext;
        _queueService = queueService;
    }

    public async Task Enqueue(string shopCode)
    {
        var shopQueue = await _queueService.ShopQueueAsync(shopCode);
        if (!shopQueue.Enabled)
        {
            await Clients.Caller.SendAsync("ReceiveEnqueueResponse", new QueueErrorResponse
            {
                Message = "Queue is no longer enabled"
            });

            return;
        }

        if (!Queues.ContainsKey(shopCode))
            Queues.Add(shopCode, new());

        var queue = Queues[shopCode];
        var id = Guid.NewGuid();
        queue.Enqueue(id);

        await Clients.Caller.SendAsync("ReceiveEnqueueResponse", new EnqueueResponse
        {
            Id = id,
            Position = queue.Count,
            ShopCode = shopCode
        });
    }

    private static async Task Dequeue()
    {
        var dequeuedQueuesResponse = new DequeuedQueuesResponse();

        foreach (var (key, value) in Queues)
        {
            var shopQueue = await _queueService.ShopQueueAsync(key);
            var flowThrough = shopQueue.FlowThroughPerMinute / MinuteFlowThroughSplit;

            var dequeuedIds = new List<Guid>();
            for (var i = 0; i < flowThrough; i++)
            {
                var removed = value.TryDequeue(out var id);

                //If nothing could be removed, check if queue is empty and if so remove
                if (!removed && value.IsEmpty)
                {
                    Queues.Remove(key);

                    continue;
                }

                dequeuedIds.Add(id);
            }

            dequeuedQueuesResponse.DequeuedQueues.Add(
                key,
                new()
                {
                    Ids = dequeuedIds,
                    RemainingEntries = value.Count
                }
            );
        }

        await _hubContext.Clients.All.SendAsync("ReceiveDequeuedResponse", dequeuedQueuesResponse);
    }
}