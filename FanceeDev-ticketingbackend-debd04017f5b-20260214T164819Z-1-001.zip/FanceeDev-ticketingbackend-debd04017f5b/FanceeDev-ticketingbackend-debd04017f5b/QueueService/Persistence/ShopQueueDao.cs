﻿using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace QueueService.Persistence;

public class ShopQueueDao : IShopQueueDao
{
    private readonly TicketingContext _dbContext;

    public ShopQueueDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<ShopQueue?> ByCodeAsync(string shopCode)
    {
        return await _dbContext.ShopQueues.Where(sq => sq.ShopCode == shopCode)
            .FirstOrDefaultAsync();
    }
}