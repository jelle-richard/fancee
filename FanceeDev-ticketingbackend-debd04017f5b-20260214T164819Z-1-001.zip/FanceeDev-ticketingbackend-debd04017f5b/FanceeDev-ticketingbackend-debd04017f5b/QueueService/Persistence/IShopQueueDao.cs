﻿using FanceeData.Models.Ticketing;

namespace QueueService.Persistence;

public interface IShopQueueDao
{
    /// <summary>
    /// Gets the Queue of a shop by its primary key
    /// </summary>
    /// <param name="shopCode"></param>
    /// <returns></returns>
    public Task<ShopQueue?> ByCodeAsync(string shopCode);
}