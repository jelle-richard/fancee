using System.Collections.Generic;
using System.Threading.Tasks;
using CurrencyService.Controllers;
using CurrencyService.Services;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses.Currency;
using WebApiCore.Services.Cache;
using WebApiCore.Utils;

namespace CurrencyService.Tests.Controllers;

public class CurrenciesControllerTests
{
    private readonly CurrenciesController _sut;
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();

    public CurrenciesControllerTests()
    {
        _mockedCurrencyService.Setup(cs => cs.ActiveCurrenciesAsync())
            .ReturnsAsync(new List<CurrencyResponse>
            {
                new()
                {
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                },
                new()
                {
                    Character = "$",
                    Name = "Dollar",
                    ShortCode = "USD"
                }
            });

        _sut = new(_mockedCurrencyService.Object, _mockedCacheService.Object);
    }

    [Fact]
    public async Task TestThatListActiveChecksCache()
    {
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<IEnumerable<CurrencyResponse>>(CacheKeys.ActiveCurrencies))
            .ReturnsAsync(value: null!);

        await _sut.ListActive();

        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<IEnumerable<CurrencyResponse>>(CacheKeys.ActiveCurrencies), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.ActiveCurrenciesAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatListActiveCallsCurrencyServiceActiveCurrenciesAsyncAndCachesResult()
    {
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<IEnumerable<CurrencyResponse>>(CacheKeys.ActiveCurrencies))
            .ReturnsAsync(value: null!);

        var actual = await _sut.ListActive();

        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<IEnumerable<CurrencyResponse>>(CacheKeys.ActiveCurrencies), Times.Once);
        _mockedCacheService.Verify(cs => cs.CacheObjectAsync(CacheKeys.ActiveCurrencies, It.IsAny<IEnumerable<CurrencyResponse>>(), 7), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.ActiveCurrenciesAsync(), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }
}