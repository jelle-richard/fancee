using System.Threading.Tasks;
using CurrencyService.Controllers;
using CurrencyService.Services;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses.Currency;
using WebApiCore.Services.Cache;
using WebApiCore.Utils;

namespace CurrencyService.Tests.Controllers;

public class CurrencyControllerTests
{
    private readonly CurrencyController _sut;
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();

    public CurrencyControllerTests()
    {
        _mockedCurrencyService.Setup(cs => cs.PlatformBaseCurrencyAsync())
            .ReturnsAsync(new CurrencyResponse
            {
                Character = "€",
                Name = "Euro",
                ShortCode = "EUR"
            });

        _sut = new(_mockedCurrencyService.Object, _mockedCacheService.Object);
    }

    [Fact]
    public async Task TestThatPlatformBaseCurrencyChecksCache()
    {
        await _sut.PlatformBaseCurrency();

        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<CurrencyResponse>(CacheKeys.PlatformBaseCurrency), Times.Once);
    }

    [Fact]
    public async Task TestThatPlatformBaseCurrencyCallsCurrencyServicePlatformBaseCurrencyAsyncWhenNoCacheIsPresent()
    {
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<CurrencyResponse>(CacheKeys.PlatformBaseCurrency))
            .ReturnsAsync(value: null!);

        var actual = await _sut.PlatformBaseCurrency();

        _mockedCurrencyService.Verify(cs => cs.PlatformBaseCurrencyAsync(), Times.Once);
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<CurrencyResponse>(CacheKeys.PlatformBaseCurrency), Times.Once);
        _mockedCacheService.Verify(cs => cs.CacheObjectAsync(CacheKeys.PlatformBaseCurrency, It.IsAny<CurrencyResponse>(), 7), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }
}