﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Persistence.Currency;
using CurrencyService.Persistence.CurrencyExchangeRate;
using CurrencyService.Services.Exceptions;
using FanceeData.Models.Ticketing;
using TestCore.Mocks;

namespace CurrencyService.Tests.Services;

public class CurrencyServiceTests
{
    private readonly CurrencyService.Services.CurrencyService _sut;
    private readonly Mock<ICurrencyExchangeRateDao> _mockedCurrencyExchangeRateDao = new();
    private readonly Mock<ICurrencyDao> _mockedCurrencyDao = new();

    public CurrencyServiceTests()
    {
        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" }
        });

        _sut = new(_mockedCurrencyExchangeRateDao.Object, _mockedCurrencyDao.Object, mockedConfiguration);
    }

    [Fact]
    public async Task TestThatUpdateExchangeRatesAsyncDoesNotUpdateWhenNoChangesAreDetected()
    {
        _mockedCurrencyExchangeRateDao.Setup(cerd => cerd.AllAsync()).ReturnsAsync(new List<CurrencyExchangeRate>
        {
            new()
            {
                CurrencyShortCode = "EUR",
                Rate = 1.0m
            }
        });

        var rates = new ExchangeRates
        {
            LastAlteration = DateTime.UtcNow,
            Rates = new() { { CurrencyCode.EUR, 1.0m } }
        };

        await _sut.UpdateExchangeRatesAsync(rates);

        _mockedCurrencyExchangeRateDao.Verify(cerd => cerd.AllAsync(), Times.Once);
        _mockedCurrencyExchangeRateDao.Verify(cerd => cerd.UpdateRangeAsync(new List<CurrencyExchangeRate>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateExchangeRatesAsyncOnlyUpdatesUpdatedRates()
    {
        _mockedCurrencyExchangeRateDao.Setup(cerd => cerd.AllAsync()).ReturnsAsync(new List<CurrencyExchangeRate>
        {
            new() { CurrencyShortCode = "EUR", Rate = 1.0m },
            new() { CurrencyShortCode = "USD", Rate = 1.14m },
            new() { CurrencyShortCode = "DKK", Rate = 4.53m },
            new() { CurrencyShortCode = "CAD", Rate = 1.5041m },
            new() { CurrencyShortCode = "GBP", Rate = 0.04m }
        });

        var rates = new ExchangeRates
        {
            LastAlteration = DateTime.UtcNow,
            Rates = new()
            {
                { CurrencyCode.EUR, 1.0m },
                { CurrencyCode.USD, 1.15m },
                { CurrencyCode.DKK, 4.53m },
                { CurrencyCode.CAD, 1.6m },
                { CurrencyCode.GBP, 1.0582m }
            }
        };

        await _sut.UpdateExchangeRatesAsync(rates);

        _mockedCurrencyExchangeRateDao.Verify(cerd => cerd.AllAsync(), Times.Once);
        _mockedCurrencyExchangeRateDao.Verify(cerd => cerd.UpdateRangeAsync(
            It.Is<List<CurrencyExchangeRate>>(l => l.Count == 3)
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateExchangeRatesAsyncSkipsCurrenciesThatAreNotFoundInPersistence()
    {
        _mockedCurrencyExchangeRateDao.Setup(cerd => cerd.AllAsync()).ReturnsAsync(new List<CurrencyExchangeRate>
        {
            new() { CurrencyShortCode = "EUR", Rate = 1.0m }
        });

        var rates = new ExchangeRates
        {
            LastAlteration = DateTime.UtcNow,
            Rates = new() { { CurrencyCode.TRY, 24.0m } }
        };

        await _sut.UpdateExchangeRatesAsync(rates);

        _mockedCurrencyExchangeRateDao.Verify(cerd => cerd.AllAsync(), Times.Once);
        _mockedCurrencyExchangeRateDao.Verify(cerd => cerd.UpdateRangeAsync(new List<CurrencyExchangeRate>()), Times.Once);
    }

    [Fact]
    public async Task TestThatActiveCurrenciesAsyncCallsCurrencyDaoActiveCurrenciesAsyncAndAdapts()
    {
        _mockedCurrencyDao.Setup(cd => cd.ActiveCurrenciesAsync())
            .ReturnsAsync(new List<Currency>
            {
                new()
                {
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                },
                new()
                {
                    Character = "$",
                    Name = "Dollar",
                    ShortCode = "USD"
                }
            });

        var actual = await _sut.ActiveCurrenciesAsync();

        Assert.Equal(2, actual.Count());
        _mockedCurrencyDao.Verify(cd => cd.ActiveCurrenciesAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatPlatformBaseCurrencyAsyncThrowsPlatformBaseCurrencyNotConfiguredExceptionWhenConfigurationKeyDoesNotExist()
    {
        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformBaseCurrency", null }
        });

        var sut = new CurrencyService.Services.CurrencyService(_mockedCurrencyExchangeRateDao.Object, _mockedCurrencyDao.Object, mockedConfiguration);

        await Assert.ThrowsAsync<PlatformBaseCurrencyNotConfiguredException>(async () => await sut.PlatformBaseCurrencyAsync());
    }

    [Fact]
    public async Task TestThatPlatformBaseCurrencyAsyncThrowsPlatformBaseCurrencyNotConfiguredExceptionWhenConfigurationPlatformBaseCurrencyIsNotFoundInDatabase()
    {
        _mockedCurrencyDao.Setup(cd => cd.ByShortCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<PlatformBaseCurrencyNotConfiguredException>(async () => await _sut.PlatformBaseCurrencyAsync());
    }

    [Fact]
    public async Task TestThatPlatformBaseCurrencyAsyncListsActiveCurrenciesAndCallsCurrencyDaoPlatformBaseCurrencyAsync()
    {
        _mockedCurrencyDao.Setup(cd => cd.ByShortCodeAsync("EUR"))
            .ReturnsAsync(new Currency
            {
                Character = "€",
                Name = "Euro",
                ShortCode = "EUR"
            });

        var actual = await _sut.PlatformBaseCurrencyAsync();

        Assert.Equal("EUR", actual.ShortCode);
        _mockedCurrencyDao.Verify(cd => cd.ByShortCodeAsync("EUR"), Times.Once);
    }
}