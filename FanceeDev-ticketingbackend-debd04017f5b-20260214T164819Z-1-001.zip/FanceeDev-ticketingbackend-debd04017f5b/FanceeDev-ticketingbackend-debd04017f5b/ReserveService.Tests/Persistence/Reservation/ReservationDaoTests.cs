﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using ReserveService.Persistence.Reservation;

namespace ReserveService.Tests.Persistence.Reservation;

public class ReservationDaoTests
{
    private static readonly FanceeData.Models.Ticketing.Discount MockedDiscount = new()
    {
        Id = Guid.NewGuid(),
        OrganizationId = Guid.NewGuid(),
        Code = "unit",
        Stock = 5,
        CreatedOn = DateTime.UtcNow.AddDays(-5),
        ExpiresOn = DateTime.UtcNow.AddDays(5)
    };

    private readonly ReservationDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    private readonly ReservationReference _mockedReservationReference = new()
    {
        Reference = Guid.NewGuid(),
        Discount = MockedDiscount,
        DiscountId = MockedDiscount.Id
    };

    public ReservationDaoTests()
    {
        _mockedContext = new();

        _mockedContext.Setup(mc => mc.ReservedProducts)
            .ReturnsDbSet(new List<ReservedProduct>());

        _mockedContext.Setup(mc => mc.ReservationReferences)
            .ReturnsDbSet(new[]
            {
                _mockedReservationReference
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatCreateReservationSavesChanges()
    {
        IEnumerable<ReservedProduct> products = new List<ReservedProduct>
        {
            new()
            {
                Id = Guid.NewGuid(),
                ProductId = Guid.NewGuid(),
                Quantity = 2,
                ReservationReference = new()
            }
        };

        await _sut.CreateReservationAsync(products);

        _mockedContext.Verify(mc => mc.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesAndSavesChanges()
    {
        await _sut.UpdateAsync(_mockedReservationReference);

        _mockedContext.Verify(mc => mc.ReservationReferences.Update(_mockedReservationReference), Times.Once);
        _mockedContext.Verify(mc => mc.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatByReferenceAsyncReturnsExpected()
    {
        var actual = await _sut.ByReferenceAsync(_mockedReservationReference.Reference);

        Assert.NotNull(actual);
        Assert.Equal(_mockedReservationReference, actual);
        Assert.Equal(_mockedReservationReference.Reference, actual.Reference);
    }
}