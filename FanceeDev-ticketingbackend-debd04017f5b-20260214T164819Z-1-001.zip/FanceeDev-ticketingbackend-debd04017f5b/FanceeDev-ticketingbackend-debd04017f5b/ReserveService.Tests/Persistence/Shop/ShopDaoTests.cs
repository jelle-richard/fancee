﻿using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using ReserveService.Persistence.Shop;

namespace ReserveService.Tests.Persistence.Shop;

public class ShopDaoTests
{
    private readonly ShopDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public ShopDaoTests()
    {
        _mockedContext = new();

        _mockedContext.Setup(mc => mc.Shops)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Shop>
            {
                new()
                {
                    Code = "ShopCode1",
                    Name = "Shop1"
                },
                new()
                {
                    Code = "ShopCode2",
                    Name = "Shop2"
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsNullOnUnknownShop()
    {
        var actual = await _sut.ByCodeAsync("NonExistingShopCode");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsShopOnValidCode()
    {
        var actual = await _sut.ByCodeAsync("ShopCode1");

        Assert.NotNull(actual);
        Assert.Equal("Shop1", actual!.Name);
    }
}