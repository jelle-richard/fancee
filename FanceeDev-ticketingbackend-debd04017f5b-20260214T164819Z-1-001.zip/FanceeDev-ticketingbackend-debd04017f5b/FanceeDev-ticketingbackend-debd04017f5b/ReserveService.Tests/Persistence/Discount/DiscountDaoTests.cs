using System;
using System.Threading.Tasks;
using FanceeData.Contexts;
using ReserveService.Persistence.Discount;

namespace ReserveService.Tests.Persistence.Discount;

public class DiscountDaoTests
{
    private static readonly FanceeData.Models.Ticketing.Discount MockedDiscount = new()
    {
        Id = Guid.NewGuid(),
        OrganizationId = Guid.NewGuid(),
        Code = "unit",
        Stock = 5,
        CreatedOn = DateTime.UtcNow.AddDays(-5),
        ExpiresOn = DateTime.UtcNow.AddDays(5)
    };

    private readonly DiscountDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public DiscountDaoTests()
    {
        _mockedContext = new();

        _mockedContext.Setup(mc => mc.Discounts)
            .ReturnsDbSet(new[]
            {
                MockedDiscount
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsExpected()
    {
        var actual = await _sut.ByCodeAsync(MockedDiscount.Code);

        Assert.NotNull(actual);
        Assert.Equal(MockedDiscount, actual);
        Assert.Equal(MockedDiscount.Code, actual.Code);
    }
}