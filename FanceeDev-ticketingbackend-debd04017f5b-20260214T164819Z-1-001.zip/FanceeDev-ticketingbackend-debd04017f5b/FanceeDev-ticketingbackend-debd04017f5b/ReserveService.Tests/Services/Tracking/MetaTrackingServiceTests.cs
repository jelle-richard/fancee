using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Fs.PixelTracking.Configuration;
using Fs.PixelTracking.Meta;
using Fs.PixelTracking.Models;
using Microsoft.AspNetCore.Http;
using ReserveService.Dtos.Requests.Reserve;
using ReserveService.Persistence;
using ReserveService.Persistence.Shop;
using ReserveService.Services.Tracking;
using WebApiCore.Services.Currency;

namespace ReserveService.Tests.Services.Tracking;

public class MetaTrackingServiceTests
{
    private const string FacebookAccessCode = "Access123";
    private const string FacebookPixelId = "Pixel123";
    private const string UserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/119.0";
    private const string ShopCode = "Shop123";

    private static readonly Guid EventId = Guid.NewGuid();
    private static readonly Guid[] ProductIds = { Guid.NewGuid(), Guid.NewGuid() };

    private readonly MetaTrackingService _sut;
    private readonly Mock<IMetaTracker> _mockedMetaTracker = new();
    private readonly Mock<IHttpContextAccessor> _mockedHttpContextAccessor = new();
    private readonly Mock<IShopDao> _mockedShopDao = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();
    private readonly Mock<IProductDao> _mockedProductDao = new();

    private readonly Shop _shop = new()
    {
        FacebookAccessCode = FacebookAccessCode,
        FacebookPixelId = FacebookPixelId,
        Code = ShopCode,
        EventId = EventId
    };

    public MetaTrackingServiceTests()
    {
        _mockedCurrencyService.Setup(cs => cs.CentsToDecimalAsync(It.IsAny<string>(), It.IsAny<long>()))
            .ReturnsAsync((string _, long value) => (decimal)value / 100);

        _sut = new(
            _mockedMetaTracker.Object,
            _mockedHttpContextAccessor.Object,
            _mockedShopDao.Object,
            _mockedCurrencyService.Object,
            _mockedProductDao.Object
        );
    }

    [Fact]
    public async Task TestThatRegisterAddToCartAsyncDoesNothingIfUserAgentIsNull()
    {
        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary());

        await _sut.RegisterAddToCartAsync(_shop, new List<ReserveProductRequest>());

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Exactly(2));
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterAddToCartAsyncDoesNothingIfFacebookAccessCodeIsNull()
    {
        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _shop.FacebookAccessCode = null;

        await _sut.RegisterAddToCartAsync(_shop, new List<ReserveProductRequest>());

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterAddToCartAsyncDoesNothingIfFacebookPixelIdIsNull()
    {
        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _shop.FacebookPixelId = null;

        await _sut.RegisterAddToCartAsync(_shop, new List<ReserveProductRequest>());

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterAddToCartAsyncDoesNothingIfFacebookAccessCodeAndPixelIdAreNull()
    {
        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _shop.FacebookAccessCode = null;
        _shop.FacebookPixelId = null;

        await _sut.RegisterAddToCartAsync(_shop, new List<ReserveProductRequest>());

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterAddToCartAsyncCallsMetaTrackerUpdateCartAsync()
    {
        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedHttpContextAccessor.SetupGet(hca => hca.HttpContext!.Connection.RemoteIpAddress)
            .Returns(IPAddress.Loopback);

        _mockedMetaTracker.Setup(mt => mt.SetConfiguration(It.IsAny<MetaConfiguration>()))
            .Returns(_mockedMetaTracker.Object);

        _mockedShopDao.Setup(sd => sd.CurrencyShortCodeByCodeAsync(ShopCode))
            .ReturnsAsync("EUR");

        _mockedProductDao.Setup(pd => pd.ProductPricesAsync(ProductIds.ToList()))
            .ReturnsAsync(new Dictionary<Guid, int?>
            {
                { ProductIds[0], 1000 },
                { ProductIds[1], 2359 }
            });

        var products = new List<ReserveProductRequest>
        {
            new()
            {
                ProductId = ProductIds[0],
                Quantity = 1
            },
            new()
            {
                ProductId = ProductIds[1],
                Quantity = 2
            }
        };

        await _sut.RegisterAddToCartAsync(_shop, products);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedMetaTracker.Verify(mt => mt.SetConfiguration(It.Is<MetaConfiguration>(mc => mc.PixelId == FacebookPixelId && mc.AccessCode == FacebookAccessCode)), Times.Once);
        _mockedShopDao.Verify(sd => sd.CurrencyShortCodeByCodeAsync(ShopCode), Times.Once);
        _mockedProductDao.Verify(pd => pd.ProductPricesAsync(ProductIds.ToList()), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.CentsToDecimalAsync("EUR", It.IsAny<long>()), Times.Exactly(2));
        _mockedMetaTracker.Verify(mt => mt.UpdateCartAsync(It.Is<TrackingInformation>(ti =>
                ti.ShopCode == ShopCode &&
                ti.IpAddress == IPAddress.Loopback &&
                ti.UserAgent == UserAgent &&
                ti.EventId == EventId),
            It.Is<IList<CartItem>>(ci =>
                ci.Count == 2 &&
                ci[0].ProductId == ProductIds[0] &&
                ci[0].Quantity == 1 &&
                ci[0].ItemPrice == 10 &&
                ci[1].ProductId == ProductIds[1] &&
                ci[1].Quantity == 2 &&
                ci[1].ItemPrice == 23.59m
            )
        ), Times.Once);
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterAddToCartAsyncFallsBackIpAddressNone()
    {
        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedHttpContextAccessor.SetupGet(hca => hca.HttpContext!.Connection.RemoteIpAddress)
            .Returns(value: null);

        _mockedMetaTracker.Setup(mt => mt.SetConfiguration(It.IsAny<MetaConfiguration>()))
            .Returns(_mockedMetaTracker.Object);

        _mockedShopDao.Setup(sd => sd.CurrencyShortCodeByCodeAsync(ShopCode))
            .ReturnsAsync("EUR");

        _mockedProductDao.Setup(pd => pd.ProductPricesAsync(It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync(new Dictionary<Guid, int?>());

        await _sut.RegisterAddToCartAsync(_shop, new List<ReserveProductRequest>());

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedMetaTracker.Verify(mt => mt.SetConfiguration(It.Is<MetaConfiguration>(mc => mc.PixelId == FacebookPixelId && mc.AccessCode == FacebookAccessCode)), Times.Once);
        _mockedShopDao.Verify(sd => sd.CurrencyShortCodeByCodeAsync(ShopCode), Times.Once);
        _mockedProductDao.Verify(pd => pd.ProductPricesAsync(It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedMetaTracker.Verify(mt => mt.UpdateCartAsync(It.Is<TrackingInformation>(ti =>
                ti.ShopCode == ShopCode &&
                ti.IpAddress == IPAddress.None &&
                ti.UserAgent == UserAgent &&
                ti.EventId == EventId),
            It.IsAny<IList<CartItem>>()
        ), Times.Once);
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
    }
}