using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Fs.SeatingUtils.Providers;
using ReserveService.Dtos.Requests.Reserve;
using ReserveService.Dtos.Responses.Reserve;
using ReserveService.Persistence.Discount;
using ReserveService.Persistence.Reservation;
using ReserveService.Persistence.Shop;
using ReserveService.Services.Reserve.Exceptions;
using ReserveService.Services.Tracking;
using SeatsioDotNet.EventReports;
using WebApiCore.Exceptions.Event;
using WebApiCore.Exceptions.Shop;
using WebApiCore.Persistence.Product;
using WebApiCore.Persistence.SecureCode;
using ReservationNotFoundException = ReserveService.Services.Reserve.Exceptions.ReservationNotFoundException;

namespace ReserveService.Tests.Services.Reserve;

public class ReserveServiceTests
{
    private const string ShopCode = "UT-ShopCode";
    private const string CampaignCode = "CampaignCode";
    private static readonly Guid[] MockedProductIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private static readonly Guid[] MockedSeatedProductIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private static readonly string[] MockedSeatedProductCategoryKeys = { "key-1", "key-2", "key-3" };
    private static readonly Guid EventId = Guid.NewGuid();
    private static readonly Guid SeatsIoEventId = Guid.NewGuid();
    private static readonly Guid PaymentMethodId = Guid.NewGuid();
    private static readonly Guid ProductIdSaleWindow = Guid.NewGuid();

    private readonly ReserveService.Services.Reserve.ReserveService _sut;
    private readonly Mock<IShopDao> _mockedShopDao = new();
    private readonly Mock<IProductDao> _mockedProductDao = new();
    private readonly Mock<IReservationDao> _mockedReservationDao = new();
    private readonly Mock<IDiscountDao> _mockedDiscountDao = new();
    private readonly Mock<ITrackingService> _mockedTrackingService = new();
    private readonly Mock<ISeatsIoProvider> _mockedSeatsIoProvider = new();
    private readonly Mock<ISecureCodeDao> _mockedSecureCodeDao = new();

    private readonly List<ReserveProductRequest> _products = new()
    {
        new() { ProductId = MockedProductIds[0], Quantity = 2 },
        new() { ProductId = MockedProductIds[1], Quantity = 1 },
        new() { ProductId = MockedProductIds[2], Quantity = 1 }
    };

    private readonly List<ReserveProductRequest> _onlyAccordionProducts =
    [
        new() { ProductId = MockedProductIds[2], Quantity = 1 }
    ];

    private readonly List<ReserveProductRequest> _seatedProducts = new()
    {
        new() { ProductId = MockedSeatedProductIds[0], Quantity = 2, SeatsIoObjectIds = new[] { "A-1", "A-2" } },
        new() { ProductId = MockedSeatedProductIds[1], Quantity = 1, SeatsIoObjectIds = new[] { "B-17" } },
        new() { ProductId = MockedSeatedProductIds[2], Quantity = 1, SeatsIoObjectIds = new[] { "C-11" } }
    };

    private readonly Shop _validShop = new()
    {
        Name = "UnitShop",
        Code = ShopCode,
        Active = true,
        Layout = ShopLayout.Ticketshop,
        StartDate = DateTime.UtcNow,
        EndDate = DateTime.UtcNow.AddDays(1),
        IsSecuredUntil = null,
        ShopCampaigns = new List<ShopCampaign>
        {
            new()
            {
                ShopCode = ShopCode,
                CampaignCode = CampaignCode,
                Clicks = 0
            }
        },
        ShopDesign = new()
        {
            PrimaryColor = "FFFFFF",
            TextColor = "000FFF",
            BackdropColor = "FFF000",
            BackgroundColor = "F0F0F0",
            BackgroundMediaFile = new()
            {
                Id = Guid.NewGuid(),
                Name = "shopbackground.jpg",
                Path = "shop/background.jpg"
            }
        },
        Event = new()
        {
            Id = Guid.NewGuid(),
            OrganizationId = Guid.NewGuid(),
            Name = "UnitTestParty",
            Type = EventType.Normal,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1),
            Status = EventStatus.Active,
            Description = "UnitTestParty-description",
            MinimumAge = 10,
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    PaymentMethodId = PaymentMethodId,
                    PaidBy = PaidBy.Client,
                    PaymentMethod = new()
                    {
                        Id = PaymentMethodId,
                        Name = "UnitPayments",
                        Provider = PaymentProvider.Adyen,
                        FeePercentage = 2,
                        FeeStaticCents = 40,
                        Order = 1,
                        Active = true
                    }
                }
            },
            Organization = new()
            {
                Currency = "EUR",
                CurrencyNavigation = new()
                {
                    Active = true,
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                }
            },
            Products = new List<Product>
            {
                new()
                {
                    Id = MockedProductIds[0],
                    EventId = EventId,
                    Name = "Ticket1",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product
                },
                new()
                {
                    Id = MockedProductIds[1],
                    EventId = EventId,
                    Name = "Ticket2",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product
                },
                new()
                {
                    Id = MockedProductIds[2],
                    EventId = EventId,
                    Name = "Ticket3",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product
                },
                new()
                {
                    Id = MockedSeatedProductIds[0],
                    EventId = EventId,
                    Name = "SeatedTicket0",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.SeatedTicket
                },
                new()
                {
                    Id = MockedSeatedProductIds[1],
                    EventId = EventId,
                    Name = "SeatedTicket1",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.SeatedTicket
                },
                new()
                {
                    Id = MockedSeatedProductIds[2],
                    EventId = EventId,
                    Name = "SeatedTicket2",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.SeatedTicket
                }
            }
        },
        ItemsInShop = new List<ItemInShop>
        {
            new()
            {
                Id = Guid.NewGuid(),
                ShopCode = ShopCode,
                ProductId = MockedProductIds[0],
                Position = 1,
                Product = new()
                {
                    Id = MockedProductIds[0],
                    EventId = EventId,
                    Name = "Ticket1",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product,
                    SaleStart = null,
                    SaleEnd = null
                }
            },
            new()
            {
                Id = Guid.NewGuid(),
                ShopCode = ShopCode,
                ProductId = MockedProductIds[1],
                Position = 2,
                Product = new()
                {
                    Id = MockedProductIds[1],
                    EventId = EventId,
                    Name = "Ticket2",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product,
                    SaleStart = null,
                    SaleEnd = null
                }
            },
            new()
            {
                Id = Guid.NewGuid(),
                ShopCode = ShopCode,
                ProductId = ProductIdSaleWindow,
                Position = 4,
                Product = new()
                {
                    Id = ProductIdSaleWindow,
                    EventId = EventId,
                    Name = "Ticket salewindow",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product,
                    SaleStart = DateTime.UtcNow.AddDays(2),
                    SaleEnd = DateTime.UtcNow.AddDays(10)
                }
            },
            new()
            {
                Id = Guid.NewGuid(),
                ShopCode = ShopCode,
                Position = 3,
                ShopElement = new AccordionElement
                {
                    Elements = new AccordionShopElement[]
                    {
                        new()
                        {
                            Position = 1,
                            ProductId = MockedProductIds[2],
                            Product = new()
                            {
                                Id = MockedProductIds[2],
                                EventId = EventId,
                                Name = "Ticket3",
                                Stock = 651,
                                PriceCents = 8442,
                                Description = "",
                                MaximumPurchasePerOrder = 10,
                                Type = ProductType.Product,
                                SaleStart = null,
                                SaleEnd = null
                            }
                        }
                    }
                }
            }
        }
    };

    public ReserveServiceTests()
    {
        _mockedSeatsIoProvider.Setup(sip => sip.ObjectInfosAsync(SeatsIoEventId.ToString(), _seatedProducts[0].SeatsIoObjectIds))
            .ReturnsAsync(new Dictionary<string, EventObjectInfo>
            {
                {
                    "A-1", new EventObjectInfo
                    {
                        CategoryKey = MockedSeatedProductCategoryKeys[0]
                    }
                },
                {
                    "A-2", new EventObjectInfo
                    {
                        CategoryKey = MockedSeatedProductCategoryKeys[0]
                    }
                }
            });

        _mockedSeatsIoProvider.Setup(sip => sip.ObjectInfosAsync(SeatsIoEventId.ToString(), _seatedProducts[1].SeatsIoObjectIds))
            .ReturnsAsync(new Dictionary<string, EventObjectInfo>
            {
                {
                    "B-17", new EventObjectInfo
                    {
                        CategoryKey = MockedSeatedProductCategoryKeys[1]
                    }
                }
            });

        _mockedSeatsIoProvider.Setup(sip => sip.ObjectInfosAsync(SeatsIoEventId.ToString(), _seatedProducts[2].SeatsIoObjectIds))
            .ReturnsAsync(new Dictionary<string, EventObjectInfo>
            {
                {
                    "C-11", new EventObjectInfo
                    {
                        CategoryKey = MockedSeatedProductCategoryKeys[2]
                    }
                }
            });

        _sut = new(_mockedShopDao.Object, _mockedProductDao.Object, _mockedReservationDao.Object, _mockedDiscountDao.Object, new[] { _mockedTrackingService.Object }, _mockedSeatsIoProvider.Object, _mockedSecureCodeDao.Object);
    }

    [Fact]
    public async Task TestThatValidReserveReturnsReservationReference()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[0], MockedProductIds[1], MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[0], (25, false) },
                { MockedProductIds[1], (25, false) }
            });

        var response = await _sut.ReserveAsync(ShopCode, _products, CampaignCode);

        Assert.IsType<Guid>(response.Reference);
    }

    [Fact]
    public async Task TestThatReserveThrowsProductsNotInStockExceptionIfReservedProductsAreOutsideOfSaleWindow()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[0], MockedProductIds[1], MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[0], (25, true) },
                { ProductIdSaleWindow, (25, true) }
            });

        await Assert.ThrowsAsync<ProductsNotInStockException>(async () => await _sut.ReserveAsync(ShopCode, _products, CampaignCode));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopNotFoundExceptionOnNonExistingShop()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopNotActiveExceptionOnInactiveShop()
    {
        var inactiveShop = _validShop;
        inactiveShop.Active = false;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(inactiveShop);

        await Assert.ThrowsAsync<ShopNotActiveException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopNotActiveExceptionOnExpiredEndDate()
    {
        var expiredShop = _validShop;
        expiredShop.EndDate = DateTime.UtcNow.AddDays(-2);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(expiredShop);

        await Assert.ThrowsAsync<ShopNotActiveException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsEventNotFoundExceptionOnMissingEvent()
    {
        var shopWithoutEvent = _validShop;
        shopWithoutEvent.Event = null;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(shopWithoutEvent);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopMissingProductsExceptionWhenNoProductsConfigured()
    {
        var shopWithoutItems = _validShop;
        shopWithoutItems.ItemsInShop = null;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(shopWithoutItems);

        await Assert.ThrowsAsync<ShopMissingProductsException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopMissingProductsExceptionWhenItemsInShopIsEmpty()
    {
        var shopWithoutItems = _validShop;
        shopWithoutItems.ItemsInShop = new List<ItemInShop>();

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(shopWithoutItems);

        await Assert.ThrowsAsync<ShopMissingProductsException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopMissingProductsExceptionWhenSomeProductNotInShop()
    {
        var products = _products;
        products[0].ProductId = Guid.NewGuid();

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        await Assert.ThrowsAsync<ShopMissingProductsException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopMissingProductsExceptionWhenSomeProductNotInShopIncludingAccordion()
    {
        var products = _products;
        products[2].ProductId = Guid.NewGuid();

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        await Assert.ThrowsAsync<ShopMissingProductsException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsShopMissingProductsExceptionWhenNoProductsRequested()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        await Assert.ThrowsAsync<ShopMissingProductsException>(async () => await _sut.ReserveAsync(ShopCode, new List<ReserveProductRequest>()));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsProductNotInStockExceptionOnInsufficientStock()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[0], MockedProductIds[1], MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[0], (1, false) },
                { MockedProductIds[1], (0, true) },
                { MockedProductIds[2], (1, false) }
            });

        await Assert.ThrowsAsync<ProductsNotInStockException>(async () => await _sut.ReserveAsync(ShopCode, _products));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsProductNotInStockExceptionOnInsufficientStockForProductInAccordion()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[2], (0, false) }
            });

        await Assert.ThrowsAsync<ProductsNotInStockException>(async () => await _sut.ReserveAsync(ShopCode, _onlyAccordionProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncCallsCreateReservationAsync()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[0], MockedProductIds[1], MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[0], (50, false) },
                { MockedProductIds[1], (50, false) }
            });

        await _sut.ReserveAsync(ShopCode, _products);

        _mockedReservationDao.Verify(rd => rd.CreateReservationAsync(It.IsAny<IList<ReservedProduct>>()), Times.Once);
        _mockedTrackingService.Verify(ts => ts.RegisterAddToCartAsync(_validShop, _products), Times.Once);
        _mockedTrackingService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatReserveAsyncWithSecureCodeThrowsSecureCodeNotValidExceptionIfNotApplicable()
    {
        var securedShop = _validShop;
        securedShop.IsSecuredUntil = DateTime.UtcNow.AddDays(100);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(securedShop);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[0], MockedProductIds[1], MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[0], (50, false) },
                { MockedProductIds[1], (50, false) }
            });

        _mockedSecureCodeDao.Setup(scd => scd.AssertApplicableAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<SecureCodeNotValidException>(async () => await _sut.ReserveAsync(ShopCode, _onlyAccordionProducts, null, null, "UnitSecureCode"));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsEventNotActiveExceptionIfEventActiveIsFalse()
    {
        var shopWithInactiveEvent = _validShop;
        shopWithInactiveEvent.Event.Status = EventStatus.Cancelled;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(shopWithInactiveEvent);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[0], MockedProductIds[1], MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[0], (50, false) },
                { MockedProductIds[1], (50, false) }
            });

        _mockedSecureCodeDao.Setup(scd => scd.AssertApplicableAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotActiveException>(async () => await _sut.ReserveAsync(ShopCode, _onlyAccordionProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsEventNotActiveExceptionIfEventEndDateIsSurpassed()
    {
        var shopWithInactiveEvent = _validShop;
        shopWithInactiveEvent.Event.EndDate = DateTime.UtcNow.AddDays(-1);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(shopWithInactiveEvent);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[0], MockedProductIds[1], MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[0], (50, false) },
                { MockedProductIds[1], (50, false) }
            });

        _mockedSecureCodeDao.Setup(scd => scd.AssertApplicableAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotActiveException>(async () => await _sut.ReserveAsync(ShopCode, _onlyAccordionProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncCallsCreateReservationAsyncForProductInAccordion()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        IEnumerable<Guid> expectedProductIds = new[] { MockedProductIds[2] };

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(expectedProductIds))
            .ReturnsAsync(new Dictionary<Guid, (int, bool)>
            {
                { MockedProductIds[2], (50, true) }
            });

        await _sut.ReserveAsync(ShopCode, _onlyAccordionProducts);

        _mockedReservationDao.Verify(rd => rd.CreateReservationAsync(It.IsAny<IList<ReservedProduct>>()), Times.Once);
        _mockedTrackingService.Verify(ts => ts.RegisterAddToCartAsync(_validShop, _onlyAccordionProducts), Times.Once);
        _mockedTrackingService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncReturnsReservationNotFoundExceptionOnInvalidReservation()
    {
        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ReservationNotFoundException>(async () => await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit"));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncReturnsReservationNotFoundExceptionOnExpiredReservation()
    {
        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(-5)
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        await Assert.ThrowsAsync<ReservationNotFoundException>(async () => await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit"));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncReturnsReservationNotFoundExceptionOnReservationWithOrder()
    {
        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            OrderReference = new()
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        await Assert.ThrowsAsync<ReservationNotFoundException>(async () => await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit"));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncThrowsDiscountNotFoundExceptionOnMissingDiscount()
    {
        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5)
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        _mockedDiscountDao.Setup(dd => dd.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<DiscountNotFoundException>(async () => await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit"));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
        _mockedDiscountDao.Verify(dd => dd.ByCodeAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncThrowsDiscountNotFoundExceptionWhenNotApplicableToShopOrProducts()
    {
        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            ReservedProducts = new List<ReservedProduct>
            {
                new()
                {
                    ShopCode = "validShopCode",
                    ProductId = Guid.NewGuid()
                }
            }
        };

        var mockedDiscount = new Discount
        {
            ApplicableDiscounts = new List<DiscountApplicableTo>
            {
                new()
                {
                    ShopCode = "randomShop",
                    ProductId = Guid.NewGuid()
                }
            }
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        _mockedDiscountDao.Setup(dd => dd.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(mockedDiscount);

        await Assert.ThrowsAsync<DiscountNotFoundException>(async () => await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit"));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
        _mockedDiscountDao.Verify(dd => dd.ByCodeAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncThrowsDiscountNoLongerAvailableExceptionOnExpiredDiscount()
    {
        const string validShopCode = "validShopCode";

        var validProductId = Guid.NewGuid();

        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            ReservedProducts = new List<ReservedProduct>
            {
                new()
                {
                    ShopCode = validShopCode,
                    ProductId = validProductId
                }
            }
        };

        var mockedDiscount = new Discount
        {
            ApplicableDiscounts = new List<DiscountApplicableTo>
            {
                new()
                {
                    ShopCode = validShopCode,
                    ProductId = validProductId
                }
            },
            ExpiresOn = DateTime.UtcNow.AddDays(-5)
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        _mockedDiscountDao.Setup(dd => dd.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(mockedDiscount);

        await Assert.ThrowsAsync<DiscountNoLongerAvailableException>(async () => await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit"));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
        _mockedDiscountDao.Verify(dd => dd.ByCodeAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncThrowsDiscountNoLongerAvailableExceptionOnInsufficientStock()
    {
        const string validShopCode = "validShopCode";

        var validProductId = Guid.NewGuid();

        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            ReservedProducts = new List<ReservedProduct>
            {
                new()
                {
                    ShopCode = validShopCode,
                    ProductId = validProductId
                }
            },
            OrderReference = null
        };

        var mockedDiscount = new Discount
        {
            ApplicableDiscounts = new List<DiscountApplicableTo>
            {
                new()
                {
                    ShopCode = validShopCode,
                    ProductId = validProductId
                }
            },
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            Stock = 2,
            ReservationReferences = new List<ReservationReference>
            {
                mockedReservation,
                mockedReservation,
                new()
                {
                    Reference = Guid.NewGuid(),
                    ExpiresOn = DateTime.UtcNow.AddDays(5),
                    ReservedProducts = new List<ReservedProduct>
                    {
                        new()
                        {
                            ShopCode = validShopCode,
                            ProductId = validProductId
                        }
                    },
                    OrderReference = new()
                    {
                        PaymentStatus = PaymentStatus.Authorised
                    }
                }
            }
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        _mockedDiscountDao.Setup(dd => dd.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(mockedDiscount);

        await Assert.ThrowsAsync<DiscountNoLongerAvailableException>(async () => await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit"));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
        _mockedDiscountDao.Verify(dd => dd.ByCodeAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncCallsReservationDaoUpdateAsync()
    {
        const string validShopCode = "validShopCode";

        var validProductId = Guid.NewGuid();

        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            ReservedProducts = new List<ReservedProduct>
            {
                new()
                {
                    ShopCode = validShopCode,
                    ProductId = validProductId
                }
            },
            OrderReference = null
        };

        var mockedDiscount = new Discount
        {
            ApplicableDiscounts = new List<DiscountApplicableTo>
            {
                new()
                {
                    ShopCode = validShopCode,
                    ProductId = validProductId
                }
            },
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            Stock = 5,
            ReservationReferences = new List<ReservationReference>
            {
                mockedReservation,
                mockedReservation,
                new()
                {
                    Reference = Guid.NewGuid(),
                    ExpiresOn = DateTime.UtcNow.AddDays(5),
                    ReservedProducts = new List<ReservedProduct>
                    {
                        new()
                        {
                            ShopCode = validShopCode,
                            ProductId = validProductId
                        }
                    },
                    OrderReference = new()
                    {
                        PaymentStatus = PaymentStatus.Authorised
                    }
                }
            }
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        _mockedDiscountDao.Setup(dd => dd.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(mockedDiscount);

        _mockedReservationDao.Setup(rd => rd.UpdateAsync(It.IsAny<ReservationReference>()));

        await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit");

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
        _mockedDiscountDao.Verify(dd => dd.ByCodeAsync(It.IsAny<string>()), Times.Once);
        _mockedReservationDao.Verify(rd => rd.UpdateAsync(It.IsAny<ReservationReference>()), Times.Once);
    }

    [Fact]
    public async Task TestThatApplyDiscountAsyncReturnsExpected()
    {
        const string validShopCode = "validShopCode";

        var validProductId = Guid.NewGuid();

        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            ReservedProducts = new List<ReservedProduct>
            {
                new()
                {
                    ShopCode = validShopCode,
                    ProductId = validProductId
                }
            },
            OrderReference = null
        };

        var mockedDiscount = new Discount
        {
            ApplicableDiscounts = new List<DiscountApplicableTo>
            {
                new()
                {
                    ShopCode = "randomShopCode",
                    ProductId = validProductId
                }
            },
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            Stock = 5,
            ReservationReferences = new List<ReservationReference>
            {
                mockedReservation,
                mockedReservation,
                new()
                {
                    Reference = Guid.NewGuid(),
                    ExpiresOn = DateTime.UtcNow.AddDays(5),
                    ReservedProducts = new List<ReservedProduct>
                    {
                        new()
                        {
                            ShopCode = validShopCode,
                            ProductId = validProductId
                        }
                    },
                    OrderReference = new()
                    {
                        PaymentStatus = PaymentStatus.Authorised
                    }
                }
            }
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        _mockedDiscountDao.Setup(dd => dd.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(mockedDiscount);

        _mockedReservationDao.Setup(rd => rd.UpdateAsync(It.IsAny<ReservationReference>()));

        var actual = await _sut.ApplyDiscountAsync(Guid.NewGuid(), "unit");

        Assert.IsType<AppliedDiscountResponse>(actual);
        Assert.False(actual.IsApplicableToShop);

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
        _mockedDiscountDao.Verify(dd => dd.ByCodeAsync(It.IsAny<string>()), Times.Once);
        _mockedReservationDao.Verify(rd => rd.UpdateAsync(It.IsAny<ReservationReference>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRemoveDiscountAsyncReturnsReservationNotFoundExceptionOnInvalidReservation()
    {
        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ReservationNotFoundException>(async () => await _sut.RemoveDiscountAsync(Guid.NewGuid()));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRemoveDiscountAsyncReturnsReservationNotFoundExceptionOnExpiredReservation()
    {
        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(-5)
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        await Assert.ThrowsAsync<ReservationNotFoundException>(async () => await _sut.RemoveDiscountAsync(Guid.NewGuid()));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRemoveDiscountAsyncReturnsReservationNotFoundExceptionOnReservationWithOrder()
    {
        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            OrderReference = new()
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        await Assert.ThrowsAsync<ReservationNotFoundException>(async () => await _sut.RemoveDiscountAsync(Guid.NewGuid()));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRemoveDiscountAsyncCallsReservationDaoUpdateAsyncOnInvalidDiscountCode()
    {
        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5)
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        await Assert.ThrowsAsync<DiscountNotFoundException>(async () => await _sut.RemoveDiscountAsync(mockedReservation.Reference));

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRemoveDiscountAsyncCallsReservationDaoUpdateAsync()
    {
        const string validDiscountCode = "validDiscountCode";

        var mockedReservation = new ReservationReference
        {
            Reference = Guid.NewGuid(),
            ExpiresOn = DateTime.UtcNow.AddDays(5),
            Discount = new()
            {
                Code = validDiscountCode
            }
        };

        _mockedReservationDao.Setup(rd => rd.ByReferenceAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedReservation);

        _mockedReservationDao.Setup(rd => rd.UpdateAsync(It.IsAny<ReservationReference>()));

        await _sut.RemoveDiscountAsync(mockedReservation.Reference);

        _mockedReservationDao.Verify(rd => rd.ByReferenceAsync(It.IsAny<Guid>()), Times.Once);
        _mockedReservationDao.Verify(rd => rd.UpdateAsync(It.IsAny<ReservationReference>()), Times.Once);
    }

    [Fact]
    public async Task TestThatReservationOfSeatedProductsValidatesTheSeatsIoObjectIds()
    {
        _validShop.Event.Type = EventType.Seating;
        _validShop.Event.SeatsIoEventId = SeatsIoEventId;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        var response = await _sut.ReserveAsync(ShopCode, _seatedProducts);

        Assert.IsType<Guid>(response.Reference);
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsEventNotSeatedExceptionWhenReservingSeatedProductsForANonSeatedEvent()
    {
        _validShop.Event.Type = EventType.Timeslotted;
        _validShop.Event.SeatsIoEventId = SeatsIoEventId;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        await Assert.ThrowsAsync<EventNotSeatedException>(async () => await _sut.ReserveAsync(ShopCode, _seatedProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsMissingSeatsIoEventBindingExceptionForSeatedEventWithoutSeatsIoEventId()
    {
        _validShop.Event.Type = EventType.Seating;
        _validShop.Event.SeatsIoEventId = null;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        await Assert.ThrowsAsync<MissingSeatsIoEventBindingException>(async () => await _sut.ReserveAsync(ShopCode, _seatedProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsDuplicateSeatsIoObjectIdExceptionForReservationWithDuplicateSeatsIoObjectIds()
    {
        _validShop.Event.Type = EventType.Seating;
        _validShop.Event.SeatsIoEventId = SeatsIoEventId;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        _seatedProducts[0].SeatsIoObjectIds = new[] { "A-2", "A-2" };

        await Assert.ThrowsAsync<DuplicateSeatsIoObjectIdException>(async () => await _sut.ReserveAsync(ShopCode, _seatedProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsSeatedObjectIdMismatchExceptionIfObjectIdCountDoesNotMatchQuantity()
    {
        _validShop.Event.Type = EventType.Seating;
        _validShop.Event.SeatsIoEventId = SeatsIoEventId;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        _seatedProducts[0].Quantity = 7;
        await Assert.ThrowsAsync<SeatedObjectIdMismatchException>(async () => await _sut.ReserveAsync(ShopCode, _seatedProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsProductReservationExceedsMaximumOrderAmountExceptionWhenQuantityExceedsMaxReservationInOrder()
    {
        _validShop.Event.Type = EventType.Seating;
        _validShop.Event.SeatsIoEventId = SeatsIoEventId;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        _seatedProducts[0].Quantity = 99;
        await Assert.ThrowsAsync<ProductReservationExceedsMaximumOrderAmountException>(async () => await _sut.ReserveAsync(ShopCode, _seatedProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsSeatsIoObjectNotFoundExceptionForUnknownObjectIds()
    {
        _validShop.Event.Type = EventType.Seating;
        _validShop.Event.SeatsIoEventId = SeatsIoEventId;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        _mockedSeatsIoProvider.Setup(sip => sip.ObjectInfosAsync(It.IsAny<string>(), It.IsAny<string[]>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<SeatsIoObjectNotFoundException>(async () => await _sut.ReserveAsync(ShopCode, _seatedProducts));
    }

    [Fact]
    public async Task TestThatReserveAsyncThrowsSeatsIoObjectCategoryDoesNotBelongToProductExceptionForMismatchInCategoryKeys()
    {
        _validShop.Event.Type = EventType.Seating;
        _validShop.Event.SeatsIoEventId = SeatsIoEventId;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.ShopCampaigns))
            .ReturnsAsync(_validShop);

        _mockedProductDao.Setup(pd => pd.SeatsIoCategoryToProductMappingAsync(MockedSeatedProductIds))
            .ReturnsAsync(new Dictionary<Guid, string>
            {
                { MockedSeatedProductIds[0], MockedSeatedProductCategoryKeys[0] },
                { MockedSeatedProductIds[1], MockedSeatedProductCategoryKeys[1] },
                { MockedSeatedProductIds[2], MockedSeatedProductCategoryKeys[2] }
            });

        _mockedProductDao.Setup(pd => pd.FilterProductsByTypeAsync(It.IsAny<IEnumerable<Guid>>(), ProductType.SeatedTicket))
            .ReturnsAsync(MockedSeatedProductIds);

        _mockedProductDao.Setup(pd => pd.RemainingProductStocksAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new Dictionary<Guid, (int, bool)>());

        _mockedSeatsIoProvider.Setup(sip => sip.ObjectInfosAsync(SeatsIoEventId.ToString(), _seatedProducts[0].SeatsIoObjectIds))
            .ReturnsAsync(new Dictionary<string, EventObjectInfo>
            {
                {
                    "A-1", new EventObjectInfo
                    {
                        CategoryKey = "WrongKey1"
                    }
                },
                {
                    "A-2", new EventObjectInfo
                    {
                        CategoryKey = "WrongKey2"
                    }
                }
            });

        await Assert.ThrowsAsync<SeatsIoObjectCategoryDoesNotBelongToProductException>(async () => await _sut.ReserveAsync(ShopCode, _seatedProducts));
    }
}