﻿using System;
using System.Collections.Generic;
using System.Linq;
using ReserveService.Dtos.Requests.Reserve;
using ReserveService.Utils.Adapter;

namespace ReserveService.Tests.Utils.Adapter;

public class ReservationAdapterTests
{
    [Fact]
    public void TestThatToReservedProductsParsesReserveProductRequest()
    {
        var productId = Guid.NewGuid();

        var productRequests = new List<ReserveProductRequest>
        {
            new()
            {
                ProductId = productId,
                Quantity = 3
            }
        };

        var actual = productRequests.ToReservedProducts(8, "code");

        Assert.Single(actual);
        Assert.Equal(productId, actual.First().ProductId);
        Assert.Null(actual.First().MetaData);
    }

    [Fact]
    public void TestThatToReservedProductsParsesSeatsIoObjectIdsToJsonMetadata()
    {
        var productId = Guid.NewGuid();

        var productRequests = new List<ReserveProductRequest>
        {
            new()
            {
                ProductId = productId,
                Quantity = 3,
                SeatsIoObjectIds = new[] { "A-1", "A-2", "A-3" }
            }
        };

        var actual = productRequests.ToReservedProducts(8, "code");

        Assert.Single(actual);
        Assert.Equal(productId, actual[0].ProductId);
        Assert.IsType<string>(actual[0].MetaData);
        Assert.Equal("""{"SeatsIoObjectIds":["A-1","A-2","A-3"]}""", actual[0].MetaData);
    }
}