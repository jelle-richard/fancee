using System;
using System.Collections.Generic;
using FanceeData.Models.Ticketing;
using ReserveService.Utils.Adapter;

namespace ReserveService.Tests.Utils.Adapter;

public class DiscountAdapterTests
{
    [Fact]
    public void TestThatToAppliedDiscountResponseParsesDiscount()
    {
        var discount = new Discount
        {
            Code = "unit",
            AmountPercentual = 5,
            AmountStaticCents = 300,
            ApplicableDiscounts = new List<DiscountApplicableTo>
            {
                new()
                {
                    ProductId = Guid.NewGuid()
                },
                new()
                {
                    ProductId = null
                },
                new()
                {
                    ProductId = null
                }
            }
        };

        var actual = discount.ToAppliedDiscountResponse(true);

        Assert.Equal(discount.Code, actual.DiscountCode);
        Assert.Equal(discount.AmountPercentual, actual.AmountPercentual);
        Assert.Equal(discount.AmountStaticCents, actual.AmountStaticCents);
        Assert.True(actual.IsApplicableToShop);
        Assert.Single(actual.MatchingProductIds);
    }
}