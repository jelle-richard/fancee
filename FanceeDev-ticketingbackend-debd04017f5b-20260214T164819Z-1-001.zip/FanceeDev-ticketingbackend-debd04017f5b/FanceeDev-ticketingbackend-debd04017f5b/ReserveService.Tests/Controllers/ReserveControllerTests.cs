﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ReserveService.Controllers;
using ReserveService.Dtos.Requests.Reserve;
using ReserveService.Dtos.Responses.Reserve;
using ReserveService.Services.Reserve;
using WebApiCore.Dtos.Responses;

namespace ReserveService.Tests.Controllers;

public class ReserveControllerTests
{
    private const string UnitTestShopCode = "unitTestShopCode";
    private readonly ReserveController _sut;
    private readonly Mock<IReserveService> _mockedReserveService;

    public ReserveControllerTests()
    {
        _mockedReserveService = new();

        _mockedReserveService.Setup(rs => rs.ReserveAsync(It.IsAny<string>(), It.IsAny<IList<ReserveProductRequest>>(), It.IsAny<string?>(), It.IsAny<string?>(), It.IsAny<string?>(), It.IsAny<string?>()))
            .ReturnsAsync(new ReserveResponse
            {
                Reference = Guid.NewGuid(),
                SecondsRemaining = 240
            });
        _mockedReserveService.Setup(rs => rs.ApplyDiscountAsync(It.IsAny<Guid>(), It.IsAny<string>()))
            .ReturnsAsync(new AppliedDiscountResponse
            {
                DiscountCode = "unit",
                AmountPercentual = 5,
                AmountStaticCents = 300,
                IsApplicableToShop = true,
                MatchingProductIds = new[] { Guid.NewGuid() }
            });

        _sut = new(_mockedReserveService.Object);
    }

    [Fact]
    public async Task TestThatReserveCallsShopServiceReserve()
    {
        var request = new ReserveRequest
        {
            Products = new List<ReserveProductRequest>
            {
                new()
                {
                    ProductId = Guid.NewGuid(),
                    Quantity = 2
                }
            }
        };

        var response = await _sut.Reserve(UnitTestShopCode, request, null, null, null);

        _mockedReserveService.Verify(ss => ss.ReserveAsync(UnitTestShopCode, It.IsAny<IList<ReserveProductRequest>>(), It.IsAny<string?>(), It.IsAny<string?>(), It.IsAny<string?>(), It.IsAny<string?>()), Times.Once);
        Assert.IsType<ActionResult<ApiResponse<ReserveResponse>>>(response);
    }

    [Fact]
    public async Task TestThatApplyDiscountCallsReserveServiceApplyDiscountAsync()
    {
        const string discountCode = "unit";

        var reservationReference = Guid.NewGuid();

        var response = await _sut.ApplyDiscount(reservationReference, discountCode);

        _mockedReserveService.Verify(rs => rs.ApplyDiscountAsync(reservationReference, discountCode));
        Assert.IsType<ActionResult<ApiResponse<AppliedDiscountResponse>>>(response);
    }

    [Fact]
    public async Task TestThatRemoveDiscountCallsReserveServiceRemoveDiscountAsync()
    {
        var reservationReference = Guid.NewGuid();

        await _sut.RemoveDiscount(reservationReference);

        _mockedReserveService.Verify(rs => rs.RemoveDiscountAsync(reservationReference));
    }

    [Fact]
    public async Task TestThatCombiReserveCallsReserveServicePerShopReservationInCombiReserve()
    {
        var combinedShopCode = "CombiCode";

        _mockedReserveService.Setup(rs => rs.ReserveAsync(It.IsAny<string>(), It.IsAny<IList<ReserveProductRequest>>(), null, null, null, combinedShopCode))
            .ReturnsAsync(new ReserveResponse());

        var actual = await _sut.CombiReserve(combinedShopCode, new()
        {
            Reservations = new List<CombinedReserveProductRequest>
            {
                new()
                {
                    Products = new List<ReserveProductRequest>(),
                    ShopCode = "ShopCode1"
                },
                new()
                {
                    Products = new List<ReserveProductRequest>(),
                    ShopCode = "ShopCode2"
                },
                new()
                {
                    Products = new List<ReserveProductRequest>(),
                    ShopCode = "ShopCode3"
                }
            }
        });

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedReserveService.Verify(rs => rs.ReserveAsync(It.IsAny<string>(), It.IsAny<IList<ReserveProductRequest>>(), null, null, null, combinedShopCode), Times.Exactly(3));
    }
}