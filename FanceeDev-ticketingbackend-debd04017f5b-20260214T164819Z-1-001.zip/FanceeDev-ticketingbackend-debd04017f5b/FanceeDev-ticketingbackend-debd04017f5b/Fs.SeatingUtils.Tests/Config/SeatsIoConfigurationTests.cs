using Fs.SeatingUtils.Config;
using Fs.SeatingUtils.Exceptions;
using JetBrains.Annotations;

namespace Fs.SeatingUtils.Tests.Config;

[TestSubject(typeof(SeatsIoConfiguration))]
public class SeatsIoConfigurationTests
{
    [Theory]
    [InlineData("eu", "https://api-eu.seatsio.net")]
    [InlineData("na", "https://api-na.seatsio.net")]
    [InlineData("sa", "https://api-sa.seatsio.net")]
    [InlineData("oc", "https://api-oc.seatsio.net")]
    public void TestThatSeatsIoRegionMapsRegionToCorrectRegion(string input, string expected)
    {
        var sut = new SeatsIoConfiguration
        {
            SecretKey = "test",
            Region = input
        };

        Assert.Equal(expected, sut.SeatsIoRegion.Url());
        Assert.Equal("test", sut.SecretKey);
    }

    [Fact]
    public void TestThatSeatsIoRegionThrowsInvalidSeatsIoRegionExceptionOnInvalidRegionCode()
    {
        var sut = new SeatsIoConfiguration
        {
            SecretKey = "test",
            Region = "failure"
        };

        Assert.Throws<InvalidSeatsIoRegionException>(() => sut.SeatsIoRegion);
    }
}