using Fs.SeatingUtils.Config;
using Fs.SeatingUtils.Providers;
using Fs.SeatingUtils.Utils;
using JetBrains.Annotations;
using Microsoft.Extensions.DependencyInjection;

namespace Fs.SeatingUtils.Tests.Utils;

[TestSubject(typeof(SeatingUtilsExtensions))]
public class SeatingUtilsExtensionsTests
{
    [Fact]
    public void TestThatAddSeatingUtilsRegistersConfigurationAndSeatsIoProvider()
    {
        var serviceCollection = new ServiceCollection();
        var seatsIoConfiguration = new SeatsIoConfiguration { SecretKey = "secret", Region = "eu" };

        serviceCollection.AddLogging();

        var actual = serviceCollection.AddSeatingUtils(seatsIoConfiguration);

        var provider = serviceCollection.BuildServiceProvider();

        Assert.NotNull(actual);
        Assert.IsType<SeatsIoProvider>(provider.GetService<ISeatsIoProvider>());
        Assert.Equal(seatsIoConfiguration, provider.GetService<ISeatsIoConfiguration>());
    }
}