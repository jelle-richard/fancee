using Fs.SeatingUtils.Providers;
using Fs.SeatingUtils.Services.SeatsIo;
using JetBrains.Annotations;
using Microsoft.Extensions.Logging;
using RestSharp;
using SeatsioDotNet;
using SeatsioDotNet.Events;
using TestCore.Mocks;

namespace Fs.SeatingUtils.Tests.Providers;

[TestSubject(typeof(SeatsIoProvider))]
public class SeatsIoProviderTests
{
    private const string SkipReason = "SeatsIO SDK is poorly set up, we cannot override the API calls.";

    private readonly SeatsIoProvider _sut;
    private readonly Mock<ISeatsIoClient> _mockedSeatsIoClient = new();
    private readonly Mock<ILogger<SeatsIoProvider>> _mockedLogger = new();

    public SeatsIoProviderTests()
    {
        _sut = new(_mockedSeatsIoClient.Object, _mockedLogger.Object);
    }

    [Fact(Skip = SkipReason)]
    public async Task TestThatValidEventIdAsyncLogsUnknownError()
    {
        _mockedSeatsIoClient.Setup(sc => sc.Events.Retrieve("invalid"))
            .Throws(SeatsioException.From(MockError("UNKNOWN_ERROR")));

        var actual = await _sut.ValidEventIdAsync("invalid");

        Assert.False(actual);

        _mockedSeatsIoClient.Verify(sc => sc.Events.Retrieve("invalid"), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Error, "An unknown SeatsIO error occured");
        _mockedSeatsIoClient.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact(Skip = SkipReason)]
    public async Task TestThatValidEventIdAsyncDoesNotLogIfErrorIsNotFoundAndReturnsFalse()
    {
        _mockedSeatsIoClient.Setup(sc => sc.Events.Retrieve("invalid"))
            .Throws(SeatsioException.From(MockError("EVENT_NOT_FOUND")));

        var actual = await _sut.ValidEventIdAsync("invalid");

        Assert.False(actual);

        _mockedSeatsIoClient.Verify(sc => sc.Events.Retrieve("invalid"), Times.Once);
        _mockedSeatsIoClient.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact(Skip = SkipReason)]
    public async Task TestThatValidEventIdAsyncReturnsFalseIfEventIsNull()
    {
        _mockedSeatsIoClient.Setup(sc => sc.Events.Retrieve("null"))
            .Returns(value: null!);

        var actual = await _sut.ValidEventIdAsync("null");

        Assert.False(actual);

        _mockedSeatsIoClient.Verify(sc => sc.Events.Retrieve("null"), Times.Once);
        _mockedSeatsIoClient.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact(Skip = SkipReason)]
    public async Task TestThatValidEventIdAsyncReturnsTrueForValidEvent()
    {
        _mockedSeatsIoClient.Setup(sc => sc.Events.Retrieve("valid"))
            .Returns(new Event());

        var actual = await _sut.ValidEventIdAsync("valid");

        Assert.True(actual);

        _mockedSeatsIoClient.Verify(sc => sc.Events.Retrieve("valid"), Times.Once);
        _mockedSeatsIoClient.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    private static RestResponse MockError(string errorCode) =>
        new()
        {
            ContentType = "application/json",
            Content = $$"""{"requestId": "unittest", "errors": [{"code": "{{errorCode}}", "message": "unit test message"}]}"""
        };
}