﻿using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Persistence.Currency;
using CurrencyService.Persistence.CurrencyExchangeRate;
using CurrencyService.Services.Exceptions;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses.Currency;
using WebApiCore.Utils.Adapter.Currency;

namespace CurrencyService.Services;

public class CurrencyService : ICurrencyService
{
    private readonly ICurrencyExchangeRateDao _currencyExchangeRateDao;
    private readonly ICurrencyDao _currencyDao;
    private readonly IConfiguration _configuration;

    public CurrencyService(ICurrencyExchangeRateDao currencyExchangeRateDao, ICurrencyDao currencyDao, IConfiguration configuration)
    {
        _currencyExchangeRateDao = currencyExchangeRateDao;
        _currencyDao = currencyDao;
        _configuration = configuration;
    }

    public async Task UpdateExchangeRatesAsync(ExchangeRates rates)
    {
        var currentRates = await _currencyExchangeRateDao.AllAsync();
        var updatedRates = new List<CurrencyExchangeRate>();

        foreach (var (currencyCode, rate) in rates.Rates)
        {
            var cer = currentRates.FirstOrDefault(cr => cr.CurrencyShortCode == currencyCode.ToString() && cr.Rate != rate);

            if (cer == null)
                continue;

            cer.Rate = rate;

            updatedRates.Add(cer);
        }

        await _currencyExchangeRateDao.UpdateRangeAsync(updatedRates);
    }

    public async Task<IEnumerable<CurrencyResponse>> ActiveCurrenciesAsync()
    {
        var currencies = await _currencyDao.ActiveCurrenciesAsync();

        return currencies.Select(c => c.ToCurrencyResponse());
    }

    public async Task<CurrencyResponse> PlatformBaseCurrencyAsync()
    {
        var platformBaseCurrencyShortCode = _configuration.GetValue<string>("OrganizationDetails:PlatformBaseCurrency") ?? throw new PlatformBaseCurrencyNotConfiguredException();
        var currency = await _currencyDao.ByShortCodeAsync(platformBaseCurrencyShortCode) ?? throw new PlatformBaseCurrencyNotConfiguredException();

        return currency.ToCurrencyResponse();
    }
}