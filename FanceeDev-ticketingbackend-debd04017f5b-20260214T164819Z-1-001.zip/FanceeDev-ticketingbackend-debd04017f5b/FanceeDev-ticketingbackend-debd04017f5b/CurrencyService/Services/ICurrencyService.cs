﻿using CurrencyService.Dtos.Shared.Currency;
using WebApiCore.Dtos.Responses.Currency;

namespace CurrencyService.Services;

public interface ICurrencyService
{
    /// <summary>
    /// Updates the persisted exchange rates with the given exchange rates.
    /// </summary>
    /// <param name="rates"></param>
    /// <returns></returns>
    public Task UpdateExchangeRatesAsync(ExchangeRates rates);

    /// <summary>
    /// Gets the active currencies.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<CurrencyResponse>> ActiveCurrenciesAsync();

    /// <summary>
    /// Gets the standard platform currency.
    /// </summary>
    /// <returns></returns>
    public Task<CurrencyResponse> PlatformBaseCurrencyAsync();
}