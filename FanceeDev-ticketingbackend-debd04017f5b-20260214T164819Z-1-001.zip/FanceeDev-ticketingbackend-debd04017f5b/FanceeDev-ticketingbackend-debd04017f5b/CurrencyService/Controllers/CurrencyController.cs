using CurrencyService.Services;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.Currency;
using WebApiCore.Services.Cache;
using WebApiCore.Utils;

namespace CurrencyService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class CurrencyController : ControllerBase
{
    private readonly ICurrencyService _currencyService;
    private readonly ICacheService _cacheService;

    public CurrencyController(ICurrencyService currencyService, ICacheService cacheService)
    {
        _currencyService = currencyService;
        _cacheService = cacheService;
    }

    [HttpGet]
    [Route("platform-standard")]
    [ProducesResponseType(typeof(ApiResponse<CurrencyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<CurrencyResponse>>> PlatformBaseCurrency()
    {
        var response = await _cacheService.GetCachedObjectAsync<CurrencyResponse>(CacheKeys.PlatformBaseCurrency);

        if (response == null)
        {
            response = await _currencyService.PlatformBaseCurrencyAsync();
            await _cacheService.CacheObjectAsync(CacheKeys.PlatformBaseCurrency, response, 7);
        }

        return Ok(new ApiResponse<CurrencyResponse>
        {
            Data = response
        });
    }
}