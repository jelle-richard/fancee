using CurrencyService.Services;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.Currency;
using WebApiCore.Services.Cache;
using WebApiCore.Utils;

namespace CurrencyService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class CurrenciesController : ControllerBase
{
    private readonly ICurrencyService _currencyService;
    private readonly ICacheService _cacheService;

    public CurrenciesController(ICurrencyService currencyService, ICacheService cacheService)
    {
        _currencyService = currencyService;
        _cacheService = cacheService;
    }

    [HttpGet]
    [Route("active")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<CurrencyResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<CurrencyResponse>>>> ListActive()
    {
        var response = await _cacheService.GetCachedObjectAsync<IEnumerable<CurrencyResponse>>(CacheKeys.ActiveCurrencies);

        if (response == null)
        {
            response = (await _currencyService.ActiveCurrenciesAsync()).ToList();
            await _cacheService.CacheObjectAsync(CacheKeys.ActiveCurrencies, response, 7);
        }

        return Ok(new ApiResponse<IEnumerable<CurrencyResponse>>
        {
            Data = response
        });
    }
}