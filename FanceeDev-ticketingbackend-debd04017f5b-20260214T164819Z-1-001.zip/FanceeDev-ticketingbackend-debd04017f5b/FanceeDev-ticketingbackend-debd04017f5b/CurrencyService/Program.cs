using System.Text.Json.Serialization;
using CurrencyService.BackgroundTasks.MessageBus;
using CurrencyService.Persistence.Currency;
using CurrencyService.Persistence.CurrencyExchangeRate;
using CurrencyService.Providers.Currency;
using CurrencyService.Providers.Currency.ExchangeRateApi;
using CurrencyService.Services;
using CurrencyService.Utils.Converter;
using WebApiCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    UseAuthenticationAndAuthorization = true,
    UseS3Storage = false,
    SwaggerOptions = new()
    {
        Title = "CurrencyService",
        EndpointName = "CurrencyService v1"
    },
    JsonConverters = new List<JsonConverter>
    {
        new CurrencyExchangeRateConverter()
    }
};

builder.AddDependency<ICurrencyExchangeRateDao, CurrencyExchangeRateDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICurrencyService, CurrencyService.Services.CurrencyService>(ServiceLifetime.Scoped);
builder.AddDependency<IExchangeRateProvider, ExchangeRateApiProvider>(ServiceLifetime.Scoped);
builder.AddDependency<ICurrencyService, CurrencyService.Services.CurrencyService>(ServiceLifetime.Scoped);
builder.AddDependency<ICurrencyDao, CurrencyDao>(ServiceLifetime.Scoped);

builder.AddDependency(x => new UpdateCurrencyExchangeRatesListener(x), ServiceLifetime.Singleton);

builder.AddHostedService<UpdateCurrencyExchangeRatesListener>();

var app = builder.Build();
app.Run();