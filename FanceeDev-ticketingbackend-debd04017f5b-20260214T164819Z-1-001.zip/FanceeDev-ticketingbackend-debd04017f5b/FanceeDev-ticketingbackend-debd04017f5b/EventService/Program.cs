using System.Text.Json.Serialization;
using EventService.BackgroundTasks.MessageBus;
using EventService.Persistence.Category;
using EventService.Persistence.Event;
using EventService.Persistence.EventMedia;
using EventService.Persistence.Order;
using EventService.Persistence.Organization;
using EventService.Persistence.PaymentMethod;
using EventService.Persistence.Product;
using EventService.Persistence.Product.Ticket;
using EventService.Persistence.ProductMedia;
using EventService.Persistence.Shop;
using EventService.Persistence.ShopDesignHeaderMedia;
using EventService.Persistence.Ticket;
using EventService.Services.Category;
using EventService.Services.Event;
using EventService.Services.Event.Status;
using EventService.Services.Product;
using EventService.Services.Product.Ticket;
using EventService.Services.SeatsIo;
using EventService.Services.Shop;
using EventService.Utils.Converter;
using Fs.SeatingUtils.Config;
using Fs.SeatingUtils.Utils;
using WebApiCore;
using WebApiCore.Dtos.Shared.ShopElement;
using WebApiCore.Exceptions;
using WebApiCore.Utils.Converter;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "EventService",
        EndpointName = "EventService v1"
    },
    JsonConverters = new List<JsonConverter>
    {
        new ShopElementDtoConverter<ProductElementDto>(),
        new TicketDesignElementDtoConverter()
    }
};

builder.OnConfigureServices += (_, collection) =>
{
    if (builder.IsCiCd)
        return;

    collection.AddSeatingUtils(new SeatsIoConfiguration
    {
        Region = builder.Configuration.GetValue<string>("SeatsIo:Region") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "Region"),
        SecretKey = builder.Configuration.GetValue<string>("SeatsIo:SecretKey") ?? throw new MissingRequiredConfigurationEntryException("SeatsIo", "SecretKey")
    });
};

builder.AddDependency<IEventService, EventService.Services.Event.EventService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationDao, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICategoryService, CategoryService>(ServiceLifetime.Scoped);
builder.AddDependency<ICategoryDao, CategoryDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventsService, EventsService>(ServiceLifetime.Scoped);
builder.AddDependency<IProductService, ProductService>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketDao, TicketDao>(ServiceLifetime.Scoped);
builder.AddDependency<IProductDao, ProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<IProductMediaDao, ProductMediaDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopService, ShopService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDao, ShopDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDesignHeaderMediaDao, ShopDesignHeaderMediaDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopFieldRequirementDao, ShopFieldRequirementDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPaymentMethodDao, PaymentMethodDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventStatusService, EventStatusService>(ServiceLifetime.Scoped);
builder.AddDependency<IStatusService, ActiveStatusService>(ServiceLifetime.Scoped);
builder.AddDependency<IStatusService, UnpublishedStatusService>(ServiceLifetime.Scoped);
builder.AddDependency<IStatusService, CancelledStatusService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderDao, OrderDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopMailService, ShopMailService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopMailDao, ShopMailDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventMailService, EventMailService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventMailDao, EventMailDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventMediaDao, EventMediaDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopQuestionService, ShopQuestionService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopQuestionDao, ShopQuestionDao>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketDesignService, TicketDesignService>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketDesignDao, TicketDesignDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventCancellationService, EventCancellationService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventCancellationDao, EventCancellationDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISeatsIoService, SeatsIoService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopsService, ShopsService>(ServiceLifetime.Scoped);
builder.AddDependency<IShopsDao, ShopsDao>(ServiceLifetime.Scoped);
builder.AddDependency<IProductsService, ProductsService>(ServiceLifetime.Scoped);
builder.AddDependency<IProductsDao, ProductsDao>(ServiceLifetime.Scoped);

builder.AddDependency(sp => new ConcludeEventsListener(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new CleanShopViewsCacheListener(sp), ServiceLifetime.Singleton);

builder.AddHostedService<ConcludeEventsListener>();
builder.AddHostedService<CleanShopViewsCacheListener>();

var app = builder.Build();
app.Run();