using EventService.Dtos.Requests.Product.Media;
using EventService.Dtos.Shared.Ticket;
using EventService.Services.Product.Ticket;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Utils;

namespace EventService.Controllers;

[ApiController]
[Route("/event/{eventId:guid}/product/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class TicketController : ControllerBase
{
    private readonly IOrganizationService _organizationService;
    private readonly ITicketDesignService _ticketDesignService;

    public TicketController(IOrganizationService organizationService, ITicketDesignService ticketDesignService)
    {
        _organizationService = organizationService;
        _ticketDesignService = ticketDesignService;
    }

    [HttpGet]
    [Route("design/elements")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TicketDesignDto>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<TicketDesignDto>>>> TicketDesign(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<TicketDesignDto>>
        {
            Data = await _ticketDesignService.GetAsync(eventId)
        });
    }

    [HttpPost]
    [Route("design/elements")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> AddOrUpdateTicketDesign(Guid eventId, [FromBody] TicketDesignDto request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        await _ticketDesignService.AddOrUpdateDesignAsync(organizationId, eventId, request);

        return Created(string.Empty, new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("design/media")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ApiResponse<Guid>>> UploadMedia(Guid eventId, [FromForm] UploadTicketDesignMediaRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        var uploadedFile = await _ticketDesignService.UploadMediaAsync(eventId, request);

        return Created(uploadedFile.Url, new ApiResponse<Guid>
        {
            Data = uploadedFile.Id
        });
    }

    [HttpDelete]
    [Route("design/media/{fileId:guid}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteMedia(Guid eventId, Guid fileId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        if (!await _ticketDesignService.MediaBelongsToEventAsync(eventId, fileId))
            throw new MediaNotFoundException();

        await _ticketDesignService.DeleteMediaAsync(eventId, fileId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("design/media/{fileId:guid}/focal-point")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateMediaFocalPoint(Guid eventId, Guid fileId, [FromBody] FocalPointRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        if (!await _ticketDesignService.MediaBelongsToEventAsync(eventId, fileId))
            throw new MediaNotFoundException();

        await _ticketDesignService.UpdateMediaFocalPointAsync(eventId, fileId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}