using EventService.Dtos.Responses.Product;
using EventService.Services.Product;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Utils;

namespace EventService.Controllers;

[ApiController]
[Route("/event/{eventId:guid}/[controller]")]
[UseOrganizationHeader]
public class ProductsController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly IOrganizationService _organizationService;

    public ProductsController(IProductService productService, IOrganizationService organizationService)
    {
        _productService = productService;
        _organizationService = organizationService;
    }

    [HttpGet]
    [Route("issued")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ProductSalesResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ProductSalesResponse>>>> EventProductSales(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<ProductSalesResponse>>
        {
            Data = await _productService.EventProductSalesAsync(eventId)
        });
    }

    [HttpGet]
    [Route("shops")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EventProductShopsResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<EventProductShopsResponse>>>> EventProductsShopInfo(Guid eventId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<EventProductShopsResponse>>
        {
            Data = await _productService.ProductShopsAsync(eventId, organizationId)
        });
    }
}