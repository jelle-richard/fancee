using System.Net.Mime;
using EventService.Dtos.Requests.Event.Media;
using EventService.Dtos.Requests.Media;
using EventService.Services.Event;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Utils;

namespace EventService.Controllers;

[ApiController]
[Route("/event/{eventId:guid}/media")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class EventMediaController : ControllerBase
{
    private readonly IOrganizationService _organizationService;
    private readonly IEventService _eventService;

    public EventMediaController(IOrganizationService organizationService, IEventService eventService)
    {
        _organizationService = organizationService;
        _eventService = eventService;
    }

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status503ServiceUnavailable)]
    [Consumes("multipart/form-data")]
    public async Task<ActionResult<ApiResponse<Guid>>> UploadMedia(Guid eventId, [FromForm] UploadEventMediaRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        var uploadedFile = await _eventService.UploadMediaAsync(eventId, request);

        return Created(uploadedFile.Url, new ApiResponse<Guid> { Data = uploadedFile.Id });
    }

    [HttpPut]
    [Route("reposition")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> RepositionMedia(Guid eventId, [FromBody] RepositionMediaRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        await _eventService.RepositionMediaAsync(eventId, request.Positions);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("{fileId:guid}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteMedia(Guid eventId, Guid fileId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        if (!await _eventService.OwnerOfMediaAsync(organizationId, fileId, eventId))
            throw new MediaNotFoundException();

        await _eventService.DeleteMediaAsync(eventId, fileId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("{fileId:guid}/focal-point")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateMediaFocalPoint(Guid eventId, Guid fileId, [FromBody] FocalPointRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        if (!await _eventService.OwnerOfMediaAsync(organizationId, fileId, eventId))
            throw new MediaNotFoundException();

        await _eventService.UpdateMediaFocalPointAsync(eventId, fileId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}