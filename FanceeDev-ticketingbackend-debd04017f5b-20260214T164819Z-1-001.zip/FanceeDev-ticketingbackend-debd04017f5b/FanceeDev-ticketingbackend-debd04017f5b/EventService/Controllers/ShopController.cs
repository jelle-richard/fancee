using System.Diagnostics.CodeAnalysis;
using System.Net.Mime;
using EventService.Dtos.Requests.Media;
using EventService.Dtos.Requests.Shop;
using EventService.Dtos.Responses.Event;
using EventService.Dtos.Responses.Shop;
using EventService.Services.Event;
using EventService.Services.Shop;
using EventService.Services.Shop.Exceptions;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared.ShopElement;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Exceptions.Shop;
using WebApiCore.Services.Cache;
using WebApiCore.Services.Organization;
using WebApiCore.Services.Profanity;
using WebApiCore.Utils;
using InvalidDateRangeException = WebApiCore.Exceptions.InvalidDateRangeException;

namespace EventService.Controllers;

[ApiController]
[Route("/event/{eventId:guid}/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
[SuppressMessage("ReSharper", "RouteTemplates.MatchingConstraintConstructorNotResolved")]
[UseOrganizationHeader]
public class ShopController : ControllerBase
{
    private readonly IOrganizationService _organizationService;
    private readonly IShopService _shopService;
    private readonly IEventService _eventService;
    private readonly IShopMailService _shopMailService;
    private readonly IShopQuestionService _shopQuestionService;
    private readonly IProfanityService _profanityService;
    private readonly IShopCacheService _shopCacheService;

    public ShopController(IOrganizationService organizationService, IShopService shopService, IEventService eventService, IShopMailService shopMailService, IShopQuestionService shopQuestionService, IProfanityService profanityService, IShopCacheService shopCacheService)
    {
        _organizationService = organizationService;
        _shopService = shopService;
        _eventService = eventService;
        _shopMailService = shopMailService;
        _shopQuestionService = shopQuestionService;
        _profanityService = profanityService;
        _shopCacheService = shopCacheService;
    }

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<string>>> Create(Guid eventId, [FromBody] ConfigureShopRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        var @event = await _eventService.GetAsync(eventId, organizationId);

        if (request.StartDate > @event.EndDate || request.EndDate > @event.EndDate)
            throw new InvalidDateRangeException();

        AddRequiredShopFields(@event, request);

        if (!await _shopService.UniqueNameForEventAsync(request.Name!, eventId))
            throw new ShopNameInUseException();

        request.Tags = (await _profanityService.FilterProfanityAsync(request.Tags)).Where(t => t.Length > 0).Distinct().ToArray();

        var shopCode = await _shopService.CreateAsync(request, eventId);

        return CreatedAtAction(nameof(Get), new { eventId, shopCode }, new ApiResponse<string> { Data = shopCode });
    }

    [HttpGet]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<ShopResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ShopResponse>>> Get(Guid eventId, string shopCode)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        return Ok(new ApiResponse<ShopResponse>
        {
            Data = await _shopService.ByCodeAsync(shopCode)
        });
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    public async Task<ActionResult> Update(Guid eventId, string shopCode, [FromBody] ConfigureShopRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfShopAsync(organizationId, shopCode, eventId))
            throw new ShopNotFoundException();

        var @event = await _eventService.GetAsync(eventId, organizationId);

        if (request.StartDate > @event.EndDate || request.EndDate > @event.EndDate)
            throw new InvalidDateRangeException();

        AddRequiredShopFields(@event, request);

        request.Tags = (await _profanityService.FilterProfanityAsync(request.Tags)).Where(t => t.Length > 0).Distinct().ToArray();

        await _shopService.UpdateAsync(request, shopCode, eventId);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return Ok();
    }

    [HttpDelete]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    public async Task<ActionResult> Delete(Guid eventId, string shopCode)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.DeleteAsync(shopCode);

        return Ok();
    }

    [HttpPost]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/background")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ApiResponse<Guid>>> AssignBackgroundMedia(Guid eventId, string shopCode, [FromForm] UploadBackgroundMediaRequest request)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        var uploadedFile = await _shopService.UploadBackgroundMediaAsync(shopCode, request);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return Created(uploadedFile.Url, new ApiResponse<Guid> { Data = uploadedFile.Id });
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/background/focal-point")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateBackgroundMediaFocalPoint(Guid eventId, string shopCode, [FromBody] FocalPointRequest request)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.UpdateBackgroundMediaFocalPointAsync(shopCode, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/background")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteBackgroundMedia(Guid eventId, string shopCode)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.DeleteBackgroundMediaAsync(shopCode);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/header")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [Consumes("multipart/form-data")]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<ApiResponse<Guid>>> AssignHeaderMedia(Guid eventId, string shopCode, [FromForm] UploadHeaderMediaRequest request)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        var uploadedFile = await _shopService.UploadHeaderMediaAsync(shopCode, request);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return Created(uploadedFile.Url, new ApiResponse<Guid> { Data = uploadedFile.Id });
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/header/inherit")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> InheritHeaderMedia(Guid eventId, string shopCode)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.InheritHeaderMediaAsync(shopCode);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/header/reposition")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> RepositionMedia(Guid eventId, string shopCode, [FromBody] RepositionMediaRequest request)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.RepositionHeaderMediaAsync(shopCode, request.Positions);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/header/{{fileId:guid}}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteHeaderMedia(Guid eventId, string shopCode, Guid fileId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfShopAsync(organizationId, shopCode, eventId))
            throw new ShopNotFoundException();

        if (!await _shopService.OwnerOfHeaderMediaAsync(fileId, shopCode, organizationId))
            throw new MediaNotFoundException();

        await _shopService.DeleteHeaderMediaAsync(shopCode, fileId);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/media/header/{{fileId:guid}}/focal-point")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateHeaderMediaFocalPoint(Guid eventId, string shopCode, Guid fileId, [FromBody] FocalPointRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfShopAsync(organizationId, shopCode, eventId))
            throw new ShopNotFoundException();

        if (!await _shopService.OwnerOfHeaderMediaAsync(fileId, shopCode, organizationId))
            throw new MediaNotFoundException();

        await _shopService.UpdateHeaderMediaFocalPointAsync(shopCode, fileId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route($$"""{shopCode:length({{Shop.CodeLengthAttribute}})}/elements""")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ShopElementDto>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ShopElementDto>>>> Elements(Guid eventId, string shopCode)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        return Ok(new ApiResponse<IEnumerable<ShopElementDto>>
        {
            Data = await _shopService.ElementsAsync(shopCode)
        });
    }

    [HttpPost]
    [Route($$"""{shopCode:length({{Shop.CodeLengthAttribute}})}/elements""")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> AssignElements(Guid eventId, string shopCode, [FromBody] List<ShopElementDto> elements)
    {
        var organizationId = Request.GetOrganizationId();

        // Since we have a custom JSON deserializer for this request object, we have to manually check the models for correctness.
        if (elements.Any(element => !TryValidateModel(element)))
            return UnprocessableEntity(ModelState);

        if (!await _organizationService.OwnerOfShopAsync(organizationId, shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.CreateElementAsync(elements, shopCode, organizationId);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return CreatedAtAction(nameof(Get), new { eventId, shopCode }, new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/mail")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateShopMail(Guid eventId, string shopCode, [FromBody] UpdateShopMailRequest request)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopMailService.AddOrUpdateAsync(shopCode, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route($$"""{shopCode:length({{Shop.CodeLengthAttribute}})}/questions""")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> CreateShopQuestions(Guid eventId, string shopCode, [FromBody] List<ShopQuestionRequest> shopQuestionRequests)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopQuestionService.AddAsync(shopCode, shopQuestionRequests);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route($$"""{shopCode:length({{Shop.CodeLengthAttribute}})}/questions/{shopQuestionId:guid}""")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteShopQuestion(Guid eventId, string shopCode, Guid shopQuestionId)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopQuestionService.DeleteAsync(shopQuestionId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route($$"""{shopCode:length({{Shop.CodeLengthAttribute}})}/questions/{shopQuestionId:guid}""")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateShopQuestion(Guid eventId, string shopCode, Guid shopQuestionId, [FromBody] ShopQuestionRequest shopQuestionRequest)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopQuestionService.UpdateAsync(shopCode, shopQuestionId, shopQuestionRequest);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/views")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateViews(Guid eventId, string shopCode, int views = 1)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.UpdateViewsAsync(views, shopCode);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route($"{{shopCode:length({Shop.CodeLengthAttribute})}}/secure")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [Authorize(OrganizationSecureShopPermissions.Add)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status423Locked)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateSecureState(Guid eventId, string shopCode, [FromBody] ShopSecureStateRequest request)
    {
        if (!await _organizationService.OwnerOfShopAsync(Request.GetOrganizationId(), shopCode, eventId))
            throw new ShopNotFoundException();

        await _shopService.SetShopSecureStateAsync(shopCode, request);
        await _shopCacheService.RemoveShopCacheAsync(shopCode);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    /// <summary>
    /// Adds required shop fields to the request, to make sure they are always set, even if the request does not contain them.
    /// </summary>
    /// <param name="event"></param>
    /// <param name="request"></param>
    private static void AddRequiredShopFields(EventResponse @event, ConfigureShopRequest request)
    {
        if (@event.MinAge != null && !request.ShopFields.Any(sfrr => sfrr.Field == ShopField.Birthdate))
        {
            request.ShopFields.Add(new()
            {
                Field = ShopField.Birthdate,
                Required = true,
                Enabled = true
            });
        }
    }
}