﻿using System.Net.Mime;
using EventService.Dtos.Requests.Media;
using EventService.Dtos.Requests.Product.Media;
using EventService.Services.Product;
using EventService.Services.Product.Exceptions;
using EventService.Services.Shop;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Utils;

namespace EventService.Controllers;

[ApiController]
[Route("/event/{eventId:guid}/product/{productId:guid}/media")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class ProductMediaController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly IOrganizationService _organizationService;
    private readonly IShopService _shopService;

    public ProductMediaController(IProductService productService, IOrganizationService organizationService, IShopService shopService)
    {
        _productService = productService;
        _organizationService = organizationService;
        _shopService = shopService;
    }

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    [Consumes("multipart/form-data")]
    public async Task<ActionResult<ApiResponse<Guid>>> UploadMedia(Guid eventId, Guid productId, [FromForm] UploadProductMediaRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        if (!await _productService.BelongsToEvent(productId, eventId))
            throw new ProductNotFoundException();

        var uploadedFile = await _productService.UploadMediaAsync(productId, request);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Created(uploadedFile.Url, new ApiResponse<Guid> { Data = uploadedFile.Id });
    }

    [HttpPut]
    [Route("reposition")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> RepositionMedia(Guid eventId, Guid productId, [FromBody] RepositionMediaRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        if (!await _productService.BelongsToEvent(productId, eventId))
            throw new ProductNotFoundException();

        await _productService.RepositionMediaAsync(productId, request.Positions);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("{fileId:guid}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteMedia(Guid eventId, Guid productId, Guid fileId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        if (!await _productService.BelongsToEvent(productId, eventId))
            throw new ProductNotFoundException();

        if (!await _productService.OwnerOfMediaAsync(organizationId, fileId, productId))
            throw new MediaNotFoundException();

        await _productService.DeleteMediaAsync(productId, eventId, fileId);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("{fileId:guid}/focal-point")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateMediaFocalPoint(Guid eventId, Guid productId, Guid fileId, [FromBody] FocalPointRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        if (!await _productService.BelongsToEvent(productId, eventId))
            throw new ProductNotFoundException();

        if (!await _productService.OwnerOfMediaAsync(organizationId, fileId, productId))
            throw new MediaNotFoundException();

        await _productService.UpdateMediaFocalPointAsync(productId, fileId, request);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}