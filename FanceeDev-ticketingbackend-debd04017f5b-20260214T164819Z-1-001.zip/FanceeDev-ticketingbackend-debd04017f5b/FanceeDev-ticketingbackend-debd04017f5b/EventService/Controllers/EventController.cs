using System.ComponentModel.DataAnnotations;
using System.Net.Mime;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Responses.Event;
using EventService.Services.Category;
using EventService.Services.Event;
using EventService.Services.Event.Status;
using EventService.Services.SeatsIo;
using EventService.Services.Shop;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Fs.SeatingUtils.Providers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests.Event;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.Event;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Country;
using WebApiCore.Services.CountryManager;
using WebApiCore.Services.Organization;
using WebApiCore.Services.Profanity;
using WebApiCore.Utils;

namespace EventService.Controllers;

[ApiController]
[Route("/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class EventController : ControllerBase
{
    private readonly ICategoryService _categoryService;
    private readonly ICountryManagerService _countryManagerService;
    private readonly ICountryService _countryService;
    private readonly IEventMailService _eventMailService;
    private readonly IEventService _eventService;
    private readonly IEventStatusService _eventStatusService;
    private readonly IOrganizationService _organizationService;
    private readonly IShopService _shopService;
    private readonly IProfanityService _profanityService;
    private readonly IEventCancellationService _eventCancellationService;
    private readonly ISeatsIoService _seatsIoService;
    private readonly ISeatsIoProvider _seatsIoProvider;

    public EventController(IEventService eventService, IOrganizationService organizationService, ICategoryService categoryService, IEventStatusService eventStatusService, IShopService shopService, ICountryService countryService, IEventMailService eventMailService, ICountryManagerService countryManagerService, IProfanityService profanityService, IEventCancellationService eventCancellationService, ISeatsIoService seatsIoService, ISeatsIoProvider seatsIoProvider)
    {
        _eventService = eventService;
        _organizationService = organizationService;
        _categoryService = categoryService;
        _eventStatusService = eventStatusService;
        _shopService = shopService;
        _countryService = countryService;
        _eventMailService = eventMailService;
        _countryManagerService = countryManagerService;
        _profanityService = profanityService;
        _eventCancellationService = eventCancellationService;
        _seatsIoService = seatsIoService;
        _seatsIoProvider = seatsIoProvider;
    }

    [HttpGet]
    [Route("{eventId:guid}")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<EventResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EventResponse>>> Get(Guid eventId) =>
        Ok(new ApiResponse<EventResponse>
        {
            Data = await _eventService.GetAsync(eventId, Request.GetOrganizationId())
        });

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<CreateEventResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<CreateEventResponse>>> Create([FromBody] EventRequest request)
    {
        var response = new ApiResponse<CreateEventResponse>();

        await request.Prepare(
            Request.GetOrganizationId(),
            response,
            categories => CategoryValidationCallback(categories, response),
            ValidCountryCodeCallback,
            TagsValidationCallback,
            VerifySeatsIoEventIdAsync
        );

        if (response.Errors?.Any() ?? false)
            return BadRequest(response);

        response.Data = new()
        {
            Id = await _eventService.CreateAsync(request)
        };

        return Ok(response);
    }

    [HttpPut]
    [Route("{eventId:guid}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Update(Guid eventId, [FromBody] UpdateEventRequest request)
    {
        var response = new ApiResponse<EmptyResponse>();
        var organizationId = Request.GetOrganizationId();

        await request.Prepare(
            organizationId,
            response,
            categories => CategoryValidationCallback(categories, response),
            ValidCountryCodeCallback,
            TagsValidationCallback,
            VerifySeatsIoEventIdAsync
        );

        if (response.Errors?.Any() ?? false)
            return BadRequest(response);

        await _eventService.UpdateAsync(organizationId, eventId, request);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("{eventId:guid}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult> Delete(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        await _eventService.DeleteAsync(eventId);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok();
    }

    [HttpGet]
    [Route("{eventId:guid}/payment-methods")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>>> GetPaymentMethods(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>
        {
            Data = await _eventService.AvailablePaymentMethodsAsync(eventId)
        });
    }

    [HttpPut]
    [Route("{eventId:guid}/payment-methods")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult> AssignPaymentMethods(Guid eventId, [FromBody] AssignPaymentMethodsRequestModel request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        await _eventService.AssignPaymentMethodsAsync(eventId, organizationId, request.PaymentMethods!);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok();
    }

    [HttpPut]
    [Route("{eventId:guid}/validate")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EventValidationResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EventValidationResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EventValidationResponse>>> ValidateEvent(Guid eventId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<EventValidationResponse>
        {
            Data = await _eventService.ValidateAsync(eventId, organizationId)
        });
    }

    [HttpPut]
    [Route("{eventId:guid}/status")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ChangeEventStatus(Guid eventId, [FromBody] ChangeStatusRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        await _eventStatusService.ChangeStatusAsync(eventId, organizationId, (ChangeableEventStatus)request.Status!);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("{eventId:guid}/copy")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<CreateEventResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<CreateEventResponse>>> CopyEvent(Guid eventId, [FromBody] CopyEventRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<CreateEventResponse>
        {
            Data = new()
            {
                Id = await _eventService.CopyEventAsync(eventId, request)
            }
        });
    }

    [HttpGet]
    [Route("{eventId:guid}/statistics")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<GlobalEventStatisticsResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<GlobalEventStatisticsResponse>>> Statistics(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<GlobalEventStatisticsResponse>
        {
            Data = await _eventService.StatisticsAsync(eventId)
        });
    }

    [HttpGet]
    [Route("{eventId:guid}/revenues")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<RevenueResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<RevenueResponse>>> Revenues(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<RevenueResponse>
        {
            Data = await _eventService.RevenuesAsync(eventId, Request.GetOrganizationId())
        });
    }

    [HttpGet]
    [Route("{eventId:guid}/mail")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<EventMailResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EventMailResponse>>> GetMail(Guid eventId, [FromQuery] EventMailRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<EventMailResponse>
        {
            Data = await _eventMailService.EventMailAsync(eventId, request)
        });
    }

    [HttpPut]
    [Route("{eventId:guid}/mail")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateMail(Guid eventId, [FromBody] UpdateEventMailRequest request)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        await _eventMailService.AddOrUpdateAsync(eventId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("{eventId:guid}/review")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Review(Guid eventId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        var reviewRecipientEmails = (await _countryManagerService.CountryManagerEmailsForOrganization(organizationId)).ToList();

        if (!reviewRecipientEmails.Any())
            reviewRecipientEmails.Add(new("support@wearefancee.com", "Support"));

        foreach (var reviewRecipient in reviewRecipientEmails)
            await _eventMailService.SendEventReviewMailAsync(eventId, organizationId, reviewRecipient);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{eventId:guid}/statistics/countries")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EventCustomersCountryStatisticsResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<EventCustomersCountryStatisticsResponse>>>> CountryStatistics(Guid eventId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<EventCustomersCountryStatisticsResponse>>
        {
            Data = await _eventService.CustomerCountryStatisticsAsync(eventId)
        });
    }

    [HttpGet]
    [Route("{eventId:guid}/statistics/cities")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EventCustomersCityStatisticsResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<EventCustomersCityStatisticsResponse>>>> CityStatistics(Guid eventId, [FromQuery] [Required] string countryCode)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<EventCustomersCityStatisticsResponse>>
        {
            Data = await _eventService.CustomerCityStatisticsAsync(eventId, countryCode)
        });
    }

    [HttpPost]
    [Route("{eventId:guid}/cancel")]
    [Authorize(OrganizationEventPermissions.Cancel)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> CreateEventCancellation([FromRoute] Guid eventId, EventCancelRequest cancelRequest)
    {
        var organizationId = Request.GetOrganizationId();
        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        await _eventCancellationService.CreateAsync(eventId, organizationId, cancelRequest);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("seats/{seatsIoEventId:guid}/validate")]
    [Authorize(OrganizationEventPermissions.TypeSeating)]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<bool>>> ValidateSeatsIoEventId([FromRoute] Guid seatsIoEventId) =>
        Ok(new ApiResponse<bool>
        {
            Data = await VerifySeatsIoEventIdAsync(seatsIoEventId)
        });

    [HttpGet]
    [Route("{eventId:guid}/seats/sync")]
    [Authorize(OrganizationEventPermissions.TypeSeating)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> SyncSeatsIoCategories([FromRoute] Guid eventId)
    {
        await _seatsIoService.SyncCategoriesAsync(eventId, Request.GetOrganizationId());
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    private async Task<IList<EventCategory>> CategoryValidationCallback<T>(IEnumerable<string> categories, ApiResponse<T> response)
    {
        var validCategoryNames = (await _categoryService.GetAllActiveSubCategories())
            .ToList();

        var mappedCategories = new List<EventCategory>();

        foreach (var category in categories)
        {
            if (validCategoryNames.All(vcn => !string.Equals(vcn.Name, category, StringComparison.InvariantCultureIgnoreCase)))
                response.AddError(ErrorCode.ExceptionInvalidData, $"'{category}' is not a valid category");
            else
                mappedCategories.Add(validCategoryNames.First(vcn => string.Equals(vcn.Name, category, StringComparison.InvariantCultureIgnoreCase)));
        }

        return mappedCategories;
    }

    private async Task<bool> ValidCountryCodeCallback(string countryCode) => await _countryService.ValidAsync(countryCode);

    private async Task<IList<Profanity>> TagsValidationCallback(IEnumerable<string> tags) => await _profanityService.ListProfanitiesInTextAsync(string.Join(' ', tags));

    private async Task<bool> VerifySeatsIoEventIdAsync(Guid eventId) => await _seatsIoProvider.ValidEventIdAsync(eventId.ToString());
}