﻿using System.Net.Mime;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Requests.Product;
using EventService.Dtos.Requests.Shop;
using EventService.Dtos.Responses.Event;
using EventService.Dtos.Responses.Events;
using EventService.Dtos.Responses.Product;
using EventService.Services.Event;
using EventService.Services.Product;
using EventService.Services.Shop;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Services.Country;
using WebApiCore.Services.Logging;
using WebApiCore.Utils;
using WebApiCore.Utils.Adapter;
using WebApiCore.Utils.HttpContext;

namespace EventService.Controllers;

[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[Produces(MediaTypeNames.Application.Json)]
public class EventsController : ControllerBase
{
    private readonly IEventsService _eventsService;
    private readonly IProductService _productService;
    private readonly ICountryService _countryService;
    private readonly IEventService _eventService;
    private readonly IUserLoggingService _userLoggingService;
    private readonly IShopsService _shopsService;
    private readonly IProductsService _productsService;

    public EventsController(IEventsService eventsService, IProductService productService, ICountryService countryService, IEventService eventService, IUserLoggingService userLoggingService, IShopsService shopsService, IProductsService productsService)
    {
        _eventsService = eventsService;
        _productService = productService;
        _countryService = countryService;
        _eventService = eventService;
        _userLoggingService = userLoggingService;
        _shopsService = shopsService;
        _productsService = productsService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(OrganizationEventPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<EventListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<EventListItemResponse>>>> List([FromQuery] PaginatedRequest<EventsRequestFilter> request)
    {
        var result = await _eventsService.ListEventsAsync(request, Request.GetOrganizationId());

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("list/select-options")]
    [Authorize(OrganizationEventPermissions.List)]
    [ProducesResponseType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>> ListSelectOptions(SelectOptionsRequest<Guid> request) =>
        Ok(new ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>
        {
            Data = await _eventsService.ListSelectOptionsAsync(Request.GetOrganizationId(), request)
        });

    [HttpGet]
    [Route("admin/list/{organizationId:guid}")]
    [Authorize(AdminEventPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<EventListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<EventListItemResponse>>>> List(Guid organizationId, [FromQuery] PaginatedRequest<EventsRequestFilter> request)
    {
        request.Options.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.Options.CountryCodes);

        var result = await _eventsService.ListEventsAsync(request, organizationId);

        await _userLoggingService.LogAsync(User.GetUserId(), $"Has taken a look at the events of the following organization: {organizationId}");

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("app-team/list")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<EventListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<EventListItemResponse>>>> AppTeamList([FromQuery] PaginatedRequest<EventsRequestFilter> request)
    {
        var result = await _eventsService.ListAppTeamEventsAsync(request, User.GetAppTeamId());

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("admin/list")]
    [Authorize(AdminEventPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<EventListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<EventListItemResponse>>>> ListAll([FromQuery] PaginatedRequest<EventsRequestFilter> request)
    {
        request.Options.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.Options.CountryCodes);

        var result = await _eventsService.ListEventsAsync(request);

        await _userLoggingService.LogAsync(User.GetUserId(), "Has taken a look at all the events of the platform");

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("admin/list/select-options")]
    [Authorize(AdminEventPermissions.List)]
    [ProducesResponseType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(StatusCodes.Status200OK)]
    public async Task<ActionResult<IEnumerable<SelectOptionResponse<Guid>>>> AdminListSelectOptions(SelectOptionsRequest<Guid> request) =>
        Ok(new ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>
        {
            Data = await _eventsService.ListSelectOptionsAsync(request)
        });

    [HttpGet]
    [Route("organization/export/csv")]
    [Authorize(OrganizationEventPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<FileResult> ExportOrganizationEventsAsCsv([FromQuery] EventsRequestFilter request)
    {
        var file = await _eventsService.OrganizationEventsAsCsvAsync(Request.GetOrganizationId(), request);

        return ServeEventExportCsvFile(file);
    }

    [HttpGet]
    [Route("admin/export/csv")]
    [Authorize(AdminEventPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> AdminExportPlatformEventsAsCsv([FromQuery] EventsRequestFilter request)
    {
        request.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.CountryCodes);

        var file = await _eventsService.PlatformEventsAsCsvAsync(request);

        await _userLoggingService.LogAsync(User.GetUserId(), "Has made en export of all the events on the platform");

        return ServeEventExportCsvFile(file);
    }

    [HttpGet]
    [Route("admin/export/csv/{organizationId:guid}")]
    [Authorize(AdminEventPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> AdminExportOrganizationEventsAsCsv(Guid organizationId, [FromQuery] EventsRequestFilter request)
    {
        request.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.CountryCodes);

        var file = await _eventsService.PlatformEventsAsCsvAsync(organizationId, request);

        await _userLoggingService.LogAsync(User.GetUserId(), $"Has made en export of the events of the following organization: {organizationId}");

        return ServeEventExportCsvFile(file);
    }

    [HttpGet]
    [Route("crm/agenda")]
    [Authorize(AdminOrganizationManagementPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AgendaEventResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AgendaEventResponse>>>> Agenda([FromQuery] DateTime startDate, [FromQuery] DateTime endDate, [FromQuery] IEnumerable<string>? countryCodes = null)
    {
        var allowedCountries = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), countryCodes);

        await _userLoggingService.LogAsync(User.GetUserId(), "Has viewed the platform");

        return Ok(new ApiResponse<IEnumerable<AgendaEventResponse>>
        {
            Data = await _eventsService.EventsAgendaAsync(startDate, endDate, allowedCountries)
        });
    }

    [HttpGet]
    [Route("statistics")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<GlobalEventStatisticsResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<GlobalEventStatisticsResponse>>> GlobalStatistics() =>
        Ok(new ApiResponse<GlobalEventStatisticsResponse>
        {
            Data = await _eventsService.GlobalStatisticsAsync(Request.GetOrganizationId())
        });

    [HttpGet]
    [Route("platform/statistics")]
    [Authorize(AdminCrmPermissions.Growth)]
    [ProducesResponseType(typeof(ApiResponse<GlobalEventStatisticsResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<GlobalEventStatisticsResponse>>> GlobalPlatformStatistics([FromQuery] DateTime startDate, [FromQuery] DateTime endDate, [FromQuery] IEnumerable<string>? countryCodes = null)
    {
        var allowedCountries = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), countryCodes);

        return Ok(new ApiResponse<GlobalEventStatisticsResponse>
        {
            Data = await _eventsService.GlobalPlatformStatisticsAsync(startDate, endDate, allowedCountries)
        });
    }

    [HttpGet]
    [Route("revenues")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<RevenueResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<RevenueResponse>>> Revenues() =>
        Ok(new ApiResponse<RevenueResponse>
        {
            Data = await _eventService.RevenuesAsync(Request.GetOrganizationId())
        });

    [HttpGet]
    [Route("upcoming/products")]
    [Authorize(OrganizationEventPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EventProductsResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [UseOrganizationHeader]
    [Obsolete("Use /products/list/select-options instead")]
    public async Task<ActionResult<ApiResponse<IEnumerable<EventProductsResponse>>>> UpcomingProductsOfEvents() =>
        Ok(new ApiResponse<IEnumerable<EventProductsResponse>>
        {
            Data = await _productService.UpcomingEventProductsAsync(Request.GetOrganizationId())
        });

    [HttpGet]
    [Route("products/list/select-options")]
    [Authorize(OrganizationEventPermissions.List)]
    [ProducesResponseType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>> ListProductSelectOptions(ProductSelectOptionsRequest request) =>
        Ok(new ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>
        {
            Data = await _productsService.ListSelectOptionsAsync(Request.GetOrganizationId(), request)
        });

    [HttpGet]
    [Route("crm/balance")]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<EventBalanceResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [Authorize(AdminCrmPermissions.ListEventBalancesMutations)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<EventBalanceResponse>>>> BalanceMutations([FromQuery] PaginatedRequest<EventsBalanceMutationsRequestFilter> request)
    {
        request.Options.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.Options.CountryCodes);

        var result = await _eventsService.BalanceMutationsAsync(request);

        await _userLoggingService.LogAsync(User.GetUserId(), "Has viewed the platform event balance");

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("shops/list/select-options")]
    [Authorize(OrganizationEventPermissions.List)]
    [ProducesResponseType<ApiResponse<IEnumerable<SelectOptionResponse<string>>>>(StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<IEnumerable<SelectOptionResponse<string>>>> ListShopSelectOptions(ShopSelectOptionsRequest request) =>
        Ok(new ApiResponse<IEnumerable<SelectOptionResponse<string>>>
        {
            Data = await _shopsService.ListSelectOptionsAsync(Request.GetOrganizationId(), request)
        });

    private FileResult ServeEventExportCsvFile(FileContentResult file) => File(file.FileContents, "text/csv", $"Events-export-{DateTime.UtcNow}-UTC.csv");
}