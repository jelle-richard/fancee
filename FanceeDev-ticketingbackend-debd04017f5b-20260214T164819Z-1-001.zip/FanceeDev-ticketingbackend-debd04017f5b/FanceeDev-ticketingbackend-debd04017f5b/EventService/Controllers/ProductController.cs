﻿using System.Net.Mime;
using EventService.Dtos.Requests.Product.Item;
using EventService.Dtos.Responses.Product;
using EventService.Services.Product;
using EventService.Services.Product.Exceptions;
using EventService.Services.Shop;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Utils;

namespace EventService.Controllers;

[ApiController]
[Route("/event/{eventId:guid}/[controller]")]
[Consumes(MediaTypeNames.Application.Json)]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class ProductController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly IOrganizationService _organizationService;
    private readonly IShopService _shopService;

    public ProductController(IProductService productService, IOrganizationService organizationService, IShopService shopService)
    {
        _productService = productService;
        _organizationService = organizationService;
        _shopService = shopService;
    }

    [HttpGet]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<IdentifiedProductDto>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<IdentifiedProductDto>>>> Get(Guid eventId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<IdentifiedProductDto>>
        {
            Data = await _productService.GetAllAsync(eventId, organizationId)
        });
    }

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(ApiResponse<CreateProductResponse>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<CreateProductResponse>>> Create(Guid eventId, [FromBody] PostProductDto productDto)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        if (productDto.WaveLinkedProductId != null && !await _productService.BelongsToEvent((Guid)productDto.WaveLinkedProductId, eventId))
            throw new WaveLinkedProductNotFoundException();

        var response = await _productService.InsertAsync(productDto, eventId);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return CreatedAtAction(nameof(Get), new { eventId }, new ApiResponse<CreateProductResponse>
        {
            Data = response
        });
    }

    [HttpPut]
    [Route("{productId:guid}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Update(Guid eventId, Guid productId, [FromBody] IdentifiedProductDto productDto)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        if (productId != productDto.Id || !await _productService.OwnerOfProductsAsync(organizationId, new[] { productDto.Id }))
            throw new ProductNotFoundException();

        if (productDto.WaveLinkedProductId != null && !await _productService.BelongsToEvent((Guid)productDto.WaveLinkedProductId, eventId))
            throw new WaveLinkedProductNotFoundException();

        if (await ContainsCircularWaveLinkedProduct(new[] { productDto }, eventId, organizationId))
            throw new CircularWaveLinkedProductsException();

        await _productService.UpdateAsync(new[] { productDto }, organizationId);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok();
    }

    [HttpPut]
    [Route("")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult> Update(Guid eventId, [FromBody] IList<IdentifiedProductDto> productDtos)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        if (!productDtos.Any() || !await _productService.OwnerOfProductsAsync(organizationId, productDtos.Select(p => p.Id)))
            throw new ProductNotFoundException();

        if (await ContainsCircularWaveLinkedProduct(productDtos, eventId, organizationId))
            throw new CircularWaveLinkedProductsException();

        await _productService.UpdateAsync(productDtos, organizationId);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok();
    }

    [HttpDelete]
    [Route("{productId:guid}")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult> Delete(Guid eventId, Guid productId)
    {
        if (!await _organizationService.OwnerOfEventAsync(Request.GetOrganizationId(), eventId))
            throw new EventNotFoundException();

        if (!await _productService.BelongsToEvent(productId, eventId))
            throw new ProductNotFoundException();

        if (await _productService.HasSalesOrReservations(productId))
            throw new ProductInUseException();

        await _productService.DeleteAsync(productId);
        await _shopService.InvalidateShopCacheByEventIdAsync(eventId);

        return Ok();
    }

    private async Task<bool> ContainsCircularWaveLinkedProduct(IEnumerable<IdentifiedProductDto> products, Guid eventId, Guid organizationId)
    {
        var waveLinkedUpdatedProducts = products.Where(p => p.WaveLinkedProductId != null).ToList();

        var persistedProducts = await _productService.GetAllExcludingAsync(eventId, organizationId, waveLinkedUpdatedProducts.Select(p => p.Id));
        var productConcat = waveLinkedUpdatedProducts.Concat(persistedProducts).ToList();

        return waveLinkedUpdatedProducts.Any(product => IsCircularWaveLinkChain(product, productConcat, new List<Guid>()));
    }

    private bool IsCircularWaveLinkChain(IdentifiedProductDto product, IList<IdentifiedProductDto> products, ICollection<Guid> checkedIds)
    {
        if (product.Id == product.WaveLinkedProductId)
            return true;

        if (checkedIds.Count > 1 && checkedIds.FirstOrDefault() == checkedIds.LastOrDefault())
            return true;

        if (product.WaveLinkedProductId == null)
            return false;

        checkedIds.Add((Guid)product.WaveLinkedProductId);

        var waveLinkedProduct = products.FirstOrDefault(p => p.Id == product.WaveLinkedProductId) ?? throw new ProductNotFoundException();

        return IsCircularWaveLinkChain(waveLinkedProduct, products, checkedIds);
    }
}