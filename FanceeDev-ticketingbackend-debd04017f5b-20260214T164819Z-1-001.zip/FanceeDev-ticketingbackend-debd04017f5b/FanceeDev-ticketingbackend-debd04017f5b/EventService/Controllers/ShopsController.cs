﻿using EventService.Dtos.Responses.Shops;
using EventService.Services.Shop;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Utils;

namespace EventService.Controllers;

[ApiController]
[Route("/event/{eventId:guid}/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class ShopsController : ControllerBase
{
    private readonly IOrganizationService _organizationService;
    private readonly IShopService _shopService;

    public ShopsController(IOrganizationService organizationService, IShopService shopService)
    {
        _organizationService = organizationService;
        _shopService = shopService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(OrganizationEventPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ShopListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ShopListItemResponse>>>> List(Guid eventId)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfEventAsync(organizationId, eventId))
            throw new EventNotFoundException();

        return Ok(new ApiResponse<IEnumerable<ShopListItemResponse>>
        {
            Data = await _shopService.ListAsync(organizationId, eventId)
        });
    }
}