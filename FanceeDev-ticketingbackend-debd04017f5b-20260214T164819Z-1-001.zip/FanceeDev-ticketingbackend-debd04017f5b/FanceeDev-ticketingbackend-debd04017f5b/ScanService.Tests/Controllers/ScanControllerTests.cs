using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using ScanService.Controllers;
using ScanService.Dtos.Requests.Scan;
using ScanService.Dtos.Responses.Scan;
using ScanService.Services.AppTeam;
using ScanService.Services.Event;
using ScanService.Services.Scan;
using ScanService.Services.Scan.Exceptions;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Organization;
using WebApiCore.Services.Organization.Exceptions;

namespace ScanService.Tests.Controllers;

public class ScanControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidAppTeamId = Guid.NewGuid();

    private readonly ScanController _sut;
    private readonly Mock<IScanService> _mockedScanService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();
    private readonly Mock<IAppTeamService> _mockedAppTeamService = new();
    private readonly Mock<IEventService> _mockedEventService = new();

    public ScanControllerTests()
    {
        _sut = new(_mockedScanService.Object, _mockedOrganizationService.Object, _mockedAppTeamService.Object, _mockedEventService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatSetScanStateThrowsIssuedTicketNotFoundExceptionWhenAuthorizedUserIsNotTicketIssuer()
    {
        _mockedScanService.Setup(ss => ss.IsIssuerOfIssuedTicketAsync(It.IsAny<Guid>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        var request = new ScanStateRequestModel
        {
            State = ScanState.Scanned
        };

        await Assert.ThrowsAsync<IssuedTicketNotFoundException>(async () => await _sut.SetScanState(request, "UNITCODE123"));
    }

    [Fact]
    public async Task TestThatSetScanStateCallsScanServiceSetScanStateAsync()
    {
        _mockedScanService.Setup(ss => ss.IsIssuerOfIssuedTicketAsync(It.IsAny<Guid>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        var request = new ScanStateRequestModel
        {
            State = ScanState.Scanned
        };

        var actual = await _sut.SetScanState(request, "TSUNIT123");

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<ScanResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedScanService.Verify(ss => ss.SetScanStateAsync("TSUNIT123", null, request), Times.Once);
    }

    [Fact]
    public async Task TestThatSetScanStateAsAppTeamUserCallsScanServiceSetScanStateAsync()
    {
        _sut.SetupHttpContext(appTeamId: ValidAppTeamId);

        _mockedScanService.Setup(ss => ss.IsAppTeamAssignedToTicketForScanningAsync(It.IsAny<Guid>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        var request = new ScanStateRequestModel
        {
            State = ScanState.Scanned
        };

        var actual = await _sut.SetScanState(request, "TSUNIT123");

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<ScanResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedScanService.Verify(ss => ss.SetScanStateAsync("TSUNIT123", It.IsAny<Guid>(), request), Times.Once);
    }

    [Fact]
    public async Task TestThatTicketScanStatisticsThrowsInvalidOrganizationExceptionIfOrganizationIsNotLinkedToEvent()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidOrganizationException>(async () => await _sut.TicketScanStatistics(Guid.NewGuid()));

        _mockedOrganizationService.Verify(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatTicketScanStatisticsCallsScanServiceEventTicketScansAsync()
    {
        _mockedOrganizationService.Setup(os => os.OwnerOfEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedScanService.Setup(ss => ss.EventTicketScansAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<TicketScanStatisticsResponse>());

        var actual = await _sut.TicketScanStatistics(Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedScanService.Verify(ss => ss.EventTicketScansAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatEventAppTeamScanStatisticsThrowsIfEventDoesNotExist()
    {
        _mockedEventService.Setup(es => es.EventExists(It.IsAny<Guid>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.EventAppTeamScanStatistics(It.IsAny<Guid>(), It.IsAny<Guid>(), DateTime.Now));
    }

    [Fact]
    public async Task TestThatEventAppTeamScanStatisticsThrowsIfUserIsNotOwnerOfAppTeam()
    {
        _mockedEventService.Setup(es => es.EventExists(It.IsAny<Guid>())).ReturnsAsync(true);
        _mockedAppTeamService.Setup(ats => ats.IsOwnerOfAppTeam(ValidOrganizationId, It.IsAny<Guid>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<UnauthorizedAccessException>(async () => await _sut.EventAppTeamScanStatistics(ValidOrganizationId, It.IsAny<Guid>(), DateTime.Now));

        _mockedEventService.Verify(es => es.EventExists(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatEventAppTeamScanStatisticsCallsScanServiceEventAppTeamTicketScansAsync()
    {
        _mockedEventService.Setup(es => es.EventExists(It.IsAny<Guid>())).ReturnsAsync(true);
        _mockedAppTeamService.Setup(ats => ats.IsOwnerOfAppTeam(It.IsAny<Guid>(), It.IsAny<Guid>())).ReturnsAsync(true);

        _mockedScanService.Setup(ss => ss.EventAppTeamTicketScansAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new TicketScanStatistics[]
            {
                new()
                {
                    Name = "Unit test", IntervalScans = new TicketIntervalScanStatistics[]
                    {
                        new()
                        {
                            TicketsScanned = 1,
                            TicketsUnscanned = 0,
                            TimeInterval = DateTime.Now
                        }
                    }
                }
            });

        await _sut.EventAppTeamScanStatistics(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTime>());

        _mockedScanService.Verify(ss => ss.EventAppTeamTicketScansAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSetScanStateByAppTeamThrowsIssuedTicketNotFoundExceptionOnInvalidAppTeam()
    {
        _sut.SetupHttpContext(appTeamId: ValidAppTeamId);

        _mockedScanService.Setup(ss => ss.IsAppTeamAssignedToTicketForScanningAsync(ValidAppTeamId, "code")).ReturnsAsync(false);

        await Assert.ThrowsAsync<IssuedTicketNotFoundException>(async () => await _sut.SetScanStateByAppTeam(new()
        {
            State = ScanState.Scanned
        }, "code"));

        _mockedScanService.Verify(ss => ss.IsAppTeamAssignedToTicketForScanningAsync(ValidAppTeamId, "code"), Times.Once);
        _mockedScanService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSetScanStateByAppTeamSetsScanStateForAppTeam()
    {
        _sut.SetupHttpContext(appTeamId: ValidAppTeamId);

        _mockedScanService.Setup(ss => ss.IsAppTeamAssignedToTicketForScanningAsync(ValidAppTeamId, "code")).ReturnsAsync(true);

        var actual = await _sut.SetScanStateByAppTeam(new() { State = ScanState.Scanned }, "code");

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<ScanResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedScanService.Verify(ss => ss.IsAppTeamAssignedToTicketForScanningAsync(ValidAppTeamId, "code"), Times.Once);
        _mockedScanService.Verify(ss => ss.SetScanStateAsync("code", ValidAppTeamId, It.IsAny<ScanStateRequestModel>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAppTeamTicketScanStatisticsThrowsEventNotFoundExceptionIfEventDoesNotExist()
    {
        _sut.SetupHttpContext(appTeamId: ValidAppTeamId);

        _mockedEventService.Setup(es => es.EventExists(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.AppTeamProductScanStatistics(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatAppTeamTicketScanStatisticsReturnsTicketScanStatisticsOfTheEventToWhichTheAppTeamIsBound()
    {
        _sut.SetupHttpContext(appTeamId: ValidAppTeamId);

        _mockedEventService.Setup(es => es.EventExists(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedAppTeamService.Setup(ats => ats.ProductsForEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync([Guid.NewGuid()]);

        _mockedScanService.Setup(ss => ss.AppTeamTicketScansAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync(new List<TicketScanStatisticsResponse>());

        var actual = await _sut.AppTeamProductScanStatistics(Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedAppTeamService.Verify(ats => ats.ProductsForEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
        _mockedScanService.Verify(ss => ss.AppTeamTicketScansAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<Guid>>()), Times.Once);
    }
}