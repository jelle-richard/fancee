﻿using AccountingService.BackgroundTasks.MessageBus;
using AccountingService.Persistence.Exact;
using AccountingService.Persistence.Invoice;
using AccountingService.Persistence.ItemMapping;
using AccountingService.Persistence.OAuth;
using AccountingService.Persistence.PayOut;
using AccountingService.Services.Exact;
using AccountingService.Services.Invoice;
using AccountingService.Services.ItemMapping;
using AccountingService.Services.OAuth;
using AccountingService.Services.PayOut;
using AccountingUtils.Config;
using AccountingUtils.Utils;
using WebApiCore;
using WebApiCore.Exceptions;
using ZipUtils.Utils;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "AccountingService",
        EndpointName = "AccountingService v1"
    },
    UseS3Storage = true,
    UseRabbitMq = true,
    UseSignalR = false
};

builder.OnConfigureServices += (_, collection) =>
{
    if (builder.IsCiCd)
        return;

    collection.AddAccountingUtils(new ExactConfiguration
    {
        BaseUrl = builder.Configuration.GetValue<string>("Exact:BaseUrl") ?? throw new MissingRequiredConfigurationEntryException("Exact", "BaseUrl"),
        ClientId = builder.Configuration.GetValue<string>("Exact:ClientId") ?? throw new MissingRequiredConfigurationEntryException("Exact", "ClientId"),
        ClientSecret = builder.Configuration.GetValue<string>("Exact:ClientSecret") ?? throw new MissingRequiredConfigurationEntryException("Exact", "ClientSecret"),
        OAuthRedirectDomain = builder.Configuration.GetValue<string>("Exact:OAuthRedirectDomain") ?? throw new MissingRequiredConfigurationEntryException("Exact", "OAuthRedirectDomain")
    });

    collection.AddZipUtils();
};

builder.AddDependency<IOAuthProviderTokenService, OAuthProviderTokenService>(ServiceLifetime.Scoped);
builder.AddDependency<IOAuthProviderTokenDao, OAuthProviderTokenDao>(ServiceLifetime.Scoped);
builder.AddDependency<IItemMappingService, ItemMappingService>(ServiceLifetime.Scoped);
builder.AddDependency<IItemMappingDao, ItemMappingDao>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceRowSpecificationDao, InvoiceRowSpecificationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IExactService, ExactService>(ServiceLifetime.Scoped);
builder.AddDependency<IExactConfigurationDao, ExactConfigurationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceDao, InvoiceDao>(ServiceLifetime.Scoped);
builder.AddDependency<IExactDao, ExactDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPayOutService, PayOutService>(ServiceLifetime.Scoped);
builder.AddDependency<IPayOutDao, PayOutDao>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceRowSpecificationService, InvoiceRowSpecificationService>(ServiceLifetime.Scoped);

builder.AddDependency<RefreshExactTokenListener>(x => new(x), ServiceLifetime.Singleton);
builder.AddDependency<AddAccountingInvoiceListener>(x => new(x), ServiceLifetime.Singleton);

builder.AddHostedService<RefreshExactTokenListener>();
builder.AddHostedService<AddAccountingInvoiceListener>();

var app = builder.Build();
app.Run();