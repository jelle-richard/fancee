using System.ComponentModel.DataAnnotations;
using AccountingService.Dtos.Requests.Exact;
using AccountingService.Dtos.Responses.Exact;
using AccountingService.Services.Exact;
using AccountingService.Services.ItemMapping;
using AccountingService.Services.OAuth;
using AccountingService.Utils.Adapter;
using AccountingUtils.Config;
using AccountingUtils.Providers.Accounting.Exact;
using AccountingUtils.Providers.Accounting.Exact.Responses;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions;
using WebApiCore.Services.DeploymentEnvironment;

namespace AccountingService.Controllers;

[ApiController]
[Route("/accounting/integrations/[controller]")]
public class ExactController : ControllerBase
{
    private const int ExactRefreshExpireDays = 30;

    private readonly IExactProvider _exactProvider;
    private readonly IDeploymentEnvironmentService _deploymentEnvironmentService;
    private readonly IOAuthProviderTokenService _oAuthProviderTokenService;
    private readonly IExactConfiguration _exactConfiguration;
    private readonly IItemMappingService _itemMappingService;
    private readonly IExactService _exactService;

    public ExactController(IExactProvider exactProvider, IDeploymentEnvironmentService deploymentEnvironmentService, IOAuthProviderTokenService oAuthProviderTokenService, IExactConfiguration exactConfiguration, IItemMappingService itemMappingService, IExactService exactService)
    {
        _exactProvider = exactProvider;
        _deploymentEnvironmentService = deploymentEnvironmentService;
        _exactConfiguration = exactConfiguration;
        _itemMappingService = itemMappingService;
        _exactService = exactService;
        _oAuthProviderTokenService = oAuthProviderTokenService;
    }

    [HttpGet]
    [Route("authenticate")]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    [ProducesResponseType(typeof(ApiResponse<string>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status401Unauthorized)]
    public ActionResult<ApiResponse<string>> Authenticate()
    {
        var endpoint = $"{_exactConfiguration.OAuthRedirectDomain}/accounting/integrations/exact/token";

        return Ok(new ApiResponse<string>
        {
            Data = _exactProvider.OAuthRedirectUrl(endpoint)
        });
    }

    [HttpGet]
    [Route("enabled")]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<bool>>> Enabled() =>
        Ok(new ApiResponse<bool>
        {
            Data = await _oAuthProviderTokenService.ExistsAsync(OAuthProvider.Exact, ExactRefreshExpireDays)
        });

    [HttpGet]
    [Route("token")]
    [ProducesResponseType(typeof(void), StatusCodes.Status302Found)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult> Token([FromQuery] [Required] string code)
    {
        var endpoint = $"{_exactConfiguration.OAuthRedirectDomain}/accounting/integrations/exact/token";
        TokenResponse tokenResponse;

        try
        {
            tokenResponse = await _exactProvider.TokenAsync(code, endpoint);
        }
        catch (Exception)
        {
            throw new InvalidOAuthCodeException();
        }

        _exactProvider.SetToken(tokenResponse.AccessToken);

        await _oAuthProviderTokenService.AddOrUpdateAsync(tokenResponse);
        await _exactService.SetConfigurationAsync(await _exactProvider.CurrentDivisionAsync(), null);

        var env = await _deploymentEnvironmentService.GetAsync();

        return Redirect(env.FrontendBaseUrl + "/crm/integrations/exact");
    }

    [HttpGet]
    [Route("items")]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<MinimalItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<IEnumerable<MinimalItemResponse>>>> Items()
    {
        _exactProvider.SetToken(await TokenAsync());

        var division = (await _exactService.ConfigurationAsync()).Division;

        return Ok(new ApiResponse<IEnumerable<MinimalItemResponse>>
        {
            Data = (await _exactProvider.ItemsAsync(division)).ToMinimalItemResponses()
        });
    }

    [HttpGet]
    [Route("journals")]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<MinimalJournalResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<IEnumerable<MinimalJournalResponse>>>> Journals()
    {
        _exactProvider.SetToken(await TokenAsync());

        var division = (await _exactService.ConfigurationAsync()).Division;

        return Ok(new ApiResponse<IEnumerable<MinimalJournalResponse>>
        {
            Data = (await _exactProvider.JournalsAsync(division)).ToMinimalJournalResponses().OrderBy(r => r.Code)
        });
    }

    [HttpPost]
    [Route("configure")]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status503ServiceUnavailable)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> Configure([FromBody] ConfigureRequest request)
    {
        _exactProvider.SetToken(await TokenAsync());

        await _exactService.SetConfigurationAsync(await _exactProvider.CurrentDivisionAsync(), request.Journal!);

        return Created(string.Empty, new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("configure/items")]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ConfigureItems([FromBody] ConfigureItemsRequest request)
    {
        await _itemMappingService.AddAsync(request.Items);

        return Created(string.Empty, new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("configuration")]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    [ProducesResponseType(typeof(ApiResponse<ConfigurationResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
    public async Task<ActionResult<ApiResponse<ConfigurationResponse>>> Configuration() =>
        Ok(new ApiResponse<ConfigurationResponse>
        {
            Data = new()
            {
                Journal = (await _exactService.ConfigurationAsync()).Journal,
                Items = await _itemMappingService.MappingsAsync()
            }
        });

    private async Task<string> TokenAsync()
    {
        var currentToken = await _oAuthProviderTokenService.ForProviderAsync(OAuthProvider.Exact);

        // Tokens are valid for 10 minutes and can be refreshed after 9 minutes and 30 seconds.
        if (currentToken.ValidUntil.AddSeconds(-30) > DateTime.UtcNow)
            return currentToken.Token;

        return await _exactService.RefreshTokenAsync(currentToken);
    }
}