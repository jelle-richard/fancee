using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;
using WebApiCore.Services.Country;

namespace AccountingService.Controllers;

[ApiController]
[Route("/accounting/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class VatController : ControllerBase
{
    private readonly ICountryService _countryService;

    public VatController(ICountryService countryService)
    {
        _countryService = countryService;
    }

    [HttpGet]
    [Route("countries")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<Dictionary<string, bool>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Dictionary<string, bool>>>> VatCountries() =>
        Ok(new ApiResponse<Dictionary<string, bool>>
        {
            Data = await _countryService.VatMapAsync()
        });
}