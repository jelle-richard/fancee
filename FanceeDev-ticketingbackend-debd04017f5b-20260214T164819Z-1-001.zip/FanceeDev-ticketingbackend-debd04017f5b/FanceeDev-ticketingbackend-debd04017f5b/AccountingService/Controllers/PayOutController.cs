using System.Net.Mime;
using AccountingService.Dtos.Requests.PayOut;
using AccountingService.Dtos.Responses.PayOut;
using AccountingService.Services.PayOut;
using FanceeData.Models.Ticketing.Invoicing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils.Adapter;

namespace AccountingService.Controllers;

[ApiController]
[Route("/accounting/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class PayOutController : ControllerBase
{
    private readonly IPayOutService _payOutService;

    public PayOutController(IPayOutService payOutService)
    {
        _payOutService = payOutService;
    }

    [HttpPost]
    [Route("create-export")]
    [Authorize(AdminCrmPermissions.PayOutExport)]
    [ProducesResponseType(typeof(ApiResponse<CreatePayOutExportResponse>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<CreatePayOutExportResponse>>> CreateExport() =>
        Created(
            string.Empty,
            new ApiResponse<CreatePayOutExportResponse>
            {
                Data = await _payOutService.CreateExportAsync()
            }
        );

    [HttpGet]
    [Route("pending")]
    [Authorize(AdminCrmPermissions.PayOutExport)]
    [ProducesResponseType(typeof(ApiResponse<int>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<int>>> PendingPayouts() =>
        Ok(new ApiResponse<int>
        {
            Data = await _payOutService.PendingPayoutsAsync()
        });

    [HttpGet]
    [Route("download-export/{exportId:guid}")]
    [Authorize(AdminCrmPermissions.PayOutExport)]
    [ProducesResponseType(typeof(FileStreamResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<FileStreamResult> DownloadExport([FromRoute] Guid exportId)
    {
        var stream = await _payOutService.DownloadFileAsync(exportId);

        return File(stream, MediaTypeNames.Application.Zip, "PayOut Export.zip");
    }

    [HttpPut]
    [Route("export/{exportId:guid}/status/processed")]
    [Authorize(AdminCrmPermissions.PayOutExport)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ChangeStatusToProcessed([FromRoute] Guid exportId)
    {
        await _payOutService.ChangeStatusAsync(exportId, PayOutExportStatus.Processed);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("export/list")]
    [Authorize(AdminCrmPermissions.PayOutExport)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<PayOutExportItemResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<PayOutExportItemResponse>>>> ExportList([FromQuery] PaginatedRequest<PayOutExportFilter> request)
    {
        var result = await _payOutService.ListAsync(request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }
}