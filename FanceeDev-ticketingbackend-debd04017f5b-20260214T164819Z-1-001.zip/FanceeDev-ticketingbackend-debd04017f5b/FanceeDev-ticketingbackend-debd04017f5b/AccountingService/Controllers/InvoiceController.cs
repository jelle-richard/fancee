using AccountingService.Services.Invoice;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Responses;

namespace AccountingService.Controllers;

[ApiController]
[Route("/accounting/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class InvoiceController : ControllerBase
{
    private readonly IInvoiceRowSpecificationService _invoiceRowSpecificationService;

    public InvoiceController(IInvoiceRowSpecificationService invoiceRowSpecificationService)
    {
        _invoiceRowSpecificationService = invoiceRowSpecificationService;
    }

    [HttpGet]
    [Route("specification-names")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<string>>), StatusCodes.Status200OK)]
    [Authorize(AdminCrmPermissions.IntegrateSoftware)]
    public async Task<ActionResult<ApiResponse<IEnumerable<string>>>> InvoiceSpecificationNames() =>
        Ok(new ApiResponse<IEnumerable<string>>
        {
            Data = await _invoiceRowSpecificationService.NamesAsync()
        });
}