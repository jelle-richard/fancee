using Fs.PixelTracking.Utils;

namespace Fs.PixelTracking.Tests.Utils;

public class HashUtilsTests
{
    [Fact]
    public void TestThatSha256ReturnsExpectedResult()
    {
        const string input = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " +
                             "Morbi rutrum arcu tempus maximus facilisis. In hac habitasse platea dictumst. Donec.";
        const string expected = "da26ac1828fa3f905dfcc4fb98a8ecb4279e01237b0de528966f1e3bc86fd513";

        var actual = HashUtils.Sha256(input);

        Assert.Equal(expected, actual);
    }
}