using Fs.PixelTracking.Meta;
using Microsoft.Extensions.DependencyInjection;

namespace Fs.PixelTracking.Tests;

public class PixelTrackingExtensionsTests
{
    [Fact]
    public void TestThatAddPixelTrackingRegistersHttpClientAndProviders()
    {
        var serviceCollection = new ServiceCollection();

        var actual = serviceCollection.AddPixelTracking();

        var provider = serviceCollection.BuildServiceProvider();

        Assert.NotNull(actual);
        Assert.NotNull(provider.GetRequiredService<IHttpClientFactory>().CreateClient("Meta"));
        Assert.IsType<MetaTracker>(provider.GetService<ITracker>());
        Assert.IsType<MetaTracker>(provider.GetService<IMetaTracker>());
    }
}