using System.Net;
using Fs.PixelTracking.Configuration;
using Fs.PixelTracking.Meta;
using Fs.PixelTracking.Models;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;

namespace Fs.PixelTracking.Tests.Meta;

public class MetaTrackerTests
{
    private readonly MetaTracker _sut;
    private readonly Mock<ILogger<MetaTracker>> _mockedLogger = new();
    private readonly Mock<HttpMessageHandler> _mockedHandler = new();

    public MetaTrackerTests()
    {
        var mockedHttpClientFactory = new Mock<IHttpClientFactory>();

        var httpClient = new HttpClient(_mockedHandler.Object) { BaseAddress = new("https://base") };

        mockedHttpClientFactory.Setup(hcf => hcf.CreateClient("Meta"))
            .Returns(httpClient);

        _sut = new(_mockedLogger.Object, mockedHttpClientFactory.Object);
    }

    [Fact]
    public void TestThatSetConfigurationSetsConfiguration()
    {
        _sut.SetConfiguration(new MetaConfiguration
        {
            PixelId = "123",
            AccessCode = "456"
        });

        Assert.NotNull(_sut.Configuration);
        Assert.Equal("123", _sut.Configuration.PixelId);
        Assert.Equal("456", _sut.Configuration.AccessCode);
    }

    [Fact]
    public async Task TestThatSendAndForgetAsyncLogsMissingMetaConfigurationExceptionOnMissingConfiguration()
    {
        _sut.SetConfiguration(null!);

        await _sut.ViewContentAsync(new()
        {
            IpAddress = IPAddress.None,
            UserAgent = "unit test",
            EventId = Guid.Empty,
            ShopCode = "shop",
            Email = "test@mail.com",
            OrderId = "123456",
            Currency = "EUR"
        });

        _mockedLogger.VerifyCalled(LogLevel.Error, "Meta conversion tracking request failed!");
    }

    [Fact]
    public async Task TestThatSendAndForgetAsyncLogsErrorOnException()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.BadRequest));

        _sut.SetConfiguration(new MetaConfiguration { PixelId = "unit", AccessCode = "test" });

        await _sut.ViewContentAsync(new()
        {
            IpAddress = IPAddress.None,
            UserAgent = "unit test",
            EventId = Guid.Empty,
            ShopCode = "shop"
        });

        _mockedLogger.VerifyCalled(LogLevel.Error, "Meta conversion tracking request failed!");
        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "/unit/events");
    }

    [Fact]
    public async Task TestThatViewContentAsyncSendsViewContentRequest()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));

        _sut.SetConfiguration(new MetaConfiguration { PixelId = "unit", AccessCode = "test" });

        await _sut.ViewContentAsync(new()
        {
            IpAddress = IPAddress.None,
            UserAgent = "unit test",
            EventId = Guid.Empty,
            ShopCode = "shop"
        });

        _mockedLogger.VerifyNoOtherCalls();
        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "/unit/events",
            hrm =>
                hrm.Method == HttpMethod.Post &&
                ((MultipartFormDataContent)hrm.Content!).ElementAt(1).ReadAsStringAsync().Result.Contains("ViewContent")
        );
    }

    [Fact]
    public async Task TestThatUpdateCartAsyncSendsUpdateCartRequest()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));

        _sut.SetConfiguration(new MetaConfiguration { PixelId = "unit", AccessCode = "test" });

        await _sut.UpdateCartAsync(new()
        {
            IpAddress = IPAddress.None,
            UserAgent = "unit test",
            EventId = Guid.Empty,
            ShopCode = "shop"
        }, new List<CartItem> { new() { ItemPrice = 1.05m, ProductId = Guid.NewGuid(), Quantity = 2 } });

        _mockedLogger.VerifyNoOtherCalls();
        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "/unit/events",
            hrm =>
                hrm.Method == HttpMethod.Post &&
                ((MultipartFormDataContent)hrm.Content!).ElementAt(1).ReadAsStringAsync().Result.Contains("AddToCart")
        );
    }

    [Fact]
    public async Task TestThatCheckoutAsyncSendsCheckoutRequest()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));

        _sut.SetConfiguration(new MetaConfiguration { PixelId = "unit", AccessCode = "test" });

        await _sut.CheckoutAsync(new()
        {
            IpAddress = IPAddress.None,
            UserAgent = "unit test",
            EventId = Guid.Empty,
            ShopCode = "shop"
        }, new List<CartItem>());

        _mockedLogger.VerifyNoOtherCalls();
        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "/unit/events",
            hrm =>
                hrm.Method == HttpMethod.Post &&
                ((MultipartFormDataContent)hrm.Content!).ElementAt(1).ReadAsStringAsync().Result.Contains("InitiateCheckout")
        );
    }

    [Fact]
    public async Task TestThatCompletePurchaseAsyncSendsCompletePurchaseRequest()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));

        _sut.SetConfiguration(new MetaConfiguration { PixelId = "unit", AccessCode = "test" });

        await _sut.CompletePurchaseAsync(new()
        {
            IpAddress = IPAddress.None,
            UserAgent = "unit test",
            EventId = Guid.Empty,
            ShopCode = "shop"
        }, new List<CartItem>());

        _mockedLogger.VerifyNoOtherCalls();
        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "/unit/events",
            hrm =>
                hrm.Method == HttpMethod.Post &&
                ((MultipartFormDataContent)hrm.Content!).ElementAt(1).ReadAsStringAsync().Result.Contains("Purchase")
        );
    }
}