using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using OrderService.Controllers;
using OrderService.Dtos.Requests.Order;
using OrderService.Dtos.Responses.Order;
using OrderService.Services.Event;
using OrderService.Services.Order;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Services.Country;
using WebApiCore.Services.Logging;

namespace OrderService.Tests.Controllers;

public class OrdersControllerTests
{
    private static readonly Guid ValidAdminId = Guid.NewGuid();
    private static readonly Guid ValidClientId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly OrdersController _sut;
    private readonly Mock<IOrderService> _mockedOrderService = new();
    private readonly Mock<IEventService> _mockedEventService = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();

    public OrdersControllerTests()
    {
        _sut = new(_mockedOrderService.Object, _mockedEventService.Object, _mockedCountryService.Object, _mockedUserLoggingService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatDailyEventOrdersThrowsEventNotFoundExceptionOnNonExistingConnection()
    {
        _mockedEventService.Setup(es => es.BelongsToOrganizationAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.DailyEventOrders(Guid.NewGuid(), DateTime.UtcNow.AddDays(-5), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatDailyEventOrdersThrowsInvalidDateRangeExceptionOnSurpassedStartDate()
    {
        _mockedEventService.Setup(es => es.BelongsToOrganizationAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<InvalidDateRangeException>(async () => await _sut.DailyEventOrders(Guid.NewGuid(), DateTime.UtcNow.AddDays(5), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatDailyOrdersThrowsInvalidDateRangeExceptionOnSurpassedStartDate()
    {
        await Assert.ThrowsAsync<InvalidDateRangeException>(async () => await _sut.DailyOrders(DateTime.UtcNow.AddDays(5), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatDailyEventOrdersThrowsExceededDateRangeExceptionOnDiffSizeBeyond30Days()
    {
        _mockedEventService.Setup(es => es.BelongsToOrganizationAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<ExceededDateRangeException>(async () => await _sut.DailyEventOrders(Guid.NewGuid(), DateTime.UtcNow.AddDays(-31), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatDailyOrdersThrowsExceededDateRangeExceptionOnDiffSizeBeyond30Days()
    {
        await Assert.ThrowsAsync<ExceededDateRangeException>(async () => await _sut.DailyOrders(DateTime.UtcNow.AddDays(-31), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatDailyEventOrdersReturnsOkResultOnValidCall()
    {
        _mockedEventService.Setup(es => es.BelongsToOrganizationAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.DailyEventOrdersAsync(It.IsAny<Guid>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<DailyOrdersResponse>
            {
                new()
                {
                    Date = DateTime.UtcNow,
                    TotalOrders = 11
                }
            });

        var actual = await _sut.DailyEventOrders(Guid.NewGuid(), DateTime.UtcNow.AddDays(-5), DateTime.UtcNow);

        Assert.IsType<ActionResult<ApiResponse<IEnumerable<DailyOrdersResponse>>>>(actual);
    }

    [Fact]
    public async Task TestThatDailyOrdersReturnsOkResultOnValidCall()
    {
        _mockedOrderService.Setup(os => os.DailyOrdersAsync(It.IsAny<Guid>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<DailyOrdersResponse>
            {
                new()
                {
                    Date = DateTime.UtcNow,
                    TotalOrders = 11
                }
            });

        var actual = await _sut.DailyOrders(DateTime.UtcNow.AddDays(-5), DateTime.UtcNow);

        Assert.IsType<ActionResult<ApiResponse<IEnumerable<DailyOrdersResponse>>>>(actual);
    }

    [Fact]
    public async Task TestThatGetClientOrdersCallsOrderServiceAsync()
    {
        _sut.SetupHttpContext(platformUserId: ValidClientId, userType: UserType.Client.ToString());

        var request = new PaginatedRequest<OrdersRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _mockedOrderService.Setup(os => os.ListClientOrdersAsync(ValidClientId, request))
            .ReturnsAsync(new PaginatedResultSet<OrderListItemResponse>
            {
                Items = new OrderListItemResponse[]
                {
                    new()
                    {
                        Id = Guid.Empty,
                        EventName = "Event1",
                        CreationDate = DateTime.UtcNow.AddYears(-1),
                        Status = PaymentStatus.Error,
                        Currency = new(),
                        PspReference = ""
                    },
                    new()
                    {
                        Id = Guid.Empty,
                        EventName = "Event2",
                        CreationDate = DateTime.UtcNow.AddHours(-22),
                        Status = PaymentStatus.Error,
                        Currency = new(),
                        PspReference = ""
                    }
                },
                TotalItems = 20
            });

        var actual = await _sut.GetClientOrders(request);

        _mockedOrderService.Verify(os => os.ListClientOrdersAsync(ValidClientId, request), Times.Once);
        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatGetClientOrdersThrowsInvalidUserTypeExceptionOnWrongUserType()
    {
        _sut.SetupHttpContext(platformUserId: ValidClientId, userType: UserType.Client.ToString());

        var request = new PaginatedRequest<OrdersRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _sut.SetupHttpContext(platformUserId: Guid.Empty, userType: UserType.Organization.ToString());

        await Assert.ThrowsAsync<InvalidUserTypeException>(async () => await _sut.GetClientOrders(request));
    }

    [Fact]
    public async Task TestThatGetOrganizationOrdersCallsOrderServiceListOrganizationOrdersAsync()
    {
        _sut.SetupHttpContext(organizationId: ValidOrganizationId);

        var request = new PaginatedRequest<OrdersRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _mockedOrderService.Setup(os => os.ListOrganizationOrdersAsync(ValidOrganizationId, request))
            .ReturnsAsync(new PaginatedResultSet<OrderListItemResponse>
            {
                Items = new List<OrderListItemResponse>(),
                TotalItems = 3
            });

        var actual = await _sut.GetOrganizationOrders(request);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrderService.Verify(os => os.ListOrganizationOrdersAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatGetPlatformOrdersCallsOrderServiceListOrdersAsync()
    {
        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());

        var request = new PaginatedRequest<OrdersRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _mockedOrderService.Setup(os => os.ListPlatformOrdersAsync(request))
            .ReturnsAsync(new PaginatedResultSet<OrderListItemResponse>
            {
                Items = new OrderListItemResponse[]
                {
                    new()
                    {
                        Id = Guid.Empty,
                        EventName = "Event1",
                        CreationDate = DateTime.UtcNow.AddYears(-1),
                        Status = PaymentStatus.Error,
                        Currency = new(),
                        PspReference = ""
                    },
                    new()
                    {
                        Id = Guid.Empty,
                        EventName = "Event2",
                        CreationDate = DateTime.UtcNow.AddHours(-22),
                        Status = PaymentStatus.Error,
                        Currency = new(),
                        PspReference = ""
                    }
                },
                TotalItems = 20
            });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.GetPlatformOrders(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrderService.Verify(os => os.ListPlatformOrdersAsync(request), Times.Once);
        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExportOrganizationOrdersAsCsvCallsOrderServiceExportOrganizationOrdersAsCsvAsync()
    {
        _sut.SetupHttpContext(organizationId: ValidOrganizationId);

        var requestFilter = new OrdersRequestFilter
        {
            SearchQuery = null
        };

        _mockedOrderService.Setup(os => os.OrganizationOrdersCsvAsync(ValidOrganizationId, requestFilter))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportOrganizationOrdersAsCsv(requestFilter);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedOrderService.Verify(os => os.OrganizationOrdersCsvAsync(ValidOrganizationId, requestFilter), Times.Once);
    }

    [Fact]
    public async Task TestThatExportClientOrdersAsCsvCallsOrderServiceClientOrdersCsvAsyncAndServesFile()
    {
        _sut.SetupHttpContext(platformUserId: ValidClientId, userType: UserType.Client.ToString());

        var request = new OrdersRequestFilter();

        _mockedOrderService.Setup(os => os.ClientOrdersAsCsvAsync(ValidClientId, request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportClientOrdersAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedOrderService.Verify(os => os.ClientOrdersAsCsvAsync(ValidClientId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatExportPlatformOrdersAsCsvCallsOrderServicePlatformOrdersCsvAsyncAndServesFile()
    {
        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());

        var request = new OrdersRequestFilter();

        _mockedOrderService.Setup(os => os.PlatformOrdersAsCsvAsync(request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportPlatformOrdersAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedOrderService.Verify(os => os.PlatformOrdersAsCsvAsync(request), Times.Once);
    }
}