﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using OrderService.Controllers;
using OrderService.Dtos.Requests.Order;
using OrderService.Dtos.Responses.Event;
using OrderService.Dtos.Responses.Order;
using OrderService.Dtos.Shared;
using OrderService.Services.AppTeam;
using OrderService.Services.Order;
using OrderService.Services.Order.Exceptions;
using OrderService.Services.Shop;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Shop;
using WebApiCore.Services.Logging;

namespace OrderService.Tests.Controllers;

public class OrderControllerTests
{
    private const string UnitTestShopCode = "unitTestShopCode";

    private static readonly Guid ValidAdminId = Guid.NewGuid();

    private readonly OrderController _sut;
    private readonly Mock<IOrderService> _mockedOrderService;
    private readonly Mock<IShopService> _mockedShopService = new();
    private readonly Mock<IAppTeamService> _mockedAppTeamService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();

    public OrderControllerTests()
    {
        _mockedOrderService = new();

        _mockedOrderService.Setup(os => os.PlaceOrderAsync(It.IsAny<string>(), It.IsAny<OrderRequest>()))
            .ReturnsAsync(new OrderCompleteResponse
            {
                RedirectUrl = "www.unittestredirect.com",
                OrderId = Guid.NewGuid()
            });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        _sut = new(_mockedOrderService.Object, _mockedShopService.Object, _mockedAppTeamService.Object, _mockedUserLoggingService.Object);

        _sut.SetupHttpContext();
    }

    [Fact]
    public async Task TestThatOrderCallsShopServiceOrder()
    {
        var request = new OrderRequest
        {
            ReservationReference = Guid.NewGuid(),
            OrderClient = new()
            {
                Email = "",
                FirstName = "",
                LastName = "",
                PhoneNumber = "",
                Birthdate = DateTime.UtcNow,
                Address = null
            },
            PaymentMethodId = Guid.NewGuid(),
            ReceiveViaSms = false,
            OptInPromotionalSms = false,
            OptInPromotionalEmail = false,
            EnabledTicketServicePlus = false
        };

        var response = await _sut.Order(UnitTestShopCode, request);
        _mockedOrderService.Verify(ss => ss.PlaceOrderAsync(UnitTestShopCode, It.IsAny<OrderRequest>()), Times.Once);
        Assert.IsType<ActionResult<ApiResponse<OrderCompleteResponse>>>(response);
    }

    [Fact]
    public async Task TestThatOrderForPinTerminalCallsOrderServicePlaceOrderAsync()
    {
        var request = new OrderRequest()
        {
            ReservationReference = Guid.NewGuid(),
            OrderClient = new()
        };

        var actual = await _sut.Order("shop", "terminal", request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<PinOrderCompleteResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedOrderService.Verify(os => os.PlaceOrderAsync("shop", request, "terminal"));
    }

    [Fact]
    public async Task TestThatGetOrderTicketsThrowsInvalidUserTypeExceptionOnNonClientUser()
    {
        _sut.SetupHttpContext(organizationId: Guid.Empty);

        await Assert.ThrowsAsync<InvalidUserTypeException>(async () => await _sut.GetOrderTickets());
    }

    [Fact]
    public async Task TestThatGetOrderTicketsCallsOrderServiceGetUpcomingClientEventOrdersAsync()
    {
        _sut.SetupHttpContext(platformUserId: Guid.Empty, userType: UserType.Client.ToString());

        _mockedOrderService.Setup(os => os.UpcomingClientEventOrdersAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<EventOrderResponse>
            {
                new()
                {
                    OrderId = Guid.NewGuid(),
                    Name = "UNIT EVENT NAME",
                    StartDate = DateTime.UtcNow.AddDays(5),
                    Tickets = new List<EventOrderTicketsResponse>()
                }
            });

        await _sut.GetOrderTickets();

        _mockedOrderService.Verify(os => os.UpcomingClientEventOrdersAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetOrderThrowsOrderNotFoundExceptionOnNoAccess()
    {
        _sut.SetupHttpContext(organizationId: Guid.NewGuid());

        _mockedOrderService.Setup(os => os.HasAccessAsync(It.IsAny<Guid>(), null, It.IsAny<Guid>(), UserType.Organization))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<OrderNotFoundException>(async () => await _sut.GetOrder(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatGetOrderThrowsOrderNotFoundExceptionIfUserDoesNotHaveAccess()
    {
        _sut.SetupHttpContext(organizationId: Guid.Empty, userType: UserType.Organization.ToString());

        await Assert.ThrowsAsync<OrderNotFoundException>(async () => await _sut.GetOrder(Guid.Empty));

        _mockedOrderService.Verify(os => os.HasAccessAsync(Guid.Empty, null, Guid.Empty, UserType.Organization), Times.Once);
    }

    [Fact]
    public async Task TestThatGetOrderCallsOrderServiceOrderAsync()
    {
        _sut.SetupHttpContext(organizationId: Guid.NewGuid(), userType: UserType.Organization.ToString());

        _mockedOrderService.Setup(os => os.HasAccessAsync(It.IsAny<Guid>(), null, It.IsAny<Guid>(), UserType.Organization))
            .ReturnsAsync(true);

        var actual = await _sut.GetOrder(Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrderService.Verify(os => os.OrderAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetOrderAsAppTeamCallsOrderServiceOrderAsyncWithAppTeamIdAdded()
    {
        var appTeamId = Guid.NewGuid();
        var orderId = Guid.NewGuid();

        _sut.SetupHttpContext(appTeamId: appTeamId);

        _mockedOrderService.Setup(os => os.OrderAsync(orderId, appTeamId))
            .ReturnsAsync(new OrderResponse());

        var actual = await _sut.GetOrderAsAppTeam(orderId);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrderService.Verify(os => os.OrderAsync(orderId, appTeamId), Times.Once);
    }

    [Fact]
    public async Task TestThatCashOrderThrowsShopNotFoundExceptionIfOrganizationIsNotOwnerOfShop()
    {
        var organizationId = Guid.NewGuid();

        _sut.SetupHttpContext(organizationId: organizationId);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.CashOrder("code", new()
        {
            ReservationReference = Guid.NewGuid(),
            OrderClient = new()
        }));

        _mockedShopService.Verify(ss => ss.OwnerOfShopAsync(organizationId, "code"), Times.Once);
        _mockedShopService.VerifyNoOtherCalls();
        _mockedAppTeamService.VerifyNoOtherCalls();
        _mockedOrderService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCashOrderCallsOrderServicePlaceCashOrderAsync()
    {
        var organizationId = Guid.NewGuid();

        _mockedShopService.Setup(ss => ss.OwnerOfShopAsync(organizationId, "code"))
            .ReturnsAsync(true);

        _sut.SetupHttpContext(organizationId: organizationId);

        var actual = await _sut.CashOrder("code", new()
        {
            ReservationReference = Guid.NewGuid(),
            OrderClient = new()
        });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<OrderCompleteResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedShopService.Verify(ss => ss.OwnerOfShopAsync(organizationId, "code"), Times.Once);
        _mockedOrderService.Verify(os => os.PlaceCashOrderAsync("code", It.IsAny<OrderRequest>()), Times.Once);
        _mockedShopService.VerifyNoOtherCalls();
        _mockedAppTeamService.VerifyNoOtherCalls();
        _mockedOrderService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAppTeamCashOrderThrowsShopNotFoundExceptionIfAppTeamDoesNotHaveSalesAndCashEnabled()
    {
        var appTeamId = Guid.NewGuid();

        _sut.SetupHttpContext(appTeamId: appTeamId);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.AppTeamCashOrder("code", new()
        {
            ReservationReference = Guid.NewGuid(),
            OrderClient = new()
        }));

        _mockedAppTeamService.Verify(ats => ats.HasSalesAndCashEnabledForReservationAsync(appTeamId, It.IsAny<Guid>()), Times.Once);
        _mockedAppTeamService.VerifyNoOtherCalls();
        _mockedShopService.VerifyNoOtherCalls();
        _mockedOrderService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAppTeamCashOrderCallsOrderServicePlaceCashOrderAsync()
    {
        var appTeamId = Guid.NewGuid();

        _mockedAppTeamService.Setup(ats => ats.HasSalesAndCashEnabledForReservationAsync(appTeamId, It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.OwnerOfShopAsync(It.IsAny<Guid>(), "code"))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.PlaceCashOrderAsync("code", It.IsAny<OrderRequest>()));

        _sut.SetupHttpContext(appTeamId: appTeamId);

        var actual = await _sut.AppTeamCashOrder("code", new()
        {
            ReservationReference = Guid.NewGuid(),
            OrderClient = new()
        });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<OrderCompleteResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedAppTeamService.Verify(ats => ats.HasSalesAndCashEnabledForReservationAsync(appTeamId, It.IsAny<Guid>()), Times.Once);
        _mockedOrderService.Verify(os => os.PlaceCashOrderAsync("code", It.IsAny<OrderRequest>()));
    }

    [Fact]
    public async Task TestThatDownloadOrderTicketsPdfThrowsInvalidOrderTicketPdfRequestExceptionIfRequestDoesNotMatchCriteria()
    {
        _mockedOrderService.Setup(os => os.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidOrderTicketPdfRequestException>(async () => await _sut.DownloadOrderTicketsPdf(Guid.NewGuid(), Guid.NewGuid()));
        _mockedOrderService.Verify(os => os.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadOrderTicketsPdfCallsOrderServiceDownloadTicketPdfAsyncAndServesFile()
    {
        _mockedOrderService.Setup(os => os.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.OrderHasTicketsFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.IsOrderOfSealedEventOrWithinSealtimeAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        _mockedOrderService.Setup(os => os.DownloadTicketPdfAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new MemoryStream());

        var actual = await _sut.DownloadOrderTicketsPdf(Guid.NewGuid(), Guid.NewGuid());

        Assert.Equal("application/pdf", actual.ContentType);

        _mockedOrderService.Verify(os => os.DownloadTicketPdfAsync(It.IsAny<Guid>()), Times.Once);
        _mockedOrderService.Verify(os => os.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadOrderTicketsPdfThrowsOrderTicketFileNotFoundExceptionOnMissingOrderFile()
    {
        _mockedOrderService.Setup(os => os.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.OrderHasTicketsFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<OrderTicketFileNotFoundException>(async () => await _sut.DownloadOrderTicketsPdf(Guid.NewGuid(), Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatDownloadOrderTicketsPdfThrowsOrderSealedExceptionWhenTryingToDownloadAnOrderOfASealedEvent()
    {
        _mockedOrderService.Setup(os => os.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.OrderHasTicketsFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.IsOrderOfSealedEventOrWithinSealtimeAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<OrderSealedException>(async () => await _sut.DownloadOrderTicketsPdf(Guid.NewGuid(), Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatCostCallsOrderServiceTotalCostAsync()
    {
        _mockedOrderService.Setup(os => os.TotalOrderCostAsync(It.IsAny<Guid>(), It.IsAny<Guid?>(), It.IsAny<bool>(), It.IsAny<bool>()))
            .ReturnsAsync(new OrderCostResponse
            {
                TotalOrderCostCents = 1251,
                PaymentFeeCents = 0,
                TicketFeeCents = 0,
                Discount = null,
                TicketServicePlusCents = 0
            });

        var actual = await _sut.Cost(new()
        {
            ReservationReference = Guid.NewGuid()
        });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<OrderCostResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrderService.Verify(os => os.TotalOrderCostAsync(It.IsAny<Guid>(), It.IsAny<Guid?>(), It.IsAny<bool>(), It.IsAny<bool>()), Times.Once);
    }

    [Fact]
    public async Task TestThatResendCallsOrderServiceResendOrderAsync()
    {
        var orderId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        _sut.SetupHttpContext(organizationId: organizationId, userType: UserType.Organization.ToString());

        _mockedOrderService.Setup(os => os.HasAccessAsync(orderId, null, organizationId, UserType.Organization))
            .ReturnsAsync(true);
        _mockedOrderService.Setup(os => os.ResendOrderAsync(orderId, null));

        var actual = await _sut.Resend(orderId);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrderService.Verify(os => os.HasAccessAsync(orderId, null, organizationId, UserType.Organization), Times.Once);
        _mockedOrderService.Verify(os => os.ResendOrderAsync(orderId, null), Times.Once);
    }

    [Fact]
    public async Task TestThatResendThrowsOrderNotFoundExceptionWhenUserHasNoAccess()
    {
        var orderId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        _sut.SetupHttpContext(organizationId: organizationId, userType: UserType.Organization.ToString());

        _mockedOrderService.Setup(os => os.HasAccessAsync(orderId, null, organizationId, UserType.Organization))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<OrderNotFoundException>(async () => await _sut.Resend(orderId));

        _mockedOrderService.Verify(os => os.HasAccessAsync(orderId, null, organizationId, UserType.Organization), Times.Once);
    }

    [Fact]
    public async Task TestThatExplicitResendCallsOrderServiceResendOrderAsync()
    {
        var orderId = Guid.NewGuid();
        var adminId = Guid.NewGuid();
        var explicitMail = new EmailRequest { EmailAddress = "test@abc.com" };

        _sut.SetupHttpContext(platformUserId: adminId, userType: UserType.Admin.ToString());

        _mockedOrderService.Setup(os => os.HasAccessAsync(orderId, adminId, null, UserType.Admin))
            .ReturnsAsync(true);
        _mockedOrderService.Setup(os => os.ResendOrderAsync(orderId, explicitMail.EmailAddress));

        var actual = await _sut.ExplicitResend(orderId, explicitMail);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrderService.Verify(os => os.HasAccessAsync(orderId, adminId, null, UserType.Admin), Times.Once);
        _mockedOrderService.Verify(os => os.ResendOrderAsync(orderId, explicitMail.EmailAddress), Times.Once);
    }

    [Fact]
    public async Task TestThatExplicitResendThrowsOrderNotFoundExceptionWhenUserHasNoAccess()
    {
        var orderId = Guid.NewGuid();
        var adminId = Guid.NewGuid();

        _sut.SetupHttpContext(platformUserId: adminId, userType: UserType.Admin.ToString());

        _mockedOrderService.Setup(os => os.HasAccessAsync(orderId, adminId, null, UserType.Admin))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<OrderNotFoundException>(async () => await _sut.ExplicitResend(orderId, new() { EmailAddress = "test@abc.com" }));

        _mockedOrderService.Verify(os => os.HasAccessAsync(orderId, adminId, null, UserType.Admin), Times.Once);
    }

    [Fact]
    public async Task TestThatRegenerateOrderTicketPdfCallsOrderServiceRegenerateAndDownloadTicketPdfAsync()
    {
        var orderId = Guid.NewGuid();

        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());

        await _sut.RegenerateOrderTicketPdf(orderId);

        _mockedOrderService.Verify(os => os.RegenerateAndDownloadTicketPdfAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRegenerateOrderTicketPdfCallsOrderServiceRegenerateAndDownloadTicketPdfAsyncAndReturnsRegenerateTicketResponse()
    {
        var request = new RegenerateTicketRequest
        {
            PspReference = It.IsAny<string>(),
            PaidOnDate = DateTime.UtcNow
        };

        _mockedOrderService.Setup(os => os.RegenerateAndDownloadTicketPdfAsync(request.PspReference, request.PaidOnDate))
            .ReturnsAsync(new RegenerateTicketResponse
            {
                OrderId = default,
                ClientId = default
            });

        await _sut.RegenerateOrderTicketPdf(request);

        _mockedOrderService.Verify(os => os.RegenerateAndDownloadTicketPdfAsync(request.PspReference, request.PaidOnDate), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateReceiptCallsOrderServiceMethods()
    {
        var orderId = Guid.NewGuid();

        _mockedOrderService.Setup(os => os.ExistsAsync(orderId))
            .ReturnsAsync(true);

        await _sut.GenerateReceipt(orderId);

        _mockedOrderService.Verify(os => os.ExistsAsync(orderId), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateReceiptThrowsOrderNotFoundException()
    {
        var orderId = Guid.NewGuid();

        _mockedOrderService.Setup(os => os.ExistsAsync(orderId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<OrderNotFoundException>(() => _sut.GenerateReceipt(orderId));

        _mockedOrderService.Verify(os => os.ExistsAsync(orderId), Times.Once);
        _mockedOrderService.Verify(os => os.GenerateReceiptAsync(orderId), Times.Never);
    }

    [Fact]
    public async Task TestThatDownloadOrderReceiptPdfCallsOrderServiceMethods()
    {
        var orderId = Guid.NewGuid();

        _mockedOrderService.Setup(os => os.HasReceiptAsync(orderId))
            .ReturnsAsync(true);

        _mockedOrderService.Setup(os => os.DownloadReceiptPdfAsync(orderId))
            .ReturnsAsync(new MemoryStream());

        var actual = await _sut.DownloadOrderReceiptPdf(orderId);

        Assert.Equal("application/pdf", actual.ContentType);

        _mockedOrderService.Verify(os => os.HasReceiptAsync(orderId), Times.Once);
        _mockedOrderService.Verify(os => os.DownloadReceiptPdfAsync(orderId), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadOrderReceiptPdfThrowsOrderNotFoundException()
    {
        var orderId = Guid.NewGuid();

        _mockedOrderService.Setup(os => os.HasReceiptAsync(orderId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<OrderReceiptNotFoundException>(() => _sut.DownloadOrderReceiptPdf(orderId));

        _mockedOrderService.Verify(os => os.HasReceiptAsync(orderId), Times.Once);
        _mockedOrderService.Verify(os => os.DownloadReceiptPdfAsync(orderId), Times.Never);
    }

    [Fact]
    public async Task TestThatCombinedCostCallsOrderServiceTotalOrderCostPerReservationReferenceAndFlattensTheResult()
    {
        var combinedOrderRequest = new CombinedOrderCostRequest
        {
            ReservationReferences = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()],
            PaymentMethodId = Guid.NewGuid(),
            ReceiveViaSms = true,
            EnabledTicketServicePlus = false
        };

        _mockedOrderService.Setup(os => os.TotalOrderCostAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), true, false))
            .ReturnsAsync(new OrderCostResponse
            {
                TotalOrderCostCents = 1000,
                PaymentFeeCents = 50,
                TicketFeeCents = 100,
                SeatedTicketFeeCents = 0,
                Discount = null,
                TicketServicePlusCents = 0,
                ProductFeeCents = 0
            });

        var actual = await _sut.CombinedCost(combinedOrderRequest);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        var resultValue = (ApiResponse<OrderCostResponse>)((OkObjectResult)actual.Result).Value!;
        Assert.IsType<ApiResponse<OrderCostResponse>>(resultValue);
        Assert.Equal(3000, resultValue.Data.TotalOrderCostCents);
        Assert.Equal(150, resultValue.Data.PaymentFeeCents);

        _mockedOrderService.Verify(os => os.TotalOrderCostAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), true, false), Times.Exactly(3));
    }

    [Fact]
    public async Task TestThatOrderWithCombinedShopCodeAndRequestCallsOrderServicePlaceCombiOrderAsync()
    {
        var combinedShopCode = "UnitCombiCode";
        var request = new CombinedOrderRequest
        {
            ReservationReferences = [Guid.NewGuid(), Guid.NewGuid()],
            OrderClient = new()
            {
                Email = "unit@combimail.com"
            },
            PaymentMethodId = Guid.NewGuid(),
            ReceiveViaSms = false,
            OptInPromotionalEmail = false,
            OptInPromotionalSms = false,
            EnabledTicketServicePlus = false,
            ShopQuestionAnswers = new List<ShopQuestionAnswerDto>()
        };

        _mockedOrderService.Setup(os => os.PlaceCombinedOrderAsync(combinedShopCode, request))
            .ReturnsAsync(new CombinedOrderCompleteResponse
            {
                ClientId = Guid.NewGuid(),
                RedirectUrl = "unit/url/redirect/combi",
                OrderIds = [Guid.NewGuid(), Guid.NewGuid()]
            });

        var actual = await _sut.Order(combinedShopCode, request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrderService.Verify(os => os.PlaceCombinedOrderAsync(combinedShopCode, request), Times.Once);
    }
}