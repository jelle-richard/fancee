﻿using System;
using System.Collections.Generic;
using System.Linq;
using FanceeData.Models.Ticketing;
using OrderService.Dtos.Requests.Order;
using OrderService.Utils.Adapter;

namespace OrderService.Tests.Utils.Adapter;

public class OrderAdapterTests
{
    private readonly OrderRequest _orderRequest = new()
    {
        OrderClient = new()
        {
            FirstName = "unit",
            LastName = "tester",
            PhoneNumber = "0612345678"
        },
        ReceiveViaSms = false,
        OptInPromotionalSms = false,
        OptInPromotionalEmail = false,
        EnabledTicketServicePlus = false
    };

    private readonly Client _client = new()
    {
        UserId = Guid.NewGuid()
    };

    private readonly Currency _validCurrency = new()
    {
        Active = true,
        Character = "€",
        Name = "Euro",
        ShortCode = "EUR"
    };

    [Theory]
    [InlineData(null, null)]
    [InlineData(PaymentRefusalReason.IssuerUnavailable, OrderService.Dtos.Shared.PaymentRefusalReason.IssuerUnavailable)]
    [InlineData(PaymentRefusalReason.NotEnoughBalance, OrderService.Dtos.Shared.PaymentRefusalReason.NotEnoughBalance)]
    [InlineData(PaymentRefusalReason.Fraud, OrderService.Dtos.Shared.PaymentRefusalReason.Fraud)]
    [InlineData(PaymentRefusalReason.InvalidPin, OrderService.Dtos.Shared.PaymentRefusalReason.InvalidPin)]
    [InlineData(PaymentRefusalReason.PinLimitReached, OrderService.Dtos.Shared.PaymentRefusalReason.PinLimitReached)]
    [InlineData(PaymentRefusalReason.RestrictedCard, OrderService.Dtos.Shared.PaymentRefusalReason.RestrictedCard)]
    [InlineData(PaymentRefusalReason.WithdrawalAmountExceeded, OrderService.Dtos.Shared.PaymentRefusalReason.WithdrawalAmountExceeded)]
    [InlineData(PaymentRefusalReason.WithdrawalCountExceeded, OrderService.Dtos.Shared.PaymentRefusalReason.WithdrawalCountExceeded)]
    [InlineData(PaymentRefusalReason.None, OrderService.Dtos.Shared.PaymentRefusalReason.None)]
    public void TestThatToPaymentRefusalReasonReturnsMappedPaymentRefusalReasonDto(PaymentRefusalReason? input, OrderService.Dtos.Shared.PaymentRefusalReason? expected)
    {
        var actual = input.ToPaymentRefusalReasonDto();

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatToOrderParsedClientOrder()
    {
        var actual = OrderAdapter.ToOrder(Guid.NewGuid(), _validCurrency, _client, _orderRequest, _orderRequest.ReservationReference, 0, 0, null, 1000, new() { AmountCents = 83, PaidBy = PaidBy.Organization }, false);

        Assert.Equal(_orderRequest.OrderClient.FirstName, actual.ClientOrder.FirstName);
        Assert.Equal(PaymentStatus.Unknown, actual.PaymentStatus);
        Assert.Equal(83, actual.PaymentFeeCents);
    }

    [Fact]
    public void TestThatToOrderSetsPaymentStatusNoneForCostlessOrder()
    {
        var actual = OrderAdapter.ToOrder(Guid.NewGuid(), _validCurrency, _client, _orderRequest, _orderRequest.ReservationReference, 0, 0, new(), null, new()
        {
            AmountCents = 0,
            PaidBy = PaidBy.Client
        }, false);

        Assert.Equal(PaymentStatus.Authorised, actual.PaymentStatus);
    }

    [Fact]
    public void TestThatToOrderSetsPaymentStatusAuthorizeForCash()
    {
        var actual = OrderAdapter.ToOrder(Guid.NewGuid(), _validCurrency, _client, _orderRequest, _orderRequest.ReservationReference, 85, 98, new(), 1500, new() { AmountCents = 83, PaidBy = PaidBy.Organization }, true);

        Assert.Equal(PaymentStatus.Authorised, actual.PaymentStatus);
    }

    [Fact]
    public void TestThatToOrderResponseAllowsNullForAddress()
    {
        var order = new Order
        {
            Id = Guid.Empty,
            TotalCostCents = 1234,
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethod = new() { Name = "cash" },
            CreatedAt = DateTime.UtcNow,
            PspReference = null,
            ClientOrder = new()
            {
                FirstName = "Hans",
                LastName = "de Tester",
                Client = new() { User = new() { Email = "client@email.com" } },
                Gender = Gender.Neutral
            },
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new ReservedProduct[]
                {
                    new()
                    {
                        Product = new()
                        {
                            Event = new()
                            {
                                Name = "Unit event name",
                                StartDate = DateTime.UtcNow.AddDays(5),
                                Organization = new()
                                {
                                    Name = "Unit BV",
                                    Contract = new()
                                    {
                                        TicketFeeCents = 55,
                                        ProductFeeCents = 55
                                    }
                                }
                            }
                        }
                    }
                }
            },
            CurrencyNavigation = new() { ShortCode = "EUR" },
            PspHistories = new List<OrderPspHistory>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    AmountCents = 1234,
                    CreatedOn = DateTime.UtcNow.AddMinutes(-10),
                    PaymentStatus = PaymentStatus.Unknown,
                    PspReference = "UnknownPsp123"
                },
                new()
                {
                    Id = Guid.NewGuid(),
                    AmountCents = 1234,
                    CreatedOn = DateTime.UtcNow.AddMinutes(-8),
                    PaymentStatus = PaymentStatus.Pending,
                    PspReference = "PendingPsp123"
                },
                new()
                {
                    Id = Guid.NewGuid(),
                    AmountCents = 1234,
                    CreatedOn = DateTime.UtcNow.AddMinutes(-6),
                    PaymentStatus = PaymentStatus.Authorised,
                    PspReference = "AuthorisedPsp123"
                }
            }
        };

        var actual = order.ToOrderResponse(new(), new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-100),
            PeriodEnd = DateTime.UtcNow.AddDays(100),
            TicketFeeCents = 50,
            TicketFeePercentage = 2,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            ProductFeeCents = 30,
            ProductFeePercentage = 1,
            GuestListFeeCents = 15
        });

        Assert.Null(actual.Client.Address);
        Assert.Equal(3, actual.PaymentHistory.Count());
    }

    [Fact]
    public void TestThatToOrderResponseReturnsHistoricProductPrices()
    {
        var productId = Guid.NewGuid();
        var paymentMethodId = Guid.NewGuid();
        var reservationReference = Guid.NewGuid();

        var order = new Order
        {
            Id = Guid.Empty,
            TotalCostCents = 1234,
            PaymentStatus = PaymentStatus.Authorised,
            PaymentMethod = new() { Name = "cash" },
            PaymentMethodId = paymentMethodId,
            ReservationReference = reservationReference,
            CreatedAt = DateTime.UtcNow.AddDays(-10),
            PspReference = null,
            ClientOrder = new()
            {
                FirstName = "Hans",
                LastName = "de Tester",
                Client = new() { User = new() { Email = "client@email.com" } },
                Gender = Gender.Neutral
            },
            ReservationReferenceNavigation = new()
            {
                Reference = reservationReference,
                ReservedProducts = new ReservedProduct[]
                {
                    new()
                    {
                        Quantity = 1,
                        Product = new()
                        {
                            Id = productId,
                            PriceCents = 1200,
                            FeeCents = null,
                            Type = ProductType.Ticket,
                            PackQuantity = 1,
                            PriceHistories = new List<ProductPriceHistory>
                            {
                                new()
                                {
                                    ProductId = productId,
                                    PriceCents = 1000,
                                    FeeCents = 20,
                                    Date = DateTime.UtcNow.AddDays(-5)
                                }
                            },
                            Event = new()
                            {
                                Name = "Unit event name",
                                StartDate = DateTime.UtcNow.AddDays(5),
                                Organization = new()
                                {
                                    Name = "Unit BV",
                                    Contract = new()
                                    {
                                        TicketFeeCents = 55,
                                        ProductFeeCents = 55
                                    }
                                }
                            }
                        }
                    }
                }
            },
            CurrencyNavigation = new() { ShortCode = "EUR" }
        };

        var actual = order.ToOrderResponse(new(), new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-100),
            PeriodEnd = DateTime.UtcNow.AddDays(100),
            TicketFeeCents = 50,
            TicketFeePercentage = 2,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            ProductFeeCents = 30,
            ProductFeePercentage = 1,
            GuestListFeeCents = 15
        });

        Assert.NotEmpty(actual.Products);
        Assert.Equal(1200, actual.Products.First().PriceCents);
        Assert.Equal(50, actual.Products.First().FeeCents);
        Assert.Equal(reservationReference, actual.ReservationReference);
    }
}