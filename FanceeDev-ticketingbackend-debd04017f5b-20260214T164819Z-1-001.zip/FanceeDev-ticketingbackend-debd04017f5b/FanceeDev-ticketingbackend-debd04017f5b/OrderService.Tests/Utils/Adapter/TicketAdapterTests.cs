using System;
using FanceeData.Models.Ticketing;
using OrderService.Utils.Adapter;

namespace OrderService.Tests.Utils.Adapter;

public class TicketAdapterTests
{
    private static readonly IssuedTicket IssuedTicket = new()
    {
        Code = "FANUNIT123456789",
        Holder = new()
        {
            Code = "HolderCode",
            FirstName = "Unit",
            LastName = "Test",
            Email = "unit@holder.test",
            Gender = Gender.Female,
            PersonalizedOn = DateTime.UtcNow.AddDays(-10)
        },
        IssuedProduct = new()
        {
            Product = new()
            {
                Name = "UnitProductName",
                TicketOption = new()
                {
                    PartialAccessStart = null,
                    PartialAccessEnd = null,
                    MaximumPreArrivalTimeMinutes = 60
                }
            }
        },
        Label = "Unit label"
    };

    [Fact]
    public void TestThatToEventOrderTicketsResponseAdaptersIssuedTicketToEventOrderTicketResponse()
    {
        var actual = IssuedTicket.ToEventOrderTicketsResponse(false);

        Assert.Equal("FANUNIT123456789", actual.Code);
    }

    [Fact]
    public void TestThatToEventOrderTicketsResponseAdaptersIssuedTicketToEventOrderTicketResponseButHidesTicketCodesWhenSealed()
    {
        var actual = IssuedTicket.ToEventOrderTicketsResponse(true);

        Assert.Equal("SEALED", actual.Code);
    }

    [Fact]
    public void TestThatToOrderTicketAdaptsAnIssuedTicketToAnOrderTicket()
    {
        var actual = IssuedTicket.ToOrderTicket();

        Assert.Equal("HolderCode", actual.Holder.Code);
    }
}