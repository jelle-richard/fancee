using System;
using System.Collections.Generic;
using System.Linq;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;
using OrderService.Utils.Adapter;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Shared.Contract;

namespace OrderService.Tests.Utils.Adapter;

[TestSubject(typeof(ProductAdapter))]
public class ProductAdapterTests
{
    private static readonly HostedDeploymentEnvironment Env = new()
    {
        ContentDeliveryNetworkBaseUrl = "test.com"
    };

    [Fact]
    public void TestThatToOrderProductMapsProduct()
    {
        var contractFee = new ContractFee
        {
            PeriodStart = DateTime.MinValue,
            PeriodEnd = DateTime.MaxValue,
            ProductFeeCents = 10,
            ProductFeePercentage = 0,
            TicketFeeCents = 20,
            TicketFeePercentage = 0,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 30
        };

        var product = new Product
        {
            Name = "Unit Product",
            Type = ProductType.Product,
            PackQuantity = 2,
            PriceCents = 1000,
            IssuedProducts = new List<IssuedProduct>(),
            ProductMedia = new List<ProductMedia> { new() { File = new() { Path = "image.png" } } }
        };

        var actual = product.ToOrderProduct(1, DateTime.UtcNow, Env, contractFee);

        Assert.NotNull(actual);
        Assert.Equal("Unit Product", actual.Name);
        Assert.Equal(1000, actual.PriceCents);
        Assert.Equal(20, actual.FeeCents);
        Assert.Equal(ProductType.Product, actual.Type);
        Assert.Single(actual.Media);
        Assert.Equal("http://test.com/image.png", actual.Media.First().Url);
        Assert.Empty(actual.IssuedTickets);
    }

    [Fact]
    public void TestThatToOrderProductMapsProductWithPercentualFeePriceHistory()
    {
        var contractFee = new ContractFee
        {
            PeriodStart = DateTime.MinValue,
            PeriodEnd = DateTime.MaxValue,
            ProductFeeCents = 0,
            ProductFeePercentage = 25,
            TicketFeeCents = 0,
            TicketFeePercentage = 0,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 0
        };

        var product = new Product
        {
            Name = "Unit Product",
            Type = ProductType.Product,
            PackQuantity = 2,
            PriceCents = 1000,
            IssuedProducts = new List<IssuedProduct>(),
            PriceHistories = new List<ProductPriceHistory>
            {
                new()
                {
                    Date = DateTime.UtcNow.AddDays(-5),
                    PriceCents = 500
                },
                new()
                {
                    Date = DateTime.UtcNow.AddDays(1),
                    PriceCents = 750
                }
            }
        };

        var actual = product.ToOrderProduct(1, DateTime.UtcNow, Env, contractFee);

        Assert.NotNull(actual);
        Assert.Equal(1, actual.Quantity);
        Assert.Empty(actual.IssuedTickets);
        Assert.Equal(500, actual.PriceCents);
        Assert.Equal(250, actual.FeeCents);
    }
}