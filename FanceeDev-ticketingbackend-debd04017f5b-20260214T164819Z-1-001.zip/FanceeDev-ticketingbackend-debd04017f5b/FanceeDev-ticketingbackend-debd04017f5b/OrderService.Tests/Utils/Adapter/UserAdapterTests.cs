﻿using System;
using FanceeData.Models.Ticketing;
using OrderService.Dtos.Requests.Order;
using OrderService.Utils.Adapter;

namespace OrderService.Tests.Utils.Adapter;

public class UserAdapterTests
{
    [Fact]
    public void TestThatToClientParsesFromClientOrderRequest()
    {
        var fanceeUsersId = Guid.NewGuid();

        var clientOrderRequest = new ClientOrderRequest
        {
            Email = "unit@tester.com",
            FirstName = "Unit",
            LastName = "Tester",
            PhoneNumber = "0612345678",
            Address = new()
            {
                CountryCode = "NL",
                PostalCode = "1234AB",
                Street = "Unitstreet",
                City = "UnitCity",
                HouseNumber = "12a",
                Venue = "UnitPlaza",
                Latitude = 1,
                Longitude = 2
            }
        };

        var actual = clientOrderRequest.ToClient(fanceeUsersId, null);

        Assert.Equal(clientOrderRequest.Email, actual.User.Email);
        Assert.Equal(fanceeUsersId, actual.User.FanceeUsersId);
    }

    [Fact]
    public void TestThatToClientUpdatesExistingUserWithClientUserType()
    {
        var fanceeUsersId = Guid.NewGuid();

        var clientOrderRequest = new ClientOrderRequest
        {
            Email = "unit@tester.com",
            FirstName = "Unit",
            LastName = "Tester",
            PhoneNumber = "0612345678",
            Address = new()
            {
                CountryCode = "NL",
                PostalCode = "1234AB",
                Street = "Unitstreet",
                City = "UnitCity",
                HouseNumber = "12a",
                Venue = "UnitPlaza",
                Latitude = 1,
                Longitude = 2
            }
        };

        var user = new User
        {
            Type = UserType.Organization,
            Organization = new()
        };

        var actual = clientOrderRequest.ToClient(fanceeUsersId, user);

        Assert.Equal(UserType.Client | UserType.Organization, actual.User.Type);
    }

    [Fact]
    public void TestThatToClientParsesFromClientOrderRequestWithoutAddress()
    {
        var clientOrderRequest = new ClientOrderRequest
        {
            Email = "unit@tester.com",
            FirstName = "Unit",
            LastName = "Tester",
            PhoneNumber = "0612345678",
            Address = null
        };

        var actual = clientOrderRequest.ToClient(Guid.NewGuid(), null);

        Assert.Null(actual.User.UserContactInfo.Address);
    }

    [Fact]
    public void TestThatToOrderEventOrganizationParsesOrganization()
    {
        var organization = new Organization
        {
            Name = "Unit BV",
            Contract = new()
            {
                TicketFeeCents = 55,
                ProductFeeCents = 65
            }
        };

        var actual = organization.ToOrderEventOrganization();

        Assert.Equal("Unit BV", actual.Name);
        Assert.Equal(55, actual.TicketFeeCents);
        Assert.Equal(65, actual.ProductFeeCents);
    }
}