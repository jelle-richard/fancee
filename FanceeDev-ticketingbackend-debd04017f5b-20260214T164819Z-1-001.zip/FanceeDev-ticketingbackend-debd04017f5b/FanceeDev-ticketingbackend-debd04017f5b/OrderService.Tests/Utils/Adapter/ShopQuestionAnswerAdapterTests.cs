using System;
using OrderService.Dtos.Shared;
using OrderService.Utils.Adapter;

namespace OrderService.Tests.Utils.Adapter;

public class ShopQuestionAnswerAdapterTests
{
    [Fact]
    public void TestThatToShopQuestionAnswerReturnsValidShopQuestionAnswerEntity()
    {
        var orderId = Guid.NewGuid();
        var questionId = Guid.NewGuid();

        var actual = new ShopQuestionAnswerDto
        {
            QuestionId = questionId,
            Answer = "Yes"
        }.ToShopQuestionAnswer(orderId);

        Assert.Equal("Yes", actual.Answer);
        Assert.Equal(orderId, actual.OrderId);
        Assert.Equal(questionId, actual.ShopQuestionId);
    }
}