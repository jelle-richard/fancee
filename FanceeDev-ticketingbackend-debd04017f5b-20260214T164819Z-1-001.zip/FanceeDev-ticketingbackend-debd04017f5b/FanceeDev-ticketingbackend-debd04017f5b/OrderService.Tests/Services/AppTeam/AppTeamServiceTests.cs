using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using OrderService.Persistence.AppTeam;
using OrderService.Persistence.Reservation;
using OrderService.Services.AppTeam;
using WebApiCore.Exceptions;

namespace OrderService.Tests.Services.AppTeam;

public class AppTeamServiceTests
{
    private readonly AppTeamService _sut;
    private readonly Mock<IAppTeamDao> _mockedAppTeamDao = new();
    private readonly Mock<IReservationDao> _mockedReservationDao = new();

    public AppTeamServiceTests()
    {
        _sut = new(_mockedAppTeamDao.Object, _mockedReservationDao.Object);
    }

    [Fact]
    public async Task TestThatHasSalesAndCashEnabledForShopAsyncCallsAppTeamDaoHasSalesAndCashEnabledForShopAsync()
    {
        var appTeamId = Guid.NewGuid();

        _mockedAppTeamDao.Setup(atd => atd.HasSalesAndCashEnabledForProductsAsync(appTeamId, It.IsAny<IEnumerable<Guid>>() ))
            .ReturnsAsync(true);

        var actual = await _sut.HasSalesAndCashEnabledForReservationAsync(appTeamId, Guid.NewGuid());

        Assert.True(actual);

        _mockedAppTeamDao.Verify(atd => atd.HasSalesAndCashEnabledForProductsAsync(appTeamId, It.IsAny<IEnumerable<Guid>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatOrganizationIdAsyncCallsAppTeamDaoOrganizationIdAsync()
    {
        var appTeamId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        _mockedAppTeamDao.Setup(atd => atd.OrganizationIdAsync(appTeamId))
            .ReturnsAsync(organizationId);

        var actual = await _sut.OrganizationIdAsync(appTeamId);

        Assert.Equal(organizationId, actual);

        _mockedAppTeamDao.Verify(atd => atd.OrganizationIdAsync(appTeamId), Times.Once);
    }

    [Fact]
    public async Task TestThatOrganizationIdAsyncThrowsAppTeamNotFoundExceptionOnInvalidAppTeamId()
    {
        await Assert.ThrowsAsync<AppTeamNotFoundException>(async () => await _sut.OrganizationIdAsync(Guid.Empty));

        _mockedAppTeamDao.Verify(atd => atd.OrganizationIdAsync(Guid.Empty), Times.Once);
    }
}