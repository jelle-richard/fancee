﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using FanceeAuthentication.Dtos.Requests;
using FanceeAuthentication.Providers.Authentication;
using FanceeData.Models.Ticketing;
using Fs.MessageBus.Publishers;
using Fs.SeatingUtils.Providers;
using Microsoft.EntityFrameworkCore.Query;
using OrderService.Dtos.Requests.Order;
using OrderService.Dtos.Responses.Order;
using OrderService.Dtos.Responses.Ticket;
using OrderService.Persistence.Order;
using OrderService.Persistence.Order.Filters;
using OrderService.Persistence.OrganizationBlockedEmail;
using OrderService.Persistence.Reservation;
using OrderService.Persistence.Shop;
using OrderService.Persistence.User;
using OrderService.Services;
using OrderService.Services.CombinedShop;
using OrderService.Services.Order.Exceptions;
using OrderService.Services.PaymentMethod;
using OrderService.Services.Pin;
using OrderService.Services.Shop;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses.Discount;
using WebApiCore.Dtos.Responses.Order;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Contract;
using WebApiCore.Dtos.Shared.Product;
using WebApiCore.Exceptions.CombinedShop;
using WebApiCore.Exceptions.Event;
using WebApiCore.Exceptions.Order;
using WebApiCore.Exceptions.Shop;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.MessageBus.Messages.PinTerminal;
using WebApiCore.MessageBus.Messages.Product;
using WebApiCore.Services.AppTeam.Exceptions;
using WebApiCore.Services.Contract;
using WebApiCore.Services.Country;
using WebApiCore.Services.Currency;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Discount;
using WebApiCore.Services.Storage;
using File = FanceeData.Models.Ticketing.File;

namespace OrderService.Tests.Services.Order;

public class OrderServiceTests
{
    private const string ShopCode = "UT-ShopCode";

    public static readonly object[][] InvalidOrderRetrievalUserTypes =
    [
        [UserType.Ambassador, false],
        [UserType.Host, false],
        [UserType.Ambassador | UserType.Host, false]
    ];

    private static readonly ContractFee DefaultContract = new()
    {
        PeriodStart = DateTime.UtcNow.AddDays(-100),
        PeriodEnd = DateTime.UtcNow.AddDays(100),
        ProductFeeCents = 83,
        ProductFeePercentage = 0,
        TicketFeeCents = 83,
        TicketFeePercentage = 0,
        SeatedTicketFeeCents = 0,
        SeatedTicketFeePercentage = 0,
        GuestListFeeCents = 20
    };

    private static readonly FanceeData.Models.Ticketing.Event ValidEvent = new()
    {
        Name = "UnitEvent",
        StartDate = DateTime.UtcNow.AddDays(2),
        Organization = new()
        {
            Name = "Unit BV",
            Contract = new()
            {
                TicketFeeCents = 55,
                ProductFeeCents = 55
            }
        }
    };

    private static readonly Product ValidProduct = new()
    {
        PriceCents = 1200,
        Name = "UnitProductTicket",
        Type = ProductType.Ticket,
        Event = ValidEvent
    };

    private static readonly Product ValidProductNoFee = new()
    {
        PriceCents = 1200,
        Name = "UnitProductTicket",
        Type = ProductType.Ticket,
        Event = ValidEvent,
        FeeCents = 0
    };

    private static readonly List<ReservedProduct> ValidReservedProducts = [new() { Product = ValidProduct, Quantity = 1 }];

    private static readonly List<ReservedProduct> ValidReservedProductsMultipleQuantity = [new() { Product = ValidProductNoFee, Quantity = 2 }];

    private static readonly List<ReservedProduct> ValidReservedProductsWithCustomFee =
    [
        new()
        {
            Product = new()
            {
                PriceCents = 1200,
                Name = "UnitProductTicketWithFee",
                Type = ProductType.Ticket,
                FeeCents = 500,
                Event = ValidEvent
            },
            Quantity = 1
        }
    ];

    private static readonly Guid[] MockedProductIds = [Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid OrganizationId = Guid.NewGuid();
    private static readonly Guid UserId = Guid.NewGuid();
    private static readonly Guid EventId = Guid.NewGuid();
    private static readonly Guid PaymentMethodId = Guid.NewGuid();
    private static readonly Guid ReservationReference = Guid.NewGuid();

    private readonly OrderService.Services.Order.OrderService _sut;
    private readonly Mock<IShopDao> _mockedShopDao = new();
    private readonly Mock<IOrderDao> _mockedOrderDao = new();
    private readonly Mock<WebApiCore.Persistence.Order.IOrderDao> _mockedWebApiCoreOrderDao = new();
    private readonly Mock<IReservationDao> _mockedReservationDao = new();
    private readonly Mock<IUserDao> _mockedUserDao = new();
    private readonly Mock<IOrganizationBlockedEmailDao> _mockedOrganizationBlockedEmailDao = new();
    private readonly Mock<IMessagePublisher<IssueProductsMessage>> _mockedPublisher = new();
    private readonly Mock<IAuthenticationProvider> _mockedAuthenticationProvider = new();
    private readonly Mock<IPaymentMethodService> _mockedPaymentMethodService = new();
    private readonly Mock<IPinService> _mockedPinService = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<IShopQuestionService> _mockedShopQuestionService = new();
    private readonly Mock<IMessagePublisher<IGeneratePdfMessage>> _mockedGeneratePdfPublisher = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();
    private readonly Mock<ITrackingService> _mockedTrackingService = new();
    private readonly Mock<IContractService> _mockedContractService = new();
    private readonly Mock<ISeatsIoProvider> _mockedSeatsIoProvider = new();
    private readonly Mock<IDiscountService> _mockedDiscountService = new();
    private readonly Mock<WebApiCore.Persistence.Reservation.IReservationDao> _mockedWebApiCoreReservationDao = new();
    private readonly Mock<ICombinedShopDao> _mockedCombinedShopDao = new();

    private readonly FanceeData.Models.Ticketing.Order _retrievableOrder = new()
    {
        Id = Guid.NewGuid(),
        TotalCostCents = 1000,
        PaymentStatus = PaymentStatus.Authorised,
        PaymentMethod = new()
        {
            Name = "UnitMethod"
        },
        CreatedAt = DateTime.UtcNow.AddDays(-1),
        PspReference = "UNITPSP123",
        ClientOrder = new()
        {
            FirstName = "UnitFirst",
            LastName = "UnitLast",
            Client = new()
            {
                User = new() { Email = "unit@email.com" }
            },
            PhoneNumber = "0612345678",
            Gender = Gender.Female,
            Birthdate = DateTime.UtcNow.AddYears(-25),
            Address = new()
            {
                City = "UnitCity",
                Latitude = 0,
                Longitude = 0,
                Street = "UnitStreet",
                Venue = "UnitVenue",
                CountryCode = "NL",
                HouseNumber = "4a",
                PostalCode = "1234AB"
            },
            ReceiveViaSmsCostCents = 0,
            TicketServicePlusCostCents = 0,
            OptInPromotionalSms = true,
            OptInPromotionalEmail = true
        },
        IssuedProducts = new List<IssuedProduct>
        {
            new()
            {
                Product = ValidProduct,
                IssuedTicket = new()
                {
                    Code = "UnitCode4321",
                    Holder = new()
                    {
                        Code = "UnitCode4321",
                        FirstName = "UnitFirstName",
                        LastName = "UnitLastName",
                        Email = "unit@email.com",
                        Gender = Gender.Female,
                        PersonalizedOn = DateTime.UtcNow.AddDays(-2)
                    }
                }
            }
        },
        ReservationReferenceNavigation = new()
        {
            ReservedProducts = ValidReservedProducts
        },
        CurrencyNavigation = new()
        {
            Character = "€",
            ShortCode = "EUR",
            Name = "Euro"
        },
        ShopQuestionAnswers = new List<ShopQuestionAnswer>
        {
            new()
            {
                Answer = "Autobus",
                ShopQuestion = new()
                {
                    Question = "Dus?"
                }
            }
        }
    };

    private readonly FanceeData.Models.Ticketing.Shop _validShop = new()
    {
        Name = "UnitShop",
        Code = ShopCode,
        Active = true,
        Layout = ShopLayout.Ticketshop,
        StartDate = DateTime.UtcNow,
        EndDate = DateTime.UtcNow.AddDays(1),
        ShopDesign = new()
        {
            PrimaryColor = "FFFFFF",
            TextColor = "000FFF",
            BackdropColor = "FFF000",
            BackgroundColor = "F0F0F0",
            BackgroundMediaFile = new()
            {
                Id = Guid.NewGuid(),
                Name = "shopbackground.jpg",
                Path = "shop/background.jpg"
            }
        },
        ShopFieldRequirements = new List<ShopFieldRequirement>
        {
            new()
            {
                Field = ShopField.Email,
                Required = true,
                Enabled = true
            }
        },
        Event = new()
        {
            Id = EventId,
            OrganizationId = UserId,
            Name = "UnitTestParty",
            Type = EventType.Normal,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1),
            Status = EventStatus.Active,
            Description = "UnitTestParty-description",
            MinimumAge = 10,
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    EventId = EventId,
                    PaymentMethodId = PaymentMethodId,
                    PaymentMethod = new()
                    {
                        Id = PaymentMethodId,
                        Name = "UnitPayments",
                        Provider = PaymentProvider.Adyen,
                        FeePercentage = 2,
                        FeeStaticCents = 40,
                        Order = 1,
                        Active = true
                    }
                }
            },
            Organization = new()
            {
                CurrencyNavigation = new()
                {
                    Active = true,
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                }
            },
            Products = new List<Product>
            {
                new()
                {
                    Id = MockedProductIds[0],
                    EventId = EventId,
                    Name = "Ticket1",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product
                },
                new()
                {
                    Id = MockedProductIds[1],
                    EventId = EventId,
                    Name = "Ticket2",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product
                }
            }
        },
        ItemsInShop = new List<ItemInShop>
        {
            new()
            {
                Id = Guid.NewGuid(),
                ShopCode = ShopCode,
                ProductId = MockedProductIds[0],
                Position = 1,
                Product = new()
                {
                    Id = MockedProductIds[0],
                    EventId = EventId,
                    Name = "Ticket1",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product
                }
            },
            new()
            {
                Id = Guid.NewGuid(),
                ShopCode = ShopCode,
                ProductId = MockedProductIds[1],
                Position = 2,
                Product = new()
                {
                    Id = MockedProductIds[1],
                    EventId = EventId,
                    Name = "Ticket2",
                    Stock = 100,
                    PriceCents = 1000,
                    Description = "",
                    MaximumPurchasePerOrder = 10,
                    Type = ProductType.Product
                }
            }
        }
    };

    private readonly OrderRequest _orderRequest = new()
    {
        ReservationReference = ReservationReference,
        OrderClient = new()
        {
            Email = "unittest@client.com",
            FirstName = "Unit",
            LastName = "Test",
            PhoneNumber = "0612345678",
            Birthdate = DateTime.UtcNow.AddYears(-18),
            Address = new()
            {
                CountryCode = "NL",
                PostalCode = "1234AB",
                Street = "UnitStreet",
                City = "UnitCity",
                HouseNumber = "1",
                Venue = "UnitPlaza",
                Longitude = 1,
                Latitude = 2
            }
        },
        PaymentMethodId = PaymentMethodId,
        ReceiveViaSms = false,
        OptInPromotionalSms = false,
        OptInPromotionalEmail = false,
        EnabledTicketServicePlus = false
    };

    private readonly Currency _validCurrency = new()
    {
        Active = true,
        ShortCode = "EUR",
        Name = "Euro",
        Character = "€"
    };

    private readonly IEnumerable<string> _validBlockedEmails = new[]
    {
        "unit@test.com",
        "*@domain.tld",
        "user@*.tld"
    };

    private readonly Guid _orderId = Guid.NewGuid();

    public OrderServiceTests()
    {
        Mock<IDeploymentEnvironmentService> mockedDeploymentEnvironmentService = new();
        mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment
        {
            Id = Guid.NewGuid(),
            Name = "UnitTestEnv",
            Domain = "localhost",
            FrontendBaseUrl = "http://localhost:8080",
            IsHttps = false
        });

        var configuration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformSmsCostCents", "85" },
            { "OrganizationDetails:PlatformTicketServicePlusCostCents", "98" },
            { "OrganizationDetails:DefaultEventSealHours", "24" },
            { "PlatformName", "Fancee" }
        });

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(ReservationReference))
            .ReturnsAsync(Guid.NewGuid);

        _mockedContractService.Setup(rd => rd.ActiveOrganizationContractOnDatetimeAsync(It.IsAny<Guid>(), It.IsAny<DateTime>()))
            .ReturnsAsync(DefaultContract);

        _sut = new(
            _mockedShopDao.Object,
            _mockedOrderDao.Object,
            _mockedReservationDao.Object,
            _mockedUserDao.Object,
            _mockedOrganizationBlockedEmailDao.Object,
            mockedDeploymentEnvironmentService.Object,
            _mockedPublisher.Object,
            _mockedAuthenticationProvider.Object,
            _mockedPaymentMethodService.Object,
            _mockedPinService.Object,
            configuration,
            _mockedWebApiCoreOrderDao.Object,
            _mockedCurrencyService.Object,
            _mockedStorageService.Object,
            _mockedShopQuestionService.Object,
            _mockedGeneratePdfPublisher.Object,
            _mockedCountryService.Object,
            new[] { _mockedTrackingService.Object },
            _mockedContractService.Object,
            _mockedSeatsIoProvider.Object,
            _mockedWebApiCoreReservationDao.Object,
            _mockedDiscountService.Object,
            _mockedCombinedShopDao.Object
        );
    }

    [Fact]
    public async Task TestThatOrderReturnsPaymentUrlOnOrderWithPaidProducts()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatOrderReturnsPaymentUrlOnOrderWithPaidProductsAndBookedSeats()
    {
        _validShop.Event.Type = EventType.Seating;
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Quantity = 1,
                        Product = new()
                        {
                            Type = ProductType.SeatedTicket,
                            Event = new()
                            {
                                SeatsIoEventId = Guid.NewGuid()
                            }
                        },
                        MetaData = """{"SeatsIoObjectIds":["A-1"]}"""
                    }
                },
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedSeatsIoProvider.Setup(sip => sip.BookObjectsAsync(It.IsAny<string>(), It.IsAny<string[]>()));

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatOrderThrowsSeatedTicketIssueWithoutMetadataExceptionForBookingSeatedTicketsWithMissingMetadata()
    {
        _validShop.Event.Type = EventType.Seating;
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Quantity = 1,
                        Product = new()
                        {
                            Type = ProductType.SeatedTicket,
                            Event = new()
                            {
                                SeatsIoEventId = Guid.NewGuid()
                            }
                        },
                        MetaData = """{"UnknownKey":["A-1"]}"""
                    }
                },
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedSeatsIoProvider.Setup(sip => sip.BookObjectsAsync(It.IsAny<string>(), It.IsAny<string[]>()));

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await Assert.ThrowsAsync<SeatedTicketIssueWithoutMetadataException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatOrderTakesIntoAccountPercentualDiscountCodeOnShop()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(5000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.OrganizationId))
            .ReturnsAsync(_validBlockedEmails);

        var shopCode = "unitShopCode";

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(OrganizationId);

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountPercentual = 20,
                ApplicableDiscounts = new List<DiscountApplicableTo>
                {
                    new()
                    {
                        ShopCode = shopCode
                    }
                }
            });

        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(shopCode);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderFeeCentsAsync(_orderRequest.ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(new OrderCostBuildupResponse
            {
                PercentualTicketFeeCents = 0,
                PercentualProductFeeCents = 0,
                TicketPriceCents = 1900,
                ProductPriceCents = 0,
                StaticProductFeeCents = 0,
                StaticTicketFeeCents = 100
            });

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatOrderDoesNotApplyDiscountForCostlessOrder()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(5000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.OrganizationId))
            .ReturnsAsync(_validBlockedEmails);

        var shopCode = "unitShopCode";

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(OrganizationId);

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountPercentual = 20,
                ApplicableDiscounts = new List<DiscountApplicableTo>
                {
                    new()
                    {
                        ShopCode = shopCode
                    }
                }
            });

        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(shopCode);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderFeeCentsAsync(_orderRequest.ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(value: null);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatOrderSkipsPercentualDiscountThatDoesNotMatchShopCodeOfReservation()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(5000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.OrganizationId))
            .ReturnsAsync(_validBlockedEmails);

        var shopCode = "unitShopCode";

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(OrganizationId);

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountPercentual = 20,
                ApplicableDiscounts = new List<DiscountApplicableTo>
                {
                    new()
                    {
                        ShopCode = "OtherShopCde"
                    }
                }
            });

        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(shopCode);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatOrderTakesIntoAccountPercentualDiscountCodeOnProduct()
    {
        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(ShopCode);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(5000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.OrganizationId))
            .ReturnsAsync(_validBlockedEmails);

        var productId = Guid.NewGuid();

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(OrganizationId);

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountPercentual = 55,
                ApplicableDiscounts = new List<DiscountApplicableTo>
                {
                    new()
                    {
                        ProductId = productId
                    }
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ByReservationReferenceAndProductIdsAsync(_orderRequest.ReservationReference, new List<Guid> { productId }))
            .ReturnsAsync(new List<ReservedProduct>
            {
                new()
                {
                    Product = new()
                    {
                        PriceCents = 1000,
                        Event = new()
                        {
                            Organization = new()
                            {
                                Contract = new()
                                {
                                    TicketFeeCents = 50
                                }
                            }
                        }
                    },
                    Quantity = 2
                },
                new()
                {
                    Product = new()
                    {
                        PriceCents = null,
                        Event = new()
                        {
                            Organization = new()
                            {
                                Contract = new()
                                {
                                    TicketFeeCents = 50
                                }
                            }
                        }
                    },
                    Quantity = 1
                }
            });

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatOrderContinuesAsNormalForNoMatchingDiscountProductIdsInReservation()
    {
        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(ShopCode);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(5000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.OrganizationId))
            .ReturnsAsync(_validBlockedEmails);

        var productId = Guid.NewGuid();

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(OrganizationId);

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountStaticCents = 555,
                ApplicableDiscounts = new List<DiscountApplicableTo>
                {
                    new()
                    {
                        ProductId = productId
                    }
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ByReservationReferenceAndProductIdsAsync(_orderRequest.ReservationReference, new List<Guid> { productId }))
            .ReturnsAsync(new List<ReservedProduct>());

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatAppliedStaticDiscountCentsIsNotMoreThanProductPriceCents()
    {
        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(ShopCode);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.OrganizationId))
            .ReturnsAsync(_validBlockedEmails);

        var productId = Guid.NewGuid();

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(OrganizationId);

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountStaticCents = 555,
                ApplicableDiscounts = new List<DiscountApplicableTo>
                {
                    new()
                    {
                        ProductId = productId
                    }
                }
            });

        _mockedWebApiCoreOrderDao.Setup(wacod => wacod.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(40000);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ByReservationReferenceAndProductIdsAsync(_orderRequest.ReservationReference, new List<Guid> { productId }))
            .ReturnsAsync(new List<ReservedProduct>
            {
                new()
                {
                    Product = new()
                    {
                        PriceCents = 40000,
                        Event = new()
                        {
                            Organization = new()
                            {
                                Contract = new()
                                {
                                    TicketFeeCents = 50
                                }
                            }
                        }
                    },
                    Quantity = 2
                }
            });

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatOrderWithUnknownDiscountContinuesAsNormal()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(5000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.OrganizationId))
            .ReturnsAsync(_validBlockedEmails);

        _mockedReservationDao.Setup(rd => rd.OrganizationIdByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(OrganizationId);

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(_orderRequest.ReservationReference))
            .ReturnsAsync(value: null);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncReturnsOrderPaymentLinkWhenOrderHasAlreadyBeenPlacedButIsNotPaid()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedOrderDao.Setup(od => od.ByReservationReferenceAsync(ReservationReference))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Order
            {
                Id = Guid.NewGuid(),
                PaymentStatus = PaymentStatus.Cancelled
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                StartDate = DateTime.UtcNow,
                MinimumAge = 0
            });

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncUsesExistingFanceeUsersUserToCreateNewClient()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ReturnsAsync(Guid.NewGuid());
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event)).ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com")).ReturnsAsync(value: null);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);

        _mockedAuthenticationProvider.Verify(ap => ap.IdByEmailAsync(It.IsAny<string>()), Times.Once);
        _mockedAuthenticationProvider.Verify(ap => ap.CreateUserAsync(It.IsAny<CreateUserRequest>()), Times.Never);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncCallsTrackingServicesRegisterCheckoutAsync()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ReturnsAsync(Guid.NewGuid());
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event)).ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com")).ReturnsAsync(value: null);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/pay/{ReservationReference}", order.RedirectUrl);

        _mockedTrackingService.Verify(ts => ts.RegisterCheckoutAsync(ShopCode, ReservationReference), Times.Once);
        _mockedTrackingService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncCallsTrackingServicesRegisterPurchaseAsyncForCostlessOrder()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ReturnsAsync(Guid.NewGuid());
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event)).ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com")).ReturnsAsync(value: null);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(0);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 0
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        var order = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/postback?o={Guid.Empty}&c={Guid.Empty}", order.RedirectUrl);

        _mockedTrackingService.Verify(ts => ts.RegisterCheckoutAsync(ShopCode, ReservationReference), Times.Once);
        _mockedTrackingService.Verify(ts => ts.RegisterPurchaseAsync(ShopCode, ReservationReference), Times.Once);
        _mockedTrackingService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatOrderRedirectIsNotPaymentUrlAndIssuesProductsOnCostlessProductsOrder()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(0);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        var actual = await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        Assert.Equal($"http://localhost:8080/shop/{ShopCode}/postback?o={Guid.Empty}&c={Guid.Empty}", actual.RedirectUrl);

        _mockedPublisher.Verify(p => p.Publish(It.Is<IssueProductsMessage>(
            ipm => ipm.Origin == ProductOriginDto.PlatformShop)), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderThrowsShopNotFoundExceptionOnNonExistingShop()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatOrderThrowsShopNotActiveOnDisabledActive()
    {
        var inactiveShop = _validShop;
        inactiveShop.Active = false;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(inactiveShop);

        await Assert.ThrowsAsync<ShopNotActiveException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatOrderThrowsShopNotActiveExpiredEndDate()
    {
        var expiredShop = _validShop;
        expiredShop.EndDate = DateTime.UtcNow.AddDays(-2);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(expiredShop);

        await Assert.ThrowsAsync<ShopNotActiveException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatOrderGetsReservationFromOrderDaoReservationViaReference()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await _sut.PlaceOrderAsync(ShopCode, _orderRequest);
    }

    [Fact]
    public async Task TestThatOrderThrowsReservationNotFoundExceptionOnNonExistingReservationReference()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(new(), default))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ReservationNotFoundException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatOrderThrowsReservationExpiredExceptionOnExpiredReservationReference()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-11),
                ExpiresOn = DateTime.UtcNow.AddMinutes(-3)
            });

        await Assert.ThrowsAsync<ReservationExpiredException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatOrderCallsUserDaoGetClientAsync()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com", u => u.UserContactInfo.Address))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        _mockedUserDao.Verify(ud => ud.GetClientAsync("unittest@client.com", u => u.UserContactInfo.Address), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderCreatesNewClientOnMissingPriorClient()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(value: null);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        _mockedUserDao.Verify(ud => ud.CreateClientAsync(It.IsAny<Client>(), It.IsAny<string[]>()), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderGetsReservationCostViaOrderDao()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        _mockedWebApiCoreOrderDao.Verify(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderCallsUserDaoOrganizationCurrencyAsyncOnOrderWithCosts()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        _mockedUserDao.Verify(ud => ud.OrganizationCurrencyAsync(ReservationReference), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderThrowsEventOrganizationMissingCurrencyExceptionOnOrderWithCostButOrganizationWithoutConfiguredCurrency()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(value: null);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await Assert.ThrowsAsync<EventOrganizationMissingCurrencyException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatOrderCreatesOrderViaOrderDao()
    {
        _orderRequest.ReceiveViaSms = true;
        _orderRequest.EnabledTicketServicePlus = true;

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedReservationDao.Setup(rd => rd.TotalTicketsInReservationAsync(ReservationReference))
            .ReturnsAsync(5);

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(_validShop.Event.Organization.UserId))
            .ReturnsAsync(_validBlockedEmails);

        await _sut.PlaceOrderAsync(ShopCode, _orderRequest);

        _mockedOrderDao.Verify(od => od.CreateOrderAsync(It.IsAny<FanceeData.Models.Ticketing.Order>()), Times.Once);
    }

    [Fact]
    public async Task TestThatListPlatformOrdersAsyncCallsOrderDaoListOrdersAsync()
    {
        var request = new PaginatedRequest<OrdersRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _mockedCountryService.Setup(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(It.IsAny<IEnumerable<string>>());

        _mockedOrderDao.Setup(od => od.ListPlatformOrdersAsync(3, 3, It.IsAny<OrdersFilter>()))
            .ReturnsAsync(new PaginatedResultSet<OrderListItemResponse>
            {
                Items = new OrderListItemResponse[]
                {
                    new()
                    {
                        Id = Guid.Empty,
                        CreationDate = DateTime.UtcNow.AddHours(-2),
                        Status = PaymentStatus.Authorised,
                        EventName = "Unit event",
                        CostCents = 1000,
                        Currency = new(),
                        PspReference = null
                    },
                    new()
                    {
                        Id = Guid.Empty,
                        EventName = "Unit 2 event",
                        CreationDate = DateTime.UtcNow.AddHours(-4),
                        Status = PaymentStatus.Error,
                        Currency = new(),
                        PspReference = null
                    }
                },
                TotalItems = 2
            });

        var actual = await _sut.ListPlatformOrdersAsync(request);

        _mockedOrderDao.Verify(od => od.ListPlatformOrdersAsync(3, 3, It.IsAny<OrdersFilter>()), Times.Once);
        Assert.Equal(2, actual.TotalItems);
        Assert.IsType<OrderListItemResponse>(actual.Items.FirstOrDefault());
    }

    [Fact]
    public async Task TestThatListOrdersAsyncForClientCallsOrderDaoListOrdersAsync()
    {
        var request = new PaginatedRequest<OrdersRequestFilter>
        {
            Page = 2,
            PageSize = 3,
            Options = new()
        };

        _mockedOrderDao.Setup(od => od.ListClientOrdersAsync(UserId, 3, 3, It.IsAny<OrdersFilter>()))
            .ReturnsAsync(new PaginatedResultSet<OrderListItemResponse>
            {
                Items = new OrderListItemResponse[]
                {
                    new()
                    {
                        Id = Guid.Empty,
                        CreationDate = DateTime.UtcNow.AddHours(-2),
                        Status = PaymentStatus.Authorised,
                        EventName = "Unit event",
                        CostCents = 1000,
                        Currency = new(),
                        PspReference = null
                    },
                    new()
                    {
                        Id = Guid.Empty,
                        CreationDate = DateTime.UtcNow.AddHours(-4),
                        Status = PaymentStatus.Error,
                        EventName = "Unit 2 event",
                        CostCents = 1000,
                        Currency = new(),
                        PspReference = null
                    }
                },
                TotalItems = 2
            });

        var actual = await _sut.ListClientOrdersAsync(UserId, request);

        _mockedOrderDao.Verify(od => od.ListClientOrdersAsync(UserId, 3, 3, It.IsAny<OrdersFilter>()), Times.Once);
        Assert.Equal(2, actual.TotalItems);
        Assert.IsType<OrderListItemResponse>(actual.Items.FirstOrDefault());
    }

    [Fact]
    public async Task TestThatGetUpcomingClientEventOrdersAsyncCallsOrderDaoGetUpcomingClientEventOrdersAsync()
    {
        _mockedOrderDao.Setup(od => od.UpcomingClientEventOrdersAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<FanceeData.Models.Ticketing.Order>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    ReservationReferenceNavigation = new()
                    {
                        ReservedProducts = new List<ReservedProduct>
                        {
                            new()
                            {
                                IssuedProducts = new List<IssuedProduct>
                                {
                                    new()
                                    {
                                        IssuedTicket = new()
                                        {
                                            Code = "UNITCODEUNITCODEUNITCODE1",
                                            Holder = new()
                                            {
                                                Code = "UNITCODE",
                                                FirstName = "Unit",
                                                LastName = "Tester",
                                                Email = "unit@test.com",
                                                Gender = Gender.Female,
                                                PersonalizedOn = DateTime.UtcNow.AddDays(-1)
                                            },
                                            IssuedProduct = new()
                                            {
                                                Product = new()
                                                {
                                                    Name = "UNIT PRODUCT",
                                                    TicketOption = new()
                                                    {
                                                        PartialAccessStart = null,
                                                        PartialAccessEnd = null,
                                                        MaximumPreArrivalTimeMinutes = 60
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },
                                Product = new()
                                {
                                    Type = ProductType.Ticket,
                                    Event = new()
                                    {
                                        Name = "UNIT EVENT NAME",
                                        StartDate = DateTime.UtcNow.AddDays(2)
                                    }
                                }
                            }
                        }
                    }
                }
            });

        var actual = (await _sut.UpcomingClientEventOrdersAsync(new())).ToList();

        Assert.Single(actual);
        Assert.Equal("UNIT EVENT NAME", actual.FirstOrDefault()!.Name);
        Assert.IsType<HolderResponse>(actual.FirstOrDefault()!.Tickets.FirstOrDefault()!.Holder);
    }

    [Fact]
    public async Task TestThatDailyEventOrdersAsyncCallsOrderDaoDailyOrdersAsync()
    {
        _mockedOrderDao.Setup(od => od.DailyEventOrdersAsync(It.IsAny<Guid>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<DailyOrdersResponse>
            {
                new()
                {
                    Date = DateTime.UtcNow.AddDays(-2),
                    TotalOrders = 11,
                    CashSalesRevenueCents = 1000,
                    OnlineSalesRevenueCents = 1000
                }
            });

        var actual = await _sut.DailyEventOrdersAsync(new(), DateTime.UtcNow.AddDays(-2), DateTime.UtcNow);

        Assert.Single(actual);
        _mockedOrderDao.Verify(od => od.DailyEventOrdersAsync(It.IsAny<Guid>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDailyOrdersAsyncCallsOrderDaoDailyOrdersAsync()
    {
        _mockedOrderDao.Setup(od => od.DailyOrdersAsync(It.IsAny<Guid>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<DailyOrdersResponse>
            {
                new()
                {
                    Date = DateTime.UtcNow.AddDays(-2),
                    TotalOrders = 11,
                    CashSalesRevenueCents = 1000,
                    OnlineSalesRevenueCents = 1000
                }
            });

        var actual = await _sut.DailyOrdersAsync(new(), DateTime.UtcNow.AddDays(-2), DateTime.UtcNow);

        Assert.Single(actual);
        _mockedOrderDao.Verify(od => od.DailyOrdersAsync(It.IsAny<Guid>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatHasAccessAsyncReturnsFalseIfOrganizationIdAndUserIdAreNull()
    {
        var actual = await _sut.HasAccessAsync(Guid.Empty, null, null, UserType.Client);

        Assert.False(actual);

        _mockedUserDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatHasAccessAsyncChecksIfAdminsHasAccessToOrderIssuer()
    {
        _mockedUserDao.Setup(ud => ud.CountryCodeOfIssuerOfOrder(It.IsAny<Guid>()))
            .ReturnsAsync("NL");
        _mockedCountryService.Setup(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), null))
            .ReturnsAsync(new[] { "NL" });

        var actual = await _sut.HasAccessAsync(Guid.NewGuid(), Guid.NewGuid(), null, UserType.Admin);

        Assert.True(actual);
        _mockedUserDao.Verify(ud => ud.CountryCodeOfIssuerOfOrder(It.IsAny<Guid>()), Times.Once);
        _mockedCountryService.Verify(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), null), Times.Once);
    }

    [Fact]
    public async Task TestThatHasAccessAsyncChecksIfClientIsOwner()
    {
        _mockedUserDao.Setup(ud => ud.OwnerOfOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        var actual = await _sut.HasAccessAsync(Guid.NewGuid(), Guid.NewGuid(), null, UserType.Client);

        Assert.True(actual);
        _mockedUserDao.Verify(ud => ud.OwnerOfOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatHasAccessAsyncCallsIsOrderIssuerAsyncForOrganization()
    {
        _mockedUserDao.Setup(ud => ud.IsIssuerOfOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        var actual = await _sut.HasAccessAsync(Guid.NewGuid(), null, Guid.NewGuid(), UserType.Organization);

        Assert.True(actual);
        _mockedUserDao.Verify(ud => ud.IsIssuerOfOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Theory]
    [MemberData(nameof(InvalidOrderRetrievalUserTypes))]
    public async Task TestThatHasAccessAsyncReturnsExpectedResultForInvalidUserTypes(UserType userType, bool expectedResult)
    {
        var actual = await _sut.HasAccessAsync(Guid.NewGuid(), Guid.NewGuid(), null, userType);

        Assert.Equal(expectedResult, actual);
    }

    [Fact]
    public async Task TestThatOrderAsyncThrowsOrderNotFoundExceptionOnInvalidOrderId()
    {
        _mockedOrderDao.Setup(od => od.OrderAsync(It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<OrderNotFoundException>(async () => await _sut.OrderAsync(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatOrderAsyncCallsOrderDaoOrderAsync()
    {
        _mockedOrderDao.Setup(od => od.OrderAsync(It.IsAny<Guid>()))
            .ReturnsAsync(_retrievableOrder);

        var actual = await _sut.OrderAsync(Guid.NewGuid());

        Assert.Equal(1000, actual.CostCents);
        Assert.Equal("unit@email.com", actual.Client.Email);
        Assert.Equal("UnitEvent", actual.Event.Name);
        Assert.Equal(ProductType.Ticket, actual.Products.First().Type);
        Assert.Equal(1200, actual.Products.First().PriceCents);

        Assert.NotEmpty(actual.AnsweredQuestions);

        var answer = actual.AnsweredQuestions.First();
        Assert.Equal("Autobus", answer.Answer);
        Assert.Equal("Dus?", answer.Question);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncThrowsInvalidClientDetailsExceptionWhenRequiredShopFieldHasNotBeenSatisfied()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.LastName,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(new()))
            .ReturnsAsync(_validCurrency);

        _orderRequest.OrderClient.LastName = null;
        await Assert.ThrowsAsync<InvalidClientDetailsException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncChecksClientBirthdateAgainstEventMinimumAge()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.LastName,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(new()))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                StartDate = DateTime.UtcNow,
                MinimumAge = 18
            });

        _orderRequest.OrderClient.Birthdate = DateTime.UtcNow.AddYears(-16);
        await Assert.ThrowsAsync<ClientUnderAgedException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncThrowsEventNotFoundExceptionIfNoEventCanBeFoundViaShopCode()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.LastName,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(new()))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(value: null);

        _orderRequest.OrderClient.Birthdate = DateTime.UtcNow.AddYears(-16);
        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncWithTerminalThrowsInvalidPinTerminalExceptionOnInvalidPinTerminal()
    {
        _mockedPinService.Setup(ps => ps.ValidTerminalAsync("terminal")).ReturnsAsync(false);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event)).ReturnsAsync(_validShop);
        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code)).ReturnsAsync(Enumerable.Empty<ShopFieldRequirement>());
        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default)).ReturnsAsync(new ReservationReference
        {
            Reference = _orderRequest.ReservationReference,
            CreatedOn = DateTime.UtcNow.AddMinutes(-5),
            ExpiresOn = DateTime.UtcNow.AddMinutes(3)
        });

        await Assert.ThrowsAsync<InvalidPinTerminalException>(async () => await _sut.PlaceOrderAsync(_validShop.Code, _orderRequest, "terminal"));

        _mockedPinService.Verify(ps => ps.ValidTerminalAsync("terminal"), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event), Times.Once);
        _mockedShopDao.Verify(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code), Times.Once);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncWithTerminalThrowsInvalidPaymentMethodExceptionWhenPinMethodCouldNotBeFound()
    {
        _mockedPinService.Setup(ps => ps.ValidTerminalAsync("terminal")).ReturnsAsync(true);
        _mockedPaymentMethodService.Setup(pms => pms.PinPaymentMethodIdAsync()).ReturnsAsync(value: null);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event)).ReturnsAsync(_validShop);
        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code)).ReturnsAsync(Enumerable.Empty<ShopFieldRequirement>());
        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default)).ReturnsAsync(new ReservationReference
        {
            Reference = _orderRequest.ReservationReference,
            CreatedOn = DateTime.UtcNow.AddMinutes(-5),
            ExpiresOn = DateTime.UtcNow.AddMinutes(3)
        });

        await Assert.ThrowsAsync<InvalidPaymentMethodException>(async () => await _sut.PlaceOrderAsync(_validShop.Code, _orderRequest, "terminal"));

        _mockedPinService.Verify(ps => ps.ValidTerminalAsync("terminal"), Times.Once);
        _mockedPaymentMethodService.Verify(pms => pms.PinPaymentMethodIdAsync(), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event), Times.Once);
        _mockedShopDao.Verify(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code), Times.Once);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncWithTerminalDoesNotStartTransactionForCostlessOrderAndIssuesProducts()
    {
        var pinGuid = Guid.NewGuid();
        var fanceeUsersId = Guid.NewGuid();

        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ThrowsAsync(new());
        _mockedPinService.Setup(ps => ps.ValidTerminalAsync("terminal")).ReturnsAsync(true);
        _mockedPaymentMethodService.Setup(pms => pms.PinPaymentMethodIdAsync()).ReturnsAsync(pinGuid);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event)).ReturnsAsync(_validShop);
        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code)).ReturnsAsync(Enumerable.Empty<ShopFieldRequirement>());
        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default)).ReturnsAsync(new ReservationReference
        {
            Reference = _orderRequest.ReservationReference,
            CreatedOn = DateTime.UtcNow.AddMinutes(-5),
            ExpiresOn = DateTime.UtcNow.AddMinutes(3)
        });
        _mockedAuthenticationProvider.Setup(ap => ap.CreateUserAsync(It.IsAny<CreateUserRequest>())).ReturnsAsync(fanceeUsersId);
        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(0);
        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        var actual = await _sut.PlaceOrderAsync(_validShop.Code, _orderRequest, "terminal");

        Assert.Equal(PinTransactionResponse.Completed, actual.PinTransactionStatus);

        _mockedPinService.Verify(ps => ps.ValidTerminalAsync("terminal"), Times.Once);
        _mockedPaymentMethodService.Verify(pms => pms.PinPaymentMethodIdAsync(), Times.Once);
        _mockedPinService.VerifyNoOtherCalls();
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event), Times.Once);
        _mockedShopDao.Verify(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code), Times.Once);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default), Times.Exactly(2));
        _mockedAuthenticationProvider.Verify(ap => ap.CreateUserAsync(It.IsAny<CreateUserRequest>()), Times.Once);
        _mockedWebApiCoreOrderDao.Verify(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()), Times.Once);
        _mockedPublisher.Verify(p => p.Publish(It.IsAny<IssueProductsMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncWithTerminalStartsTransaction()
    {
        var pinGuid = Guid.NewGuid();
        var fanceeUsersId = Guid.NewGuid();

        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ThrowsAsync(new());
        _mockedPinService.Setup(ps => ps.ValidTerminalAsync("terminal")).ReturnsAsync(true);
        _mockedPaymentMethodService.Setup(pms => pms.PinPaymentMethodIdAsync()).ReturnsAsync(pinGuid);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event)).ReturnsAsync(_validShop);
        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code)).ReturnsAsync(Enumerable.Empty<ShopFieldRequirement>());
        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default)).ReturnsAsync(new ReservationReference
        {
            Reference = _orderRequest.ReservationReference,
            CreatedOn = DateTime.UtcNow.AddMinutes(-5),
            ExpiresOn = DateTime.UtcNow.AddMinutes(3)
        });
        _mockedAuthenticationProvider.Setup(ap => ap.CreateUserAsync(It.IsAny<CreateUserRequest>())).ReturnsAsync(fanceeUsersId);
        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1200);

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(_orderRequest.ReservationReference)).ReturnsAsync(new Currency { ShortCode = "EUR" });
        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, pinGuid, 0, 0, false, true, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy { PaidBy = PaidBy.Organization, AmountCents = 0 });

        var actual = await _sut.PlaceOrderAsync(_validShop.Code, _orderRequest, "terminal");

        Assert.Equal(PinTransactionResponse.SentToPinTerminal, actual.PinTransactionStatus);

        _mockedPinService.Verify(ps => ps.ValidTerminalAsync("terminal"), Times.Once);
        _mockedPaymentMethodService.Verify(pms => pms.PinPaymentMethodIdAsync(), Times.Once);
        _mockedPinService.Verify(ps => ps.StartTransaction(It.Is<StartPinTerminalTransactionMessage>(m => m.TerminalSerialNumber == "terminal" && m.ReservationReference == _orderRequest.ReservationReference)), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event), Times.Once);
        _mockedShopDao.Verify(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code), Times.Once);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default), Times.Exactly(2));
        _mockedAuthenticationProvider.Verify(ap => ap.CreateUserAsync(It.IsAny<CreateUserRequest>()), Times.Once);
        _mockedWebApiCoreOrderDao.Verify(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.OrganizationCurrencyAsync(_orderRequest.ReservationReference), Times.Once);
        _mockedWebApiCoreOrderDao.Verify(od => od.CalculatePaymentFeeAsync(ReservationReference, pinGuid, 0, 0, false, true, It.IsAny<ContractFee>()), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderAsyncWithAppTeamIdChecksIfAppTeamHasOrderAccessAsyncViaOrderDao()
    {
        var orderId = Guid.NewGuid();
        var appTeamId = Guid.NewGuid();

        _mockedOrderDao.Setup(od => od.HasOrderAccessAsync(orderId, appTeamId))
            .ReturnsAsync(true);

        _mockedOrderDao.Setup(od => od.OrderAsync(It.IsAny<Guid>()))
            .ReturnsAsync(_retrievableOrder);

        await _sut.OrderAsync(orderId, appTeamId);

        _mockedOrderDao.Verify(od => od.HasOrderAccessAsync(orderId, appTeamId), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderAsyncForAppTeamThrowsUnauthorizedAppTeamExceptionIfAppTeamHasNoAccess()
    {
        _mockedOrderDao.Setup(od => od.HasOrderAccessAsync(Guid.NewGuid(), Guid.NewGuid()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<UnauthorizedAppTeamException>(async () => await _sut.OrderAsync(Guid.NewGuid(), Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatPlaceCashOrderAsyncThrowsInvalidPaymentMethodExceptionIfCashIsMissingInDatabase()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event)).ReturnsAsync(_validShop);
        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code)).ReturnsAsync(Enumerable.Empty<ShopFieldRequirement>());
        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default)).ReturnsAsync(new ReservationReference
        {
            Reference = _orderRequest.ReservationReference,
            CreatedOn = DateTime.UtcNow.AddMinutes(-5),
            ExpiresOn = DateTime.UtcNow.AddMinutes(3)
        });

        await Assert.ThrowsAsync<InvalidPaymentMethodException>(async () => await _sut.PlaceCashOrderAsync(_validShop.Code, _orderRequest));

        _mockedPaymentMethodService.Verify(pms => pms.CashPaymentMethodIdAsync(), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event), Times.Once);
        _mockedShopDao.Verify(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code), Times.Once);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceCashOrderAsyncIssuesProducts()
    {
        var fanceeUsersId = Guid.NewGuid();
        var cashGuid = Guid.NewGuid();

        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ThrowsAsync(new());
        _mockedPaymentMethodService.Setup(pms => pms.CashPaymentMethodIdAsync()).ReturnsAsync(cashGuid);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event)).ReturnsAsync(_validShop);
        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code)).ReturnsAsync(Enumerable.Empty<ShopFieldRequirement>());
        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default)).ReturnsAsync(new ReservationReference
        {
            Reference = _orderRequest.ReservationReference,
            CreatedOn = DateTime.UtcNow.AddMinutes(-5),
            ExpiresOn = DateTime.UtcNow.AddMinutes(3)
        });
        _mockedAuthenticationProvider.Setup(ap => ap.CreateUserAsync(It.IsAny<CreateUserRequest>())).ReturnsAsync(fanceeUsersId);
        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(1200);
        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(_orderRequest.ReservationReference)).ReturnsAsync(new Currency { ShortCode = "EUR" });

        var actual = await _sut.PlaceCashOrderAsync(_validShop.Code, _orderRequest);

        Assert.Equal(Guid.Empty, actual.OrderId);

        _mockedPaymentMethodService.Verify(pms => pms.CashPaymentMethodIdAsync(), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(_validShop.Code, s => s.Event), Times.Once);
        _mockedShopDao.Verify(sd => sd.RequiredShopFieldRequirementsByCodeAsync(_validShop.Code), Times.Once);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(_orderRequest.ReservationReference, default), Times.Exactly(2));
        _mockedAuthenticationProvider.Verify(ap => ap.CreateUserAsync(It.IsAny<CreateUserRequest>()), Times.Once);
        _mockedWebApiCoreOrderDao.Verify(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.OrganizationCurrencyAsync(_orderRequest.ReservationReference), Times.Once);
    }

    [Fact]
    public async Task TestThatListOrganizationOrdersAsyncCallsOrderDaoListOrganizationOrdersAsync()
    {
        _mockedOrderDao.Setup(od => od.ListOrganizationOrdersAsync(UserId, 10, 0, It.IsAny<OrdersFilter>()))
            .ReturnsAsync(new PaginatedResultSet<OrderListItemResponse>
            {
                Items = new List<OrderListItemResponse>
                {
                    new()
                    {
                        Id = Guid.Empty,
                        EventName = "YeetEvent",
                        Currency = new(),
                        Status = PaymentStatus.Authorised,
                        CostCents = 1000,
                        CreationDate = DateTime.UtcNow.AddDays(-2),
                        PspReference = null
                    }
                },
                TotalItems = 20
            });

        var request = new PaginatedRequest<OrdersRequestFilter>
        {
            Page = 1,
            PageSize = 10,
            Options = new()
        };

        var actual = await _sut.ListOrganizationOrdersAsync(UserId, request);

        Assert.Equal(20, actual.TotalItems);
        Assert.Equal("YeetEvent", actual.Items.First().EventName);

        _mockedOrderDao.Verify(od => od.ListOrganizationOrdersAsync(UserId, 10, 0, It.IsAny<OrdersFilter>()), Times.Once);
    }

    [Fact]
    public async Task TestThatOrganizationOrdersCsvAsyncCallsOrderDaoOrganizationOrderExportItemsAsyncAndConvertsRecordsToCsv()
    {
        _mockedOrderDao.Setup(od => od.OrganizationOrderExportItemsAsync(UserId, It.IsAny<OrdersFilter>()))
            .ReturnsAsync(new List<OrderExportItemResponse>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Email = "Unit@test.eu"
                }
            });

        var actual = await _sut.OrganizationOrdersCsvAsync(UserId, new()
        {
            SearchQuery = null
        });

        _mockedOrderDao.Verify(od => od.OrganizationOrderExportItemsAsync(UserId, It.IsAny<OrdersFilter>()), Times.Once);

        Assert.NotEmpty(actual.FileContents);
    }

    [Fact]
    public async Task TestThatOrganizationOrdersCsvAsyncExportsShopQuestionAnswers()
    {
        _mockedOrderDao.Setup(od => od.OrganizationOrderExportItemsAsync(UserId, It.IsAny<OrdersFilter>()))
            .ReturnsAsync(new List<OrderExportItemResponse>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Email = "Unit@test.eu",
                    ShopQuestionAnswers = new()
                    {
                        { "Question #1?", "Answer #1" }
                    }
                },
                new()
                {
                    Id = Guid.NewGuid(),
                    Email = "Unit@test.eu",
                    ShopQuestionAnswers = new()
                    {
                        { "Question #2?", "Answer #2" }
                    }
                }
            });

        var actual = await _sut.OrganizationOrdersCsvAsync(UserId, new()
        {
            SearchQuery = null
        });

        Assert.NotEmpty(actual.FileContents);

        using var memStream = new MemoryStream(actual.FileContents);
        using var reader = new StreamReader(memStream);

        var fileContentString = await reader.ReadToEndAsync();

        Assert.Contains("Question #1?", fileContentString);
        Assert.Contains("Question #2?", fileContentString);
        Assert.Contains("Answer #1", fileContentString);
        Assert.Contains("Answer #2", fileContentString);
    }

    [Fact]
    public async Task TestThatRequestMatchesDownloadableOrderTicketPdfCriteriaAsyncCallsOrderDaoRequestMatchesDownloadableOrderTicketPdfCriteriaAsync()
    {
        _mockedOrderDao.Setup(od => od.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        var actual = await _sut.ClientBelongsToOrderAsync(Guid.NewGuid(), Guid.NewGuid());

        Assert.False(actual);
        _mockedOrderDao.Verify(od => od.ClientBelongsToOrderAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadTicketPdfAsyncThrowsOrderTicketsPdfNotFoundExceptionOnNonExistingOrderFile()
    {
        _mockedOrderDao.Setup(od => od.OrderTicketsFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<OrderTicketsPdfNotFoundException>(async () => await _sut.DownloadTicketPdfAsync(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatDownloadTicketPdfAsyncThrowsOrderTicketsPdfNotFoundExceptionOnFaultDuringStorageServiceDownloadFileAsync()
    {
        _mockedOrderDao.Setup(od => od.OrderTicketsFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new File());

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.TicketPdfStoragePool, It.IsAny<string>()))
            .ThrowsAsync(new("Something internal broke"));

        await Assert.ThrowsAsync<OrderTicketsPdfNotFoundException>(async () => await _sut.DownloadTicketPdfAsync(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatDownloadTicketPdfAsyncCallsStorageServiceAndServesFileStream()
    {
        _mockedOrderDao.Setup(od => od.OrderTicketsFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new File());

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.TicketPdfStoragePool, It.IsAny<string>()))
            .ReturnsAsync(new MemoryStream());

        var actual = await _sut.DownloadTicketPdfAsync(Guid.NewGuid());

        Assert.Equal(0, actual.Length);

        _mockedOrderDao.Verify(od => od.OrderTicketsFileAsync(It.IsAny<Guid>()), Times.Once);
        _mockedStorageService.Verify(ss => ss.DownloadFileAsync(IStorageService.TicketPdfStoragePool, It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatPlatformOrdersAsCsvAsyncCallsOrderDaoPlatformOrderExportItemsAsyncAndConvertsToCsv()
    {
        _mockedOrderDao.Setup(od => od.PlatformOrderExportItemsAsync(It.IsAny<OrdersFilter>()))
            .ReturnsAsync(new List<OrderExportItemResponse>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Email = "Unit@test.eu"
                }
            });

        var actual = await _sut.PlatformOrdersAsCsvAsync(new());

        _mockedOrderDao.Verify(od => od.PlatformOrderExportItemsAsync(It.IsAny<OrdersFilter>()), Times.Once);
        Assert.NotEmpty(actual.FileContents);
    }

    [Fact]
    public async Task TestThatClientOrdersAsCsvAsyncCallsOrderDaoClientOrderExportItemsAsyncAndConvertsToCsv()
    {
        _mockedOrderDao.Setup(od => od.ClientOrderExportItemsAsync(It.IsAny<Guid>(), It.IsAny<OrdersFilter>()))
            .ReturnsAsync(new List<OrderExportItemResponse>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Email = "Unit@test.eu"
                }
            });

        var actual = await _sut.ClientOrdersAsCsvAsync(Guid.NewGuid(), new());

        _mockedOrderDao.Verify(od => od.ClientOrderExportItemsAsync(It.IsAny<Guid>(), It.IsAny<OrdersFilter>()), Times.Once);
        Assert.NotEmpty(actual.FileContents);
    }

    [Fact]
    public async Task TestThatOrderHasTicketsFileAsyncCallsOrderDaoOrderHasTicketsFileAsync()
    {
        _mockedOrderDao.Setup(od => od.OrderHasTicketsFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        var actual = await _sut.OrderHasTicketsFileAsync(Guid.NewGuid());

        Assert.True(actual);
        _mockedOrderDao.Verify(od => od.OrderHasTicketsFileAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatTotalOrderCostAsyncCallsUserDaoOrganizationCurrencyAsync()
    {
        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                CreatedOn = DateTime.UtcNow.AddMinutes(-30)
            });

        await _sut.TotalOrderCostAsync(ReservationReference, PaymentMethodId, false, false);

        _mockedUserDao.Verify(ud => ud.OrganizationCurrencyAsync(It.IsAny<Guid>()), Times.Once());
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, default), Times.Once);
    }

    [Fact]
    public async Task TestThatTotalOrderCostAsyncRetrievesTotalOrderCost()
    {
        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                CreatedOn = DateTime.UtcNow.AddMinutes(-30)
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderFeeCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(new OrderCostBuildupResponse
            {
                TicketPriceCents = ValidProduct.PriceCents ?? 0,
                ProductPriceCents = 0,
                StaticTicketFeeCents = ValidEvent.Organization.Contract.TicketFeeCents,
                StaticProductFeeCents = 0,
                PercentualProductFeeCents = 0,
                PercentualTicketFeeCents = 0
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        var actual = await _sut.TotalOrderCostAsync(ReservationReference, PaymentMethodId, false, false);

        Assert.Equal(1255, actual.TotalOrderCostCents);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, default), Times.Once);
    }

    [Fact]
    public async Task TestThatTotalOrderCostAsyncThrowsReservationExpiredException()
    {
        var invalidReservationId = Guid.NewGuid();
        _mockedReservationDao.Setup(rd => rd.ExistsAsync(invalidReservationId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<ReservationExpiredException>(() => _sut.TotalOrderCostAsync(invalidReservationId, PaymentMethodId, false, false));
    }

    [Fact]
    public async Task TestThatTotalOrderCostUsesCustomProductFeeForCalculation()
    {
        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                CreatedOn = DateTime.UtcNow.AddMinutes(-30)
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync((ValidProduct.PriceCents ?? 0) + ValidEvent.Organization.Contract.TicketFeeCents);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderFeeCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(new OrderCostBuildupResponse
            {
                TicketPriceCents = ValidProduct.PriceCents ?? 0,
                ProductPriceCents = 0,
                StaticTicketFeeCents = ValidEvent.Organization.Contract.TicketFeeCents,
                StaticProductFeeCents = 0,
                PercentualProductFeeCents = 0,
                PercentualTicketFeeCents = 0
            });

        var discount = new Discount
        {
            AmountPercentual = 5,
            AmountStaticCents = 120,
            ApplicableDiscounts = new List<DiscountApplicableTo> { new() { ProductId = MockedProductIds[0] } }
        };

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(ReservationReference))
            .ReturnsAsync(discount);

        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(ReservationReference)).ReturnsAsync(ShopCode);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ByReservationReferenceAndProductIdsAsync(ReservationReference, new List<Guid> { MockedProductIds[0] }))
            .ReturnsAsync(ValidReservedProductsWithCustomFee);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        var actual = await _sut.TotalOrderCostAsync(ReservationReference, PaymentMethodId, false, false);

        Assert.Equal(1255, actual.TotalOrderCostCents);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, default), Times.Once);
    }

    [Fact]
    public async Task TestThatTotalOrderCostCalculatesStaticAndPercentualDiscountForShop()
    {
        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                CreatedOn = DateTime.UtcNow.AddMinutes(-30)
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync((ValidProduct.PriceCents ?? 0) + ValidEvent.Organization.Contract.TicketFeeCents);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderFeeCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(new OrderCostBuildupResponse
            {
                TicketPriceCents = ValidProduct.PriceCents ?? 0,
                ProductPriceCents = 0,
                StaticTicketFeeCents = ValidEvent.Organization.Contract.TicketFeeCents,
                StaticProductFeeCents = 0,
                PercentualProductFeeCents = 0,
                PercentualTicketFeeCents = 0
            });

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountPercentual = 2,
                AmountStaticCents = 120,
                ApplicableDiscounts = new List<DiscountApplicableTo> { new() { ShopCode = ShopCode } }
            });

        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(ReservationReference)).ReturnsAsync(ShopCode);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ByReservationReferenceAndProductIdsAsync(ReservationReference, It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync(Array.Empty<ReservedProduct>());

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedDiscountService.Setup(ds => ds.CalculateValueCentsAsync(It.IsAny<Guid>(), It.IsAny<Discount>(), It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(new DiscountResponse
            {
                TotalDiscountCents = 142,
                ShopDiscountCents = 142,
                ProductDiscounts = []
            });

        var actual = await _sut.TotalOrderCostAsync(ReservationReference, PaymentMethodId, false, false);

        Assert.Equal(1113, actual.TotalOrderCostCents);
        Assert.Equal(142, actual.Discount?.TotalDiscountCents);

        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, default), Times.Once);
        _mockedDiscountService.Verify(ds => ds.CalculateValueCentsAsync(It.IsAny<Guid>(), It.IsAny<Discount>(), It.IsAny<string>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatTotalOrderCostCalculatesStaticAndPercentualDiscountForProducts()
    {
        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                CreatedOn = DateTime.UtcNow.AddMinutes(-30)
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync((ValidProduct.PriceCents ?? 0) + ValidEvent.Organization.Contract.TicketFeeCents);

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderFeeCentsAsync(ReservationReference, It.IsAny<ContractFee>()))
            .ReturnsAsync(new OrderCostBuildupResponse
            {
                TicketPriceCents = ValidProduct.PriceCents ?? 0,
                ProductPriceCents = 0,
                StaticTicketFeeCents = ValidEvent.Organization.Contract.TicketFeeCents,
                StaticProductFeeCents = 0,
                PercentualProductFeeCents = 0,
                PercentualTicketFeeCents = 0
            });

        _mockedDiscountService.Setup(dd => dd.ByReservationReferenceAsync(ReservationReference))
            .ReturnsAsync(new Discount
            {
                AmountPercentual = 5,
                AmountStaticCents = 120,
                ApplicableDiscounts = new List<DiscountApplicableTo> { new() { ProductId = MockedProductIds[0] } }
            });

        _mockedReservationDao.Setup(rd => rd.ShopCodeByReservationReferenceAsync(ReservationReference)).ReturnsAsync(ShopCode);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ByReservationReferenceAndProductIdsAsync(ReservationReference, new List<Guid> { MockedProductIds[0] }))
            .ReturnsAsync(ValidReservedProducts);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(ReservationReference, PaymentMethodId, 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Client,
                AmountCents = 50
            });

        var actual = await _sut.TotalOrderCostAsync(ReservationReference, PaymentMethodId, false, false);

        Assert.Equal(1305, actual.TotalOrderCostCents);
        _mockedWebApiCoreReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, default), Times.Once);
    }

    [Fact]
    public async Task TestThatResendOrderAsyncThrowsOrderNotFoundExceptionForUnknownOrder()
    {
        _mockedOrderDao.Setup(od => od.OrderAsync(It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<OrderNotFoundException>(async () => await _sut.ResendOrderAsync(Guid.NewGuid()));

        _mockedOrderDao.Verify(od => od.OrderAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatResendOrderAsyncThrowsOrderNotPaidExceptionForResendOnOrderThatIsNotPaid()
    {
        _mockedOrderDao.Setup(od => od.OrderAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Order
            {
                PaymentStatus = PaymentStatus.Refund
            });

        await Assert.ThrowsAsync<OrderNotPaidException>(async () => await _sut.ResendOrderAsync(Guid.NewGuid()));

        _mockedOrderDao.Verify(od => od.OrderAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatResendOrderAsyncCallsPdfMessagePublisherPublishToRegenerateAndSendOrder()
    {
        var orderId = Guid.NewGuid();
        _mockedOrderDao.Setup(od => od.OrderAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Order
            {
                PaymentStatus = PaymentStatus.Authorised
            });

        await _sut.ResendOrderAsync(orderId);

        _mockedOrderDao.Verify(od => od.OrderAsync(It.IsAny<Guid>()), Times.Once);
        _mockedGeneratePdfPublisher.Verify(gpp => gpp.Publish(It.IsAny<GenerateOrderTicketPdfMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExplicitResendOrderAsyncCallsPdfMessagePublisherPublishToRegenerateAndSendOrder()
    {
        var orderId = Guid.NewGuid();
        _mockedOrderDao.Setup(od => od.OrderAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Order
            {
                PaymentStatus = PaymentStatus.Authorised
            });

        await _sut.ResendOrderAsync(orderId, "test@abc.com");

        _mockedOrderDao.Verify(od => od.OrderAsync(It.IsAny<Guid>()), Times.Once);
        _mockedGeneratePdfPublisher.Verify(gpp => gpp.Publish(It.Is<GenerateOrderTicketPdfMessage>(gom => gom.ExplicitEmail == "test@abc.com")), Times.Once);
    }

    [Theory]
    [InlineData("unit@test.com")]
    [InlineData("test@domain.tld")]
    [InlineData("user@test.tld")]
    public async Task TestThatPlaceOrderAsyncThrowsClientBlockedExceptionUsingAnExistingBlockedEmail(string email)
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(_validBlockedEmails);

        _orderRequest.OrderClient.Email = email;

        await Assert.ThrowsAsync<ClientBlockedException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));

        _mockedOrganizationBlockedEmailDao.Verify(obe => obe.BlockedEmailsAsync(It.IsAny<Guid>()), Times.Once());
        _mockedReservationDao.Verify(rd => rd.UpdateReservationsAsync(It.IsAny<IList<ReservationReference>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncThrowsEventNotFoundExceptionForAShopWithoutValidEvent()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode,
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(default(FanceeData.Models.Ticketing.Event));

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncThrowsOrderOnBusinessAccountExceptionIfExistingUserIsAdmin()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ReturnsAsync(Guid.NewGuid());
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event)).ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com", u => u.UserContactInfo.Address))
            .ReturnsAsync(new User { Type = UserType.Admin });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        await Assert.ThrowsAsync<OrderOnBusinessAccountException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));

        _mockedUserDao.Verify(ud => ud.GetClientAsync("unittest@client.com", u => u.UserContactInfo.Address), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceOrderAsyncThrowsThrowsOrderOnBusinessAccountExceptionIfExistingUserIsOrganization()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.IdByEmailAsync(It.IsAny<string>())).ReturnsAsync(Guid.NewGuid());
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode, s => s.Event)).ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(ShopCode))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                },
                new()
                {
                    Field = ShopField.Birthdate,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com", u => u.UserContactInfo.Address))
            .ReturnsAsync(new User { Type = UserType.Organization });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(ReservationReference))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(ShopCode))
            .ReturnsAsync(_validShop.Event);

        await Assert.ThrowsAsync<OrderOnBusinessAccountException>(async () => await _sut.PlaceOrderAsync(ShopCode, _orderRequest));

        _mockedUserDao.Verify(ud => ud.GetClientAsync("unittest@client.com", u => u.UserContactInfo.Address), Times.Once);
    }

    [Fact]
    public async Task TestThatRegenerateAndDownloadTicketPdfAsyncPublishMessage()
    {
        await _sut.RegenerateAndDownloadTicketPdfAsync(Guid.NewGuid());

        _mockedGeneratePdfPublisher.Verify(gpp => gpp.Publish(It.IsAny<GenerateOrderTicketPdfMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRegenerateAndDownloadTicketPdfAsyncPublishesMessageAndCallsDownloadFileAsync()
    {
        var order = new FanceeData.Models.Ticketing.Order
        {
            ClientOrder = new()
            {
                ClientId = default
            },
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            Event = new()
                            {
                                IsSealed = false,
                                StartDate = DateTime.UtcNow.AddMonths(1)
                            }
                        }
                    }
                }
            }
        };
        _mockedOrderDao.Setup(od => od.RetrieveOrderForTicketRegenerationAsync(It.IsAny<string>(), It.IsAny<DateTime>()))
            .ReturnsAsync(order);

        await _sut.RegenerateAndDownloadTicketPdfAsync(It.IsAny<string>(), It.IsAny<DateTime>());

        _mockedOrderDao.Verify(od => od.RetrieveOrderForTicketRegenerationAsync(It.IsAny<string>(), It.IsAny<DateTime>()), Times.Once);
        _mockedGeneratePdfPublisher.Verify(gpp => gpp.Publish(It.IsAny<GenerateOrderTicketPdfMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRegenerateAndDownloadTicketPdfAsyncThrowsOrderNotFoundException()
    {
        FanceeData.Models.Ticketing.Order? order = null;
        _mockedOrderDao.Setup(od => od.RetrieveOrderForTicketRegenerationAsync(It.IsAny<string>(), It.IsAny<DateTime>()))
            .ReturnsAsync(order);

        await Assert.ThrowsAsync<OrderNotFoundException>(() => _sut.RegenerateAndDownloadTicketPdfAsync(It.IsAny<string>(), It.IsAny<DateTime>()));

        _mockedOrderDao.Verify(od => od.RetrieveOrderForTicketRegenerationAsync(It.IsAny<string>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRegenerateAndDownloadTicketPdfAsyncThrowsOrderIsSealedExceptionForSealedEvent()
    {
        var order = new FanceeData.Models.Ticketing.Order
        {
            ClientOrder = new()
            {
                ClientId = default
            },
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            Event = new()
                            {
                                IsSealed = true,
                                StartDate = DateTime.UtcNow.AddMonths(1)
                            }
                        }
                    }
                }
            }
        };

        _mockedOrderDao.Setup(od => od.RetrieveOrderForTicketRegenerationAsync(It.IsAny<string>(), It.IsAny<DateTime>()))
            .ReturnsAsync(order);

        await Assert.ThrowsAsync<OrderIsSealedException>(() => _sut.RegenerateAndDownloadTicketPdfAsync(It.IsAny<string>(), It.IsAny<DateTime>()));

        _mockedOrderDao.Verify(od => od.RetrieveOrderForTicketRegenerationAsync(It.IsAny<string>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatHasReceiptAsyncCallsExistsAsync()
    {
        _mockedOrderDao.Setup(od => od.ExistsAsync(_orderId))
            .ReturnsAsync(true);

        await _sut.ExistsAsync(_orderId);

        _mockedOrderDao.Verify(od => od.ExistsAsync(_orderId), Times.Once);
    }

    [Fact]
    public async Task TestThatHasReceiptAsyncCallsHasReceiptAsync()
    {
        _mockedOrderDao.Setup(od => od.HasReceiptAsync(_orderId))
            .ReturnsAsync(true);

        await _sut.HasReceiptAsync(_orderId);

        _mockedOrderDao.Verify(od => od.HasReceiptAsync(_orderId), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadReceiptPdfAsyncCallsMethods()
    {
        var file = new File
        {
            Name = "name"
        };

        _mockedOrderDao.Setup(od => od.OrderReceiptsFileAsync(_orderId))
            .ReturnsAsync(file);

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.OrderReceiptPdfStoragePool, $"{file.Name}.pdf"))
            .ReturnsAsync(new MemoryStream());

        var actual = await _sut.DownloadReceiptPdfAsync(_orderId);

        Assert.IsAssignableFrom<Stream>(actual);

        _mockedOrderDao.Verify(od => od.OrderReceiptsFileAsync(_orderId), Times.Once);
        _mockedStorageService.Verify(ss => ss.DownloadFileAsync(IStorageService.OrderReceiptPdfStoragePool, $"{file.Name}.pdf"), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadReceiptPdfAsyncThrowsOrderReceiptNotFoundException()
    {
        _mockedOrderDao.Setup(od => od.OrderReceiptsFileAsync(_orderId))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<OrderReceiptNotFoundException>(() => _sut.DownloadReceiptPdfAsync(_orderId));

        _mockedOrderDao.Verify(od => od.OrderReceiptsFileAsync(_orderId), Times.Once);
        _mockedStorageService.Verify(ss => ss.DownloadFileAsync(IStorageService.OrderReceiptPdfStoragePool, It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task TestThatDownloadReceiptPdfAsyncThrowsOrderReceiptNotFoundExceptionWhenDownloading()
    {
        var file = new File
        {
            Name = "name"
        };

        _mockedOrderDao.Setup(od => od.OrderReceiptsFileAsync(_orderId))
            .ReturnsAsync(file);

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.OrderReceiptPdfStoragePool, It.IsAny<string>()))
            .Throws(() => new NullReferenceException());

        await Assert.ThrowsAsync<OrderReceiptNotFoundException>(() => _sut.DownloadReceiptPdfAsync(_orderId));

        _mockedOrderDao.Verify(od => od.OrderReceiptsFileAsync(_orderId), Times.Once);
        _mockedStorageService.Verify(ss => ss.DownloadFileAsync(IStorageService.OrderReceiptPdfStoragePool, It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public void TestThatGenerateReceiptAsyncCallsPublisher()
    {
        _sut.GenerateReceiptAsync(_orderId);

        _mockedGeneratePdfPublisher.Verify(gpp => gpp.Publish(It.IsAny<IGeneratePdfMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatIsOrderOfSealedEventOrWithinSealtimeAsyncCallsOrderDaoIsOrderOfSealedEventOrWithinSealtimeAsyncWithDefaultEventSealHours()
    {
        _mockedOrderDao.Setup(od => od.IsOrderOfSealedEventOrWithinSealtimeAsync(It.IsAny<Guid>(), 24))
            .ReturnsAsync(true);

        var actual = await _sut.IsOrderOfSealedEventOrWithinSealtimeAsync(Guid.NewGuid());

        Assert.True(actual);

        _mockedOrderDao.Verify(od => od.IsOrderOfSealedEventOrWithinSealtimeAsync(It.IsAny<Guid>(), 24), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceCombinedOrderAsyncThrowsCombinedShopNotFoundExceptionIfCombinedShopDaoByCodeAsyncReturnNull()
    {
        _mockedCombinedShopDao.Setup(cs => cs.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<CombinedShopNotFoundException>(() => _sut.PlaceCombinedOrderAsync("UnitCombiCode", new()
        {
            ReservationReferences = new List<Guid>(),
            OrderClient = new()
        }));

        _mockedCombinedShopDao.Verify(cs => cs.ByCodeAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceCombinedOrderAsyncValidatedCombinedShopShopAndThrowsShopNotFoundExceptionIfSubShopIsNotFound()
    {
        _mockedCombinedShopDao.Setup(cs => cs.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(new CombinedShop()
            {
                ShopsInCombinedShop = new List<ShopInCombinedShop>
                {
                    new()
                    {
                        ShopCode = "UnitSubShop1"
                    }
                }
            });

        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitSubShop1", s => s.Event))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(() => _sut.PlaceCombinedOrderAsync("UnitCombiCode", new()
        {
            ReservationReferences = new List<Guid>(),
            OrderClient = new()
        }));

        _mockedCombinedShopDao.Verify(cs => cs.ByCodeAsync(It.IsAny<string>()), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync("UnitSubShop1", s => s.Event), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceCombinedOrderAsyncValidatedCombinedShopShopAndThrowsShopNotActiveExceptionIfSubShopIsNotActive()
    {
        _mockedCombinedShopDao.Setup(cs => cs.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(new CombinedShop()
            {
                ShopsInCombinedShop = new List<ShopInCombinedShop>
                {
                    new()
                    {
                        ShopCode = "UnitSubShop1"
                    }
                }
            });

        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitSubShop1", s => s.Event))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop()
            {
                Active = false,
                EndDate = DateTime.UtcNow.AddDays(10)
            });

        await Assert.ThrowsAsync<ShopNotActiveException>(() => _sut.PlaceCombinedOrderAsync("UnitCombiCode", new()
        {
            ReservationReferences = new List<Guid>(),
            OrderClient = new()
        }));

        _mockedCombinedShopDao.Verify(cs => cs.ByCodeAsync(It.IsAny<string>()), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync("UnitSubShop1", s => s.Event), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceCombinedOrderAsyncValidatedCombinedShopShopAndThrowsShopNotActiveExceptionIfSubShopEndDateIsPassed()
    {
        _mockedCombinedShopDao.Setup(cs => cs.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(new CombinedShop()
            {
                ShopsInCombinedShop = new List<ShopInCombinedShop>
                {
                    new()
                    {
                        ShopCode = "UnitSubShop1"
                    }
                }
            });

        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitSubShop1", s => s.Event))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop()
            {
                Active = true,
                EndDate = DateTime.UtcNow.AddDays(-1)
            });

        await Assert.ThrowsAsync<ShopNotActiveException>(() => _sut.PlaceCombinedOrderAsync("UnitCombiCode", new()
        {
            ReservationReferences = new List<Guid>(),
            OrderClient = new()
        }));

        _mockedCombinedShopDao.Verify(cs => cs.ByCodeAsync(It.IsAny<string>()), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync("UnitSubShop1", s => s.Event), Times.Once);
    }

    [Fact]
    public async Task TestThatPlaceCombinedOrderAsyncInsertsOrderPerReservationReference()
    {
        _mockedCombinedShopDao.Setup(cs => cs.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(new CombinedShop()
            {
                ShopsInCombinedShop = new List<ShopInCombinedShop>
                {
                    new()
                    {
                        ShopCode = "UnitSubShop1"
                    },
                    new()
                    {
                        ShopCode = "UnitSubShop2"
                    },
                    new()
                    {
                        ShopCode = "UnitSubShop3"
                    }
                }
            });

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(It.IsAny<string>(),
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(It.IsAny<Guid>(), default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(It.IsAny<Guid>(), It.IsAny<ContractFee>()))
            .ReturnsAsync(1000);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(It.IsAny<Guid>()))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(_validBlockedEmails);

        var combiOrderRequest = new CombinedOrderRequest
        {
            ReservationReferences = [Guid.NewGuid(), Guid.NewGuid()],
            OrderClient = new()
            {
                Email = "unit@combi.mail"
            },
            PaymentMethodId = Guid.NewGuid(),
            ReceiveViaSms = false,
            OptInPromotionalEmail = false,
            OptInPromotionalSms = false,
            EnabledTicketServicePlus = false
        };

        var actual = await _sut.PlaceCombinedOrderAsync("UnitCombiCode", combiOrderRequest);

        Assert.IsType<CombinedOrderCompleteResponse>(actual);
        Assert.Equal("http://localhost:8080/shop/combined/UnitCombiCode/pay/MDAwMDAwMDAtMDAwMC0wMDAwLTAwMDAtMDAwMDAwMDAwMDAwLDAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMA==", actual.RedirectUrl);
    }

    [Fact]
    public async Task TestThatPlaceCombinedOrderAsyncReturnsRedirectUrlIfOrdersAreAllCostless()
    {
        _mockedCombinedShopDao.Setup(cs => cs.ByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(new CombinedShop()
            {
                ShopsInCombinedShop = new List<ShopInCombinedShop>
                {
                    new()
                    {
                        ShopCode = "UnitSubShop1"
                    },
                    new()
                    {
                        ShopCode = "UnitSubShop2"
                    },
                    new()
                    {
                        ShopCode = "UnitSubShop3"
                    }
                }
            });

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(It.IsAny<string>(),
                s => s.Event))
            .ReturnsAsync(_validShop);

        _mockedShopDao.Setup(sd => sd.RequiredShopFieldRequirementsByCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                }
            });

        _mockedWebApiCoreReservationDao.Setup(rd => rd.ReservationAsync(It.IsAny<Guid>(), default))
            .ReturnsAsync(new ReservationReference
            {
                Reference = ReservationReference,
                CreatedOn = DateTime.UtcNow.AddMinutes(-5),
                ExpiresOn = DateTime.UtcNow.AddMinutes(3)
            });

        _mockedUserDao.Setup(ud => ud.GetClientAsync("unittest@client.com"))
            .ReturnsAsync(new User
            {
                Id = UserId,
                Email = "unittest@client.com",
                Client = new() { UserId = UserId }
            });

        _mockedWebApiCoreOrderDao.Setup(od => od.OrderCostCentsAsync(It.IsAny<Guid>(), It.IsAny<ContractFee>()))
            .ReturnsAsync(0);

        _mockedWebApiCoreOrderDao.Setup(od => od.CalculatePaymentFeeAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), 0, 0, false, false, It.IsAny<ContractFee>()))
            .ReturnsAsync(new PaymentPaidBy
            {
                PaidBy = PaidBy.Organization,
                AmountCents = 50
            });

        _mockedUserDao.Setup(ud => ud.OrganizationCurrencyAsync(It.IsAny<Guid>()))
            .ReturnsAsync(_validCurrency);

        _mockedShopDao.Setup(s => s.EventByShopCodeAsync(It.IsAny<string>()))
            .ReturnsAsync(_validShop.Event);

        _mockedOrganizationBlockedEmailDao.Setup(obe => obe.BlockedEmailsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(_validBlockedEmails);

        var combiOrderRequest = new CombinedOrderRequest
        {
            ReservationReferences = [Guid.NewGuid(), Guid.NewGuid()],
            OrderClient = new()
            {
                Email = "unit@combi.mail"
            },
            PaymentMethodId = Guid.NewGuid(),
            ReceiveViaSms = false,
            OptInPromotionalEmail = false,
            OptInPromotionalSms = false,
            EnabledTicketServicePlus = false
        };

        var actual = await _sut.PlaceCombinedOrderAsync("UnitCombiCode", combiOrderRequest);

        Assert.IsType<CombinedOrderCompleteResponse>(actual);
        Assert.Equal("http://localhost:8080/shop/combined/UnitCombiCode/postback?o=00000000-0000-0000-0000-000000000000,00000000-0000-0000-0000-000000000000&c=00000000-0000-0000-0000-000000000000", actual.RedirectUrl);
    }
}