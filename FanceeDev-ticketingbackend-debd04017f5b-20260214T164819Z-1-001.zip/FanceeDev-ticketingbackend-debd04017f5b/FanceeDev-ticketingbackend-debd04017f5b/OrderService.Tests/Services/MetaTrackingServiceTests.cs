using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Fs.PixelTracking.Configuration;
using Fs.PixelTracking.Meta;
using Fs.PixelTracking.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Query;
using OrderService.Persistence.Shop;
using OrderService.Services;
using WebApiCore.Persistence.Reservation;
using WebApiCore.Services.Currency;

namespace OrderService.Tests.Services;

public class MetaTrackingServiceTests
{
    private const string FacebookAccessCode = "Access123";
    private const string FacebookPixelId = "Pixel123";
    private const string UserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/119.0";
    private const string ShopCode = "Shop123";

    private static readonly Guid ReservationReference = Guid.NewGuid();
    private static readonly Guid EventId = Guid.NewGuid();
    private static readonly Guid[] ProductIds = { Guid.NewGuid(), Guid.NewGuid() };

    private readonly MetaTrackingService _sut;
    private readonly Mock<IMetaTracker> _mockedMetaTracker = new();
    private readonly Mock<IReservationDao> _mockedReservationDao = new();
    private readonly Mock<IShopDao> _mockedShopDao = new();
    private readonly Mock<IHttpContextAccessor> _mockedHttpContextAccessor = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();

    private readonly FanceeData.Models.Ticketing.Shop _shop = new()
    {
        FacebookAccessCode = FacebookAccessCode,
        FacebookPixelId = FacebookPixelId,
        Code = ShopCode,
        EventId = EventId
    };

    private readonly ReservationReference _reservationReference = new()
    {
        ReservedProducts = new List<ReservedProduct>
        {
            new()
            {
                ProductId = ProductIds[0],
                Quantity = 2,
                Product = new()
                {
                    PriceCents = 1234,
                    Event = new() { Organization = new() { Currency = "EUR" } }
                }
            },
            new()
            {
                ProductId = ProductIds[1],
                Quantity = 1,
                Product = new()
                {
                    PriceCents = 666,
                    Event = new() { Organization = new() { Currency = "EUR" } }
                }
            }
        }
    };
    
    private readonly ReservationReference _freeReservationReference = new()
    {
        ReservedProducts = new List<ReservedProduct>
        {
            new()
            {
                ProductId = ProductIds[0],
                Quantity = 2,
                Product = new()
                {
                    PriceCents = 0,
                    Event = new() { Organization = new() { Currency = "EUR" } }
                }
            },
        }
    };

    public MetaTrackingServiceTests()
    {
        _mockedCurrencyService.Setup(cs => cs.CentsToDecimalAsync(It.IsAny<string>(), It.IsAny<long>()))
            .ReturnsAsync((string _, long value) => (decimal)value / 100);

        _sut = new(
            _mockedMetaTracker.Object,
            _mockedReservationDao.Object,
            _mockedShopDao.Object,
            _mockedHttpContextAccessor.Object,
            _mockedCurrencyService.Object
        );
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncDoesNothingIfUserAgentIsNull()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop());

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary());

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Exactly(2));
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncDoesNothingIfFacebookAccessCodeIsNull()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _shop.FacebookAccessCode = null;

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncDoesNothingIfFacebookPixelIdIsNull()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _shop.FacebookPixelId = null;

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncDoesNothingIfFacebookAccessCodeAndPixelIdAreNull()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _shop.FacebookPixelId = null;
        _shop.FacebookAccessCode = null;

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncDoesNothingOnInvalidReservationReference()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(value: null);

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncDoesNothingIfReservationHasNoReservedProducts()
    {
        _reservationReference.ReservedProducts = new List<ReservedProduct>();

        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(_reservationReference);

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncCallsMetaTrackerCheckoutAsync()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedMetaTracker.Setup(mt => mt.SetConfiguration(It.IsAny<MetaConfiguration>()))
            .Returns(_mockedMetaTracker.Object);

        _mockedHttpContextAccessor.SetupGet(hca => hca.HttpContext!.Connection.RemoteIpAddress)
            .Returns(IPAddress.Loopback);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(_reservationReference);

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Connection.RemoteIpAddress, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.CentsToDecimalAsync("EUR", It.IsAny<long>()), Times.Exactly(2));
        _mockedMetaTracker.Verify(mt => mt.SetConfiguration(It.Is<MetaConfiguration>(mc => mc.PixelId == FacebookPixelId && mc.AccessCode == FacebookAccessCode)), Times.Once);
        _mockedMetaTracker.Verify(mt => mt.CheckoutAsync(It.Is<TrackingInformation>(ti =>
                ti.ShopCode == ShopCode &&
                ti.IpAddress == IPAddress.Loopback &&
                ti.UserAgent == UserAgent &&
                ti.EventId == EventId),
            It.Is<IList<CartItem>>(ci =>
                ci.Count == 2 &&
                ci[0].ProductId == ProductIds[0] &&
                ci[0].Quantity == 2 &&
                ci[0].ItemPrice == 12.34m &&
                ci[1].ProductId == ProductIds[1] &&
                ci[1].Quantity == 1 &&
                ci[1].ItemPrice == 6.66m
            )
        ), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterCheckoutAsyncFallsBackIpAddressNone()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedMetaTracker.Setup(mt => mt.SetConfiguration(It.IsAny<MetaConfiguration>()))
            .Returns(_mockedMetaTracker.Object);

        _mockedHttpContextAccessor.SetupGet(hca => hca.HttpContext!.Connection.RemoteIpAddress)
            .Returns(value: null);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(_reservationReference);

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Connection.RemoteIpAddress, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.CentsToDecimalAsync("EUR", It.IsAny<long>()), Times.Exactly(2));
        _mockedMetaTracker.Verify(mt => mt.SetConfiguration(It.Is<MetaConfiguration>(mc => mc.PixelId == FacebookPixelId && mc.AccessCode == FacebookAccessCode)), Times.Once);
        _mockedMetaTracker.Verify(mt => mt.CheckoutAsync(It.Is<TrackingInformation>(ti =>
                ti.ShopCode == ShopCode &&
                ti.IpAddress == IPAddress.None &&
                ti.UserAgent == UserAgent &&
                ti.EventId == EventId),
            It.IsAny<IList<CartItem>>()
        ), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterPurchaseAsyncCallsMetaTrackerCompletePurchaseAsync()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedMetaTracker.Setup(mt => mt.SetConfiguration(It.IsAny<MetaConfiguration>()))
            .Returns(_mockedMetaTracker.Object);

        _mockedHttpContextAccessor.SetupGet(hca => hca.HttpContext!.Connection.RemoteIpAddress)
            .Returns(IPAddress.Loopback);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(_reservationReference);

        await _sut.RegisterPurchaseAsync(ShopCode, ReservationReference);

        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Connection.RemoteIpAddress, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.CentsToDecimalAsync("EUR", It.IsAny<long>()), Times.Exactly(2));
        _mockedMetaTracker.Verify(mt => mt.SetConfiguration(It.Is<MetaConfiguration>(mc => mc.PixelId == FacebookPixelId && mc.AccessCode == FacebookAccessCode)), Times.Once);
        _mockedMetaTracker.Verify(mt => mt.CompletePurchaseAsync(It.Is<TrackingInformation>(ti =>
                ti.ShopCode == ShopCode &&
                ti.IpAddress == IPAddress.Loopback &&
                ti.UserAgent == UserAgent &&
                ti.EventId == EventId),
            It.Is<IList<CartItem>>(ci =>
                ci.Count == 2 &&
                ci[0].ProductId == ProductIds[0] &&
                ci[0].Quantity == 2 &&
                ci[0].ItemPrice == 12.34m &&
                ci[1].ProductId == ProductIds[1] &&
                ci[1].Quantity == 1 &&
                ci[1].ItemPrice == 6.66m
            )
        ), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterAsyncUsesCacheForSecondInvocation()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(ShopCode))
            .ReturnsAsync(_shop);

        _mockedMetaTracker.Setup(mt => mt.SetConfiguration(It.IsAny<MetaConfiguration>()))
            .Returns(_mockedMetaTracker.Object);

        _mockedHttpContextAccessor.SetupGet(hca => hca.HttpContext!.Connection.RemoteIpAddress)
            .Returns(IPAddress.Loopback);

        _mockedHttpContextAccessor.Setup(hca => hca.HttpContext!.Request.Headers)
            .Returns(new HeaderDictionary(1)
            {
                { "User-Agent", UserAgent }
            });

        _mockedReservationDao.Setup(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()))
            .ReturnsAsync(_freeReservationReference);

        await _sut.RegisterCheckoutAsync(ShopCode, ReservationReference);
        
        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Once);
        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Connection.RemoteIpAddress, Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.CentsToDecimalAsync("EUR", It.IsAny<long>()), Times.Once);
        _mockedMetaTracker.Verify(mt => mt.SetConfiguration(It.Is<MetaConfiguration>(mc => mc.PixelId == FacebookPixelId && mc.AccessCode == FacebookAccessCode)), Times.Once);
        _mockedMetaTracker.Verify(mt => mt.CheckoutAsync(It.Is<TrackingInformation>(ti =>
                ti.ShopCode == ShopCode &&
                ti.IpAddress == IPAddress.Loopback &&
                ti.UserAgent == UserAgent &&
                ti.EventId == EventId),
            It.Is<IList<CartItem>>(ci =>
                ci.Count == 1 &&
                ci[0].ProductId == ProductIds[0] &&
                ci[0].Quantity == 2 &&
                ci[0].ItemPrice == 0
            )
        ), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();

        await _sut.RegisterPurchaseAsync(ShopCode, ReservationReference);
        
        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Request.Headers, Times.Exactly(2));
        _mockedHttpContextAccessor.VerifyGet(hca => hca.HttpContext!.Connection.RemoteIpAddress, Times.Exactly(2));
        _mockedShopDao.Verify(sd => sd.ByCodeAsync(ShopCode), Times.Once);
        _mockedReservationDao.Verify(rd => rd.ReservationAsync(ReservationReference, It.IsAny<Expression<Func<IQueryable<ReservationReference>, IIncludableQueryable<ReservationReference, object>>>?>()), Times.Exactly(2));
        _mockedCurrencyService.Verify(cs => cs.CentsToDecimalAsync("EUR", It.IsAny<long>()), Times.Exactly(2));
        _mockedMetaTracker.Verify(mt => mt.SetConfiguration(It.Is<MetaConfiguration>(mc => mc.PixelId == FacebookPixelId && mc.AccessCode == FacebookAccessCode)), Times.Exactly(2));
        _mockedMetaTracker.Verify(mt => mt.CompletePurchaseAsync(It.Is<TrackingInformation>(ti =>
                ti.ShopCode == ShopCode &&
                ti.IpAddress == IPAddress.Loopback &&
                ti.UserAgent == UserAgent &&
                ti.EventId == EventId),
            It.Is<IList<CartItem>>(ci =>
                ci.Count == 1 &&
                ci[0].ProductId == ProductIds[0] &&
                ci[0].Quantity == 2 &&
                ci[0].ItemPrice == 0
            )
        ), Times.Once);
        _mockedHttpContextAccessor.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedReservationDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedMetaTracker.VerifyNoOtherCalls();
        
    }
}