using System;
using System.Threading.Tasks;
using Fs.MessageBus.Publishers;
using OrderService.Services.Pin;
using WebApiCore.MessageBus.Messages.PinTerminal;

namespace OrderService.Tests.Services.Pin;

public class PinServiceTests
{
    private readonly PinService _sut;
    private readonly Mock<IMessagePublisher<ValidPinTerminalMessage>> _mockedValidPinTerminalPublisher = new();
    private readonly Mock<IMessagePublisher<StartPinTerminalTransactionMessage>> _mockedStartPinTerminalTransactionPublisher = new();

    public PinServiceTests()
    {
        _sut = new(_mockedValidPinTerminalPublisher.Object, _mockedStartPinTerminalTransactionPublisher.Object);
    }

    [Fact]
    public async Task TestThatValidTerminalAsyncReturnsTrueForValidTerminal()
    {
        _mockedValidPinTerminalPublisher.Setup(p => p.Call<ValidPinTerminalResponseMessage>(It.IsAny<ValidPinTerminalMessage>())).Returns(new ValidPinTerminalResponseMessage
        {
            Valid = true
        });

        var actual = await _sut.ValidTerminalAsync("terminal");

        Assert.True(actual);

        _mockedValidPinTerminalPublisher.Verify(p => p.Call<ValidPinTerminalResponseMessage>(It.IsAny<ValidPinTerminalMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatValidTerminalAsyncReturnsFalseForInvalidTerminal()
    {
        _mockedValidPinTerminalPublisher.Setup(p => p.Call<ValidPinTerminalResponseMessage>(It.IsAny<ValidPinTerminalMessage>())).Returns(new ValidPinTerminalResponseMessage
        {
            Valid = false
        });

        var actual = await _sut.ValidTerminalAsync("terminal");

        Assert.False(actual);

        _mockedValidPinTerminalPublisher.Verify(p => p.Call<ValidPinTerminalResponseMessage>(It.IsAny<ValidPinTerminalMessage>()), Times.Once);
    }

    [Fact]
    public void TestThatStartTransactionCallsPublisherPublish()
    {
        var request = new StartPinTerminalTransactionMessage
        {
            ReservationReference = Guid.NewGuid(),
            TerminalSerialNumber = "terminal-123456789"
        };

        _sut.StartTransaction(request);

        _mockedStartPinTerminalTransactionPublisher.Verify(p => p.Publish(request), Times.Once);
    }
}