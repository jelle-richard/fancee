﻿namespace ViewRenderer;

public interface IViewRenderer
{
    /// <summary>
    /// Renders the given view to a HTML string.
    /// </summary>
    /// <typeparam name="TViewModel"></typeparam>
    /// <param name="viewName"></param>
    /// <param name="model"></param>
    /// <returns></returns>
    public Task<string> RenderViewAsync<TViewModel>(string viewName, TViewModel model);
}