﻿using Microsoft.Extensions.DependencyInjection;

namespace ViewRenderer;

public static class ViewRendererExtensions
{
    public static IServiceCollection AddViewRenderer(this IServiceCollection serviceCollection)
    {
        return serviceCollection.AddScoped<IViewRenderer, ViewRenderer>();
    }
}