﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Routing;
using ViewRenderer.Exceptions;

namespace ViewRenderer;

public class ViewRenderer : IViewRenderer
{
    private readonly IRazorViewEngine _viewEngine;
    private readonly ITempDataProvider _tempDataProvider;
    private readonly IServiceProvider _serviceProvider;

    public ViewRenderer(IRazorViewEngine viewEngine, ITempDataProvider tempDataProvider, IServiceProvider serviceProvider)
    {
        _viewEngine = viewEngine;
        _tempDataProvider = tempDataProvider;
        _serviceProvider = serviceProvider;
    }

    public async Task<string> RenderViewAsync<TViewModel>(string viewName, TViewModel model)
    {
        var viewPath = $"~/Views/{viewName}.cshtml";

        var actionContext = GetActionContext();
        var view = FindView(actionContext, viewPath);

        await using var output = new StringWriter();

        var viewContext = new ViewContext(
            actionContext,
            view,
            new ViewDataDictionary<TViewModel>(new EmptyModelMetadataProvider(), new ModelStateDictionary()) { Model = model },
            new TempDataDictionary(actionContext.HttpContext, _tempDataProvider),
            output,
            new HtmlHelperOptions());

        await view.RenderAsync(viewContext);

        return output.ToString();
    }

    /// <summary>
    /// Finds a view with the given name.
    /// </summary>
    /// <param name="actionContext"></param>
    /// <param name="viewName"></param>
    /// <returns></returns>
    /// <exception cref="InvalidViewException"></exception>
    private IView FindView(ActionContext actionContext, string viewName)
    {
        var getViewResult = _viewEngine.GetView(null, viewName, true);
        if (getViewResult.Success)
            return getViewResult.View;

        var findViewResult = _viewEngine.FindView(actionContext, viewName, true);
        if (findViewResult.Success)
            return findViewResult.View;

        throw new InvalidViewException(viewName, getViewResult.SearchedLocations.Concat(findViewResult.SearchedLocations));
    }

    /// <summary>
    /// Gets a new ActionContext object.
    /// </summary>
    /// <returns></returns>
    private ActionContext GetActionContext()
    {
        var httpContext = new DefaultHttpContext
{
            RequestServices = _serviceProvider
        };

        return new ActionContext(httpContext, new RouteData(), new ActionDescriptor());
    }
}