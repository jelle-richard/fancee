namespace ViewRenderer.Exceptions;

public class InvalidViewException(string viewName, IEnumerable<string> searchedLocations) : Exception($"Unable to find view '{viewName}'. The following locations were searched: {string.Join("; ", searchedLocations)}");