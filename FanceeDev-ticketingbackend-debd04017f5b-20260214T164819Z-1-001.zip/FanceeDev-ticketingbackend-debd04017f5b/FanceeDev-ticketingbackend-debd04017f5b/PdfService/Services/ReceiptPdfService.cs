using System.Net.Mime;
using FanceeData.Models.Ticketing;
using PdfService.Models.Receipt;
using PdfService.Persistence.Order;
using PdfService.Provider.Pdf;
using PdfService.Utils.Adapter;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.Contract;
using WebApiCore.Services.Currency;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using WebApiCore.Utils;

namespace PdfService.Services;

public class ReceiptPdfService : IPdfService, IReceiptPdfService
{
    private readonly IOrderDao _orderDao;
    private readonly IDeploymentEnvironmentService _deploymentEnvironmentService;
    private readonly OrganizationDetailsSettings _organizationDetailsSettings;
    private readonly ICurrencyService _currencyService;
    private readonly IPdfProvider _pdfProvider;
    private readonly IUploadService _uploadService;
    private readonly IStorageService _storageService;
    private readonly IContractDao _contractDao;

    public ReceiptPdfService(IOrderDao orderDao, IDeploymentEnvironmentService deploymentEnvironmentService, IConfiguration configuration, IPdfProvider pdfProvider, IUploadService uploadService, IStorageService storageService, ICurrencyService currencyService, IContractDao contractDao)
    {
        _orderDao = orderDao;
        _deploymentEnvironmentService = deploymentEnvironmentService;
        _pdfProvider = pdfProvider;
        _uploadService = uploadService;
        _storageService = storageService;
        _currencyService = currencyService;
        _contractDao = contractDao;
        _organizationDetailsSettings = OrganizationDetailsSettings.FromConfiguration(configuration);
    }

    public Type GetMessageType() => typeof(GenerateOrderReceiptMessage);

    public async Task GeneratePdfAsync(IGeneratePdfMessage message)
    {
        var task = message switch
        {
            GenerateOrderReceiptMessage generateOrderReceiptMessage => GenerateOrderReceiptAsync(generateOrderReceiptMessage),
            var _ => throw new NotSupportedException()
        };

        await task;
    }

    public async Task DeleteExpiredOrderReceiptsAsync()
    {
        var orderReceiptFiles = await _orderDao.ExpiredOrderReceiptsAsync(IStorageService.ReceiptPdfRetentionTimeInMinutes);

        foreach (var orderReceiptsFile in orderReceiptFiles)
            await _storageService.DeleteFileAsync(IStorageService.OrderReceiptPdfStoragePool, orderReceiptsFile.File.Path);

        await _orderDao.DeleteOrderReceiptFilesAsync(orderReceiptFiles);
    }

    private async Task GenerateOrderReceiptAsync(GenerateOrderReceiptMessage message)
    {
        if (await _orderDao.OrderReceiptsFileExists(message.OrderId))
            return;

        var order = await _orderDao.RetrieveForReceiptGenerationAsync(message.OrderId);
        if (order is null)
            return;

        var model = await GetPdfModelAsync(order);
        var pdf = await _pdfProvider.RenderPdfAsync("Receipt/Order", model);

        await _uploadService
            .UploadAsync(
                pdf.FileStream,
                IStorageService.OrderReceiptPdfStoragePool,
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                await _deploymentEnvironmentService.GetAsync(),
                async file => await _orderDao.InsertOrderReceiptsFileAsync(order.Id, file));
    }

    private async Task<OrderReceiptPdfModel> GetPdfModelAsync(Order order)
    {
        var organizationId = order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.OrganizationId;
        var orderContract = await _contractDao.ContractFeeAsync(organizationId, order.CreatedAt);
        var orderCost = await _orderDao.OrderReceiptCostsAsync(order.Id, orderContract);
        var @event = order.IssuedProducts.First().Product.Event;
        var organization = @event.Organization;

        await UpdatePriceFormatting(orderCost, order.CurrencyNavigation);

        return new()
        {
            OrderCost = orderCost,
            PspReference = order.PspReference,
            Organization = @event.Organization.Name,
            ClientFirstname = order.ClientOrder.FirstName,
            ClientLastname = order.ClientOrder.LastName,
            OrderDate = order.CreatedAt.ToString(DateFormat.YearMonthDay),
            EventName = @event.Name,
            PlatformName = _organizationDetailsSettings.PlatformName,
            OrganizationSupportEmail = _organizationDetailsSettings.SupportEmail,
            OrganizationWebsite = _organizationDetailsSettings.Website,
            ClientAddress = order.ClientOrder.Address?.ToAddress(),
            OrganizationAddress = organization.Address?.ToAddress(),
            Currency = order.CurrencyNavigation,
            PlatformSettings = _organizationDetailsSettings,
            Title = "Receipt"
        };
    }

    private async Task UpdatePriceFormatting(OrderReceiptCostModel model, Currency currency)
    {
        model.TotalOrderCost = model.TotalOrderCostCents == null
            ? null
            : await _currencyService.FormatAsync(currency.ShortCode, (long)model.TotalOrderCostCents);
        model.PaymentFee = model.PaymentFeeCents == null
            ? null
            : await _currencyService.FormatAsync(currency.ShortCode, (long)model.PaymentFeeCents);
        model.TicketServicePlusCost = model.TicketServicePlusCostCents == null
            ? null
            : await _currencyService.FormatAsync(currency.ShortCode, (long)model.TicketServicePlusCostCents);
        model.ReceiveViaSmsCost = model.ReceiveViaSmsCostCents == null
            ? null
            : await _currencyService.FormatAsync(currency.ShortCode, (long)model.ReceiveViaSmsCostCents);

        foreach (var issuedTicket in model.IssuedTickets)
        {
            issuedTicket.Price = issuedTicket.PriceCents == null
                ? null
                : await _currencyService.FormatAsync(currency.ShortCode, (long)issuedTicket.PriceCents);
            issuedTicket.Fee = issuedTicket.FeeCents == null
                ? null
                : await _currencyService.FormatAsync(currency.ShortCode, (long)issuedTicket.FeeCents);

            var totalCents = ((issuedTicket.PriceCents ?? 0) + (issuedTicket.FeeCents ?? 0)) * issuedTicket.Quantity;
            issuedTicket.Total = issuedTicket.PriceCents == null && issuedTicket.FeeCents == null
                ? null
                : await _currencyService.FormatAsync(currency.ShortCode, totalCents);
        }
    }
}