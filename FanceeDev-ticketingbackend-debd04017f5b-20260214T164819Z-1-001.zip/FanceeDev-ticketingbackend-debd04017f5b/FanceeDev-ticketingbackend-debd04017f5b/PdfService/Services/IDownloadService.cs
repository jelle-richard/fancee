using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Services;

public interface IDownloadService
{
    /// <summary>
    /// Downloads the given file and converts it to a base64 representation.
    /// </summary>
    /// <param name="pool"></param>
    /// <param name="file"></param>
    /// <param name="convertToJpeg"></param>
    /// <returns></returns>
    public Task<string> Base64Async(string pool, File file, bool convertToJpeg);
}