using System.Net.Mime;
using FanceeData.Models.Ticketing;
using MailTemplates.Models.User.Organization;
using MailTemplates.Templates;
using Microsoft.AspNetCore.Mvc;
using PdfService.Models.Organization;
using PdfService.Persistence.Organization;
using PdfService.Provider.Pdf;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.Currency;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using WebApiCore.Utils;
using WebApiCore.Utils.Mail;
using WebApiCore.Utils.String;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Services;

public class OrganizationContractService : IPdfService
{
    private readonly IPdfProvider _pdfProvider;
    private readonly IOrganizationDao _organizationDao;
    private readonly IMailer _mailer;
    private readonly ICurrencyDao _currencyDao;
    private readonly IConfiguration _configuration;
    private readonly IUploadService _uploadService;
    private readonly ICurrencyService _currencyService;

    public OrganizationContractService(IPdfProvider pdfProvider, IOrganizationDao organizationDao, IMailer mailer, ICurrencyDao currencyDao, IConfiguration configuration, IUploadService uploadService, ICurrencyService currencyService)
    {
        _pdfProvider = pdfProvider;
        _organizationDao = organizationDao;
        _mailer = mailer;
        _currencyDao = currencyDao;
        _configuration = configuration;
        _uploadService = uploadService;
        _currencyService = currencyService;
    }

    public Type GetMessageType() => typeof(GenerateOrganizationContractMessage);

    public async Task GeneratePdfAsync(IGeneratePdfMessage message)
    {
        if (message is not GenerateOrganizationContractMessage pdfMessage)
            return;

        var platformSettings = OrganizationDetailsSettings.FromConfiguration(_configuration);
        var currency = await _currencyDao.CurrencyAsync(platformSettings.PlatformBaseCurrency);
        var contractDetails = await _organizationDao.OrganizationContractDetailsAsync(pdfMessage.OrganizationId, platformSettings.PackageSettings, currency);
        if (contractDetails == null)
            return;

        contractDetails.TicketFee = await _currencyService.CentsToDecimalAsync(currency.ShortCode, contractDetails.TicketFeeCents);
        contractDetails.ProductFee = await _currencyService.CentsToDecimalAsync(currency.ShortCode, contractDetails.ProductFeeCents);
        contractDetails.GuestListFee = await _currencyService.CentsToDecimalAsync(currency.ShortCode, contractDetails.GuestListFeeCents);
        contractDetails.SeatedTicketFee = await _currencyService.CentsToDecimalAsync(currency.ShortCode, contractDetails.SeatedTicketFeeCents);
        contractDetails.CreationDate = DateTimeUtils.ConvertToTimezone(contractDetails.CreationDate, "Europe/Amsterdam");
        contractDetails.SigningDate = DateTimeUtils.ConvertToTimezone(contractDetails.SigningDate, "Europe/Amsterdam");
        contractDetails.EndDate = DateTimeUtils.ConvertToTimezone(contractDetails.EndDate, "Europe/Amsterdam");

        var platformContract = new OrganizationContractPlatformWrapModel
        {
            Title = $"{platformSettings.Name} ticket fee contract",
            Contract = contractDetails,
            PlatformSettings = platformSettings,
            Base64Signature = pdfMessage.Base64Signature
        };

        var pdfStream = await _pdfProvider.RenderPdfAsync(contractDetails.CountryCode == "NL" ? "Contract/Base_NL" : "Contract/Base_EN", platformContract);
        var base64 = await pdfStream.FileStream.ToBase64Async();

        await UploadContractAsync(pdfStream, pdfMessage, contractDetails);

        if (pdfMessage.Base64Signature == null)
            await MailContractProposalAsync(platformContract, base64, pdfMessage.Environment.FrontendBaseUrl, pdfMessage.IsAlteration);
        else
            await MailSignedContractAsync(platformContract, base64, pdfMessage.Environment.FrontendBaseUrl);
    }

    private async Task MailContractProposalAsync(OrganizationContractPlatformWrapModel platformContract, string base64Attachment, string frontendBaseUrl, bool isAlteration)
    {
        var name = $"{platformContract.Contract.OrganizationHolderFirstName} {platformContract.Contract.OrganizationHolderLastName}";
        var subject = (isAlteration
                ? Templates.ContractProposalAlterationSubject
                : Templates.ContractProposalSubject
            ).Replace("%platformName%", platformContract.PlatformSettings.Name);

        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.ContractProposal, new ContractModel
        {
            Name = name,
            IsAlteration = isAlteration
        }.SetDefaultValues(subject, platformContract.PlatformSettings, frontendBaseUrl));

        _mailer.Send(new()
        {
            Subject = subject,
            To = new MailAddress[] { new(platformContract.Contract.Email, name) },
            HtmlContent = htmlContent,
            Attachments = new Attachment[]
            {
                new("TicketFeeContractProposal.pdf",
                    "application/pdf",
                    base64Attachment)
            }
        });
    }

    private async Task MailSignedContractAsync(OrganizationContractPlatformWrapModel platformContract, string base64Attachment, string frontendBaseUrl)
    {
        var name = $"{platformContract.Contract.OrganizationHolderFirstName} {platformContract.Contract.OrganizationHolderLastName}";
        var subject = Templates.ContractSignedSubject.Replace("%platformName%", platformContract.PlatformSettings.Name);

        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.ContractSigned, new ContractModel
        {
            Name = name
        }.SetDefaultValues(subject, platformContract.PlatformSettings, frontendBaseUrl));

        _mailer.Send(new()
        {
            Subject = subject,
            To = new MailAddress[] { new(platformContract.Contract.Email, name) },
            HtmlContent = htmlContent,
            Attachments = new Attachment[]
            {
                new("SignedTicketFeeContract.pdf",
                    "application/pdf",
                    base64Attachment)
            }
        });
    }

    private async Task UploadContractAsync(FileStreamResult pdfStream, GenerateOrganizationContractMessage pdfMessage, OrganizationContractModel contractDetails)
    {
        await _uploadService.UploadAsync(pdfStream.FileStream, IStorageService.ContractStoragePool, null, "pdf", MediaTypeNames.Application.Pdf, null, false, pdfMessage.Environment, async file =>
        {
            if (pdfMessage.Base64Signature == null && !pdfMessage.IsAlteration)
                await InsertUnsignedContractAsync(file, pdfMessage.OrganizationId, contractDetails);
            else
                await _organizationDao.UpdateContractFileAsync(pdfMessage.OrganizationId, file, !pdfMessage.IsAlteration);
        });
    }

    private async Task InsertUnsignedContractAsync(File file, Guid organizationId, OrganizationContractModel contractDetails)
    {
        OrganizationContract contract = new()
        {
            Start = DateTime.UtcNow,
            End = DateTime.UtcNow.AddYears(1),
            File = file,
            OrganizationId = organizationId,
            PackageType = contractDetails.PackageType,
            ProductFeeCents = contractDetails.ProductFeeCents,
            ProductFeePercentage = contractDetails.ProductFeePercentage,
            TicketFeeCents = contractDetails.TicketFeeCents,
            TicketFeePercentage = contractDetails.TicketFeePercentage,
            SeatedTicketFeeCents = contractDetails.SeatedTicketFeeCents,
            SeatedTicketFeePercentage = contractDetails.SeatedTicketFeePercentage,
            GuestListFeeCents = contractDetails.GuestListFeeCents,
            Signed = false
        };

        await _organizationDao.InsertContractAsync(contract);
    }
}