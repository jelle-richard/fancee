using System.Net.Mime;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Invoicing;
using MailTemplates.Models.Receipt;
using MailTemplates.Templates;
using Microsoft.EntityFrameworkCore;
using PdfService.Models.Receipt;
using PdfService.Persistence.WalletPayment;
using PdfService.Provider.Pdf;
using PdfService.Utils.Adapter;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using WebApiCore.Utils.Mail;
using WebApiCore.Utils.String;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Services;

public class PayoutReceiptPdfService : IPdfService
{
    private readonly IPdfProvider _pdfProvider;
    private readonly IConfiguration _configuration;
    private readonly IUploadService _uploadService;
    private readonly IMailer _mailer;
    private readonly IWalletPaymentDao _walletPaymentDao;
    private readonly ICurrencyService _currencyService;

    public PayoutReceiptPdfService(IPdfProvider pdfProvider, IConfiguration configuration, IUploadService uploadService, IMailer mailer, IWalletPaymentDao walletPaymentDao, ICurrencyService currencyService)
    {
        _pdfProvider = pdfProvider;
        _configuration = configuration;
        _uploadService = uploadService;
        _mailer = mailer;
        _walletPaymentDao = walletPaymentDao;
        _currencyService = currencyService;
    }

    public Type GetMessageType() => typeof(GeneratePayoutReceiptPdfMessage);

    public async Task GeneratePdfAsync(IGeneratePdfMessage message)
    {
        if (message is not GeneratePayoutReceiptPdfMessage pdfMessage)
            return;

        var walletPayment = await _walletPaymentDao.ByIdAsync(
            pdfMessage.WalletPaymentId,
            i => i.Include(wp => wp.Organization.PaymentSettings)
                .Include(wp => wp.Organization.User.UserContactInfo.Address)
        );

        if (walletPayment == null)
            return;

        var platformSettings = OrganizationDetailsSettings.FromConfiguration(_configuration);

        var model = new PayoutReceiptModel
        {
            Title = "Pay Out",
            PlatformSettings = platformSettings,
            WalletPaymentId = pdfMessage.WalletPaymentId,
            RequestDateTime = walletPayment.RequestedAt,
            FormattedPayoutValue = await _currencyService.FormatAsync(platformSettings.PlatformBaseCurrency, walletPayment.AmountCents),
            Iban = walletPayment.Organization.PaymentSettings.Iban,
            BankAccountNumber = walletPayment.Organization.PaymentSettings.BankAccountNumber,
            Bic = walletPayment.Organization.PaymentSettings.Bic,
            Organization = walletPayment.Organization.Name,
            Address = walletPayment.Organization.User.UserContactInfo.Address.ToAddress()
        };

        var pdf = await _pdfProvider.RenderPdfAsync("Receipt/Payout", model);
        var base64Content = await pdf.FileStream.ToBase64Async();

        await _uploadService.UploadAsync(
            pdf.FileStream,
            IStorageService.ReceiptMediaStoragePool,
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            pdfMessage.Environment,
            async file =>
            {
                await UpdateWalletPaymentAsync(file, walletPayment);
                await SendReceiptAsync(walletPayment.Organization, base64Content, pdfMessage.Environment);
            }
        );
    }

    private async Task UpdateWalletPaymentAsync(File file, WalletPayment walletPayment)
    {
        walletPayment.File = file;

        await _walletPaymentDao.UpdateAsync(walletPayment);
    }

    private async Task SendReceiptAsync(Organization organization, string payoutBase64, DeploymentEnvironment environment)
    {
        var organizationSettings = OrganizationDetailsSettings.FromConfiguration(_configuration);
        var name = $"{organization.User.UserContactInfo?.FirstName} {organization.User.UserContactInfo?.LastName}";

        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.PayOutReceipt, new PayOutReceiptModel
        {
            Name = name
        }.SetDefaultValues(Templates.PayOutReceiptSubject, organizationSettings, environment.FrontendBaseUrl));

        _mailer.Send(new()
        {
            To = new MailAddress[] { new(organization.User.Email, name) },
            Subject = Templates.PayOutReceiptSubject,
            HtmlContent = htmlContent,
            Attachments = new Attachment[]
            {
                new("receipt.pdf", MediaTypeNames.Application.Pdf, payoutBase64)
            }
        });
    }
}