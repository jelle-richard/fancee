﻿using System.Net.Mime;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Invoicing;
using Fs.MessageBus.Publishers;
using MailTemplates.Models.Invoice;
using MailTemplates.Templates;
using Microsoft.EntityFrameworkCore;
using PdfService.Models;
using PdfService.Persistence.Invoice;
using PdfService.Provider.Pdf;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Invoices;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using WebApiCore.Utils;
using WebApiCore.Utils.Mail;
using WebApiCore.Utils.String;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Services;

public class InvoicePdfService : IPdfService
{
    private readonly IPdfProvider _pdfProvider;
    private readonly IInvoiceDao _invoiceDao;
    private readonly IUploadService _uploadService;
    private readonly IMailer _mailer;
    private readonly IConfiguration _configuration;
    private readonly IOrganizationDao _organizationDao;
    private readonly IMessagePublisher<AddAccountingInvoiceMessage> _accountingInvoicePublisher;

    public InvoicePdfService(IPdfProvider pdfProvider, IInvoiceDao invoiceDao, IUploadService uploadService, IMailer mailer, IConfiguration configuration, IOrganizationDao organizationDao, IMessagePublisher<AddAccountingInvoiceMessage> accountingInvoicePublisher)
    {
        _pdfProvider = pdfProvider;
        _invoiceDao = invoiceDao;
        _uploadService = uploadService;
        _mailer = mailer;
        _configuration = configuration;
        _organizationDao = organizationDao;
        _accountingInvoicePublisher = accountingInvoicePublisher;
    }

    public Type GetMessageType() => typeof(GenerateInvoicePdfMessage);

    public async Task GeneratePdfAsync(IGeneratePdfMessage message)
    {
        if (message is not GenerateInvoicePdfMessage invoiceMessage)
            return;

        var invoice = await _invoiceDao.GetAsync(invoiceMessage.InvoiceNumber);

        if (invoice == null)
            return;

        var model = SetCorrectContactDetails(new()
        {
            Invoice = invoice,
            PlatformSettings = OrganizationDetailsSettings.FromConfiguration(_configuration)
        });

        var pdf = await _pdfProvider.RenderPdfAsync("Invoice", model);
        var base64Content = await pdf.FileStream.ToBase64Async();

        await _uploadService.UploadAsync(
            pdf.FileStream,
            IStorageService.InvoiceMediaStoragePool,
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            invoiceMessage.Environment,
            async file =>
            {
                await UpdateInvoiceAsync(invoice, file);
                AddAccountingInvoice(invoice.Id);
                await SendInvoiceMailAsync(invoice, message.Environment, base64Content);
            });
    }

    /// <summary>
    /// Sets the correct contract details of an (historic) invoice.
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    private static InvoiceModel SetCorrectContactDetails(InvoiceModel model)
    {
        model.PlatformSettings.Name = model.Invoice.SenderContactDetails.Organization;
        model.PlatformSettings.Address.Street = model.Invoice.SenderContactDetails.Address.Street;
        model.PlatformSettings.Address.HouseNumber = model.Invoice.SenderContactDetails.Address.HouseNumber;
        model.PlatformSettings.Address.PostalCode = model.Invoice.SenderContactDetails.Address.PostalCode;
        model.PlatformSettings.Address.City = model.Invoice.SenderContactDetails.Address.City;
        model.PlatformSettings.Address.CountryCode = model.Invoice.SenderContactDetails.Address.CountryCode;

        return model;
    }

    /// <summary>
    /// Updates the file of the invoice.
    /// </summary>
    /// <param name="invoice"></param>
    /// <param name="file"></param>
    /// <returns></returns>
    private async Task UpdateInvoiceAsync(Invoice invoice, File file)
    {
        invoice.File = file;

        await _invoiceDao.UpdateAsync(invoice);
    }

    /// <summary>
    /// Sends an email with the invoice to the organization.
    /// </summary>
    /// <param name="invoice"></param>
    /// <param name="environment"></param>
    /// <param name="invoiceBase64"></param>
    private async Task SendInvoiceMailAsync(Invoice invoice, DeploymentEnvironment environment, string invoiceBase64)
    {
        var organizationSettings = OrganizationDetailsSettings.FromConfiguration(_configuration);
        var organization = await _organizationDao.ByIdAsync(invoice.OrganizationId, q => q.Include(o => o.User.UserContactInfo));

        if (organization == null)
            return;

        var name = $"{organization.User.UserContactInfo?.FirstName} {organization.User.UserContactInfo?.LastName}";
        var subject = Templates.NewInvoiceSubject.Replace("%platformName%", organizationSettings.PlatformName);

        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.NewInvoice, new NewInvoiceModel
        {
            Name = name,
            InvoiceDate = invoice.CreatedAt.ToDateOnly()
        }.SetDefaultValues(subject, organizationSettings, environment.FrontendBaseUrl));

        _mailer.Send(new()
        {
            To = new List<MailAddress> { new(organization.User.Email, name) },
            Subject = subject,
            HtmlContent = htmlContent,
            Attachments = new Attachment[]
            {
                new("invoice.pdf", MediaTypeNames.Application.Pdf, invoiceBase64)
            }
        });
    }

    /// <summary>
    /// Sends off a message to add the invoice to the external accounting software.
    /// </summary>
    /// <param name="invoiceId"></param>
    private void AddAccountingInvoice(int invoiceId)
    {
        _accountingInvoicePublisher.Publish(new()
        {
            InvoiceId = invoiceId
        });
    }
}