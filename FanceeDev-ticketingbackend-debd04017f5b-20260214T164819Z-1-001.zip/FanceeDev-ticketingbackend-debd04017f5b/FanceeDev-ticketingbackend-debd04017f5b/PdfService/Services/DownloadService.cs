using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Processing;
using WebApiCore.Services.Cache;
using WebApiCore.Services.Storage;
using WebApiCore.Utils.String;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Services;

public class DownloadService : IDownloadService
{
    private readonly IStorageService _storageService;
    private readonly ILogger<DownloadService> _logger;
    private readonly ICacheService _cacheService;

    public DownloadService(IStorageService storageService, ILogger<DownloadService> logger, ICacheService cacheService)
    {
        _storageService = storageService;
        _logger = logger;
        _cacheService = cacheService;
    }

    public async Task<string> Base64Async(string pool, File file, bool convertToJpeg)
    {
        var value = await _cacheService.GetCachedObjectAsync<string?>(file.Id.ToString());
        if (value != null)
            return value;

        try
        {
            var fileStream = await _storageService.DownloadFileAsync(pool, file.Path);

            var base64 = convertToJpeg
                ? await ConvertMedia(fileStream) ?? await fileStream.ToBase64Async()
                : await fileStream.ToBase64Async();

            await _cacheService.CacheObjectAsync(file.Id.ToString(), base64, TimeSpan.FromMinutes(2));

            return base64;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unable to download file: {FileId}", file.Id);

            return string.Empty;
        }
    }

    /// <summary>
    /// Converts media to a JPEG file with a max width of 900px and a quality of 50 keeping the original aspect ratio.
    /// </summary>
    /// <param name="stream"></param>
    /// <returns></returns>
    private static async Task<string?> ConvertMedia(Stream stream)
    {
        try
        {
            var memStream = new MemoryStream();

            using var image = await Image.LoadAsync(stream);

            var resizeAction = Resize(image);
            if (resizeAction != null)
                image.Mutate(resizeAction);

            await image.SaveAsJpegAsync(memStream, new JpegEncoder
            {
                Quality = 50,
                SkipMetadata = true
            });

            memStream.Position = 0;

            return await memStream.ToBase64Async();
        }
        catch (Exception)
        {
            return null;
        }
    }

    /// <summary>
    /// Gets a resize action that resizes the image with a maximum of either 900 pixels in width or height while
    /// keeping the original aspect ratio.
    /// </summary>
    /// <param name="image"></param>
    /// <returns></returns>
    private static Action<IImageProcessingContext>? Resize(Image image)
    {
        Size size;

        if (image.Width > 900)
            size = new() { Width = 900 };
        else if (image.Height > 900)
            size = new() { Height = 900 };
        else
            return null;

        return c => c.Resize(new ResizeOptions
        {
            Mode = ResizeMode.Max,
            Size = size
        });
    }
}