namespace PdfService.Services;

public interface ITicketPdfService
{
    /// <summary>
    /// Deletes expired ticket pdfs from storage and database.
    /// </summary>
    /// <returns></returns>
    public Task DeleteExpiredTicketPdfsAsync();
}