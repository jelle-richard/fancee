using System.Net.Mime;
using System.Text;
using FanceeData.Models.Ticketing;
using MailTemplates.Models.Shop;
using MailTemplates.Models.User;
using MailTemplates.Templates;
using PdfService.Models;
using PdfService.Models.Views;
using PdfService.Persistence.Event;
using PdfService.Persistence.IssuedTicket;
using PdfService.Persistence.Order;
using PdfService.Persistence.Ticket;
using PdfService.Persistence.User;
using PdfService.Provider.Pdf;
using PdfService.Utils.Adapter;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Address;
using WebApiCore.Exceptions.Contract;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.Contract;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using WebApiCore.Utils;
using WebApiCore.Utils.Mail;
using WebApiCore.Utils.String;

namespace PdfService.Services;

public class TicketPdfService : IPdfService, ITicketPdfService
{
    private const string DefaultOrderContent = "<p>Thank you for your order, you’ll find your tickets attached to this email.</p>";
    private const string DefaultSealedTicketContent = "<p>Thank you for your patience, you’ll find your tickets attached to this email.</p>";
    private const string DefaultGuestListContent = "<p>Your guest list tickets are attached to this email.</p>";

    private readonly IPdfProvider _pdfProvider;
    private readonly IIssuedTicketDao _issuedTicketDao;
    private readonly IMailer _mailer;
    private readonly OrganizationDetailsSettings _organizationDetails;
    private readonly IOrganizationDao _organizationDao;
    private readonly IUploadService _uploadService;
    private readonly IOrderDao _orderDao;
    private readonly IDeploymentEnvironmentService _deploymentEnvironmentService;
    private readonly IEventMailDao _eventMailDao;
    private readonly IStorageService _storageService;
    private readonly IDownloadService _downloadService;
    private readonly IEventDao _eventDao;
    private readonly ITicketDesignDao _ticketDesignDao;
    private readonly IUserDao _userDao;
    private readonly IContractDao _contractDao;
    private readonly IConfiguration _configuration;

    private readonly Dictionary<Guid, FocalPoint> _focusPointCache = new();

    public TicketPdfService(IPdfProvider pdfProvider, IIssuedTicketDao issuedTicketDao, IMailer mailer, IConfiguration configuration, IOrganizationDao organizationDao, IUploadService uploadService, IDeploymentEnvironmentService deploymentEnvironmentService, IOrderDao orderDao, IEventMailDao eventMailDao, IStorageService storageService, IDownloadService downloadService, IEventDao eventDao, ITicketDesignDao ticketDesignDao, IUserDao userDao, IContractDao contractDao)
    {
        _pdfProvider = pdfProvider;
        _issuedTicketDao = issuedTicketDao;
        _mailer = mailer;
        _configuration = configuration;
        _organizationDao = organizationDao;
        _uploadService = uploadService;
        _deploymentEnvironmentService = deploymentEnvironmentService;
        _orderDao = orderDao;
        _eventMailDao = eventMailDao;
        _storageService = storageService;
        _downloadService = downloadService;
        _eventDao = eventDao;
        _ticketDesignDao = ticketDesignDao;
        _userDao = userDao;
        _contractDao = contractDao;
        _organizationDetails = OrganizationDetailsSettings.FromConfiguration(configuration);
    }

    public Type GetMessageType() => typeof(GenerateTicketPdfMessage);

    public async Task GeneratePdfAsync(IGeneratePdfMessage message)
    {
        var task = message switch
        {
            GenerateTicketSwapTicketPdfMessage ticketSwapTicketPdfMessage => GenerateTicketSwapPdfAsync(ticketSwapTicketPdfMessage),
            GenerateGuestListTicketPdfMessage guestListPdfMessage => GenerateGuestListPdfAsync(guestListPdfMessage),
            GenerateOrderTicketPdfMessage ticketPdfMessage => GenerateOrderPdfSendOrDownloadAsync(ticketPdfMessage),
            var _ => throw new NotSupportedException()
        };

        await task;
    }

    public async Task DeleteExpiredTicketPdfsAsync()
    {
        var orderTicketFiles = await _orderDao.ExpiredOrderTicketPdfFilesAsync(IStorageService.TicketPdfRetentionTimeMinutes);

        foreach (var orderTicketsFile in orderTicketFiles)
        {
            var actualPath = orderTicketsFile.File.Path.ReplaceFirst($"uploads/{IStorageService.TicketPdfStoragePool}/", string.Empty);
            await _storageService.DeleteFileAsync(IStorageService.TicketPdfStoragePool, actualPath);
        }

        await _orderDao.DeleteOrderTicketFilesAsync(orderTicketFiles);
    }

    public static string GetFormattedAddress(IAddressDto address)
    {
        const string br = "<br/>";
        var sb = new StringBuilder();

        if (!string.IsNullOrEmpty(address.Venue))
            sb.Append(address.Venue).Append(br);

        if (!string.IsNullOrEmpty(address.Street))
            sb.Append(address.Street).Append(' ').Append(address.HouseNumber ?? string.Empty).Append(br);

        if (!string.IsNullOrEmpty(address.PostalCode))
            sb.Append(address.PostalCode).Append(' ');

        if (!string.IsNullOrEmpty(address.City))
            sb.Append(address.City).Append(br);

        if (!string.IsNullOrEmpty(address.CountryCode))
            sb.Append(address.CountryCode.ToUpperInvariant());

        if (sb.Length > 0)
            sb.Insert(0, "📍 ");

        return sb.ToString();
    }

    private async Task GenerateTicketSwapPdfAsync(GenerateTicketSwapTicketPdfMessage ticketSwapTicketPdfMessage)
    {
        var ticket = await _issuedTicketDao.ByCodeAsync(ticketSwapTicketPdfMessage.SwappedIssuedTicketCode);
        if (ticket == null)
            return;

        var address = GetAddress(ticket.IssuedProduct);
        var model = await GetPdfModelAsync(new List<IssuedTicket> { ticket }, address, false);

        var pdf = await _pdfProvider.RenderPdfAsync("Product/Templates/Base", model);

        await UploadTicketsPdfAsync(pdf.FileStream, ticketSwapTicketPdfMessage.PreviousIssuedTicketCode, ticketSwapTicketPdfMessage.SwappedIssuedTicketCode);
    }

    private async Task GenerateOrderPdfSendOrDownloadAsync(GenerateOrderTicketPdfMessage orderTicketPdfMessage)
    {
        var tickets = (await _issuedTicketDao.ByOrderIdAsync(orderTicketPdfMessage.OrderId)).ToList();
        if (tickets.Count == 0)
            return;

        var address = GetAddress(tickets[0].IssuedProduct);
        var model = await GetPdfModelAsync(tickets, address, true);

        var pdf = await _pdfProvider.RenderPdfAsync("Product/Templates/Base", model);

        var ticketHolder = await _userDao.ByClientIdAsync(tickets[0].IssuedProduct.Order.ClientOrder.ClientId);
        if (ticketHolder is not null && !orderTicketPdfMessage.Resend)
            await SendFirstTimeBuyerOrNotYetRegisteredMailAsync(ticketHolder);

        var @event = tickets[0].IssuedProduct.Product.Event;
        var sealTimeHours = _configuration.GetValue<int>("OrganizationDetails:DefaultEventSealHours");
        DateTime? sendOn = @event.IsSealed
            ? @event.StartDate.AddHours(-sealTimeHours)
            : null;

        if (orderTicketPdfMessage.SendMail)
        {
            var isSealed = @event.IsSealed && @event.StartDate.AddHours(-sealTimeHours) > DateTime.UtcNow;
            var containsSwappableTickets = tickets.Any(t => t.IssuedProduct.Product.TicketOption.Swappable);

            await SendOrderPdfMailAsync(tickets[0].IssuedProduct, pdf.FileStream, orderTicketPdfMessage.Environment.FrontendBaseUrl, address, orderTicketPdfMessage.ExplicitEmail, isSealed, @event.Id, containsSwappableTickets, sendOn);
        }

        if (orderTicketPdfMessage.RegeneratePdf)
            await UploadTicketsPdfAsync(pdf.FileStream, orderTicketPdfMessage.OrderId);
    }

    private async Task SendFirstTimeBuyerOrNotYetRegisteredMailAsync(User user)
    {
        var env = await _deploymentEnvironmentService.GetAsync();
        var subject = Templates.CreateAccountForFirstTimeTicketBuyerSubject.Replace("%platformName%", _organizationDetails.PlatformName);
        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.CreateAccountForFirstTimeTicketBuyer, new CreateClientAfterTicketSaleModel
        {
            VerifyUrl = $"{env.FrontendBaseUrl}/auth/sign-up/{user.AccountVerifyId}"
        }.SetDefaultValues(subject, _organizationDetails, env.FrontendBaseUrl));

        var name = $"{user.UserContactInfo?.FirstName ?? null} {user.UserContactInfo?.LastName ?? null}";

        _mailer.Send(new()
        {
            To = new MailAddress[] { new(user.Email, !string.IsNullOrEmpty(name) ? name : null) },
            Subject = subject,
            HtmlContent = htmlContent
        });
    }

    private async Task GenerateGuestListPdfAsync(GenerateGuestListTicketPdfMessage guestListTicketPdfMessage)
    {
        var tickets = (await _issuedTicketDao.ByCodesAsync(guestListTicketPdfMessage.IssuedTicketCodes)).ToList();
        if (!tickets.Any())
            return;

        var address = GetAddress(tickets[0].IssuedProduct);
        var model = await GetPdfModelAsync(tickets, address, false);

        var pdf = await _pdfProvider.RenderPdfAsync("Product/Templates/Base", model);

        await SendGuestListPdfMailAsync(tickets[0].IssuedProduct, pdf.FileStream, guestListTicketPdfMessage.Environment.FrontendBaseUrl, address);
    }

    private async Task SendOrderPdfMailAsync(IssuedProduct issuedProduct, Stream pdf, string frontendBaseUrl, IAddressDto? address, string explicitEmail, bool sealedDelivery, Guid eventId, bool containsSwappableTickets, DateTime? sendOn = null)
    {
        var mailTemplate = await _eventMailDao.ByEventAndTypeAsync(issuedProduct.Product.EventId, EventMailType.DefaultShopMail) ?? new();
        mailTemplate.Content ??= DefaultOrderContent;

        await SendPdfMailAsync(issuedProduct, pdf, frontendBaseUrl, address, mailTemplate, false, explicitEmail, sealedDelivery, containsSwappableTickets, eventId, sendOn);
    }

    private async Task SendGuestListPdfMailAsync(IssuedProduct issuedProduct, Stream pdf, string frontendBaseUrl, IAddressDto? address)
    {
        var mailTemplate = await _eventMailDao.ByEventAndTypeAsync(issuedProduct.Product.Event.Id, EventMailType.GuestList) ?? new();
        mailTemplate.Content ??= DefaultGuestListContent;

        await SendPdfMailAsync(issuedProduct, pdf, frontendBaseUrl, address, mailTemplate, true, string.Empty, false, false);
    }

    private async Task SendPdfMailAsync(IssuedProduct issuedProduct, Stream pdf, string frontendBaseUrl, IAddressDto? address, CustomMail template, bool isGuestList, string explicitEmail, bool sealedDelivery, bool containsSwappableTickets, Guid? eventId = null, DateTime? sendOn = null)
    {
        const string firstNameTemplate = "{firstname}";
        const string lastNameTemplate = "{lastname}";

        var replacementTemplates = TemplateReplacements(firstNameTemplate, lastNameTemplate, issuedProduct, isGuestList, address);
        var purchaseMailSubject = template.Subject.IsNullOrWhitespace()
            ? Templates.ShopPurchaseSubject.Replace("%eventName%", issuedProduct.Product.Event.Name.RemoveDiacritics())
            : template.Subject.RemoveDiacritics();

        var purchaseMailHtmlContent = await PurchaseMailHtmlContentAsync(issuedProduct.Product.Event.Name, template, purchaseMailSubject, issuedProduct, frontendBaseUrl, replacementTemplates);

        var email = explicitEmail;
        if (email.IsNullOrEmpty())
            email = HolderEmail(isGuestList, issuedProduct);

        var attachments = await PdfStreamToAttachmentsAsync(pdf);

        _mailer.Send(PurchaseMail(purchaseMailSubject, email, replacementTemplates, firstNameTemplate, lastNameTemplate, template.SenderName, purchaseMailHtmlContent, attachments, sealedDelivery));

        if (sealedDelivery && sendOn != null)
        {
            var sealedMailTemplate = await _eventMailDao.ByEventAndTypeAsync(issuedProduct.Product.EventId, EventMailType.SealedTicketsMail) ?? new();
            sealedMailTemplate.Content ??= DefaultSealedTicketContent;

            var sealedMailSubject = sealedMailTemplate.Subject.IsNullOrWhitespace()
                ? Templates.SealedTicketsSubject.Replace("%eventName%", issuedProduct.Product.Event.Name.RemoveDiacritics())
                : template.Subject.RemoveDiacritics();

            var sealedTicketsHtmlContent = await SealedTicketsHtmlContentAsync(issuedProduct.Product.Event.Name, sealedMailTemplate, sealedMailSubject, frontendBaseUrl, replacementTemplates, (Guid)issuedProduct.OrderId!, containsSwappableTickets);

            _mailer.Send(SealedMail(sealedMailSubject, email, replacementTemplates, firstNameTemplate, lastNameTemplate, sealedMailTemplate.SenderName, sealedTicketsHtmlContent, attachments, sendOn, eventId));
        }

        if (issuedProduct.OrderId != null)
        {
            var hasOrderTicketsFile = await _orderDao.OrderTicketsFileExists((Guid)issuedProduct.OrderId);

            if (!hasOrderTicketsFile)
                await UploadTicketsPdfAsync(pdf, (Guid)issuedProduct.OrderId);
        }
    }

    private static Dictionary<string, Func<string>> TemplateReplacements(string firstNameTemplate, string lastNameTemplate, IssuedProduct issuedProduct, bool isGuestList, IAddressDto? address)
    {
        return new()
        {
            { firstNameTemplate, () => isGuestList ? issuedProduct.IssuedTicket.Holder?.FirstName ?? string.Empty : issuedProduct.Order.ClientOrder.FirstName },
            { lastNameTemplate, () => isGuestList ? issuedProduct.IssuedTicket.Holder?.LastName ?? string.Empty : issuedProduct.Order.ClientOrder.LastName },
            { "{age}", () => $"{issuedProduct.Order?.ClientOrder.Birthdate?.ToDateOnly().GetAge(issuedProduct.Product.Event.StartDate.ToDateOnly())}" },
            { "{event-name}", () => issuedProduct.Product.Event.Name.RemoveDiacritics() },
            { "{event-start-date}", () => DateTimeUtils.ConvertToTimezone(issuedProduct.Product.Event.StartDate, issuedProduct.Product.Event.TimezoneIdentification).ToString(DateFormat.YearMonthDayHourMinuteSecond) },
            { "{event-end-date}", () => DateTimeUtils.ConvertToTimezone(issuedProduct.Product.Event.EndDate, issuedProduct.Product.Event.TimezoneIdentification).ToString(DateFormat.YearMonthDayHourMinuteSecond) },
            { "{location}", () => address == null ? string.Empty : GetFormattedAddress(address) }
        };
    }

    private static string HolderEmail(bool isGuestList, IssuedProduct issuedProduct) =>
        isGuestList
            ? issuedProduct.IssuedTicket.Holder.Email
            : issuedProduct.Order.ClientOrder.Client.User.Email;

    private static async Task<Attachment[]> PdfStreamToAttachmentsAsync(Stream pdfStream) =>
    [
        new("tickets.pdf",
            "application/pdf",
            await pdfStream.ToBase64Async())
    ];

    /// <summary>
    /// Creates the HTML for the sealed tickets delivery mail.
    /// </summary>
    /// <param name="eventName"></param>
    /// <param name="template"></param>
    /// <param name="subject"></param>
    /// <param name="frontendBaseUrl"></param>
    /// <param name="templates"></param>
    /// <param name="orderId"></param>
    /// <param name="containsSwappableTickets"></param>
    /// <returns></returns>
    private async Task<string> SealedTicketsHtmlContentAsync(string eventName, CustomMail template, string subject, string frontendBaseUrl, Dictionary<string, Func<string>> templates, Guid orderId, bool containsSwappableTickets)
    {
        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.SealedTickets, new SealedTicketsModel
        {
            EventName = eventName,
            MailContent = template.Content,
            MailPreview = subject,
            HeaderImageUrl = null,
            TicketSwapSaleUrl = containsSwappableTickets
                ? $"https://www.ticketswap.com/sell/tickets/{_organizationDetails.PlatformName}/{orderId}"
                : null
        }.SetDefaultValues(subject, _organizationDetails, frontendBaseUrl));

        foreach (var (key, value) in templates)
            htmlContent = htmlContent.Replace(key, value());

        return htmlContent;
    }

    /// <summary>
    /// Creates the HTML for the purchase email.
    /// Todo: once supported fill the following (FAN-1036) (header-footer images)
    /// </summary>
    /// <param name="eventName"></param>
    /// <param name="template"></param>
    /// <param name="subject"></param>
    /// <param name="issuedProduct"></param>
    /// <param name="frontendBaseUrl"></param>
    /// <param name="templates"></param>
    /// <returns></returns>
    private async Task<string> PurchaseMailHtmlContentAsync(string eventName, CustomMail template, string subject, IssuedProduct issuedProduct, string frontendBaseUrl, Dictionary<string, Func<string>> templates)
    {
        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, new PurchaseModel
        {
            EventName = eventName,
            MailContent = template.Content,
            MailPreview = subject,
            ReceiptUrl = $"{frontendBaseUrl}/order/{issuedProduct.OrderId}",
            EventSupportMailAddress = (await _organizationDao.ContactAsync(issuedProduct.Product.Event.OrganizationId, ContactInfoRole.CustomerSupport))?.Email
                                      ?? issuedProduct.Product.Event.Organization.User.Email,
            HeaderImageUrl = null,
            FooterImageUrl = null,
            IsGuestTicket = issuedProduct.Type == IssuedProductType.GuestTicket
        }.SetDefaultValues(subject, _organizationDetails, frontendBaseUrl));

        foreach (var (key, value) in templates)
            htmlContent = htmlContent.Replace(key, value());

        return htmlContent;
    }

    private static Mail SealedMail(string subject, string email, Dictionary<string, Func<string>> templates, string firstNameTemplate, string lastNameTemplate, string senderName, string htmlContent, Attachment[] attachments, DateTime? sendOn, Guid? eventId)
    {
        return new()
        {
            Subject = subject,
            To = new MailAddress[] { new(email, $"{templates[firstNameTemplate]()} {templates[lastNameTemplate]()}") },
            From = string.IsNullOrWhiteSpace(senderName) ? null : new(null, senderName.RemoveDiacritics()),
            Provider = WebApiCore.Dtos.MailProvider.Provider.Default,
            HtmlContent = htmlContent,
            Attachments = attachments,
            SendOn = sendOn,
            EventId = eventId
        };
    }

    private static Mail PurchaseMail(string subject, string email, Dictionary<string, Func<string>> templates, string firstNameTemplate, string lastNameTemplate, string senderName, string htmlContent, Attachment[] attachments, bool sealedDelivery)
    {
        var purchaseMail = new Mail
        {
            Subject = subject,
            To = new MailAddress[] { new(email, $"{templates[firstNameTemplate]()} {templates[lastNameTemplate]()}") },
            From = string.IsNullOrWhiteSpace(senderName) ? null : new(null, senderName.RemoveDiacritics()),
            Provider = WebApiCore.Dtos.MailProvider.Provider.Default,
            HtmlContent = htmlContent
        };

        //Do not send attachment with tickets for sealed event
        if (!sealedDelivery)
            purchaseMail.Attachments = attachments;

        return purchaseMail;
    }

    private async Task UploadTicketsPdfAsync(Stream pdf, Guid orderId)
    {
        await _uploadService.UploadAsync(pdf, IStorageService.TicketPdfStoragePool, null, "pdf", MediaTypeNames.Application.Pdf, null, false, await _deploymentEnvironmentService.GetAsync(), async file => await _orderDao.InsertOrderTicketsFileAsync(orderId, file));
    }

    private async Task UploadTicketsPdfAsync(Stream pdf, string previousTicketCode, string swappedTicketCode)
    {
        await _uploadService.UploadAsync(pdf, IStorageService.TicketPdfStoragePool, null, "pdf", MediaTypeNames.Application.Pdf, null, false, await _deploymentEnvironmentService.GetAsync(), async file => await _issuedTicketDao.InsertSwappedTicketAsync(previousTicketCode, swappedTicketCode, file));
    }

    private async Task<GridTicketPdfModel> GetPdfModelAsync(IList<IssuedTicket> issuedTickets, IAddressDto? address, bool showPricing)
    {
        var entries = new List<TicketEntryInfoModel>();
        foreach (var issuedTicket in issuedTickets)
            entries.Add(await TicketEntryInfoModelAsync(issuedTicket, issuedTickets[0].IssuedProduct, showPricing));

        return new()
        {
            EventName = issuedTickets[0].IssuedProduct.Product.Event.Name,
            OrderDate = issuedTickets[0].IssuedProduct.Order?.CreatedAt.ToString(DateFormat.YearMonthDay) ?? string.Empty,
            Address = address,
            PlatformName = _organizationDetails.PlatformName,
            OrganizationWebsite = _organizationDetails.Website,
            OrganizationSupportEmail = _organizationDetails.SupportEmail,
            TicketEntryInfos = entries
        };
    }

    private async Task<TicketEntryInfoModel> TicketEntryInfoModelAsync(IssuedTicket issuedTicket, IssuedProduct firstProduct, bool showPricing)
    {
        var model = issuedTicket.IssuedProduct.ToGridTicketEntryInfoModel(firstProduct.Product.Event.TimezoneIdentification);

        var designElements = issuedTicket.IssuedProduct.Product.TicketOption?.Design?.DesignElements ?? GetDefaultTicketDesign();

        foreach (var designElement in designElements)
        {
            var elementTask = designElement switch
            {
                TicketDesignQrElement qr => CreateQrContainerModel(qr, issuedTicket, firstProduct, showPricing),
                TicketDesignMediaElement media => CreateMediaContainerModel(media),
                TicketDesignUpcomingEventsElement upcoming => CreateUpcomingEventsContainerModel(firstProduct.Product.Event.OrganizationId, upcoming, firstProduct.Product.EventId),
                _ => null
            };

            if (elementTask == null)
                continue;

            model.Elements.Add(await elementTask);
        }

        return model;
    }

    private async Task<TicketElement> CreateQrContainerModel(TicketDesignQrElement qrElement, IssuedTicket issuedTicket, IssuedProduct firstProduct, bool showPricing)
    {
        if (qrElement.File != null)
            qrElement.File.Path = qrElement.File.Path.ReplaceFirst("uploads/ticketdesigns/", string.Empty);

        var logo = qrElement.File == null
            ? null
            : await _downloadService.Base64Async(IStorageService.ProductMediaStoragePool, qrElement.File, true);

        var contract = await _contractDao.ContractFeeAsync(issuedTicket.IssuedProduct.Product.Event.OrganizationId, issuedTicket.IssuedProduct.CreatedOn) ??
                       throw new ContractNotFoundException(issuedTicket.IssuedProduct.CreatedOn);

        return qrElement.GetQrContainerModel(issuedTicket, firstProduct, showPricing, contract, logo);
    }

    private async Task<TicketElement> CreateUpcomingEventsContainerModel(Guid organizationId, TicketDesignUpcomingEventsElement upcomingElement, Guid excludedEventId) =>
        upcomingElement.GetUpcomingEventsContainerModel(await _eventDao.UpcomingAsync(organizationId, upcomingElement.Amount, new[] { excludedEventId }));

    private async Task<TicketElement> CreateMediaContainerModel(TicketDesignMediaElement mediaElement)
    {
        mediaElement.File.Path = mediaElement.File.Path.ReplaceFirst("uploads/ticketdesigns/", string.Empty);

        var base64Image = await _downloadService.Base64Async(IStorageService.TicketDesignMediaStoragePool, mediaElement.File, true);
        var focalPoint = await FocalPointAsync(mediaElement.FileId);

        return mediaElement.GetMediaContainerModel(base64Image, focalPoint.X, focalPoint.Y);
    }

    private async Task<FocalPoint> FocalPointAsync(Guid fileId)
    {
        if (_focusPointCache.TryGetValue(fileId, out var focalPoint))
            return focalPoint;

        focalPoint = await _ticketDesignDao.MediaFocalPointAsync(fileId) ?? new FocalPoint { X = 50, Y = 50 };
        _focusPointCache[fileId] = focalPoint;

        return focalPoint;
    }

    private static IAddressDto? GetAddress(IssuedProduct issuedProduct) => issuedProduct.Product.Event.Address?.ToAddress();

    private static IEnumerable<TicketDesignElement> GetDefaultTicketDesign() =>
        new TicketDesignElement[]
        {
            new TicketDesignQrElement
            {
                Column = 3,
                Row = 4,
                RowSpan = 1,
                ColumnSpan = 1
            }
        };
}