﻿using WebApiCore.MessageBus.Messages.Pdf;

namespace PdfService.Services;

public interface IPdfService
{
    /// <summary>
    /// Gets the message type that the PdfService can accept.
    /// </summary>
    /// <returns></returns>
    public Type GetMessageType();

    /// <summary>
    /// Generates a pdf for the given message.
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public Task GeneratePdfAsync(IGeneratePdfMessage message);
}