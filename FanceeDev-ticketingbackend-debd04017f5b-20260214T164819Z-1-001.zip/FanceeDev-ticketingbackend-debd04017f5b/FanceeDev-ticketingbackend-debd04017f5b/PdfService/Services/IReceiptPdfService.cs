namespace PdfService.Services;

public interface IReceiptPdfService
{
    /// <summary>
    /// Deletes expired order receipts.
    /// </summary>
    /// <returns></returns>
    public Task DeleteExpiredOrderReceiptsAsync();
}