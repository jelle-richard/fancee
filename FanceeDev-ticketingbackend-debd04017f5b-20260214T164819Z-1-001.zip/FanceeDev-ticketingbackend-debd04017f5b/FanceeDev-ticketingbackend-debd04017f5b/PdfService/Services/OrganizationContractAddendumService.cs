using System.Net.Mime;
using MailTemplates.Models.User.Organization;
using MailTemplates.Templates;
using Microsoft.AspNetCore.Mvc;
using PdfService.Models.Organization;
using PdfService.Persistence.Organization;
using PdfService.Persistence.Shop;
using PdfService.Provider.Pdf;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Services.Cache;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using WebApiCore.Utils.Mail;
using WebApiCore.Utils.String;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Services;

public class OrganizationContractAddendumService : IPdfService
{
    private readonly IPdfProvider _pdfProvider;
    private readonly IOrganizationContractDao _organizationContractDao;
    private readonly IOrganizationContractAddendumDao _organizationContractAddendumDao;
    private readonly IMailer _mailer;
    private readonly IConfiguration _configuration;
    private readonly IUploadService _uploadService;
    private readonly IDeploymentEnvironmentService _deploymentEnvironmentService;
    private readonly IShopDao _shopDao;
    private readonly IShopCacheService _shopCacheService;

    public OrganizationContractAddendumService(IPdfProvider pdfProvider, IOrganizationContractDao organizationContractDao, IOrganizationContractAddendumDao organizationContractAddendumDao, IMailer mailer, IConfiguration configuration, IUploadService uploadService, IDeploymentEnvironmentService deploymentEnvironmentService, IShopDao shopDao, IShopCacheService shopCacheService)
    {
        _pdfProvider = pdfProvider;
        _organizationContractDao = organizationContractDao;
        _organizationContractAddendumDao = organizationContractAddendumDao;
        _mailer = mailer;
        _configuration = configuration;
        _uploadService = uploadService;
        _deploymentEnvironmentService = deploymentEnvironmentService;
        _shopDao = shopDao;
        _shopCacheService = shopCacheService;
    }

    public Type GetMessageType() => typeof(GenerateOrganizationContractAddendumMessage);

    public async Task GeneratePdfAsync(IGeneratePdfMessage message)
    {
        if (message is not GenerateOrganizationContractAddendumMessage addendumMsg)
            return;

        var contract = await _organizationContractDao.RetrieveOrganizationContractAsync(addendumMsg.OrganizationId);
        if (contract == null)
            return;

        var platformSettings = OrganizationDetailsSettings.FromConfiguration(_configuration);
        var addendumWrapModel = new OrganizationContractAddendumWrapModel
        {
            PlatformSettings = platformSettings,
            Title = $"{platformSettings.Name} Contract Addendum",
            PackageType = contract.PackageType,
            Start = addendumMsg.Start,
            End = addendumMsg.End,
            Text = addendumMsg.Text,
            Contract = contract
        };

        var pdfStream = await _pdfProvider.RenderPdfAsync("Contract/Addendum", addendumWrapModel);
        var base64 = await pdfStream.FileStream.ToBase64Async();
        var environment = await _deploymentEnvironmentService.GetAsync();

        await UploadContractAddendum(pdfStream, addendumMsg, environment);
        await MailContractAddendumAsync(addendumWrapModel, base64, environment.FrontendBaseUrl);
        await ClearShopCacheOfOrganization(addendumMsg.OrganizationId);
    }

    private async Task MailContractAddendumAsync(OrganizationContractAddendumWrapModel addendumWrapModel, string contractAddendumPdfBase64, string frontendBaseUrl)
    {
        var name = $"{addendumWrapModel.Contract.Organization.User.UserContactInfo.FirstName} {addendumWrapModel.Contract.Organization.User.UserContactInfo.LastName}";
        var subject = Templates.ContractAddendumSubject.Replace("%platformName%", addendumWrapModel.PlatformSettings.Name);
        var htmlContent = await _mailer.ViewRenderer.RenderViewAsync(Templates.ContractAddendum, new ContractModel
        {
            Name = name
        }.SetDefaultValues(subject, addendumWrapModel.PlatformSettings, frontendBaseUrl));

        _mailer.Send(new()
        {
            Subject = subject,
            To = new MailAddress[] { new(addendumWrapModel.Contract.Organization.User.Email, name) },
            HtmlContent = htmlContent,
            Attachments = new Attachment[]
            {
                new("ContractAddendum.pdf", "application/pdf", contractAddendumPdfBase64)
            }
        });
    }

    private async Task UploadContractAddendum(FileStreamResult pdfStream, GenerateOrganizationContractAddendumMessage addendumMsg, HostedDeploymentEnvironment environment)
    {
        await _uploadService.UploadAsync(
            pdfStream.FileStream,
            IStorageService.ContractAddendaStoragePool,
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            environment,
            async file => await InsertContractAddendumFileAsync(file, addendumMsg)
        );
    }

    private async Task InsertContractAddendumFileAsync(File file, GenerateOrganizationContractAddendumMessage message)
    {
        await _organizationContractAddendumDao.InsertAddendumAsync(new()
        {
            OrganizationId = message.OrganizationId,
            Start = message.Start,
            End = message.End,
            Text = message.Text,
            File = file,
            CreatedAt = DateTime.UtcNow
        });
    }

    private async Task ClearShopCacheOfOrganization(Guid organizationId)
    {
        var organizationShopCodes = await _shopDao.ShopCodesByOrganizationIdAsync(organizationId);
        foreach (var shopCode in organizationShopCodes)
            await _shopCacheService.RemoveShopCacheAsync(shopCode);
    }
}