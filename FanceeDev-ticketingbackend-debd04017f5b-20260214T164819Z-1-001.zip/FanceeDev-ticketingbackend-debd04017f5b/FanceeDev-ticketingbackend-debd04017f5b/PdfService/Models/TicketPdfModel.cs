using PdfService.Models.Views;
using WebApiCore.Dtos.Shared.Address;

namespace PdfService.Models;

public abstract class TicketPdfModel
{
    public abstract string ViewName { get; }
    public string EventName { get; init; } = default!;
    public string OrderDate { get; init; } = default!;
    public string PlatformName { get; init; } = default!;
    public string OrganizationWebsite { get; init; } = default!;
    public string OrganizationSupportEmail { get; init; } = default!;
    public IAddressDto? Address { get; init; }
    public IEnumerable<TicketEntryInfoModel> TicketEntryInfos { get; init; } = Enumerable.Empty<TicketEntryInfoModel>();

    public bool HasAddress() => !(string.IsNullOrEmpty(Address?.Venue)
                                  && string.IsNullOrEmpty(Address?.CountryCode)
                                  && string.IsNullOrEmpty(Address?.PostalCode)
                                  && string.IsNullOrEmpty(Address?.City)
                                  && string.IsNullOrEmpty(Address?.Street)
                                  && string.IsNullOrEmpty(Address?.HouseNumber));
}