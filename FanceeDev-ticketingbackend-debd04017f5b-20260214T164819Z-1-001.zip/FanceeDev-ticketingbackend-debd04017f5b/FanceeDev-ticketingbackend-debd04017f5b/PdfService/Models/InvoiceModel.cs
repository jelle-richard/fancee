using FanceeData.Models.Ticketing.Invoicing;

namespace PdfService.Models;

public class InvoiceModel : LetterheadModel
{
    public required Invoice Invoice { get; set; }
}