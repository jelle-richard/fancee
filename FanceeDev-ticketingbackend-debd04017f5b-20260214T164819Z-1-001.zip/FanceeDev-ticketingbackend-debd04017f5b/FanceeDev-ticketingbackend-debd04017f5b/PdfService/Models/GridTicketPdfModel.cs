namespace PdfService.Models;

public class GridTicketPdfModel : TicketPdfModel
{
    public override string ViewName => "Grid";
}