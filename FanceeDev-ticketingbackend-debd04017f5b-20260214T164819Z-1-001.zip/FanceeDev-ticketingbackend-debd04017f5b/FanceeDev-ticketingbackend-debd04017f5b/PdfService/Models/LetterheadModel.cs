using WebApiCore.Settings;

namespace PdfService.Models;

public abstract class LetterheadModel
{
    public OrganizationDetailsSettings PlatformSettings { get; set; } = default!;
    public string? Title { get; set; }
}