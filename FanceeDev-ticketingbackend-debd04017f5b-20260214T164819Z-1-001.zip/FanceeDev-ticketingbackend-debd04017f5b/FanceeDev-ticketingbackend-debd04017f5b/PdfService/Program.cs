using PdfService.BackgroundTasks.MessageBus;
using PdfService.Persistence.Event;
using PdfService.Persistence.Invoice;
using PdfService.Persistence.IssuedTicket;
using PdfService.Persistence.Order;
using PdfService.Persistence.Organization;
using PdfService.Persistence.Shop;
using PdfService.Persistence.Ticket;
using PdfService.Persistence.User;
using PdfService.Persistence.WalletPayment;
using PdfService.Provider.Pdf;
using PdfService.Services;
using WebApiCore;
using WebApiCore.Services.Currency;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "PdfService",
        EndpointName = "PdfService v1"
    },
    UseAuthenticationAndAuthorization = false,
    UseSignalR = false
};

builder.AddDependency<IPdfProvider, PuppeteerPdfProvider>(ServiceLifetime.Scoped);
builder.AddDependency<IPdfService, InvoicePdfService>(ServiceLifetime.Scoped);
builder.AddDependency<IPdfService, TicketPdfService>(ServiceLifetime.Scoped);
builder.AddDependency<IPdfService, ReceiptPdfService>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketPdfService, TicketPdfService>(ServiceLifetime.Scoped);
builder.AddDependency<IPdfService, OrganizationContractService>(ServiceLifetime.Scoped);
builder.AddDependency<IPdfService, PayoutReceiptPdfService>(ServiceLifetime.Scoped);
builder.AddDependency<IPdfService, OrganizationContractAddendumService>(ServiceLifetime.Scoped);
builder.AddDependency<IInvoiceDao, InvoiceDao>(ServiceLifetime.Scoped);
builder.AddDependency<IIssuedTicketDao, IssuedTicketDao>(ServiceLifetime.Scoped);
builder.AddDependency<IWalletPaymentDao, WalletPaymentDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationDao, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationContractAddendumDao, OrganizationContractAddendumDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationContractDao, OrganizationContractDao>(ServiceLifetime.Scoped);
builder.AddDependency<WebApiCore.Persistence.User.Organization.IOrganizationDao, WebApiCore.Persistence.User.Organization.OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopMailDao, ShopMailDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrderDao, OrderDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventMailDao, EventMailDao>(ServiceLifetime.Scoped);
builder.AddDependency<IDownloadService, DownloadService>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);
builder.AddDependency<ITicketDesignDao, TicketDesignDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICurrencyService, CurrencyService>(ServiceLifetime.Scoped);
builder.AddDependency<IUserDao, UserDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDao, ShopDao>(ServiceLifetime.Scoped);

builder.AddDependency(x => new GeneratePdfListener(x), ServiceLifetime.Singleton);
builder.AddDependency(x => new DeleteTicketPdfsListener(x), ServiceLifetime.Singleton);

builder.AddHostedService<GeneratePdfListener>();
builder.AddHostedService<DeleteTicketPdfsListener>();

var app = builder.Build();
app.Run();