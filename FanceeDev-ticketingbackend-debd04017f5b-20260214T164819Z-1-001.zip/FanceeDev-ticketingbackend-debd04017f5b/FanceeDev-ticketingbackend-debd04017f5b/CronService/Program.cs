using CronService.BackgroundTasks.Cron;
using CronService.BackgroundTasks.Job;
using WebApiCore;
using WebApiCore.Exceptions;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    UseAuthenticationAndAuthorization = false,
    UseS3Storage = false
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddScheduler(sb =>
    {
        sb.AddJob<CreateInvoicesJob>(configure: options =>
        {
            options.CronSchedule = builder.Configuration.GetValue<string>("CronIntervals:CreateInvoices") ?? throw new MissingRequiredConfigurationEntryException("CronIntervals", "CreateInvoices");
            options.RunImmediately = false;
            options.CronTimeZone = TimeZoneInfo.Utc.Id;
        });

        sb.AddJob<RefreshExactTokenJob>(configure: options =>
        {
            options.CronSchedule = builder.Configuration.GetValue<string>("CronIntervals:RefreshExactToken") ?? throw new MissingRequiredConfigurationEntryException("CronIntervals", "RefreshExactToken");
            options.RunImmediately = false;
            options.CronTimeZone = TimeZoneInfo.Utc.Id;
        });
    });
};

builder.AddDependency(sp => new Cron<SendMailQueueCronJob>(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new Cron<UpdateCurrencyExchangeRatesCronJob>(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new Cron<UnlockReservedProductsCronJob>(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new Cron<ConcludeEventsCronJob>(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new Cron<DeleteTicketPdfsCronJob>(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new CreateInvoicesJob(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new RefreshExactTokenJob(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new Cron<CleanShopViewsInCacheCronJob>(sp), ServiceLifetime.Singleton);
builder.AddDependency(sp => new Cron<RemoveSentMailsCronJob>(sp), ServiceLifetime.Singleton);

builder.AddHostedService<Cron<SendMailQueueCronJob>>();
builder.AddHostedService<Cron<UpdateCurrencyExchangeRatesCronJob>>();
builder.AddHostedService<Cron<UnlockReservedProductsCronJob>>();
builder.AddHostedService<Cron<ConcludeEventsCronJob>>();
builder.AddHostedService<Cron<DeleteTicketPdfsCronJob>>();
builder.AddHostedService<Cron<CleanShopViewsInCacheCronJob>>();
builder.AddHostedService<Cron<RemoveSentMailsCronJob>>();

var app = builder.Build();
app.Run();