﻿namespace CronService.Utils;

public static class TimeSpanUtils
{
    /// <summary>
    /// Tries to get the <see cref="TimeSpan" /> value from the configuration.
    /// Returns <see cref="defaultValue" /> on failure.
    /// </summary>
    /// <param name="configuration"></param>
    /// <param name="key"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static TimeSpan GetTimeSpan(this IConfiguration? configuration, string key, TimeSpan defaultValue)
    {
        try
        {
            return configuration?.GetValue(key, defaultValue) ?? defaultValue;
        }
        catch (Exception)
        {
            return defaultValue;
        }
    }
}