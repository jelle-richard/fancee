using PdfService.Models;

namespace PdfService.Tests.Models;

public class GridTicketPdfModelTests
{
    private readonly GridTicketPdfModel _sut = new();

    [Fact]
    public void TestThatViewNameReturnsCorrectViewName()
    {
        Assert.Equal("Grid", _sut.ViewName);
    }
}