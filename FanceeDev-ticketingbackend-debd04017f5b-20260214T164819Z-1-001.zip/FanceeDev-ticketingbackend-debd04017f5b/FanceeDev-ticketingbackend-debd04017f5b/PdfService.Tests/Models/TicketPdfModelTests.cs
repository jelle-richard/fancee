using PdfService.Models;

namespace PdfService.Tests.Models;

public class TicketPdfModelTests
{
    private readonly TicketPdfModel _sut;

    public TicketPdfModelTests()
    {
        _sut = new UnitTicketPdfModel();
    }

    [Fact]
    public void TestThatHasAddressReturnsFalseIfAddressIsNull()
    {
        Assert.False(_sut.HasAddress());
    }

    [Theory]
    [InlineData(null, null, null, null, null, null, false)]
    [InlineData("unit", null, null, null, null, null, true)]
    [InlineData(null, "unit", null, null, null, null, true)]
    [InlineData(null, null, "unit", null, null, null, true)]
    [InlineData(null, null, null, "unit", null, null, true)]
    [InlineData(null, null, null, null, "unit", null, true)]
    [InlineData(null, null, null, null, null, "unit", true)]
    public void TestThatHasAddressReturnsExpectedResult(string? venue, string? countryCode, string? postalCode, string? city, string? street, string? houseNumber, bool expected)
    {
        var sut = new UnitTicketPdfModel
        {
            Address = new Address
            {
                Venue = venue,
                CountryCode = countryCode,
                PostalCode = postalCode,
                City = city,
                Street = street,
                HouseNumber = houseNumber
            }
        };

        Assert.Equal(expected, sut.HasAddress());
    }

    #region Unit Test Classes

    public class UnitTicketPdfModel : TicketPdfModel
    {
        public override string ViewName => "Unit Test";
    }

    #endregion
}