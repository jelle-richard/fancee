using PdfService.Models.Views;

namespace PdfService.Tests.Models.Views;

public class TicketElementTests
{
    [Fact]
    public void TestThatGridPositionStyleGetsCssGrid()
    {
        var sut = new UnitTestElement
        {
            Column = 2,
            Row = 3,
            ColumnSpan = 4,
            RowSpan = 5
        };

        Assert.Equal("grid-column: 2 / span 4; grid-row: 3 / span 5;", sut.GridPositionStyle);
    }

    #region Unit Test Classes

    private class UnitTestElement : TicketElement
    {
    }

    #endregion
}