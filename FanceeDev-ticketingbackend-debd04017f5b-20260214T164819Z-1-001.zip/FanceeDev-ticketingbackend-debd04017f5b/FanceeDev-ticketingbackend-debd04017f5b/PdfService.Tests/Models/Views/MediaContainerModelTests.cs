using PdfService.Models.Views;

namespace PdfService.Tests.Models.Views;

public class MediaContainerModelTests
{
    private readonly MediaContainerModel _sut;

    public MediaContainerModelTests()
    {
        _sut = new();
    }

    [Fact]
    public void TestThatImageSourceReturnsCssDataSource()
    {
        _sut.Base64Media = "test";

        Assert.Equal("data:;base64,test", _sut.ImageSource);
    }

    [Fact]
    public void TestThatPositionReturnsCssBackgroundPosition()
    {
        _sut.FocalPointX = 19;
        _sut.FocalPointY = 98;

        Assert.Equal("background-position: 19% 98%;", _sut.Position);
    }
}