﻿using PdfService.Provider.Pdf;
using PdfService.Utils.Adapter;
using PuppeteerSharp.Media;

namespace PdfService.Tests.Utils.Adapter;

public class PuppeteerPdfAdapterTests
{
    public static readonly object[][] ToPaperFormatTestData =
    {
        new object[] { PageSize.A3, PaperFormat.A3 },
        new object[] { PageSize.A4, PaperFormat.A4 },
        new object[] { PageSize.A5, PaperFormat.A5 },
        new object[] { PageSize.A6, PaperFormat.A6 },
        new object[] { PageSize.Legal, PaperFormat.Legal },
        new object[] { PageSize.Letter, PaperFormat.Letter }
    };

    [Theory]
    [MemberData(nameof(ToPaperFormatTestData))]
    public void TestThatToSizeMapsTheCorrectPageSize(PageSize pageSize, PaperFormat expected)
    {
        var actual = pageSize.ToPaperFormat();

        Assert.Equal(expected, actual);
    }
}