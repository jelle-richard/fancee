using System;
using System.Linq;
using FanceeData.Models.Ticketing;
using PdfService.Utils.Adapter;
using WebApiCore.Dtos.Shared.Contract;
using WebApiCore.Utils;

namespace PdfService.Tests.Utils.Adapter;

public class TicketEntryInfoModelAdapterTests
{
    private const string UnitTimezone = "Europe/Amsterdam";

    private static readonly ContractFee ContractFee = new()
    {
        PeriodStart = DateTime.UtcNow.AddDays(-39),
        PeriodEnd = DateTime.UtcNow.AddDays(55),
        ProductFeeCents = 83,
        ProductFeePercentage = 2,
        TicketFeeCents = 83,
        TicketFeePercentage = 2,
        SeatedTicketFeeCents = 0,
        SeatedTicketFeePercentage = 0,
        GuestListFeeCents = 20
    };

    private static readonly IssuedProduct ValidIssuedProduct = new()
    {
        Type = IssuedProductType.PlatformTicket,
        Product = new()
        {
            Name = "UnitProduct",
            PriceCents = 1234,
            PackQuantity = 1,
            FeeCents = null,
            Event = new()
            {
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddHours(1),
                Name = "UnitEvent",
                Organization = new()
                {
                    Contract = new()
                    {
                        TicketFeeCents = 89
                    }
                }
            },
            PriceHistories = Array.Empty<ProductPriceHistory>(),
            TicketOption = new()
            {
                PartialAccessEnd = null,
                PartialAccessStart = null
            }
        },
        Order = new()
        {
            CreatedAt = DateTime.UtcNow.AddDays(-10),
            CurrencyNavigation = new()
            {
                Character = "€",
                ShortCode = "EUR"
            }
        }
    };

    private static readonly IssuedTicket ValidIssuedTicket = new()
    {
        Code = "TestCode",
        IssuedProduct = ValidIssuedProduct,
        Holder = new()
        {
            FirstName = "Unit",
            LastName = "Teset"
        }
    };

    [Fact]
    public void TestThatToGridTicketEntryInfoModelReturnsGridTicketEntryInfoModelWithoutElements()
    {
        var actual = ValidIssuedProduct.ToGridTicketEntryInfoModel(UnitTimezone);

        Assert.Equal(DateTimeUtils.ConvertToTimezone(ValidIssuedProduct.Product.Event.StartDate, "Europe/Amsterdam"), actual.StartDate);
        Assert.Equal(DateTimeUtils.ConvertToTimezone(ValidIssuedProduct.Product.Event.EndDate, "Europe/Amsterdam"), actual.EndDate);
        Assert.Empty(actual.Elements);
    }

    [Fact]
    public void TestThatToGridTicketEntryInfoModelUsesPartialAccessWhenAvailable()
    {
        var partialStart = DateTime.UtcNow.AddHours(-1);
        var partialEnd = DateTime.UtcNow.AddHours(3);

        ValidIssuedProduct.Product.TicketOption.PartialAccessStart = partialStart;
        ValidIssuedProduct.Product.TicketOption.PartialAccessEnd = partialEnd;

        var actual = ValidIssuedProduct.ToGridTicketEntryInfoModel(UnitTimezone);
        Assert.Equal(DateTimeUtils.ConvertToTimezone(partialStart, "Europe/Amsterdam"), actual.StartDate);
        Assert.Equal(DateTimeUtils.ConvertToTimezone(partialEnd, "Europe/Amsterdam"), actual.EndDate);
    }

    [Fact]
    public void TestThatGetQrContainerModelMapsTicketDesignQrElementToQrContainerModel()
    {
        var element = new TicketDesignQrElement
        {
            Column = 3,
            Row = 2,
            ColumnSpan = 2,
            RowSpan = 5
        };

        var actual = element.GetQrContainerModel(ValidIssuedTicket, ValidIssuedProduct, true, ContractFee, null);

        Assert.Equal(3, actual.Column);
        Assert.Equal(2, actual.ColumnSpan);
        Assert.Equal(2, actual.Row);
        Assert.Equal(5, actual.RowSpan);
        Assert.Equal("TestCode", actual.Barcode);
        Assert.Null(actual.QrLogo);
        Assert.Equal("UnitProduct", actual.TicketName);
        Assert.Equal("€", actual.CurrencySymbol);
        Assert.Equal(1234, actual.TicketPriceCents);
        Assert.Equal(108, actual.TicketFeeCents);
    }

    [Fact]
    public void TestThatGetQrContainerModelMapsTicketDesignQrElementToQrContainerModelWithGuestHighlightForGuestTickets()
    {
        var element = new TicketDesignQrElement
        {
            Column = 3,
            Row = 2,
            ColumnSpan = 2,
            RowSpan = 5
        };

        ValidIssuedTicket.IssuedProduct.Type = IssuedProductType.GuestTicket;
        var actual = element.GetQrContainerModel(ValidIssuedTicket, ValidIssuedProduct, true, ContractFee, null);

        Assert.Equal(3, actual.Column);
        Assert.Equal(2, actual.ColumnSpan);
        Assert.Equal(2, actual.Row);
        Assert.Equal(5, actual.RowSpan);
        Assert.Equal("TestCode", actual.Barcode);
        Assert.Null(actual.QrLogo);
        Assert.Equal("Guest - UnitProduct", actual.TicketName);
        Assert.Equal("€", actual.CurrencySymbol);
        Assert.Equal(1234, actual.TicketPriceCents);
        Assert.Equal(108, actual.TicketFeeCents);
    }

    [Fact]
    public void TestThatGetQrContainerModelMapsTicketDesignQrElementToQrContainerModelForGuestList()
    {
        var element = new TicketDesignQrElement
        {
            Column = 1,
            Row = 1,
            ColumnSpan = 1,
            RowSpan = 1
        };

        ValidIssuedTicket.IssuedProduct.Type = IssuedProductType.PlatformTicket;
        var actual = element.GetQrContainerModel(ValidIssuedTicket, ValidIssuedProduct, false, ContractFee, null);

        Assert.Equal(1, actual.Column);
        Assert.Equal(1, actual.ColumnSpan);
        Assert.Equal(1, actual.Row);
        Assert.Equal(1, actual.RowSpan);
        Assert.Equal("TestCode", actual.Barcode);
        Assert.Null(actual.QrLogo);
        Assert.Equal("UnitProduct", actual.TicketName);
        Assert.Null(actual.CurrencySymbol);
        Assert.Null(actual.TicketPriceCents);
        Assert.Null(actual.TicketFeeCents);
    }

    [Fact]
    public void TestThatGetMediaContainerModelMapsTicketDesignMediaElementToMediaContainerModel()
    {
        const string base64Image = "content";
        var element = new TicketDesignMediaElement
        {
            Column = 1,
            Row = 1,
            ColumnSpan = 1,
            RowSpan = 1
        };

        var actual = element.GetMediaContainerModel(base64Image, 23, 42);

        Assert.Equal(1, actual.Column);
        Assert.Equal(1, actual.ColumnSpan);
        Assert.Equal(1, actual.Row);
        Assert.Equal(1, actual.RowSpan);
        Assert.Equal(23, actual.FocalPointX);
        Assert.Equal(42, actual.FocalPointY);
        Assert.Equal(base64Image, actual.Base64Media);
    }

    [Fact]
    public void TestThatGetUpcomingEventsContainerModelMapsTicketDesignUpcomingEventsElementToUpcomingEventsContainerModel()
    {
        var startDate = DateTime.UtcNow.AddDays(1);

        var element = new TicketDesignUpcomingEventsElement
        {
            Column = 1,
            Row = 2,
            ColumnSpan = 2,
            RowSpan = 1
        };

        var events = new Event[]
        {
            new() { Name = "Upcoming Event #01", StartDate = startDate }
        };

        var actual = element.GetUpcomingEventsContainerModel(events);

        Assert.Equal(1, actual.Column);
        Assert.Equal(2, actual.ColumnSpan);
        Assert.Equal(2, actual.Row);
        Assert.Equal(1, actual.RowSpan);

        var actualEvents = actual.Events.ToList();

        Assert.Single(actualEvents);
        Assert.Equal("Upcoming Event #01", actualEvents[0].Name);
        Assert.Equal(startDate, actualEvents[0].Date);
    }
}