using FanceeData.Models.Ticketing;
using PdfService.Utils.Adapter;

namespace PdfService.Tests.Utils.Adapter;

public class AddressAdapterTests
{
    [Fact]
    public void TestThatToAddressReturnsMappedAddress()
    {
        Address address = new()
        {
            Venue = "Venue",
            CountryCode = "NL",
            PostalCode = "1234AB",
            City = "UnitCity",
            Street = "UnitStreet",
            HouseNumber = "UnitHouseNr",
            Latitude = 1234.1m,
            Longitude = 1.4321m
        };

        var actual = address.ToAddress();

        Assert.Equal("Venue", actual.Venue);
        Assert.Equal("NL", actual.CountryCode);
        Assert.Equal("1234AB", actual.PostalCode);
        Assert.Equal("UnitCity", actual.City);
        Assert.Equal("UnitStreet", actual.Street);
        Assert.Equal("UnitHouseNr", actual.HouseNumber);
        Assert.Equal(1234.1m, actual.Latitude);
        Assert.Equal(1.4321m, actual.Longitude);
    }
}