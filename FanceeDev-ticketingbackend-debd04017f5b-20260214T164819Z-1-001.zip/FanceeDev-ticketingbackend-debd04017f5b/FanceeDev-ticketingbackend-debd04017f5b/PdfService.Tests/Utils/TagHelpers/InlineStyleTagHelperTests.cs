using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Primitives;
using PdfService.Utils.TagHelpers;

namespace PdfService.Tests.Utils.TagHelpers;

public class InlineStyleTagHelperTests
{
    private readonly InlineStyleTagHelper _sut;
    private readonly Mock<IHostEnvironment> _mockedHostEnvironment = new();
    private readonly Mock<IMemoryCache> _mockedMemoryCache = new();
    private readonly Mock<IFileProvider> _mockedFileProvider = new();
    private readonly Mock<IFileInfo> _mockedFileInfo = new();
    private readonly Mock<ICacheEntry> _mockedCacheEntry = new();

    public InlineStyleTagHelperTests()
    {
        object? @null = null;

        _mockedCacheEntry.Setup(ce => ce.ExpirationTokens).Returns(new List<IChangeToken>());
        _mockedFileProvider.Setup(fp => fp.Watch(It.IsAny<string>())).Returns(new Mock<IChangeToken>().Object);
        _mockedFileProvider.Setup(fp => fp.GetFileInfo(It.IsAny<string>())).Returns(_mockedFileInfo.Object);
        _mockedHostEnvironment.Setup(he => he.ContentRootFileProvider).Returns(_mockedFileProvider.Object);
        _mockedMemoryCache.Setup(mc => mc.CreateEntry(It.IsAny<string>())).Returns(_mockedCacheEntry.Object);
        _mockedMemoryCache.Setup(mc => mc.TryGetValue(It.IsAny<string>(), out @null));

        _sut = new(_mockedHostEnvironment.Object, _mockedMemoryCache.Object);
    }

    [Fact]
    public async Task TestThatProcessAsyncReturnsIfFileDoesNotExist()
    {
        _sut.Href = "/invalid.css";

        _mockedFileInfo.Setup(fi => fi.Exists).Returns(false);

        var mockedTagHelper = new Mock<TagHelperOutput>("test-tag", new TagHelperAttributeList(), new Func<bool, HtmlEncoder, Task<TagHelperContent>>(async (_, _) =>
        {
            await Task.Delay(1);
            return new DefaultTagHelperContent();
        }));
        mockedTagHelper.SetupAllProperties();

        await _sut.ProcessAsync(null!, mockedTagHelper.Object);

        Assert.True(mockedTagHelper.Object.IsContentModified);
        Assert.Null(mockedTagHelper.Object.TagName);
    }

    [Fact]
    public async Task TestThatProcessAsyncSetsOutputTagWithFileContents()
    {
        _sut.Href = "/valid.css";

        _mockedFileInfo.Setup(fi => fi.Exists).Returns(true);
        _mockedFileInfo.Setup(fi => fi.CreateReadStream()).Returns(new MemoryStream(Encoding.UTF8.GetBytes("<h1>Unit</h1>")));

        var mockedTagHelper = new Mock<TagHelperOutput>("test-tag", new TagHelperAttributeList(), new Func<bool, HtmlEncoder, Task<TagHelperContent>>(async (_, _) =>
        {
            await Task.Delay(1);
            return new DefaultTagHelperContent();
        }));
        mockedTagHelper.SetupAllProperties();

        await _sut.ProcessAsync(null!, mockedTagHelper.Object);

        Assert.True(mockedTagHelper.Object.IsContentModified);
        Assert.Equal("style", mockedTagHelper.Object.TagName);
        Assert.Empty(mockedTagHelper.Object.Attributes);
        Assert.Equal("<h1>Unit</h1>", mockedTagHelper.Object.Content.GetContent());
    }
}