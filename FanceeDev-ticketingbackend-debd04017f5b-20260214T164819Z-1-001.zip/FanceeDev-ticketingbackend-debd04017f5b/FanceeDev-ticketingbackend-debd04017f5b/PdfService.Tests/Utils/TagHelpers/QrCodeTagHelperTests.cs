using System;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;
using PdfService.Utils.TagHelpers;

namespace PdfService.Tests.Utils.TagHelpers;

/// <summary>
/// Note:
///   We can't fully test QrCodeTagHelper as it depends on System.Drawing (Bitmap).
///   This is not supported in .NET 6 environments without libgdiplus.
///   The macOS package (brew mono-libgdiplus) does not work nicely with the .NET runtime as it does
///   not load the package by default and requires manual copying of DLL's.
///   For this reason no tests are created with the QrLogo feature.
/// </summary>
public class QrCodeTagHelperTests
{
    private const string LogoPng = "iVBORw0KGgoAAAANSUhEUgAAAAIAAAACAQMAAABIeJ9nAAAAA1BMVEX/2ABQA0YgAAAACklEQVQIHWMAAgAABAABDTukuQAAAABJRU5ErkJggg==";

    private readonly QrCodeTagHelper _sut;

    public QrCodeTagHelperTests()
    {
        _sut = new();
    }

    [Fact]
    public async Task TestThatProcessAsyncReturnsSvgWithoutLogo()
    {
        var mockedTagHelper = new Mock<TagHelperOutput>("qr-code", new TagHelperAttributeList(), new Func<bool, HtmlEncoder, Task<TagHelperContent>>(async (_, _) =>
        {
            await Task.Delay(1);
            return new DefaultTagHelperContent();
        }));
        mockedTagHelper.SetupAllProperties();

        _sut.Code = "Unit-Code";

        await _sut.ProcessAsync(null!, mockedTagHelper.Object);

        var actualContent = mockedTagHelper.Object.Content.GetContent();

        Assert.True(mockedTagHelper.Object.IsContentModified);
        Assert.StartsWith("<svg version=\"1.1\" baseProfile=\"full\" shape-rendering=\"crispEdges\" viewBox=\"", actualContent);
        Assert.EndsWith("</svg>", actualContent);
    }
}