using System;
using System.Threading.Tasks;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PdfService.BackgroundTasks.MessageBus;
using PdfService.Services;
using RabbitMQ.Client;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace PdfService.Tests.BackgroundTasks.MessageBus;

public class DeleteOrderReceiptsListenerTests
{
    private readonly DeleteOrderReceiptsListener _sut;
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ILogger<DeleteOrderReceiptsListener>> _mockedLogger = new();
    private readonly Mock<DeleteOrderReceiptPdfsSubscriber> _mockedSubscriber;
    private readonly Mock<IReceiptPdfService> _mockedReceiptPdfService = new();

    public DeleteOrderReceiptsListenerTests()
    {
        var mockedConnection = new Mock<IConnection>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);

        _mockedSubscriber = new(mockedConnection.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<DeleteOrderReceiptMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<DeleteOrderReceiptsListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IReceiptPdfService))).Returns(_mockedReceiptPdfService.Object);
        _sut = new(_mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsToSubscriber()
    {
        await _sut.StartAsync(default);
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageCallsPdfService()
    {
        var message = new DeleteOrderReceiptMessage();

        await _sut.StartAsync(default);

        var result = _mockedSubscriber.Object.Callback?.Invoke(message);

        Assert.NotNull(result);

        await result!;

        _mockedReceiptPdfService.Verify(ps => ps.DeleteExpiredOrderReceiptsAsync(), Times.Once);
    }
}