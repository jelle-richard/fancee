﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PdfService.BackgroundTasks.MessageBus;
using PdfService.Services;
using RabbitMQ.Client;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace PdfService.Tests.BackgroundTasks.MessageBus;

public class GeneratePdfListenerTests
{
    private readonly GeneratePdfListener _sut;
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ILogger<GeneratePdfListener>> _mockedLogger = new();
    private readonly Mock<GeneratePdfSubscriber> _mockedSubscriber;
    private readonly Mock<IPdfService> _mockedPdfService = new();

    public GeneratePdfListenerTests()
    {
        var mockedConnection = new Mock<IConnection>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);

        _mockedSubscriber = new(mockedConnection.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<IGeneratePdfMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<GeneratePdfListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IEnumerable<IPdfService>))).Returns(new List<IPdfService> { _mockedPdfService.Object });
        _mockedPdfService.Setup(ps => ps.GetMessageType()).Returns(typeof(GenerateInvoicePdfMessage));

        _sut = new(_mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsToSubscriber()
    {
        await _sut.StartAsync(default);
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageCallsPdfService()
    {
        var message = new GenerateInvoicePdfMessage();

        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback?.Invoke(message);

        Assert.NotNull(actual);

        await actual!;

        _mockedPdfService.Verify(ps => ps.GeneratePdfAsync(message), Times.Once);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageLogsIfNoServiceCouldBeFound()
    {
        var message = new UnsupportedMessage();

        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback?.Invoke(message);

        Assert.NotNull(actual);

        await actual!;

        _mockedPdfService.Verify(ps => ps.GetMessageType(), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Critical, "[GeneratePdfListener] Received unsupported PDF generator message with type 'UnsupportedMessage'");
        _mockedPdfService.VerifyNoOtherCalls();
    }

    #region Unit test classes

    public class UnsupportedMessage : IGeneratePdfMessage
    {
        public HostedDeploymentEnvironment Environment { get; set; } = default!;
    }

    #endregion
}