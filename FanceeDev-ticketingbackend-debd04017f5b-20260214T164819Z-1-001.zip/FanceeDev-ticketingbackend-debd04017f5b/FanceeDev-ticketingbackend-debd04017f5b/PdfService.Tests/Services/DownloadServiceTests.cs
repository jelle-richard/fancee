using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using PdfService.Services;
using SixLabors.ImageSharp;
using TestCore.Mocks;
using WebApiCore.Services.Cache;
using WebApiCore.Services.Storage;

namespace PdfService.Tests.Services;

public class DownloadServiceTests
{
    private readonly DownloadService _sut;
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<ILogger<DownloadService>> _mockedLogger = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();

    public DownloadServiceTests()
    {
        _sut = new(_mockedStorageService.Object, _mockedLogger.Object, _mockedCacheService.Object);
    }

    [Fact]
    public async Task TestThatBase64AsyncReturnsEmptyStringOnInvalidFile()
    {
        var fileId = Guid.NewGuid();

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("testPool", "invalidPath")).ThrowsAsync(new());

        var actual = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "invalidPath" }, false);

        Assert.Empty(actual);

        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("testPool", "invalidPath"), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Error, $"Unable to download file: {fileId}");
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatBase64AsyncReturnsBase64OfFile()
    {
        var fileId = Guid.NewGuid();

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("testPool", "file.png"))
            .ReturnsAsync(new MemoryStream("file"u8.ToArray()));

        var actual = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "file.png" }, false);

        Assert.Equal("ZmlsZQ==", actual);

        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("testPool", "file.png"), Times.Once);
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatBase64AsyncReturnsFileFromCache()
    {
        var fileId = Guid.NewGuid();

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("testPool", "file.png"))
            .ReturnsAsync(new MemoryStream("file"u8.ToArray()));

        _mockedCacheService.SetupSequence(cs => cs.GetCachedObjectAsync<string?>(fileId.ToString()))
            .ReturnsAsync(value: null)
            .ReturnsAsync("ZmlsZQ==");

        var actual = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "file.png" }, false);
        var actual2 = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "file.png" }, false);

        Assert.Equal("ZmlsZQ==", actual);
        Assert.True(actual == actual2);

        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("testPool", "file.png"), Times.Once);
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatBase64AsyncFallsBackToDefaultIfInvalidImageIsProvided()
    {
        var fileId = Guid.NewGuid();

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("testPool", "file.png"))
            .ReturnsAsync(new MemoryStream("file"u8.ToArray()));

        var actual = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "file.png" }, true);

        Assert.Equal("ZmlsZQ==", actual);

        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("testPool", "file.png"), Times.Once);
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatBase64AsyncConvertsImage()
    {
        const string base64Image = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIW2NgYGD4DwABBAEAwS2OUAAAAABJRU5ErkJggg==";

        var fileId = Guid.NewGuid();

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("testPool", "file.png"))
            .ReturnsAsync(new MemoryStream(Convert.FromBase64String(base64Image)));

        var actual = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "file.png" }, true);

        Assert.NotEqual(base64Image, actual);

        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("testPool", "file.png"), Times.Once);
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatBase64AsyncResizesWidth()
    {
        const string base64Image = "iVBORw0KGgoAAAANSUhEUgAAA4UAAAABBAMAAACbNxbAAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAADUExURQAAAKd6PdoAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAOSURBVCjPY2AYBUMdAAABxAABwnL5WgAAAABJRU5ErkJggg==";

        var fileId = Guid.NewGuid();

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("testPool", "file.png"))
            .ReturnsAsync(new MemoryStream(Convert.FromBase64String(base64Image)));

        var actual = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "file.png" }, true);

        Assert.NotEqual(base64Image, actual);

        using var newImage = await Image.LoadAsync(new MemoryStream(Convert.FromBase64String(actual)));
        Assert.Equal(900, newImage.Width);
        Assert.Equal(1, newImage.Height);

        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("testPool", "file.png"), Times.Once);
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatBase64AsyncResizesHeight()
    {
        const string base64Image = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAOFBAMAAABZ8pXpAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAADUExURQAAAKd6PdoAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAWSURBVEjHY2AYBaNgFIyCUTAKRjIAAAcKAAFa6AktAAAAAElFTkSuQmCC";

        var fileId = Guid.NewGuid();

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("testPool", "file.png"))
            .ReturnsAsync(new MemoryStream(Convert.FromBase64String(base64Image)));

        var actual = await _sut.Base64Async("testPool", new() { Id = fileId, Path = "file.png" }, true);

        Assert.NotEqual(base64Image, actual);

        using var newImage = await Image.LoadAsync(new MemoryStream(Convert.FromBase64String(actual)));
        Assert.Equal(1, newImage.Width);
        Assert.Equal(900, newImage.Height);

        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("testPool", "file.png"), Times.Once);
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }
}