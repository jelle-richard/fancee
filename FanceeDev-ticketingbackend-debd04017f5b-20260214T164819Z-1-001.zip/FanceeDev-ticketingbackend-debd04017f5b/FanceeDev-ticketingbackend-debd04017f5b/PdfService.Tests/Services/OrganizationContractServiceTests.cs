using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using MailTemplates.Models;
using MailTemplates.Models.User.Organization;
using MailTemplates.Templates;
using Microsoft.AspNetCore.Mvc;
using PdfService.Models.Organization;
using PdfService.Persistence.Organization;
using PdfService.Provider.Pdf;
using PdfService.Services;
using TestCore.Mocks;
using ViewRenderer;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.Currency;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Tests.Services;

public class OrganizationContractServiceTests
{
    private static HostedDeploymentEnvironment DeploymentEnvironment => GenerateOrganizationContractMessage.Environment;
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private static readonly OrganizationDetailsSettings.PackageConfigurations PackageSettings = new()
    {
        Light =
        {
            DefaultProductFeeCents = 99,
            DefaultTicketFeeCents = 99,
            DefaultTicketFeePercentage = 0,
            DefaultProductFeePercentage = 0
        },
        Medium =
        {
            DefaultProductFeeCents = 83,
            DefaultTicketFeeCents = 83,
            DefaultTicketFeePercentage = 0,
            DefaultProductFeePercentage = 0,
            MinimumAnnualSalesAmount = 2500
        },
        Custom =
        {
            DefaultProductFeeCents = 83,
            DefaultTicketFeeCents = 83,
            DefaultTicketFeePercentage = 0,
            DefaultProductFeePercentage = 0
        }
    };

    private static readonly Currency Currency = new()
    {
        Character = "€",
        ShortCode = "EUR",
        Name = "Euro"
    };

    private static readonly GenerateOrganizationContractMessage GenerateOrganizationContractMessage = new()
    {
        OrganizationId = ValidOrganizationId,
        Environment = new()
        {
            Id = Guid.NewGuid(),
            Name = "UnitTestEnv",
            Domain = "localhost",
            IsHttps = false,
            FrontendBaseUrl = "http://unit.test"
        },
        IsAlteration = false
    };

    private static readonly GenerateOrganizationContractMessage GenerateAlterationOrganizationContractMessage = new()
    {
        OrganizationId = ValidOrganizationId,
        Environment = DeploymentEnvironment,
        IsAlteration = true
    };

    private readonly OrganizationContractService _sut;
    private readonly Mock<IPdfProvider> _mockedPdfProvider = new();
    private readonly Mock<IOrganizationDao> _mockedOrganizationDao = new();
    private readonly Mock<IMailer> _mockedMailer = new();
    private readonly Mock<ICurrencyDao> _mockedCurrencyDao = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();

    public OrganizationContractServiceTests()
    {
        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:Website", "https://unittest.eu" },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:PlatformName", "UnitTest (test)" },
            { "OrganizationDetails:SupportEmail", "support@unit.eu" },
            { "OrganizationDetails:SupportPhoneNumber", "+31 687542154" }
        });

        _sut = new(_mockedPdfProvider.Object, _mockedOrganizationDao.Object, _mockedMailer.Object, _mockedCurrencyDao.Object, mockedConfiguration, _mockedUploadService.Object, _mockedCurrencyService.Object);
    }

    [Fact]
    public void TestThatGetMessageTypeReturnsCorrectMessageType()
    {
        Assert.Equal(typeof(GenerateOrganizationContractMessage), _sut.GetMessageType());
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncReturnsIfMessageIsNotGenerateOrganizationContractMessage()
    {
        var message = new UnitTestMessage();

        await _sut.GeneratePdfAsync(message);

        _mockedOrganizationDao.VerifyNoOtherCalls();
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncDoesNotGenerateIfNoContractDetailsCanBeFound()
    {
        _mockedOrganizationDao.Setup(od => od.OrganizationContractDetailsAsync(ValidOrganizationId, PackageSettings, Currency))
            .ReturnsAsync(value: null);

        await _sut.GeneratePdfAsync(GenerateOrganizationContractMessage);

        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncGeneratesPdfAndMailsResult()
    {
        _mockedOrganizationDao.Setup(od => od.OrganizationContractDetailsAsync(It.IsAny<Guid>(), It.IsAny<OrganizationDetailsSettings.PackageConfigurations>(), It.IsAny<Currency>()))
            .ReturnsAsync(new OrganizationContractModel
            {
                Email = "unit@organization.eu",
                Currency = new()
                {
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                },
                Address = new()
                {
                    City = "UnitCity",
                    CountryCode = "NL",
                    Street = "UnitStreet",
                    HouseNumber = "12A",
                    Venue = "UnitRoof",
                    PostalCode = "1234AB"
                },
                Organization = "UnitCompany BV",
                CountryCode = "DE",
                PackageType = OrganizationPackageType.Light,
                CreationDate = DateTime.UtcNow.AddDays(-2),
                SigningDate = DateTime.UtcNow,
                VatCode = "123456",
                ChamberOfCommerceIdentifier = "12345678",
                ApproximateAnnualSalesAmount = 1000,
                ProductFeeCents = 99,
                TicketFeeCents = 99,
                TicketFeePercentage = 0,
                ProductFeePercentage = 0,
                OrganizationHolderFirstName = "Unit",
                OrganizationHolderLastName = "Holder"
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Contract/Base_EN", It.IsAny<OrganizationContractPlatformWrapModel>()))
            .ReturnsAsync(new FileStreamResult(new MemoryStream(Encoding.UTF8.GetBytes("I'm a PDF!")), "application/pdf"));

        _mockedCurrencyDao.Setup(cd => cd.CurrencyAsync(It.IsAny<string>()))
            .ReturnsAsync(Currency);

        _mockedOrganizationDao.Setup(od => od.InsertContractAsync(It.IsAny<OrganizationContract>()));

        _mockedMailer.Setup(m => m.ViewRenderer).Returns(new Mock<IViewRenderer>().Object);

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "contracts",
                null,
                "pdf",
                "application/pdf",
                null,
                false,
                DeploymentEnvironment,
                It.IsAny<Func<File, Task>>())
            )
            .Callback(
                (Stream _, string _, string? _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback)
                    => callback(new()
                    ));

        await _sut.GeneratePdfAsync(GenerateOrganizationContractMessage);

        _mockedUploadService.Verify(us => us.UploadAsync(It.IsAny<Stream>(),
            "contracts",
            null,
            "pdf",
            "application/pdf",
            null,
            false,
            DeploymentEnvironment,
            It.IsAny<Func<File, Task>>()), Times.Once);
        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync<MailModel>(Templates.ContractProposal, It.Is<ContractModel>(cm => !cm.IsAlteration)), Times.Once);
        _mockedOrganizationDao.Verify(od => od.OrganizationContractDetailsAsync(ValidOrganizationId, It.IsAny<OrganizationDetailsSettings.PackageConfigurations>(), Currency), Times.Once);
        _mockedOrganizationDao.Verify(od => od.InsertContractAsync(It.IsAny<OrganizationContract>()), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Contract/Base_EN", It.IsAny<OrganizationContractPlatformWrapModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 && mail.To.First().Name == "Unit Holder" && !mail.Subject.Contains("updated"))));
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncGeneratesPdfAndMailsAlteration()
    {
        _mockedOrganizationDao.Setup(od => od.OrganizationContractDetailsAsync(It.IsAny<Guid>(), It.IsAny<OrganizationDetailsSettings.PackageConfigurations>(), It.IsAny<Currency>()))
            .ReturnsAsync(new OrganizationContractModel
            {
                Email = "unit@organization.eu",
                Currency = new()
                {
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                },
                Address = new()
                {
                    City = "UnitCity",
                    CountryCode = "NL",
                    Street = "UnitStreet",
                    HouseNumber = "12A",
                    Venue = "UnitRoof",
                    PostalCode = "1234AB"
                },
                CountryCode = "NL",
                Organization = "UnitCompany BV",
                PackageType = OrganizationPackageType.Light,
                CreationDate = DateTime.UtcNow.AddDays(-2),
                SigningDate = DateTime.UtcNow,
                VatCode = "123456",
                ChamberOfCommerceIdentifier = "12345678",
                ApproximateAnnualSalesAmount = 1000,
                ProductFeeCents = 99,
                TicketFeeCents = 99,
                OrganizationHolderFirstName = "Unit",
                OrganizationHolderLastName = "Holder"
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Contract/Base_NL", It.IsAny<OrganizationContractPlatformWrapModel>()))
            .ReturnsAsync(new FileStreamResult(new MemoryStream(Encoding.UTF8.GetBytes("I'm a PDF!")), "application/pdf"));

        _mockedCurrencyDao.Setup(cd => cd.CurrencyAsync(It.IsAny<string>()))
            .ReturnsAsync(Currency);

        _mockedOrganizationDao.Setup(od => od.InsertContractAsync(It.IsAny<OrganizationContract>()));

        _mockedMailer.Setup(m => m.ViewRenderer).Returns(new Mock<IViewRenderer>().Object);

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "contracts",
                null,
                "pdf",
                "application/pdf",
                null,
                false,
                DeploymentEnvironment,
                It.IsAny<Func<File, Task>>())
            )
            .Callback(
                (Stream _, string _, string? _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback)
                    => callback(new()
                    ));

        await _sut.GeneratePdfAsync(GenerateAlterationOrganizationContractMessage);

        _mockedUploadService.Verify(us => us.UploadAsync(It.IsAny<Stream>(),
            "contracts",
            null,
            "pdf",
            "application/pdf",
            null,
            false,
            DeploymentEnvironment,
            It.IsAny<Func<File, Task>>()), Times.Once);
        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync<MailModel>(Templates.ContractProposal, It.Is<ContractModel>(cm => cm.IsAlteration)), Times.Once);
        _mockedOrganizationDao.Verify(od => od.OrganizationContractDetailsAsync(ValidOrganizationId, It.IsAny<OrganizationDetailsSettings.PackageConfigurations>(), Currency), Times.Once);
        _mockedOrganizationDao.Verify(od => od.UpdateContractFileAsync(ValidOrganizationId, It.IsAny<File>(), false), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Contract/Base_NL", It.IsAny<OrganizationContractPlatformWrapModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 && mail.To.First().Name == "Unit Holder" && mail.Subject.Contains("updated"))));
    }

    [Fact]
    public async Task TestThatGeneratePdfWithSignatureInMessageGeneratesSignedContractPdf()
    {
        _mockedOrganizationDao.Setup(od => od.OrganizationContractDetailsAsync(ValidOrganizationId, It.IsAny<OrganizationDetailsSettings.PackageConfigurations>(), Currency))
            .ReturnsAsync(new OrganizationContractModel
            {
                Email = "unit@organization.eu",
                Currency = new()
                {
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                },
                Address = new()
                {
                    City = "UnitCity",
                    CountryCode = "NL",
                    Street = "UnitStreet",
                    HouseNumber = "12A",
                    Venue = "UnitRoof",
                    PostalCode = "1234AB"
                },
                Organization = "UnitCompany BV",
                CountryCode = "NL",
                PackageType = OrganizationPackageType.Light,
                CreationDate = DateTime.UtcNow.AddDays(-2),
                SigningDate = DateTime.UtcNow,
                VatCode = "123456",
                ChamberOfCommerceIdentifier = "12345678",
                ApproximateAnnualSalesAmount = 1000,
                ProductFeeCents = 83,
                TicketFeeCents = 83,
                TicketFeePercentage = 0,
                ProductFeePercentage = 0,
                OrganizationHolderFirstName = "Unit",
                OrganizationHolderLastName = "Holder"
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Contract/Base_NL", It.IsAny<OrganizationContractPlatformWrapModel>()))
            .ReturnsAsync(new FileStreamResult(new MemoryStream(Encoding.UTF8.GetBytes("I'm a PDF!")), "application/pdf"));

        _mockedCurrencyDao.Setup(cd => cd.CurrencyAsync(It.IsAny<string>()))
            .ReturnsAsync(Currency);

        _mockedOrganizationDao.Setup(od => od.UpdateContractFileAsync(It.IsAny<Guid>(), It.IsAny<File>(), It.IsAny<bool>()));

        _mockedMailer.Setup(m => m.ViewRenderer).Returns(new Mock<IViewRenderer>().Object);

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "contracts",
                null,
                "pdf",
                "application/pdf",
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>())
            )
            .Callback(
                (Stream _, string _, string? _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback)
                    => callback(new()
                    ));

        GenerateOrganizationContractMessage.Base64Signature = "UnitBase64Image";
        await _sut.GeneratePdfAsync(GenerateOrganizationContractMessage);

        _mockedUploadService.Verify(us => us.UploadAsync(It.IsAny<Stream>(),
            "contracts",
            null,
            "pdf",
            "application/pdf",
            null,
            false,
            DeploymentEnvironment,
            It.IsAny<Func<File, Task>>()), Times.Once);
        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync<MailModel>(Templates.ContractSigned, It.IsAny<ContractModel>()), Times.Once);
        _mockedOrganizationDao.Verify(od => od.OrganizationContractDetailsAsync(ValidOrganizationId, It.IsAny<OrganizationDetailsSettings.PackageConfigurations>(), Currency), Times.Once);
        _mockedOrganizationDao.Verify(od => od.UpdateContractFileAsync(ValidOrganizationId, It.IsAny<File>(), true), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Contract/Base_NL", It.IsAny<OrganizationContractPlatformWrapModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 && mail.To.First().Name == "Unit Holder")));
    }

    #region Unit Test Classes

    public class UnitTestMessage : IGeneratePdfMessage
    {
        public HostedDeploymentEnvironment Environment { get; set; } = default!;
    }

    #endregion
}