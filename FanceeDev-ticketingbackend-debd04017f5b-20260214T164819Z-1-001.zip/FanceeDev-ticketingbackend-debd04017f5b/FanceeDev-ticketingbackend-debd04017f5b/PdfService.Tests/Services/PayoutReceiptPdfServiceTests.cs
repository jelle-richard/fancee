using System;
using System.IO;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing.Invoicing;
using JetBrains.Annotations;
using MailTemplates.Models;
using MailTemplates.Templates;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PdfService.Models.Receipt;
using PdfService.Persistence.WalletPayment;
using PdfService.Provider.Pdf;
using PdfService.Services;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Upload;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Tests.Services;

[TestSubject(typeof(PayoutReceiptPdfService))]
public class PayoutReceiptPdfServiceTests
{
    private readonly PayoutReceiptPdfService _sut;
    private readonly Mock<IPdfProvider> _mockedPdfProvider = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IMailer> _mockedMailer = new();
    private readonly Mock<IWalletPaymentDao> _mockedWalletPaymentDao = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();

    public PayoutReceiptPdfServiceTests()
    {
        var mockedConfig = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:PlatformName", "UnitTest (test)" }
        });

        _sut = new(_mockedPdfProvider.Object, mockedConfig, _mockedUploadService.Object, _mockedMailer.Object, _mockedWalletPaymentDao.Object, _mockedCurrencyService.Object);
    }

    [Fact]
    public void TestThatGetMessageTypeReturnsCorrectType()
    {
        Assert.Equal(typeof(GeneratePayoutReceiptPdfMessage), _sut.GetMessageType());
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncDoesNothingIfMessageIsNotTypeOfGeneratePayoutReceiptPdfMessage()
    {
        await _sut.GeneratePdfAsync(new GenerateInvoicePdfMessage());

        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
        _mockedWalletPaymentDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncDoesNothingIfWalletPaymentDoesNotExist()
    {
        _mockedWalletPaymentDao.Setup(wpd => wpd.ByIdAsync(Guid.Empty, i => i.Include(wp => wp.Organization.PaymentSettings).Include(wp => wp.Organization.User.UserContactInfo.Address)))
            .ReturnsAsync(value: null);

        await _sut.GeneratePdfAsync(new GeneratePayoutReceiptPdfMessage
        {
            WalletPaymentId = Guid.Empty
        });

        _mockedWalletPaymentDao.Verify(wpd => wpd.ByIdAsync(Guid.Empty, i => i.Include(wp => wp.Organization.PaymentSettings)
            .Include(wp => wp.Organization.User.UserContactInfo.Address)), Times.Once);
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
        _mockedWalletPaymentDao.VerifyNoOtherCalls();
        _mockedCurrencyService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncUpdatesWalletPaymentAndSendsMail()
    {
        var walletPaymentId = Guid.NewGuid();

        _mockedWalletPaymentDao.Setup(wpd => wpd.ByIdAsync(walletPaymentId, i => i.Include(wp => wp.Organization.PaymentSettings).Include(wp => wp.Organization.User.UserContactInfo.Address)))
            .ReturnsAsync(new WalletPayment
            {
                Id = walletPaymentId,
                FileId = null,
                InvoiceId = null,
                AmountCents = 1234,
                Type = WalletPaymentType.Debit,
                RequestedAt = DateTime.UtcNow.AddHours(-1),
                ProcessedAt = null,
                OrganizationId = Guid.NewGuid(),
                IncludeInBalanceIfUnprocessed = true,
                CurrencyShortCode = "EUR",
                File = null,
                Invoice = null,
                Organization = new()
                {
                    PaymentSettings = new()
                    {
                        Iban = "NL19TEST11111111",
                        BankAccountNumber = "1234",
                        Bic = "BIC"
                    },
                    Name = "Test B.V.",
                    User = new()
                    {
                        UserContactInfo = new()
                        {
                            Address = new()
                            {
                                City = "UnitCity",
                                Street = "UnitStreet",
                                HouseNumber = "42a",
                                CountryCode = "NL",
                                PostalCode = "1234AB"
                            }
                        }
                    }
                }
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Receipt/Payout", It.Is<PayoutReceiptModel>(prm =>
                prm.Iban == "NL19TEST11111111" &&
                prm.BankAccountNumber == "1234" &&
                prm.Bic == "BIC")))
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedMailer.Setup(vr => vr.ViewRenderer.RenderViewAsync(Templates.PayOutReceipt, It.IsAny<MailModel>()))
            .ReturnsAsync("<h1>Mail!</h1>");

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "receipts",
                null,
                "pdf",
                "application/pdf",
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()
            ))
            .Callback<Stream, string, string, string, string, string, bool, HostedDeploymentEnvironment, Func<File, Task>>(
                (_, _, _, _, _, _, _, _, uploadedCallback) => { uploadedCallback(new()); }
            );

        _mockedCurrencyService.Setup(cs => cs.FormatAsync("EUR", It.IsAny<long>()))
            .ReturnsAsync("€ 12,34");

        await _sut.GeneratePdfAsync(new GeneratePayoutReceiptPdfMessage
        {
            Environment = new(),
            WalletPaymentId = walletPaymentId
        });

        _mockedWalletPaymentDao.Verify(wpd => wpd.ByIdAsync(walletPaymentId, i => i.Include(wp => wp.Organization.PaymentSettings).Include(wp => wp.Organization.User.UserContactInfo.Address)), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Receipt/Payout", It.Is<PayoutReceiptModel>(m =>
            m.PlatformSettings.PlatformBaseCurrency == "EUR"
            && m.WalletPaymentId == walletPaymentId
            && m.FormattedPayoutValue == "€ 12,34"
            && m.RequestDateTime <= DateTime.UtcNow
        )), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<Stream>(),
            "receipts",
            null,
            "pdf",
            "application/pdf",
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync(Templates.PayOutReceipt, It.IsAny<MailModel>()), Times.Once);
        _mockedWalletPaymentDao.Verify(wpd => wpd.UpdateAsync(It.Is<WalletPayment>(wp => wp.File != null)), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.IsAny<Mail>()), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.FormatAsync("EUR", 1234), Times.Once);
        _mockedMailer.VerifyNoOtherCalls();
    }
}