using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Mime;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using PdfService.Models.Receipt;
using PdfService.Models.Views;
using PdfService.Persistence.Order;
using PdfService.Provider.Pdf;
using PdfService.Services;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Shared.Contract;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.Contract;
using WebApiCore.Services.Currency;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Tests.Services;

public class ReceiptPdfServiceTests

{
    private static readonly Guid ValidOrderId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidProductId = Guid.NewGuid();
    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid InvalidOrderId = Guid.NewGuid();

    private static readonly GenerateOrderReceiptMessage InvalidMessage = new()
    {
        OrderId = InvalidOrderId
    };

    private static readonly GenerateOrderReceiptMessage ValidMessage = new()
    {
        OrderId = ValidOrderId
    };

    private static readonly Order Order = new()
    {
        Id = ValidOrderId,
        PaymentStatus = PaymentStatus.Authorised,
        Currency = "USD",
        PspReference = "PSPReference",
        TotalCostCents = 1000,
        PaymentFeeCents = 100,
        PaymentFeePaidBy = PaidBy.Organization,
        PaidOn = default,
        CreatedAt = DateTime.UtcNow.AddDays(-2),
        CurrencyNavigation = new()
        {
            ShortCode = "USD",
            Character = "$",
            Name = "Dollar",
            Decimals = 2,
            Active = true
        },
        ReservationReferenceNavigation = new()
        {
            ReservedProducts = new List<ReservedProduct>
            {
                new()
                {
                    Product = new()
                    {
                        Event = new()
                        {
                            OrganizationId = ValidOrganizationId
                        }
                    }
                }
            }
        },
        IssuedProducts = new List<IssuedProduct>
        {
            new()
            {
                Id = Guid.NewGuid(),
                ProductId = ValidProductId,
                OrderId = ValidOrderId,
                Type = IssuedProductType.HardcopyTicket,
                Product = new()
                {
                    Id = ValidProductId,
                    EventId = ValidEventId,
                    Name = "Unit Test Product",
                    Stock = 0,
                    PriceCents = 10000,
                    FeeCents = 100,
                    Type = ProductType.Product,
                    Event = new()
                    {
                        Name = "Unit Test Event",
                        Organization = new()
                        {
                            Address = new()
                            {
                                Id = Guid.NewGuid(),
                                CountryCode = "NL",
                                PostalCode = "0000AA",
                                Street = "UnitTestStreet",
                                City = "UnitTestCity",
                                HouseNumber = "200"
                            }
                        }
                    }
                }
            }
        },
        OrderTicketFile = null,
        ClientOrder = new()
        {
            OrderId = ValidOrderId,
            ClientId = Guid.NewGuid(),
            FirstName = "Unit",
            LastName = "Test",
            Address = new()
            {
                Id = Guid.NewGuid(),
                CountryCode = "NL",
                PostalCode = "0000AA",
                Street = "UnitTestStreet",
                City = "UnitTestCity",
                HouseNumber = "200"
            }
        },
        ShopQuestionAnswers = null,
        OrderReceiptFile = null
    };

    private readonly ReceiptPdfService _sut;
    private readonly Mock<IPdfProvider> _mockedPdfProvider = new();
    private readonly Mock<IOrderDao> _mockedOrderDao = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();
    private readonly Mock<IContractDao> _mockedContractDao = new();

    private readonly HostedDeploymentEnvironment _hostedDeploymentEnvironment = new()
    {
        Id = Guid.NewGuid(),
        Name = "UnitTestEnv",
        Domain = "localhost",
        IsHttps = false,
        FrontendBaseUrl = "https://unit.test"
    };

    private readonly List<OrderReceiptsFile> _expOrderReceiptsFiles = new()
    {
        new()
        {
            OrderId = Guid.NewGuid(),
            CreatedAt = DateTime.UtcNow.AddMinutes(-18),
            File = new()
            {
                Name = "UnitFile1"
            }
        },
        new()
        {
            OrderId = Guid.NewGuid(),
            CreatedAt = DateTime.UtcNow.AddMinutes(-20),
            File = new()
            {
                Name = "UnitFile2"
            }
        }
    };

    public ReceiptPdfServiceTests()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(_hostedDeploymentEnvironment);

        var mockedConfig = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformName", "UnitPlatform" },
            { "OrganizationDetails:Website", "https://unit.test" },
            { "OrganizationDetails:SupportEmail", "unit@test.com" }
        });

        _sut = new(
            _mockedOrderDao.Object,
            _mockedDeploymentEnvironmentService.Object,
            mockedConfig,
            _mockedPdfProvider.Object,
            _mockedUploadService.Object,
            _mockedStorageService.Object,
            _mockedCurrencyService.Object,
            _mockedContractDao.Object
        );
    }

    [Fact]
    public void TestThatGetMessageTypeReturnsCorrectMessageType()
    {
        Assert.Equal(typeof(GenerateOrderReceiptMessage), _sut.GetMessageType());
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncReturnsIfMessageIsNotGenerateTicketPdfMessage()
    {
        var message = new UnitTestMessage();

        await Assert.ThrowsAsync<NotSupportedException>(async () => await _sut.GeneratePdfAsync(message));

        _mockedOrderDao.VerifyNoOtherCalls();
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedStorageService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGenerateOrderReceiptAsyncReturnsIfNoOrdersFound()
    {
        _mockedOrderDao.Setup(od => od.OrderReceiptsFileExists(InvalidMessage.OrderId))
            .ReturnsAsync(true);

        await _sut.GeneratePdfAsync(InvalidMessage);

        _mockedOrderDao.Verify(od => od.RetrieveForReceiptGenerationAsync(InvalidMessage.OrderId), Times.Never);
        _mockedCurrencyService.VerifyNoOtherCalls();
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGenerateOrderReceiptsAsyncCallsServices()
    {
        _mockedOrderDao.Setup(od => od.OrderReceiptsFileExists(ValidMessage.OrderId))
            .ReturnsAsync(false);

        _mockedOrderDao.Setup(od => od.RetrieveForReceiptGenerationAsync(ValidMessage.OrderId))
            .ReturnsAsync(Order);

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync(It.IsAny<string>(), It.IsAny<OrderReceiptPdfModel>()))
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), MediaTypeNames.Application.Pdf));

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        _mockedContractDao.Setup(cd => cd.ContractFeeAsync(ValidOrganizationId, Order.CreatedAt))
            .ReturnsAsync(new ContractFee
            {
                PeriodStart = DateTime.UtcNow.AddDays(-100),
                PeriodEnd = DateTime.UtcNow.AddDays(-100),
                TicketFeeCents = 55,
                TicketFeePercentage = 1,
                ProductFeeCents = 45,
                ProductFeePercentage = 1,
                SeatedTicketFeeCents = 25,
                SeatedTicketFeePercentage = 0,
                GuestListFeeCents = 20
            });

        _mockedOrderDao.Setup(od => od.OrderReceiptCostsAsync(Order.Id, It.IsAny<ContractFee>()))
            .ReturnsAsync(new OrderReceiptCostModel
            {
                IssuedTickets = new List<OrderProductReceiptEntry>
                {
                    new()
                    {
                        Name = "UnitTestProduct",
                        PriceCents = 1000,
                        FeeCents = 200,
                        Quantity = 1
                    }
                },
                PaymentFeeCents = 50,
                TicketServicePlusCostCents = 100,
                ReceiveViaSmsCostCents = 100,
                TotalOrderCostCents = 9999
            });

        await _sut.GeneratePdfAsync(ValidMessage);

        _mockedOrderDao.Verify(od => od.OrderReceiptsFileExists(ValidMessage.OrderId), Times.Once);
        _mockedOrderDao.Verify(od => od.RetrieveForReceiptGenerationAsync(ValidMessage.OrderId), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.FormatAsync(It.IsAny<string>(), It.IsAny<long>()), Times.Exactly(7));
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync(It.IsAny<string>(), It.IsAny<OrderReceiptPdfModel>()), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedOrderDao.Verify(od => od.InsertOrderReceiptsFileAsync(It.IsAny<Guid>(), It.IsAny<File>()), Times.Once);
        _mockedContractDao.Verify(cd => cd.ContractFeeAsync(ValidOrganizationId, Order.CreatedAt), Times.Once);
        _mockedOrderDao.Verify(od => od.OrderReceiptCostsAsync(Order.Id, It.IsAny<ContractFee>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteExpiredOrderReceiptsAsyncCallsMethods()
    {
        _mockedOrderDao.Setup(od => od.ExpiredOrderReceiptsAsync(IStorageService.ReceiptPdfRetentionTimeInMinutes))
            .ReturnsAsync(_expOrderReceiptsFiles);

        await _sut.DeleteExpiredOrderReceiptsAsync();

        _mockedOrderDao.Verify(od => od.ExpiredOrderReceiptsAsync(IStorageService.ReceiptPdfRetentionTimeInMinutes), Times.Once);
        _mockedStorageService.Verify(ss => ss.DeleteFileAsync(IStorageService.OrderReceiptPdfStoragePool, It.IsAny<string>()), Times.Exactly(_expOrderReceiptsFiles.Count));
        _mockedOrderDao.Verify(od => od.DeleteOrderReceiptFilesAsync(_expOrderReceiptsFiles), Times.Once);
    }

    #region Unit Test Classes

    public class UnitTestMessage : IGeneratePdfMessage
    {
        public HostedDeploymentEnvironment Environment { get; set; } = default!;
    }

    #endregion
}