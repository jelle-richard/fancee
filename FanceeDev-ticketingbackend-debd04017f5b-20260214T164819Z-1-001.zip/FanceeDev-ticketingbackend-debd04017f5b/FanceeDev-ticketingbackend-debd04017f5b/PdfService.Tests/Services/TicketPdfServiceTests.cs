using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using MailTemplates.Models;
using MailTemplates.Models.Shop;
using MailTemplates.Templates;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using PdfService.Models;
using PdfService.Persistence.Event;
using PdfService.Persistence.IssuedTicket;
using PdfService.Persistence.Order;
using PdfService.Persistence.Ticket;
using PdfService.Persistence.User;
using PdfService.Provider.Pdf;
using PdfService.Services;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Contract;
using WebApiCore.Exceptions.Contract;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.Contract;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using Address = PdfService.Models.Address;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Tests.Services;

public class TicketPdfServiceTests
{
    public static readonly TheoryData<GenerateOrderTicketPdfMessage> GeneratePdfAsyncWithOrderMessageTestData = new()
    {
        new()
        {
            OrderId = Guid.NewGuid(),
            Environment = new() { FrontendBaseUrl = "http://unit.test" }
        },
        new()
        {
            OrderId = Guid.NewGuid(),
            SendMail = true,
            Environment = new() { FrontendBaseUrl = "http://unit.test" },
            ExplicitEmail = "test@abc.com"
        }
    };

    private static readonly List<MappedOrganizationContractFee> ContractFees =
    [
        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-60),
            PeriodEnd = DateTime.UtcNow.AddDays(-40),
            ProductFeeCents = 55,
            ProductFeePercentage = 0,
            TicketFeeCents = 55,
            TicketFeePercentage = 0,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 10
        },
        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-39),
            PeriodEnd = DateTime.UtcNow.AddDays(55),
            ProductFeeCents = 83,
            ProductFeePercentage = 2,
            TicketFeeCents = 83,
            TicketFeePercentage = 2,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 20
        }
    ];

    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidFileId = Guid.NewGuid();
    private static readonly Guid ValidClientId = Guid.NewGuid();

    private static readonly IssuedTicket[] IssuedTickets =
    [
        new()
        {
            Code = "TestCode",
            IssuedProduct = new()
            {
                OrderId = Guid.NewGuid(),
                ReservedProduct = new()
                {
                    ShopCode = "Shop1"
                },
                Product = new()
                {
                    Name = "UnitProduct",
                    PriceCents = 1234,
                    PackQuantity = 1,
                    Event = new()
                    {
                        OrganizationId = ValidOrganizationId,
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow.AddHours(1),
                        TimezoneIdentification = "Europe/Amsterdam",
                        Name = "UnitEvent",
                        Address = new()
                        {
                            Venue = "Unit Venue",
                            Street = "Unit",
                            HouseNumber = "1",
                            PostalCode = "9876ZY",
                            City = "Test",
                            CountryCode = "nl"
                        },
                        Organization = new()
                        {
                            Contract = new()
                            {
                                TicketFeeCents = 89
                            }
                        }
                    },
                    PriceHistories = Array.Empty<ProductPriceHistory>(),
                    TicketOption = new()
                    {
                        Design = new()
                        {
                            DesignElements = new TicketDesignElement[]
                            {
                                new TicketDesignQrElement
                                {
                                    Column = 1,
                                    Row = 1,
                                    ColumnSpan = 1,
                                    RowSpan = 1
                                },
                                new TicketDesignUpcomingEventsElement
                                {
                                    Column = 1,
                                    Row = 2,
                                    ColumnSpan = 3,
                                    RowSpan = 1,
                                    Amount = 4
                                },
                                new TicketDesignMediaElement
                                {
                                    Column = 1,
                                    Row = 3,
                                    ColumnSpan = 1,
                                    RowSpan = 1,
                                    FileId = ValidFileId,
                                    File = new()
                                    {
                                        Id = ValidFileId,
                                        Path = "test.png"
                                    }
                                },
                                new TicketDesignMediaElement
                                {
                                    Column = 2,
                                    Row = 3,
                                    ColumnSpan = 1,
                                    RowSpan = 1,
                                    FileId = ValidFileId,
                                    File = new()
                                    {
                                        Id = ValidFileId,
                                        Path = "test.png"
                                    }
                                }
                            }
                        }
                    }
                },
                Order = new()
                {
                    CurrencyNavigation = new()
                    {
                        Character = "€",
                        ShortCode = "EUR"
                    },
                    ClientOrder = new()
                    {
                        ClientId = ValidClientId,
                        Client = new()
                        {
                            UserId = ValidClientId, User = new()
                            {
                                Id = ValidClientId,
                                Email = "unit@test.com",
                                AccountVerifyId = Guid.NewGuid()
                            }
                        },
                        FirstName = "Unit",
                        LastName = "Test",
                        Birthdate = new(2000, 5, 23)
                    }
                }
            },
            Holder = new()
            {
                FirstName = "Unit",
                LastName = "Teset"
            }
        }
    ];

    private static readonly IssuedTicket[] SealedIssuedTickets =
    [
        new()
        {
            Code = "TestCode",
            IssuedProduct = new()
            {
                IssuedTicket = new()
                {
                    Holder = null
                },
                OrderId = Guid.NewGuid(),
                ReservedProduct = new()
                {
                    ShopCode = "Shop1"
                },
                Product = new()
                {
                    Name = "UnitProduct",
                    PriceCents = 1234,
                    PackQuantity = 1,
                    Event = new()
                    {
                        IsSealed = true,
                        OrganizationId = ValidOrganizationId,
                        StartDate = DateTime.UtcNow.AddDays(22),
                        EndDate = DateTime.UtcNow.AddDays(23),
                        TimezoneIdentification = "Europe/Amsterdam",
                        Name = "UnitEvent",
                        Address = new()
                        {
                            Venue = "Unit Venue",
                            Street = "Unit",
                            HouseNumber = "1",
                            PostalCode = "9876ZY",
                            City = "Test",
                            CountryCode = "nl"
                        },
                        Organization = new()
                        {
                            Contract = new()
                            {
                                TicketFeeCents = 89
                            }
                        }
                    },
                    PriceHistories = Array.Empty<ProductPriceHistory>(),
                    TicketOption = new()
                    {
                        Swappable = true,
                        Design = new()
                        {
                            DesignElements = new TicketDesignElement[]
                            {
                                new TicketDesignQrElement
                                {
                                    Column = 1,
                                    Row = 1,
                                    ColumnSpan = 1,
                                    RowSpan = 1
                                },
                                new TicketDesignUpcomingEventsElement
                                {
                                    Column = 1,
                                    Row = 2,
                                    ColumnSpan = 3,
                                    RowSpan = 1,
                                    Amount = 4
                                },
                                new TicketDesignMediaElement
                                {
                                    Column = 1,
                                    Row = 3,
                                    ColumnSpan = 1,
                                    RowSpan = 1,
                                    FileId = ValidFileId,
                                    File = new()
                                    {
                                        Id = ValidFileId,
                                        Path = "test.png"
                                    }
                                },
                                new TicketDesignMediaElement
                                {
                                    Column = 2,
                                    Row = 3,
                                    ColumnSpan = 1,
                                    RowSpan = 1,
                                    FileId = ValidFileId,
                                    File = new()
                                    {
                                        Id = ValidFileId,
                                        Path = "test.png"
                                    }
                                }
                            }
                        }
                    }
                },
                Order = new()
                {
                    CurrencyNavigation = new()
                    {
                        Character = "€",
                        ShortCode = "EUR"
                    },
                    ClientOrder = new()
                    {
                        ClientId = ValidClientId,
                        Client = new()
                        {
                            UserId = ValidClientId, User = new()
                            {
                                Id = ValidClientId,
                                Email = "unit@test.com",
                                AccountVerifyId = Guid.NewGuid()
                            }
                        },
                        FirstName = "Unit",
                        LastName = "Test",
                        Birthdate = new(2000, 5, 23)
                    }
                }
            },
            Holder = new()
            {
                FirstName = "Unit",
                LastName = "Teset"
            }
        }
    ];

    private readonly TicketPdfService _sut;
    private readonly Mock<IPdfProvider> _mockedPdfProvider = new();
    private readonly Mock<IIssuedTicketDao> _mockedIssuedTicketDao = new();
    private readonly Mock<IMailer> _mockedMailer = new();
    private readonly Mock<IEventMailDao> _mockedEventMailDao = new();
    private readonly Mock<IOrderDao> _mockedOrderDao = new();
    private readonly Mock<IOrganizationDao> _mockedOrganizationDao = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<IDownloadService> _mockedDownloadService = new();
    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly Mock<ITicketDesignDao> _mockedTicketDesignDao = new();
    private readonly Mock<IUserDao> _mockedUserDao = new();
    private readonly Mock<IContractDao> _mockedContractDao = new();

    private readonly HostedDeploymentEnvironment _hostedDeploymentEnvironment = new()
    {
        Id = Guid.NewGuid(),
        Name = "UnitTestEnv",
        Domain = "localhost",
        IsHttps = false,
        FrontendBaseUrl = "https://unit.test"
    };

    public TicketPdfServiceTests()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(_hostedDeploymentEnvironment);

        var now = DateTime.UtcNow;

        _mockedContractDao.Setup(cd => cd.ContractFeeAsync(It.IsAny<Guid>(), It.Is<DateTime>(dt => dt >= now.AddDays(-60) && dt < now.AddDays(-40))))
            .ReturnsAsync(ContractFees[0]);

        _mockedContractDao.Setup(cd => cd.ContractFeeAsync(It.IsAny<Guid>(), It.Is<DateTime>(dt => dt >= now.AddDays(-39) && dt < now.AddDays(55))))
            .ReturnsAsync(ContractFees[1]);

        _mockedContractDao.Setup(cd => cd.ContractFeeAsync(It.IsAny<Guid>(), It.IsAny<DateTime>()))
            .ReturnsAsync(ContractFees[1]);

        var mockedConfig = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformName", "UnitPlatform" },
            { "OrganizationDetails:Website", "https://unit.test" },
            { "OrganizationDetails:SupportEmail", "unit@test.com" },
            { "OrganizationDetails:DefaultEventSealHours", "24" }
        });

        _sut = new(
            _mockedPdfProvider.Object,
            _mockedIssuedTicketDao.Object,
            _mockedMailer.Object, 
            mockedConfig,
            _mockedOrganizationDao.Object,
            _mockedUploadService.Object,
            _mockedDeploymentEnvironmentService.Object,
            _mockedOrderDao.Object,
            _mockedEventMailDao.Object,
            _mockedStorageService.Object,
            _mockedDownloadService.Object,
            _mockedEventDao.Object,
            _mockedTicketDesignDao.Object,
            _mockedUserDao.Object,
            _mockedContractDao.Object
        );
    }

    [Fact]
    public void TestThatGetMessageTypeReturnsCorrectMessageType()
    {
        Assert.Equal(typeof(GenerateTicketPdfMessage), _sut.GetMessageType());
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncReturnsIfMessageIsNotGenerateTicketPdfMessage()
    {
        var message = new UnitTestMessage();

        await Assert.ThrowsAsync<NotSupportedException>(async () => await _sut.GeneratePdfAsync(message));

        _mockedIssuedTicketDao.VerifyNoOtherCalls();
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncWithOrderMessageReturnsIfThereAreNoTicketsInOrder()
    {
        var message = new GenerateOrderTicketPdfMessage
        {
            OrderId = Guid.NewGuid()
        };

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(Array.Empty<IssuedTicket>());

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
    }

    [Theory]
    [MemberData(nameof(GeneratePdfAsyncWithOrderMessageTestData))]
    public async Task TestThatGeneratePdfAsyncWithOrderMessageGeneratesPdfAndMailsResult(GenerateOrderTicketPdfMessage message)
    {
        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(IssuedTickets);

        _mockedUserDao.Setup(ud => ud.ByClientIdAsync(ValidClientId))
            .ReturnsAsync(IssuedTickets[0].IssuedProduct.Order.ClientOrder.Client.User);

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(new HostedDeploymentEnvironment
            {
                FrontendBaseUrl = "front-end-url.com"
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedOrganizationDao.Setup(od => od.ContactAsync(ValidOrganizationId, ContactInfoRole.CustomerSupport)).ReturnsAsync(new OrganizationContactInfo
        {
            Email = "cs@unit.test"
        });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.CreateAccountForFirstTimeTicketBuyer, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        _mockedTicketDesignDao.Setup(tdd => tdd.MediaFocalPointAsync(ValidFileId)).ReturnsAsync(new FocalPoint
        {
            X = 20,
            Y = 80
        });

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            (message.ExplicitEmail.IsNullOrEmpty() || mail.To.First().Email == message.ExplicitEmail) &&
            mail.HtmlContent == "<html>")));
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            (message.ExplicitEmail.IsNullOrEmpty() || mail.To.First().Email == message.ExplicitEmail) &&
            mail.HtmlContent == "<html>" &&
            mail.Attachments.Any())));
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedOrderDao.Verify(od => od.InsertOrderTicketsFileAsync(It.IsAny<Guid>(), It.IsAny<File>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaFocalPointAsync(ValidFileId), Times.Once);
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncThrowsContractNotFoundException()
    {
        _mockedContractDao.Setup(cd => cd.ContractFeeAsync(It.IsAny<Guid>(), It.IsAny<DateTime>()))
            .ReturnsAsync(value: null);

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(It.IsAny<Guid>()))
            .ReturnsAsync(IssuedTickets);

        _mockedUserDao.Setup(ud => ud.ByClientIdAsync(ValidClientId))
            .ReturnsAsync(IssuedTickets[0].IssuedProduct.Order.ClientOrder.Client.User);

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(new HostedDeploymentEnvironment
            {
                FrontendBaseUrl = "front-end-url.com"
            });

        _mockedTicketDesignDao.Setup(tdd => tdd.MediaFocalPointAsync(ValidFileId)).ReturnsAsync(new FocalPoint
        {
            X = 20,
            Y = 80
        });

        var message = new GenerateOrderTicketPdfMessage
        {
            OrderId = Guid.Empty,
            Environment = new()
        };

        await Assert.ThrowsAsync<ContractNotFoundException>(async () => await _sut.GeneratePdfAsync(message));

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(It.IsAny<Guid>()), Times.Once);
        _mockedContractDao.Verify(cd => cd.ContractFeeAsync(It.IsAny<Guid>(), It.IsAny<DateTime>()), Times.Once);
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
    }

    [Theory]
    [MemberData(nameof(GeneratePdfAsyncWithOrderMessageTestData))]
    public async Task TestThatGeneratePdfAsyncFromResendWithOrderMessageGeneratesPdfAndMailsResultWithoutAccountCreationMail(GenerateOrderTicketPdfMessage message)
    {
        message.Resend = true;

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(IssuedTickets);

        _mockedUserDao.Setup(ud => ud.ByClientIdAsync(ValidClientId))
            .ReturnsAsync(IssuedTickets[0].IssuedProduct.Order.ClientOrder.Client.User);

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(new HostedDeploymentEnvironment
            {
                FrontendBaseUrl = "front-end-url.com"
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedOrganizationDao.Setup(od => od.ContactAsync(ValidOrganizationId, ContactInfoRole.CustomerSupport)).ReturnsAsync(new OrganizationContactInfo
        {
            Email = "cs@unit.test"
        });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.CreateAccountForFirstTimeTicketBuyer, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        _mockedTicketDesignDao.Setup(tdd => tdd.MediaFocalPointAsync(ValidFileId)).ReturnsAsync(new FocalPoint
        {
            X = 20,
            Y = 80
        });

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync(Templates.CreateAccountForFirstTimeTicketBuyer, It.IsAny<MailModel>()), Times.Never);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            (message.ExplicitEmail.IsNullOrEmpty() || mail.To.First().Email == message.ExplicitEmail) &&
            mail.HtmlContent == "<html>" &&
            mail.Attachments.Any())));
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedOrderDao.Verify(od => od.InsertOrderTicketsFileAsync(It.IsAny<Guid>(), It.IsAny<File>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaFocalPointAsync(ValidFileId), Times.Once);
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncWithOrderMessageGeneratesPdfAndMailsResultButDoesNotInvocateSendFirstTimeBuyerOrNotYetRegisteredMail()
    {
        var message = new GenerateOrderTicketPdfMessage
        {
            OrderId = Guid.NewGuid(),
            Environment = new() { FrontendBaseUrl = "http://unit.test" }
        };

        var fileId = Guid.NewGuid();

        var issuedTicket = new IssuedTicket[]
        {
            new()
            {
                Code = "TestCode",
                IssuedProduct = new()
                {
                    OrderId = Guid.NewGuid(),
                    ReservedProduct = new()
                    {
                        ShopCode = "Shop1"
                    },
                    Product = new()
                    {
                        Name = "UnitProduct",
                        PriceCents = 1234,
                        PackQuantity = 1,
                        Event = new()
                        {
                            OrganizationId = ValidOrganizationId,
                            StartDate = DateTime.UtcNow,
                            EndDate = DateTime.UtcNow.AddHours(1),
                            TimezoneIdentification = "Europe/Amsterdam",
                            Name = "UnitEvent",
                            Address = new()
                            {
                                Venue = "Unit Venue",
                                Street = "Unit",
                                HouseNumber = "1",
                                PostalCode = "9876ZY",
                                City = "Test",
                                CountryCode = "nl"
                            },
                            Organization = new()
                            {
                                Contract = new()
                                {
                                    TicketFeeCents = 89
                                }
                            }
                        },
                        PriceHistories = Array.Empty<ProductPriceHistory>(),
                        TicketOption = new()
                        {
                            Design = new()
                            {
                                DesignElements = new TicketDesignElement[]
                                {
                                    new TicketDesignQrElement
                                    {
                                        Column = 1,
                                        Row = 1,
                                        ColumnSpan = 1,
                                        RowSpan = 1
                                    },
                                    new TicketDesignUpcomingEventsElement
                                    {
                                        Column = 1,
                                        Row = 2,
                                        ColumnSpan = 3,
                                        RowSpan = 1,
                                        Amount = 4
                                    },
                                    new TicketDesignMediaElement
                                    {
                                        Column = 1,
                                        Row = 3,
                                        ColumnSpan = 1,
                                        RowSpan = 1,
                                        FileId = fileId,
                                        File = new()
                                        {
                                            Id = fileId,
                                            Path = "test.png"
                                        }
                                    },
                                    new TicketDesignMediaElement
                                    {
                                        Column = 2,
                                        Row = 3,
                                        ColumnSpan = 1,
                                        RowSpan = 1,
                                        FileId = fileId,
                                        File = new()
                                        {
                                            Id = fileId,
                                            Path = "test.png"
                                        }
                                    }
                                }
                            }
                        }
                    },
                    Order = new()
                    {
                        CurrencyNavigation = new()
                        {
                            Character = "€",
                            ShortCode = "EUR"
                        },
                        ClientOrder = new()
                        {
                            Client = new()
                            {
                                User = new()
                                {
                                    Email = "unit@test.com"
                                }
                            },
                            FirstName = "Unit",
                            LastName = "Test",
                            Birthdate = new(2000, 5, 23)
                        }
                    }
                },
                Holder = new()
                {
                    FirstName = "Unit",
                    LastName = "Teset"
                }
            }
        };

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(issuedTicket);

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(new HostedDeploymentEnvironment
            {
                FrontendBaseUrl = "front-end-url.com"
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedOrganizationDao.Setup(od => od.ContactAsync(ValidOrganizationId, ContactInfoRole.CustomerSupport)).ReturnsAsync(new OrganizationContactInfo
        {
            Email = "cs@unit.test"
        });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.CreateAccountForFirstTimeTicketBuyer, It.IsAny<MailModel>()))
            .ReturnsAsync("<html><div>create account</div></html>");

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        _mockedTicketDesignDao.Setup(tdd => tdd.MediaFocalPointAsync(fileId)).ReturnsAsync(new FocalPoint
        {
            X = 20,
            Y = 80
        });

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            mail.HtmlContent == "<html><div>create account</div></html>")), Times.Never);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            mail.HtmlContent == "<html>" &&
            mail.Attachments.Any())));
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedOrderDao.Verify(od => od.InsertOrderTicketsFileAsync(It.IsAny<Guid>(), It.IsAny<File>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaFocalPointAsync(fileId), Times.Once);
    }

    [Fact]
    public async Task TestThatGeneratePdfWithOrderMessageAsyncSetsDefaultMailSettings()
    {
        var message = new GenerateOrderTicketPdfMessage
        {
            OrderId = Guid.NewGuid(),
            Environment = new() { FrontendBaseUrl = "http://unit.test" }
        };

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(new IssuedTicket[]
            {
                new()
                {
                    Code = "TestCode",
                    IssuedProduct = new()
                    {
                        ReservedProduct = new()
                        {
                            ShopCode = "Shop1"
                        },
                        Product = new()
                        {
                            Name = "UnitProduct",
                            PriceCents = 1234,
                            PackQuantity = 1,
                            Event = new()
                            {
                                OrganizationId = ValidOrganizationId,
                                StartDate = DateTime.UtcNow,
                                EndDate = DateTime.UtcNow.AddHours(1),
                                TimezoneIdentification = "Europe/Amsterdam",
                                Name = "UnitEvent",
                                Address = null,
                                Organization = new()
                                {
                                    User = new() { Email = "org@mail.com" },
                                    Contract = new()
                                    {
                                        TicketFeeCents = 89
                                    }
                                }
                            },
                            PriceHistories = Array.Empty<ProductPriceHistory>(),
                            TicketOption = new()
                        },
                        Order = new()
                        {
                            CurrencyNavigation = new()
                            {
                                Character = "€",
                                ShortCode = "EUR"
                            },
                            ClientOrder = new()
                            {
                                Client = new() { User = new() { Email = "unit@test.com" } },
                                FirstName = "Unit",
                                LastName = "Test"
                            }
                        }
                    },
                    Holder = new()
                    {
                        FirstName = "Unit",
                        LastName = "Teset"
                    }
                }
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedEventMailDao.Setup(emd => emd.ByEventAndTypeAsync(It.IsAny<Guid>(), EventMailType.DefaultShopMail))
            .ReturnsAsync(new EventMail
            {
                Type = EventMailType.DefaultShopMail,
                SenderName = "UnitTest B.V.",
                Subject = "Unit purchase mail"
            });

        _mockedOrganizationDao.Setup(od => od.ContactAsync(ValidOrganizationId, ContactInfoRole.CustomerSupport)).ReturnsAsync(value: null);

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, It.IsAny<MailModel>()))
            .ReturnsAsync((string _, MailModel model) => ((PurchaseModel)model).MailContent);

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.From!.Name == "UnitTest B.V." &&
            mail.From.Email == null &&
            mail.HtmlContent == "<p>Thank you for your order, you’ll find your tickets attached to this email.</p>")));
    }

    [Fact]
    public void TestThatGetFormattedAddressReturnsExpectedStrings()
    {
        var address = new Address();

        Assert.Empty(TicketPdfService.GetFormattedAddress(address));

        address.Venue = "Venue";
        Assert.Equal("📍 Venue<br/>", TicketPdfService.GetFormattedAddress(address));

        address.Street = "Street";
        Assert.Equal("📍 Venue<br/>Street <br/>", TicketPdfService.GetFormattedAddress(address));

        address.HouseNumber = "1";
        Assert.Equal("📍 Venue<br/>Street 1<br/>", TicketPdfService.GetFormattedAddress(address));

        address.PostalCode = "1234AB";
        Assert.Equal("📍 Venue<br/>Street 1<br/>1234AB ", TicketPdfService.GetFormattedAddress(address));

        address.City = "City";
        Assert.Equal("📍 Venue<br/>Street 1<br/>1234AB City<br/>", TicketPdfService.GetFormattedAddress(address));

        address.CountryCode = "nl";
        Assert.Equal("📍 Venue<br/>Street 1<br/>1234AB City<br/>NL", TicketPdfService.GetFormattedAddress(address));
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncWithGuestListMessageDoesNothingIfNoTicketsAreFound()
    {
        _mockedIssuedTicketDao.Setup(itd => itd.ByCodesAsync(It.IsAny<IEnumerable<string>>())).ReturnsAsync(Array.Empty<IssuedTicket>());

        await _sut.GeneratePdfAsync(new GenerateGuestListTicketPdfMessage
        {
            IssuedTicketCodes = new[] { "Invalid" }
        });

        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncWithGuestListMessageGeneratesPdfAndSendsGuestListMailWithDefaultTicketDesign()
    {
        var eventId = Guid.NewGuid();

        var issuedTicket = new IssuedTicket
        {
            Code = "ticket1",
            Holder = new()
            {
                Email = "holder@test.com",
                FirstName = "Henry",
                LastName = "Peters"
            },
            IssuedProduct = new()
            {
                Product = new()
                {
                    Name = "UnitProduct",
                    PriceCents = 1234,
                    PackQuantity = 1,
                    Event = new()
                    {
                        Id = eventId,
                        OrganizationId = ValidOrganizationId,
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow.AddHours(1),
                        TimezoneIdentification = "Europe/Amsterdam",
                        Name = "UnitEvent",
                        Address = new()
                        {
                            Venue = "Unit Venue",
                            Street = "Unit",
                            HouseNumber = "1",
                            PostalCode = "9876ZY",
                            City = "Test",
                            CountryCode = "nl"
                        },
                        Organization = new()
                        {
                            User = new() { Email = "organization@test.com" }
                        }
                    },
                    PriceHistories = Array.Empty<ProductPriceHistory>(),
                    TicketOption = new()
                }
            }
        };

        // This resolves an error for unit testing, as EntityFramework will populate IssuedTicket with a reference to itself.
        issuedTicket.IssuedProduct.IssuedTicket = issuedTicket;

        _mockedIssuedTicketDao.Setup(itd => itd.ByCodesAsync(It.IsAny<IEnumerable<string>>())).ReturnsAsync(new[]
        {
            issuedTicket
        });

        _mockedOrganizationDao.Setup(od => od.ContactAsync(ValidOrganizationId, ContactInfoRole.CustomerSupport)).ReturnsAsync(new OrganizationContactInfo
        {
            Email = "email@test.com"
        });

        _mockedEventMailDao.Setup(emd => emd.ByEventAndTypeAsync(eventId, EventMailType.GuestList))
            .ReturnsAsync(new EventMail
            {
                EventId = eventId,
                Content = "Guestlist mail content",
                SenderName = "UnitTest B.V.",
                Subject = "Unit guestlist mail"
            });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        var ticketCodes = new[] { "ticket1" };

        await _sut.GeneratePdfAsync(new GenerateGuestListTicketPdfMessage
        {
            IssuedTicketCodes = ticketCodes,
            Environment = _hostedDeploymentEnvironment
        });

        _mockedIssuedTicketDao.Verify(itd => itd.ByCodesAsync(ticketCodes), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(m => m.Attachments.Count() == 1)), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteExpiredTicketPdfsAsyncDeletesFetchedExpiredOrderTicketPdfFilesFromStorageAndDatabase()
    {
        _mockedOrderDao.Setup(od => od.ExpiredOrderTicketPdfFilesAsync(IStorageService.TicketPdfRetentionTimeMinutes))
            .ReturnsAsync(new List<OrderTicketsFile>
            {
                new()
                {
                    CreatedAt = DateTime.UtcNow.AddMinutes(-17),
                    File = new()
                    {
                        Path = $"uploads/{IStorageService.TicketPdfStoragePool}/file1.pdf",
                        Name = "UnitFile1"
                    }
                },
                new()
                {
                    CreatedAt = DateTime.UtcNow.AddMinutes(-16),
                    File = new()
                    {
                        Path = $"uploads/{IStorageService.TicketPdfStoragePool}/file2.pdf",
                        Name = "UnitFile2"
                    }
                }
            });

        _mockedStorageService.Setup(ss => ss.DeleteFileAsync(IStorageService.TicketPdfStoragePool, It.IsAny<string>()));

        _mockedOrderDao.Setup(od => od.DeleteOrderTicketFilesAsync(It.IsAny<IList<OrderTicketsFile>>()));

        await _sut.DeleteExpiredTicketPdfsAsync();

        _mockedOrderDao.Verify(od => od.ExpiredOrderTicketPdfFilesAsync(IStorageService.TicketPdfRetentionTimeMinutes), Times.Once);
        _mockedStorageService.Verify(ss => ss.DeleteFileAsync(IStorageService.TicketPdfStoragePool, It.Is<string>(s => s.StartsWith("file"))), Times.Exactly(2));
        _mockedOrderDao.Verify(od => od.DeleteOrderTicketFilesAsync(It.IsAny<IList<OrderTicketsFile>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateTicketSwapPdfAsyncRendersPdf()
    {
        var fileId = Guid.NewGuid();
        var message = new GenerateTicketSwapTicketPdfMessage
        {
            Environment = new() { FrontendBaseUrl = "http://unit.test" },
            PreviousIssuedTicketCode = "FAN-previous",
            SwappedIssuedTicketCode = "TS-swapped"
        };

        _mockedIssuedTicketDao.Setup(itd => itd.ByCodeAsync(message.SwappedIssuedTicketCode))
            .ReturnsAsync(new IssuedTicket
            {
                Code = "TestCode",
                IssuedProduct = new()
                {
                    OrderId = Guid.NewGuid(),
                    ReservedProduct = new()
                    {
                        ShopCode = "Shop1"
                    },
                    Product = new()
                    {
                        Name = "UnitProduct",
                        PriceCents = 1234,
                        PackQuantity = 1,
                        Event = new()
                        {
                            OrganizationId = ValidOrganizationId,
                            StartDate = DateTime.UtcNow,
                            EndDate = DateTime.UtcNow.AddHours(1),
                            TimezoneIdentification = "Europe/Amsterdam",
                            Name = "UnitEvent",
                            Address = new()
                            {
                                Venue = "Unit Venue",
                                Street = "Unit",
                                HouseNumber = "1",
                                PostalCode = "9876ZY",
                                City = "Test",
                                CountryCode = "nl"
                            },
                            Organization = new()
                            {
                                Contract = new()
                                {
                                    TicketFeeCents = 89
                                }
                            }
                        },
                        PriceHistories = Array.Empty<ProductPriceHistory>(),
                        TicketOption = new()
                        {
                            Design = new()
                            {
                                DesignElements = new TicketDesignElement[]
                                {
                                    new TicketDesignQrElement
                                    {
                                        Column = 1,
                                        Row = 1,
                                        ColumnSpan = 1,
                                        RowSpan = 1
                                    },
                                    new TicketDesignUpcomingEventsElement
                                    {
                                        Column = 1,
                                        Row = 2,
                                        ColumnSpan = 3,
                                        RowSpan = 1,
                                        Amount = 4
                                    },
                                    new TicketDesignMediaElement
                                    {
                                        Column = 1,
                                        Row = 3,
                                        ColumnSpan = 1,
                                        RowSpan = 1,
                                        FileId = fileId,
                                        File = new()
                                        {
                                            Id = fileId,
                                            Path = "test.png"
                                        }
                                    },
                                    new TicketDesignMediaElement
                                    {
                                        Column = 2,
                                        Row = 3,
                                        ColumnSpan = 1,
                                        RowSpan = 1,
                                        FileId = fileId,
                                        File = new()
                                        {
                                            Id = fileId,
                                            Path = "test.png"
                                        }
                                    }
                                }
                            }
                        }
                    },
                    Order = new()
                    {
                        CurrencyNavigation = new()
                        {
                            Character = "€",
                            ShortCode = "EUR"
                        },
                        ClientOrder = new()
                        {
                            Client = new() { User = new() { Email = "unit@test.com" } },
                            FirstName = "Unit",
                            LastName = "Test",
                            Birthdate = new(2000, 5, 23)
                        }
                    }
                },
                Holder = new()
                {
                    FirstName = "Unit",
                    LastName = "Teset"
                }
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedIssuedTicketDao.Setup(itd => itd.InsertSwappedTicketAsync(message.PreviousIssuedTicketCode, message.SwappedIssuedTicketCode, It.IsAny<File>()));

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByCodeAsync(message.SwappedIssuedTicketCode), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedIssuedTicketDao.Verify(itd => itd.InsertSwappedTicketAsync(message.PreviousIssuedTicketCode, message.SwappedIssuedTicketCode, It.IsAny<File>()), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateTicketSwapPdfAsyncExecutesNoFurtherCodeWhenIssuedTicketDaoByCodeAsyncFindsNoResult()
    {
        var message = new GenerateTicketSwapTicketPdfMessage
        {
            Environment = new() { FrontendBaseUrl = "http://unit.test" },
            PreviousIssuedTicketCode = "FAN-previous",
            SwappedIssuedTicketCode = "TS-swapped"
        };

        _mockedIssuedTicketDao.Setup(itd => itd.ByCodeAsync(message.SwappedIssuedTicketCode))
            .ReturnsAsync(value: null);

        await _sut.GeneratePdfAsync(message);

        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedIssuedTicketDao.Verify(itd => itd.ByCodeAsync(message.SwappedIssuedTicketCode), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateOrderPdfAsyncUsedEventMailWhenNoShopMailIsPresent()
    {
        var message = new GenerateOrderTicketPdfMessage
        {
            OrderId = Guid.NewGuid(),
            Environment = new() { FrontendBaseUrl = "http://unit.test" }
        };

        var fileId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(new IssuedTicket[]
            {
                new()
                {
                    Code = "TestCode",
                    IssuedProduct = new()
                    {
                        OrderId = Guid.NewGuid(),
                        ReservedProduct = new()
                        {
                            ShopCode = "Shop1"
                        },
                        Product = new()
                        {
                            Name = "UnitProduct",
                            PriceCents = 1234,
                            EventId = eventId,
                            PackQuantity = 1,
                            Event = new()
                            {
                                OrganizationId = ValidOrganizationId,
                                StartDate = DateTime.UtcNow,
                                EndDate = DateTime.UtcNow.AddHours(1),
                                TimezoneIdentification = "Europe/Amsterdam",
                                Name = "UnitEvent",
                                Address = new()
                                {
                                    Venue = "Unit Venue",
                                    Street = "Unit",
                                    HouseNumber = "1",
                                    PostalCode = "9876ZY",
                                    City = "Test",
                                    CountryCode = "nl"
                                },
                                Organization = new()
                                {
                                    Contract = new()
                                    {
                                        TicketFeeCents = 89
                                    }
                                }
                            },
                            PriceHistories = Array.Empty<ProductPriceHistory>(),
                            TicketOption = new()
                            {
                                Design = new()
                                {
                                    DesignElements = new TicketDesignElement[]
                                    {
                                        new TicketDesignQrElement
                                        {
                                            Column = 1,
                                            Row = 1,
                                            ColumnSpan = 1,
                                            RowSpan = 1
                                        },
                                        new TicketDesignUpcomingEventsElement
                                        {
                                            Column = 1,
                                            Row = 2,
                                            ColumnSpan = 3,
                                            RowSpan = 1,
                                            Amount = 4
                                        },
                                        new TicketDesignMediaElement
                                        {
                                            Column = 1,
                                            Row = 3,
                                            ColumnSpan = 1,
                                            RowSpan = 1,
                                            FileId = fileId,
                                            File = new()
                                            {
                                                Id = fileId,
                                                Path = "test.png"
                                            }
                                        },
                                        new TicketDesignMediaElement
                                        {
                                            Column = 2,
                                            Row = 3,
                                            ColumnSpan = 1,
                                            RowSpan = 1,
                                            FileId = fileId,
                                            File = new()
                                            {
                                                Id = fileId,
                                                Path = "test.png"
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        Order = new()
                        {
                            CurrencyNavigation = new()
                            {
                                Character = "€",
                                ShortCode = "EUR"
                            },
                            ClientOrder = new()
                            {
                                Client = new() { User = new() { Email = "unit@test.com" } },
                                FirstName = "Unit",
                                LastName = "Test",
                                Birthdate = new(2000, 5, 23)
                            }
                        }
                    },
                    Holder = new()
                    {
                        FirstName = "Unit",
                        LastName = "Teset"
                    }
                }
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedEventMailDao.Setup(emd => emd.ByEventAndTypeAsync(eventId, EventMailType.DefaultShopMail))
            .ReturnsAsync(new EventMail
            {
                Content = "Event mail content",
                Subject = "Your unit purchas mail",
                SenderName = "Unit tester"
            });

        _mockedOrganizationDao.Setup(od => od.ContactAsync(ValidOrganizationId, ContactInfoRole.CustomerSupport)).ReturnsAsync(new OrganizationContactInfo
        {
            Email = "cs@unit.test"
        });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        _mockedTicketDesignDao.Setup(tdd => tdd.MediaFocalPointAsync(fileId)).ReturnsAsync(new FocalPoint
        {
            X = 20,
            Y = 80
        });

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            mail.HtmlContent == "<html>" &&
            mail.Attachments.Any())));
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedOrderDao.Verify(od => od.InsertOrderTicketsFileAsync(It.IsAny<Guid>(), It.IsAny<File>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaFocalPointAsync(fileId), Times.Once);
        _mockedEventMailDao.Verify(emd => emd.ByEventAndTypeAsync(eventId, EventMailType.DefaultShopMail), Times.Once);
    }

    [Fact]
    public async Task TestThatGenerateOrderPdfSendOrDownloadAsyncRegeneratesPdfAndUpload()
    {
        var message = new GenerateOrderTicketPdfMessage
        {
            OrderId = Guid.NewGuid(),
            RegeneratePdf = true,
            SendMail = false,
            Environment = new() { FrontendBaseUrl = "http://unit.test" }
        };

        var fileId = Guid.NewGuid();

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(new IssuedTicket[]
            {
                new()
                {
                    Code = "TestCode",
                    IssuedProduct = new()
                    {
                        OrderId = Guid.NewGuid(),
                        ReservedProduct = new()
                        {
                            ShopCode = "Shop1"
                        },
                        Product = new()
                        {
                            Name = "UnitProduct",
                            PriceCents = 1234,
                            PackQuantity = 1,
                            Event = new()
                            {
                                StartDate = DateTime.UtcNow,
                                EndDate = DateTime.UtcNow.AddHours(1),
                                TimezoneIdentification = "Europe/Amsterdam",
                                Name = "UnitEvent",
                                Address = new()
                                {
                                    Venue = "Unit Venue",
                                    Street = "Unit",
                                    HouseNumber = "1",
                                    PostalCode = "9876ZY",
                                    City = "Test",
                                    CountryCode = "nl"
                                },
                                Organization = new()
                                {
                                    Id = ValidOrganizationId,
                                    Contract = new()
                                    {
                                        TicketFeeCents = 89
                                    }
                                }
                            },
                            PriceHistories = Array.Empty<ProductPriceHistory>(),
                            TicketOption = new()
                            {
                                Design = new()
                                {
                                    DesignElements = new TicketDesignElement[]
                                    {
                                        new TicketDesignQrElement
                                        {
                                            Column = 1,
                                            Row = 1,
                                            ColumnSpan = 1,
                                            RowSpan = 1
                                        },
                                        new TicketDesignUpcomingEventsElement
                                        {
                                            Column = 1,
                                            Row = 2,
                                            ColumnSpan = 3,
                                            RowSpan = 1,
                                            Amount = 4
                                        },
                                        new TicketDesignMediaElement
                                        {
                                            Column = 1,
                                            Row = 3,
                                            ColumnSpan = 1,
                                            RowSpan = 1,
                                            FileId = fileId,
                                            File = new()
                                            {
                                                Id = fileId,
                                                Path = "test.png"
                                            }
                                        },
                                        new TicketDesignMediaElement
                                        {
                                            Column = 2,
                                            Row = 3,
                                            ColumnSpan = 1,
                                            RowSpan = 1,
                                            FileId = fileId,
                                            File = new()
                                            {
                                                Id = fileId,
                                                Path = "test.png"
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        Order = new()
                        {
                            CurrencyNavigation = new()
                            {
                                Character = "€",
                                ShortCode = "EUR"
                            },
                            ClientOrder = new()
                            {
                                Client = new() { User = new() { Email = "unit@test.com" } },
                                FirstName = "Unit",
                                LastName = "Test",
                                Birthdate = new(2000, 5, 23)
                            }
                        }
                    },
                    Holder = new()
                    {
                        FirstName = "Unit",
                        LastName = "Teset"
                    }
                }
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedOrderDao.Verify(od => od.InsertOrderTicketsFileAsync(It.IsAny<Guid>(), It.IsAny<File>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaFocalPointAsync(fileId), Times.Once);
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncWithOrderMessageGeneratesPdfAndMailsResultWithoutAttchamentsAndBooksSealedTicketDeliveryForSealedEvent()
    {
        var message = new GenerateOrderTicketPdfMessage
        {
            OrderId = Guid.NewGuid(),
            Environment = new() { FrontendBaseUrl = "http://unit.test" }
        };

        _mockedIssuedTicketDao.Setup(itd => itd.ByOrderIdAsync(message.OrderId))
            .ReturnsAsync(SealedIssuedTickets);

        _mockedUserDao.Setup(ud => ud.ByClientIdAsync(ValidClientId))
            .ReturnsAsync(SealedIssuedTickets[0].IssuedProduct.Order.ClientOrder.Client.User);

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()))
            .Callback((string _, GridTicketPdfModel model) =>
            {
                var unused = model.TicketEntryInfos.ToList();
            })
            .ReturnsAsync(new FileStreamResult(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"));

        _mockedEventMailDao.Setup(emd => emd.ByEventAndTypeAsync(It.IsAny<Guid>(), EventMailType.DefaultShopMail))
            .ReturnsAsync(new EventMail
            {
                Content = "Event mail content",
                Subject = "Your unit purchas mail",
                SenderName = "Unit tester"
            });

        _mockedEventMailDao.Setup(emd => emd.ByEventAndTypeAsync(It.IsAny<Guid>(), EventMailType.SealedTicketsMail))
            .ReturnsAsync(new EventMail
            {
                Content = "Sealed event mail content",
                Subject = "Your unit sealed ticket delivery mail",
                SenderName = "Unit tester"
            });

        _mockedOrganizationDao.Setup(od => od.ContactAsync(ValidOrganizationId, ContactInfoRole.CustomerSupport)).ReturnsAsync(new OrganizationContactInfo
        {
            Email = "cs@unit.test"
        });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.ShopPurchase, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.SealedTickets, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(Templates.CreateAccountForFirstTimeTicketBuyer, It.IsAny<MailModel>()))
            .ReturnsAsync("<html>");

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                It.IsAny<string>(),
                null,
                "pdf",
                MediaTypeNames.Application.Pdf,
                null,
                false,
                It.IsAny<HostedDeploymentEnvironment>(),
                It.IsAny<Func<File, Task>>()))
            .Callback((Stream _, string _, string _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback.Invoke(new()));

        _mockedTicketDesignDao.Setup(tdd => tdd.MediaFocalPointAsync(ValidFileId))
            .ReturnsAsync(new FocalPoint
            {
                X = 20,
                Y = 80
            });

        await _sut.GeneratePdfAsync(message);

        _mockedIssuedTicketDao.Verify(itd => itd.ByOrderIdAsync(message.OrderId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Product/Templates/Base", It.IsAny<GridTicketPdfModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            (message.ExplicitEmail.IsNullOrEmpty() || mail.To.First().Email == message.ExplicitEmail) &&
            mail.HtmlContent == "<html>")));
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.To.First().Name == "Unit Test" &&
            (message.ExplicitEmail.IsNullOrEmpty() || mail.To.First().Email == message.ExplicitEmail) &&
            mail.HtmlContent == "<html>" &&
            mail.Attachments.Any())));
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<MemoryStream>(),
            It.IsAny<string>(),
            null,
            "pdf",
            MediaTypeNames.Application.Pdf,
            null,
            false,
            It.IsAny<HostedDeploymentEnvironment>(),
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedOrderDao.Verify(od => od.InsertOrderTicketsFileAsync(It.IsAny<Guid>(), It.IsAny<File>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaFocalPointAsync(ValidFileId), Times.Once);
    }

    #region Unit Test Classes

    public class UnitTestMessage : IGeneratePdfMessage
    {
        public HostedDeploymentEnvironment Environment { get; set; } = default!;
    }

    #endregion
}