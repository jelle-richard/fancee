using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using MailTemplates.Models;
using MailTemplates.Models.User.Organization;
using MailTemplates.Templates;
using Microsoft.AspNetCore.Mvc;
using PdfService.Models.Organization;
using PdfService.Persistence.Organization;
using PdfService.Persistence.Shop;
using PdfService.Provider.Pdf;
using PdfService.Services;
using TestCore.Mocks;
using ViewRenderer;
using WebApiCore.Dtos.Environment;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Services.Cache;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Tests.Services;

public class OrganizationContractAddendumServiceTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidUserId = Guid.NewGuid();

    private static readonly GenerateOrganizationContractAddendumMessage GenerateOrganizationContractAddendumMessage = new()
    {
        OrganizationId = ValidOrganizationId
    };

    private readonly OrganizationContractAddendumService _sut;
    private readonly Mock<IPdfProvider> _mockedPdfProvider = new();
    private readonly Mock<IOrganizationContractDao> _mockedOrganizationContractDao = new();
    private readonly Mock<IOrganizationContractAddendumDao> _mockedOrganizationAddendumDao = new();
    private readonly Mock<IMailer> _mockedMailer = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IShopDao> _mockedShopDao = new();
    private readonly Mock<IShopCacheService> _mockedShopCacheService = new();

    private readonly IEnumerable<string> _shopCodes = new List<string>()
    {
        "shopCodeA",
        "shopCodeB",
        "ShopCodeC"
    };

    private readonly HostedDeploymentEnvironment _deploymentEnvironment = new()
    {
        Id = Guid.NewGuid(),
        Name = "UnitTestEnv",
        Domain = "localhost",
        IsHttps = false,
        FrontendBaseUrl = "http://unit.test"
    };

    public OrganizationContractAddendumServiceTests()
    {
        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:Website", "https://unittest.eu" },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:PlatformName", "UnitTest (test)" },
            { "OrganizationDetails:SupportEmail", "support@unit.eu" },
            { "OrganizationDetails:SupportPhoneNumber", "+31 687542154" }
        });

        _sut = new(_mockedPdfProvider.Object, _mockedOrganizationContractDao.Object, _mockedOrganizationAddendumDao.Object, _mockedMailer.Object, mockedConfiguration, _mockedUploadService.Object, _mockedDeploymentEnvironmentService.Object, _mockedShopDao.Object, _mockedShopCacheService.Object);
    }

    [Fact]
    public void TestThatGetMessageTypeReturnsCorrectMessageType()
    {
        Assert.Equal(typeof(GenerateOrganizationContractAddendumMessage), _sut.GetMessageType());
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncReturnsIfMessageIsNotGenerateOrganizationContractMessage()
    {
        var message = new UnitTestMessage();

        await _sut.GeneratePdfAsync(message);
        _mockedOrganizationContractDao.VerifyNoOtherCalls();
        _mockedOrganizationAddendumDao.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedShopCacheService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncReturnsIfNoContractCanBeFound()
    {
        var message = new UnitTestMessage();

        await _sut.GeneratePdfAsync(message);
        _mockedOrganizationContractDao.VerifyNoOtherCalls();
        _mockedOrganizationAddendumDao.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
        _mockedShopDao.VerifyNoOtherCalls();
        _mockedShopCacheService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncGeneratesPdfAndMailResult()
    {
        _mockedOrganizationContractDao.Setup(ocd => ocd.RetrieveOrganizationContractAsync(ValidOrganizationId))
            .ReturnsAsync(new OrganizationContract
            {
                OrganizationId = ValidOrganizationId,
                Start = DateTime.UtcNow.AddYears(-10),
                End = DateTime.UtcNow.AddYears(10),
                PackageType = OrganizationPackageType.Light,
                ProductFeeCents = 50,
                TicketFeeCents = 50,
                FileId = Guid.NewGuid(),
                Signed = true,
                Organization = new()
                {
                    Id = ValidOrganizationId,
                    UserId = ValidUserId,
                    ApproximatedAnnualSalesAmount = 1000,
                    DefaultReservationTimeMinutes = 10,
                    Name = "UnitTesting Inc.",
                    Currency = "Eur",
                    CountryCode = "NL",
                    IsProfileComplete = true,
                    User = new()
                    {
                        Id = ValidUserId,
                        FanceeUsersId = null,
                        Type = UserType.Organization,
                        Email = "UnitTesting@UnitTest.com",
                        UserContactInfo = new()
                        {
                            UserId = ValidUserId,
                            FirstName = "Unit",
                            LastName = "Test",
                            PhoneNumber = "0612345678"
                        }
                    },
                    CurrencyNavigation = new()
                    {
                        ShortCode = "USD",
                        Character = "$",
                        Name = "Dollar"
                    }
                },
                File = new()
                {
                    Id = Guid.NewGuid(),
                    Name = "Contract",
                    OriginalFileName = "Contract",
                    MimeType = "application/pdf"
                },
                Addenda = null
            });

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Contract/Addendum", It.IsAny<OrganizationContractAddendumWrapModel>()))
            .ReturnsAsync(new FileStreamResult(new MemoryStream(Encoding.UTF8.GetBytes("I am an addendum for a contract!")), "application/pdf"));

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(_deploymentEnvironment);

        _mockedOrganizationAddendumDao.Setup(oad => oad.InsertAddendumAsync(It.IsAny<OrganizationContractAddendum>()));

        _mockedMailer.Setup(m => m.ViewRenderer).Returns(new Mock<IViewRenderer>().Object);

        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                IStorageService.ContractAddendaStoragePool,
                null,
                "pdf",
                "application/pdf",
                null,
                false,
                _deploymentEnvironment,
                It.IsAny<Func<File, Task>>())
            )
            .Callback((Stream _, string _, string? _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback) => callback(new()));

        _mockedShopDao.Setup(sd => sd.ShopCodesByOrganizationIdAsync(ValidOrganizationId))
            .ReturnsAsync(_shopCodes);

        await _sut.GeneratePdfAsync(GenerateOrganizationContractAddendumMessage);

        _mockedOrganizationContractDao.Verify(ocd => ocd.RetrieveOrganizationContractAsync(ValidOrganizationId), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<Stream>(),
            IStorageService.ContractAddendaStoragePool,
            null,
            "pdf",
            "application/pdf",
            null,
            false,
            _deploymentEnvironment,
            It.IsAny<Func<File, Task>>()), Times.Once());

        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync<MailModel>(Templates.ContractAddendum, It.IsAny<ContractModel>()), Times.Once);
        _mockedOrganizationAddendumDao.Verify(oad => oad.InsertAddendumAsync(It.IsAny<OrganizationContractAddendum>()), Times.Once);
        _mockedShopDao.Verify(sd => sd.ShopCodesByOrganizationIdAsync(ValidOrganizationId), Times.Once);
        _mockedShopCacheService.Verify(css => css.RemoveShopCacheAsync(It.IsAny<string>()), Times.Exactly(_shopCodes.Count()));
    }
}

#region Unit Test Classses

public class UnitTestMessage : IGeneratePdfMessage
{
    public HostedDeploymentEnvironment Environment { get; set; } = default!;
}

#endregion