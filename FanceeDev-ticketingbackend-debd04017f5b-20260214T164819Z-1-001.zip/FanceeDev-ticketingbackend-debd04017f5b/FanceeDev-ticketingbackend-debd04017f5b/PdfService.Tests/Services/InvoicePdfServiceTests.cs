﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Invoicing;
using Fs.MessageBus.Publishers;
using MailTemplates.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PdfService.Models;
using PdfService.Persistence.Invoice;
using PdfService.Provider.Pdf;
using PdfService.Services;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Invoices;
using WebApiCore.MessageBus.Messages.Pdf;
using WebApiCore.Persistence.User.Organization;
using WebApiCore.Services.Mail;
using WebApiCore.Services.Upload;
using File = FanceeData.Models.Ticketing.File;

namespace PdfService.Tests.Services;

public class InvoicePdfServiceTests
{
    private readonly InvoicePdfService _sut;
    private readonly Mock<IPdfProvider> _mockedPdfProvider = new();
    private readonly Mock<IInvoiceDao> _mockedInvoiceDao = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IMailer> _mockedMailer = new();
    private readonly Mock<IOrganizationDao> _mockedOrganizationDao = new();
    private readonly Mock<IMessagePublisher<AddAccountingInvoiceMessage>> _mockedPublisher = new();

    public InvoicePdfServiceTests()
    {
        var configuration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:PlatformName", "Fancee" },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" }
        });

        _sut = new(_mockedPdfProvider.Object, _mockedInvoiceDao.Object, _mockedUploadService.Object, _mockedMailer.Object, configuration, _mockedOrganizationDao.Object, _mockedPublisher.Object);
    }

    [Fact]
    public void TestThatGetMessageTypeReturnsExpectedResult()
    {
        Assert.Equal(typeof(GenerateInvoicePdfMessage), _sut.GetMessageType());
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncReturnsOnInvalidMessageType()
    {
        var message = new UnsupportedMessageType();

        await _sut.GeneratePdfAsync(message);

        _mockedInvoiceDao.VerifyNoOtherCalls();
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncReturnsOnInvalidInvoiceNumber()
    {
        _mockedInvoiceDao.Setup(id => id.GetAsync(999)).ReturnsAsync(value: null);

        var message = new GenerateInvoicePdfMessage { InvoiceNumber = 999 };

        await _sut.GeneratePdfAsync(message);

        _mockedInvoiceDao.Verify(id => id.GetAsync(999), Times.Once);
        _mockedInvoiceDao.VerifyNoOtherCalls();
        _mockedPdfProvider.VerifyNoOtherCalls();
        _mockedUploadService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGeneratePdfAsyncUploadsGeneratedPdfAndSendsMailAndPublishesAccountingMessage()
    {
        const string html = "Mail Content";
        const string base64Content = "pdf";
        const int invoiceId = 20202020;
        var invoice = new Invoice { Id = invoiceId, CreatedAt = DateTime.UtcNow, SenderContactDetails = new() { Address = new() } };
        var message = new GenerateInvoicePdfMessage { InvoiceNumber = invoiceId, Environment = new() { FrontendBaseUrl = "https://frontend" } };
        var organizationId = Guid.NewGuid();

        _mockedInvoiceDao.Setup(id => id.GetAsync(invoiceId)).ReturnsAsync(invoice);
        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "invoices",
                null,
                "pdf",
                "application/pdf",
                null,
                false,
                message.Environment,
                It.IsAny<Func<File, Task>>())
            )
            .Callback(
                (Stream _, string _, string? _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback)
                    => callback(new()
                    ));

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Invoice", It.Is<InvoiceModel>(im => im.Invoice == invoice))).ReturnsAsync(new FileStreamResult(new MemoryStream(Encoding.UTF8.GetBytes(base64Content)), "application/pdf"));
        _mockedOrganizationDao.Setup(od => od.ByIdAsync(It.IsAny<Guid>(), q => q.Include(o => o.User.UserContactInfo))).ReturnsAsync(new Organization
        {
            Id = organizationId,
            User = new()
            {
                Email = "units@tester.com",
                UserContactInfo = new()
                {
                    FirstName = "Units",
                    LastName = "Tester"
                }
            }
        });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(It.IsAny<string>(), It.IsAny<MailModel>())).ReturnsAsync(html);

        await _sut.GeneratePdfAsync(message);

        _mockedInvoiceDao.Verify(id => id.GetAsync(invoiceId), Times.Once);
        _mockedPdfProvider.Verify(pp => pp.RenderPdfAsync("Invoice", It.Is<InvoiceModel>(im => im.Invoice == invoice)), Times.Once);
        _mockedInvoiceDao.Verify(id => id.UpdateAsync(invoice), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<Stream>(),
            "invoices",
            null,
            "pdf",
            "application/pdf",
            null,
            false,
            message.Environment,
            It.IsAny<Func<File, Task>>()
        ), Times.Once);

        _mockedOrganizationDao.Verify(od => od.ByIdAsync(It.IsAny<Guid>(), q => q.Include(o => o.User.UserContactInfo)), Times.Once);
        _mockedPublisher.Verify(p => p.Publish(It.Is<AddAccountingInvoiceMessage>(m => m.InvoiceId == invoiceId)));
        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(ma =>
            ma.Subject == "Your Fancee invoice" &&
            ma.To.Single(t => t.Email == "units@tester.com").Name == "Units Tester" &&
            ma.HtmlContent == html &&
            ma.Attachments.First().Base64Content == "cGRm")
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatSendInvoiceMailAsyncReturnsOnInvalidOrganization()
    {
        var invoice = new Invoice { CreatedAt = DateTime.UtcNow, SenderContactDetails = new() { Address = new() } };
        var message = new GenerateInvoicePdfMessage { InvoiceNumber = 20202020, Environment = new() { FrontendBaseUrl = "https://frontend" } };

        _mockedInvoiceDao.Setup(id => id.GetAsync(20202020)).ReturnsAsync(invoice);
        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "invoices",
                null,
                "pdf",
                "application/pdf",
                null,
                false,
                message.Environment,
                It.IsAny<Func<File, Task>>())
            )
            .Callback(
                (Stream _, string _, string? _, string _, string _, string _, bool _, HostedDeploymentEnvironment _, Func<File, Task> callback)
                    => callback(new()
                    ));

        _mockedPdfProvider.Setup(pp => pp.RenderPdfAsync("Invoice", It.Is<InvoiceModel>(im => im.Invoice == invoice))).ReturnsAsync(new FileStreamResult(new MemoryStream(), "application/pdf"));
        _mockedOrganizationDao.Setup(od => od.ByIdAsync(It.IsAny<Guid>(), q => q.Include(o => o.User.UserContactInfo))).ReturnsAsync(value: null);

        await _sut.GeneratePdfAsync(message);

        _mockedMailer.VerifyNoOtherCalls();
    }

    #region Unit test classes

    public class UnsupportedMessageType : IGeneratePdfMessage
    {
        public HostedDeploymentEnvironment Environment { get; set; } = default!;
    }

    #endregion
}