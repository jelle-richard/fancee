using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Order;
using WebApiCore.Dtos.Shared.Contract;

namespace PdfService.Tests.Persistence.Order;

public class OrderDaoTests
{
    private static readonly Guid OrderId = Guid.NewGuid();
    private static readonly Guid ReceiptOrderId = Guid.NewGuid();
    private static readonly Guid FileId = Guid.NewGuid();
    private readonly OrderDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly ContractFee _contractFee = new()
    {
        PeriodStart = DateTime.MinValue,
        PeriodEnd = DateTime.MaxValue,
        ProductFeeCents = 10,
        ProductFeePercentage = 0,
        TicketFeeCents = 20,
        TicketFeePercentage = 0,
        SeatedTicketFeeCents = 0,
        SeatedTicketFeePercentage = 0,
        GuestListFeeCents = 30
    };

    private readonly List<OrderTicketsFile> _expiredOrderTicketsFiles = new()
    {
        new()
        {
            OrderId = OrderId,
            CreatedAt = DateTime.UtcNow.AddMinutes(-18),
            File = new()
            {
                Name = "UnitFile2"
            }
        },
        new()
        {
            OrderId = Guid.NewGuid(),
            CreatedAt = DateTime.UtcNow.AddMinutes(-22),
            File = new()
            {
                Name = "UnitFile3"
            }
        }
    };

    private readonly List<OrderReceiptsFile> _expOrderReceiptsFiles = new()
    {
        new()
        {
            OrderId = OrderId,
            CreatedAt = DateTime.UtcNow.AddMinutes(-18),
            File = new()
            {
                Name = "UnitFile1"
            }
        },
        new()
        {
            OrderId = Guid.NewGuid(),
            CreatedAt = DateTime.UtcNow.AddMinutes(-20),
            File = new()
            {
                Name = "UnitFile2"
            }
        },
        new()
        {
            OrderId = Guid.NewGuid(),
            CreatedAt = DateTime.UtcNow.AddMinutes(+30),
            File = new()
            {
                Name = "UnitFile3"
            }
        }
    };

    private readonly List<ReservedProduct> _receiptReservedProducts = new()
    {
        new()
        {
            ProductId = Guid.NewGuid(),
            Product = new()
            {
                PriceCents = 500,
                FeeCents = null,
                Name = "Unit Ticket 1",
                Type = ProductType.Ticket,
                PackQuantity = 1,
                PriceHistories = new List<ProductPriceHistory>()
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    Id = ReceiptOrderId,
                    PaymentFeePaidBy = PaidBy.Client,
                    PaymentFeeCents = 10,
                    TotalCostCents = 1698,
                    ClientOrder = new()
                    {
                        TicketServicePlusCostCents = 98,
                        ReceiveViaSmsCostCents = 0
                    }
                }
            },
            Quantity = 3
        }
    };

    public OrderDaoTests()
    {
        var orderTicketsFiles = new List<OrderTicketsFile>
        {
            new()
            {
                CreatedAt = DateTime.UtcNow.AddMinutes(-11),
                File = new()
                {
                    Name = "UnitFile1"
                }
            }
        };
        orderTicketsFiles.AddRange(_expiredOrderTicketsFiles);

        _mockedContext.Setup(c => c.OrderTicketsFiles)
            .ReturnsDbSet(orderTicketsFiles);

        _mockedContext.Setup(c => c.OrderReceiptsFiles)
            .ReturnsDbSet(_expOrderReceiptsFiles);

        _mockedContext.Setup(c => c.Files)
            .ReturnsDbSet(new List<File>());

        _mockedContext.Setup(o => o.Orders)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Order>
            {
                new()
                {
                    Id = OrderId
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInsertOrderTicketsFileAsyncInsertsRecord()
    {
        var file = new File
        {
            Id = FileId,
            Name = "FileName",
            Path = "/path/unit/test"
        };

        await _sut.InsertOrderTicketsFileAsync(OrderId, file);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatExpiredOrderTicketPdfFilesAsyncFetchesOrderTicketsFilesThatExceededTheRetentionTime()
    {
        var actual = await _sut.ExpiredOrderTicketPdfFilesAsync(15);

        Assert.Equal(2, actual.Count);
    }

    [Fact]
    public async Task TestThatDeleteOrderTicketFilesAsyncSavesChangesAsyncWhenRemovingRangeOfOrderTicketsFiles()
    {
        await _sut.DeleteOrderTicketFilesAsync(_expiredOrderTicketsFiles);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatOrderTicketsFileExistsReturnsFalseForUnknownOrder()
    {
        var actual = await _sut.OrderTicketsFileExists(Guid.NewGuid());

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatOrderTicketsFileExistsReturnsTrueForOrderWithFile()
    {
        var actual = await _sut.OrderTicketsFileExists(OrderId);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatExpiredOrderReceiptsAsyncCallsContext()
    {
        var actual = await _sut.ExpiredOrderReceiptsAsync(1);

        Assert.Equal(2, actual.Count);
    }

    [Fact]
    public async Task TestThatDeleteOrderReceiptFilesAsyncCallsContext()
    {
        await _sut.DeleteOrderReceiptFilesAsync(_expOrderReceiptsFiles);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatInsertOrderReceiptsFilesAsyncCallsContext()
    {
        await _sut.InsertOrderReceiptsFileAsync(OrderId, new());

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatRetrieveForReceiptGenerationAsyncReturnsOrder()
    {
        var actual = await _sut.RetrieveForReceiptGenerationAsync(OrderId);

        Assert.NotNull(actual);
        Assert.Equal(actual.Id, OrderId);

        _mockedContext.Verify(c => c.Orders, Times.Once);
    }

    [Fact]
    public async Task TestThatOrderReceiptsFileExistsCallsContext()
    {
        var actual = await _sut.OrderReceiptsFileExists(OrderId);

        Assert.True(actual);

        _mockedContext.Verify(c => c.OrderReceiptsFiles, Times.Once);
    }

    [Fact]
    public async Task TestThatOrderReceiptCostsAsyncCalculatesOrderAndProductCosts()
    {
        _mockedContext.Setup(c => c.ReservedProducts)
            .ReturnsDbSet(_receiptReservedProducts);

        var actual = await _sut.OrderReceiptCostsAsync(ReceiptOrderId, _contractFee);

        var actualIssuedTickets = actual.IssuedTickets.ToList();

        Assert.Equal(1698, actual.TotalOrderCostCents);
        Assert.Equal(10, actual.PaymentFeeCents);
        Assert.Equal(98, actual.TicketServicePlusCostCents);
        Assert.Single(actualIssuedTickets);
        Assert.Equal(20, actualIssuedTickets[0].FeeCents);
    }
}