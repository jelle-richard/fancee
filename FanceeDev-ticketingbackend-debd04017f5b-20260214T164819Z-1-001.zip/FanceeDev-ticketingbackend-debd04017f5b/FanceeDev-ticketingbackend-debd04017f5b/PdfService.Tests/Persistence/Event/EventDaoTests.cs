using System;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Event;

namespace PdfService.Tests.Persistence.Event;

public class EventDaoTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid[] EventIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    private readonly EventDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public EventDaoTests()
    {
        _mockedContext.Setup(c => c.Events).ReturnsDbSet(new FanceeData.Models.Ticketing.Event[]
        {
            new()
            {
                Id = EventIds[0],
                OrganizationId = ValidOrganizationId,
                Status = EventStatus.Unpublished,
                StartDate = DateTime.UtcNow.AddDays(5),
                Name = "Unpublished"
            },
            new()
            {
                Id = EventIds[1],
                OrganizationId = ValidOrganizationId,
                Status = EventStatus.Active,
                StartDate = DateTime.UtcNow.AddDays(-5),
                Name = "Active past event"
            },
            new()
            {
                Id = EventIds[2],
                OrganizationId = ValidOrganizationId,
                Status = EventStatus.Active,
                StartDate = DateTime.UtcNow.AddDays(30),
                Name = "Active event"
            },
            new()
            {
                Id = EventIds[3],
                OrganizationId = Guid.Empty,
                Status = EventStatus.Active,
                StartDate = DateTime.UtcNow.AddDays(8),
                Name = "Active event of different organization"
            },
            new()
            {
                Id = EventIds[4],
                OrganizationId = ValidOrganizationId,
                Status = EventStatus.Active,
                StartDate = DateTime.UtcNow.AddDays(2),
                Name = "Active event #2"
            },
            new()
            {
                Id = EventIds[5],
                OrganizationId = ValidOrganizationId,
                Status = EventStatus.Active,
                StartDate = DateTime.UtcNow.AddDays(3),
                Name = "Active event #3"
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatUpcomingAsyncReturnsUpcomingEvents()
    {
        var actual = (await _sut.UpcomingAsync(ValidOrganizationId, 2, Array.Empty<Guid>())).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal("Active event #2", actual[0].Name);
        Assert.Equal("Active event #3", actual[1].Name);
    }

    [Fact]
    public async Task TestThatUpcomingAsyncExcludesEvents()
    {
        var actual = (await _sut.UpcomingAsync(ValidOrganizationId, 2, new[] { EventIds[4] })).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal("Active event #3", actual[0].Name);
        Assert.Equal("Active event", actual[1].Name);
    }
}