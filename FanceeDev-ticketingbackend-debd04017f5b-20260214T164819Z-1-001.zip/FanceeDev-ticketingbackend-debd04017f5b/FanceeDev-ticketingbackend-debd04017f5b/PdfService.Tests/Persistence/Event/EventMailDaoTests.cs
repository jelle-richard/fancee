using System;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Event;

namespace PdfService.Tests.Persistence.Event;

public class EventMailDaoTests
{
    private static readonly Guid ValidEventId = Guid.NewGuid();

    private readonly EventMailDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public EventMailDaoTests()
    {
        _mockedContext.Setup(c => c.EventMails).ReturnsDbSet(new EventMail[]
        {
            new()
            {
                EventId = ValidEventId,
                Content = "<html>",
                SenderName = "Tester",
                Type = EventMailType.GuestList
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByEventAndTypeAsyncReturnsNullOnInvalidCombination()
    {
        var actual = await _sut.ByEventAndTypeAsync(ValidEventId, EventMailType.DefaultShopMail);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByEventAndTypeAsyncReturnsEventMail()
    {
        var actual = await _sut.ByEventAndTypeAsync(ValidEventId, EventMailType.GuestList);

        Assert.NotNull(actual);
        Assert.Equal(ValidEventId, actual.EventId);
        Assert.Equal(EventMailType.GuestList, actual.Type);
        Assert.Equal("Tester", actual.SenderName);
        Assert.Equal("<html>", actual.Content);
    }
}