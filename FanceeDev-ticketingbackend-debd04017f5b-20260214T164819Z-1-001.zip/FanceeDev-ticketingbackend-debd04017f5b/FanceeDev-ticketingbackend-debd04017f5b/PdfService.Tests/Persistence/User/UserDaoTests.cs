using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using PdfService.Persistence.User;

namespace PdfService.Tests.Persistence.User;

public class UserDaoTests
{
    private static readonly Guid[] UserIds =
    {
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    };

    private static readonly Guid[] AccountVerifyIds =
    {
        Guid.NewGuid(),
        Guid.NewGuid()
    };

    private static readonly List<FanceeData.Models.Ticketing.User> Users = new()
    {
        new()
        {
            Id = UserIds[0],
            AccountVerifyId = AccountVerifyIds[0],
            UserContactInfo = new()
            {
                UserId = UserIds[0],
                FirstName = "Unit",
                LastName = "Test",
                PhoneNumber = "0612345678"
            }
        },
        new()
        {
            Id = UserIds[1],
            AccountVerifyId = AccountVerifyIds[1],
            UserContactInfo = new()
            {
                UserId = UserIds[1],
                FirstName = "Unit",
                LastName = "Test",
                PhoneNumber = "0612345678"
            }
        },
        new()
        {
            Id = UserIds[1],
            UserContactInfo = new()
            {
                UserId = UserIds[1],
                FirstName = "Unit",
                LastName = "Test",
                PhoneNumber = "0612345678"
            }
        }
    };

    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly UserDao _sut;

    public UserDaoTests()
    {
        _mockedContext.Setup(c => c.Users)
            .ReturnsDbSet(Users);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task ByClientIdAsyncShouldReturnValidUserIfIdFound()
    {
        var user = await _sut.ByClientIdAsync(UserIds[0]);

        Assert.Equal(Users[0], user);
    }

    [Fact]
    public async Task ByClientIdAsyncShouldReturnNullIfIdNotFound()
    {
        var user = await _sut.ByClientIdAsync(Guid.NewGuid());

        Assert.Null(user);
    }

    [Fact]
    public async Task ByClientIdAsyncShouldReturnNullIfIdIsFoundButVerifyIdIsNull()
    {
        var user = await _sut.ByClientIdAsync(UserIds[2]);

        Assert.Null(user);
    }
}