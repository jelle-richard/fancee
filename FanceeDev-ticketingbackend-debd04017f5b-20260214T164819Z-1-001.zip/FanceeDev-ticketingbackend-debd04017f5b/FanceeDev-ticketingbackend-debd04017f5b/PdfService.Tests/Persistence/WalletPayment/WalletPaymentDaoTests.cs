using System;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Invoicing;
using Microsoft.EntityFrameworkCore;
using PdfService.Persistence.WalletPayment;

namespace PdfService.Tests.Persistence.WalletPayment;

public class WalletPaymentDaoTests
{
    private static readonly Guid ValidWalletPaymentId = Guid.NewGuid();

    private readonly WalletPaymentDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public WalletPaymentDaoTests()
    {
        _mockedContext.Setup(c => c.WalletPayments).ReturnsDbSet(new FanceeData.Models.Ticketing.Invoicing.WalletPayment[]
        {
            new()
            {
                Id = ValidWalletPaymentId,
                AmountCents = 2300,
                CurrencyShortCode = "EUR",
                IncludeInBalanceIfUnprocessed = true,
                Type = WalletPaymentType.Debit
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsNullOnInvalidId()
    {
        var actual = await _sut.ByIdAsync(Guid.Empty, i => i.Include(wp => wp.Organization));

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsWalletPayment()
    {
        var actual = await _sut.ByIdAsync(ValidWalletPaymentId, i => i.Include(wp => wp.Organization));

        Assert.NotNull(actual);
        Assert.Equal(ValidWalletPaymentId, actual.Id);
        Assert.Equal(2300, actual.AmountCents);
        Assert.Equal("EUR", actual.CurrencyShortCode);
        Assert.True(actual.IncludeInBalanceIfUnprocessed);
        Assert.Equal(WalletPaymentType.Debit, actual.Type);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesWalletPayment()
    {
        var wp = new FanceeData.Models.Ticketing.Invoicing.WalletPayment();

        await _sut.UpdateAsync(wp);

        _mockedContext.Verify(c => c.WalletPayments.Update(wp), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}