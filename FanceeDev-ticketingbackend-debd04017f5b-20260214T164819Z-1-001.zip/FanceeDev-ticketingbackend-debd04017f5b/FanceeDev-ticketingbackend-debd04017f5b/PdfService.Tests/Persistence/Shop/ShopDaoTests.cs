using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Shop;

namespace PdfService.Tests.Persistence.Shop;

public class ShopDaoTests
{
    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly ShopDao _sut;
    private readonly List<Guid> _validOrganizationIds = new()
    {
        Guid.NewGuid(),
        Guid.NewGuid()
    };

    public ShopDaoTests()
    {
        _mockedContext.Setup(c => c.Shops)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Shop>()
        {
            new()
            {
                Code = "ActiveEventByOrganizer1",
                Active = true,
                Event = new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-1),
                    EndDate = DateTime.UtcNow.AddDays(1),
                    OrganizationId = _validOrganizationIds[0],
                }
            },
            new()
            {
                Code = "InactiveEventByOrganizer1",
                Active = false,
                Event = new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-1),
                    EndDate = DateTime.UtcNow.AddDays(1),
                    OrganizationId = _validOrganizationIds[0]
                }
            },
            new()
            {
                Code = "FutureEventByOrganizer1",
                Active = true,
                Event = new()
                {
                    StartDate = DateTime.UtcNow.AddDays(1),
                    EndDate = DateTime.UtcNow.AddDays(2),
                    OrganizationId = _validOrganizationIds[0]
                }
            },
            new()
            {
                Code = "PastEventByOrganizer1",
                Active = true,
                Event = new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-3),
                    EndDate = DateTime.UtcNow.AddDays(-1),
                    OrganizationId = _validOrganizationIds[0]
                }
            },
            new()
            {
                Code = "ActiveEventByOrganizer2",
                Active = true,
                Event = new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-1),
                    EndDate = DateTime.UtcNow.AddDays(1),
                    OrganizationId = _validOrganizationIds[1]
                }
            }
        });

        _sut = new(_mockedContext.Object);
    }
    
    [Fact]
    public async Task TestThatShopCodesByOrganizationIdAsyncReturnsShopCodes()
    {
        var actual = await _sut.ShopCodesByOrganizationIdAsync(_validOrganizationIds[0]);

        var actualAsCollection = actual.ToList();
        Assert.Single(actualAsCollection);
        Assert.Equal("ActiveEventByOrganizer1", actualAsCollection[0]);
    }
}