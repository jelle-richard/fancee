using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Shop;

namespace PdfService.Tests.Persistence.Shop;

public class ShopMailDaoTests
{
    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly ShopMailDao _sut;

    public ShopMailDaoTests()
    {
        _mockedContext.Setup(c => c.ShopMails).ReturnsDbSet(new ShopMail[]
        {
            new()
            {
                ShopCode = "Shop1",
                Type = ShopMailType.Purchase,
                Content = "Content",
                SenderName = "Unit",
                Subject = "Unit purchase mail"
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByShopAndTypeAsyncReturnsNullOnInvalidShopCodeAndTypeCombination()
    {
        var actual = await _sut.ByShopAndTypeAsync("invalid", ShopMailType.Purchase);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByShopAndTypeAsyncReturnsShopMail()
    {
        var actual = await _sut.ByShopAndTypeAsync("Shop1", ShopMailType.Purchase);

        Assert.NotNull(actual);
        Assert.Equal("Content", actual.Content);
    }
}