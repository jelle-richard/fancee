using System;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Ticket;

namespace PdfService.Tests.Persistence.Ticket;

public class TicketDesignDaoTests
{
    private static readonly Guid FocalFile = Guid.NewGuid();
    private static readonly Guid NoFocalFile = Guid.NewGuid();

    private readonly TicketDesignDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public TicketDesignDaoTests()
    {
        _mockedContext.Setup(c => c.TicketDesignMedia).ReturnsDbSet(new TicketDesignMedia[]
        {
            new()
            {
                FileId = FocalFile,
                FocalPointWidthPercentage = 22,
                FocalPointHeightPercentage = 44
            },
            new()
            {
                FileId = NoFocalFile,
                FocalPointWidthPercentage = null,
                FocalPointHeightPercentage = null
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatMediaFocalPointAsyncReturnsNullOnInvalidFileId()
    {
        var actual = await _sut.MediaFocalPointAsync(Guid.Empty);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatMediaFocalPointAsyncReturnsDefaultOf50WhenNoFocalPointIsSetForFile()
    {
        var actual = await _sut.MediaFocalPointAsync(NoFocalFile);

        Assert.NotNull(actual);
        Assert.Equal(50, actual.X);
        Assert.Equal(50, actual.Y);
    }

    [Fact]
    public async Task TestThatMediaFocalPointAsyncReturnsFocalPoint()
    {
        var actual = await _sut.MediaFocalPointAsync(FocalFile);

        Assert.NotNull(actual);
        Assert.Equal(22, actual.X);
        Assert.Equal(44, actual.Y);
    }
}