﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using PdfService.Persistence.Invoice;

namespace PdfService.Tests.Persistence.Invoice;

public class InvoiceDaoTests
{
    private const int ValidInvoiceNumber = 202200010;
    private readonly InvoiceDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly List<FanceeData.Models.Ticketing.Invoicing.Invoice> _invoices = new()
    {
        new()
        {
            Id = ValidInvoiceNumber,
            OrganizationId = Guid.NewGuid(),
            SenderContactDetails = new()
            {
                Address = new() { City = "UnitTest City" },
                PaymentSettings = new() { Iban = "NL13TEST9876123435" }
            },
            ReceiverContactDetails = new()
            {
                Address = new() { City = "UnitTest City" },
                PaymentSettings = new() { Iban = "NL31TEST1111411211" }
            }
        }
    };

    public InvoiceDaoTests()
    {
        _mockedContext.Setup(c => c.Invoices).ReturnsDbSet(_invoices);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsInvoice()
    {
        var actual = await _sut.GetAsync(ValidInvoiceNumber);

        Assert.NotNull(actual);
        Assert.Equal(ValidInvoiceNumber, actual!.Id);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsNullOnInvalidInvoiceNumber()
    {
        var actual = await _sut.GetAsync(9999999);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesInvoice()
    {
        var invoice = _invoices.First();

        await _sut.UpdateAsync(invoice);

        _mockedContext.Verify(c => c.Entry(invoice), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}