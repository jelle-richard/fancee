using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Organization;

namespace PdfService.Tests.Persistence.Organization;

public class OrganizationContractDaoTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidUserId = Guid.NewGuid();

    private static readonly OrganizationContract Contract = new()
    {
        OrganizationId = ValidOrganizationId,
        Start = DateTime.UtcNow.AddYears(-10),
        End = DateTime.UtcNow.AddYears(10),
        PackageType = OrganizationPackageType.Light,
        ProductFeeCents = 50,
        TicketFeeCents = 50,
        Signed = true,
        Organization = new()
        {
            Id = ValidOrganizationId,
            UserId = Guid.NewGuid(),
            MailchimpKey = It.IsAny<string>(),
            CustomTermFileId = Guid.NewGuid(),
            ApproximatedAnnualSalesAmount = 1000,
            DefaultReservationTimeMinutes = 10,
            Name = "name",
            IsImportant = false,
            Currency = "EUR",
            ChamberOfCommerceIdentifier = It.IsAny<string>(),
            CountryCode = "NL",
            User = new()
            {
                Id = ValidUserId,
                FanceeUsersId = Guid.NewGuid(),
                Type = UserType.Organization,
                Email = "Email@Email.com",
                UserContactInfo = new()
                {
                    UserId = ValidUserId,
                    FirstName = "Name",
                    LastName = "Lastname",
                    PhoneNumber = "061245678"
                }
            },
            CurrencyNavigation = new()
            {
                Character = "€",
                ShortCode = "EUR",
                Name = "Euro"
            }
        }
    };

    private readonly OrganizationContractDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public OrganizationContractDaoTests()
    {
        _mockedContext.Setup(c => c.OrganizationContracts)
            .ReturnsDbSet(new List<OrganizationContract>
            {
                Contract
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatRetrieveOrganizationContractAsyncReturnsNullForUnknownOrganizationId()
    {
        var actual = await _sut.RetrieveOrganizationContractAsync(Guid.NewGuid());

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatRetrieveOrganizationContractAsyncReturnsOrganizationContract()
    {
        var actual = await _sut.RetrieveOrganizationContractAsync(ValidOrganizationId);

        Assert.NotNull(actual);
        Assert.Equivalent(Contract, actual);
    }
}