using System;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Organization;

namespace PdfService.Tests.Persistence.Organization;

public class OrganizationContractAddendumDaoTests
{
    private static readonly OrganizationContractAddendum ContractAddendum = new()
    {
        Id = Guid.NewGuid(),
        OrganizationId = Guid.NewGuid(),
        Start = DateTime.UtcNow.AddYears(-10),
        End = DateTime.UtcNow.AddYears(10),
        Text = "Unittest"
    };

    private readonly OrganizationContractAddendumDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public OrganizationContractAddendumDaoTests()
    {
        _mockedContext.Setup(c => c.OrganizationContractAddenda.AddAsync(ContractAddendum, default));
        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInsertContractAsyncSavesChangesAsync()
    {
        await _sut.InsertAddendumAsync(ContractAddendum);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}