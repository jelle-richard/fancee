using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.Organization;
using WebApiCore.Settings;

namespace PdfService.Tests.Persistence.Organization;

public class OrganizationDaoTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid SignedContractOrganizationId = Guid.NewGuid();
    private static readonly Guid NoContractOrganizationId = Guid.NewGuid();

    private static readonly OrganizationDetailsSettings.PackageConfigurations PackageSettings = new()
    {
        Light =
        {
            DefaultProductFeeCents = 99,
            DefaultTicketFeeCents = 99,
            DefaultTicketFeePercentage = 0,
            DefaultProductFeePercentage = 0
        },
        Medium =
        {
            DefaultProductFeeCents = 83,
            DefaultTicketFeeCents = 83,
            MinimumAnnualSalesAmount = 2500,
            DefaultTicketFeePercentage = 0,
            DefaultProductFeePercentage = 0
        }
    };

    private static readonly Currency Currency = new()
    {
        Character = "€",
        ShortCode = "EUR",
        Name = "Euro"
    };

    private static readonly List<FanceeData.Models.Ticketing.Organization> MockedOrganizations = new()
    {
        new()
        {
            Id = ValidOrganizationId,
            Name = "Unit BV",
            User = new()
            {
                UserContactInfo = new()
                {
                    Address = new()
                    {
                        City = "UnitCity",
                        CountryCode = "NL",
                        Street = "UnitStreet",
                        HouseNumber = "12A",
                        Venue = "UnitRoof",
                        PostalCode = "1234AB"
                    },
                    FirstName = "Unit",
                    LastName = "Holder"
                }
            },
            ChamberOfCommerceIdentifier = "12345678",
            PaymentSettings = new()
            {
                VatCode = "UnitVat1234"
            },
            ApproximatedAnnualSalesAmount = 1000,
            Contract = new()
            {
                OrganizationId = ValidOrganizationId,
                Start = DateTime.UtcNow.AddYears(-1),
                End = DateTime.UtcNow.AddYears(1),
                TicketFeeCents = 55,
                ProductFeeCents = 55,
                File = new()
                {
                    Id = Guid.NewGuid(),
                    Name = "UnitFile",
                    Path = "uploads/unit/UnitFile.pdf",
                    DeploymentEnvironmentId = Guid.NewGuid()
                },
                Signed = false,
                PackageType = OrganizationPackageType.Light
            }
        },
        new()
        {
            Id = NoContractOrganizationId,
            Name = "Unit BV",
            User = new()
            {
                UserContactInfo = new()
                {
                    Address = new()
                    {
                        City = "UnitCity",
                        CountryCode = "NL",
                        Street = "UnitStreet",
                        HouseNumber = "12A",
                        Venue = "UnitRoof",
                        PostalCode = "1234AB"
                    },
                    FirstName = "Unit",
                    LastName = "Holder"
                }
            },
            ChamberOfCommerceIdentifier = "12345678",
            PaymentSettings = new() { VatCode = "UnitVat1234" },
            ApproximatedAnnualSalesAmount = 1000,
            Contract = null
        }
    };

    private readonly OrganizationDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public OrganizationDaoTests()
    {
        _mockedContext.Setup(c => c.Organizations)
            .ReturnsDbSet(MockedOrganizations);

        _mockedContext.Setup(c => c.OrganizationContracts)
            .ReturnsDbSet(new List<OrganizationContract>
            {
                new()
                {
                    OrganizationId = ValidOrganizationId,
                    Start = DateTime.UtcNow.AddYears(-1),
                    End = DateTime.UtcNow.AddYears(1),
                    TicketFeeCents = 83,
                    ProductFeeCents = 83,
                    File = new()
                    {
                        Id = Guid.NewGuid(),
                        Name = "UnitFile",
                        Path = "uploads/unit/UnitFile.pdf",
                        DeploymentEnvironmentId = Guid.NewGuid()
                    },
                    Signed = false,
                    PackageType = OrganizationPackageType.Light
                },
                new()
                {
                    OrganizationId = SignedContractOrganizationId,
                    Start = DateTime.UtcNow.AddYears(-1),
                    End = DateTime.UtcNow.AddYears(1),
                    TicketFeeCents = 83,
                    ProductFeeCents = 83,
                    File = new()
                    {
                        Id = Guid.NewGuid(),
                        Name = "UnitFile",
                        Path = "uploads/unit/UnitFile.pdf",
                        DeploymentEnvironmentId = Guid.NewGuid()
                    },
                    Signed = true,
                    PackageType = OrganizationPackageType.Light
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatOrganizationContractDetailsAsyncReturnsNullForUnknownOrganization()
    {
        var actual = await _sut.OrganizationContractDetailsAsync(Guid.NewGuid(), PackageSettings, Currency);

        Assert.Null(actual);
    }

    [Theory]
    [InlineData(OrganizationPackageType.Custom, OrganizationPackageType.Custom, 55, 0)]
    [InlineData(OrganizationPackageType.Custom, OrganizationPackageType.Custom, 55, 3000)]
    [InlineData(OrganizationPackageType.Light, OrganizationPackageType.Light, 55, 0)]
    [InlineData(OrganizationPackageType.Light, OrganizationPackageType.Light, 55, 3000)]
    [InlineData(OrganizationPackageType.Medium, OrganizationPackageType.Medium, 55, 0)]
    [InlineData(OrganizationPackageType.Medium, OrganizationPackageType.Medium, 55, 3000)]
    public async Task TestThatOrganizationContractDetailsAsyncRetrievesDetailsForOrganization(OrganizationPackageType packageType, OrganizationPackageType expectedPackageType, int fee, int sales)
    {
        var mockedOrganization = MockedOrganizations[0];
        mockedOrganization.ApproximatedAnnualSalesAmount = sales;
        mockedOrganization.Contract.PackageType = packageType;

        var actual = await _sut.OrganizationContractDetailsAsync(ValidOrganizationId, PackageSettings, Currency);

        Assert.NotNull(actual);
        Assert.Equal(expectedPackageType, actual.PackageType);
        Assert.Equal(fee, actual.TicketFeeCents);
        Assert.Equal(fee, actual.ProductFeeCents);
        Assert.Equal(sales, actual.ApproximateAnnualSalesAmount);
        Assert.Equal("UnitStreet", actual.Address.Street);
        Assert.Equal("Unit BV", actual.Organization);
    }

    [Theory]
    [InlineData(OrganizationPackageType.Light, 99, 0)]
    [InlineData(OrganizationPackageType.Medium, 83, 3000)]
    public async Task TestThatOrganizationContractDetailsAsyncRetrievesDetailsForOrganizationWhenContractIsNull(OrganizationPackageType expectedPackageType, int fee, int sales)
    {
        var mockedOrganization = MockedOrganizations[1];
        mockedOrganization.ApproximatedAnnualSalesAmount = sales;

        var actual = await _sut.OrganizationContractDetailsAsync(NoContractOrganizationId, PackageSettings, Currency);

        Assert.NotNull(actual);
        Assert.Equal(expectedPackageType, actual.PackageType);
        Assert.Equal(fee, actual.TicketFeeCents);
        Assert.Equal(fee, actual.ProductFeeCents);
        Assert.Equal(sales, actual.ApproximateAnnualSalesAmount);
        Assert.Equal("UnitStreet", actual.Address.Street);
        Assert.Equal("Unit BV", actual.Organization);
    }

    [Fact]
    public async Task TestThatInsertContractAsyncSavesChangesAsync()
    {
        await _sut.InsertContractAsync(new()
        {
            OrganizationId = Guid.NewGuid(),
            Start = DateTime.UtcNow.AddYears(-1),
            End = DateTime.UtcNow.AddYears(1),
            TicketFeeCents = 83,
            ProductFeeCents = 83,
            File = new()
            {
                Id = Guid.NewGuid(),
                Name = "UnitFile",
                Path = "uploads/unit/UnitFile.pdf",
                DeploymentEnvironmentId = Guid.NewGuid()
            },
            Signed = false,
            PackageType = OrganizationPackageType.Light
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateContractFileAsyncSavesUpdatesChangesAsync()
    {
        await _sut.UpdateContractFileAsync(ValidOrganizationId, new()
        {
            Id = Guid.NewGuid(),
            Name = "UnitFile",
            Path = "uploads/unit/UnitFile.pdf",
            DeploymentEnvironmentId = Guid.NewGuid()
        }, true);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateContractFileAsyncDoesNotSaveChangesAsyncForNoContract()
    {
        await _sut.UpdateContractFileAsync(Guid.NewGuid(), new()
        {
            Id = Guid.NewGuid(),
            Name = "UnitFile",
            Path = "uploads/unit/UnitFile.pdf",
            DeploymentEnvironmentId = Guid.NewGuid()
        }, true);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Never);
    }

    [Fact]
    public async Task TestThatUpdateContractFileAsyncDoesNotSaveChangesAsyncForAlreadySignedContract()
    {
        await _sut.UpdateContractFileAsync(SignedContractOrganizationId, new()
        {
            Id = Guid.NewGuid(),
            Name = "UnitFile",
            Path = "uploads/unit/UnitFile.pdf",
            DeploymentEnvironmentId = Guid.NewGuid()
        }, true);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Never);
    }
}