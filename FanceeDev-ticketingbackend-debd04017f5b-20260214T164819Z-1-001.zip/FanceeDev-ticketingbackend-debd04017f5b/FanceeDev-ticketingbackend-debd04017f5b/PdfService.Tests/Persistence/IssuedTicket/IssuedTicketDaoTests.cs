using System;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using PdfService.Persistence.IssuedTicket;

namespace PdfService.Tests.Persistence.IssuedTicket;

public class IssuedTicketDaoTests
{
    private static readonly Guid ValidOrderId = Guid.NewGuid();

    private readonly IssuedTicketDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public IssuedTicketDaoTests()
    {
        _mockedContext.Setup(c => c.IssuedTickets).ReturnsDbSet(new FanceeData.Models.Ticketing.IssuedTicket[]
        {
            new()
            {
                Code = "Code1",
                IssuedProduct = new() { OrderId = ValidOrderId }
            },
            new()
            {
                Code = "Code2",
                IssuedProduct = new() { OrderId = Guid.NewGuid() }
            },
            new()
            {
                Code = "Code3",
                IssuedProduct = new() { OrderId = ValidOrderId }
            },
            new()
            {
                Code = "Code4",
                IssuedProduct = new()
                {
                    Product = new()
                    {
                        Name = "UnitProductName"
                    }
                }
            }
        });

        _mockedContext.Setup(c => c.IssuedTicketSwaps)
            .ReturnsDbSet(Array.Empty<IssuedTicketSwap>());

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByOrderIdAsyncGetsOrderById()
    {
        var actual = await _sut.ByOrderIdAsync(ValidOrderId);

        Assert.Equal(2, actual.Count());
    }

    [Fact]
    public async Task TestThatByCodesAsyncGetsIssuedTicketsByCode()
    {
        var actual = (await _sut.ByCodesAsync(new[] { "Code1", "Code3", "DoesNotExist" })).ToList();

        Assert.Equal(2, actual.Count);
        Assert.All(actual, ticket => Assert.Equal(ValidOrderId, ticket.IssuedProduct.OrderId));
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsNullForUnknownCode()
    {
        var actual = await _sut.ByCodeAsync("UnitTest");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncGetsIssuedTicketByCode()
    {
        var actual = await _sut.ByCodeAsync("Code4");

        Assert.IsType<FanceeData.Models.Ticketing.IssuedTicket>(actual);
        Assert.Equal("UnitProductName", actual.IssuedProduct.Product.Name);
    }

    [Fact]
    public async Task TestThatInsertSwappedTicketAsyncSavesChangesAsync()
    {
        await _sut.InsertSwappedTicketAsync("Code4", "Code5", new()
        {
            Name = "UnitFile"
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}