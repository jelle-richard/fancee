﻿using MailKit.Net.Smtp;
using MailService.Controllers;
using MailService.Providers.MailProvider;
using Mandrill;
using Mandrill.Requests.Messages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MimeKit;
using sib_api_v3_sdk.Api;
using sib_api_v3_sdk.Model;
using TestCore.Mocks;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.Services.Mail;
using Task = System.Threading.Tasks.Task;

namespace MailService.Tests.Controllers;

public class MailControllerTests
{
    private readonly MailController _sut;
    private readonly Mock<ISmtpClient> _mockedSmtpClient;
    private readonly Mock<IMandrillApi> _mockedMandrillApi;
    private readonly Mock<ITransactionalEmailsApi> _mockedSendinblueApi;
    private readonly Mock<IMailer> _mockedMailer;

    public MailControllerTests()
    {
        var mockedConfig = ConfigurationMockUtils.Create(new()
        {
            { "Sendinblue:ApiKey", "jdfj93jfJsdjfj1knnnc" }
        });

        _mockedSmtpClient = new();
        _mockedSmtpClient.SetupGet(sc => sc.IsConnected).Returns(true);

        _mockedMandrillApi = new();
        Mock<ILogger<SmtpMailProvider>> mockedSmtpLogger = new();
        Mock<ILogger<MailchimpMailProvider>> mockedMailchimpLogger = new();

        _mockedSendinblueApi = new();
        Mock<ILogger<SendinblueMailProvider>> mockedSendinblueLogger = new();

        Mock<SmtpMailProvider> mockedSmtpMailProvider = new(mockedConfig, _mockedSmtpClient.Object, mockedSmtpLogger.Object);
        Mock<MailchimpMailProvider> mockedMandrillMailProvider = new(_mockedMandrillApi.Object, mockedMailchimpLogger.Object);
        Mock<SendinblueMailProvider> mockedSendinblueMailProvider = new(_mockedSendinblueApi.Object, mockedConfig, mockedSendinblueLogger.Object);

        _mockedMailer = new();

        _sut = new(new IMailProvider[] { mockedSmtpMailProvider.Object, mockedMandrillMailProvider.Object, mockedSendinblueMailProvider.Object }, _mockedMailer.Object);
    }

    [Fact]
    public async Task TestThatSendSmtpCallsSmtpMailProvider()
    {
        var actual = await _sut.SendSmtp();

        Assert.NotNull(actual);
        Assert.IsType<OkResult>(actual);

        _mockedSmtpClient.Verify(sc => sc.SendAsync(It.Is<MimeMessage>(mm => mm.Subject == "Attachment Email"), default, null), Times.Once);
    }

    [Fact]
    public async Task TestThatSendMailchimpCallsMailchimpMailProvider()
    {
        var actual = await _sut.SendMailchimp();

        Assert.NotNull(actual);
        Assert.IsType<OkResult>(actual);

        _mockedMandrillApi.Verify(ma => ma.SendMessage(It.Is<SendMessageRequest>(smr => smr.Message.Subject == "Attachment Email")), Times.Once);
    }

    [Fact]
    public async Task TestThatSendSendinblueCallsSendinblueMailProvider()
    {
        var actual = await _sut.SendSendinblue();

        Assert.NotNull(actual);
        Assert.IsType<OkResult>(actual);

        _mockedSendinblueApi.Verify(sa => sa.SendTransacEmailAsync(It.Is<SendSmtpEmail>(sse => sse.Subject == "Attachment Email")), Times.Once);
    }

    [Fact]
    public void TestThatAddMailCallsMailer()
    {
        var model = new Mail { Subject = "test" };

        _sut.AddMail(model);

        _mockedMailer.Verify(m => m.Send(model));
    }
}