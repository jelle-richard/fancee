﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PreRegisterService.Controllers;
using PreRegisterService.Dtos.Response.PreRegisters;
using PreRegisterService.Services.PreRegister;
using TestCore.Mocks;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Requests.Filters.Pagination;

namespace PreRegisterService.Tests.Controllers;

public class PreRegistersControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly PreRegistersController _sut;
    private readonly Mock<IPreRegisterService> _mockedPreRegisterService = new();

    public PreRegistersControllerTests()
    {
        _sut = new(_mockedPreRegisterService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatListCallsPreRegisterServiceListPreRegistersAsync()
    {
        var request = new PaginatedRequest<SearchQueryFilter>
        {
            Page = 1,
            PageSize = 10,
            Options = new() { SearchQuery = string.Empty }
        };

        _mockedPreRegisterService.Setup(prs => prs.ListPreRegistersAsync(request, ValidOrganizationId))
            .ReturnsAsync((new List<PreRegisterListItemResponse>(), 0));

        await _sut.List(request);

        _mockedPreRegisterService.Verify(prs => prs.ListPreRegistersAsync(request, ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatExportPreRegistersAsCsvCallsPreRegisterServicePreRegistersCsvAsyncAndServesFile()
    {
        var request = new SearchQueryFilter();
        _mockedPreRegisterService.Setup(prs => prs.PreRegistersCsvAsync(ValidOrganizationId, request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportPreRegistersAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedPreRegisterService.Verify(prs => prs.PreRegistersCsvAsync(ValidOrganizationId, request), Times.Once);
    }
}