﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PreRegisterService.Controllers;
using PreRegisterService.Dtos.Requests.PreRegister;
using PreRegisterService.Dtos.Requests.SignUp;
using PreRegisterService.Dtos.Response.PreRegister;
using PreRegisterService.Dtos.Response.PreRegisterSignUp;
using PreRegisterService.Services.Exceptions;
using PreRegisterService.Services.PreRegister;
using PreRegisterService.Services.SignUp;
using TestCore.Mocks;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;

namespace PreRegisterService.Tests.Controllers;

public class PreRegisterControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly PreRegisterController _sut;
    private readonly Mock<IPreRegisterService> _mockedPreRegisterService = new();
    private readonly Mock<IPreRegisterSignUpService> _mockedPreRegisterSignUpService = new();

    private readonly PreRegisterSignUpRequestModel _requestModel = new()
    {
        Code = new Guid(),
        Email = "unit@test.com",
        FirstName = "John",
        LastName = "Doe"
    };

    public PreRegisterControllerTests()
    {
        _sut = new(_mockedPreRegisterSignUpService.Object, _mockedPreRegisterService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatRegisterSignUpCallsPreRegisterServiceExistsAsync()
    {
        _mockedPreRegisterService.Setup(mprs => mprs.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedPreRegisterService.Setup(prs => prs.HasPreRegisterExpiredAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        var actual = await _sut.RegisterSignUp(_requestModel);

        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedPreRegisterService.Verify(mprs => mprs.ExistsAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRegisterSignUpThrowsPreRegisterNotFoundExceptionOnUnknownPreRegister()
    {
        _mockedPreRegisterService.Setup(mprs => mprs.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<PreRegisterNotFoundException>(async () => await _sut.RegisterSignUp(_requestModel));
    }

    [Fact]
    public async Task TestThatRegisterSignUpThrowsPreRegisterExpiredExceptionOnExpiredPreRegister()
    {
        _mockedPreRegisterService.Setup(prs => prs.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedPreRegisterService.Setup(prs => prs.HasPreRegisterExpiredAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<PreRegisterExpiredException>(async () => await _sut.RegisterSignUp(_requestModel));
    }

    [Fact]
    public async Task TestThatRegisterSignUpCallsPreRegisterSignUpServiceIsRegistered()
    {
        _mockedPreRegisterService.Setup(mprs => mprs.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedPreRegisterService.Setup(prs => prs.HasPreRegisterExpiredAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        var actual = await _sut.RegisterSignUp(_requestModel);

        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedPreRegisterSignUpService.Verify(mprsus => mprsus.IsRegisteredAsync(It.IsAny<Guid>(), It.IsAny<string>()),
            Times.Once);
    }

    [Fact]
    public async Task TestThatRegisterSignUpReturnsCreatedOnDuplicateInsert()
    {
        _mockedPreRegisterService.Setup(mprs => mprs.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedPreRegisterSignUpService.Setup(mprsus => mprsus.IsRegisteredAsync(It.IsAny<Guid>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockedPreRegisterService.Setup(prs => prs.HasPreRegisterExpiredAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        var actual = await _sut.RegisterSignUp(_requestModel);

        Assert.NotNull(actual.Result);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedPreRegisterService.Verify(prs => prs.ExistsAsync(It.IsAny<Guid>()), Times.Once);
        _mockedPreRegisterService.Verify(prs => prs.HasPreRegisterExpiredAsync(It.IsAny<Guid>()), Times.Once);
        _mockedPreRegisterSignUpService.Verify(prss => prss.IsRegisteredAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
        _mockedPreRegisterService.VerifyNoOtherCalls();
        _mockedPreRegisterSignUpService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRegisterSignUpCallsCreateAsyncOnValidRequestModel()
    {
        _mockedPreRegisterService.Setup(mprs => mprs.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedPreRegisterSignUpService.Setup(mprsus => mprsus.IsRegisteredAsync(It.IsAny<Guid>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        _mockedPreRegisterService.Setup(prs => prs.HasPreRegisterExpiredAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        var actual = await _sut.RegisterSignUp(_requestModel);

        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedPreRegisterSignUpService.Verify(mprsus => mprsus.CreateAsync(_requestModel), Times.Once);
    }

    [Fact]
    public async Task TestThatGetCallsPreRegisterServiceGet()
    {
        var code = Guid.NewGuid();
        _mockedPreRegisterService.Setup(prs => prs.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new PreRegisterResponse
            {
                Code = code,
                CreatedAt = DateTime.UtcNow,
                Name = "Unit name",
                Description = "Unit description",
                HeaderMedia = null
            });

        var actual = await _sut.Get(code);

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<PreRegisterResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedPreRegisterService.Verify(prs => prs.GetAsync(code), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteCallsPreRegisterServiceDelete()
    {
        await _sut.Delete(new());

        _mockedPreRegisterService.Verify(prs => prs.DeleteAsync(It.IsAny<Guid>(), ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateCallsPreRegisterServiceCreateAsync()
    {
        await _sut.Create(new()
        {
            Name = "name",
            Description = "description",
            ExpiresOn = null
        });

        _mockedPreRegisterService.Verify(prs => prs.CreateAsync("name", "description", null, ValidOrganizationId),
            Times.Once);
    }

    [Fact]
    public async Task TestThatEditCallsPreRegisterServiceUpdateAsync()
    {
        await _sut.Edit(new(), new()
        {
            Name = "name",
            Description = "description",
            ExpiresOn = null
        });

        _mockedPreRegisterService.Verify(
            prs => prs.UpdateAsync(new(), "name", "description", null, ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignHeaderMediaCallsPreRegisterServiceUploadHeaderMediaAsync()
    {
        _mockedPreRegisterService.Setup(prs =>
                prs.UploadHeaderMediaAsync(new(), ValidOrganizationId, It.IsAny<UploadHeaderMediaRequest>()))
            .ReturnsAsync(new UploadedFile { Id = It.IsAny<Guid>(), Url = "http://localhost/uploads/test.png" });

        var actual = await _sut.AssignHeaderMedia(new(), new());

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);

        var actualResponse = actual.Result as CreatedResult;

        Assert.Equal("http://localhost/uploads/test.png", actualResponse?.Location);

        _mockedPreRegisterService.Verify(
            prs => prs.UploadHeaderMediaAsync(new(), ValidOrganizationId, It.IsAny<UploadHeaderMediaRequest>()),
            Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteHeaderMediaCallsPreRegisterDeleteHeaderMediaAsync()
    {
        await _sut.DeleteHeaderMedia(new());

        _mockedPreRegisterService.Verify(prs => prs.DeleteHeaderMediaAsync(new(), ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatSignUpsThrowsPreRegisterNotFoundExceptionOnInvalidPreRegisterCode()
    {
        var code = Guid.NewGuid();

        _mockedPreRegisterService.Setup(prs => prs.OwnerOfPreRegisterAsync(code, ValidOrganizationId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<PreRegisterNotFoundException>(async () => await _sut.SignUps(code));

        _mockedPreRegisterService.Verify(prs => prs.OwnerOfPreRegisterAsync(code, ValidOrganizationId), Times.Once);
        _mockedPreRegisterService.VerifyNoOtherCalls();
        _mockedPreRegisterSignUpService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSignUpsCallsPreRegisterSignUpServiceDetailsAync()
    {
        var code = Guid.NewGuid();

        _mockedPreRegisterService.Setup(prs => prs.OwnerOfPreRegisterAsync(code, ValidOrganizationId)).ReturnsAsync(true);
        _mockedPreRegisterSignUpService.Setup(prsus => prsus.DetailsAsync(code, ValidOrganizationId))
            .ReturnsAsync(new List<PreRegisterSignUpResponse>());

        var actual = await _sut.SignUps(code);

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<PreRegisterSignUpResponse>>>(((OkObjectResult)actual.Result!).Value);

        _mockedPreRegisterService.Verify(prs => prs.OwnerOfPreRegisterAsync(code, ValidOrganizationId), Times.Once);
        _mockedPreRegisterSignUpService.Verify(prsus => prsus.DetailsAsync(code, ValidOrganizationId), Times.Once);
    }
}