using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using FanceeData.Models.Ticketing;
using UserService.Dtos.Requests.User.Admin;
using UserService.Utils.Adapter;
using WebApiCore.Dtos.Shared;

namespace UserService.Tests.Utils.Adapter;

public class CountryManagerAdapterTests
{
    [Fact]
    public void TestThatToCountryManagerAdaptsRequestToCountryManagerEntity()
    {
        var fanceeUsersId = Guid.NewGuid();
        var request = new CreateCountryManagerRequest
        {
            Email = "unit@test.com",
            Password = "UnitTesterPass123!",
            CountryCode = CountryCode.NL,
            FirstName = "Unit",
            LastName = "Tester",
            TerminatesOn = DateTime.UtcNow.AddYears(1),
            Claims = new()
            {
                "profile.details"
            }
        };

        var expectedCountryManager = new CountryManager
        {
            Countries = new Collection<Country>
            {
                new() { Code = CountryCode.NL.ToString() }
            },
            StartedOn = DateTime.UtcNow,
            TerminatedOn = DateTime.UtcNow.AddYears(1),
            Role = AdminRole.CountryManager,
            User = new()
            {
                FanceeUsersId = fanceeUsersId,
                Email = "unit@test.com",
                UserContactInfo = new()
                {
                    FirstName = "Unit",
                    LastName = "Tester"
                },
                UserClaims = new List<UserClaim>
                {
                    new()
                    {
                        ClaimType = ClaimType.Permission,
                        ClaimValue = "profile.details"
                    }
                }
            }
        };

        var adaptedCountryManager = request.ToCountryManager(fanceeUsersId);

        Assert.IsType<CountryManager>(adaptedCountryManager);
        Assert.Equivalent(expectedCountryManager.Countries, adaptedCountryManager.Countries, true);
        Assert.Equal(expectedCountryManager.User.UserContactInfo.LastName, adaptedCountryManager.User.UserContactInfo.LastName);
        Assert.Equal(1, adaptedCountryManager.User.UserClaims.Count);
        Assert.Equal("profile.details", adaptedCountryManager.User.UserClaims.First().ClaimValue);
    }
}