using System.Linq;
using FanceeData.Models.Ticketing;
using UserService.Utils.Adapter;

namespace UserService.Tests.Utils.Adapter;

public class UserClaimAdapterTests
{
    [Fact]
    public void TestThatToUserPermissionsConvertsStringEnumerableToUserClaims()
    {
        var claims = new[]
        {
            "user.claim1",
            "admin.truncate-system"
        };

        var actual = claims.ToUserPermissions().ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal(ClaimType.Permission, actual[0].ClaimType);
        Assert.Equal("user.claim1", actual[0].ClaimValue);
        Assert.Equal(ClaimType.Permission, actual[1].ClaimType);
        Assert.Equal("admin.truncate-system", actual[1].ClaimValue);
    }
}