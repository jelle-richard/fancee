using System;
using System.Collections.Generic;
using FanceeData.Models.Ticketing;
using UserService.Dtos.Requests.User.Admin;
using UserService.Utils.Adapter;

namespace UserService.Tests.Utils.Adapter;

public class CustomerServiceEmployeeTests
{
    [Fact]
    public void TestThatToCustomerServiceEmployeeAdaptsRequestToCustomerServiceEmployeeEntity()
    {
        var fanceeUsersId = Guid.NewGuid();
        var countryManagerId = Guid.NewGuid();
        var request = new CreateCustomerServiceEmployeeRequest
        {
            Email = "unit@test.com",
            Password = "UnitTesterPass123!",
            FirstName = "Unit",
            LastName = "Tester",
            CountryManagerId = countryManagerId,
            Claims = new()
            {
                "profile.details"
            }
        };

        var expectedCustomerServiceEmployee = new CustomerServiceEmployee
        {
            Role = AdminRole.CustomerServiceEmployee,
            CountryManagerId = countryManagerId,
            User = new()
            {
                FanceeUsersId = fanceeUsersId,
                Email = "unit@test.com",
                UserContactInfo = new()
                {
                    FirstName = "Unit",
                    LastName = "Tester"
                },
                UserClaims = new List<UserClaim>
                {
                    new()
                    {
                        ClaimType = ClaimType.Permission,
                        ClaimValue = "profile.details"
                    }
                }
            }
        };

        var adaptedCustomerServiceEmployee = request.ToCustomerServiceEmployee(fanceeUsersId);

        Assert.IsType<CustomerServiceEmployee>(adaptedCustomerServiceEmployee);
        Assert.Equal(expectedCustomerServiceEmployee.User.Email, request.Email);
        Assert.Equal(expectedCustomerServiceEmployee.User.UserContactInfo.FirstName, request.FirstName);
        Assert.Equal(expectedCustomerServiceEmployee.CountryManagerId, request.CountryManagerId);
    }
}