﻿using System;
using System.Collections.Generic;
using System.Linq;
using CommerceUtils.Providers.Models;
using FanceeData.Models.Ticketing;
using UserService.Dtos.Requests.Organization;
using UserService.Dtos.Responses.Organization;
using UserService.Dtos.Shared.Profile;
using UserService.Services.Organization.Exceptions;
using UserService.Utils.Adapter;
using WebApiCore.Dtos.Environment;
using Address = FanceeData.Models.Ticketing.Address;

namespace UserService.Tests.Utils.Adapter;

public class OrganizationAdapterTests
{
    [Fact]
    public void TestThatOrganizationGetsAdaptedToOrganizationContractResponse()
    {
        const string timezoneIdentification = "Europe/Amsterdam";
        var localDate = DateTime.UtcNow;
        var organization = new Organization
        {
            Contract = new()
            {
                Start = localDate,
                End = localDate,
                PackageType = OrganizationPackageType.Light,
                ProductFeeCents = 98,
                TicketFeeCents = 99,
                GuestListFeeCents = 10
            }
        };

        var actual = organization.Contract.ToOrganizationContract(timezoneIdentification);

        Assert.Equal(98, actual.ProductFeeCents);
        Assert.Equal(99, actual.TicketFeeCents);
        Assert.Equal(10, actual.GuestListFeeCents);
        Assert.Equal(OrganizationPackageType.Light, actual.PackageType);
        Assert.Equal(localDate, actual.Start);
        Assert.Equal(localDate, actual.Start);
        Assert.Equal(timezoneIdentification, actual.TimezoneIdentification);
        Assert.IsType<OrganizationContractSpecificationResponse>(actual);
    }

    [Theory]
    [InlineData(ContactInfoRole.Finance, RoleDto.Finance)]
    [InlineData(ContactInfoRole.CustomerSupport, RoleDto.CustomerSupport)]
    [InlineData(ContactInfoRole.Marketing, RoleDto.Marketing)]
    [InlineData(ContactInfoRole.Organization, RoleDto.Organization)]
    public void TestThatToRoleDtoReturnsExpectedResult(ContactInfoRole? input, RoleDto expected)
    {
        var actual = input.ToRoleDto();

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatToRoleDtoThrowsInvalidContactInfoRoleExceptionOnInvalidRole()
    {
        ContactInfoRole? role = null;

        // ReSharper disable once ExpressionIsAlwaysNull
        Assert.Throws<InvalidContactInfoRoleException>(() => role.ToRoleDto());
    }

    [Fact]
    public void TestThatToOrganizationContactInfosReturnsIdentifiedOrganizationContactDtos()
    {
        var infos = new List<OrganizationContactInfo>
        {
            new()
            {
                Id = Guid.NewGuid(),
                Email = "unit@test.com",
                FirstName = "Unit",
                LastName = "Test",
                PhoneNumber = "123",
                Role = ContactInfoRole.CustomerSupport
            }
        };

        var actual = infos.ToOrganizationContactInfos()?.ToList();

        Assert.NotNull(actual);
        Assert.Single(actual);
        Assert.Equal(infos[0].Id, actual[0].Id);
        Assert.Equal(infos[0].Email, actual[0].Email);
        Assert.Equal(infos[0].FirstName, actual[0].FirstName);
        Assert.Equal(infos[0].LastName, actual[0].LastName);
        Assert.Equal(infos[0].PhoneNumber, actual[0].PhoneNumber);
        Assert.Equal(RoleDto.CustomerSupport, actual[0].Role);
    }

    [Fact]
    public void TestThatToAddressDtoReturnsMappedAddress()
    {
        var address = new Address
        {
            CountryCode = "NL",
            Street = "street",
            PostalCode = "1234AB",
            City = "UnitCity",
            HouseNumber = "93o"
        };

        var actual = address.ToAddressDto();

        Assert.NotNull(actual);
        Assert.Null(actual.Venue);
        Assert.Null(actual.Latitude);
        Assert.Null(actual.Longitude);
        Assert.Equal("NL", actual.CountryCode);
        Assert.Equal("street", actual.Street);
        Assert.Equal("1234AB", actual.PostalCode);
        Assert.Equal("UnitCity", actual.City);
        Assert.Equal("93o", actual.HouseNumber);
    }

    [Fact]
    public void TestThatToOrganizationProfileDtoReturnsOrganizationProfileDto()
    {
        var organization = new Organization
        {
            Name = "Unit BV",
            CountryCode = "DE",
            CurrencyNavigation = new()
            {
                ShortCode = "EUR"
            },
            User = new()
            {
                Email = "organization@test.com",
                UserContactInfo = new()
                {
                    FirstName = "Unit",
                    LastName = "Test",
                    Address = new()
                    {
                        CountryCode = "NL",
                        City = "UnitCity",
                        Street = "UnitStreet",
                        HouseNumber = "29583",
                        PostalCode = "UnitPostalCode"
                    }
                }
            },
            ChamberOfCommerceIdentifier = "1234TEST",
            ContactInfos = new OrganizationContactInfo[]
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Email = "support@test.com",
                    FirstName = "Harry",
                    LastName = "Schippers",
                    PhoneNumber = "1234",
                    Role = ContactInfoRole.CustomerSupport
                }
            },
            PaymentSettings = new()
            {
                Iban = "NLTEST0006004010",
                Bic = "TESTNL01492",
                VatCode = "24912593"
            }
        };

        var actual = organization.ToOrganizationProfileDto();

        Assert.NotNull(actual);
        Assert.Equal("organization@test.com", actual.Holder.Email);
        Assert.Equal("Unit", actual.Holder.FirstName);
        Assert.Equal("Test", actual.Holder.LastName);
        Assert.Equal("Unit BV", actual.LegalEntity.Name);
        Assert.Equal("1234TEST", actual.LegalEntity.ChamberOfCommerceIdentifier);
        Assert.Equal("DE", actual.LegalEntity.CountryCode);
        Assert.Equal("NLTEST0006004010", actual.Finance.Iban);
        Assert.Equal("TESTNL01492", actual.Finance.Bic);
        Assert.Equal("24912593", actual.Finance.VatCode);
        Assert.Equal("NL", actual.Address.CountryCode);
        Assert.False(actual.TwoFactorEnabled);
    }

    [Fact]
    public void TestThatUpdateAddressReturnsNullIfCommerceAddressIsNull()
    {
        var address = new Address();

        var actual = address.UpdateAddress(commerceAddress: null);

        Assert.Null(actual);
    }

    [Fact]
    public void TestThatUpdateAddressUpdatesAddressFromCommerceAddress()
    {
        var address = new Address { Id = Guid.NewGuid(), CountryCode = "DE", PostalCode = "46419", City = "Anholt", Street = "Schloß", HouseNumber = "1" };
        var commerceAddress = new CommerceUtils.Providers.Models.Address { Country = CountryCode.NL, PostalCode = "7041AC", City = "'s-Heerenberg", Street = "Hof van Bergh", HouseNumber = "8" };

        var actual = address.UpdateAddress(commerceAddress);

        Assert.NotNull(actual);
        Assert.Equal(commerceAddress.Country.ToString(), actual.CountryCode);
        Assert.Equal(commerceAddress.PostalCode, actual.PostalCode);
        Assert.Equal(commerceAddress.City, actual.City);
        Assert.Equal(commerceAddress.Street, actual.Street);
        Assert.Equal(commerceAddress.HouseNumber, actual.HouseNumber);
        Assert.Null(actual.Venue);
        Assert.Null(actual.Latitude);
        Assert.Null(actual.Longitude);
    }

    [Fact]
    public void TestThatToOrganizationNoteResponseParsedOrganizationNoteToOrganizationNoteResponse()
    {
        var note = new OrganizationNote
        {
            Id = Guid.NewGuid(),
            Admin = new()
            {
                User = new()
                {
                    Email = "admin@email.com",
                    UserContactInfo = new()
                    {
                        FirstName = "John",
                        LastName = "Doe"
                    }
                }
            },
            Description = "note description",
            PlacedOn = DateTime.UtcNow.AddDays(-3),
            Files = new List<File>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Path = "Unit/file/path",
                    OriginalFileName = "image.jpg",
                    MimeType = "image/jpg"
                }
            }
        };

        var actual = note.ToOrganizationNoteResponse();

        Assert.Equal("admin@email.com", actual.AdminEmail);
        Assert.Equal("note description", actual.Description);
        Assert.Equal("image.jpg", actual.Files.First().OriginalFileName);
    }

    [Fact]
    public void TestThatToOrganizationShopPaletteResponseAdaptsShopColorPalletToResponse()
    {
        var palette = new ShopColorPalette
        {
            PrimaryColor = "FEFEF1",
            TextColor = "FEFEF3",
            BackdropColor = "FEFEF4",
            BackgroundColor = "FEFEF5"
        };

        var actual = palette.ToOrganizationShopPaletteResponse();

        Assert.Equal(palette.PrimaryColor, actual.PrimaryColor);
        Assert.Equal(palette.TextColor, actual.TextColor);
        Assert.Equal(palette.BackdropColor, actual.BackdropColor);
        Assert.Equal(palette.BackdropColor, actual.BackdropColor);
    }

    [Fact]
    public void TestThatUpdateOrganizationShopPaletteUpdatesTheShopColorPalletFromRequest()
    {
        var palette = new ShopColorPalette
        {
            PrimaryColor = "FEFEF1",
            TextColor = "FEFEF3",
            BackdropColor = "FEFEF4",
            BackgroundColor = "FEFEF5"
        };

        palette.UpdateOrganizationShopPalette(new()
        {
            PrimaryColor = "FFFFF1",
            TextColor = "FFFFF3",
            BackdropColor = "FFFFF4",
            BackgroundColor = "FFFFF5"
        });

        Assert.Equal("FFFFF1", palette.PrimaryColor);
        Assert.Equal("FFFFF3", palette.TextColor);
        Assert.Equal("FFFFF4", palette.BackdropColor);
        Assert.Equal("FFFFF5", palette.BackgroundColor);
    }

    [Fact]
    public void TestThatToShopColorPaletteParsedRequestToShopColorPaletteForOrganization()
    {
        var request = new OrganizationShopPaletteRequestModel
        {
            PrimaryColor = "FFFFF1",
            TextColor = "FFFFF3",
            BackdropColor = "FFFFF4",
            BackgroundColor = "FFFFF5"
        };
        var organizationId = Guid.NewGuid();

        var actual = request.ToShopColorPalette(organizationId);

        Assert.Equal(organizationId, actual.OrganizationId);
        Assert.Equal("FFFFF1", actual.PrimaryColor);
        Assert.Equal("FFFFF3", actual.TextColor);
        Assert.Equal("FFFFF4", actual.BackdropColor);
        Assert.Equal("FFFFF5", actual.BackgroundColor);
    }

    [Fact]
    public void TestThatToOrganizationResponseMapsAvatar()
    {
        var organization = new Organization
        {
            User = new()
            {
                UserMedia = new()
                {
                    File = new()
                    {
                        Id = Guid.Empty,
                        Path = "test.png",
                        OriginalFileName = "_test_.png",
                        MimeType = "image/png"
                    },
                    FocalPointHeightPercentage = 1,
                    FocalPointWidthPercentage = 99
                }
            },
            CurrencyNavigation = new(),
            ContactInfos = new List<OrganizationContactInfo>(),
            OrganizationUsers = new List<OrganizationUser>()
        };

        var env = new HostedDeploymentEnvironment
        {
            ContentDeliveryNetworkBaseUrl = "unit.test",
            IsHttps = false
        };

        var actual = organization.ToOrganizationResponse(true, false, env);

        Assert.NotNull(actual.Avatar);
        Assert.Equal(Guid.Empty, actual.Avatar.Id);
        Assert.Equal("http://unit.test/test.png", actual.Avatar.Url);
        Assert.Equal(99, actual.Avatar.FocalPointWidthPercentage);
        Assert.Equal(1, actual.Avatar.FocalPointHeightPercentage);
        Assert.Equal("_test_.png", actual.Avatar.OriginalFileName);
        Assert.Equal("image/png", actual.Avatar.MimeType);
    }

    [Fact]
    public void TestThatToOrganizationResponseMapsManagedBy()
    {
        var organization = new Organization
        {
            User = new()
            {
                UserMedia = new()
                {
                    File = new()
                    {
                        Id = Guid.Empty,
                        Path = "test.png",
                        OriginalFileName = "_test_.png",
                        MimeType = "image/png"
                    },
                    FocalPointHeightPercentage = 1,
                    FocalPointWidthPercentage = 99
                }
            },
            CurrencyNavigation = new(),
            ContactInfos = new List<OrganizationContactInfo>(),
            OrganizationUsers = new List<OrganizationUser>
            {
                new()
                {
                    User = new()
                    {
                        Id = Guid.Empty,
                        FanceeUsersId = Guid.NewGuid(),
                        Email = "manager@test.com",
                        UserContactInfo = new()
                        {
                            FirstName = "Mana",
                            LastName = "Ger"
                        },
                        UserMedia = new()
                        {
                            File = new()
                            {
                                Id = Guid.Empty,
                                Path = "manager.png",
                                OriginalFileName = "_manager_.png",
                                MimeType = "image/png"
                            },
                            FocalPointHeightPercentage = 22,
                            FocalPointWidthPercentage = 44
                        },
                        UserClaims = Array.Empty<UserClaim>()
                    },
                    UserClaims = Array.Empty<OrganizationUserClaim>()
                }
            }
        };

        var env = new HostedDeploymentEnvironment
        {
            ContentDeliveryNetworkBaseUrl = "unit.test",
            IsHttps = false
        };

        var actual = organization.ToOrganizationResponse(true, false, env);
        var actualManagers = actual.ManagedBy.ToList();

        Assert.NotNull(actual.Avatar);
        Assert.Equal(actual.Avatar, actualManagers[0].Avatar);
        Assert.Equal(2, actualManagers.Count);
        Assert.Equal("http://unit.test/manager.png", actualManagers[1].Avatar?.Url);
        Assert.Equal("Mana", actualManagers[1].FirstName);
        Assert.Equal("Ger", actualManagers[1].LastName);
        Assert.IsType<Guid>(actualManagers[1].FanceeUsersId);
    }

    [Theory]
    [InlineData("Light", OrganizationPackageType.Light)]
    [InlineData("Medium", OrganizationPackageType.Medium)]
    [InlineData("Custom", OrganizationPackageType.Custom)]
    public void TestThatToOrganizationPackageTypeAdaptsAllPossibleTypes(string input, OrganizationPackageType expected)
    {
        var actual = input.ToOrganizationPackageType();

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatToOrganizationPackageTypeThrowsUnknownOrganizationPackageTypeExceptionWhenUnknownPackageTypeHasBeenProvided()
    {
        Assert.Throws<UnknownOrganizationPackageTypeException>(() => "InvalidType".ToOrganizationPackageType());
    }
}