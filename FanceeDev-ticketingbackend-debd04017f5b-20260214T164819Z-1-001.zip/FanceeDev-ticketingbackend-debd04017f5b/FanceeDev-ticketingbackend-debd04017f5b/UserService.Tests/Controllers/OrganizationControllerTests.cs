using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.Organization;
using UserService.Dtos.Requests.User.Organization;
using UserService.Dtos.Responses.Organization;
using UserService.Dtos.Shared.Profile;
using UserService.Services.Organization;
using UserService.Services.Organization.Exceptions;
using WebApiCore.Dtos.Requests.Event;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.Event;
using WebApiCore.Dtos.Responses.ShopField;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.User;

namespace UserService.Tests.Controllers;

[TestSubject(typeof(OrganizationController))]
public class OrganizationControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidFanceeUsersId = Guid.NewGuid();

    private readonly OrganizationController _sut;
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    public OrganizationControllerTests()
    {
        _sut = new(_mockedOrganizationService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatGetContractReturnsOkResultForOrganizationWithContract()
    {
        _mockedOrganizationService.Setup(us => us.OrganizationContractAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new OrganizationContractSpecificationResponse
            {
                TicketFeeCents = 50
            });

        var actual = await _sut.GetContract();

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ActionResult<ApiResponse<OrganizationContractSpecificationResponse>>>(actual);
    }

    [Fact]
    public async Task TestThatGetContractReturnsNotFoundResultForOrganizationWithoutContract()
    {
        _mockedOrganizationService.Setup(us => us.OrganizationContractAsync(It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        var actual = await _sut.GetContract();

        Assert.IsType<NotFoundObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatGetProfileReturnsOkResult()
    {
        _mockedOrganizationService.Setup(os => os.ProfileAsync(ValidOrganizationId))
            .ReturnsAsync(new OrganizationProfileDto());

        var actual = await _sut.GetProfile();

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<OrganizationProfileDto>>(((OkObjectResult)actual.Result).Value);
    }

    [Fact]
    public async Task TestThatDeleteContactThrowsOrganizationContactNotFoundExceptionIfOrganizationIsNotOwnerOfContact()
    {
        var contactId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfContactAsync(contactId, ValidOrganizationId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<OrganizationContactNotFoundException>(async () => await _sut.DeleteContact(contactId));

        _mockedOrganizationService.Verify(os => os.OwnerOfContactAsync(contactId, ValidOrganizationId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteContactCallsOrganizationServiceRemoveContactAsync()
    {
        var contactId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.OwnerOfContactAsync(contactId, ValidOrganizationId)).ReturnsAsync(true);

        var actual = await _sut.DeleteContact(contactId);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfContactAsync(contactId, ValidOrganizationId), Times.Once);
        _mockedOrganizationService.Verify(os => os.RemoveContactAsync(ValidOrganizationId, contactId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddContactCallsOrganizationServiceCreateContactAsync()
    {
        var newId = Guid.NewGuid();
        var request = new OrganizationContactDto
        {
            Email = "new@test.com",
            FirstName = "Unit",
            LastName = "Test",
            PhoneNumber = "123454523",
            Role = RoleDto.Finance
        };

        _mockedOrganizationService.Setup(os => os.CreateContactAsync(ValidOrganizationId, request)).ReturnsAsync(newId);

        var actual = await _sut.AddContact(request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedAtActionResult>(actual.Result);
        Assert.IsType<ApiResponse<Guid>>(((CreatedAtActionResult)actual.Result).Value);
        Assert.Equal(newId, ((ApiResponse<Guid>)((CreatedAtActionResult)actual.Result).Value)?.Data);

        _mockedOrganizationService.Verify(os => os.CreateContactAsync(ValidOrganizationId, request), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateContactThrowsOrganizationContactNotFoundExceptionIfOrganizationIsNotOwnerOfContact()
    {
        var contactId = Guid.NewGuid();
        var request = new OrganizationContactDto();

        await Assert.ThrowsAsync<OrganizationContactNotFoundException>(async () => await _sut.UpdateContact(contactId, request));

        _mockedOrganizationService.Verify(os => os.OwnerOfContactAsync(contactId, ValidOrganizationId), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateContactCallsOrganizationServiceUpdateContactAsync()
    {
        var contactId = Guid.NewGuid();
        var request = new OrganizationContactDto { Email = "unit@test.com", FirstName = "Unit", LastName = "Test", PhoneNumber = "324", Role = RoleDto.Finance };

        _mockedOrganizationService.Setup(os => os.OwnerOfContactAsync(contactId, ValidOrganizationId))
            .ReturnsAsync(true);

        var actual = await _sut.UpdateContact(contactId, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedOrganizationService.Verify(os => os.OwnerOfContactAsync(contactId, ValidOrganizationId), Times.Once);
        _mockedOrganizationService.Verify(os => os.UpdateContactAsync(contactId, ValidOrganizationId, request), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateAccountHolderCallsOrganizationServiceUpdateHolderAsync()
    {
        _sut.SetupHttpContext(organizationId: ValidOrganizationId, fanceeUsersId: ValidFanceeUsersId);

        var request = new HolderRequest
        {
            FirstName = "First",
            LastName = "Last",
            CustomerSupportContact = new()
        };

        var actual = await _sut.UpdateAccountHolder(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedOrganizationService.Verify(os => os.UpdateHolderAsync(ValidFanceeUsersId, ValidOrganizationId, request), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateCompanyInfoCallsOrganizationServiceUpdateCompanyInfoAsync()
    {
        _sut.SetupHttpContext(organizationId: ValidOrganizationId);

        var request = new CompanyInfoRequest
        {
            LegalEntity = new(),
            Address = new()
        };

        var actual = await _sut.UpdateCompanyInfo(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedOrganizationService.Verify(os => os.UpdateCompanyInfoAsync(ValidOrganizationId, request), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateFinanceCallsOrganizationServiceUpdateFinanceAsync()
    {
        _sut.SetupHttpContext(organizationId: ValidOrganizationId);

        var request = new FinanceRequest();

        var actual = await _sut.UpdateFinance(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedOrganizationService.Verify(os => os.UpdateFinanceAsync(ValidOrganizationId, request), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGetOrganizationThrowsUserNotFoundExceptionForInvalidOrganizationId()
    {
        _sut.SetupHttpContext(organizationId: Guid.Empty);

        _mockedOrganizationService.Setup(os => os.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.GetOrganization(new()));
    }

    [Fact]
    public async Task TestThatGetOrganizationCallsOrganizationServiceOrganizationAsyncOnValidCall()
    {
        _sut.SetupHttpContext(platformUserId: Guid.Empty);

        _mockedOrganizationService.Setup(os => os.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrganizationService.Setup(os => os.OrganizationAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(new OrganizationResponse
            {
                Email = "unit@email.com",
                ManagedBy = Enumerable.Empty<OrganizationUserResponse>()
            });

        var actual = await _sut.GetOrganization(Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrganizationService.Verify(os => os.OrganizationAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDefaultPaymentMethodsCallsOrganizationServiceDefaultPaymentMethodsAsync()
    {
        _mockedOrganizationService.Setup(os => os.DefaultPaymentMethodsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<AvailablePaymentMethodResponse>());

        var actual = await _sut.DefaultPaymentMethods();

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.DefaultPaymentMethodsAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignDefaultPaymentMethodsCallsOrganizationServiceAssignDefaultPaymentMethodsAsync()
    {
        _mockedOrganizationService.Setup(os => os.AssignDefaultPaymentMethodsAsync(ValidOrganizationId, It.IsAny<IEnumerable<PaymentMethodRequestModel>>()));

        var actual = await _sut.AssignDefaultPaymentMethods(new()
        {
            PaymentMethods = new List<PaymentMethodRequestModel>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    PaidBy = PaidByDto.Client
                }
            }
        });

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.AssignDefaultPaymentMethodsAsync(ValidOrganizationId, It.IsAny<IEnumerable<PaymentMethodRequestModel>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRequestPackageChangeThrowsUserNotFoundExceptionIfOrganizationDoesNotExist()
    {
        _sut.SetupHttpContext(organizationId: Guid.Empty);

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.RequestPackageChange(OrganizationPackageType.Medium));
    }

    [Fact]
    public async Task TestThatRequestPackageChangeCallsOrganizationServiceRequestPackageChange()
    {
        var organizationId = Guid.NewGuid();

        _sut.SetupHttpContext(organizationId: organizationId);

        _mockedOrganizationService.Setup(os => os.ExistsAsync(It.IsAny<Guid>())).ReturnsAsync(true);

        var actual = await _sut.RequestPackageChange(OrganizationPackageType.Medium);

        Assert.IsType<ActionResult<ApiResponse<EmptyResponse>>>(actual);

        _mockedOrganizationService.Verify(os => os.RequestPackageChange(organizationId, OrganizationPackageType.Medium), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignDefaultShopFieldsCallsOrganizationServiceAssignDefaultShopFieldsAsync()
    {
        _mockedOrganizationService.Setup(os => os.AddDefaultShopFieldsAsync(ValidOrganizationId, It.IsAny<IEnumerable<ShopFieldRequestModel>>()));

        var actual = await _sut.AssignDefaultShopFields(new()
        {
            ShopFields = new List<ShopFieldRequestModel>
            {
                new()
                {
                    ShopField = ShopField.Email,
                    Enabled = true,
                    Required = true
                },
                new()
                {
                    ShopField = ShopField.FirstName,
                    Enabled = true,
                    Required = true
                },
                new()
                {
                    ShopField = ShopField.LastName,
                    Enabled = true,
                    Required = true
                }
            }
        });

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationService.Verify(os => os.AddDefaultShopFieldsAsync(ValidOrganizationId, It.IsAny<IEnumerable<ShopFieldRequestModel>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDefaultShopFieldsCallsOrganizationServiceDefaultShopFieldsAsync()
    {
        _mockedOrganizationService.Setup(os => os.DefaultShopFieldsAsync(ValidOrganizationId))
            .ReturnsAsync(new List<OrganizationDefaultShopFieldResponse>());

        var actual = await _sut.DefaultShopFields();

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<OrganizationDefaultShopFieldResponse>>>(((OkObjectResult)actual.Result!).Value);
    }

    [Fact]
    public async Task TestThatDefaultShopPalettesReturnsShopPalette()
    {
        _mockedOrganizationService.Setup(os => os.DefaultShopPaletteAsync(ValidOrganizationId))
            .ReturnsAsync(new OrganizationShopPaletteResponse());

        var actual = await _sut.DefaultShopPalette();

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<OrganizationShopPaletteResponse>>(((OkObjectResult)actual.Result!).Value);
    }

    [Fact]
    public async Task TestThatAssignDefaultShopPaletteReturnsValidResponse()
    {
        var request = new AssignOrganizationShopPaletteRequestModel
        {
            OrganizationShopPalette = new()
            {
                BackdropColor = "FFFFFF",
                BackgroundColor = "FFFFFF",
                PrimaryColor = "FFFFFF",
                TextColor = "FFFFFF"
            }
        };

        _mockedOrganizationService.Setup(os => os.AssignOrganizationShopPaletteAsync(ValidOrganizationId, request.OrganizationShopPalette));

        var actual = await _sut.AssignDefaultShopPalette(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationService.Verify(os => os.AssignOrganizationShopPaletteAsync(ValidOrganizationId, request.OrganizationShopPalette), Times.Once);
    }

    [Fact]
    public async Task TestThatSetOrganizationImportantThrowsInvalidUserTypeExceptionForNonAdmins()
    {
        _sut.SetupHttpContext(platformUserId: Guid.Empty, userType: UserType.Organization.ToString());

        await Assert.ThrowsAsync<InvalidUserTypeException>(async () => await _sut.SetOrganizationImportant(Guid.NewGuid(), false));
    }

    [Fact]
    public async Task TestThatSetOrganizationImportantThrowsUserNotFoundExceptionForInvalidOrganizationId()
    {
        _sut.SetupHttpContext(platformUserId: Guid.Empty, userType: UserType.Admin.ToString());

        _mockedOrganizationService.Setup(os => os.ExistsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.SetOrganizationImportant(Guid.NewGuid(), false));
    }

    [Fact]
    public async Task TestThatSetOrganizationImportantCallsOrganizationServiceSetOrganizationImportantState()
    {
        var userId = Guid.NewGuid();

        _sut.SetupHttpContext(platformUserId: userId, userType: UserType.Admin.ToString());

        _mockedOrganizationService.Setup(os => os.ExistsAsync(ValidOrganizationId))
            .ReturnsAsync(true);

        await _sut.SetOrganizationImportant(ValidOrganizationId, true);

        _mockedOrganizationService.Verify(os => os.SetOrganizationImportantStateAsync(userId, ValidOrganizationId, true));
    }

    [Fact]
    public async Task TestThatDeleteDefaultShopFieldAsyncCallsOrganizationServiceDeleteDefaultShopFieldsAsync()
    {
        const ShopFieldDto shopField = ShopFieldDto.Email;

        var actual = await _sut.DeleteDefaultShopFieldAsync(shopField);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedOrganizationService.Verify(os => os.DeleteDefaultShopFieldAsync(ValidOrganizationId, shopField), Times.Once);
        _mockedOrganizationService.VerifyNoOtherCalls();
    }
}