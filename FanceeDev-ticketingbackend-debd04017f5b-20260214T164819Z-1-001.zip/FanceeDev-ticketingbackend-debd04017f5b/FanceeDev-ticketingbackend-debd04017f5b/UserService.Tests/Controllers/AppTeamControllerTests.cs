using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.AppTeam;
using UserService.Dtos.Responses.AppTeam;
using UserService.Services.AppTeam;
using UserService.Services.Organization;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.File;
using WebApiCore.Exceptions;

namespace UserService.Tests.Controllers;

public class AppTeamControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private static readonly AppTeamResponse AppTeamResponse = new()
    {
        Name = "UnitTeam",
        SalesEnabled = true,
        StatisticsEnabled = true,
        ScanningEnabled = true,
        ScanGuestlistEnabled = false,
        Products = new List<AppTeamProductResponse>
        {
            new()
            {
                Id = Guid.NewGuid(),
                Name = "Unit ticket",
                Media = Array.Empty<FileResponse>()
            }
        }
    };

    private readonly AppTeamController _sut;
    private readonly Mock<IAppTeamService> _mockedAppTeamService = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    public AppTeamControllerTests()
    {
        _sut = new(_mockedAppTeamService.Object, _mockedOrganizationService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatGetThrowsAppTeamNotFoundExceptionOnInvalidAppTeamOrganizationLink()
    {
        _sut.SetupHttpContext(organizationId: ValidOrganizationId, userType: UserType.Organization.ToString());

        _mockedOrganizationService.Setup(os => os.AppTeamBelongsToOrganizationAsync(ValidOrganizationId, It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<AppTeamNotFoundException>(async () => await _sut.Get(Guid.Empty));
    }

    [Fact]
    public async Task TestThatGetCallsAppTeamServiceAppTeamAsync()
    {
        _sut.SetupHttpContext(organizationId: ValidOrganizationId, userType: UserType.Organization.ToString());

        _mockedOrganizationService.Setup(os => os.AppTeamBelongsToOrganizationAsync(ValidOrganizationId, It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedAppTeamService.Setup(ats => ats.AppTeamAsync(It.IsAny<Guid>()))
            .ReturnsAsync(AppTeamResponse);

        var actual = await _sut.Get(Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedAppTeamService.Verify(ats => ats.AppTeamAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetByAppTeamGetsAppTeamForAppTeamUser()
    {
        var appTeamId = Guid.NewGuid();

        _sut.SetupHttpContext(appTeamId: appTeamId);

        var actual = await _sut.GetByAppTeam();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<AppTeamResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedAppTeamService.Verify(ats => ats.AppTeamAsync(appTeamId), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateCallsAppTeamServiceCreateAsync()
    {
        var appTeamId = Guid.NewGuid();
        var request = new AppTeamRequest
        {
            Name = "Unit Name",
            AssignedProducts = [Guid.NewGuid(), Guid.NewGuid()],
            SalesEnabled = true,
            StatisticsEnabled = true,
            ScanningEnabled = true,
            ScanGuestlistEnabled = false
        };

        _mockedAppTeamService.Setup(ats => ats.CreateAsync(ValidOrganizationId, request))
            .ReturnsAsync(new AppTeamCreateResponse
            {
                Id = appTeamId
            });

        var actual = await _sut.Create(request);

        Assert.IsType<CreatedAtActionResult>(actual.Result);

        _mockedAppTeamService.Verify(ats => ats.CreateAsync(ValidOrganizationId, request));
    }

    [Fact]
    public async Task TestThatDeleteTeamThrowsAppTeamNotFoundExceptionOnInvalidAppTeamToOrganizationLink()
    {
        var appTeamId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.AppTeamBelongsToOrganizationAsync(ValidOrganizationId, appTeamId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<AppTeamNotFoundException>(async () => await _sut.Delete(appTeamId));
    }

    [Fact]
    public async Task TestThatDeleteTeamCallsAppTeamServiceDeleteAsync()
    {
        var appTeamId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.AppTeamBelongsToOrganizationAsync(ValidOrganizationId, appTeamId))
            .ReturnsAsync(true);

        _mockedAppTeamService.Setup(ats => ats.DeleteAsync(appTeamId));

        var actual = await _sut.Delete(appTeamId);

        _mockedAppTeamService.Verify(ats => ats.DeleteAsync(appTeamId), Times.Once);

        Assert.IsType<OkResult>(actual);
    }

    [Fact]
    public async Task TestThatUpdateThrowsAppTeamNotFoundExceptionOnInvalidAppTeamToOrganizationLink()
    {
        var appTeamId = Guid.NewGuid();

        _mockedOrganizationService.Setup(os => os.AppTeamBelongsToOrganizationAsync(ValidOrganizationId, appTeamId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<AppTeamNotFoundException>(async () => await _sut.Update(appTeamId, new()));
    }

    [Fact]
    public async Task TestThatUpdateCallsAppTeamServiceUpdateAsync()
    {
        var appTeamId = Guid.NewGuid();
        var request = new AppTeamRequest
        {
            Name = "UnitAppTeam",
            SalesEnabled = true,
            StatisticsEnabled = true,
            ScanningEnabled = true,
            AssignedProducts = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()]
        };

        _mockedOrganizationService.Setup(os => os.AppTeamBelongsToOrganizationAsync(ValidOrganizationId, appTeamId))
            .ReturnsAsync(true);

        var actual = await _sut.Update(appTeamId, request);

        Assert.IsType<OkResult>(actual.Result);

        _mockedAppTeamService.Verify(ats => ats.UpdateAsync(ValidOrganizationId, appTeamId, request));
    }
}