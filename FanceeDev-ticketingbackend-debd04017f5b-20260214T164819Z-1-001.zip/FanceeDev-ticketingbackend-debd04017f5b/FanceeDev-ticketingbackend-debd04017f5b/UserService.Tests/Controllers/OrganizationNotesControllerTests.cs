using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationNote;
using UserService.Services.OrganizationNote.Exceptions;

namespace UserService.Tests.Controllers;

public class OrganizationNotesControllerTests
{
    private static readonly Guid ValidAdminId = Guid.NewGuid();
    private static readonly Guid ValidFanceeUsersId = Guid.NewGuid();

    private readonly OrganizationNotesController _sut;
    private readonly Mock<IOrganizationNoteService> _mockedOrganizationNoteService = new();

    public OrganizationNotesControllerTests()
    {
        _sut = new(_mockedOrganizationNoteService.Object);

        _sut.SetupHttpContext(platformUserId: ValidAdminId, fanceeUsersId: ValidFanceeUsersId, userType: UserType.Admin.ToString());
    }

    [Fact]
    public async Task TestThatGetNotesCallsOrganizationNoteServiceGetNotesAsync()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), null))
            .ReturnsAsync(true);
        _mockedOrganizationNoteService.Setup(ons => ons.NotesAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<OrganizationNoteResponse>());

        var actual = await _sut.GetNotes(Guid.NewGuid());

        _mockedOrganizationNoteService.Verify(ons => ons.NotesAsync(It.IsAny<Guid>()), Times.Once);
        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), null), Times.Once);

        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatGetNotesThrowsInvalidNoteMutationException()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), null))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidNoteMutationException>(async () => await _sut.GetNotes(Guid.NewGuid()));
    }
}