using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.User.Admin;
using UserService.Services.Organization;
using UserService.Services.Organization.Exceptions;
using WebApiCore.Services.Logging;

namespace UserService.Tests.Controllers;

[TestSubject(typeof(OrganizationContractController))]
public class OrganizationContractControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly OrganizationContractController _sut;
    private readonly Mock<IOrganizationContractService> _mockedOrganizationContractService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();

    public OrganizationContractControllerTests()
    {
        _sut = new(_mockedOrganizationContractService.Object, _mockedUserLoggingService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId, platformUserId: Guid.NewGuid());
    }

    [Fact]
    public async Task TestThatDownloadContractAsAdminCallsOrganizationContractServiceActiveContractFileAsZipAsync()
    {
        _mockedOrganizationContractService.Setup(ocs => ocs.ActiveContractFileAsZipAsync(ValidOrganizationId))
            .ReturnsAsync(new byte[] { 5, 3, 4 });

        var actual = await _sut.DownloadContractAsAdmin(ValidOrganizationId);

        Assert.IsType<FileContentResult>(actual);
        _mockedOrganizationContractService.Verify(ocs => ocs.ActiveContractFileAsZipAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadContractCallsOrganizationContractServiceActiveContractFileAsZipAsync()
    {
        _mockedOrganizationContractService.Setup(ocs => ocs.ActiveContractFileAsZipAsync(ValidOrganizationId))
            .ReturnsAsync(new byte[] { 5, 3, 4 });

        var actual = await _sut.DownloadContractAsZip();

        Assert.IsType<FileContentResult>(actual);
        _mockedOrganizationContractService.Verify(ocs => ocs.ActiveContractFileAsZipAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadContractCallsOrganizationContractServiceActiveContractFileAsync()
    {
        using var testStream = new MemoryStream(Encoding.UTF8.GetBytes("UNIT_BYTES"));
        _mockedOrganizationContractService.Setup(ocs => ocs.ActiveContractFileAsync(ValidOrganizationId))
            .ReturnsAsync(testStream);

        var actual = await _sut.DownloadContract();

        Assert.IsType<FileStreamResult>(actual);
        _mockedOrganizationContractService.Verify(ocs => ocs.ActiveContractFileAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatSignContractThrowsNoSignableContractExceptionForOrganizationWithoutUnsignedContract()
    {
        _mockedOrganizationContractService.Setup(ocs => ocs.HasUnsignedContractAsync(ValidOrganizationId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<NoSignableContractException>(async () => await _sut.SignContract(new()));
        _mockedOrganizationContractService.Verify(ocs => ocs.HasUnsignedContractAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatSignContractCallsOrganizationContractServiceSignContractAsync()
    {
        _mockedOrganizationContractService.Setup(ocs => ocs.HasUnsignedContractAsync(ValidOrganizationId))
            .ReturnsAsync(true);

        _mockedOrganizationContractService.Setup(ocs => ocs.SignContractAsync(ValidOrganizationId, It.IsAny<IFormFile>()));

        var actual = await _sut.SignContract(new()
        {
            Media = new FormFile(Stream.Null, 0, 0, "unitFile", "unitFileName")
        });

        _mockedOrganizationContractService.Verify(ocs => ocs.HasUnsignedContractAsync(ValidOrganizationId), Times.Once);
        _mockedOrganizationContractService.Verify(ocs => ocs.SignContractAsync(ValidOrganizationId, It.IsAny<IFormFile>()), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatGenerateAddendumCallsCreateContractAddendumAsync()
    {
        _mockedOrganizationContractService.Setup(ocs => ocs.CreateContractAddendumAsync(ValidOrganizationId, It.IsAny<CreateContractAddendumRequest>()));

        var actual = await _sut.GenerateAddendum(ValidOrganizationId, It.IsAny<CreateContractAddendumRequest>());

        _mockedOrganizationContractService.Verify(ocs => ocs.CreateContractAddendumAsync(ValidOrganizationId, It.IsAny<CreateContractAddendumRequest>()), Times.Once());
        Assert.IsType<CreatedResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatUpdatePackageCallsOrganizationContractServiceUpdateOrganizationPackageTypeAsyncWithPackageType()
    {
        _mockedOrganizationContractService.Setup(ocs => ocs.UpdateOrganizationPackageTypeAsync(ValidOrganizationId, OrganizationPackageType.Custom));

        var actual = await _sut.UpdatePackageType(ValidOrganizationId, "Custom");

        _mockedOrganizationContractService.Verify(ocs => ocs.UpdateOrganizationPackageTypeAsync(ValidOrganizationId, OrganizationPackageType.Custom), Times.Once);
        Assert.IsType<OkObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatAlterContractCallsOrganizationContractServiceAlterContractAsync()
    {
        var request = new AlterContractRequest { ProductFeeCents = 10, TicketFeeCents = 20, GuestListFeeCents = 30 };

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.AlterContract(ValidOrganizationId, request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationContractService.Verify(ocs => ocs.AlterContractAsync(ValidOrganizationId, request), Times.Once);
        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
        _mockedOrganizationContractService.VerifyNoOtherCalls();
    }
}