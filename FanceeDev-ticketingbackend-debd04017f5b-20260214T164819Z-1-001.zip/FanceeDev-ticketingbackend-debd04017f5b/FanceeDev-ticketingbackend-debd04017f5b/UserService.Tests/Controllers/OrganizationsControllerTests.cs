using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.Organization;
using UserService.Dtos.Responses.Organization;
using UserService.Services.Organization;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;
using WebApiCore.Services.Country;
using WebApiCore.Services.Logging;

namespace UserService.Tests.Controllers;

public class OrganizationsControllerTests
{
    private static readonly Guid ValidAdminId = Guid.NewGuid();

    private readonly OrganizationsController _sut;
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();

    public OrganizationsControllerTests()
    {
        _sut = new(_mockedOrganizationService.Object, _mockedCountryService.Object, _mockedUserLoggingService.Object);

        _sut.SetupHttpContext(platformUserId: ValidAdminId, userType: UserType.Admin.ToString());
    }

    [Fact]
    public async Task TestThatGetListCallsOrganizationServiceOrganizationsAsync()
    {
        var request = new PaginatedRequest<OrganizationRequestFilter>
        {
            Page = 1,
            PageSize = 10,
            Options = new() { SearchQuery = string.Empty }
        };

        _mockedCountryService.Setup(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), request.Options.CountryCodes))
            .ReturnsAsync((IEnumerable<string>)null);

        _mockedOrganizationService.Setup(os => os.OrganizationsAsync(request))
            .ReturnsAsync(new PaginatedResultSet<OrganizationListResponse>
            {
                Items = new List<OrganizationListResponse>
                {
                    new()
                    {
                        Email = "unit@test.com"
                    }
                },
                TotalItems = 2
            });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.GetList(request);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrganizationService.Verify(os => os.OrganizationsAsync(It.IsAny<PaginatedRequest<OrganizationRequestFilter>>()));
        _mockedCountryService.Verify(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<string>>()), Times.Once);
        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAdminExportOrganizationsAsCsvCallsOrganizationServiceOrganizationsAsCsvAsyncAndServesFile()
    {
        var request = new OrganizationRequestFilter { SearchQuery = string.Empty };

        _mockedCountryService.Setup(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), request.CountryCodes));

        _mockedOrganizationService.Setup(os => os.OrganizationsAsCsvAsync(It.IsAny<OrganizationRequestFilter>()))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.AdminExportOrganizationsAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);
        _mockedOrganizationService.Verify(os => os.OrganizationsAsCsvAsync(It.IsAny<OrganizationRequestFilter>()), Times.Once);
        _mockedCountryService.Verify(cs => cs.RestrictCountryCodesAsync(It.IsAny<Guid>(), It.IsAny<IEnumerable<string>>()), Times.Once);
    }
}