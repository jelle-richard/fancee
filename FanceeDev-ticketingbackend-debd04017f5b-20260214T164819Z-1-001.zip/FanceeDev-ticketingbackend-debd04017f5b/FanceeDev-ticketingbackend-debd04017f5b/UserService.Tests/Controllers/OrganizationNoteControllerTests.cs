using System;
using System.IO;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.OrganizationNote;
using UserService.Services.OrganizationNote;
using UserService.Services.OrganizationNote.Exceptions;
using WebApiCore.Dtos.Responses.File;

namespace UserService.Tests.Controllers;

public class OrganizationNoteControllerTests
{
    private static readonly Guid ValidAdminId = Guid.NewGuid();
    private static readonly Guid ValidFanceeUsersId = Guid.NewGuid();

    private readonly OrganizationNoteController _sut;
    private readonly Mock<IOrganizationNoteService> _mockedOrganizationNoteService = new();

    public OrganizationNoteControllerTests()
    {
        _sut = new(_mockedOrganizationNoteService.Object);

        _sut.SetupHttpContext(platformUserId: ValidAdminId, fanceeUsersId: ValidFanceeUsersId, userType: UserType.Admin.ToString());
    }

    [Fact]
    public async Task TestThatCreateNoteThrowsInvalidNoteMutationExceptionIfAdminIsNotEligibleForNoteMutations()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), null))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidNoteMutationException>(async () => await _sut.CreateNote(Guid.NewGuid(), new()));

        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), null), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateNoteThrowsInvalidNoteMutationExceptionIfAdminIsNotEligibleForNoteMutations()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidNoteMutationException>(async () => await _sut.UpdateNote(Guid.NewGuid(), Guid.NewGuid(), new()));

        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteNoteThrowsInvalidNoteMutationExceptionIfAdminIsNotEligibleForNoteMutations()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidNoteMutationException>(async () => await _sut.DeleteNote(Guid.NewGuid(), Guid.NewGuid()));

        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteNoteFileThrowsInvalidNoteMutationExceptionIfAdminIsNotEligibleForNoteMutations()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), Guid.NewGuid()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidNoteMutationException>(async () => await _sut.DeleteNoteFile(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()));

        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateNoteCallsOrganizationNoteServiceCreateNoteAsync()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), null))
            .ReturnsAsync(true);

        _mockedOrganizationNoteService.Setup(ons => ons.CreateNoteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<OrganizationNoteRequest>()))
            .ReturnsAsync(Guid.NewGuid);

        var actual = await _sut.CreateNote(Guid.NewGuid(), new()
        {
            Description = "UnitNote"
        });

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), null), Times.Once);
        _mockedOrganizationNoteService.Verify(ons => ons.CreateNoteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<OrganizationNoteRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateNoteCallsOrganizationNoteServiceUpdateNoteAsync()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrganizationNoteService.Setup(ons => ons.UpdateNoteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), Guid.NewGuid(), It.IsAny<OrganizationNoteRequest>()));

        var actual = await _sut.UpdateNote(Guid.NewGuid(), Guid.NewGuid(), new()
        {
            Description = "UnitNote"
        });

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
        _mockedOrganizationNoteService.Verify(ons => ons.UpdateNoteAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<OrganizationNoteRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteNoteCallsOrganizationNoteServiceDeleteNoteAsync()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrganizationNoteService.Setup(ons => ons.DeleteNoteAsync(It.IsAny<Guid>()));

        var actual = await _sut.DeleteNote(Guid.NewGuid(), Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
        _mockedOrganizationNoteService.Verify(ons => ons.DeleteNoteAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteNoteFileCallsOrganizationNoteService()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrganizationNoteService.Setup(ons => ons.DeleteNoteFileAsync(It.IsAny<Guid>()));

        var actual = await _sut.DeleteNoteFile(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid());

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
        _mockedOrganizationNoteService.Verify(ons => ons.DeleteNoteFileAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadNoteFileCallsOrganizationNoteServiceNoteFileAsync()
    {
        _mockedOrganizationNoteService.Setup(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(true);

        _mockedOrganizationNoteService.Setup(ons => ons.NoteFileAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new NamedFileStreamResultResponse
            {
                File = new(new MemoryStream("I'm a PDF!"u8.ToArray()), "application/pdf"),
                Name = "UnitFile.pdf"
            });

        var actual = await _sut.DownloadNoteFile(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid());

        _mockedOrganizationNoteService.Verify(ons => ons.AdminEligibleForOrganizationNoteMutation(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
        _mockedOrganizationNoteService.Verify(ons => ons.NoteFileAsync(It.IsAny<Guid>()), Times.Once);

        Assert.Equal("application/pdf", actual.ContentType);
    }
}