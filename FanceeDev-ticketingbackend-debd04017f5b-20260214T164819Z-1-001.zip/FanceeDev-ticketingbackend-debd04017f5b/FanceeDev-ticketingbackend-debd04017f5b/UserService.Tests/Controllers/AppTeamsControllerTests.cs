using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.AppTeam;
using UserService.Dtos.Responses.AppTeams;
using UserService.Services.AppTeam;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Requests.Filters.Pagination;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;

namespace UserService.Tests.Controllers;

public class AppTeamsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly AppTeamsController _sut;
    private readonly Mock<IAppTeamService> _mockedAppTeamService = new();

    public AppTeamsControllerTests()
    {
        _sut = new(_mockedAppTeamService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatListCallsAppTeamServiceListAsync()
    {
        var request = new PaginatedRequest<SearchQueryFilter>
        {
            Page = 1,
            PageSize = 10,
            Options = new()
            {
                SearchQuery = ""
            }
        };

        _mockedAppTeamService.Setup(ats => ats.ListAsync(ValidOrganizationId, request))
            .ReturnsAsync(new PaginatedResultSet<AppTeamListItemResponse>
            {
                Items = new List<AppTeamListItemResponse>
                {
                    new()
                    {
                        Id = Guid.NewGuid(),
                        Name = "UnitTeam1"
                    },
                    new()
                    {
                        Id = Guid.NewGuid(),
                        Name = "UnitTeam2"
                    }
                },
                TotalItems = 2
            });

        var actual = await _sut.List(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedAppTeamService.Verify(ats => ats.ListAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatExportOrganizationTicketsAsCsvCallsAppTeamServiceExportOrganizationAppTeamsAsCsvAsyncAndServesCsv()
    {
        var request = new SearchQueryFilter
        {
            SearchQuery = null
        };

        _mockedAppTeamService.Setup(ats => ats.ExportOrganizationAppTeamsAsCsvAsync(ValidOrganizationId, request))
            .ReturnsAsync(new FileContentResult(Array.Empty<byte>(), "text/csv"));

        var actual = await _sut.ExportOrganizationTicketsAsCsv(request);

        Assert.Equal("text/csv", actual.ContentType);

        _mockedAppTeamService.Verify(ats => ats.ExportOrganizationAppTeamsAsCsvAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatListAppTeamSelectOptionsCallsAppTeamServiceListSelectOptionsAsync()
    {
        var id = Guid.NewGuid();
        var request = new AppTeamOptionsRequest();

        _mockedAppTeamService.Setup(ats => ats.ListSelectOptionsAsync(ValidOrganizationId, request))
            .ReturnsAsync([new SelectOptionResponse<Guid> { Id = id, Label = "Unit" }]);

        var actual = await _sut.ListAppTeamSelectOptions(request);

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(((OkObjectResult)actual.Result!).Value);

        var actualValue = (ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>)((OkObjectResult)actual.Result!).Value;
        Assert.NotNull(actualValue);
        Assert.Single(actualValue.Data);
        Assert.Equal(id, actualValue.Data.First().Id);

        _mockedAppTeamService.Verify(ats => ats.ListSelectOptionsAsync(ValidOrganizationId, request), Times.Once);
        _mockedAppTeamService.VerifyNoOtherCalls();
    }
}