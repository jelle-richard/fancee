using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.OrganizationUser;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationUsers;
using WebApiCore.Dtos.Responses;

namespace UserService.Tests.Controllers;

public class OrganizationUsersControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly OrganizationUsersController _sut;
    private readonly Mock<IOrganizationUsersService> _mockedOrganizationUsersService = new();

    public OrganizationUsersControllerTests()
    {
        _sut = new(_mockedOrganizationUsersService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatGetOrganizationUsersCallsOrganizationUsersServiceGetAsync()
    {
        _mockedOrganizationUsersService.Setup(ous => ous.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<OrganizationUserResponse>());

        var actual = await _sut.GetOrganizationUsers();

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ActionResult<ApiResponse<IEnumerable<OrganizationUserResponse>>>>(actual);

        _mockedOrganizationUsersService.Verify(ous => ous.GetAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatAddOrganizationUserCallsOrganizationUsersServiceAddAsync()
    {
        _mockedOrganizationUsersService.Setup(ous => ous.AddAsync(
                It.IsAny<AddOrganizationUserRequest>(),
                It.IsAny<Guid>()
            ))
            .ReturnsAsync(It.IsAny<OrganizationUserResponse>());

        var actual = await _sut.AddOrganizationUser(new()
        {
            Email = "unit@test.com",
            Claims = new[] { "organization.event.list" }
        });

        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ActionResult<ApiResponse<OrganizationUserResponse>>>(actual);

        _mockedOrganizationUsersService.Verify(ous => ous.AddAsync(
            It.IsAny<AddOrganizationUserRequest>(),
            It.IsAny<Guid>()
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteOrganizationUserCallsOrganizationUsersServiceDeleteAsync()
    {
        _mockedOrganizationUsersService.Setup(ous => ous.DeleteAsync(It.IsAny<Guid>(), It.IsAny<Guid>()));

        var actual = await _sut.DeleteOrganizationUser(It.IsAny<Guid>());

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ActionResult<ApiResponse<EmptyResponse>>>(actual);

        _mockedOrganizationUsersService.Verify(ous => ous.DeleteAsync(ValidOrganizationId, It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateOrganizationUserCallsOrganizationUsersServiceUpdateAsync()
    {
        _mockedOrganizationUsersService.Setup(ous => ous.UpdateAsync(It.IsAny<UpdateOrganizationUserRequest>(), It.IsAny<Guid>()));

        var actual = await _sut.UpdateOrganizationUser(It.IsAny<UpdateOrganizationUserRequest>());

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ActionResult<ApiResponse<EmptyResponse>>>(actual);

        _mockedOrganizationUsersService.Verify(ous => ous.UpdateAsync(It.IsAny<UpdateOrganizationUserRequest>(), ValidOrganizationId), Times.Once);
    }
}