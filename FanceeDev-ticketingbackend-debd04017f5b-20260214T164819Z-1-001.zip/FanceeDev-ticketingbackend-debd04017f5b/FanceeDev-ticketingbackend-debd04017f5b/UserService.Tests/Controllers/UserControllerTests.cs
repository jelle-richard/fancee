﻿using System;
using System.Net;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.User;
using UserService.Dtos.Responses.User;
using UserService.Services.Password;
using UserService.Services.Password.Exceptions;
using UserService.Services.User;
using UserService.Services.User.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;

namespace UserService.Tests.Controllers;

public class UserControllerTests
{
    private const string OldPassword = "OldPassword!";
    private const string NewPassword = "NewPassword!";
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidFanceeUsersId = Guid.NewGuid();

    private readonly UserController _sut;
    private readonly Mock<IUserService> _mockedUserService;
    private readonly Mock<IPasswordService> _mockedPasswordService;

    public UserControllerTests()
    {
        _mockedUserService = new();
        _mockedPasswordService = new();

        _sut = new(_mockedUserService.Object, _mockedPasswordService.Object);

        _sut.SetupHttpContext(platformUserId: ValidOrganizationId, userType: UserType.Organization.ToString(), fanceeUsersId: ValidFanceeUsersId);
    }

    [Fact]
    public async Task TestThatCreateReturnsExpectedResponse()
    {
        var actual = await _sut.Create(new() { Email = "unit@test.com", Password = "passw0rd" });

        Assert.IsType<ActionResult<ApiResponse<CreateUserResponse>>>(actual);
    }

    [Fact]
    public async Task TestThatAlreadyUsedEmailThrowsEmailAlreadyInUseException()
    {
        var model = new CreateRequest { Email = "in@use.com", Password = "passw0rd" };

        _mockedUserService.Setup(u => u.CreateAsync(model)).Throws(new EmailAlreadyInUseException("in@use.com"));

        await Assert.ThrowsAsync<EmailAlreadyInUseException>(() => _sut.Create(model));
    }

    [Fact]
    public async Task TestThatChangePasswordChangesThePassword()
    {
        var actual = await _sut.ChangePassword(new() { NewPassword = NewPassword, OldPassword = OldPassword });

        _mockedPasswordService.Verify(p => p.ChangeAsync(OldPassword, NewPassword, It.IsAny<Guid>()));
        Assert.IsType<ActionResult<ApiResponse<EmptyResponse>>>(actual);
    }

    [Fact]
    public async Task TestThatChangePasswordWithInvalidPasswordThrowsInvalidPasswordException()
    {
        _mockedPasswordService.Setup(p => p.ChangeAsync(OldPassword, NewPassword, ValidFanceeUsersId))
            .ThrowsAsync(new InvalidPasswordException());

        await Assert.ThrowsAsync<InvalidPasswordException>(async () => await _sut.ChangePassword(new() { NewPassword = NewPassword, OldPassword = OldPassword }));
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("      ")]
    [InlineData(null)]
    public async Task TestThatForgotPasswordReturnsOkOnEmptyEmail(string input)
    {
        var actual = await _sut.ForgotPassword(input);

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);
    }

    [Fact]
    public async Task TestThatForgotPasswordCallsPasswordServiceOnValidEmail()
    {
        _mockedPasswordService.Setup(p => p.AddPasswordResetTokenAsync("unit@test.com", It.IsAny<IPAddress>()));

        var mockedControllerContext = new Mock<ControllerContext>();
        var mockedHttpContext = new Mock<HttpContext>();
        mockedHttpContext.SetupGet(x => x.Connection.RemoteIpAddress).Returns(IPAddress.Parse("127.0.0.1"));
        mockedControllerContext.Object.HttpContext = mockedHttpContext.Object;
        _sut.ControllerContext = mockedControllerContext.Object;

        var actual = await _sut.ForgotPassword("unit@test.com");

        Assert.IsType<OkObjectResult>(actual.Result);

        var actualResult = (OkObjectResult)actual.Result;

        Assert.IsType<ApiResponse<EmptyResponse>>(actualResult.Value);
        Assert.Equal((int)HttpStatusCode.OK, actualResult.StatusCode);
    }

    [Fact]
    public async Task TestThatResetPasswordCallsPasswordService()
    {
        const string newPassword = "New@Password!";
        var guid = Guid.NewGuid();

        var actual = await _sut.ResetPassword(new() { NewPassword = newPassword, ResetToken = guid });

        _mockedPasswordService.Verify(p => p.ChangeAsync(guid, newPassword), Times.Once);

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);
    }

    [Theory]
    [InlineData(UserType.Admin)]
    [InlineData(UserType.Host)]
    public async Task TestThatPrivateUserTypesCannotBeUsedForPubliclyAvailableCreate(UserType userType)
    {
        var request = new CreateRequest
        {
            Email = "unit@test.com",
            Password = "UnitPass",
            Type = userType
        };

        var actual = await _sut.Create(request);

        Assert.IsType<UnauthorizedObjectResult>(actual.Result);
    }

    [Fact]
    public async Task TestThatVerifyUserCallsUserServiceVerifyAsync()
    {
        var verifyId = Guid.NewGuid();
        var request = new VerifyRequest { VerifyId = verifyId };

        var actual = await _sut.VerifyUser(request);

        Assert.IsType<OkObjectResult>(actual);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual).Value);

        _mockedUserService.Verify(us => us.VerifyAsync(verifyId), Times.Once);
    }

    [Fact]
    public async Task TestThatUploadAvatarAsyncCallsUserServiceUploadMediaAsync()
    {
        var request = new UploadUserMediaRequest();

        _mockedUserService.Setup(us => us.UploadMediaAsync(ValidOrganizationId, request))
            .ReturnsAsync(new UploadedFile { Id = It.IsAny<Guid>(), Url = "http://unit.test/" });

        var actual = await _sut.UploadAvatar(request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<Guid>>(((CreatedResult)actual.Result).Value);

        _mockedUserService.Verify(us => us.UploadMediaAsync(ValidOrganizationId, request), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAvatarAsyncCallsUserServiceDeleteMediaAsync()
    {
        _mockedUserService.Setup(us => us.DeleteMediaAsync(ValidOrganizationId));

        var actual = await _sut.DeleteAvatar();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result).Value);

        _mockedUserService.Verify(us => us.DeleteMediaAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAndVerifyUserCallsUpdateExistingClientAndVerifyAsync()
    {
        var verifyId = Guid.NewGuid();
        var request = new CreateAndVerifyRequest { VerifyId = verifyId, Password = "password" };

        var actual = await _sut.UpdateAndVerifyUser(request);

        Assert.IsType<OkObjectResult>(actual);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual).Value);

        _mockedUserService.Verify(us => us.UpdateExistingClientAndVerifyAsync(request), Times.Once);
    }

    [Fact]
    public async Task TestThatUserIsNotYetVerifiedCallsIsUserNotYetVerifiedAsync()
    {
        var verifyId = Guid.NewGuid();

        _mockedUserService.Setup(us => us.IsVerifiedAsync(verifyId))
            .ReturnsAsync(true);
        var actual = await _sut.IsVerified(verifyId);

        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<bool>>(((OkObjectResult)actual.Result!).Value);
        _mockedUserService.Verify(us => us.IsVerifiedAsync(verifyId), Times.Once);
    }
}