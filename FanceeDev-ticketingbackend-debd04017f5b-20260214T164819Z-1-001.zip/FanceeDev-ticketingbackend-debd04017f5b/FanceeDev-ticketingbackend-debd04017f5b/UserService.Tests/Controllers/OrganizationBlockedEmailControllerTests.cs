using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationBlockedEmail;
using WebApiCore.Dtos.Responses;

namespace UserService.Tests.Controllers;

public class OrganizationBlockedEmailControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly OrganizationBlockedEmailController _sut;
    private readonly Mock<IOrganizationBlockedEmailService> _mockedOrganizationBlockedEmailService = new();

    public OrganizationBlockedEmailControllerTests()
    {
        _sut = new(_mockedOrganizationBlockedEmailService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatCreateBlockedEmailEntryCallsCreateBlockedEmailEntryAsync()
    {
        _mockedOrganizationBlockedEmailService.Setup(bes => bes.CreateBlockedEmailEntryAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.CreateBlockedEmailEntry(new() { Email = "unit@test.com" });

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<OrganizationBlockedEmailResponse>>(((CreatedResult)actual.Result!).Value);

        _mockedOrganizationBlockedEmailService.Verify(bes => bes.CreateBlockedEmailEntryAsync(It.IsAny<Guid>(), It.IsAny<string>()));
    }

    [Fact]
    public async Task TestThatUpdateBlockedEmailEntryCallsUpdateBlockedEmailEntryAsync()
    {
        _mockedOrganizationBlockedEmailService.Setup(bes => bes.UpdateBlockedEmailEntryAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));

        var actual = await _sut.UpdateBlockedEmailEntry(new()
        {
            CurrentEmail = "unit@test.com",
            NewEmail = "update@test.com"
        });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<OrganizationBlockedEmailResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationBlockedEmailService.Verify(bes => bes.UpdateBlockedEmailEntryAsync(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
    }

    [Fact]
    public async Task TestThatDeleteBlockedEmailEntryCallsDeleteBlockedEmailEntryAsync()
    {
        _mockedOrganizationBlockedEmailService.Setup(bes => bes.DeleteBlockedEmailEntryAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.DeleteBlockedEmailEntry(new() { Email = "unit@test.com" });

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationBlockedEmailService.Verify(bes => bes.DeleteBlockedEmailEntryAsync(It.IsAny<Guid>(), It.IsAny<string>()));
    }
}