using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Requests.User.Admin;
using UserService.Dtos.Responses.CountryManager;
using UserService.Services.User;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Services.Country;

namespace UserService.Tests.Controllers;

public class AdminControllerTests
{
    private static readonly Guid ValidAdminid = Guid.NewGuid();

    private readonly AdminController _sut;
    private readonly Mock<IUserService> _mockedUserService = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();

    public AdminControllerTests()
    {
        _sut = new(_mockedUserService.Object, _mockedCountryService.Object);

        _sut.SetupHttpContext(platformUserId: ValidAdminid, userType: UserType.Admin.ToString());
    }

    [Fact]
    public async Task TestThatCreateCountryManagerCallsUserServiceCreateCountryManagerAsync()
    {
        var request = new CreateCountryManagerRequest
        {
            Email = "admin@test.com",
            Password = "PassW0rd!",
            FirstName = "Unit",
            LastName = "Tester",
            CountryCode = CountryCode.NL,
            TerminatesOn = DateTime.UtcNow.AddYears(2),
            Claims = new()
            {
                "customerinsight.view",
                "event.details",
                "event.list"
            }
        };

        _mockedUserService.Setup(us => us.CreateCountryManagerAsync(request))
            .ReturnsAsync(Guid.NewGuid());

        var actual = await _sut.CreateCountryManager(request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<Guid>>(((CreatedResult)actual.Result).Value);

        _mockedUserService.Verify(us => us.CreateCountryManagerAsync(request), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateCustomerServiceEmployeeCallsUserServiceCreateCustomerServiceEmployeeAsync()
    {
        var request = new CreateCustomerServiceEmployeeRequest
        {
            Email = "admin@test.com",
            Password = "PassW0rd!",
            FirstName = "Unit",
            LastName = "Tester",
            CountryManagerId = Guid.NewGuid(),
            Claims = new()
            {
                "customerinsight.view",
                "event.details",
                "event.list"
            }
        };

        _mockedUserService.Setup(us => us.CreateCustomerServiceEmployeeAsync(It.IsAny<Guid>(), request))
            .ReturnsAsync(Guid.NewGuid());

        var actual = await _sut.CreateCustomerServiceEmployee(request);

        Assert.NotNull(actual);
        Assert.IsType<CreatedResult>(actual.Result);
        Assert.IsType<ApiResponse<Guid>>(((CreatedResult)actual.Result).Value);

        _mockedUserService.Verify(us => us.CreateCustomerServiceEmployeeAsync(It.IsAny<Guid>(), request), Times.Once);
    }

    [Fact]
    public async Task TestThatGetActiveCountryManagersReturnsOkObjectResultOnCallingUserServiceActiveCountryManagersAsync()
    {
        _mockedUserService.Setup(us => us.ActiveCountryManagersAsync())
            .ReturnsAsync(new List<CountryManagerCountriesResponse>());

        var actual = await _sut.GetActiveCountryManagers();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedUserService.Verify(us => us.ActiveCountryManagersAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatBlockUserCallsUserServiceBlockUserAsync()
    {
        var userId = Guid.NewGuid();

        await _sut.BlockUser(userId);

        _mockedUserService.Verify(us => us.BlockUserAsync(userId));
    }

    [Fact]
    public async Task TestThatUnblockUserCallsUserServiceUnblockUserAsync()
    {
        var userId = Guid.NewGuid();

        await _sut.UnblockUser(userId);

        _mockedUserService.Verify(us => us.UnblockUserAsync(userId));
    }
}