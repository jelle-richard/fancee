using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TestCore.Mocks;
using UserService.Controllers;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationBlockedEmail;
using WebApiCore.Dtos.Responses;

namespace UserService.Tests.Controllers;

public class OrganizationBlockedEmailsControllerTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly OrganizationBlockedEmailsController _sut;
    private readonly Mock<IOrganizationBlockedEmailService> _mockedOrganizationBlockedEmailService = new();

    public OrganizationBlockedEmailsControllerTests()
    {
        _sut = new(_mockedOrganizationBlockedEmailService.Object);

        _sut.SetupHttpContext(organizationId: ValidOrganizationId);
    }

    [Fact]
    public async Task TestThatGetBlockedEmailsCallsGetBlockedEmailsAsync()
    {
        _mockedOrganizationBlockedEmailService.Setup(bes => bes.GetBlockedEmailsAsync(It.IsAny<Guid>()));

        var actual = await _sut.GetBlockedEmails();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<OrganizationBlockedEmailsResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationBlockedEmailService.Verify(bes => bes.GetBlockedEmailsAsync(It.IsAny<Guid>()));
    }

    [Fact]
    public async Task TestThatDeleteBlockedEmailsCallsDeleteBlockedEmailsAsync()
    {
        _mockedOrganizationBlockedEmailService.Setup(bes => bes.DeleteBlockedEmailsAsync(It.IsAny<Guid>()));

        var actual = await _sut.DeleteBlockedEmails();

        Assert.NotNull(actual);
        Assert.IsType<OkObjectResult>(actual.Result);
        Assert.IsType<ApiResponse<EmptyResponse>>(((OkObjectResult)actual.Result!).Value);

        _mockedOrganizationBlockedEmailService.Verify(bes => bes.DeleteBlockedEmailsAsync(It.IsAny<Guid>()));
    }
}