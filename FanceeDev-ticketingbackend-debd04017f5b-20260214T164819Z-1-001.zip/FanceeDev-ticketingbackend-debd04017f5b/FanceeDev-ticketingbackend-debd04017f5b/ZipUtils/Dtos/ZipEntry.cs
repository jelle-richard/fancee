namespace ZipUtils.Dtos;

public class ZipEntry
{
    public byte[] Bytes { get; init; } = default!;
    public string FileName { get; init; } = default!;
}