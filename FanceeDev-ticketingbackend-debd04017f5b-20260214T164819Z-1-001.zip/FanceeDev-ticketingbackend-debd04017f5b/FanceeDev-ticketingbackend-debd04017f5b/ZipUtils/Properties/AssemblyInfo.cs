﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ZipUtils.Tests")]
