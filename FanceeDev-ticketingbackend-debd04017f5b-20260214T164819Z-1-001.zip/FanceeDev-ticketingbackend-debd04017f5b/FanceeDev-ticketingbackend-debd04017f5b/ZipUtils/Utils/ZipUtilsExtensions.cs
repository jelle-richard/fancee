using Microsoft.Extensions.DependencyInjection;
using ZipUtils.Providers.Zip;

namespace ZipUtils.Utils;

public static class ZipUtilsExtensions
{
    public static IServiceCollection AddZipUtils(this IServiceCollection serviceCollection) =>
        serviceCollection.AddTransient<IZipProvider, ZipProvider>();
}