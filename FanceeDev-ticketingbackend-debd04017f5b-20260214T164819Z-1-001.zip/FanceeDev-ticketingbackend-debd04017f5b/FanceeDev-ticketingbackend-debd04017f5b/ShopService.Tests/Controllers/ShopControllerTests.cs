﻿using System.Threading.Tasks;
using ShopService.Controllers;
using ShopService.Dtos.Responses.Shop;
using ShopService.Services.Campaign;
using ShopService.Services.Shop;
using ShopService.Services.Tracking;
using WebApiCore.Services.Cache;

namespace ShopService.Tests.Controllers;

public class ShopControllerTests
{
    private const string UnitTestShopCode = "unitTestShopCode";
    private const string CampaignCode = "CampaignCode";
    private readonly ShopController _sut;
    private readonly Mock<IShopService> _mockedShopService = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();
    private readonly Mock<ICampaignService> _mockedCampaignService = new();
    private readonly Mock<ITrackingService> _mockedTrackingService = new();

    public ShopControllerTests()
    {
        _sut = new(_mockedShopService.Object, _mockedCacheService.Object, _mockedCampaignService.Object, new[] { _mockedTrackingService.Object });
    }

    [Fact]
    public async Task TestThatGetCallsShopServiceGetAsync()
    {
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<TrackableShopResponseWrapper?>(UnitTestShopCode))
            .ReturnsAsync(value: null);

        _mockedShopService.Setup(ss => ss.ByCodeAsync(UnitTestShopCode))
            .ReturnsAsync(new TrackableShopResponseWrapper
            {
                ShopResponse = new()
                {
                    Secured = false
                }
            });

        _mockedShopService.Setup(ss => ss.UpdateShopResponseProductMaxOrderQuantitiesAsync(It.IsAny<ShopResponse>()))
            .ReturnsAsync((ShopResponse shopResponse) => shopResponse);

        _mockedShopService.Setup(ss => ss.IsShopLinkedToCampaign(UnitTestShopCode, CampaignCode))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.IsShopSecuredAsync(It.IsAny<string>()))
            .ReturnsAsync(false);

        await _sut.Get(UnitTestShopCode, CampaignCode);

        _mockedCampaignService.Verify(cs => cs.AddClickToCampaignAsync(UnitTestShopCode, CampaignCode));
        _mockedShopService.Verify(ss => ss.ByCodeAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetCallsTrackingServicesRegisterViewAsync()
    {
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<TrackableShopResponseWrapper?>(UnitTestShopCode))
            .ReturnsAsync(value: null);

        _mockedShopService.Setup(ss => ss.ByCodeAsync(UnitTestShopCode))
            .ReturnsAsync(new TrackableShopResponseWrapper
            {
                ShopResponse = new()
                {
                    Secured = false
                }
            });

        _mockedShopService.Setup(ss => ss.UpdateShopResponseProductMaxOrderQuantitiesAsync(It.IsAny<ShopResponse>()))
            .ReturnsAsync((ShopResponse shopResponse) => shopResponse);

        _mockedShopService.Setup(ss => ss.IsShopLinkedToCampaign(UnitTestShopCode, CampaignCode))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.IsShopSecuredAsync(It.IsAny<string>()))
            .ReturnsAsync(false);

        await _sut.Get(UnitTestShopCode, CampaignCode);

        _mockedTrackingService.Verify(ts => ts.RegisterViewAsync(UnitTestShopCode, It.IsAny<TrackableShopResponseWrapper>()), Times.Never);
        _mockedTrackingService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGetChecksCacheViaGetCachedObjectAsync()
    {
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<TrackableShopResponseWrapper>(UnitTestShopCode))
            .ReturnsAsync(new TrackableShopResponseWrapper
            {
                ShopResponse = new()
                {
                    Secured = false
                }
            });

        _mockedShopService.Setup(ss => ss.UpdateShopResponseProductMaxOrderQuantitiesAsync(It.IsAny<ShopResponse>()))
            .ReturnsAsync((ShopResponse shopResponse) => shopResponse);

        _mockedShopService.Setup(ss => ss.IsShopLinkedToCampaign(UnitTestShopCode, CampaignCode))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.IsShopSecuredAsync(It.IsAny<string>()))
            .ReturnsAsync(false);

        await _sut.Get(UnitTestShopCode, CampaignCode);

        _mockedCampaignService.Verify(cs => cs.AddClickToCampaignAsync(UnitTestShopCode, CampaignCode));
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<ShopResponse>(It.IsAny<string>()), Times.Never());
    }

    [Fact]
    public async Task TestThatGetUpdatesResponseWithMaxOrderQuantities()
    {
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<TrackableShopResponseWrapper>(UnitTestShopCode))
            .ReturnsAsync(new TrackableShopResponseWrapper
            {
                ShopResponse = new()
                {
                    Secured = false
                }
            });

        _mockedShopService.Setup(ss => ss.UpdateShopResponseProductMaxOrderQuantitiesAsync(It.IsAny<ShopResponse>()))
            .ReturnsAsync((ShopResponse shopResponse) => shopResponse);

        _mockedShopService.Setup(ss => ss.IsShopLinkedToCampaign(UnitTestShopCode, CampaignCode))
            .ReturnsAsync(true);

        _mockedShopService.Setup(ss => ss.IsShopSecuredAsync(It.IsAny<string>()))
            .ReturnsAsync(false);

        await _sut.Get(UnitTestShopCode, CampaignCode);

        _mockedCampaignService.Verify(cs => cs.AddClickToCampaignAsync(UnitTestShopCode, CampaignCode));
        _mockedShopService.Verify(ss => ss.UpdateShopResponseProductMaxOrderQuantitiesAsync(It.IsAny<ShopResponse>()), Times.Once);
    }
}