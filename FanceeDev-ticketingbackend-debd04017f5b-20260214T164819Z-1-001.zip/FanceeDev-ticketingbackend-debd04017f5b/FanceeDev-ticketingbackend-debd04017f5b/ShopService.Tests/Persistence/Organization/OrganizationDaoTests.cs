using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using ShopService.Persistence.Organization;

namespace ShopService.Tests.Persistence.Organization;

public class OrganizationDaoTests
{
    private readonly Guid _eurOrganizationId1 = Guid.NewGuid();
    private readonly Guid _eurOrganizationId2 = Guid.NewGuid();
    private readonly Guid _usdOrganizationId1 = Guid.NewGuid();

    private readonly OrganizationDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public OrganizationDaoTests()
    {
        _mockedContext.Setup(c => c.Organizations)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Organization>
            {
                new()
                {
                    Id = _eurOrganizationId1,
                    PublicCode = "H734J9",
                    Name = "UnitOrganization1",
                    Currency = "EUR"
                },
                new()
                {
                    Id = _eurOrganizationId2,
                    PublicCode = "ER764K",
                    Name = "UnitOrganization2",
                    Currency = "EUR"
                },
                new()
                {
                    Id = _usdOrganizationId1,
                    PublicCode = "77HE9M",
                    Name = "UnitOrganization3",
                    Currency = "USD"
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatOrganizationIdByPublicCodeAsyncReturnsNullForUnknownCode()
    {
        var actual = await _sut.OrganizationIdByPublicCodeAsync("UnknownCode");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatOrganizationIdByPublicCodeAsyncReturnsIdByPublicCode()
    {
        var actual = await _sut.OrganizationIdByPublicCodeAsync("H734J9");

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatUseSameCurrencyAsyncReturnsFalseForCurrencyMismatch()
    {
        var actual = await _sut.UseSameCurrencyAsync([_eurOrganizationId1, _usdOrganizationId1]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatUseSameCurrencyAsyncReturnsTrueForCurrencyMatch()
    {
        var actual = await _sut.UseSameCurrencyAsync([_eurOrganizationId1, _eurOrganizationId2]);

        Assert.True(actual);
    }
}