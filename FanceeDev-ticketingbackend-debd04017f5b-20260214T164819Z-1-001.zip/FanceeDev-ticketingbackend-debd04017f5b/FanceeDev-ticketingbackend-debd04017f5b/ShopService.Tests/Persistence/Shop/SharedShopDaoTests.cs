using System;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using ShopService.Persistence.Shop;

namespace ShopService.Tests.Persistence.Shop;

public class SharedShopDaoTests
{
    private readonly Guid _validOrganizationId = Guid.NewGuid();

    private readonly SharedShopDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public SharedShopDaoTests()
    {
        _mockedContext.Setup(c => c.Shops).ReturnsDbSet(
        [
            new() { Code = "Secured", IsSecuredUntil = DateTime.UtcNow.AddYears(5) },
            new() { Code = "Unsecured" }
        ]);

        _mockedContext.Setup(c => c.OrganizationShopShares).ReturnsDbSet(
        [
            new()
            {
                CreatedOn = DateTime.UtcNow,
                OrganizationId = _validOrganizationId,
                ShopCode = "UnitShopCode1",
                Shop = new()
                {
                    Name = "UnitShopName1",
                    Event = new()
                    {
                        Name = "UnitEventName1",
                        StartDate = DateTime.UtcNow,
                        OrganizationId = _validOrganizationId
                    },
                    ShopsInCombinedShop =
                    [
                        new() { CombinedShop = new() { OrganizationId = _validOrganizationId } }
                    ]
                },
                Organization = new()
                {
                    Name = "UnitOrganizationName1",
                    User = new()
                    {
                        Email = "unitmail1@test.com"
                    }
                }
            },
            new()
            {
                CreatedOn = DateTime.UtcNow,
                OrganizationId = Guid.NewGuid(),
                ShopCode = "UnitShopCode2",
                Shop = new()
                {
                    Name = "UnitShopName2",
                    Event = new()
                    {
                        Name = "UnitEventName2",
                        StartDate = DateTime.UtcNow,
                        OrganizationId = _validOrganizationId
                    }
                },
                Organization = new()
                {
                    Name = "UnitOrganizationName2",
                    User = new()
                    {
                        Email = "unitmail2@test.com"
                    }
                }
            },
            new()
            {
                CreatedOn = DateTime.UtcNow,
                OrganizationId = Guid.NewGuid(),
                ShopCode = "UnitShopCode3",
                Shop = new()
                {
                    Name = "UnitShopName3",
                    Event = new()
                    {
                        Name = "UnitEventName3",
                        StartDate = DateTime.UtcNow,
                        OrganizationId = _validOrganizationId
                    }
                },
                Organization = new()
                {
                    Name = "UnitOrganizationName3",
                    User = new()
                    {
                        Email = "unitmail3@test.com"
                    }
                }
            },
            new()
            {
                CreatedOn = DateTime.UtcNow,
                OrganizationId = _validOrganizationId,
                ShopCode = "UnitShopCode4",
                Shop = new()
                {
                    Name = "UnitShopName4",
                    Event = new()
                    {
                        Name = "UnitEventName4",
                        StartDate = DateTime.UtcNow,
                        OrganizationId = _validOrganizationId
                    }
                },
                Organization = new()
                {
                    Name = "UnitOrganizationName4",
                    User = new()
                    {
                        Email = "unitmail4@test.com"
                    }
                }
            }
        ]);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInsertOrganizationShopSharesAsyncAddsShopShares()
    {
        OrganizationShopShare[] shopShares = [new(), new()];

        await _sut.InsertOrganizationShopSharesAsync(shopShares);

        _mockedContext.Verify(c => c.OrganizationShopShares.AddRangeAsync(shopShares, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatSharedShopCodesByOrganizationIdAsyncReturnsSharedShopCodesByOrganizationId()
    {
        var actual = await _sut.SharedShopCodesByOrganizationIdAsync(_validOrganizationId);

        Assert.Equal(2, actual.Count());
    }

    [Fact]
    public async Task TestThatListAsyncFetchesSharedShopsOfOrganization()
    {
        var actual = await _sut.ListAsync(_validOrganizationId, 10, 0, null);

        Assert.Equal(4, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatListAsyncFetchesFilteredSharedShopsOfOrganization()
    {
        var actual = await _sut.ListAsync(_validOrganizationId, 10, 0, "4");

        Assert.Single(actual.Items);
        Assert.Equal(1, actual.TotalItems);
        Assert.Equal("UnitEventName4", actual.Items.First().EventName);
    }

    [Fact]
    public async Task TestThatAsExportItemsAsyncReturnsExpectedResult()
    {
        var actual = (await _sut.AsExportItemsAsync(_validOrganizationId, null)).ToList();

        Assert.Equal(4, actual.Count);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsExpectedResult()
    {
        var actual = (await _sut.ListSelectOptionsAsync(_validOrganizationId, ["UnitShopCode1"], null)).ToList();

        Assert.Single(actual);
        Assert.Equal("UnitShopCode1", actual[0].Id);
        Assert.Equal("UnitShopName1", actual[0].Label);
        Assert.Equal("UnitEventName1", actual[0].Header);
    }

    [Fact]
    public async Task TestThatAreShopsShareableReturnsTrue()
    {
        var actual = await _sut.AreShopsShareable(["Unsecured"]);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatAreShopsShareableReturnsFalse()
    {
        var actual = await _sut.AreShopsShareable(["Unsecured", "Secured"]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsExpectedResult()
    {
        var actual = await _sut.GetAsync(_validOrganizationId, "UnitShopCode1");

        Assert.NotNull(actual);
        Assert.Equal("UnitShopCode1", actual.ShopCode);
        Assert.Single(actual.Shop.ShopsInCombinedShop);
    }

    [Fact]
    public async Task TestThatRemoveAsyncRemovesOrganizationShopShare()
    {
        var sharedShop = new OrganizationShopShare();

        await _sut.RemoveAsync(sharedShop);

        _mockedContext.Verify(c => c.OrganizationShopShares.Remove(sharedShop), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}