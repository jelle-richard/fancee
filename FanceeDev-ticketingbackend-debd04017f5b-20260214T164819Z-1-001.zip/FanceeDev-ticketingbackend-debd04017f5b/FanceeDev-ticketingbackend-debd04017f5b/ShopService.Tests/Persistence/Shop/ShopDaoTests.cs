﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using ShopService.Persistence.Shop;

namespace ShopService.Tests.Persistence.Shop;

public class ShopDaoTests
{
    private const string InvalidShopCode = "NonExistingShopCode";
    private const string CampaignCode = "CampaignCode";

    private static readonly Guid[] MockedProductIds = [Guid.NewGuid(), Guid.NewGuid()];
    private static readonly string[] ShopCodes = ["ShopCode1", "ShopCode2", "ShopCode3"];
    private static readonly Guid OrganizationId = Guid.NewGuid();

    private readonly ShopDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public ShopDaoTests()
    {
        _mockedContext.Setup(mc => mc.Shops)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Shop>
            {
                new()
                {
                    Code = ShopCodes[0],
                    Name = "Shop1",
                    ShopCampaigns = new List<ShopCampaign>
                    {
                        new()
                        {
                            ShopCode = ShopCodes[0],
                            CampaignCode = CampaignCode
                        }
                    },
                    StartDate = DateTime.UtcNow.AddDays(-10),
                    EndDate = DateTime.UtcNow.AddDays(10),
                    Event = new() { OrganizationId = OrganizationId }
                },
                new()
                {
                    Code = ShopCodes[1],
                    Name = "Shop2",
                    StartDate = DateTime.UtcNow.AddDays(-10),
                    EndDate = DateTime.UtcNow.AddDays(10),
                    Event = new() { OrganizationId = Guid.NewGuid() }
                },
                new()
                {
                    Code = ShopCodes[2],
                    StartDate = DateTime.UtcNow.AddDays(10),
                    EndDate = DateTime.UtcNow.AddDays(20),
                    Event = new() { OrganizationId = Guid.NewGuid() },
                    IsSecuredUntil = DateTime.UtcNow.AddDays(1)
                }
            });

        _mockedContext.Setup(mc => mc.Products)
            .ReturnsDbSet(new List<Product>
            {
                new()
                {
                    Id = MockedProductIds[0],
                    Name = "Product1",
                    Stock = 100,
                    ReservedProducts = new List<ReservedProduct>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            ProductId = MockedProductIds[0],
                            Quantity = 3,
                            ReservationReference = new(),
                            ReservationReferenceNavigation = new()
                            {
                                CreatedOn = DateTime.UtcNow,
                                ExpiresOn = DateTime.UtcNow.AddHours(5),
                                OrderReference = new()
                                {
                                    PaymentStatus = PaymentStatus.Authorised
                                }
                            }
                        }
                    }
                }
            });

        _mockedContext.Setup(mc => mc.ReservedProducts)
            .ReturnsDbSet(new List<ReservedProduct>());

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsNullOnUnknownShop()
    {
        var actual = await _sut.ByCodeAsync(InvalidShopCode);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsNullIfStartDateIsNotMet()
    {
        var actual = await _sut.ByCodeAsync(ShopCodes[2]);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsNullIfEndDateIsNotMet()
    {
        var actual = await _sut.ByCodeAsync(ShopCodes[2]);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsNullIfStartAndEndDateAreNotBeingMet()
    {
        var actual = await _sut.ByCodeAsync(ShopCodes[2]);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsShopOnValidCode()
    {
        var actual = await _sut.ByCodeAsync(ShopCodes[0]);

        Assert.NotNull(actual);
        Assert.Equal("Shop1", actual!.Name);
    }

    [Fact]
    public async Task TestThatExistsAsyncReturnsTrue()
    {
        var actual = await _sut.ExistsAsync(ShopCodes[0]);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatExistsAsyncReturnsFalse()
    {
        var actual = await _sut.ExistsAsync(InvalidShopCode);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatIsShopLinkedToCampaignReturnsTrue()
    {
        var actual = await _sut.IsShopLinkedToCampaign(ShopCodes[0], CampaignCode);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatIsShopLinkedToCampaignReturnsFalse()
    {
        var actual = await _sut.IsShopLinkedToCampaign(ShopCodes[1], CampaignCode);

        Assert.False(actual);
    }

    [Theory]
    [InlineData(InvalidShopCode, false)]
    [InlineData("ShopCode1", true)]
    public async Task TestThatIsOwnerOfShopAsyncReturnsExpectedResult(string shopCode, bool expected)
    {
        var actual = await _sut.IsOwnerOfShopAsync(OrganizationId, shopCode);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatIsOwnerOfShopsAsyncReturnsTrue()
    {
        var actual = await _sut.IsOwnerOfShopsAsync(OrganizationId, ["ShopCode1"]);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatIsOwnerOfShopsAsyncReturnsFalse()
    {
        var actual = await _sut.IsOwnerOfShopsAsync(OrganizationId, ["ShopCode1", "ShopCode2"]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatIsShopSecuredChecksDateAgainstUtcNow()
    {
        var actual = await _sut.IsShopSecuredAsync(ShopCodes[2]);

        Assert.True(actual);
    }
}