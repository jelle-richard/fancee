using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using ShopService.Persistence.PreRegister;

namespace ShopService.Tests.Persistence.PreRegister;

public class PreRegisterDaoTests
{
    private static readonly Guid ValidPreRegisterCode = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly PreRegisterDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public PreRegisterDaoTests()
    {
        _mockedContext.Setup(c => c.PreRegisters)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.PreRegister>
            {
                new()
                {
                    OrganizationId = ValidOrganizationId,
                    Code = ValidPreRegisterCode,
                    PreRegisterSignUps = new List<PreRegisterSignUp>
                    {
                        new()
                        {
                            Email = "unitmail1@test.com"
                        },
                        new()
                        {
                            Email = "unitmail2@test.com"
                        },
                        new()
                        {
                            Email = "unitmail3@test.com"
                        }
                    }
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatIsOwnerOfPreRegisterAsyncChecksCorrectOrganizationToPreRegisterBinding()
    {
        var actual = await _sut.IsOwnerOfPreRegisterAsync(ValidOrganizationId, ValidPreRegisterCode);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatIsOwnerOfPreRegisterAsyncChecksIncorrectOrganizationToPreRegisterBinding()
    {
        var actual = await _sut.IsOwnerOfPreRegisterAsync(ValidOrganizationId, Guid.NewGuid());

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatPreRegisterEmailsAsyncFetchesEmailsOfPreRegister()
    {
        var actual = await _sut.PreRegisterEmailsAsync(ValidPreRegisterCode);

        Assert.Equal(3, actual.Count());
    }
}