using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using ShopService.Persistence.SecureCode;

namespace ShopService.Tests.Persistence.SecureCode;

public class ShopSecureCodeDaoTests
{
    private readonly ShopSecureCodeDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public ShopSecureCodeDaoTests()
    {
        _mockedContext.Setup(c => c.ShopSecureCodes)
            .ReturnsDbSet(new List<ShopSecureCode>
            {
                new()
                {
                    ShopCode = "UnitShopCode1",
                    Code = "UnitSecureCode1",
                    MaximumUses = 5,
                    Active = true,
                    CreatedOn = DateTime.UtcNow
                },
                new()
                {
                    ShopCode = "UnitShopCode1",
                    Code = "SuperSecretCode",
                    MaximumUses = null,
                    Active = true,
                    CreatedOn = DateTime.UtcNow
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Theory]
    [InlineData("UnitShopCode1", "UnitSecureCode1", true)]
    [InlineData("UnitShopCode1", "RandomSecureCode", false)]
    [InlineData("RandomShopCode", "UnitSecureCode1", false)]
    [InlineData("RandomShopCode", "RandomSecureCode", false)]
    public async Task TestThatExistsForShopAsyncReturnsExpectedBindings(string shopCode, string secureCode, bool expected)
    {
        var actual = await _sut.ExistsForShopAsync(shopCode, secureCode);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatCreateAsyncSavesChangesAsync()
    {
        await _sut.CreateAsync(new()
        {
            Code = "NewSecureCode",
            ShopCode = "UnitShopCode",
            Active = true,
            MaximumUses = null
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncSavesChangesAsync()
    {
        await _sut.UpdateAsync(new()
        {
            Code = "UnitSecureCode1",
            ShopCode = "UnitShopCode1",
            Active = true,
            MaximumUses = 99
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatByCodesAsyncReturnsNullForUnknownCodeCombination()
    {
        var actual = await _sut.ByCodesAsync("ABC", "ABC");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByCodesAsyncReturnsShopSecureCode()
    {
        var actual = await _sut.ByCodesAsync("UnitShopCode1", "UnitSecureCode1");

        Assert.NotNull(actual);
        Assert.True(actual.Active);
    }

    [Fact]
    public async Task TestThatListAsyncAppliesSearchWhenFilteringShopSecureCodes()
    {
        var actual = await _sut.ListAsync("UnitShopCode1", new()
        {
            Options = new()
            {
                SearchQuery = "Secret"
            },
            Page = 1,
            PageSize = 10
        });

        Assert.Single(actual.Items);
        Assert.Equal(1, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatAsExportItemsAsyncAppliesSearchWhenFilteringShopSecureCodes()
    {
        var actual = await _sut.AsExportItemsAsync("UnitShopCode1", new()
        {
            SearchQuery = "Secret"
        });

        Assert.Single(actual);
    }

    [Fact]
    public async Task TestThatInsertAsyncSavesChangesAsync()
    {
        await _sut.InsertAsync(new List<ShopSecureCode>
        {
            new()
            {
                ShopCode = "UnitShopCode1",
                Code = "MyNewCode",
                MaximumUses = 5,
                Active = true
            }
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatByShopCodeAsyncReturnsAllSecureCodesOfAShop()
    {
        var actual = await _sut.ByShopCodeAsync("UnitShopCode1");

        Assert.Equal(2, actual.Count());
    }

    [Fact]
    public async Task TestThatDeleteUnusedCodesOfShopAsyncSavesChangesAsync()
    {
        await _sut.DeleteUnusedCodesOfShopAsync("UnitShopCode1");

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncSavesChangesAsync()
    {
        await _sut.DeleteAsync(new()
        {
            ShopCode = "UnitShopCode1",
            Code = "UnitSecureCode1",
            MaximumUses = 5,
            Active = true
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}