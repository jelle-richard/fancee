using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;
using ShopService.Persistence.CombinedShop;

namespace ShopService.Tests.Persistence.CombinedShop;

[TestSubject(typeof(CombinedShopMediaDao))]
public class CombinedShopMediaDaoTests
{
    private const string CombinedShopCode = "CombinedShop1";
    private static readonly Guid[] FileIds = [Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid OrganizationId = Guid.NewGuid();

    private readonly CombinedShopMediaDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public CombinedShopMediaDaoTests()
    {
        _mockedContext.Setup(c => c.CombinedShopMedia).ReturnsDbSet([
            new()
            {
                FileId = FileIds[0],
                CombinedShopCode = CombinedShopCode,
                Position = 1,
                CombinedShop = new() { OrganizationId = OrganizationId }
            },
            new()
            {
                FileId = FileIds[1],
                CombinedShopCode = CombinedShopCode,
                Position = 2,
                CombinedShop = new() { OrganizationId = OrganizationId }
            }
        ]);

        _mockedContext.Setup(c => c.Files).ReturnsDbSet([]);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsNullOnInvalidCombinedShopCode()
    {
        var actual = await _sut.ByIdAsync(Guid.Empty, string.Empty);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsCombinedShopMedia()
    {
        var actual = await _sut.ByIdAsync(FileIds[0], CombinedShopCode);

        Assert.NotNull(actual);
        Assert.Equal(CombinedShopCode, actual.CombinedShopCode);
        Assert.Equal(1, actual.Position);
    }

    [Fact]
    public async Task TestThatNextPositionAsyncReturnsExpectedResult()
    {
        var actual = await _sut.NextPositionAsync(CombinedShopCode);

        Assert.Equal(3, actual);
    }

    [Fact]
    public async Task TestThatNextPositionAsyncReturnsOneForNonExistentCombinedShopCode()
    {
        var actual = await _sut.NextPositionAsync(string.Empty);

        Assert.Equal(1, actual);
    }

    [Fact]
    public async Task TestThatInsertAsyncAddsNewMedia()
    {
        var media = new CombinedShopMedia();

        await _sut.InsertAsync(media);

        _mockedContext.Verify(c => c.CombinedShopMedia.AddAsync(media, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatForCombinedShopAsyncReturnsCombinedShopMedia()
    {
        var actual = (await _sut.ForCombinedShopAsync(CombinedShopCode)).ToList();

        Assert.Equal(2, actual.Count);
        Assert.All(actual, media => Assert.Equal(CombinedShopCode, media.CombinedShopCode));
    }

    [Fact]
    public async Task TestThatRepositionMediaAsyncWithMediaListRepositionsMedia()
    {
        var media = _mockedContext.Object.CombinedShopMedia.Where(csm => csm.CombinedShopCode == CombinedShopCode).ToList();
        List<Guid> fileIds = [media[1].FileId, media[0].FileId];

        await _sut.RepositionMediaAsync(media, fileIds);

        _mockedContext.Verify(c => c.CombinedShopMedia.UpdateRange(It.Is<IList<CombinedShopMedia>>(l =>
            l[0].Position == 2 &&
            l[1].Position == 1
        )), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatRepositionMediaAsyncWithCombinedShopCodeRepositionsMedia()
    {
        var actual = await _sut.RepositionMediaAsync(CombinedShopCode, 1);

        Assert.Equal(1, actual);
    }

    [Fact]
    public async Task TestThatOwnerOfMediaAsyncReturnsTrue()
    {
        var actual = await _sut.OwnerOfMediaAsync(FileIds[0], CombinedShopCode, OrganizationId);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatOwnerOfMediaAsyncReturnsFalse()
    {
        var actual = await _sut.OwnerOfMediaAsync(Guid.Empty, CombinedShopCode, OrganizationId);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncRemovesMedia()
    {
        var media = _mockedContext.Object.CombinedShopMedia.First();

        await _sut.DeleteAsync(media);

        _mockedContext.Verify(c => c.CombinedShopMedia.Remove(It.IsAny<CombinedShopMedia>()), Times.Once);
        _mockedContext.Verify(c => c.Files.Remove(It.IsAny<File>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesMedia()
    {
        await _sut.UpdateAsync(new());

        _mockedContext.Verify(c => c.CombinedShopMedia.Update(It.IsAny<CombinedShopMedia>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}