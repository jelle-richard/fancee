using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using ShopService.Persistence.CombinedShop;

namespace ShopService.Tests.Persistence.CombinedShop;

public class CombinedShopDaoTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    public static readonly TheoryData<Guid, string, bool> OwnerBindings = new()
    {
        { ValidOrganizationId, "UnitCode1", true },
        { ValidOrganizationId, "UnitCode2", false },
        { ValidOrganizationId, "UnitCode3", false },
        { Guid.NewGuid(), "UnitCode1", false },
        { Guid.NewGuid(), "UnknownCode", false }
    };

    private static readonly Guid[] ValidPaymentMethodIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];

    private readonly CombinedShopDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public CombinedShopDaoTests()
    {
        _mockedContext.Setup(c => c.OrganizationShopShares)
            .ReturnsDbSet(
            [
                new()
                {
                    OrganizationId = ValidOrganizationId,
                    ShopCode = "SharedUnitShopCode1"
                },
                new()
                {
                    OrganizationId = ValidOrganizationId,
                    ShopCode = "SharedUnitShopCode2"
                }
            ]);

        _mockedContext.Setup(c => c.Shops)
            .ReturnsDbSet(
            [
                new()
                {
                    Code = "UnitShopCode1",
                    Event = new() { OrganizationId = ValidOrganizationId }
                },
                new()
                {
                    Code = "UnitShopCode2",
                    Event = new() { OrganizationId = ValidOrganizationId }
                },
                new()
                {
                    Code = "SecuredCode1",
                    IsSecuredUntil = DateTime.UtcNow.AddDays(5),
                    Event = new() { OrganizationId = ValidOrganizationId }
                }
            ]);

        _mockedContext.Setup(c => c.CombinedShops)
            .ReturnsDbSet(
            [
                new()
                {
                    Code = "UnitCode1",
                    OrganizationId = ValidOrganizationId,
                    Name = "UnitName1",
                    Active = true,
                    ShopsInCombinedShop = []
                },
                new()
                {
                    Code = "UnitCode2",
                    OrganizationId = Guid.NewGuid(),
                    Name = "UnitName2",
                    Active = false,
                    ShopsInCombinedShop =
                    [
                        new(),
                        new(),
                        new()
                    ]
                }
            ]);

        _mockedContext.Setup(c => c.ShopsInCombinedShops)
            .ReturnsDbSet(
            [
                new()
                {
                    CombinedShopCode = "UnitCode1",
                    ShopCode = "UnitShopCode1",
                    Position = 1
                },
                new()
                {
                    CombinedShopCode = "UnitCode1",
                    ShopCode = "UnitShopCode2",
                    Position = 2
                }
            ]);

        _mockedContext.Setup(c => c.PaymentMethods).ReturnsDbSet([
            new()
            {
                Id = ValidPaymentMethodIds[0],
                Name = "IDeal",
                Provider = PaymentProvider.Adyen,
                Active = true,
                FeeStaticCents = 10,
                Order = 3,
                CombinedShops =
                [
                    new() { CombinedShopCode = "UnitCode1", PaymentMethodId = ValidPaymentMethodIds[0], PaidBy = PaidBy.Organization }
                ]
            },
            new()
            {
                Id = ValidPaymentMethodIds[1],
                Name = "PayPal",
                Provider = PaymentProvider.Adyen,
                Active = false,
                FeeStaticCents = 10,
                FeePercentage = 1.0m,
                Order = 2,
                CombinedShops =
                [
                    new() { CombinedShopCode = "UnitCode1", PaymentMethodId = ValidPaymentMethodIds[1], PaidBy = PaidBy.Client }
                ]
            },
            new()
            {
                Id = ValidPaymentMethodIds[2],
                Name = "Bancontact",
                Provider = PaymentProvider.Adyen,
                Active = true,
                FeeStaticCents = null,
                FeePercentage = 2.3m,
                Order = 1,
                CombinedShops =
                [
                    new() { CombinedShopCode = "UnitCode1", PaymentMethodId = ValidPaymentMethodIds[2], PaidBy = PaidBy.Client }
                ]
            }
        ]);

        _sut = new(_mockedContext.Object);
    }

    [Theory]
    [MemberData(nameof(OwnerBindings))]
    public async Task TestThatIsOwnerAsyncChecksOrganizationToCodeBinding(Guid organizationId, string code, bool expected)
    {
        var actual = await _sut.IsOwnerAsync(organizationId, code);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatInsertAsyncSavesChangesAsync()
    {
        await _sut.InsertAsync(new());

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsNullForUnknownOrganizationAndCodeCombination()
    {
        var actual = await _sut.GetAsync(Guid.NewGuid(), "UnknownCode");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsCombinedShopByOrganizationIdAndShopCode()
    {
        var actual = await _sut.GetAsync(ValidOrganizationId, "UnitCode1");

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatUpdateAsyncDeletesBoundShopsAndSavesChangesAsync()
    {
        await _sut.UpdateAsync(new()
        {
            Code = "UnitCode1",
            Active = false
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Exactly(2));
    }

    [Fact]
    public async Task TestThatDeleteAsyncDeletesBoundShopsAndSavesChangesAsync()
    {
        await _sut.DeleteAsync(new()
        {
            Code = "UnitCode1",
            Active = false
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Exactly(2));
    }

    [Theory]
    [InlineData("NonExistendCode", true)]
    [InlineData("UnitCode1", false)]
    public async Task TestThatIsUniqueAsyncReturnsFalseWhenCodeExists(string code, bool expected)
    {
        _mockedContext.Setup(c => c.CombinedShops.FindAsync("UnitCode1"))
            .ReturnsAsync(new FanceeData.Models.Ticketing.CombinedShop());

        var actual = await _sut.IsUniqueAsync(code);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatCanCombineShopsAsyncReturnsTrueIfSharesMatchShops()
    {
        var actual = await _sut.CanCombineShopsAsync(ValidOrganizationId, ["UnitShopCode1", "SharedUnitShopCode2"]);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatCanCombineShopsAsyncReturnsFalseIfSharesDoNotMatchShops()
    {
        _mockedContext.Setup(c => c.OrganizationShopShares)
            .ReturnsDbSet(
            [
                new()
                {
                    OrganizationId = ValidOrganizationId,
                    ShopCode = "UnitShopCode1"
                }
            ]);

        var actual = await _sut.CanCombineShopsAsync(ValidOrganizationId, ["UnitShopCode1", "UnitShopCode2"]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatCanCombineShopsAsyncReturnsFalseIfShopIsSecured()
    {
        var actual = await _sut.CanCombineShopsAsync(ValidOrganizationId, ["SecuredCode1"]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatListAsyncFiltersWithSearch()
    {
        var actual = await _sut.ListAsync(ValidOrganizationId, 10, 0, "Name1");

        Assert.Equal(1, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatListAsyncDoesNotFilterIfNoSearchQueryIsProvided()
    {
        _mockedContext.Setup(c => c.CombinedShops)
            .ReturnsDbSet(
            [
                new()
                {
                    Code = "UnitCode1",
                    OrganizationId = ValidOrganizationId,
                    Name = "UnitName1",
                    Active = true,
                    ShopsInCombinedShop = []
                },
                new()
                {
                    Code = "UnitCode2",
                    OrganizationId = ValidOrganizationId,
                    Name = "UnitName2",
                    Active = false,
                    ShopsInCombinedShop =
                    [
                        new(),
                        new(),
                        new()
                    ]
                },
                new()
                {
                    Code = "UnitCode3",
                    OrganizationId = ValidOrganizationId,
                    Name = "UnitName3",
                    Active = true,
                    ShopsInCombinedShop = []
                }
            ]);

        var actual = await _sut.ListAsync(ValidOrganizationId, 10, 0, null);

        Assert.Equal(3, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatExportItemsAsyncFiltersWithSearch()
    {
        var actual = await _sut.ExportItemsAsync(ValidOrganizationId, "Name1");

        Assert.Single(actual);
    }

    [Fact]
    public async Task TestThatExportAsyncDoesNotFilterIfNoSearchQueryIsProvided()
    {
        _mockedContext.Setup(c => c.CombinedShops)
            .ReturnsDbSet(
            [
                new()
                {
                    Code = "UnitCode1",
                    OrganizationId = ValidOrganizationId,
                    Name = "UnitName1",
                    Active = true,
                    ShopsInCombinedShop = []
                },
                new()
                {
                    Code = "UnitCode2",
                    OrganizationId = ValidOrganizationId,
                    Name = "UnitName2",
                    Active = false,
                    ShopsInCombinedShop =
                    [
                        new(),
                        new(),
                        new()
                    ]
                },
                new()
                {
                    Code = "UnitCode3",
                    OrganizationId = ValidOrganizationId,
                    Name = "UnitName3",
                    Active = true,
                    ShopsInCombinedShop = []
                }
            ]);

        var actual = await _sut.ExportItemsAsync(ValidOrganizationId, null);

        Assert.Equal(3, actual.Count());
    }

    [Fact]
    public async Task TestThatAvailablePaymentMethodsAsyncReturnsExpectedResult()
    {
        var actual = (await _sut.AvailablePaymentMethodsAsync(ValidOrganizationId, "UnitCode1")).ToList();

        Assert.Equal(2, actual.Count);

        var (firstPmv, firstPaidBy) = actual[0];
        var (secondPmv, secondPaidBy) = actual[1];

        Assert.Equal("Bancontact", firstPmv.Name);
        Assert.Equal(PaidBy.Client, firstPaidBy);
        Assert.Equal("IDeal", secondPmv.Name);
        Assert.Equal(PaidBy.Organization, secondPaidBy);
    }

    [Fact]
    public async Task TestThatRemoveShopsInCombinedShopAsyncRemovesShopsInCombinedShops()
    {
        List<ShopInCombinedShop> shops = [new(), new()];

        await _sut.RemoveShopsInCombinedShopAsync(shops);

        _mockedContext.Verify(c => c.ShopsInCombinedShops.RemoveRange(shops), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatRepositionShopsInCombinedShopAsyncReturnsExpectedResult()
    {
        var actual = await _sut.RepositionShopsInCombinedShopAsync("UnitCode1", 1);

        Assert.Equal(1, actual);
    }
}