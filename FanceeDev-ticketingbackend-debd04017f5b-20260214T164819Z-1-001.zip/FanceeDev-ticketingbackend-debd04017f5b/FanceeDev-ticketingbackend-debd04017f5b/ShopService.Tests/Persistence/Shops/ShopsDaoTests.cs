﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using ShopService.Persistence.Shops;

namespace ShopService.Tests.Persistence.Shops;

public class ShopsDaoTests
{
    private static readonly Guid[] MockedProductIds = { Guid.NewGuid(), Guid.NewGuid() };
    private readonly ShopsDao _sut;

    public ShopsDaoTests()
    {
        var mockedContext = new Mock<TicketingContext>();

        mockedContext.Setup(mc => mc.Shops)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Shop>
            {
                new()
                {
                    Code = "ShopCode1",
                    Name = "Shop1"
                },
                new()
                {
                    Code = "ShopCode2",
                    Name = "Shop2"
                },
                new()
                {
                    Code = "ShopCode3",
                    Name = "Shop3"
                },
                new()
                {
                    Code = "PromoShop1",
                    Active = true,
                    EndDate = DateTime.UtcNow.AddMonths(3)
                }
            });

        var itemsInShop = new List<ItemInShop>
        {
            new()
            {
                Id = Guid.NewGuid(),
                ShopCode = "PromoShop1",
                ProductId = MockedProductIds[0],
                Product = new()
                {
                    Id = MockedProductIds[0],
                    Name = "Product90",
                    Stock = 100
                }
            }
        };
        mockedContext.Setup(mc => mc.IssuedProducts)
            .ReturnsDbSet(new List<IssuedProduct>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    ReservedProduct = new()
                    {
                        ShopCode = "PromoShop1",
                        Shop = new()
                        {
                            Code = "PromoShop1",
                            Active = true,
                            EndDate = DateTime.UtcNow.AddMonths(1),
                            ItemsInShop = itemsInShop
                        }
                    }
                }
            });

        mockedContext.Setup(mc => mc.ItemsInShops)
            .ReturnsDbSet(itemsInShop);

        mockedContext.Setup(mc => mc.ReservedProducts)
            .ReturnsDbSet(new List<ReservedProduct>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    ProductId = MockedProductIds[1],
                    ReservationReferenceNavigation = new()
                    {
                        CreatedOn = DateTime.UtcNow.AddDays(-4),
                        Reference = new(),
                        ExpiresOn = DateTime.UtcNow.AddDays(4)
                    },
                    ShopCode = "PromoShop1"
                }
            });

        _sut = new(mockedContext.Object);
    }

    [Fact]
    public async Task TestThatGetPromoShopsReturnsCorrectShops()
    {
        IEnumerable<string> shopCodes = new List<string> { "ShopCode1", "ShopCode3" };

        var actual = await _sut.PromoShopsAsync(shopCodes);

        Assert.Equal(2, actual.Count);
        Assert.Equal("ShopCode3", actual.FindLast(s => s.Code == "ShopCode3")!.Code);
    }

    [Fact]
    public async Task TestThatGetPercentageSoldOutBestsellingShopCodesReturnsShopCodes()
    {
        var actual = await _sut.PercentageSoldOutBestsellingShopCodesAsync();

        Assert.Equal("PromoShop1", actual.First());
    }

    [Fact]
    public async Task TestThatGetOrderCountBestsellingShopCodesReturnsShopCodes()
    {
        var actual = await _sut.OrderCountBestsellingShopCodesAsync();

        Assert.Equal("PromoShop1", actual.First());
    }

    [Fact]
    public async Task TestThatMostRecentActivityBestsellingShopCodesAsyncReturnsShopCodes()
    {
        var actual = await _sut.MostRecentActivityBestsellingShopCodesAsync(7);

        Assert.Equal("PromoShop1", actual.First());
    }
}