﻿using System;
using System.Collections.Generic;
using System.Linq;
using FanceeData.Models.Ticketing;
using ShopService.Utils.Adapter;
using ShopService.Utils.Adapter.Exceptions;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Shared.ShopElement;

namespace ShopService.Tests.Utils.Adapter;

public class ShopAdapterTests
{
    private static readonly HostedDeploymentEnvironment Env = new()
    {
        Id = Guid.NewGuid(),
        Domain = "localhost",
        IsHttps = false,
        Name = "localhost",
        ContentDeliveryNetworkBaseUrl = "localhost",
        Port = null
    };

    [Fact]
    public void TestThatToShopResponseCanParseShop()
    {
        var paymentMethodId = Guid.NewGuid();

        var @event = new Event
        {
            Id = Guid.NewGuid(),
            Name = "Event1",
            Organization = new()
            {
                Name = "ClublUnit",
                CurrencyNavigation = new()
                {
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                },
                Contract = new()
                {
                    ProductFeeCents = 98,
                    TicketFeeCents = 99
                }
            },
            Description = "unit description",
            EndDate = DateTime.UtcNow,
            StartDate = DateTime.UtcNow,
            Status = EventStatus.Active,
            Address = null,
            MinimumAge = 18,
            TimezoneIdentification = "Europe/Amsterdam",
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    PaymentMethodId = paymentMethodId,
                    PaidBy = PaidBy.Client,
                    PaymentMethod = new()
                    {
                        Id = paymentMethodId,
                        Name = "IDeal",
                        Provider = PaymentProvider.Adyen,
                        FeePercentage = 2,
                        FeeStaticCents = 50,
                        Order = 1
                    }
                }
            }
        };

        var shop = new Shop
        {
            EndDate = DateTime.UtcNow,
            StartDate = DateTime.UtcNow,
            ShopDesign = null,
            Event = @event,
            ItemsInShop = new List<ItemInShop>
            {
                new()
                {
                    Position = 2,
                    ShopElement = new DividerElement { Name = "-= Divider =-" }
                },
                new()
                {
                    Position = 1,
                    ProductId = Guid.Empty,
                    Product = new()
                    {
                        Event = @event,
                        ProductMedia = new List<ProductMedia>
                        {
                            new() { Position = 2, File = new() { Path = "2.png" } },
                            new() { Position = 1, File = new() { Path = "1.png" } }
                        }
                    }
                },
                new()
                {
                    Position = 3,
                    ShopElement = new ExternalLinkElement { Link = "https://wearefancee.com", Name = "Fancee" }
                },
                new()
                {
                    Position = 4,
                    ShopElement = new NoticeElement { Content = "Notice", Variant = NoticeVariant.Info }
                },
                new()
                {
                    Position = 5,
                    ShopElement = new TextBlockElement { Text = "Content", Title = "Text" }
                },
                new()
                {
                    Position = 6,
                    ShopElement = new SeatingMapElement()
                }
            },
            IsReservationShop = false,
            Layout = ShopLayout.Ticketshop,
            ShopFieldRequirements = new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                }
            }
        };

        var actual = shop.ToShopResponse(50, 60, Env);

        Assert.Equal(shop.Event.Name, actual.Event.Name);
        Assert.Single(actual.ShopFields);
        Assert.True(actual.ShopFields.First().Enabled);
        Assert.NotNull(actual.Elements);

        var actualElements = actual.Elements.ToList();
        Assert.Equal(6, actualElements.Count);
        Assert.IsType<ShopProductDetailsElementDto>(actualElements[0]);
        Assert.IsType<DividerElementDto>(actualElements[1]);
        Assert.IsType<ExternalLinkElementDto>(actualElements[2]);
        Assert.IsType<NoticeElementDto>(actualElements[3]);
        Assert.IsType<TextBlockElementDto>(actualElements[4]);
        Assert.IsType<SeatingMapElementDto>(actualElements[5]);

        var actualMedia = ((ShopProductDetailsElementDto)actualElements[0]).Media.ToList();
        Assert.Equal(2, actualMedia.Count);
        Assert.Equal("http://localhost/1.png", actualMedia[0].Url);
        Assert.Equal("http://localhost/2.png", actualMedia[1].Url);
        Assert.Equal("Europe/Amsterdam", actual.Event.TimezoneIdentification);
    }

    [Fact]
    public void TestThatToShopResponseCanParseShopOfSeatedEvent()
    {
        var paymentMethodId = Guid.NewGuid();

        var @event = new Event
        {
            Id = Guid.NewGuid(),
            Name = "Event1",
            Type = EventType.Seating,
            SeatsIoEventId = Guid.NewGuid(),
            Organization = new()
            {
                Name = "ClublUnit",
                CurrencyNavigation = new()
                {
                    Character = "€",
                    Name = "Euro",
                    ShortCode = "EUR"
                },
                Contract = new()
                {
                    ProductFeeCents = 98,
                    TicketFeeCents = 99,
                    SeatedTicketFeeCents = 95,
                    ProductFeePercentage = 1,
                    TicketFeePercentage = 2,
                    SeatedTicketFeePercentage = 3
                }
            },
            Products = new List<Product>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    SeatsIoCategoryId = "UnitSeatsIoProductId",
                    Name = "SeatedProduct",
                    Type = ProductType.SeatedTicket,
                    PriceCents = 1000,
                    FeeCents = null,
                    MaximumPurchasePerOrder = 5,
                    Event = new()
                    {
                        Organization = new()
                        {
                            Name = "ClublUnit",
                            CurrencyNavigation = new()
                            {
                                Character = "€",
                                Name = "Euro",
                                ShortCode = "EUR"
                            },
                            Contract = new()
                            {
                                ProductFeeCents = 98,
                                TicketFeeCents = 99,
                                SeatedTicketFeeCents = 95,
                                ProductFeePercentage = 1,
                                TicketFeePercentage = 2,
                                SeatedTicketFeePercentage = 3
                            }
                        }
                    }
                }
            },
            Description = "unit description",
            EndDate = DateTime.UtcNow,
            StartDate = DateTime.UtcNow,
            Status = EventStatus.Active,
            Address = null,
            MinimumAge = 18,
            TimezoneIdentification = "Europe/Amsterdam",
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    PaymentMethodId = paymentMethodId,
                    PaidBy = PaidBy.Client,
                    PaymentMethod = new()
                    {
                        Id = paymentMethodId,
                        Name = "IDeal",
                        Provider = PaymentProvider.Adyen,
                        FeePercentage = 2,
                        FeeStaticCents = 50,
                        Order = 1
                    }
                }
            }
        };

        var shop = new Shop
        {
            EndDate = DateTime.UtcNow,
            StartDate = DateTime.UtcNow,
            ShopDesign = null,
            Event = @event,
            ItemsInShop = new List<ItemInShop>
            {
                new()
                {
                    Position = 2,
                    ShopElement = new DividerElement { Name = "-= Divider =-" }
                },
                new()
                {
                    Position = 1,
                    ProductId = Guid.Empty,
                    Product = new()
                    {
                        Event = @event,
                        Type = ProductType.SeatedTicket,
                        PriceCents = 1111,
                        FeeCents = 222,
                        ProductMedia = new List<ProductMedia>
                        {
                            new() { Position = 2, File = new() { Path = "2.png" } },
                            new() { Position = 1, File = new() { Path = "1.png" } }
                        }
                    }
                },
                new()
                {
                    Position = 3,
                    ShopElement = new ExternalLinkElement { Link = "https://wearefancee.com", Name = "Fancee" }
                },
                new()
                {
                    Position = 4,
                    ShopElement = new NoticeElement { Content = "Notice", Variant = NoticeVariant.Info }
                },
                new()
                {
                    Position = 5,
                    ShopElement = new TextBlockElement { Text = "Content", Title = "Text" }
                },
                new()
                {
                    Position = 6,
                    ShopElement = new SeatingMapElement()
                }
            },
            IsReservationShop = false,
            Layout = ShopLayout.Ticketshop,
            ShopFieldRequirements = new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                }
            }
        };

        var actual = shop.ToShopResponse(50, 60, Env);

        Assert.Equal(shop.Event.Name, actual.Event.Name);
        Assert.Single(actual.ShopFields);
        Assert.True(actual.ShopFields.First().Enabled);
        Assert.NotNull(actual.Elements);

        var actualElements = actual.Elements.ToList();
        Assert.Equal(6, actualElements.Count);
        Assert.IsType<ShopProductDetailsElementDto>(actualElements[0]);
        Assert.IsType<DividerElementDto>(actualElements[1]);
        Assert.IsType<ExternalLinkElementDto>(actualElements[2]);
        Assert.IsType<NoticeElementDto>(actualElements[3]);
        Assert.IsType<TextBlockElementDto>(actualElements[4]);
        Assert.IsType<SeatingMapElementDto>(actualElements[5]);
        Assert.NotNull(actual.SeatedProducts);
        Assert.Single(actual.SeatedProducts);
        Assert.Equal(5, actual.SeatedProducts[0].ReservableQuantity);

        var actualMedia = ((ShopProductDetailsElementDto)actualElements[0]).Media.ToList();
        Assert.Equal(2, actualMedia.Count);
        Assert.Equal("http://localhost/1.png", actualMedia[0].Url);
        Assert.Equal("http://localhost/2.png", actualMedia[1].Url);
        Assert.Equal("Europe/Amsterdam", actual.Event.TimezoneIdentification);
    }

    [Fact]
    public void TestThatGetFeeCentsReturnsNullIfProductIsNull()
    {
        var actual = ShopAdapter.GetFeeCents(null);

        Assert.Null(actual);
    }

    [Fact]
    public void TestThatGetFeeCentsReturnsProductFeeForProductTypeProduct()
    {
        var iis = new ItemInShop
        {
            ProductId = Guid.Empty,
            Product = new()
            {
                Id = Guid.Empty,
                Type = ProductType.Product,
                PackQuantity = 1,
                Event = new()
                {
                    Organization = new()
                    {
                        Contract = new()
                        {
                            ProductFeeCents = 25,
                            TicketFeeCents = 30
                        }
                    }
                }
            }
        };

        var actual = ShopAdapter.GetFeeCents(iis.Product);

        Assert.Equal(25, actual);
    }

    [Fact]
    public void TestThatGetFeeCentsReturnsProductFeeForProductTypeProductWithPackQuantity()
    {
        var iis = new ItemInShop
        {
            ProductId = Guid.Empty,
            Product = new()
            {
                Id = Guid.Empty,
                Type = ProductType.Product,
                PackQuantity = 6,
                Event = new()
                {
                    Organization = new()
                    {
                        Contract = new()
                        {
                            ProductFeeCents = 25,
                            TicketFeeCents = 30
                        }
                    }
                }
            }
        };

        var actual = ShopAdapter.GetFeeCents(iis.Product);

        Assert.Equal(150, actual);
    }

    [Fact]
    public void TestThatGetFeeCentsReturnsTicketFeeForProductTypeTicket()
    {
        var iis = new ItemInShop
        {
            ProductId = Guid.Empty,
            Product = new()
            {
                Id = Guid.Empty,
                Type = ProductType.Ticket,
                PackQuantity = 1,
                Event = new()
                {
                    Organization = new()
                    {
                        Contract = new()
                        {
                            ProductFeeCents = 25,
                            TicketFeeCents = 30
                        }
                    }
                }
            }
        };

        var actual = ShopAdapter.GetFeeCents(iis.Product);

        Assert.Equal(30, actual);
    }

    [Fact]
    public void TestThatGetFeeCentsReturnsTicketFeeForProductTypeTicketWithPackQuantity()
    {
        var iis = new ItemInShop
        {
            ProductId = Guid.Empty,
            Product = new()
            {
                Id = Guid.Empty,
                Type = ProductType.Ticket,
                PackQuantity = 3,
                Event = new()
                {
                    Organization = new()
                    {
                        Contract = new()
                        {
                            ProductFeeCents = 25,
                            TicketFeeCents = 30
                        }
                    }
                }
            }
        };

        var actual = ShopAdapter.GetFeeCents(iis.Product);

        Assert.Equal(90, actual);
    }

    [Fact]
    public void TestThatFromItemsInShopParsesAccordionElement()
    {
        var productId = Guid.NewGuid();

        var items = new ItemInShop[]
        {
            new()
            {
                Position = 1,
                ShopElement = new AccordionElement
                {
                    Title = "Parking Tickets",
                    Opened = true,
                    Icon = "parking",
                    Elements = new AccordionShopElement[]
                    {
                        new()
                        {
                            Position = 2,
                            ShopElement = new NoticeElement()
                        },
                        new()
                        {
                            Position = 1,
                            ProductId = productId,
                            Product = new()
                            {
                                Id = productId,
                                FeeCents = 100,
                                PriceCents = 2000,
                                Name = "Test",
                                Type = ProductType.Ticket,
                                Event = new()
                                {
                                    Organization = new()
                                    {
                                        Contract = new()
                                        {
                                            TicketFeeCents = 50,
                                            TicketFeePercentage = 1,
                                            ProductFeeCents = 50,
                                            ProductFeePercentage = 1
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        };

        var actual = ShopAdapter.FromItemsInShop(items, new()).ToList();

        Assert.Single(actual);
        Assert.IsType<AccordionElementDto>(actual[0]);

        var actualAccordion = (AccordionElementDto)actual[0];
        Assert.NotNull(actualAccordion);
        Assert.NotNull(actualAccordion.Elements);
        Assert.Equal(2, actualAccordion.Elements.Count);
    }

    [Fact]
    public void TestThatFromItemsInShopThrowsUnsupportedShopElementExceptionOnUnsupportedElement()
    {
        var items = new ItemInShop[]
        {
            new()
            {
                Position = 1,
                ShopElement = new UnitTestElement()
            }
        };

        Assert.Throws<UnsupportedShopElementException>(() => ShopAdapter.FromItemsInShop(items, new()));
    }

    [Fact]
    public void TestThatParseProductElementsFromShopElementsParsesHopElementsToProductDetailElements()
    {
        var shopElements = new List<ShopElementDto>
        {
            new ShopProductDetailsElementDto
            {
                Id = Guid.NewGuid(),
                Kind = ElementKind.Product
            },
            new AccordionElementDto
            {
                Kind = ElementKind.Accordion,
                Elements =
                [
                    new ShopProductDetailsElementDto
                    {
                        Id = Guid.NewGuid(),
                        Kind = ElementKind.Product
                    },

                    new NoticeElementDto
                    {
                        Kind = ElementKind.Notice,
                        Content = "test2",
                        Variant = NoticeVariant.Danger
                    },

                    new AccordionElementDto
                    {
                        Kind = ElementKind.Accordion,
                        Elements =
                        [
                            new ShopProductDetailsElementDto
                            {
                                Id = Guid.NewGuid(),
                                Kind = ElementKind.Product
                            }
                        ]
                    }
                ]
            }
        };

        var productDetailElements = ShopAdapter.ParseProductElementsFromShopElements(shopElements);

        Assert.Equal(3, productDetailElements.Count());
    }

    [Fact]
    public void TestThatShopProductDetailsElementDtoSurpassedCustomSaleWindowReturnsFalseIfSaleWindowIsCurrentlyActive()
    {
        var element = new ShopProductDetailsElementDto
        {
            SaleStart = DateTime.UtcNow,
            SaleEnd = DateTime.UtcNow.AddHours(2)
        };

        Assert.False(element.ShopProductDetailsElementDtoSurpassedCustomSaleWindow());
    }

    [Fact]
    public void TestThatShopProductDetailsElementDtoSurpassedCustomSaleWindowReturnsTrueIfSaleWindowHasBeenSurpassed()
    {
        var element = new ShopProductDetailsElementDto
        {
            SaleStart = DateTime.UtcNow.AddDays(-4),
            SaleEnd = DateTime.UtcNow.AddDays(-3)
        };

        Assert.True(element.ShopProductDetailsElementDtoSurpassedCustomSaleWindow());
    }

    [Fact]
    public void TestThatRemoveElementFromElementCollectionUpdatedCollectionWithRemovedElement()
    {
        var removableElementId = Guid.NewGuid();
        var shopElements = new List<ShopElementDto>
        {
            new ShopProductDetailsElementDto
            {
                Id = removableElementId,
                Kind = ElementKind.Product
            },
            new AccordionElementDto
            {
                Kind = ElementKind.Accordion,
                Elements =
                [
                    new ShopProductDetailsElementDto
                    {
                        Id = Guid.NewGuid(),
                        Kind = ElementKind.Product
                    },

                    new NoticeElementDto
                    {
                        Kind = ElementKind.Notice,
                        Content = "test2",
                        Variant = NoticeVariant.Danger
                    },

                    new AccordionElementDto
                    {
                        Kind = ElementKind.Accordion,
                        Elements =
                        [
                            new ShopProductDetailsElementDto
                            {
                                Id = Guid.NewGuid(),
                                Kind = ElementKind.Product
                            }
                        ]
                    }
                ]
            }
        };

        var productToRemove = new ShopProductDetailsElementDto
        {
            Id = removableElementId
        };

        ShopAdapter.RemoveElementFromElementCollection(productToRemove, shopElements);
        Assert.Equal(2, shopElements.Count);
    }

    [Fact]
    public void TestThatShopContainsPricedProductsWillReturnFalseIfNoneOfTheProductsHavePriceCentsAboveZero()
    {
        var shop = new Shop
        {
            ItemsInShop = new List<ItemInShop>
            {
                new()
                {
                    Position = 1,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 0
                    }
                },
                new()
                {
                    Position = 2,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 0
                    }
                }
            }
        };

        Assert.False(shop.ShopContainsPricedProducts());
    }

    [Fact]
    public void TestThatShopContainsPricedProductsReturnsTrueIfAtLeastOneProductHasAPriceCentsAboveZero()
    {
        var shop = new Shop
        {
            ItemsInShop = new List<ItemInShop>
            {
                new()
                {
                    Position = 1,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 0
                    }
                },
                new()
                {
                    Position = 2,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 999
                    }
                },
                new()
                {
                    Position = 3,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 0
                    }
                }
            }
        };

        Assert.True(shop.ShopContainsPricedProducts());
    }

    [Fact]
    public void TestThatShopContainsProductsReturnsFalseForShopWithoutProducts()
    {
        var shop = new Shop
        {
            ItemsInShop = new List<ItemInShop>()
        };

        Assert.False(shop.ShopContainsProducts());
    }

    [Fact]
    public void TestThatShopContainsProductsReturnsTrueForShopWithProducts()
    {
        var shop = new Shop
        {
            ItemsInShop = new List<ItemInShop>
            {
                new()
                {
                    Position = 1,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 0
                    }
                },
                new()
                {
                    Position = 2,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 999
                    }
                },
                new()
                {
                    Position = 3,
                    ProductId = Guid.NewGuid(),
                    Product = new()
                    {
                        PriceCents = 0
                    }
                },
                new()
                {
                    Position = 4,
                    Id = Guid.NewGuid(),
                    ShopElement = new AccordionElement
                    {
                        Elements = new List<AccordionShopElement>
                        {
                            new()
                            {
                                Position = 1,
                                ProductId = Guid.NewGuid()
                            }
                        }
                    }
                }
            }
        };

        Assert.True(shop.ShopContainsProducts());
    }

    [Fact]
    public void TestThatShopContainsProductsReturnsTrueForShopWithProductsInAccordion()
    {
        var shop = new Shop
        {
            ItemsInShop = new List<ItemInShop>
            {
                new()
                {
                    Position = 1,
                    Id = Guid.NewGuid(),
                    ShopElement = new AccordionElement
                    {
                        Elements = new List<AccordionShopElement>
                        {
                            new()
                            {
                                Position = 2,
                                ProductId = Guid.NewGuid()
                            }
                        }
                    }
                }
            }
        };

        Assert.True(shop.ShopContainsProducts());
    }

    #region Unit Test Classes

    private class UnitTestElement : ShopElement
    {
        public override object Clone() => new UnitTestElement();
    }

    #endregion
}