﻿using System;
using System.Collections.Generic;
using System.Linq;
using FanceeData.Models.Ticketing;
using ShopService.Dtos.Responses.Shops;
using ShopService.Utils.Adapter;

namespace ShopService.Tests.Utils.Adapter;

public class ShopsAdapterTests
{
    [Fact]
    public void TestThatToPromoShopsResponseParsedMultipleShops()
    {
        var shops = new List<Shop>
        {
            new()
            {
                Code = "ShopCode1",
                Name = "Shop1",
                Event = new()
                {
                    Description = "Shop desc 1"
                },
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddMonths(6)
            },
            new()
            {
                Code = "ShopCode2",
                Name = "Shop2",
                Event = new()
                {
                    Description = "Shop desc 2"
                },
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddMonths(6)
            }
        };

        var actual = shops.ToPromoShopsResponse();

        Assert.Equal(2, actual.PromoShops.Count());
        Assert.IsType<PromoShopsResponse>(actual);
    }
}