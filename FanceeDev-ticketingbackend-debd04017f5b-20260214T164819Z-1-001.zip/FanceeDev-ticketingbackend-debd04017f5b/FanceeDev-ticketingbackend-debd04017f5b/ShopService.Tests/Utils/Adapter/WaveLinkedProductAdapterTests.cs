using System;
using FanceeData.Models.Ticketing;
using ShopService.Utils.Adapter;
using WebApiCore.Dtos.Shared.ShopElement;

namespace ShopService.Tests.Utils.Adapter;

public class WaveLinkedProductAdapterTests
{
    [Fact]
    public void TestThatToWaveLinkDtoParsesProduct()
    {
        var mockedProductId = Guid.NewGuid();

        var waveLinkedProduct = new Product
        {
            Id = mockedProductId,
            Stock = 100,
            WaveLinkedProduct = null
        };

        var actual = waveLinkedProduct.ToWaveLinkDto();

        Assert.IsType<WaveLinkDto>(actual);
        Assert.Equal(mockedProductId, actual.Id);
        Assert.Equal(100, actual.Stock);
        Assert.Null(actual.WaveLinkedProduct);
    }
}