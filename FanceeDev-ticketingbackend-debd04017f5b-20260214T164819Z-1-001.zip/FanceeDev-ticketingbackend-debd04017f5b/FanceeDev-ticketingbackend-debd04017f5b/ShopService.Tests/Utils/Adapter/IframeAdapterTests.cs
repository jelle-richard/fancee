using System;
using System.Collections.Generic;
using System.Linq;
using FanceeData.Models.Ticketing;
using ShopService.Dtos.Requests.AgendaIframe;
using ShopService.Dtos.Responses.AgendaIframe;
using ShopService.Utils.Adapter;
using WebApiCore.Dtos.Environment;

namespace ShopService.Tests.Utils.Adapter;

public class IframeAdapterTests
{
    private const string ShopCode = "ShopCode";
    private static readonly Guid GoogleAnalyticsId = Guid.NewGuid();

    private static readonly HostedDeploymentEnvironment Env = new()
    {
        FrontendBaseUrl = "https://url.com"
    };

    private static readonly Guid[] EventIds =
    {
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    };

    private static readonly Guid AgendaIframeId = Guid.NewGuid();
    private static readonly Guid AgendaIframeDesignId = Guid.NewGuid();
    private static readonly Guid AddressId = Guid.NewGuid();
    private static readonly Guid OrganizationId = Guid.NewGuid();

    private static readonly AgendaIframe AgendaIframe = new()
    {
        Id = AgendaIframeId,
        OrganizationId = OrganizationId,
        IframeDesignId = AgendaIframeDesignId,
        Name = "Name",
        ShowAllShopsOfActiveEvents = true,
        Active = true,
        GoogleAnalyticsId = GoogleAnalyticsId.ToString(),
        IframeDesign = new()
        {
            Id = AgendaIframeDesignId,
            ShowHeaders = true,
            PrimaryColor = "#00000",
            TextColor = "#00000",
            BackgroundColor = "#00000",
            BackdropColor = "#00000"
        },
        LinkedEvents = new List<Event>
        {
            new()
            {
                Id = EventIds[0],
                OrganizationId = OrganizationId,
                Name = "An event",
                Type = EventType.Normal,
                Status = EventStatus.Active,
                Description = "Description",
                AddressId = AddressId,
                Address = new()
                {
                    Id = AddressId,
                    CountryCode = "NL",
                    PostalCode = "6969AA",
                    Street = "Bourgondiersstraat",
                    City = "Arnhem",
                    HouseNumber = "69",
                    Venue = "Biertaptent Arnhem"
                },
                Shops = new List<Shop>
                {
                    new()
                    {
                        Code = ShopCode,
                        EventId = EventIds[0],
                        Name = "ShopName",
                        Active = true,
                        Layout = ShopLayout.List,
                        ShopDesign = new()
                        {
                            ShopCode = ShopCode,
                            BackgroundMediaFileId = Guid.NewGuid(),
                            PrimaryColor = "#00000",
                            TextColor = "#00000",
                            BackdropColor = "#00000",
                            BackgroundColor = "#00000",
                            BackgroundImageFocalPointWidthPercentage = 0,
                            BackgroundImageFocalPointHeightPercentage = 0,
                            BackgroundMediaFile = new()
                            {
                                Id = Guid.NewGuid(),
                                Name = "File 1",
                                OriginalFileName = "File 1",
                                MimeType = "jpg",
                                Path = "Path"
                            },
                            HeaderMedia = new List<ShopDesignHeaderMedia>
                            {
                                new()
                                {
                                    ShopCode = ShopCode,
                                    FileId = Guid.NewGuid(),
                                    Position = 0,
                                    FocalPointWidthPercentage = 0,
                                    FocalPointHeightPercentage = 0,
                                    File = new()
                                    {
                                        Id = Guid.NewGuid(),
                                        Name = "File 2",
                                        OriginalFileName = "File 2",
                                        MimeType = "jpg",
                                        Path = "Path"
                                    }
                                },
                                new()
                                {
                                    ShopCode = ShopCode,
                                    FileId = Guid.NewGuid(),
                                    Position = 0,
                                    FocalPointWidthPercentage = 0,
                                    FocalPointHeightPercentage = 0,
                                    File = new()
                                    {
                                        Id = Guid.NewGuid(),
                                        Name = "File 3",
                                        OriginalFileName = "File 3",
                                        MimeType = "jpg",
                                        Path = "Path"
                                    }
                                }
                            }
                        }
                    }
                },
                EventMedia = new List<EventMedia>
                {
                    new()
                    {
                        EventId = EventIds[0],
                        FileId = Guid.NewGuid(),
                        Position = 0,
                        FocalPointWidthPercentage = 0,
                        FocalPointHeightPercentage = 0,
                        File = new()
                        {
                            Id = Guid.NewGuid(),
                            Name = "File 4",
                            OriginalFileName = "File 4",
                            MimeType = "jpg",
                            Path = "Path"
                        }
                    }
                }
            }
        }
    };

    private static readonly AgendaIframeRequest IframeRequest = new()
    {
        Events = new(EventIds),
        Design = new()
        {
            ShowHeaders = true,
            PrimaryColor = "#00000",
            BackgroundColor = "#00000",
            BackdropColor = "#00000",
            TextColor = "#00000"
        },
        Active = true,
        GoogleAnalyticsId = GoogleAnalyticsId.ToString(),
        Name = "agendaiframenameofzoikbenookmaareenprogrammeur"
    };

    private static readonly AgendaIframeListItemResponse AgendaIframeListItemResponse = new()
    {
        Id = AgendaIframeId,
        Name = "Name",
        ShowAllActiveEvents = true,
        LinkedEvents = new List<AgendaIframeEventListItemResponse>
        {
            new()
            {
                Name = "An event",
                Type = EventType.Normal,
                StartDate = default,
                EndDate = default
            }
        }
    };

    [Fact]
    public void TestThatToModelAdaptersRequestCorrectly()
    {
        var actual = IframeRequest.ToModel();
        Assert.NotNull(actual);
        Assert.False(actual.ShowAllShopsOfActiveEvents);
        Assert.Equal(actual.GoogleAnalyticsId, IframeRequest.GoogleAnalyticsId);
        Assert.Equal(actual.IframeDesign.ShowHeaders, IframeRequest.Design.ShowHeaders);
        Assert.Equal(actual.IframeDesign.PrimaryColor, IframeRequest.Design.PrimaryColor);
        Assert.Equal(actual.IframeDesign.BackdropColor, IframeRequest.Design.BackdropColor);
        Assert.Equal(actual.IframeDesign.BackgroundColor, IframeRequest.Design.BackgroundColor);
        Assert.Equal(actual.IframeDesign.TextColor, IframeRequest.Design.TextColor);
        Assert.Contains(IframeRequest.Events, g => actual.LinkedEvents.Select(e => e.Id).Contains(g));
    }

    [Fact]
    public void TestThatToListItemResponseAdaptersModelCorrectly()
    {
        var actual = AgendaIframe.ToListItemResponse();

        Assert.Equal(AgendaIframe.Id, actual.Id);
        Assert.Equal(AgendaIframe.ShowAllShopsOfActiveEvents, actual.ShowAllActiveEvents);
        Assert.Equal(AgendaIframe.Name, actual.Name);
        Assert.Contains(AgendaIframe.LinkedEvents.Select(e => e.Name), n => actual.LinkedEvents.Select(e => e.Name).Contains(n));
    }

    [Fact]
    public void TestThatToResponseAdaptersModelCorrectly()
    {
        var actual = AgendaIframe.ToResponse(Env);

        Assert.Equal(actual.Id, AgendaIframe.Id);
        Assert.Equal(actual.OrganizationId, AgendaIframe.OrganizationId);
        Assert.Equal(actual.Name, AgendaIframe.Name);
        Assert.Equal(actual.GoogleAnalyticsId, AgendaIframe.GoogleAnalyticsId);
        Assert.NotNull(actual.Design);
        Assert.Equal(actual.Design.ShowHeaders, AgendaIframe.IframeDesign.ShowHeaders);
        Assert.Equal(actual.Design.BackdropColor, AgendaIframe.IframeDesign.BackdropColor);
        Assert.Equal(actual.Design.BackgroundColor, AgendaIframe.IframeDesign.BackgroundColor);
        Assert.Equal(actual.Design.TextColor, AgendaIframe.IframeDesign.TextColor);
        Assert.Contains(AgendaIframe.LinkedEvents.Select(e => e.Name), n => actual.LinkedEvents.Select(e => e.Name).Contains(n));
        Assert.NotNull(actual.LinkedEvents.First().Shops);
        Assert.NotEmpty(actual.LinkedEvents.First().Shops!);
        Assert.Equal(AgendaIframe.LinkedEvents.First().Shops.First().Code, actual.LinkedEvents.First().Shops!.First().Code);
        Assert.Equal(AgendaIframe.LinkedEvents.First().Shops.First().Name, actual.LinkedEvents.First().Shops!.First().Name);
        Assert.Contains(AgendaIframe.LinkedEvents.First().Shops.First().ShopDesign.HeaderMedia.Select(hm => hm.File.Id), f => actual.LinkedEvents.First().Shops!.First().Design.HeaderImages.Select(hm => hm.Id).Contains(f));
        Assert.Equal(AgendaIframe.LinkedEvents.First().Shops.First().Code, actual.LinkedEvents.First().Shops!.First().Code);
    }
}