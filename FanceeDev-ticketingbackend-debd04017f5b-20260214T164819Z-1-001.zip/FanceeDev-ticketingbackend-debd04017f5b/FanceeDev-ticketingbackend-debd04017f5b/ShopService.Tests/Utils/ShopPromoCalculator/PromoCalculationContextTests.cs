﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ShopService.Dtos.Responses.Shops;
using ShopService.Services.Shops;
using ShopService.Utils.ShopPromoCalculator;
using ShopService.Utils.ShopPromoCalculator.Strategies;

namespace ShopService.Tests.Utils.ShopPromoCalculator;

public class PromoCalculationContextTests
{
    private readonly PromoCalculationContext _sut;
    private readonly Mock<IPromoCalculationStrategy> _mockedStrategy;
    private readonly Mock<IShopsService> _mockedShopsService;

    public PromoCalculationContextTests()
    {
        _mockedStrategy = new();
        _mockedShopsService = new();

        _sut = new(_mockedStrategy.Object, _mockedShopsService.Object);
    }

    [Fact]
    public async Task TestThatCalculateCallsStrategyCalculate()
    {
        await _sut.CalculateAsync();

        _mockedStrategy.Verify(ms => ms.CalculateAsync(_mockedShopsService.Object), Times.Once);
    }

    [Fact]
    public async Task TestThatGetPromoShopsCallsShopsServiceGetPromoShopsAsync()
    {
        _mockedShopsService.Setup(mss => mss.PromoShopsAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new PromoShopsResponse
            {
                PromoShops = new List<PromoShopResponse>
                {
                    new()
                    {
                        Code = "ShopCode1",
                        Name = "Shop1",
                        Description = "Description1",
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow
                    },
                    new()
                    {
                        Code = "ShopCode2",
                        Name = "Shop2",
                        Description = "Description2",
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow
                    }
                }
            });

        var actual = await _sut.PromoShopsAsync();

        Assert.IsType<PromoShopsResponse>(actual);
        Assert.Equal(2, actual.PromoShops.Count());
        Assert.Equal("Shop1", actual.PromoShops.First(ps => ps.Code == "ShopCode1").Name);
    }
}