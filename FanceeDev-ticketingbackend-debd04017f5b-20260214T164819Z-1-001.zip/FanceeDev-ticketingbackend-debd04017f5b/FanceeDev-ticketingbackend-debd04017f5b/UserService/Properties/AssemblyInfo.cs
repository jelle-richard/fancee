﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UserService.Tests")]