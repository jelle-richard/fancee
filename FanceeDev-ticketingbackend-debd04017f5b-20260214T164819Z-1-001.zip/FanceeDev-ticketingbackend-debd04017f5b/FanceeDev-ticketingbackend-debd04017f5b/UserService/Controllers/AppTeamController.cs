using System;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.AppTeam;
using UserService.Dtos.Responses.AppTeam;
using UserService.Services.AppTeam;
using UserService.Services.Organization;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Utils;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

[ApiController]
[Route("/user/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class AppTeamController : ControllerBase
{
    private readonly IAppTeamService _appTeamService;
    private readonly IOrganizationService _organizationService;

    public AppTeamController(IAppTeamService appTeamService, IOrganizationService organizationService)
    {
        _appTeamService = appTeamService;
        _organizationService = organizationService;
    }

    [HttpGet]
    [Route("")]
    [Authorize(AuthenticationSchemes = Schemes.AppTeamScheme)]
    [ProducesResponseType(typeof(ApiResponse<AppTeamResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<AppTeamResponse>>> GetByAppTeam() => await Get(User.GetAppTeamId());

    [HttpGet]
    [Route("{appTeamId:guid}")]
    [Authorize(OrganizationAppTeamPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<AppTeamResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader(false)]
    public async Task<ActionResult<ApiResponse<AppTeamResponse>>> Get(Guid appTeamId)
    {
        if (!User.IsAppTeam())
            await ValidateAppTeamRightsForOrganizationAsync(appTeamId);

        return Ok(new ApiResponse<AppTeamResponse>
        {
            Data = await _appTeamService.AppTeamAsync(appTeamId)
        });
    }

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationAppTeamPermissions.Add)]
    [ProducesResponseType(typeof(ApiResponse<AppTeamCreateResponse>), StatusCodes.Status201Created)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<AppTeamCreateResponse>>> Create([FromBody] AppTeamRequest request)
    {
        var response = await _appTeamService.CreateAsync(Request.GetOrganizationId(), request);

        return CreatedAtAction(nameof(Get), new { appTeamId = response.Id }, new ApiResponse<AppTeamCreateResponse>
        {
            Data = response
        });
    }

    [HttpDelete]
    [Route("{appTeamId:guid}")]
    [Authorize(OrganizationAppTeamPermissions.Remove)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult> Delete(Guid appTeamId)
    {
        if (!await _organizationService.AppTeamBelongsToOrganizationAsync(Request.GetOrganizationId(), appTeamId))
            throw new AppTeamNotFoundException();

        await _appTeamService.DeleteAsync(appTeamId);

        return Ok();
    }

    [HttpPut]
    [Route("{appTeamId:guid}")]
    [Authorize(OrganizationAppTeamPermissions.Add)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<AppTeamCreateResponse>>> Update(Guid appTeamId, [FromBody] AppTeamRequest request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.AppTeamBelongsToOrganizationAsync(organizationId, appTeamId))
            throw new AppTeamNotFoundException();

        await _appTeamService.UpdateAsync(organizationId, appTeamId, request);

        return Ok();
    }

    private async Task ValidateAppTeamRightsForOrganizationAsync(Guid appTeamId)
    {
        if (!await _organizationService.AppTeamBelongsToOrganizationAsync(Request.GetOrganizationId(), appTeamId))
            throw new AppTeamNotFoundException();
    }
}