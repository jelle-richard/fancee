using System;
using System.Net.Mime;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.User.Admin;
using UserService.Dtos.Requests.User.Organization.Contract;
using UserService.Services.Organization;
using UserService.Services.Organization.Exceptions;
using UserService.Utils.Adapter;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Services.Logging;
using WebApiCore.Utils;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

[ApiController]
[Route("/user/organization/contract")]
public class OrganizationContractController : ControllerBase
{
    private readonly IOrganizationContractService _organizationContractService;
    private readonly IUserLoggingService _userLoggingService;

    public OrganizationContractController(IOrganizationContractService organizationContractService, IUserLoggingService userLoggingService)
    {
        _organizationContractService = organizationContractService;
        _userLoggingService = userLoggingService;
    }

    [HttpGet]
    [Route("download/contract")]
    [ProducesResponseType(typeof(FileStreamResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [Authorize(OrganizationContractPermissions.Details)]
    [UseOrganizationHeader]
    public async Task<FileStreamResult> DownloadContract() => File(await _organizationContractService.ActiveContractFileAsync(Request.GetOrganizationId()), MediaTypeNames.Application.Pdf, "Fancee ticketing contract.pdf");

    [HttpGet]
    [Route("download/contract/zip")]
    [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [Authorize(OrganizationContractPermissions.Details)]
    [UseOrganizationHeader]
    public async Task<FileContentResult> DownloadContractAsZip() => File(await _organizationContractService.ActiveContractFileAsZipAsync(Request.GetOrganizationId()), MediaTypeNames.Application.Zip, "Fancee ticketing contract.zip");

    [HttpPost]
    [Route("sign")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [Authorize(OrganizationContractPermissions.Details)]
    [Consumes("multipart/form-data")]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> SignContract([FromForm] UploadSignatureMediaRequest request)
    {
        if (!await _organizationContractService.HasUnsignedContractAsync(Request.GetOrganizationId()))
            throw new NoSignableContractException();

        await _organizationContractService.SignContractAsync(Request.GetOrganizationId(), request.Media);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("{organizationId:guid}/alter")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status423Locked)]
    [Authorize(AdminContractPermissions.AdminAlter)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> AlterContract(Guid organizationId, [FromBody] AlterContractRequest request)
    {
        await _organizationContractService.AlterContractAsync(organizationId, request);

        await _userLoggingService.LogAsync(User.GetUserId(), $"Has altered the contract of the organization {organizationId}");

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("addendum/{organizationId:guid}")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status201Created)]
    [Authorize(AdminContractPermissions.AdminAlter)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> GenerateAddendum(Guid organizationId, [FromBody] CreateContractAddendumRequest request)
    {
        await _organizationContractService.CreateContractAddendumAsync(organizationId, request);

        await _userLoggingService.LogAsync(User.GetUserId(), $"Has added an addendum for the organization {organizationId}");

        return Created(string.Empty, new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("{organizationId:guid}/package/{packageType}")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [Authorize(AdminContractPermissions.AdminAlter)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdatePackageType(Guid organizationId, string packageType)
    {
        await _organizationContractService.UpdateOrganizationPackageTypeAsync(organizationId, packageType.ToOrganizationPackageType());

        await _userLoggingService.LogAsync(User.GetUserId(), $"Has changed the package of organization: {organizationId} to: {packageType}");

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{organizationId:Guid}/download")]
    [ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [Authorize(AdminContractPermissions.AdminDetails)]
    public async Task<FileContentResult> DownloadContractAsAdmin(Guid organizationId)
    {
        await _userLoggingService.LogAsync(User.GetUserId(), $"Has downloaded the contract of organization: {organizationId}");

        return File(await _organizationContractService.ActiveContractFileAsZipAsync(organizationId), MediaTypeNames.Application.Zip, "FanceeTicketingContract.zip");
    }
}