using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.AppTeam;
using UserService.Dtos.Responses.AppTeams;
using UserService.Services.AppTeam;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Requests.Filters.Pagination;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;
using WebApiCore.Utils.Adapter;

namespace UserService.Controllers;

[ApiController]
[Route("/user/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[UseOrganizationHeader]
public class AppTeamsController : ControllerBase
{
    private readonly IAppTeamService _appTeamService;

    public AppTeamsController(IAppTeamService appTeamService)
    {
        _appTeamService = appTeamService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(OrganizationAppTeamPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<AppTeamListItemResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<AppTeamListItemResponse>>>> List([FromQuery] PaginatedRequest<SearchQueryFilter> request)
    {
        var result = await _appTeamService.ListAsync(Request.GetOrganizationId(), request);

        return Ok(result.ToPaginatedApiResponse(request.Page, request.PageSize));
    }

    [HttpGet]
    [Route("list/select-options")]
    [Authorize(OrganizationAppTeamPermissions.List)]
    [ProducesResponseType<ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>>(StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<IEnumerable<SelectOptionResponse<Guid>>>> ListAppTeamSelectOptions(AppTeamOptionsRequest request) =>
        Ok(new ApiResponse<IEnumerable<SelectOptionResponse<Guid>>>
        {
            Data = await _appTeamService.ListSelectOptionsAsync(Request.GetOrganizationId(), request)
        });

    [HttpGet]
    [Route("export/csv")]
    [Authorize(OrganizationCustomerInsightPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> ExportOrganizationTicketsAsCsv([FromQuery] SearchQueryFilter request)
    {
        var file = await _appTeamService.ExportOrganizationAppTeamsAsCsvAsync(Request.GetOrganizationId(), request);

        return File(file.FileContents, "text/csv", $"AppTeams-export-{DateTime.UtcNow}-UTC.csv");
    }
}