using System;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.Organization;
using UserService.Dtos.Responses.Organization;
using UserService.Services.Organization;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Responses;
using WebApiCore.Services.Country;
using WebApiCore.Services.Logging;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

[ApiController]
[Route("/user/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status403Forbidden)]
public class OrganizationsController : ControllerBase
{
    private readonly IOrganizationService _organizationService;
    private readonly ICountryService _countryService;
    private readonly IUserLoggingService _userLoggingService;

    public OrganizationsController(IOrganizationService organizationService, ICountryService countryService, IUserLoggingService userLoggingService)
    {
        _organizationService = organizationService;
        _countryService = countryService;
        _userLoggingService = userLoggingService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(AdminOrganizationManagementPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<OrganizationListResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<OrganizationListResponse>>>> GetList([FromQuery] PaginatedRequest<OrganizationRequestFilter> request)
    {
        request.Options.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.Options.CountryCodes);

        var result = await _organizationService.OrganizationsAsync(request);

        await _userLoggingService.LogAsync(User.GetUserId(), "Has retrieved a list overview of the organizations");

        return Ok(new ApiResponse<PaginatedResponse<OrganizationListResponse>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("export/csv")]
    [Authorize(AdminOrganizationManagementPermissions.Export)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> AdminExportOrganizationsAsCsv([FromQuery] OrganizationRequestFilter request)
    {
        request.CountryCodes = await _countryService.RestrictCountryCodesAsync(User.GetUserId(), request.CountryCodes);

        var file = await _organizationService.OrganizationsAsCsvAsync(request);

        return File(file.FileContents, "text/csv", $"Organizations-export-{DateTime.UtcNow}-UTC.csv");
    }
}