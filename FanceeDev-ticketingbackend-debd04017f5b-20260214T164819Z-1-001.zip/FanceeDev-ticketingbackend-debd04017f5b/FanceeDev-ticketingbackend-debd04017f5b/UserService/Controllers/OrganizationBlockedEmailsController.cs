using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationBlockedEmail;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace UserService.Controllers;

[ApiController]
[Route("/user/organization/blocked-emails")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[UseOrganizationHeader]
public class OrganizationBlockedEmailsController : ControllerBase
{
    private readonly IOrganizationBlockedEmailService _organizationBlockedEmailService;

    public OrganizationBlockedEmailsController(IOrganizationBlockedEmailService organizationBlockedEmailService)
    {
        _organizationBlockedEmailService = organizationBlockedEmailService;
    }

    [HttpGet]
    [Route("list")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationBlockedEmailsResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<OrganizationBlockedEmailsResponse>>> GetBlockedEmails() =>
        Ok(new ApiResponse<OrganizationBlockedEmailsResponse>
        {
            Data = new()
            {
                BlockedEmails = await _organizationBlockedEmailService.GetBlockedEmailsAsync(Request.GetOrganizationId())
            }
        });

    [HttpDelete]
    [Route("list")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteBlockedEmails()
    {
        await _organizationBlockedEmailService.DeleteBlockedEmailsAsync(Request.GetOrganizationId());

        return Ok(new ApiResponse<EmptyResponse>());
    }
}