using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.OrganizationBlockedEmail;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationBlockedEmail;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace UserService.Controllers;

[ApiController]
[Route("/user/organization/blocked-email")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
[UseOrganizationHeader]
public class OrganizationBlockedEmailController : ControllerBase
{
    private readonly IOrganizationBlockedEmailService _organizationBlockedEmailService;

    public OrganizationBlockedEmailController(IOrganizationBlockedEmailService organizationBlockedEmailService)
    {
        _organizationBlockedEmailService = organizationBlockedEmailService;
    }

    [HttpPost]
    [Route("")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationBlockedEmailResponse>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<OrganizationBlockedEmailResponse>>> CreateBlockedEmailEntry([FromBody] OrganizationBlockedEmailRequest request)
    {
        await _organizationBlockedEmailService.CreateBlockedEmailEntryAsync(Request.GetOrganizationId(), request.Email);

        return Created("", new ApiResponse<OrganizationBlockedEmailResponse>
        {
            Data = new()
            {
                BlockedEmail = request.Email
            }
        });
    }

    [HttpPut]
    [Route("")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationBlockedEmailResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<OrganizationBlockedEmailResponse>>> UpdateBlockedEmailEntry([FromBody] OrganizationBlockedEmailUpdateRequest request)
    {
        await _organizationBlockedEmailService.UpdateBlockedEmailEntryAsync(Request.GetOrganizationId(), request.CurrentEmail, request.NewEmail);

        return Ok(new ApiResponse<OrganizationBlockedEmailResponse>
        {
            Data = new()
            {
                BlockedEmail = request.NewEmail
            }
        });
    }

    [HttpDelete]
    [Route("")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteBlockedEmailEntry([FromBody] OrganizationBlockedEmailRequest request)
    {
        await _organizationBlockedEmailService.DeleteBlockedEmailEntryAsync(Request.GetOrganizationId(), request.Email);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}