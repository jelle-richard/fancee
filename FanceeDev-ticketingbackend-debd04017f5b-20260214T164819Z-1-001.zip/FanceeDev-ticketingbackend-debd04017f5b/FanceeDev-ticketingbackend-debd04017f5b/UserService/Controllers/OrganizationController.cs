using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.Organization;
using UserService.Dtos.Requests.User.Organization;
using UserService.Dtos.Responses.Organization;
using UserService.Dtos.Shared.Profile;
using UserService.Services.Organization;
using UserService.Services.Organization.Exceptions;
using WebApiCore.Dtos.Requests.Event;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Responses.Event;
using WebApiCore.Dtos.Responses.ShopField;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.User;
using WebApiCore.Utils;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

/// <summary>
/// Contains all the endpoints related to organization.
/// </summary>
[ApiController]
[Route("/user/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
public class OrganizationController : ControllerBase
{
    private readonly IOrganizationService _organizationService;

    public OrganizationController(IOrganizationService organizationService)
    {
        _organizationService = organizationService;
    }

    [HttpGet]
    [Route("contract")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationContractSpecificationResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<OrganizationContractSpecificationResponse>>> GetContract()
    {
        var contract = await _organizationService.OrganizationContractAsync(Request.GetOrganizationId());
        if (contract == null)
            return NotFound(new ApiResponse<EmptyResponse>());

        return Ok(new ApiResponse<OrganizationContractSpecificationResponse>
        {
            Data = contract
        });
    }

    [HttpGet]
    [Route("profile")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationProfileDto>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<OrganizationProfileDto>>> GetProfile() =>
        Ok(new ApiResponse<OrganizationProfileDto>
        {
            Data = await _organizationService.ProfileAsync(Request.GetOrganizationId())
        });

    [HttpPut]
    [Route("profile/holder")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateAccountHolder([FromBody] HolderRequest request)
    {
        await _organizationService.UpdateHolderAsync(User.GetFanceeUsersId(), Request.GetOrganizationId(), request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("profile/company-info")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateCompanyInfo([FromBody] CompanyInfoRequest request)
    {
        await _organizationService.UpdateCompanyInfoAsync(Request.GetOrganizationId(), request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("profile/finance")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateFinance([FromBody] FinanceRequest request)
    {
        await _organizationService.UpdateFinanceAsync(Request.GetOrganizationId(), request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("profile/contacts")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<Guid>>> AddContact([FromBody] OrganizationContactDto request) =>
        CreatedAtAction(nameof(GetProfile), null, new ApiResponse<Guid>
        {
            Data = await _organizationService.CreateContactAsync(Request.GetOrganizationId(), request)
        });

    [HttpPut]
    [Route("profile/contacts/{id:guid}")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateContact(Guid id, OrganizationContactDto request)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfContactAsync(id, organizationId))
            throw new OrganizationContactNotFoundException();

        await _organizationService.UpdateContactAsync(id, organizationId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("profile/contacts/{id:guid}")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationProfileDto>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteContact(Guid id)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.OwnerOfContactAsync(id, organizationId))
            throw new OrganizationContactNotFoundException();

        await _organizationService.RemoveContactAsync(organizationId, id);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{organizationId:guid}/account")]
    [Authorize(AdminOrganizationManagementPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ApiResponse<OrganizationResponse>>> GetOrganization(Guid organizationId)
    {
        if (!await _organizationService.ExistsAsync(organizationId))
            throw new UserNotFoundException();

        return Ok(new ApiResponse<OrganizationResponse>
        {
            Data = await _organizationService.OrganizationAsync(User.GetUserId(), organizationId)
        });
    }

    [HttpPut]
    [Route("{organizationId:guid}/important/{important:bool}")]
    [Authorize(AdminOrganizationManagementPermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> SetOrganizationImportant(Guid organizationId, bool important)
    {
        if (!User.IsAdmin())
            throw new InvalidUserTypeException();

        if (!await _organizationService.ExistsAsync(organizationId))
            throw new UserNotFoundException();

        await _organizationService.SetOrganizationImportantStateAsync(User.GetUserId(), organizationId, important);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("events/any")]
    [Authorize(OrganizationEventPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<bool>>> OrganizationHasCreatedEvents() =>
        Ok(new ApiResponse<bool>
        {
            Data = await _organizationService.OrganizationHasCreatedEventsAsync(Request.GetOrganizationId())
        });

    [HttpGet]
    [Route("payment-methods/default")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>>> DefaultPaymentMethods() =>
        Ok(new ApiResponse<IEnumerable<AvailablePaymentMethodResponse>>
        {
            Data = await _organizationService.DefaultPaymentMethodsAsync(Request.GetOrganizationId())
        });

    [HttpPut]
    [Route("payment-methods/default")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> AssignDefaultPaymentMethods([FromBody] AssignPaymentMethodsRequestModel request)
    {
        await _organizationService.AssignDefaultPaymentMethodsAsync(Request.GetOrganizationId(), request.PaymentMethods!);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("shop-palette/default")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationShopPaletteResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<OrganizationShopPaletteResponse>>> DefaultShopPalette() =>
        Ok(new ApiResponse<OrganizationShopPaletteResponse>
        {
            Data = await _organizationService.DefaultShopPaletteAsync(Request.GetOrganizationId())
        });

    [HttpPut]
    [Route("shop-palette/default")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> AssignDefaultShopPalette([FromBody] AssignOrganizationShopPaletteRequestModel request)
    {
        await _organizationService.AssignOrganizationShopPaletteAsync(Request.GetOrganizationId(), request.OrganizationShopPalette!);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("request/package")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> RequestPackageChange(OrganizationPackageType packageType)
    {
        var organizationId = Request.GetOrganizationId();

        if (!await _organizationService.ExistsAsync(organizationId))
            throw new UserNotFoundException();

        await _organizationService.RequestPackageChange(organizationId, packageType);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("shop-fields/default")]
    [Authorize(OrganizationEventPermissions.Configure)]
    [ProducesResponseType(typeof(void), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> AssignDefaultShopFields([FromBody] AssignShopFieldsRequestModel request)
    {
        await _organizationService.AddDefaultShopFieldsAsync(Request.GetOrganizationId(), request.ShopFields!);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("shop-fields/default")]
    [Authorize(ProfilePermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<OrganizationDefaultShopFieldResponse>>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<IEnumerable<OrganizationDefaultShopFieldResponse>>>> DefaultShopFields() =>
        Ok(new ApiResponse<IEnumerable<OrganizationDefaultShopFieldResponse>>
        {
            Data = await _organizationService.DefaultShopFieldsAsync(Request.GetOrganizationId())
        });

    [HttpDelete]
    [Route("shop-fields/default/{shopField}")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationDefaultShopField>), StatusCodes.Status200OK)]
    [UseOrganizationHeader]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteDefaultShopFieldAsync([FromRoute] ShopFieldDto shopField)
    {
        await _organizationService.DeleteDefaultShopFieldAsync(Request.GetOrganizationId(), shopField);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}