using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.OrganizationUser;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationUsers;
using WebApiCore.Dtos.Responses;
using WebApiCore.Dtos.Swagger;
using WebApiCore.Utils;

namespace UserService.Controllers;

[ApiController]
[UseOrganizationHeader]
[Route("/user/organization/users")]
public class OrganizationUsersController : ControllerBase
{
    private readonly IOrganizationUsersService _organizationUsersService;

    public OrganizationUsersController(IOrganizationUsersService organizationUsersService)
    {
        _organizationUsersService = organizationUsersService;
    }

    [HttpGet]
    [Route("")]
    [Authorize(OrganizationUsersPermissions.List)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<OrganizationUserResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<OrganizationUserResponse>>>> GetOrganizationUsers() =>
        Ok(new ApiResponse<IEnumerable<OrganizationUserResponse>>
        {
            Data = await _organizationUsersService.GetAsync(Request.GetOrganizationId())
        });

    [HttpPost]
    [Route("")]
    [Authorize(OrganizationUsersPermissions.Add)]
    [ProducesResponseType(typeof(ApiResponse<OrganizationUserResponse>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<OrganizationUserResponse>>> AddOrganizationUser(AddOrganizationUserRequest request) =>
        Created(string.Empty, new ApiResponse<OrganizationUserResponse>
        {
            Data = await _organizationUsersService.AddAsync(request, Request.GetOrganizationId())
        });

    [HttpDelete]
    [Route("{userId:guid}")]
    [Authorize(OrganizationUsersPermissions.Delete)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteOrganizationUser(Guid userId)
    {
        await _organizationUsersService.DeleteAsync(Request.GetOrganizationId(), userId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPut]
    [Route("")]
    [Authorize(OrganizationUsersPermissions.Add)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateOrganizationUser(UpdateOrganizationUserRequest request)
    {
        await _organizationUsersService.UpdateAsync(request, Request.GetOrganizationId());

        return Ok(new ApiResponse<EmptyResponse>());
    }
}