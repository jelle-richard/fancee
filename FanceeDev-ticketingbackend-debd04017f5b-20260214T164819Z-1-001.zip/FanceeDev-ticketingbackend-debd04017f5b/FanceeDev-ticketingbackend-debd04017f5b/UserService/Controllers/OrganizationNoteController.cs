using System;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.OrganizationNote;
using UserService.Services.OrganizationNote;
using UserService.Services.OrganizationNote.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

[ApiController]
[Route("/user/organization/{organizationId:guid}/note")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class OrganizationNoteController : ControllerBase
{
    private readonly IOrganizationNoteService _organizationNoteService;

    public OrganizationNoteController(IOrganizationNoteService organizationNoteService)
    {
        _organizationNoteService = organizationNoteService;
    }

    [HttpPost]
    [Route("")]
    [Authorize(AdminOrganizationManagementPermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [Consumes("multipart/form-data")]
    public async Task<ActionResult<ApiResponse<Guid>>> CreateNote(Guid organizationId, [FromForm] OrganizationNoteRequest request)
    {
        if (!await _organizationNoteService.AdminEligibleForOrganizationNoteMutation(User.GetUserId(), organizationId, null))
            throw new InvalidNoteMutationException();

        return Ok(new ApiResponse<Guid>
        {
            Data = await _organizationNoteService.CreateNoteAsync(User.GetUserId(), organizationId, request)
        });
    }

    [HttpPut]
    [Route("{noteId:guid}")]
    [Authorize(AdminOrganizationManagementPermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [Consumes("multipart/form-data")]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UpdateNote(Guid organizationId, Guid noteId, [FromForm] OrganizationNoteRequest request)
    {
        if (!await _organizationNoteService.AdminEligibleForOrganizationNoteMutation(User.GetUserId(), organizationId, noteId))
            throw new InvalidNoteMutationException();

        await _organizationNoteService.UpdateNoteAsync(User.GetUserId(), organizationId, noteId, request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("{noteId:guid}")]
    [Authorize(AdminOrganizationManagementPermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteNote(Guid organizationId, Guid noteId)
    {
        if (!await _organizationNoteService.AdminEligibleForOrganizationNoteMutation(User.GetUserId(), organizationId, noteId))
            throw new InvalidNoteMutationException();

        await _organizationNoteService.DeleteNoteAsync(noteId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpDelete]
    [Route("{noteId:guid}/file/{fileId}")]
    [Authorize(AdminOrganizationManagementPermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteNoteFile(Guid organizationId, Guid noteId, Guid fileId)
    {
        if (!await _organizationNoteService.AdminEligibleForOrganizationNoteMutation(User.GetUserId(), organizationId, noteId))
            throw new InvalidNoteMutationException();

        await _organizationNoteService.DeleteNoteFileAsync(fileId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("{noteId:guid}/file/{fileId}")]
    [Authorize(AdminOrganizationManagementPermissions.List)]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    public async Task<FileResult> DownloadNoteFile(Guid organizationId, Guid noteId, Guid fileId)
    {
        if (!await _organizationNoteService.AdminEligibleForOrganizationNoteMutation(User.GetUserId(), organizationId, noteId))
            throw new InvalidNoteMutationException();

        var response = await _organizationNoteService.NoteFileAsync(fileId);
        return File(response.File.FileStream, response.File.ContentType, response.Name);
    }
}