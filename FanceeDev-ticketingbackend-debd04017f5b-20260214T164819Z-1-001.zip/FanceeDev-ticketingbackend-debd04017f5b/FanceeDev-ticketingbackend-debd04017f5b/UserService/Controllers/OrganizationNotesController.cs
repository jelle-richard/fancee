using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Responses.Organization;
using UserService.Services.OrganizationNote;
using UserService.Services.OrganizationNote.Exceptions;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

[ApiController]
[Route("/user/organization/notes")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class OrganizationNotesController : ControllerBase
{
    private readonly IOrganizationNoteService _organizationNoteService;

    public OrganizationNotesController(IOrganizationNoteService organizationNoteService)
    {
        _organizationNoteService = organizationNoteService;
    }

    [HttpGet]
    [Route("{organizationId:guid}")]
    [Authorize(AdminOrganizationManagementPermissions.Details)]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<OrganizationNoteResponse>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<IEnumerable<OrganizationNoteResponse>>>> GetNotes(Guid organizationId)
    {
        if (!await _organizationNoteService.AdminEligibleForOrganizationNoteMutation(User.GetUserId(), organizationId, null))
            throw new InvalidNoteMutationException();

        return Ok(new ApiResponse<IEnumerable<OrganizationNoteResponse>>
        {
            Data = await _organizationNoteService.NotesAsync(organizationId)
        });
    }
}