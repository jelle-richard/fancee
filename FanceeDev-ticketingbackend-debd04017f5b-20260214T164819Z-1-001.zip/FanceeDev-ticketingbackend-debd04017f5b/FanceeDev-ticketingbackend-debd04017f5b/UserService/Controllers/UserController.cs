using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.User;
using UserService.Dtos.Responses.User;
using UserService.Services.Password;
using UserService.Services.User;
using WebApiCore.Dtos.Responses;
using WebApiCore.Exceptions.User;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

[ApiController]
[Route("[controller]")]
public class UserController : ControllerBase
{
    private readonly IUserService _userService;
    private readonly IPasswordService _passwordService;

    public UserController(IUserService userService, IPasswordService passwordService)
    {
        _userService = userService;
        _passwordService = passwordService;
    }

    [HttpPost]
    [Route("")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
    public async Task<ActionResult<ApiResponse<CreateUserResponse>>> Create([FromBody] CreateRequest request)
    {
        if (request.Type is UserType.Admin or UserType.Host)
            return Unauthorized(new ApiResponse<EmptyResponse>());

        await _userService.CreateAsync(request);

        return Created(string.Empty, new ApiResponse<CreateUserResponse>
        {
            Data = new()
        });
    }

    [HttpPost]
    [Route("verify")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult> VerifyUser([FromBody] VerifyRequest request)
    {
        await _userService.VerifyAsync((Guid)request.VerifyId!);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("create")]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult> UpdateAndVerifyUser([FromBody] CreateAndVerifyRequest request)
    {
        await _userService.UpdateExistingClientAndVerifyAsync(request);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("verified/{verifyId:guid}")]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<bool>>> IsVerified(Guid verifyId) =>
        Ok(new ApiResponse<bool> { Data = await _userService.IsVerifiedAsync(verifyId) });

    [HttpPut]
    [Route("change-password")]
    [Authorize(ProfilePermissions.Edit)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ChangePassword([FromBody] ChangePasswordRequest request)
    {
        await _passwordService.ChangeAsync(request.OldPassword, request.NewPassword, User.GetFanceeUsersId());

        return Ok();
    }

    [HttpPut]
    [Route("reset-password")]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ResetPassword([FromBody] ResetPasswordRequest request)
    {
        await _passwordService.ChangeAsync(request.ResetToken, request.NewPassword);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    /// <summary>
    /// Adds a forgot password request and sends instructions to the users' email address.
    /// </summary>
    /// <param name="email"></param>
    /// <returns></returns>
    [HttpGet]
    [Route("forgot-password")]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> ForgotPassword([FromQuery] [EmailAddress] string email)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new UserNotFoundException();

            await _passwordService.AddPasswordResetTokenAsync(email, HttpContext.Connection.RemoteIpAddress);
        }
        catch (Exception)
        {
            /*
             * We catch all exceptions so that we can always return 'Ok'.
             * This is so that a user cannot look at the response to see if a user exists.
             */
        }

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("avatar")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status503ServiceUnavailable)]
    [Consumes("multipart/form-data")]
    public async Task<ActionResult<ApiResponse<Guid>>> UploadAvatar([FromForm] UploadUserMediaRequest request)
    {
        var uploadedFile = await _userService.UploadMediaAsync(User.GetUserId(), request);

        return Created(uploadedFile.Url, new ApiResponse<Guid> { Data = uploadedFile.Id });
    }

    [HttpDelete]
    [Route("avatar")]
    [Authorize(ProfilePermissions.Edit)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> DeleteAvatar()
    {
        await _userService.DeleteMediaAsync(User.GetUserId());

        return Ok(new ApiResponse<EmptyResponse>());
    }
}