using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Permissions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserService.Dtos.Requests.User.Admin;
using UserService.Dtos.Responses.CountryManager;
using UserService.Services.User;
using WebApiCore.Dtos.Responses;
using WebApiCore.Services.Country;
using WebApiCore.Utils.HttpContext;

namespace UserService.Controllers;

[ApiController]
[Route("/user/[controller]")]
[ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status401Unauthorized)]
[ProducesResponseType(typeof(void), StatusCodes.Status403Forbidden)]
public class AdminController : ControllerBase
{
    private readonly IUserService _userService;
    private readonly ICountryService _countryService;

    public AdminController(IUserService userService, ICountryService countryService)
    {
        _userService = userService;
        _countryService = countryService;
    }

    [HttpPost]
    [Route("country-manager")]
    [Authorize(AdminCrmPermissions.CreateCountryManager)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<Guid>>> CreateCountryManager([FromBody] CreateCountryManagerRequest request)
    {
        await _countryService.RestrictCountryCodesAsync(User.GetUserId(), new[] { request.CountryCode.ToString() });

        return Created(string.Empty, new ApiResponse<Guid>
        {
            Data = await _userService.CreateCountryManagerAsync(request)
        });
    }

    [HttpPost]
    [Route("customer-service-employee")]
    [Authorize(AdminCrmPermissions.CreateCustomerServiceEmployee)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<Guid>>> CreateCustomerServiceEmployee([FromBody] CreateCustomerServiceEmployeeRequest request) =>
        Created(string.Empty, new ApiResponse<Guid>
        {
            Data = await _userService.CreateCustomerServiceEmployeeAsync(User.GetUserId(), request)
        });

    [HttpPost]
    [Route("country-manager/assign/{customerServiceEmployeeId:guid}/{countryManagerId:guid}")]
    [Authorize(AdminCrmPermissions.AssignCountryManager)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> AssignToCountryManager(Guid customerServiceEmployeeId, Guid countryManagerId)
    {
        await _userService.AssignToCountryManagerAsync(countryManagerId, customerServiceEmployeeId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpGet]
    [Route("country-manager/active")]
    [Authorize(AdminCrmPermissions.ListAdmins)]
    [ProducesResponseType(typeof(ApiResponse<Guid>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<CountryManagerCountriesResponse>>>> GetActiveCountryManagers() =>
        Ok(new ApiResponse<IEnumerable<CountryManagerCountriesResponse>>
        {
            Data = await _userService.ActiveCountryManagersAsync()
        });

    [HttpPost]
    [Route("block-user/{userId:guid}")]
    [Authorize(AdminCrmPermissions.BlockUser)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> BlockUser(Guid userId)
    {
        await _userService.BlockUserAsync(userId);

        return Ok(new ApiResponse<EmptyResponse>());
    }

    [HttpPost]
    [Route("unblock-user/{userId:guid}")]
    [Authorize(AdminCrmPermissions.BlockUser)]
    [ProducesResponseType(typeof(ApiResponse<EmptyResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<EmptyResponse>>> UnblockUser(Guid userId)
    {
        await _userService.UnblockUserAsync(userId);

        return Ok(new ApiResponse<EmptyResponse>());
    }
}