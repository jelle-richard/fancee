﻿namespace UserService.Config;

public static class PasswordConfig
{
    /// <summary>
    /// Determines the work factor for hashing a password
    /// </summary>
    public const int WorkFactor = 13;
}