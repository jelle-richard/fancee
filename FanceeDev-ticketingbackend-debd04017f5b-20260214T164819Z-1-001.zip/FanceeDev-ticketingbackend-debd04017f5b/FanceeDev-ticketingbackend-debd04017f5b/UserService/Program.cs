using CommerceUtils.Providers;
using CommerceUtils.Providers.ChamberOfCommerce;
using CommerceUtils.Utils;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using UserService.Persistence.Currency;
using UserService.Persistence.Organization;
using UserService.Persistence.OrganizationBlockedEmail;
using UserService.Persistence.OrganizationNote;
using UserService.Persistence.OrganizationUsers;
using UserService.Persistence.PasswordReset;
using UserService.Persistence.PaymentMethod;
using UserService.Persistence.Product;
using UserService.Persistence.Shop;
using UserService.Persistence.User;
using UserService.Persistence.User.Admin;
using UserService.Persistence.User.Ambassador;
using UserService.Persistence.User.AppTeam;
using UserService.Persistence.User.Client;
using UserService.Persistence.UserMedia;
using UserService.Services.AppTeam;
using UserService.Services.Commerce;
using UserService.Services.Organization;
using UserService.Services.OrganizationBlockedEmail;
using UserService.Services.OrganizationNote;
using UserService.Services.OrganizationUsers;
using UserService.Services.Password;
using UserService.Services.User;
using WebApiCore;
using WebApiCore.Persistence.Country;
using ZipUtils.Utils;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "UserService",
        EndpointName = "UserService v1"
    }
};

builder.OnConfigureServices += (_, collection) => { collection.AddZipUtils(); };

builder.AddDependency<IUserService, UserService.Services.User.UserService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationService, OrganizationService>(ServiceLifetime.Scoped);
builder.AddDependency<IUserDao, UserDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserMediaDao, UserMediaDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationDao, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPasswordService, PasswordService>(ServiceLifetime.Scoped);
builder.AddDependency<IPasswordResetDao, PasswordResetDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserType, OrganizationDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserType, AmbassadorDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserType, ClientDao>(ServiceLifetime.Scoped);
builder.AddDependency<IAdminDao, AdminDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICommerceService, CommerceService>(ServiceLifetime.Scoped);
builder.AddDependency<ICustomCertificateHttpClient, CustomCertificateHttpClient>(ServiceLifetime.Scoped);
builder.AddDependency<IAppTeamService, AppTeamService>(ServiceLifetime.Scoped);
builder.AddDependency<IAppTeamDao, AppTeamDao>(ServiceLifetime.Scoped);

builder.AddDependency<IOrganizationContractService, OrganizationContractService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationNoteService, OrganizationNoteService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationNoteDao, OrganizationNoteDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationUsersService, OrganizationUsersService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationUsersDao, OrganizationUsersDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPaymentMethodDao, PaymentMethodDao>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationMailService, OrganizationMailService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationBlockedEmailService, OrganizationBlockedEmailService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationBlockedEmailDao, OrganizationBlockedEmailDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICountryDao, CountryDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICurrencyDao, CurrencyDao>(ServiceLifetime.Scoped);
builder.AddDependency<IProductDao, ProductDao>(ServiceLifetime.Scoped);
builder.AddDependency<IShopDao, ShopDao>(ServiceLifetime.Scoped);

builder.AddDependency<ICommerceProvider>(sp => new ChamberOfCommerceProvider(
    sp.GetRequiredService<ICustomCertificateHttpClient>(),
    builder.Configuration.GetValue<string>("Commerce:ChamberOfCommerce:Endpoint"),
    builder.Configuration.GetValue<string>("Commerce:ChamberOfCommerce:ApiKey")), ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();