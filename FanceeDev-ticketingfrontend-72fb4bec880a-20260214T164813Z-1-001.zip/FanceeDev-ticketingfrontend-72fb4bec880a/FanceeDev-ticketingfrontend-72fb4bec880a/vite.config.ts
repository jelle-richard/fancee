import autoprefixer from 'autoprefixer';
import glob from 'fast-glob';
import { existsSync, readFileSync } from 'fs';
import { resolve } from 'path';
import { defineConfig, loadEnv, type PluginOption, type UserConfig } from 'vite';
import { default as createVuePlugin } from '@vitejs/plugin-vue';

export default defineConfig(async ({mode}): Promise<UserConfig> => {
    const env = loadEnv(mode, process.cwd(), '');

    const buildVersion = generateVersion();
    const analyticsTarget = await overrideFile('./analytics-api.local.js', 'https://dev.fanc.ee/analytics-api');
    const apiTarget = await overrideFile('./api.local.js', 'https://dev.fanc.ee/api');
    const shopTarget = await overrideFile('./shop.local.js', 'https://dev.fanc.ee/shop');

    return {
        server: {
            host: true,
            port: 8080,
            proxy: {
                '/api': {
                    target: apiTarget,
                    changeOrigin: true,
                    followRedirects: true,
                    headers: {
                        'CF-Access-Client-Id': env.CF_ACCESS_CLIENT_ID,
                        'CF-Access-Client-Secret': env.CF_ACCESS_CLIENT_SECRET
                    },
                    rewrite: (path: string) => path.replace(/^\/api/, '')
                },
                '/analytics-api': {
                    target: analyticsTarget,
                    changeOrigin: true,
                    followRedirects: true,
                    headers: {
                        'CF-Access-Client-Id': env.CF_ACCESS_CLIENT_ID,
                        'CF-Access-Client-Secret': env.CF_ACCESS_CLIENT_SECRET
                    },
                    rewrite: (path: string) => path.replace(/^\/analytics-api/, '')
                },
                '/shop': {
                    target: shopTarget,
                    changeOrigin: true,
                    followRedirects: true,
                    headers: {
                        'CF-Access-Client-Id': env.CF_ACCESS_CLIENT_ID,
                        'CF-Access-Client-Secret': env.CF_ACCESS_CLIENT_SECRET
                    },
                    rewrite: (path: string) => path.replace(/^\/shop/, '')
                }
            }
        },
        plugins: [
            createVuePlugin(),
            rollbarSourceMapUploadPlugin(buildVersion)
        ],
        build: {
            emptyOutDir: true,
            minify: 'esbuild',
            sourcemap: true,
            rollupOptions: {
                output: {
                    assetFileNames: '[hash].[ext]',
                    chunkFileNames: '[hash].js',
                    entryFileNames: '[hash].js',
                    compact: true,
                    minifyInternalExports: true,
                    manualChunks: {
                        base: [
                            'lodash/groupBy',
                            'lodash/map',
                            'lodash/merge',
                            'luxon',
                            'rollbar',
                            'uuid'
                        ],

                        api: [
                            '@fancee/client',
                            '@fancee/data',
                            '@fancee/api'
                        ],
                        flux: [
                            '@fancee/flux'
                        ],
                        icons: [
                            '@fortawesome/free-brands-svg-icons',
                            '@fortawesome/pro-regular-svg-icons'
                        ],

                        coreComposable: [
                            'src/composable/index.ts'
                        ],
                        coreData: [
                            'src/data/constant/index.ts',
                            'src/data/index.ts'
                        ],
                        coreI18n: [
                            'src/data/i18n/index.ts'
                        ],
                        coreRouter: [
                            'src/data/router/router.ts',
                            'src/data/router/index.ts'
                        ],
                        coreUtils: [
                            'src/product/analytics/util/index.ts',
                            'src/product/ticketing/util/index.ts',
                            'src/util/index.ts'
                        ],

                        vueBase: [
                            'pinia',
                            'vue',
                            'vue-i18n',
                            'vue-router'
                        ],
                        // vueCharts: [
                        //     'apexcharts',
                        //     'vue3-apexcharts'
                        // ],
                        vueTiptap: [
                            '@tiptap/starter-kit',
                            '@tiptap/vue-3'
                        ],
                        vueVuelidate: [
                            '@vuelidate/core',
                            '@vuelidate/validators'
                        ],

                        analytics: [
                            // note(Bas): Analytics data should also be migrated to @fancee/data etc.
                            'src/data/dto/analytics/dashboard/index.ts'
                        ],
                    }
                }
            }
        },
        resolve: {
            alias: {
                '@': resolve(__dirname, './src')
            },
            extensions: [
                '.js',
                '.ts',
                '.json',
                '.vue'
            ]
        },
        css: {
            postcss: {
                plugins: [
                    autoprefixer() as any
                ]
            }
        },
        define: {
            'process.env': {},
            'import.meta.env.VERSION': `'${buildVersion}'`
        }
    };
});

function generateVersion(): string {
    const buildDate = new Date();
    const buildVersionMajor = buildDate.getFullYear();
    const buildVersionMinor = (buildDate.getMonth() + 1);
    const buildVersionPatch = buildDate.getDate();
    const buildVersionBuild = `${buildDate.getHours().toString().padStart(2, '0')}${buildDate.getMinutes().toString().padStart(2, '0')}`;

    return `${buildVersionMajor}.${buildVersionMinor}.${buildVersionPatch}-${buildVersionBuild}`;
}

async function overrideFile(fileName: string, fallback: string): Promise<string> {
    try {
        const {default: value} = await import(fileName);
        return value;
    } catch (_) {
        return fallback;
    }
}

type RollbarSourceMapEntry = {
    readonly content: Blob;
    readonly minified_url: string;
    readonly source_map: string;
};

/**
 * Plugin that uploads source maps to Rollbar.
 */
function rollbarSourceMapUploadPlugin(buildVersion: string): PluginOption {
    if (!('ROLLBAR_SOURCE_MAPS' in process.env)) {
        console.warn('⛔️ Rollbar source-map upload plugin is disabled. Currently not building our production Docker container.');

        return {
            name: 'rollbar-source-map-upload-disabled'
        };
    }

    const branch: string = process.env['ROLLBAR_SOURCE_MAPS']!;
    const branchUrlMap = {
        production: 'ticketing.wearefancee.com',
        staging: 'staging.fanc.ee'
    };

    if (!(branch in branchUrlMap)) {
        console.warn('⚠️ Rollbar source-map upload plugin is disabled. Currently not on a target that should upload source-maps.');
    }

    const accessToken = 'e206c2077b9245f18647c1b1edaf565e';
    const baseUrl = branchUrlMap[branch];

    return {
        name: 'rollbar-source-map-upload',
        async writeBundle() {
            const files = await glob('./**/*.map', {cwd: 'dist'});

            const sourceMaps: RollbarSourceMapEntry[] = files
                .map<RollbarSourceMapEntry | null>(file => {
                    const sourcePath = file.replace('.map', '');
                    const sourceFilename = resolve('dist', sourcePath);

                    if (!existsSync(sourceFilename)) {
                        console.error(`No source file found for ${file}.`);
                        return null;
                    }

                    const sourceMapLocation = resolve('dist', file);

                    try {
                        return {
                            content: new Blob([readFileSync(sourceMapLocation, 'utf-8')], {
                                type: 'application/json'
                            }),
                            minified_url: `/${sourcePath}`,
                            source_map: sourceMapLocation
                        };
                    } catch (err) {
                        console.error(`Could not read source map file ${sourceMapLocation}`, err);
                        return null;
                    }
                })
                .filter(sm => sm !== null) as RollbarSourceMapEntry[];

            if (sourceMaps.length === 0) {
                return;
            }

            try {
                await Promise.all(sourceMaps.map(async ({content, minified_url, source_map}) => {
                    const formData = new FormData();
                    formData.append('access_token', accessToken);
                    formData.append('version', buildVersion);
                    formData.append('minified_url', `//${baseUrl}${minified_url}`);
                    formData.append('source_map', content, source_map);

                    console.log(`Uploading source map for ${minified_url}...`);

                    const response = await fetch('https://api.rollbar.com/api/1/sourcemap', {
                        body: formData,
                        method: 'post'
                    });

                    if (response.ok) {
                        return;
                    }

                    const body = await response.json();
                    console.error(`Uploading source map for ${minified_url} failed.`, body);
                }));
            } catch (err) {
                console.error('Uploading source maps to Rollbar failed.', err);
            }
        }
    };
}
