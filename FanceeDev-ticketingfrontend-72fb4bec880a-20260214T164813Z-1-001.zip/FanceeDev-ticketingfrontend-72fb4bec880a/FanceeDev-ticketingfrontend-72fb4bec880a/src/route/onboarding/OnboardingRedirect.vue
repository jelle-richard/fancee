<template>
    <div/>
</template>

<script
    lang="ts"
    setup>
    import { OrganizationProfile } from '@fancee/data';
    import { computed, unref, watch } from 'vue';
    import { useOnboarding, useRouter } from '@/composable';

    const {profile} = useOnboarding();
    const router = useRouter();

    const routeName = computed(() => {
        const p = unref(profile);

        if (!p) {
            return null;
        }

        if (inPersonalStep(p)) {
            return 'onboarding-personal';
        }

        if (inCompanyStep(p)) {
            return 'onboarding-company';
        }

        if (inFinanceStep(p)) {
            return 'onboarding-financial';
        }

        return 'onboarding-agreement';
    });

    function inPersonalStep(p: OrganizationProfile): boolean {
        return !p.holder.firstName || !p.holder.lastName;
    }

    function inCompanyStep(p: OrganizationProfile): boolean {
        return !p.legalEntity.name || !p.address;
    }

    function inFinanceStep(p: OrganizationProfile): boolean {
        return !p.finance.currency || (!p.finance.bankAccountIban && !p.finance.bankAccountNumber && !p.finance.bankAccountBic);
    }

    watch(routeName, routeName => {
        if (!routeName) {
            return;
        }

        router.replace({
            name: routeName
        });
    }, {immediate: true});
</script>
