<template>
    <canvas
        ref="canvasRef"
        :class="$style.confettiCanvas"/>

    <OnboardingLayoutHeader>
        <h1>{{ t('onboarding.welcome.title') }}</h1>
        <p>{{ t('onboarding.welcome.intro') }}</p>
    </OnboardingLayoutHeader>

    <OnboardingLayoutFooter>
        <FluxSpacer/>

        <FluxPrimaryButton
            icon-after="circle-arrow-right"
            :label="t('onboarding.welcome.start')"
            :to="{name: 'home'}"
            type="route"/>
    </OnboardingLayoutFooter>
</template>

<script
    lang="ts"
    setup>
    import { onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { OnboardingLayoutFooter, OnboardingLayoutHeader } from '@/components/layout';
    import { usePlatformStore, useStore } from '@/data/store';
    import { getConfettiCannon } from '@/util';

    const {t} = useI18n();
    const {organizationContract} = useStore(usePlatformStore());

    const canvasRef = ref<HTMLCanvasElement>();

    onMounted(async () => {
        const confetti = getConfettiCannon(unref(canvasRef)!);
        confetti.fire({
            spread: 90,
            angle: 90,
            xRandom: true,
            y: 1.1,
            decay: 0.9,
            startVelocity: 120,
            gravity: 2,
            particles: 500
        });
    });
</script>

<style
    lang="scss"
    module>
    @use '@/assets/css/breakpoints' as *;

    .confettiCanvas {
        position: fixed;
        top: 0;
        left: 0;
        height: 100dvh;
        width: 100dvw;
        pointer-events: none;
        z-index: 100;

        @include breakpoint-up(lg) {
            left: 300px;
            width: calc(100dvw - 300px);
        }
    }
</style>
