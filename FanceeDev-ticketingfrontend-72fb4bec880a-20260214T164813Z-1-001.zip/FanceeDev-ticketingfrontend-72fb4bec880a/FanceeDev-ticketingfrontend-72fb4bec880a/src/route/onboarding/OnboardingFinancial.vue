<template>
    <OnboardingLayoutHeader>
        <h1>{{ t('onboarding.financial.title') }}</h1>
        <p>{{ t('onboarding.financial.intro') }}</p>
    </OnboardingLayoutHeader>

    <FluxFormColumn v-if="user">
        <CombinedFormNotice/>

        <ValidationField
            :label="t('form.field.currency')"
            :rules="{required}"
            :value="state.currency">
            <FluxFormSelect
                v-model="state.currency"
                :options="currencyOptions"
                :placeholder="t('form.placeholder.currency')"/>
        </ValidationField>

        <ValidationField
            :label="t('form.field.iban')"
            :rules="{required: requiredUnless(state.bankAccountNumber)}"
            :value="state.iban">
            <FluxFormInput
                v-model="state.iban"
                :is-disabled="!!state.bankAccountNumber"
                pattern="iban"
                :placeholder="t('form.placeholder.iban')"/>
        </ValidationField>

        <FluxFormRow>
            <ValidationField
                :label="t('form.field.bankAccountNumber')"
                :rules="{required: requiredUnless(state.iban)}"
                :value="state.bankAccountNumber">
                <FluxFormInput
                    v-model="state.bankAccountNumber"
                    :is-disabled="!!state.iban"
                    :placeholder="t('form.placeholder.bankAccountNumber')"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.bic')"
                :rules="{required: requiredIf(state.bankAccountNumber)}"
                :value="state.bic">
                <FluxFormInput
                    v-model="state.bic"
                    :is-disabled="!!state.iban"
                    :placeholder="t('form.placeholder.bic')"/>
            </ValidationField>
        </FluxFormRow>

        <FluxNotice
            icon="circle-exclamation"
            is-small
            :message="t('onboarding.financial.ibanInfo')"/>

        <FluxFormRow>
            <ValidationField
                v-if="profile && profile.legalEntity.countryCode && profile.legalEntity.countryCode in vatCountries && vatCountries[profile.legalEntity.countryCode]"
                :label="t('form.field.vat')"
                :rules="{required: requiredIf(vatCountries[profile.legalEntity.countryCode] ?? false)}"
                :value="state.vatCode">
                <FluxFormInput
                    v-model="state.vatCode"
                    pattern="vat"
                    :placeholder="t('form.placeholder.vat')"/>
            </ValidationField>

            <ValidationField
                :label="t('onboarding.financial.approximateAnnualSales')"
                :rules="{required, integer, minValue: minValue(1), maxValue: maxValue(999999999)}"
                :value="state.approximateAnnualSales">
                <FluxFormInput
                    v-model="state.approximateAnnualSales"
                    :max="999999999"
                    :max-length="9"
                    :placeholder="t('onboarding.financial.approximateAnnualSalesPlaceholder')"/>
            </ValidationField>
        </FluxFormRow>
    </FluxFormColumn>

    <OnboardingLayoutFooter>
        <FluxSecondaryButton
            :label="t('global.back')"
            :to="{name: 'onboarding-company'}"
            type="route"/>

        <FluxSpacer/>

        <FluxPrimaryButton
            :disabled="invalid"
            icon-after="circle-arrow-right"
            :label="t('global.next')"
            @click="validated(onSubmit)"/>
    </OnboardingLayoutFooter>
</template>

<script
    lang="ts"
    setup>
    import { AccountingVatService, CurrencyService } from '@fancee/api';
    import { CountryCode, Currency } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { computed, onMounted, reactive, ref, unref, watchEffect } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { OnboardingLayoutFooter, OnboardingLayoutHeader } from '@/components/layout';
    import { useOnboarding, useRouter, useService, useUser, useValidationScope } from '@/composable';
    import { useAuthStore, useStore } from '@/data/store';
    import { integer, maxValue, minValue, required, requiredIf, requiredUnless } from '@/data/validation';
    import { convertCurrentyToIcon, toNullableString } from '@/util';

    const {t} = useI18n();
    const {profile, loaded, submitFinance} = useOnboarding();
    const {invalid, validated} = useValidationScope(false);
    const {getCountries: getVatCountries} = useService(AccountingVatService);
    const {getActive: getCurrencies} = useService(CurrencyService);
    const {setUser} = useStore(useAuthStore());
    const router = useRouter();
    const user = useUser();

    const currencies = ref<Currency[]>([]);
    const vatCountries = ref<Partial<Record<CountryCode, boolean>>>({});

    const state = reactive({
        currency: 'EUR' as string | null, // note(Bas): as most of our customers are in europe, we default to euro.
        iban: '',
        bankAccountNumber: '',
        bic: '',
        vatCode: '',
        approximateAnnualSales: null as number | null
    });

    const currencyOptions = computed(() => unref(currencies).map<FluxFormSelectOption>(c => ({
        id: c.shortCode,
        icon: convertCurrentyToIcon(c),
        label: c.name
    })));

    onMounted(() => loaded(async () => {
        const {data: _vatCountries} = await getVatCountries();
        vatCountries.value = _vatCountries;

        const {data: _currencies} = await getCurrencies();
        currencies.value = _currencies;
    })());

    async function onSubmit(): Promise<void> {
        await submitFinance(
            state.currency!, // note(Bas): suppressed because validation handles this.
            toNullableString(state.iban),
            toNullableString(state.bankAccountNumber),
            toNullableString(state.bic),
            toNullableString(state.vatCode),
            state.approximateAnnualSales! // note(Bas): suppressed because validation handles this.
        );

        await router.push({
            name: 'onboarding-agreement'
        });
    }

    watchEffect(() => {
        const _user = unref(user);

        if (!_user) {
            return;
        }

        const currency = unref(currencies).find(c => c.shortCode === state.currency);

        if (!currency) {
            return;
        }

        _user.currency = currency;

        setUser(_user);
    });

    watchEffect(() => {
        state.currency = unref(profile)?.finance.currency?.shortCode ?? 'EUR'; // note(Bas): as most of our customers are in europe, we default to euro.
        state.iban = unref(profile)?.finance.bankAccountIban ?? '';
        state.bankAccountNumber = unref(profile)?.finance.bankAccountNumber ?? '';
        state.bic = unref(profile)?.finance.bankAccountBic ?? '';
        state.vatCode = unref(profile)?.finance.vatIdentifier ?? '';
        state.approximateAnnualSales = unref(profile)?.finance.approximatedAnnualSalesAmount ?? null;
    });
</script>
