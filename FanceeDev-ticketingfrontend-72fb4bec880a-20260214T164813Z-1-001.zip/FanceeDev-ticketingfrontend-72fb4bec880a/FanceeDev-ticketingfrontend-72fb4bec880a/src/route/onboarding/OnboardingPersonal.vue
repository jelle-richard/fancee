<template>
    <OnboardingLayoutHeader>
        <h1>{{ t('onboarding.personal.title') }}</h1>
        <p>{{ t('onboarding.personal.intro') }}</p>
    </OnboardingLayoutHeader>

    <FluxFormColumn v-if="profile">
        <CombinedFormNotice/>

        <FluxFormField :label="t('form.field.email')">
            <FluxFormInput
                v-model="profile.holder.email"
                is-disabled/>
        </FluxFormField>

        <FluxFormField :label="t('form.field.phoneNumber')">
            <FluxFormInput
                v-model="profile.legalEntity.phoneNumber"
                is-disabled/>
        </FluxFormField>

        <FluxFormRow>
            <ValidationField
                :label="t('form.field.firstName')"
                :rules="{required}"
                :value="state.firstName">
                <FluxFormInput
                    v-model="state.firstName"
                    :placeholder="t('form.placeholder.firstName')"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.lastName')"
                :rules="{required}"
                :value="state.lastName">
                <FluxFormInput
                    v-model="state.lastName"
                    :placeholder="t('form.placeholder.lastName')"/>
            </ValidationField>
        </FluxFormRow>

        <FluxDivider/>

        <FluxNotice
            :title="t('onboarding.company.optionalSupportContact')"
            :message="t('onboarding.company.supportContactExplanation')"/>
        <FluxFormRow>
            <FluxSecondaryButton
                v-show="state.supportContact === null"
                icon-before="plus"
                :label="t('onboarding.company.supportContact')"
                @click="addSupportContact"/>
        </FluxFormRow>

        <FluxPane
            v-if="state.supportContact !== null"
            :class="$style.transparentPane">
            <FluxPaneHeader>
                <FluxRemove @click="removeSupportContact"/>
            </FluxPaneHeader>

            <FluxFormColumn>
                <FluxFormRow>
                    <ValidationField
                        :label="t('form.field.email')"
                        :rules="{required, email}"
                        :value="state.supportContact.email">
                        <FluxFormInput v-model="state.supportContact.email"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('form.field.phoneNumber')"
                        :rules="{required, phoneNumber}"
                        :value="state.supportContact.phoneNumber">
                        <FluxFormInput v-model="state.supportContact.phoneNumber"/>
                    </ValidationField>
                </FluxFormRow>

                <FluxFormRow>
                    <ValidationField
                        :label="t('form.field.firstName')"
                        :rules="{required, minLength: minLength(1), maxLength: maxLength(100)}"
                        :value="state.supportContact.firstName">
                        <FluxFormInput v-model="state.supportContact.firstName"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('form.field.lastName')"
                        :rules="{required, minLength: minLength(1), maxLength: maxLength(100)}"
                        :value="state.supportContact.lastName">
                        <FluxFormInput v-model="state.supportContact.lastName"/>
                    </ValidationField>
                </FluxFormRow>
            </FluxFormColumn>
        </FluxPane>
    </FluxFormColumn>

    <OnboardingLayoutFooter>
        <FluxSpacer/>

        <FluxPrimaryButton
            :disabled="invalid"
            icon-after="circle-arrow-right"
            :label="t('global.next')"
            @click="validated(onSubmit)"/>
    </OnboardingLayoutFooter>
</template>

<script
    lang="ts"
    setup>
    import { OrganizationContact } from '@fancee/data';
    import { reactive, unref, watchEffect } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { OnboardingLayoutFooter, OnboardingLayoutHeader } from '@/components/layout';
    import { useOnboarding, useRouter, useValidationScope } from '@/composable';
    import { email, maxLength, minLength, phoneNumber, required } from '@/data/validation';

    const {t} = useI18n();
    const {profile, submitHolder} = useOnboarding();
    const {invalid, validated} = useValidationScope(false);
    const router = useRouter();

    const state = reactive({
        firstName: '',
        lastName: '',
        supportContact: null as OrganizationContact | null
    });

    function addSupportContact(): void {
        state.supportContact = OrganizationContact.empty();
    }

    function removeSupportContact(): void {
        state.supportContact = null;
    }

    async function onSubmit(): Promise<void> {
        await submitHolder(state.firstName, state.lastName, state.supportContact);

        await router.push({
            name: 'onboarding-company'
        });
    }

    watchEffect(() => {
        let _profile = unref(profile);

        state.firstName = _profile?.holder.firstName ?? '';
        state.lastName = _profile?.holder.lastName ?? '';

        state.supportContact = _profile?.contacts.length === 0
            ? null
            : _profile?.contacts[0] ?? null;
    });
</script>

<style module>
    .transparentPane {
        background-color: transparent;
        border: none;
        box-shadow: none
    }
</style>
