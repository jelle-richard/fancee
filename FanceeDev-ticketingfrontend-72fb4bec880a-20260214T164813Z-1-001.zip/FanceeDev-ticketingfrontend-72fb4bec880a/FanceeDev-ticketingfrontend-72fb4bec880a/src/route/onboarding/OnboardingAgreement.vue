<template>
    <OnboardingLayoutHeader>
        <h1>{{ t('onboarding.agreement.title') }}</h1>
        <p>{{ t('onboarding.agreement.intro') }}</p>
    </OnboardingLayoutHeader>

    <FluxNotice
        v-if="organizationContract?.signed"
        icon="circle-exclamation"
        is-small
        :message="t('onboarding.agreement.alreadySigned')"
        variant="danger"/>

    <FluxFormColumn v-else-if="profile">
        <CombinedFormNotice/>

        <FluxPane v-if="contractPdfSource">
            <FluxPaneBody v-if="contractDownloadFailed">
                <FluxNotice
                    icon="circle-exclamation"
                    is-small
                    :message="t('onboarding.agreement.downloadFailed')"
                    variant="danger"/>
            </FluxPaneBody>

            <template v-else-if="contractPdfSource">
                <FluxPaneBody>
                    <VuePdfEmbed
                        ref="pdfViewer"
                        :page="currentPage"
                        :source="contractPdfSource"
                        @rendered="onPdfRendered()"/>
                </FluxPaneBody>

                <FluxPaneFooter :class="$style.contractFooter">
                    <FluxSecondaryButton
                        icon-before="arrow-down-to-line"
                        :label="t('global.download')"
                        @click="onDownloadClick()"/>

                    <FluxSecondaryButton
                        icon-before="refresh"
                        :label="t('global.refresh')"
                        @click="loadContract()"/>

                    <FluxSpacer/>

                    <FluxPagination
                        is-compact
                        :page="currentPage"
                        :per-page="pageLength"
                        :total="totalItems"
                        @navigate="setCurrentPage"/>
                </FluxPaneFooter>
            </template>
        </FluxPane>

        <FluxPane
            v-else
            is-loading>
            <FluxPaneBody/>
        </FluxPane>

        <FluxNotice
            icon="circle-exclamation"
            is-small
            :message="t('onboarding.agreement.negotiate')"/>
    </FluxFormColumn>

    <OnboardingLayoutFooter :class="$style.onboardingFooter">
        <FluxSecondaryButton
            :label="t('global.back')"
            :to="{name: 'onboarding-financial'}"
            type="route"/>

        <FluxSpacer/>

        <FluxButtonStack>
            <FluxSecondaryButton
                :label="t('onboarding.agreement.contactSales')"
                type="link"
                :href="`mailto:${SALES_EMAIL}?subject=${unref(contractNegotiationSubject)}`"/>

            <FluxPrimaryButton
                v-if="organizationContract?.signed"
                icon-after="circle-arrow-right"
                :label="t('global.next')"
                :to="{name: 'home'}"
                type="route"/>

            <FluxPrimaryButton
                v-else
                :disabled="!contractPdfSource"
                icon-after="circle-arrow-right"
                :label="t('onboarding.agreement.sign')"
                @click="onSignClick"/>
        </FluxButtonStack>
    </OnboardingLayoutFooter>

    <FluxOverlay size="medium">
        <SignOverlay
            v-if="signpadOpened"
            @close="signpadOpened = false"
            @save="onSignatureProvided"/>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { OrganizationService, UserService } from '@fancee/api';
    import { defineAsyncComponent, onMounted, onUnmounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice } from '@/components/form';
    import { OnboardingLayoutFooter, OnboardingLayoutHeader } from '@/components/layout';
    import { SignOverlay } from '@/components/ui';
    import { useOnboarding, usePagination, useRouter, useService } from '@/composable';
    import { usePlatformStore, useStore } from '@/data/store';
    import { downloadUrl, wait } from '@/util';
    import { CONTRACT_DOWNLOAD_MS, SALES_EMAIL } from '@/data';

    const VuePdfEmbed = defineAsyncComponent(() => import('vue-pdf-embed/dist/vue3-pdf-embed'));

    const {t} = useI18n();
    const {organizationId, profile, loaded, sandboxed} = useOnboarding();
    const {getContract} = useService(OrganizationService);
    const {downloadContract, signContract} = useService(UserService);
    const {organizationContract, setOrganizationContract} = useStore(usePlatformStore());
    const router = useRouter();

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setTotalItems
    } = usePagination(1);

    const contractDownloadAttempts = ref(0);
    const contractDownloadFailed = ref(false);
    const contractPdfSource = ref<string | null>(null);
    const pdfViewer = ref<{ readonly pageCount: number; }>();
    const signpadOpened = ref(false);
    const contractNegotiationSubject = ref(`Contract negotiation "${unref(profile)?.legalEntity.name ?? ''}" - ${unref(profile)?.legalEntity.countryCode ?? 'NL'}`);

    onMounted(async () => await loadContract());

    onUnmounted(() => contractPdfSource.value && URL.revokeObjectURL(contractPdfSource.value));

    async function fetchContractUntilSigned(): Promise<void> {
        const {data: contract} = await getContract(unref(organizationId));

        if (contract.signed) {
            await setOrganizationContract(contract);
            return;
        }

        await wait(500);

        return fetchContractUntilSigned();
    }

    async function loadContract(): Promise<void> {
        await sandboxed(
            async () => {
                const {blob} = await downloadContract(unref(organizationId));
                contractPdfSource.value = URL.createObjectURL(blob);

                const {data: contract} = await getContract(unref(organizationId));
                await setOrganizationContract(contract);
            },
            async () => {
                if (++contractDownloadAttempts.value >= 30) {
                    contractDownloadFailed.value = true;
                } else {
                    setTimeout(() => loadContract(), CONTRACT_DOWNLOAD_MS);
                }
            }
        );
    }

    function onDownloadClick(): void {
        const source = unref(contractPdfSource);

        if (!source) {
            return;
        }

        downloadUrl(source, 'contract.pdf');
    }

    function onPdfRendered(): void {
        setTotalItems(unref(pdfViewer)!.pageCount);
    }

    async function onSignatureProvided(signatureBlob: Blob): Promise<void> {
        signpadOpened.value = false;

        await loaded(async () => {
            await signContract(unref(organizationId), signatureBlob);
            await fetchContractUntilSigned();

            await router.push({
                name: 'onboarding-welcome'
            });
        })();
    }

    async function onSignClick(): Promise<void> {
        if (!unref(contractPdfSource)) {
            return;
        }

        signpadOpened.value = true;
    }
</script>

<style
    lang="scss"
    module>
    @use '@/assets/css/breakpoints' as *;

    .onboardingFooter {
        flex-wrap: wrap;
    }

    .contractFooter {
        flex-wrap: wrap;
    }

    @include breakpoint-down(lg) {
        .onboardingFooter {
            flex-direction: column-reverse;
        }
    }
</style>
