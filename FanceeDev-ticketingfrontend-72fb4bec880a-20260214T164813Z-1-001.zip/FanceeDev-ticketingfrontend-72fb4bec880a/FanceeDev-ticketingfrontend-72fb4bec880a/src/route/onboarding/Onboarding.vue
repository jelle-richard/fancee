<template>
    <OnboardingLayout
        :is-loading="isLoading"
        :step="currentStep"
        :steps="4">
        <RouterView/>
    </OnboardingLayout>
</template>

<script
    lang="ts"
    setup>
    import { computed, unref } from 'vue';
    import { OnboardingLayout } from '@/components/layout';
    import { useOnboarding, useRouteName } from '@/composable';

    const ONBOARDING_ROUTE_NAMES = [
        'onboarding-personal',
        'onboarding-company',
        'onboarding-financial',
        'onboarding-agreement',
        'onboarding-welcome'
    ];

    const {isLoading} = useOnboarding();
    const routeName = useRouteName();

    const currentStep = computed(() => ONBOARDING_ROUTE_NAMES.indexOf(unref(routeName)) + 1);
</script>
