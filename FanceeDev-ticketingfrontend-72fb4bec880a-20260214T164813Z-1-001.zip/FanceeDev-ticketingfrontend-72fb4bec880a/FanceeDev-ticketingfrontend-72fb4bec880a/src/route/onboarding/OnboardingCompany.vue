<template>
    <OnboardingLayoutHeader>
        <h1>{{ t('onboarding.company.title') }}</h1>
        <p>{{ t('onboarding.company.intro') }}</p>
    </OnboardingLayoutHeader>

    <FluxFormColumn v-if="user">
        <CombinedFormNotice/>

        <ValidationField
            :label="t('form.field.organizationName')"
            :rules="{required}"
            :value="state.name">
            <FluxFormInput
                v-model="state.name"
                :placeholder="t('form.placeholder.organizationName')"/>
        </ValidationField>

        <FluxFormField
            is-optional
            :label="t('form.field.chamberOfCommerce')">
            <FluxFormInput v-model="state.chamberOfCommerce"/>
        </FluxFormField>

        <FluxDivider/>

        <FluxFormField :label="t('form.field.country')">
            <FluxFormSelect
                v-model="state.country"
                is-disabled
                is-searchable
                :options="SELECT_COUNTRY_OPTIONS"/>
        </FluxFormField>

        <ValidationField
            :label="t('form.field.timezone')"
            :rules="{required}"
            :value="state.timezone">
            <FluxFormTimeZonePicker v-model="state.timezone"/>
        </ValidationField>

        <FluxDivider/>

        <FluxFormField :label="t('form.field.address')">
            <GooglePlacesAutocomplete
                :placeholder="t('form.placeholder.address')"
                @addressChanged="onAddressChanged"/>
        </FluxFormField>

        <FluxFormRow>
            <ValidationField
                :label="t('form.field.addressStreet')"
                :rules="{required}"
                :value="state.address.street">
                <FluxFormInput v-model="state.address.street"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.addressHouseNumber')"
                :rules="{required}"
                :value="state.address.houseNumber">
                <FluxFormInput v-model="state.address.houseNumber"/>
            </ValidationField>
        </FluxFormRow>

        <FluxFormRow>
            <ValidationField
                :label="t('form.field.addressPostalCode')"
                :rules="{required}"
                :value="state.address.postalCode">
                <FluxFormInput v-model="state.address.postalCode"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.addressCity')"
                :rules="{required}"
                :value="state.address.city">
                <FluxFormInput v-model="state.address.city"/>
            </ValidationField>
        </FluxFormRow>
    </FluxFormColumn>

    <OnboardingLayoutFooter>
        <FluxSecondaryButton
            :label="t('global.back')"
            :to="{name: 'onboarding-personal'}"
            type="route"/>

        <FluxSpacer/>

        <FluxPrimaryButton
            :disabled="invalid"
            icon-after="circle-arrow-right"
            :label="t('global.next')"
            @click="validated(onSubmit)"/>
    </OnboardingLayoutFooter>
</template>

<script
    lang="ts"
    setup>
    import { Address, type CountryCode, LegalEntity } from '@fancee/data';
    import { reactive, unref, watchEffect } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, GooglePlacesAutocomplete, ValidationField } from '@/components/form';
    import { OnboardingLayoutFooter, OnboardingLayoutHeader } from '@/components/layout';
    import { useOnboarding, useRouter, useUser, useValidationScope } from '@/composable';
    import { SELECT_COUNTRY_OPTIONS } from '@/data';
    import { required } from '@/data/validation';
    import { toNullableString } from '@/util';

    const {t} = useI18n();
    const {profile, submitCompany} = useOnboarding();
    const {invalid, validated} = useValidationScope(false);
    const router = useRouter();
    const user = useUser();

    const state = reactive({
        name: '',
        chamberOfCommerce: '',
        country: 'NL' as CountryCode,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        address: Address.empty()
    });

    function onAddressChanged(address: Address): void {
        state.address = address;
    }

    async function onSubmit(): Promise<void> {
        await submitCompany(state.address as Address, new LegalEntity(
            state.name,
            state.country,
            toNullableString(state.chamberOfCommerce),
            state.timezone,
            unref(profile)?.legalEntity.phoneNumber ?? null
        ));

        await router.push({
            name: 'onboarding-financial'
        });
    }

    watchEffect(() => {
        state.name = unref(profile)?.legalEntity.name ?? '';
        state.chamberOfCommerce = unref(profile)?.legalEntity.chamberOfCommerceIdentifier ?? '';
        state.country = unref(profile)?.legalEntity.countryCode ?? 'NL';
        state.timezone = unref(profile)?.legalEntity.timezoneIdentification ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
        state.address = unref(profile)?.address ?? Address.empty();
    });
</script>
