<template>
    <AuthLayout
        :title="t('platform.receipt.title')"
        :description="t('platform.receipt.description')">

        <FluxNotice
            v-if="generatingFailed"
            is-small
            icon="circle-exclamation"
            :message="t('platform.receipt.failed')"
            variant="danger"/>

        <FluxNotice
            v-else-if="isDownloading || isGenerating"
            is-loading
            is-small
            :message="t('platform.receipt.downloading')"/>

        <FluxNotice
            v-else-if="downloadFailed"
            icon="circle-exclamation"
            is-small
            :message="t('platform.receipt.exceeded')"
            variant="warning"/>

        <FluxNotice
            v-else
            icon="circle-check"
            is-small
            :message="t('platform.receipt.success')"
            variant="info"/>
    </AuthLayout>
</template>

<script
    setup
    lang="ts">
    import { OrderService } from '@fancee/api';
    import { downloadBlob, guarded, wait } from '@/util';
    import { useI18n } from 'vue-i18n';
    import { useRouteParam, useService } from '@/composable';
    import { onMounted, ref, unref } from 'vue';
    import { AuthLayout } from '@/components/layout';
    import { CHECK_RECEIPT_GENERATED_MS, GENERATE_RECEIPT_MS } from '@/data';

    const {t} = useI18n();
    const {generateReceipt: generate, getReceipt} = useService(OrderService);

    const _generateReceipt = guarded(generate);
    const _getReceipt = guarded(getReceipt, () => void 0);

    const isGenerating = ref(false);
    const downloadAttempts = ref(0);
    const downloadFailed = ref(false);
    const downloadLimit = ref(30);
    const isDownloading = ref(false);
    const generatingFailed = ref(false);

    const orderId = useRouteParam('id');

    onMounted(async () => {
        await generateReceipt();
    });

    async function generateReceipt(): Promise<void> {
        if (unref(orderId) === null) {
            return;
        }

        isGenerating.value = true;

        try {
            await _generateReceipt(unref(orderId)!);
            await downloadReceipt();
        } catch (err) {
            generatingFailed.value = true;
        } finally {
            isGenerating.value = false;
        }
    }

    async function downloadReceipt(): Promise<void> {
        downloadFailed.value = false;
        isDownloading.value = true;

        await wait(GENERATE_RECEIPT_MS);

        try {
            const {blob, name} = await _getReceipt(unref(orderId)!);
            downloadBlob(blob, name);

            isDownloading.value = false;
        } catch (err) {
            ++downloadAttempts.value;

            if (unref(downloadAttempts) >= unref(downloadLimit)) {
                downloadFailed.value = true;
                isDownloading.value = false;
                return;
            }

            await wait(CHECK_RECEIPT_GENERATED_MS);
            await downloadReceipt();
        }
    }
</script>
