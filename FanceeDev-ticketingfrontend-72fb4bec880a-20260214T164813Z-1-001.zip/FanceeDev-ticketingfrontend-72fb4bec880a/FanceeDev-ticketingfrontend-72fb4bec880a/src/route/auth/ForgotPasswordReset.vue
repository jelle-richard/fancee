<template>
    <form @submit.prevent>
        <AuthLayout
            :title="t('auth.forgotPasswordReset.title')"
            :description="t('auth.forgotPasswordReset.description')"
            :is-loading="isLoading">
            <CombinedFormNotice/>

            <FluxNotice
                v-if="isSuccessful"
                icon="circle-check"
                is-small
                :message="t('auth.forgotPasswordReset.success')"
                variant="success"/>

            <FluxFormColumn>
                <ValidationField
                    :label="t('form.field.passwordNew')"
                    :rules="{required, minLength: minLength(6)}"
                    :value="state.password">
                    <FluxFormInput
                        v-model="state.password"
                        auto-complete="new-password"
                        auto-focus
                        data-testid="forgot-password-reset-password"
                        type="password"/>
                </ValidationField>

                <ValidationField
                    :label="t('form.field.passwordNewConfirm')"
                    :rules="{required, sameAs: sameAs(state.password)}"
                    :value="state.passwordConfirm">
                    <FluxFormInput
                        v-model="state.passwordConfirm"
                        auto-complete="new-password"
                        auto-focus
                        data-testid="forgot-password-reset-password-confirm"
                        type="password"/>
                </ValidationField>
            </FluxFormColumn>

            <FluxButtonStack
                axis="vertical"
                is-fill>
                <FluxPrimaryButton
                    data-testid="forgot-password-reset"
                    :disabled="invalid"
                    icon-after="circle-arrow-right"
                    :is-loading="isLoading"
                    is-submit
                    :label="t('global.continue')"
                    @click="validated(onResetPasswordClicked)"/>

                <FluxSeparator/>

                <FluxSecondaryButton
                    data-testid="forgot-password-back-to-login"
                    :label="t('global.cancel')"
                    :to="{name: 'auth-login'}"
                    type="route"/>
            </FluxButtonStack>
        </AuthLayout>
    </form>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { reactive, ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRequestErrorBoundary, useRoute, useRouter, useService, useValidationScope } from '@/composable';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { minLength, required, sameAs } from '@/data/validation';
    import { REDIRECT_TO_LOGIN_MS } from '@/data';

    const {t} = useI18n();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const {resetPassword} = useService(UserService);
    const {invalid, validated} = useValidationScope(false);
    const route = useRoute();
    const router = useRouter();

    const isLoading = ref(false);
    const isSuccessful = ref(false);

    const state = reactive({
        password: '',
        passwordConfirm: ''
    });

    async function onResetPasswordClicked(): Promise<void> {
        isLoading.value = true;

        resetErrors();

        await resetPassword(route.query.token as string, state.password)
            .finally(() => isLoading.value = false);

        isSuccessful.value = true;

        setTimeout(() => router.push({name: 'auth-login'}), REDIRECT_TO_LOGIN_MS);
    }
</script>
