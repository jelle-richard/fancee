<template>
    <AuthLayout
        :title="t('auth.verify.title')"
        :description="t('auth.verify.description')">
        <CombinedFormNotice/>

        <FluxNotice
            v-if="isLoading"
            is-loading
            is-small
            :message="t('auth.verify.busy')"/>

        <template v-else-if="isVerified">
            <FluxNotice
                icon="circle-check"
                is-small
                :message="t('auth.verify.done')"
                variant="success"/>

            <FluxPrimaryButton
                data-testid="register-login"
                icon-after="circle-arrow-right"
                :label="t('auth.login.title')"
                :to="{name: 'auth-login'}"
                type="route"/>
        </template>
    </AuthLayout>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { ref, unref, watchEffect } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { useRouteParam, useService } from '@/composable';

    const {t} = useI18n();
    const {verify} = useService(UserService);
    const code = useRouteParam('code');

    const isLoading = ref(false);
    const isVerified = ref(false);

    watchEffect(async () => {
        isLoading.value = true;

        const verifyId = unref(code);

        if (!verifyId) {
            return;
        }

        await verify(verifyId)
            .finally(() => isLoading.value = false);

        isVerified.value = true;
    });
</script>
