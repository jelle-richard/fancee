<template>
    <form @submit.prevent>
        <AuthLayout
            :title="t(`auth.register.${registerType.toLowerCase()}.title`)"
            :description="t(`auth.register.${registerType.toLowerCase()}.description`)"
            :is-loading="isLoading">
            <CombinedFormNotice/>

            <template v-if="isRegisterComplete">
                <FluxNotice
                    icon="circle-check"
                    is-small
                    :message="t('auth.register.complete')"
                    variant="success"/>

                <FluxPrimaryButton
                    data-testid="register-login"
                    icon-after="circle-arrow-right"
                    :label="t('auth.login.title')"
                    size="large"
                    :to="{name: 'auth-login'}"
                    type="route"/>
            </template>

            <template v-else>
                <FluxFormColumn>
                    <ValidationField
                        :label="t('form.field.email')"
                        :rules="{required, email}"
                        :value="state.email">
                        <FluxFormInput
                            v-model="state.email"
                            auto-complete="email"
                            data-testid="register-email"
                            type="email"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('form.field.password')"
                        :rules="{required, minLength: minLength(6)}"
                        :value="state.password">
                        <FluxFormInput
                            v-model="state.password"
                            auto-complete="new-password"
                            data-testid="register-password"
                            type="password"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('form.field.passwordConfirm')"
                        :rules="{required, sameAs: sameAs(state.password)}"
                        :value="state.passwordConfirm">
                        <FluxFormInput
                            v-model="state.passwordConfirm"
                            auto-complete="new-password"
                            data-testid="register-repeat-password"
                            type="password"/>
                    </ValidationField>

                    <template v-if="registerType === UserType.Organization">
                        <FluxDivider/>

                        <ValidationField
                            :label="t('form.field.organizationName')"
                            :rules="{required}"
                            :value="state.organizationName">
                            <FluxFormInput
                                v-model="state.organizationName"
                                data-testid="register-organization-name"/>
                        </ValidationField>

                        <ValidationField
                            :label="t('form.field.country')"
                            :rules="{required}"
                            :value="state.organizationCountry">
                            <FluxFormSelect
                                v-model="state.organizationCountry"
                                is-searchable
                                data-testid="register-organization-country"
                                :options="SELECT_COUNTRY_OPTIONS"/>
                        </ValidationField>

                        <ValidationField
                            :label="t('form.field.phoneNumber')"
                            :rules="{required, phoneNumber: phoneNumber(state.organizationCountry)}"
                            :value="state.organizationPhoneNumber">
                            <FluxFormInput
                                v-model="state.organizationPhoneNumber"
                                data-testid="register-organization-phone-number"/>
                        </ValidationField>
                    </template>
                </FluxFormColumn>

                <FluxDivider/>

                <FluxButtonStack
                    axis="vertical"
                    is-fill>
                    <FluxPrimaryButton
                        data-testid="register-submit"
                        :disabled="invalid"
                        icon-before="circle-check"
                        is-submit
                        :label="t('auth.register.submit')"
                        size="large"
                        @click="validated(onRegisterClicked)"/>

                    <FluxSecondaryButton
                        data-testid="register-cancel"
                        :label="t('global.cancel')"
                        :to="{name: 'auth-register'}"
                        type="route"/>
                </FluxButtonStack>
            </template>
        </AuthLayout>
    </form>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { AuthAdapter, CountryCode, UserType } from '@fancee/data';
    import { computed, reactive, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { useRequestErrorBoundary, useRoute, useService, useValidationScope } from '@/composable';
    import { email, minLength, phoneNumber, required, sameAs } from '@/data/validation';
    import { SELECT_COUNTRY_OPTIONS } from '@/data';

    const {t} = useI18n();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const {register} = useService(UserService);
    const {invalid, validated} = useValidationScope(false);
    const route = useRoute();

    const registerType = computed(() => AuthAdapter.parseUserType(route.params.type as string));

    const state = reactive({
        email: '',
        password: '',
        passwordConfirm: '',
        organizationCountry: 'NL' as CountryCode,
        organizationName: '',
        organizationPhoneNumber: ''
    });

    const isLoading = ref(false);
    const isRegisterComplete = ref(false);

    async function onRegisterClicked(): Promise<void> {
        resetErrors();

        isLoading.value = true;

        try {
            switch (unref(registerType)) {
                case UserType.Organization:
                    await register(state.email, state.password, UserType.Organization, state.organizationCountry, state.organizationName, state.organizationPhoneNumber);
                    break;

                default:
                    await register(state.email, state.password, UserType.Client, null, null, null);
                    break;
            }

            isRegisterComplete.value = true;
        } finally {
            isLoading.value = false;
        }
    }
</script>
