<template>
    <form @submit.prevent>
        <AuthLayout
            :title="t('auth.login.title')"
            :description="t('auth.login.description')"
            :is-loading="isLoading">
            <CombinedFormNotice/>

            <FluxFormColumn>
                <ValidationField
                    :label="t('form.field.email')"
                    :rules="{required, email}"
                    :value="state.email">
                    <FluxFormInput
                        v-model="state.email"
                        auto-complete="email"
                        auto-focus
                        data-testid="login-email"
                        type="email"/>
                </ValidationField>

                <ValidationField
                    :label="t('form.field.password')"
                    :rules="{required}"
                    :value="state.password">
                    <FluxFormInput
                        v-model="state.password"
                        auto-complete="new-password"
                        data-testid="login-password"
                        type="password"/>
                </ValidationField>
            </FluxFormColumn>

            <FluxButtonStack
                axis="vertical"
                is-fill>
                <FluxPrimaryButton
                    data-testid="login-sign-in"
                    :disabled="invalid"
                    icon-before="circle-check"
                    is-submit
                    :label="t('auth.login.submit')"
                    size="large"
                    @click="validated(onSignInClicked)"/>

                <FluxDivider>
                    {{ t('auth.login.or') }}
                </FluxDivider>

                <FluxSecondaryButton
                    data-testid="login-forgot-password"
                    :label="t('auth.login.forgotPassword')"
                    :to="{name: 'auth-forgot-password'}"
                    type="route"/>

                <FluxSecondaryButton
                    data-testid="login-register"
                    :label="t('auth.login.createAccount')"
                    :to="{name: 'auth-register'}"
                    type="route"/>
            </FluxButtonStack>
        </AuthLayout>
    </form>
</template>

<script
    lang="ts"
    setup>
    import { AuthService, CurrencyService, OrganizationService, TokenResponse } from '@fancee/api';
    import { AuthUser, CountryCode, ManageableOrganization, UserType } from '@fancee/data';
    import { reactive, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import type { RouteLocationRaw } from 'vue-router';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { useRequestErrorBoundary, useRoute, useRouter, useService, useValidationScope } from '@/composable';
    import { useAuthStore, usePlatformStore, useStore, useUiStore } from '@/data/store';
    import { email, required } from '@/data/validation';

    const {login: storeLogin, setAdminTokenResponse, setManagingOrganization, setUser} = useStore(useAuthStore());
    const {setOrganizationContract, setStandardCurrency} = useStore(usePlatformStore());
    const {allowedCountries, setCountry} = useStore(useUiStore());

    const {t} = useI18n();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const {login} = useService(AuthService);
    const {getPlatformStandard} = useService(CurrencyService);
    const {getContract} = useService(OrganizationService);
    const {invalid, validated} = useValidationScope(false);
    const route = useRoute();
    const router = useRouter();

    const state = reactive({
        email: '',
        password: ''
    });

    const isLoading = ref(false);

    async function onSignInClicked(): Promise<void> {
        resetErrors();
        isLoading.value = true;

        const {data} = await login(state.email, state.password)
            .finally(() => isLoading.value = false);

        isLoading.value = true;

        switch (data.user.type) {
            case UserType.Admin:
                await signInAdmin(data);
                break;

            case UserType.Client:
                await signInClient(data);
                break;

            case UserType.Organization:
                await signInOrganization(data);
                break;

            default:
                await signInDefault(data);
                break;
        }

        isLoading.value = false;
    }

    async function signInAdmin(response: TokenResponse): Promise<void> {
        const adminTokenResponse = new TokenResponse(response.claims, response.token, response.user, response.manageableOrganizations, response.validUntil);
        setAdminTokenResponse(adminTokenResponse);

        storeLogin(
            response.claims,
            response.token,
            response.user,
            response.manageableOrganizations,
            response.validUntil,
            adminTokenResponse
        );

        // todo: remove country restrictions once FAN-1631 is fixed.
        const whitelistedCountries: CountryCode[] = ['NL', 'BE', 'FR'];
        const countries = unref(allowedCountries).length === 0 ? whitelistedCountries : unref(allowedCountries).filter(c => whitelistedCountries.includes(c));
        setCountry(countries);

        const {data} = await getPlatformStandard();
        setStandardCurrency(data);

        await continueToDashboard({name: 'home'});
    }

    async function signInClient(response: TokenResponse): Promise<void> {
        storeLogin(
            response.claims,
            response.token,
            response.user,
            response.manageableOrganizations,
            response.validUntil,
            null
        );

        if (response.manageableOrganizations.length > 0) {
            await continueToDashboard({name: 'auth-select'});
        } else {
            await continueToDashboard({name: 'client-home'});
        }
    }

    async function signInDefault(response: TokenResponse): Promise<void> {
        storeLogin(
            response.claims,
            response.token,
            response.user,
            response.manageableOrganizations,
            response.validUntil,
            null
        );

        await continueToDashboard({name: 'home'});
    }

    async function signInOrganization(response: TokenResponse): Promise<void> {
        storeLogin(
            response.claims,
            response.token,
            response.user,
            response.manageableOrganizations,
            response.validUntil,
            null
        );

        if (response.manageableOrganizations.length === 1) {
            await signInOrganizationContinueAs(response, response.manageableOrganizations[0]);
        } else {
            await continueToDashboard({name: 'auth-select'});
        }
    }

    async function signInOrganizationContinueAs(response: TokenResponse, organization: ManageableOrganization): Promise<void> {
        setManagingOrganization(organization.id, organization.claims);

        if (!response.user.isProfileComplete) {
            await continueToDashboard({name: 'onboarding'});
            return;
        }

        const {data: contract} = await getContract(organization.id);
        await setOrganizationContract(contract);

        if (!contract.signed) {
            await continueToDashboard({name: 'onboarding'});
        } else {
            await router.push({name: 'home'});
        }
    }

    async function continueToDashboard(to: RouteLocationRaw): Promise<void> {
        if ('to' in route.query) {
            await router.push(route.query.to as string);
        } else {
            await router.push(to);
        }
    }
</script>
