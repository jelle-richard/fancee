<template>
    <AuthLayout
        :title="t('auth.register.title')"
        :description="t('auth.register.description')">
        <CombinedFormNotice/>

        <FluxButtonStack
            axis="vertical"
            is-fill>
            <FeatureButton
                icon="user"
                :title="t('auth.register.clientTitle')"
                :description="t('auth.register.clientDescription')"
                :to="{name: 'auth-register-type', params: {type: 'client'}}"
                type="route"/>

            <FeatureButton
                icon="shopping-bag"
                :title="t('auth.register.organizationTitle')"
                :description="t('auth.register.organizationDescription')"
                :to="{name: 'auth-register-type', params: {type: 'organization'}}"
                type="route"/>
        </FluxButtonStack>

        <FluxSecondaryButton
            :label="t('global.back')"
            :to="{name: 'auth-login'}"
            type="route"/>
    </AuthLayout>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { FeatureButton } from '@/components/ui';

    const {t} = useI18n();
</script>
