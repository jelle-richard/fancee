<template>
    <form @submit.prevent>
        <AuthLayout
            :title="t('auth.forgotPassword.title')"
            :description="t('auth.forgotPassword.description')"
            :is-loading="isLoading">
            <CombinedFormNotice/>

            <FluxNotice
                v-if="isRequested"
                icon="circle-check"
                is-small
                :message="t('auth.forgotPassword.feedback')"
                variant="success"/>

            <FluxFormColumn>
                <ValidationField
                    :label="t('form.field.email')"
                    :rules="{required, email}"
                    :value="state.email">
                    <FluxFormInput
                        v-model="state.email"
                        auto-focus
                        data-testid="forgot-password-email"
                        type="email"/>
                </ValidationField>
            </FluxFormColumn>

            <FluxButtonStack
                axis="vertical"
                is-fill>
                <FluxPrimaryButton
                    data-testid="forgot-password-reset"
                    :disabled="invalid"
                    icon-after="circle-arrow-right"
                    :is-loading="isLoading"
                    is-submit
                    :label="t('global.continue')"
                    @click="validated(onResetPasswordClicked)"/>

                <FluxSeparator/>

                <FluxSecondaryButton
                    data-testid="forgot-password-back-to-login"
                    :label="t('global.back')"
                    :to="{name: 'auth-login'}"
                    type="route"/>
            </FluxButtonStack>
        </AuthLayout>
    </form>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { reactive, ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRequestErrorBoundary, useService, useValidationScope } from '@/composable';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { email, required } from '@/data/validation';

    const {t} = useI18n();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const {forgotPassword} = useService(UserService);
    const {invalid, validated} = useValidationScope(false);

    const isLoading = ref(false);
    const isRequested = ref(false);

    const state = reactive({
        email: ''
    });

    async function onResetPasswordClicked(): Promise<void> {
        isLoading.value = true;

        resetErrors();

        await forgotPassword(state.email)
            .finally(() => isLoading.value = false);

        isRequested.value = true;
    }
</script>
