<template>
    <AuthLayout
        :title="t('auth.select.title', {name: user?.firstName})"
        :description="t('auth.select.description')"
        :is-loading="isLoading">
        <CombinedFormNotice/>

        <FluxButtonStack axis="vertical">
            <template v-for="organization of organizations">
                <FluxSecondaryButton
                    :class="$style.organization"
                    icon-after="angle-right"
                    @click="continueAs(organization)"
                    #before>
                    <FluxAvatar
                        fallback-icon="user"
                        :size="42"
                        :url="organization.avatar?.url"/>

                    <span>{{ organization.name }}</span>

                    <FluxIcon
                        v-if="organization.isOwner"
                        :size="16"
                        :class="$style.isOwner"
                        variant="star"/>
                </FluxSecondaryButton>
            </template>
        </FluxButtonStack>

        <FluxSecondaryButton
            v-if="user?.type === UserType.Client"
            :label="t('auth.useClient')"
            @click="onUseClientClicked()"/>

        <FluxSecondaryButton
            data-testid="auth-select-organization-logout"
            :label="t('auth.logout')"
            @click="onLogoutClicked()"/>
    </AuthLayout>
</template>

<script
    lang="ts"
    setup>
    import { OrganizationService } from '@fancee/api';
    import { ManageableOrganization, UserType } from '@fancee/data';
    import { computed, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { useRouter, useService } from '@/composable';
    import { useAuthStore, usePlatformStore, useStore } from '@/data/store';
    import { handleUserLogout } from '@/util';

    const {manageableOrganizations, user, setManagingOrganization} = useStore(useAuthStore());
    const {setOrganizationContract} = useStore(usePlatformStore());

    const {t} = useI18n();
    const {getContract} = useService(OrganizationService);
    const router = useRouter();

    const isLoading = ref(false);

    const organizations = computed(() => unref(manageableOrganizations)?.toSorted((a, b) => a.isOwner ? -1 : (b.isOwner ? 1 : 0)));

    async function continueAs(organization: ManageableOrganization): Promise<void> {
        isLoading.value = true;

        try {
            setManagingOrganization(organization.id, organization.claims);

            const {data: contract} = await getContract(organization.id);
            await setOrganizationContract(contract);

            if (!contract.signed) {
                await router.push({name: 'onboarding'});
            } else {
                await router.push({name: 'organization-home'});
            }
        } catch (err) {
            isLoading.value = false;
            throw err;
        }
    }

    async function onLogoutClicked(): Promise<void> {
        await handleUserLogout(router);
    }

    async function onUseClientClicked(): Promise<void> {
        await router.push({name: 'client-home'});
    }
</script>

<style module>
    .organization {
        height: unset;
        padding: 15px 21px 15px 15px;
        gap: 15px;
        justify-content: flex-start;

        :is(span) {
            flex-grow: 1;
            font-size: 16px;
            text-align: left;
        }
    }

    .isOwner {
        color: rgb(var(--warning-7));
    }
</style>
