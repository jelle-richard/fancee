<template>
    <form @submit.prevent>
        <AuthLayout
            :title="t('auth.register.client.title')"
            :description="t('auth.register.client.description')"
            :is-loading="isLoading">
            <CombinedFormNotice/>

            <template v-if="isRegisterComplete">
                <FluxNotice
                    icon="circle-check"
                    is-small
                    :message="t('auth.register.complete')"
                    variant="success"/>

                <FluxPrimaryButton
                    data-testid="register-login"
                    icon-after="circle-arrow-right"
                    :label="t('auth.login.title')"
                    size="large"
                    :to="{name: 'auth-login'}"
                    type="route"/>
            </template>

            <template v-else>
                <FluxFormColumn>
                    <ValidationField
                        :label="t('form.field.password')"
                        :rules="{required, minLength: minLength(6)}"
                        :value="state.password">
                        <FluxFormInput
                            v-model="state.password"
                            auto-complete="new-password"
                            data-testid="register-password"
                            type="password"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('form.field.passwordConfirm')"
                        :rules="{required, sameAs: sameAs(state.password)}"
                        :value="state.passwordConfirm">
                        <FluxFormInput
                            v-model="state.passwordConfirm"
                            auto-complete="new-password"
                            data-testid="register-repeat-password"
                            type="password"/>
                    </ValidationField>
                </FluxFormColumn>

                <FluxDivider/>

                <FluxButtonStack
                    axis="vertical"
                    is-fill>
                    <FluxPrimaryButton
                        data-testid="register-submit"
                        :disabled="invalid"
                        icon-before="circle-check"
                        is-submit
                        :label="t('auth.register.submit')"
                        size="large"
                        @click="validated(onRegisterClicked)"/>

                    <FluxSecondaryButton
                        data-testid="register-cancel"
                        :label="t('global.cancel')"
                        :to="{name: 'auth-register'}"
                        type="route"/>
                </FluxButtonStack>
            </template>
        </AuthLayout>
    </form>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { onMounted, reactive, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { AuthLayout } from '@/components/layout';
    import { useRequestErrorBoundary, useRouteParam, useRouter, useService, useValidationScope } from '@/composable';
    import { minLength, required, sameAs } from '@/data/validation';

    const {t} = useI18n();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const {createAccount, verified} = useService(UserService);
    const {invalid, validated} = useValidationScope(false);
    const router = useRouter();

    const verifyId = useRouteParam('code');

    const state = reactive({
        password: '',
        passwordConfirm: ''
    });

    const isLoading = ref(false);
    const isRegisterComplete = ref(false);

    onMounted(async () => {
        const id = unref(verifyId);

        // note(Bas): checks if the verify id exists, if something fails we assume that it doesn't.
        if (id && await verified(id).catch(() => false)) {
            return;
        }

        await router.push({
            name: 'auth-login'
        });
    });

    async function onRegisterClicked(): Promise<void> {
        resetErrors();

        isLoading.value = true;

        try {
            await createAccount(unref(verifyId)!, state.password);

            isRegisterComplete.value = true;
        } finally {
            isLoading.value = false;
        }
    }
</script>
