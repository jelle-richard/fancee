import { DateTimeAdapter } from '@fancee/data';
import { DateTime } from 'luxon';

export default function (date?: DateTime | string | null): string {
    date ??= DateTimeAdapter.now();

    if (typeof date === 'string') {
        date = DateTimeAdapter.parseDateTimeStringToLocal(date);
    }

    return date.toLocaleString(DateTime.DATE_FULL);
}
