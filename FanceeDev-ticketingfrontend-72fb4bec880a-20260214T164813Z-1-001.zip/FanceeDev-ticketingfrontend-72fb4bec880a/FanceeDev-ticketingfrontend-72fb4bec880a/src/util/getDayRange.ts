import { DateTimeAdapter } from '@fancee/data';
import type { DateTime } from 'luxon';

export default function getDayRange(dateTime?: DateTime): [DateTime, DateTime] {
    dateTime ??= DateTimeAdapter.now();

    return [
        dateTime.startOf('day'),
        dateTime.endOf('day')
    ];
}
