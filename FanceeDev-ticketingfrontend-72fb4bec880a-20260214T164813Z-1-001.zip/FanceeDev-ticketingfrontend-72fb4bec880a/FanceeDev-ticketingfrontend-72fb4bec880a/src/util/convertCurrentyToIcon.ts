import { Currency } from '@fancee/data';
import { IconNames } from '@fancee/flux';

export default function (currency: Currency): IconNames {
    switch (currency.shortCode) {
        case 'EUR':
            return 'euro-sign';

        case 'GBP':
            return 'sterling-sign';

        case 'USD':
            return 'dollar-sign';

        default:
            return 'flux-empty';
    }
}
