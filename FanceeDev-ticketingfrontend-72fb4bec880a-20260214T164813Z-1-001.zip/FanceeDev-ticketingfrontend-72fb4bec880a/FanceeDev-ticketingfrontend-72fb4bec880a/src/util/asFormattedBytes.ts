export default function (bytes: number, si: boolean = true, decimals: number = 1): string {
    const treshold = si ? 1000 : 1024;

    if (Math.abs(bytes) < treshold) {
        return `${bytes} B`;
    }

    const units = si
        ? ['kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
        : ['KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'];
    let unitIndex = -1;
    const power = 10 ** decimals;

    do {
        bytes /= treshold;
        ++unitIndex;
    } while (Math.round(Math.abs(bytes) * power) / power >= treshold && unitIndex < units.length - 1);

    return `${new Intl.NumberFormat([], {minimumFractionDigits: 0, maximumFractionDigits: decimals}).format(bytes)} ${units[unitIndex]}`;
}
