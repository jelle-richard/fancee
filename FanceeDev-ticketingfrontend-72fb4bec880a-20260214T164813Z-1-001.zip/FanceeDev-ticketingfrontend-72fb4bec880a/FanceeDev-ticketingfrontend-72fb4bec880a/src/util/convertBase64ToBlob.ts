export default function (base64: string, type: string): Blob {
    const bytes = atob(base64);
    const byteArrays: Uint8Array[] = [];

    for (let offset = 0; offset < bytes.length; offset += 512) {
        const slice = bytes.slice(offset, offset + 512);
        const byteNumbers = new Array<number>(512);

        for (let i = 0; i < 512; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }

        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }

    return new Blob(byteArrays, {type});
}
