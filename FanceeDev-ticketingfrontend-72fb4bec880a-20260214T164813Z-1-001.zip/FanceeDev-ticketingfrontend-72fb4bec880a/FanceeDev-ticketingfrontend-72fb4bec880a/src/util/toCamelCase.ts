import lowerFirst from 'lodash/lowerFirst';
import toPascalCase from './toPascalCase';

export default function (str: string): string {
    return lowerFirst(toPascalCase(str));
}
