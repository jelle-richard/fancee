import type { DateTime } from 'luxon';

export default function (dateTime: DateTime, compareTo: DateTime): boolean {
    return dateTime <= compareTo;
}
