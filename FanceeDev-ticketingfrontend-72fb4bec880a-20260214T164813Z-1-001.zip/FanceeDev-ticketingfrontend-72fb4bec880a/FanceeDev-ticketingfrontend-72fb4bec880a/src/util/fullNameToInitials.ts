export default function (fullName: string): string {
    if (fullName.length === 0) {
        return '';
    }

    const parts = fullName.split(' ');

    if (parts.length === 0) {
        return parts[0][0];
    }

    return parts[0][0] + parts[parts.length - 1][0];
}
