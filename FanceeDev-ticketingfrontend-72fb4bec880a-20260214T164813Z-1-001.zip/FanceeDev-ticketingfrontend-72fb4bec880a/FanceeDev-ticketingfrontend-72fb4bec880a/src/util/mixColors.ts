import hexToRGB from './hexToRGB';
import rgbToHex from './rgbToHex';

export default function (fromHex: string, toHex: string, percentage: number = .5): string {
    const from = hexToRGB(fromHex);
    const to = hexToRGB(toHex);

    const r = (from[0] - to[0]) * percentage;
    const g = (from[1] - to[1]) * percentage;
    const b = (from[2] - to[2]) * percentage;

    return rgbToHex(r, g, b);
}
