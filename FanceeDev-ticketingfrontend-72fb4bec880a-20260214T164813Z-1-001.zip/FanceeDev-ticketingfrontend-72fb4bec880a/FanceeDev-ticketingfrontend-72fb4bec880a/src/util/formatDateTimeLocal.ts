import { DateTimeAdapter } from '@fancee/data';
import { DateTime } from 'luxon';

export default function (dateTime?: DateTime | string | null): string {
    dateTime ??= DateTimeAdapter.now();

    if (typeof dateTime === 'string') {
        dateTime = DateTimeAdapter.parseDateTimeStringToLocal(dateTime);
    }

    return dateTime.toLocaleString(DateTime.DATETIME_MED);
}
