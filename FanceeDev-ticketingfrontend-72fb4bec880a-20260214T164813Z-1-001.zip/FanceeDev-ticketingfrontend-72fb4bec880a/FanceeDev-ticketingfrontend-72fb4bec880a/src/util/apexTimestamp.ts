import { DateTime } from 'luxon';

export default function apexTimestamp(datetime: number | string | DateTime): number {
    return DateTime.fromISO(datetime.toString()).set({hour: 12, minute: 0, second: 0, millisecond: 0}).toMillis();
}
