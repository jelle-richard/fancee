export default async function (ms: number): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, ms));
}
