import type { DateTime } from 'luxon';

export default function (other: DateTime): number {
    return other.diffNow().as('days');
}
