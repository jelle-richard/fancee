import { Component, h, render } from 'vue';

export default function<C extends Component<P>, P extends {}>(component: C, props: P): string {
    let elm: HTMLElement | undefined = document.createElement('div');

    render(h(component, props), elm);

    const html = elm.innerHTML;
    elm = undefined;

    return html;
}
