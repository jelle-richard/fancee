export default function (r: number, g: number, b: number): string {
    return '#'
        .concat(r.toString(16).padStart(2, '0'))
        .concat(g.toString(16).padStart(2, '0'))
        .concat(b.toString(16).padStart(2, '0'));
}
