import type { Currency } from '@fancee/data';

export default function (cents: number, currency: Currency): string {
    return new Intl.NumberFormat(navigator.language, {
        currency: currency.shortCode,
        style: 'currency'
    }).format(cents / Math.pow(10, currency.decimals));
}
