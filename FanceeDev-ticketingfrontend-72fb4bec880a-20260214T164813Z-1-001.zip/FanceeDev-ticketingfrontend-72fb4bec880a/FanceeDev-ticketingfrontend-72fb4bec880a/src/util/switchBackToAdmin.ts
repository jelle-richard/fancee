import type { AuthUser } from '@fancee/data';
import type { Router } from 'vue-router';
import { useAuthStore } from '@/data/store';

export default async function (router: Router, user: AuthUser): Promise<void> {
    const {adminTokenResponse, login} = useAuthStore();

    if (adminTokenResponse === null) {
        return;
    }

    login(
        adminTokenResponse.claims,
        adminTokenResponse.token,
        adminTokenResponse.user,
        adminTokenResponse.manageableOrganizations,
        adminTokenResponse.validUntil,
        adminTokenResponse
    );

    await router.push({
        name: 'organization',
        params: {
            id: user.activeOrganizationId!
        }
    });
}
