import { UserType } from '@fancee/data';
import type { Router } from 'vue-router';
import { useAuthStore, usePlatformStore } from '@/data/store';
import switchBackToAdmin from './switchBackToAdmin';

export default async function (router: Router, isTimedOut: boolean = false): Promise<void> {
    const {logout, user, adminTokenResponse} = useAuthStore();
    const {setOrganizationContract, setStandardCurrency} = usePlatformStore();

    let route: object = {
        name: 'auth-login'
    };

    if (adminTokenResponse !== null && user?.type !== UserType.Admin) {
        await switchBackToAdmin(router, user!);
        return;
    }

    if (isTimedOut) {
        route['query'] = {
            timedOut: true
        };
    }

    logout();

    await router.push(route);
    await setOrganizationContract(null);
    setStandardCurrency(null);
}
