export default function <T>(...args: T[]): T {
    let target = {};
    let merger = (obj) => {
        for (let prop in obj) {
            if (obj.hasOwnProperty(prop)) {
                target[prop] = obj[prop];
            }
        }
    };
    for (let arg of args) {
        merger(arg);
    }
    return target as T;
}
