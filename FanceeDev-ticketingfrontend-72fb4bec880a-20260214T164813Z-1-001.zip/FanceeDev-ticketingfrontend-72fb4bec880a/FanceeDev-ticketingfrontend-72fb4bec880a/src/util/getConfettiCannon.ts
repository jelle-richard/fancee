import { markRaw } from 'vue';
import hexToRGB from './hexToRGB';
import randomInteger from './randomInteger';

class ConfettiCannon {
    get height(): number {
        return this.#canvas.height;
    }

    get width(): number {
        return this.#canvas.width;
    }

    readonly #canvas: HTMLCanvasElement;
    readonly #context: CanvasRenderingContext2D;
    readonly #options: ConfettiOptions;
    #frame: number = 0;
    #isAnimating: boolean = false;
    #particles: ConfettiParticle[] = [];

    constructor(canvas: HTMLCanvasElement, options: Partial<ConfettiOptions> = {}) {
        this.#canvas = canvas;
        this.#context = canvas.getContext('2d')!;
        this.#options = Object.assign({}, DEFAULT_OPTIONS, options);
    }

    option<TKey extends keyof ConfettiOptions>(key: TKey, options?: ConfettiOptions): ConfettiOptions[TKey] {
        options ??= this.#options;

        const value = options[key];

        if (value === undefined || value === null) {
            return DEFAULT_OPTIONS[key];
        }

        return value;
    }

    fire(options: Partial<ConfettiOptions> = {}): void {
        const combinedOptions: ConfettiOptions = Object.assign({}, this.#options, options);

        this.resize();

        const angle = this.option('angle', combinedOptions);
        const colors = this.option('colors', combinedOptions);
        const decay = this.option('decay', combinedOptions);
        const gravity = this.option('gravity', combinedOptions);
        const particleCount = Math.floor(this.option('particles', combinedOptions));
        const shapes = this.option('shapes', combinedOptions);
        const spread = this.option('spread', combinedOptions);
        const ticks = this.option('ticks', combinedOptions);
        const startVelocity = this.option('startVelocity', combinedOptions);
        const x = this.width * this.option('x', combinedOptions);
        const y = this.height * this.option('y', combinedOptions);

        const particles: ConfettiParticle[] = [];
        let counter = particleCount;

        while (counter--) {
            particles.push(new ConfettiParticle(
                this.option('xRandom', combinedOptions) ? this.width * Math.random() : x,
                this.option('yRandom', combinedOptions) ? this.height * Math.random() : y,
                angle,
                colors[counter % colors.length],
                decay,
                gravity,
                shapes[randomInteger(0, shapes.length)],
                spread,
                ticks,
                startVelocity
            ));
        }

        this.#particles = this.#particles
            .concat(particles)
            .sort((a, b) => a.id === b.id ? -1 : a.opacity - b.opacity);

        if (!this.#isAnimating) {
            this.start();
        }
    }

    resize(): void {
        const {height, width} = this.#canvas.getBoundingClientRect();
        this.#canvas.height = height;
        this.#canvas.width = width;
    }

    start(): void {
        this.#isAnimating = true;
        requestAnimationFrame(() => this.update());
    }

    stop(): void {
        this.#isAnimating = false;
    }

    draw(): void {
        this.#context.clearRect(0, 0, this.width, this.height);

        let lastId: string | null = null;

        for (const particle of this.#particles) {
            if (lastId !== particle.id) {
                lastId = particle.id;
                particle.updateFillStyle(this.#context);
            }

            particle.draw(this.#context);
        }
    }

    tick(): void {
        this.#particles = this.#particles.filter(particle => particle.tick());
    }

    update(): void {
        if (!this.#isAnimating) {
            return;
        }

        ++this.#frame;

        this.tick();
        this.draw();

        if (this.#particles.length > 0) {
            this.start();
        } else {
            this.stop();
        }
    }
}

class ConfettiParticle {
    get id(): string {
        return `${this.#color.join('-')}|${this.opacity}`;
    }

    get opacity(): number {
        return Math.round(this.progress / 0.1) * 0.1;
    }

    get progress(): number {
        return this.#tick / this.#ticks;
    }

    readonly #angle2D: number;
    readonly #color: [number, number, number];
    readonly #decay: number;
    readonly #gravity: number;
    readonly #shape: ConfettiShape;
    readonly #ticks: number;
    #ovalScalar: number = 0.6;
    #random: number = Math.random() + 5;
    #tick: number = 0;
    #tiltAngle: number = Math.random() * Math.PI;
    #tiltCos: number = 0;
    #tiltSin: number = 0;
    #velocity: number;
    #wobble: number = Math.random() * 10;
    #wobbleX: number = 0;
    #wobbleY: number = 0;
    #x: number;
    #y: number;

    constructor(x: number, y: number, angle: number, color: string, decay: number, gravity: number, shape: ConfettiShape, spread: number, ticks: number, velocity: number) {
        const radAngle = angle * Math.PI / 180;
        const radSpread = spread * Math.PI / 180;

        this.#angle2D = -radAngle + 0.5 * radSpread - Math.random() * radSpread;
        this.#color = hexToRGB(color);
        this.#decay = decay;
        this.#gravity = gravity * 3;
        this.#shape = shape;
        this.#ticks = ticks;
        this.#velocity = velocity * 0.5 + Math.random() * velocity;
        this.#x = x;
        this.#y = y;
    }

    draw(ctx: CanvasRenderingContext2D): void {
        const x1 = this.#x + this.#random * this.#tiltCos;
        const y1 = this.#y + this.#random * this.#tiltSin;
        const x2 = this.#wobbleX + this.#random * this.#tiltCos;
        const y2 = this.#wobbleY + this.#random * this.#tiltSin;

        ctx.beginPath();

        switch (this.#shape) {
            case 'circle':
                this.drawCircle(ctx, [x1, y1, x2, y2]);
                break;

            case 'square':
                this.drawSquare(ctx, [x1, y1, x2, y2]);
                break;

            case 'star':
                this.drawStar(ctx);
                break;
        }

        ctx.fill();
        ctx.closePath();
    }

    drawCircle(ctx: CanvasRenderingContext2D, [x1, y1, x2, y2]: [number, number, number, number]): void {
        ctx.ellipse(this.#x, this.#y, Math.abs(x2 - x1) * this.#ovalScalar, Math.abs(y2 - y1) * this.#ovalScalar, Math.PI / 10 * this.#wobble, 0, 2 * Math.PI);
    }

    drawSquare(ctx: CanvasRenderingContext2D, [x1, y1, x2, y2]: [number, number, number, number]): void {
        ctx.moveTo(Math.floor(this.#x), Math.floor(this.#y));
        ctx.lineTo(Math.floor(this.#wobbleX), Math.floor(y1));
        ctx.lineTo(Math.floor(x2), Math.floor(y2));
        ctx.lineTo(Math.floor(x1), Math.floor(this.#wobbleY));
    }

    drawStar(ctx: CanvasRenderingContext2D): void {
        let alpha = (2 * Math.PI) / 10;
        let points = 6;

        ctx.save();
        ctx.translate(this.#x, this.#y);
        ctx.rotate(this.#tiltAngle);
        ctx.scale(Math.cos(this.#tiltAngle), 1);

        for (let i = 11; i > 0; i--) {
            let r = points * (i % 2 + 1) / 2;
            let omega = alpha * i;
            ctx.lineTo((r * Math.sin(omega)), (r * Math.cos(omega)));
        }

        ctx.restore();
    }

    tick(): boolean {
        ++this.#tick;
        this.#x += Math.cos(this.#angle2D) * this.#velocity;
        this.#y += Math.sin(this.#angle2D) * this.#velocity + this.#gravity;
        this.#velocity *= this.#decay;
        this.#tiltAngle += 0.1;
        this.#tiltCos = Math.cos(this.#tiltAngle);
        this.#tiltSin = Math.sin(this.#tiltAngle);
        this.#random = Math.random() + 5;
        this.#wobble += 0.1;
        this.#wobbleX = this.#x + 10 * Math.cos(this.#wobble);
        this.#wobbleY = this.#y + 10 * Math.sin(this.#wobble);

        return this.#tick < this.#ticks;
    }

    updateFillStyle(ctx: CanvasRenderingContext2D): void {
        ctx.fillStyle = `rgb(${this.#color[0]} ${this.#color[1]} ${this.#color[2]} / ${1 - this.opacity})`;
    }
}

export default function (canvas: HTMLCanvasElement, options: Partial<ConfettiOptions> = {}): ConfettiCannon {
    return markRaw(new ConfettiCannon(canvas, options));
}

const DEFAULT_OPTIONS: ConfettiOptions = {
    angle: 90,
    colors: [
        '#26ccff',
        '#a25afd',
        '#ff5e7e',
        '#88ff5a',
        '#fcff42',
        '#ffa62d',
        '#ff36ff'
    ],
    decay: 0.9,
    gravity: 1,
    particles: 50,
    shapes: ['circle', 'square', 'star'],
    spread: 55,
    ticks: 200,
    startVelocity: 45,
    x: 0.5,
    xRandom: false,
    y: 2,
    yRandom: false,
    z: 100
};

interface ConfettiOptions {
    angle: number;
    colors: string[];
    decay: number;
    gravity: number;
    particles: number;
    shapes: ConfettiShape[];
    spread: number;
    ticks: number;
    startVelocity: number;
    x: number;
    xRandom: boolean;
    y: number;
    yRandom: boolean;
    z: number;
}

type ConfettiShape = 'circle' | 'square' | 'star';
