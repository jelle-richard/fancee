import type { Currency } from '@fancee/data';

export default function (decimal: number, currency: Currency): number {
    return Math.floor(decimal * Math.pow(10, currency.decimals));
}
