import { DateTimeAdapter } from '@fancee/data';
import type { DateTime } from 'luxon';
import isDateTimeBefore from './isDateTimeBefore';

export default function (dateTime: DateTime): boolean {
    return isDateTimeBefore(dateTime, DateTimeAdapter.now());
}
