import { Duration, DurationObjectUnits } from 'luxon';

export default function (object: DurationObjectUnits, format: string): string {
    return Duration.fromObject(object).toFormat(format);
}
