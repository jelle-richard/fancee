import { BaseResponse } from '@fancee/client';
import { SelectOption } from '@fancee/data';
import { FluxFilterOptionRow, FluxFormSelectEntry } from '@fancee/flux';

type Entry = FluxFilterOptionRow & FluxFormSelectEntry;

export default function <T extends (...args: any[]) => Promise<BaseResponse<SelectOption[]>>>(fn: T): () => Promise<Entry[]> {
    return (async (...args: any[]) => {
        const {data} = await fn(...args);
        const options: Entry[] = [];
        let lastHeader: string | null = null;

        data
            .toSorted((a, b) => {
                if (a.header === b.header) {
                    return a.label.localeCompare(b.label);
                }

                if (!a.header) {
                    return -1;
                }

                if (!b.header) {
                    return 1;
                }

                return a.header.localeCompare(b.header);
            })
            .forEach(option => {
                if (lastHeader !== option.header) {
                    option.header && options.push({
                        icon: null,
                        label: option.header,
                        title: option.header
                    });

                    lastHeader = option.header;
                }

                options.push({
                    command: option.note ?? undefined,
                    id: option.id,
                    label: option.label,
                    value: option.id
                });
            });

        return options;
    });
}
