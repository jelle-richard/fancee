const formatter = new Intl.NumberFormat(navigator.language, {
    maximumFractionDigits: 1,
    minimumFractionDigits: 0
});

export default function (num: number): string {
    let abs = Math.abs(num);

    if (abs < 10000) {
        return num.toString();
    }

    if (abs < 1000000) {
        return `${formatter.format(num / 1000)}K`;
    }

    return `${formatter.format(num / 1000000)}M`;
}
