export default function <T extends Function>(_: T): T {
    return (async () => {
        throw new Error('alwaysFail() triggered.');
    }) as unknown as T;
}
