import { DateTimeAdapter } from '@fancee/data';
import type { DateTime } from 'luxon';
import isDateTimeAfter from './isDateTimeAfter';

export default function (dateTime: DateTime): boolean {
    return isDateTimeAfter(dateTime, DateTimeAdapter.now());
}
