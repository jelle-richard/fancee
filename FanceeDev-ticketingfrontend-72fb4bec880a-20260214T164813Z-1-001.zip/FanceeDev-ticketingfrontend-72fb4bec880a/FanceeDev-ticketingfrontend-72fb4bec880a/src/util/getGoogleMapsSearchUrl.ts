import type { Address } from '@fancee/data';

export default function (address: Address): string {
    let addressStr = '';

    if (address.street !== null) {
        addressStr += ` ${address.street}`;
    }

    if (address.houseNumber !== null) {
        addressStr += ` ${address.houseNumber}`;
    }

    if (address.postalCode !== null) {
        addressStr += ` ${address.postalCode}`;
    }

    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addressStr)}`;
}
