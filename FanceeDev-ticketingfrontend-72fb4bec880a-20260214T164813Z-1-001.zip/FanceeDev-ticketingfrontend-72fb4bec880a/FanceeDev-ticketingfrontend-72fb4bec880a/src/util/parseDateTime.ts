import { DateTime } from 'luxon';

export default function (dateTimeStr: string): DateTime {
    return DateTime.fromSQL(dateTimeStr);
}
