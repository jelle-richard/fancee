export default function (str: string | null): string | null {
    if (!str || str.trim().length === 0) {
        return null;
    }

    return str;
}
