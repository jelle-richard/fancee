export default function apexChartsSharedTooltip({series, seriesIndex, dataPointIndex, w}) {
    const hoverXaxis = w.globals.seriesX[seriesIndex][dataPointIndex];
    const hoverIndexes = w.globals.seriesX.map((seriesX: any[]) => {
        return seriesX.findIndex((xData) => xData === hoverXaxis);
    });

    let hoverList = '';
    hoverIndexes.forEach((hoverIndex: number, seriesEachIndex: number) => {
        hoverList += `
            <div class="apexcharts-tooltip-series-group apexcharts-active" style="order: 1; display: flex;">
                <span class="apexcharts-tooltip-marker" style="background-color: ${
            w.globals.markers.colors[seriesEachIndex]
        };"></span>
                <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                    <div class="apexcharts-tooltip-y-group">
                        <span class="apexcharts-tooltip-text-y-label">${w.globals.seriesNames[seriesEachIndex]}:</span>
                        <span class="apexcharts-tooltip-text-y-value">${w.globals.yLabelFormatters[0](series[seriesEachIndex][hoverIndex] ?? '-')}</span>
                    </div>
                </div>
            </div>`;
    });
    const parsed = new Date(hoverXaxis)
        .toDateString()
        .split(' ')
        .slice(1);

    return `<div class="apexcharts-tooltip-title" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">${parsed[1] + ' ' + parsed[0] + ' ' + parsed[2]}</div>${hoverList}`;
}
