import { DateTimeAdapter } from '@fancee/data';
import { DateTime } from 'luxon';

export default function (date?: DateTime | number | string | null, locale?: string): string {
    date ??= DateTimeAdapter.now();

    if (typeof date === 'number') {
        date = DateTimeAdapter.now().set({month: date});
    }

    if (typeof date === 'string') {
        date = DateTimeAdapter.parseDateTimeStringToLocal(date);
    }

    return date.toLocaleString({month: 'long'}, {locale});
}
