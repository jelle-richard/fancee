import upperFirst from 'lodash/upperFirst';

export default function (str: string): string {
    if (!str.includes(' ')) {
        return upperFirst(str);
    }

    return str
        .toLowerCase()
        .replace(new RegExp(/[-_]+/, 'g'), ' ')
        .replace(new RegExp(/[^\w\s]/, 'g'), '')
        .replace(new RegExp(/\s+(.)(\w*)/, 'g'), (_, $2, $3) => `${$2.toUpperCase() + $3}`)
        .replace(new RegExp(/\w/), s => s.toUpperCase());
}
