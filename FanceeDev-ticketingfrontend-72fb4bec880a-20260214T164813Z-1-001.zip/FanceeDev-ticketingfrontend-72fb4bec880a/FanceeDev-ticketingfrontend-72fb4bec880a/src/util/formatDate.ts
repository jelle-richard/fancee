import { DateTimeAdapter } from '@fancee/data';
import type { DateTime } from 'luxon';
import { LUXON_DATE_FORMAT } from '@/data';

export default function (dateTime?: DateTime): string {
    dateTime ??= DateTimeAdapter.now();
    return dateTime.toFormat(LUXON_DATE_FORMAT);
}
