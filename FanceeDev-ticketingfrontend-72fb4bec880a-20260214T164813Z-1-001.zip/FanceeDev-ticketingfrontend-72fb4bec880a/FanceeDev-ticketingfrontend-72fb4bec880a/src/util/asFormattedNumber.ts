const formatter = new Intl.NumberFormat(navigator.language, {
    maximumFractionDigits: 0,
    minimumFractionDigits: 0
});

export default function (num: number): string {
    return formatter.format(num);
}
