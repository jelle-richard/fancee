import { HttpStatusCode } from '@fancee/client';

export default function (statusCode: HttpStatusCode): string {
    if (statusCode === null) {
        return 'server_unreachable_error';
    }

    if (statusCode === HttpStatusCode.BadRequest) {
        return 'invalid_records_provided_error';
    }

    if (statusCode === HttpStatusCode.NotFound) {
        return 'no_records_found_error';
    }

    if (statusCode === HttpStatusCode.InternalServerError) {
        return 'internal_server_error';
    }

    if ([HttpStatusCode.BadGateway, HttpStatusCode.ServiceUnavailable, HttpStatusCode.GatewayTimeout].includes(statusCode)) {
        return 'overloaded_server_error';
    }

    return 'unknown_error_contact_support';
}
