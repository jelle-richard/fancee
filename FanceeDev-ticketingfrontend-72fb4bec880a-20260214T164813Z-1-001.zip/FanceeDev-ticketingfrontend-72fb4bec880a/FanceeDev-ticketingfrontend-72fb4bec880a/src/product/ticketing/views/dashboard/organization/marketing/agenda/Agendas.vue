<template>
    <FluxPane>
        <FluxActionBar>
            <template #primary>
                <Flux-primary-button
                    icon-before="circle-plus"
                    :label="t('marketing.agenda.singular')"
                    :to="{name: 'create-agenda'}"
                    type="route"/>
            </template>
        </FluxActionBar>

        <ShareOverlay v-slot="{share}">
            <FluxDataTable
                :data-set="agendas"
                :is-loading="isLoading"
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                is-hoverable>
                <template #header>
                    <FluxTableHeader>{{ t('form.field.name') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('event.plural') }}</FluxTableHeader>
                    <FluxTableHeader is-shrinking/>
                </template>

                <template #name="{row: {name}}">
                    <FluxTableCell>{{ name }}</FluxTableCell>
                </template>

                <template #eventName="{row: {linkedEvents, showAllActiveEvents}}">
                    <FluxTableCell
                        class="table-cell-shops"
                        #content>
                        <div
                            v-if="!showAllActiveEvents"
                            class="event-shops">
                            <div
                                v-for="event in linkedEvents"
                                class="shop-link">
                                <b>{{ event.name }}</b> - {{ event.startDate.toFormat(LUXON_DATE_TIME_FORMAT) }}
                            </div>
                        </div>
                        <div
                            v-else
                            class="event-shops">{{ t('marketing.agenda.table.all') }}
                        </div>
                    </FluxTableCell>
                </template>

                <template #actions="{row: {id}}">
                    <FluxTableCell>
                        <FluxTableActions>
                            <FluxTooltip :content="t('global.edit')">
                                <FluxAction
                                    icon="pen"
                                    :to="{name: 'configure-agenda', params: {id: id}}"
                                    type="route"/>
                            </FluxTooltip>

                            <FluxTooltip :content="t('global.share')">
                                <FluxAction
                                    icon="share-from-square"
                                    @click="share(getShareUrl(id))"/>
                            </FluxTooltip>

                            <FluxTooltip :content="t('global.delete')">
                                <FluxAction
                                    destructive
                                    icon="trash"
                                    @click="removeAgenda(id)"/>
                            </FluxTooltip>
                        </FluxTableActions>
                    </FluxTableCell>
                </template>
            </FluxDataTable>
        </ShareOverlay>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { AgendaService } from '@fancee/api';
    import { AgendaListing } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ShareOverlay } from '@/components/ui';
    import { useActiveOrganizationId, usePagination, useService } from '@/composable';
    import { LUXON_DATE_TIME_FORMAT } from '@/data';
    import { guarded } from '@/util';

    const organizationId = useActiveOrganizationId();
    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const {list, delete: deleteAgenda} = useService(AgendaService);
    const {t} = useI18n();

    const _deleteAgenda = guarded(deleteAgenda, t('ui.somethingWentWrong.title'), t('marketing.agenda.deleteFailed'));
    const _list = guarded(list, t('ui.somethingWentWrong.title'), t('marketing.agenda.loadingFailed'));

    const agendas = ref<AgendaListing[]>([]);
    const isLoading = ref(false);
    const isRemoving = ref(false);
    const initialLoadSucceeded = ref(false);

    async function removeAgenda(id: string): Promise<void> {
        isRemoving.value = true;

        try {
            await _deleteAgenda(unref(organizationId), id);

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('marketing.agenda.deleteSuccessful')
            });

            await listAgendas();
        } finally {
            isRemoving.value = false;
        }
    }

    async function listAgendas(): Promise<void> {
        isLoading.value = true;

        try {
            const {data: {items, totalItems}} = await _list(unref(organizationId), unref(pageLength), unref(currentPage));

            agendas.value = items;
            setTotalItems(totalItems);
            initialLoadSucceeded.value = true;
        } finally {
            isLoading.value = false;
        }
    }

    function getShareUrl(code: string): string {
        return `${import.meta.env.VITE_BASE_URL}/shop/agenda/${code}`;
    }

    watch([currentPage, pageLength], () => {
        listAgendas();
    }, {immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .event-shops {
        display: flex;
        height: 100%;
        padding: 12px 15px;
        align-items: flex-start;
        flex-flow: column;
        justify-content: center;
        gap: 3px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;

        &.small {
            font-size: 80%;
        }
    }

    .shop-link {
        display: flex;
        height: 20px;
        max-width: 100%;
        align-items: center;
        gap: 9px;

        a,
        span {
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }
</style>
