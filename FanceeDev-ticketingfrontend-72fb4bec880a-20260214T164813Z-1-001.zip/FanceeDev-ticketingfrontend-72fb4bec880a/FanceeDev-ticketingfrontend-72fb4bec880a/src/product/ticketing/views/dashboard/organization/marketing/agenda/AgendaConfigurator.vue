<template>
    <FluxGrid>
        <FluxGridColumn :md="6">
            <FluxStack>
                <FluxPane :is-loading="isLoading">
                    <FluxPaneHeader :title="agendaId === null ? t('marketing.agenda.configure.title.create') : t('marketing.agenda.configure.title.edit')"/>

                    <FluxPaneBody>
                        <FluxFormColumn>
                            <ValidationField
                                :label="t('form.field.name')"
                                :rules="{required, maxLength: maxLength(50)}"
                                :value="agenda.name">
                                <FluxFormInput v-model="agenda.name"/>
                            </ValidationField>

                            <FluxFormField :label="t('marketing.agenda.configure.allEvents')">
                                <FluxToggle v-model="agenda.showAllEvents"/>
                            </FluxFormField>

                            <ValidationField
                                v-if="!agenda.showAllEvents"
                                :label="t('event.plural')"
                                :rules="{required}"
                                :value="agenda.events">
                                <FluxFormSelectAsync
                                    v-model="agenda.events"
                                    is-multiple
                                    :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                                    :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                                    :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>
                            </ValidationField>
                        </FluxFormColumn>
                    </FluxPaneBody>

                    <FluxPaneBody>
                        <FluxFormColumn>
                            <FluxFormField :label="t('global.active')">
                                <FluxToggle v-model="agenda.active"/>
                            </FluxFormField>

                            <FluxDivider/>

                            <FluxFormField :label="t('marketing.agenda.configure.showHeaders')">
                                <FluxToggle v-model="agenda.design.showHeaders"/>
                            </FluxFormField>

                            <FluxFormRow>
                                <ShopColorField
                                    v-model="agenda.design.primaryColor"
                                    :default-color="BRAND_PRIMARY_COLOR"
                                    :label="t('settings.defaultShopPalette.primary')"/>

                                <ShopColorField
                                    v-model="agenda.design.textColor"
                                    :default-color="BRAND_TEXT_COLOR"
                                    :label="t('settings.defaultShopPalette.text')"/>
                            </FluxFormRow>

                            <FluxFormRow>
                                <ShopColorField
                                    v-model="agenda.design.backdropColor"
                                    :default-color="BRAND_BACKDROP_COLOR"
                                    :label="t('settings.defaultShopPalette.panel')"/>

                                <ShopColorField
                                    v-model="agenda.design.backgroundColor"
                                    :default-color="BRAND_BACKGROUND_COLOR"
                                    :label="t('settings.defaultShopPalette.background')"/>
                            </FluxFormRow>
                        </FluxFormColumn>
                    </FluxPaneBody>

                    <FluxPaneFooter>
                        <FluxSpacer/>
                        <FluxPrimaryButton
                            :disabled="invalid"
                            icon-before="circle-check"
                            :label="t('global.save')"
                            :is-loading="isSaving"
                            @click="saveAgenda"/>
                    </FluxPaneFooter>
                </FluxPane>
            </FluxStack>
        </FluxGridColumn>

        <FluxGridColumn :md="6">
            <AgendaPreview :agenda="agenda"/>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    setup
    lang="ts">
    import { AgendaService, SelectService } from '@fancee/api';
    import { Agenda, BRAND_BACKDROP_COLOR, BRAND_BACKGROUND_COLOR, BRAND_PRIMARY_COLOR, BRAND_TEXT_COLOR } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { onMounted, ref, unref, watch } from 'vue';
    import { useActiveOrganizationId, useRouteParam, useRouter, useService, useValidationScope } from '@/composable';
    import { fetchSelect, guarded, isDateTimeInFuture, parseDateTime } from '@/util';
    import { ShopColorField } from '@/product/ticketing/views/dashboard/organization/events/create/component';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { maxLength, required } from '@/data/validation';
    import AgendaPreview from '@/product/ticketing/views/dashboard/organization/marketing/agenda/AgendaPreview.vue';

    const {get, create, update} = useService(AgendaService);
    const {t} = useI18n();
    const {getEventOptions} = useService(SelectService);
    const {invalid, validate} = useValidationScope();
    const router = useRouter();
    const organizationId = useActiveOrganizationId();

    const _getAgenda = guarded(get, t('ui.somethingWentWrong.title'), t('marketing.agenda.loadingSingleFailed'));
    const _createAgenda = guarded(create, t('ui.somethingWentWrong.title'), t('marketing.agenda.savingFailed'));
    const _updateAgenda = guarded(update, t('ui.somethingWentWrong.title'), t('marketing.agenda.savingFailed'));

    const agendaId = useRouteParam('id');
    const agenda = ref(Agenda.empty());
    const isSaving = ref(false);
    const isLoading = ref(false);
    const allEventsSelected = ref(false);

    onMounted(async () => {
        await getAgenda();
    });

    async function getAgenda(): Promise<void> {
        if (unref(agendaId) === null) {
            return;
        }

        isLoading.value = true;

        try {
            const {data} = await _getAgenda(unref(organizationId), unref(agendaId)!);
            agenda.value = data;
        } finally {
            isLoading.value = false;
        }
    }

    async function saveAgenda(): Promise<void> {
        if (!await validate()) {
            return;
        }

        isSaving.value = true;

        if (unref(agenda).showAllEvents) {
            agenda.value.events = [];
        }

        try {
            if (unref(agendaId) === null) {
                await _createAgenda(unref(organizationId), unref(agenda));
            } else {
                await _updateAgenda(unref(organizationId), unref(agendaId)!, unref(agenda));
            }

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('marketing.agenda.savingSuccessful')
            });

            await router.push({name: 'agendas'});
        } finally {
            isSaving.value = false;
        }
    }

    watch(() => unref(agenda).showAllEvents, async showAllEvents => {
        if (showAllEvents) {
            const {data: events} = await getEventOptions(unref(organizationId));

            agenda.value.events = unref(events)
                .filter(e => isDateTimeInFuture(parseDateTime(e.note!)))
                .map(e => e.id);
        }
    }, {immediate: true});
</script>
