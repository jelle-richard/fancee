<template>
    <div class="shop-switcher-item">
        <button
            class="shop-switcher-item-caption"
            @click="$emit('select')">
            <img
                v-if="headerMedia.length > 0"
                class="shop-switcher-item-image"
                :src="headerMedia[0].url"
                alt=""/>

            <FluxPlaceholder
                v-else
                class="shop-switcher-item-image flex-grow-0"
                icon="image"
                variant="small"/>

            <strong>{{ shop.name }}</strong>
        </button>

        <FluxDestructiveButton
            v-if="isDeletable"
            class="shop-switcher-item-delete"
            icon-before="trash"
            :is-loading="isDeleting"
            @click="$emit('delete')"/>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShop, CreateEventShopListing } from '@fancee/data';
    import { computed } from 'vue';

    interface Emits {
        (e: 'delete'): void;

        (e: 'select'): void;
    }

    interface Props {
        readonly isDeletable?: boolean;
        readonly isDeleting?: boolean;
        readonly shop: CreateEventShop | CreateEventShopListing;
    }

    defineEmits<Emits>();
    const {shop} = defineProps<Props>();

    const headerMedia = computed(() => {
        if (shop instanceof CreateEventShop) {
            return shop.design.headerMedia;
        }

        return shop.headerMedia;
    });
</script>

<style
    lang="scss"
    scoped>
    .shop-switcher-item {
        position: relative;
        display: flex;

        &-caption {
            display: flex;
            align-items: center;
            flex-flow: row;
            gap: 15px;
            padding: 12px 66px 12px 12px;
            flex-grow: 1;
            background: rgb(var(--gray-2));
            border: 0;
            border-radius: calc(var(--radius) / 2);
            color: var(--foreground-prominent);
            text-align: left;
            word-break: break-word;

            &:hover {
                background: rgb(var(--gray-3));
            }
        }

        &-delete {
            position: absolute;
            top: 12px;
            right: 12px;
        }

        &-image {
            height: 42px;
            width: 42px;
            border-radius: calc(var(--radius) / 2);
            flex-grow: 0;
        }
    }
</style>
