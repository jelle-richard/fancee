<template>
    <FluxStack>
        <FluxNotice
            v-if="statisticsFailed"
            icon="circle-exclamation"
            is-small
            :message="t('dashboard.statistics.loadingFailed')"
            variant="warning"/>

        <FluxNotice
            v-if="issuedProducts.length === 0 && !isLoadingIssuedProducts"
            icon="circle-exclamation"
            is-small
            :message="t('dashboard.statistics.notEnoughData')"
            variant="warning"/>

        <template v-else>
            <GlobalEventStatisticsCards :global-event-statistics="globalEventStatistics"/>

            <EventRevenueStatistics
                :currency="currency"
                :event-revenue-statistics="eventRevenueStatisticsData"/>

            <FluxGrid v-if="eventWithIssuedProducts">
                <FluxGridColumn :md="5">
                    <ProductRatioStatistics
                        :products="issuedProducts"
                        :is-loading="isLoadingIssuedProducts"/>
                </FluxGridColumn>

                <FluxGridColumn :md="7">
                    <DailyOrdersChart
                        :daily-orders="dailyOrders"
                        :is-loading="isLoadingDailyOrders"
                        :daily-history-days="dailyOrdersHistoryAmount"
                        :current-date-reached="dailyOrdersDays === 0"
                        @history-amount="onHistoryAmountChanged"
                        @next="dailyOrdersDays += dailyOrdersHistoryAmount"
                        @previous="dailyOrdersDays -= dailyOrdersHistoryAmount"/>
                </FluxGridColumn>
            </FluxGrid>

            <FluxGrid>
                <FluxGridColumn
                    lg="3"
                    md="4"
                    xs="12">
                    <TotalProductsSoldStatistics
                        :products="issuedProducts"
                        :is-loading="isLoadingIssuedProducts"/>
                </FluxGridColumn>

                <FluxGridColumn
                    lg="9"
                    md="8"
                    xs="12">
                    <FluxPane :is-loading="isLoadingIssuedProducts">
                        <ProductSalesStatisticsTable
                            v-if="!isLoadingIssuedProducts"
                            :currency="currency"
                            :product-sale-statistics="issuedProducts"/>
                    </FluxPane>
                </FluxGridColumn>
            </FluxGrid>

            <FluxGrid v-if="selectedSeatsIoEventId !== null">
                <FluxGridColumn>
                    <FluxPane>
                        <SeatsioSeatingChart
                            :workspaceKey="WORKSPACE_KEY"
                            :event="selectedSeatsIoEventId"
                            :showSeatLabels="true"
                            :showFullScreenButton="false"
                            region="eu"
                            mode="static"
                            colorScheme="light"/>
                    </FluxPane>
                </FluxGridColumn>
            </FluxGrid>
        </template>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { EventService, OrderService } from '@fancee/api';
    import { Currency, DailyOrder, EventRevenueStatistics as EventRevenueStatisticsDto, GlobalEventStatistics, IssuedProductStatistics } from '@fancee/data';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { formatDateTime, guarded } from '@/util';
    import { SeatsioSeatingChart } from '@seatsio/seatsio-vue';
    import DailyOrdersChart from '@/product/ticketing/views/dashboard/organization/statistics/DailyOrdersChart.vue';
    import EventRevenueStatistics from '@/product/ticketing/views/dashboard/organization/statistics/EventRevenueStatistics.vue';
    import GlobalEventStatisticsCards from '@/product/ticketing/views/dashboard/organization/statistics/GlobalEventStatisticsCards.vue';
    import ProductRatioStatistics from '@/product/ticketing/views/dashboard/organization/home/ProductRatioStatistics.vue';
    import ProductSalesStatisticsTable from '@/product/ticketing/views/dashboard/organization/home/ProductStatisticsManager.vue';
    import TotalProductsSoldStatistics from '@/product/ticketing/views/dashboard/organization/home/TotalProductsSoldStatistics.vue';

    const WORKSPACE_KEY = import.meta.env.VITE_SEATSIO_WORKSPACE_KEY;

    export interface Props {
        readonly currency: Currency;
        readonly selectedEventId: string;
        readonly selectedSeatsIoEventId: string | null;
    }

    const props = defineProps<Props>();
    const {selectedEventId} = toRefs(props);

    const {t} = useI18n();
    const {getGlobalStatistics, getStatisticsRevenue, getIssuedProducts} = useService(EventService);
    const {getDailyEvent} = useService(OrderService);
    const organizationId = useActiveOrganizationId();

    const _getGlobalStatistics = guarded(getGlobalStatistics, onLoadStatisticsFailed);
    const _getStatisticsRevenue = guarded(getStatisticsRevenue, onLoadStatisticsFailed);
    const _getDailyEvent = guarded(getDailyEvent, onLoadStatisticsFailed);
    const _getIssuedProducts = guarded(getIssuedProducts, onLoadStatisticsFailed);

    const globalEventStatistics = ref<GlobalEventStatistics | null>(null);
    const eventRevenueStatisticsData = ref<EventRevenueStatisticsDto | null>(null);
    const dailyOrders = ref<DailyOrder[]>([]);
    const issuedProducts = ref<IssuedProductStatistics[]>([]);
    const isLoadingIssuedProducts = ref(true);
    const isLoadingDailyOrders = ref(true);
    const dailyOrdersHistoryAmount = ref(7);
    const dailyOrdersDays = ref(0);
    const statisticsFailed = ref(false);

    const eventWithIssuedProducts = computed((): boolean => unref(issuedProducts).reduce((acc, ip) => acc + ip.deductedGuestAmount + ip.notDeductedGuestAmount + ip.soldAmount, 0) > 0);

    async function retrieveStatistics(eventId: string): Promise<void> {
        await getGlobalEventStatistics(eventId);
        await getEventRevenueStatistics(eventId);
        await getIssuedProductsStatistics(eventId);
        await getDailyOrderStatistics(eventId);
    }

    async function getGlobalEventStatistics(eventId: string): Promise<void> {
        globalEventStatistics.value = null;

        const {data} = await _getGlobalStatistics(unref(organizationId), eventId);
        globalEventStatistics.value = data;
    }

    async function getEventRevenueStatistics(eventId: string): Promise<void> {
        eventRevenueStatisticsData.value = null;

        const {data} = await _getStatisticsRevenue(unref(organizationId), eventId);
        eventRevenueStatisticsData.value = data;
    }

    async function getDailyOrderStatistics(eventId: string): Promise<void> {
        isLoadingDailyOrders.value = true;
        dailyOrders.value = [];

        let endDate = formatDateTime(DateTime.now().endOf('day').minus({days: -dailyOrdersDays.value}));
        let startDate = formatDateTime(DateTime.now().startOf('day').minus({days: dailyOrdersHistoryAmount.value - dailyOrdersDays.value}));

        try {
            const {data} = await _getDailyEvent(unref(organizationId), eventId, startDate, endDate);
            dailyOrders.value = data;
        } finally {
            isLoadingDailyOrders.value = false;
        }
    }

    async function getIssuedProductsStatistics(eventId: string): Promise<void> {
        isLoadingIssuedProducts.value = true;
        issuedProducts.value = [];

        try {
            const {data} = await _getIssuedProducts(unref(organizationId), eventId);
            issuedProducts.value = data;
        } finally {
            isLoadingIssuedProducts.value = false;
        }
    }

    function onHistoryAmountChanged(days: number): void {
        dailyOrdersHistoryAmount.value = days;
        dailyOrdersDays.value = 0;

        getDailyOrderStatistics(unref(selectedEventId));
    }

    function onLoadStatisticsFailed(): void {
        statisticsFailed.value = true;
    }

    watch(selectedEventId, () => retrieveStatistics(unref(selectedEventId)), {immediate: true});

    watch(dailyOrdersDays, () => getDailyOrderStatistics(unref(selectedEventId)));
</script>
