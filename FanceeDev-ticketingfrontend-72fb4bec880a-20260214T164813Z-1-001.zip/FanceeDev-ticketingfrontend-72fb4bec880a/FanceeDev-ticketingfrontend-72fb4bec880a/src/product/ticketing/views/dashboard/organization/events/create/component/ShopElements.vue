<template>
    <div class="shop-elements-mount">
        <FluxPlaceholder
            v-if="elements.length === 0"
            class="shop-elements-placeholder"
            icon="bring-front"
            :title="t('event.create.shops.noElements.title')"
            :message="t('event.create.shops.noElements.message')"/>

        <Draggable
            :animation="0"
            :class="{'is-dragging': isDragging}"
            :draggable="'.shop-element-mount'"
            :item-key="() => void 0"
            :model-value="elements"
            :swap-threshold="0.5"
            class="shop-elements"
            group="shop-elements"
            handle=".shop-element-move"
            @change="onChange"
            @end="onDragEnd"
            @start="onDragStart">
            <template #item="{element}">
                <ShopAccordion
                    v-if="CreateEventShopElement.isAccordion(element)"
                    :key="'accordion-' + element.internalId"
                    :editor-elements="elements"
                    :editor-elements-emit="emit"
                    :element="element"/>

                <ShopDivider
                    v-else-if="CreateEventShopElement.isDivider(element)"
                    :key="'divider-' + element.internalId"
                    :editor-elements="elements"
                    :editor-elements-emit="emit"
                    :element="element"/>

                <ShopExternalLink
                    v-else-if="CreateEventShopElement.isExternalLink(element)"
                    :key="'external-link-' + element.internalId"
                    :editor-elements="elements"
                    :editor-elements-emit="emit"
                    :element="element"/>

                <ShopNotice
                    v-else-if="CreateEventShopElement.isNotice(element)"
                    :key="'notice-' + element.internalId"
                    :editor-elements="elements"
                    :editor-elements-emit="emit"
                    :element="element"/>

                <ShopProduct
                    v-else-if="CreateEventShopElement.isProduct(element)"
                    :key="'product-' + element.internalId"
                    :editor-elements="elements"
                    :editor-elements-emit="emit"
                    :element="element"/>

                <ShopSeatingMap
                    v-else-if="CreateEventShopElement.isSeatingMap(element)"
                    :key="'seating-map-' + element.internalId"
                    :editor-elements="elements"
                    :editor-elements-emit="emit"
                    :element="element"/>

                <ShopTextBlock
                    v-else-if="CreateEventShopElement.isTextBlock(element)"
                    :key="'text-block-' + element.internalId"
                    :editor-elements="elements"
                    :editor-elements-emit="emit"
                    :element="element"/>
            </template>
        </Draggable>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopElement } from '@fancee/data';
    import { ref, toRefs } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { default as Draggable } from 'vuedraggable';
    import ShopAccordion from './ShopAccordion.vue';
    import ShopDivider from './ShopDivider.vue';
    import ShopExternalLink from './ShopExternalLink.vue';
    import ShopNotice from './ShopNotice.vue';
    import ShopProduct from './ShopProduct.vue';
    import ShopSeatingMap from './ShopSeatingMap.vue';
    import ShopTextBlock from './ShopTextBlock.vue';

    interface DraggableChange {
        readonly moved?: {
            readonly element: CreateEventShopElement;
            readonly newIndex: number;
            readonly oldIndex: number;
        };

        readonly added?: {
            readonly element: CreateEventShopElement;
            readonly newIndex: number;
        };

        readonly removed?: {
            readonly element: CreateEventShopElement;
            readonly oldIndex: number;
        };
    }

    export interface Emits {
        (e: 'add', newIndex: number, element: CreateEventShopElement): void;

        (e: 'move', oldIndex: number, newIndex: number): void;

        (e: 'remove', oldIndex: number, fromDraggable?: boolean): void;
    }

    export interface Props {
        readonly elements: CreateEventShopElement[];
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {elements} = toRefs(props);

    const {t} = useI18n();

    const isDragging = ref(false);

    function onChange({added, moved, removed}: DraggableChange): void {
        if (added) {
            emit('add', added.newIndex, added.element);
        }

        if (moved) {
            emit('move', moved.oldIndex, moved.newIndex);
        }

        if (removed) {
            emit('remove', removed.oldIndex, true);
        }
    }

    function onDragEnd(): void {
        requestAnimationFrame(() => requestAnimationFrame(() => isDragging.value = false));
    }

    function onDragStart(): void {
        isDragging.value = true;
    }
</script>

<style lang="scss">
    .shop-elements {
        position: relative;
        display: flex;
        margin: 0 21px 21px;
        min-height: 90px;
        padding: 0;
        flex-flow: column;
        gap: 21px;
        z-index: 1;

        &:not(.is-dragging):hover > .shop-element-mount:not(:hover) {
            opacity: .5;
            scale: 0.9875;
        }

        &-placeholder {
            background: hsl(var(--shop-panel-secondary) / .5);
            border-color: hsl(var(--shop-panel-secondary));
            z-index: 0;

            .flux-icon {
                color: hsl(var(--shop-panel-quaternary));
            }

            @at-root :not(.shop-accordion-body) > & {
                margin-left: 15px;
                margin-right: 15px;
                margin-bottom: 15px;
            }
        }

        &.is-dragging &-placeholder {
            opacity: 0;
        }

        &-mount {
            display: grid;

            > * {
                grid-column: 1;
                grid-row: 1;
            }
        }
    }
</style>
