<template>
    <FluxPane>
        <FluxPaneHeader
            v-if="shop !== null && !isLoadingShop"
            :title="`${shop.name} - ${formatDateTimeLocal(shop.dateTimeSpan.start)} / ${formatDateTimeLocal(shop.dateTimeSpan.end)}`"
            :sub-title="secureCodeSubTitle"/>

        <FluxActionBar
            :is-resettable="filter.isResettable"
            @reset="filter.reset()">
            <template #primary>
                <ClaimCheck claim="organization.secureshop.add">
                    <FluxSecondaryButton
                        icon-before="circle-plus"
                        :label="t('event.secureCode.singular')"
                        type="button"
                        @click="addSecureCodesOverlayOpened = true"/>
                </ClaimCheck>

                <ClaimCheck
                    v-if="shop !== null"
                    claim="organization.secureshop.add">
                    <FluxSecondaryButton
                        icon-before="store-lock"
                        :label="t('event.secureCode.alterShopSecure')"
                        @click="showToggleSecureStateOverlay = true"/>
                </ClaimCheck>
            </template>

            <template #actions-before-search>
                <ClaimCheck claim="organization.secureshop.delete">
                    <FluxDestructiveButton
                        v-if="secureCodes.length > 0"
                        icon-before="trash"
                        :label="t('global.deleteAll')"
                        @click="removeAllSecureCodes"/>
                </ClaimCheck>

                <ClaimCheck claim="organization.secureshop.export">
                    <ToolbarDownload
                        :is-loading="isDownloading"
                        @download="onDownloadClicked"/>
                </ClaimCheck>
            </template>

            <template #search>
                <ToolbarSearch
                    v-model="filter.searchQuery"
                    data-testid="my-events-search"
                    :placeholder="t('event.secureCode.search')"/>
            </template>
        </FluxActionBar>

        <SecureCodeDataTable
            :current-page="currentPage"
            :is-loading="isLoadingCodes"
            :items="secureCodes"
            :page-length="pageLength"
            :total-items="totalItems"
            @delete="removeSecureCode"/>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>

    <FluxOverlay
        is-closeable
        size="large">
        <AddSecureCodesOverlay
            v-if="addSecureCodesOverlayOpened"
            :shop-code="shop?.code"
            @close="closeOverlay"/>
    </FluxOverlay>

    <FluxOverlay
        v-if="showToggleSecureStateOverlay && shop !== null && shopCode !== null && eventId !== null"
        is-closeable
        @close="closeOverlay">
        <SecureStateOverlay
            :shop-code="shopCode"
            :event-id="eventId"
            :shop-start-date="shop.dateTimeSpan.start!"
            :shop-end-date="shop.dateTimeSpan.end!"
            :is-secured-until="shop.isSecuredUntil ?? shop.dateTimeSpan.end"
            @close="showToggleSecureStateOverlay = false"
            @secureStateChanged="updateSecureState"/>
    </FluxOverlay>
</template>

<script
    setup
    lang="ts">
    import { CreateEventService, SecureCodeService } from '@fancee/api';
    import { CreateEventShop, SecureCodeListFilter, SecureCodeListing } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { useActiveOrganizationId, usePagination, useRouteParam, useService } from '@/composable';
    import { computed, onMounted, ref, unref, watch } from 'vue';
    import { ClaimCheck } from '@/components/ui';
    import { ToolbarDownload, ToolbarSearch } from '@/components/filter';
    import { useI18n } from 'vue-i18n';
    import { downloadBlob, formatDateTimeLocal, guarded } from '@/util';
    import { DateTime } from 'luxon';
    import SecureCodeDataTable from '@/product/ticketing/views/dashboard/organization/events/securecode/component/SecureCodeDataTable.vue';
    import AddSecureCodesOverlay from '@/product/ticketing/views/dashboard/organization/events/securecode/AddSecureCodesOverlay.vue';
    import SecureStateOverlay from '@/product/ticketing/views/dashboard/organization/events/securecode/component/SecureStateOverlay.vue';

    const {t} = useI18n();
    const {getShop} = useService(CreateEventService);
    const {list, delete: deleteSecureCode, csvExport, deleteUnused} = useService(SecureCodeService);
    const organizationId = useActiveOrganizationId();
    const eventId = useRouteParam('eventId');
    const shopCode = useRouteParam('shopCode');

    const _deleteUnused = guarded(deleteUnused, t('ui.somethingWentWrong.title'), t('event.secureCode.table.deleteAllFailed'));
    const _list = guarded(list, t('ui.somethingWentWrong.title'), t('event.secureCode.table.loadingFailed'));
    const _getShop = guarded(getShop, t('ui.somethingWentWrong.title'), t('event.secureCode.table.loadingShopFailed'));
    const _csvExport = guarded(csvExport, t('ui.somethingWentWrong.title'), t('event.secureCode.table.downloadFailed'));
    const _deleteSecureCode = guarded(deleteSecureCode, t('ui.somethingWentWrong.title'), t('event.secureCode.table.deleteFailed'));

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const filter = ref(SecureCodeListFilter.default());
    const secureCodes = ref<SecureCodeListing[]>([]);
    const isLoadingCodes = ref(false);
    const isLoadingShop = ref(false);
    const isDownloading = ref(false);
    const addSecureCodesOverlayOpened = ref(false);
    const shop = ref<CreateEventShop | null>(null);
    const showToggleSecureStateOverlay = ref(false);

    const secureCodeSubTitle = computed(() => {
        if (unref(shop)?.isSecuredUntil === null) {
            return null;
        }

        return `${t('event.secureCode.set.until')} ${formatDateTimeLocal(unref(shop)!.isSecuredUntil)}`;
    });

    onMounted(async () => await loadShop());

    async function removeSecureCode(code: string): Promise<void> {
        await _deleteSecureCode(unref(organizationId), unref(shopCode)!, code);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('event.secureCode.table.deleteSuccess')
        });

        await loadSecureCodes();
    }

    async function removeAllSecureCodes(): Promise<void> {
        isLoadingCodes.value = true;

        await _deleteUnused(unref(organizationId), unref(shopCode)!);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('event.secureCode.table.deleteAllSuccess')
        });

        await loadSecureCodes();
    }

    async function onDownloadClicked(): Promise<void> {
        isDownloading.value = true;

        const {blob, name} = await _csvExport(unref(organizationId), unref(shopCode)!, unref(filter));
        downloadBlob(blob, name);

        isDownloading.value = false;
    }

    async function loadSecureCodes(): Promise<void> {
        isLoadingCodes.value = true;

        const {data: {items, totalItems}} = await _list(unref(organizationId), unref(shopCode)!, unref(pageLength), unref(currentPage), unref(filter));
        secureCodes.value = items;
        setTotalItems(totalItems);

        isLoadingCodes.value = false;
    }

    async function loadShop(): Promise<void> {
        isLoadingShop.value = true;

        const {data} = await _getShop(unref(organizationId), unref(eventId)!, unref(shopCode)!);

        shop.value = data;

        isLoadingShop.value = false;
    }

    function closeOverlay(forceUpdate: boolean): void {
        addSecureCodesOverlayOpened.value = false;

        if (forceUpdate) {
            loadSecureCodes();
        }
    }

    function updateSecureState(securedUntil: DateTime | null): void {
        let _shop = unref(shop);

        if (_shop === null) {
            return;
        }

        _shop.isSecuredUntil = securedUntil;
    }

    watch([currentPage, pageLength, filter], async () => {
        await loadSecureCodes();
    }, {deep: true, immediate: true});
</script>
