<template>
    <FluxStack>
        <FluxGrid :columns="2">
            <FluxFormField
                v-if="selectedOrder.pspReference"
                :label="t('finance.order.single.order.psp')">
                {{ selectedOrder.pspReference }}
            </FluxFormField>

            <FluxFormField :label="t('global.date')">
                {{ formatDateLocal(selectedOrder.placedOn) }}
            </FluxFormField>

            <FluxFormField :label="t('finance.order.single.order.cost')">
                {{ asMoney(selectedOrder.costCents ?? 0, selectedOrder.currency!) }}
            </FluxFormField>

            <FluxFormField :label="t('finance.order.single.order.paymentMethod')">
                {{ selectedOrder.paymentMethod }}
            </FluxFormField>
        </FluxGrid>

        <FluxFormField :label="t('finance.order.single.order.paymentStatus')">
            <span v-if="selectedOrder.paymentHistory.length === 0">{{ selectedOrder.transactionStatus }}</span>

            <OrderPspHistoryTimeline
                v-else
                :selected-order="selectedOrder"/>
        </FluxFormField>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { Order } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { asMoney, formatDateLocal } from '@/util';
    import OrderPspHistoryTimeline from '@/product/ticketing/views/dashboard/generic/components/OrderPspHistoryTimeline.vue';

    export interface Props {
        readonly selectedOrder: Order;
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>
