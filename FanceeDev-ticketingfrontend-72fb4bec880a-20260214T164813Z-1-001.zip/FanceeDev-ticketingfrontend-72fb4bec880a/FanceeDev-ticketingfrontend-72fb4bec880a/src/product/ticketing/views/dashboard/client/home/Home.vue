<template>
    <EmptyView
        v-if="!isLoading && latestOrder === null"
        :title="t('client.dashboard.emptyView.title')"
        :message="t('client.dashboard.emptyView.message')"
        variant="tickets"/>

    <FluxGrid v-else>
        <FluxGridColumn :md="4">
            <LastOrderCard
                v-if="latestOrder !== null"
                :order="latestOrder"/>

            <FluxPane
                v-else
                is-loading>
                <FluxAspectRatio :aspect-ratio="4 / 3"/>
            </FluxPane>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { OrderService } from '@fancee/api';
    import { Order, OrdersFilter } from '@fancee/data';
    import { onMounted, ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { EmptyView } from '@/components/ui';
    import { useService } from '@/composable';
    import { DEFAULT_PAGES_AMOUNT } from '@/data';
    import { guarded } from '@/util';
    import LastOrderCard from '@/product/ticketing/views/dashboard/client/order/LastOrderCard.vue';

    const {t} = useI18n();
    const {getClient, getClientOrder} = useService(OrderService);

    const _getClient = guarded(getClient, t('ui.somethingWentWrong.title'), t('client.dashboard.loadingFailed'));
    const _getClientOrder = guarded(getClientOrder, t('ui.somethingWentWrong.title'), t('client.dashboard.loadingFailed'));

    const isLoading = ref(true);
    const latestOrder = ref<Order | null>(null);

    onMounted(async () => await loadLatestOrder());

    async function loadLatestOrder(): Promise<void> {
        try {
            const {data: {items}} = await _getClient(1, DEFAULT_PAGES_AMOUNT, OrdersFilter.default(), []);

            if (items.length > 0) {
                await loadOrder(items[0].id);
            }
        } finally {
            isLoading.value = false;
        }
    }

    async function loadOrder(orderId: string): Promise<void> {
        const {data} = await _getClientOrder(orderId);
        latestOrder.value = data;
    }
</script>
