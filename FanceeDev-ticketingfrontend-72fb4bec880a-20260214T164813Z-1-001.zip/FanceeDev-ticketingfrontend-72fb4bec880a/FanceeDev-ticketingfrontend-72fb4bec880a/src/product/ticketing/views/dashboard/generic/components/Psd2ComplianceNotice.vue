<template>
    <FluxNotice
        icon="circle-exclamation"
        variant="warning"
        :title="t('event.create.paymentMethods.psd2.title')">
        <p v-for="paragraph of tm('event.create.paymentMethods.psd2.paragraphs') as string[]">
            {{ rt(paragraph) }}
        </p>
    </FluxNotice>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';

    const {rt, t, tm} = useI18n();
</script>
