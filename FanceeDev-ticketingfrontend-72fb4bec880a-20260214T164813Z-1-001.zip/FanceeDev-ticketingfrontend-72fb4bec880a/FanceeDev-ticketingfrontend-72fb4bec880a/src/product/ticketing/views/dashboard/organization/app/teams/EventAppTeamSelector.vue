<template>
    <SelectorPane :title="t('app.team.statistics.title')">
        <FluxFormInputGroup>
            <FluxFormSelectAsync
                v-model="selectedEventId"
                :placeholder="t('app.team.statistics.selectEvent')"
                :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>

            <FluxSecondaryButton
                v-if="selectedEventId !== null"
                icon-before="xmark"
                @click="resetEventSelection"/>
        </FluxFormInputGroup>

        <FluxFormInputGroup v-if="selectedEventId !== null">
            <FluxFormSelectAsync
                v-model="selectedAppTeamId"
                :placeholder="t('app.team.statistics.selectAppTeam')"
                :fetch-options="fetchSelect(async (ids: string[]) => await getAppTeamsOptions(organizationId, [selectedEventId!], ids))"
                :fetch-relevant="fetchSelect(async () => await getAppTeamsOptions(organizationId, [selectedEventId!]))"
                :fetch-search="fetchSelect(async (searchQuery: string) => await getAppTeamsOptions(organizationId, [selectedEventId!], searchQuery))"/>

            <FluxSecondaryButton
                v-if="selectedAppTeamId !== null"
                icon-before="xmark"
                @click="resetAppTeamSelection"/>
        </FluxFormInputGroup>
    </SelectorPane>
</template>

<script
    lang="ts"
    setup>
    import { SelectService } from '@fancee/api';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { SelectorPane } from '@/components/ui';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { fetchSelect } from '@/util';

    export type Emits = {
        (e: 'selected-event-changed', selectedEventId: string | null): void;
        (e: 'selected-app-team-changed', search: string | null): void;
    };

    export type Props = {
        readonly appTeamId?: string | null;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {appTeamId} = toRefs(props);

    const {t} = useI18n();
    const {getEventOptions, getAppTeamsOptions} = useService(SelectService);
    const organizationId = useActiveOrganizationId();

    const selectedEventId = ref<string | null>(null);
    const selectedAppTeamId = ref<string | null>(null);

    function resetEventSelection(): void {
        selectedEventId.value = null;
        selectedAppTeamId.value = null;
    }

    function resetAppTeamSelection(): void {
        selectedAppTeamId.value = null;
    }

    watch(selectedEventId, () => emit('selected-event-changed', unref(selectedEventId)));

    watch(selectedAppTeamId, () => emit('selected-app-team-changed', unref(selectedAppTeamId)));

    watch(appTeamId, () => {
        if (unref(appTeamId) === null) {
            resetAppTeamSelection();
        }
    });
</script>
