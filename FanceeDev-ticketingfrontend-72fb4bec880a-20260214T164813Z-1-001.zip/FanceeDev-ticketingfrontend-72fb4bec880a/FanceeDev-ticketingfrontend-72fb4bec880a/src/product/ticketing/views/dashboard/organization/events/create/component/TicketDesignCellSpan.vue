<template>
    <nav
        class="ticket-design-cell-span"
        :class="[`is-${bearing}`]">
        <TicketDesignCellButton
            :disabled="!canDecrease"
            :icon="decreaseIcon"
            @click="onDecrease"/>

        <TicketDesignCellButton
            :disabled="!canIncrease"
            :icon="increaseIcon"
            @click="onIncrease"/>
    </nav>
</template>

<script
    lang="ts"
    setup>
    import type { IconNames } from '@fancee/flux';
    import { computed, toRefs } from 'vue';
    import { Bearing, EVENT_TICKET_DESIGN_COLUMNS, EVENT_TICKET_DESIGN_ROWS } from '@/data';
    import TicketDesignCellButton from './TicketDesignCellButton.vue';

    export interface Emits {
        (e: 'span', direction: Bearing, amount: number): void;
    }

    export interface Props {
        readonly bearing: Bearing;
        readonly column: number;
        readonly columnSpan: number;
        readonly row: number;
        readonly rowSpan: number;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {bearing, column, columnSpan, row, rowSpan} = toRefs(props);

    const isStart = computed(() => ['north', 'west'].includes(bearing.value));
    const isVertical = computed(() => ['north', 'south'].includes(bearing.value));
    const position = computed(() => isVertical.value ? row.value : column.value);
    const positionLimit = computed(() => isStart.value ? 1 : (isVertical.value ? EVENT_TICKET_DESIGN_ROWS : EVENT_TICKET_DESIGN_COLUMNS));
    const span = computed(() => isVertical.value ? rowSpan.value : columnSpan.value);

    const canDecrease = computed(() => span.value > 1);

    const canIncrease = computed(() => position.value !== positionLimit.value && position.value + span.value - 1 !== positionLimit.value);

    const decreaseIcon = computed((): IconNames => {
        switch (bearing.value) {
            case 'north':
                return 'arrow-down-from-line';

            case 'east':
                return 'arrow-left-from-line';

            case 'south':
                return 'arrow-up-from-line';

            case 'west':
                return 'arrow-right-from-line';
        }
    });

    const increaseIcon = computed((): IconNames => {
        switch (bearing.value) {
            case 'north':
                return 'arrow-up-from-line';

            case 'east':
                return 'arrow-right-from-line';

            case 'south':
                return 'arrow-down-from-line';

            case 'west':
                return 'arrow-left-from-line';
        }
    });

    function onDecrease(): void {
        emit('span', bearing.value, -1);
    }

    function onIncrease(): void {
        emit('span', bearing.value, 1);
    }
</script>

<style lang="scss">
    .ticket-design-cell-span {
        position: absolute;
        display: flex;
        gap: 12px;
        justify-content: space-between;
        transition: 450ms var(--deceleration-curve);
        z-index: 1;

        &.is-north,
        &.is-south {
            left: 50%;
            height: 80px;
        }

        &.is-east,
        &.is-west {
            top: 50%;
            width: 80px;
        }

        &.is-north {
            top: -1px;
            flex-flow: column-reverse;
            translate: -50% -50%;
        }

        &.is-east {
            right: -1px;
            flex-flow: row;
            translate: 50% -50%;
        }

        &.is-south {
            bottom: -1px;
            flex-flow: column;
            translate: -50% 50%;
        }

        &.is-west {
            left: -1px;
            flex-flow: row-reverse;
            translate: -50% -50%;
        }
    }

    .ticket-design-cell:not(:hover) .ticket-design-cell-span {
        opacity: 0;
        pointer-events: none;
        scale: .95;
        transition-duration: 300ms;
        transition-timing-function: var(--swift-out);
    }
</style>
