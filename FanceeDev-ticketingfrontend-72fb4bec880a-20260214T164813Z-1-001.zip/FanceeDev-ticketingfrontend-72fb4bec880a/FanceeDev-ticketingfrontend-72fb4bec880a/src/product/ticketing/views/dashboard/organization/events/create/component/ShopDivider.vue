<template>
    <ShopElement
        :internal-id="element.internalId"
        :editor-elements="editorElements"
        :editor-elements-emit="editorElementsEmit"
        is-indented
        @edit="edit">
        <template #edit>
            <FluxPaneBody>
                <FluxFormColumn>
                    <FluxFormField :label="t('event.create.shops.element.divider.title')">
                        <FluxFormInput
                            v-model="localElement.name"
                            data-testid="create-event-shop-divider-title"
                            :placeholder="t('event.create.shops.element.divider.titlePlaceholder')"/>
                    </FluxFormField>
                </FluxFormColumn>
            </FluxPaneBody>
        </template>

        <FluxDivider
            class="shop-divider-empty"
            v-if="!element.name || element.name.trim().length === 0"/>

        <div
            v-else
            class="shop-divider">
            <h2>{{ element.name }}</h2>
        </div>
    </ShopElement>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopDividerElement, CreateEventShopElement } from '@fancee/data';
    import { ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import ShopElement from './ShopElement.vue';

    export interface Props {
        readonly editorElements: CreateEventShopElement[];
        readonly editorElementsEmit: Function;
        readonly element: CreateEventShopDividerElement;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const {t} = useI18n();

    const localElement = ref(new CreateEventShopDividerElement(unref(element).name));

    function edit(commitChanges: boolean): void {
        if (commitChanges) {
            element.value.name = unref(localElement).name;
            return;
        }

        localElement.value = new CreateEventShopDividerElement(unref(element).name);
    }
</script>

<style lang="scss">
    .shop-divider {
        margin-top: 21px;
        margin-bottom: -3px;

        &-name {
            margin-top: 0;
            margin-bottom: 0;
        }
    }
</style>
