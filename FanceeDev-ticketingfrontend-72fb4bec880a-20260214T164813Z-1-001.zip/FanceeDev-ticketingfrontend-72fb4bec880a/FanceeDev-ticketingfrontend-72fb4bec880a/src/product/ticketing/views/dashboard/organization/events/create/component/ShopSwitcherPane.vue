<template>
    <FluxPane>
        <FluxExpandable ref="expandableRef">
            <template #header="{isOpen, toggle}">
                <FluxPaneBody>
                    <FluxStack
                        axis="horizontal"
                        class="shop-switcher-header"
                        :gap="9">
                        <FluxSecondaryButton
                            class="shop-switcher-toggle"
                            :icon-after="shops.length > 1 ? (isOpen ? 'angle-up' : 'angle-down') : null"
                            :label="selectedShopName"
                            @click="toggle"/>

                        <FluxSpacer/>

                        <FluxSecondaryButton
                            class="shop-switcher-add"
                            icon-before="plus"
                            :is-loading="isAddingShop"
                            @click="onAddShop"/>
                    </FluxStack>
                </FluxPaneBody>
            </template>

            <template #body>
                <FluxPaneBody class="shop-switcher-body">
                    <FluxStack :gap="3">
                        <FluxNotice
                            v-if="hasErrors"
                            icon="circle-exclamation"
                            is-small
                            variant="danger">
                            <ul>
                                <template v-for="(messages, code) of errors">
                                    <li
                                        :key="`${code}/${index}`"
                                        v-for="(message, index) of messages">
                                        <strong>{{ code }}</strong>: {{ message }}
                                    </li>
                                </template>
                            </ul>
                        </FluxNotice>

                        <template v-for="shop of shops">
                            <ShopSwitcherItem
                                :is-deletable="shops.length > 1"
                                :is-deleting="deletingShopCode === shop.code"
                                :shop="shop"
                                @delete="onDeleteShop(shop.code)"
                                @select="onSelectShop(shop.code)"/>
                        </template>
                    </FluxStack>
                </FluxPaneBody>
            </template>
        </FluxExpandable>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventService } from '@fancee/api';
    import { CreateEventShop, DateTimeSpan } from '@fancee/data';
    import { FluxExpandable, showConfirm, showPrompt } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useRequestErrorBoundary, useService } from '@/composable';
    import { storeToRefs, useCreateEventStore } from '@/data/store';
    import ShopSwitcherItem from './ShopSwitcherItem.vue';

    const createEventStore = useCreateEventStore();
    const {setSelectedShopCode, setShops} = createEventStore;
    const {details, eventId, selectedShopCode, shops} = storeToRefs(createEventStore);

    const {t} = useI18n();
    const {errors, hasErrors, reset: resetErrors} = useRequestErrorBoundary();
    const {createShop, deleteShop} = useService(CreateEventService);
    const organizationId = useActiveOrganizationId();

    const deletingShopCode = ref<string | null>(null);
    const expandableRef = ref<typeof FluxExpandable>();
    const isAddingShop = ref(false);

    const selectedShopName = computed(() => unref(shops).find(s => s.code === unref(selectedShopCode))?.name);

    async function onAddShop(): Promise<void> {
        const shopName = await showPrompt({
            icon: 'store',
            title: t('event.create.shops.newShop.title'),
            message: t('event.create.shops.newShop.message'),
            fieldLabel: t('event.create.shops.newShop.label'),
            fieldPlaceholder: t('event.create.shops.newShop.placeholder')
        });

        if (!shopName) {
            return;
        }

        unref(expandableRef)?.open();
        isAddingShop.value = true;

        const shop = CreateEventShop.default();
        shop.dateTimeSpan = new DateTimeSpan(
            DateTime.now().startOf('day'),
            unref(details).dateTimeSpan.end
        );
        shop.isActive = true;
        shop.name = shopName;

        const {data: shopCode} = await createShop(unref(organizationId), unref(eventId)!, shop)
            .finally(() => isAddingShop.value = false);
        shop.code = shopCode;
        unref(shops).push(shop);
    }

    async function onDeleteShop(shopCode: string): Promise<void> {
        resetErrors();

        const shop = unref(shops).find(s => s.code === shopCode);

        if (!shop) {
            return;
        }

        const confirmed = await showConfirm({
            icon: 'trash',
            message: t('ui.confirmDeleteOverlay.message', [shop.name]),
            title: t('ui.confirmDeleteOverlay.title', [shop.name])
        });

        if (!confirmed) {
            return;
        }

        deletingShopCode.value = shopCode;

        const otherShops = unref(shops).filter(s => s.code !== shopCode);

        if (unref(selectedShopCode) === shopCode) {
            setSelectedShopCode(otherShops[0]?.code || null);
        }

        await deleteShop(unref(organizationId), unref(eventId)!, shopCode);
        setShops(otherShops);

        deletingShopCode.value = null;
    }

    function onSelectShop(shopCode: string): void {
        unref(expandableRef)?.close();
        setSelectedShopCode(shopCode);
    }
</script>

<style lang="scss">
    .shop-switcher {
        &-add {
            margin-right: -9px;
        }

        &-body {
            margin-left: -9px;
            margin-right: -9px;
            margin-bottom: -9px;
            padding-top: 0;
        }

        &-header {
            margin-top: -9px;
            margin-bottom: -9px;
        }

        &-toggle {
            margin-left: -9px;
            min-width: 0;
            flex: 1 1 auto;
            justify-content: flex-start;
            border: 0;
            box-shadow: none;
            text-align: left;

            span {
                color: var(--foreground-prominent);
                overflow: hidden;
                text-align: left;
                text-overflow: ellipsis;
            }
        }
    }
</style>
