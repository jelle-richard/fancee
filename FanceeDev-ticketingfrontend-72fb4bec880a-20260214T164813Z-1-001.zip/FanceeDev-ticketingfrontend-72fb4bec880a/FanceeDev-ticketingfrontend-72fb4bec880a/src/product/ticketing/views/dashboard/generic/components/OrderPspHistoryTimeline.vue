<template>
    <FluxTimeline
        :class="$style.orderPspTimeline">
        <FluxTimelineItem
            color="primary"
            :icon="iconByPaymentStatus(selectedOrder.transactionStatus)"
            :title="t(`finance.paymentStatus.${toCamelCase(selectedOrder.transactionStatus)}`)"
            :when="formatDateTime(selectedOrder.lastAlteration)">
            <p>{{ selectedOrder.pspReference }}</p>
            <p>{{ asMoney(selectedOrder.costCents ?? 0, currency) }}</p>
        </FluxTimelineItem>

        <FluxTimelineItem
            v-for="orderPspHistory in selectedOrder.paymentHistory"
            :key="orderPspHistory.createdOn"
            :icon="iconByPaymentStatus(orderPspHistory.paymentStatus)"
            :title="orderPspHistory.paymentStatus === PaymentStatus.Unknown ? $t('finance.order.single.order.placed') : t(`finance.paymentStatus.${toCamelCase(orderPspHistory.paymentStatus)}`)"
            :when="formatDateTime(orderPspHistory.createdOn)">
            <p>{{ orderPspHistory.pspReference }}</p>
            <p>{{ asMoney(orderPspHistory.amountCents, currency) }}</p>
        </FluxTimelineItem>
    </FluxTimeline>
</template>

<script
    setup
    lang="ts">
    import { Order, PaymentStatus } from '@fancee/data';
    import { IconNames } from '@fancee/flux';
    import { toRefs } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useCurrency } from '@/composable';
    import { asMoney, formatDateTime, toCamelCase } from '@/util';

    const {t} = useI18n();
    const currency = useCurrency();

    export interface Props {
        readonly selectedOrder: Order;
    }

    const props = defineProps<Props>();
    const {selectedOrder} = toRefs(props);

    function iconByPaymentStatus(status: PaymentStatus): IconNames {
        switch (status) {
            case PaymentStatus.Authorised:
                return 'circle-check';

            case PaymentStatus.Pending:
                return 'timer';

            case PaymentStatus.Error:
                return 'circle-exclamation';

            case PaymentStatus.Cancelled:
                return 'xmark-circle';

            case PaymentStatus.Refund:
            case PaymentStatus.PartialRefund:
                return 'arrow-left-to-line';

            case PaymentStatus.Refused:
            case PaymentStatus.Blocked:
                return 'shield';

            case PaymentStatus.Unknown:
                return 'shopping-cart';

            default:
                return 'circle-question';
        }
    }
</script>

<style
    lang="scss"
    module>

    .orderPspTimeline {
        margin-top: 12px;
    }
</style>
