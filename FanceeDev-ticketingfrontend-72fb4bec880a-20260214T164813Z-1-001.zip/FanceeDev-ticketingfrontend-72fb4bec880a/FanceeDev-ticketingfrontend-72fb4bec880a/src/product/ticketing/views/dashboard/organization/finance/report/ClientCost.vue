<template>
    <FluxPane>
        <DetailListPaneSection :title="t('finance.report.client.cost.title')">
            <DetailListItem
                :label="t('finance.report.client.cost.smsCost')"
                :value="asMoney(cost.smsFeeCostCents, currency)"/>

            <DetailListItem
                :label="t('finance.report.client.cost.tspCost')"
                :value="asMoney(cost.ticketServicePlusFeeCostCents, currency)"/>

            <DetailListItem
                :label="t('finance.report.client.cost.paymentFeeCost')"
                :value="asMoney(cost.paymentFeeCostCents, currency)"/>
        </DetailListPaneSection>

        <FluxSeparator/>

        <DetailListPaneSection :title="t('finance.report.totals.title')">
            <DetailListItem
                :label="t('finance.report.totals.clientCost')"
                :value="asMoney(totalCost, currency)"/>
        </DetailListPaneSection>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { ClientCost } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { asMoney } from '@/util';
    import { DetailListItem, DetailListPaneSection } from '@/components/ui';
    import { useCurrency } from '@/composable';

    const {t} = useI18n();
    const currency = useCurrency();

    export type Props = {
        readonly cost: ClientCost;
        readonly totalCost: number;
    };

    defineProps<Props>();
</script>
