<template>
    <FluxStack>
        <div class="shop-background">
            <FluxPane
                v-if="shop"
                light
                class="shop-editor"
                :tag="t('event.create.shops.designer')">
                <ShopHeader/>

                <ShopElements
                    :key="elements.map(e => e.internalId).join(',')"
                    :elements="elements"
                    @add="onElementsAdd"
                    @move="onElementsMove"
                    @remove="onElementsRemove"/>
            </FluxPane>
        </div>

        <ShopElementsDebug
            v-if="false /* note(Bas): I want to keep this here because working with shop elements is a pain. */"
            :elements="elements"/>

        <FluxPane>
            <FluxPaneFooter :class="$style.elementsFooter">
                <FluxFlyout
                    v-if="filteredTickets.length > 0"
                    :width="420">
                    <template #opener="{open}">
                        <FluxPlaceholder
                            is-button
                            icon="ticket-simple"
                            :title="t('event.create.shops.insert.ticket')"
                            data-testid="create-event-insert-ticket"
                            variant="simple"
                            @click="open"/>
                    </template>

                    <template #default="{close}">
                        <ProductSelector
                            :products="filteredTickets"
                            @select="addProduct($event, close)"/>
                    </template>
                </FluxFlyout>

                <FluxFlyout
                    v-if="filteredProducts.length > 0"
                    :width="420">
                    <template #opener="{open}">
                        <FluxPlaceholder
                            is-button
                            icon="shirt"
                            :title="t('event.create.shops.insert.product')"
                            data-testid="create-event-insert-product"
                            variant="simple"
                            @click="open"/>
                    </template>

                    <template #default="{close}">
                        <ProductSelector
                            :products="filteredProducts"
                            @select="addProduct($event, close)"/>
                    </template>
                </FluxFlyout>

                <FluxPlaceholder
                    v-if="eventType === EventType.Seating"
                    is-button
                    icon="loveseat"
                    :title="t('event.create.shops.insert.seating')"
                    variant="simple"
                    data-testid="create-event-add-seating"
                    @click="addSeatingMap()"/>

                <FluxPlaceholder
                    is-button
                    icon="circle"
                    :title="t('event.create.shops.insert.accordion')"
                    variant="simple"
                    data-testid="create-event-add-accordion"
                    @click="addAccordion()"/>

                <FluxPlaceholder
                    is-button
                    icon="dash"
                    :title="t('event.create.shops.insert.divider')"
                    variant="simple"
                    data-testid="create-event-add-divider"
                    @click="addDivider()"/>

                <FluxPlaceholder
                    is-button
                    icon="link-simple"
                    :title="t('event.create.shops.insert.link')"
                    variant="simple"
                    data-testid="create-event-add-external-link"
                    @click="addExternalLink()"/>

                <FluxPlaceholder
                    is-button
                    icon="circle-exclamation"
                    :title="t('event.create.shops.insert.notice')"
                    data-testid="create-event-add-notice"
                    variant="simple"
                    @click="addNotice()"/>

                <FluxPlaceholder
                    is-button
                    icon="text"
                    :title="t('event.create.shops.insert.text')"
                    data-testid="create-event-add-text"
                    variant="simple"
                    @click="addTextBlock()"/>
            </FluxPaneFooter>
        </FluxPane>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopAccordionElement, CreateEventShopDividerElement, CreateEventShopElement, CreateEventShopExternalLinkElement, CreateEventShopNoticeElement, CreateEventShopProductElement, CreateEventShopSeatingMapElement, CreateEventShopTextBlockElement, EventType, ShopDesign } from '@fancee/data';
    import { computed, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { BACKDROP_SHOP_COLOR, BACKGROUND_SHOP_COLOR, PRIMARY_SHOP_COLOR, TEXT_SHOP_COLOR } from '@/data';
    import { storeToRefs, useCreateEventStore } from '@/data/store';
    import { hexToHSL } from '@/util';
    import ProductSelector from './ProductSelector.vue';
    import ShopElements from './ShopElements.vue';
    import ShopElementsDebug from './ShopElementsDebug.vue';
    import ShopHeader from './ShopHeader.vue';

    const createEventStore = useCreateEventStore();
    const {eventType, products, selectedShopCode, shop, tickets} = storeToRefs(createEventStore);

    const {t} = useI18n();

    const elements = ref<CreateEventShopElement[]>([]);

    const shopDesign = computed(() => unref(shop)?.design ?? ShopDesign.default());
    const shopProducts = computed(() => {
        const elements = unref(shop)?.elements ?? [];
        const products: CreateEventShopProductElement[] = [];

        for (const element of elements) {
            if (CreateEventShopElement.isAccordion(element)) {
                element.elements
                    .filter(CreateEventShopElement.isProduct)
                    .forEach(p => products.push(p));
            }

            if (CreateEventShopElement.isProduct(element)) {
                products.push(element);
            }
        }

        return products;
    });
    const filteredProducts = computed(() => unref(products).filter(p => !unref(shopProducts).find(sp => sp.productId === p.id)));
    const filteredTickets = computed(() => unref(tickets).filter(p => !unref(shopProducts).find(sp => sp.productId === p.id)));

    function addElement(element: CreateEventShopElement): void {
        unref(elements).push(element);
    }

    function addProduct(productId: string, close: Function): void {
        close();
        addElement(new CreateEventShopProductElement(productId));
    }

    function addAccordion(): void {
        addElement(new CreateEventShopAccordionElement([], 'shirt', true, ''));
    }

    function addDivider(): void {
        addElement(new CreateEventShopDividerElement(''));
    }

    function addExternalLink(): void {
        addElement(new CreateEventShopExternalLinkElement(import.meta.env.VITE_BASE_URL, t('event.create.shops.default.buttonLabel')));
    }

    function addNotice(): void {
        addElement(new CreateEventShopNoticeElement(t('event.create.shops.default.noticeContent'), 'warning'));
    }

    function addSeatingMap(): void {
        addElement(new CreateEventShopSeatingMapElement());
    }

    function addTextBlock(): void {
        addElement(new CreateEventShopTextBlockElement(t('event.create.shops.default.textBlockText'), t('event.create.shops.default.textBlockTitle')));
    }

    function onElementsAdd(newIndex: number, element: CreateEventShopElement): void {
        const e = unref(elements);
        e.splice(newIndex, 0, element);
    }

    function onElementsMove(oldIndex: number, newIndex: number): void {
        const e = unref(elements);
        const oldElement = e[oldIndex];
        e.splice(oldIndex, 1);
        e.splice(newIndex, 0, oldElement);
    }

    function onElementsRemove(oldIndex: number, fromDraggable?: boolean): void {
        const e = unref(elements);
        const oldElement = e[oldIndex];

        if (fromDraggable && CreateEventShopElement.isAccordion(oldElement)) {
            return;
        }

        e.splice(oldIndex, 1);
    }

    watch(selectedShopCode, () => {
        const $shop = unref(shop);

        if (!$shop) {
            return;
        }

        elements.value = [...$shop.elements];
    }, {immediate: true});

    watch(elements, elements => {
        const s = unref(shop);

        if (!s) {
            return;
        }

        s.elements = [...elements];
    }, {deep: true});

    watch(shopDesign, shopDesign => {
        document.body.style.removeProperty('--shop-primary');
        document.body.style.removeProperty('--shop-background');
        document.body.style.removeProperty('--shop-panel');
        document.body.style.removeProperty('--shop-panel-secondary');
        document.body.style.removeProperty('--shop-text');
        document.body.style.removeProperty('--shop-link');

        let h: number, s: number, l: number;

        [h, s, l] = hexToHSL(shopDesign.primaryColor ?? PRIMARY_SHOP_COLOR);
        document.body.style.setProperty('--shop-primary', `${h}deg ${s}% ${l}%`);
        document.body.style.setProperty('--shop-primary-text', `${h}deg ${s}% ${Math.max(0, Math.min(100, l < 45 ? l - 90 : l + 90))}%`);

        [h, s, l] = hexToHSL(shopDesign.backgroundColor ?? BACKGROUND_SHOP_COLOR);
        document.body.style.setProperty('--shop-background', `${h}deg ${s}% ${l}%`);

        [h, s, l] = hexToHSL(shopDesign.backdropColor ?? BACKDROP_SHOP_COLOR);
        document.body.style.setProperty('--shop-panel', `${h}deg ${s}% ${l}%`);
        document.body.style.setProperty('--shop-panel-secondary', `${h}deg ${s}% ${Math.max(0, Math.min(100, l < 45 ? l + 10 : l - 5))}%`);
        document.body.style.setProperty('--shop-panel-tertiary', `${h}deg ${s}% ${Math.max(0, Math.min(100, l < 45 ? l - 5 : l + 5))}%`);
        document.body.style.setProperty('--shop-panel-quaternary', `${h}deg ${s}% ${Math.max(0, Math.min(100, l > 85 ? l - 20 : l + 20))}%`);

        [h, s, l] = hexToHSL(shopDesign.textColor ?? TEXT_SHOP_COLOR);
        document.body.style.setProperty('--shop-text', `${h}deg ${s}% ${l}%`);
    }, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .shop-background {
        padding: 18px;
        background: hsl(var(--shop-background));
        border-radius: var(--radius);
    }

    .shop-editor {
        --foreground: hsl(var(--shop-text));
        --foreground-prominent: hsl(var(--shop-text));
        --foreground-secondary: hsl(var(--shop-text));

        background: hsl(var(--shop-panel));
        border-color: hsl(var(--shop-panel-secondary));
        color: var(--foreground);

        ::v-deep(.flux-overlay),
        ::v-deep(.flux-toolbar) {
            --foreground: rgb(var(--gray-7));
            --foreground-prominent: rgb(var(--gray-9));
            --foreground-secondary: rgb(var(--gray-6));
        }

        ::v-deep(.flux-divider),
        ::v-deep(.shop-product) {
            background: hsl(var(--shop-panel-secondary));
        }

        > ::v-deep(.flux-pane-footer) {
            background: hsl(var(--shop-panel-tertiary));
            border-color: hsl(var(--shop-panel-secondary));
            border-radius: 0 0 var(--radius) var(--radius);
        }

        > ::v-deep(.flux-pane-footer) .flux-placeholder {
            background: hsl(var(--shop-panel));
            border-color: hsl(var(--shop-panel-quaternary));

            &:hover {
                background: hsl(var(--shop-panel-tertiary));
            }
        }

        ::v-deep(.flux-quantity-selector),
        ::v-deep(.flux-quantity-selector) :is(.flux-button, .flux-form-input) {
            background: hsl(var(--shop-panel));
            border-color: hsl(var(--shop-panel-quaternary));
            pointer-events: none;
        }

        ::v-deep(.flux-quantity-selector),
        ::v-deep(.flux-quantity-selector) .flux-button:hover {
            background: hsl(var(--shop-panel-secondary));
        }

        ::v-deep(.flux-info-icon) {
            color: hsl(var(--shop-primary));
        }
    }
</style>

<style
    lang="scss"
    module>
    .elementsFooter {
        flex-wrap: wrap;
    }
</style>
