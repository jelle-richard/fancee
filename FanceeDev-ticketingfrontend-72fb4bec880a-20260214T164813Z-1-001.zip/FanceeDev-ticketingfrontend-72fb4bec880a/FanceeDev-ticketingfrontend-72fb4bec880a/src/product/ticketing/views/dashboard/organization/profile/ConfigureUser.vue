<template>
    <FluxPane :is-loading="isUploadingAvatar || isDeletingAvatar">
        <FluxPaneBody v-if="hasAnyErrors">
            <FluxNoticeStack>
                <FluxNotice
                    icon="circle-exclamation"
                    variant="danger">
                    <ul>
                        <template
                            v-for="error of localErrors">
                            <li>
                                {{ error }}
                            </li>
                        </template>

                        <template v-for="(messages, code) of errors">
                            <li v-for="message of messages">
                                <strong>{{ code }}</strong>: {{ message }}
                            </li>
                        </template>
                    </ul>
                </FluxNotice>
            </FluxNoticeStack>
        </FluxPaneBody>

        <FluxPaneBody>
            <FluxFormField :label="t('platform.profile.user.avatar')">
                <FluxDropZone
                    @select="onFilesSelected"
                    accept="image/*">
                    <template #default="{showPicker}">
                        <FluxStack axis="horizontal">
                            <FluxPersona
                                is-compact
                                :avatar-fallback-initials="user.firstName && user.lastName ? fullNameToInitials(`${user.firstName} ${user.lastName}`) : 'F'"
                                :avatar-size="100"
                                :avatar-url="newAvatarUrl ?? user.avatarFile?.url"
                                :name="user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : user.email"
                                :title="user.type"/>

                            <FluxButtonStack>
                                <FluxSecondaryButton
                                    icon-before="circle-arrow-up"
                                    :label="t('global.upload')"
                                    @click="showPicker"/>

                                <FluxDestructiveButton
                                    v-if="user.avatarFile"
                                    icon-before="trash"
                                    @click="onDeleteAvatar"/>
                            </FluxButtonStack>
                        </FluxStack>
                    </template>
                </FluxDropZone>
            </FluxFormField>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { AuthUser, Media } from '@fancee/data';
    import { HttpStatusCode } from '@fancee/client';
    import { computed, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useRequestErrorBoundary, useService } from '@/composable';
    import { MAX_FILE_SIZE_KB } from '@/data';
    import { useAuthStore } from '@/data/store';
    import { fullNameToInitials } from '@/util';

    const authStore = useAuthStore();
    const {setUser} = authStore;

    const {t} = useI18n();
    const {errors, hasErrors, reset: resetErrors} = useRequestErrorBoundary();
    const {uploadAvatar, deleteAvatar} = useService(UserService);
    const organizationId = useActiveOrganizationId();

    const isDeletingAvatar = ref(false);
    const isUploadingAvatar = ref(false);
    const newAvatarUrl = ref<string | null>(null);

    const localErrors = ref<string[]>([]);
    const user = computed(() => authStore.user!);
    const hasAnyErrors = computed(() => hasErrors.value || localErrors.value.length > 0);

    async function onDeleteAvatar(): Promise<void> {
        resetAllErrors();
        isDeletingAvatar.value = true;
        newAvatarUrl.value = null;

        await deleteAvatar(unref(organizationId))
            .finally(() => isDeletingAvatar.value = false);

        updateUserAvatar(null);
    }

    async function onFilesSelected(files: FileList): Promise<void> {
        resetAllErrors();
        isUploadingAvatar.value = true;

        const file = files.item(0)!;

        if (file['size'] / 1024 > MAX_FILE_SIZE_KB) {
            localErrors.value.push(t('image_size_limit', {amount: MAX_FILE_SIZE_KB}));

            isUploadingAvatar.value = false;
            return;
        }

        newAvatarUrl.value = URL.createObjectURL(file);

        const {data: id, headers, statusCode} = await uploadAvatar(unref(organizationId), file)
            .finally(() => isUploadingAvatar.value = false);

        if (statusCode !== HttpStatusCode.Created || !headers.has('location')) {
            return;
        }

        URL.revokeObjectURL(newAvatarUrl.value);
        newAvatarUrl.value = headers.get('location')!;

        updateUserAvatar(new Media(id, newAvatarUrl.value, null, null, null));
    }

    function updateUserAvatar(avatar: Media | null): void {
        const newUser = new AuthUser(
            unref(user).id,
            unref(user).email,
            unref(user).firstName,
            unref(user).lastName,
            unref(user).type,
            avatar,
            unref(user).lastLogin,
            unref(user).currency,
            [],
            unref(user).isProfileComplete,
            unref(user).changelogsSinceLastLogin,
            unref(user).activeOrganizationId
        );

        setUser(newUser);
    }

    function resetAllErrors(): void {
        resetErrors();
        localErrors.value = [];
    }
</script>
