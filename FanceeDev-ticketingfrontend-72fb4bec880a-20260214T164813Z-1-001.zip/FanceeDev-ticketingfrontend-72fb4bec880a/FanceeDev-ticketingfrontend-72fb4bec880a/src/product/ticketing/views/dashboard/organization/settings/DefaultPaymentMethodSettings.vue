<template>
    <FluxStack>
        <FluxPane :is-loading="isLoading">
            <FluxPaneBody>
                <FluxStack :gap="6">
                    <template
                        v-for="paymentMethod of paymentMethods"
                        :key="paymentMethod.id">
                        <ConfigurablePaymentMethod :payment-method="paymentMethod"/>
                    </template>
                </FluxStack>
            </FluxPaneBody>

            <FluxPaneFooter>
                <FluxSpacer/>

                <FluxPrimaryButton
                    icon-before="circle-check"
                is-submit
                :label="t('global.save')"
                    :is-loading="isSaving"
                    @click="saveDefaultPaymentMethods"/>
            </FluxPaneFooter>
        </FluxPane>

        <Psd2ComplianceNotice/>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { OrganizationDefaultsService } from '@fancee/api';
    import { AssignedPaymentMethod, EventPaymentMethod } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { ConfigurablePaymentMethod } from '@/product/ticketing/views/dashboard/organization/events/create/component';
    import { guarded } from '@/util';
    import Psd2ComplianceNotice from '@/product/ticketing/views/dashboard/generic/components/Psd2ComplianceNotice.vue';

    const {t} = useI18n();
    const {getPaymentMethods, updatePaymentMethods} = useService(OrganizationDefaultsService);
    const organizationId = useActiveOrganizationId();

    const _getPaymentMethods = guarded(getPaymentMethods, t('ui.somethingWentWrong.title'), t('settings.defaultPaymentMethods.loadingFailed'));
    const _updatePaymentMethods = guarded(updatePaymentMethods, t('ui.somethingWentWrong.title'), t('settings.defaultPaymentMethods.savingFailed'));

    const paymentMethods = ref<EventPaymentMethod[]>([]);
    const isLoading = ref(false);
    const isSaving = ref(false);

    onMounted(async () => await fetchDefaultPaymentMethods());

    async function fetchDefaultPaymentMethods(): Promise<void> {
        isLoading.value = true;

        try {
            const {data} = await _getPaymentMethods(unref(organizationId));
            paymentMethods.value = data;
        } finally {
            isLoading.value = false;
        }
    }

    async function saveDefaultPaymentMethods(): Promise<void> {
        if (paymentMethods.value.length === 0) {
            return;
        }

        isSaving.value = true;

        try {
            await _updatePaymentMethods(unref(organizationId), unref(paymentMethods).map(mp => new AssignedPaymentMethod(mp.id, mp.paidBy)));

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('ui.changesSavedSuccessfully')
            });
        } finally {
            isSaving.value = false;
        }
    }
</script>
