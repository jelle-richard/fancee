<template>
    <FluxFormRow>
        <ValidationField
            :label="t('form.field.email')"
            :rules="{required, email}"
            :value="guest.email">
            <FluxFormInput
                data-lpignore="true"
                v-model="guest.email"
                type="email"
                :placeholder="t('form.placeholder.email')"/>
        </ValidationField>

        <FluxFormField :label="t('form.field.firstName')">
            <FluxFormInput
                v-model="guest.firstName"
                type="text"
                :placeholder="t('form.placeholder.firstName')"/>
        </FluxFormField>

        <FluxFormField :label="t('form.field.lastName')">
            <FluxFormInput
                v-model="guest.lastName"
                type="text"
                :placeholder="t('form.placeholder.lastName')"/>
        </FluxFormField>

        <ValidationField
            :label="t('form.field.quantity')"
            :rules="{required, integer, minValue: minValue(1), maxValue: maxValue(10)}"
            :value="guest.quantity">
            <FluxFormInput
                v-model="guest.quantity"
                type="number"/>
        </ValidationField>

        <FluxFormField
            :class="$style.deleteField"
            label=" ">
            <FluxTooltip :content="t('global.delete')">
                <FluxDestructiveButton
                    icon-before="trash"
                    @click="$emit('delete', index)"/>
            </FluxTooltip>
        </FluxFormField>
    </FluxFormRow>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { Guest } from '@/data/dto/guestlist/Guest';
    import { email, integer, maxValue, minValue, required } from '@/data/validation';

    interface Emits {
        (e: 'delete', index: number): void;
    }

    interface Props {
        readonly guest: Guest;
        readonly index: number;
    }

    defineEmits<Emits>();
    defineProps<Props>();

    const {t} = useI18n();
</script>

<style
    lang="scss"
    module>
    .deleteField {
        flex-grow: 0;
    }
</style>
