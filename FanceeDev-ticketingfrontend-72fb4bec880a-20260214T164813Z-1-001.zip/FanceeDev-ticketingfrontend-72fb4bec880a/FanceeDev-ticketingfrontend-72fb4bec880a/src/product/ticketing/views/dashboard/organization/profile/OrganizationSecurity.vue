<template>
    <FluxPane>
        <ValidationNotice pane-body/>

        <FluxPaneBody>
            <FluxFormColumn>
                <ValidationField
                    :label="t('form.field.password')"
                    name="password"
                    :rules="{required}"
                    :value="currentUserPassword">
                    <FluxFormInput
                        v-model="currentUserPassword"
                        auto-complete="password"
                        type="password"/>
                </ValidationField>

                <FluxFormRow>
                    <ValidationField
                        :label="t('form.field.passwordNew')"
                        name="password"
                        :rules="{required}"
                        :value="newUserPassword">
                        <FluxFormInput
                            v-model="newUserPassword"
                            auto-complete="new-password"
                            type="password"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('form.field.passwordNewConfirm')"
                        name="password"
                        :rules="{required, sameAs: sameAs(newUserPassword)}"
                        :value="newUserPasswordRepeat">
                        <FluxFormInput
                            v-model="newUserPasswordRepeat"
                            auto-complete="new-password"
                            type="password"/>
                    </ValidationField>
                </FluxFormRow>
            </FluxFormColumn>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxPrimaryButton
                :disabled="invalid"
                icon-before="circle-check"
                :label="t('global.save')"
                @click="validated(resetPassword)"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { showSnackbar } from '@fancee/flux';
    import { ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { useRouter, useService, useValidationScope } from '@/composable';
    import { useAuthStore } from '@/data/store';
    import { required, sameAs } from '@/data/validation';
    import { guarded } from '@/util';

    const {logout} = useAuthStore();
    const {t} = useI18n();
    const {updatePassword} = useService(UserService);
    const {invalid, validated} = useValidationScope();
    const router = useRouter();

    const _updatePassword = guarded(updatePassword, t('ui.somethingWentWrong.title'), t('platform.profile.security.passwordChangeFailed'));

    const currentUserPassword = ref('');
    const newUserPassword = ref('');
    const newUserPasswordRepeat = ref('');

    async function resetPassword(): Promise<void> {
        await _updatePassword(unref(currentUserPassword), unref(newUserPassword));

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('platform.profile.security.passwordChanged')
        });

        logout();

        await router.push({
            name: 'auto-login'
        });
    }
</script>
