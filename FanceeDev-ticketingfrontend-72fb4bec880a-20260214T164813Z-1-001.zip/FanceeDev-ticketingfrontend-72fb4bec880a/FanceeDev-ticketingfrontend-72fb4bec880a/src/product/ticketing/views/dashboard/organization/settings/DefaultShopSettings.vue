<template>
    <FluxGrid>
        <FluxGridColumn
            :xs="12"
            :sm="8"
            :md="6"
            :lg="4">
            <FluxPane :is-loading="isLoading">
                <FluxPaneHeader
                    :title="t('settings.defaultShopPalette.title')"
                    :sub-title="t('settings.defaultShopPalette.description')"/>

                <FluxPaneBody>
                    <FluxFormColumn>
                        <FluxFormRow>
                            <ShopColorField
                                v-model="palette.primaryColor"
                                :default-color="PRIMARY_SHOP_COLOR"
                                :label="t('settings.defaultShopPalette.primary')"/>

                            <ShopColorField
                                v-model="palette.backgroundColor"
                                :default-color="BACKGROUND_SHOP_COLOR"
                                :label="t('settings.defaultShopPalette.background')"/>
                        </FluxFormRow>

                        <FluxFormRow>
                            <ShopColorField
                                v-model="palette.backdropColor"
                                :default-color="BACKDROP_SHOP_COLOR"
                                :label="t('settings.defaultShopPalette.panel')"/>

                            <ShopColorField
                                v-model="palette.textColor"
                                :default-color="TEXT_SHOP_COLOR"
                                :label="t('settings.defaultShopPalette.text')"/>
                        </FluxFormRow>
                    </FluxFormColumn>
                </FluxPaneBody>

                <FluxPaneFooter>
                    <FluxSpacer/>

                    <FluxPrimaryButton
                        icon-before="circle-check"
                        is-submit
                        :label="t('global.save')"
                        :is-loading="isSaving"
                        @click="saveDefaultPalette()"/>
                </FluxPaneFooter>
            </FluxPane>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    setup
    lang="ts">
    import { OrganizationDefaultsService } from '@fancee/api';
    import { HttpStatusCode, isRequestError } from '@fancee/client';
    import { ShopColorPalette } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { BACKDROP_SHOP_COLOR, BACKGROUND_SHOP_COLOR, PRIMARY_SHOP_COLOR, TEXT_SHOP_COLOR } from '@/data';
    import { ShopColorField } from '@/product/ticketing/views/dashboard/organization/events/create/component';
    import { guarded } from '@/util';

    const {t} = useI18n();
    const {getPalette, updatePalette} = useService(OrganizationDefaultsService);
    const organizationId = useActiveOrganizationId();

    const _getPalette = guarded(getPalette, t('ui.somethingWentWrong.title'), t('event.create.shops.configurator.defaultPalette.loadingFailed'));
    const _updatePalette = guarded(updatePalette, t('ui.somethingWentWrong.title'), t('event.create.shops.configurator.defaultPalette.savingFailed'));

    const palette = ref(new ShopColorPalette(PRIMARY_SHOP_COLOR, TEXT_SHOP_COLOR, BACKDROP_SHOP_COLOR, BACKGROUND_SHOP_COLOR));
    const isLoading = ref(false);
    const isSaving = ref(false);

    onMounted(async () => await fetchDefaultPalette());

    async function fetchDefaultPalette(): Promise<void> {
        isLoading.value = true;

        try {
            const {data} = await _getPalette(unref(organizationId));
            palette.value = data;
        } catch (err) {
            // note: It's normal that an organization doesn't have a default palette yet.
            if (isRequestError(err) && err.statusCode === HttpStatusCode.NotFound) {
                return;
            }

            throw err;
        } finally {
            isLoading.value = false;
        }
    }

    async function saveDefaultPalette(): Promise<void> {
        isSaving.value = true;

        try {
            await _updatePalette(unref(organizationId), palette.value);

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('ui.changesSavedSuccessfully')
            });
        } finally {
            isSaving.value = false;
        }
    }
</script>
