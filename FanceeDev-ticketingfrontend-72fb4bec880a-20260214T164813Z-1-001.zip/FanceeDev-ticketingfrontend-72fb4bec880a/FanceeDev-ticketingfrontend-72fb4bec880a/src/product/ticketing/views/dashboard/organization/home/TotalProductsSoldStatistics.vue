<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneBody>
            <ApexChart
                type="radialBar"
                :key="remainingProductsPercentage()"
                :options="goalOverviewRadialBar['chartOptions']"
                :series="goalOverviewRadialBar['series']"/>

            <FluxDivider/>

            <FluxGrid
                :class="$style.saleInsights"
                columns="2">
                <div>
                    <p>{{ t('global.sold') }}</p>
                    <h3>{{ totalSoldProducts() }}</h3>
                </div>

                <div>
                    <p>{{ t('global.stock') }}</p>
                    <h3>{{ totalStockedProducts() }}</h3>
                </div>
            </FluxGrid>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { IssuedProductStatistics } from '@fancee/data';
    import { ref, toRefs, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        readonly isLoading: boolean;
        readonly products: IssuedProductStatistics[];
    }

    const props = defineProps<Props>();
    const {products, isLoading} = toRefs(props);

    const {t} = useI18n();

    const goalOverviewRadialBar = ref<object>({
        series: [0],
        chartOptions: {
            chart: {
                sparkline: {
                    enabled: true
                },
                dropShadow: {
                    enabled: true,
                    blur: 3,
                    left: 1,
                    top: 1,
                    opacity: 0.1
                }
            },
            colors: ['#89a69d'],
            plotOptions: {
                radialBar: {
                    offsetY: -10,
                    startAngle: -150,
                    endAngle: 150,
                    hollow: {
                        size: '77%'
                    },
                    track: {
                        background: '#ebe9f1',
                        strokeWidth: '50%'
                    },
                    dataLabels: {
                        name: {
                            show: false
                        },
                        value: {
                            color: '#5e5873',
                            fontSize: '2.86rem',
                            fontWeight: '600'
                        }
                    }
                }
            },
            stroke: {
                lineCap: 'round'
            },
            grid: {
                padding: {
                    bottom: 30
                }
            }
        }
    });

    function totalSoldProducts(): number {
        return products.value.length === 0
            ? 0
            : products.value.map(p => p.soldAmount)
                .reduce((accumulator, curr) => accumulator + curr);
    }

    function totalStockedProducts(): number {
        return products.value.length === 0
            ? 0
            : products.value.map(p => p.stock)
                .reduce((accumulator, curr) => accumulator + curr);
    }

    function remainingProductsPercentage(): number {
        let totalSold = totalSoldProducts();
        let totalStocked = totalStockedProducts();

        if (totalSold === 0 || totalStocked === 0)
            return 0;

        return Math.round(totalSold / (totalStocked / 100));
    }

    watch(products, () => {
        goalOverviewRadialBar.value['series'] = [remainingProductsPercentage()];
    }, {immediate: true});
</script>

<style
    lang="scss"
    module>
    .saleInsights {
        text-align: center;

        div {
            p {
                margin-bottom: 0;
            }

            h3 {
                margin-top: 9px;
            }
        }
    }
</style>
