<template>
    <FluxContainer :gutter="0">
        <FluxTabs>
            <FluxTab :label="t('platform.profile.organization.title')">
                <OrganizationConfigurator :profile="profile"/>
            </FluxTab>

            <FluxTab
                v-if="organizationContract?.signed"
                :label="t('platform.profile.contact.title')">
                <OrganizationContacts :profile="profile"/>
            </FluxTab>

            <FluxTab
                v-if="organizationContract?.signed"
                :label="t('platform.profile.user.title')">
                <ConfigureUser/>
            </FluxTab>

            <FluxTab
                v-if="organizationContract?.signed"
                :label="t('platform.profile.security.title')">
                <OrganizationSecurity/>
            </FluxTab>

            <FluxTab
                v-if="organizationContract?.signed"
                :label="t('platform.profile.sessions.title')">
                <SessionsDataTable/>
            </FluxTab>

            <FluxTab
                v-if="organizationContract?.signed"
                :label="t('platform.profile.packages.title')">
                <Packages/>
            </FluxTab>
        </FluxTabs>
    </FluxContainer>
</template>

<script
    lang="ts"
    setup>
    import { OrganizationService } from '@fancee/api';
    import { Address, OrganizationProfile } from '@fancee/data';
    import { ref, unref, watchEffect } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { SessionsDataTable } from '@/components/auth';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { usePlatformStore, useStore } from '@/data/store';
    import { guarded } from '@/util';
    import OrganizationConfigurator from '@/product/ticketing/views/dashboard/organization/profile/OrganizationConfigurator.vue';
    import OrganizationContacts from '@/product/ticketing/views/dashboard/organization/profile/OrganizationContacts.vue';
    import OrganizationSecurity from '@/product/ticketing/views/dashboard/organization/profile/OrganizationSecurity.vue';
    import ConfigureUser from '@/product/ticketing/views/dashboard/organization/profile/ConfigureUser.vue';
    import Packages from '@/product/ticketing/views/dashboard/organization/user/Packages.vue';

    const {t} = useI18n();
    const {getProfile} = useService(OrganizationService);
    const {organizationContract} = useStore(usePlatformStore());
    const organizationId = useActiveOrganizationId();

    const _getProfile = guarded(getProfile, t('ui.somethingWentWrong.title'), t('platform.profile.loadingFailed'));

    const profile = ref(OrganizationProfile.empty());

    watchEffect(async () => {
        if (!unref(organizationId)) {
            return;
        }

        const {data} = await _getProfile(unref(organizationId));

        data.address ??= Address.empty();

        profile.value = data;
    });
</script>
