<template>
    <FluxPaneBody>
        <TicketDesignGrid @loading="$emit('loading', $event)"/>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { TicketDesign, TicketDesignElement } from '@fancee/data';
    import { computed, toRefs, unref } from 'vue';
    import { EVENT_TICKET_DESIGN_COLUMNS, EVENT_TICKET_DESIGN_ROWS } from '@/data';
    import { provideTicketDesigner } from '../composable';
    import TicketDesignGrid from './TicketDesignGrid.vue';

    export interface Emits {
        (e: 'loading', isLoading: boolean): void;
    }

    export interface Props {
        readonly design: TicketDesign;
    }

    defineEmits<Emits>();
    const props = defineProps<Props>();

    const {design} = toRefs(props);

    const cells = computed(() => EVENT_TICKET_DESIGN_ROWS * EVENT_TICKET_DESIGN_COLUMNS);
    const elements = computed(() => [...unref(design).elements].sort((a, b) => {
        if (TicketDesignElement.isQr(a)) {
            return 1;
        }

        if (TicketDesignElement.isQr(b)) {
            return -1;
        }

        return 0;
    }));
    const occupied = computed(() => getOccupied());

    function getOccupied(skip?: TicketDesignElement): [number, number][] {
        if (skip && TicketDesignElement.isQr(skip)) {
            return [];
        }

        const cells: [number, number][] = [];

        for (const element of unref(elements)) {
            if (skip && (TicketDesignElement.isQr(element) || skip === element)) {
                continue;
            }

            let column = element.column;
            let row = element.row;

            for (let r = 0; r < element.rowSpan; ++r) {
                for (let c = 0; c < element.columnSpan; ++c) {
                    cells.push([row + r, column + c]);
                }
            }
        }

        return cells;
    }

    provideTicketDesigner({
        cells,
        design,
        elements,
        occupied,
        getOccupied
    });
</script>
