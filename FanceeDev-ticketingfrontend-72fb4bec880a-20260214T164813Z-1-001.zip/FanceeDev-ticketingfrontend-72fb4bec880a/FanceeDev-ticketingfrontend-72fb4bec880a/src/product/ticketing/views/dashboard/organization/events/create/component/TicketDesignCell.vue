<template>
    <FluxDropZone
        v-slot="{showPicker}"
        class="ticket-design-cell"
        :is-disabled="!TicketDesignElement.isMedia(element)"
        @select="onFilesSelected">
        <template
            v-for="bearing of EVENT_TICKET_DESIGN_BEARINGS"
            :key="bearing">
            <TicketDesignCellSpan
                :bearing="bearing"
                :column="element.column"
                :column-span="element.columnSpan"
                :row="element.row"
                :row-span="element.rowSpan"
                @span="onSpan"/>
        </template>

        <TicketDesignCellOptions
            :element="element"
            :show-picker="showPicker"
            @move="onMove"
            @remove="onRemove"/>

        <div
            v-if="TicketDesignElement.isMedia(element)"
            class="ticket-design-cell-media"
            :style="{
                '--fileUrl': `url(${element.fileUrl})`
            }"/>

        <div
            v-if="TicketDesignElement.isQr(element)"
            class="ticket-design-cell-qr">
            <div>
                <strong>Ticket Name</strong><br/>
                <span>{{ asMoney(1000, currency) }}</span>
            </div>

            <QRCode
                level="H"
                :size="breakpoint === 'xs' ? 48 : 96"
                value="WeAreFancee"/>

            <strong>FAN1234567890ABCDEF</strong>
        </div>

        <div
            v-if="TicketDesignElement.isUpcomingEvents(element)"
            class="ticket-design-cell-upcoming-events">
            <table>
                <thead>
                <tr>
                    <th colspan="2">{{ t('event.create.ticketDesign.upcomingEvents.title') }}</th>
                </tr>
                </thead>
                <tbody>
                <tr
                    v-for="index in element.amount"
                    :key="index">
                    <td>00-00-0000</td>
                    <td>{{ t('event.create.ticketDesign.upcomingEvents.anotherEvent') }}</td>
                </tr>
                </tbody>
            </table>
        </div>
    </FluxDropZone>
</template>

<script
    lang="ts"
    setup>
    import { EventProductService } from '@fancee/api';
    import { RequestError } from '@fancee/client';
    import { TicketDesignElement } from '@fancee/data';
    import { showSnackbar, useBreakpoints } from '@fancee/flux';
    import { default as QRCode } from 'qrcode.vue';
    import { computed, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useCurrency, useMultiFileManagement, useService } from '@/composable';
    import { Bearing, EVENT_TICKET_DESIGN_BEARINGS } from '@/data';
    import { storeToRefs, useCreateEventStore } from '@/data/store';
    import { asMoney } from '@/util';
    import { useTicketDesigner } from '../composable';
    import TicketDesignCellOptions from './TicketDesignCellOptions.vue';
    import TicketDesignCellSpan from './TicketDesignCellSpan.vue';

    export interface Props {
        readonly element: TicketDesignElement;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const createEventStore = useCreateEventStore();
    const {eventId} = storeToRefs(createEventStore);
    const {breakpoint} = useBreakpoints();

    const {t} = useI18n();
    const {uploadTicketDesignMedia} = useService(EventProductService);
    const {design} = useTicketDesigner();
    const organizationId = useActiveOrganizationId();
    const currency = useCurrency();

    const {upload: uploadMedia} = useMultiFileManagement({
        onUploadError(file: File, _: RequestError, message: string) {
            showSnackbar({
                color: 'danger',
                icon: 'circle-exclamation',
                message: message,
                title: file.name
            });
        },
        upload: async file => await uploadTicketDesignMedia(unref(organizationId), unref(eventId)!, file)
    });

    const column = computed(() => unref(element).column);
    const columnSpan = computed(() => unref(element).columnSpan);
    const row = computed(() => unref(element).row);
    const rowSpan = computed(() => unref(element).rowSpan);

    async function onFilesSelected(files: FileList): Promise<void> {
        if (!TicketDesignElement.isMedia(element.value)) {
            return;
        }

        const images: File[] = [];

        for (let i = 0; i < files.length; ++i) {
            const file = files.item(i);

            if (!file || !file.type.startsWith('image/')) {
                continue;
            }

            images.push(file);
        }

        const medias = await uploadMedia(images);

        if (medias.length === 1) {
            const media = medias[0];
            element.value.fileId = media.id;
            element.value.fileUrl = media.url;
        }
    }

    function onMove(bearing: Bearing): void {
        switch (bearing) {
            case 'north':
                element.value.row--;
                break;

            case 'east':
                element.value.column++;
                break;

            case 'south':
                element.value.row++;
                break;

            case 'west':
                element.value.column--;
                break;
        }
    }

    function onRemove(): void {
        const index = unref(design).elements.findIndex(el => el === unref(element));

        if (index === -1) {
            return;
        }

        unref(design).elements.splice(index, 1);
    }

    function onSpan(bearing: Bearing, amount: number): void {
        switch (bearing) {
            case 'north':
                element.value.row -= amount;
                element.value.rowSpan += amount;
                break;

            case 'east':
                element.value.columnSpan += amount;
                break;

            case 'south':
                element.value.rowSpan += amount;
                break;

            case 'west':
                element.value.column -= amount;
                element.value.columnSpan += amount;
                break;
        }
    }
</script>

<style
    lang="scss"
    scoped>
    @use '@/assets/css/breakpoints' as *;

    .ticket-design-cell {
        position: relative;
        display: flex;
        grid-column: v-bind(column) / span v-bind(columnSpan);
        grid-row: v-bind(row) / span v-bind(rowSpan);
        align-items: center;
        justify-content: center;
        background: rgb(var(--gray-1));
        color: rgb(var(--primary-11));
        font-variant-numeric: tabular-nums;
        transition: 300ms var(--swift-out);
        z-index: 0;

        &:hover {
            opacity: 1;
            z-index: 1;
        }

        &-media,
        &-qr,
        &-upcoming-events {
            position: absolute;
            inset: 0;
            background: white;
        }

        &-media {
            background: var(--fileUrl) no-repeat center center / cover;
        }

        &-qr {
            display: flex;
            align-items: center;
            flex-flow: column;
            gap: 12px;
            justify-content: center;
            text-align: center;
        }

        &-upcoming-events {
            table {
                width: 100%;
                padding: 0;
                border-collapse: collapse;
                border-spacing: 0;
                pointer-events: none;

                td,
                th {
                    padding: 9px 12px;
                    text-align: left;
                }

                th {
                    background: #354152;
                    color: white;
                    font-size: 16px;
                }

                td {
                    color: #2a2f4c;
                }

                td:first-child {
                    width: 120px;
                }

                tr:nth-child(even) td {
                    background: #edf2f6;
                }

                tr:nth-child(odd) td {
                    background: #fcfcfd;
                }
            }
        }
    }

    @include breakpoint-down(sm) {
        .ticket-design-cell-qr {
            gap: 3px;
            font-size: 9px;
        }
    }
</style>
