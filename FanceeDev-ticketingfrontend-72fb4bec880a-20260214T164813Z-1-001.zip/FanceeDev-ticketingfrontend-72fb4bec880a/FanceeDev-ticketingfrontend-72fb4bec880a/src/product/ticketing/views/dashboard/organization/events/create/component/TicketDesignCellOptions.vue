<template>
    <nav class="ticket-design-cell-options">
        <TicketDesignCellButton
            v-if="canMoveNorth"
            class="north"
            icon="angle-up"
            @click="move('north')"/>

        <TicketDesignCellButton
            v-if="canMoveEast"
            class="east"
            icon="angle-right"
            @click="move('east')"/>

        <TicketDesignCellButton
            v-if="canMoveSouth"
            class="south"
            icon="angle-down"
            @click="move('south')"/>

        <TicketDesignCellButton
            v-if="canMoveWest"
            class="west"
            icon="angle-left"
            @click="move('west')"/>

        <FluxFlyout>
            <template #opener="{open}">
                <TicketDesignCellButton
                    class="more"
                    icon="ellipsis-h"
                    @click="open"/>
            </template>

            <FluxMenu>
                <template v-if="TicketDesignElement.isMedia(element)">
                    <FluxMenuGroup>
                        <FluxMenuItem
                            icon-before="arrow-up-from-line"
                            :label="t('event.create.ticketDesign.uploadImage')"
                            @click="showPicker"/>
                    </FluxMenuGroup>

                    <FluxSeparator/>
                </template>

                <template v-if="TicketDesignElement.isUpcomingEvents(element)">
                    <FluxMenuGroup>
                        <FluxMenuItem
                            v-for="n in 5"
                            :key="n"
                            is-selectable
                            :is-selected="element.amount === n"
                            :label="t('event.create.ticketDesign.upcomingEvents.nEvents', n)"
                            @click="element.amount = n"/>
                    </FluxMenuGroup>

                    <FluxSeparator/>
                </template>

                <FluxMenuGroup>
                    <FluxMenuItem
                        icon-before="trash"
                        is-destructive
                        :label="t('global.delete')"
                        @click="remove"/>
                </FluxMenuGroup>
            </FluxMenu>
        </FluxFlyout>
    </nav>
</template>

<script
    lang="ts"
    setup>
    import { TicketDesignElement } from '@fancee/data';
    import { computed, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { Bearing, EVENT_TICKET_DESIGN_COLUMNS, EVENT_TICKET_DESIGN_ROWS } from '@/data';
    import { useTicketDesigner } from '../composable';
    import TicketDesignCellButton from './TicketDesignCellButton.vue';

    export interface Emits {
        (e: 'move', direction: Bearing): void;

        (e: 'remove'): void;
    }

    export interface Props {
        readonly element: TicketDesignElement;
        readonly showPicker: Function;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const {t} = useI18n();
    const {getOccupied} = useTicketDesigner();

    const column = computed(() => unref(element).column);
    const columnSpan = computed(() => unref(element).columnSpan);
    const row = computed(() => unref(element).row);
    const rowSpan = computed(() => unref(element).rowSpan);

    const canMoveNorth = computed(() => canMoveTo(unref(row) - 1, unref(column)));
    const canMoveEast = computed(() => canMoveTo(unref(row), unref(column) + 1));
    const canMoveSouth = computed(() => canMoveTo(unref(row) + 1, unref(column)));
    const canMoveWest = computed(() => canMoveTo(unref(row), unref(column) - 1));

    function canMoveTo(row: number, column: number): boolean {
        if (row < 1 || column < 1) {
            return false;
        }

        if (row + unref(rowSpan) - 1 > EVENT_TICKET_DESIGN_ROWS || column + unref(columnSpan) - 1 > EVENT_TICKET_DESIGN_COLUMNS) {
            return false;
        }

        const occupied = getOccupied(unref(element));

        for (let r = 0; r < unref(rowSpan); ++r) {
            for (let c = 0; c < unref(columnSpan); ++c) {
                if (occupied.find(cell => cell[0] === row + r && cell[1] === column + c)) {
                    return false;
                }
            }
        }

        return true;
    }

    function move(direction: Bearing): void {
        emit('move', direction);
    }

    function remove(): void {
        emit('remove');
    }
</script>

<style
    lang="scss"
    scoped>
    .ticket-design-cell-options {
        position: absolute;
        display: grid;
        top: 50%;
        left: 50%;
        gap: 12px;
        grid-template-columns: repeat(3, 36px);
        grid-template-rows: repeat(3, 36px);
        transition: 450ms var(--deceleration-curve);
        translate: -50% -50%;
        z-index: 1;

        .north {
            grid-area: 1 / 2;
        }

        .east {
            grid-area: 2 / 3;
        }

        .south {
            grid-area: 3 / 2;
        }

        .west {
            grid-area: 2 / 1;
        }

        .more {
            grid-area: 2 / 2;
        }
    }

    .ticket-design-cell:not(:hover) .ticket-design-cell-options {
        gap: 9px;
        opacity: 0;
        pointer-events: none;
        scale: .95;
        transition-duration: 300ms;
        transition-timing-function: var(--swift-out);
    }
</style>
