<template>
    <FluxFormColumn>
        <ValidationField
            v-if="!file"
            :label="t('global.upload')"
            :rules="{required}"
            :value="file">
            <FluxDropZone
                accept=".csv"
                is-empty
                placeholder-icon="file"
                :placeholder-button="t('ui.csvUpload.button')"
                :placeholder-message="t('ui.csvUpload.message')"
                @select="setFile"/>
        </ValidationField>

        <template v-else>
            <FluxFormField :label="t('ui.csvUpload.hasHeader')">
                <FluxToggle
                    v-model="hasHeader"
                    class="toggle-form-row-offset"/>
            </FluxFormField>

            <FluxPane>
                <FluxTable>
                    <template #header>
                        <FluxTableRow>
                            <FluxTableHeader>{{ t('ui.csvUpload.exampleData') }}</FluxTableHeader>
                            <FluxTableHeader>{{ t('ui.csvUpload.fieldType') }}</FluxTableHeader>
                        </FluxTableRow>
                    </template>

                    <template #rows>
                        <FluxTableRow
                            v-for="(column, index) in csvPreviewRows[hasHeader ? 1 : 0]"
                            :key="index">
                            <FluxTableCell class="align-field-mapping-items-center">{{ column }}</FluxTableCell>
                            <FluxTableCell>
                                <FluxFormInputGroup>
                                    <FluxFormSelect
                                        v-if="fieldMappings.length > 0"
                                        v-model="fieldMappings[index].id"
                                        class="field-type-table-offset"
                                        :options="fieldOptions"/>

                                    <FluxDestructiveButton
                                        v-if="fieldMappings[index]?.id !== null"
                                        icon-before="xmark"
                                        @click="fieldMappings[index].id = null"/>
                                </FluxFormInputGroup>
                            </FluxTableCell>
                        </FluxTableRow>
                    </template>
                </FluxTable>
            </FluxPane>
        </template>
    </FluxFormColumn>
</template>

<script
    setup
    lang="ts">
    import { CsvDelimiter } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { CsvAdapter } from '@/data/adapter/file/CsvAdapter';
    import { required } from '@/data/validation';
    import { SecureCodeFieldType } from '@/data';

    export type Emits = {
        (e: 'field-mapping-changed', fieldMappings: { id: string | null, label: string }[]): void;
        (e: 'file-changed', file: File | null): void;
        (e: 'delimiter-name-changed', delimiter: CsvDelimiter): void;
        (e: 'has-header-changed', hasHeader: boolean): void;
        (e: 'total-rows-changed', totalRows: number): void;
    };

    const emit = defineEmits<Emits>();

    const {t} = useI18n();

    const csvPreviewRows = ref<string[][]>([]);
    const file = ref<File | null>(null);
    const delimiterName = ref(CsvDelimiter.Comma);
    const hasHeader = ref(false);
    const fieldMappings = ref<{ id: string | null, label: string }[]>([]);
    const totalRows = ref(0);

    const fieldOptions = ref<FluxFormSelectOption[]>([
        {id: SecureCodeFieldType.Code, label: t('event.secureCode.singular')},
        {id: SecureCodeFieldType.MaxUses, label: t('event.secureCode.add.maxUses')}
    ]);

    function setFile(files: FileList): void {
        file.value = files.item(0);

        if (!unref(file)) {
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            let result = reader.result;

            if (!result) {
                return;
            }

            result = result.toString();

            totalRows.value = result.split('\n').length;

            delimiterName.value = CsvAdapter.detectDelimiter(result);
            csvPreviewRows.value = CsvAdapter.csvStringToRowColumns(result, unref(delimiterName), 2);

            Array(csvPreviewRows.value[0].length).fill(0).forEach(() => fieldMappings.value.push({id: null, label: ''}));
        };

        reader.readAsText(unref(file)!);
    }

    watch(file, () => emit('file-changed', unref(file)));

    watch(delimiterName, () => emit('delimiter-name-changed', unref(delimiterName)));

    watch(hasHeader, () => emit('has-header-changed', unref(hasHeader)));

    watch(fieldMappings, () => emit('field-mapping-changed', unref(fieldMappings)), {deep: true});

    watch(totalRows, () => emit('total-rows-changed', unref(totalRows)));
</script>
