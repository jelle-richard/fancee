<template>
    <FluxOverlay
        is-closeable
        size="large"
        @close="closeOverlay">
        <FluxPane v-if="isOpen">
            <FluxPaneHeader
                icon="circle-plus"
                :title="t('event.addBarcodesOverlay.title')">
                <FluxSecondaryButton
                    icon-before="xmark"
                    @click="closeOverlay"/>
            </FluxPaneHeader>

            <ValidationNotice pane-body/>

            <FluxPaneBody>
                <FluxStack :gap="15">
                    <FluxNotice
                        v-if="validateImport.length > 0"
                        icon="info-circle"
                        is-small
                        :title="t('validation.errors.pleaseFix')"
                        variant="danger">
                        <ul>
                            <template v-for="error in validateImport">
                                <li>{{ error }}</li>
                            </template>
                        </ul>
                    </FluxNotice>

                    <FluxTabs v-model="selectedTabIndex">
                        <FluxTab :label="t('event.addBarcodesOverlay.generate')">
                            <GenerateBarcodes
                                @selected-event-id-changed="selectedEventId = $event"
                                @selected-product-id-changed="selectedProductId = $event"
                                @amount-changed="amount = $event"/>
                        </FluxTab>

                        <FluxTab :label="t('event.addBarcodesOverlay.import')">
                            <ImportBarcodes
                                @selected-event-id-changed="selectedEventId = $event"
                                @selected-product-id-changed="selectedProductId = $event"
                                @file-changed="file = $event"
                                @delimiter-name-changed="delimiterName = $event"
                                @has-header-changed="hasHeader = $event"
                                @total-rows-changed="totalRows = $event"
                                @field-mapping-changed="fieldMappings = $event"/>
                        </FluxTab>
                    </FluxTabs>
                </FluxStack>
            </FluxPaneBody>

            <FluxPaneFooter>
                <FluxSpacer/>

                <FluxSecondaryButton
                    :label="t('global.close')"
                    @click="closeOverlay"/>

                <FluxPrimaryButton
                    :disabled="invalid"
                    icon-before="circle-check"
                    :label="selectedTabIndex === 0 ? t('event.addBarcodesOverlay.submitGenerate') : t('event.addBarcodesOverlay.submitImport')"
                    :is-loading="addingBarcodes"
                    @click="selectedTabIndex === 0 ? generateBarcodesForOrganization() : importBarcodesForOrganization()"/>
            </FluxPaneFooter>
        </FluxPane>
    </FluxOverlay>
</template>

<script
    setup
    lang="ts">
    import { ProductService } from '@fancee/api';
    import { BarcodeImport, CsvDelimiter, ProductOrigin, TicketFilter } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationNotice } from '@/components/form';
    import { useActiveOrganizationId, useService, useValidationScope } from '@/composable';
    import { BarcodeFieldType, MAX_VALUE_BARCODE_IMPORT_ROWS } from '@/data';
    import { CsvAdapter } from '@/data/adapter/file/CsvAdapter';
    import { getDayRange, guarded } from '@/util';
    import GenerateBarcodes from '@/product/ticketing/views/dashboard/organization/events/tickets/GenerateBarcodes.vue';
    import ImportBarcodes from '@/product/ticketing/views/dashboard/organization/events/tickets/ImportBarcodes.vue';

    export interface Emits {
        (e: 'close'): void;
    }

    export interface Props {
        readonly isOpen: boolean;
        readonly filter: TicketFilter;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {filter} = toRefs(props);

    const {t} = useI18n();
    const {generateBarcodes, importBarcodes} = useService(ProductService);
    const {invalid, validate} = useValidationScope();
    const organizationId = useActiveOrganizationId();

    const _generateBarcodes = guarded(generateBarcodes, t('ui.somethingWentWrong.title'), t('event.addBarcodesOverlay.generateError'));
    const _importBarcodes = guarded(importBarcodes, t('ui.somethingWentWrong.title'), t('event.addBarcodesOverlay.importError'));

    const selectedEventId = ref<string | null>(null);
    const selectedProductId = ref<string | null>(null);
    const addingBarcodes = ref(false);
    const selectedTabIndex = ref(0);
    const amount = ref(0);
    const file = ref<File | null>(null);
    const delimiterName = ref(CsvDelimiter.Comma);
    const hasHeader = ref(false);
    const fieldMappings = ref<{ id: string | null, label: string }[]>([]);
    const totalRows = ref(0);

    const validateImport = computed<string[]>(() => {
        let errors: string[] = [];

        if (unref(selectedTabIndex) === 1) {
            if (unref(totalRows) > MAX_VALUE_BARCODE_IMPORT_ROWS) {
                errors.push(t('event.addBarcodesOverlay.importMax', {amount: MAX_VALUE_BARCODE_IMPORT_ROWS}));
            }

            if (unref(file) && CsvAdapter.fieldMappingIndexByFieldType(BarcodeFieldType.Barcode, unref(fieldMappings)) === null) {
                errors.push(t('event.addBarcodesOverlay.importMissingBarcode'));
            }

            let fields = fieldMappings.value
                .filter(fm => fm.id !== null)
                .map(item => item.id);

            if (fields.some((item, idx) => fields.indexOf(item) !== idx)) {
                errors.push(t('event.addBarcodesOverlay.importDuplicateFound'));
            }
        }

        return errors;
    });

    function closeOverlay(): void {
        clearSelection();
        emit('close');
    }

    async function generateBarcodesForOrganization(): Promise<void> {
        if (!await validate()) {
            return;
        }

        addingBarcodes.value = true;

        try {
            await _generateBarcodes(unref(organizationId), unref(selectedProductId)!, unref(amount));

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                title: t('event.addBarcodesOverlay.success.title'),
                message: t('event.addBarcodesOverlay.success.message', {amount: unref(amount)})
            });

            filter.value.origins = [ProductOrigin.PlatformGenerated];
            filter.value.eventIds = [unref(selectedEventId)!];
            filter.value.dateSpan = getDayRange();
        } finally {
            addingBarcodes.value = false;
            closeOverlay();
        }
    }

    async function importBarcodesForOrganization(): Promise<void> {
        if (!await validate()) {
            return;
        }

        addingBarcodes.value = true;

        try {
            await _importBarcodes(
                unref(organizationId),
                unref(selectedProductId)!,
                new BarcodeImport(
                    unref(file)!,
                    CsvAdapter.fieldMappingIndexByFieldType(BarcodeFieldType.Barcode, unref(fieldMappings))!,
                    CsvAdapter.fieldMappingIndexByFieldType(BarcodeFieldType.EmailAddress, unref(fieldMappings)),
                    CsvAdapter.fieldMappingIndexByFieldType(BarcodeFieldType.FirstName, unref(fieldMappings)),
                    CsvAdapter.fieldMappingIndexByFieldType(BarcodeFieldType.LastName, unref(fieldMappings)),
                    unref(delimiterName),
                    unref(hasHeader)
                )
            );

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                title: t('event.addBarcodesOverlay.success.title'),
                message: t('event.addBarcodesOverlay.success.message')
            });

            filter.value.origins = [ProductOrigin.PlatformImported];
            filter.value.eventIds = [unref(selectedEventId)!];
            filter.value.dateSpan = getDayRange();
        } finally {
            addingBarcodes.value = false;
            closeOverlay();
        }
    }

    function clearSelection(): void {
        selectedEventId.value = null;
        selectedProductId.value = null;
        amount.value = 0;
        fieldMappings.value = [];
        file.value = null;
        hasHeader.value = false;
        delimiterName.value = CsvDelimiter.Comma;
        totalRows.value = 0;
    }

    watch(selectedTabIndex, () => {
        clearSelection();
    });
</script>
