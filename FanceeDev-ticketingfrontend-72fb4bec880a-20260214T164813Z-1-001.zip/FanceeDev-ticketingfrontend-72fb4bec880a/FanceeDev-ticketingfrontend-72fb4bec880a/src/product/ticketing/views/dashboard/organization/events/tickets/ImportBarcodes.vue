<template>
    <FluxStack :gap="15">
        <ValidationField
            :label="t('event.singular')"
            :rules="{required}"
            :value="selectedEventId">
            <FluxFormSelectAsync
                v-model="selectedEventId"
                :placeholder="t('event.addBarcodesOverlay.selectEvent')"
                :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>
        </ValidationField>

        <ValidationField
            v-if="selectedEventId"
            :label="t('event.productSingular')"
            :rules="{required}"
            :value="selectedProductId">
            <FluxFormSelectAsync
                v-model="selectedProductId"
                :placeholder="t('event.addBarcodesOverlay.selectProduct')"
                :fetch-options="fetchSelect(async (ids: string[]) => await getEventProductOptions(organizationId, [selectedEventId!], null, ids))"
                :fetch-relevant="fetchSelect(async () => await getEventProductOptions(organizationId, [selectedEventId!], null))"
                :fetch-search="fetchSelect(async (searchQuery: string) => await getEventProductOptions(organizationId, [selectedEventId!], null, searchQuery))"/>
        </ValidationField>

        <ValidationField
            v-if="!file"
            :label="t('global.upload')"
            :rules="{required}"
            :value="file">
            <FluxDropZone
                accept=".csv"
                is-empty
                placeholder-icon="file"
                :placeholder-button="t('ui.csvUpload.button')"
                :placeholder-message="t('ui.csvUpload.message')"
                @select="setFile"/>
        </ValidationField>

        <template v-else>
            <FluxFormField :label="t('ui.csvUpload.hasHeader')">
                <FluxToggle
                    v-model="hasHeader"
                    class="toggle-form-row-offset"/>
            </FluxFormField>

            <FluxPane class="table-pane">
                <table class="field-type-table">
                    <FluxTableRow>
                        <FluxTableHeader>{{ t('ui.csvUpload.exampleData') }}</FluxTableHeader>
                        <FluxTableHeader>{{ t('ui.csvUpload.fieldType') }}</FluxTableHeader>
                    </FluxTableRow>

                    <FluxTableRow
                        v-for="(column, index) in csvPreviewRows[hasHeader ? 1 : 0]"
                        :key="index">
                        <FluxTableCell class="align-field-mapping-items-center">
                            {{ column }}
                        </FluxTableCell>

                        <FluxTableCell>
                            <FluxFormInputGroup>
                                <FluxFormSelect
                                    v-if="fieldMappings.length > 0"
                                    v-model="fieldMappings[index].id"
                                    class="field-type-table-offset"
                                    :options="fieldOptions"/>

                                <FluxSecondaryButton
                                    v-if="fieldMappings[index]?.id !== null"
                                    icon-before="xmark"
                                    @click="fieldMappings[index].id = null"/>
                            </FluxFormInputGroup>
                        </FluxTableCell>
                    </FluxTableRow>
                </table>
            </FluxPane>
        </template>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { SelectService } from '@fancee/api';
    import { CsvDelimiter } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { BarcodeFieldType } from '@/data';
    import { CsvAdapter } from '@/data/adapter/file/CsvAdapter';
    import { required } from '@/data/validation';
    import { fetchSelect } from '@/util';

    export interface Emits {
        (e: 'selected-event-id-changed', eventId: string | null): void;

        (e: 'selected-product-id-changed', productId: string | null): void;

        (e: 'field-mapping-changed', fieldMappings: { id: string | null, label: string }[]): void;

        (e: 'file-changed', file: File | null): void;

        (e: 'delimiter-name-changed', delimiter: CsvDelimiter): void;

        (e: 'has-header-changed', hasHeader: boolean): void;

        (e: 'total-rows-changed', totalRows: number): void;
    }

    const emit = defineEmits<Emits>();

    const {t} = useI18n();
    const {getEventOptions, getEventProductOptions} = useService(SelectService);
    const organizationId = useActiveOrganizationId();

    const selectedEventId = ref<string | null>(null);
    const selectedProductId = ref<string | null>(null);
    const csvPreviewRows = ref<string[][]>([]);
    const file = ref<File | null>(null);
    const delimiterName = ref(CsvDelimiter.Comma);
    const hasHeader = ref(false);
    const fieldMappings = ref<{ id: string | null, label: string }[]>([]);
    const totalRows = ref(0);

    const fieldOptions = ref<FluxFormSelectOption[]>([
        {id: BarcodeFieldType.Barcode, label: t('event.addBarcodesOverlay.fieldType.barcode')},
        {id: BarcodeFieldType.EmailAddress, label: t('event.addBarcodesOverlay.fieldType.email')},
        {id: BarcodeFieldType.FirstName, label: t('event.addBarcodesOverlay.fieldType.firstName')},
        {id: BarcodeFieldType.LastName, label: t('event.addBarcodesOverlay.fieldType.lastName')}
    ]);

    function setFile(files: FileList): void {
        file.value = files.item(0);

        if (!unref(file)) {
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            let result = reader.result;

            if (!result) {
                return;
            }

            result = result.toString();

            totalRows.value = result.split('\n').length;

            delimiterName.value = CsvAdapter.detectDelimiter(result);
            csvPreviewRows.value = CsvAdapter.csvStringToRowColumns(result, unref(delimiterName), 2);

            for (let i = 0; i < csvPreviewRows.value[0].length; i++) {
                fieldMappings.value.push({id: null, label: ''});
            }
        };

        reader.readAsText(unref(file)!);
    }

    watch(selectedEventId, () => {
        emit('selected-event-id-changed', unref(selectedEventId));
        selectedProductId.value = null;
    });

    watch(selectedProductId, () => emit('selected-product-id-changed', unref(selectedProductId)));

    watch(file, () => emit('file-changed', unref(file)));

    watch(delimiterName, () => emit('delimiter-name-changed', unref(delimiterName)));

    watch(hasHeader, () => emit('has-header-changed', unref(hasHeader)));

    watch(fieldMappings, () => emit('field-mapping-changed', unref(fieldMappings)), {deep: true});

    watch(totalRows, () => emit('total-rows-changed', unref(totalRows)));
</script>

<style
    lang="scss"
    scoped>
    .table-pane {
        margin-top: 15px;
    }

    .field-type-table {
        width: 100%;
    }

    .field-type-table-offset {
        margin-bottom: 6px;
    }
</style>

<style lang="scss">
    .align-field-mapping-items-center > .flux-table-cell-content {
        align-items: center;
    }
</style>
