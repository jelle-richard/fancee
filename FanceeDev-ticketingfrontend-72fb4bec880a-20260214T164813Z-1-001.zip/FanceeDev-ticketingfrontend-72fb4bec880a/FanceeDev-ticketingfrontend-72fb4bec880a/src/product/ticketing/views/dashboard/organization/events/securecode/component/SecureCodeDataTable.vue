<template>
    <FluxDataTable
        :data-set="items"
        :is-loading="isLoading"
        :page="currentPage"
        :per-page="pageLength"
        :total="totalItems"
        is-hoverable>
        <template #header>
            <FluxTableHeader>{{ t('event.secureCode.table.code') }}</FluxTableHeader>
            <FluxTableHeader>{{ t('event.secureCode.table.createdOn') }}</FluxTableHeader>
            <FluxTableHeader>{{ t('event.secureCode.table.uses') }}</FluxTableHeader>
            <FluxTableHeader is-shrinking/>
        </template>

        <template #code="{row: {code}}">
            <FluxTableCell>
                {{ code }}
            </FluxTableCell>
        </template>

        <template #createdOn="{row: {createdOn}}">
            <FluxTableCell>
                {{ formatDateTime(createdOn) }}
            </FluxTableCell>
        </template>

        <template #maximumUses="{row: {maximumUses, usedAmount, pendingAmount}}">
            <FluxTableCell>
                <FluxTooltip :content="t('event.secureCode.table.codeUsages', {usedAmount, maximumUses, pendingAmount, slash: maximumUses !== null ? '/' : ''})">
                    <span>{{ usedAmount }}<span v-if="maximumUses">/</span>{{ maximumUses }}</span>
                </FluxTooltip>
            </FluxTableCell>
        </template>

        <template #active="{row: {code, usedAmount, pendingAmount}}">
            <FluxTableCell>
                <FluxTableActions>
                    <FluxAction
                        v-if="usedAmount === 0 && pendingAmount === 0"
                        destructive
                        icon="trash"
                        @click="onDeleteSecureCodeClicked(code)"/>
                </FluxTableActions>
            </FluxTableCell>
        </template>
    </FluxDataTable>
</template>

<script
    setup
    lang="ts">
    import { SecureCodeListing } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { formatDateTime } from '@/util';

    export type Emits = {
        (e: 'delete', code: string): void;
    };

    export type Props = {
        readonly currentPage: number;
        readonly isLoading: boolean;
        readonly isReadonly?: boolean;
        readonly items: SecureCodeListing[];
        readonly pageLength: number;
        readonly totalItems: number;
    };

    const emit = defineEmits<Emits>();
    defineProps<Props>();

    const {t} = useI18n();

    function onDeleteSecureCodeClicked(code: string): void {
        emit('delete', code);
    }
</script>
