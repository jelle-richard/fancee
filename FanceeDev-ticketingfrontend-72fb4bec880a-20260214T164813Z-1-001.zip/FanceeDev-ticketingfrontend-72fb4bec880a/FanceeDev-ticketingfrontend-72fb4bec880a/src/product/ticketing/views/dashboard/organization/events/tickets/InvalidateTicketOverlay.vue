<template>
    <ModalFormOverlay
        :title="t('event.ticket.single.info.advanced.invalidate.title')"
        :explanation="t('event.ticket.single.info.advanced.invalidate.explanation')"
        :ok-disabled="invalid"
        :is-loading="isInvalidating"
        @cancel="closeCancellation"
        @ok="validated(invalidateTicket)">
        <ValidationNotice pane-body/>

        <FluxPaneBody>
            <FluxStack>
                <FluxFormField :label="t('event.ticket.single.info.advanced.invalidate.returnToStock')">
                    <FluxToggle v-model="returnToStock"/>
                </FluxFormField>

                <ValidationField
                    is-optional
                    :label="t('form.field.reason')"
                    :rules="{maxLength: maxLength(450)}"
                    :current-length="reason?.length ?? 0"
                    :hint="t('event.ticket.single.info.advanced.invalidate.giveReason')"
                    :max-length="450"
                    :value="reason">
                    <FluxFormTextArea
                        v-model="reason"
                        :max-length="450"
                        :rows="3"/>
                </ValidationField>
            </FluxStack>
        </FluxPaneBody>
    </ModalFormOverlay>
</template>

<script
    setup
    lang="ts">
    import { ProductService } from '@fancee/api';
    import { showSnackbar } from '@fancee/flux';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { ModalFormOverlay } from '@/components/ui';
    import { maxLength } from '@/data/validation';
    import { ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService, useValidationScope } from '@/composable';
    import { guarded } from '@/util';

    export type Emits = {
        (e: 'close'): void;
        (e: 'ticket-invalidated'): void;
    }

    export type Props = {
        readonly code: string;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {code} = toRefs(props);

    const {t} = useI18n();
    const {invalidate} = useService(ProductService);
    const {invalid, validated} = useValidationScope();
    const organizationId = useActiveOrganizationId();

    const _invalidate = guarded(invalidate, t('ui.somethingWentWrong.title'), t('event.ticket.single.info.advanced.invalidate.failed'));

    const reason = ref<string | null>(null);
    const returnToStock = ref(true);
    const isInvalidating = ref(false);

    function closeCancellation(): void {
        reason.value = null;
        emit('close');
    }

    async function invalidateTicket(): Promise<void> {
        isInvalidating.value = true;

        try {
            await _invalidate(unref(organizationId), unref(code), unref(reason), unref(returnToStock));

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('event.ticket.single.info.advanced.invalidate.success')
            });

            emit('ticket-invalidated');
        } finally {
            isInvalidating.value = false;
            closeCancellation();
        }
    }
</script>
