<template>
    <ShopElement
        :internal-id="element.internalId"
        :editor-elements="editorElements"
        :editor-elements-emit="editorElementsEmit"
        is-indented
        @edit="edit">
        <template #edit>
            <FluxPaneBody>
                <FluxFormColumn>
                    <ValidationField
                        :current-length="localElement.title.length"
                        :max-length="50"
                        :label="t('event.create.shops.element.textBlock.title')"
                        :rules="{required, minLength: minLength(3), maxLength: maxLength(50)}"
                        :value="localElement.title">
                        <FluxFormInput
                            v-model="localElement.title"
                            data-testid="create-event-shop-element-add-text-block-title"
                            :placeholder="t('event.create.shops.element.textBlock.titlePlaceholder')"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('event.create.shops.element.textBlock.text')"
                        :rules="{required, minLength: minLength(3)}"
                        :value="localElement.text">
                        <FluxFormTextArea
                            v-model="localElement.text"
                            data-testid="create-event-shop-element-add-text-block-text"
                            :placeholder="t('event.create.shops.element.textBlock.textPlaceholder')"
                            :rows="3"/>
                    </ValidationField>
                </FluxFormColumn>
            </FluxPaneBody>
        </template>

        <div class="shop-text-block">
            <h2>{{ element.title }}</h2>
            <p>{{ element.text }}</p>
        </div>
    </ShopElement>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopElement, CreateEventShopTextBlockElement } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { maxLength, minLength, required } from '@/data/validation';
    import ShopElement from './ShopElement.vue';
    import { ref, toRefs, unref } from 'vue';

    export interface Props {
        readonly editorElements: CreateEventShopElement[];
        readonly editorElementsEmit: Function;
        readonly element: CreateEventShopTextBlockElement;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const {t} = useI18n();

    const localElement = ref(new CreateEventShopTextBlockElement(unref(element).text, unref(element).title));

    function edit(commitChanges: boolean): void {
        if (commitChanges) {
            element.value.title = unref(localElement).title;
            element.value.text = unref(localElement).text;
            return;
        }

        localElement.value = new CreateEventShopTextBlockElement(unref(element).text, unref(element).title);
    }
</script>
