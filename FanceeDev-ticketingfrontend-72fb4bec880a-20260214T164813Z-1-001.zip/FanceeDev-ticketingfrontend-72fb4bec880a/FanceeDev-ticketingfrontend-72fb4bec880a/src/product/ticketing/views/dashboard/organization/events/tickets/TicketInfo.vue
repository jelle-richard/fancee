<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="t('event.ticket.single.title')">
            <FluxSecondaryButton
                icon-before="xmark"
                @click="close()"/>
        </FluxPaneHeader>

        <template v-if="ticket">
            <FluxExpandableGroup>
                <FluxExpandable :label="t('event.ticketSingular')">
                    <FluxGrid
                        :columns="2"
                        :gap="18">
                        <FluxFormField :label="t('event.ticket.single.info.name')">
                            {{ ticket.ticketName }}
                        </FluxFormField>

                        <FluxFormField :label="t('event.ticket.single.info.code')">
                            {{ ticket.code }}
                        </FluxFormField>

                        <FluxFormField
                            v-if="ticket.label"
                            :label="t('event.ticket.single.info.seatLocation')">
                            {{ ticket.label }}
                        </FluxFormField>

                        <FluxFormField
                            :label="t('event.ticket.single.info.ticketState')">
                            {{ ticket.ticketState }}
                        </FluxFormField>

                        <FluxFormField
                            v-if="ticket.orderId !== null"
                            :label="t('event.ticket.single.info.viewOrder')">
                            <FluxButtonStack>
                                <FluxSecondaryButton
                                    icon-before="ticket"
                                    :label="t('global.view')"
                                    @click="$emit('navigate-to-order', ticket.orderId)"/>
                            </FluxButtonStack>
                        </FluxFormField>

                        <FluxFormField :label="t('event.ticket.single.info.scanStatus')">
                            <span v-if="ticket.scanState">{{ t(`event.scanState.${toCamelCase(ticket.scanState)}`) }} <em>({{ ticket.scanTime }})</em></span>
                            <span v-else>{{ t('event.scanState.notScanned') }}</span>

                            <FluxButtonStack>
                                <FluxSecondaryButton
                                    v-if="DateTime.utc() >= ticket.eventStartDate"
                                    icon-before="qrcode"
                                    :is-loading="isUpdatingScanState"
                                    :label="ticket.scanState === ScanState.Scanned ? t('event.ticket.single.info.markUnscanned') : t('event.ticket.single.info.markScanned')"
                                    @click="updateScanState"/>
                            </FluxButtonStack>
                        </FluxFormField>
                    </FluxGrid>
                </FluxExpandable>

                <FluxExpandable
                    v-if="ticket.origin !== ProductOrigin.PlatformImported"
                    :label="t('event.ticket.single.client.title')">
                    <FluxGrid
                        :columns="2"
                        :gap="18">
                        <FluxFormField
                            v-if="ticket.orderId !== null"
                            :label="t('event.ticket.single.client.boughtInShop')">
                            {{ ticket.shopName }}
                        </FluxFormField>

                        <FluxFormField :label="t('event.ticket.single.client.belongsTo')">
                            {{ ticket.eventName }}
                        </FluxFormField>

                        <template v-if="ticket.client">
                            <FluxFormField
                                v-if="ticket.client.firstName || ticket.client.lastName"
                                :label="t('event.ticket.single.client.boughtBy')">
                                {{ ticket.client.firstName }} {{ ticket.client.lastName }}
                            </FluxFormField>

                            <FluxFormField :label="t('form.field.email')">
                                <a :href="`mailto:${ticket.client.email}`">{{ ticket.client.email }}</a>
                            </FluxFormField>

                            <FluxFormField
                                v-if="ticket.client.phoneNumber"
                                :label="t('form.field.phoneNumber')">
                                <a :href="`tel:${ticket.client.phoneNumber}`">{{ ticket.client.phoneNumber }}</a>
                            </FluxFormField>

                            <FluxFormField
                                v-if="ticket.client.age"
                                :label="t('form.field.age')">
                                {{ ticket.client.age }}
                            </FluxFormField>

                            <FluxFormField
                                v-if="ticket.client.gender"
                                :label="t('form.field.gender')">
                                {{ t(`global.gender.${ticket.client.gender.toLowerCase()}`) }}
                            </FluxFormField>

                            <FluxFormField
                                v-if="ticket.client.optInPromotionalEmail || ticket.client.optInPromotionalSms"
                                :label="t('event.ticket.single.client.optins.label')">
                                <FluxBadge
                                    v-if="ticket.client.optInPromotionalEmail"
                                    :label="t('event.ticket.single.client.optins.email')"/>

                                <FluxBadge
                                    v-if="ticket.client.optInPromotionalSms"
                                    :label="t('event.ticket.single.client.optins.sms')"/>
                            </FluxFormField>

                            <FluxFormField :label="t('event.ticket.single.client.enabledTsp')">
                                {{ ticket.client.enabledTicketServicePlus ? t('global.yes') : t('global.no') }}
                            </FluxFormField>

                            <FluxFormField :label="t('event.ticket.single.client.enabledSms')">
                                {{ ticket.client.receiveViaSms ? t('global.yes') : t('global.no') }}
                            </FluxFormField>
                        </template>
                    </FluxGrid>
                </FluxExpandable>

                <FluxExpandable
                    v-if="!isEmptyHolder && ticket.holder"
                    :label="t('event.ticket.single.holder.title')">
                    <FluxFormField
                        v-if="ticket.holder.firstname || ticket.holder.lastname"
                        :label="t('form.field.name')">
                        {{ ticket.holder.firstname }} {{ ticket.holder.lastname }}
                    </FluxFormField>

                    <FluxFormField
                        v-if="ticket.holder.email"
                        :label="t('form.field.email')">
                        <a :href="`mailto:${ticket.holder.email}`">{{ ticket.holder.email }}</a>
                    </FluxFormField>
                </FluxExpandable>

                <FluxExpandable
                    v-if="ticket.ticketState === TicketState.Active"
                    :label="t('event.ticket.single.info.advanced.title')">
                    <FluxSecondaryButton
                        icon-before="qrcode"
                        :label="t('event.ticket.single.info.advanced.invalidate.title')"
                        @click="confirmingInvalidateTicket = true"/>
                </FluxExpandable>
            </FluxExpandableGroup>
        </template>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxSecondaryButton
                :label="t('global.close')"
                @click="close"/>
        </FluxPaneFooter>
    </FluxPane>

    <FluxOverlay
        v-if="confirmingInvalidateTicket"
        is-closeable
        size="small"
        @close="confirmingInvalidateTicket = false">
        <InvalidateTicketOverlay
            :code="code"
            @close="confirmingInvalidateTicket = false"
            @ticketInvalidated="invalidateTicket"/>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { ProductService, ScanService } from '@fancee/api';
    import { ProductOrigin, ScanState, TicketInformation, TicketState } from '@fancee/data';
    import { showConfirm, showSnackbar } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { toCamelCase } from '@/util';
    import InvalidateTicketOverlay from '@/product/ticketing/views/dashboard/organization/events/tickets/InvalidateTicketOverlay.vue';

    export type Emits = {
        (e: 'close'): void;
        (e: 'navigate-to-order', orderId: string): void;
        (e: 'update-scan-state', code: string, scanState: ScanState, scanTime: DateTime): void;
    };

    export type Props = {
        readonly code: string;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {t} = useI18n();
    const {getTicket} = useService(ProductService);
    const {updateState} = useService(ScanService);
    const organizationId = useActiveOrganizationId();

    const isLoading = ref(false);
    const isUpdatingScanState = ref(false);
    const confirmingInvalidateTicket = ref(false);
    const ticket = ref<TicketInformation | null>(null);

    const isEmptyHolder = computed((): boolean => {
        const holder = unref(ticket)!.holder;

        return holder === null || (holder.firstname === null && holder.lastname === null && holder.email === null);
    });

    function close(): void {
        emit('close');
    }

    function invalidateTicket(): void {
        let _ticket = unref(ticket);
        if (_ticket === null)
            return;

        _ticket.ticketState = TicketState.Invalidated;
    }

    async function loadTicket(): Promise<void> {
        isLoading.value = true;

        try {
            const {data} = await getTicket(unref(organizationId), props.code);
            ticket.value = data;
        } catch (err) {
            close();
            throw err;
        } finally {
            isLoading.value = false;
        }
    }

    async function updateScanState(): Promise<void> {
        if (!ticket.value) {
            return;
        }

        const {code, scanState} = ticket.value;
        const newScanState = scanState === ScanState.Scanned ? ScanState.Unscanned : ScanState.Scanned;

        const updateConfirmed = await showConfirm({
            icon: 'qrcode',
            message: t('event.ticket.single.info.scanStateConfirm', {
                code: code,
                state: t(scanState === ScanState.Scanned ? 'event.scanState.unscanned' : 'event.scanState.scanned')
            }),
            title: t(scanState === ScanState.Scanned ? 'event.ticket.single.info.markUnscanned' : 'event.ticket.single.info.markScanned')
        });

        if (!updateConfirmed) {
            return;
        }

        isUpdatingScanState.value = true;

        try {
            const {data: {notification}} = await updateState(unref(organizationId), code, newScanState);

            ticket.value.scanState = newScanState;
            ticket.value.scanTime = DateTime.now();

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                title: t('event.ticket.single.info.scanStateUpdated'),
                message: notification && notification.trim().length > 0 ? notification : undefined
            });

            emit('update-scan-state', code, newScanState, DateTime.now());
        } catch (err) {
            close();
            throw err;
        } finally {
            isUpdatingScanState.value = false;
        }
    }

    watch(() => props.code, async () => await loadTicket(), {immediate: true});
</script>
