<template>
    <FluxPane :is-loading="isRedirecting">
        <FluxActionBar
            :is-resettable="filter.isResettable"
            @reset="filter.reset()">
            <template #primary>
                <FluxSecondaryButton
                    icon-before="circle-plus"
                    :label="t('event.ticket.addBarcodes')"
                    type="button"
                    @click="addBarcodesOverlayOpened = true"/>
            </template>

            <template #filter>
                <FluxFilter
                    v-model="filter"
                    :resettable="filter.resettable"
                    @reset="(field: string) => filter.reset(field)">
                    <FluxFilterDateRange
                        icon="calendar"
                        :label="t('global.filter.date')"
                        name="dateSpan"/>

                    <FluxFilterOption
                        icon="qrcode"
                        :label="t('event.ticket.filter.scanState')"
                        name="scanState"
                        :options="scanStateFilterOptions"/>

                    <FluxSeparator/>

                    <FluxFilterOptionsAsync
                        icon="calendar"
                        :label="t('event.singular')"
                        :search-placeholder="t('flux.search')"
                        name="eventIds"
                        :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                        :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                        :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>

                    <FluxFilterOptionsAsync
                        icon="shopping-bag"
                        :label="t('event.shopSingular')"
                        :search-placeholder="t('flux.search')"
                        name="shopCodes"
                        :fetch-options="fetchSelect(async (ids: string[]) => await getShopOptions(organizationId, filter.eventIds, ids))"
                        :fetch-relevant="fetchSelect(async () => await getShopOptions(organizationId, filter.eventIds))"
                        :fetch-search="fetchSelect(async (searchQuery: string) => await getShopOptions(organizationId, filter.eventIds, searchQuery))"/>

                    <FluxSeparator/>

                    <FluxFilterOptions
                        icon="star-of-life"
                        :label="t('event.ticket.filter.acquirerOrigin')"
                        name="origins"
                        :options="originFilterOptions"/>

                    <FluxFilterOption
                        icon="envelope"
                        :label="t('event.ticket.filter.promotionalEmail')"
                        name="optInPromotionalEmail"
                        :options="communicationFilterOptions"/>

                    <FluxFilterOption
                        icon="comment-sms"
                        :label="t('event.ticket.filter.promotionalSms')"
                        name="optInPromotionalSms"
                        :options="communicationFilterOptions"/>

                    <FluxFilterOption
                        icon="comment-sms"
                        :label="t('event.ticket.filter.receiveOrderSms')"
                        name="receiveViaSms"
                        :options="communicationFilterOptions"/>
                </FluxFilter>
            </template>

            <template #actions-before-search>
                <ToolbarDownload
                    :is-loading="isDownloading"
                    @download="onDownloadTicketsClicked"/>
            </template>

            <template #search>
                <ToolbarSearch
                    v-model="filter.searchQuery"
                    :placeholder="t('event.ticket.searchPlaceholder')"/>
            </template>
        </FluxActionBar>

        <FluxDataTable
            :data-set="tickets"
            :is-loading="isLoading"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems"
            is-hoverable>
            <template #header>
                <FluxTableHeader>{{ t('event.ticket.table.event') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.shop') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.ticket') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.code') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.holder') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.origin') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.scanStatus') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.state') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('event.ticket.table.scanTime') }}</FluxTableHeader>
                <FluxTableHeader/>
            </template>

            <template #eventName="{row: {eventName}}">
                <FluxTableCell>{{ eventName }}</FluxTableCell>
            </template>

            <template #shopName="{row: {shopName}}">
                <FluxTableCell>{{ shopName ?? '&mdash;' }}</FluxTableCell>
            </template>

            <template #productName="{row: {productName}}">
                <FluxTableCell>{{ productName }}</FluxTableCell>
            </template>

            <template #code="{row: {code}}">
                <FluxTableCell><code>{{ code }}</code></FluxTableCell>
            </template>

            <template #holder="{row: {email, name}}">
                <FluxTableCell>
                    {{ email ?? '&mdash;' }}
                    <span v-if="(name?.length ?? 0) > 0">
                        &nbsp;({{ name }})
                    </span>
                </FluxTableCell>
            </template>

            <template #origin="{row: {origin}}">
                <FluxTableCell>
                    <FluxTooltip
                        v-if="origin === ProductOrigin.PlatformShop"
                        :content="t('event.ticket.origin.shop')">
                        <FluxIcon variant="shopping-bag"/>
                    </FluxTooltip>

                    <FluxTooltip
                        v-else-if="origin === ProductOrigin.PlatformApp"
                        :content="t('event.ticket.origin.app')">
                        <FluxIcon variant="mobile-notch"/>
                    </FluxTooltip>

                    <FluxTooltip
                        v-else-if="origin === ProductOrigin.PlatformImported"
                        :content="t('event.ticket.origin.imported')">
                        <FluxIcon variant="arrow-up-from-line"/>
                    </FluxTooltip>

                    <FluxTooltip
                        v-else-if="origin === ProductOrigin.PlatformGuestList"
                        :content="t('event.ticket.origin.guestlist')">
                        <FluxIcon variant="user-plus"/>
                    </FluxTooltip>

                    <FluxTooltip
                        v-else-if="origin === ProductOrigin.PlatformGenerated"
                        :content="t('event.ticket.origin.generated', {name: PLATFORM_NAME})">
                        <FluxIcon variant="file-code"/>
                    </FluxTooltip>

                    <FluxTooltip
                        v-else-if="origin === ProductOrigin.TicketSwap"
                        :content="t('event.ticket.origin.ticketswap', {name: PLATFORM_NAME})">
                        <img
                            :src="ticketswapLogo"
                            alt="ticketswap"
                            class="partner-origin-logo"/>
                    </FluxTooltip>
                </FluxTableCell>
            </template>

            <template #scanState="{row: {scanState}}">
                <FluxTableCell>{{ scanState !== null ? t(`event.scanState.${toCamelCase(scanState)}`) : '&mdash;' }}</FluxTableCell>
            </template>

            <template #ticketState="{row: {ticketState}}">
                <FluxTableCell>{{ ticketState }}</FluxTableCell>
            </template>

            <template #scanTime="{row: {scanTime}}">
                <FluxTableCell>{{ scanTime === null ? '&mdash;' : formatDateTime(scanTime) }}</FluxTableCell>
            </template>

            <template #actions="{row: {code}}">
                <FluxTableCell>
                    <FluxTableActions>
                        <FluxTooltip :content="t('global.show')">
                            <FluxAction
                                icon="eye"
                                @click="selectedTicketCode = code"/>
                        </FluxTooltip>
                    </FluxTableActions>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>

    <FluxSlideOver
        is-closeable
        @close="selectedTicketCode = null">
        <TicketInfo
            v-if="selectedTicketCode"
            :code="selectedTicketCode"
            @close="selectedTicketCode = null"
            @navigate-to-order="navigateToOrder"
            @update-scan-state="onUpdateScanState"/>
    </FluxSlideOver>

    <AddBarcodesOverlay
        :is-open="addBarcodesOverlayOpened"
        :filter="filter"
        @close="addBarcodesOverlayOpened = false"/>
</template>

<script
    lang="ts"
    setup>
    import { ProductService, SelectService } from '@fancee/api';
    import { ProductOrigin, ScanState, TicketFilter, TicketListing } from '@fancee/data';
    import { FluxFilterOptionItem, showSnackbar } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, onMounted, ref, unref, watch } from 'vue';
    import { ToolbarDownload, ToolbarSearch } from '@/components/filter';
    import { useActiveOrganizationId, usePagination, useRequestErrorBoundary, useRoute, useRouter, useService } from '@/composable';
    import { PLATFORM_NAME, SLIDE_OVER_CLOSE_MS } from '@/data';
    import { downloadBlob, fetchSelect, formatDateTime, toCamelCase } from '@/util';
    import { useI18n } from 'vue-i18n';
    import AddBarcodesOverlay from '@/product/ticketing/views/dashboard/organization/events/tickets/AddBarcodesOverlay.vue';
    import TicketInfo from './TicketInfo.vue';
    import ticketswapLogo from '@/assets/images/logos/partners/ticketswap-logo-small.png?url';

    const {t} = useI18n();
    const {hasErrors, runSandboxed} = useRequestErrorBoundary();
    const {listTicket, csvExportTicket} = useService(ProductService);
    const {getEventOptions, getShopOptions} = useService(SelectService);
    const organizationId = useActiveOrganizationId();
    const route = useRoute();
    const router = useRouter();

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const filter = ref(TicketFilter.default());
    const isDownloading = ref(false);
    const isLoading = ref(true);
    const selectedTicketCode = ref<string | null>(null);
    const tickets = ref<TicketListing[]>([]);
    const addBarcodesOverlayOpened = ref(false);
    const isRedirecting = ref(false);
    const passedOrderId = ref(route.query.orderId);

    const communicationFilterOptions = computed<FluxFilterOptionItem[]>(() => [
        {label: t('global.yes'), value: true},
        {label: t('global.no'), value: false}
    ]);

    const originFilterOptions = computed<FluxFilterOptionItem[]>(() => [
        {label: t('event.ticket.origin.filter.shop'), value: ProductOrigin.PlatformShop},
        {label: t('event.ticket.origin.filter.app'), value: ProductOrigin.PlatformApp},
        {label: t('event.ticket.origin.filter.generated'), value: ProductOrigin.PlatformGenerated},
        {label: t('event.ticket.origin.filter.imported'), value: ProductOrigin.PlatformImported},
        {label: t('event.ticket.origin.filter.guestlist'), value: ProductOrigin.PlatformGuestList},
        {label: t('event.ticket.origin.filter.ticketswap'), value: ProductOrigin.TicketSwap}
    ]);

    const scanStateFilterOptions = computed<FluxFilterOptionItem[]>(() => [
        {label: t('event.scanState.scanned'), value: ScanState.Scanned},
        {label: t('event.scanState.unscanned'), value: ScanState.Unscanned},
        {label: t('event.scanState.notScanned'), value: ScanState.NotScanned}
    ]);

    onMounted(async () => {
        if (!unref(passedOrderId)) {
            await loadTickets();
            return;
        }

        filter.value.searchQuery = unref(passedOrderId) as string;
    });

    async function loadTickets(): Promise<void> {
        isLoading.value = true;

        const {data: {items, totalItems}} = await listTicket(unref(organizationId), unref(pageLength), unref(currentPage), unref(filter));
        tickets.value = items;
        setTotalItems(totalItems);

        isLoading.value = false;
    }

    async function onDownloadTicketsClicked(): Promise<void> {
        isDownloading.value = true;

        await runSandboxed(
            async () => {
                const {blob, name} = await csvExportTicket(unref(organizationId), filter.value);
                downloadBlob(blob, name);
            },
            () => showSnackbar({
                color: 'danger',
                icon: 'circle-exclamation',
                message: t('ui.somethingWentWrong.downloadFailed'),
                title: t('ui.somethingWentWrong.title')
            })
        );

        isDownloading.value = false;
    }

    function navigateToOrder(orderId: string): void {
        selectedTicketCode.value = null;
        isRedirecting.value = true;

        setTimeout(() => router.push({
            name: 'orders',
            query: {orderId}
        }), SLIDE_OVER_CLOSE_MS);
    }

    function onUpdateScanState(code: string, scanState: ScanState, scanTime: DateTime): void {
        const ticket = unref(tickets.value).find(t => t.code === code);

        if (!ticket) {
            return;
        }

        ticket.scanState = scanState;
        ticket.scanTime = scanTime;
    }

    watch(filter, () => currentPage.value = 1, {deep: true});

    watch(hasErrors, () => isLoading.value = false);

    watch([currentPage, pageLength, filter], async () => await loadTickets(), {deep: true});
</script>
