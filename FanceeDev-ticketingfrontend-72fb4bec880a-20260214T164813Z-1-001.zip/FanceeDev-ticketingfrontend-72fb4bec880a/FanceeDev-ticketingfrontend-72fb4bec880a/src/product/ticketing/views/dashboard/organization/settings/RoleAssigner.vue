<template>
    <FluxPane
        is-contained
        :is-loading="isLoading">
        <FluxActionBar>
            <template #primary>
                <FluxPrimaryButton
                    :label="t('global.add')"
                    icon-before="circle-plus"
                    data-testid="role-assign-new-user"
                    @click="assignNewUser()"/>
            </template>
        </FluxActionBar>

        <FluxPaneBody>
            <FluxNotice
                icon="circle-info"
                is-small
                :message="t('settings.roleManagement.notice')"/>
        </FluxPaneBody>

        <template v-if="assignedUsers.length > 0">
            <FluxSeparator/>

            <FluxTable is-hoverable>
                <template #header>
                    <FluxTableHeader is-shrinking/>
                    <FluxTableHeader>{{ t('form.field.name') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('form.field.email') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('form.field.description') }}</FluxTableHeader>
                    <FluxTableHeader is-shrinking/>
                </template>

                <template #rows>
                    <FluxTableRow v-for="user of assignedUsers">
                        <FluxTableCell>
                            <FluxAvatar
                                :fallback-initials="user.firstName && user.lastName ? fullNameToInitials(`${user.firstName} ${user.lastName}`) : 'F'"
                                :size="24"
                                :url="user.avatar?.url"/>
                        </FluxTableCell>

                        <FluxTableCell>
                            <strong>{{ user.firstName }} {{ user.lastName }}</strong>
                        </FluxTableCell>

                        <FluxTableCell>
                            {{ user.email }}
                        </FluxTableCell>

                        <FluxTableCell>
                            {{ user.description }}
                        </FluxTableCell>

                        <FluxTableCell>
                            <FluxTableActions>
                                <FluxAction
                                    icon="pen"
                                    @click="updatedAssignedUser(user.id)"/>

                                <FluxAction
                                    destructive
                                    icon="trash"
                                    @click="deleteAssignedUser(user.id)"/>
                            </FluxTableActions>
                        </FluxTableCell>
                    </FluxTableRow>
                </template>
            </FluxTable>
        </template>
    </FluxPane>

    <FluxSlideOver
        is-closeable
        @close="resetSelection()">
        <OrganizationUserRoleAssignmentConfigurator
            v-if="isConfiguringUser"
            :user="selectedUser"
            :errors="assignmentErrors"
            @add="addOrganizationUser"
            @update="updateOrganizationUser"
            @close="resetSelection()"/>
    </FluxSlideOver>
</template>

<script
    setup
    lang="ts">
    import { OrganizationUserManagementService } from '@fancee/api';
    import { IResponseErrors, isRequestError } from '@fancee/client';
    import { OrganizationUser, OrganizationUserAssignment, OrganizationUserAssignmentUpdate } from '@fancee/data';
    import { showConfirm, showSnackbar } from '@fancee/flux';
    import { onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useLoaded, useService } from '@/composable';
    import { fullNameToInitials, guarded } from '@/util';
    import OrganizationUserRoleAssignmentConfigurator from '@/product/ticketing/views/dashboard/organization/settings/OrganizationUserRoleAssignmentConfigurator.vue';

    const {t} = useI18n();
    const {isLoading, loaded} = useLoaded();
    const {get, add, update, delete: deleteUserAssignment} = useService(OrganizationUserManagementService);
    const organizationId = useActiveOrganizationId();

    const _add = guarded(add, onAddOrganizationUserFailed);
    const _delete = guarded(loaded(deleteUserAssignment), t('ui.somethingWentWrong.title'), t('settings.roleManagement.deleteFailed'));
    const _get = guarded(loaded(get), t('ui.somethingWentWrong.title'), t('settings.roleManagement.loadingFailed'));
    const _update = guarded(update, onUpdateOrganizationUserFailed);

    const assignedUsers = ref<OrganizationUser[]>([]);
    const isConfiguringUser = ref(false);
    const selectedUser = ref<OrganizationUser | null>(null);
    const assignmentErrors = ref<IResponseErrors | null>(null);

    onMounted(async () => await loadAssignedUsers());

    async function loadAssignedUsers(): Promise<void> {
        const {data} = await _get(unref(organizationId));
        assignedUsers.value = data;
    }

    async function deleteAssignedUser(userId: string): Promise<void> {
        const deleteConfirmed = await showConfirm({
            icon: 'trash',
            message: t('ui.confirmDeleteOverlay.messageGeneric'),
            title: t('ui.confirmDeleteOverlay.titleGeneric')
        });

        if (!deleteConfirmed) {
            return;
        }

        await _delete(unref(organizationId), userId);

        assignedUsers.value = unref(assignedUsers).filter(u => u.id !== userId);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('settings.roleManagement.deleteSuccess')
        });
    }

    async function addOrganizationUser(user: OrganizationUserAssignment): Promise<void> {
        await _add(unref(organizationId), user);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('settings.roleManagement.addSuccess')
        });

        await loadAssignedUsers();
        resetSelection();
    }

    async function updateOrganizationUser(user: OrganizationUserAssignmentUpdate): Promise<void> {
        await _update(unref(organizationId), user);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('ui.changesSavedSuccessfully')
        });

        await loadAssignedUsers();
        resetSelection();
    }

    function onAddOrganizationUserFailed(err: Error): void {
        if (isRequestError(err)) {
            assignmentErrors.value = err.errors;
            return;
        }

        showSnackbar({
            color: 'danger',
            icon: 'circle-exclamation',
            title: t('ui.somethingWentWrong.title'),
            message: t('settings.roleManagement.addFailed')
        });

        resetSelection();
    }

    function onUpdateOrganizationUserFailed(): void {
        showSnackbar({
            color: 'danger',
            icon: 'circle-exclamation',
            title: t('ui.somethingWentWrong.title'),
            message: t('settings.roleManagement.updateFailed')
        });

        resetSelection();
    }

    function resetSelection(): void {
        isConfiguringUser.value = false;
        selectedUser.value = null;
        assignmentErrors.value = null;
    }

    function assignNewUser(): void {
        isConfiguringUser.value = true;
    }

    function updatedAssignedUser(userId: string): void {
        isConfiguringUser.value = true;
        selectedUser.value = unref(assignedUsers).find(u => u.id === userId) ?? null;
    }
</script>
