<template>
    <FluxStack
        v-if="user"
        :gap="21">
        <FluxNotice
            icon="circle-exclamation"
            is-small
            :message="t('platform.profile.organization.cannotMakeChanges')"
            variant="info"/>

        <FluxPane>
            <FluxPaneHeader :title="t('platform.profile.organization.holder')"/>

            <FluxPaneBody>
                <FluxFormColumn>
                    <FluxFormField :label="t('form.field.email')">
                        <FluxFormInput
                            is-disabled
                            :model-value="profile.holder.email"/>
                    </FluxFormField>

                    <FluxFormRow>
                        <FluxFormField :label="t('form.field.firstName')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.holder.firstName"
                                type="text"/>
                        </FluxFormField>

                        <FluxFormField :label="t('form.field.lastName')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.holder.lastName"
                                type="text"/>
                        </FluxFormField>
                    </FluxFormRow>
                </FluxFormColumn>
            </FluxPaneBody>
        </FluxPane>

        <FluxPane>
            <FluxPaneHeader :title="t('platform.profile.organization.legalEntity')"/>

            <FluxPaneBody>
                <FluxFormColumn>
                    <FluxFormRow>
                        <FluxFormField :label="t('form.field.organizationName')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.legalEntity.name"
                                type="text"/>
                        </FluxFormField>

                        <FluxFormField :label="t('form.field.country')">
                            <FluxFormSelect
                                is-disabled
                                :model-value="profile.legalEntity.countryCode"
                                :options="SELECT_COUNTRY_OPTIONS"/>
                        </FluxFormField>
                    </FluxFormRow>

                    <FluxFormField :label="t('form.field.chamberOfCommerce')">
                        <FluxFormInput
                            is-disabled
                            :model-value="profile.legalEntity.chamberOfCommerceIdentifier"
                            type="text"/>
                    </FluxFormField>

                    <FluxFormRow>
                        <FluxFormField :label="t('form.field.timezone')">
                            <FluxFormTimeZonePicker
                                is-disabled
                                :model-value="profile.legalEntity.timezoneIdentification"/>
                        </FluxFormField>

                        <FluxFormField :label="t('form.field.phoneNumber')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.legalEntity.phoneNumber"
                                type="text"/>
                        </FluxFormField>
                    </FluxFormRow>
                </FluxFormColumn>
            </FluxPaneBody>
        </FluxPane>

        <FluxPane>
            <FluxPaneHeader :title="t('form.field.address')"/>

            <FluxPaneBody>
                <FluxFormColumn>
                    <FluxFormField :label="t('form.field.address')">
                        <FluxFormInput
                            is-disabled
                            :model-value="profile.address.formatted"/>
                    </FluxFormField>

                    <FluxFormRow>
                        <FluxFormField :label="t('form.field.addressStreet')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.address.street"
                                type="text"/>
                        </FluxFormField>

                        <FluxFormField :label="t('form.field.addressHouseNumber')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.address.houseNumber"
                                type="text"/>
                        </FluxFormField>
                    </FluxFormRow>

                    <FluxFormRow>
                        <FluxFormField :label="t('form.field.addressPostalCode')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.address.postalCode"
                                type="text"/>
                        </FluxFormField>

                        <FluxFormField :label="t('form.field.addressCity')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.address.city"
                                type="text"/>
                        </FluxFormField>
                    </FluxFormRow>
                </FluxFormColumn>
            </FluxPaneBody>
        </FluxPane>

        <FluxPane>
            <FluxPaneHeader :title="t('platform.profile.organization.finance')"/>

            <FluxPaneBody>
                <FluxFormColumn>
                    <FluxFormField :label="t('form.field.currency')">
                        <FluxFormSelect
                            is-disabled
                            :model-value="profile.finance.currency?.shortCode"
                            :options="currencyOptions"/>
                    </FluxFormField>

                    <FluxFormRow>
                        <FluxFormField :label="t('form.field.iban')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.finance.bankAccountIban"
                                pattern="iban"
                                type="text"/>
                        </FluxFormField>

                        <FluxFormField :label="t('form.field.bic')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.finance.bankAccountBic"
                                pattern="bic"
                                type="text"/>
                        </FluxFormField>
                    </FluxFormRow>

                    <FluxFormRow>
                        <FluxFormField :label="t('form.field.vat')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.finance.vatIdentifier"
                                type="text"/>
                        </FluxFormField>

                        <FluxFormField :label="t('onboarding.financial.approximateAnnualSales')">
                            <FluxFormInput
                                is-disabled
                                :model-value="profile.finance.approximatedAnnualSalesAmount"
                                type="text"/>
                        </FluxFormField>
                    </FluxFormRow>
                </FluxFormColumn>
            </FluxPaneBody>
        </FluxPane>

        <FluxPane v-if="organizationContract">
            <FluxPaneFooter>
                <FluxSecondaryButton
                    icon-before="arrow-down-to-line"
                    :is-loading="downloadInProgress"
                    :label="t('platform.profile.organization.downloadContract')"
                    @click="downloadContractZip"/>
            </FluxPaneFooter>
        </FluxPane>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { CurrencyService, UserService } from '@fancee/api';
    import { Currency, OrganizationProfile } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { computed, onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useLoaded, useService, useUser } from '@/composable';
    import { SELECT_COUNTRY_OPTIONS } from '@/data';
    import { usePlatformStore, useStore } from '@/data/store';
    import { convertCurrentyToIcon, downloadBlob, guarded } from '@/util';

    export type Props = {
        readonly profile: OrganizationProfile;
    };

    defineProps<Props>();

    const {t} = useI18n();
    const {isLoading: downloadInProgress, loaded} = useLoaded();
    const {downloadContractAsZip} = useService(UserService);
    const {getActive: getActiveCurrencies} = useService(CurrencyService);
    const {organizationContract} = useStore(usePlatformStore());
    const organizationId = useActiveOrganizationId();
    const user = useUser();

    const _downloadContractAsZip = guarded(loaded(downloadContractAsZip), t('ui.somethingWentWrong.title'), t('onboarding.agreement.downloadFailed'));
    const _getActiveCurrencies = guarded(getActiveCurrencies, t('ui.somethingWentWrong.title'), t('platform.profile.organization.loadCurrenciesFailed'));

    const currencies = ref<Currency[]>([]);

    const currencyOptions = computed(() => unref(currencies).map<FluxFormSelectOption>(c => ({
        id: c.shortCode,
        icon: convertCurrentyToIcon(c),
        label: c.name
    })));

    onMounted(async () => {
        const {data} = await _getActiveCurrencies();
        currencies.value = data;
    });

    async function downloadContractZip(): Promise<void> {
        const {blob, name} = await _downloadContractAsZip(unref(organizationId));
        downloadBlob(blob, name);
    }
</script>
