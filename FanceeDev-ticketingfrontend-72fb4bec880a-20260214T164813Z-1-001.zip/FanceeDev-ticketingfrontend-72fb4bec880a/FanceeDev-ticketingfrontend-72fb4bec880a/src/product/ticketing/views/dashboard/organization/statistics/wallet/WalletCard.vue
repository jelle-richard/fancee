<template>
    <FluxPane
        :is-loading="timedWalletBalances.length === 0"
        :class="$style.balancePane">
        <FluxPaneBody>
            <h2>{{ t('dashboard.wallet.title') }}</h2>

            <h2
                v-if="timedWalletBalances.length > 0">
                {{ asMoney(spendableWalletBalance, timedWalletBalances[timedWalletBalances.length - 1].organizationCurrencyBalance.currency) }}
            </h2>

            <ApexChart
                :key="timedWalletBalances.length"
                type="line"
                height="80"
                :options="chart.options"
                :series="chart.series"/>

            <FluxSecondaryButton
                icon-before="wallet"
                type="route"
                :label="t('dashboard.wallet.manage')"
                :to="{name: 'wallet'}"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { TimedWalletBalanceSetting } from '@fancee/data';
    import { reactive, ref, toRefs, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CHART_COLORS } from '@/data';
    import { asMoney } from '@/util';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        readonly timedWalletBalances: TimedWalletBalanceSetting[];
        readonly walletBalanceHistoricDaysAmount: number;
        readonly containsRedirect?: boolean;
    }

    const props = withDefaults(defineProps<Props>(), {
        containsRedirect: false
    });
    const {timedWalletBalances, walletBalanceHistoricDaysAmount} = toRefs(props);

    const {t} = useI18n();

    const spendableWalletBalance = ref<number>(0);
    const chart = reactive<any>({
        series: [
            {
                data: []
            },
            {
                data: []
            }
        ],
        options: {
            chart: {
                height: 80,
                toolbar: {show: false},
                zoom: {enabled: false},
                type: 'line',
                sparkline: {enabled: true}
            },
            stroke: {
                curve: 'smooth',
                dashArray: [0, 5],
                width: [2]
            },
            colors: CHART_COLORS,
            tooltip: {
                enabled: false
            }
        }
    });

    function updateSpendableBalance(): void {
        spendableWalletBalance.value = timedWalletBalances.value.length > 0
            ? (timedWalletBalances.value[timedWalletBalances.value.length - 1].organizationCurrencyBalance.balanceCents
                - timedWalletBalances.value[timedWalletBalances.value.length - 1].organizationCurrencyBalance.reserveCents
                - timedWalletBalances.value[timedWalletBalances.value.length - 1].organizationCurrencyBalance.pendingCents)
            : 0;
    }

    watch(timedWalletBalances, timedWalletBalances => {
        let balanceLineData: number[] = [];
        let pendingLineData: number[] = [];

        for (let i = 0; i < walletBalanceHistoricDaysAmount.value; i++) {
            let timedWalletBalance: TimedWalletBalanceSetting = timedWalletBalances[i];

            balanceLineData[i] = timedWalletBalance.organizationCurrencyBalance.balanceCents;
            pendingLineData[i] = timedWalletBalance.organizationCurrencyBalance.pendingCents;
        }

        chart['series'][0]['data'] = balanceLineData;
        chart['series'][1]['data'] = pendingLineData;
        updateSpendableBalance();
    });
</script>

<style
    lang="scss"
    module>
    .balancePane {
        text-align: center;

        h2 {
            margin-top: 9px;
        }
    }
</style>
