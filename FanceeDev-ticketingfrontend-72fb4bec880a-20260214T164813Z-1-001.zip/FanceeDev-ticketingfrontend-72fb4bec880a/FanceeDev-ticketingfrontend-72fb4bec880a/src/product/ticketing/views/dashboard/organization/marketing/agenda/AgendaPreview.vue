<template>
    <FluxStack>
        <FluxPane
            :class="$style.eventEditor"
            :tag="t('event.create.shops.designer')">

            <div :class="$style.eventBackground">
                <FluxPane :class="$style.eventBackdrop">
                    <div :class="$style.eventElements">
                        <div
                            v-for="event in previewEvents"
                            :key="event.id"
                            :class="$style.event">
                            <FluxAspectRatio
                                v-if="agenda.design.showHeaders"
                                :class="$style.eventImage"
                                :aspect-ratio="4 / 3">

                                <FluxFader
                                    v-if="event.headerImages.length > 0"
                                    :interval="FADER_INTERVAL_MS">
                                    <FluxFaderItem
                                        v-for="{id, focalPoint, url} of event.headerImages"
                                        :key="id">
                                        <FluxFocalPointImage
                                            :focal-point="focalPoint"
                                            :src="url"
                                            alt=""/>
                                    </FluxFaderItem>
                                </FluxFader>

                                <img
                                    v-else
                                    :class="$style.placeholderImage"
                                    :src="fanceePlaceholder"
                                    alt="Fancee logo placeholder">
                            </FluxAspectRatio>

                            <div :class="$style.eventCaption">
                                <h2>{{ event.name }}</h2>
                                <h5 v-if="!event.address?.isEmpty">
                                    <span v-if="event.address?.venue">{{ event.address!.venue }}</span>
                                    <span v-if="event.address?.city || event.address?.countryCode"> - </span>
                                    <span v-if="event.address?.city">{{ event.address!.city }}</span>
                                    <span v-if="event.address?.countryCode">({{ event.address!.countryCode }})</span></h5>
                                <p v-html="truncateString(event.description ?? '', 100)"/>
                            </div>

                            <div :class="$style.eventDate">
                                <div :class="$style.eventDateStart">
                                    <strong>{{ event.startDate.toFormat(LUXON_DAY) }}</strong>
                                    <span>{{ event.startDate.toFormat(LUXON_MONTH_ABBREVIATION) }}</span>
                                </div>
                                <div :class="$style.eventDateEnd">
                                    <strong>{{ event.endDate.toFormat(LUXON_DAY) }}</strong>
                                    <span>{{ event.endDate.toFormat(LUXON_MONTH_ABBREVIATION) }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </FluxPane>
            </div>
        </FluxPane>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { AgendaService } from '@fancee/api';
    import { Agenda, AgendaDesign, AgendaOverviewLinkedEvent, truncateString } from '@fancee/data';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useAgendaDesignColor, useService } from '@/composable';
    import { FADER_INTERVAL_MS, LUXON_DAY, LUXON_MONTH_ABBREVIATION } from '@/data';
    import fanceePlaceholder from '@/assets/placeholders/fancee-placeholder.svg?url';

    export interface Props {
        readonly agenda: Agenda;
    }

    const props = defineProps<Props>();
    const {agenda} = toRefs(props);

    const {events} = useService(AgendaService);
    const {t} = useI18n();
    const organizationId = useActiveOrganizationId();

    const selectedEvents = ref<string[]>([]);
    const previewEvents = ref<AgendaOverviewLinkedEvent[]>([]);

    const agendaDesign = computed(() => unref(agenda)?.design ?? AgendaDesign.empty());
    const backgroundColor = useAgendaDesignColor(agendaDesign, 'backgroundColor');
    const backdropColor = useAgendaDesignColor(agendaDesign, 'backdropColor');
    const backdropColorSecondary = useAgendaDesignColor(agendaDesign, 'backdropColor', {lightness: 3});
    const backdropColorThirdly = useAgendaDesignColor(agendaDesign, 'backdropColor', {lightness: 15});
    const backdropColorFourthly = useAgendaDesignColor(agendaDesign, 'backdropColor', {lightness: 9});
    const backdropBorder = useAgendaDesignColor(agendaDesign, 'backdropColor', {lightness: 15});
    const backdropHover = useAgendaDesignColor(agendaDesign, 'backdropColor', {lightness: 6});
    const textColor = useAgendaDesignColor(agendaDesign, 'textColor', {lightness: -9});
    const textColorProminent = useAgendaDesignColor(agendaDesign, 'textColor');

    async function getEvents(): Promise<void> {
        const {data} = await events(unref(organizationId), unref(selectedEvents));
        previewEvents.value = data;
    }

    watch(agenda, () => {
        selectedEvents.value = unref(agenda).events;
    }, {immediate: true, deep: true});

    watch(selectedEvents, () => {
        getEvents();
    });
</script>

<style module>
    .eventBackground {
        padding: 18px;
        background: v-bind(backgroundColor);
        border-radius: var(--radius);
    }

    .eventEditor {
        color: v-bind(textColor);
    }

    .eventBackdrop {
        background: v-bind(backdropColor);
        border-color: v-bind(backdropBorder);
    }

    .event {
        background: v-bind(backdropColorSecondary);
        border: 1px solid v-bind(backdropBorder);
        margin: 15px 0;
        padding: 15px;
        gap: 30px;
        border-radius: var(--radius);
        display: grid;
        grid-template-columns: auto 1fr auto;
    }

    .event:hover {
        background: v-bind(backdropHover);
        cursor: pointer;
    }

    @media (max-width: 900px) {
        .event {
            grid-template-columns: auto 1fr;
        }
    }

    .eventDateStart {
        background: v-bind(backdropColorThirdly);
        color: v-bind(textColorProminent);
    }

    .eventDateEnd {
        background: v-bind(backdropColorFourthly);
        color: v-bind(textColorProminent);
        border: 1px solid v-bind(backdropBorder);
    }

    .eventDate {
        display: flex;
        flex-flow: column;
        gap: 3px;
        margin-left: auto;
    }

    .eventDateStart,
    .eventDateEnd {
        display: flex;
        flex-flow: column;
        align-items: center;
        border-radius: var(--radius);
        height: 48px;
        width: 48px;
        padding-top: 3px;

        & > span {
            font-size: 12px;
            font-weight: 800;
        }
    }

    .eventElements {
        position: relative;
        display: flex;
        margin: 6px 21px;
        min-height: 90px;
        padding: 0;
        flex-flow: column;
        z-index: 1;
    }

    .eventCaption {
        display: flex;
        flex-flow: column;
        flex-grow: 1;
        gap: 3px;

        h2 {
            color: v-bind(textColorProminent);
            font-size: 16px;
        }

        p {
            margin-top: 0;
        }
    }

    .eventImage {
        height: 100px;
        width: 150px;
    }

    .placeholderImage {
        border-radius: var(--radius);
    }

    @media (max-width: 900px) {
        .eventImage {
            grid-column: 1 / span 2;
            width: 100%;
            height: 100%;
        }
    }
</style>
