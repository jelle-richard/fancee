<template>
    <button
        class="ticket-design-preview"
        :class="{
            'is-selected': isSelected
        }"
        @click="$emit('click', $event)">
        <template v-for="element of design.elements">
            <div
                v-if="TicketDesignElement.isMedia(element)"
                class="ticket-design-preview-cell ticket-design-preview-media"
                :style="{
                    '--column': element.column,
                    '--columnSpan': element.columnSpan,
                    '--row': element.row,
                    '--rowSpan': element.rowSpan,
                    '--fileUrl': `url(${element.fileUrl})`
                }"/>

            <div
                v-else-if="TicketDesignElement.isQr(element)"
                class="ticket-design-preview-cell ticket-design-preview-qr"
                :style="{
                    '--column': element.column,
                    '--columnSpan': element.columnSpan,
                    '--row': element.row,
                    '--rowSpan': element.rowSpan
                }">
                <FluxIcon
                    :size="16"
                    variant="qrcode"/>
            </div>

            <div
                v-else-if="TicketDesignElement.isUpcomingEvents(element)"
                class="ticket-design-preview-cell ticket-design-preview-upcoming-events"
                :style="{
                    '--column': element.column,
                    '--columnSpan': element.columnSpan,
                    '--row': element.row,
                    '--rowSpan': element.rowSpan
                }">
                <FluxIcon
                    :size="16"
                    variant="calendar"/>
            </div>
        </template>
    </button>
</template>

<script
    lang="ts"
    setup>
    import { TicketDesign, TicketDesignElement } from '@fancee/data';

    export interface Emits {
        (e: 'click', evt: MouseEvent): void;
    }

    export interface Props {
        readonly design: TicketDesign;
        readonly isSelected?: boolean;
    }

    defineEmits<Emits>();
    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .ticket-design-preview {
        position: relative;
        display: grid;
        padding: 6px;
        gap: 2px;
        grid-template-columns: repeat(3, 1fr);
        grid-template-rows: repeat(4, 1fr);
        background: white;
        background-clip: padding-box;
        border: 1px solid rgb(var(--gray-11) / .05);
        border-radius: var(--radius);
        box-shadow: var(--shadow-sm);
        cursor: pointer;
        outline: 2px solid transparent;
        transition: 210ms var(--swift-out);
        z-index: 0;

        &::after {
            position: absolute;
            display: block;
            inset: 0;
            content: '';
            background: rgb(var(--primary-7) / .6);
            border-radius: inherit;
            opacity: 0;
            transition: inherit;
            z-index: 2;
        }

        &::before {
            position: relative;
            display: block;
            content: '';
            grid-column: 1;
            grid-row: 1;
            aspect-ratio: 1;
        }

        &:hover {
            outline: 2px solid rgb(var(--primary-7));
            outline-offset: 2px;
        }

        &.is-selected {
            outline: 2px solid rgb(var(--primary-7));
            outline-offset: -2px;
            pointer-events: none;

            &::after {
                opacity: 1;
            }
        }

        &-cell {
            height: 100%;
            width: 100%;
            grid-column: var(--column) / span var(--columnSpan);
            grid-row: var(--row) / span var(--rowSpan);
            background: rgb(var(--gray-3));
            outline: 2px solid white;

            .flux-icon {
                color: var(--foreground);
            }
        }

        &-media {
            background: var(--fileUrl) no-repeat center center / cover;
        }

        &-qr {
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1;
        }

        &-upcoming-events {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    }
</style>
