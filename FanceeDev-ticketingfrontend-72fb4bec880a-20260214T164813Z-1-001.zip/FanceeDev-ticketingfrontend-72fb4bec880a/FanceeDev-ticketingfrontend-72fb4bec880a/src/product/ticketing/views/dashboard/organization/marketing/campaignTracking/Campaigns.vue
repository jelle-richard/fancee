<template>
    <FluxPane>
        <FluxActionBar>
            <template #primary>
                <ClaimCheck claim="organization.campaigns.configure">
                    <FluxPrimaryButton
                        icon-before="circle-plus"
                        :label="t('marketing.campaign.singular')"
                        @click="setEmptySelectedCampaign"/>
                </ClaimCheck>
            </template>

            <template #actions-before-search>
                <ToolbarDownload
                    :is-loading="isDownloadingExport"
                    @download="downloadExport"/>
            </template>

            <template #search>
                <ToolbarSearch
                    v-model="filter.searchQuery"
                    :placeholder="t('marketing.campaign.search')"/>
            </template>
        </FluxActionBar>

        <ShareOverlay v-slot="{share}">
            <FluxDataTable
                :data-set="campaigns"
                :is-loading="isLoading"
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                is-hoverable>
                <template #header>
                    <FluxTableHeader>{{ t('marketing.campaign.table.name') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('marketing.campaign.table.event') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('marketing.campaign.table.clicks') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('marketing.campaign.table.revenue') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('marketing.campaign.table.productsSold') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('marketing.campaign.table.averageAge') }}</FluxTableHeader>
                    <FluxTableHeader>{{ t('marketing.campaign.table.genderSplit') }}</FluxTableHeader>
                    <FluxTableHeader is-shrinking/>
                </template>

                <template #name="{row: {name}}">
                    <FluxTableCell>{{ name }}</FluxTableCell>
                </template>

                <template #eventName="{row: {code, eventName, shops}}">
                    <FluxTableCell
                        class="table-cell-shops"
                        v-slot:content>
                        <div class="event-shops">
                            <b>{{ eventName }}</b>
                            <template v-for="shop in shops">
                                <span class="shop-link">
                                    <a
                                        :href="getShopUrl(shop.code, code)"
                                        rel="noopener"
                                        target="_blank">
                                        {{ shop.name }}
                                    </a>

                                    <FluxTableActions>
                                        <FluxAction
                                            icon="share-from-square"
                                            @click="share(getShopUrl(shop.code, code))"/>
                                    </FluxTableActions>
                                </span>
                            </template>
                        </div>
                    </FluxTableCell>
                </template>

                <template #clicks="{row: {clicks}}">
                    <FluxTableCell>{{ clicks }}</FluxTableCell>
                </template>

                <template #revenueCents="{row: {revenueCents}}">
                    <FluxTableCell>{{ asMoney(revenueCents, currency) }}</FluxTableCell>
                </template>

                <template #amountOfSoldTickets="{row: {amountOfSoldTickets, amountOfOrders, amountOfReservations}}">
                    <FluxTooltip :content="t('marketing.campaign.table.salesSplitTip', {productAmount: amountOfSoldTickets, orderAmount: amountOfOrders, reservationAmount: amountOfReservations})">
                        <FluxTableCell>{{ amountOfSoldTickets }}</FluxTableCell>
                    </FluxTooltip>
                </template>

                <template #averageAge="{row: {averageAge}}">
                    <FluxTableCell>{{ averageAge === null ? '—' : averageAge }}</FluxTableCell>
                </template>

                <template #genderSplit="{row: {amountOfOrders, amountOfMales, amountOfFemales, amountOfNeutrals}}">
                    <FluxTableCell>
                        <template v-if="amountOfOrders === 0 || (amountOfMales === 0 && amountOfFemales === 0 && amountOfNeutrals === 0)">
                            &mdash;
                        </template>

                        <template v-else>
                            <FluxPercentageBar
                                :class="$style.genderSplitBar"
                                :items="[
                                {color: RAINBOW_COLORS[9], label: t('global.gender.male'), value: amountOfMales / amountOfOrders},
                                {color: RAINBOW_COLORS[15], label: t('global.gender.female'), value: amountOfFemales / amountOfOrders},
                                {color: RAINBOW_COLORS[3], label: t('global.gender.neutral'), value: amountOfNeutrals / amountOfOrders},
                                {color: 'rgb(var(--gray-4))', label: t('global.gender.unknown'), value: (amountOfOrders - amountOfMales - amountOfFemales - amountOfNeutrals) / amountOfOrders}
                            ]"/>
                        </template>
                    </FluxTableCell>
                </template>

                <template #actions="{row: {code, name}}">
                    <FluxTableCell>
                        <FluxTableActions>
                            <ClaimCheck claim="organization.campaigns.configure">
                                <FluxTooltip :content="t('global.edit')">
                                    <FluxAction
                                        icon="pen"
                                        @click="setSelectedCampaignByCode(code)"/>
                                </FluxTooltip>
                            </ClaimCheck>

                            <FluxTooltip :content="t('global.delete')">
                                <FluxAction
                                    destructive
                                    icon="trash"
                                    @click="removeCampaign(code, name)"/>
                            </FluxTooltip>
                        </FluxTableActions>
                    </FluxTableCell>
                </template>
            </FluxDataTable>
        </ShareOverlay>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>

    <FluxSlideOver
        is-closeable
        @close="deselectCampaign">
        <FluxPane v-if="selectedCampaign !== null">
            <FluxPaneHeader :title="t('marketing.campaign.configure.title')">
                <FluxSecondaryButton
                    icon-before="xmark"
                    @click="deselectCampaign"/>
            </FluxPaneHeader>

            <CampaignConfigurator
                :campaign="selectedCampaign"
                @select-event-id="selectedCampaign.eventId = $event"
                @select-shop-codes="selectedCampaign.shopCodes = $event"/>

            <FluxPaneFooter>
                <FluxSecondaryButton
                    :label="t('global.close')"
                    @click="deselectCampaign"/>

                <FluxSpacer/>

                <FluxPrimaryButton
                    :disabled="invalid"
                    icon-before="circle-check"
                    :label="t('global.save')"
                    @click="validated(saveCampaign)"/>
            </FluxPaneFooter>
        </FluxPane>
    </FluxSlideOver>
</template>

<script
    setup
    lang="ts">
    import { CampaignService } from '@fancee/api';
    import { Campaign, CampaignFilter, ConfigurableCampaign } from '@fancee/data';
    import { showConfirm, showSnackbar } from '@fancee/flux';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ToolbarDownload, ToolbarSearch } from '@/components/filter';
    import { ClaimCheck, ShareOverlay } from '@/components/ui';
    import { useActiveOrganizationId, useCurrency, useLoaded, usePagination, useService, useValidationScope } from '@/composable';
    import { RAINBOW_COLORS } from '@/data';
    import { getShopUrl } from '@/product/ticketing/util';
    import { asMoney, downloadBlob, guarded } from '@/util';
    import CampaignConfigurator from '@/product/ticketing/views/dashboard/organization/marketing/campaignTracking/CampaignConfigurator.vue';

    const currency = useCurrency();
    const organizationId = useActiveOrganizationId();
    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const {t} = useI18n();
    const {isLoading, loaded} = useLoaded();
    const {create: createCampaign, delete: deleteCampaign, export: csvExportCampaigns, list: listCampaigns, update: updateCampaigns} = useService(CampaignService);
    const {invalid, validated} = useValidationScope();

    const _createCampaign = guarded(createCampaign, t('ui.somethingWentWrong.title'), t('marketing.campaign.configure.savingFailed'));
    const _csvExportCampaigns = guarded(csvExportCampaigns, t('ui.somethingWentWrong.title'), t('marketing.campaign.exportFailed'));
    const _deleteCampaign = guarded(deleteCampaign, t('ui.somethingWentWrong.title'), t('marketing.campaign.deleteFailed'));
    const _listCampaigns = guarded(loaded(listCampaigns), t('ui.somethingWentWrong.title'), t('marketing.campaign.loadingFailed'));
    const _updateCampaigns = guarded(updateCampaigns, t('ui.somethingWentWrong.title'), t('marketing.campaign.configure.savingFailed'));

    const campaigns = ref<Campaign[]>([]);
    const filter = ref(new CampaignFilter(''));
    const isSaving = ref(false);
    const isDownloadingExport = ref(false);
    const selectedCampaign = ref<ConfigurableCampaign | null>(null);
    const selectedCampaignCode = ref<string | null>(null);

    async function downloadExport(): Promise<void> {
        isDownloadingExport.value = true;

        try {
            const {blob, name} = await _csvExportCampaigns(unref(organizationId), unref(filter).searchQuery);
            downloadBlob(blob, name);
        } finally {
            isDownloadingExport.value = false;
        }
    }

    async function loadCampaigns(): Promise<void> {
        const {data: {items, totalItems}} = await _listCampaigns(unref(organizationId), unref(filter), unref(pageLength), unref(currentPage));
        campaigns.value = items;
        setTotalItems(totalItems);
    }

    async function removeCampaign(code: string, name: string): Promise<void> {
        const confirmed = await showConfirm({
            icon: 'trash',
            title: t('ui.confirmDeleteOverlay.title', [t('marketing.campaign.singular')]),
            message: t('marketing.campaign.deleteConfirm', [name])
        });

        if (!confirmed) {
            return;
        }

        await _deleteCampaign(unref(organizationId), code);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('marketing.campaign.deleteSuccessful')
        });

        await loadCampaigns();
    }

    async function saveCampaign(): Promise<void> {
        let campaign = unref(selectedCampaign);

        if (campaign === null) {
            return;
        }

        isSaving.value = true;

        try {
            let campaignCode = unref(selectedCampaignCode);

            if (campaignCode === null) {
                await _createCampaign(unref(organizationId), campaign);
            } else {
                await _updateCampaigns(unref(organizationId), campaignCode, campaign);
            }

            deselectCampaign();

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('marketing.campaign.configure.savingSuccessful')
            });

            await loadCampaigns();
        } finally {
            isSaving.value = false;
        }
    }

    function setEmptySelectedCampaign(): void {
        selectedCampaign.value = new ConfigurableCampaign('', '', []);
        selectedCampaignCode.value = null;
    }

    function setSelectedCampaignByCode(code: string): void {
        let campaign = unref(campaigns).find(c => c.code === code);

        if (campaign === undefined) {
            return;
        }

        selectedCampaign.value = new ConfigurableCampaign(campaign.name, campaign.eventId, campaign.shops.map(s => s.code));
        selectedCampaignCode.value = code;
    }

    function deselectCampaign(): void {
        selectedCampaign.value = null;
        selectedCampaignCode.value = null;
    }

    watch([currentPage, pageLength, filter], async () => await loadCampaigns(), {deep: true, immediate: true});
</script>

<style
    lang="scss"
    module>
    .genderSplitBar {
        width: 100%;
    }
</style>

<style
    lang="scss"
    scoped>
    .event-shops {
        display: flex;
        height: 100%;
        padding: 12px 15px;
        align-items: flex-start;
        flex-flow: column;
        justify-content: center;
        gap: 3px;
        font-size: 80%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .shop-link {
        display: flex;
        height: 20px;
        max-width: 100%;
        align-items: center;
        gap: 9px;

        a,
        span {
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }

    .table-cell-shops {
        max-width: 300px;
    }
</style>
