<template>
    <ShopElement
        v-if="product"
        :internal-id="element.internalId"
        :editor-elements="editorElements"
        :editor-elements-emit="editorElementsEmit"
        :class="$style.shopProduct">
        <FluxStack
            v-if="breakpoint === 'xs'"
            :class="$style.productInfo">
            <FluxAspectRatio
                :class="$style.shopProductImage"
                :aspect-ratio="1">
                <img
                    v-if="product.media.length > 0"
                    class="flux-typography-image"
                    :src="product.media[0].url"
                    alt="">

                <FluxPlaceholder
                    v-else
                    icon="image"
                    variant="small"/>
            </FluxAspectRatio>

            <div :class="$style.shopProductCaption">
                <h3>{{ product.name }}</h3>
                <p v-if="product.priceCents">{{ asMoney(product.priceCents, currency) }}</p>
                <p v-else>{{ t('global.free') }}</p>
            </div>

            <FluxQuantitySelector
                v-model="quantity"
                :max="product.maximumPurchasePerOrder"
                :min="0"/>

            <div
                v-if="product.priceCents"
                :class="$style.shopProductPrice">
                {{ asMoney(quantity * product.priceCents, currency) }}
            </div>
        </FluxStack>

        <template v-else>
            <FluxAspectRatio
                :class="$style.shopProductImage"
                :aspect-ratio="1">
                <img
                    v-if="product.media.length > 0"
                    class="flux-typography-image"
                    :src="product.media[0].url"
                    alt="">

                <FluxPlaceholder
                    v-else
                    icon="image"
                    variant="small"/>
            </FluxAspectRatio>

            <div :class="$style.shopProductCaption">
                <h3>{{ product.name }}</h3>
                <p v-if="product.priceCents">{{ asMoney(product.priceCents, currency) }}</p>
                <p v-else>{{ t('global.free') }}</p>
            </div>

            <FluxQuantitySelector
                v-model="quantity"
                :max="product.maximumPurchasePerOrder"
                :min="0"/>

            <div
                v-if="product.priceCents"
                :class="$style.shopProductPrice">
                {{ asMoney(quantity * product.priceCents, currency) }}
            </div>
        </template>
    </ShopElement>
</template>

<script
    lang="ts"
    setup>
    import { EventProductService } from '@fancee/api';
    import { CreateEventShopElement, CreateEventShopProductElement } from '@fancee/data';
    import { computed, onMounted, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useCurrency, useService } from '@/composable';
    import { storeToRefs, useCreateEventStore } from '@/data/store';
    import { asMoney } from '@/util';
    import ShopElement from './ShopElement.vue';
    import { useBreakpoints } from '@fancee/flux';

    export interface Props {
        readonly editorElements: CreateEventShopElement[];
        readonly editorElementsEmit: Function;
        readonly element: CreateEventShopProductElement;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const createEventStore = useCreateEventStore();
    const {allProducts, eventId} = storeToRefs(createEventStore);
    const {setAllProducts} = createEventStore;

    const {t} = useI18n();
    const {breakpoint} = useBreakpoints();
    const {list: getProducts} = useService(EventProductService);
    const organizationId = useActiveOrganizationId();
    const currency = useCurrency();

    const quantity = ref(1);

    const product = computed(() => unref(allProducts).find(p => p.id === unref(element).productId));

    onMounted(async () => {
        const {data: products} = await getProducts(unref(organizationId), unref(eventId)!);
        setAllProducts(products);
    });
</script>

<style
    lang="scss"
    module>
    @use '@/assets/css/breakpoints' as *;

    .productInfo {
        text-align: center;
        align-items: center;
        margin: 0 auto;
    }

    .shopProduct {
        display: flex;
        padding: 15px;
        align-items: center;
        gap: 30px;
        background: rgb(var(--gray-2));
    }

    .shopProductCaption {
        display: flex;
        flex-flow: column;
        flex-grow: 1;
        gap: 3px;

        h3 {
            font-size: 16px;
        }

        p {
            margin-top: 0;
        }
    }

    .shopProductImage {
        height: 72px;
        width: 72px;
    }

    .shopProductPrice {
        margin-right: 15px;
        width: 90px;
        font-size: 16px;
        font-weight: 700;
        text-align: right;
    }

    .shopProduct + .shopProduct {
        margin-top: -15px;
    }

    @include breakpoint-down(xs) {
        .shopProductPrice {
            margin: 0;
            text-align: center;
        }
    }
</style>
