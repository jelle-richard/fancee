<template>
    <FluxPaneBody>
        <FluxFormColumn>
            <ValidationNotice/>

            <FluxNotice
                icon="circle-info"
                is-small
                :message="t('marketing.campaign.configure.info')"/>

            <ValidationField
                :label="t('form.field.name')"
                :rules="{required, minLength: minLength(1), maxLength: maxLength(50)}"
                :value="campaign.name">
                <FluxFormInput v-model="campaign.name"/>
            </ValidationField>

            <ValidationField
                :label="t('event.plural')"
                :hint="t('marketing.campaign.configure.eventsHint')"
                :rules="{required}"
                :value="localEventId">
                <FluxFormSelectAsync
                    v-model="localEventId"
                    :is-disabled="disabledEventSelection"
                    :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                    :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                    :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>
            </ValidationField>

            <ValidationField
                v-if="localEventId !== ''"
                :label="t('event.shopPlural')"
                :rules="{required}"
                :value="localShopCodes">
                <FluxFormSelectAsync
                    v-model="localShopCodes"
                    is-multiple
                    :fetch-options="fetchSelect(async (ids: string[]) => await getShopOptions(organizationId, [localEventId], ids))"
                    :fetch-relevant="fetchSelect(async () => await getShopOptions(organizationId, [localEventId]))"
                    :fetch-search="fetchSelect(async (searchQuery: string) => await getShopOptions(organizationId, [localEventId], searchQuery))"/>
            </ValidationField>
        </FluxFormColumn>
    </FluxPaneBody>
</template>

<script
    setup
    lang="ts">
    import { SelectService } from '@fancee/api';
    import { ConfigurableCampaign } from '@fancee/data';
    import { onMounted, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { maxLength, minLength, required } from '@/data/validation';
    import { fetchSelect } from '@/util';

    export type Emits = {
        (e: 'select-event-id', eventId: string): void;
        (e: 'select-shop-codes', shopsCodes: string[]): void;
    };

    export type Props = {
        readonly campaign: ConfigurableCampaign;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {campaign} = toRefs(props);

    const {t} = useI18n();
    const {getEventOptions, getShopOptions} = useService(SelectService);
    const organizationId = useActiveOrganizationId();

    const disabledEventSelection = ref(false);
    const localEventId = ref('');
    const localShopCodes = ref<string[]>([]);
    let lockEventId = false;

    onMounted(async () => {
        lockEventId = unref(campaign).eventId !== '';
        disabledEventSelection.value = lockEventId;

        if (lockEventId) {
            localEventId.value = campaign.value.eventId;
        }

        if (unref(campaign).shopCodes.length > 0) {
            localShopCodes.value = unref(campaign).shopCodes;
        }
    });


    watch(localEventId, () => {
        if (!lockEventId) {
            localShopCodes.value = [];
        }

        lockEventId = false;
    });

    watch(localShopCodes, () => {
        emit('select-event-id', unref(localEventId));
        emit('select-shop-codes', unref(localShopCodes));
    });
</script>
