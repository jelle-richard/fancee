<template>
    <FluxGrid>
        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="eventRevenueStatistics === null">
                <FluxStatistic
                    color="primary"
                    icon="credit-card"
                    :label="t('dashboard.statistics.finance.onlineSalesRevenue')"
                    :value="asMoney(eventRevenueStatistics?.onlineSalesRevenueCents || 0, currency)"/>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="eventRevenueStatistics === null">
                <FluxStatistic
                    color="primary"
                    icon="money-bills"
                    :label="t('dashboard.statistics.finance.cashSalesRevenue')"
                    :value="asMoney(eventRevenueStatistics?.cashSalesRevenueCents || 0, currency)"/>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="eventRevenueStatistics === null">
                <FluxStatistic
                    color="primary"
                    icon="arrow-up-right-from-square"
                    :label="t('dashboard.statistics.finance.platformExpenses')"
                    :value="asMoney(eventRevenueStatistics?.platformExpensesCents || 0, currency)"/>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="eventRevenueStatistics === null">
                <FluxStatistic
                    color="primary"
                    icon="treasure-chest"
                    :label="t('dashboard.statistics.finance.profit')"
                    :value="asMoney(eventRevenueStatistics?.profitCents || 0, currency)"/>
            </FluxPane>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { Currency, EventRevenueStatistics as EventRevenueStatisticsDto } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { asMoney } from '@/util';

    export interface Props {
        readonly currency: Currency;
        readonly eventRevenueStatistics: EventRevenueStatisticsDto | null;
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>
