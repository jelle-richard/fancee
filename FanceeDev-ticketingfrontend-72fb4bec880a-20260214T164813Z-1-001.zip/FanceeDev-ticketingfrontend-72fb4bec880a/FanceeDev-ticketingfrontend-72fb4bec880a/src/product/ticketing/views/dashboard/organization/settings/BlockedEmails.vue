<template>
    <FluxPane>
        <FluxActionBar>
            <template #primary>
                <FluxPrimaryButton
                    icon-before="circle-plus"
                    :label="t('global.add')"
                    @click="addBlockedEmail = true"/>
            </template>

            <template #actions-end>
                <FluxDestructiveButton
                    v-if="blockedEmails.length > 0"
                    :disabled="isLoading"
                    icon-before="trash"
                    :label="t('global.deleteAll')"
                    @click="deleteAllBlockedEmails"/>
            </template>
        </FluxActionBar>

        <FluxDataTable
            :data-set="blockedEmails"
            :is-loading="isLoading"
            :page="1"
            :per-page="blockedEmails.length"
            :total="blockedEmails.length"
            is-hoverable>
            <template #header>
                <FluxTableHeader>{{ t('form.field.email') }}</FluxTableHeader>
                <FluxTableHeader is-shrinking/>
            </template>

            <template #blockedEmail="{row: {blockedEmail}}">
                <FluxTableCell>{{ blockedEmail }}</FluxTableCell>
            </template>

            <template #actions="{row: {blockedEmail}}">
                <FluxTableCell>
                    <FluxTableActions>
                        <FluxTooltip :content="t('global.delete')">
                            <FluxAction
                                destructive
                                icon="trash"
                                @click="deleteBlockedEmail(blockedEmail)"/>
                        </FluxTooltip>
                    </FluxTableActions>
                </FluxTableCell>
            </template>
        </FluxDataTable>
    </FluxPane>

    <FluxOverlay
        size="small"
        @close="resetErrors()">
        <FluxPane v-if="addBlockedEmail || selectedBlockedEmail !== null">
            <form @submit.prevent>
                <FluxPaneHeader :title="t('settings.blockedEmails.add')">
                    <FluxSecondaryButton
                        icon-before="xmark"
                        @click="resetSelect"/>
                </FluxPaneHeader>

                <FluxPaneBody>
                    <FluxFormColumn>
                        <CombinedFormNotice/>

                        <ValidationField
                            :label="t('form.field.email')"
                            :rules="{required, email}"
                            :value="state.email">
                            <FluxFormInput
                                v-model="state.email"
                                auto-focus
                                type="email"
                                auto-complete="off"/>
                        </ValidationField>
                    </FluxFormColumn>
                </FluxPaneBody>

                <FluxPaneFooter>
                    <FluxSpacer/>

                    <FluxSecondaryButton
                        :label="t('global.cancel')"
                        @click="resetSelect"/>

                    <FluxPrimaryButton
                        :disabled="invalid"
                        icon-before="circle-check"
                        :is-loading="isLoading"
                        :label="t('global.save')"
                        @click="validated(addEmail)"/>
                </FluxPaneFooter>
            </form>
        </FluxPane>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { showConfirm, showSnackbar } from '@fancee/flux';
    import { onMounted, reactive, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { useActiveOrganizationId, useLoaded, useRequestErrorBoundary, useService, useValidationScope } from '@/composable';
    import { email, required } from '@/data/validation';
    import { guarded } from '@/util';

    const {t} = useI18n();
    const {isLoading, loaded} = useLoaded();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const {getBlockedEmails, deleteBlockedEmails, blockEmail, deleteBlockedEmail: deleteEmail} = useService(UserService);
    const {invalid, validated} = useValidationScope();
    const organizationId = useActiveOrganizationId();

    const _blockEmail = loaded(blockEmail);
    const _deleteBlockedEmails = guarded(loaded(deleteBlockedEmails), t('ui.somethingWentWrong.title'), t('settings.blockedEmails.deleteEverythingFailed'));
    const _deleteEmail = guarded(loaded(deleteEmail), t('ui.somethingWentWrong.title'), t('settings.blockedEmails.deleteFailed'));
    const _getBlockedEmails = guarded(loaded(getBlockedEmails), t('ui.somethingWentWrong.title'), t('settings.blockedEmails.loadingFailed'));

    const selectedBlockedEmail = ref<string | null>(null);
    const blockedEmails = ref<{ blockedEmail: string }[]>([]);
    const addBlockedEmail = ref(false);
    const state = reactive({
        email: ''
    });

    onMounted(async () => await loadBlockedEmails());

    function resetSelect(): void {
        state.email = '';
        selectedBlockedEmail.value = null;
        addBlockedEmail.value = false;
    }

    async function loadBlockedEmails(): Promise<void> {
        const {data} = await _getBlockedEmails(unref(organizationId));
        blockedEmails.value = data.map(blockedEmail => ({blockedEmail}));
    }

    async function addEmail(): Promise<void> {
        resetErrors();

        await _blockEmail(unref(organizationId), state.email);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('settings.blockedEmails.addSuccess', [state.email])
        });

        resetSelect();
        await loadBlockedEmails();

        addBlockedEmail.value = false;
    }

    async function deleteAllBlockedEmails(): Promise<void> {
        const confirmed = await showConfirm({
            icon: 'trash',
            title: t('ui.confirmDeleteOverlay.titleAll'),
            message: t('settings.blockedEmails.deleteEverythingConfirm')
        });

        if (!confirmed) {
            return;
        }

        await _deleteBlockedEmails(unref(organizationId));

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('settings.blockedEmails.deleteEverythingSuccess')
        });

        await loadBlockedEmails();
    }

    async function deleteBlockedEmail(email: string): Promise<void> {
        const confirmed = await showConfirm({
            icon: 'trash',
            title: t('ui.confirmDeleteOverlay.title', [email]),
            message: t('ui.confirmDeleteOverlay.messageGeneric')
        });

        if (!confirmed) {
            return;
        }

        await _deleteEmail(unref(organizationId), email);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('settings.blockedEmails.deleteSuccess')
        });

        await loadBlockedEmails();
    }
</script>
