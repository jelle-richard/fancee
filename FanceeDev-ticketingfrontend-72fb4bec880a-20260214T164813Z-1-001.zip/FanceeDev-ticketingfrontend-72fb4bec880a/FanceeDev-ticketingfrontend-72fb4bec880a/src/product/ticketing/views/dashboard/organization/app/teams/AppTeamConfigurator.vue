<template>
    <FluxPane>
        <FluxPaneHeader :title="isNew ? t('app.team.configure.title.new') : t('app.team.configure.title.edit', [appTeam.name])">
            <FluxSecondaryButton
                icon-before="xmark"
                @click="close()"/>
        </FluxPaneHeader>

        <FluxPaneBody>
            <FluxFormColumn>
                <CombinedFormNotice/>

                <ValidationField
                    :label="t('form.field.name')"
                    :rules="{required, maxLength: maxLength(50), minLength: minLength(3)}"
                    :value="appTeam.name">
                    <FluxFormInput
                        v-model="appTeam.name"
                        data-testid="app-team-name"/>
                </ValidationField>

                <FluxFormRow>
                    <ValidationField
                        :label="t('app.team.right.scanning')"
                        :rules="{required: requiredUnless(hasRights)}"
                        :value="appTeam.scanningEnabled ? ':)' : ''">
                        <FluxToggle
                            v-model="appTeam.scanningEnabled"
                            data-testid="app-team-scanning-enabled"/>
                    </ValidationField>

                    <FluxFormField :label="t('app.team.right.guestlists')">
                        <FluxToggle
                            v-model="appTeam.scanGuestlistEnabled"
                            data-testid="app-team-guestlist-enabled"/>
                    </FluxFormField>
                </FluxFormRow>

                <FluxFormRow>
                    <ValidationField
                        :label="t('app.team.right.sales')"
                        :rules="{required: requiredUnless(hasRights)}"
                        :value="appTeam.salesEnabled ? ':)' : ''">
                        <FluxToggle
                            v-model="appTeam.salesEnabled"
                            data-testid="app-team-sales-enabled"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('app.team.right.statistics')"
                        :rules="{required: requiredUnless(hasRights)}"
                        :value="appTeam.statisticsEnabled ? ':)' : ''">
                        <FluxToggle
                            v-model="appTeam.statisticsEnabled"
                            data-testid="app-team-statistics-enabled"/>
                    </ValidationField>
                </FluxFormRow>

                <FluxFormField
                    v-if="hasCashClaim"
                    :label="t('app.team.right.cash')">
                    <FluxToggle
                        v-model="appTeam.cashEnabled"
                        :is-disabled="!appTeam.salesEnabled"
                        data-testid="app-team-cash-enabled"/>
                </FluxFormField>

                <ValidationField
                    :label="t('event.productPlural')"
                    :rules="{required}"
                    :value="selectedProducts.length > 0 ? ':)' : ''">
                    <FluxFormSelectAsync
                        v-model="selectedProducts"
                        is-multiple
                        :fetch-options="fetchSelect(async (ids: string[]) => await getEventProductOptions(organizationId, null, null, ids))"
                        :fetch-relevant="fetchSelect(async () => await getEventProductOptions(organizationId, null, null))"
                        :fetch-search="fetchSelect(async (searchQuery: string) => await getEventProductOptions(organizationId, null, null, searchQuery))"/>
                </ValidationField>
            </FluxFormColumn>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSecondaryButton
                :label="t('global.close')"
                @click="close()"/>

            <FluxSpacer/>

            <FluxPrimaryButton
                :disabled="invalid"
                icon-before="circle-check"
                :label="t('global.save')"
                data-testid="app-team-save-team"
                @click="validated(save)"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { SelectService } from '@fancee/api';
    import { AppTeam } from '@fancee/data';
    import { computed, onMounted, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { useActiveOrganizationId, useHasClaim, useService, useValidationScope } from '@/composable';
    import { maxLength, minLength, required, requiredUnless } from '@/data/validation';
    import { fetchSelect } from '@/util';

    export type Emits = {
        (e: 'close'): void;
        (e: 'products-changed', selectedProducts: string[]): void;
        (e: 'save'): void;
    };

    export type Props = {
        readonly appTeam: AppTeam;
        readonly isNew?: boolean;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {appTeam} = toRefs(props);
    const {getEventProductOptions} = useService(SelectService);
    const organizationId = useActiveOrganizationId();

    const {t} = useI18n();
    const {invalid, validated} = useValidationScope();
    const hasCashClaim = useHasClaim('organization.sale.payments.cash');

    const selectedProducts = ref<string[]>([]);

    const hasRights = computed(() => unref(appTeam).scanningEnabled
        || unref(appTeam).salesEnabled
        || unref(appTeam).statisticsEnabled);

    onMounted(() => {
        if (!hasCashClaim.value) {
            appTeam.value.cashEnabled = false;
        }
    });

    function close(): void {
        emit('close');
    }

    function save(): void {
        emit('save');
    }

    watch(selectedProducts, () => {
        emit('products-changed', selectedProducts.value);
    });

    watch(() => appTeam.value.products, products => {
        selectedProducts.value = products.map(p => p.id);
    }, {immediate: true});
</script>
