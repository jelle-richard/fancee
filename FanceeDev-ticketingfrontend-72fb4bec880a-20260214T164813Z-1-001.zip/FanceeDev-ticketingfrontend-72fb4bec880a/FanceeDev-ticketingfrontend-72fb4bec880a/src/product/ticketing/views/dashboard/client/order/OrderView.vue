<template>
    <FluxExpandableGroup>
        <FluxExpandable :label="t('finance.order.single.client.title')">
            <OrderClient :selected-order="order"/>
        </FluxExpandable>

        <FluxExpandable :label="t('finance.order.single.order.title')">
            <OrderTransaction :selected-order="order"/>
        </FluxExpandable>

        <FluxExpandable :label="t('finance.order.single.purchase.title')">
            <OrderProducts :selected-order="order"/>
        </FluxExpandable>
    </FluxExpandableGroup>
</template>

<script
    lang="ts"
    setup>
    import { Order } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import OrderClient from './OrderClient.vue';
    import OrderTransaction from './OrderTransaction.vue';
    import OrderProducts from './OrderProducts.vue';

    export interface Props {
        readonly order: Order;
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>
