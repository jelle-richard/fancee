<template>
    <FluxPane :is-loading="checkableClaimCategories.length === 0">
        <FluxPaneHeader :title="user === null ? t('settings.roleManagement.configure.title.add') : t('settings.roleManagement.configure.title.edit', [user?.email])">
            <FluxSecondaryButton
                icon-before="xmark"
                data-testid="role-assign-header-close-overlay"
                @click="close()"/>
        </FluxPaneHeader>

        <ValidationNotice pane-body/>

        <FluxPaneBody>
            <ResponseErrorsNotice
                v-if="errors !== null && errors !== undefined"
                :errors="errors"
                data-testid="role-assign-error-notice"/>

            <FluxFormColumn>
                <ValidationField
                    v-if="user === null"
                    :label="t('form.field.email')"
                    :rules="{required, email}"
                    :value="state.email">
                    <FluxFormInput
                        v-model="state.email"
                        data-lpignore="true"
                        type="email"
                        auto-focus
                        data-testid="role-assign-user-email"/>
                </ValidationField>

                <ValidationField
                    :label="t('form.field.description')"
                    :rules="{required, maxLength: maxLength(50)}"
                    :value="state.description">
                    <FluxFormInput
                        v-model="state.description"
                        data-testid="role-assign-user-description"/>
                </ValidationField>

                <template
                    v-for="checkableClaimCategory of checkableClaimCategories"
                    :key="checkableClaimCategory.category">
                    <ClaimCategory :claim-category="checkableClaimCategory"/>
                </template>
            </FluxFormColumn>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSecondaryButton
                :label="t('global.close')"
                data-testid="role-assign-footer-close-overlay"
                @click="close()"/>

            <FluxSpacer/>

            <FluxPrimaryButton
                :disabled="invalid"
                icon-before="circle-check"
                :label="t('global.save')"
                data-testid="role-assign-footer-save-overlay"
                @click="!user ? add() : update()"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { AuthService } from '@fancee/api';
    import { IResponseErrors } from '@fancee/client';
    import { OrganizationUser, OrganizationUserAssignment, OrganizationUserAssignmentUpdate } from '@fancee/data';
    import { computed, onMounted, reactive, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { ResponseErrorsNotice } from '@/components/ui';
    import { useService, useValidationScope } from '@/composable';
    import { Claim } from '@/data';
    import { email, maxLength, required } from '@/data/validation';
    import { ClaimCheckCategory } from '@/data/dto/claim/ClaimCheckCategory';
    import { guarded } from '@/util';
    import { ClaimAdapter } from '@/data/adapter/claim/ClaimAdapter';
    import ClaimCategory from '@/product/ticketing/views/dashboard/generic/claims/ClaimCategory.vue';

    export type Emits = {
        (e: 'close'): void;
        (e: 'add', assignedUser: OrganizationUserAssignment): void;
        (e: 'update', assignedUser: OrganizationUserAssignmentUpdate): void;
    };

    export type Props = {
        user?: OrganizationUser | null;
        errors?: IResponseErrors | null;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {user} = toRefs(props);

    const {t} = useI18n();
    const {invalid, validate} = useValidationScope();

    const {getPlatformOrganizationClaims} = useService(AuthService);
    const _getPlatformClaims = guarded(getPlatformOrganizationClaims, t('ui.somethingWentWrong.title'), t('settings.roleManagement.configure.title.loadingFailed'));

    const claims = ref<string[]>([]);
    const checkableClaimCategories = ref<ClaimCheckCategory[]>([]);
    const defaultClaims = ref<Claim[]>([
        'organization.contract.details',
        'organization.contract.list',
        'profile.details'
    ]);

    const checkedClaims = computed(() => unref(checkableClaimCategories).map(ccc => ccc.selectedClaims).flat());

    const state = reactive({
        email: '',
        description: ''
    });

    onMounted(async () => {
        let userToUpdate = unref(user);

        if (!userToUpdate) {
            await loadPlatformClaims();
            return;
        }

        claims.value = userToUpdate.claims;
        await loadPlatformClaims();
        state.description = userToUpdate.description;
    });

    async function loadPlatformClaims(): Promise<void> {
        const {data} = await _getPlatformClaims();
        checkableClaimCategories.value = ClaimAdapter.parseClaimHierarchyCategoryToCheckableClaims(data, unref(claims));
    }

    function close(): void {
        emit('close');
    }

    async function add(): Promise<void> {
        if (!await validate()) {
            return;
        }

        let assignedUser = new OrganizationUserAssignment(
            state.email,
            mergeClaims(),
            state.description
        );

        emit('add', assignedUser);
    }

    async function update(): Promise<void> {
        if (!await validate()) {
            return;
        }

        let userToUpdate = unref(user);

        if (!userToUpdate) {
            return;
        }

        let assignedUser = new OrganizationUserAssignmentUpdate(
            userToUpdate.id,
            unref(checkedClaims),
            state.description
        );

        emit('update', assignedUser);
    }

    function mergeClaims(): string[] {
        let claims = unref(checkedClaims).concat(unref(defaultClaims));

        if (claims.includes('organization.event.configure')) {
            claims.push('organization.event.type.normal');
        }

        return claims;
    }
</script>
