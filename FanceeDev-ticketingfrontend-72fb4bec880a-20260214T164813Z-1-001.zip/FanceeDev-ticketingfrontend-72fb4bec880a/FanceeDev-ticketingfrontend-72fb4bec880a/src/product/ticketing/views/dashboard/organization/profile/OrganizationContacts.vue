<template>
    <FluxPane>
        <ValidationNotice pane-body/>

        <FluxPaneBody v-if="profile.contacts.length === 0">
            <ConfigureOrganizationContacts @add="addEmptyContact()"/>
        </FluxPaneBody>

        <template v-else>
            <FluxPaneBody>
                <template v-for="(contact, index) in profile.contacts">
                    <FluxDivider v-if="index > 0"/>

                    <FluxFormColumn>
                        <FluxFormRow>
                            <ValidationField
                                :label="t('form.field.email')"
                                :rules="{required, email}"
                                :value="contact.email">
                                <FluxFormInput
                                    v-model="contact.email"
                                    auto-complete="new-email"
                                    type="email"/>
                            </ValidationField>

                            <ValidationField
                                :label="t('form.field.role')"
                                :rules="{required}"
                                :value="contact.contactRoleType">
                                <FluxFormSelect
                                    v-model="contact.contactRoleType"
                                    :options="contactTypes"/>
                            </ValidationField>
                        </FluxFormRow>

                        <FluxFormRow>
                            <ValidationField
                                :label="t('form.field.firstName')"
                                :rules="{required}"
                                :value="contact.firstName">
                                <FluxFormInput
                                    v-model="contact.firstName"
                                    type="text"/>
                            </ValidationField>

                            <ValidationField
                                :label="t('form.field.lastName')"
                                :rules="{required}"
                                :value="contact.lastName">
                                <FluxFormInput
                                    v-model="contact.lastName"
                                    type="text"/>
                            </ValidationField>
                        </FluxFormRow>

                        <FluxFormRow>
                            <ValidationField
                                :label="t('form.field.phoneNumber')"
                                :rules="{required, phoneNumber: phoneNumber(profile.legalEntity.countryCode!)}"
                                :value="contact.phoneNumber">
                                <FluxFormInput
                                    v-model="contact.phoneNumber"
                                    type="tel"/>
                            </ValidationField>

                            <FluxTooltip :content="t('global.delete')">
                                <FluxDestructiveButton
                                    :class="$style.deleteButton"
                                    icon-before="trash"
                                    @click="removeContact(index)"/>
                            </FluxTooltip>
                        </FluxFormRow>
                    </FluxFormColumn>
                </template>
            </FluxPaneBody>

            <FluxPaneFooter>
                <FluxSecondaryButton
                    icon-before="circle-plus"
                    :label="t('platform.profile.contact.add')"
                    @click="addEmptyContact"/>

                <FluxSpacer/>

                <FluxPrimaryButton
                    :disabled="invalid"
                    icon-before="circle-check"
                    :label="t('global.save')"
                    @click="validated(saveContacts)"/>
            </FluxPaneFooter>
        </template>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { OrganizationService } from '@fancee/api';
    import { ContactType, OrganizationContact, OrganizationProfile } from '@fancee/data';
    import { FluxFormSelectOption, showSnackbar } from '@fancee/flux';
    import { ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { useActiveOrganizationId, useService, useValidationScope } from '@/composable';
    import { email, phoneNumber, required } from '@/data/validation';
    import { guarded } from '@/util';
    import ConfigureOrganizationContacts from '@/product/ticketing/views/dashboard/organization/profile/ConfigureOrganizationContacts.vue';

    interface Props {
        profile: OrganizationProfile;
    }

    const props = defineProps<Props>();
    const {profile} = toRefs(props);

    const {t} = useI18n();
    const {addContact, deleteContact, updateContact} = useService(OrganizationService);
    const {invalid, validated} = useValidationScope();
    const organizationId = useActiveOrganizationId();

    const _addContact = guarded(addContact, t('ui.somethingWentWrong.title'), t('platform.profile.contact.createFailed'));
    const _deleteContact = guarded(deleteContact, t('ui.somethingWentWrong.title'), t('platform.profile.contact.deleteFailed'));
    const _updateContact = guarded(updateContact, t('ui.somethingWentWrong.title'), t('platform.profile.contact.editFailed'));

    const contactTypes = ref<FluxFormSelectOption[]>([
        {id: ContactType.CustomerSupport, label: t('platform.profile.contact.role.customerSupprt')},
        {id: ContactType.Finance, label: t('platform.profile.contact.role.finance')},
        {id: ContactType.Marketing, label: t('platform.profile.contact.role.marketing')},
        {id: ContactType.Organization, label: t('platform.profile.contact.role.organization')}
    ]);

    function addEmptyContact(): void {
        unref(profile).contacts.push(OrganizationContact.empty());
    }

    async function createContact(contact: OrganizationContact): Promise<void> {
        const {data: contactId} = await _addContact(unref(organizationId), contact);
        contact.id = contactId;

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('platform.profile.contact.added', [
                contact.firstName,
                contact.lastName
            ])
        });
    }

    async function editContact(contact: OrganizationContact): Promise<void> {
        await _updateContact(unref(organizationId), contact);

        if (unref(profile).contacts.length <= 0) {
            return;
        }

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('ui.changesSavedSuccessfully')
        });
    }

    async function saveContacts(): Promise<void> {
        for (const contact of unref(profile).contacts) {
            contact.id === null
                ? await createContact(contact)
                : await editContact(contact);
        }
    }

    async function removeContact(index: number): Promise<void> {
        const contact = unref(profile).contacts[index] || null;

        if (contact === null) {
            return;
        }

        if (contact.id === null) {
            unref(profile).contacts.splice(index, 1);
            return;
        }

        await _deleteContact(unref(organizationId), contact.id);

        unref(profile).contacts.splice(index, 1);

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('platform.profile.contact.deleted', [
                contact.firstName,
                contact.lastName
            ])
        });
    }
</script>

<style module>
    .deleteButton {
        margin-top: auto;
    }
</style>
