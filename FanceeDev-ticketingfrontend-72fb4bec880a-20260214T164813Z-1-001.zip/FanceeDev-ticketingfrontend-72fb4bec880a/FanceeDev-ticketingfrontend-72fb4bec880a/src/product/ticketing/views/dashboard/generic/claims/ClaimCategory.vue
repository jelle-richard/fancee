<template>
    <FluxPane>
        <FluxPaneHeader :title="claimCategory.category">
            <FluxSpacer/>
            <FluxBadge :label="claimCategory.selection"/>
            <FluxCheckbox v-model="claimCategory.isChecked"/>
        </FluxPaneHeader>

        <FluxPaneBody>
            <FluxStack :gap="6">
                <template
                    v-for="claim of claimCategory.claims"
                    :key="claim.claim">
                    <ClaimCheckbox :claim="claim"/>
                </template>
            </FluxStack>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ClaimCheckCategory } from '@/data/dto/claim/ClaimCheckCategory';
    import ClaimCheckbox from '@/product/ticketing/views/dashboard/generic/claims/ClaimCheckbox.vue';

    export interface Props {
        readonly claimCategory: ClaimCheckCategory;
    }

    defineProps<Props>();
</script>
