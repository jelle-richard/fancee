<template>
    <div class="ticket-design-grid">
        <template v-for="cell in cells">
            <FluxDropZone
                v-if="!isOccupied(cell)"
                v-slot="{showPicker}"
                :key="`placeholder-cell-${cell}`"
                class="ticket-design-grid-placeholder"
                :style="getCellStyles(cell)"
                @select="(files: any) => onFilesSelected(cell, files)">
                <FluxButtonStack>
                    <FluxSecondaryButton
                        v-if="!hasQrCode"
                        icon-before="qrcode"
                        data-testid="create-event-grid-add-qrcode"
                        @click="addQr(cell)"/>

                    <FluxSecondaryButton
                        icon-before="image"
                        data-testid="create-event-grid-add-image"
                        @click="showPicker"/>

                    <FluxSecondaryButton
                        icon-before="calendar"
                        data-testid="create-event-grid-add-upcoming-events"
                        @click="addUpcomingEvents(cell)"/>
                </FluxButtonStack>
            </FluxDropZone>
        </template>

        <template
            v-for="element of elements"
            :key="element.internalId">
            <TicketDesignCell :element="element"/>
        </template>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { EventProductService } from '@fancee/api';
    import { RequestError } from '@fancee/client';
    import { Media, TicketDesignElement, TicketDesignMediaElement, TicketDesignQrElement, TicketDesignUpcomingEventsElement } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { computed, unref } from 'vue';
    import { useActiveOrganizationId, useMultiFileManagement, useService } from '@/composable';
    import { EVENT_TICKET_DESIGN_COLUMNS } from '@/data';
    import { storeToRefs, useCreateEventStore } from '@/data/store';
    import { useTicketDesigner } from '../composable';
    import TicketDesignCell from './TicketDesignCell.vue';

    export interface Emits {
        (e: 'loading', isLoading: boolean): void;
    }

    const emit = defineEmits<Emits>();

    const createEventStore = useCreateEventStore();
    const organizationId = useActiveOrganizationId();
    const {eventId} = storeToRefs(createEventStore);
    const {uploadTicketDesignMedia} = useService(EventProductService);
    const {cells, design, elements, occupied} = useTicketDesigner();

    const {upload: uploadMedia} = useMultiFileManagement({
        onUploadError(file: File, _: RequestError, message: string) {
            showSnackbar({
                color: 'danger',
                icon: 'circle-exclamation',
                message: message,
                title: file.name
            });
        },
        upload: async file => await uploadTicketDesignMedia(unref(organizationId), unref(eventId)!, file)
    });

    const hasQrCode = computed(() => !!unref(elements).find(TicketDesignElement.isQr));

    function add(cell: number, element: TicketDesignElement, columnSpan: number = 1, rowSpan: number = 1): void {
        const [row, column] = getCellPosition(cell);
        element.column = column;
        element.row = row;
        element.columnSpan = columnSpan;
        element.rowSpan = rowSpan;

        design.value.elements.push(element);
    }

    function addMedia(cell: number, media: Media): void {
        add(cell, new TicketDesignMediaElement(media.id, media.url));
    }

    function addQr(cell: number): void {
        add(cell, new TicketDesignQrElement(null, null));
    }

    function addUpcomingEvents(cell: number): void {
        add(cell, new TicketDesignUpcomingEventsElement(5));
    }

    async function onFilesSelected(cell: number, files: FileList): Promise<void> {
        const images: File[] = [];

        for (let i = 0; i < files.length; ++i) {
            const file = files.item(i);

            if (!file || !file.type.startsWith('image/')) {
                continue;
            }

            images.push(file);
        }

        emit('loading', true);
        const medias = await uploadMedia(images);

        if (medias.length === 1) {
            const media = medias[0];
            addMedia(cell, media);
        }

        emit('loading', false);
    }

    function getCellPosition(cell: number): [number, number] {
        const row = Math.ceil(cell / EVENT_TICKET_DESIGN_COLUMNS);
        const column = cell - (row - 1) * EVENT_TICKET_DESIGN_COLUMNS;

        return [row, column];
    }

    function getCellStyles(cell: number): Partial<CSSStyleDeclaration> {
        const [row, column] = getCellPosition(cell);

        return {
            gridColumn: `${column} / span 1`,
            gridRow: `${row} / span 1`
        };
    }

    function isOccupied(cell: number): boolean {
        const [row, column]: [number, number] = getCellPosition(cell);

        return !!unref(occupied).find(([r, c]: [number, number]) => r === row && c === column);
    }
</script>

<style
    lang="scss"
    scoped>
    .ticket-design-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        grid-template-rows: repeat(4, 1fr);

        &::before {
            position: relative;
            display: block;
            content: '';
            grid-column: 1;
            grid-row: 1;
            aspect-ratio: 1;
        }

        &-placeholder {
            display: flex;
            aspect-ratio: 1;
            align-items: center;
            justify-content: center;
            background: rgb(var(--primary-1));
            outline: 1px dashed rgb(var(--primary-4));
            outline-offset: -3px;
            z-index: 0;

            &.is-hidden {
                grid-column: 1;
                grid-row: 1;
                opacity: 0;
                pointer-events: none;
            }

            .flux-stack {
                opacity: 0;
                transition: opacity 210ms var(--swift-out);
            }

            &:hover .flux-stack {
                opacity: 1;
            }
        }

        &:has(.ticket-design-cell:hover):hover ::v-deep(.ticket-design-cell:not(:hover)) {
            filter: grayscale(.5);
            opacity: .5;
        }
    }
</style>
