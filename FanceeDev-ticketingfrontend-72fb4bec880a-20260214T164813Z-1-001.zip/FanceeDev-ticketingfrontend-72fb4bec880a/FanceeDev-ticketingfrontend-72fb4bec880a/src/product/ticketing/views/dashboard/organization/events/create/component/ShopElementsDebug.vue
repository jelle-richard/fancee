<template>
    <div class="shop-elements-debug">
        <pre class="shop-elements-debug-tree">{{ elementTree }}</pre>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopElement } from '@fancee/data';
    import { computed, unref } from 'vue';
    import { storeToRefs, useCreateEventStore } from '@/data/store';

    export interface Props {
        readonly elements: CreateEventShopElement[];
    }

    const props = defineProps<Props>();

    const createEventStore = useCreateEventStore();
    const {allProducts} = storeToRefs(createEventStore);

    const elementTree = computed(() => {
        const result: string[] = [];

        function convert(e: CreateEventShopElement, prefix: string = ''): void {
            if (CreateEventShopElement.isAccordion(e)) {
                result.push(`${prefix}${e.kind} (${e.title})`);

                e.elements.forEach(se => convert(se, ' ↳ '));
            } else if (CreateEventShopElement.isProduct(e)) {
                result.push(`${prefix}${e.kind} (${unref(allProducts).find(p => p.id === e.productId)?.name})`);
            } else {
                result.push(`${prefix}${e.kind}`);
            }
        }

        props.elements.forEach(e => convert(e));

        return result.join('\n');
    });
</script>

<style
    lang="scss"
    scoped>
    .shop-elements-debug {
        position: fixed;
        padding: 15px;
        top: 108px;
        right: 21px;
        width: 420px;
        background: #333;
        border-radius: 9px;
        color: #fff;
        overflow: hidden;
        z-index: 999999;

        &-tree {
            background: unset;
            color: unset;
            font-size: 18px;
            line-height: 1.7;
        }
    }
</style>
