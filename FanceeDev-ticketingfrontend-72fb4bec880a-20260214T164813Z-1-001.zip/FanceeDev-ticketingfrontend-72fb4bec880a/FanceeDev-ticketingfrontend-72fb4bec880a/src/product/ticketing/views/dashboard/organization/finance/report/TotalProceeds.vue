<template>
    <FluxPane>
        <DetailListPaneSection :title="t('finance.report.totals.totals')">
            <DetailListItem
                :label="t('finance.report.totals.revenue')"
                :value="asMoney(totalRevenue, currency)"
                @mouseenter="$emit('hover-element', 'revenue', true)"
                @mouseleave="$emit('hover-element', 'revenue', false)"/>

            <DetailListItem
                :label="t('finance.report.totals.cost')"
                :value="asMoney(totalCost, currency)"
                @mouseenter="$emit('hover-element', 'cost', true)"
                @mouseleave="$emit('hover-element', 'cost', false)"/>
        </DetailListPaneSection>

        <FluxSeparator/>

        <DetailListPaneSection :title="t('finance.report.totals.profit.title')">
            <DetailListItem
                v-if="totalProfit !== placedInWallet"
                :label="t('finance.report.totals.profit.profit')"
                :value="asMoney(totalProfit, currency)"/>

            <DetailListItem
                :label="t('finance.report.totals.profit.wallet')"
                :value="asMoney(placedInWallet, currency)"/>
        </DetailListPaneSection>

        <FluxNotice
            v-if="totalProfit !== placedInWallet"
            icon="circle-info"
            is-small
            variant="info"
            :message="t('finance.report.totals.profit.cash')"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { asMoney } from '@/util';
    import { DetailListItem, DetailListPaneSection } from '@/components/ui';
    import { useCurrency } from '@/composable';

    const {t} = useI18n();
    const currency = useCurrency();

    export type Emits = {
        (e: 'hover-element', element: string, hover: boolean): void;
    }

    export type Props = {
        readonly totalRevenue: number;
        readonly totalCost: number;
        readonly totalProfit: number;
        readonly placedInWallet: number;
    };

    defineEmits<Emits>();
    defineProps<Props>();
</script>
