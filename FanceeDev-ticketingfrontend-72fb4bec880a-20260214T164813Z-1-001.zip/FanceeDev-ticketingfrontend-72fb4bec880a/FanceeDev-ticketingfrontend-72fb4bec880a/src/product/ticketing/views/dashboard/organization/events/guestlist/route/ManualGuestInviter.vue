<template>
    <FluxPane>
        <FluxPaneHeader :title="`${event.name} - ${formatDateTimeLocal(event.dateTimeSpan.start)}`"/>

        <FluxPaneBody>
            <FluxStack>
                <ValidationNotice/>

                <FluxNotice
                    v-if="lastSendSuccessful"
                    icon="circle-check"
                    is-small
                    :message="t('event.guestlist.manage.success')"
                    variant="success"/>

                <FluxGrid>
                    <FluxGridColumn
                        :sm="12"
                        :md="6"
                        :lg="5">
                        <FluxFormRow>
                            <ValidationField
                                :label="t('event.ticketSingular')"
                                :rules="{required}"
                                :value="selectedTicketId">
                                <FluxFormSelectAsync
                                    v-model="selectedTicketId"
                                    :fetch-options="fetchSelect(async (ids: string[]) => await getEventProductOptions(organizationId, [eventId], null, ids))"
                                    :fetch-relevant="fetchSelect(async () => await getEventProductOptions(organizationId, [eventId], null))"
                                    :fetch-search="fetchSelect(async (searchQuery: string) => await getEventProductOptions(organizationId, [eventId], null, searchQuery))"/>
                            </ValidationField>

                            <FluxFormField :label="t('event.guestlist.manage.deduct')">
                                <FluxToggle
                                    v-model="deductStock"
                                    :class="$style.toggleFormRowOffset"/>
                            </FluxFormField>
                        </FluxFormRow>
                    </FluxGridColumn>
                </FluxGrid>

                <FluxStack :gap="15">
                    <GuestRow
                        v-for="(guest, index) in guests"
                        :key="index"
                        :index="index"
                        :guest="guest"
                        @delete="deleteGuest"/>
                </FluxStack>
            </FluxStack>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSecondaryButton
                :label="t('event.guestlist.manage.guest')"
                icon-before="circle-plus"
                @click="addGuest"/>

            <FluxSpacer/>

            <FluxPrimaryButton
                :disabled="invalid"
                icon-before="paper-plane"
                :is-loading="isSendingGuestlists"
                :label="t('global.send')"
                @click="saveGuests"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ProductService, SelectService } from '@fancee/api';
    import { CsvDelimiter, EventDetails } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { nextTick, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { useActiveOrganizationId, useService, useValidationScope } from '@/composable';
    import { Guest } from '@/data/dto/guestlist/Guest';
    import { required } from '@/data/validation';
    import { formatDateTimeLocal, fetchSelect, guarded } from '@/util';
    import GuestRow from '@/product/ticketing/views/dashboard/organization/events/guestlist/component/GuestRow.vue';

    const {t} = useI18n();
    const {importGuests} = useService(ProductService);
    const {getEventProductOptions} = useService(SelectService);
    const {invalid, reset: resetValidation, validate} = useValidationScope();
    const organizationId = useActiveOrganizationId();

    const _importGuests = guarded(importGuests, t('ui.somethingWentWrong.title'), t('event.guestlist.manage.failed'));

    export interface Props {
        readonly event: EventDetails;
        readonly eventId: string;
    }

    const props = defineProps<Props>();
    const {event} = toRefs(props);

    const deductStock = ref(false);
    const selectedTicketId = ref<string | null>(null);
    const guests = ref<Guest[]>([Guest.empty()]);
    const isSendingGuestlists = ref(false);
    const lastSendSuccessful = ref(false);

    async function saveGuests(): Promise<void> {
        if (!await validate()) {
            return;
        }

        lastSendSuccessful.value = false;
        isSendingGuestlists.value = true;

        let media = parseGuestsToCsv();

        try {
            await _importGuests(
                unref(organizationId),
                unref(selectedTicketId)!,
                media,
                0,
                3,
                1,
                2,
                unref(deductStock),
                CsvDelimiter.Comma,
                true
            );

            await resetForm();
        } finally {
            isSendingGuestlists.value = false;
        }
    }

    async function resetForm(): Promise<void> {
        guests.value = [Guest.empty()];
        selectedTicketId.value = null;
        deductStock.value = false;
        isSendingGuestlists.value = false;
        lastSendSuccessful.value = true;

        await nextTick(resetValidation);
    }

    function parseGuestsToCsv(): Blob {
        let headers = ['Email', 'FirstName', 'LastName', 'Quantity'];
        let guestRows = guests.value.map(g => [g.email, g.firstName, g.lastName, g.quantity])
            .join('\n');

        const rows = [headers, guestRows].join('\n');

        return new Blob([rows], {type: 'text/csv'});
    }

    function addGuest(): void {
        guests.value.push(Guest.empty());
    }

    function deleteGuest(index: number): void {
        guests.value.splice(index, 1);

        if (unref(guests).length === 0) {
            addGuest();
        }
    }
</script>

<style
    lang="scss"
    module>
    .toggleFormRowOffset {
        margin-top: 6px;
    }
</style>
