<template>
    <ShopElement
        :editor-elements="editorElements"
        :editor-elements-emit="editorElementsEmit"
        :internal-id="element.internalId"
        @edit="edit">
        <template #edit>
            <FluxPaneBody>
                <FluxFormColumn>
                    <ValidationField
                        :current-length="localElement.content.length"
                        :label="t('event.create.shops.element.notice.message')"
                        :max-length="250"
                        :rules="{required, minLength: minLength(3), maxLength: maxLength(250)}"
                        :value="localElement.content">
                        <FluxFormTextArea
                            v-model="localElement.content"
                            data-testid="create-event-shop-element-add-notice-message"
                            :placeholder="t('event.create.shops.element.notice.messagePlaceholder')"
                            :rows="3"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('event.create.shops.element.notice.variant')"
                        :rules="{required}"
                        :value="localElement.variant">
                        <FluxFormSelect
                            v-model="localElement.variant"
                            data-testid="create-event-shop-element-add-notice-variant"
                            :options="variantOptions"/>
                    </ValidationField>
                </FluxFormColumn>
            </FluxPaneBody>
        </template>

        <FluxNotice
            :icon="icon"
            :message="element.content"
            :variant="element.variant.toString() === 'error' ? 'danger' : element.variant"/>
    </ShopElement>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopElement, CreateEventShopNoticeElement } from '@fancee/data';
    import type { FluxFormSelectOption, IconNames } from '@fancee/flux';
    import { computed, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { maxLength, minLength, required } from '@/data/validation';
    import ShopElement from './ShopElement.vue';

    export interface Props {
        readonly editorElements: CreateEventShopElement[];
        readonly editorElementsEmit: Function;
        readonly element: CreateEventShopNoticeElement;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const {t} = useI18n();

    const icon = computed<IconNames>(() => {
        switch (props.element.variant) {
            case 'danger':
            case 'warning':
                return 'circle-exclamation';

            case 'info':
            case 'primary':
                return 'circle-info';

            default:
                return 'circle-check';
        }
    });

    const variantOptions: FluxFormSelectOption[] = [
        {id: 'danger', label: t('event.create.shops.element.notice.variants.danger')},
        {id: 'info', label: t('event.create.shops.element.notice.variants.info')},
        {id: 'success', label: t('event.create.shops.element.notice.variants.success')},
        {id: 'warning', label: t('event.create.shops.element.notice.variants.warning')}
    ];

    const localElement = ref(new CreateEventShopNoticeElement(unref(element).content, unref(element).variant));

    function edit(commitChanges: boolean): void {
        if (commitChanges) {
            element.value.content = unref(localElement).content;
            element.value.variant = unref(localElement).variant;
            return;
        }

        localElement.value = new CreateEventShopNoticeElement(unref(element).content, unref(element).variant);
    }
</script>
