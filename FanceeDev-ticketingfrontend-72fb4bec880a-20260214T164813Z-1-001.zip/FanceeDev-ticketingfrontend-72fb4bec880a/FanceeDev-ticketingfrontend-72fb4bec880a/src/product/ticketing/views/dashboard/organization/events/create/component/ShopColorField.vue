<template>
    <FluxFormField :label="label">
        <FluxFormInput
            v-model="internalValue"
            :data-testid="`create-event-shop-color-${label}`"
            type="color"/>
    </FluxFormField>
</template>

<script lang="ts">
    export default {
        model: {
            prop: 'modelValue',
            event: 'update:modelValue'
        }
    };
</script>

<script
    lang="ts"
    setup>
    import { ref, toRefs, watch } from 'vue';

    interface Emits {
        (e: 'update:modelValue', value: string | null): void;
    }

    interface Props {
        readonly defaultColor: string;
        readonly label: string;
        readonly modelValue?: string | null;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {defaultColor, modelValue} = toRefs(props);

    const internalValue = ref('#000000');

    watch([defaultColor, modelValue], ([defaultColor, modelValue]) => {
        internalValue.value = (modelValue ?? defaultColor ?? '#000000') as string;
    }, {immediate: true});

    watch([defaultColor, internalValue], ([defaultColor, internalValue]) => {
        if (defaultColor === internalValue) {
            emit('update:modelValue', null);
        } else {
            emit('update:modelValue', internalValue);
        }
    });
</script>
