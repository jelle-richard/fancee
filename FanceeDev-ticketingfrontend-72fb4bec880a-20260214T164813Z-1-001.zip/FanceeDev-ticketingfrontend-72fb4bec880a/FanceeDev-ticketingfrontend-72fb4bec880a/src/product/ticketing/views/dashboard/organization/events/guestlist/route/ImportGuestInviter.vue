<template>
    <FluxPane>
        <FluxPaneHeader
            :title="event.name"
            :sub-title="formatDateTimeLocal(event.dateTimeSpan.start)"/>

        <FluxPaneBody>
            <FluxNotice
                icon="circle-info"
                is-small>
                <p>{{ t('event.guestlist.manage.import.info') }}</p>
                <p>{{ t('event.guestlist.manage.import.maxRows', [asFormattedNumber(MAX_VALUE_GUESTLIST_IMPORT)]) }}</p>
            </FluxNotice>
        </FluxPaneBody>

        <FluxPaneBody>
            <FluxFormColumn>
                <ResponseErrorsNotice
                    v-if="hasErrors"
                    :errors="errors"/>

                <FluxNotice
                    v-if="lastSendSuccessful"
                    icon="circle-check"
                    is-small
                    :message="t('event.guestlist.manage.success')"
                    variant="success"/>

                <FluxNotice
                    v-if="maxRowsExceeded"
                    is-small
                    icon="circle-info"
                    :message="t('event.guestlist.manage.import.maxRowsExceeded', [asFormattedNumber(MAX_VALUE_GUESTLIST_IMPORT)])"
                    variant="danger"/>

                <FluxNotice
                    v-if="file && fieldMappingIndexByFieldType(GuestFieldType.Email) === null"
                    is-small
                    icon="circle-exclamation"
                    :message="t('event.guestlist.manage.import.missingEmailField')"
                    variant="warning"/>

                <FluxNotice
                    v-if="file && fieldMappingIndexByFieldType(GuestFieldType.Quantity) === null"
                    is-small
                    icon="circle-exclamation"
                    :message="t('event.guestlist.manage.import.missingQuantityField')"
                    variant="warning"/>

                <FluxFormRow>
                    <input
                        :class="$style.fileUploadOverlay"
                        type="file"
                        accept=".csv"
                        @change="setFile">

                    <FluxSecondaryButton
                        :class="$style.fileUploadButton"
                        :label="t('event.guestlist.manage.import.choose')"
                        icon-before="arrow-up-from-line"/>

                    <ValidationField
                        :class="$style.ticketField"
                        :label="t('event.ticketSingular')"
                        :rules="{required}"
                        :value="selectedTicketId">
                        <FluxFormSelectAsync
                            v-model="selectedTicketId"
                            :fetch-options="fetchSelect(async (ids: string[]) => await getEventProductOptions(organizationId, [eventId], null, ids))"
                            :fetch-relevant="fetchSelect(async () => await getEventProductOptions(organizationId, [eventId], null))"
                            :fetch-search="fetchSelect(async (searchQuery: string) => await getEventProductOptions(organizationId, [eventId], null, searchQuery))"/>
                    </ValidationField>

                    <FluxFormField
                        :class="$style.shrink"
                        :label="t('event.guestlist.manage.deduct')">
                        <FluxToggle
                            v-model="deductStock"
                            :class="$style.toggleFormRowOffset"/>
                    </FluxFormField>

                    <FluxFormField
                        :class="$style.shrink"
                        :label="t('event.guestlist.manage.hasHeader')">
                        <FluxToggle
                            v-model="hasHeader"
                            :class="$style.toggleFormRowOffset"/>
                    </FluxFormField>
                </FluxFormRow>
            </FluxFormColumn>
        </FluxPaneBody>

        <template v-if="file && !maxRowsExceeded">
            <FluxSeparator/>

            <FluxTable is-hoverable>
                <template #header>
                    <FluxTableHeader :class="$style.tableExample">{{ t('event.guestlist.manage.import.table.example') }}</FluxTableHeader>
                    <FluxTableHeader :class="$style.tableField">{{ t('event.guestlist.manage.import.table.field') }}</FluxTableHeader>
                    <FluxTableHeader/>
                </template>

                <template #rows>
                    <FluxTableRow v-for="(column, index) of csvPreviewRows[hasHeader ? 1 : 0]">
                        <FluxTableCell>
                            {{ column }}
                        </FluxTableCell>

                        <FluxTableCell>
                            <FluxFormSelect
                                v-model="fieldMappings[index].id"
                                :class="$style.fieldTypeTableOffset"
                                :options="fieldOptions"/>
                        </FluxTableCell>

                        <FluxTableCell/>
                    </FluxTableRow>
                </template>
            </FluxTable>
        </template>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxPrimaryButton
                :disabled="invalid || !requirementsMet"
                icon-before="paper-plane"
                :is-loading="isSendingGuestlists"
                :label="t('global.send')"
                @click="validated(saveGuests)"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ProductService, SelectService } from '@fancee/api';
    import { CsvDelimiter, EventDetails } from '@fancee/data';
    import { computed, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { useActiveOrganizationId, useRequestErrorBoundary, useService, useValidationScope } from '@/composable';
    import { GuestFieldType, MAX_VALUE_GUESTLIST_IMPORT } from '@/data';
    import { CsvAdapter } from '@/data/adapter/file/CsvAdapter';
    import { required } from '@/data/validation';
    import { asFormattedNumber, fetchSelect, formatDateTimeLocal } from '@/util';
    import { ResponseErrorsNotice } from '@/components/ui';

    export interface Props {
        readonly event: EventDetails;
        readonly eventId: string;
    }

    defineProps<Props>();

    const {t} = useI18n();
    const {importGuests} = useService(ProductService);
    const {getEventProductOptions} = useService(SelectService);
    const {errors, hasErrors, reset: resetErrors} = useRequestErrorBoundary();
    const {invalid, validated} = useValidationScope();
    const organizationId = useActiveOrganizationId();

    const selectedTicketId = ref<string | null>(null);
    const hasHeader = ref(false);
    const fieldMappings = ref<Record<string, unknown>[]>([]);
    const file = ref<Blob | null>(null);
    const csvPreviewRows = ref<string[][]>([]);
    const fileRows = ref<string[][]>([]);
    const deductStock = ref(false);
    const isSendingGuestlists = ref(false);
    const lastSendSuccessful = ref(false);
    const delimiterName = ref<CsvDelimiter>(CsvDelimiter.Comma);
    const fieldOptions = [
        {id: GuestFieldType.Email, label: t('form.field.email')},
        {id: GuestFieldType.FirstName, label: t('form.field.firstName')},
        {id: GuestFieldType.LastName, label: t('form.field.lastName')},
        {id: GuestFieldType.Quantity, label: t('form.field.quantity')}
    ];

    const maxRowsExceeded = computed((): boolean => (unref(hasHeader) ? unref(fileRows).length - 1 : unref(fileRows).length) > MAX_VALUE_GUESTLIST_IMPORT);
    const requirementsMet = computed(() => fieldMappingIndexByFieldType(GuestFieldType.Email) !== null && fieldMappingIndexByFieldType(GuestFieldType.Quantity) !== null);

    async function saveGuests(): Promise<void> {
        if (!unref(requirementsMet)) {
            return;
        }

        isSendingGuestlists.value = true;
        lastSendSuccessful.value = false;
        resetErrors();

        try {
            await importGuests(
                unref(organizationId),
                unref(selectedTicketId)!,
                unref(file) as Blob,
                fieldMappingIndexByFieldType(GuestFieldType.Email)!,
                fieldMappingIndexByFieldType(GuestFieldType.Quantity)!,
                fieldMappingIndexByFieldType(GuestFieldType.FirstName),
                fieldMappingIndexByFieldType(GuestFieldType.LastName),
                unref(deductStock),
                unref(delimiterName),
                unref(hasHeader)
            );

            resetForm();
        } finally {
            isSendingGuestlists.value = false;
        }
    }

    function resetForm(): void {
        selectedTicketId.value = null;
        deductStock.value = false;
        isSendingGuestlists.value = false;
        lastSendSuccessful.value = true;
        csvPreviewRows.value = [];
        fieldMappings.value = [];
        file.value = null;
    }

    function setFile(event: Event): void {
        file.value = (event.target as HTMLInputElement).files![0];
        if (unref(file) === null) {
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            let result = reader.result;

            if (!result) {
                return;
            }

            result = result.toString();

            delimiterName.value = CsvAdapter.detectDelimiter(result);
            csvPreviewRows.value = CsvAdapter.csvStringToRowColumns(result, delimiterName.value, 2);
            fileRows.value = CsvAdapter.csvStringToRowColumns(result, delimiterName.value, MAX_VALUE_GUESTLIST_IMPORT + 2);

            for (let i = 0; i < csvPreviewRows.value[0].length; i++) {
                fieldMappings.value.push({id: null, label: ''});
            }
        };
        reader.readAsText(unref(file)!);
    }

    function fieldMappingIndexByFieldType(fieldType: GuestFieldType): number | null {
        for (let i = 0; i < fieldMappings.value.length; i++) {
            if (fieldMappings.value[i]['id'] === fieldType) {
                return i;
            }
        }

        return null;
    }
</script>

<style
    lang="scss"
    module>
    .toggleFormRowOffset {
        margin-top: 6px;
    }

    .fileUploadOverlay {
        position: absolute;
        width: 140px;
        height: 42px;
        margin-top: 30px;
        opacity: 0;
    }

    .fileUploadButton {
        margin-top: 30px;
        width: 140px;
    }

    .tableExample,
    .tableField {
        width: 300px;
    }

    .shrink {
        flex-grow: 0;
        flex-shrink: 1;
        white-space: nowrap;
    }

    .ticketField {
        max-width: 360px;
    }
</style>
