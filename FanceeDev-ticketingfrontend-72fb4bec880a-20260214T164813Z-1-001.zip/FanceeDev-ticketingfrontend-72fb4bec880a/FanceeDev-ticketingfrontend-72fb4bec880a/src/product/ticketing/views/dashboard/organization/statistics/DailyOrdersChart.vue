<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="t('dashboard.statistics.dailyOrders.title')"
            :sub-title="t('dashboard.statistics.dailyOrders.subTitle')">

            <FluxStack
                axis="horizontal"
                :gap="9">

                <FluxFormSelect
                    v-model="historyAmountDays"
                    :class="$style.daysSelector"
                    :options="options"/>

                <FluxTooltip :content="t('global.n.previous.days', dailyHistoryDays)">
                    <FluxSecondaryButton
                        icon-before="chevron-left"
                        @click="$emit('previous')"/>
                </FluxTooltip>

                <FluxTooltip :content="t('global.n.next.days', dailyHistoryDays)">
                    <FluxSecondaryButton
                        :disabled="currentDateReached"
                        icon-before="chevron-right"
                        @click="$emit('next')"/>
                </FluxTooltip>
            </FluxStack>
        </FluxPaneHeader>

        <FluxPaneBody>
            <ApexChart
                :key="dailyOrders.length"
                type="line"
                height="400"
                :options="dailyOrdersLineOptions"
                :series="dailyOrdersLineSeries"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DailyOrder } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { reactive, Ref, ref, toRefs, unref, useCssModule, watch } from 'vue';
    import { useCurrency } from '@/composable';
    import { CHART_BORDER_LABEL_COLOR, LUXON_DATE_FORMAT } from '@/data';
    import { asMoney } from '@/util';
    import ApexChart from 'vue3-apexcharts';
    import { useI18n } from 'vue-i18n';

    export type Emits = {
        (e: 'previous'): void;
        (e: 'next'): void;
        (e: 'history-amount', value: number): void;
    };

    export type Props = {
        readonly dailyOrders: DailyOrder[];
        readonly isLoading: boolean;
        readonly dailyHistoryDays: number;
        readonly currentDateReached: boolean;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {dailyOrders} = toRefs(props);

    const {t} = useI18n();
    const styles = useCssModule();
    const currency = useCurrency();

    const historyAmountDays = ref(7);
    const options: FluxFormSelectOption[] = [
        {id: 7, label: t('global.n.days', 7)},
        {id: 14, label: t('global.n.days', 14)},
        {id: 21, label: t('global.n.days', 21)},
        {id: 28, label: t('global.n.days', 28)}
    ];

    const dailyOrdersLineSeries = ref<object[]>([
        {
            name: t('dashboard.statistics.dailyOrders.ordersOnDay'),
            type: 'line',
            data: []
        },
        {
            name: t('dashboard.statistics.dailyOrders.onlineRevenue'),
            type: 'column',
            data: []
        },
        {
            name: t('dashboard.statistics.dailyOrders.cashRevenue'),
            type: 'column',
            data: []
        }
    ]) as unknown as Ref<object[]>;

    const dailyOrdersLineOptions = reactive<any>({
        chart: {
            zoom: {
                enabled: false
            },
            stacked: true,
            toolbar: {
                show: false
            }
        },
        xaxis: {
            categories: []
        },
        colors: ['#89a69d', '#6071b5', '#f59f40'],
        dataLabels: {
            enabled: false
        },
        stroke: {
            width: [4, 1, 1]
        },
        tooltip: {
            custom: (data: any) => generateTooltip(data.dataPointIndex)
        },
        yaxis: [
            {
                axisTicks: {
                    show: true
                },
                tickAmount: 1,
                axisBorder: {
                    show: true,
                    color: CHART_BORDER_LABEL_COLOR
                },
                labels: {
                    style: {
                        colors: CHART_BORDER_LABEL_COLOR
                    },
                    formatter: (val: number) => val.toFixed(0)
                },
                title: {
                    text: t('dashboard.statistics.dailyOrders.orders'),
                    style: {
                        color: '#0c0019'
                    }
                }
            },
            {
                opposite: true,
                axisTicks: {
                    show: true
                },
                axisBorder: {
                    show: true,
                    color: CHART_BORDER_LABEL_COLOR
                },
                labels: {
                    style: {
                        colors: CHART_BORDER_LABEL_COLOR
                    },
                    formatter: getParsedChartRevenue
                },
                title: {
                    text: t('dashboard.statistics.dailyOrders.revenueFlow'),
                    style: {
                        color: CHART_BORDER_LABEL_COLOR
                    }
                }
            },
            {
                show: false,
                labels: {
                    formatter: getParsedChartRevenue
                }
            }
        ],
        legend: {
            position: 'top',
            horizontalAlign: 'left',
            offsetX: 40
        }
    });

    function generateTooltip(index: number): string {
        let dailyOrder: DailyOrder = dailyOrders.value[index];

        return `<div class="${styles.chartTooltip}">
                    <p>${t('dashboard.statistics.dailyOrders.orders')}: ${dailyOrder.totalOrders}</p>
                    <p>${t('dashboard.statistics.dailyOrders.productsSold')}: ${dailyOrder.totalProductsSold}</p>
                    <p>${t('dashboard.statistics.dailyOrders.onlineRevenue')}: ${getParsedChartRevenue(dailyOrder.onlineSalesRevenueCents)}</p>
                    <p>${t('dashboard.statistics.dailyOrders.cashRevenue')}: ${getParsedChartRevenue(dailyOrder.cashSalesRevenueCents)}</p>
                </div>`;
    }

    function getParsedChartRevenue(value: number): string {
        return asMoney(value, unref(currency));
    }

    watch(historyAmountDays, value => {
        emit('history-amount', value);
    });

    watch(dailyOrders, dailyOrders => {
        let dailyOrdersLength = dailyOrders.length;

        let xaxis: object = {
            categories: []
        };

        let ordersLineData: number[] = [];
        let onlineRevenueLineData: number[] = [];
        let cashRevenueLineData: number[] = [];

        for (let i = 0; i < dailyOrdersLength; i++) {
            let dailyOrder: DailyOrder = dailyOrders[i];

            xaxis['categories'][i] = dailyOrder.date.toFormat(LUXON_DATE_FORMAT);
            ordersLineData[i] = dailyOrder.totalOrders;
            onlineRevenueLineData[i] = dailyOrder.onlineSalesRevenueCents;
            cashRevenueLineData[i] = dailyOrder.cashSalesRevenueCents;
        }

        dailyOrdersLineOptions.xaxis = xaxis;
        dailyOrdersLineSeries.value[0]['data'] = ordersLineData;
        dailyOrdersLineSeries.value[1]['data'] = onlineRevenueLineData;
        dailyOrdersLineSeries.value[2]['data'] = cashRevenueLineData;
    }, {immediate: true});
</script>

<style
    lang="scss"
    module>
    .daysSelector {
        min-width: 150px;
    }

    .chartTooltip {
        padding: 12px;

        p {
            margin: 0;
        }
    }
</style>
