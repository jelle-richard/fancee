<template>
    <FluxGrid>
        <FluxGridColumn
            :sm="12"
            :md="8"
            :lg="9">
            <div>
                <p v-for="paragraph of tm('platform.profile.contact.emptyView') as string[]">
                    {{ rt(paragraph) }}
                </p>
            </div>
        </FluxGridColumn>

        <FluxGridColumn
            :sm="12"
            :md="4"
            :lg="3">
            <Visual
                class="full-width-auto-height"
                variant="comments"/>
        </FluxGridColumn>

        <FluxGridColumn :md="12">
            <FluxButtonStack>
                <FluxPrimaryButton
                    icon-before="circle-plus"
                    :label="t('platform.profile.contact.add')"
                    @click="addEmptyContact"/>
            </FluxButtonStack>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { Visual } from '@/components/ui';

    export type Emits = {
        (e: 'add'): void;
    };

    const emit = defineEmits<Emits>();

    const {rt, t, tm} = useI18n();

    function addEmptyContact(): void {
        emit('add');
    }
</script>
