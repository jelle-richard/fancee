<template>
    <button
        class="ticket-design-cell-button"
        :disabled="disabled"
        tabindex="-1"
        @click="$emit('click', $event)">
        <FluxIcon
            :size="18"
            :variant="icon"/>
    </button>
</template>

<script
    lang="ts"
    setup>
    import type { IconNames } from '@fancee/flux';

    export interface Emits {
        (e: 'click', evt: MouseEvent): void;
    }

    export interface Props {
        readonly disabled?: boolean;
        readonly icon: IconNames;
    }

    defineEmits<Emits>();
    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .ticket-design-cell-button {
        display: flex;
        height: 36px;
        width: 36px;
        padding: 6px;
        align-items: center;
        flex: 0 0 36px;
        justify-content: center;
        backdrop-filter: blur(5px) saturate(180%);
        background: rgb(var(--gray-0) / .9);
        background-clip: padding-box;
        border: 1px solid rgb(var(--gray-11) / .05);
        border-radius: 99px;
        box-shadow: var(--shadow-lg);
        color: var(--foreground-prominent);
        cursor: pointer;
        transition: background 180ms var(--swift-out);

        &:hover {
            background-color: rgb(var(--gray-0));
            border: 1px solid rgb(var(--gray-11) / .1);
            box-shadow: var(--shadow-xl);
        }

        &:disabled {
            opacity: 0;
            pointer-events: none;
        }
    }
</style>
