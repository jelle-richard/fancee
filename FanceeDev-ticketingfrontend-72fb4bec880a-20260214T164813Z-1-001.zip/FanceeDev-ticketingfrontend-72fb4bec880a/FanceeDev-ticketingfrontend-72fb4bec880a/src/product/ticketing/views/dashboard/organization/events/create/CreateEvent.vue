<template>
    <FluxContainer :gutter="0">
        <RouterView/>
    </FluxContainer>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventService } from '@fancee/api';
    import { onMounted, onUnmounted, provide, ref, unref, watch } from 'vue';
    import { useActiveOrganizationId, useRouteParam, useRouter, useService } from '@/composable';
    import { useCreateEventStore, useStore, useUiStore } from '@/data/store';

    const {getEvent} = useService(CreateEventService);
    const {setDetails, setEventId} = useStore(useCreateEventStore());
    const {setNavigation} = useStore(useUiStore());
    const eventId = useRouteParam('eventId');
    const organizationId = useActiveOrganizationId();
    const router = useRouter();

    const isLoading = ref(false);

    onMounted(() => {
        if (unref(eventId) !== 'new') {
            return;
        }

        router.push({
            name: 'create-event'
        });
    });

    onUnmounted(() => setNavigation(null));

    async function loadEvent(eventId: string): Promise<void> {
        isLoading.value = true;

        const {data: eventDetails} = await getEvent(unref(organizationId), eventId);

        setDetails(eventDetails);
        setEventId(eventId);

        isLoading.value = false;
    }

    watch(eventId, async eventId => {
        if (!eventId || eventId === 'new') {
            return;
        }

        setNavigation([
            {
                icon: 'left',
                route: 'my-events',
                title: 'global.back'
            },
            {
                separator: true
            },
            {
                icon: 'pen',
                route: 'create-event-details',
                routeParams: {eventId: unref(eventId)},
                title: 'event.create.step.details'
            },
            {
                icon: 'shopping-bag',
                route: 'create-event-products',
                routeParams: {eventId: unref(eventId)},
                title: 'event.create.step.products'
            },
            {
                icon: 'store',
                route: 'create-event-shops',
                routeParams: {eventId: unref(eventId)},
                title: 'event.create.step.shops'
            },
            {
                icon: 'coin',
                route: 'create-event-payment',
                routeParams: {eventId: unref(eventId)},
                title: 'event.create.step.payment'
            },
            {
                icon: 'envelope',
                route: 'create-event-mailing',
                routeParams: {eventId: unref(eventId)},
                title: 'event.create.step.mailing'
            },
            {
                icon: 'pen-ruler',
                route: 'create-event-design',
                routeParams: {eventId: unref(eventId)},
                title: 'event.create.step.design'
            },
            {
                icon: 'circle-check',
                route: 'create-event-publish',
                routeParams: {eventId: unref(eventId)},
                title: 'event.create.step.publish'
            }
        ]);

        await loadEvent(eventId);
    }, {immediate: true, flush: 'post'});

    provide('create-event', loadEvent);
</script>
