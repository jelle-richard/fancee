<template>
    <FluxPane>
        <FluxPaneHeader
            icon="key"
            :title="t('event.secureCode.add.title')">
            <FluxSecondaryButton
                icon-before="xmark"
                @click="closeOverlay()"/>
        </FluxPaneHeader>

        <FluxPaneBody>
            <FluxStack :gap="15">
                <CombinedFormNotice/>

                <FluxNotice
                    v-if="validateImport.length > 0"
                    icon="circle-info"
                    is-small
                    :title="t('event.secureCode.add.pleaseFix')"
                    variant="danger">
                    <ul>
                        <template v-for="error in validateImport">
                            <li>{{ error }}</li>
                        </template>
                    </ul>
                </FluxNotice>

                <FluxTabs v-model="selectedTabIndex">
                    <FluxTab :label="t('event.secureCode.add.manual')">
                        <FluxFormRow>
                            <ValidationField
                                :label="t('event.secureCode.singular')"
                                :rules="{required, secureCode, minLength: minLength(2), maxLength: maxLength(254)}"
                                :value="enteredSecureCode">
                                <FluxFormInput
                                    v-model="enteredSecureCode"
                                    type="text"/>
                            </ValidationField>

                            <ValidationField
                                :hint="t('event.secureCode.add.maxUsesHint')"
                                :label="t('event.secureCode.add.maxUses')"
                                :rules="{integer, minValue: minValue(0), maxValue: maxValue(999999)}"
                                :value="maxUses">
                                <FluxFormInput
                                    v-model="maxUses"
                                    type="number"
                                    :step="1"/>
                            </ValidationField>
                        </FluxFormRow>
                    </FluxTab>

                    <FluxTab :label="t('event.secureCode.add.import.title')">
                        <ImportSecureCodes
                            @file-changed="file = $event"
                            @delimiter-name-changed="delimiterName = $event"
                            @has-header-changed="hasHeader = $event"
                            @total-rows-changed="totalRows = $event"
                            @field-mapping-changed="fieldMappings = $event"/>
                    </FluxTab>
                </FluxTabs>
            </FluxStack>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxSecondaryButton
                :label="t('global.close')"
                @click="closeOverlay()"/>

            <FluxPrimaryButton
                :disabled="invalid || validateImport.length > 0"
                icon-before="circle-check"
                :label="selectedTabIndex === 0 ? t('global.add') : t('event.secureCode.add.import.title')"
                :is-loading="isAddingSecureCodes"
                @click="selectedTabIndex === 0 ? addSecureCodes() : importSecureCodes()"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { SecureCodeService } from '@fancee/api';
    import { CsvDelimiter, SecureCode, SecureCodeImportCsv } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { useActiveOrganizationId, useRequestErrorBoundary, useService, useValidationScope } from '@/composable';
    import { SecureCodeFieldType } from '@/data';
    import { CsvAdapter } from '@/data/adapter/file/CsvAdapter';
    import { integer, maxLength, maxValue, minLength, minValue, required, secureCode } from '@/data/validation';
    import { guarded } from '@/util';
    import ImportSecureCodes from './ImportSecureCodes.vue';

    export type Emits = {
        (e: 'close', forceUpdate: boolean): void;
    };

    export type Props = {
        readonly shopCode?: string | null;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {shopCode} = toRefs(props);

    const {t} = useI18n();
    const {create, import: importSecureCodesForShop} = useService(SecureCodeService);
    const {invalid, validate} = useValidationScope();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const organizationId = useActiveOrganizationId();

    //todo: Make it so that guarded can access response errors (FAN-2900)
    const _create = create;
    const _importSecureCodesForShop = guarded(importSecureCodesForShop, t('ui.somethingWentWrong.title'), t('event.secureCode.add.import.failed'));

    const isAddingSecureCodes = ref(false);
    const selectedTabIndex = ref(0);
    const maxUses = ref<number | null>(null);
    const file = ref<File | null>(null);
    const delimiterName = ref(CsvDelimiter.Comma);
    const hasHeader = ref(false);
    const fieldMappings = ref<{ id: string | null, label: string }[]>([]);
    const totalRows = ref(0);
    const enteredSecureCode = ref('');

    const validateImport = computed<string[]>(() => {
        let errors: string[] = [];

        if (unref(selectedTabIndex) === 1) {
            if (unref(file) && CsvAdapter.fieldMappingIndexByFieldType(SecureCodeFieldType.Code, unref(fieldMappings)) === null) {
                errors.push(t('event.secureCode.add.noneSelected'));
            }

            if (unref(file) && CsvAdapter.fieldMappingIndexByFieldType(SecureCodeFieldType.MaxUses, unref(fieldMappings)) === null) {
                errors.push(t('event.secureCode.add.noMaxUsesSelected'));
            }

            let fields = fieldMappings.value
                .filter(fm => fm.id !== null)
                .map(item => item.id);

            if (fields.some((item, idx) => fields.indexOf(item) !== idx)) {
                errors.push(t('event.secureCode.add.duplicates'));
            }
        }

        return errors;
    });

    async function addSecureCodes(): Promise<void> {
        if (!await validate() || unref(shopCode) === null) {
            return;
        }

        isAddingSecureCodes.value = true;

        if (unref(maxUses) === 0) {
            maxUses.value = null;
        }

        try {
            await _create(unref(organizationId), unref(shopCode)!, new SecureCode(unref(enteredSecureCode), unref(maxUses), true));

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('event.secureCode.add.success')
            });

            closeOverlay(true);
        } finally {
            isAddingSecureCodes.value = false;
        }
    }

    async function importSecureCodes(): Promise<void> {
        if (!await validate()) {
            return;
        }

        isAddingSecureCodes.value = true;

        try {
            await _importSecureCodesForShop(
                unref(organizationId),
                unref(shopCode)!,
                new SecureCodeImportCsv(
                    unref(file)!,
                    CsvAdapter.fieldMappingIndexByFieldType(SecureCodeFieldType.Code, unref(fieldMappings))!,
                    CsvAdapter.fieldMappingIndexByFieldType(SecureCodeFieldType.MaxUses, unref(fieldMappings))!,
                    unref(delimiterName),
                    unref(hasHeader)
                )
            );

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('event.secureCode.add.import.success')
            });

            closeOverlay(true);
        } finally {
            isAddingSecureCodes.value = false;
        }
    }

    function closeOverlay(forceUpdate: boolean = false): void {
        clearSelection();
        emit('close', forceUpdate);
    }

    function clearSelection(): void {
        enteredSecureCode.value = '';
        maxUses.value = 0;
        fieldMappings.value = [];
        file.value = null;
        hasHeader.value = false;
        delimiterName.value = CsvDelimiter.Comma;
        totalRows.value = 0;
    }

    watch(selectedTabIndex, () => {
        clearSelection();
    });

    watch(enteredSecureCode, () => {
        resetErrors();
    });
</script>
