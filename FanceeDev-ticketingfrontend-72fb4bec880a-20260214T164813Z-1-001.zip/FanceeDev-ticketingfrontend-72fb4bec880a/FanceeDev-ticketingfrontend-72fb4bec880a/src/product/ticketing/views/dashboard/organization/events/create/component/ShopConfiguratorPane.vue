<template>
    <FluxPane
        v-if="shop"
        :is-loading="isRemovingHeaderMedia || isUploadingHeaderMedia">
        <FluxExpandableGroup>
            <ValidationExpandable :label="t('event.create.shops.configurator.details.title')">
                <FluxFormColumn>
                    <ValidationField
                        :label="t('event.create.shops.configurator.details.name.label')"
                        :rules="{required, minLength: minLength(3), maxLength: maxLength(50)}"
                        :value="shop.name">
                        <FluxFormInput
                            v-model="shop.name"
                            :max-length="50"
                            data-testid="create-event-shop-name"
                            :placeholder="t('event.create.shops.configurator.details.name.placeholder')"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('event.create.shops.configurator.details.startDate')"
                        :rules="{beforeDate: beforeDate(shop.dateTimeSpan.end)}"
                        :value="shop.dateTimeSpan.start">
                        <FluxFormDateTimeInput
                            v-model="shop.dateTimeSpan.start"
                            data-testid="create-event-shop-start-date"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('event.create.shops.configurator.details.endDate')"
                        :rules="{afterDate: afterDate(shop.dateTimeSpan.start)}"
                        :value="shop.dateTimeSpan.end">
                        <FluxFormDateTimeInput
                            v-model="shop.dateTimeSpan.end"
                            data-testid="create-event-shop-end-date"/>
                    </ValidationField>

                    <FluxFormField :label="t('event.create.shops.configurator.details.active')">
                        <FluxToggle
                            v-model="shop.isActive"
                            data-testid="create-event-shop-is-active"/>
                    </FluxFormField>
                </FluxFormColumn>
            </ValidationExpandable>

            <ValidationExpandable :label="t('event.create.shops.configurator.marketing.title')">
                <FluxFormColumn>
                    <ValidationField
                        :current-length="shop.analytics.googleAnalyticsId?.length || 0"
                        :max-length="20"
                        :label="t('event.create.shops.configurator.marketing.googleAnalyticsId.label')"
                        :rules="{maxLength: maxLength(20)}"
                        :value="shop.analytics.googleAnalyticsId">
                        <FluxFormInput
                            v-model="shop.analytics.googleAnalyticsId"
                            :max-length="40"
                            data-testid="create-event-shop-google-analytics-id"
                            :placeholder="t('event.create.shops.configurator.marketing.googleAnalyticsId.placeholder')"/>
                    </ValidationField>

                    <ValidationField
                        :current-length="shop.analytics.googleTagManagerId?.length || 0"
                        :max-length="12"
                        :label="t('event.create.shops.configurator.marketing.googleTagManagerId.label')"
                        :rules="{maxLength: maxLength(12)}"
                        :value="shop.analytics.googleTagManagerId">
                        <FluxFormInput
                            v-model="shop.analytics.googleTagManagerId"
                            data-testid="create-event-shop-gtm-id"
                            :max-length="12"
                            :placeholder="t('event.create.shops.configurator.marketing.googleTagManagerId.placeholder')"/>
                    </ValidationField>

                    <ValidationField
                        :current-length="shop.analytics.tiktokPixelId?.length || 0"
                        :max-length="40"
                        :label="t('event.create.shops.configurator.marketing.tiktokPixelId.label')"
                        :rules="{maxLength: maxLength(40)}"
                        :value="shop.analytics.tiktokPixelId">
                        <FluxFormInput
                            v-model="shop.analytics.tiktokPixelId"
                            data-testid="create-event-shop-tiktok-pixel-id"
                            :max-length="40"
                            :placeholder="t('event.create.shops.configurator.marketing.tiktokPixelId.placeholder')"/>
                    </ValidationField>

                    <ValidationField
                        :current-length="shop.analytics.facebookPixelId?.length || 0"
                        :max-length="20"
                        :label="t('event.create.shops.configurator.marketing.facebookPixelId.label')"
                        :rules="facebookInputsRequired ? {required, maxLength: maxLength(20)} : {maxLength: maxLength(20)}"
                        :value="shop.analytics.facebookPixelId">
                        <FluxFormInput
                            v-model="shop.analytics.facebookPixelId"
                            data-testid="create-event-shop-facebook-pixel-id"
                            :max-length="20"
                            :placeholder="t('event.create.shops.configurator.marketing.facebookPixelId.placeholder')"/>
                    </ValidationField>

                    <ValidationField
                        :current-length="shop.analytics.facebookAccessCode?.length || 0"
                        :max-length="255"
                        :label="t('event.create.shops.configurator.marketing.facebookPixelId.accessToken')"
                        :rules="facebookInputsRequired ? {required, maxLength: maxLength(255)} : {maxLength: maxLength(255)}"
                        :value="shop.analytics.facebookAccessCode">
                        <FluxFormInput
                            v-model="shop.analytics.facebookAccessCode"
                            data-testid="create-event-shop-facebook-access-token"
                            :max-length="255"/>
                    </ValidationField>

                    <FluxNotice
                        v-if="facebookInputsRequired"
                        icon="circle-exclamation"
                        is-small
                        data-testid="create-event-shop-facebook-token-notice"
                        :message="t('event.create.shops.configurator.marketing.facebookPixelId.required')"
                        variant="warning"/>
                </FluxFormColumn>
            </ValidationExpandable>

            <ValidationExpandable :label="t('event.create.shops.configurator.fields.title')">
                <FluxFormColumn>
                    <p>{{ t('event.create.shops.configurator.fields.info') }}</p>

                    <FluxNotice
                        v-if="!!details.minimalAge"
                        :message="t('event.create.shops.configurator.fields.birthdateRequired')"
                        is-small
                        icon="cake"
                        variant="warning"/>

                    <FluxFormRow>
                        <FluxFormField :label="t('event.create.shops.configurator.fields.email')">
                            <FluxFormSelect
                                is-disabled
                                :options="basicFieldOptions"
                                data-testid="create-event-shop-email-require"
                                model-value="required"/>
                        </FluxFormField>

                        <FluxFormField :label="t('event.create.shops.configurator.fields.birthdate')">
                            <FluxFormSelect
                                v-model="birthdateRequirement"
                                data-testid="create-event-shop-birthdate-require"
                                :is-disabled="!!details.minimalAge"
                                :options="basicFieldOptions"/>
                        </FluxFormField>
                    </FluxFormRow>

                    <FluxFormRow>
                        <FluxFormField :label="t('event.create.shops.configurator.fields.firstName')">
                            <FluxFormSelect
                                v-model="firstNameRequirement"
                                data-testid="create-event-shop-firstname-require"
                                :options="basicFieldOptions"/>
                        </FluxFormField>

                        <FluxFormField :label="t('event.create.shops.configurator.fields.lastName')">
                            <FluxFormSelect
                                v-model="lastNameRequirement"
                                data-testid="create-event-shop-lastname-require"
                                :options="basicFieldOptions"/>
                        </FluxFormField>
                    </FluxFormRow>

                    <FluxFormRow>
                        <FluxFormField :label="t('event.create.shops.configurator.fields.phoneNumber')">
                            <FluxFormSelect
                                v-model="phoneNumberRequirement"
                                data-testid="create-event-shop-phone-require"
                                :options="basicFieldOptions"/>
                        </FluxFormField>

                        <FluxFormField :label="t('event.create.shops.configurator.fields.gender')">
                            <FluxFormSelect
                                v-model="genderRequirement"
                                data-testid="create-event-shop-gender-require"
                                :options="basicFieldOptions"/>
                        </FluxFormField>
                    </FluxFormRow>

                    <FluxFormRow>
                        <FluxFormField :label="t('event.create.shops.configurator.fields.address')">
                            <FluxFormSelect
                                v-model="addressRequirement"
                                data-testid="create-event-shop-address-require"
                                :options="basicFieldOptions"/>
                        </FluxFormField>

                        <FluxFormField :label="t('event.create.shops.configurator.fields.city')">
                            <FluxFormSelect
                                v-model="cityRequirement"
                                :options="basicFieldOptions"/>
                        </FluxFormField>
                    </FluxFormRow>
                </FluxFormColumn>
            </ValidationExpandable>

            <ValidationExpandable :label="t('event.create.shops.configurator.colors.title')">
                <FluxFormColumn>
                    <FluxFormRow>
                        <ShopColorField
                            v-model="shop.design.primaryColor"
                            :default-color="PRIMARY_SHOP_COLOR"
                            data-testid="create-event-shop-color-primary"
                            :label="t('event.create.shops.configurator.colors.primary')"/>

                        <ShopColorField
                            v-model="shop.design.backgroundColor"
                            :default-color="BACKGROUND_SHOP_COLOR"
                            data-testid="create-event-shop-color-background"
                            :label="t('event.create.shops.configurator.colors.background')"/>
                    </FluxFormRow>

                    <FluxFormRow>
                        <ShopColorField
                            v-model="shop.design.backdropColor"
                            :default-color="BACKDROP_SHOP_COLOR"
                            data-testid="create-event-shop-color-backdrop"
                            :label="t('event.create.shops.configurator.colors.panel')"/>

                        <ShopColorField
                            v-model="shop.design.textColor"
                            :default-color="TEXT_SHOP_COLOR"
                            data-testid="create-event-shop-color-text"
                            :label="t('event.create.shops.configurator.colors.text')"/>
                    </FluxFormRow>
                    <FluxStack
                        axis="horizontal"
                        :gap="12">
                        <FluxSpacer/>
                        <FluxSecondaryButton
                            :label="t('global.applyDefault')"
                            :is-loading="isLoadingPalette"
                            icon-before="palette"
                            data-testid="create-event-shop-color-apply-default"
                            @click="applyDefaultPalette"/>
                    </FluxStack>
                </FluxFormColumn>
            </ValidationExpandable>

            <ValidationExpandable :label="t('event.create.shops.configurator.images.title')">
                <FluxFormColumn>
                    <FluxFormField :label="t('event.create.shops.configurator.images.header')">
                        <FluxGallery
                            :key="shop.code"
                            is-editable
                            :pending-items="headerMediaPending"
                            data-testid="create-event-shop-header-media"
                            @delete="removeHeaderMedia(shop.design.headerMedia[$event].id!)"
                            @upload="uploadHeaderMedia">
                            <template
                                v-for="image of shop.design.headerMedia"
                                :key="image.url">
                                <FluxGalleryItem
                                    is-deletable
                                    :focal-point="image.focalPoint"
                                    :url="image.url"
                                    @delete="removeHeaderMedia(image.id!)"/>
                            </template>
                        </FluxGallery>

                        <p><small>{{ t('global.uploadHint.images') }}</small></p>

                        <FluxButtonStack v-if="shop.design.headerMedia.length > 0">
                            <FluxSpacer/>

                            <FocalPointEditor
                                :label="t('ui.focalPoint.plural')"
                                :images="shop.design.headerMedia"
                                @close="onFocalPointEditorClose"/>
                        </FluxButtonStack>

                        <FluxNoticeStack v-if="headerMediaErrors.length > 0">
                            <FluxNotice
                                v-for="(error, index) of headerMediaErrors"
                                :key="index"
                                icon="circle-exclamation"
                                is-small
                                :message="error"
                                variant="danger"/>
                        </FluxNoticeStack>
                    </FluxFormField>
                </FluxFormColumn>
            </ValidationExpandable>
        </FluxExpandableGroup>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventService, OrganizationDefaultsService } from '@fancee/api';
    import { isDtoDirty, markDtoClean } from '@fancee/client';
    import { Media, ShopField, ShopFieldRequirement } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { computed, onMounted, ref, unref, watch, WritableComputedOptions } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationExpandable, ValidationField } from '@/components/form';
    import { FocalPointEditor } from '@/components/ui';
    import { useActiveOrganizationId, useMultiFileManagement, useService } from '@/composable';
    import { BACKDROP_SHOP_COLOR, BACKGROUND_SHOP_COLOR, PRIMARY_SHOP_COLOR, ShopFieldOption, TEXT_SHOP_COLOR } from '@/data';
    import { storeToRefs, useCreateEventStore } from '@/data/store';
    import { afterDate, beforeDate, maxLength, minLength, required } from '@/data/validation';
    import { guarded } from '@/util';
    import ShopColorField from './ShopColorField.vue';

    type Requirement = 'required' | 'optional' | 'disabled';

    const createEventStore = useCreateEventStore();
    const {details, eventId, shop} = storeToRefs(createEventStore);

    const {t} = useI18n();
    const {deleteShopHeader, updateShopHeaderFocalPoint, uploadShopHeader} = useService(CreateEventService);
    const {getPalette} = useService(OrganizationDefaultsService);
    const organizationId = useActiveOrganizationId();

    const _getPalette = guarded(getPalette, t('ui.somethingWentWrong.title'), t('event.create.shops.configurator.defaultPalette.loadingFailed'));

    const isLoadingPalette = ref(false);

    const {
        errors: headerMediaErrors,
        isRemoving: isRemovingHeaderMedia,
        isUploading: isUploadingHeaderMedia,
        pendingMedia: pendingHeaderMedia,
        remove: removeHeaderMedia,
        upload: uploadHeaderMedia
    } = useMultiFileManagement({
        remove: async fileId => await deleteShopHeader(unref(organizationId), unref(eventId)!, unref(shop)!.code, fileId),
        upload: async file => {
            return await uploadShopHeader(unref(organizationId), unref(eventId)!, unref(shop)!.code, file);
        },
        onRemove(fileId: string): void {
            const design = unref(shop)!.design;

            if (!design) {
                return;
            }

            design.headerMedia.splice(design.headerMedia.findIndex(f => f.id === fileId), 1);
        },
        onUpload(media: Media): void {
            unref(shop)!.design?.headerMedia.push(media);
        }
    });

    const facebookInputsRequired = computed((): boolean => {
        if (((unref(shop)?.analytics.facebookPixelId?.trim().length || 0) > 0) && ((unref(shop)?.analytics.facebookAccessCode?.trim().length || 0) > 0)) {
            return false;
        }

        if ((unref(shop)?.analytics.facebookPixelId?.trim().length || 0) > 0) {
            return true;
        }

        return ((unref(shop)?.analytics.facebookAccessCode?.trim().length || 0) > 0);
    });

    const basicFieldOptions = computed<FluxFormSelectOption[]>(() => [
        {id: ShopFieldOption.Disabled, label: t('global.disabled')},
        {id: ShopFieldOption.Optional, label: t('global.optional')},
        {id: ShopFieldOption.Required, label: t('global.required')}
    ]);

    const fields = computed(() => unref(shop)!.fields);
    const headerMediaPending = computed(() => unref(pendingHeaderMedia).map(m => m.url));

    const birthdateRequirement = computed(createRequirementWritableComputed(ShopField.Birthdate, () => !!unref(details).minimalAge));
    const firstNameRequirement = computed(createRequirementWritableComputed(ShopField.FirstName));
    const lastNameRequirement = computed(createRequirementWritableComputed(ShopField.LastName));
    const phoneNumberRequirement = computed(createRequirementWritableComputed(ShopField.Phone));
    const genderRequirement = computed(createRequirementWritableComputed(ShopField.Gender));
    const addressRequirement = computed(createRequirementWritableComputed(ShopField.Address));
    const cityRequirement = computed(createRequirementWritableComputed(ShopField.City));

    onMounted(() => {
        birthdateRequirement.value = unref(birthdateRequirement);
        firstNameRequirement.value = unref(firstNameRequirement);
        lastNameRequirement.value = unref(lastNameRequirement);
        phoneNumberRequirement.value = unref(phoneNumberRequirement);
        genderRequirement.value = unref(genderRequirement);
        addressRequirement.value = unref(addressRequirement);
        cityRequirement.value = unref(cityRequirement);

        markDtoClean(unref(shop));
    });

    function createRequirementWritableComputed(field: ShopField, alwaysRequiredCheck?: () => boolean): WritableComputedOptions<Requirement> {
        return {
            get: () => alwaysRequiredCheck?.() ? 'required' : getFieldRequirement(field),
            set: (requirement: Requirement) => setFieldRequirement(field, alwaysRequiredCheck?.() ? 'required' : requirement)
        };
    }

    function getFieldRequirement(field: ShopField): Requirement {
        const requirement = unref(fields).find(f => f.field === field);

        if (requirement?.enabled && requirement?.required) {
            return 'required';
        }

        if (requirement?.enabled) {
            return 'optional';
        }

        return 'disabled';
    }

    function setFieldRequirement(field: ShopField, requirement: Requirement): void {
        const newFields = [...unref(fields)];

        if (newFields.find(f => f.field === field)) {
            newFields.splice(newFields.findIndex(f => f.field === field), 1);
        }

        newFields.push(new ShopFieldRequirement(field, requirement !== 'disabled', requirement === 'required'));

        unref(shop)!.fields = newFields;
    }

    async function onFocalPointEditorClose(): Promise<void> {
        for (const image of (unref(shop)!.design?.headerMedia ?? [])) {
            if (!isDtoDirty(image)) {
                continue;
            }

            await updateShopHeaderFocalPoint(unref(organizationId), unref(eventId)!, unref(shop)!.code, image);
            markDtoClean(image);
        }
    }

    async function applyDefaultPalette(): Promise<void> {
        if (shop.value === null) {
            return;
        }

        isLoadingPalette.value = true;

        try {
            const {data} = await _getPalette(unref(organizationId));

            shop.value.design.primaryColor = data.primaryColor;
            shop.value.design.backdropColor = data.backdropColor;
            shop.value.design.backgroundColor = data.backgroundColor;
            shop.value.design.textColor = data.textColor;
        } finally {
            isLoadingPalette.value = false;
        }
    }

    watch(addressRequirement, () => {
        let _addressRequirement = unref(addressRequirement);
        if (_addressRequirement === 'required' || _addressRequirement === 'optional')
            cityRequirement.value = 'disabled';
    });

    watch(cityRequirement, () => {
        let _cityRequirement = unref(cityRequirement);
        if (_cityRequirement === 'required' || _cityRequirement === 'optional')
            addressRequirement.value = 'disabled';
    });
</script>
