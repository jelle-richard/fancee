<template>
    <FluxGrid>
        <FluxGridColumn
            xl="2"
            md="4"
            sm="6">
            <FluxPane :is-loading="globalEventStatistics === null">
                <FluxTooltip :content="t('dashboard.statistics.productsSold.tip', [globalEventStatistics?.productsSoldAmount || 0])">
                    <FluxStatistic
                        axis="vertical"
                        color="primary"
                        icon="shopping-bag"
                        :label="t('dashboard.statistics.productsSold.title')"
                        :value="asCompactNumber(globalEventStatistics?.productsSoldAmount || 0)"/>
                </FluxTooltip>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            xl="2"
            md="4"
            sm="6">
            <FluxPane :is-loading="globalEventStatistics === null">
                <FluxTooltip :content="t('dashboard.statistics.fulfilledOrders.tip', [globalEventStatistics?.ordersPlacedAmount || 0])">
                    <FluxStatistic
                        axis="vertical"
                        color="primary"
                        icon="cart-shopping"
                        :label="t('dashboard.statistics.fulfilledOrders.title')"
                        :value="asCompactNumber(globalEventStatistics?.ordersPlacedAmount || 0)"/>
                </FluxTooltip>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            xl="2"
            md="4"
            sm="6">
            <FluxPane :is-loading="globalEventStatistics === null">
                <FluxTooltip v-if="globalEventStatistics !== null">
                    <template #content>
                        <span v-if="globalEventStatistics.uniqueCustomers.uniqueMaleCustomers > 0">
                            {{ t('dashboard.statistics.uniqueCustomers.tip.male', [globalEventStatistics.uniqueCustomers.uniqueMaleCustomers]) }}
                        </span>

                        <span v-if="globalEventStatistics.uniqueCustomers.uniqueFemaleCustomers > 0">
                            {{ t('dashboard.statistics.uniqueCustomers.tip.female', [globalEventStatistics.uniqueCustomers.uniqueFemaleCustomers]) }}
                        </span>

                        <span v-if="globalEventStatistics.uniqueCustomers.uniqueNeutralCustomers > 0">
                            {{ t('dashboard.statistics.uniqueCustomers.tip.neutral', [globalEventStatistics.uniqueCustomers.uniqueNeutralCustomers]) }}
                        </span>

                        <span v-if="globalEventStatistics.uniqueCustomers.uniqueUnknownCustomers > 0">
                            {{ t('dashboard.statistics.uniqueCustomers.tip.unknown', [globalEventStatistics.uniqueCustomers.uniqueUnknownCustomers]) }}
                        </span>
                    </template>

                    <FluxStatistic
                        axis="vertical"
                        icon="chart-user"
                        color="primary"
                        :label="t('dashboard.statistics.uniqueCustomers.title')"
                        :value="asCompactNumber(totalUniqueCustomers())"/>
                </FluxTooltip>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            xl="2"
            md="4"
            sm="6">
            <FluxPane :is-loading="globalEventStatistics === null">
                <FluxTooltip :content="t('dashboard.statistics.ticketsScanned.tip', [globalEventStatistics?.ticketsScannedAmount || 0])">
                    <FluxStatistic
                        axis="vertical"
                        icon="scanner-gun"
                        color="primary"
                        :label="t('dashboard.statistics.ticketsScanned.title')"
                        :value="asCompactNumber(globalEventStatistics?.ticketsScannedAmount || 0)"/>
                </FluxTooltip>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            xl="2"
            md="4"
            sm="6">
            <FluxPane :is-loading="globalEventStatistics === null">
                <FluxTooltip v-if="globalEventStatistics !== null">
                    <template #content>
                        <span v-if="globalEventStatistics.averageAges.maleAverageAge !== null">
                            {{ t('dashboard.statistics.averageAge.tip.male', [globalEventStatistics.averageAges.maleAverageAge.toFixed(0)]) }}
                        </span>

                        <span v-if="globalEventStatistics.averageAges.femaleAverageAge !== null">
                            {{ t('dashboard.statistics.averageAge.tip.female', [globalEventStatistics.averageAges.femaleAverageAge.toFixed(0)]) }}
                        </span>

                        <span v-if="globalEventStatistics.averageAges.neutralAverageAge !== null">
                            {{ t('dashboard.statistics.averageAge.tip.neutral', [globalEventStatistics.averageAges.neutralAverageAge.toFixed(0)]) }}
                        </span>

                        <span v-if="globalEventStatistics.averageAges.unknownAverageAge !== null">
                            {{ t('dashboard.statistics.averageAge.tip.unknown', [globalEventStatistics.averageAges.unknownAverageAge.toFixed(0)]) }}
                        </span>
                    </template>

                    <FluxStatistic
                        axis="vertical"
                        icon="id-card"
                        color="primary"
                        :label="t('dashboard.statistics.averageAge.title')"
                        :value="globalEventStatistics.averageAges.totalAverageAge !== null ? globalEventStatistics.averageAges.totalAverageAge.toFixed(0) : '?'"/>
                </FluxTooltip>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            xl="2"
            md="4"
            sm="6">
            <FluxPane :is-loading="globalEventStatistics === null">
                <FluxTooltip :content="t('dashboard.statistics.pendingRefunds.tip', {amount: globalEventStatistics?.pendingRefundsAmount || 0})">
                    <FluxStatistic
                        axis="vertical"
                        icon="turn-down-left"
                        color="primary"
                        :label="t('dashboard.statistics.pendingRefunds.title')"
                        :value="asCompactNumber(globalEventStatistics?.pendingRefundsAmount || 0)"/>
                </FluxTooltip>
            </FluxPane>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { GlobalEventStatistics } from '@fancee/data';
    import { toRefs } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { asCompactNumber } from '@/util';

    export interface Props {
        readonly globalEventStatistics: GlobalEventStatistics | null;
    }

    const props = defineProps<Props>();
    const {globalEventStatistics} = toRefs(props);

    const {t} = useI18n();

    function totalUniqueCustomers(): number {
        if (globalEventStatistics.value === null) {
            return 0;
        }

        return globalEventStatistics.value.uniqueCustomers.uniqueMaleCustomers +
            globalEventStatistics.value.uniqueCustomers.uniqueFemaleCustomers +
            globalEventStatistics.value.uniqueCustomers.uniqueNeutralCustomers +
            globalEventStatistics.value.uniqueCustomers.uniqueUnknownCustomers;
    }
</script>
