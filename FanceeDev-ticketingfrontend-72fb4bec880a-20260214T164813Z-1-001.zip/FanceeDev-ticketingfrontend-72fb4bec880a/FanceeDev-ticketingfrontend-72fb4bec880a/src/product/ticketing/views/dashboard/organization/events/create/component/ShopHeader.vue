<template>
    <FluxPaneBody
        v-if="shop"
        class="shop-header">
        <FluxAspectRatio
            v-if="shop.design.headerMedia.length > 0"
            :aspect-ratio="7/3">
            <FluxFader
                :key="`${shop.code}_${shop.design.headerMedia.length}`"
                :interval="FADER_INTERVAL_MS">
                <FluxFaderItem
                    v-for="{id, focalPoint, url} of shop.design.headerMedia"
                    :key="id">
                    <FluxFocalPointImage
                        :focal-point="focalPoint"
                        :src="url"
                        alt=""/>
                </FluxFaderItem>
            </FluxFader>
        </FluxAspectRatio>

        <h1 class="shop-name shop-inset">{{ shop.name }}</h1>

        <div class="shop-details shop-inset">
            <div
                class="shop-description"
                v-html="details.description"/>

            <FluxInfoStack>
                <FluxInfo icon="calendar">
                    {{ formatDateTimeLocal(details.dateTimeSpan.start) }}
                </FluxInfo>
                <FluxInfo
                    v-if="details.location.formatted || details.location.venue"
                    icon="location-dot">
                    {{ details.location.venue }}
                    <br v-if="details.location.formatted && details.location.venue"/>
                    {{ details.location.formatted }}
                </FluxInfo>
                <FluxInfo
                    v-if="!!details.minimalAge"
                    icon="circle-exclamation">
                    {{ t('shop_minimal_age', {age: details.minimalAge}) }}
                </FluxInfo>
            </FluxInfoStack>
        </div>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { storeToRefs, useCreateEventStore } from '@/data/store';
    import { formatDateTimeLocal } from '@/util';
    import { FADER_INTERVAL_MS } from '@/data';

    const {t} = useI18n();
    const createEventStore = useCreateEventStore();
    const {details, shop} = storeToRefs(createEventStore);
</script>

<style
    lang="scss"
    scoped>
    .shop-header {
        display: flex;
        flex-flow: column;
        gap: 24px;
    }

    .shop-inset {
        margin-left: 15px;
        margin-right: 15px;
    }

    .shop-details {
        display: grid;
        gap: 21px;
        grid-template-columns: 1fr 210px;
    }

    .shop-name {
        margin-top: 12px;
        margin-bottom: -6px;
        word-break: break-word;
    }

    .shop-description ::v-deep(span) {
        color: unset !important;
    }
</style>
