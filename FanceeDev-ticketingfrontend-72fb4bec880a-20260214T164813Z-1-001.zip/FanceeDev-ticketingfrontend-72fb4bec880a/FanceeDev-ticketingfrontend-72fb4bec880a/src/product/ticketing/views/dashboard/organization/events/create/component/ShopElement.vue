<template>
    <div
        class="shop-element-mount"
        :class="{'is-indented': isIndented}">
        <FluxToolbar floating-mode="top-end">
            <template v-if="$slots.actions">
                <FluxToolbarGroup>
                    <slot name="actions"/>
                </FluxToolbarGroup>

                <FluxSeparator axis="horizontal"/>
            </template>

            <template v-if="$slots.edit">
                <FluxToolbarGroup>
                    <FluxAction
                        icon="pen"
                        data-testid="create-event-shop-edit-element"
                        @click="isEditing = true"/>
                </FluxToolbarGroup>

                <FluxSeparator axis="vertical"/>
            </template>

            <FluxToolbarGroup>
                <FluxAction
                    class="shop-element-move"
                    data-testid="create-event-shop-move-element"
                    icon="grip-dots"/>

                <FluxAction
                    :disabled="isFirst"
                    icon="angle-up"
                    data-testid="create-event-shop-move-element-up"
                    @click="move(-1)"/>

                <FluxAction
                    :disabled="isLast"
                    icon="angle-down"
                    data-testid="create-event-shop-move-element-down"
                    @click="move(1)"/>
            </FluxToolbarGroup>

            <FluxSeparator axis="vertical"/>

            <FluxToolbarGroup>
                <FluxAction
                    destructive
                    icon="xmark"
                    data-testid="create-event-shop-remove-element"
                    @click="remove"/>
            </FluxToolbarGroup>
        </FluxToolbar>

        <slot/>

        <template v-if="$slots.edit">
            <FluxOverlay
                :is-closeable="!invalid"
                data-testid="create-event-shop-close-edit-element"
                @close="isEditing = false">
                <FluxPane
                    v-if="isEditing"
                    class="shop-element-edit">
                    <FluxPaneHeader
                        :icon="editIcon ?? 'pen'"
                        :title="editTitle ?? t('global.edit')"/>

                    <slot name="edit"/>

                    <FluxPaneFooter>
                        <FluxSpacer/>

                        <FluxSecondaryButton
                            :label="t('global.cancel')"
                            @click="edit(false)"/>

                        <FluxPrimaryButton
                            :disabled="invalid"
                            icon-before="circle-check"
                            :label="t('global.save')"
                            data-testid="create-event-shop-add-element"
                            @click="edit(true)"/>
                    </FluxPaneFooter>
                </FluxPane>
            </FluxOverlay>
        </template>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopElement } from '@fancee/data';
    import type { IconNames } from '@fancee/flux';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useValidationScope } from '@/composable';

    export interface Emits {
        (e: 'commitChanges', commitChanges: boolean): void;
    }

    interface Props {
        readonly editorElements: CreateEventShopElement[];
        readonly editorElementsEmit: Function;
        readonly editIcon?: IconNames;
        readonly editTitle?: string;
        readonly internalId: string;
        readonly isEditForced?: boolean;
        readonly isIndented?: boolean;
    }

    const emit = defineEmits();
    const props = withDefaults(defineProps<Props>(), {
        isEditForced: false,
        isIndented: false
    });
    const {editorElements, editorElementsEmit, isEditForced} = toRefs(props);

    const {t} = useI18n();
    const {invalid} = useValidationScope();

    const isEditing = ref(false);

    const elementIndex = computed(() => unref(editorElements).findIndex(e => e && e.internalId === props.internalId) ?? -1);
    const isFirst = computed(() => unref(elementIndex) === 0);
    const isLast = computed(() => unref(elementIndex) === unref(editorElements).length - 1);

    function move(direction: number): void {
        const index = unref(editorElements).findIndex(e => e.internalId === props.internalId);
        const newIndex = index + direction;

        if (newIndex < 0 || newIndex >= unref(editorElements).length) {
            return;
        }

        unref(editorElementsEmit)('move', index, newIndex);
    }

    function remove(): void {
        const index = unref(editorElements).findIndex(e => e.internalId === props.internalId);
        unref(editorElementsEmit)('remove', index);
    }

    function edit(commitChanges: boolean): void {
        emit('edit', commitChanges);
        isEditing.value = false;
    }

    watch(isEditForced, isEditForced => {
        if (!isEditForced) {
            return;
        }

        isEditing.value = true;
    }, {immediate: true});
</script>

<style lang="scss">
    .shop-element {
        &-edit {
            max-width: 540px;
            width: calc(100dvw - 90px);
        }

        &-mount {
            position: relative;
            background: hsl(var(--shop-background-secondary));
            border: 2px solid transparent;
            border-radius: var(--radius);
            cursor: default;
            outline: 2px solid transparent;
            pointer-events: all;
            transition: 300ms var(--swift-out);
            transition-property: border, filter, opacity, scale;

            &.is-indented {
                padding-left: 15px;
                padding-right: 15px;
            }

            .flux-toolbar {
                transition: 300ms var(--swift-out);
                transition-property: opacity, translate;
                translate: 0 calc(-50% - 1px);
                z-index: 100;
            }

            &:not(:hover) .flux-toolbar {
                opacity: 0;
                translate: 0 calc(-50% + 6px);
            }

            &:hover {
                border-color: hsl(var(--shop-panel-quaternary));
                z-index: 1;
            }
        }

        &-move:not([disabled]) {
            cursor: move;
        }
    }
</style>
