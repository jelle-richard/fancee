<template>
    <FluxContainer>
        <FluxStack>
            <EventAppTeamSelector
                :app-team-id="selectedAppTeamId"
                @selected-event-changed="selectedEventId = $event"
                @selected-app-team-changed="selectedAppTeamId = $event"/>

            <AppTeamScannedChart
                v-if="selectedAppTeamId !== null"
                :key="appTeamScanStatistics.length"
                :app-team-scan-statistics="appTeamScanStatistics"
                :is-loading="isLoadingAppTeamScanStatistics"
                :start-scan-date-time="startScanDateTime"
                @scan-time-start="startScanDateTime = $event"/>

            <ScannedChart
                v-if="ticketScanStatistics.length > 0 && selectedEventId !== null"
                :event-statistics="ticketScanStatistics"
                :is-loading="isLoadingStatistics"/>
        </FluxStack>
    </FluxContainer>
</template>

<script
    setup
    lang="ts">
    import { ScanService } from '@fancee/api';
    import { AppTeamScanStatistics, TicketScanStatistics } from '@fancee/data';
    import { DateTime } from 'luxon';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { guarded } from '@/util';
    import AppTeamScannedChart from './AppTeamScannedChart.vue';
    import EventAppTeamSelector from './EventAppTeamSelector.vue';
    import ScannedChart from './ScannedChart.vue';

    const {t} = useI18n();
    const {eventAppTeamStatistics, eventStatistics} = useService(ScanService);
    const organizationId = useActiveOrganizationId();

    const _eventAppTeamStatistics = guarded(eventAppTeamStatistics, t('ui.somethingWentWrong.title'), t('app.team.statistics.loadingTeamFailed'));
    const _eventStatistics = guarded(eventStatistics, t('ui.somethingWentWrong.title'), t('app.team.statistics.loadingFailed'));

    const selectedEventId = ref<string | null>(null);
    const selectedAppTeamId = ref<string | null>(null);
    const isLoadingStatistics = ref(false);
    const isLoadingAppTeamScanStatistics = ref(false);
    const ticketScanStatistics = ref<TicketScanStatistics[]>([]);
    const appTeamScanStatistics = ref<AppTeamScanStatistics[]>([]);
    const startScanDateTime = ref<DateTime | null>(null);

    async function getEventStatistics(): Promise<void> {
        if (unref(selectedEventId) === null) {
            return;
        }

        isLoadingStatistics.value = true;

        try {
            const {data} = await _eventStatistics(unref(organizationId), unref(selectedEventId)!);
            ticketScanStatistics.value = data;
        } finally {
            isLoadingStatistics.value = false;
        }
    }

    async function getAppTeamScanStatistics(): Promise<void> {
        isLoadingAppTeamScanStatistics.value = true;

        try {
            const {data} = await _eventAppTeamStatistics(unref(organizationId), unref(selectedEventId)!, unref(selectedAppTeamId)!, unref(startScanDateTime));
            appTeamScanStatistics.value = data;
        } finally {
            isLoadingAppTeamScanStatistics.value = false;
        }
    }

    watch(selectedEventId, async () => {
        selectedAppTeamId.value = null;
        appTeamScanStatistics.value = [];

        if (unref(selectedEventId) === null) {
            ticketScanStatistics.value = [];
            return;
        }

        await getEventStatistics();
    });

    watch(selectedAppTeamId, async () => {
        if (unref(selectedAppTeamId) !== null) {
            await getAppTeamScanStatistics();
        }
    });

    watch(startScanDateTime, () => getAppTeamScanStatistics());
</script>
