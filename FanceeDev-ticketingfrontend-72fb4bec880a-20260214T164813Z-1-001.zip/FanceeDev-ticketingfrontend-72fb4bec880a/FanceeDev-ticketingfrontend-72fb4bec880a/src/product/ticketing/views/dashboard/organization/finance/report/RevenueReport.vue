<template>
    <FluxGrid>
        <FluxGridColumn :md="4">
            <FluxStack>
                <FluxFormInputGroup>
                    <FluxFormInputAddition icon="magnifying-glass"/>

                    <FluxFormSelectAsync
                        v-model="selectedEventId"
                        :placeholder="t('finance.report.searchEvent')"
                        :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                        :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                        :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>

                    <FluxSecondaryButton
                        v-if="selectedEventId !== null"
                        icon-before="xmark"
                        @click="resetSelection"/>
                </FluxFormInputGroup>

                <template v-if="revenueStatistics === null">
                    <FluxPane is-loading>
                        <FluxAspectRatio :aspect-ratio="3 / 3"/>
                    </FluxPane>

                    <FluxPane is-loading>
                        <FluxAspectRatio :aspect-ratio="6 / 3"/>
                    </FluxPane>
                </template>

                <template v-else>
                    <OrganizationRevenue
                        :class="{[$style.highLight] : highlightOrganizationRevenue}"
                        :statistics="revenueStatistics.revenueStatistics"
                        :revenue="revenueStatistics.organizationRevenue"
                        :total-online-revenue="onlineRevenue"
                        :total-cash-revenue="cashRevenue"/>

                    <PlatformRevenue
                        :class="{[$style.highLight] : highlightPlatformRevenue}"
                        :revenue="revenueStatistics.platformRevenue"
                        :total-revenue="platformRevenue"/>
                </template>
            </FluxStack>
        </FluxGridColumn>

        <FluxGridColumn
            :class="$style.paneAlign"
            :md="4">
            <FluxStack>
                <template v-if="revenueStatistics === null">
                    <FluxPane is-loading>
                        <FluxAspectRatio :aspect-ratio="6 / 3"/>
                    </FluxPane>

                    <FluxPane is-loading>
                        <FluxAspectRatio :aspect-ratio="6 / 3"/>
                    </FluxPane>
                </template>

                <template v-else>
                    <PlatformCost
                        :class="{[$style.highLight] : highlightOrganizationCost}"
                        :cost="revenueStatistics.platformCost"
                        :total-cost="platformCost"/>

                    <ClientCost
                        :class="{[$style.highLight] : highlightClientCost}"
                        :cost="revenueStatistics.clientCost"
                        :total-cost="clientCost"/>
                </template>
            </FluxStack>
        </FluxGridColumn>

        <FluxGridColumn
            :class="$style.paneAlign"
            :md="4">
            <FluxStack>
                <FluxPane
                    v-if="revenueStatistics === null"
                    is-loading>
                    <FluxAspectRatio :aspect-ratio="6 / 3"/>
                </FluxPane>

                <TotalProceeds
                    v-else
                    :total-revenue="totalRevenue"
                    :total-cost="totalCost"
                    :total-profit="totalProfit"
                    :placed-in-wallet="totalWallet"
                    @hover-element="highlightElement"/>
            </FluxStack>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { RevenueService, SelectService } from '@fancee/api';
    import { RevenueReportStatistics } from '@fancee/data';
    import { computed, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { fetchSelect, guarded } from '@/util';
    import OrganizationRevenue from '@/product/ticketing/views/dashboard/organization/finance/report/OrganizationRevenue.vue';
    import PlatformRevenue from '@/product/ticketing/views/dashboard/organization/finance/report/PlatformRevenue.vue';
    import PlatformCost from '@/product/ticketing/views/dashboard/organization/finance/report/PlatformCost.vue';
    import ClientCost from '@/product/ticketing/views/dashboard/organization/finance/report/ClientCost.vue';
    import TotalProceeds from '@/product/ticketing/views/dashboard/organization/finance/report/TotalProceeds.vue';

    const {t} = useI18n();
    const {getEventOptions} = useService(SelectService);
    const {accountRevenueReport, eventRevenueReport} = useService(RevenueService);
    const organizationId = useActiveOrganizationId();

    const _accountRevenueReport = guarded(accountRevenueReport, t('ui.somethingWentWrong.title'), t('finance.report.loadingFailed'));
    const _eventRevenueReport = guarded(eventRevenueReport, t('ui.somethingWentWrong.title'), t('finance.report.loadingFailed'));

    const selectedEventId = ref<string | null>(null);
    const revenueStatistics = ref<RevenueReportStatistics | null>(null);
    const highlightOrganizationRevenue = ref(false);
    const highlightPlatformRevenue = ref(false);
    const highlightOrganizationCost = ref(false);
    const highlightClientCost = ref(false);

    const onlineRevenue = computed((): number => {
        const revenue = unref(revenueStatistics)?.organizationRevenue.onlineRevenue;

        if (!revenue) {
            return 0;
        }

        return revenue.recetteCents
            + revenue.administrationFeeCents
            - revenue.discountCents;
    });

    const cashRevenue = computed((): number => {
        const revenue = unref(revenueStatistics)?.organizationRevenue.cashRevenue;

        if (!revenue) {
            return 0;
        }

        return revenue.recetteCents
            + revenue.administrationFeeCents
            - revenue.discountCents;
    });

    const platformRevenue = computed((): number => {
        const revenue = unref(revenueStatistics)?.platformRevenue;

        if (!revenue) {
            return 0;
        }

        return revenue.paymentFeeCostCents
            + revenue.ticketServicePlusFeeCostCents
            + revenue.smsFeeCostCents;
    });

    const platformCost = computed((): number => {
        const cost = unref(revenueStatistics)?.platformCost;

        if (!cost) {
            return 0;
        }

        return cost.paymentFeeCostCents
            + cost.guestListFeeCostCents
            + cost.additionalCostCents
            + cost.productFeeCostCents
            + cost.ticketFeeCostCents
            + cost.seatedTicketFeeCostCents;
    });

    const clientCost = computed((): number => {
        const cost = unref(revenueStatistics)?.clientCost;

        if (!cost) {
            return 0;
        }

        return cost.paymentFeeCostCents
            + cost.smsFeeCostCents
            + cost.ticketServicePlusFeeCostCents;
    });

    const totalRevenue = computed((): number => unref(onlineRevenue) + unref(cashRevenue) + unref(platformRevenue));
    const totalCost = computed((): number => unref(platformCost) + unref(clientCost));
    const totalProfit = computed((): number => unref(totalRevenue) - unref(totalCost));
    const totalWallet = computed((): number => unref(totalRevenue) - unref(cashRevenue) - unref(totalCost));

    async function fetchAccountRevenue(): Promise<void> {
        revenueStatistics.value = null;

        const {data} = await _accountRevenueReport(unref(organizationId));
        revenueStatistics.value = data;
    }

    async function fetchEventRevenue(): Promise<void> {
        if (selectedEventId.value === null) {
            return;
        }

        revenueStatistics.value = null;

        const {data} = await _eventRevenueReport(unref(organizationId), unref(selectedEventId)!);
        revenueStatistics.value = data;
    }

    function resetSelection(): void {
        selectedEventId.value = null;
    }

    function highlightElement(element: string, highlight: boolean): void {
        if (element === 'revenue') {
            highlightOrganizationRevenue.value = highlight;
            highlightPlatformRevenue.value = highlight;
        }

        if (element === 'cost') {
            highlightOrganizationCost.value = highlight;
            highlightClientCost.value = highlight;
        }
    }

    watch(selectedEventId, async selectedEventId => {
        if (selectedEventId === null) {
            await fetchAccountRevenue();
        } else {
            await fetchEventRevenue();
        }
    }, {immediate: true});
</script>

<style
    lang="scss"
    module>
    @use '@/assets/css/breakpoints' as *;

    .highLight {
        box-shadow: rgba(var(--gray-5)) 0 0 12px;
    }

    .paneAlign {
        margin-top: 72px;
    }

    @include breakpoint-down(xs) {
        .paneAlign {
            margin-top: 0;
        }
    }
</style>
