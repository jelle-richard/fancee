<template>
    <RouterView/>
</template>

<script
    setup
    lang="ts">
    import { onMounted, onUnmounted } from 'vue';
    import { useUiStore } from '@/data/store';

    const {setNavigation} = useUiStore();

    onMounted(() => setNavigation([
        {
            icon: 'left',
            route: 'home',
            title: 'global.back'
        },
        {
            separator: true
        },
        {
            icon: 'palette',
            route: 'default-shop-settings',
            title: 'settings.navigation.defaultShopPalette'
        },
        {
            icon: 'coin',
            route: 'default-payment-methods',
            title: 'settings.navigation.defaultPaymentMethods'
        },
        {
            icon: 'ban',
            route: 'blocked-emails',
            title: 'settings.navigation.blockedEmails'
        },
        {
            icon: 'user-group-crown',
            route: 'role-assigner',
            title: 'settings.navigation.roleManagement'
        }
    ]));

    onUnmounted(() => setNavigation(null));
</script>
