<template>
    <div class="product">
        <FluxAspectRatio
            class="product-image"
            :aspect-ratio="1">
            <img
                v-if="mediaUrl !== null"
                :src="mediaUrl"
                alt=""/>

            <FluxPlaceholder
                v-else
                class="border"
                :icon="productType === ProductType.Ticket ? 'ticket' : 't-shirt'"
                variant="small"/>
        </FluxAspectRatio>

        <div class="product-caption">
            <h3>{{ title }}</h3>
            <p v-if="subTitle !== null">{{ subTitle }}</p>
            <p v-if="description !== null">{{ description }}</p>
            <FluxNotice
                v-if="!!noticeMessage"
                icon="circle-exclamation"
                is-small
                :message="t(noticeMessage)"
                variant="warning"/>
        </div>

        <div
            v-if="barSeries !== null"
            class="product-bar">
            <FluxPercentageBar
                class="percentage-bar"
                :items="barSeries"/>
        </div>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { ProductType } from '@fancee/data';
    import { FluxPercentageBarItemSpec } from '@fancee/flux';
    import { useI18n } from 'vue-i18n';

    export interface Props {
        readonly title: string;
        readonly subTitle?: string | null;
        readonly description?: string | null;
        readonly mediaUrl?: string | null;
        readonly noticeMessage?: string | null;
        readonly productType?: ProductType;
        readonly barSeries?: FluxPercentageBarItemSpec[] | null;
    }

    withDefaults(defineProps<Props>(), {
        productType: ProductType.Ticket,
        media: null,
        subTitle: null,
        description: null,
        noticeMessage: null,
        series: null
    });

    const {t} = useI18n();
</script>

<style
    lang="scss"
    scoped>
    .product {
        display: flex;
        align-items: center;
        gap: 15px;
        background: transparent;
        border: 0;
        border-radius: calc(var(--radius) / 2);
        text-align: left;

        &-caption {
            display: flex;
            flex-flow: column;
            flex-grow: 1;
            gap: 3px;

            h3 {
                font-size: 16px;
            }

            p {
                margin-top: 0;
                font-size: 13px;
            }
        }

        &-bar {
            display: flex;
            flex-flow: column;
            flex-grow: 1;
            gap: 3px;

            > .percentage-bar {
                width: 100%;
            }
        }

        &-image {
            height: 54px;
            width: 54px;
        }

        &-border {
            border: 1px solid rgb(var(--gray-4));
        }
    }
</style>
