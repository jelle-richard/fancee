<template>
    <FluxTabs v-if="eventId !== null && event !== null">
        <FluxTab
            icon="circle-plus"
            :label="t('event.guestlist.manage.manual.title')">
            <ManualGuestInviter
                :event-id="eventId"
                :event="event"/>
        </FluxTab>

        <FluxTab
            v-if="hasImportClaim"
            icon="arrow-up-from-line"
            :label="t('event.guestlist.manage.import.title')">
            <ImportGuestInviter
                :event-id="eventId"
                :event="event"/>
        </FluxTab>
    </FluxTabs>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventService } from '@fancee/api';
    import { EventDetails, EventStatus } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useRouteParam, useRouter, useService } from '@/composable';
    import { storeToRefs, useAuthStore } from '@/data/store';
    import ManualGuestInviter from '@/product/ticketing/views/dashboard/organization/events/guestlist/route/ManualGuestInviter.vue';
    import ImportGuestInviter from '@/product/ticketing/views/dashboard/organization/events/guestlist/route/ImportGuestInviter.vue';

    const authStore = useAuthStore();
    const {claims} = storeToRefs(authStore);

    const {t} = useI18n();
    const {getEvent} = useService(CreateEventService);
    const organizationId = useActiveOrganizationId();
    const router = useRouter();

    const eventId = useRouteParam('id');
    const event = ref<EventDetails | null>(null);
    const hasImportClaim = ref(claims.value.includes('organization.guestlist.import'));

    onMounted(async () => {
        await loadEvent();
        await allowedEvent();
    });

    async function loadEvent(): Promise<void> {
        if (eventId.value === null) {
            return;
        }

        const {data: eventDetails} = await getEvent(unref(organizationId), eventId.value);

        event.value = eventDetails;
    }

    async function allowedEvent(): Promise<void> {
        if (unref(event) === null || ![EventStatus.Active, EventStatus.SoldOut].includes(unref(event)!.status)) {
            await router.push({name: 'guestlists'});

            showSnackbar({
                color: 'danger',
                icon: 'circle-exclamation',
                message: t('event.guestlist.manage.onlyActiveEvents')
            });
        }
    }
</script>
