<template>
    <FluxTable>
        <template #header>
            <FluxTableRow>
                <FluxTableHeader :class="$style.productSelector">
                    <FluxCheckbox
                        v-model="selectAll"
                        @update:model-value="selectAllClicked"/>
                </FluxTableHeader>
                <FluxTableHeader>{{ t('dashboard.statistics.productStatistics.name') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('dashboard.statistics.productStatistics.price') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('dashboard.statistics.productStatistics.stock') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('dashboard.statistics.productStatistics.sold') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('dashboard.statistics.productStatistics.guest') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('dashboard.statistics.productStatistics.pending') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('dashboard.statistics.productStatistics.remaining') }}</FluxTableHeader>
            </FluxTableRow>
        </template>

        <template #rows>
            <FluxTableRow
                v-for="row in productSaleStatistics"
                :key="row.id">
                <FluxTableCell :class="$style.productSelector">
                    <FluxCheckbox
                        v-model="row.selected"
                        @update:model-value="updateSelectAll"/>
                </FluxTableCell>
                <FluxTableCell>
                    {{ row.name }}
                </FluxTableCell>

                <FluxTableCell>
                    {{ asMoney(row.priceCents, currency) }}
                </FluxTableCell>

                <FluxTableCell>
                    {{ asFormattedNumber(row.stock * row.packQuantity) }} {{ row.packQuantity > 1 ? `(${asFormattedNumber(row.stock)})` : '' }}
                </FluxTableCell>

                <FluxTableCell>
                    {{ asFormattedNumber(row.soldAmount * row.packQuantity) }} {{ row.packQuantity > 1 ? `(${asFormattedNumber(row.soldAmount)})` : '' }}
                </FluxTableCell>

                <FluxTableCell>
                    <FluxTooltip :content="t('dashboard.statistics.productStatistics.guestlistTip')">
                        <span>{{ asFormattedNumber(row.deductedGuestAmount) }} / {{ asFormattedNumber(row.notDeductedGuestAmount) }}</span>
                    </FluxTooltip>
                </FluxTableCell>

                <FluxTableCell>
                    <FluxTooltip :content="t('dashboard.statistics.productStatistics.pendingTip', [row.pendingReservationsAmount + row.pendingPaymentsAmount, row.pendingPaymentsAmount])">
                        <span>{{ asFormattedNumber(row.pendingReservationsAmount + row.pendingPaymentsAmount) }}</span>
                    </FluxTooltip>
                </FluxTableCell>

                <FluxTableCell>
                    {{ asFormattedNumber(calculateRemaining(row, true)) }} {{ row.packQuantity > 1 ? `(${asFormattedNumber(calculateRemaining(row, false))})` : '' }}
                </FluxTableCell>
            </FluxTableRow>
        </template>

        <template #footer>
            <FluxTableRow>
                <FluxTableCell/>
                <FluxTableCell>
                    <strong>{{ t('global.total') }}</strong>
                </FluxTableCell>
                <FluxTableCell/>
                <FluxTableCell>
                    <strong>{{ asFormattedNumber(totalsWithPack.stock) }} {{ totals.stock !== totalsWithPack.stock ? `(${asFormattedNumber(totals.stock)})` : '' }}</strong>
                </FluxTableCell>
                <FluxTableCell>
                    <strong>{{ asFormattedNumber(totalsWithPack.soldAmount) }} {{ totals.soldAmount !== totalsWithPack.soldAmount ? `(${asFormattedNumber(totals.soldAmount)})` : '' }}</strong>
                </FluxTableCell>
                <FluxTableCell>
                    <FluxTooltip :content="t('dashboard.statistics.productStatistics.guestlistTip')">
                        <strong><span>{{ asFormattedNumber(totals.deductedGuestAmount) }} / {{ asFormattedNumber(totals.notDeductedGuestAmount) }}</span></strong>
                    </FluxTooltip>
                </FluxTableCell>
                <FluxTableCell>
                    <FluxTooltip :content="t('dashboard.statistics.productStatistics.pendingTip', [totals.pendingReservationsAmount + totals.pendingPaymentsAmount, totals.pendingPaymentsAmount])">
                        <strong><span>{{ asFormattedNumber(totals.pendingReservationsAmount + totals.pendingPaymentsAmount) }}</span></strong>
                    </FluxTooltip>
                </FluxTableCell>
                <FluxTableCell>
                    <strong>{{ asFormattedNumber(calculateRemaining(totalsWithPack, false)) }} {{ totals.stock !== totalsWithPack.stock ? `(${asFormattedNumber(calculateRemaining(totals, false))})` : '' }}</strong>
                </FluxTableCell>
            </FluxTableRow>
        </template>
    </FluxTable>
</template>

<script
    lang="ts"
    setup>
    import { Currency, IssuedProductStatistics } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { asFormattedNumber, asMoney } from '@/util';
    import { computed, ref, toRefs, unref, watch } from 'vue';

    export interface Props {
        readonly currency: Currency;
        readonly productSaleStatistics: IssuedProductStatistics[];
    }

    const props = defineProps<Props>();
    const {productSaleStatistics} = toRefs(props);

    const {t} = useI18n();

    const selectAll = ref(true);
    const totalsWithPack = ref(new IssuedProductStatistics('', '', 0, 0, 0, 0, 0, 0, 0, 0, true));
    const totals = ref(new IssuedProductStatistics('', '', 0, 0, 0, 0, 0, 0, 0, 0, true));

    const allSelected = computed(() => unref(productSaleStatistics).filter(s => s.selected).length === unref(productSaleStatistics).length);

    function calculateRemaining(productSaleStatistics: IssuedProductStatistics, withPack: boolean): number {
        return (productSaleStatistics.stock * (withPack ? productSaleStatistics.packQuantity : 1))
            - (productSaleStatistics.soldAmount * (withPack ? productSaleStatistics.packQuantity : 1))
            - productSaleStatistics.deductedGuestAmount
            - productSaleStatistics.pendingReservationsAmount
            - productSaleStatistics.pendingPaymentsAmount;
    }

    function calculateSelectedProducts(withPack: boolean): IssuedProductStatistics {
        return unref(productSaleStatistics).filter(pss => pss.selected).reduce((acc, curr) => {
            acc.stock += (curr.stock * (withPack ? curr.packQuantity : 1));
            acc.soldAmount += (curr.soldAmount * (withPack ? curr.packQuantity : 1));
            acc.deductedGuestAmount += curr.deductedGuestAmount;
            acc.notDeductedGuestAmount += curr.notDeductedGuestAmount;
            acc.pendingReservationsAmount += curr.pendingReservationsAmount;
            acc.pendingPaymentsAmount += curr.pendingPaymentsAmount;

            return acc;
        }, new IssuedProductStatistics('', '', 0, 0, 0, 0, 0, 0, 0, 0, true));
    }

    function selectAllClicked(): void {
        const _allSelected = unref(allSelected);

        productSaleStatistics.value.forEach(s => s.selected = !_allSelected);
    }

    function updateSelectAll(): void {
        selectAll.value = unref(allSelected);
    }

    watch(productSaleStatistics, () => {
        totals.value = calculateSelectedProducts(false);
        totalsWithPack.value = calculateSelectedProducts(true);
    }, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    module>
    .productSelector > div {
        justify-content: center;
    }
</style>
