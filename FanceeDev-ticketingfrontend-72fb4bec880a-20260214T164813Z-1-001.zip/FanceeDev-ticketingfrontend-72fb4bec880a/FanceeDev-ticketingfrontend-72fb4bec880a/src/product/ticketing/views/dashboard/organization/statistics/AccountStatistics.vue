<template>
    <FluxStack>
        <FluxNotice
            v-if="statisticsFailed"
            icon="circle-exclamation"
            is-small
            :message="t('dashboard.statistics.loadingFailed')"
            variant="warning"/>

        <template v-else>
            <GlobalEventStatisticsCards :global-event-statistics="globalEventStatistics"/>

            <EventRevenueStatistics
                :currency="currency"
                :event-revenue-statistics="eventRevenueStatisticsData"/>

            <FluxGrid>
                <FluxGridColumn
                    v-if="bestSellingProductsValue.length > 0"
                    sm="12"
                    md="5"
                    lg="4">
                    <BestSellingProducts
                        :products="bestSellingProductsValue"
                        :is-loading="isLoadingBestSellingProducts"/>
                </FluxGridColumn>

                <FluxGridColumn
                    sm="12"
                    :md="bestSellingProductsValue.length > 0 ? 7 : 12"
                    :lg="bestSellingProductsValue.length > 0 ? 8 : 12">
                    <DailyOrdersChart
                        :daily-orders="dailyOrders"
                        :is-loading="isLoadingDailyOrders"
                        :daily-history-days="dailyOrdersHistoryAmount"
                        :current-date-reached="dailyOrdersDays === 0"
                        @history-amount="onHistoryAmountChanged($event)"
                        @next="dailyOrdersDays += dailyOrdersHistoryAmount"
                        @previous="dailyOrdersDays -= dailyOrdersHistoryAmount"/>
                </FluxGridColumn>
            </FluxGrid>

            <FluxGrid>
                <FluxGridColumn md="4">
                    <WalletCard
                        :timed-wallet-balances="timedWalletBalances"
                        :wallet-balance-historic-days-amount="DEFAULT_WALLET_BALANCE_ENTRIES"/>
                </FluxGridColumn>
            </FluxGrid>
        </template>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { EventService, OrderService, PaymentService, ProductService } from '@fancee/api';
    import { BestSellingProduct, Currency, DailyOrder, EventRevenueStatistics as EventRevenueStatisticsDto, GlobalEventStatistics, TimedWalletBalanceSetting } from '@fancee/data';
    import { DateTime } from 'luxon';
    import { onMounted, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { DEFAULT_WALLET_BALANCE_ENTRIES } from '@/data';
    import { formatDateTime, guarded } from '@/util';
    import BestSellingProducts from '@/product/ticketing/views/dashboard/organization/events/products/BestSellingProducts.vue';
    import DailyOrdersChart from '@/product/ticketing/views/dashboard/organization/statistics/DailyOrdersChart.vue';
    import EventRevenueStatistics from '@/product/ticketing/views/dashboard/organization/statistics/EventRevenueStatistics.vue';
    import GlobalEventStatisticsCards from '@/product/ticketing/views/dashboard/organization/statistics/GlobalEventStatisticsCards.vue';
    import WalletCard from '@/product/ticketing/views/dashboard/organization/statistics/wallet/WalletCard.vue';

    export interface Props {
        readonly currency: Currency;
    }

    const props = defineProps<Props>();
    const {currency} = toRefs(props);

    const {t} = useI18n();
    const {getGlobalStatisticsEvents, getStatisticsRevenueEvents} = useService(EventService);
    const {getBalanceHistory} = useService(PaymentService);
    const {getBestSelling} = useService(ProductService);
    const {getDaily} = useService(OrderService);
    const organizationId = useActiveOrganizationId();

    const _getBalanceHistory = guarded(getBalanceHistory, onLoadStatisticsFailed);
    const _getGlobalStatisticsEvents = guarded(getGlobalStatisticsEvents, onLoadStatisticsFailed);
    const _getStatisticsRevenueEvents = guarded(getStatisticsRevenueEvents, onLoadStatisticsFailed);
    const _getBestSelling = guarded(getBestSelling, onLoadStatisticsFailed);
    const _getDaily = guarded(getDaily, onLoadStatisticsFailed);

    const globalEventStatistics = ref<GlobalEventStatistics | null>(null);
    const eventRevenueStatisticsData = ref<EventRevenueStatisticsDto | null>(null);
    const bestSellingProductsValue = ref<BestSellingProduct[]>([]);
    const timedWalletBalances = ref<TimedWalletBalanceSetting[]>([]);
    const dailyOrders = ref<DailyOrder[]>([]);
    const dailyOrdersHistoryAmount = ref(7);
    const dailyOrdersDays = ref(0);
    const isLoadingDailyOrders = ref(true);
    const isLoadingBestSellingProducts = ref(true);
    const statisticsFailed = ref(false);

    onMounted(async () => {
        await getGlobalEventStatistics();
        await getEventRevenueStatistics();
        await getBestSellingProducts();
        await getDailyOrderStatistics();
        await getTimedWalletBalances();
    });

    async function getTimedWalletBalances(): Promise<void> {
        let startDate = formatDateTime(DateTime.now().minus({days: DEFAULT_WALLET_BALANCE_ENTRIES - 1}));
        let endDate = formatDateTime(DateTime.now());

        const {data} = await _getBalanceHistory(unref(organizationId), startDate, endDate);
        timedWalletBalances.value = data;
    }

    async function getGlobalEventStatistics(): Promise<void> {
        const {data} = await _getGlobalStatisticsEvents(unref(organizationId));
        globalEventStatistics.value = data;
    }

    async function getEventRevenueStatistics(): Promise<void> {
        const {data} = await _getStatisticsRevenueEvents(unref(organizationId));
        eventRevenueStatisticsData.value = data;
    }

    async function getBestSellingProducts(): Promise<void> {
        let endDate = formatDateTime(DateTime.now());
        let startDate = formatDateTime(DateTime.now().minus({days: 7}));

        try {
            const {data} = await _getBestSelling(unref(organizationId), 6, startDate, endDate);
            bestSellingProductsValue.value = data;
        } finally {
            isLoadingBestSellingProducts.value = false;
        }
    }

    async function getDailyOrderStatistics(): Promise<void> {
        isLoadingDailyOrders.value = true;
        dailyOrders.value = [];

        let endDate = formatDateTime(DateTime.now().endOf('day').minus({days: -dailyOrdersDays.value}));
        let startDate = formatDateTime(DateTime.now().startOf('day').minus({days: dailyOrdersHistoryAmount.value - dailyOrdersDays.value}));

        try {
            const {data} = await _getDaily(unref(organizationId), startDate, endDate);
            dailyOrders.value = data;
        } finally {
            isLoadingDailyOrders.value = false;
        }
    }

    function onHistoryAmountChanged(days: number): void {
        dailyOrdersHistoryAmount.value = days;
        dailyOrdersDays.value = 0;

        getDailyOrderStatistics();
    }

    function onLoadStatisticsFailed(): void {
        statisticsFailed.value = true;
    }

    watch(dailyOrdersDays, getDailyOrderStatistics);
</script>
