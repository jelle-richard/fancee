<template>
    <FluxPane>
        <FluxPaneHeader
            icon="lock"
            :title="t('event.secureCode.set.title')">
            <FluxSecondaryButton
                icon-before="xmark"
                @click="closeOverlay"/>
        </FluxPaneHeader>

        <FluxPaneBody>
            <FluxFormColumn>
                <FluxNotice
                    icon="circle-info"
                    is-small
                    :message="t('event.secureCode.set.info')"/>

                <FluxFormField :label="t('event.secureCode.set.state')">
                    <FluxToggle v-model="isSecured"/>
                </FluxFormField>

                <ValidationField
                    v-if="isSecured"
                    :label="t('event.secureCode.set.until')"
                    :rules="{future, afterDate: afterDate(shopStartDate), beforeDate: beforeDate(shopEndDate)}"
                    :value="localSecuredUntil">
                    <FluxFormDateTimeInput
                        v-model="localSecuredUntil"
                        :min="shopStartDate"
                        :max="shopEndDate"/>
                </ValidationField>
            </FluxFormColumn>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxSecondaryButton
                :label="t('global.close')"
                @click="closeOverlay"/>

            <FluxPrimaryButton
                :disabled="invalid"
                icon-before="circle-check"
                :label="t('global.save')"
                @click="saveSecureState"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { EventService } from '@fancee/api';
    import { showSnackbar } from '@fancee/flux';
    import { useI18n } from 'vue-i18n';
    import { onMounted, ref, toRefs, unref } from 'vue';
    import { useActiveOrganizationId, useRequestErrorBoundary, useService, useValidationScope } from '@/composable';
    import { DateTime } from 'luxon';
    import { afterDate, beforeDate, future } from '@/data/validation';
    import { ValidationField } from '@/components/form';

    const {t} = useI18n();
    const {runSandboxed} = useRequestErrorBoundary();
    const {invalid} = useValidationScope();
    const {updateSecuredState} = useService(EventService);
    const organizationId = useActiveOrganizationId();

    export type Emits = {
        (e: 'close'): void;
        (e: 'secureStateChanged', isSecuredUntil: DateTime | null): void;
    };

    export type Props = {
        readonly shopCode: string;
        readonly shopStartDate: DateTime;
        readonly shopEndDate: DateTime;
        readonly eventId: string;
        readonly isSecuredUntil: DateTime | null;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {shopCode, eventId, isSecuredUntil} = toRefs(props);
    const isSaving = ref(false);
    const isSecured = ref(unref(isSecuredUntil) !== null);
    const localSecuredUntil = ref<DateTime | null>(null);

    onMounted(() => {
        localSecuredUntil.value = unref(isSecuredUntil);
    });

    async function saveSecureState(): Promise<void> {
        isSaving.value = true;

        await runSandboxed(
            async () => {
                await updateSecuredState(unref(organizationId), unref(eventId), unref(shopCode), unref(isSecured), unref(localSecuredUntil));

                showSnackbar({
                    color: 'success',
                    icon: 'circle-check',
                    message: t('event.secureCode.set.success')
                });

                emit('secureStateChanged', !unref(isSecured) ? null : unref(localSecuredUntil));
                closeOverlay();
            },
            () => showSnackbar({
                color: 'danger',
                icon: 'circle-exclamation',
                message: t('event.secureCode.set.failed')
            })
        );

        isSaving.value = false;
    }

    function closeOverlay(): void {
        emit('close');
    }
</script>
