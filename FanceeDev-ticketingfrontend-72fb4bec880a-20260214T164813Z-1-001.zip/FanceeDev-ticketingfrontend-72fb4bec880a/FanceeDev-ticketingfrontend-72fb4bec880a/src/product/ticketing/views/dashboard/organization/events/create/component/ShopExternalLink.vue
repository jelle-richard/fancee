<template>
    <ShopElement
        :internal-id="element.internalId"
        :editor-elements="editorElements"
        :editor-elements-emit="editorElementsEmit"
        :is-edit-forced="!element.link || element.link.length === 0"
        is-indented
        @edit="edit">
        <template #edit>
            <FluxPaneBody>
                <FluxFormColumn>
                    <ValidationField
                        :label="t('event.create.shops.element.externalLink.text')"
                        :rules="{required, minLength: minLength(3), maxLength: maxLength(100)}"
                        :value="localElement.name">
                        <FluxFormInput
                            v-model="localElement.name"
                            data-testid="create-event-shop-localElement-add-external-link-text"
                            :placeholder="t('event.create.shops.element.externalLink.textPlaceholder')"/>
                    </ValidationField>

                    <ValidationField
                        :label="t('event.create.shops.element.externalLink.url')"
                        :rules="{required, url}"
                        :value="localElement.link">
                        <FluxFormInput
                            v-model="localElement.link"
                            data-testid="create-event-shop-element-add-external-link-url"
                            :placeholder="t('event.create.shops.element.externalLink.urlPlaceholder')"
                            type="url"/>
                    </ValidationField>
                </FluxFormColumn>
            </FluxPaneBody>
        </template>

        <FluxSecondaryButton :label="element.name"/>
    </ShopElement>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopElement, CreateEventShopExternalLinkElement } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { maxLength, minLength, required, url } from '@/data/validation';
    import ShopElement from './ShopElement.vue';
    import { ref, toRefs, unref } from 'vue';

    export interface Props {
        readonly editorElements: CreateEventShopElement[];
        readonly editorElementsEmit: Function;
        readonly element: CreateEventShopExternalLinkElement;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const {t} = useI18n();

    const localElement = ref(new CreateEventShopExternalLinkElement(unref(element).link, unref(element).name));

    function edit(commitChanges: boolean): void {
        if (commitChanges) {
            element.value.name = unref(localElement).name;
            element.value.link = unref(localElement).link;
            return;
        }

        localElement.value = new CreateEventShopExternalLinkElement(unref(element).link, unref(element).name);
    }
</script>
