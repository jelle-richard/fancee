<template>
    <ShopElement
        :internal-id="element.internalId"
        :editor-elements="editorElements"
        :editor-elements-emit="editorElementsEmit">
        <div :class="$style.seatingMap">
            <SeatsioSeatingChart
                :class="$style.seatingMapChart"
                :event="details.seatsIoEventId"
                :workspaceKey="WORKSPACE_KEY"
                region="eu"
                colorScheme="light"
                mode="static"
                :showFullScreenButton="false"/>
        </div>
    </ShopElement>
</template>

<script
    lang="ts"
    setup>
    import { CreateEventShopDividerElement, CreateEventShopElement } from '@fancee/data';
    import { SeatsioSeatingChart } from '@seatsio/seatsio-vue';
    import { toRefs } from 'vue';
    import { useCreateEventStore, useStore } from '@/data/store';
    import ShopElement from './ShopElement.vue';

    const WORKSPACE_KEY = import.meta.env.VITE_SEATSIO_WORKSPACE_KEY;

    export interface Props {
        readonly editorElements: CreateEventShopElement[];
        readonly editorElementsEmit: Function;
        readonly element: CreateEventShopDividerElement;
    }

    const props = defineProps<Props>();
    const {element} = toRefs(props);

    const {details} = useStore(useCreateEventStore());
</script>

<style
    lang="scss"
    module>
    .seatingMap {
        position: relative;
        display: flex;
        aspect-ratio: 16 / 9;
        align-items: center;
        justify-content: center;
        background: rgb(var(--gray-1));
        border: 2px dashed rgb(var(--gray-3));
        border-radius: var(--radius);
        color: rgb(var(--gray-6));
    }

    .seatingMapChart {
        position: absolute;
        inset: 0;
        pointer-events: none;
    }
</style>
