<template>
    <div class="icon-picker">
        <template
            v-for="icon of AVAILABLE_ICONS"
            :key="icon">
            <button
                class="icon-picker-item"
                :class="{'is-selected': icon === modelValue}"
                @click="$emit('update:model-value', icon)">
                <FluxIcon
                    :size="30"
                    :variant="icon"/>
            </button>
        </template>
    </div>
</template>

<script lang="ts">
    export default {
        model: {
            prop: 'model-value',
            event: 'update:model-value'
        }
    };
</script>

<script
    lang="ts"
    setup>
    import { IconNames } from '@fancee/flux';

    export interface Emits {
        (e: 'update:model-value', value: IconNames): void;
    }

    export interface Props {
        readonly modelValue: IconNames;
    }

    defineEmits<Emits>();
    defineProps<Props>();

    const AVAILABLE_ICONS: IconNames[] = [
        'ticket-simple',
        'shirt',
        'star',
        'music',
        'martini-glass-citrus',
        'square-parking',
        'car',
        'bus',
        'compass',
        'party-horn',
        'balloon',
        'face-smile',
        'right',
        'campground',
        'ferris-wheel'
    ];
</script>

<style
    lang="scss"
    scoped>
    .icon-picker {
        display: grid;
        margin-top: 3px;
        gap: 9px;
        grid-template-columns: repeat(5, 1fr);
        grid-template-rows: repeat(3, 1fr);

        &-item {
            display: flex;
            aspect-ratio: 1;
            align-items: center;
            flex-flow: column;
            justify-content: center;
            background: rgb(var(--gray-1), .5);
            border: 1px solid rgb(var(--gray-3) / .5);
            border-radius: var(--radius);
            color: var(--foreground);
            cursor: pointer;
            outline: 0;
            transition: 210ms var(--swift-out);
            user-select: none;

            &.is-selected {
                background: rgb(var(--primary-3) / .75);
                border-color: rgb(var(--primary-4) / .5);
                color: rgb(var(--primary-9));
            }

            &:hover {
                background: rgb(var(--gray-1));
                border-color: rgb(var(--gray-3));
                box-shadow: var(--shadow-sm);
            }
        }
    }
</style>
