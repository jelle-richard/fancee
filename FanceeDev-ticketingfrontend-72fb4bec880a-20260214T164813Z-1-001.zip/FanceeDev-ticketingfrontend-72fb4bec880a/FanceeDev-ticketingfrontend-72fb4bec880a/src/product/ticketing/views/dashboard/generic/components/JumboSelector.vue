<template>
    <SelectorPane :title="selectedId ? selectedEventName : title">
        <FluxFormInputGroup>
            <FluxFormInputAddition icon="magnifying-glass"/>

            <FluxFormSelect
                v-model="selectedId"
                is-searchable
                :search-query="search"
                :placeholder="selectPlaceholder"
                :options="options"
                @update:search-query="emit('select-input-changed', $event);"/>

            <FluxSecondaryButton
                v-if="selectedId !== null"
                icon-before="xmark"
                @click="resetSelection"/>
        </FluxFormInputGroup>

        <p>{{ subtitle }}</p>
    </SelectorPane>
</template>

<script
    lang="ts"
    setup>
    // todo: Once flux supports it: bind the search as the second v-model binding instead of using the @update
    import { FluxFormSelectOption } from '@fancee/flux';
    import { computed, ref, toRefs, watch } from 'vue';
    import { SelectorPane } from '@/components/ui';

    export type Emits = {
        (e: 'selected-row-changed', selectedId: string): void;
        (e: 'select-input-changed', search: string): void;
    };

    export type Props = {
        readonly options: FluxFormSelectOption[];
        readonly title: string;
        readonly subtitle: string;
        readonly selectPlaceholder: string;
        readonly isLoadingOptions: boolean;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {options} = toRefs(props);

    const selectedId = ref<string | null>(null);
    const search = ref<string>('');

    const selectedEventName = computed(() => options.value.find(o => o.id === selectedId.value)?.label ?? '-');

    function resetSelection(): void {
        selectedId.value = null;
    }

    watch(selectedId, async selectedId => {
        emit('selected-row-changed', <string>selectedId);
    });
</script>
