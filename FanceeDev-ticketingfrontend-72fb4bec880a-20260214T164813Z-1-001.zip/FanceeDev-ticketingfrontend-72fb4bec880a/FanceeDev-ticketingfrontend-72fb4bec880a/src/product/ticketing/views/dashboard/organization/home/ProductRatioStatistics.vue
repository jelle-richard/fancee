<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="t('dashboard.statistics.productRatio.title')"
            :sub-title="t('dashboard.statistics.productRatio.subTitle')"/>

        <FluxPaneBody>
            <ApexChart
                v-show="renderKey > 0"
                :key="renderKey"
                type="donut"
                height="400"
                :options="donutOptions"
                :series="donutSeries"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { IssuedProductStatistics } from '@fancee/data';
    import { nextTick, onMounted, ref, toRefs, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        readonly products: IssuedProductStatistics[];
        readonly isLoading: boolean;
    }

    const props = defineProps<Props>();
    const {products, isLoading} = toRefs(props);

    const {t} = useI18n();

    const donutSeries = ref<number[]>([]);
    const donutOptions = ref({
        chart: {
            id: 'donut-example-products-sold',
            type: 'donut',
            toolbar: {
                show: true,
                export: {
                    csv: {
                        filename: 'Product-ratio',
                        columnDelimiter: ',',
                        headerCategory: 'Product',
                        headerValue: 'Sold'
                    },
                    svg: {
                        filename: 'Product-ratio-YOUREVENT-07092021'
                    },
                    png: {
                        filename: 'Product-ratio-YOUREVENT-07092021'
                    }
                }
            }
        },
        colors: ['#f59f40', '#89a69d', '#6071b5', '#7367f0', '#ea5455', '#00cfe8', '#28c76f'],
        labels: [] as string[],
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    });
    const renderKey = ref(0);

    onMounted(() => nextTick(() => renderKey.value = Math.floor(Math.random() * 10)));

    watch(products, products => {
        donutSeries.value = [];
        donutOptions.value.labels = [];

        products.forEach(p => {
            donutSeries.value.push(p.soldAmount);
            donutOptions.value.labels.push(p.name);
        });
    }, {immediate: true});
</script>
