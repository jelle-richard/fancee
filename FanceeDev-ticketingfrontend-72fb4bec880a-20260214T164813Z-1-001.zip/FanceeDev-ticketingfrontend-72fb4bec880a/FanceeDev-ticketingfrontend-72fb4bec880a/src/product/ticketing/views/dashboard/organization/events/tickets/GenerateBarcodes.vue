<template>
    <FluxStack :gap="15">
        <ValidationField
            :label="t('event.singular')"
            :rules="{required}"
            :value="selectedEventId">
            <FluxFormSelectAsync
                v-model="selectedEventId"
                :placeholder="t('event.addBarcodesOverlay.selectEvent')"
                :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>
        </ValidationField>

        <ValidationField
            v-if="selectedEventId !== null"
            :label="t('event.productSingular')"
            :rules="{required}"
            :value="selectedProductId">
            <FluxFormSelectAsync
                v-model="selectedProductId"
                :placeholder="t('event.addBarcodesOverlay.selectProduct')"
                :fetch-options="fetchSelect(async (ids: string[]) => await getEventProductOptions(organizationId, [selectedEventId!], null, ids))"
                :fetch-relevant="fetchSelect(async () => await getEventProductOptions(organizationId, [selectedEventId!], null))"
                :fetch-search="fetchSelect(async (searchQuery: string) => await getEventProductOptions(organizationId, [selectedEventId!], null, searchQuery))"/>
        </ValidationField>

        <ValidationField
            :label="t('global.amount')"
            :rules="{required, integer, minValue: minValue(1), maxValue: maxValue(MAX_VALUE_BARCODE_GENERATE)}"
            :value="amount">
            <FluxFormInput
                v-model="amount"
                type="number"/>
        </ValidationField>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { SelectService } from '@fancee/api';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField } from '@/components/form';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { MAX_VALUE_BARCODE_GENERATE } from '@/data';
    import { integer, maxValue, minValue, required } from '@/data/validation';
    import { fetchSelect } from '@/util';

    export interface Emits {
        (e: 'selected-event-id-changed', eventId: string | null): void;

        (e: 'selected-product-id-changed', productId: string | null): void;

        (e: 'amount-changed', amount: number): void;
    }

    const emit = defineEmits<Emits>();

    const {t} = useI18n();
    const {getEventOptions, getEventProductOptions} = useService(SelectService);
    const organizationId = useActiveOrganizationId();

    const selectedEventId = ref<string | null>(null);
    const selectedProductId = ref<string | null>(null);
    const amount = ref(0);

    watch(selectedEventId, () => emit('selected-event-id-changed', unref(selectedEventId)));

    watch(selectedProductId, () => emit('selected-product-id-changed', unref(selectedProductId)));

    watch(amount, () => emit('amount-changed', unref(amount)));
</script>
