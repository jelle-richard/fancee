<!--suppress ALL -->
<template>
    <div
        style=""
        lang="en">
        <!--[if mso | IE]>
        <table
            align="center"
            border="0"
            cellpadding="0"
            cellspacing="0"
            class=""
            role="presentation"
            style="width:600px;"
            width="600">
        <tr>
            <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table
                align="center"
                border="0"
                cellpadding="0"
                cellspacing="0"
                role="presentation"
                style="width:100%;">
                <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;padding-bottom:0;text-align:center;">
                        <!--[if mso | IE]>
                        <table
                            role="presentation"
                            border="0"
                            cellpadding="0"
                            cellspacing="0">
                        <tr>
                            <td
                                class=""
                                style="vertical-align:top;width:600px;"><![endif]-->
                        <div
                            class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table
                                border="0"
                                cellpadding="0"
                                cellspacing="0"
                                role="presentation"
                                style="vertical-align:top;"
                                width="100%">
                                <tbody>
                                <tr>
                                    <td
                                        align="left"
                                        style="font-size:0px;padding:10px 25px;word-break:break-word;">
                                        <table
                                            border="0"
                                            cellpadding="0"
                                            cellspacing="0"
                                            role="presentation"
                                            style="border-collapse:collapse;border-spacing:0px;">
                                            <tbody>
                                            <tr>
                                                <td style="width:120px;">
                                                    <img
                                                        height="auto"
                                                        :src="appLogo"
                                                        style="border:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:16px;"
                                                        width="120"/>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table>
    <table
        align="center"
        border="0"
        cellpadding="0"
        cellspacing="0"
        class=""
        role="presentation"
        style="width:600px;"
        width="600">
    <tr>
        <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table
                align="center"
                border="0"
                cellpadding="0"
                cellspacing="0"
                role="presentation"
                style="width:100%;">
                <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;padding-top:0;text-align:center;">
                        <!--[if mso | IE]>
                        <table
                            role="presentation"
                            border="0"
                            cellpadding="0"
                            cellspacing="0">
                        <tr>
                            <td
                                class=""
                                style="vertical-align:top;width:600px;"><![endif]-->
                        <div
                            class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table
                                border="0"
                                cellpadding="0"
                                cellspacing="0"
                                role="presentation"
                                style="vertical-align:top;"
                                width="100%">
                                <tbody>
                                <tr>
                                    <td
                                        align="center"
                                        style="font-size:0px;padding:10px 25px;padding-top:18px;padding-bottom:12px;word-break:break-word;">
                                        <p style="border-top:solid 4px #f1f5f9;font-size:1px;margin:0px auto;width:100%;">
                                        </p>
                                        <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" style="border-top:solid 4px #f1f5f9;font-size:1px;margin:0px auto;width:550px;" role="presentation" width="550px" ><tr><td style="height:0;line-height:0;"> &nbsp;
                                        </td></tr></table><![endif]-->
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table>
    <table
        align="center"
        border="0"
        cellpadding="0"
        cellspacing="0"
        class=""
        role="presentation"
        style="width:600px;"
        width="600">
    <tr>
        <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table
                align="center"
                border="0"
                cellpadding="0"
                cellspacing="0"
                role="presentation"
                style="width:100%;">
                <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;padding-top:0;text-align:center;">
                        <!--[if mso | IE]>
                        <table
                            role="presentation"
                            border="0"
                            cellpadding="0"
                            cellspacing="0">
                        <tr>
                            <td
                                class=""
                                style="vertical-align:top;width:600px;"><![endif]-->
                        <div
                            class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table
                                border="0"
                                cellpadding="0"
                                cellspacing="0"
                                role="presentation"
                                style="vertical-align:top;"
                                width="100%">
                                <tbody>
                                <tr>
                                    <td
                                        align="left"
                                        style="font-size:0px;padding:10px 25px;padding-top:0;word-break:break-word;">
                                        <div
                                            style="font-family:Arial, sans-serif;font-size:16px;line-height:1.5;text-align:left;color:#334155;"
                                            v-html="parsedContent()"/>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table>
    <table
        align="center"
        border="0"
        cellpadding="0"
        cellspacing="0"
        class=""
        role="presentation"
        style="width:600px;"
        width="600">
    <tr>
        <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table
                align="center"
                border="0"
                cellpadding="0"
                cellspacing="0"
                role="presentation"
                style="width:100%;">
                <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;padding-top:0;text-align:center;">
                        <!--[if mso | IE]>
                        <table
                            role="presentation"
                            border="0"
                            cellpadding="0"
                            cellspacing="0">
                        <tr>
                            <td
                                class=""
                                style="vertical-align:top;width:300px;"><![endif]-->
                        <div
                            class="mj-column-per-50 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table
                                border="0"
                                cellpadding="0"
                                cellspacing="0"
                                role="presentation"
                                style="vertical-align:top;"
                                width="100%">
                                <tbody>
                                <tr>
                                    <td
                                        align="right"
                                        vertical-align="middle"
                                        style="font-size:0px;padding:10px 25px;word-break:break-word;">
                                        <table
                                            border="0"
                                            cellpadding="0"
                                            cellspacing="0"
                                            role="presentation"
                                            style="border-collapse:separate;width:100%;line-height:100%;">

                                            <tbody>
                                            <tr>
                                                <td
                                                    align="center"
                                                    bgcolor="#6071b5"
                                                    role="presentation"
                                                    style="border:none;border-radius:9px;cursor:auto;mso-padding-alt:10px 25px;background:#6071b5;"
                                                    valign="middle">
                                                    <a
                                                        class="disabled-button"
                                                        href="#"
                                                        target="_blank"> Payment overview </a>
                                                </td>
                                            </tr>
                                            </tbody>

                                        </table>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td>
                    <td
                        class=""
                        style="vertical-align:top;width:300px;"><![endif]-->
                        <div
                            class="mj-column-per-50 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table
                                border="0"
                                cellpadding="0"
                                cellspacing="0"
                                role="presentation"
                                style="vertical-align:top;"
                                width="100%">

                                <tbody>
                                <tr>
                                    <td
                                        align="left"
                                        vertical-align="middle"
                                        style="font-size:0px;padding:10px 25px;word-break:break-word;">
                                        <table
                                            border="0"
                                            cellpadding="0"
                                            cellspacing="0"
                                            role="presentation"
                                            style="border-collapse:separate;width:100%;line-height:100%;">
                                            <tbody>
                                            <tr>
                                                <td
                                                    align="center"
                                                    bgcolor="#6071b5"
                                                    role="presentation"
                                                    style="border:none;border-radius:9px;cursor:auto;mso-padding-alt:10px 25px;background:#6071b5;"
                                                    valign="middle">
                                                    <a
                                                        class="disabled-button"
                                                        href="mailto:@test@test.com"
                                                        target="_blank"> Contact event </a>
                                                </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                </tbody>

                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table>
    <table
        align="center"
        border="0"
        cellpadding="0"
        cellspacing="0"
        class=""
        role="presentation"
        style="width:600px;"
        width="600">
    <tr>
        <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table
                align="center"
                border="0"
                cellpadding="0"
                cellspacing="0"
                role="presentation"
                style="width:100%;">
                <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;padding-top:0;text-align:center;">
                        <!--[if mso | IE]>
                        <table
                            role="presentation"
                            border="0"
                            cellpadding="0"
                            cellspacing="0">
                        <tr>
                            <td
                                class=""
                                style="vertical-align:top;width:600px;"><![endif]-->
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table>
    <table
        align="center"
        border="0"
        cellpadding="0"
        cellspacing="0"
        class=""
        role="presentation"
        style="width:600px;"
        width="600">
    <tr>
        <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table
                align="center"
                border="0"
                cellpadding="0"
                cellspacing="0"
                role="presentation"
                style="width:100%;">
                <tbody>
                <tr>
                    <td style="direction:ltr;font-size:0px;padding:20px 0;text-align:center;">
                        <!--[if mso | IE]>
                        <table
                            role="presentation"
                            border="0"
                            cellpadding="0"
                            cellspacing="0">
                        <tr>
                            <td
                                class=""
                                style="vertical-align:top;width:600px;"><![endif]-->
                        <div
                            class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table
                                border="0"
                                cellpadding="0"
                                cellspacing="0"
                                role="presentation"
                                style="vertical-align:top;"
                                width="100%">
                                <tbody>
                                <tr>
                                    <td
                                        align="center"
                                        style="font-size:0px;padding:10px 25px;padding-top:18px;padding-bottom:12px;word-break:break-word;">
                                        <p style="border-top:solid 4px #f1f5f9;font-size:1px;margin:0px auto;width:100%;">
                                        </p>
                                        <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" style="border-top:solid 4px #f1f5f9;font-size:1px;margin:0px auto;width:550px;" role="presentation" width="550px" ><tr><td style="height:0;line-height:0;"> &nbsp;
                                        </td></tr></table><![endif]-->
                                    </td>
                                </tr>
                                <tr>
                                    <td
                                        align="center"
                                        style="font-size:0px;padding:10px 25px;word-break:break-word;">
                                        <div style="font-family:Arial, sans-serif;font-size:12px;line-height:1.5;text-align:center;color:#64748b;">
                                            <p>&copy; FanceeTest</p>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><![endif]-->
    </div>
</template>

<script
    lang="ts"
    setup>

    import { toRefs, unref } from 'vue';
    import { Template } from '@/data/dto/editor/Template';
    import appLogo from '@/assets/images/logos/fancee/ticketing/FanceeTicketingBlack.svg';

    export interface Props {
        readonly content: string;
        readonly templateOptions: Template[];
    }

    const props = defineProps<Props>();

    const {content, templateOptions} = toRefs(props);

    function parsedContent(): string {
        let parsedContent = unref(content);

        templateOptions.value.forEach((option: Template) => parsedContent = parsedContent.replaceAll(option.key, option.contents));

        return parsedContent;
    }
</script>

<style scoped>
    h1 {
        margin: 0;
        font-size: 16px;
        font-weight: 700;
    }

    h2 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
    }

    p {
        margin: 0;
    }

    h2 + p {
        margin-top: 18px;
    }

    a {
        color: inherit;
    }

    #outlook a {
        padding: 0;
    }

    body {
        margin: 0;
        padding: 0;
        -webkit-text-size-adjust: 100%;
        -ms-text-size-adjust: 100%;
    }

    table,
    td {
        border-collapse: collapse;
        mso-table-lspace: 0pt;
        mso-table-rspace: 0pt;
    }

    img {
        border: 0;
        height: auto;
        line-height: 100%;
        outline: none;
        text-decoration: none;
        -ms-interpolation-mode: bicubic;
    }

    p {
        display: block;
        margin: 13px 0;
    }

    .disabled-button {
        pointer-events: none;
        cursor: default;
        display: inline-block;
        background: #6071b5;
        color: white;
        font-family: Arial, sans-serif;
        font-size: 16px;
        font-weight: 500;
        line-height: 1.5;
        margin: 0;
        text-decoration: none;
        text-transform: none;
        padding: 10px 25px;
        mso-padding-alt: 0px;
        border-radius: 9px;
    }

    @media only screen and (min-width: 480px) {
        .mj-column-per-100 {
            width: 100% !important;
            max-width: 100%;
        }

        .mj-column-per-50 {
            width: 50% !important;
            max-width: 50%;
        }

        .moz-text-html .mj-column-per-100 {
            width: 100% !important;
            max-width: 100%;
        }

        .moz-text-html .mj-column-per-50 {
            width: 50% !important;
            max-width: 50%;
        }
    }

    @media only screen and (max-width: 480px) {
        table.mj-full-width-mobile {
            width: 100% !important;
        }

        td.mj-full-width-mobile {
            width: auto !important;
        }
    }
</style>
