<template>
    <div :class="$style.preRegisterContainer">
        <FluxPane
            v-if="!isExpired && !isSignUpComplete"
            :is-loading="isLoading">
            <FluxPaneMedia
                v-if="preRegister.headerMedia !== null"
                :image-url="preRegister.headerMedia.url"/>

            <FluxPaneBody
                :class="$style.preRegisterHeader"
                is-larger-padded>
                <h1>{{ preRegister.name }}</h1>

                <Countdown
                    v-if="!isLoading"
                    :end-date="preRegister.expiresOn"/>
            </FluxPaneBody>

            <FluxPaneBody is-larger-padded>
                <div v-html="preRegister.description"/>
            </FluxPaneBody>

            <FluxPaneBody is-larger-padded>
                <FluxFormColumn>
                    <ValidationNotice v-if="!previewPreRegister"/>

                    <ValidationField
                        :label="t('form.field.email')"
                        :rules="{required: requiredIf(!previewPreRegister), email}"
                        :value="signUp.email">
                        <FluxFormInput
                            v-model="signUp.email"
                            auto-complete="email"
                            auto-focus
                            type="email"/>
                    </ValidationField>

                    <FluxFormRow>
                        <ValidationField
                            :label="t('form.field.firstName')"
                            :rules="{minLength: minLength(2), required: requiredIf(!previewPreRegister)}"
                            :value="signUp.firstName">
                            <FluxFormInput
                                v-model="signUp.firstName"
                                auto-complete="given-name"
                                type="email"/>
                        </ValidationField>

                        <ValidationField
                            :label="t('form.field.lastName')"
                            :rules="{minLength: minLength(2), required: requiredIf(!previewPreRegister)}"
                            :value="signUp.lastName">
                            <FluxFormInput
                                v-model="signUp.lastName"
                                auto-complete="family-name"
                                type="email"/>
                        </ValidationField>
                    </FluxFormRow>
                </FluxFormColumn>
            </FluxPaneBody>

            <FluxPaneFooter>
                <FluxSpacer/>

                <FluxPrimaryButton
                    :disabled="invalid || !!previewPreRegister"
                    :is-loading="isLoading"
                    icon-before="circle-check"
                    :label="t('global.submit')"
                    @click="validated(submitPreRegister)"/>
            </FluxPaneFooter>
        </FluxPane>

        <FluxPane v-else-if="isSignUpComplete">
            <FluxPaneBody is-larger-padded>
                <FluxGrid>
                    <FluxGridColumn
                        :class="$style.preRegisterGridColumn"
                        :md="8">
                        <h2>{{ t('marketing.preRegister.signUp.complete.title') }}</h2>
                        <p>{{ t('marketing.preRegister.signUp.complete.message', {name: preRegister.name}) }}</p>
                    </FluxGridColumn>

                    <FluxGridColumn
                        :class="$style.preRegisterGridColumn"
                        :md="4">
                        <Visual
                            class="registration-complete-illustration"
                            variant="confirmed"/>
                    </FluxGridColumn>
                </FluxGrid>
            </FluxPaneBody>
        </FluxPane>

        <FluxPane v-else-if="isExpired">
            <FluxPaneBody is-larger-padded>
                <FluxGrid>
                    <FluxGridColumn
                        :class="$style.preRegisterGridColumn"
                        :md="8">
                        <h2>{{ t('marketing.preRegister.signUp.expired.title') }}</h2>
                        <p>{{ t('marketing.preRegister.signUp.expired.message') }}</p>
                    </FluxGridColumn>

                    <FluxGridColumn
                        :class="$style.preRegisterGridColumn"
                        :md="4">
                        <Visual
                            class="pre-register-expired-illustration"
                            variant="countdown"/>
                    </FluxGridColumn>
                </FluxGrid>
            </FluxPaneBody>
        </FluxPane>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { PreRegisterService } from '@fancee/api';
    import { PreRegister, PreRegisterSignUp } from '@fancee/data';
    import { DateTime } from 'luxon';
    import { onMounted, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { Countdown } from '@/components/timer';
    import { Visual } from '@/components/ui';
    import { useLoaded, useRouteParam, useRouter, useService, useValidationScope } from '@/composable';
    import { email, minLength, requiredIf } from '@/data/validation';
    import { guarded, isDateTimeBefore } from '@/util';

    const {t} = useI18n();
    const {isLoading, loaded} = useLoaded();
    const {get: getPreRegister, signUp: preRegisterSignUp} = useService(PreRegisterService);
    const {invalid, validated} = useValidationScope();
    const router = useRouter();

    const _getPreRegister = guarded(loaded(getPreRegister), () => router.push({name: 'error-404'}));
    const _preRegisterSignUp = guarded(loaded(preRegisterSignUp), t('ui.somethingWentWrong.title'), t('marketing.preRegister.signUp.failed'));

    const signUp = ref(PreRegisterSignUp.empty());
    const preRegister = ref(PreRegister.default());
    const isExpired = ref(false);
    const isSignUpComplete = ref(false);

    export type Props = {
        readonly previewPreRegister?: PreRegister | null;
    };

    const props = withDefaults(defineProps<Props>(), {
        previewPreRegister: null
    });
    const {previewPreRegister} = toRefs(props);

    const code = useRouteParam('code');

    onMounted(async () => {
        const preview = unref(previewPreRegister);

        if (!!preview) {
            preRegister.value = preview;
            return;
        }

        const {data} = await _getPreRegister(unref(code)!);
        preRegister.value = data;
        isExpired.value = isDateTimeBefore(data.expiresOn, DateTime.now());
    });

    async function submitPreRegister(): Promise<void> {
        await _preRegisterSignUp(unref(code)!, unref(signUp));
        isSignUpComplete.value = true;
    }

    watch(previewPreRegister, previewPreRegister => {
        if (!previewPreRegister) {
            return;
        }

        preRegister.value = previewPreRegister;
    });
</script>

<style
    lang="scss"
    module>
    .preRegisterContainer {
        margin: 60px auto;
        width: min(100%, 720px);
    }

    .preRegisterGridColumn {
        align-content: flex-start;
    }

    .preRegisterHeader {
        display: grid;
        align-content: flex-start;
        gap: 30px;
        grid-template-columns: 1fr auto;

        :global(h1) {
            font-size: 24px;
            line-height: 1.5;
        }
    }
</style>
