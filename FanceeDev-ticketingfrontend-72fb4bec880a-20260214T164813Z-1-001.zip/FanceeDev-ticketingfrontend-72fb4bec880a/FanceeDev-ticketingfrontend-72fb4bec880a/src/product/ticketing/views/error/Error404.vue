<template>
    <EmptyView
        :class="$style.notFound"
        :title="t('ui.notFound.page.title')"
        :message="t('ui.notFound.page.content')"
        variant="notFound">
        <FluxButtonStack>
            <FluxSecondaryButton
                :label="t('global.back')"
                @click="back"/>

            <FluxSecondaryButton
                :label="t('ui.notFound.page.goHome')"
                :to="{name: 'home'}"
                type="route"/>
        </FluxButtonStack>
    </EmptyView>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { EmptyView } from '@/components/ui';

    const {t} = useI18n();

    function back(): void {
        history.go(-1);
    }
</script>

<style module>
    .notFound {
        min-height: 100dvh;
    }
</style>
