<template>
    <FluxPane>
        <FluxActionBar>
            <template #actions-before-search>
                <ClaimCheck claim="admin.paymentmethod.export">
                    <ToolbarDownload
                        :is-loading="downloadInProgress"
                        @download="downloadPaymentMethodsCsv"/>
                </ClaimCheck>
            </template>

            <template #search>
                <ToolbarSearch
                    v-model="search"
                    :placeholder="t('crm.paymentMethod.search')"/>
            </template>
        </FluxActionBar>

        <FluxDataTable
            :is-loading="isLoading"
            :data-set="paymentMethods"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems"
            is-hoverable>
            <template #header>
                <FluxTableHeader>{{ t('crm.paymentMethod.table.id') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.paymentMethod.table.name') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.paymentMethod.table.provider') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.paymentMethod.table.cost') }}</FluxTableHeader>
            </template>

            <template #id="{row: {id}}">
                <FluxTableCell>{{ id }}</FluxTableCell>
            </template>

            <template #name="{row: {name, brandCode}}">
                <FluxTableCell>
                    <FluxStack
                        axis="horizontal"
                        :gap="15">
                        <img
                            v-if="paymentMethodImages[brandCode]"
                            :alt="name"
                            width="32"
                            :src="paymentMethodImages[brandCode]"/>

                        <span>{{ name }}</span>
                    </FluxStack>
                </FluxTableCell>
            </template>

            <template #provider="{row: {provider}}">
                <FluxTableCell>{{ provider }}</FluxTableCell>
            </template>

            <template #cost="{row: {feePercentage, feeStaticCents}}">
                <FluxTableCell>
                    <FluxBadgeStack>
                        <FluxBadge
                            v-if="feePercentage !== null && feeStaticCents !== null"
                            :label="`${feePercentage}% + ${asMoney(feeStaticCents, currency)}`"/>

                        <FluxBadge
                            v-else
                            if="feePercentage !== null"
                            :label="`${feePercentage}%`"/>

                        <FluxBadge
                            v-else
                            if="feeStaticCents !== null"
                            :label="asMoney(feeStaticCents, currency)"/>
                    </FluxBadgeStack>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { PaymentMethodService } from '@fancee/api';
    import { EventPaymentMethod } from '@fancee/data';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ToolbarDownload, ToolbarSearch } from '@/components/filter';
    import { ClaimCheck } from '@/components/ui';
    import { useCurrency, usePagination, useService } from '@/composable';
    import { asMoney, downloadBlob, guarded } from '@/util';
    import paymentMethodImages from '@/assets/images/payment_methods_brandcodes';

    const {t} = useI18n();
    const {csvExport, list} = useService(PaymentMethodService);
    const currency = useCurrency();

    const _csvExport = guarded(csvExport, t('ui.somethingWentWrong.title'), t('crm.paymentMethod.downloadFailed'));
    const _list = guarded(list, t('ui.somethingWentWrong.title'), t('crm.paymentMethod.loadingFailed'));

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const search = ref('');
    const isLoading = ref(false);
    const paymentMethods = ref<EventPaymentMethod[]>([]);
    const downloadInProgress = ref(false);

    async function loadPaymentMethods(): Promise<void> {
        isLoading.value = true;

        try {
            const {data: {items, totalItems}} = await _list(unref(pageLength), unref(currentPage), unref(search));

            paymentMethods.value = items;
            setTotalItems(totalItems);
        } finally {
            isLoading.value = false;
        }
    }

    async function downloadPaymentMethodsCsv(): Promise<void> {
        downloadInProgress.value = true;

        try {
            const {blob, name} = await _csvExport(search.value);
            downloadBlob(blob, name);
        } finally {
            downloadInProgress.value = false;
        }
    }

    watch([currentPage, pageLength, search], async () => await loadPaymentMethods(), {immediate: true});
</script>
