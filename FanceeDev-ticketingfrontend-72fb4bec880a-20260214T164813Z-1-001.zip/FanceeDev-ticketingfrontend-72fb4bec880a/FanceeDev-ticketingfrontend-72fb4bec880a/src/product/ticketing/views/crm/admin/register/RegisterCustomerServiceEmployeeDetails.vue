<template>
    <ValidationNotice pane-body/>

    <FluxPaneBody>
        <FluxFormColumn>
            <ValidationField
                :label="t('form.field.email')"
                :rules="{required, email}"
                :value="customerServiceEmployee.email">
                <FluxFormInput
                    v-model="customerServiceEmployee.email"
                    auto-complete="new-email"
                    auto-focus
                    type="email"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.password')"
                :rules="{required, minLength: minLength(10)}"
                :value="customerServiceEmployee.password">
                <FluxFormInput
                    v-model="customerServiceEmployee.password"
                    auto-complete="off"
                    type="password"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.firstName')"
                :rules="{required}"
                :value="customerServiceEmployee.firstName">
                <FluxFormInput
                    v-model="customerServiceEmployee.firstName"
                    auto-complete="off"
                    type="text"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.firstName')"
                :rules="{required}"
                :value="customerServiceEmployee.lastName">
                <FluxFormInput
                    v-model="customerServiceEmployee.lastName"
                    auto-complete="off"
                    type="text"/>
            </ValidationField>

            <ValidationField
                :label="t('crm.adminRegister.customerServiceEmployee.countryManager')"
                :rules="{required}"
                :value="selectedCountryManager">
                <FluxFormSelect
                    v-model="selectedCountryManager"
                    :options="countryManagers"/>
            </ValidationField>

            <FluxNotice
                icon="circle-info"
                is-small
                :message="t('crm.adminRegister.customerServiceEmployee.hint')"/>
        </FluxFormColumn>
    </FluxPaneBody>

    <FluxPaneFooter>
        <FluxSpacer/>
        <FluxPrimaryButton
            :disabled="invalid"
            icon-before="circle-check"
            :label="t('global.save')"
            @click="validated(register)"/>
    </FluxPaneFooter>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { CountryGroupedCountryManagers, RegisterCustomerServiceEmployee } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { computed, onMounted, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService, useValidationScope } from '@/composable';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { DEFAULT_CUSTOMER_SERVICE_EMPLOYEE_CLAIMS } from '@/data';
    import { SelectAdapter } from '@/data/adapter/components/select/SelectAdapter';
    import { email, minLength, required } from '@/data/validation';
    import { guarded } from '@/util';

    const {t} = useI18n();
    const {getActiveCountryManagers, registerCustomerServiceEmployee} = useService(UserService);
    const {invalid, validated} = useValidationScope();

    const _getActiveCountryManagers = guarded(getActiveCountryManagers, t('ui.somethingWentWrong.title'), t('crm.adminRegister.customerServiceEmployee.countryManager'));
    const _registerCustomerServiceEmployee = guarded(registerCustomerServiceEmployee, t('ui.somethingWentWrong.title'), t('crm.adminRegister.customerServiceEmployee.createFailed'));

    const customerServiceEmployee = ref(RegisterCustomerServiceEmployee.empty());
    const countryGroupedCountryManagers = ref<CountryGroupedCountryManagers[]>([]);
    const selectedCountryManager = ref<string | null>(null);
    const countryManagers = computed(() => SelectAdapter.parseCountryGroupedCountryManagersToFluxFormSelectOption(unref(countryGroupedCountryManagers)));

    onMounted(async () => await getCountryManagers());

    async function getCountryManagers(): Promise<void> {
        const {data} = await _getActiveCountryManagers();
        countryGroupedCountryManagers.value = data;
    }

    async function register(): Promise<void> {
        customerServiceEmployee.value.claims = DEFAULT_CUSTOMER_SERVICE_EMPLOYEE_CLAIMS;

        await _registerCustomerServiceEmployee(unref(customerServiceEmployee));

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('crm.adminRegister.customerServiceEmployee.createSuccess')
        });

        customerServiceEmployee.value = RegisterCustomerServiceEmployee.empty();
        selectedCountryManager.value = null;
    }

    watch(selectedCountryManager, () => {
        if (!unref(selectedCountryManager)) {
            return;
        }

        customerServiceEmployee.value.countryManagerId = unref(selectedCountryManager)!;
    });
</script>
