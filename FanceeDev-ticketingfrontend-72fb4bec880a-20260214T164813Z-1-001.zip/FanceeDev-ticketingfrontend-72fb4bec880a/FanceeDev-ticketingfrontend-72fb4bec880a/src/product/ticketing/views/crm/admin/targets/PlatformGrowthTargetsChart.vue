<template>
    <FluxPane
        is-contained
        :is-loading="platformGrowthTargetProgression.length === 0 || ticketRevenueIndication === null">
        <FluxPaneHeader
            icon="star"
            :title="t('crm.home.targets.title')"
            :sub-title="t('crm.home.targets.subTitle')">
            <FluxSpacer/>

            <FluxBadgeStack>
                <FluxChip :label="t('crm.home.targets.ticketFeeThisMonth', [asMoney(ticketFeeProgressThisMonth, currency), asMoney(ticketFeeTargetThisMonth, currency)])"/>
                <FluxChip :label="t('crm.home.targets.ticketFeeLastMonth', [asMoney(ticketFeeProgressLastMonth, currency), asMoney(ticketFeeTargetLastMonth, currency)])"/>
            </FluxBadgeStack>
        </FluxPaneHeader>

        <FluxPaneBody>
            <ApexChart
                type="line"
                height="400"
                :options="platformGrowthOptions"
                :series="platformGrowthSeries"/>
        </FluxPaneBody>

        <FluxPaneDeck
            :min-column-width="150"
            :class="$style.stats">
            <FluxPane>
                <FluxPaneBody>
                    <FluxStack :gap="6">
                        <span>{{ t('crm.home.targets.topDailySoldProducts') }}</span>
                        <h2>{{ asFormattedNumber(ticketRevenueIndication?.highestDailyTicketSalesAmount ?? 0) }}</h2>
                    </FluxStack>
                </FluxPaneBody>
            </FluxPane>

            <FluxPane>
                <FluxPaneBody>
                    <FluxStack :gap="6">
                        <span>{{ t('crm.home.targets.revenueToday') }}</span>
                        <h2>{{ asMoney(ticketRevenueIndication?.ticketFeeRevenueCentsYesterday ?? 0, currency) }}</h2>
                    </FluxStack>
                </FluxPaneBody>
            </FluxPane>

            <FluxPane>
                <FluxPaneBody>
                    <FluxStack :gap="6">
                        <span>{{ t('crm.home.targets.revenueYesterday') }}</span>
                        <h2>{{ asMoney(ticketRevenueIndication?.ticketFeeRevenueCentsToday ?? 0, currency) }}</h2>
                    </FluxStack>
                </FluxPaneBody>
            </FluxPane>
        </FluxPaneDeck>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { Currency, PlatformGrowthTargetProgression, TargetProgression, TicketRevenueIndication } from '@fancee/data';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { asFormattedNumber, asMoney, formatMonthLocal, parseDateTime } from '@/util';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        readonly currency: Currency;
        readonly platformGrowthTargetProgression: PlatformGrowthTargetProgression[];
        readonly ticketRevenueIndication: TicketRevenueIndication | null;
    }

    const props = defineProps<Props>();
    const {currency, platformGrowthTargetProgression, ticketRevenueIndication} = toRefs(props);

    const {t} = useI18n();

    const platformGrowthSeries = ref<object[]>([
        {
            name: t('crm.home.targets.revenueAccomplished'),
            data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        },
        {
            name: t('crm.home.targets.revenueTarget'),
            data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        }
    ]);
    const platformGrowthOptions = ref({
        chart: {
            zoom: {
                enabled: false
            },
            toolbar: {
                show: false
            }
        },
        markers: {
            strokeWidth: 4,
            strokeOpacity: 1,
            strokeColors: ['#f59f40'],
            colors: ['#f59f40']
        },
        colors: ['#6071b5', '#89a69d'],
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'straight'
        },
        grid: {
            xaxis: {
                lines: {
                    show: true
                }
            }
        },
        tooltip: {
            custom: function (data) {
                return generateTooltip(data.dataPointIndex);
            }.bind(this)
        },
        yaxis: {
            labels: {
                formatter: data => asMoney(data, unref(currency))
            }
        },
        xaxis: {
            categories: [] as string[]
        }
    });

    const parseGrowthTargetDatesToShortMonthRepresentation = computed(() => platformGrowthTargetProgression.value.map(pg => parseDateTime(pg.date).monthShort!));
    const currentMonth = computed(() => DateTime.now().month);
    const previousMonth = computed(() => DateTime.now().plus({month: -1}).month);

    const ticketFeeProgressThisMonth = computed(() => unref(platformGrowthTargetProgression)[unref(currentMonth) - 1]?.ticketFeeRevenueCents.progress ?? 0);
    const ticketFeeTargetThisMonth = computed(() => unref(platformGrowthTargetProgression)[unref(currentMonth) - 1]?.ticketFeeRevenueCents.target ?? 0);
    const ticketFeeProgressLastMonth = computed(() => unref(platformGrowthTargetProgression)[unref(previousMonth) - 1]?.ticketFeeRevenueCents.progress ?? 0);
    const ticketFeeTargetLastMonth = computed(() => unref(platformGrowthTargetProgression)[unref(previousMonth) - 1]?.ticketFeeRevenueCents.target ?? 0);

    function generateTooltip(index: number): string {
        return `<div style="padding: 6px;">
                    <h3 style="color: inherit; text-transform: capitalize;">${formatMonthLocal(unref(platformGrowthTargetProgression)[index].date)}</h3>
                    ${generateTooltipLine('crm.home.targets.tooltip.ticketFeeRevenue', unref(platformGrowthTargetProgression)[index].ticketFeeRevenueCents, true)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.seatedTicketFeeREvenue', unref(platformGrowthTargetProgression)[index].seatedTicketFeeRevenueCents, true)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.tickets', unref(platformGrowthTargetProgression)[index].tickets, false)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.seatedTickets', unref(platformGrowthTargetProgression)[index].seatedTickets, false)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.organizations', unref(platformGrowthTargetProgression)[index].organizations, false)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.events', unref(platformGrowthTargetProgression)[index].events, false)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.placedOrders', unref(platformGrowthTargetProgression)[index].placedOrders, false)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.fulfilledOrders', unref(platformGrowthTargetProgression)[index].fulfilledOrders, false)}<br>
                    ${generateTooltipLine('crm.home.targets.tooltip.uniqueBuyers', unref(platformGrowthTargetProgression)[index].uniqueBuyers, false)}
                </div>`;
    }

    function generateTooltipLine(translationKey: string, targetProgression: TargetProgression, isMoney: boolean): string {
        if (isMoney) {
            return `<span>${t(translationKey, [asMoney(targetProgression.progress, unref(currency)), asMoney(targetProgression.target, unref(currency))])}</span>`;
        }

        return `<span>${t(translationKey, [asFormattedNumber(targetProgression.progress), asFormattedNumber(targetProgression.target)])}</span>`;
    }

    watch(platformGrowthTargetProgression, () => {
        let revenueProgressSeries: number[] = [];
        let revenueTargetSeries: number[] = [];

        unref(platformGrowthTargetProgression).forEach(pg => revenueProgressSeries.push(pg.ticketFeeRevenueCents.progress / 100));
        unref(platformGrowthTargetProgression).forEach(pg => revenueTargetSeries.push(pg.ticketFeeRevenueCents.target / 100));

        let series: object[] = [
            ...unref(platformGrowthSeries)
        ];

        series[0]['data'] = revenueProgressSeries;
        series[1]['data'] = revenueTargetSeries;

        platformGrowthSeries.value = series;

        let options = {
            ...unref(platformGrowthOptions)
        };

        options.xaxis.categories = unref(parseGrowthTargetDatesToShortMonthRepresentation);

        platformGrowthOptions.value = options;
    }, {immediate: true});
</script>

<style
    lang="scss"
    module>
    .stats {
        border-top: 1px solid rgb(var(--gray-3)) !important;
        border-radius: 0;
        text-align: center;
    }
</style>
