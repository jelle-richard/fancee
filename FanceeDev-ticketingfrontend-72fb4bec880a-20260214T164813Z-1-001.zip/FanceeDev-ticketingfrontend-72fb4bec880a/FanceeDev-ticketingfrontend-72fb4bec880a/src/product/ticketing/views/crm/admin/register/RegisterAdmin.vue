<template>
    <FluxGrid>
        <FluxGridColumn md="5">
            <FluxPane>
                <FluxPaneBody>
                    <FluxFormSelect
                        v-model="selectedAdminRole"
                        :placeholder="t('crm.adminRegister.choose')"
                        :options="[
                            {id: RegisterAdminType.CountryManager, label: RegisterAdminType.CountryManager},
                            {id: RegisterAdminType.CustomerServiceEmployee, label: RegisterAdminType.CustomerServiceEmployee}
                        ]"/>
                </FluxPaneBody>

                <RegisterCountryManagerDetails v-if="selectedAdminRole === RegisterAdminType.CountryManager"/>
                <RegisterCustomerServiceEmployeeDetails v-else-if="selectedAdminRole === RegisterAdminType.CustomerServiceEmployee"/>
            </FluxPane>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { RegisterAdminType } from '@/data/enum/user/admin/RegisterAdminType';
    import { ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import RegisterCountryManagerDetails from '@/product/ticketing/views/crm/admin/register/RegisterCountryManagerDetails.vue';
    import RegisterCustomerServiceEmployeeDetails from '@/product/ticketing/views/crm/admin/register/RegisterCustomerServiceEmployeeDetails.vue';

    const {t} = useI18n();

    const selectedAdminRole = ref<string | null>(null);
</script>
