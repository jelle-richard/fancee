<template>
    <ValidationNotice pane-body/>

    <FluxPaneBody>
        <FluxFormColumn>
            <ValidationField
                :label="t('form.field.email')"
                :rules="{required, email}"
                :value="countryManager.email">
                <FluxFormInput
                    v-model="countryManager.email"
                    auto-complete="new-email"
                    auto-focus
                    type="email"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.password')"
                :rules="{required, minLength: minLength(10)}"
                :value="countryManager.password">
                <FluxFormInput
                    v-model="countryManager.password"
                    auto-complete="off"
                    type="password"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.firstName')"
                :rules="{required}"
                :value="countryManager.firstName">
                <FluxFormInput
                    v-model="countryManager.firstName"
                    auto-complete="off"
                    type="text"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.lastName')"
                :rules="{required}"
                :value="countryManager.lastName">
                <FluxFormInput
                    v-model="countryManager.lastName"
                    auto-complete="off"
                    type="text"/>
            </ValidationField>

            <ValidationField
                :label="t('form.field.country')"
                :rules="{required}"
                :value="selectedCountry">
                <FluxFormSelect
                    v-model="selectedCountry"
                    is-searchable
                    :options="SELECT_COUNTRY_OPTIONS"/>
            </ValidationField>

            <ValidationField
                is-optional
                :label="t('crm.adminRegister.terminatesOn')"
                :rules="{future}"
                :value="countryManager.terminatesOn">
                <FluxFormDateInput
                    v-model="countryManager.terminatesOn"
                    auto-complete="off"/>
            </ValidationField>

            <FluxNotice
                icon="circle-info"
                is-small
                :message="t('crm.adminRegister.countryManager.hint')"/>
        </FluxFormColumn>
    </FluxPaneBody>

    <FluxPaneFooter>
        <FluxSpacer/>

        <FluxPrimaryButton
            :disabled="invalid"
            icon-before="circle-check"
            :label="t('global.save')"
            @click="validated(register)"/>
    </FluxPaneFooter>
</template>

<script
    lang="ts"
    setup>
    import { UserService } from '@fancee/api';
    import { RegisterCountryManager } from '@fancee/data';
    import { showSnackbar } from '@fancee/flux';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ValidationField, ValidationNotice } from '@/components/form';
    import { useService, useValidationScope } from '@/composable';
    import { DEFAULT_COUNTRY_MANAGER_CLAIMS, SELECT_COUNTRY_OPTIONS } from '@/data';
    import { email, future, minLength, required } from '@/data/validation';
    import { guarded } from '@/util';

    const {t} = useI18n();
    const {registerCountryManager} = useService(UserService);
    const {invalid, validated} = useValidationScope();

    const _registerCountryManager = guarded(registerCountryManager, t('ui.somethingWentWrong.title'), t('crm.adminRegister.countryManager.createFailed'));

    const countryManager = ref(RegisterCountryManager.empty());
    const selectedCountry = ref<string | null>(null);

    async function register(): Promise<void> {
        countryManager.value.claims = DEFAULT_COUNTRY_MANAGER_CLAIMS;

        await _registerCountryManager(unref(countryManager));

        showSnackbar({
            color: 'success',
            icon: 'circle-check',
            message: t('crm.adminRegister.countryManager.createSuccess')
        });

        countryManager.value = RegisterCountryManager.empty();
        selectedCountry.value = null;
    }

    watch(selectedCountry, () => {
        if (!unref(selectedCountry)) {
            return;
        }

        countryManager.value.countryCode = unref(selectedCountry)!;
    });
</script>
