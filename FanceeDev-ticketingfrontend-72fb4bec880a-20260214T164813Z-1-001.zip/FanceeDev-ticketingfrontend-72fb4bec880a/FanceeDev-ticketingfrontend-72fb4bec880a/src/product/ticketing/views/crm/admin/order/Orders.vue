<template>
    <FluxPane>
        <FluxActionBar
            :is-resettable="filter.isResettable"
            @reset="filter.reset()">
            <template #actions-before-search>
                <ClaimCheck claim="admin.order.export">
                    <ToolbarDownload
                        :is-loading="downloadInProgress"
                        @download="downloadOrdersCsv"/>
                </ClaimCheck>
            </template>

            <template #search>
                <ToolbarSearch
                    v-model="filter.searchQuery"
                    :placeholder="t('finance.order.search')"/>
            </template>

            <template #filter>
                <FluxFilter
                    v-model="filter"
                    :resettable="filter.resettable"
                    @reset="(field: string) => filter.reset(field)">
                    <FluxFilterDateRange
                        icon="calendar"
                        :label="t('global.date')"
                        name="dateSpan"/>

                    <FluxSeparator/>

                    <FluxFilterOptions
                        icon="circle-dashed"
                        :label="t('finance.paymentStatus.title')"
                        name="paymentStates"
                        :options="paymentStatesOptions"/>

                    <FluxFilterRange
                        icon="coin"
                        :label="t('finance.order.cost')"
                        name="costCentsRange"
                        :formatter="rangeFormatter"
                        :min="MINIMUM_COSTS_CENTS"
                        :max="MAXIMUM_COSTS_CENTS"
                        :step="10"/>

                    <FluxSeparator/>

                    <FluxFilterOptionsAsync
                        icon="calendar"
                        :label="t('event.singular')"
                        :search-placeholder="t('flux.search')"
                        name="eventIds"
                        :fetch-options="fetchSelect(async (ids: string[]) => await crmGetEventOptions(ids))"
                        :fetch-relevant="fetchSelect(async () => await crmGetEventOptions())"
                        :fetch-search="fetchSelect(async (searchQuery: string) => await crmGetEventOptions(searchQuery))"/>

                    <FluxFilterOptions
                        icon="circle-dashed"
                        :label="t('event.status.title')"
                        name="states"
                        :options="eventStateFilterOptions"/>

                    <FluxSeparator/>

                    <FluxFilterOption
                        icon="comment-sms"
                        :label="t('finance.order.filter.promotionalEmail')"
                        name="optInPromotionalSms"
                        :options="communicationFilterOptions"/>

                    <FluxFilterOption
                        icon="envelope"
                        :label="t('finance.order.filter.promotionalSms')"
                        name="optInPromotionalEmail"
                        :options="communicationFilterOptions"/>

                    <FluxFilterOption
                        icon="comment-sms"
                        :label="t('finance.order.filter.orderSms')"
                        name="receiveViaSms"
                        :options="communicationFilterOptions"/>
                </FluxFilter>
            </template>
        </FluxActionBar>

        <FluxDataTable
            :is-loading="isLoading"
            :data-set="orders"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems"
            is-hoverable>
            <template #header>
                <FluxTableHeader>{{ t('finance.order.table.psp') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('finance.order.table.event') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('finance.order.table.date') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('finance.order.table.amount') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('finance.order.table.paymentStatus') }}</FluxTableHeader>
                <FluxTableHeader/>
            </template>

            <template #id="{row: {pspReference}}">
                <FluxTableCell>{{ pspReference ? pspReference : '&mdash;' }}</FluxTableCell>
            </template>

            <template #eventName="{row: {eventName}}">
                <FluxTableCell>{{ eventName }}</FluxTableCell>
            </template>

            <template #creationDate="{row: {creationDate}}">
                <FluxTableCell>{{ formatDateTime(creationDate) }}</FluxTableCell>
            </template>

            <template #costCents="{row: {costCents, currency}}">
                <FluxTableCell>
                    {{
                        costCents === null || currency === null
                            ? '&mdash;'
                            : asMoney(costCents, currency)
                    }}
                </FluxTableCell>
            </template>

            <template #status="{row: {status}}">
                <FluxTableCell>
                    <FluxBadge
                        dot
                        :label="t(`finance.paymentStatus.${toCamelCase(status)}`)"
                        :color="PaymentAdapter.parsePaymentStatusToClass(status)"/>
                </FluxTableCell>
            </template>

            <template #actions="{row: {id}}">
                <FluxTableCell>
                    <FluxTableActions>
                        <FluxTooltip :content="t('global.view')">
                            <FluxAction
                                icon="eye"
                                @click="setSelectedOrder(id)"/>
                        </FluxTooltip>
                    </FluxTableActions>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>

    <FluxSlideOver
        is-closeable
        @close="selectedOrder = null">
        <FluxPane
            v-if="selectedOrder"
            :is-loading="isSelectedOrderLoading">
            <FluxPaneHeader
                v-if="selectedOrder"
                :title="t('finance.order.single.title')">
                <FluxSecondaryButton
                    icon-before="xmark"
                    @click="selectedOrder = null"/>
            </FluxPaneHeader>

            <OrderView
                :order="selectedOrder"
                :is-loading="isLoading"/>

            <FluxPaneFooter>
                <FluxSecondaryButton
                    :label="t('global.close')"
                    @click="selectedOrder = null"/>
            </FluxPaneFooter>
        </FluxPane>
    </FluxSlideOver>
</template>

<script
    lang="ts"
    setup>
    import { OrderService, SelectService } from '@fancee/api';
    import { EventStatus, Order, OrdersFilter, PaymentStatus, PlatformOrderItem } from '@fancee/data';
    import { FluxFilterOptionItem } from '@fancee/flux';
    import { computed, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ToolbarDownload, ToolbarSearch } from '@/components/filter';
    import { ClaimCheck } from '@/components/ui';
    import { useCurrency, usePagination, useService } from '@/composable';
    import { MAXIMUM_COSTS_CENTS, MINIMUM_COSTS_CENTS } from '@/data';
    import { PaymentAdapter } from '@/data/adapter/payment/PaymentAdapter';
    import { useStore, useUiStore } from '@/data/store';
    import { asMoney, downloadBlob, fetchSelect, formatDateTime, guarded, toCamelCase } from '@/util';
    import OrderView from '@/product/ticketing/views/crm/admin/order/OrderView.vue';

    const {allowedCountries} = useStore(useUiStore());
    const {t} = useI18n();
    const {csvExportPlatform, getCrm, getPlatform} = useService(OrderService);
    const {crmGetEventOptions} = useService(SelectService);
    const currency = useCurrency();

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const _csvExportPlatform = guarded(csvExportPlatform, t('ui.somethingWentWrong.title'), t('finance.order.downloadFailed'));
    const _getCrm = guarded(getCrm, t('ui.somethingWentWrong.title'), t('finance.order.loadingSingleFailed'));
    const _getPlatform = guarded(getPlatform, t('ui.somethingWentWrong.title'), t('finance.order.loadingFailed'));

    const orders = ref<PlatformOrderItem[]>([]);
    const selectedOrder = ref<Order | null>(null);
    const isLoading = ref(false);
    const downloadInProgress = ref(false);
    const isSelectedOrderLoading = ref(false);
    const filter = ref(OrdersFilter.default());

    const eventStateFilterOptions = computed<FluxFilterOptionItem[]>(() => [
        {label: t('event.status.active'), value: EventStatus.Active},
        {label: t('event.status.canceled'), value: EventStatus.Cancelled},
        {label: t('event.status.unpublished'), value: EventStatus.Unpublished},
        {label: t('event.status.soldOut'), value: EventStatus.SoldOut},
        {label: t('event.status.concluded'), value: EventStatus.Concluded}
    ]);

    const paymentStatesOptions = computed<FluxFilterOptionItem[]>(() => [
        {label: t('finance.paymentStatus.authorised'), value: PaymentStatus.Authorised},
        {label: t('finance.paymentStatus.blocked'), value: PaymentStatus.Blocked},
        {label: t('finance.paymentStatus.cancelled'), value: PaymentStatus.Cancelled},
        {label: t('finance.paymentStatus.challengeShopper'), value: PaymentStatus.ChallengeShopper},
        {label: t('finance.paymentStatus.chargeback'), value: PaymentStatus.Chargeback},
        {label: t('finance.paymentStatus.error'), value: PaymentStatus.Error},
        {label: t('finance.paymentStatus.expired'), value: PaymentStatus.Expired},
        {label: t('finance.paymentStatus.identifyShopper'), value: PaymentStatus.IdentifyShopper},
        {label: t('finance.paymentStatus.partiallyAuthorised'), value: PaymentStatus.PartiallyAuthorised},
        {label: t('finance.paymentStatus.partialRefund'), value: PaymentStatus.PartialRefund},
        {label: t('finance.paymentStatus.pending'), value: PaymentStatus.Pending},
        {label: t('finance.paymentStatus.received'), value: PaymentStatus.Received},
        {label: t('finance.paymentStatus.refund'), value: PaymentStatus.Refund},
        {label: t('finance.paymentStatus.pendingRefund'), value: PaymentStatus.PendingRefund},
        {label: t('finance.paymentStatus.refused'), value: PaymentStatus.Refused},
        {label: t('finance.paymentStatus.unknown'), value: PaymentStatus.Unknown}
    ]);

    const communicationFilterOptions = computed<FluxFilterOptionItem[]>(() => [
        {label: t('global.yes'), value: true},
        {label: t('global.no'), value: false}
    ]);

    async function loadOrders(): Promise<void> {
        isLoading.value = true;

        try {
            const {data: {items, totalItems}} = await _getPlatform(unref(pageLength), unref(currentPage), unref(filter), unref(allowedCountries));

            orders.value = items;
            setTotalItems(totalItems);
        } finally {
            isLoading.value = false;
        }
    }

    async function setSelectedOrder(orderId: string): Promise<void> {
        isSelectedOrderLoading.value = true;

        try {
            const {data} = await _getCrm(orderId);
            selectedOrder.value = data;
        } finally {
            isSelectedOrderLoading.value = false;
        }
    }

    async function downloadOrdersCsv(): Promise<void> {
        downloadInProgress.value = true;

        try {
            const {blob, name} = await _csvExportPlatform(unref(filter), unref(allowedCountries));
            downloadBlob(blob, name);
        } finally {
            downloadInProgress.value = false;
        }
    }

    function rangeFormatter(value: number): string {
        let _currency = unref(currency);

        const formatter = new Intl.NumberFormat(navigator.language, {
            currency: _currency.shortCode,
            maximumFractionDigits: _currency.decimals,
            minimumFractionDigits: _currency.decimals,
            style: 'currency'
        });
        return formatter.format(value / 100);
    }

    watch([currentPage, pageLength, filter, allowedCountries], async () => {
        await loadOrders();
    }, {deep: true, immediate: true});
</script>
