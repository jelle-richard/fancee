<template>
    <FluxGrid>
        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="platformGrowthTargetProgression.length === 0">
                <FluxStatistic
                    axis="vertical"
                    icon="briefcase"
                    color="primary"
                    :label="t('crm.home.targetProgression.newOrganizations')"
                    :value="platformGrowthTargetProgression.map(pg => pg.organizations.progress).reduce((a, b) => a + b, 0).toString()"/>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="platformGrowthTargetProgression.length === 0">
                <FluxStatistic
                    axis="vertical"
                    icon="cart-shopping"
                    color="primary"
                    :label="t('crm.home.targetProgression.newUniqueBuyers')"
                    :value="platformGrowthTargetProgression.map(pg => pg.uniqueBuyers.progress).reduce((a, b) => a + b, 0).toString()"/>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="platformGrowthTargetProgression.length === 0">
                <FluxStatistic
                    axis="vertical"
                    icon="speaker"
                    color="primary"
                    :label="t('crm.home.targetProgression.newEvents')"
                    :value="platformGrowthTargetProgression.map(pg => pg.events.progress).reduce((a, b) => a + b, 0).toString()"/>
            </FluxPane>
        </FluxGridColumn>

        <FluxGridColumn
            lg="3"
            sm="6">
            <FluxPane :is-loading="platformGrowthTargetProgression.length === 0">
                <FluxTooltip
                    :content="t('crm.home.targetProgression.placedOrdersTip', {
                        placed: platformGrowthTargetProgression.map(pg => pg.placedOrders.progress).reduce((a, b) => a + b, 0).toString(),
                        fulfilled: platformGrowthTargetProgression.map(pg => pg.fulfilledOrders.progress).reduce((a, b) => a + b, 0).toString(),
                    })">
                    <FluxStatistic
                        axis="vertical"
                        icon="users"
                        color="primary"
                        :label="t('crm.home.targetProgression.placedOrders')"
                        :value="platformGrowthTargetProgression.map(pg => pg.placedOrders.progress).reduce((a, b) => a + b, 0).toString()"/>
                </FluxTooltip>
            </FluxPane>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { PlatformGrowthTargetProgression } from '@fancee/data';
    import { useI18n } from 'vue-i18n';

    export interface Props {
        readonly platformGrowthTargetProgression: PlatformGrowthTargetProgression[];
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>
