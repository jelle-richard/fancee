namespace Fs.MessageBus.Models;

public interface IExternalMessage;