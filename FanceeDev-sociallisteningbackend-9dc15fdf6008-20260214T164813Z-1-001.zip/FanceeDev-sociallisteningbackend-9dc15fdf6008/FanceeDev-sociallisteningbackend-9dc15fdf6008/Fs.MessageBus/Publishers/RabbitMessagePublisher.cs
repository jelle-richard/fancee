using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using Fs.MessageBus.Models;
using Fs.MessageBus.Utils;
using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace Fs.MessageBus.Publishers;

public class RabbitMessagePublisher<TMessage> : RabbitManager, IMessagePublisher<TMessage> where TMessage : IMessage
{
    private const string TicketingMessagesNamespace = "WebApiCore.MessageBus.Messages";
    internal EventingBasicConsumer? Consumer { get; private set; }
    internal BlockingCollection<object?> RpcQueue { get; } = new();

    protected RabbitMessagePublisher(IConnection connection, RabbitOptions options) : base(connection, options)
    {
    }

    public void ConfigureRpc()
    {
        Options.CorrelationId ??= Guid.NewGuid();
        Options.ReplyTo ??= Model.QueueDeclare().QueueName;

        Consumer = new(Model);
        Consumer.Received += HandleRpcMessage;

        Model.BasicConsume(Consumer, Options.ReplyTo, true);
    }

    public void Publish(TMessage message)
    {
        var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(message, message.GetType(), RabbitConfig.JsonOptions));

        var properties = Model.CreateBasicProperties();

        //TODO(SOC-581): FS.MessageBus should be used as a nuget package so that Ticketing and Social can use the same types without having to use a hacky fix like this.
        //Note: The following code changes the type of a rabbit message such as SocialListeningCore.MessageBus.Messages.Mail.AddMailMessage to WebApiCore.MessageBus.Messages.Mail.AddMailMessage
        var type = message.GetType().FullName ?? string.Empty;
        if (message is IExternalMessage)
        {
            var name = type.GetPartOfNamespace();
            type = $"{TicketingMessagesNamespace}.{name}";
        }

        properties.Headers = new Dictionary<string, object>
        {
            { RabbitConfig.Headers.MessageType, type }
        };

        if (Options.AdditionalHeaders?.Count > 0)
        {
            foreach (var header in Options.AdditionalHeaders)
                properties.Headers.Add(header);
        }

        if (Options.CorrelationId != null)
            properties.CorrelationId = Options.CorrelationId.ToString();

        if (Options.ReplyTo != null)
            properties.ReplyTo = Options.ReplyTo;

        Publish(properties, body);
    }

    public object? Call(TMessage message)
    {
        Publish(message);

        return RpcQueue.Take();
    }

    public TReturn? Call<TReturn>(TMessage message) where TReturn : IMessage => (TReturn?)Call(message);

    protected override void CleanUp()
    {
        if (Consumer != null)
            Consumer.Received -= HandleRpcMessage;

        Consumer = null;
    }

    internal void HandleRpcMessage(object? sender, BasicDeliverEventArgs ea)
    {
        if (ea.BasicProperties.CorrelationId != Options.CorrelationId.ToString())
            return;

        var body = Encoding.UTF8.GetString(ea.Body.ToArray());
        var typeToDecode = ea.GetTypeFromReceivedEvent();

        if (typeToDecode == null)
        {
            RpcQueue.Add(body);
            return;
        }

        RpcQueue.Add(JsonSerializer.Deserialize(body, typeToDecode, RabbitConfig.JsonOptions));
    }
}