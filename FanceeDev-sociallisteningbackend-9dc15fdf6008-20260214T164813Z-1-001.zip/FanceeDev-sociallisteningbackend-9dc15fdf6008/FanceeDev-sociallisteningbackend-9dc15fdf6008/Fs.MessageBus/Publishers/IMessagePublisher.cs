using Fs.MessageBus.Models;

namespace Fs.MessageBus.Publishers;

public interface IMessagePublisher<in TMessage> where TMessage : IMessage
{
    /// <summary>
    /// Configures the message to be an RPC call.
    /// </summary>
    public void ConfigureRpc();

    /// <summary>
    /// Publishes a message to the queue.
    /// </summary>
    /// <param name="message"></param>
    public void Publish(TMessage message);

    /// <summary>
    /// Publishes a message to the queue and waits for a response message.
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public object? Call(TMessage message);

    /// <summary>
    /// Publishes a message to the queue and returns the response as a <see cref="IMessage"/>.
    /// </summary>
    /// <param name="message"></param>
    /// <typeparam name="TReturn"></typeparam>
    /// <returns></returns>
    public TReturn? Call<TReturn>(TMessage message) where TReturn : IMessage;
}