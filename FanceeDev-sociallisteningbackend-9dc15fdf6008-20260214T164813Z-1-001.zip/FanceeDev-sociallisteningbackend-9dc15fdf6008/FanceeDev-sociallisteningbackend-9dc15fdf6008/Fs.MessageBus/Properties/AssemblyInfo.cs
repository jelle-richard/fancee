﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Fs.MessageBus.Tests")]