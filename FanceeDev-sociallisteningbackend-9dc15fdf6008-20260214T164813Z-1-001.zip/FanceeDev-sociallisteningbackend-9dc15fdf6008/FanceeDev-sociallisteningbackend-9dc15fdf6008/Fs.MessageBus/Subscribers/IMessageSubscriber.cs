using Fs.MessageBus.Models;

namespace Fs.MessageBus.Subscribers;

public interface IMessageSubscriber<out TMessage> where TMessage : IMessage
{
    /// <summary>
    /// Binds a callback for when a message is received.
    /// </summary>
    /// <param name="callback"></param>
    public void Bind(Func<TMessage?, Task> callback);

    /// <summary>
    /// Binds a callback for when a message is received with a return value.
    /// </summary>
    /// <param name="callback"></param>
    public void Bind(Func<TMessage?, Task<IMessage>> callback);

    /// <summary>
    /// Unbinds all callbacks.
    /// </summary>
    public void Unbind();
}