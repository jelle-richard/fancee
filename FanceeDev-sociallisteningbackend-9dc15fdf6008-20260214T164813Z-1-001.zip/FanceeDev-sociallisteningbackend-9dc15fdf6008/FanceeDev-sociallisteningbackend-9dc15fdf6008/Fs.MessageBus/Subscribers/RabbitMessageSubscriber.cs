using System.Text;
using System.Text.Json;
using Fs.MessageBus.Models;
using Fs.MessageBus.Utils;
using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace Fs.MessageBus.Subscribers;

public class RabbitMessageSubscriber<TMessage> : RabbitManager, IMessageSubscriber<TMessage> where TMessage : IMessage
{
    private const string TicketingMessagesNamespace = "WebApiCore.MessageBus.Messages";
    public Func<TMessage?, Task>? Callback { get; private set; }
    public Func<TMessage?, Task<IMessage>>? RpcCallback { get; private set; }

    private EventingBasicConsumer? _consumer;

    protected RabbitMessageSubscriber(IConnection connection, RabbitOptions options) : base(connection, options)
    {
        if (options.QosOptions != null)
            Model.BasicQos(options.QosOptions.PrefetchSize, options.QosOptions.PrefetchCount, options.QosOptions.Global);

        Model.QueueBind(options.QueueOptions.Name, options.Exchange, options.RoutingKey, null);
    }

    public void Bind(Func<TMessage?, Task> callback)
    {
        Callback = callback;
        Bind();
    }

    public void Bind(Func<TMessage?, Task<IMessage>> callback)
    {
        RpcCallback = callback;
        Bind();
    }

    public void Unbind()
    {
        Callback = RpcCallback = null;

        if (_consumer != null)
            _consumer.Received -= HandleMessageAsync;
    }

    protected override void CleanUp()
    {
        Unbind();

        _consumer = null;
    }

    private void Bind()
    {
        if (_consumer != null)
            return;

        _consumer = new(Model);
        _consumer.Received += HandleMessageAsync;

        Model.BasicConsume(Options.QueueOptions.Name, Options.AutoAcknowledge, _consumer);
    }

    private void Reply(BasicDeliverEventArgs ea, IMessage? reply)
    {
        var props = ea.BasicProperties;

        if (string.IsNullOrEmpty(props.CorrelationId) || string.IsNullOrEmpty(props.ReplyTo))
            return;

        var replyProps = Model.CreateBasicProperties();
        replyProps.CorrelationId = props.CorrelationId;

        var responseStr = "ok";

        if (reply != null)
        {
            var type = reply.GetType().FullName!;
            if (reply is IExternalMessage)
            {
                var name = type.GetPartOfNamespace();
                type = $"{TicketingMessagesNamespace}.{name}";
            }

            replyProps.Headers = new Dictionary<string, object> { { RabbitConfig.Headers.MessageType, type } };
            responseStr = JsonSerializer.Serialize(reply, reply.GetType(), RabbitConfig.JsonOptions);
        }

        var responseBytes = Encoding.UTF8.GetBytes(responseStr);

        try
        {
            Model.BasicPublish(string.Empty, props.ReplyTo, replyProps, responseBytes);
            Model.BasicAck(ea.DeliveryTag, false);
        }
        catch (Exception)
        {
            // Exception can be thrown when the 'sender' is no longer reachable.
            // This usually happens when the 'sender' has crashed.
        }
    }

    internal async void HandleMessageAsync(object? sender, BasicDeliverEventArgs ea)
    {
        var type = ea.GetTypeFromReceivedEvent();

        if (type != typeof(TMessage) && !typeof(TMessage).IsAssignableFrom(type))
            return;

        var message = Encoding.UTF8.GetString(ea.Body.Span);
        var obj = (TMessage?)JsonSerializer.Deserialize(message, type, RabbitConfig.JsonOptions);

        IMessage? callbackResult = null;

        if (Callback != null)
            await Callback.Invoke(obj);

        if (RpcCallback != null)
            callbackResult = await RpcCallback.Invoke(obj);

        Reply(ea, callbackResult);
    }
}