using System.Net;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Fs.MessageBus.Utils.Converter;

public class IpAddressConverter : JsonConverter<IPAddress>
{
    public override bool CanConvert(Type typeToConvert) =>
        typeof(IPAddress).IsAssignableFrom(typeToConvert);

    public override IPAddress? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        return IPAddress.TryParse(reader.GetString(), out var ip)
            ? ip
            : null;
    }

    public override void Write(Utf8JsonWriter writer, IPAddress? value, JsonSerializerOptions options)
    {
        writer.WriteStringValue(value?.ToString());
    }
}