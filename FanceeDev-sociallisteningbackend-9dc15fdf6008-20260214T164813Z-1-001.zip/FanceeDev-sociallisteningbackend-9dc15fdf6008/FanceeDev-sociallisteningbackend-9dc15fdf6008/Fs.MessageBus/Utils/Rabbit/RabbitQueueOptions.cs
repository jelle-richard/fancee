namespace Fs.MessageBus.Utils.Rabbit;

public class RabbitQueueOptions : ICloneable
{
    public string Name { get; set; } = default!;
    public bool Durable { get; set; } = true;
    public bool Exclusive { get; set; } = false;
    public bool AutoDelete { get; set; } = false;
    public IDictionary<string, object>? Arguments { get; set; } = null;
    
    public object Clone()
    {
        return new RabbitQueueOptions
        {
            Name = Name,
            Durable = Durable,
            Exclusive = Exclusive,
            AutoDelete = AutoDelete,
            Arguments = Arguments?.Clone()
        };
    }
}