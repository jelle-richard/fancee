using System.Text.Json;
using Fs.MessageBus.Utils.Converter;

namespace Fs.MessageBus.Utils.Rabbit;

public static class RabbitConfig
{
    public static readonly JsonSerializerOptions JsonOptions = new()
    {
        Converters = { new IpAddressConverter() }
    };

    public static class Exchanges
    {
        public const string Default = "DefaultExchange";
    }

    public static class Queues
    {
        public const string Mail = "MailQueue";
        public const string AddMail = "AddMailQueue";
        public const string Currency = "CurrencyQueue";
        public const string GeneratePdf = "GeneratePdfQueue";
        public const string DeleteTicketPdf = "DeleteTicketPdfQueue";
        public const string DeleteOrderReceiptPdf = "DeleteOrderReceiptPdfQueue";
        public const string IssueProducts = "IssueProductsQueue";
        public const string CreateReceipt = "CreateReceiptQueue";
        public const string CreateInvoices = "CreateInvoicesQueue";
        public const string ConcludeEvents = "ConcludeEventsQueue";
        public const string EventCanceled = "EventCanceledQueue";
        public const string ValidPinTerminal = "ValidPinTerminalQueue";
        public const string RefreshExactToken = "RefreshExactTokenQueue";
        public const string AddAdditionalCost = "AddAdditionalCostQueue";
        public const string AddAccountingInvoice = "AddAccountingInvoiceQueue";
        public const string PinTerminalTransaction = "PinTerminalTransactionQueue";
        public const string UnlockReservedProducts = "UnlockReservedProductsQueue";
        public const string CleanShopViews = "CleanShopViewsQueue";
        public const string RemoveSentMails = "RemoveSentMailsQueue";
        public const string RequestTicketingData = "DataRequestQueue";
    }

    public static class Headers
    {
        public const string TimeToLive = "x-message-ttl";
        public const string MessageType = "message-type";
    }

    public static class RoutingKeys
    {
        public const string SendMailQueue = "cron.send-mail-queue";
        public const string AddMail = "mail.send";
        public const string UpdateCurrencyExchangeRates = "currency.update-exchange-rates";
        public const string GeneratePdf = "pdf.generate";
        public const string IssueProducts = "products.issue";
        public const string UnlockReservedProducts = "products.unlock";
        public const string CreateReceipt = "receipt.create";
        public const string CreateInvoices = "invoices.create";
        public const string RefreshExactToken = "token.refresh.exact";
        public const string AddAccountingInvoice = "accounting.invoice.add";
        public const string ValidPinTerminal = "pin.valid-terminal";
        public const string StartPinTerminalTransaction = "pin.start-transaction";
        public const string ConcludeEvents = "events.conclude";
        public const string AddAdditionalCost = "invoices.additional-cost.create";
        public const string DeleteTicketPdfs = "pdf.ticket.delete";
        public const string DeleteOrderReceiptPdfs = "pdf.order.receipt.delete";
        public const string CleanShopViews = "shop.views.clean";
        public const string RemoveSentMails = "remove.sent.mails";
        public const string EventCanceled = "event.canceled";
        public const string RequestTicketingData = "data.request";
    }
}