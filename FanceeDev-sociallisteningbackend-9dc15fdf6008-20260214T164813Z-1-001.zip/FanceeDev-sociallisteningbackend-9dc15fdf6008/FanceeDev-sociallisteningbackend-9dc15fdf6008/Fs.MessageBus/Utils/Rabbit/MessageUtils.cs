using System.Text;
using Fs.MessageBus.Models;
using RabbitMQ.Client.Events;

namespace Fs.MessageBus.Utils.Rabbit;

internal static class MessageUtils
{
    private static Type? GetTypeFromAssembly(string typeName)
    {
        return AppDomain.CurrentDomain
            .GetAssemblies()
            .Select(assembly => assembly.GetType(typeName))
            .FirstOrDefault(type => type != null);
    }

    internal static bool IsRabbitMessage(this Type type) => type.GetInterfaces().Contains(typeof(IMessage));

    internal static Type? GetTypeFromReceivedEvent(this BasicDeliverEventArgs args)
    {
        var typeHeader = args.BasicProperties?.Headers?.FirstOrDefault(h => h.Key == RabbitConfig.Headers.MessageType);

        if (typeHeader is not { Value: byte[] typeValue })
            return null;

        var typeName = Encoding.UTF8.GetString(typeValue);
        var realType = Type.GetType(typeName) ?? GetTypeFromAssembly(typeName);

        return realType?.IsRabbitMessage() ?? false
            ? realType
            : null;
    }
}