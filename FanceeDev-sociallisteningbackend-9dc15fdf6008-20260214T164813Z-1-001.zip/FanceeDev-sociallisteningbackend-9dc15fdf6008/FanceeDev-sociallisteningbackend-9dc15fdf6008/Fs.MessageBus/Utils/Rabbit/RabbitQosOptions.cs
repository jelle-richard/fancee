namespace Fs.MessageBus.Utils.Rabbit;

public class RabbitQosOptions : ICloneable
{
    public uint PrefetchSize { get; set; }
    public ushort PrefetchCount { get; set; }
    public bool Global { get; set; }
    
    public object Clone()
    {
        return new RabbitQosOptions
        {
            PrefetchSize = PrefetchSize,
            PrefetchCount = PrefetchCount,
            Global = Global
        };
    }
}