namespace Fs.MessageBus.Utils.Rabbit;

public class RabbitOptions : ICloneable
{
    public string Exchange { get; set; } = default!;
    public string RoutingKey { get; set; } = default!;
    public string ExchangeType { get; set; } = RabbitMQ.Client.ExchangeType.Direct;
    public RabbitQueueOptions QueueOptions { get; set; } = default!;
    public RabbitQosOptions? QosOptions { get; set; }

    /// <summary>
    /// If a Publisher message is configured as an RPC call, this should be set to for false for the Subscriber.
    /// Otherwise exceptions will be thrown that the delivery tag cannot be found.
    /// </summary>
    public bool AutoAcknowledge { get; set; } = true;

    public IDictionary<string, object> Arguments { get; set; } = new Dictionary<string, object>
    {
        { RabbitConfig.Headers.TimeToLive, 30000 }
    };

    public IDictionary<string, object>? AdditionalHeaders { get; set; }
    public Guid? CorrelationId { get; set; } = null;
    public string? ReplyTo { get; set; }
    
    public object Clone()
    {
        return new RabbitOptions
        {
            Exchange = Exchange,
            RoutingKey = RoutingKey,
            ExchangeType = ExchangeType,
            AutoAcknowledge = AutoAcknowledge,
            Arguments = Arguments.Clone(),
            QueueOptions = (RabbitQueueOptions)QueueOptions.Clone(),
            QosOptions = (RabbitQosOptions?)QosOptions?.Clone(),
            AdditionalHeaders = AdditionalHeaders?.Clone(),
            CorrelationId = CorrelationId == null ? null : Guid.Parse(CorrelationId.ToString()!),
            ReplyTo = ReplyTo
        };
    }
}