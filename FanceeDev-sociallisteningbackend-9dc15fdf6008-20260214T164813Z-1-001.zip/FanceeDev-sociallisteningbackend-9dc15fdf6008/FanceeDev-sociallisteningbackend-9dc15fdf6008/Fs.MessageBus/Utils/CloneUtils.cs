namespace Fs.MessageBus.Utils;

internal static class CloneUtils
{
    /// <summary>
    /// Clones a dictionary.
    /// </summary>
    /// <param name="dictionary"></param>
    /// <typeparam name="TKey"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <returns></returns>
    internal static IDictionary<TKey, TValue> Clone<TKey, TValue>(this IDictionary<TKey, TValue> dictionary) where TKey : notnull
    {
        var dict = new Dictionary<TKey, TValue>();

        foreach (var (key, value) in dictionary)
            dict.Add(key, value);

        return dict;
    }
}