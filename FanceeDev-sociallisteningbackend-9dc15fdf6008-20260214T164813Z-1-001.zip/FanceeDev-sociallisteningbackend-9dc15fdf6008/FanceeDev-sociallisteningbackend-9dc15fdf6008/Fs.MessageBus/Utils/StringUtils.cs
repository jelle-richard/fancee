using Fs.MessageBus.Exceptions;

namespace Fs.MessageBus.Utils;

public static class StringUtils
{
    /// <summary>
    /// Retrieves the last 3 parts of a given namespace.
    /// Explicitly used to convert SociallisteningCore.path.to.namespace.file to WebApiCore.path.to.namespace.file.
    /// Since the Rabbit namespace structure for WebApiCore and SociallisteningCore is identical, this should not give any problems.
    /// Use of this method on any other string might result in unexpected results.
    /// </summary>
    /// <param name="fullNamespace"></param>
    /// <returns></returns>
    /// <exception cref="NamespaceToShortForRabbitException"></exception>
    public static string GetPartOfNamespace(this string fullNamespace)
    {
        var parts = fullNamespace.Split('.');

        if (parts.Length < 3)
            throw new NamespaceToShortForRabbitException(fullNamespace);

        var desiredPart = string.Join(".", parts, 3, parts.Length - 3);
        return desiredPart;
    }
}