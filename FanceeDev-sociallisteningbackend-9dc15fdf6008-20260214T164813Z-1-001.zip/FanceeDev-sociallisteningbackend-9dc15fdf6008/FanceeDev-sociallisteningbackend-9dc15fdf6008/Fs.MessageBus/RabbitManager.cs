using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;

namespace Fs.MessageBus;

public abstract class RabbitManager : IDisposable
{
    public RabbitOptions Options { get; }

    internal bool Disposed { get; private set; }
    internal readonly IModel Model;

    protected RabbitManager(IConnection connection, RabbitOptions options)
    {
        Options = (RabbitOptions)options.Clone();

        Model = connection.CreateModel();
        Model.ExchangeDeclare(options.Exchange, options.ExchangeType, arguments: options.Arguments);
        Model.QueueDeclare(options.QueueOptions.Name, options.QueueOptions.Durable, options.QueueOptions.Exclusive, options.QueueOptions.AutoDelete, options.QueueOptions.Arguments);
    }

    public void Dispose()
    {
        Dispose(true);

        GC.SuppressFinalize(this);
    }

    protected void Publish(IBasicProperties properties, byte[] body)
    {
        Model.BasicPublish(Options.Exchange, Options.RoutingKey, properties, body);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (Disposed)
            return;

        if (disposing)
        {
            CleanUp();

            Model.Close();
            Model.Dispose();
        }

        Disposed = true;
    }

    /// <summary>
    /// Cleans up any open connections and disposes any unused variables.
    /// </summary>
    protected abstract void CleanUp();
}