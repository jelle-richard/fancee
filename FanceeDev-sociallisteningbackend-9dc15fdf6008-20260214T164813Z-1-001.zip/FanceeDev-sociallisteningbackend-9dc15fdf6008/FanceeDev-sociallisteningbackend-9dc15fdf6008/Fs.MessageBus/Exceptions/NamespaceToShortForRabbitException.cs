namespace Fs.MessageBus.Exceptions;

public class NamespaceToShortForRabbitException(string? message) : Exception(message);