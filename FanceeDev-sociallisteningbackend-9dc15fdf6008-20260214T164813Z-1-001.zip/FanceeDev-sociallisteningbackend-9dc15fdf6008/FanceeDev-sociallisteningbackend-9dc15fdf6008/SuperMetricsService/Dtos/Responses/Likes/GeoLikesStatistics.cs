using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Likes;

[BsonIgnoreExtraElements]
public class GeoLikesStatistics
{
    [BsonRepresentation(BsonType.String)]
    public CountryCode CountryCode { get; set; }

    [BsonRepresentation(BsonType.Int32, AllowTruncation = true)]
    public int LikesAmount { get; set; }

    [BsonRepresentation(BsonType.Int32, AllowTruncation = true)]
    public int LikesGained { get; set; }

    [BsonRepresentation(BsonType.Int32, AllowTruncation = true)]
    public int? PreviousLikesGained { get; set; }

    public float? ImprovementPercentage { get; set; }

    public GeoLikesStatistics()
    {
    }

    public GeoLikesStatistics(CountryCode countryCode, int total, int difference)
    {
        CountryCode = countryCode;
        LikesAmount = total;
        LikesGained = difference;
    }
}