using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Likes;

public class LikesHistory
{
    public DateTime Date { get; set; }

    [BsonRepresentation(BsonType.Int32, AllowTruncation = true)]
    public int LikesAmount { get; set; }
}