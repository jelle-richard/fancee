﻿using SuperMetricsService.Enums;

namespace SuperMetricsService.Dtos.Responses.Likes;

public class EmotionLikes
{
    public Emotion Emotion { get; set; }
    public decimal Amount { get; set; }
}