using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Likes;

[BsonIgnoreExtraElements]
public class GenderLikesStatistics
{
    public string? Gender { get; set; }

    [BsonRepresentation(BsonType.Int32, AllowTruncation = true)]
    public int? LikesAmount { get; set; }
}