﻿using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Likes;

[BsonIgnoreExtraElements]
public class AgeLikesStatistics
{
    public string? Age { get; set; }
    public int? LikesAmount { get; set; }
}