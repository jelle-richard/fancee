﻿using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Posts;

[BsonIgnoreExtraElements]
public class AvgPerDayOfWeek
{
    public DayOfWeek DayOfWeek { get; set; }
    public int? Average { get; set; }
}