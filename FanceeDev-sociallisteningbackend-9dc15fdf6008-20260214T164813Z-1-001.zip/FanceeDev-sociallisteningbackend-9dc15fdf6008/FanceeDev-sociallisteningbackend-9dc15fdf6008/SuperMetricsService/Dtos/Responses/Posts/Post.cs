using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Posts;

[BsonIgnoreExtraElements]
public class Post
{
    public string? Thumbnail { get; set; }
    public string? Message { get; set; }
    public int? TotalReach { get; set; }
    public int? TotalLikes { get; set; }
    public int? TotalReactions { get; set; }
    public DateTime Date { get; set; }
    public string? Time { get; set; }
}