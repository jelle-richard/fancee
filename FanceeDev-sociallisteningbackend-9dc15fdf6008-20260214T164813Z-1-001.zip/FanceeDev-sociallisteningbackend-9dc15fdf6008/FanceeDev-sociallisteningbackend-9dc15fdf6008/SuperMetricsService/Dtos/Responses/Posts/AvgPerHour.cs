﻿using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Posts;

[BsonIgnoreExtraElements]
public class AvgPerHour
{
    public string? Hour { get; set; }
    public int? Average { get; set; }
}