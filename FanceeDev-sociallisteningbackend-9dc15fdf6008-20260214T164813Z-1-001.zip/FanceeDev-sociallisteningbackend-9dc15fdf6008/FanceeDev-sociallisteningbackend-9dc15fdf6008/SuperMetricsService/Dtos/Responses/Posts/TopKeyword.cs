﻿using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.Posts;

[BsonIgnoreExtraElements]
public class TopKeyword(string word, int amount)
{
    public string Word { get; set; } = word;
    public int Amount { get; set; } = amount;

    public TopKeyword() : this(string.Empty, 0)
    {
    }
}