namespace SuperMetricsService.Dtos.Responses.Sum;

public class SumResponse<TSumGroup>(TSumGroup first, TSumGroup last, IEnumerable<TSumGroup> items)
{
    public TSumGroup First { get; set; } = first;
    public TSumGroup Last { get; set; } = last;
    public IEnumerable<TSumGroup> Items { get; set; } = items;
}