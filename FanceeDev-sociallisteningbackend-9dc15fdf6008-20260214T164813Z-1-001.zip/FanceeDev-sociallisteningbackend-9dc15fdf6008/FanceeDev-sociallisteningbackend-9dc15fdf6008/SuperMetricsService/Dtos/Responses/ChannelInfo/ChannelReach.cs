﻿using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.ChannelInfo;

[BsonIgnoreExtraElements]
public class ChannelReach
{
    public string? Name { get; set; }

    public string? Description { get; set; }

    public int? TotalFollowers { get; set; }

    public int? IncreasedFollowers { get; set; }

    public decimal? PercentIncreaseFollowers { get; set; }

    public decimal? Reach { get; set; }

    public int? ActiveFollowers { get; set; }

    public decimal? AverageAge { get; set; }

    public decimal? PercentMen { get; set; }

    public decimal? PercentWomen { get; set; }

    public int? Shares { get; set; }

    public int? Likes { get; set; }

    public int? Comments { get; set; }

    public int? ClicksOnPage { get; set; }

    public static ChannelReach operator +(ChannelReach a, ChannelReach b)
    {
        a.Name ??= b.Name;
        a.Description ??= b.Description;
        a.TotalFollowers ??= b.TotalFollowers;
        a.ActiveFollowers ??= b.ActiveFollowers;
        a.IncreasedFollowers ??= b.IncreasedFollowers;
        a.PercentIncreaseFollowers ??= b.PercentIncreaseFollowers;
        a.Reach ??= b.Reach;
        a.AverageAge ??= b.AverageAge;
        a.PercentMen ??= b.PercentMen;
        a.PercentWomen ??= b.PercentWomen;
        a.Shares ??= b.Shares;
        a.Likes ??= b.Likes;
        a.Shares ??= b.Shares;
        a.Comments ??= b.Comments;
        a.ClicksOnPage ??= b.ClicksOnPage;

        return a;
    }
}