﻿using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Responses.ChannelInfo;

[BsonIgnoreExtraElements]
public class ChannelGrowth
{
    public DateTime Date { get; set; }

    public int Followers { get; set; }

    public int Lost { get; set; }

    public int Gained { get; set; }
}