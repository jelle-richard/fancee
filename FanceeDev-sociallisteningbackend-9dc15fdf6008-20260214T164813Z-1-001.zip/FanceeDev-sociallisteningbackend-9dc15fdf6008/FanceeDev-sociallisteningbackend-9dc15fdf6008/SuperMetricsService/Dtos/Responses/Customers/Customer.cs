using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Dtos.Responses.Customers;

public class Customer
{
    public string? CustomerId { get; set; }

    public string? OrderId { get; set; }

    public string? AdressId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? UserName { get; set; }

    public Gender Gender { get; set; }

    public string? PhoneNumber { get; set; }

    public string? Email { get; set; }

    public ChannelType Channel { get; set; }

    public int? Age { get; set; }

    public Status Status { get; set; }

    public string? EventName { get; set; }

    public string? EventLink { get; set; }

    public DateTime? EventStart { get; set; }
}