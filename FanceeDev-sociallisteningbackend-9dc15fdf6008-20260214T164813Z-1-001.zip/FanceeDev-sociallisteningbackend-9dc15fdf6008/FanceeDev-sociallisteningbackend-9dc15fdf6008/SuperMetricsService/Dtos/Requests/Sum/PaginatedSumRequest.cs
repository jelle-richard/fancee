using SuperMetricsService.Enums;

namespace SuperMetricsService.Dtos.Requests.Sum;

public class PaginatedSumRequest<TFieldOption>(SumType sumType, string[] channelIds, DateTime start, DateTime end, TFieldOption orderBy, bool ascending, int skip = 0, int limit = 10)
    : SumRequest(sumType, channelIds, start, end)
    where TFieldOption : Enum
{
    public TFieldOption OrderBy { get; set; } = orderBy;
    public bool OrderByAscending { get; set; } = ascending;
    public int Skip { get; set; } = skip;
    public int Limit { get; set; } = limit;
}