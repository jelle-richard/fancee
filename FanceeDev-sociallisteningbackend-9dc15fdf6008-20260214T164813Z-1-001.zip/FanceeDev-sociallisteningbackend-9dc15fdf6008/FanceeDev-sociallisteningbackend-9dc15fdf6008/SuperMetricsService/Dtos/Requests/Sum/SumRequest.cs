using System.ComponentModel.DataAnnotations;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Dtos.Requests.Sum;

public class SumRequest(SumType sumType, string[] channelIds, DateTime start, DateTime end)
    : IValidatableObject
{
    public SumType Type { get; set; } = sumType;
    public string[] ChannelIds { get; set; } = channelIds;
    public DateTime StartDate { get; set; } = start;
    public DateTime EndDate { get; set; } = end;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        StartDate = new(StartDate.Year, StartDate.Month, StartDate.Day);
        EndDate = new DateTime(EndDate.Year, EndDate.Month, EndDate.Day).AddDays(1).AddTicks(-1);

        yield return ValidationResult.Success!;
    }
}