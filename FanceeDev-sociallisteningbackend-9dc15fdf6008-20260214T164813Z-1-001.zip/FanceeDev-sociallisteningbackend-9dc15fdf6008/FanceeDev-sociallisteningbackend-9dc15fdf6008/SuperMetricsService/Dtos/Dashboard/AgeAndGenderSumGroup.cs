using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class AgeAndGenderSumGroup(string date, IEnumerable<AgeAndGenderSumItem> values) : SumGroup<AgeAndGenderSumItem>(date, values);