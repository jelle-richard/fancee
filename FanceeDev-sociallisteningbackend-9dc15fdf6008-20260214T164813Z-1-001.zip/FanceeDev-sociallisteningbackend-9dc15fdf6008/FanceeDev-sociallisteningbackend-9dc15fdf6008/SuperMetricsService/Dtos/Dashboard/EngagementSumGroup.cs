using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class EngagementSumGroup : SumGroup<EngagementSumItem>
{
    public int TotalShares { get; set; }
    public int TotalComments { get; set; }
    public int TotalLikes { get; set; }

    public EngagementSumGroup(string date, IEnumerable<EngagementSumItem> values) : base(date, values) => CalculateTotals();

    private void CalculateTotals()
    {
        TotalShares = Values.Sum(v => v.Shares);
        TotalComments = Values.Sum(v => v.Comments);
        TotalLikes = Values.Sum(v => v.Likes);
    }
}