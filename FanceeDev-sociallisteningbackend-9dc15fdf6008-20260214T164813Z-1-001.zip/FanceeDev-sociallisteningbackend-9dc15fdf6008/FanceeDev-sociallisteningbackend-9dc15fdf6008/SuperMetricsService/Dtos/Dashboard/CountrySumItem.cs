using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public sealed class CountrySumItem : SumItem
{
    [BsonRepresentation(BsonType.String)]
    public CountryCode? CountryCode { get; set; }
    public string? ChannelId { get; set; }
    public int? Followers { get; set; }
    public decimal? Percentage { get; set; }
    public decimal? GainedPercentage { get; set; }
}