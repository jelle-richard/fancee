using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class EmotionsSumItem : SumItem
{
    public int Wow { get; set; } = 0;
    public int Thankful { get; set; } = 0;
    public int Sorry { get; set; } = 0;
    public int Pride { get; set; } = 0;
    public int Love { get; set; } = 0;
    public int Haha { get; set; } = 0;
    public int Anger { get; set; } = 0;
    public int Like { get; set; } = 0;
}