using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class EmotionsSumGroup : SumGroup<EmotionsSumItem>
{
    public int TotalLike { get; set; }
    public int TotalAnger { get; set; }
    public int TotalHaha { get; set; }
    public int TotalWow { get; set; }
    public int TotalSorry { get; set; }
    public int TotalLove { get; set; }
    public int TotalThankful { get; set; }
    public int TotalPride { get; set; }

    public EmotionsSumGroup(string date, IEnumerable<EmotionsSumItem> values) : base(date, values) => CalculateTotals();

    private void CalculateTotals()
    {
        TotalLike = Values.Sum(v => v.Like);
        TotalAnger = Values.Sum(v => v.Anger);
        TotalThankful = Values.Sum(v => v.Thankful);
        TotalPride = Values.Sum(v => v.Pride);
        TotalHaha = Values.Sum(v => v.Haha);
        TotalWow = Values.Sum(v => v.Wow);
        TotalSorry = Values.Sum(v => v.Sorry);
        TotalLove = Values.Sum(v => v.Love);
    }
}