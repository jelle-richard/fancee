using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class GainedAndLostSumItem : SumItem
{
    public int? Value { get; set; }

    public int Gained { get; set; } = 0;

    public int Lost { get; set; } = 0;
}