using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public sealed class AgeAndGenderSumItem : SumItem
{
    public string? Age { get; set; }
    public string? Gender { get; set; }
    public int? Followers { get; set; }
    public decimal? Percentage { get; set; }
}