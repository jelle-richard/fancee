using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class CommentsSumGroup : SumGroup<CommentsSumItem>
{
    public int AverageComments { get; set; }
    public int AverageReach { get; set; }
    public int AverageLikes { get; set; }

    public CommentsSumGroup(string date, IEnumerable<CommentsSumItem> values) : base(date, values) => CalculateTotals();

    private void CalculateTotals()
    {
        if (Count <= 0)
            return;
        AverageComments = Values.Sum(item => item.Comments) / Count;
        AverageReach = Values.Sum(item => item.Reach) / Count;
        AverageLikes = Values.Sum(item => item.Likes) / Count;
    }
}