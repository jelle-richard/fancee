using FanceeAnalyticsData.Models.Analytics;

namespace SuperMetricsService.Dtos.Dashboard;

public class ChartSumItem<TSumItem> where TSumItem : new()
{
    public string? ChannelId { get; set; }
    public string? SubscriptionId { get; set; }
    public SubscriptionType? SubscriptionType { get; set; }
    public TSumItem? StartOfPreviousPeriod { get; set; }
    public IEnumerable<TSumItem>? Values { get; set; }
    public string? ChannelName { get; set; }
}