using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class CommentsSumItem : SumItem
{
    public string Hour { get; set; } = string.Empty;
    public string DayOfWeek { get; set; } = string.Empty;
    public int Comments { get; set; } = 0;
    public int Reach { get; set; } = 0;
    public int Likes { get; set; } = 0;
}