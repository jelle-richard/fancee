using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public sealed class CampaignAgeAndGenderSumItem : SumItem
{
    public string? CampaignId { get; set; }
    public string? Age { get; set; }
    public string? Gender { get; set; }
    public int? Clicks { get; set; }
    public decimal? Cost { get; set; }
    public int? Views { get; set; }
    public int? Impressions { get; set; }
    public decimal? Conversions { get; set; }
}