using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class PostsSumItem : SumItem
{
    public string? Name { get; set; }
    public string? Time { get; set; }
    public string? Url { get; set; }
    public string? Thumbnail { get; set; }
    public string? Message { get; set; }
    public string? PostType { get; set; }
    public int? Likes { get; set; }
    public int? Comments { get; set; }
    public int? Shares { get; set; }
    public int? Clicks { get; set; }
    public int? Views { get; set; }
    public bool? Paid { get; set; }
}