using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson.Serialization.Attributes;

namespace SuperMetricsService.Dtos.Dashboard;

[BsonIgnoreExtraElements]
public class CampaignsSumItem : SumItem
{
    public string? ChannelId { get; set; }

    public DateTime StartDate { get; set; }

    public string? CampaignId { get; set; }

    public string? Name { get; set; }

    public string? Status { get; set; }

    public decimal? Cost { get; set; }

    public decimal? Budget { get; set; }

    public int? Impressions { get; set; }

    public int? Clicks { get; set; }

    public decimal? CPC { get; set; }

    public decimal? CTR { get; set; }

    public decimal? Conversion { get; set; }
}