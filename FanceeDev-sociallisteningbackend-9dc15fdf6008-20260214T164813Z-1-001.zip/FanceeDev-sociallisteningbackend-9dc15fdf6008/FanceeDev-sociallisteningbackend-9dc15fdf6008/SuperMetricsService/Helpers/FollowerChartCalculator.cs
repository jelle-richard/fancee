using SuperMetricsService.Dtos.Dashboard;

namespace SuperMetricsService.Helpers;

public static class FollowerChartCalculator
{
    /// <summary>
    /// Calculates the missing values in the ChartSumItems.
    /// If concurrently no values are found use the previously found or next value.
    /// If a value is not found between values that are available, calculate the average of these 2 values.
    /// </summary>
    /// <param name="chartSumItem"></param>
    public static void CalculateAndPredictMissingValues(ChartSumItem<GainedAndLostSumItem> chartSumItem)
    {
        var values = chartSumItem.Values!.ToList();

        for (var i = 0; i < values.Count; i++)
        {
            if (values[i].Value != 0 && values[i].Value != null)
                continue;
            
            var average = CalculateAverage(i, values);

            values[i].Value = average != -1 ? average : GetFirstNonNullValue(i, values);
            values[i].IsPrediction = true;
        }
    }

    private static int GetFirstNonNullValue(int index, List<GainedAndLostSumItem> values)
    {
        var nextIndex = index + 1;
        var previousIndex = index - 1;

        while (nextIndex < values.Count || previousIndex >= 0)
        {
            if (nextIndex < values.Count && values[nextIndex].Value != null)
                return values[nextIndex].Value!.Value;

            if (previousIndex >= 0 && values[previousIndex].Value != null)
                return values[previousIndex].Value!.Value;

            nextIndex++;
            previousIndex--;
        }

        return 0;
    }

    private static int CalculateAverage(int index, List<GainedAndLostSumItem> values)
    {
        var previousIndex = Math.Max(0, index - 1);
        var nextIndex = Math.Min(values.Count - 1, index + 1);

        var previousValue = values[previousIndex].Value;
        var nextValue = values[nextIndex].Value;
        
        if (previousValue == null)
            return nextValue ?? -1;
        
        
        if (nextValue == null)
            return previousValue.Value;
        
        return ((int)previousValue + (int)nextValue) / 2;
    }
}