using System;
namespace SuperMetricsService.Helpers;

public class SumDictionaryItemHolder<TSumItem>(Dictionary<string, List<TSumItem>>? total = null, List<TSumItem>? first = null, List<TSumItem>? last = null)
{
    public Dictionary<string, List<TSumItem>> Total { get; } = total ?? new Dictionary<string, List<TSumItem>>();
    public List<TSumItem> First { get; } = first ?? [];
    public List<TSumItem> Last { get; } = last ?? [];
}