using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers;

public static class PostsHelper
{
    private static Func<PostsSumItem, object?> ToFunc(this PostField postField) => postField switch
    {
        PostField.Name => x => x.Name,
        PostField.Date => x => x.Date,
        PostField.Likes => x => x.Likes,
        PostField.Type => x => x.PostType,
        PostField.Shares => x => x.Shares,
        PostField.Views => x => x.Views,
        PostField.Comments => x => x.Comments,
        PostField.Paid => x => x.Paid,
        PostField.Message => x => x.Message,
        PostField.Clicks => x => x.Clicks,
        _ => throw new NotSupportedException("ToFunc")
    };

    public static IOrderedEnumerable<PostsSumItem> FieldOrderBy(this IEnumerable<PostsSumItem> posts, PostField field, bool ascending) => ascending
        ? posts.OrderBy(field.ToFunc())
        : posts.OrderByDescending(field.ToFunc());
   
    public static string GetFieldName(this PostRequestCategory category, ChannelType channelType) => channelType switch
    {
        ChannelType.FACEBOOK => GetFacebookFieldName(category),
        ChannelType.INSTAGRAM => GetInstagramFieldName(category),
        _ => throw new ChannelTypeNotSupportedException(channelType, "GetFieldName")
    };

    public static BsonElement[] ProjectionStep(ChannelType channelType)
    {
        return channelType switch
        {
            ChannelType.FACEBOOK =>  
            [
                new(nameof(Post.Thumbnail), "$data.post_picture"),
                new(nameof(Post.Message), "$data.post_message"),
                new(nameof(Post.TotalReach), "$data.post_engaged_users"),
                new(nameof(Post.TotalLikes), "$data.post_likes_on_post"),
                new(nameof(Post.TotalReactions), "$data.post_impressions"),
                new(nameof(Post.Date), "$query.date"),
                new(nameof(Post.Time), "$query.time")
            ],
            ChannelType.INSTAGRAM => 
            [
                new(nameof(Post.Thumbnail), "$data.media_thumbnail_url"),
                new(nameof(Post.Message), "$data.media_caption"),
                new(nameof(Post.TotalReach), "$data.media_reach"),
                new(nameof(Post.TotalLikes), "$data.media_like_count"),
                new(nameof(Post.TotalReactions), "$data.media_comments_count"),
                new(nameof(Post.Date), "$query.date"),
                new(nameof(Post.Time), "$query.time")
            ],
            _ => throw new ChannelTypeNotSupportedException(channelType, "ProjectionStep")
        };
    }

    private static string GetFacebookFieldName(PostRequestCategory category)
    {
        return category switch
        {
            PostRequestCategory.REACH => "data.post_engaged_users",
            PostRequestCategory.LIKES => "data.post_likes_on_post",
            PostRequestCategory.REACTION => "data.post_comments_on_post",
            _ => string.Empty
        };
    }

    private static string GetInstagramFieldName(PostRequestCategory category)
    {
        return category switch
        {
            PostRequestCategory.REACH => "data.media_reach",
            PostRequestCategory.LIKES => "data.media_like_count",
            PostRequestCategory.REACTION => "data.media_comments_count",
            _ => string.Empty
        };
    }
}