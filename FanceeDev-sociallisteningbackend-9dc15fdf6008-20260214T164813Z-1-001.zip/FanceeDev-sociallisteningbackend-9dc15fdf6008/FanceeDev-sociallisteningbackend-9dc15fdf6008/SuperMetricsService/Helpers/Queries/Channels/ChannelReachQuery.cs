using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.ChannelInfo;

namespace SuperMetricsService.Helpers.Queries.Channels;

public class ChannelReachQuery(DaoRequest daoRequest) : QueryBuilder(daoRequest)
{
    public static IEnumerable<SubscriptionType> SubscriptionTypes => [SubscriptionType.FB, SubscriptionType.IGI_PROFILE_DATA];

    protected override IEnumerable<BsonDocument> GetFacebookQuery()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate, new BsonElement[]
            {
                new("data.page_fans", new BsonDocument("$ne", BsonNull.Value))
            }),
            MongoHelper.SortStage(),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(ChannelReach.Name), "$last.data.profile"),
                new(nameof(ChannelReach.TotalFollowers), "$last.data.page_fans"),
                new(nameof(ChannelReach.IncreasedFollowers), new BsonDocument("$subtract",
                    new BsonArray { "$last.data.page_fans", "$first.data.page_fans" })
                )
            })
        };
    }

    protected override IEnumerable<BsonDocument> GetInstagramQuery()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.SortStage(),
            MongoHelper.DefaultGroupStage(new BsonElement[]
            {
                new("profile_views", new BsonDocument("$sum", "$data.profile_views")),
                new("website_clicks", new BsonDocument("$sum", "$data.website_clicks"))
            }),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(ChannelReach.Name), "$last.data.name"),
                new(nameof(ChannelReach.Description), "$last.data.biography"),
                new(nameof(ChannelReach.Reach), "$last.data.reach"),
                new(nameof(ChannelReach.ActiveFollowers), "$profile_views"),
                new(nameof(ChannelReach.ClicksOnPage), "$website_clicks"),
                new(nameof(ChannelReach.Comments), "$last.data.impressions")
            })
        };
    }
}