using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.ChannelInfo;

namespace SuperMetricsService.Helpers.Queries.Channels;

public class ChannelGrowthQuery(DaoRequest daoRequest) : QueryBuilder(daoRequest)
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB, SubscriptionType.IGI];

    protected override IEnumerable<BsonDocument> GetFacebookQuery()
    {
        return new List<BsonDocument>
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate, new BsonElement[]
            {
                new("data.page_fans", new BsonDocument("$ne", BsonNull.Value))
            }),
            MongoHelper.SortStage(),
            MongoHelper.GroupStage(new BsonElement[]
            {
                new("_id", "$query.date_month"),
                new("date", new BsonDocument("$first", "$data.Date")),
                new("adds", new BsonDocument("$sum", "$data.page_fan_adds")),
                new("removes", new BsonDocument("$sum", "$data.page_fan_removes")),
                new("total", new BsonDocument("$last", "$data.page_fans"))
            }),
            MongoHelper.PipelineStage("$project", new BsonElement[]
            {
                new("_id", false),
                new(nameof(ChannelGrowth.Date), "$date"),
                new(nameof(ChannelGrowth.Followers), "$total"),
                new(nameof(ChannelGrowth.Gained), "$adds"),
                new(nameof(ChannelGrowth.Lost), "$removes")
            }),
            MongoHelper.PipelineStage("$sort", new BsonElement[]
            {
                new(nameof(ChannelGrowth.Date), 1)
            })
        };
    }
}