using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.ChannelInfo;

namespace SuperMetricsService.Helpers.Queries.Channels;

public class ChannelReachFollowersQuery(DaoRequest daoRequest) : QueryBuilder(daoRequest)
{
    public static IEnumerable<SubscriptionType> SubscriptionTypes => [SubscriptionType.IGI];

    protected override IEnumerable<BsonDocument> GetInstagramQuery()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.SortStage(),
            MongoHelper.DefaultGroupStage(),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(ChannelReach.TotalFollowers), "$last.data.followers_count"),
                new(nameof(ChannelReach.IncreasedFollowers), new BsonDocument("$subtract",
                    new BsonArray { "$last.data.followers_count", "$first.data.followers_count" })
                )
            })
        };
    }
}