using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers.Queries.Posts;

public class TopKeywordsQuery(DaoRequest daoRequest, KeywordCategory category) : QueryBuilder(daoRequest)
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA];

    private readonly string _fieldName = category switch
    {
        KeywordCategory.HASH => "$query.keywords_hash",
        KeywordCategory.TAG => "$query.keywords_tag",
        KeywordCategory.CAPTION => "$query.keywords_caption",
        KeywordCategory.EMOJI => "$query.keywords_emoji",
        var _ => string.Empty
    };

    protected override IEnumerable<BsonDocument> GetQuery()
    {
        return new List<BsonDocument>
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.UnwindStage(_fieldName),
            MongoHelper.GroupStage(new BsonElement[]
            {
                new("_id", _fieldName),
                new(nameof(TopKeyword.Word), new BsonDocument("$first", _fieldName)),
                new(nameof(TopKeyword.Amount), new BsonDocument("$sum", 1))
            }),
            MongoHelper.SortStage(nameof(TopKeyword.Amount), -1),
            MongoHelper.LimitStage(10)
        };
    }
}