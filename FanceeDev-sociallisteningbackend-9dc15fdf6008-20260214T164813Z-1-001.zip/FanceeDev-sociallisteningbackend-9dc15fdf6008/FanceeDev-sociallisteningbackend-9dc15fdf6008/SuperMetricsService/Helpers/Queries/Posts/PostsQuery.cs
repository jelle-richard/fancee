using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;

namespace SuperMetricsService.Helpers.Queries.Posts;

public class PostsQuery(DaoRequest daoRequest) : QueryBuilder(daoRequest)
{
    protected override IEnumerable<BsonDocument> GetQuery() =>
        new List<BsonDocument>
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.ProjectStage(PostsHelper.ProjectionStep(ChannelType))
        };
}