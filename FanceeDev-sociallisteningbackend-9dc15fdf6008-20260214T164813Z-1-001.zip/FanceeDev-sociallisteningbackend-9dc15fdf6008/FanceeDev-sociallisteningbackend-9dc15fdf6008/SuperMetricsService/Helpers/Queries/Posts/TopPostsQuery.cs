using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers.Queries.Posts;

public class TopPostsQuery : QueryBuilder
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA];

    private readonly string _fieldName;
    private readonly int _limit;
    private readonly int _offset;
    private readonly bool _paginated;

    public TopPostsQuery(DaoRequest daoRequest, PostRequestCategory category, int limit, int offset, bool paginated = false) : base(daoRequest)
    {
        _fieldName = category.GetFieldName(ChannelType);
        _limit = limit;
        _offset = offset;
        _paginated = paginated;
    }

    protected override IEnumerable<BsonDocument> GetQuery()
    {
        if (_paginated)
            return GetPaginatedQuery();

        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.SortStage(_fieldName, -1),
            MongoHelper.SkipStage(_offset),
            MongoHelper.LimitStage(_limit),
            MongoHelper.ProjectStage(PostsHelper.ProjectionStep(ChannelType))
        };
    }

    private IEnumerable<BsonDocument> GetPaginatedQuery()
    {
        var matchList = new List<BsonElement>
        {
            new("subscription_id", ObjectId.Parse(SubscriptionId))
        };

        if (StartDate != null || EndDate != null)
        {
            var dateMatch = new BsonDocument();
            if (StartDate != null)
                dateMatch.Add(new BsonElement("$gte", StartDate));
            if (EndDate != null)
                dateMatch.Add(new BsonElement("$lt", EndDate));

            matchList.Add(new("query.date", dateMatch));
        }

        return MongoHelper.PaginationStages(new(matchList), _limit, _offset, new(_fieldName, -1), new[] { MongoHelper.ProjectStage(PostsHelper.ProjectionStep(ChannelType)) });
    }
}