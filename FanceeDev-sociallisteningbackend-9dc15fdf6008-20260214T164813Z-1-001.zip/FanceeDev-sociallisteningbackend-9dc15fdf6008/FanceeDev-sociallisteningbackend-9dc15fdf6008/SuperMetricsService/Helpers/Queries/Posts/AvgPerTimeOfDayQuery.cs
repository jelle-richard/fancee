using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers.Queries.Posts;

public class AvgPerTimeOfDayQuery : QueryBuilder
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA];

    private readonly string _fieldName;

    public AvgPerTimeOfDayQuery(DaoRequest daoRequest, PostRequestCategory category) : base(daoRequest)
    {
        _fieldName = category.GetFieldName(ChannelType);
    }

    protected override IEnumerable<BsonDocument> GetQuery()
    {
        return new List<BsonDocument>
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.GroupStage(new BsonElement[]
            {
                new("_id", "$query.time_hour"),
                new(nameof(AvgPerHour.Hour), new BsonDocument("$first", "$query.time_hour")),
                new(nameof(AvgPerHour.Average), new BsonDocument("$avg", $"${_fieldName}"))
            }),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", BsonNull.Value),
                new(nameof(AvgPerHour.Hour), "$Hour"),
                new(nameof(AvgPerHour.Average), new BsonDocument("$floor", "$Average"))
            })
        };
    }
}