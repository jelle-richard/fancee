using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers.Queries.Posts;

public class AvgPerDayOfWeekQuery : QueryBuilder
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA];

    private readonly string _fieldName;

    public AvgPerDayOfWeekQuery(DaoRequest daoRequest, PostRequestCategory category) : base(daoRequest)
    {
        _fieldName = category.GetFieldName(ChannelType);
    }

    protected override IEnumerable<BsonDocument> GetQuery()
    {
        return new List<BsonDocument>
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate, new BsonElement[]
            {
                new(_fieldName, new BsonDocument("$ne", BsonNull.Value))
            }),
            MongoHelper.SortStage(),
            MongoHelper.GroupStage(new BsonElement[]
            {
                new("_id", "$query.date_dayofweek"),
                new(nameof(AvgPerDayOfWeek.DayOfWeek), new BsonDocument("$first", "$query.date_dayofweek")),
                new(nameof(AvgPerDayOfWeek.Average), new BsonDocument("$avg", $"${_fieldName}"))
            }),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", BsonNull.Value),
                new(nameof(AvgPerDayOfWeek.DayOfWeek), "$DayOfWeek"),
                new(nameof(AvgPerDayOfWeek.Average), new BsonDocument("$floor", "$Average"))
            })
        };
    }
}