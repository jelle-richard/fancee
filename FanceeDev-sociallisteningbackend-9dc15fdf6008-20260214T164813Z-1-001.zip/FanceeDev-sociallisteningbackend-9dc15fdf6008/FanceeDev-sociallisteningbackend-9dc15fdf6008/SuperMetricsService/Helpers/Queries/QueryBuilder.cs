using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Utils.Extensions;

namespace SuperMetricsService.Helpers.Queries;

public class QueryBuilder : DaoRequest
{
    protected readonly ChannelType ChannelType;

    public QueryBuilder(DaoRequest daoRequest) : base(daoRequest)
    {
        ChannelType = daoRequest.SubscriptionType.ToChannelType();
    }

    public IEnumerable<BsonDocument> Build()
    {
        return ChannelType switch
        {
            ChannelType.FACEBOOK => GetFacebookQuery(),
            ChannelType.INSTAGRAM => GetInstagramQuery(),
            ChannelType.YOUTUBEV2 => GetYoutubeV2Query(),
            ChannelType.LINKEDIN => GetLinkedInQuery(),
            ChannelType.TIKTOK => GetTikTokQuery(),
            _ => throw new ChannelTypeNotSupportedException(ChannelType, "QueryBuilder")
        };
    }

    protected virtual IEnumerable<BsonDocument> GetFacebookQuery() => GetQuery();

    protected virtual IEnumerable<BsonDocument> GetInstagramQuery() => GetQuery();

    protected virtual IEnumerable<BsonDocument> GetYoutubeV2Query() => GetQuery();

    protected virtual IEnumerable<BsonDocument> GetLinkedInQuery() => GetQuery();

    protected virtual IEnumerable<BsonDocument> GetTikTokQuery() => GetQuery();

    protected virtual IEnumerable<BsonDocument> GetQuery() => throw new NotImplementedException();

    protected IEnumerable<BsonDocument> GetBasicQuery(string fieldName, string groupBy, string command = "$sum")
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate, new BsonElement[]
            {
                new(fieldName, new BsonDocument("$ne", BsonNull.Value)),
                new(groupBy, new BsonDocument("$ne", BsonNull.Value))
            }),
            MongoHelper.SortStage(),
            MongoHelper.GroupStage(new BsonElement[]
            {
                new("_id", $"${groupBy}"),
                new("total", new BsonDocument(command, $"${fieldName}"))
            })
        };
    }
}