using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Likes;

namespace SuperMetricsService.Helpers.Queries.Likes;

public class LikesPerAgeQuery : QueryBuilder
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_AGE_AND_GENDER, SubscriptionType.IGI_AGE_AND_GENDER, SubscriptionType.YT2_DEMOGRAPHIC];

    private static BsonDocument Project => MongoHelper.ProjectStage(new BsonElement[]
    {
        new("_id", false),
        new(nameof(AgeLikesStatistics.Age), "$_id"),
        new(nameof(AgeLikesStatistics.LikesAmount), "$total")
    });

    public LikesPerAgeQuery(DaoRequest daoRequest) : base(daoRequest)
    {
    }

    protected override IEnumerable<BsonDocument> GetFacebookQuery() =>
        GetBasicQuery("data.page_fans", "data.age", "$last")
            .Append(Project)
            .Append(MongoHelper.SortStage(nameof(AgeLikesStatistics.Age)));

    protected override IEnumerable<BsonDocument> GetInstagramQuery() =>
        GetBasicQuery("data.followers_count", "data.audience_age", "$last")
            .Append(Project)
            .Append(MongoHelper.SortStage(nameof(AgeLikesStatistics.Age)));

    protected override IEnumerable<BsonDocument> GetYoutubeV2Query() =>
        GetBasicQuery("data.viewerPercentage", "data.ageGroup", "$last")
            .Append(Project)
            .Append(MongoHelper.SortStage(nameof(AgeLikesStatistics.Age)));
}