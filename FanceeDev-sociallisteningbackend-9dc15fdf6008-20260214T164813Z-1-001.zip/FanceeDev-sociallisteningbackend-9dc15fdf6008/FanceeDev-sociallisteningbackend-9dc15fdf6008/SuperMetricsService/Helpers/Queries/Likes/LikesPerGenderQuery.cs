using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Likes;

namespace SuperMetricsService.Helpers.Queries.Likes;

public class LikesPerGenderQuery : QueryBuilder
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_AGE_AND_GENDER, SubscriptionType.IGI_AGE_AND_GENDER, SubscriptionType.YT2_DEMOGRAPHIC, SubscriptionType.TIKBA_GENDER, SubscriptionType.FA_AGE_AND_GENDER, SubscriptionType.AW_GENDER];

    private static BsonDocument Project => MongoHelper.ProjectStage(new BsonElement[]
    {
        new("_id", false),
        new(nameof(GenderLikesStatistics.Gender), "$_id"),
        new(nameof(GenderLikesStatistics.LikesAmount), "$total")
    });

    public LikesPerGenderQuery(DaoRequest daoRequest) : base(daoRequest)
    {
    }

    protected override IEnumerable<BsonDocument> GetFacebookQuery() =>
        GetBasicQuery("data.page_fans", "data.gender", "$last")
            .Append(Project)
            .Append(MongoHelper.SortStage(nameof(GenderLikesStatistics.Gender)));

    protected override IEnumerable<BsonDocument> GetInstagramQuery() =>
        GetBasicQuery("data.followers_count", "data.audience_gender", "$last")
            .Append(Project)
            .Append(MongoHelper.SortStage(nameof(GenderLikesStatistics.Gender)));

    protected override IEnumerable<BsonDocument> GetYoutubeV2Query() =>
        GetBasicQuery("data.viewerPercentage", "data.gender", "$last")
            .Append(Project)
            .Append(MongoHelper.SortStage(nameof(GenderLikesStatistics.Gender)));

    protected override IEnumerable<BsonDocument> GetTikTokQuery() =>
        GetBasicQuery("data.gender__distribution", "data.gender__gender", "$last")
            .Append(Project)
            .Append(MongoHelper.SortStage(nameof(GenderLikesStatistics.Gender)));
}