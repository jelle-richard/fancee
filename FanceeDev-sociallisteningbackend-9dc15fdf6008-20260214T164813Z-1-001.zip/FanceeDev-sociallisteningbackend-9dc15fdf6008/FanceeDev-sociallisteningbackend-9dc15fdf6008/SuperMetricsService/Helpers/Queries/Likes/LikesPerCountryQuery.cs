using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Likes;

namespace SuperMetricsService.Helpers.Queries.Likes;

public class LikesPerCountryQuery : QueryBuilder
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_GEO_LIKES, SubscriptionType.IGI_COUNTRY, SubscriptionType.YT2_GEO, SubscriptionType.LIP_COUNTRY];

    public LikesPerCountryQuery(DaoRequest daoRequest) : base(daoRequest)
    {
    }

    protected override IEnumerable<BsonDocument> GetFacebookQuery()
    {
        return new List<BsonDocument>
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate, new BsonElement[]
            {
                new("data.page_fans", new BsonDocument("$ne", BsonNull.Value))
            }),
            MongoHelper.SortStage(),
            MongoHelper.DefaultGroupStage("$data.country"),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(GeoLikesStatistics.CountryCode), "$_id"),
                new(nameof(GeoLikesStatistics.LikesAmount), "$last.data.page_fans"),
                new(nameof(GeoLikesStatistics.LikesGained), new BsonDocument("$subtract",
                    new BsonArray { "$last.data.page_fans", "$first.data.page_fans" })
                )
            })
        };
    }

    protected override IEnumerable<BsonDocument> GetInstagramQuery()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.SortStage(),
            MongoHelper.DefaultGroupStage("$data.audience_country_dim"),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(GeoLikesStatistics.CountryCode), "$_id"),
                new(nameof(GeoLikesStatistics.LikesAmount), "$last.data.followers_count"),
                new(nameof(GeoLikesStatistics.LikesGained), new BsonDocument("$subtract",
                    new BsonArray { "$last.data.followers_count", "$first.data.followers_count" })
                )
            })
        };
    }

    protected override IEnumerable<BsonDocument> GetYoutubeV2Query()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.SortStage(),
            MongoHelper.DefaultGroupStage("$data.country"),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(GeoLikesStatistics.CountryCode), "$_id"),
                new(nameof(GeoLikesStatistics.LikesAmount), "$last.data.likes"),
                new(nameof(GeoLikesStatistics.LikesGained), new BsonDocument("$subtract",
                    new BsonArray { "$last.data.likes", "$first.data.likes" })
                )
            })
        };
    }

    protected override IEnumerable<BsonDocument> GetLinkedInQuery()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.SortStage(),
            MongoHelper.DefaultGroupStage("$query.countryCode"),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(GeoLikesStatistics.CountryCode), "$_id"),
                new(nameof(GeoLikesStatistics.LikesAmount), "$last.data.follower_count_organic"),
                new(nameof(GeoLikesStatistics.LikesGained), new BsonDocument("$subtract",
                    new BsonArray { "$last.data.follower_count_organic", "$first.data.follower_count_organic" })
                )
            })
        };
    }

    protected override IEnumerable<BsonDocument> GetTikTokQuery()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.SortStage(),
            MongoHelper.DefaultGroupStage("$data.territories__country"),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new(nameof(GeoLikesStatistics.CountryCode), "$_id"),
                new(nameof(GeoLikesStatistics.LikesAmount), "$last.data.territories__distribution"),
                new(nameof(GeoLikesStatistics.LikesGained), new BsonDocument("$subtract",
                    new BsonArray { "$last.data.territories__distribution", "$first.data.territories__distribution" })
                )
            })
        };
    }
}