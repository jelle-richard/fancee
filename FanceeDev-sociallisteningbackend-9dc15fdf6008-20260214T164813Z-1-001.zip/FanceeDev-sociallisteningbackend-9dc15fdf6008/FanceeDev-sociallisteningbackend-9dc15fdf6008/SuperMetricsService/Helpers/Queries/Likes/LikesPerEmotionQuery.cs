using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using SocialListeningCore.Helpers;

namespace SuperMetricsService.Helpers.Queries.Likes;

public class LikesPerEmotionQuery : QueryBuilder
{
    public static SubscriptionType[] SubscriptionTypes => [SubscriptionType.FB_POSTS];

    public LikesPerEmotionQuery(DaoRequest daoRequest) : base(daoRequest)
    {
    }

    protected override IEnumerable<BsonDocument> GetFacebookQuery()
    {
        return new[]
        {
            MongoHelper.MatchStage(SubscriptionId, StartDate, EndDate),
            MongoHelper.GroupStage(new BsonDocument
            {
                { "_id", BsonNull.Value },
                { "ANGER", new BsonDocument("$sum", "$data.post_reactions_anger") },
                { "HAHA", new BsonDocument("$sum", "$data.post_reactions_haha") },
                { "LIKE", new BsonDocument("$sum", "$data.post_reactions_like") },
                { "WOW", new BsonDocument("$sum", "$data.post_reactions_wow") },
                { "THANKFUL", new BsonDocument("$sum", "$data.post_reactions_thankful") },
                { "SORRY", new BsonDocument("$sum", "$data.post_reactions_sorry") },
                { "PRIDE", new BsonDocument("$sum", "$data.post_reactions_pride") },
                { "LOVE", new BsonDocument("$sum", "$data.post_reactions_love") }
            }),
            MongoHelper.ProjectStage(new BsonElement[]
            {
                new("_id", false),
                new("items", new BsonArray
                {
                    new BsonDocument { { "Emotion", "ANGER" }, { "Amount", "$ANGER" } },
                    new BsonDocument { { "Emotion", "HAHA" }, { "Amount", "$HAHA" } },
                    new BsonDocument { { "Emotion", "LIKE" }, { "Amount", "$LIKE" } },
                    new BsonDocument { { "Emotion", "WOW" }, { "Amount", "$WOW" } },
                    new BsonDocument { { "Emotion", "THANKFUL" }, { "Amount", "$THANKFUL" } },
                    new BsonDocument { { "Emotion", "SORRY" }, { "Amount", "$SORRY" } },
                    new BsonDocument { { "Emotion", "PRIDE" }, { "Amount", "$PRIDE" } },
                    new BsonDocument { { "Emotion", "LOVE" }, { "Amount", "$LOVE" } }
                })
            }),
            new("$unwind", "$items"),
            new BsonDocument("$replaceWith", "$items")
        };
    }
}