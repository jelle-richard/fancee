using FanceeAnalyticsData.Models.Analytics.Sum;

namespace SuperMetricsService.Helpers;

public static class SumItemPaddingHelper
{
    /// <summary>
    /// Creates a list of TSumItems based on the date range given.
    /// </summary>
    /// <param name="start"></param>
    /// <param name="end"></param>
    /// <param name="subscriptionId"></param>
    /// <typeparam name="TSumItem"></typeparam>
    /// <returns></returns>
    public static IEnumerable<TSumItem> BuildPaddedDaysObjectList<TSumItem>(DateTime start, DateTime end, string subscriptionId) where TSumItem : SumItem, new()
    {
        var diff = end.Subtract(start);

        for (var i = 0; i <= diff.Days; i++)
        {
            yield return new()
            {
                Date = start.AddDays(i),
                SubscriptionId = subscriptionId
            };
        }
    }
}