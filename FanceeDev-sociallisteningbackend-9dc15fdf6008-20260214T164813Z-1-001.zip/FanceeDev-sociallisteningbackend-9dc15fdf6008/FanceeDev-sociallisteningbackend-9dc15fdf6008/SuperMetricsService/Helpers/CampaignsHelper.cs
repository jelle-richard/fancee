using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers;

public static class CampaignsHelper
{
    private static Dictionary<CampaignField, Func<CampaignsSumItem, object?>> OrderFunctions =>
        new()
        {
            { CampaignField.Name, x => x.Name },
            { CampaignField.Date, x => x.Date },
            { CampaignField.StartDate, x => x.StartDate },
            { CampaignField.Status, x => x.Status },
            { CampaignField.Cost, x => x.Cost },
            { CampaignField.Budget, x => x.Budget },
            { CampaignField.Impressions, x => x.Impressions },
            { CampaignField.Clicks, x => x.Clicks },
            { CampaignField.CPC, x => x.CPC },
            { CampaignField.CTR, x => x.CTR },
            { CampaignField.Conversion, x => x.Conversion }
        };

    public static IOrderedEnumerable<CampaignsSumItem> FieldOrderBy(this IEnumerable<CampaignsSumItem> campaigns, CampaignField field, bool ascending)
        => ascending
            ? campaigns.OrderBy(OrderFunctions[field])
            : campaigns.OrderByDescending(OrderFunctions[field]);

    public static string FieldName(SubscriptionType type) => type switch
    {
        SubscriptionType.AW_AGE or SubscriptionType.AW_GENDER or SubscriptionType.AW_CAMPAIGN => "data.CampaignID",
        SubscriptionType.FA_AGE_AND_GENDER or SubscriptionType.FA_CAMPAIGN => "data.adcampaign_id",
        var _ => throw new SubscriptionTypeNotSupportedException(type)
    };
}