using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers;

public static class SumTypeExtensions
{
    public static SubscriptionType[] ToSubscriptionTypes(this SumType sumType) => sumType switch
    {
        SumType.Followers => [SubscriptionType.FB, SubscriptionType.IGI, SubscriptionType.YT2_CHANNEL, SubscriptionType.LIP_PAGE, SubscriptionType.TIKBA_PROFILE],
        SumType.Reach => [SubscriptionType.FB, SubscriptionType.IGI_PROFILE_DATA, SubscriptionType.YT2_CHANNEL, SubscriptionType.LIP_PAGE, SubscriptionType.TIKBA_PROFILE],
        SumType.Engagement => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA, SubscriptionType.YT2_VIDEO, SubscriptionType.LIP_POST, SubscriptionType.TIKBA_VIDEO],
        SumType.Comments => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA, SubscriptionType.YT2_VIDEO, SubscriptionType.LIP_POST, SubscriptionType.TIKBA_VIDEO],
        SumType.Posts => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA, SubscriptionType.YT2_VIDEO, SubscriptionType.LIP_POST, SubscriptionType.TIKBA_VIDEO],
        SumType.Emotions => [SubscriptionType.FB_POSTS],
        SumType.Age => [SubscriptionType.FB_AGE_AND_GENDER, SubscriptionType.IGI_AGE_AND_GENDER, SubscriptionType.YT2_DEMOGRAPHIC, SubscriptionType.AW_AGE, SubscriptionType.FA_AGE_AND_GENDER],
        SumType.Gender => [SubscriptionType.FB_AGE_AND_GENDER, SubscriptionType.IGI_AGE_AND_GENDER, SubscriptionType.YT2_DEMOGRAPHIC, SubscriptionType.TIKBA_GENDER, SubscriptionType.AW_GENDER, SubscriptionType.FA_AGE_AND_GENDER],
        SumType.AgeAndGender => [SubscriptionType.FA_AGE_AND_GENDER],
        SumType.Keywords => [SubscriptionType.FB_POSTS, SubscriptionType.IGI_MEDIA, SubscriptionType.YT2_VIDEO, SubscriptionType.LIP_POST, SubscriptionType.TIKBA_VIDEO],
        SumType.Country => [SubscriptionType.FB_GEO_LIKES, SubscriptionType.IGI_COUNTRY, SubscriptionType.YT2_GEO, SubscriptionType.LIP_COUNTRY, SubscriptionType.TIKBA_COUNTRY],
        SumType.Campaigns => [SubscriptionType.AW_CAMPAIGN, SubscriptionType.FA_CAMPAIGN],
        var _ => Array.Empty<SubscriptionType>()
    };

    public static BsonDocument ToProjection(this SumType sumType, SubscriptionType subscriptionType) => sumType switch
    {
        SumType.Engagement => SumEngagementProjection(subscriptionType),
        SumType.Followers => SumFollowersProjection(subscriptionType),
        SumType.Reach => SumReachProjection(subscriptionType),
        SumType.Comments => SumCommentsProjection(subscriptionType),
        SumType.Posts => SumPostsProjection(subscriptionType),
        SumType.Emotions => SumEmotionsProjection(subscriptionType),
        SumType.Campaigns => SumCampaignsProjection(subscriptionType),
        SumType.Country => SumCountriesProjection(subscriptionType),
        SumType.Age or SumType.Gender or SumType.AgeAndGender => SumAgeAndGenderProjection(subscriptionType),
        var _ => SumBaseProjection(subscriptionType)
    };

    public static BsonDocument ExtraProjection(string name, string? channelId) => new(name, new BsonDocument("$literal", channelId));

    private static BsonDocument SumReachProjection(SubscriptionType type) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        {
            nameof(GainedAndLostSumItem.Value), type switch
            {
                SubscriptionType.FB => BsonIfNull("$data.page_impressions_unique", 0),
                SubscriptionType.IGI_PROFILE_DATA => BsonIfNull("$data.reach", 0),
                SubscriptionType.YT2_CHANNEL => BsonIfNull("$data.reach", 0),
                SubscriptionType.LIP_PAGE => BsonIfNull("$data.total_page_views", 0),
                SubscriptionType.TIKBA_PROFILE => BsonIfNull("$data.profile__video_views", 0),
                var _ => BsonLiteral(0)
            }
        }
    });

    private static BsonDocument SumFollowersProjection(SubscriptionType type) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        {
            nameof(GainedAndLostSumItem.Value), type switch
            {
                SubscriptionType.FB => "$data.page_followers",
                SubscriptionType.IGI => "$data.followers_count",
                SubscriptionType.YT2_CHANNEL => "$data.channel_subscribers",
                SubscriptionType.LIP_PAGE => "$data.follower_count",
                SubscriptionType.TIKBA_PROFILE => "$data.profile__profile_followers__current_followers",
                var _ => BsonNull.Value
            }
        }
    });

    private static BsonDocument SumEngagementProjection(SubscriptionType type) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        {
            nameof(EngagementSumItem.Shares), type switch
            {
                SubscriptionType.FB_POSTS => BsonIfNull("$data.post_shares_on_post", 0),
                SubscriptionType.IGI_MEDIA => BsonIfNull("$data.media_reel_shares", 0),
                SubscriptionType.YT2_VIDEO => BsonIfNull("$data.shares", 0),
                SubscriptionType.LIP_POST => BsonIfNull("$data.page_shares", 0),
                SubscriptionType.TIKBA_VIDEO => BsonIfNull("$data.videos__shares", 0),
                var _ => BsonLiteral(0)
            }
        },
        {
            nameof(EngagementSumItem.Comments), type switch
            {
                SubscriptionType.FB_POSTS => BsonIfNull("$data.post_comments_on_post", 0),
                SubscriptionType.IGI_MEDIA => BsonIfNull("$data.media_comments_count", 0),
                SubscriptionType.YT2_VIDEO => BsonIfNull("$data.comments", 0),
                SubscriptionType.LIP_POST => BsonIfNull("$data.page_comments", 0),
                SubscriptionType.TIKBA_VIDEO => BsonIfNull("$data.videos__comments", 0),
                var _ => BsonLiteral(0)
            }
        },
        {
            nameof(EngagementSumItem.Likes), type switch
            {
                SubscriptionType.FB_POSTS => BsonIfNull("$data.post_likes_on_post", 0),
                SubscriptionType.IGI_MEDIA => BsonIfNull("$data.media_like_count", 0),
                SubscriptionType.YT2_VIDEO => BsonIfNull("$data.likes", 0),
                SubscriptionType.LIP_POST => BsonIfNull("$data.page_likes", 0),
                SubscriptionType.TIKBA_VIDEO => BsonIfNull("$data.videos__likes", 0),
                var _ => BsonLiteral(0)
            }
        }
    });

    private static BsonDocument SumCommentsProjection(SubscriptionType type) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        { nameof(CommentsSumItem.Hour), "$query.time_hour" },
        { nameof(CommentsSumItem.DayOfWeek), "$query.date_dayofweek" },
        {
            nameof(CommentsSumItem.Comments), type switch
            {
                SubscriptionType.FB_POSTS => BsonIfNull("$data.post_comments_on_post", 0),
                SubscriptionType.IGI_MEDIA => BsonIfNull("$data.media_comments_count", 0),
                SubscriptionType.YT2_VIDEO => BsonIfNull("$data.comments", 0),
                SubscriptionType.LIP_POST => BsonIfNull("$data.page_comments", 0),
                SubscriptionType.TIKBA_VIDEO => BsonIfNull("$data.videos__comments", 0),
                var _ => BsonLiteral(0)
            }
        },
        {
            nameof(CommentsSumItem.Reach), type switch
            {
                SubscriptionType.FB_POSTS => BsonIfNull("$data.post_link_clicks_unique", 0),
                SubscriptionType.IGI_MEDIA => BsonIfNull("$data.media_reach", 0),
                SubscriptionType.YT2_VIDEO => BsonIfNull("$data.shares", 0),
                SubscriptionType.LIP_POST => BsonIfNull("$data.page_impressions", 0),
                SubscriptionType.TIKBA_VIDEO => BsonIfNull("$data.videos__reach", 0),
                var _ => BsonLiteral(0)
            }
        },
        {
            nameof(CommentsSumItem.Likes), type switch
            {
                SubscriptionType.FB_POSTS => BsonIfNull("$data.post_likes_on_post", 0),
                SubscriptionType.IGI_MEDIA => BsonIfNull("$data.media_like_count", 0),
                SubscriptionType.YT2_VIDEO => BsonIfNull("$data.likes", 0),
                SubscriptionType.LIP_POST => BsonIfNull("$data.page_likes", 0),
                SubscriptionType.TIKBA_VIDEO => BsonIfNull("$data.videos__likes", 0),
                var _ => BsonLiteral(0)
            }
        }
    });

    private static BsonDocument SumCountriesProjection(SubscriptionType type) => type switch
    {
        SubscriptionType.FB_GEO_LIKES => BsonCountrySumItem(
            type,
            "$data.country",
            "$data.page_fans",
            BsonNull.Value
        ),
        SubscriptionType.IGI_COUNTRY => BsonCountrySumItem(
            type,
            "$data.audience_country_dim",
            "$data.followers_count",
            BsonNull.Value
        ),
        SubscriptionType.YT2_GEO => BsonCountrySumItem(
            type,
            "$query.countryCode",
            "$data.likes",
            BsonNull.Value
        ),
        SubscriptionType.LIP_COUNTRY => BsonCountrySumItem(
            type,
            "$query.countryCode",
            "$data.follower_count_organic",
            BsonNull.Value
        ),
        SubscriptionType.TIKBA_COUNTRY => BsonCountrySumItem(
            type,
            "$data.territories__country",
            BsonNull.Value,
            "$data.territories__distribution"
        ),
        var _ => new()
    };

    private static BsonDocument SumAgeAndGenderProjection(SubscriptionType type) => type switch
    {
        SubscriptionType.FB_AGE_AND_GENDER => BsonAgeGenderSumItem(
            type,
            "$data.age",
            BsonToLower("$data.gender"),
            "$data.page_fans",
            BsonNull.Value
        ),
        SubscriptionType.IGI_AGE_AND_GENDER => BsonAgeGenderSumItem(
            type,
            "$data.audience_age",
            BsonToLower("$data.audience_gender"),
            "$data.followers_count",
            BsonNull.Value
        ),
        SubscriptionType.YT2_DEMOGRAPHIC => BsonAgeGenderSumItem(
            type,
            "$data.age",
            BsonToLower("$data.gender"),
            BsonNull.Value,
            "$data.viewerPercentage"
        ),
        SubscriptionType.TIKBA_GENDER => BsonAgeGenderSumItem(
            type,
            BsonNull.Value,
            BsonToLower("$data.gender__gender"),
            BsonNull.Value,
            "$data.gender__distribution"
        ),
        SubscriptionType.AW_AGE or SubscriptionType.AW_GENDER => BsonCampaignAgeGenderSumItem(
            type,
            "$data.CampaignID",
            "$data.Age",
            BsonToLower("$data.Gender"),
            BsonIfNull("$data.Clicks", 0),
            BsonIfNull("$data.Conversions", 0.0d),
            BsonIfNull("$data.Cost", 0.0d),
            BsonIfNull("$data.Impressions", 0),
            BsonIfNull("$data.videoviews", 0)
        ),
        SubscriptionType.FA_AGE_AND_GENDER => BsonCampaignAgeGenderSumItem(
            type,
            "$data.CampaignID",
            "$data.Age",
            BsonToLower("$data.Gender"),
            BsonIfNull("$data.Clicks", 0),
            BsonIfNull("$data.UniqueActions", 0),
            BsonIfNull("$data.cost", 0.0d),
            BsonIfNull("$data.impressions", 0),
            BsonIfNull("$data.action_video_view", 0)
        ),
        var _ => new()
    };

    private static BsonDocument SumPostsProjection(SubscriptionType type) => type switch
    {
        SubscriptionType.FB_POSTS => BsonPostsSumItem(
            type,
            "$data.profile",
            "$data.post_link",
            "$query.time",
            BsonIfNull("$data.post_picture", 0),
            BsonIfNull("$data.post_type", ""),
            BsonIfNull("$data.post_comments_on_post", 0),
            BsonIfNull("$data.post_likes_on_post", 0),
            BsonIfNull("$data.post_message", 0),
            BsonIfNull("$data.post_link_clicks", 0),
            BsonIfNull("$data.post_shares_on_post", 0),
            BsonIfNull("$data.post_link_clicks_unique", 0),
            BsonNe("$data.post_impressions_paid", 0)
        ),
        SubscriptionType.IGI_MEDIA => BsonPostsSumItem(
            type,
            "$data.name",
            "$data.media_permalink",
            BsonDateToString("$data.timestamp", "%H:%M"),
            BsonIfNull("$data.media_thumbnail_url", 0),
            BsonConcat(BsonIfNull("$data.media_product_type", "STORY"), "_", BsonIfNull("$data.media_type", "")),
            BsonIfNull("$data.media_comments_count", BsonIfNull("$data.media_story_replies", 0)),
            BsonIfNull("$data.media_like_count", 0),
            BsonIfNull("$data.media_caption", 0),
            BsonIfNull("$data.media_engagement", BsonIfNull("$data.media_story_taps_forward", BsonIfNull("$data.media_reel_total_interactions", 0))),
            BsonIfNull("$data.media_reel_shares", 0),
            BsonIfNull("$data.media_reach", BsonIfNull("$data.media_story_reach", BsonIfNull("$data.media_reel_plays", 0))),
            BsonEq("$data.media_product_type", "AD")
        ),
        SubscriptionType.YT2_VIDEO => BsonPostsSumItem(
            type,
            "$data.video_title",
            "$data.video_url",
            BsonDateToString("$data.video_published_at", "%H:%M"),
            BsonIfNull("$data.video_thumbnail_url", 0),
            BsonLiteral("video"),
            BsonIfNull("$data.comments", 0),
            BsonIfNull("$data.likes", 0),
            BsonIfNull("$data.video_description", 0),
            BsonIfNull("$data.cardClicks", 0),
            BsonIfNull("$data.shares", 0),
            BsonIfNull("$data.views", 0),
            BsonLiteral(BsonBoolean.False)
        ),
        SubscriptionType.LIP_POST => BsonPostsSumItem(
            type,
            "$data.update_source_name",
            "$data.update_url",
            BsonNull.Value,
            BsonIfNull("$data.update_image_url", 0),
            BsonIfNullOrEmpty("$data.update_share_media_category", "share"),
            BsonIfNull("$data.page_comments", 0),
            BsonIfNull("$data.page_likes", 0),
            BsonIfNull("$data.update_title", 0),
            BsonIfNull("$data.page_clicks", 0),
            BsonIfNull("$data.page_shares", 0),
            BsonIfNull("$data.page_views", 0),
            BsonLiteral(BsonBoolean.False)
        ),
        SubscriptionType.TIKBA_VIDEO => BsonPostsSumItem(
            type,
            "$data.videos__display_name",
            "$data.videos__share_url",
            BsonDateToString("$data.videos__create_datetime", "%H:%M"),
            BsonIfNull("$data.videos__thumbnail_url", 0),
            BsonLiteral("video"),
            BsonIfNull("$data.videos__comments", 0),
            BsonIfNull("$data.videos__likes", 0),
            BsonIfNull("$data.videos__caption", 0),
            BsonIfNull("$data.videos__reach", 0),
            BsonIfNull("$data.videos__shares", 0),
            BsonIfNull("$data.videos__video_views", 0),
            BsonLiteral(BsonBoolean.False)
        ),
        var _ => new()
    };

    private static BsonDocument SumCampaignsProjection(SubscriptionType type) => type switch
    {
        SubscriptionType.AW_CAMPAIGN => BsonCampaignsSumItem(
            type,
            "$data.startDate",
            "$data.CampaignID",
            "$data.Campaignname",
            BsonIfNull("$data.Campaignstatus", 0),
            BsonIfNull("$data.Cost", 0.0d),
            BsonIfNull("$data.Budget_noncalc", 0),
            BsonIfNull("$data.Impressions", 0),
            BsonIfNull("$data.Clicks", 0),
            BsonIfNull("$data.CPC", 0.0d),
            BsonIfNull("$data.Ctr", 0.0d),
            BsonIfNull("$data.ConversionRate", 0)
        ),
        SubscriptionType.FA_CAMPAIGN => BsonCampaignsSumItem(
            type,
            "$data.campaign_start_date",
            "$data.adcampaign_id",
            "$data.adcampaign_name",
            BsonIfNull("$data.campaignstatus", 0),
            BsonIfNull("$data.cost", 0.0d),
            BsonIfNull("$data.campaign_daily_budget", 0),
            BsonIfNull("$data.store_visits_point_estimate", 0),
            BsonIfNull("$data.Clicks", 0),
            BsonIfNull("$data.CPC", 0.0d),
            BsonIfNull("$data.CTR", 0.0d),
            BsonIfNull("$data.quality_score_ecvr", 0)
        ),
        var _ => new()
    };

    private static BsonDocument SumBaseProjection(SubscriptionType type) => new()
    {
        { nameof(SumItem.Date), "$query.date" },
        { nameof(SumItem.SubscriptionId), "$subscription_id" },
        { nameof(SumItem.Source), new BsonDocument("$literal", type.ToString()) }
    };

    private static BsonDocument SumEmotionsProjection(SubscriptionType type) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        { nameof(EmotionsSumItem.Anger), "$data.post_reactions_anger" },
        { nameof(EmotionsSumItem.Haha), "$data.post_reactions_haha" },
        { nameof(EmotionsSumItem.Like), "$data.post_reactions_like" },
        { nameof(EmotionsSumItem.Love), "$data.post_reactions_love" },
        { nameof(EmotionsSumItem.Pride), "$data.post_reactions_pride" },
        { nameof(EmotionsSumItem.Sorry), "$data.post_reactions_sorry" },
        { nameof(EmotionsSumItem.Thankful), "$data.post_reactions_thankful" },
        { nameof(EmotionsSumItem.Wow), "$data.post_reactions_wow" }
    });

    private static BsonDocument BsonCountrySumItem(SubscriptionType type, BsonValue country, BsonValue followers, BsonValue percentage) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        { nameof(CountrySumItem.CountryCode), country },
        { nameof(CountrySumItem.Followers), followers },
        { nameof(CountrySumItem.Percentage), percentage },
        { nameof(CountrySumItem.GainedPercentage), BsonNull.Value }
    });

    private static BsonDocument BsonAgeGenderSumItem(SubscriptionType type, BsonValue age, BsonValue gender, BsonValue followers, BsonValue percentage) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        { nameof(AgeAndGenderSumItem.Age), age },
        { nameof(AgeAndGenderSumItem.Gender), gender },
        { nameof(AgeAndGenderSumItem.Followers), followers },
        { nameof(AgeAndGenderSumItem.Percentage), percentage }
    });

    private static BsonDocument BsonCampaignAgeGenderSumItem(SubscriptionType type, BsonValue campaignId, BsonValue age, BsonValue gender, BsonValue clicks, BsonValue conversions, BsonValue cost, BsonValue impressions, BsonValue views) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        { nameof(CampaignAgeAndGenderSumItem.CampaignId), campaignId },
        { nameof(CampaignAgeAndGenderSumItem.Age), age },
        { nameof(CampaignAgeAndGenderSumItem.Gender), gender },
        { nameof(CampaignAgeAndGenderSumItem.Clicks), clicks },
        { nameof(CampaignAgeAndGenderSumItem.Conversions), conversions },
        { nameof(CampaignAgeAndGenderSumItem.Cost), cost },
        { nameof(CampaignAgeAndGenderSumItem.Impressions), impressions },
        { nameof(CampaignAgeAndGenderSumItem.Views), views }
    });

    private static BsonDocument BsonPostsSumItem(SubscriptionType type, BsonValue name, BsonValue url, BsonValue time, BsonValue thumbnail, BsonValue postType, BsonValue comments, BsonValue likes, BsonValue message, BsonValue clicks, BsonValue shares, BsonValue views, BsonValue paid) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        { nameof(PostsSumItem.Name), name },
        { nameof(PostsSumItem.Url), url },
        { nameof(PostsSumItem.Time), time },
        { nameof(PostsSumItem.Thumbnail), thumbnail },
        { nameof(PostsSumItem.PostType), postType },
        { nameof(PostsSumItem.Comments), comments },
        { nameof(PostsSumItem.Likes), likes },
        { nameof(PostsSumItem.Message), message },
        { nameof(PostsSumItem.Clicks), clicks },
        { nameof(PostsSumItem.Shares), shares },
        { nameof(PostsSumItem.Views), views },
        { nameof(PostsSumItem.Paid), paid }
    });

    private static BsonDocument BsonCampaignsSumItem(SubscriptionType type, BsonValue startDate, BsonValue campaignId, BsonValue name, BsonValue status, BsonValue cost, BsonValue budget, BsonValue impressions, BsonValue clicks, BsonValue cpc, BsonValue ctr, BsonValue conversion) => SumBaseProjection(type).AddRange(new Dictionary<string, object>
    {
        { nameof(CampaignsSumItem.StartDate), startDate },
        { nameof(CampaignsSumItem.CampaignId), campaignId },
        { nameof(CampaignsSumItem.Name), name },
        { nameof(CampaignsSumItem.Status), status },
        { nameof(CampaignsSumItem.Cost), cost },
        { nameof(CampaignsSumItem.Budget), budget },
        { nameof(CampaignsSumItem.Impressions), impressions },
        { nameof(CampaignsSumItem.Clicks), clicks },
        { nameof(CampaignsSumItem.CPC), cpc },
        { nameof(CampaignsSumItem.CTR), ctr },
        { nameof(CampaignsSumItem.Conversion), conversion }
    });

    private static BsonDocument BsonDateToString(string fieldName, string format = "%Y-%m-%dT%H:%M:%S.%LZ") => new("$dateToString", new BsonDocument
    {
        { "date", fieldName },
        { "format", format }
    });

    private static BsonDocument BsonIfNull(string fieldName, BsonValue ifNullValue) => new("$ifNull", new BsonArray(new[] { fieldName, ifNullValue }));

    private static BsonDocument BsonIfNull(string fieldName, int ifNullValue) => BsonIfNull(fieldName, BsonLiteral(ifNullValue));

    private static BsonDocument BsonIfNullOrEmpty(string fieldName, string ifNullValue) => BsonCond(BsonAnd(new(new[] { BsonNe(fieldName, BsonNull.Value), BsonNe(fieldName, "") })), fieldName, BsonLiteral(ifNullValue));

    private static BsonDocument BsonCond(BsonValue cond, BsonValue onTrue, BsonValue onFalse) => new("$cond", new BsonArray(new[] { cond, onTrue, onFalse }));

    private static BsonDocument BsonAnd(BsonArray andList) => new("$and", andList);

    private static BsonDocument BsonConcat(params BsonValue[] items) => new("$concat", new BsonArray(items));

    private static BsonDocument BsonEq(string fieldName, BsonValue value) => new("$eq", new BsonArray(new[] { fieldName, value }));

    private static BsonDocument BsonNe(string fieldName, BsonValue value) => new("$ne", new BsonArray(new[] { fieldName, value }));

    private static BsonDocument BsonLiteral(BsonValue value) => new("$literal", value);

    private static BsonDocument BsonToLower(BsonValue value) => new("$toLower", value);
}