using System;
using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Helpers;

public class SumDaoRequest : DaoRequest
{
    public SumType SumType { get; set; }

    public SumDaoRequest()
    {
    }

    public SumDaoRequest(SumType sumType, string? subscriptionId, SubscriptionType subscriptionType, DateTime? startDate, DateTime? endDate) : base(subscriptionId, subscriptionType, startDate, endDate)
    {
        SumType = sumType;
    }

    public SumDaoRequest(SumDaoRequest request) : base(request)
    {
        SumType = request.SumType;
    }
}

