using SocialListeningCore;
using SocialListeningCore.Logging;
using SuperMetricsService.Jobs;
using SuperMetricsService.Persistence.ChannelInfo;
using SuperMetricsService.Persistence.Channels;
using SuperMetricsService.Persistence.Customers;
using SuperMetricsService.Persistence.Dashboard;
using SuperMetricsService.Persistence.Likes;
using SuperMetricsService.Persistence.Posts;
using SuperMetricsService.Persistence.Subscriptions;
using SuperMetricsService.Services.ChannelInfo;
using SuperMetricsService.Services.Customers;
using SuperMetricsService.Services.Dashboard;
using SuperMetricsService.Services.Likes;
using SuperMetricsService.Services.Posts;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "SuperMetricsService",
        EndpointName = "SuperMetricsService v1"
    }
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddScheduler(sb =>
    {
        sb.Services.AddStartupJob<InitDatabaseJob>();

        _ = sb.AddUnobservedTaskExceptionHandler(sp =>
        {
            var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger(MongoLogger.Name);
            return
                (sender, args) =>
                {
                    logger.MongoLogException(null, args.Exception);
                    args.SetObserved();
                };
        });
    });
};

builder.AddDependency<IChannelInfoService, ChannelInfoService>(ServiceLifetime.Scoped);
builder.AddDependency<ICustomersService, CustomersService>(ServiceLifetime.Scoped);
builder.AddDependency<ILikesService, LikesService>(ServiceLifetime.Scoped);
builder.AddDependency<IDashboardService, DashboardService>(ServiceLifetime.Scoped);
builder.AddDependency<IPostsService, PostsService>(ServiceLifetime.Scoped);

builder.AddDependency<IChannelInfoDao, ChannelInfoDao>(ServiceLifetime.Scoped);
builder.AddDependency<ICustomersDao, CustomersDao>(ServiceLifetime.Scoped);
builder.AddDependency<ILikesDao, LikesDao>(ServiceLifetime.Scoped);
builder.AddDependency<IDashboardDao, DashboardDao>(ServiceLifetime.Scoped);
builder.AddDependency<IPostsDao, PostsDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISubscriptionsDao, SubscriptionsDao>(ServiceLifetime.Scoped);
builder.AddDependency<IChannelDao, ChannelDao>(ServiceLifetime.Scoped);

var app = builder.Build();
await app.RunStartupJobsAync();
app.Run();