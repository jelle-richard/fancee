using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Responses.ChannelInfo;
using SuperMetricsService.Helpers.Queries.Channels;
using SuperMetricsService.Persistence.ChannelInfo;
using SuperMetricsService.Persistence.Subscriptions;

namespace SuperMetricsService.Services.ChannelInfo;

public class ChannelInfoService(IChannelInfoDao channelInfoDao, ISubscriptionsDao subscriptionsDao) : IChannelInfoService
{
    public async Task<ChannelReach> ChannelReachAsync(string channelId, DateTime? startDate, DateTime? endDate)
    {
        var channelReach = new ChannelReach();
        var subscriptions = (await subscriptionsDao.ToListByChannelIdAsync(channelId)).ToList();

        var subscription = subscriptions.FirstOrDefault(el => ChannelReachQuery.SubscriptionTypes.Contains(el.SubscriptionType));
        if (subscription != null)
            channelReach += await channelInfoDao.ChannelReachAsync(new(subscription.Id!, subscription.SubscriptionType, startDate, endDate)) ?? channelReach;

        var subscriptionExtra = subscriptions.FirstOrDefault(el => ChannelReachFollowersQuery.SubscriptionTypes.Contains(el.SubscriptionType));
        if (subscriptionExtra != null)
            channelReach += await channelInfoDao.ChannelReachFollowersAsync(new(subscriptionExtra.Id!, subscriptionExtra.SubscriptionType, startDate, endDate)) ?? channelReach;

        return channelReach;
    }

    public async Task<IEnumerable<ChannelGrowth>> ChannelGrowthAsync(string channelId)
    {
        var mainSubscription = await GetSubscriptionBySubscriptionType(subscriptionsDao, channelId, ChannelGrowthQuery.SubscriptionTypes);
        return await channelInfoDao.ChannelGrowthAsync(mainSubscription.Id!, mainSubscription.SubscriptionType);
    }

    private static async Task<Subscription> GetSubscriptionBySubscriptionType(ISubscriptionsDao subscriptionsDao, string channelId, SubscriptionType[] types)
    {
        var subscriptions = await subscriptionsDao.ToListByChannelIdAsync(channelId);

        return subscriptions.FirstOrDefault(el => types.Contains(el.SubscriptionType))
               ?? throw new SubscriptionNotFoundException();
    }
}