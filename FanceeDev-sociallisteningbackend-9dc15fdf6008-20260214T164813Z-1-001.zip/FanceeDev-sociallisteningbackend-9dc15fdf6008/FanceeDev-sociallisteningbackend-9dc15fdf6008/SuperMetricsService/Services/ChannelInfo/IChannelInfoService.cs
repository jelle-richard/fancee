﻿using SuperMetricsService.Dtos.Responses.ChannelInfo;

namespace SuperMetricsService.Services.ChannelInfo;

public interface IChannelInfoService
{
    /// <summary>
    /// Gets the usermetrics by channelId for Age and AgeAndGender and for General info.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<ChannelReach> ChannelReachAsync(string channelId, DateTime? startDate, DateTime? endDate);

    /// <summary>
    /// Gets the growthstatistics by channelId for the past 12 months.
    /// </summary>
    /// <param name="channelId"></param>
    /// <returns></returns>
    public Task<IEnumerable<ChannelGrowth>> ChannelGrowthAsync(string channelId);
}