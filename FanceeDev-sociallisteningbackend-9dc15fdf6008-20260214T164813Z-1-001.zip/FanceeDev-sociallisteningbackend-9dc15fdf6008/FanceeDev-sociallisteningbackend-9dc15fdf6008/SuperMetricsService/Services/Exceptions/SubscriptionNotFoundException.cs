using SocialListeningCore.Exceptions;

namespace SuperMetricsService.Services.Exceptions;

public class SubscriptionNotFoundException() 
    : NotFoundApiException("The requested objectId is not valid");