using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Dtos.Responses.Likes;

namespace SuperMetricsService.Services.Likes;

public interface ILikesService
{
    /// <summary>
    /// Gets the likes per country by the channelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<IEnumerable<GeoLikesStatistics>> GeoLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null);

    /// <summary>
    /// Gets the likes per day between the dates for a specific country by the channelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="countryCode"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<IEnumerable<LikesHistory>> CountryLikesAsync(string channelId, CountryCode countryCode, DateTime? startDate = null, DateTime? endDate = null);

    /// <summary>
    /// Gets the likes per gender between two dates by channelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<IEnumerable<GenderLikesStatistics>> GenderLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null);

    /// <summary>
    /// Gets the likesAmount, TotalLikes, TotalGained en improvementPercentage per country by the channelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<IEnumerable<GeoLikesStatistics>> GeoLikesWithGainsAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null);

    /// <summary>
    /// Gets the average likes per emotion (post_reactions) between the dates by the channelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<IEnumerable<EmotionLikes>> EmotionLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null);

    /// <summary>
    /// Gets the likes per age between two dates by channelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<IEnumerable<AgeLikesStatistics>> AgeLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null);
}