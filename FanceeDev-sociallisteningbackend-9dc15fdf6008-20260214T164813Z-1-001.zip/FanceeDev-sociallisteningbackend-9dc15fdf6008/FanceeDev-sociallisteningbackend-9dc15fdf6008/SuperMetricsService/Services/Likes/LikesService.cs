using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Helpers.Queries.Likes;
using SuperMetricsService.Persistence.Likes;
using SuperMetricsService.Persistence.Subscriptions;

namespace SuperMetricsService.Services.Likes;

public class LikesService(ILikesDao likesDao, ISubscriptionsDao subscriptionsDao) : ILikesService
{
    public async Task<IEnumerable<GeoLikesStatistics>> GeoLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null)
    {
        var subscription = await subscriptionsDao.FirstAsync(channelId, LikesPerCountryQuery.SubscriptionTypes);
        return await likesDao.GeoLikesAsync(new(subscription.Id!, subscription.SubscriptionType, startDate, endDate));
    }

    public async Task<IEnumerable<LikesHistory>> CountryLikesAsync(string channelId, CountryCode countryCode, DateTime? startDate = null, DateTime? endDate = null)
    {
        var subscription = await subscriptionsDao.FirstAsync(channelId, LikesPerCountryQuery.SubscriptionTypes);
        return await likesDao.CountryLikesAsync(new(subscription.Id!, subscription.SubscriptionType, startDate, endDate), countryCode);
    }

    public async Task<IEnumerable<GenderLikesStatistics>> GenderLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null)
    {
        var subscription = await subscriptionsDao.FirstAsync(channelId, LikesPerGenderQuery.SubscriptionTypes);
        return await likesDao.GenderLikesAsync(new(subscription.Id!, subscription.SubscriptionType, startDate, endDate));
    }

    public async Task<IEnumerable<GeoLikesStatistics>> GeoLikesWithGainsAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null)
    {
        var subscription = await subscriptionsDao.FirstAsync(channelId, LikesPerCountryQuery.SubscriptionTypes);
        var likesPerCountry = (await likesDao.GeoLikesAsync(new(subscription.Id!, subscription.SubscriptionType, startDate, endDate))).ToList();

        if (startDate is not { } startDateTime || endDate is not { } endDateTime)
            return likesPerCountry;

        var diffOfDates = (endDateTime - startDateTime).TotalDays;
        var startOfQuery = startDateTime.AddDays((diffOfDates + 1) * -1);
        var endOfQuery = startDateTime.AddDays(-1);
        var prevLikes = (await likesDao.GeoLikesAsync(new(subscription.Id!, subscription.SubscriptionType, startOfQuery, endOfQuery))).ToList();

        foreach (var like in likesPerCountry)
        {
            var previousLikeData = prevLikes.SingleOrDefault(item => item.CountryCode == like.CountryCode);
            if (previousLikeData == null)
                continue;

            UpdateGeoLikesGainedData(like, previousLikeData);
        }

        return likesPerCountry;
    }

    public async Task<IEnumerable<EmotionLikes>> EmotionLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null)
    {
        var subscription = await subscriptionsDao.FirstAsync(channelId, LikesPerEmotionQuery.SubscriptionTypes);
        return await likesDao.EmotionLikesAsync(new(subscription.Id!, subscription.SubscriptionType, startDate, endDate));
    }

    public async Task<IEnumerable<AgeLikesStatistics>> AgeLikesAsync(string channelId, DateTime? startDate = null, DateTime? endDate = null)
    {
        var subscription = await subscriptionsDao.FirstAsync(channelId, LikesPerAgeQuery.SubscriptionTypes);
        return await likesDao.AgeLikesAsync(new(subscription.Id!, subscription.SubscriptionType, startDate, endDate));
    }

    private static void UpdateGeoLikesGainedData(GeoLikesStatistics like, GeoLikesStatistics previousLikeData)
    {
        float diff = like.LikesGained - previousLikeData.LikesGained;
        float perc;
        if (previousLikeData.LikesGained != 0)
            perc = diff / previousLikeData.LikesGained * 100;
        else
            perc = diff * 100;

        if (previousLikeData.LikesGained < 0)
            perc *= -1;

        like.PreviousLikesGained = previousLikeData.LikesGained;
        like.ImprovementPercentage = perc;
    }
}