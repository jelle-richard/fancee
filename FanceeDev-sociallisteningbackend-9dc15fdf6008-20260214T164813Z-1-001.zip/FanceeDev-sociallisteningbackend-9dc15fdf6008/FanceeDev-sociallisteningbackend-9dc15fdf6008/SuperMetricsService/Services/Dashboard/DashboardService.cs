using System.Text.Json;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Sum;
using SocialListeningCore.Utils;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Dtos.Requests.Sum;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Dtos.Responses.Sum;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers;
using SuperMetricsService.Models;
using SuperMetricsService.Persistence.Channels;
using SuperMetricsService.Persistence.Dashboard;
using SuperMetricsService.Persistence.Likes;
using SuperMetricsService.Persistence.Posts;
using SuperMetricsService.Persistence.Subscriptions;

namespace SuperMetricsService.Services.Dashboard;

public class DashboardService(
    IDashboardDao dashboardDao,
    ILikesDao likesDao,
    IPostsDao postsDao,
    ISubscriptionsDao subscriptionsDao,
    IChannelDao ChannelDao
)
    : IDashboardService
{
    public async Task<SumResponse<GainedAndLostSumGroup>> SumGainedAndLostAsync(SumRequest request)
    {
        var sumHolder = new SumDictionaryItemHolder<GainedAndLostSumItem>(BasicSumDict<GainedAndLostSumItem>(request));

        await FillDictionaryHolder(sumHolder, request, (prevEntry, entry) =>
        {
            if (!sumHolder.Total.TryGetValue(entry.Date.ToString(DateFormat.YearMonthDay), out var subPairsList))
                return;

            subPairsList.Add(entry);
            if (prevEntry == null)
                return;
            var diff = entry.Value - prevEntry.Value ?? 0;
            if (diff < 0)
                entry.Lost = Math.Abs(diff);
            else
                entry.Gained = diff;
        });
        var sumList = sumHolder.Total.Select(item => new GainedAndLostSumGroup(item.Key, item.Value)).ToList();
        return new(new("first", sumHolder.First), new("last", sumHolder.Last), sumList);
    }

    public async Task<SumResponse<EngagementSumGroup>> SumEngagementAsync(SumRequest request)
    {
        var sumHolder = new SumDictionaryItemHolder<EngagementSumItem>(BasicSumDict<EngagementSumItem>(request));

        await FillDictionaryHolder(sumHolder, request, (_, entry) =>
        {
            if (sumHolder.Total.TryGetValue(entry.Date.ToString(DateFormat.YearMonthDay), out var subPairsList))
                subPairsList.Add(entry);
        });

        var sumList = sumHolder.Total.Select(item => new EngagementSumGroup(item.Key, item.Value)).ToList();
        return new(new("first", sumHolder.First), new("last", sumHolder.Last), sumList);
    }

    public async Task<IEnumerable<ChartSumItem<T>>> ChartAsync<T>(SumRequest request, bool usePadded = true, bool requestPreviousPeriod = true) where T : SumItem, new()
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<ChartSumItem<T>>();

        var dateDifference = request.EndDate.Subtract(request.StartDate);
        Channel? channel = null;
        foreach (var sub in subscriptions)
        {
            if (channel is null || sub.ChannelId != channel.Id)
                channel = await ChannelDao.ByIdAsync(sub.ChannelId!);

            var channelName = channel?.Name;
            var values = await dashboardDao.GetSumListAsync<T>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), null, usePadded);

            if (values is IEnumerable<PostsSumItem> postsSumItems)
            {
                foreach (var postsSumItem in postsSumItems)
                {
                    postsSumItem.Clicks = postsSumItem.Clicks != 0 ? postsSumItem.Clicks : null;
                    postsSumItem.Comments = postsSumItem.Comments != 0 ? postsSumItem.Comments : null;
                    postsSumItem.Shares = postsSumItem.Shares != 0 ? postsSumItem.Shares : null;
                    postsSumItem.Likes = postsSumItem.Likes != 0 ? postsSumItem.Likes : null;
                    postsSumItem.Views = postsSumItem.Views != 0 ? postsSumItem.Views : null;
                }
            }
            
            totalList.Add(new()
            {
                ChannelName = channelName,
                ChannelId = sub.ChannelId,
                SubscriptionId = sub.Id,
                SubscriptionType = sub.SubscriptionType,
                StartOfPreviousPeriod = requestPreviousPeriod ? await dashboardDao.GetSumFirstAsync<T>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate.AddDays(dateDifference.Days * -1), request.StartDate)) : default,
                Values = values
            });
        }

        return totalList;
    }

    public async Task<SumResponse<EmotionsSumGroup>> SumEmotionsAsync(SumRequest request)
    {
        var sumHolder = new SumDictionaryItemHolder<EmotionsSumItem>(BasicSumDict<EmotionsSumItem>(request));

        await FillDictionaryHolder(sumHolder, request, (_, entry) =>
        {
            if (sumHolder.Total.TryGetValue(entry.Date.ToString(DateFormat.YearMonthDay), out var subPairsList))
                subPairsList.Add(entry);
        });

        var sumList = sumHolder.Total.Select(item => new EmotionsSumGroup(item.Key, item.Value)).ToList();
        return new(new("first", sumHolder.First), new("last", sumHolder.Last), sumList);
    }

    public async Task<SumResponse<CommentsSumGroup>> CommentsAvgByDayAsync(SumRequest request)
    {
        var sumHolder = new SumDictionaryItemHolder<CommentsSumItem>(new()
        {
            { "Monday", [] },
            { "Tuesday", [] },
            { "Wednesday", [] },
            { "Thursday", [] },
            { "Friday", [] },
            { "Saturday", [] },
            { "Sunday", [] }
        });

        await FillDictionaryHolder(sumHolder, request, (_, entry) =>
        {
            if (sumHolder.Total.TryGetValue(entry.Date.ToString("dddd"), out var subPairsList))
                subPairsList.Add(entry);
        });

        var sumList = sumHolder.Total.Select(item => new CommentsSumGroup(item.Key, item.Value)).ToList();
        return new(new("first", sumHolder.First), new("last", sumHolder.Last), sumList);
    }

    public async Task<SumResponse<CommentsSumGroup>> CommentsAvgByHourAsync(SumRequest request)
    {
        var sumHolder = new SumDictionaryItemHolder<CommentsSumItem>();
        foreach (var i in Enumerable.Range(0, 24))
            sumHolder.Total.Add(i.ToString("00"), []);

        await FillDictionaryHolder(sumHolder, request, (_, entry) =>
        {
            if (sumHolder.Total.TryGetValue(entry.Hour, out var subPairsList))
                subPairsList.Add(entry);
        });

        var sumList = sumHolder.Total.Select(item => new CommentsSumGroup(item.Key, item.Value)).ToList();
        return new(new("first", sumHolder.First), new("last", sumHolder.Last), sumList);
    }

    public async Task<SumResponse<AgeAndGenderSumGroup>> SumGenderAsync(SumRequest request)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<GenderLikesStatistics>();
        foreach (var sub in subscriptions)
            totalList.AddRange(await likesDao.GenderLikesAsync(new(sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate)));

        return new(new("first", Array.Empty<AgeAndGenderSumItem>()), new("last", totalList.Select(t => new AgeAndGenderSumItem { Gender = t.Gender, Followers = t.LikesAmount })), Array.Empty<AgeAndGenderSumGroup>());
    }

    public async Task<SumResponse<AgeAndGenderSumGroup>> SumAgeAsync(SumRequest request)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<AgeLikesStatistics>();
        foreach (var sub in subscriptions)
            totalList.AddRange(await likesDao.AgeLikesAsync(new(sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate)));

        return new(new("first", Array.Empty<AgeAndGenderSumItem>()), new("last", totalList.Select(t => new AgeAndGenderSumItem { Age = t.Age, Followers = t.LikesAmount })), Array.Empty<AgeAndGenderSumGroup>());
    }

    public async Task<IEnumerable<AgeAndGenderSumItem>> AgeAndGendersAsync(SumRequest request) =>
        await AgeAndGenderAsync(request, (subscription, items) => items);

    public async Task<IEnumerable<AgeAndGenderSumItem>> GenderSumAsync(SumRequest request)
    {
        var subscriptions = (await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes())).ToList();
        var totalList = new List<AgeAndGenderSumItem>();
        var summedList = new List<AgeAndGenderSumItem>();
        foreach (var subscription in subscriptions)
            totalList.AddRange(await dashboardDao.GetSumListAsync<AgeAndGenderSumItem>(new(request.Type, subscription.Id, subscription.SubscriptionType, request.StartDate, request.EndDate), null, false));

        var totalSumOfPeople = totalList.Sum(i => i.Followers ?? 0m);
        var groupedByGender = totalList.GroupBy(i => i.Gender).ToList();

        foreach (var ageAndGenderSumItems in groupedByGender)
        {
            var genderGroupSum = ageAndGenderSumItems.Sum(g => g.Followers) ?? 0m;
            summedList.Add(new()
            {
                SubscriptionId = null,
                Source = null,
                Date = DateTime.UtcNow,
                IsPrediction = false,
                Age = null,
                Gender = ageAndGenderSumItems.Key,
                Followers = (int)genderGroupSum,
                Percentage = genderGroupSum != 0 || totalSumOfPeople != 0 ? Math.Round(genderGroupSum / totalSumOfPeople * 100m, 2) : 0
            });
        }

        return summedList;
    }

    public async Task<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>> AgeAndGendersChartAsync(SumRequest request) => await AgeAndGenderAsync(request, (subscription, items) => new ChartSumItem<AgeAndGenderSumItem>[]
    {
        new()
        {
            ChannelId = subscription.ChannelId,
            SubscriptionId = subscription.Id,
            SubscriptionType = subscription.SubscriptionType,
            Values = items
        }
    });

    public async Task<IEnumerable<ChartSumItem<CountrySumItem>>> CountriesChartAsync(SumRequest request)
    {
        var countries = await AllCountriesAsync(request);

        var ranking = countries.GroupBy(item => item.CountryCode)
            .Select(group => new CountryRank { CountryCode = group.Key, TotalFollowers = group.Sum(g => g.Followers ?? 0), Items = group.ToArray() })
            .OrderByDescending(item => item.TotalFollowers)
            .Take(10);

        return countries.GroupBy(item => item.ChannelId).Select(group =>
        {
            return new ChartSumItem<CountrySumItem>
            {
                ChannelId = group.Key,
                SubscriptionId = group.First().SubscriptionId,
                Values = ranking.Select(rank => new CountrySumItem { ChannelId = group.Key, CountryCode = rank.CountryCode, Followers = rank.Items?.FirstOrDefault(i => i.ChannelId == group.Key)?.Followers, Percentage = 0 })
            };
        });
    }

    public async Task<IEnumerable<CountrySumItem>> CountriesAsync(SumRequest request)
    {
        return (await AllCountriesAsync(request)).GroupBy(item => item.CountryCode)
            .Select(group =>
            {
                var last = group.Last();
                return new CountrySumItem
                {
                    CountryCode = group.Key,
                    ChannelId = null,
                    Date = last.Date,
                    Source = last.Source,
                    Followers = group.Sum(g => g.Followers),
                    Percentage = group.Average(g => g.Percentage) * 100,
                    GainedPercentage = group.Average(g => g.GainedPercentage) * 100
                };
            })
            .OrderByDescending(item => item.Percentage);
    }

    public async Task<ResultSetResponse<PostsSumItem>> PostsAsync(PaginatedSumRequest<PostField> request)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<PostsSumItem>();

        foreach (var sub in subscriptions)
        {
            var posts = await dashboardDao.GetSumListAsync<PostsSumItem>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), null, false);

            if (sub.SubscriptionType == SubscriptionType.YT2_VIDEO)
            {
                posts = posts.GroupBy(item => item.Name).Select(group => new PostsSumItem
                {
                    Name = group.Key,
                    Time = group.First().Time,
                    Url = group.First().Url,
                    Thumbnail = group.First().Thumbnail,
                    Message = group.First().Message,
                    PostType = group.First().PostType,
                    Paid = group.First().Paid,
                    Date = group.First().Date,
                    Source = group.First().Source,
                    SubscriptionId = sub.Id,
                    Likes = group.Sum(item => item.Likes),
                    Comments = group.Sum(item => item.Comments),
                    Shares = group.Sum(item => item.Shares),
                    Clicks = group.Sum(item => item.Clicks),
                    Views = group.Sum(item => item.Views)
                });
            }

            totalList.AddRange(posts);
        }

        return new()
        {
            TotalItems = totalList.Count,
            Items = totalList.FieldOrderBy(request.OrderBy, request.OrderByAscending).Skip(request.Skip).Take(request.Limit)
        };
    }

    public async Task<CampaignsSumItem> SumCampaignsAsync(SumRequest request)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var campaigns = new List<CampaignsSumItem>();

        foreach (var sub in subscriptions)
        {
            var sumlist = await dashboardDao.GetSumListAsync<CampaignsSumItem>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), SumTypeExtensions.ExtraProjection(nameof(CampaignsSumItem.ChannelId), sub.ChannelId), false);

            campaigns.AddRange(sumlist);
        }

        var groupedByStatus = campaigns.GroupBy(campaign => campaign.CampaignId)
            .Select(group => group.Last())
            .GroupBy(campaign => campaign.Status)
            .Select(group => new CampaignStatusItem { Label = group.Last().Status, Count = group.Count() });

        return new()
        {
            ChannelId = string.Join(",", campaigns.Select(campaign => campaign.ChannelId).Distinct()),
            CampaignId = string.Join(",", campaigns.Select(campaign => campaign.CampaignId).Distinct()),
            Name = string.Join(",", campaigns.Select(campaign => campaign.Name).Distinct()),
            Date = DateTime.UtcNow,
            StartDate = DateTime.UtcNow,
            Source = string.Join(",", campaigns.Select(campaign => campaign.Source).Distinct()),
            SubscriptionId = string.Join(",", campaigns.Select(campaign => campaign.SubscriptionId).Distinct()),
            Cost = campaigns.Sum(item => item.Cost),
            Budget = campaigns.Sum(item => item.Budget),
            Status = JsonSerializer.Serialize(groupedByStatus),
            Clicks = campaigns.Sum(item => item.Clicks),
            Impressions = campaigns.Sum(item => item.Impressions),
            CPC = campaigns.Sum(item => item.CPC),
            CTR = campaigns.Sum(item => item.CTR),
            Conversion = campaigns.Sum(item => item.Conversion)
        };
    }

    public async Task<ResultSetResponse<CampaignsSumItem>> CampaignsAsync(PaginatedSumRequest<CampaignField> request)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<CampaignsSumItem>();

        foreach (var sub in subscriptions)
        {
            var campaigns = await dashboardDao.GetSumListAsync<CampaignsSumItem>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), SumTypeExtensions.ExtraProjection(nameof(CampaignsSumItem.ChannelId), sub.ChannelId), false);

            totalList.AddRange(campaigns.GroupBy(item => item.CampaignId).Select(group => new CampaignsSumItem
            {
                ChannelId = group.First().ChannelId,
                CampaignId = group.Key,
                Name = group.First().Name,
                Date = group.Last().Date,
                StartDate = group.First().StartDate,
                Source = group.First().Source,
                SubscriptionId = sub.Id,
                Cost = group.Sum(item => item.Cost),
                Budget = group.Sum(item => item.Budget),
                Status = group.Last().Status,
                Clicks = group.Sum(item => item.Clicks),
                Impressions = group.Sum(item => item.Impressions),
                CPC = group.Sum(item => item.CPC),
                CTR = group.Sum(item => item.CTR),
                Conversion = group.Sum(item => item.Conversion)
            }));
        }

        return new()
        {
            TotalItems = totalList.Count,
            Items = totalList.FieldOrderBy(request.OrderBy, request.OrderByAscending).Skip(request.Skip).Take(request.Limit)
        };
    }

    public async Task<IEnumerable<CampaignsSumItem>> CampaignAsync(SumRequest request, string campaignId) => await SumCampaignAsync<CampaignsSumItem>(request, campaignId, SumType.Campaigns);

    public async Task<IEnumerable<CampaignAgeAndGenderSumItem>> CampaignAgeAndGenderAsync(SumRequest request, string campaignId)
    {
        var items = await SumCampaignAsync<CampaignAgeAndGenderSumItem>(request, campaignId, request.Type);
        return items.GroupBy(CampaignAgeAndGendersSelector(request.Type))
            .OrderBy(group => group.Key)
            .Select(group =>
            {
                var first = group.First();

                return new CampaignAgeAndGenderSumItem
                {
                    Source = first.Source,
                    SubscriptionId = first.SubscriptionId,
                    CampaignId = first.CampaignId,
                    Date = first.Date,
                    Age = first.Age,
                    Gender = first.Gender,
                    Clicks = group.Sum(g => g.Clicks),
                    Conversions = group.Sum(g => g.Conversions),
                    Cost = group.Sum(g => g.Cost),
                    Impressions = group.Sum(g => g.Impressions),
                    Views = group.Sum(g => g.Views)
                };
            });
    }

    public async Task<IEnumerable<TopKeyword>> HashtagsAsync(SumRequest request) => await TopKeywordsAsync(request, KeywordCategory.HASH);

    public async Task<IEnumerable<TopKeyword>> MentionsAsync(SumRequest request) => await TopKeywordsAsync(request, KeywordCategory.TAG);

    public async Task<IEnumerable<TopKeyword>> CaptionsAsync(SumRequest request) => await TopKeywordsAsync(request, KeywordCategory.CAPTION);

    public async Task<IEnumerable<ChartSumItem<TopKeyword>>> TopKeywordsChartAsync(SumRequest request, KeywordCategory category)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<ChartSumItem<TopKeyword>>();

        foreach (var sub in subscriptions)
        {
            totalList.Add(new()
            {
                ChannelId = sub.ChannelId,
                SubscriptionId = sub.Id,
                SubscriptionType = sub.SubscriptionType,
                Values = await postsDao.TopKeywordsAsync(new(sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), category)
            });
        }

        return totalList;
    }

    public async Task<IEnumerable<ChartSumItem<CampaignsSumItem>>> CampaignsChartAsync(SumRequest request)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<ChartSumItem<CampaignsSumItem>>();

        foreach (var sub in subscriptions)
        {
            var sumlist = await dashboardDao.GetSumListAsync<CampaignsSumItem>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), SumTypeExtensions.ExtraProjection(nameof(CampaignsSumItem.ChannelId), sub.ChannelId), false);

            var groupedByDate = sumlist.GroupBy(campaign => campaign.Date)
                .Select(group => new CampaignsSumItem
                {
                    SubscriptionId = sub.Id,
                    ChannelId = group.Last().ChannelId,
                    Date = group.Last().Date,
                    StartDate = group.Last().StartDate,
                    CampaignId = string.Join(",", group.Select(campaign => campaign.CampaignId).Distinct()),
                    Source = group.Last().Source,
                    Status = group.Last().Status,
                    Cost = group.Sum(item => item.Cost),
                    Budget = group.Sum(item => item.Budget),
                    Clicks = group.Sum(item => item.Clicks),
                    Impressions = group.Sum(item => item.Impressions),
                    CPC = group.Sum(item => item.CPC),
                    CTR = group.Sum(item => item.CTR),
                    Conversion = group.Sum(item => item.Conversion)
                });

            totalList.Add(new()
            {
                ChannelId = sub.ChannelId,
                SubscriptionId = sub.Id,
                SubscriptionType = sub.SubscriptionType,
                Values = groupedByDate
            });
        }

        return totalList;
    }

    private async Task<IEnumerable<T>> AgeAndGenderAsync<T>(SumRequest request, Func<Subscription, IEnumerable<AgeAndGenderSumItem>, IEnumerable<T>> fillerFunc)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<T>();

        foreach (var sub in subscriptions)
        {
            var ageGroups = await dashboardDao.GetSumListAsync<AgeAndGenderSumItem>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), null, false);
            var lastAgeGroups = ageGroups.Where(item => item.Followers != null || item.Percentage != null)
                .OrderBy(item => item.Date)
                .GroupBy(AgeAndGendersSelector(request.Type))
                .Select(group => group.Last())
                .ToList();

            decimal sumFollowers = lastAgeGroups.Sum(group => group.Followers ?? 0);
            var fullPercentage = 0m;
            foreach (var group in lastAgeGroups)
            {
                group.Followers ??= Convert.ToInt32(Math.Round(sumFollowers * (group.Percentage ?? 0.00m), MidpointRounding.AwayFromZero));

                if (group.Percentage == null && group.Followers > 0)
                {
                    group.Percentage = Math.Round((group.Followers ?? 0m) / sumFollowers * 100m, 2);
                    fullPercentage += group.Percentage.Value;
                }
            }

            if (Math.Round(fullPercentage, MidpointRounding.ToZero) is not (100 and >= 1))
            {
                foreach (var group in lastAgeGroups)
                    group.Percentage *= 100;
            }

            totalList.AddRange(fillerFunc(sub, lastAgeGroups));
        }

        return totalList;
    }

    private async Task<IEnumerable<CountrySumItem>> AllCountriesAsync(SumRequest request)
    {
        var relevantTotalsDict = await MostRelevantTotalFollowers(request);
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());

        var totalList = new List<CountrySumItem>();
        foreach (var sub in subscriptions)
        {
            var totalFollowersEntry = relevantTotalsDict.FirstOrDefault(item => item.Key.ChannelId == sub.ChannelId).Value;

            var countrySumItems = await dashboardDao.GetSumListAsync<CountrySumItem>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), SumTypeExtensions.ExtraProjection(nameof(CountrySumItem.ChannelId), sub.ChannelId), false);

            totalList.AddRange(CalculateFollowerGains(countrySumItems, totalFollowersEntry?.Value ?? 0).ToList());
        }

        return totalList;
    }

    private static decimal CalculateGainedPercentage(CountrySumItem first, CountrySumItem last)
    {
        if (last.Percentage != null)
            return (last.Percentage ?? 0) - (first.Percentage ?? 0);

        if (first.Followers == 0 || last.Followers == 0)
            return 0.00m;

        var firstFollowers = first.Followers ?? 0.00m;
        var difference = (last.Followers ?? 0.00m) - firstFollowers;

        return difference == 0.00m || firstFollowers == 0.00m 
            ? 0.00m 
            : difference / firstFollowers;
    }

    private static IEnumerable<CountrySumItem> CalculateFollowerGains(IEnumerable<CountrySumItem> items, decimal totalFollowers)
    {
        return items.Where(item => item.Followers != null || item.Percentage != null).OrderBy(item => item.Date).GroupBy(item => item.CountryCode).Select(group =>
        {
            var first = group.First();
            var last = group.Last();

            return new CountrySumItem
            {
                SubscriptionId = last.SubscriptionId,
                ChannelId = last.ChannelId,
                CountryCode = last.CountryCode,
                Date = last.Date,
                Source = last.Source,
                Followers = last.Followers ?? Convert.ToInt32(Math.Round(totalFollowers * (last.Percentage ?? 0.00m), MidpointRounding.AwayFromZero)),
                Percentage = last.Percentage ?? (last.Followers == 0 || totalFollowers == 0.00m ? last.Percentage : last.Followers / totalFollowers),
                GainedPercentage = CalculateGainedPercentage(first, last)
            };
        });
    }

    private async Task<IEnumerable<TSumItem>> SumCampaignAsync<TSumItem>(SumRequest request, string campaignId, SumType type) where TSumItem : SumItem
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, type.ToSubscriptionTypes());
        var totalList = new List<TSumItem>();

        foreach (var sub in subscriptions)
            totalList.AddRange(await dashboardDao.GetCampaignSumListAsync<TSumItem>(new(type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), campaignId));

        return totalList;
    }

    private async Task<IEnumerable<TopKeyword>> TopKeywordsAsync(SumRequest request, KeywordCategory category)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());
        var totalList = new List<TopKeyword>();
        foreach (var sub in subscriptions)
            totalList.AddRange(await postsDao.TopKeywordsAsync(new(sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), category));

        return totalList.GroupBy(item => item.Word).Select(group => new TopKeyword(group.Key, group.Sum(groupItem => groupItem.Amount)));
    }

    private async Task<Dictionary<Subscription, GainedAndLostSumItem?>> MostRelevantTotalFollowers(SumRequest request)
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, SumType.Followers.ToSubscriptionTypes());
        var totalDict = new Dictionary<Subscription, GainedAndLostSumItem?>();

        foreach (var sub in subscriptions)
            totalDict.Add(sub, await dashboardDao.GetSumLastAsync<GainedAndLostSumItem>(new(SumType.Followers, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate)));

        return totalDict;
    }

    private async Task FillDictionaryHolder<TSumItem>(SumDictionaryItemHolder<TSumItem> sumDictionaryHolder, SumRequest request, Action<TSumItem?, TSumItem> fillerAction) where TSumItem : SumItem, new()
    {
        var subscriptions = await subscriptionsDao.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes());

        foreach (var sub in subscriptions)
        {
            var entries = await dashboardDao.GetSumListAsync<TSumItem>(new(request.Type, sub.Id, sub.SubscriptionType, request.StartDate, request.EndDate), null, false);
            var sumItems = entries as TSumItem[] ?? entries.ToArray();

            if (!sumItems.Any())
                continue;

            sumDictionaryHolder.First.Add(sumItems.First());
            sumDictionaryHolder.Last.Add(sumItems.Last());

            var prevEntry = default(TSumItem);
            foreach (var entry in sumItems)
            {
                fillerAction(prevEntry, entry);
                prevEntry = entry;
            }
        }
    }

    private static Func<AgeAndGenderSumItem, object?> AgeAndGendersSelector(SumType type) => type switch
    {
        SumType.Age => item => item.Age,
        SumType.Gender => item => item.Gender,
        SumType.AgeAndGender => item => new { item.Age, item.Gender },
        _ => throw new NotSupportedException()
    };

    private static Func<CampaignAgeAndGenderSumItem, object?> CampaignAgeAndGendersSelector(SumType type) => type switch
    {
        SumType.Age => item => item.Age,
        SumType.Gender => item => item.Gender,
        SumType.AgeAndGender => item => new { item.Age, item.Gender },
        _ => throw new NotSupportedException()
    };

    private static Dictionary<string, List<TSumItem>> BasicSumDict<TSumItem>(SumRequest request, string filterFormat = DateFormat.YearMonthDay)
    {
        var subPairs = new Dictionary<string, List<TSumItem>>();
        for (var dt = request.StartDate; dt <= request.EndDate; dt = dt.AddDays(1))
            subPairs.TryAdd(dt.ToString(filterFormat), []);

        return subPairs;
    }
}