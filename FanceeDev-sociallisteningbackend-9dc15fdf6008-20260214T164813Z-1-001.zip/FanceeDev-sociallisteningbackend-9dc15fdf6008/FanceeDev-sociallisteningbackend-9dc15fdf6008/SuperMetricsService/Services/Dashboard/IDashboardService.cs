using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Sum;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Dtos.Requests.Sum;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Dtos.Responses.Sum;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Services.Dashboard;

public interface IDashboardService
{
    /// <summary>
    /// Gets a summary of 'gained', 'lost' and 'total' of a specific value between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A SumResponse object containing the first, last and total list of results</returns>
    public Task<SumResponse<GainedAndLostSumGroup>> SumGainedAndLostAsync(SumRequest request);

    /// <summary>
    /// Gets a summary of 'shares', 'comments' and 'likes' between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A SumResponse object containing the first, last and total list of results</returns>
    public Task<SumResponse<EngagementSumGroup>> SumEngagementAsync(SumRequest request);

    /// <summary>
    /// Gets a list of projected items, separated by subscription.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="request"></param>
    /// <param name="usePadded"></param>
    /// <param name="requestPreviousPeriod"></param>
    /// <returns></returns>
    public Task<IEnumerable<ChartSumItem<T>>> ChartAsync<T>(SumRequest request, bool usePadded = true, bool requestPreviousPeriod = true) where T : SumItem, new();

    /// <summary>
    /// Gets a list of posts from multiple channels between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A SumResponse object containing the first, last and total list of results</returns>
    public Task<SumResponse<EmotionsSumGroup>> SumEmotionsAsync(SumRequest request);

    /// <summary>
    /// Gets an average of 'comments' per 'day' (monday, tuesday, etc) between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A SumResponse object containing the first, last and total list of results</returns>
    public Task<SumResponse<CommentsSumGroup>> CommentsAvgByDayAsync(SumRequest request);

    /// <summary>
    /// Gets an average of 'comments' per 'hour' ("01", "02", "03", etc) between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A SumResponse object containing the first, last and total list of results</returns>
    public Task<SumResponse<CommentsSumGroup>> CommentsAvgByHourAsync(SumRequest request);

    /// <summary>
    /// Gets a "paginated" list of posts from multiple channels between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A ResultSetResponse object with the result list and pagination data.</returns>
    public Task<ResultSetResponse<PostsSumItem>> PostsAsync(PaginatedSumRequest<PostField> request);

    /// <summary>
    /// Get a sum of all the running campaigns, split by Status.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A single CampaignsSumItem</returns>
    public Task<CampaignsSumItem> SumCampaignsAsync(SumRequest request);

    /// <summary>
    /// Gets a "paginated" list of campaigns from multiple channels between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A ResultSetResponse object with the result list and pagination data</returns>
    public Task<ResultSetResponse<CampaignsSumItem>> CampaignsAsync(PaginatedSumRequest<CampaignField> request);

    /// <summary>
    /// Gets a complete list of campaignsSumitem for a specific campaign between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="campaignId"></param>
    /// <returns>A list of CampaignsSumItem</returns>
    public Task<IEnumerable<CampaignsSumItem>> CampaignAsync(SumRequest request, string campaignId);

    /// <summary>
    /// Gets a complete, ungrouped, list of CampaignAgeAndGenderSumItem, for a specific campaign between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="campaignId"></param>
    /// <returns>A list of CampaignAgeAndGenderSumItem</returns>
    public Task<IEnumerable<CampaignAgeAndGenderSumItem>> CampaignAgeAndGenderAsync(SumRequest request, string campaignId);

    /// <summary>
    /// Gets a complete, ungrouped, list of AgeAndGenderSumItem between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A list of AgeAndGenderSumItem</returns>
    public Task<IEnumerable<AgeAndGenderSumItem>> AgeAndGendersAsync(SumRequest request);

    /// <summary>
    /// Retrieves the total number of followers for all the given channels in the request, as well as the amount of different genders.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<IEnumerable<AgeAndGenderSumItem>> GenderSumAsync(SumRequest request);

    /// <summary>
    /// Gets a list of projected items, separated by subscription.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="request"></param>
    /// <returns>A list of ChartSumItems with AgeAndGenderSumItem values</returns>
    public Task<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>> AgeAndGendersChartAsync(SumRequest request);

    /// <summary>
    /// Gets a list of age / followers from multiple channels between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A SumResponse object containing the first, last and total list of results</returns>
    public Task<SumResponse<AgeAndGenderSumGroup>> SumAgeAsync(SumRequest request);

    /// <summary>
    /// Gets a list of gender / followers from multiple channels between a range of dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A SumResponse object containing the first, last and total list of results</returns>
    public Task<SumResponse<AgeAndGenderSumGroup>> SumGenderAsync(SumRequest request);

    /// <summary>
    /// Gets a list of used hashtags (#) from multiple sources.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A list of TopKeyword items</returns>
    public Task<IEnumerable<TopKeyword>> HashtagsAsync(SumRequest request);

    /// <summary>
    /// Gets a list of used mentions (@) from multiple sources.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A list of TopKeyword items</returns>
    public Task<IEnumerable<TopKeyword>> MentionsAsync(SumRequest request);

    /// <summary>
    /// Gets a list of words where every character is capitalized.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A list of TopKeyword items</returns>
    public Task<IEnumerable<TopKeyword>> CaptionsAsync(SumRequest request);

    /// <summary>
    /// Gets a list of countries from multiple sources.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>L list of CountrySumItem items</returns>
    public Task<IEnumerable<CountrySumItem>> CountriesAsync(SumRequest request);

    /// <summary>
    /// Get a top 10 list of countries for presentation in comparing charts and list.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A list of CountrySumItem grouped by Channel</returns>
    public Task<IEnumerable<ChartSumItem<CountrySumItem>>> CountriesChartAsync(SumRequest request);

    /// <summary>
    /// Get a list of TopKeywords, separed by channel and subscription, for social compare.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <returns>A list of ChartSumItem with TopKeywords</returns>
    public Task<IEnumerable<ChartSumItem<TopKeyword>>> TopKeywordsChartAsync(SumRequest request, KeywordCategory category);

    /// <summary>
    /// Get a summed list of CampaignsSumitems per channel.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>A list of ChartSumItem with CampaignsSumItems</returns>
    public Task<IEnumerable<ChartSumItem<CampaignsSumItem>>> CampaignsChartAsync(SumRequest request);
}