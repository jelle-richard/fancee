using FanceeAnalyticsData.Models.Analytics.Api;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Services.Posts;

public interface IPostsService
{
    /// <summary>
    /// Gets a list of posts between two dates.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<IEnumerable<Post>> ListAsync(ApiRequest request);

    /// <summary>
    /// Gets a list of top posts per category, e.g. top 5 posts with total reach between two dates.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <param name="amount"></param>
    /// <returns></returns>
    public Task<IEnumerable<Post>> TopListAsync(ApiRequest request, PostRequestCategory category, int amount);

    /// <summary>
    /// Gets a paginated list of posts, sorted by category.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<Post>> TopListPaginatedAsync(PaginatedRequest<ChannelAndDatesQueryFilter> request, PostRequestCategory category);

    /// <summary>
    /// Gets reach (or reactions, clicks) each day of week between two dates by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <returns>e.g. Mon 100 Tue 200 Wen 300</returns>
    public Task<IEnumerable<AvgPerDayOfWeek>> AvgPerDayOfWeekAsync(ApiRequest request, PostRequestCategory category);

    /// <summary>
    /// Gets reach (or reactions, clicks) each hour of day between two dates by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <returns>e.g. TH0 100, TH1 200, TH2 300</returns>
    public Task<IEnumerable<AvgPerHour>> AvgPerTimeOfDayAsync(ApiRequest request, PostRequestCategory category);

    /// <summary>
    /// Gets the top keywords between two dates.
    /// </summary>
    /// ///
    /// <param name="request"></param>
    /// ///
    /// <param name="category"></param>
    /// <returns></returns>
    public Task<IEnumerable<TopKeyword>> TopKeywordsAsync(ApiRequest request, KeywordCategory category);
}