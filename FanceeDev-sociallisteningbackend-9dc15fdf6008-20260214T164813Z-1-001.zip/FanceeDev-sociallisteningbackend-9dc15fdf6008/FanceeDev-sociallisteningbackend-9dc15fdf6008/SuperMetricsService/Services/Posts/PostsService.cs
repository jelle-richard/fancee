using FanceeAnalyticsData.Models.Analytics.Api;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers.Queries.Posts;
using SuperMetricsService.Persistence.Posts;
using SuperMetricsService.Persistence.Subscriptions;

namespace SuperMetricsService.Services.Posts;

public class PostsService(IPostsDao postsDao, ISubscriptionsDao subscriptionsDao) : IPostsService
{
    public async Task<IEnumerable<Post>> ListAsync(ApiRequest request)
    {
        var subscription = await subscriptionsDao.FirstAsync(request.ChannelId, TopPostsQuery.SubscriptionTypes);
        return await postsDao.ToListAsync(new(subscription.Id!, subscription.SubscriptionType, request.StartDate, request.EndDate));
    }

    public async Task<IEnumerable<Post>> TopListAsync(ApiRequest request, PostRequestCategory category, int amount)
    {
        var subscription = await subscriptionsDao.FirstAsync(request.ChannelId, TopPostsQuery.SubscriptionTypes);
        return await postsDao.TopListAsync(new(subscription.Id!, subscription.SubscriptionType, request.StartDate, request.EndDate), category, amount);
    }

    public async Task<ResultSetResponse<Post>> TopListPaginatedAsync(PaginatedRequest<ChannelAndDatesQueryFilter> request, PostRequestCategory category)
    {
        var subscription = await subscriptionsDao.FirstAsync(request.Options.ChannelId, TopPostsQuery.SubscriptionTypes);
        return await postsDao.TopListPaginatedAsync(new(subscription.Id!, subscription.SubscriptionType, request.Options.StartDate, request.Options.EndDate), category, request.PageSize, request.GetOffset());
    }

    public async Task<IEnumerable<AvgPerDayOfWeek>> AvgPerDayOfWeekAsync(ApiRequest request, PostRequestCategory category)
    {
        var subscription = await subscriptionsDao.FirstAsync(request.ChannelId, AvgPerDayOfWeekQuery.SubscriptionTypes);
        return await postsDao.AvgPerDayOfWeekAsync(new(subscription.Id!, subscription.SubscriptionType, request.StartDate, request.EndDate), category);
    }

    public async Task<IEnumerable<AvgPerHour>> AvgPerTimeOfDayAsync(ApiRequest request, PostRequestCategory category)
    {
        var subscription = await subscriptionsDao.FirstAsync(request.ChannelId, AvgPerTimeOfDayQuery.SubscriptionTypes);
        return await postsDao.AvgPerTimeOfDayAsync(new(subscription.Id!, subscription.SubscriptionType, request.StartDate, request.EndDate), category);
    }

    public async Task<IEnumerable<TopKeyword>> TopKeywordsAsync(ApiRequest request, KeywordCategory category)
    {
        var subscription = await subscriptionsDao.FirstAsync(request.ChannelId, TopKeywordsQuery.SubscriptionTypes);
        return await postsDao.TopKeywordsAsync(new(subscription.Id!, subscription.SubscriptionType, request.StartDate, request.EndDate), category);
    }
}