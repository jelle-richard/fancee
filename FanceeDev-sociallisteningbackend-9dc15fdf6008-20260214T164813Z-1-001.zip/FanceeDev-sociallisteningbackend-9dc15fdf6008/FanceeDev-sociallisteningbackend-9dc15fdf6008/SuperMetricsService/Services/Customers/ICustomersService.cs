﻿using SuperMetricsService.Dtos.Responses.Customers;

namespace SuperMetricsService.Services.Customers;

public interface ICustomersService
{
    /// <summary>
    /// Gets all the customers by subscriptionId.
    /// </summary>
    /// <param name="subscriptionId"></param>
    /// <returns></returns>
    public Task<IEnumerable<Customer>> CustomersInformationAsync(string subscriptionId);
}