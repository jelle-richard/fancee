﻿using SuperMetricsService.Dtos.Responses.Customers;
using SuperMetricsService.Persistence.Customers;

namespace SuperMetricsService.Services.Customers;

public class CustomersService(ICustomersDao customersDao) : ICustomersService
{
    public async Task<IEnumerable<Customer>> CustomersInformationAsync(string subscriptionId) => await customersDao.CustomersInformationAsync(subscriptionId);
}