using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Dtos.Dashboard;

namespace SuperMetricsService.Models;

public class CountryRank
{
    public CountryCode? CountryCode { get; set; }
    public int TotalFollowers { get; set; } = 0;
    public IEnumerable<CountrySumItem>? Items { get; set; }
}