using System;
using System.Text.Json.Serialization;

namespace SuperMetricsService.Models;

public class CampaignStatusItem
{
    [JsonPropertyName("label")]
    public string? Label { get; set; }

    [JsonPropertyName("count")]
    public int Count { get; set; }
}