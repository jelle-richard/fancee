﻿namespace SuperMetricsService.Enums;

public enum Emotion
{
    ANGER,
    HAHA,
    LIKE,
    LOVE,
    PRIDE,
    SORRY,
    THANKFUL,
    WOW
}