﻿namespace SuperMetricsService.Enums;

public enum Status
{
    ACTIVE,
    INACTIVE,
    PENDING,
    UNKNOWN
}