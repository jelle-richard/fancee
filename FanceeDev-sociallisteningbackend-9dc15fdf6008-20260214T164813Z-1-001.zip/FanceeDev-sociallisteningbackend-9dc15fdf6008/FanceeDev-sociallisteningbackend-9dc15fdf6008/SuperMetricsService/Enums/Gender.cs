namespace SuperMetricsService.Enums;

public enum Gender
{
    NEUTRAL,
    MALE,
    FEMALE,
    UNKNOWN
}