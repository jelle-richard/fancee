namespace SuperMetricsService.Enums;

public enum PostField
{
    Name,
    Date,
    Type,
    Likes,
    Shares,
    Views,
    Comments,
    Paid,
    Message,
    Clicks
}