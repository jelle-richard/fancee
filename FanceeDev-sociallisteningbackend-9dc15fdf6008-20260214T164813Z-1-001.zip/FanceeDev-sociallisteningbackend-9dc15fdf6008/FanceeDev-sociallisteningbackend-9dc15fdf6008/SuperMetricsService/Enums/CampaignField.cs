namespace SuperMetricsService.Enums;

public enum CampaignField
{
    Name,
    Date,
    StartDate,
    Cost,
    Budget,
    Status,
    Impressions,
    Clicks,
    CPC,
    CTR,
    Conversion
}