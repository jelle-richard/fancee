﻿namespace SuperMetricsService.Enums;

public enum PostRequestCategory
{
    REACH,
    LIKES,
    REACTION
}