﻿namespace SuperMetricsService.Enums;

public enum SumType
{
    Followers,
    Reach,
    Engagement,
    Comments,
    Posts,
    Emotions,
    Age,
    Gender,
    AgeAndGender,
    Keywords,
    Country,
    Campaigns
}