﻿namespace SuperMetricsService.Enums;

public enum KeywordCategory
{
    HASH,
    TAG,
    CAPTION,
    EMOJI
}