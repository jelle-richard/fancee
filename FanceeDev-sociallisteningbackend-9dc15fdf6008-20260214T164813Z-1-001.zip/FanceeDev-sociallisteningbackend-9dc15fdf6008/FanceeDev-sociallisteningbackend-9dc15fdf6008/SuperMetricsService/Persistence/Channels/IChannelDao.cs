using SocialListeningCore.Persistence;
using Channel = FanceeAnalyticsData.Models.Analytics.Channel;

namespace SuperMetricsService.Persistence.Channels;

public interface IChannelDao : IMongoDao<Channel>
{
    /// <summary>
    /// Retrieves a channel by channel id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<Channel?> ByIdAsync(string id);
}