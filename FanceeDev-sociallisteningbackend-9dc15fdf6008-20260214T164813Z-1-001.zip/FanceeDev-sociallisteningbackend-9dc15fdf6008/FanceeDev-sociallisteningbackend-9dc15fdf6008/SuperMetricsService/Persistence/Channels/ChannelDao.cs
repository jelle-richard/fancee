using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;

namespace SuperMetricsService.Persistence.Channels;

public class ChannelDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null)
    : MongoDao<Channel>(configuration.GetConnectionString("Mongo"), configuration.GetValue<string>("Mongo:Database:Default"),
        CollectionSettings.GetCollectionName("Channels"), mongoDatabase), IChannelDao
{
    public async Task<Channel?> ByIdAsync(string id)
    {
        var filter = Filter.Eq(dbItem => dbItem.Id, id);

        var cursor = await Collection.FindAsync(filter);
        return await cursor.FirstOrDefaultAsync();
    }
}