using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Persistence;
using SuperMetricsService.Dtos.Responses.Customers;

namespace SuperMetricsService.Persistence.Customers;

public interface ICustomersDao : IMongoDao<GenericEntry>
{
    /// <summary>
    /// Gets all the customers by subscriptionId.
    /// </summary>
    /// <param name="subscriptionId"></param>
    /// <returns></returns>
    public Task<IEnumerable<Customer>> CustomersInformationAsync(string subscriptionId);
}