using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SuperMetricsService.Dtos.Responses.Customers;
using SuperMetricsService.TestData;

namespace SuperMetricsService.Persistence.Customers;

public class CustomersDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<GenericEntry>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    null,
    mongoDatabase), ICustomersDao
{
    public async Task<IEnumerable<Customer>> CustomersInformationAsync(string subscriptionId) =>
        //@Michel, hier kan de informatie over de customer komen. Zie de Dto voor de informatie die we moeten hebben.
        await Task.Run(CustomersInformationFactory.GetCustomersInformation);
}