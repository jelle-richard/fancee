using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Persistence;
using SuperMetricsService.Dtos.Responses.ChannelInfo;

namespace SuperMetricsService.Persistence.ChannelInfo;

public interface IChannelInfoDao : IMongoDao<GenericEntry>
{
    /// <summary>
    /// Gets ChannelReach data such as "Shares", "Likes" and "Comments", depending on the requested channel type.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<ChannelReach?> ChannelReachAsync(DaoRequest request);

    /// <summary>
    /// Gets ChannelReach data for followers and follows (Instagram).
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<ChannelReach?> ChannelReachFollowersAsync(DaoRequest request);

    /// <summary>
    /// Gets the GrowthStatistics by subscriptionId for the past 12 months.
    /// </summary>
    /// <param name="subscriptionId"></param>
    /// <param name="channel"></param>
    /// <returns></returns>
    public Task<IEnumerable<ChannelGrowth>> ChannelGrowthAsync(string subscriptionId, SubscriptionType subscriptionType);
}