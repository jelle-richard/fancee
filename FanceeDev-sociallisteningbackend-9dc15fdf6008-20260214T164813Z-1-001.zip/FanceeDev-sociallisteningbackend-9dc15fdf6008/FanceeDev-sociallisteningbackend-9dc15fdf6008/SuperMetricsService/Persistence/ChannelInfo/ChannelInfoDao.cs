using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;
using SuperMetricsService.Dtos.Responses.ChannelInfo;
using SuperMetricsService.Helpers.Queries.Channels;

namespace SuperMetricsService.Persistence.ChannelInfo;

public class ChannelInfoDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<GenericEntry>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    null,
    mongoDatabase), IChannelInfoDao
{
    public async Task<ChannelReach?> ChannelReachAsync(DaoRequest request) =>
        await CreatePipelineAndGetAsync<ChannelReach>(
            new ChannelReachQuery(request).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType));

    public async Task<ChannelReach?> ChannelReachFollowersAsync(DaoRequest request) =>
        await CreatePipelineAndGetAsync<ChannelReach>(
            new ChannelReachFollowersQuery(request).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType));

    public async Task<IEnumerable<ChannelGrowth>> ChannelGrowthAsync(string subscriptionId, SubscriptionType subscriptionType) =>
        await CreatePipelineAndGetListAsync<ChannelGrowth>(
            new ChannelGrowthQuery(new()
            {
                SubscriptionId = subscriptionId,
                SubscriptionType = subscriptionType,
                StartDate = DateTime.UtcNow.AddMonths(-12),
                EndDate = DateTime.UtcNow
            }).Build(),
            CollectionSettings.GetCollectionName(subscriptionType));
}