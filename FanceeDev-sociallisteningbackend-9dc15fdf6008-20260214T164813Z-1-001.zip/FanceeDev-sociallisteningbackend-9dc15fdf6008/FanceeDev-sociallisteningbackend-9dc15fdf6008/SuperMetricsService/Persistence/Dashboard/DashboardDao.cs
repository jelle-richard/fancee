using FanceeAnalyticsData.Models.Analytics.Entries;
using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson;
using MongoDB.Driver;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;
using SuperMetricsService.Helpers;

namespace SuperMetricsService.Persistence.Dashboard;

public class DashboardDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<GenericEntry>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    null,
    mongoDatabase), IDashboardDao
{
    public async Task<IEnumerable<TSumItem>> GetSumListAsync<TSumItem>(SumDaoRequest request, BsonDocument? extraProjection = null, bool usePadded = true) where TSumItem : SumItem, new()
    {
        var paddedDaysList = usePadded ? SumItemPaddingHelper.BuildPaddedDaysObjectList<TSumItem>(request.StartDate!.Value, request.EndDate!.Value, request.SubscriptionId!) : new List<TSumItem>();
        var projection = request.SumType.ToProjection(request.SubscriptionType);

        if (extraProjection != null)
            projection.AddRange(extraProjection);
    
        var items = await GetProjectedListAsync<TSumItem>(request, projection);
    
        if (usePadded)
            items = items.UnionBy(paddedDaysList, i => i.Date.Date).OrderBy(i => i.Date);
    
        return items.ToList();
    }

    public async Task<TSumItem?> GetSumFirstAsync<TSumItem>(SumDaoRequest request, BsonDocument? extraProjection = null) => await GetSumSingleAsync<TSumItem>(request, true, extraProjection);

    public async Task<TSumItem?> GetSumLastAsync<TSumItem>(SumDaoRequest request, BsonDocument? extraProjection = null) => await GetSumSingleAsync<TSumItem>(request, false, extraProjection);

    public async Task<IEnumerable<TSumItem>> GetCampaignSumListAsync<TSumItem>(SumDaoRequest request, string campaignId)
    {
        var filter = Builders<GenericEntry>.Filter.And(EntryHelper.GetLookupDefinition<GenericEntry>(request.SubscriptionId, request.StartDate, request.EndDate), Builders<GenericEntry>.Filter.Eq(CampaignsHelper.FieldName(request.SubscriptionType), campaignId));
        var findOptions = CreateFindOptions<GenericEntry, TSumItem>(EntryHelper.GetSortDefinition<GenericEntry>(false), request.SumType.ToProjection(request.SubscriptionType));

        return await GetListAsync(filter, findOptions, CollectionSettings.GetCollectionName(request.SubscriptionType));
    }

    private async Task<TSumItem?> GetSumSingleAsync<TSumItem>(SumDaoRequest request, bool firstEntry = true, BsonDocument? extraProjection = null)
    {
        var projection = request.SumType.ToProjection(request.SubscriptionType);

        if (extraProjection != null)
            projection.AddRange(extraProjection);

        var sumItemList = (await GetProjectedListAsync<TSumItem>(request, projection, 1, firstEntry)).ToList();

        return sumItemList.Count == 0 ? default : sumItemList.First();
    }

    private async Task<IEnumerable<TProjection>> GetProjectedListAsync<TProjection>(SumDaoRequest request, ProjectionDefinition<GenericEntry, TProjection> projection, int? limit = null, bool descending = true)
    {
        var filter = EntryHelper.GetLookupDefinition<GenericEntry>(request.SubscriptionId, request.StartDate, request.EndDate);
        var findOptions = CreateFindOptions(EntryHelper.GetSortDefinition<GenericEntry>(descending), projection, limit);

        return await GetListAsync(filter, findOptions, CollectionSettings.GetCollectionName(request.SubscriptionType));
    }

    private static FindOptions<TModel, TProjection> CreateFindOptions<TModel, TProjection>(SortDefinition<TModel> sort, ProjectionDefinition<TModel, TProjection> projection, int? limit = null) => new()
    {
        Sort = sort,
        Projection = projection,
        Limit = limit
    };
}