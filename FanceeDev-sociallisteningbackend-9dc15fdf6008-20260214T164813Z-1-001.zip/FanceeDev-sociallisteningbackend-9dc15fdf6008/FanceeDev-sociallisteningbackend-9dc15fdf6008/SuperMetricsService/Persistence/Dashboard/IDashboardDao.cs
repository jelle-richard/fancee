using FanceeAnalyticsData.Models.Analytics.Entries;
using FanceeAnalyticsData.Models.Analytics.Sum;
using MongoDB.Bson;
using SocialListeningCore.Persistence;
using SuperMetricsService.Helpers;

namespace SuperMetricsService.Persistence.Dashboard;

public interface IDashboardDao : IMongoDao<GenericEntry>
{
    /// <summary>
    /// Gets a list of SumItems for a specific SumType.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="extraProjection"></param>
    /// <param name="usePadded"></param>
    /// <returns>A list of SumItems</returns>
    public Task<IEnumerable<TSumItem>> GetSumListAsync<TSumItem>(SumDaoRequest request, BsonDocument? extraProjection = null, bool usePadded = true) where TSumItem : SumItem, new();

    /// <summary>
    /// Gets the first entry from a list of SumItems for a specific SumType between two dates.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="extraProjection"></param>
    /// <returns>A list of SumItems</returns>
    public Task<TSumItem?> GetSumFirstAsync<TSumItem>(SumDaoRequest request, BsonDocument? extraProjection = null);

    /// <summary>
    /// Gets the last entry from a list of SumItems for a specific SumType between two dates.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="extraProjection"></param>
    /// <returns>A list of SumItems</returns>
    public Task<TSumItem?> GetSumLastAsync<TSumItem>(SumDaoRequest request, BsonDocument? extraProjection = null);

    /// <summary>
    /// Gets a list of SumItems for a specific SumType.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="campaignId"></param>
    /// <returns>A list of SumItems</returns>
    public Task<IEnumerable<TSumItem>> GetCampaignSumListAsync<TSumItem>(SumDaoRequest request, string campaignId);
}