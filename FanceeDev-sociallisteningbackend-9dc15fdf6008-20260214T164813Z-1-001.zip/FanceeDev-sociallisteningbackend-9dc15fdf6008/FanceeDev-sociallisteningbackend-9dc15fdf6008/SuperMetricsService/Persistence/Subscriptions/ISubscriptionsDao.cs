using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Persistence;

namespace SuperMetricsService.Persistence.Subscriptions;

public interface ISubscriptionsDao : IMongoDao<Subscription>
{
    /// <summary>
    /// Returns the first subscription for a given channelId from a list of subscriptionTypes.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="subscriptionTypes"></param>
    /// <returns></returns>
    public Task<Subscription> FirstAsync(string channelId, IEnumerable<SubscriptionType> subscriptionTypes);

    /// <summary>
    /// Returns a list of subscriptions linked to a given channel.
    /// </summary>
    /// <param name="channelId"></param>
    /// <returns>A list of subscriptions</returns>
    public Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId);

    /// <summary>
    /// Returns a list of subscriptions from a list of subscriptionIds.
    /// </summary>
    /// <param name="subscriptionIds"></param>
    /// <returns>A list of subscriptions</returns>
    public Task<IEnumerable<Subscription>> ToListFromSubscriptionIdsAsync(IEnumerable<string> subscriptionIds);

    /// <summary>
    /// Returns a list of subscriptions if it is owned by one of the channelIds, and matches one of the subscriptionTypes.
    /// </summary>
    /// <param name="channelIds"></param>
    /// <param name="subscriptionTypes"></param>
    /// <returns></returns>
    public Task<IEnumerable<Subscription>> ToListByTypeAndChannelIdsAsync(string[] channelIds, SubscriptionType[] subscriptionTypes);
}