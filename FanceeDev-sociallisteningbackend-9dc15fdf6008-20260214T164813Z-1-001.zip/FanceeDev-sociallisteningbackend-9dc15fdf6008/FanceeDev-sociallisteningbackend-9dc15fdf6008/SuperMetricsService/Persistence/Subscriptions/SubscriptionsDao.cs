using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Persistence;
using SocialListeningCore.Services.Cache;
using SocialListeningCore.Settings;

namespace SuperMetricsService.Persistence.Subscriptions;

public class SubscriptionsDao(IConfiguration configuration, ICacheService cacheService, IMongoDatabase? mongoDatabase = null) :
    MongoDao<Subscription>(configuration.GetConnectionString("Mongo"),
        configuration.GetValue<string>("Mongo:Database:Default"),
        CollectionSettings.GetCollectionName("Subscriptions"),
        mongoDatabase), ISubscriptionsDao
{
    public async Task<Subscription> FirstAsync(string channelId, IEnumerable<SubscriptionType> subscriptionTypes)
    {
        var filter = Filter.And(
            Filter.Eq(dbItem => dbItem.ChannelId, channelId),
            Filter.In(dbItem => dbItem.SubscriptionType, subscriptionTypes)
        );

        return await Collection.Find(filter).FirstOrDefaultAsync() ??
               throw new SubscriptionNotFoundException();
    }

    public async Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId)
    {
        return await ToList(Filter.Eq(dbItem => dbItem.ChannelId, channelId));
    }

    public async Task<IEnumerable<Subscription>> ToListFromSubscriptionIdsAsync(IEnumerable<string> subscriptionIds)
    {
        return await ToList(Filter.In(dbItem => dbItem.Id, subscriptionIds));
    }

    public async Task<IEnumerable<Subscription>> ToListByTypeAndChannelIdsAsync(string[] channelIds, SubscriptionType[] subscriptionTypes)
    {
        channelIds = channelIds.OrderDescending().ToArray();
        var cacheId = $"[{string.Join(",", channelIds)}]-{string.Join(",", subscriptionTypes)}";
        var subscriptions = await cacheService.GetCachedObjectAsync<IEnumerable<Subscription>>(cacheId);

        if (subscriptions != null)
            return subscriptions;

        var filter = Filter.And(
            Filter.In(dbItem => dbItem.ChannelId, channelIds),
            Filter.In(dbItem => dbItem.SubscriptionType, subscriptionTypes)
        );

        subscriptions = await ToList(filter);

        await cacheService.CacheObjectAsync(cacheId, subscriptions, 1);

        return subscriptions;
    }

    private async Task<IEnumerable<Subscription>> ToList(FilterDefinition<Subscription> filter)
    {
        var cursor = await Collection.FindAsync(filter);
        var subscriptions = await cursor.ToListAsync();

        if (!subscriptions.Any())
            throw new SubscriptionNotFoundException();

        return subscriptions;
    }
}