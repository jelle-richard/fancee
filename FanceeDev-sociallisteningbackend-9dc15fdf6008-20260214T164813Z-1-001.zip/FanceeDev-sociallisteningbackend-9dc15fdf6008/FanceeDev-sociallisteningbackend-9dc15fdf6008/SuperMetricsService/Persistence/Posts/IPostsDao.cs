using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Persistence;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;

namespace SuperMetricsService.Persistence.Posts;

public interface IPostsDao : IMongoDao<GenericEntry>
{
    /// <summary>
    /// Gets a list of posts between two dates by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<IEnumerable<Post>> ToListAsync(DaoRequest request);

    /// <summary>
    /// Gets a list of top posts based on category between two dates by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <param name="amount"></param>
    /// <returns></returns>
    public Task<IEnumerable<Post>> TopListAsync(DaoRequest request, PostRequestCategory category, int amount);

    /// <summary>
    /// Gets a paginated list of posts, sorted by category.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<Post>> TopListPaginatedAsync(DaoRequest request, PostRequestCategory category, int limit, int offset);

    /// <summary>
    /// Get reach (or reactions, clicks) each day of week between two dates by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <returns>e.g. Mon 100 Tue 200 Wen 300</returns>
    public Task<IEnumerable<AvgPerDayOfWeek>> AvgPerDayOfWeekAsync(DaoRequest request, PostRequestCategory category);

    /// <summary>
    /// Get reach (or reactions, clicks) each hour of day between two dates by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <returns>e.g. TH0 100, TH1 200, TH2 300</returns>
    public Task<IEnumerable<AvgPerHour>> AvgPerTimeOfDayAsync(DaoRequest request, PostRequestCategory category);

    /// <summary>
    /// Get the top keywords between two dates.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="category"></param>
    /// <returns></returns>
    public Task<IEnumerable<TopKeyword>> TopKeywordsAsync(DaoRequest request, KeywordCategory category);
}