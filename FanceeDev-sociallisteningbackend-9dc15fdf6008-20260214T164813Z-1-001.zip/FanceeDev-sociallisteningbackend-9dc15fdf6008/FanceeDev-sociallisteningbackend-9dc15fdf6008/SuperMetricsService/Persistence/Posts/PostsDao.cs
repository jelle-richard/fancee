using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers.Queries.Posts;

namespace SuperMetricsService.Persistence.Posts;

public class PostsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<GenericEntry>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    null,
    mongoDatabase), IPostsDao
{
    public async Task<IEnumerable<Post>> ToListAsync(DaoRequest request) =>
        await CreatePipelineAndGetListAsync<Post>(new PostsQuery(request).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType)
        );

    public async Task<IEnumerable<Post>> TopListAsync(DaoRequest request, PostRequestCategory category, int amount) =>
        await CreatePipelineAndGetListAsync<Post>(new TopPostsQuery(request, category, amount, 0).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType)
        );

    public async Task<ResultSetResponse<Post>> TopListPaginatedAsync(DaoRequest request, PostRequestCategory category, int limit, int offset) =>
        await CreatePipelineAndGetAsync<ResultSetResponse<Post>>(new TopPostsQuery(request, category, limit, offset, true).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType)
        ) ?? new ResultSetResponse<Post>(new List<Post>());

    public async Task<IEnumerable<AvgPerDayOfWeek>> AvgPerDayOfWeekAsync(DaoRequest request, PostRequestCategory category) =>
        await CreatePipelineAndGetListAsync<AvgPerDayOfWeek>(new AvgPerDayOfWeekQuery(request, category).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType)
        );

    public async Task<IEnumerable<AvgPerHour>> AvgPerTimeOfDayAsync(DaoRequest request, PostRequestCategory category) =>
        await CreatePipelineAndGetListAsync<AvgPerHour>(new AvgPerTimeOfDayQuery(request, category).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType)
        );

    public async Task<IEnumerable<TopKeyword>> TopKeywordsAsync(DaoRequest request, KeywordCategory category) =>
        await CreatePipelineAndGetListAsync<TopKeyword>(new TopKeywordsQuery(request, category).Build(),
            CollectionSettings.GetCollectionName(request.SubscriptionType)
        );
}