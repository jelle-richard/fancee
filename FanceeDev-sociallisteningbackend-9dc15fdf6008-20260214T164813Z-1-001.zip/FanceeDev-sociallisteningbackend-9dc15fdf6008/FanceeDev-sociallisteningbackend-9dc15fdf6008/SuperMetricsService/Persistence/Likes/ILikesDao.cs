using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Persistence;
using SuperMetricsService.Dtos.Responses.Likes;

namespace SuperMetricsService.Persistence.Likes;

public interface ILikesDao : IMongoDao<GenericEntry>
{
    /// <summary>
    /// Gets the likes per country by the subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<IEnumerable<GeoLikesStatistics>> GeoLikesAsync(DaoRequest request);

    /// <summary>
    /// Gets the likes per day between the dates for a specific country by the subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="countryCode"></param>
    /// <returns></returns>
    public Task<IEnumerable<LikesHistory>> CountryLikesAsync(DaoRequest request, CountryCode countryCode);

    /// <summary>
    /// Gets the likes per gender by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<IEnumerable<GenderLikesStatistics>> GenderLikesAsync(DaoRequest request);

    /// <summary>
    /// Gets the average likes per emotion (post_reactions) between the dates by the subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<IEnumerable<EmotionLikes>> EmotionLikesAsync(DaoRequest request);

    /// <summary>
    /// Gets the likes per age by subscriptionId.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<IEnumerable<AgeLikesStatistics>> AgeLikesAsync(DaoRequest request);
}