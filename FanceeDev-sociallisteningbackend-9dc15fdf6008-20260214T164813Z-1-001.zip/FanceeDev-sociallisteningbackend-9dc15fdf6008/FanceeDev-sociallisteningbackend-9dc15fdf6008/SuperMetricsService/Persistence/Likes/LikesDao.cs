using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Bson;
using MongoDB.Driver;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Helpers.Queries.Likes;

namespace SuperMetricsService.Persistence.Likes;

public class LikesDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) :
    MongoDao<GenericEntry>(configuration.GetConnectionString("Mongo"),
        configuration.GetValue<string>("Mongo:Database:Default"),
        null,
        mongoDatabase), ILikesDao
{
    public async Task<IEnumerable<GeoLikesStatistics>> GeoLikesAsync(DaoRequest request)
    {
        var pipelineStages = new LikesPerCountryQuery(request).Build();
        return await CreatePipelineAndGetListAsync<GeoLikesStatistics>(pipelineStages, CollectionSettings.GetCollectionName(request.SubscriptionType));
    }

    public async Task<IEnumerable<LikesHistory>> CountryLikesAsync(DaoRequest request, CountryCode countryCode)
    {
        var pipelineStages = new List<BsonDocument>
        {
            MongoHelper.MatchStage(request.SubscriptionId, request.StartDate, request.EndDate, new BsonElement[]
            {
                new("data.page_fans", new BsonDocument("$ne", BsonNull.Value)),
                new("data.country", countryCode.ToString())
            }),
            MongoHelper.SortStage(),
            MongoHelper.PipelineStage("$project", new BsonElement[]
            {
                new("_id", false),
                new("Date", "$data.Date"),
                new("LikesAmount", "$data.page_fans")
            })
        };

        return await CreatePipelineAndGetListAsync<LikesHistory>(pipelineStages, CollectionSettings.GetCollectionName(request.SubscriptionType));
    }

    public async Task<IEnumerable<GenderLikesStatistics>> GenderLikesAsync(DaoRequest request)
    {
        var pipelineStages = new LikesPerGenderQuery(request).Build();
        return await CreatePipelineAndGetListAsync<GenderLikesStatistics>(pipelineStages, CollectionSettings.GetCollectionName(request.SubscriptionType));
    }

    public async Task<IEnumerable<EmotionLikes>> EmotionLikesAsync(DaoRequest request)
    {
        var pipelineStages = new LikesPerEmotionQuery(request).Build();
        return await CreatePipelineAndGetListAsync<EmotionLikes>(pipelineStages, CollectionSettings.GetCollectionName(request.SubscriptionType));
    }

    public async Task<IEnumerable<AgeLikesStatistics>> AgeLikesAsync(DaoRequest request)
    {
        var pipelineStages = new LikesPerAgeQuery(request).Build();
        return await CreatePipelineAndGetListAsync<AgeLikesStatistics>(pipelineStages, CollectionSettings.GetCollectionName(request.SubscriptionType));
    }
}