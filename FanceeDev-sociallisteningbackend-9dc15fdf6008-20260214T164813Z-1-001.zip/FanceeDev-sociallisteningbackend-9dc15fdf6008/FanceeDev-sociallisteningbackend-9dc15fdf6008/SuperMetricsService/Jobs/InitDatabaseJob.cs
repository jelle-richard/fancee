using CronScheduler.Extensions.StartupInitializer;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Driver;
using SocialListeningCore.Settings;

namespace SuperMetricsService.Jobs;

/// <summary>
/// Initializes the MongoDB database with supportive indexes for fast(er) query execution.
/// </summary>
public class InitDatabaseJob(ILogger<InitDatabaseJob> logger, IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : IStartupJob
{
    private readonly IMongoDatabase _db = mongoDatabase ?? new MongoClient(configuration.GetConnectionString("Mongo")).GetDatabase(configuration.GetValue<string>("Mongo:Database:Default"));

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        logger.LogInformation("{job} started", nameof(InitDatabaseJob));

        List<Task> tasks =
        [
            AddGoogleTrendsIndexes(cancellationToken),
            AddFBInsightIndexes(SubscriptionType.FB, cancellationToken),
            AddFBInsightIndexes(SubscriptionType.FB_GEO_LIKES, cancellationToken),
            AddFBInsightIndexes(SubscriptionType.FB_AGE_AND_GENDER, cancellationToken),
            AddQueryIndexes(SubscriptionType.FB_POSTS, cancellationToken),
            AddQueryIndexes(SubscriptionType.GAWA, cancellationToken),
            AddQueryIndexes(SubscriptionType.GAWA_DEVICE, cancellationToken),
            AddQueryIndexes(SubscriptionType.GAWA_ECOM_ITEMS, cancellationToken),
            AddQueryIndexes(SubscriptionType.GAWA_ENGAGEMENT, cancellationToken),
            AddQueryIndexes(SubscriptionType.GAWA_PUBLISHING, cancellationToken),
            AddQueryIndexes(SubscriptionType.GAWA_TRAFFIC_ACQUISITION, cancellationToken),
            AddQueryIndexes(SubscriptionType.GAWA_USER_ACQUISITION, cancellationToken),
            AddQueryIndexes(SubscriptionType.IGI, cancellationToken),
            AddQueryIndexes(SubscriptionType.IGI_AGE_AND_GENDER, cancellationToken),
            AddQueryIndexes(SubscriptionType.IGI_CITY, cancellationToken),
            AddQueryIndexes(SubscriptionType.IGI_COUNTRY, cancellationToken),
            AddQueryIndexes(SubscriptionType.IGI_MEDIA, cancellationToken),
            AddQueryIndexes(SubscriptionType.IGI_PROFILE_DATA, cancellationToken),
            AddConnectionIndexes(cancellationToken)
        ];

        await Task.WhenAll(tasks);

        logger.LogInformation("{job} ended", nameof(InitDatabaseJob));
    }

    public Task AddGoogleTrendsIndexes(CancellationToken cancellationToken = default)
    {
        var coll = _db.GetCollection<GenericEntry>(CollectionSettings.GetCollectionName(SubscriptionType.GT));
        var indexKeys = Builders<GenericEntry>.IndexKeys;

        return coll.Indexes.CreateManyAsync(
            new[]
            {
                new CreateIndexModel<GenericEntry>(indexKeys.Descending("data.date")),
                new CreateIndexModel<GenericEntry>(indexKeys.Descending("query.date")),
                new CreateIndexModel<GenericEntry>(indexKeys.Ascending("data.search_term")),
                new CreateIndexModel<GenericEntry>(indexKeys.Ascending(dbItem => dbItem.SubscriptionId))
            }, cancellationToken
        );
    }

    public Task AddFBInsightIndexes(SubscriptionType type, CancellationToken cancellationToken = default)
    {
        var coll = _db.GetCollection<GenericEntry>(CollectionSettings.GetCollectionName(type));
        var indexKeys = Builders<GenericEntry>.IndexKeys;

        return coll.Indexes.CreateManyAsync(
            new[]
            {
                new CreateIndexModel<GenericEntry>(indexKeys.Descending("data.Date")),
                new CreateIndexModel<GenericEntry>(indexKeys.Descending("query.date")),
                new CreateIndexModel<GenericEntry>(indexKeys.Ascending("query.date_dayofweek")),
                new CreateIndexModel<GenericEntry>(indexKeys.Ascending("query.date_day")),
                new CreateIndexModel<GenericEntry>(indexKeys.Ascending("data.profileid")),
                new CreateIndexModel<GenericEntry>(indexKeys.Ascending(dbItem => dbItem.SubscriptionId))
            }, cancellationToken
        );
    }

    public Task AddConnectionIndexes(CancellationToken cancellationToken = default)
    {
        var coll = _db.GetCollection<Connection>(CollectionSettings.GetCollectionName("Connections"));
        var indexKeys = Builders<Connection>.IndexKeys;

        return coll.Indexes.CreateManyAsync(
            new[]
            {
                new CreateIndexModel<Connection>(indexKeys.Ascending(dbItem => dbItem.Input.DsAccounts)),
                new CreateIndexModel<Connection>(indexKeys.Ascending(dbItem => dbItem.Input.DsId)),
                new CreateIndexModel<Connection>(indexKeys.Ascending(dbItem => dbItem.Input.DsUser)),
                new CreateIndexModel<Connection>(indexKeys.Ascending(dbItem => dbItem.SubscriptionId))
            }, cancellationToken
        );
    }

    public Task AddQueryIndexes(SubscriptionType type, CancellationToken cancellationToken = default)
    {
        var coll = _db.GetCollection<GenericEntry>(CollectionSettings.GetCollectionName(type));
        var indexKeys = Builders<GenericEntry>.IndexKeys;

        return coll.Indexes.CreateManyAsync(
            new[]
            {
                new CreateIndexModel<GenericEntry>(indexKeys.Descending("query.date")),
                new CreateIndexModel<GenericEntry>(indexKeys.Ascending(dbItem => dbItem.SubscriptionId))
            }, cancellationToken
        );
    }
}