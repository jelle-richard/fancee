using System.Net.Mime;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Responses;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Dtos.Responses.Sum;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers;
using SuperMetricsService.Services.Dashboard;

namespace SuperMetricsService.Controllers;

[ApiController]
[Produces(MediaTypeNames.Application.Json)]
[Route("/[controller]")]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class DashboardController(IDashboardService dashboardService) : ControllerBase
{
    [HttpGet]
    [Route("followers")]
    [ProducesResponseType(typeof(ApiResponse<SumResponse<GainedAndLostSumGroup>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SumResponse<GainedAndLostSumGroup>>>> SumFollowers([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<SumResponse<GainedAndLostSumGroup>>
    {
        Data = await dashboardService.SumGainedAndLostAsync(new(SumType.Followers, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("reach")]
    [ProducesResponseType(typeof(ApiResponse<SumResponse<GainedAndLostSumGroup>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SumResponse<GainedAndLostSumGroup>>>> SumReach([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<SumResponse<GainedAndLostSumGroup>>
    {
        Data = await dashboardService.SumGainedAndLostAsync(new(SumType.Reach, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("engagement")]
    [ProducesResponseType(typeof(ApiResponse<SumResponse<EngagementSumGroup>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SumResponse<EngagementSumGroup>>>> SumEngagement([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<SumResponse<EngagementSumGroup>>
    {
        Data = await dashboardService.SumEngagementAsync(new(SumType.Engagement, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("comments_by_day")]
    [ProducesResponseType(typeof(ApiResponse<SumResponse<CommentsSumGroup>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SumResponse<CommentsSumGroup>>>> SumCommentsByDay([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<SumResponse<CommentsSumGroup>>
    {
        Data = await dashboardService.CommentsAvgByDayAsync(new(SumType.Comments, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("comments_by_hour")]
    [ProducesResponseType(typeof(ApiResponse<SumResponse<CommentsSumGroup>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SumResponse<CommentsSumGroup>>>> SumCommentsByHour([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<SumResponse<CommentsSumGroup>>
    {
        Data = await dashboardService.CommentsAvgByHourAsync(new(SumType.Comments, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("posts")]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<PostsSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<PostsSumItem>>>> Posts([FromQuery] PaginatedRequest<SumQueryFilter<PostField>> request)
    {
        var result = await dashboardService.PostsAsync(new(SumType.Posts, request.Options.ChannelIds, request.Options.StartDate, request.Options.EndDate, request.Options.OrderBy, request.Options.OrderByAscending, request.GetOffset(), request.PageSize));

        return Ok(new ApiResponse<PaginatedResponse<PostsSumItem>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("campaigns")]
    [ProducesResponseType(typeof(ApiResponse<ApiResponse<CampaignsSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<CampaignsSumItem>>> SumCampaigns([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<CampaignsSumItem>
    {
        Data = await dashboardService.SumCampaignsAsync(new(SumType.Campaigns, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("campaigns/list")]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<CampaignsSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<CampaignsSumItem>>>> Campaigns([FromQuery] PaginatedRequest<SumQueryFilter<CampaignField>> request)
    {
        var result = await dashboardService.CampaignsAsync(new(SumType.Campaigns, request.Options.ChannelIds, request.Options.StartDate, request.Options.EndDate, request.Options.OrderBy, request.Options.OrderByAscending, request.GetOffset(), request.PageSize));

        return Ok(new ApiResponse<PaginatedResponse<CampaignsSumItem>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("campaigns/{campaignId}")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<CampaignsSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<CampaignsSumItem>>>> Campaign(string campaignId, [FromQuery] string channelId, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<CampaignsSumItem>>
    {
        Data = await dashboardService.CampaignAsync(new(SumType.Campaigns, [channelId], startDate, endDate), campaignId)
    });

    [HttpGet]
    [Route("campaigns/{campaignId}/age")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>>> CampaignAge(string campaignId, [FromQuery] string channelId, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>
    {
        Data = await dashboardService.CampaignAgeAndGenderAsync(new(SumType.Age, [channelId], startDate, endDate), campaignId)
    });

    [HttpGet]
    [Route("campaigns/{campaignId}/gender")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>>> CampaignGender(string campaignId, [FromQuery] string channelId, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>
    {
        Data = await dashboardService.CampaignAgeAndGenderAsync(new(SumType.Gender, [channelId], startDate, endDate), campaignId)
    });

    [HttpGet]
    [Route("campaigns/{campaignId}/age-and-gender")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>>> CampaignAgeAndGender(string campaignId, [FromQuery] string channelId, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>
    {
        Data = await dashboardService.CampaignAgeAndGenderAsync(new(SumType.AgeAndGender, [channelId], startDate, endDate), campaignId)
    });

    [HttpGet]
    [Route("emotions")]
    [ProducesResponseType(typeof(ApiResponse<SumResponse<EmotionsSumGroup>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SumResponse<EmotionsSumGroup>>>> Emotions([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<SumResponse<EmotionsSumGroup>>
    {
        Data = await dashboardService.SumEmotionsAsync(new(SumType.Emotions, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("age")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AgeAndGenderSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AgeAndGenderSumItem>>>> Age([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<AgeAndGenderSumItem>>
    {
        Data = await dashboardService.AgeAndGendersAsync(new(SumType.Age, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("gender")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AgeAndGenderSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AgeAndGenderSumItem>>>> Gender([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<AgeAndGenderSumItem>>
    {
        Data = await dashboardService.AgeAndGendersAsync(new(SumType.Gender, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("gender/sum")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AgeAndGenderSumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AgeAndGenderSumItem>>>> GenderSum([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) =>
        Ok(new ApiResponse<IEnumerable<AgeAndGenderSumItem>>
        {
            Data = await dashboardService.GenderSumAsync(new(SumType.Gender, channelIds, startDate, endDate))
        });

    [HttpGet]
    [Route("hashtags")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TopKeyword>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<TopKeyword>>>> Hashtags([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<TopKeyword>>
    {
        Data = await dashboardService.HashtagsAsync(new(SumType.Keywords, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("mentions")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TopKeyword>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<TopKeyword>>>> Mentions([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<TopKeyword>>
    {
        Data = await dashboardService.MentionsAsync(new(SumType.Keywords, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("captions")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TopKeyword>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<TopKeyword>>>> Captions([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<TopKeyword>>
    {
        Data = await dashboardService.CaptionsAsync(new(SumType.Keywords, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("countries")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<CountrySumItem>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<CountrySumItem>>>> Countries([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<CountrySumItem>>
    {
        Data = await dashboardService.CountriesAsync(new(SumType.Country, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("countries/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<CountrySumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<CountrySumItem>>>>> CountriesChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<CountrySumItem>>>
    {
        Data = await dashboardService.CountriesChartAsync(new(SumType.Country, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("followers/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<GainedAndLostSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<GainedAndLostSumItem>>>>> FollowersChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
    {
        var charts = (await dashboardService.ChartAsync<GainedAndLostSumItem>(new(SumType.Followers, channelIds, startDate, endDate))).ToList();
        foreach (var chart in charts)
            FollowerChartCalculator.CalculateAndPredictMissingValues(chart);

        return Ok(new ApiResponse<IEnumerable<ChartSumItem<GainedAndLostSumItem>>>
        {
            Data = charts
        });
    }

    [HttpGet]
    [Route("reach/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<GainedAndLostSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<GainedAndLostSumItem>>>>> ReachChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<GainedAndLostSumItem>>>
    {
        Data = await dashboardService.ChartAsync<GainedAndLostSumItem>(new(SumType.Reach, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("engagement/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<EngagementSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<EngagementSumItem>>>>> EngagementChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<EngagementSumItem>>>
    {
        Data = await dashboardService.ChartAsync<EngagementSumItem>(new(SumType.Engagement, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("age/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>>>> AgeChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>>
    {
        Data = await dashboardService.AgeAndGendersChartAsync(new(SumType.Age, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("gender/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>>>> GenderChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<AgeAndGenderSumItem>>>
    {
        Data = await dashboardService.AgeAndGendersChartAsync(new(SumType.Gender, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("hashtags/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>>> HashtagsChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>
    {
        Data = await dashboardService.TopKeywordsChartAsync(new(SumType.Keywords, channelIds, startDate, endDate), KeywordCategory.HASH)
    });

    [HttpGet]
    [Route("mentions/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>>> MentionsChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>
    {
        Data = await dashboardService.TopKeywordsChartAsync(new(SumType.Keywords, channelIds, startDate, endDate), KeywordCategory.TAG)
    });

    [HttpGet]
    [Route("captions/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>>> CaptionsChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<TopKeyword>>>
    {
        Data = await dashboardService.TopKeywordsChartAsync(new(SumType.Keywords, channelIds, startDate, endDate), KeywordCategory.CAPTION)
    });

    [HttpGet]
    [Route("comments/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<CommentsSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<CommentsSumItem>>>>> CommentsChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<CommentsSumItem>>>
    {
        Data = await dashboardService.ChartAsync<CommentsSumItem>(new(SumType.Comments, channelIds, startDate, endDate), false)
    });

    [HttpGet]
    [Route("posts/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<PostsSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<PostsSumItem>>>>> PostsChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<PostsSumItem>>>
    {
        Data = await dashboardService.ChartAsync<PostsSumItem>(new(SumType.Posts, channelIds, startDate, endDate))
    });

    [HttpGet]
    [Route("campaigns/chart")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChartSumItem<CampaignsSumItem>>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChartSumItem<CampaignsSumItem>>>>> CampaignsChart([FromQuery] string[] channelIds, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate) => Ok(new ApiResponse<IEnumerable<ChartSumItem<CampaignsSumItem>>>
    {
        Data = await dashboardService.CampaignsChartAsync(new(SumType.Campaigns, channelIds, startDate, endDate))
    });
}