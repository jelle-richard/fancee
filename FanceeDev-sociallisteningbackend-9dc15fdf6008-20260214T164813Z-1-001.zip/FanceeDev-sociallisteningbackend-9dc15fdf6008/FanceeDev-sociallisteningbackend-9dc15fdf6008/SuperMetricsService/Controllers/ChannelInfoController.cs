using System.Net.Mime;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Responses.ChannelInfo;
using SuperMetricsService.Services.ChannelInfo;

namespace SuperMetricsService.Controllers;

[Authorize]
[ApiController]
[Route("/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class ChannelInfoController(IChannelInfoService channelInfoService) : ControllerBase
{
    [HttpGet]
    [Route("reach")]
    [ProducesResponseType(typeof(ApiResponse<ChannelReach>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ChannelReach>>> ChannelReach([FromQuery] string channelId, DateTime? startDate, DateTime? endDate)
    {
        if (!ObjectId.TryParse(channelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<ChannelReach>
        {
            Data = await channelInfoService.ChannelReachAsync(channelId, startDate, endDate)
        });
    }

    [HttpGet]
    [Route("growth")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<ChannelGrowth>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<ChannelGrowth>>>> ChannelGrowth([FromQuery] string channelId)
    {
        if (!ObjectId.TryParse(channelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<IEnumerable<ChannelGrowth>>
        {
            Data = await channelInfoService.ChannelGrowthAsync(channelId)
        });
    }
}