using System.Net.Mime;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Responses;
using SuperMetricsService.Dtos.Responses.Customers;
using SuperMetricsService.Services.Customers;

namespace SuperMetricsService.Controllers;

[ApiController]
[Produces(MediaTypeNames.Application.Json)]
[Route("/[controller]")]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class CustomersController(ICustomersService customersService) : ControllerBase
{
    [HttpGet]
    [Route("customers-information")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<Customer>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<Customer>>>> CustomersInformationAsync([FromQuery] string subscriptionId) =>
        Ok(new ApiResponse<IEnumerable<Customer>>
        {
            Data = await customersService.CustomersInformationAsync(subscriptionId)
        });
}