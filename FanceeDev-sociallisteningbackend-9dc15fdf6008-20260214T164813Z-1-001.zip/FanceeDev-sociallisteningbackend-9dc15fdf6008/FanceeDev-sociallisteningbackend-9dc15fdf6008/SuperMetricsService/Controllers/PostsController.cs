using System.Net.Mime;
using FanceeAnalyticsData.Models.Analytics.Api;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;
using SuperMetricsService.Services.Posts;

namespace SuperMetricsService.Controllers;

[ApiController]
[Route("/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class PostsController(IPostsService postsService) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<Post>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<Post>>>> List([FromQuery] ApiRequest request)
    {
        if (!ObjectId.TryParse(request.ChannelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<IEnumerable<Post>>
        {
            Data = await postsService.ListAsync(request)
        });
    }

    [HttpGet]
    [Route("top")]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<Post>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<Post>>>> TopPostsPaginated([FromQuery] PaginatedRequest<ChannelAndDatesQueryFilter> request, PostRequestCategory category)
    {
        var result = await postsService.TopListPaginatedAsync(request, category);

        return Ok(new ApiResponse<PaginatedResponse<Post>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("best-day-of-week")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AvgPerDayOfWeek>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AvgPerDayOfWeek>>>> BestDayOfWeek([FromQuery] ApiRequest request, PostRequestCategory category) =>
        Ok(new ApiResponse<IEnumerable<AvgPerDayOfWeek>>
        {
            Data = await postsService.AvgPerDayOfWeekAsync(request, category)
        });

    [HttpGet]
    [Route("best-time-hour")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AvgPerHour>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AvgPerHour>>>> BestTimeHour([FromQuery] ApiRequest request, PostRequestCategory category) =>
        Ok(new ApiResponse<IEnumerable<AvgPerHour>>
        {
            Data = await postsService.AvgPerTimeOfDayAsync(request, category)
        });

    [HttpGet]
    [Route("top-keywords")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<TopKeyword>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<TopKeyword>>>> TopKeywords([FromQuery] ApiRequest request, KeywordCategory category) =>
        Ok(new ApiResponse<IEnumerable<TopKeyword>>
        {
            Data = await postsService.TopKeywordsAsync(request, category)
        });
}