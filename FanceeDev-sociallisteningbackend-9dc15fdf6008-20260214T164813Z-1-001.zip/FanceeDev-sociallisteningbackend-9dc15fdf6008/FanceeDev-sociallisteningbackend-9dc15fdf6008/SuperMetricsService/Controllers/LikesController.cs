using System.Net.Mime;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Services.Likes;

namespace SuperMetricsService.Controllers;

[ApiController]
[Produces(MediaTypeNames.Application.Json)]
[Route("/[controller]")]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class LikesController(ILikesService likesService) : ControllerBase
{
    [HttpGet]
    [Route("geo")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<GeoLikesStatistics>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<GeoLikesStatistics>>>> GeoLikes([FromQuery] string channelId, [FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
    {
        if (!ObjectId.TryParse(channelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<IEnumerable<GeoLikesStatistics>>
        {
            Data = await likesService.GeoLikesWithGainsAsync(channelId, startDate, endDate)
        });
    }

    [HttpGet]
    [Route("geo/{countryCode}")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<LikesHistory>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<LikesHistory>>>> CountryLikesHistory([FromQuery] string channelId, CountryCode countryCode, [FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
    {
        if (!ObjectId.TryParse(channelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<IEnumerable<LikesHistory>>
        {
            Data = await likesService.CountryLikesAsync(channelId, countryCode, startDate, endDate)
        });
    }

    [HttpGet]
    [Route("gender")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<GenderLikesStatistics>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<GenderLikesStatistics>>>> GenderLikes([FromQuery] string channelId, [FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
    {
        if (!ObjectId.TryParse(channelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<IEnumerable<GenderLikesStatistics>>
        {
            Data = await likesService.GenderLikesAsync(channelId, startDate, endDate)
        });
    }

    [HttpGet]
    [Route("emotion")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EmotionLikes>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<EmotionLikes>>>> EmotionLikes([FromQuery] string channelId, [FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
    {
        if (!ObjectId.TryParse(channelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<IEnumerable<EmotionLikes>>
        {
            Data = await likesService.EmotionLikesAsync(channelId, startDate, endDate)
        });
    }

    [HttpGet]
    [Route("age")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<AgeLikesStatistics>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<AgeLikesStatistics>>>> AgeLikes([FromQuery] string channelId, [FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate)
    {
        if (!ObjectId.TryParse(channelId, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<IEnumerable<AgeLikesStatistics>>
        {
            Data = await likesService.AgeLikesAsync(channelId, startDate, endDate)
        });
    }
}