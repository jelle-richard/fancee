using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Dtos.Responses.Customers;
using SuperMetricsService.Enums;

namespace SuperMetricsService.TestData;

public static class CustomersInformationFactory
{
    public static List<Customer> GetCustomersInformation() =>
    [
        new()
        {
            CustomerId = "123abc",
            OrderId = "234bcd",
            AdressId = "345cde",
            FirstName = "Jan",
            LastName = "Janssen",
            UserName = "@jJansen",
            Gender = Gender.MALE,
            PhoneNumber = "0612345678",
            Email = "janjanssen@test.nl",
            Channel = ChannelType.GOOGLETRENDS,
            Age = 26,
            Status = Status.ACTIVE,
            EventName = "ADE",
            EventLink = "www.ade.nl",
            EventStart = DateTime.Now
        },
        new()
        {
            CustomerId = "abc123",
            OrderId = "bcd234",
            AdressId = "cde345",
            FirstName = "Sanne",
            LastName = "Samson",
            UserName = "@sSamson",
            Gender = Gender.FEMALE,
            PhoneNumber = "0612345678",
            Email = "sannesamson@test.nl",
            Channel = ChannelType.FACEBOOK,
            Age = 41,
            Status = Status.INACTIVE,
            EventName = "ADE",
            EventLink = "www.ade.nl",
            EventStart = DateTime.Now
        },
        new()
        {
            CustomerId = "987abc",
            OrderId = "876bcd",
            AdressId = "765cde",
            FirstName = "John",
            LastName = "Doe",
            UserName = "@JD",
            Gender = Gender.UNKNOWN,
            PhoneNumber = "0612345678",
            Email = "johndoe@test.nl",
            Channel = ChannelType.INSTAGRAM,
            Age = 38,
            Status = Status.PENDING,
            EventName = "ADE",
            EventLink = "www.ade.nl",
            EventStart = DateTime.Now
        }
    ];
}