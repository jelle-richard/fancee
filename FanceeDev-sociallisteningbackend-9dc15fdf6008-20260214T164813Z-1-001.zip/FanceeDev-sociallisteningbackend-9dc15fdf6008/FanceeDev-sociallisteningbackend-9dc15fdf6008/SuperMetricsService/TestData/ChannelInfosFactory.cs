﻿using SuperMetricsService.Dtos.Responses.ChannelInfo;

namespace SuperMetricsService.TestData;

public static class ChannelInfoFactory
{
    public static List<ChannelReach> GetChannelReach() =>
    [
        new()
        {
            TotalFollowers = 440,
            IncreasedFollowers = 40,
            PercentIncreaseFollowers = 10,
            Reach = 800,
            ActiveFollowers = 200,
            AverageAge = 45.5m,
            PercentMen = 60,
            PercentWomen = 30,
            Shares = 50,
            Likes = 90,
            Comments = 10,
            ClicksOnPage = 1098
        }
    ];

    public static List<ChannelGrowth> GetChannelGrowths()
    {
        var channels = new List<ChannelGrowth>();

        for (var i = 0; i < 10; i++)
        {
            channels.Add(new()
            {
                Date = DateTime.Now.AddDays(-i),
                Followers = i * 1000,
                Gained = i * 100,
                Lost = i * 10
            });
        }

        return channels;
    }
}