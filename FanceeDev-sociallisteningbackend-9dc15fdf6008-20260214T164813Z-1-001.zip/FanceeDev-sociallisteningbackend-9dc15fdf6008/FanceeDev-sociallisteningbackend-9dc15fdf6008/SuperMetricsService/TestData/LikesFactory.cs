﻿using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Enums;

namespace SuperMetricsService.TestData;

public static class LikesFactory
{
    public static EmotionLikes[] MockedEmotionLikes() =>
    [
        new()
        {
            Emotion = Emotion.HAHA,
            Amount = 500
        },
        new()
        {
            Emotion = Emotion.ANGER,
            Amount = 400
        },
        new()
        {
            Emotion = Emotion.LOVE,
            Amount = 300
        }
    ];

    public static GenderLikesStatistics[] MockGenderLikes() =>
    [
        new()
        {
            Gender = Gender.MALE.ToString(),
            LikesAmount = 2000
        },
        new()
        {
            Gender = Gender.FEMALE.ToString(),
            LikesAmount = 3000
        }
    ];

    public static AgeLikesStatistics[] MockedAgeLikes() =>
    [
        new()
        {
            Age = "10",
            LikesAmount = 3000
        },
        new()
        {
            Age = "20",
            LikesAmount = 4000
        },
        new()
        {
            Age = "30",
            LikesAmount = 6000
        }
    ];
}