﻿using SuperMetricsService.Dtos.Responses.Posts;

namespace SuperMetricsService.TestData;

public static class PostsFactory
{
    public static Post[] GetMockedPosts() =>
    [
        new()
        {
            Message = "post1",
            Date = new(2022, 10, 13, 2, 32, 1),
            TotalLikes = 100,
            TotalReach = 200,
            TotalReactions = 200
        },
        new()
        {
            Message = "post2",
            Date = new(2022, 10, 12, 23, 3, 14),
            TotalLikes = 300,
            TotalReach = 600,
            TotalReactions = 400
        }
    ];

    public static Post[] GetMockedTopPosts() =>
    [
        new()
        {
            Message = "post1",
            Date = new(2022, 10, 13, 2, 32, 1),
            TotalLikes = 10000,
            TotalReach = 10000,
            TotalReactions = 2000
        },
        new()
        {
            Message = "post2",
            Date = new(2022, 10, 12, 23, 3, 14),
            TotalLikes = 3000,
            TotalReach = 6000,
            TotalReactions = 400
        }
    ];

    public static AvgPerDayOfWeek[] GetMockedAvgPerDays() =>
    [
        new()
        {
            DayOfWeek = DayOfWeek.Monday,
            Average = 10000
        },
        new()
        {
            DayOfWeek = DayOfWeek.Tuesday,
            Average = 8000
        },
        new()
        {
            DayOfWeek = DayOfWeek.Wednesday,
            Average = 2000
        },
        new()
        {
            DayOfWeek = DayOfWeek.Thursday,
            Average = 9000
        },
        new()
        {
            DayOfWeek = DayOfWeek.Friday,
            Average = 5000
        },
        new()
        {
            DayOfWeek = DayOfWeek.Saturday,
            Average = 10000
        },
        new()
        {
            DayOfWeek = DayOfWeek.Sunday,
            Average = 9000
        }
    ];

    public static AvgPerHour[] GetMockedAvgPerHours() =>
    [
        new()
        {
            Hour = "01",
            Average = 100
        },
        new()
        {
            Hour = "02",
            Average = 200
        },
        new()
        {
            Hour = "03",
            Average = 300
        },
        new()
        {
            Hour = "04",
            Average = 400
        }
    ];

    public static List<TopKeyword> GetTopKeywords() =>
    [
        new("AWSLive", 2),
        new("BehindTheScenes", 1)
    ];
}