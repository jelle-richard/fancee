namespace FanceeAnalyticsData.Models;

public enum CollectionName
{
    Events,
    Clients,
    TicketingUsers
}