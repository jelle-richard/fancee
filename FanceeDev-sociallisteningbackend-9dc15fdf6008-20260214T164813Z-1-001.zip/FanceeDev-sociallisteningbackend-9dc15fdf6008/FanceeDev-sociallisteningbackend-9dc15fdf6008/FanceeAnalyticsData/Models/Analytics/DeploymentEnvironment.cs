namespace FanceeAnalyticsData.Models.Analytics;

public class DeploymentEnvironment : BasicMongoModel
{
    public string Name { get; set; } = string.Empty;

    public string Domain { get; set; } = string.Empty;

    public int? Port { get; set; }

    public string FrontendBaseUrl { get; set; } = string.Empty;
}