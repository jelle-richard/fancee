using System.Text.Json.Serialization;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

public class BasicCron : BasicMongoModel
{
    [JsonIgnore]
    [BsonIgnore]
    public virtual string? Name { get; set; }

    [BsonElement("cron")]
    public string? Cron { get; set; }

    [BsonIgnore]
    public bool Active { get; set; }

    [BsonElement("run_once")]
    public bool RunOnce { get; set; }
}