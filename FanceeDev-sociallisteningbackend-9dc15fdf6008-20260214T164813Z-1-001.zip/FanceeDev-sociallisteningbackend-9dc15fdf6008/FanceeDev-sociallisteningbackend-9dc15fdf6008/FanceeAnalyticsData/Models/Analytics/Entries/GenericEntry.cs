using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics.Entries;

[BsonIgnoreExtraElements]
public class GenericEntry : Entry
{
    [BsonElement("data")]
    public dynamic? Data { get; set; }

    [BsonElement("query")]
    public BsonDocument? Query { get; set; }

    public GenericEntry(SubscriptionType type) : base(type)
    {
    }
}