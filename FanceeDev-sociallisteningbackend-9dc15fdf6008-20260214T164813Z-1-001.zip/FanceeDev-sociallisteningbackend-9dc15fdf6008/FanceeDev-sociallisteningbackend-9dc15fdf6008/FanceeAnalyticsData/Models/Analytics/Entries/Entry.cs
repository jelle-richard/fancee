using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics.Entries;

public abstract class Entry : BasicMongoModel
{
    [BsonElement("subscription_id")]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? SubscriptionId { get; set; }

    [BsonElement("input_type")]
    public string SubscriptionType { get; set; }

    protected Entry(SubscriptionType type)
    {
        SubscriptionType = type.ToString();
    }
}