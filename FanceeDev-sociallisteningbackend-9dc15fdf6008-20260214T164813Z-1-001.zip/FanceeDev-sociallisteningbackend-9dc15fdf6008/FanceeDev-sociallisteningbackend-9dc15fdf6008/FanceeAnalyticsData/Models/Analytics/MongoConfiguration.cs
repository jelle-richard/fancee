using Microsoft.Extensions.Logging;
using MongoDB.Driver;

namespace FanceeAnalyticsData.Models.Analytics;

public class MongoConfiguration
{
    public string DatabaseName { get; set; }
    public IMongoClient Client { get; set; }
    public LogLevel MinLevel { get; set; }

    public MongoConfiguration(string db, IMongoClient client)
    {
        DatabaseName = db;
        Client = client;
    }
}