namespace FanceeAnalyticsData.Models.Analytics;

/// <summary>
/// All available user types.
/// Note: keep values as the power of 2 (1, 2, 4, 8, 16, ...) to avoid problems with bitwise operators.
/// </summary>
[Flags]
public enum UserType
{
    None = 0,
    Organization = 1 << 0,
    Ambassador = 1 << 1,
    Client = 1 << 2,
    Admin = 1 << 3,
    Host = 1 << 4,

    // Please keep this updated with new user types.
    All = Organization | Ambassador | Client | Admin | Host
}