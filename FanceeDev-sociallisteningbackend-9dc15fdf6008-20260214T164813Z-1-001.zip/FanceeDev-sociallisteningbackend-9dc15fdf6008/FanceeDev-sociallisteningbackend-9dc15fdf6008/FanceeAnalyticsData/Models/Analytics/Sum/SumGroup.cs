namespace FanceeAnalyticsData.Models.Analytics.Sum;

public abstract class SumGroup<TSumItem> where TSumItem : new()
{
    public string? Date { get; set; }
    public IEnumerable<TSumItem> Values { get; set; }
    protected int Count { get; set; }

    protected SumGroup(string date, IEnumerable<TSumItem> values)
    {
        Date = date;
        Values = values;
        Count = Values.Count();
    }
}