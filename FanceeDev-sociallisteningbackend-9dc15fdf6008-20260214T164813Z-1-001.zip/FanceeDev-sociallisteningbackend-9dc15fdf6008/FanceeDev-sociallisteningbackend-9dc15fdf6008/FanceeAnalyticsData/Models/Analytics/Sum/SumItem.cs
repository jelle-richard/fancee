using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics.Sum;

[BsonIgnoreExtraElements]
public abstract class SumItem
{
    [BsonRepresentation(BsonType.ObjectId)]
    public string? SubscriptionId { get; set; }

    public string? Source { get; set; }

    public DateTime Date { get; set; }

    public bool IsPrediction { get; set; }
}