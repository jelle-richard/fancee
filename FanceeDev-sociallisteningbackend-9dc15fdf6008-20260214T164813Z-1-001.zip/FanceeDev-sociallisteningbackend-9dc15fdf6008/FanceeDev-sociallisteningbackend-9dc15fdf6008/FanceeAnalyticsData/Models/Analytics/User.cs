using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

[BsonIgnoreExtraElements]
public class User : BasicMongoModel
{
    [BsonElement("user_id")]
    public Guid UserId { get; set; }

    [BsonElement("fancee_users_id")]
    public Guid FanceeUsersId { get; set; }

    [BsonElement("email")]
    public string Email { get; set; } = string.Empty;

    [BsonElement("type")]
    [BsonRepresentation(BsonType.String)]
    public UserType Type { get; set; }

    [BsonElement("first_name")]
    public string? FirstName { get; set; }

    [BsonElement("last_name")]
    public string? LastName { get; set; }

    [BsonElement("phone_number")]
    public string? PhoneNumber { get; set; }

    [BsonElement("is_verified")]
    public bool? IsVerified { get; set; }

    [BsonElement("last_login")]
    public DateTime? LastLogin { get; set; }

    [BsonRepresentation(BsonType.ObjectId)]
    public string? OrganizationId { get; set; }
}