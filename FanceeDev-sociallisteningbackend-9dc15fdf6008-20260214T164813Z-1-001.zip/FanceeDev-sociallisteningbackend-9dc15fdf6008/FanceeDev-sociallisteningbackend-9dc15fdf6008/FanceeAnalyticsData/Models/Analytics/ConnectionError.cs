using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

[BsonIgnoreExtraElements]
public class ConnectionError
{
    [BsonElement("code")]
    public string? Code { get; set; }

    [BsonElement("message")]
    public string? Message { get; set; }

    [BsonElement("description")]
    public string? Description { get; set; }
}