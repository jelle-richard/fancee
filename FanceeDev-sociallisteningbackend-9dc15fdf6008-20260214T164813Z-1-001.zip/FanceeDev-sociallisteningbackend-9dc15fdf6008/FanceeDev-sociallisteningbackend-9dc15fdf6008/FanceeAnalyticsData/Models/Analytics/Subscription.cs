using System.Text.Json.Serialization;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

[BsonIgnoreExtraElements]
public class Subscription : BasicCron
{
    [JsonIgnore]
    [BsonIgnore]
    public override string Name => $"{Id}-{SubscriptionType}-{(IsHistory ? "history" : "live")}{AdditionalInfo}";

    [JsonIgnore]
    [BsonIgnore]
    public string AdditionalInfo { get; set; }

    [BsonIgnoreIfDefault]
    [BsonIgnoreIfNull]
    [BsonElement("channel_id")]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? ChannelId { get; set; }

    [BsonElement("input")]
    public Input Input { get; set; }

    [JsonPropertyName("type")]
    [BsonElement("type")]
    [BsonRepresentation(BsonType.String)]
    public SubscriptionType SubscriptionType { get; set; }

    [JsonIgnore]
    [BsonIgnore]
    public bool IsHistory { get; set; }

    [BsonElement("fields")]
    public IEnumerable<Field>? Fields { get; set; }

    public Subscription()
    {
        AdditionalInfo = string.Empty;
        Active = false;
        RunOnce = false;
        IsHistory = false;
        Cron = "";
        Input = new();
    }
}