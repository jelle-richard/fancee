using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

public class Log : BasicMongoModel
{
    [BsonElement("level")]
    [BsonRepresentation(BsonType.String)]
    public LogLevel Level { get; set; }

    [BsonElement("message")]
    public string Message { get; set; }

    [BsonElement("exception")]
    public string? Exception { get; set; }

    [BsonElement("data")]
    public BsonValue? Data { get; set; }

    [BsonElement("user_id")]
    public Guid? UserId { get; set; }

    public Log(string message)
    {
        Message = message;
    }
}