namespace FanceeAnalyticsData.Models.Analytics;

public enum SendStatus
{
    InQueue,
    Sending,
    Sent,
    Failed
}