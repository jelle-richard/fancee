using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

[BsonIgnoreExtraElements]
public class BasicMongoModel
{
    [BsonId]
    [BsonIgnoreIfDefault]
    [BsonIgnoreIfNull]
    [BsonRepresentation(BsonType.ObjectId)]
    [JsonPropertyOrder(int.MinValue)]
    public string? Id { get; set; }

    [BsonElement("created_on")]
    public DateTime CreatedOn { get; set; }

    [BsonElement("updated_on")]
    public DateTime UpdatedOn { get; set; }

    public BasicMongoModel()
    {
        CreatedOn = DateTime.UtcNow;
        UpdatedOn = DateTime.UtcNow;
    }

    protected BasicMongoModel(BasicMongoModel model)
    {
        Id = model.Id;
        CreatedOn = model.CreatedOn;
        UpdatedOn = model.UpdatedOn;
    }
}