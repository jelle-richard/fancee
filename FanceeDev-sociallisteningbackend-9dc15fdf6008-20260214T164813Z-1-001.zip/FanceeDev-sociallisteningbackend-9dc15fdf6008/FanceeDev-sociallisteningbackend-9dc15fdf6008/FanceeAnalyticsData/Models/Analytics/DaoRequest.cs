namespace FanceeAnalyticsData.Models.Analytics;

public class DaoRequest
{
    public string? SubscriptionId { get; set; }
    public SubscriptionType SubscriptionType { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }

    public DaoRequest()
    {
    }

    public DaoRequest(string? subscriptionId, SubscriptionType subscriptionType, DateTime? startDate, DateTime? endDate)
    {
        SubscriptionId = subscriptionId;
        SubscriptionType = subscriptionType;
        StartDate = startDate;
        EndDate = endDate;
    }

    public DaoRequest(DaoRequest request)
    {
        SubscriptionId = request.SubscriptionId;
        SubscriptionType = request.SubscriptionType;
        StartDate = request.StartDate;
        EndDate = request.EndDate;
    }
}