using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using static FanceeAnalyticsData.Models.Analytics.SuperMetrics.Input;

namespace FanceeAnalyticsData.Models.Analytics;

public class SubscriptionSetting : BasicMongoModel
{
    [BsonElement("subscription_type")]
    [BsonRepresentation(BsonType.String)]
    public SubscriptionType SubscriptionType { get; set; }

    [BsonElement("split")]
    public string? Split { get; set; }

    [BsonElement("subscription_name")]
    public string? SubscriptionName { get; set; }

    [BsonElement("fields")]
    public string? Fields { get; set; }

    [BsonElement("filter")]
    public string? Filter { get; set; }

    [BsonElement("settings")]
    public InputSettings? Settings { get; set; }
}