namespace FanceeAnalyticsData.Models.Analytics;

public enum ChannelStatus
{
    Setup,
    Initiating,
    Active,
    PartiallyActive,
    Paused,
    Expired,
    Error
}