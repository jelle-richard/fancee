using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

[BsonIgnoreExtraElements]
public class PasswordReset : BasicMongoModel
{
    [BsonElement("token")]
    public Guid Token { get; set; }

    [BsonElement("expires_at")]
    public DateTime ExpiresAt { get; set; }

    public User User { get; set; }

    public PasswordReset(User user)
    {
        User = user;
    }
}