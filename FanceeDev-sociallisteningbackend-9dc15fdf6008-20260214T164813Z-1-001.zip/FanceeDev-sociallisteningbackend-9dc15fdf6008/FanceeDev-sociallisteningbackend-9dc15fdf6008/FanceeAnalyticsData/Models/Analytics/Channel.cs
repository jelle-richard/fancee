using System.Text.Json.Serialization;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

[BsonIgnoreExtraElements]
public class Channel : BasicMongoModel
{
    [BsonElement("type")]
    [BsonRepresentation(BsonType.String)]
    [JsonPropertyName("type")]
    public ChannelType ChannelType { get; set; }

    [BsonElement("status")]
    [BsonRepresentation(BsonType.String)]
    public ChannelStatus Status { get; set; } = ChannelStatus.Setup;

    [BsonElement(" has_error")]
    public bool HasError { get; set; }

    [BsonElement("name")]
    public string? Name { get; set; }

    [BsonElement("request")]
    public string? Request { get; set; }

    [BsonElement("request_display_name")]
    public string? RequestDisplayName { get; set; }

    [BsonElement("user_id")]
    public Guid UserId { get; set; }

    [BsonElement("owner")]
    public ChannelOwner? Owner { get; set; }

    public Channel()
    {
    }

    protected Channel(Channel channel) : base(channel)
    {
        UserId = channel.UserId;
        ChannelType = channel.ChannelType;
        Name = channel.Name;
        Status = channel.Status;
        Request = channel.Request;
        Owner = channel.Owner;
    }
}