using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

public class Organization : BasicMongoModel
{
    [BsonElement("email")]
    public string? Email { get; set; }

    [BsonElement("first_name")]
    public string? FirstName { get; set; }

    [BsonElement("last_name")]
    public string? LastName { get; set; }

    [BsonElement("organization_name")]
    public string? OrganizationName { get; set; }

    [BsonElement("country_of_operation")]
    [BsonRepresentation(BsonType.String)]
    public CountryCode CountryOfOperation { get; set; }

    [BsonElement("chamber_of_commerce")]
    public string? ChamberOfCommerce { get; set; }

    [BsonElement("iban")]
    public string? IBAN { get; set; }

    [BsonElement("bic")]
    public string? BIC { get; set; }

    [BsonElement("vat_identifier")]
    public string? VATIdentifier { get; set; }

    [BsonElement("user_id")]
    public Guid UserId { get; set; }
}