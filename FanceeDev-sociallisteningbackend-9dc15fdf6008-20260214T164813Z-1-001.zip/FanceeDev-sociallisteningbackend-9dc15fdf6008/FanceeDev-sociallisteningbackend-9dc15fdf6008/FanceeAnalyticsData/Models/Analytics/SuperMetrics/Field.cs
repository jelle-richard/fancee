using System.Globalization;
using System.Text.Json.Serialization;

namespace FanceeAnalyticsData.Models.Analytics.SuperMetrics;

public class Field
{
    [JsonPropertyName("field_id")]
    public string? Field_id { get; set; }

    [JsonPropertyName("field_name")]
    public string? Field_name { get; set; }

    [JsonPropertyName("field_type")]
    public string? Field_type { get; set; }

    [JsonPropertyName("field_split")]
    public string? Field_split { get; set; }

    [JsonPropertyName("format")]
    public string[]? Format { get; set; }

    [JsonPropertyName("data_type")]
    public string? Data_type { get; set; }

    [JsonPropertyName("data_column")]
    public int Data_column { get; set; }

    [JsonPropertyName("visible")]
    public bool Visible { get; set; }

    public object? Transform(dynamic fieldValue) => Transform(Data_type, fieldValue, out bool _);

    public static object? Transform(string dataType, dynamic fieldValue, out bool isValid)
    {
        isValid = true;
        try
        {
            switch (dataType)
            {
                case "float.currency.value":
                case "float.number.percentage":
                case "float.number.ratio":
                case "float.number.value":
                {
                    if (fieldValue is string)
                        return null;

                    return (double?)fieldValue;
                }

                case "int.currency.value":
                case "int.duration.seconds":
                case "int.number.percentage":
                case "int.number.value":
                {
                    if (fieldValue is string)
                        return null;

                    return (int?)fieldValue;
                }

                case "string.time.date":
                {
                    return DateTime.ParseExact((string)fieldValue,
                        "yyyy-MM-dd", CultureInfo.InvariantCulture);
                }

                case "string.time.datetime":
                {
                    return DateTime.ParseExact((string)fieldValue,
                        "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                }

                case "string.currency.code":
                case "string.geo.city":
                case "string.geo.continent":
                case "string.geo.coordinates":
                case "string.geo.country":
                case "string.geo.country.twolettercode":
                case "string.geo.metro":
                case "string.geo.region":
                case "string.geo.street":
                case "string.geo.zip":
                case "string.language.locale":
                case "string.language.twolettercode":
                case "string.language.value":
                case "string.person.age":
                case "string.person.gender":
                case "string.text.email":
                case "string.text.json":
                case "string.text.percentage":
                case "string.text.phone":
                case "string.text.url":
                case "string.text.value":
                case "string.time.dayofmonth":
                case "string.time.dayofweek":
                case "string.time.dayofweekiso":
                case "string.time.gmtoffset":
                case "string.time.hm":
                case "string.time.hms":
                case "string.time.hour":
                case "string.time.minute":
                case "string.time.month":
                case "string.time.quarter":
                case "string.time.timezone":
                case "string.time.week":
                case "string.time.weekiso":
                case "string.time.year":
                case "string.time.yearmonth":
                case "string.time.yearweek":
                case "string.time.yearweekiso":
                {
                    if (fieldValue is long l)
                        return l.ToString();

                    if (fieldValue is int i)
                        return i.ToString();

                    return (string?)fieldValue;
                }

                case "bool":
                {
                    return (bool?)fieldValue;
                }

                case "string.geo.latitude":
                case "string.geo.longitude":
                {
                    if (fieldValue is double d)
                        return d;

                    return (string?)fieldValue;
                }

                default:
                {
                    return null;
                }
            }
        }
        catch (Exception e)
        {
            isValid = false;
            return $"ERROR: with type {dataType}: {e.Message}";
        }
    }
}