using System.Text.Json.Serialization;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics.SuperMetrics;

[BsonIgnoreExtraElements]
public class Input
{
    [JsonPropertyName("fields")]
    [BsonIgnore]
    public object? Fields => string.IsNullOrEmpty(FieldsAsString) ? FieldsAsArray : FieldsAsString;

    [JsonPropertyName("ds_id")]
    [BsonElement("ds_id")]
    public string? DsId { get; set; }

    [JsonPropertyName("ds_accounts")]
    [BsonElement("ds_accounts")]
    public string? DsAccounts { get; set; }

    [JsonPropertyName("ds_user")]
    [BsonElement("ds_user")]
    public string? DsUser { get; set; }

    [JsonPropertyName("date_range_type")]
    [BsonElement("date_range_type")]
    public string? DateRangeType { get; set; }

    [JsonPropertyName("start_date")]
    [BsonElement("start_date")]
    public string? StartDate { get; set; }

    [JsonPropertyName("end_date")]
    [BsonElement("end_date")]
    public string? EndDate { get; set; }

    [JsonIgnore]
    [BsonElement("fields_as_string")]
    public string? FieldsAsString { get; set; }

    [JsonIgnore]
    [BsonElement("fields_as_array")]
    public InputField[]? FieldsAsArray { get; set; }

    [JsonPropertyName("filter")]
    [BsonElement("filter")]
    public string? Filter { get; set; }

    [JsonPropertyName("max_rows")]
    [BsonElement("max_rows")]
    public int? MaxRows { get; set; }

    [JsonPropertyName("max_columns")]
    [BsonElement("max_columns")]
    public int? MaxColumns { get; set; }

    [JsonPropertyName("settings")]
    [BsonElement("settings")]
    public InputSettings? Settings { get; set; }

    public Input()
    {
    }

    public Input(Input input)
    {
        DsId = input.DsId;
        DsAccounts = input.DsAccounts;
        DateRangeType = input.DateRangeType;
        DsUser = input.DsUser;
        StartDate = input.StartDate;
        EndDate = input.EndDate;
        FieldsAsArray = input.FieldsAsArray;
        FieldsAsString = input.FieldsAsString;
        Filter = input.Filter;
        MaxRows = input.MaxRows;

        if (input.Settings != null)
            Settings = new() { ReportType = input.Settings?.ReportType };
    }

    public SubscriptionType? GetSubscriptionType()
    {
        if (Enum.TryParse(DsId, out SubscriptionType result))
            return result;

        return null;
    }

    public class InputSettings
    {
        [JsonPropertyName("report_type")]
        [BsonElement("report_type")]
        public string? ReportType { get; set; }

        public InputSettings()
        {
        }

        public InputSettings(string reportType)
        {
            ReportType = reportType;
        }
    }
}