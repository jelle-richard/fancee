using System.Text.Json.Serialization;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics.SuperMetrics;

[BsonIgnoreExtraElements]
public class InputField
{
    [BsonElement("_id")]
    public string Id { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [BsonElement("spit")]
    public string? Split { get; set; }

    public InputField(string fieldname)
    {
        Id = fieldname;
    }
}