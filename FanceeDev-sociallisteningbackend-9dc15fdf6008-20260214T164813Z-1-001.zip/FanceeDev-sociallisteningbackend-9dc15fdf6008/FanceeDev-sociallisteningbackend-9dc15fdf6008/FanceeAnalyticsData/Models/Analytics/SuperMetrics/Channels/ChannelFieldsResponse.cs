using System.Text.Json.Serialization;

namespace FanceeAnalyticsData.Models.Analytics.SuperMetrics.Channels;

public class ChannelFieldsResponse
{
    [JsonPropertyName("meta")]
    public ChannelFieldsResponseMeta? Meta { get; set; }

    [JsonPropertyName("data")]
    public List<ChannelField>? Data { get; set; }
}