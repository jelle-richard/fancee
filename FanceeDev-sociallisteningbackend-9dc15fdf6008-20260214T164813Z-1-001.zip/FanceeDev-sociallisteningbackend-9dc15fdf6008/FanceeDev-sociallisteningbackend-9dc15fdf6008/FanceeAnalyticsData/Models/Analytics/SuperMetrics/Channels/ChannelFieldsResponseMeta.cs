using System.Text.Json.Serialization;

namespace FanceeAnalyticsData.Models.Analytics.SuperMetrics.Channels;

public class ChannelFieldsResponseMeta
{
    [JsonPropertyName("request_id")]
    public string? RequestId { get; set; }
}