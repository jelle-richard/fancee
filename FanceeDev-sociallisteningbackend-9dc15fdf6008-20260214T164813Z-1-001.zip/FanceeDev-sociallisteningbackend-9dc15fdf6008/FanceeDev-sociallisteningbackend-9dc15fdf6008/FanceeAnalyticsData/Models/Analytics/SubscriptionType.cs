namespace FanceeAnalyticsData.Models.Analytics;

/// <summary>
/// SuperMetrics list of datatypes, used for 'SuperMetrics' connections and data.
/// </summary>
public enum SubscriptionType
{
    //Facebook Ads - Campaign
    FA_CAMPAIGN,

    //Facebook Ads - Ads
    FA_ADS,

    //Facebook Ads - Video
    FA_VIDEO,

    //Facebook Ads - Conversion
    FA_CONVERSION,

    //Facebook Ads - Geo
    FA_GEO,

    //Facebook Ads - Age and Gender
    FA_AGE_AND_GENDER,

    //Facebook Insights - Page
    FB,

    //Facebook Insights - Posts
    FB_POSTS,

    //Facebook Insights - Likes per geo location
    FB_GEO_LIKES,

    //Facebook Insights - Age and Gender
    FB_AGE_AND_GENDER,

    //Facebook Public Data - Page
    FBPD_PAGE,

    //Facebook Public Data - Posts
    FBPD_POSTS,

    //Facebook Public Data - Url Shares
    FBPD_URL_SHARES,

    //Google Trends
    GT,

    // Google Analytics 4
    GAWA,

    // Google Analytics 4 - Devices
    GAWA_DEVICE,

    // Google Analytics 4 - Publishing
    GAWA_PUBLISHING,

    // Google Analytics 4 - User acquisition
    GAWA_USER_ACQUISITION,

    // Google Analytics 4 - Traffic acquisition
    GAWA_TRAFFIC_ACQUISITION,

    // Google Analytics 4 - Engagement
    GAWA_ENGAGEMENT,

    // Google Analytics 4 - E-Commerse items
    GAWA_ECOM_ITEMS,

    //Instagram Insights - Profile (followers and follows)
    IGI,

    //Instagram Insights - Followers per city
    IGI_CITY,

    //Instagram Insights - Followers per country
    IGI_COUNTRY,

    //Instagram Insights - Age and gender
    IGI_AGE_AND_GENDER,

    //Instagram Insights - Media
    IGI_MEDIA,

    //Instagram Insights - Profile data
    IGI_PROFILE_DATA,

    //Instagram Public Data - Profiles
    IGPD2_PROFILES,

    //Instagram Public Data - Hashtags
    IGPD2_HASHTAGS,

    //Instagram Public Data - Posts
    IGPD2_POSTS,

    //Google Analytics - Traffic
    GA_TRAFFIC,

    //Google Analytics - Paid traffic
    GA_PAID_TRAFFIC,

    //Google Analytics - Search
    GA_SEARCH,

    //Google Analytics - User
    GA_USER,

    //Google Analytics - Technology
    GA_TECHNOLOGY,

    //Google Analytics - Content
    GA_CONTENT,

    //Google Analytics - Ecommerce
    GA_ECOMMERCE,

    //Google Analytics - Social
    GA_SOCIAL,

    //Google Analytics - Events
    GA_EVENTS,

    //Youtube - Video
    YT_VIDEO,

    //Youtube V2 - Ad Performance
    YT2_AD_PERFORMANCE,

    //Youtube V2 - Demographic
    YT2_DEMOGRAPHIC,

    //Youtube V2 - Video
    YT2_VIDEO,

    //Youtube V2 - Channel
    YT2_CHANNEL,

    //Youtube V2 - Geo
    YT2_GEO,

    //Youtube V2 - Device
    YT2_DEVICE,

    //Youtube V2 - Traffic source
    YT2_TRAFFIC_SOURCE,

    //LinkedIn Company Pages - Page
    LIP_PAGE,

    //LinkedIn Company Pages - Post
    LIP_POST,

    //LinkedIn Company Pages - Followers by country
    LIP_COUNTRY,

    //Google Ads - Campaign
    AW_CAMPAIGN,

    //Google Ads - Ad
    AW_AD,

    //Google Ads - Keyword
    AW_KEYWORD,

    //Google Ads - Placement
    AW_PLACEMENT,

    //Google Ads - Conversion
    AW_CONVERSION,

    //Google Ads - Search Query
    AW_SEARCH_QUERY,

    //Google Ads - Search Query
    AW_SHOPPING,

    //Google Ads - Geo
    AW_GEO,

    //Google Ads - Age
    AW_AGE,

    //Google Ads - Gender
    AW_GENDER,

    //TikTok Organic - Profile
    TIKBA_PROFILE,

    //TikTok Organic - Video
    TIKBA_VIDEO,

    //TikTok Organic - Country
    TIKBA_COUNTRY,

    //TikTok Organic - Gender
    TIKBA_GENDER
}