using System.Text.Json.Serialization;

namespace FanceeAnalyticsData.Models.Analytics;

public class ChannelField
{
    [JsonPropertyName("@type")]
    public string? Type { get; set; }

    [JsonPropertyName("field_id")]
    public string? FieldId { get; set; }

    [JsonPropertyName("field_name")]
    public string? FieldName { get; set; }

    [JsonPropertyName("field_type")]
    public string? FieldType { get; set; }

    [JsonPropertyName("data_type")]
    public string? DataType { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("group_name")]
    public string? GroupName { get; set; }

    [JsonPropertyName("is_filterable")]
    public bool? IsFilterable { get; set; }
}