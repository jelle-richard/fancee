using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics.Api;

public class Error
{
    [BsonElement("message")]
    public string? Message { get; set; }

    [BsonElement("description")]
    public string? Description { get; set; }
}