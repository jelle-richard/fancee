namespace FanceeAnalyticsData.Models.Analytics.Api;

public class TokenResponse
{
    public string Token { get; set; } = default!;
    public DateTime ValidUntil { get; set; }
    public DateTime RefreshableUntil { get; set; }
    public UserResponse? User { get; set; }
}