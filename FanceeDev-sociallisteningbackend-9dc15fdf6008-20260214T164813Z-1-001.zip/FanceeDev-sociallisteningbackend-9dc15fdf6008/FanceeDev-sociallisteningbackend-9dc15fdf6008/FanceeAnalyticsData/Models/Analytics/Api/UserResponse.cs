namespace FanceeAnalyticsData.Models.Analytics.Api;

/// <summary>
/// DTO that represents the basic user info provided with the token API
/// </summary>
public class UserResponse
{
    public Guid? Id { get; set; }
    public string? Email { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public UserType Type { get; set; }
    public string? AvatarFilePath { get; set; }
    public DateTime? LastLogin { get; set; }
    public bool IsProfileComplete { get; set; } = false;
    public bool? IsVerified { get; set; }
    public string? Currency { get; set; } = null;
    public string? OrganizationId { get; set; }
    public DateTime? CreatedOn { get; set; }
    public DateTime? UpdatedOn { get; set; }
}