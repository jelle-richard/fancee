using System.ComponentModel.DataAnnotations;

namespace FanceeAnalyticsData.Models.Analytics.Api;

public class ApiRequest
{
    [Required]
    public string ChannelId { get; set; } = string.Empty;

    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }

    public ApiRequest()
    {
    }

    public ApiRequest(string channelId, DateTime? startDate, DateTime? endDate)
    {
        ChannelId = channelId;
        StartDate = startDate;
        EndDate = endDate;
    }
}