using Microsoft.AspNetCore.Http;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics.Api;

public class Meta
{
    [BsonElement("status_code")]
    public int StatusCode { get; set; }

    public Meta(int statuscode = StatusCodes.Status200OK)
    {
        StatusCode = statuscode;
    }
}