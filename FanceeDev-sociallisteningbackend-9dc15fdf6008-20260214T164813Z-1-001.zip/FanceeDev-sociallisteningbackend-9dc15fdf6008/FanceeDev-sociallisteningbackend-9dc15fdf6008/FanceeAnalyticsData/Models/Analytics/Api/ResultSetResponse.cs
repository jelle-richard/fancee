namespace FanceeAnalyticsData.Models.Analytics.Api;

/// <summary>
/// Container class for returning a result set and the total count of all items.
/// Used for paginated requests.
/// </summary>
/// <typeparam name="TModel"></typeparam>
public class ResultSetResponse<TModel>
{
    public int TotalItems { get; set; }

    public IEnumerable<TModel> Items { get; set; } = default!;

    public ResultSetResponse()
    {
    }

    public ResultSetResponse(IEnumerable<TModel> items)
    {
        Items = items;
        TotalItems = items.Count();
    }
}