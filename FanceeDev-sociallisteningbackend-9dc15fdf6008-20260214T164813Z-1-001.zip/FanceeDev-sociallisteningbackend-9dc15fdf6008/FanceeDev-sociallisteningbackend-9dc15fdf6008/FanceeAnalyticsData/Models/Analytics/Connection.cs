using System.Text.Json.Serialization;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

[BsonIgnoreExtraElements]
public class Connection : BasicMongoModel
{
    [BsonElement("subscription_id")]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? SubscriptionId { get; set; }

    [BsonElement("user_id")]
    public Guid? UserId { get; set; }

    [BsonElement("meta")]
    public dynamic? Meta { get; set; }

    [BsonElement("data")]
    public dynamic? Data { get; set; }

    [BsonElement("error")]
    public ConnectionError? Error { get; set; }

    [BsonElement("input")]
    public Input Input { get; set; }

    [BsonElement("type")]
    [BsonRepresentation(BsonType.String)]
    [JsonPropertyName("type")]
    public SubscriptionType SubscriptionType { get; set; }

    public Connection()
    {
        Input = new();
    }
}