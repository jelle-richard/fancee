using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.Analytics;

public class ChannelSettings : BasicMongoModel
{
    [BsonElement("channel_id")]
    public string? ChannelId { get; set; }

    [BsonElement("fields")]
    public IEnumerable<ChannelField>? Fields { get; set; }
}