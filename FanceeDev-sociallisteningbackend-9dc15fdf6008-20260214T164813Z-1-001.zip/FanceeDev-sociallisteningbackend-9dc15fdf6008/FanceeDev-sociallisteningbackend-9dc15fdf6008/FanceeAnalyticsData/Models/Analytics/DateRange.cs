namespace FanceeAnalyticsData.Models.Analytics;

/// <summary>
/// Enum for specifying the type of range when retrieving entries between dates. Default is daily.
/// </summary>
public enum DateRange
{
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY
}