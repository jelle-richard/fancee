using FanceeAnalyticsData.Models.TicketingData.Enums;

namespace FanceeAnalyticsData.Models.TicketingData;

public class ClientOrder
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? PhoneNumber { get; set; }
    public bool OptInPromotionalSms { get; set; }
    public bool OptInPromotionalEmail { get; set; }
    public int ReceiveViaSmsCostCents { get; set; }
    public int TicketServicePlusCostCents { get; set; }
    public DateTime? Birthdate { get; set; }
    public Gender? Gender { get; set; }
    public Address? Address { get; set; }
}