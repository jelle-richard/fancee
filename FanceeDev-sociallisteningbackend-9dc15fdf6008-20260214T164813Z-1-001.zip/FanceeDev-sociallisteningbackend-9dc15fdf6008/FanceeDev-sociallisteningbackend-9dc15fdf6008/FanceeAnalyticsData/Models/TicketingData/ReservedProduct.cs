namespace FanceeAnalyticsData.Models.TicketingData;

public class ReservedProduct
{
    public Guid ReservedProductId { get; set; }
    public Guid ReservationReference { get; set; }
    public Guid ProductId { get; set; }
    public int Quantity { get; set; }
    public string? ShopCode { get; set; }
    public string? MetaData { get; set; }
}