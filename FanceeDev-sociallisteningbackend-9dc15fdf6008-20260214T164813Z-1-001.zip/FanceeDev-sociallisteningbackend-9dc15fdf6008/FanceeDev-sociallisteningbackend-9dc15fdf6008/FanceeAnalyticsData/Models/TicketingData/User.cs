﻿using FanceeAnalyticsData.Models.Analytics;

namespace FanceeAnalyticsData.Models.TicketingData;

public class User : BasicMongoModel
{
    public Guid UserId { get; set; }
    public Guid? FanceeUsersId { get; set; }
    public UserType Type { get; set; } = UserType.None;
    public string? Email { get; set; }
    public DateTime? LastLogin { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public Guid? AccountVerifyId { get; set; }
    public UserContactInfo? UserContactInfo { get; set; }
}