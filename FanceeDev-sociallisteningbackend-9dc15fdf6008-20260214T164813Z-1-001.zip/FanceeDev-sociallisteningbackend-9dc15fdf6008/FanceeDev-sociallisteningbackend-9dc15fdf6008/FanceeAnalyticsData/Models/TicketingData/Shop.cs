namespace FanceeAnalyticsData.Models.TicketingData;

public class Shop
{
    public string? Code { get; set; }
    public string? Name { get; set; }
    public bool Active { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public bool IsReservationShop { get; set; }
    public DateTime? IsSecuredUntil { get; set; }
    public int NumberOfViews { get; set; }
    public List<string> Tags { get; set; } = [];
}