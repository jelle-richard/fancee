using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson.Serialization.Attributes;

namespace FanceeAnalyticsData.Models.TicketingData;

public class Client : BasicMongoModel
{
    public Guid UserId { get; set; }

    public string? FacebookId { get; set; }

    public string? Referer { get; set; }

    [BsonIgnore]
    public User? User { get; set; }
}