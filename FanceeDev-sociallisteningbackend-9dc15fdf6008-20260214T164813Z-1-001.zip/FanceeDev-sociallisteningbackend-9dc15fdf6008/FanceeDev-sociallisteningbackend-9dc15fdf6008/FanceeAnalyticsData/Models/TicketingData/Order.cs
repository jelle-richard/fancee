using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.TicketingData.Enums;

namespace FanceeAnalyticsData.Models.TicketingData;

public class Order : BasicMongoModel
{
    public Guid OrderId { get; set; }
    public Guid ClientId { get; set; }
    public Guid? ReservationReference { get; set; }
    public PaymentStatus PaymentStatus { get; set; }
    public Guid? PaymentMethodId { get; set; }
    public DateTime LastAlteration { get; set; }
    public bool UseGoogleAnalyticsOnOrderComplete { get; set; }
    public string? Currency { get; set; }
    public string? PspReference { get; set; }
    public int? TotalCostCents { get; set; }
    public int? PaymentFeeCents { get; set; }
    public PaidBy? PaymentFeePaidBy { get; set; }
    public DateTime? PaidOn { get; set; }
    public PaymentRefusalReason? PaymentRefusalReason { get; set; }
    public ClientOrder? ClientOrderInformation { get; set; }
}