using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.TicketingData.Enums;

namespace FanceeAnalyticsData.Models.TicketingData;

public class IssuedProducts : BasicMongoModel
{
    public Guid IssuedProductId { get; set; }
    public Guid? ReservedProductId { get; set; }
    public Guid ProductId { get; set; }
    public Guid? OrderId { get; set; }
    public IssuedProductType Type { get; set; }
    public IssuedProductOrigin? Origin { get; set; }
    public bool DeductStock { get; set; } = true;
}