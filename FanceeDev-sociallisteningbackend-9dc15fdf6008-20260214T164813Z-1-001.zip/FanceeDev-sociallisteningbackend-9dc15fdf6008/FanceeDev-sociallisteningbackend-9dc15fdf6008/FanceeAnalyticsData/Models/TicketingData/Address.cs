namespace FanceeAnalyticsData.Models.TicketingData;

public class Address
{
    public Guid Id { get; set; }
    public string? CountryCode { get; set; }
    public string? PostalCode { get; set; }
    public string? Street { get; set; }
    public string? City { get; set; }
    public string? HouseNumber { get; set; }
    public string? Venue { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
}