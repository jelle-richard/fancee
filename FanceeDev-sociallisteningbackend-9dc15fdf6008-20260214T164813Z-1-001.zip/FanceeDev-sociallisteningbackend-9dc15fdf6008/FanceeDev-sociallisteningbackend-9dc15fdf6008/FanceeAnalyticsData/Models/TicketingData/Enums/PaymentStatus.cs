namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum PaymentStatus
{
    AuthenticationFinished, // payment is not authorised. But used for authentication with 3D Secure 2 Authentication data
    AuthenticationNotRequired,
    Authorised,
    Blocked,
    Cancelled,
    ChallengeShopper,
    Chargeback,
    Error,
    Expired,
    IdentifyShopper,
    PartiallyAuthorised,
    PartialRefund,
    Pending,
    PresentToShopper,
    Received, // Is not paid. Waiting for clearance. Used in SEPA Direct Debit, where it can take some time before the final status of payment is known.
    RedirectShopper,
    Refund,
    Refused,
    Unknown  
}