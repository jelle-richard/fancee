namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum ProductType
{
    Product,
    Ticket,
    SeatedTicket
}