namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum Gender
{
    Male,
    Female,
    Neutral
}