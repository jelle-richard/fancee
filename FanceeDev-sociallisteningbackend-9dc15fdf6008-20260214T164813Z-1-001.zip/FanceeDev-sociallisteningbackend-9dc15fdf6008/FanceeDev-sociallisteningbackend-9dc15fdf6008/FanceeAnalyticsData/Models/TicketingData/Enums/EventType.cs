namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum EventType
{
    Normal,
    Seating,
    Timeslotted
}