namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum PaymentRefusalReason
{
    /// <summary>
    /// It is not possible to contact the shopper's bank to authorise the transaction.
    /// </summary>
    IssuerUnavailable,

    /// <summary>
    /// Back account does not contain enough balance for the transaction
    /// </summary>
    NotEnoughBalance,

    /// <summary>
    /// Payment processor suspects fraud
    /// </summary>
    Fraud,

    /// <summary>
    /// Shopper provided invalid card credentials
    /// </summary>
    InvalidPin,

    /// <summary>
    /// Shopper has reached his/her pin retry limit
    /// </summary>
    PinLimitReached,

    /// <summary>
    /// Shoppers card is restricted from payments outside of origin country
    /// </summary>
    RestrictedCard,

    /// <summary>
    /// Shopper has exceeded his/her withdrawal balance limit
    /// </summary>
    WithdrawalAmountExceeded,

    /// <summary>
    /// Shopper has exceeded his/het withdrawal amount limit,
    /// </summary>
    WithdrawalCountExceeded,

    /// <summary>
    /// No reasoning was provided
    /// </summary>
    None
}