namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum PaidBy
{
    Client,
    Organization
}