namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum IssuedProductType
{
    PlatformShop,
    PlatformApp,
    PlatformImported,
    PlatformGuestList,
    PlatformGenerated,
    TwentyFourAndMoreApp,
    TicketSwap
}