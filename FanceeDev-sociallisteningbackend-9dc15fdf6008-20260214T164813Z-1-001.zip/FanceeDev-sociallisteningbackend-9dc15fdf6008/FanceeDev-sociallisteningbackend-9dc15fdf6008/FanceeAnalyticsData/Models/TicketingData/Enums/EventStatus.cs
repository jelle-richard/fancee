namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum EventStatus
{
    Unpublished,
    Active,
    Cancelled,
    SoldOut,
    Concluded,
    Concept
}