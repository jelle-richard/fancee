namespace FanceeAnalyticsData.Models.TicketingData.Enums;

public enum IssuedProductOrigin
{
    PlatformShop,
    PlatformApp,
    PlatformImported,
    PlatformGuestList,
    PlatformGenerated,
    TwentyFourAndMoreApp,
    TicketSwap 
}