using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.TicketingData.Enums;

namespace FanceeAnalyticsData.Models.TicketingData;

public class Event : BasicMongoModel
{
    public Guid EventId { get; set; }
    public Guid OrganizationId { get; set; }
    public string? Name { get; set; }
    public EventType Type { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public EventStatus Status { get; set; }
    public string? Description { get; set; }
    public Guid? AddressId { get; set; }
    public int? MinimumAge { get; set; }
    public int ReservationTimeMinutes { get; set; }
    public Address? Address { get; set; }
    public IEnumerable<Product> Products { get; set; } = new HashSet<Product>();
    public IEnumerable<Shop> Shops { get; set; } = new HashSet<Shop>();
}