using FanceeAnalyticsData.Models.Analytics;

namespace FanceeAnalyticsData.Models.TicketingData;

public class ReservationReference : BasicMongoModel
{
    public Guid Reference { get; set; }
    public DateTime ExpiresOn { get; set; }
    public Guid? DiscountId { get; set; }
    public string? CampaignCode { get; set; }
    public string? AppUri { get; set; }
    public IEnumerable<ReservedProduct> ReservedProducts { get; set; } = new HashSet<ReservedProduct>();
}