namespace FanceeAnalyticsData.Models.TicketingData;

public class UserContactInfo
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public Guid? AddressId { get; set; }
    public string? PhoneNumber { get; set; }
    public Address? Address { get; set; }
}