using FanceeAnalyticsData.Models.TicketingData.Enums;

namespace FanceeAnalyticsData.Models.TicketingData;

public class Product
{
    public Guid Id { get; set; }
    public string? Name { get; set; }
    public int Stock { get; set; }
    public int? PriceCents { get; set; }
    public int? FeeCents { get; set; }
    public string? Description { get; set; }
    public DateTime? SaleStart { get; set; }
    public DateTime? SaleEnd { get; set; }
    public int MaximumPurchasePerOrder { get; set; }
    public bool IsSharedCapacityEligible { get; set; }
    public Guid? WaveLinkedProductId { get; set; }
    public bool MarkSoldOutOnSaleWindowExpired { get; set; }
    public int PackQuantity { get; set; }
    public ProductType Type { get; set; }
    public string? SeatsIoCategoryId { get; set; }
    public Product? WaveLinkedProduct { get; set; }
}