using FanceeAnalyticsData.Models.Analytics;

namespace FanceeAnalyticsData.Models.TicketingData;

public class Organization : BasicMongoModel
{
    public Guid OrganizationId { get; set; }
    public Guid UserId { get; set; }
    public string? MailchimpKey { get; set; }
    public Guid? CustomTermFileId { get; set; }
    public int ApproximatedAnnualSalesAmount { get; set; }
    public int DefaultReservationTimeMinutes { get; set; } = 8;
    public string? Name { get; set; }
    public bool IsImportant { get; set; }
    public string? Currency { get; set; }
    public string? ChamberOfCommerceIdentifier { get; set; }
    public string? CountryCode { get; set; }
    public bool IsProfileComplete { get; set; }
    public bool IsDemo { get; set; }
    public Guid? AddressId { get; set; }
    public string? TimezoneIdentification { get; set; }
    public string? PhoneNumber { get; set; }
    public Address? Address { get; set; }
    public User? User { get; set; }
}