# README

## SocialListeningBackend

This repository contains all the code for running the backend.

## Notes

1. It is important that you **<u>do not</u>** clone the repository in a folder that contains a `#` sign. This will cause the debugging of docker compose projects to fail.

## Git usage

### Branches

The repository works via the following structure:

###### Main branch

Contains the latest stable release and is the exact code that is running on the live environment.

###### Develop branch

This branch contains the latest stable release marked for the next deployment and is the exact code that is running on the staging environment.

###### Feature branches

Any new feature should have it's own feature branch. Once complete, the feature branch should be merged to the develop branch and the feature branch should be deleted.

###### Bugfix branches

If a bug is found, it should be fixed within a bugfix branch. Once complete, the bugfix branch should be merged to the branch it originated from and the bugfix branch should be deleted.

### Commit messages

All commit messages should follow the following template: `<type>{(<jira-issue>)}: <subject>`
Parts between `{ }` are optional.

The following types are allowed:

| Type     | Description                                                                                                                                        |
|----------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| feat     | for when a new feature has been added                                                                                                              |
| fix      | for when a bugfix has been made                                                                                                                    |
| docs     | for when documentation has changed                                                                                                                 |
| style    | for when formatting has been changed (for example: missing semicolon, removed/added brackets etc. - no actual code functionality has been changed) |
| refactor | for when the changed code is a refactor of some kind                                                                                               |
| test     | for when adding (unit) tests                                                                                                                       |
| chore    | for all other type of commits                                                                                                                      |

## Installation guide

1. Install the latest version of Visual Studio 2022 (or newer) ([download](https://visualstudio.microsoft.com/downloads/))
    1. Select at least the following workloads:
        1. ASP.NET and web development
        2. Data storage and processing
        3. .NET cross-platform development
    2. Select at least the following individual components:
        1. .NET 6.0 Runtime
2. *Only for Windows:*
    1. Windows 10 < 2004
        1. Open the `settings` app
        2. Click on `apps`
        3. Scroll down and click on `More Windows features`
        4. Scroll down and select `Windows Subsystem for Linux`
        5. Click `OK` and restart
        6. Open the `Microsoft Store` app
        7. Search for `Debian` and install and launch it
        8. Follow the instructions on screen to download the Linux kernel and set up the user account
    2. Windows 10 >= 2004 / Windows 11
        1. Open the terminal
        2. Run `wsl --install -d Debian`
        3. Reboot the computer to finish the installation
3. Install docker desktop ([download](https://www.docker.com/get-started))
    1. If running on Windows, make sure to choose the WSL backend
    2. If running on macOS make sure to add the following path to your Docker 'File Sharing' options: `/usr/local/share/dotnet/sdk/NuGetFallbackFolder`
    3. Uncheck 'Use Docker Compose V2' in the Docker Desktop settings
4. Clone this repository (see [notes](##notes)) and open it in Visual Studio (`sociallisteningbackend.sln`)
5. Make sure the startup project is set to `docker-compose`
6. *Only for macOS / Linux:*
    1. Create an `.env` file in the root with the following content: `APPDATA=/Users/{USERNAME}` and replace `{USERNAME}` with your username
    2. Run: `ln -s ~/.microsoft ~/Microsoft`
    3. Run: `ln -s ~/.microsoft/usersecrets ~/Microsoft/UserSecrets`
    4. Make sure the following entry exists in `/etc/hosts`: `127.0.0.1 host.docker.internal`
7. Make sure you have configured the private NuGet Feed (see [configuring the feed](#configuring-the-feed))
8. Run the project by pressing `F5` or the play button in the menu bar

#### Configuring the feed

This project uses NuGet packages from a private registry. To be able to build the project, you need to add the NuGet feed.
On the command line:

1. Add the NuGet feed using the dotnet command (replace `{PASS}` in the command with the password in LastPass):
    1. Windows: `dotnet nuget add source https://packages.fanc.ee/nuget/p/main/nuget/v3/index.json -n FanceeGet -u fancee -p {PASS}`
    2. macOS/Linux: `dotnet nuget add source https://packages.fanc.ee/nuget/p/main/nuget/v3/index.json -n FanceeGet -u fancee -p {PASS} --store-password-in-clear-text`

If you are having authentication problems (often occurs with Rider), temporarily set the username and password in the `nuget.config` file in the root.
Replace `%USERNAME%` and `%PASSWORD%`.

_**Note:**_ Make sure to revert `nuget.config` before comitting!

### Secrets

The project stores connection strings and other secrets (API keys etc.) in the `secret.json` files on your local machine.
These files are managed by Visual Studio (right click project -> Manage User Secrets (only for Windows)) or via the `dotnet user-secrets` cli tool ([info](https://docs.microsoft.com/en-us/aspnet/core/security/app-secrets?view=aspnetcore-6.0&tabs=windows#how-the-secret-manager-tool-works)).  
In order to know which values to set in these files, a scaffold needs to be available in the `appsettings.Development.json` files with empty values.
These values will be overridden with the secret values when the project is running.

#### Example

**appsettings.Development.json**

```json
{
  "ExternalApiSettings": {
    "Url": "example.com",
    "ApiKey": ""
  }
}
```

**secrets.json**

```json
{
  "ExternalApiSettings": {
    "ApiKey": "SecretValue"
  }
}
```

Secrets needed to be overridden in this project are following:

```json
{
  "SuperMetrics": {
    "ApiKey": "SecretValue"
  },
  "Jwt": {
    "SigningKey": "SecretValue"
  },
  "ConnectionStrings": {
    "FanceeUsers": "SecretValue"
  },
  "Admin": {
    "Password": "SecretValue"
  },
  "Mailchimp": {
    "TransactionalApiKey": "SecretValue"
  }
}
```

#### Sharing secrets

If you have the need of storing a secret that is the same for all development machines (e.g. API keys), please share them in the company LastPass vault.  
In LastPass, there is a template for adding a new secret (App Secret). Please add new secrets in the shared folder: `Shared-Fancee dev -> App Secrets`.  
Complicated secret objects (e.g. Adyen) can be added as a secure note.

#### Staging/ Production secrets

When you've added a new secret to the project, it should also be added to the staging and production environments. These values are stored on the target machine.
Loading of these files is handled by docker-compose. The location of these files are defined in the `docker-compose.override.{ENV}.yml` file.  
Please contact the system administrator to add new values.

### Running database locally

To run the database locally you need to add 'mongoservice' to your hosts file.
windows: <WINDOWSDIR>/system32/drivers/etc/hosts
mac: /etc/hosts

hosts example:
127.0.0.1 mongoservice

Recommended tool: NoSQLBooster for MongoDB. ([download](https://nosqlbooster.com/)

#### import/export

export: mongodump --uri="mongodb://mongoservice:27017" --out export
import: mongorestore --uri="mongodb://mongoservice:27017/sociallistening"

mongodump/mongorestore requires mongodb cli tools.

mac/linux
https://www.mongodb.com/docs/database-tools/installation/installation-macos/

- homebrew: brew install mongodb

windows
https://www.mongodb.com/docs/database-tools/installation/installation-windows/

### Running database queries by hand

Recommended tool: NoSQLBooster for MongoDB. ([download](https://nosqlbooster.com/)
Connect to the preferred database in NoSQLBooster (or any other MongoDB tool)
**EXAMPLE URI**

```
mongodb://localhost:27017
```

Queries can then be copy-pasted directly into a new window (cmd+t for new tab), after connecting to the database.
**EXAMPLE QUERY**

```
db.channels.find({})
```

More information about queries (https://www.mongodb.com/docs/manual/)

## Run tests

This project contains unit tests to verify correctness of the code. These tests can be run in several ways depending on your configuration.

### Command line

Execute: `dotnet test .\sociallisteningbackend.sln`

### ReSharper

Press: `CTRL + T, L`
Menubar: `Extensions` > `ReSharper` > `Unit Tests` > `Run All Tests from Solution`

### Visual Studio 2022

Press: `CTRL + R, A`
Menubar: `Test` > `Run All Tests`

## Alter database

// Fill when database migrations are up and running.

## Use swagger

To use swagger first get a authentication token and paste this in the value field found when pressing the 'autorize' butten accourding to the format found there.

## Use shared settings

When you want to use the sharedsettings(.Development).json file in a new project, make sure you add the following to the `.csproj` file (inside the <Project> block):

```xml

<ItemGroup>
    <Content Include="..\sharedsettings*.json" CopyToOutputDirectory="PreserveNewest" LinkBase=""/>
</ItemGroup>
```

Next, make sure the value of `UseSharedSettings` in your `Program.cs` when creating a new `Startup` object is set to `true` (default).

## Code style

### C# #

- Use `PascalCase` for:
    - File names
    - Class/interface/enum names
    - Method names
    - Enum members
    - Public properties
    - Readonly properties
    - Constants
- Use `_camelCase` for:
    - Private variables
- Use `camelCase` for:
    - Variables in methods
- Avoid using (unless actually needed):
    - `object` as type
    - `dynamic` as type
    - `go to` statements
- Prefer wrapper objects instead of returning `Tuple<T, T2>`
- Use a tab indent of 4 spaces
- Prefer LINQ methods over the QUERY-syntax (`from _myCollection select ... where ...`)
- Format code according to the ReSharper/Rider profile (CTRL + ALT + L)
- Classes should have the following structure:
    - Constants
    - Properties
    - Class variables
    - Constructor
    - Methods
- Members in classes should have the following access modifier order:
    - Public
    - Protected
    - Private
- Files should use file-scoped namespaces
- Async methods should be postfixed with 'Async' (e.g. `public async Task<T> ListAsync()`)
- Interface methods should have XMLDoc with an explaination
    - Implementations do not have to inherit interface XMLDoc, unless the implementation differs.
- Generic Types start with 'T' (e.g. `class MyClass<TModel>`)
- Avoid using boxed variants of primitive types:

| Boxed   | Primitive |
|---------|-----------|
| Int16   | short     |
| Int32   | int       |
| Int64   | long      |
| String  | string    |
| Boolean | bool      |
| Double  | double    |
| Decimal | decimal   |
| Char    | char      |

## Definition of Ready
- Independent:
    - The user story can be run independently of others;
    - If there are dependencies, they are clearly detailed in a separate user story that is linked;
    - There is no/minimal dependence on another team.
- Negotiable
    - It is clear to everyone what the user story entails.
- Value
    - The priority is clear (indicated by the place in the backlog);
    - The first sentence is worded as "As <role> I want <feature> because/so that <reason>".
- Small
    - The user story can be executed in one sprint, otherwise it will be split.

## Definition of Done

- The deliverable should adhere to:
    - The deliverable adheres to all the requirements of the [code style](#Code style)
    - The deliverable follows the git [branching structure](#Branches)
    - The deliverable branch is up-to-date with it's orgin/parent branch
    - The deliverable should be production ready and not contain:
        - `Debugger.Break()` statements
        - Todo comments that should be resolved within the scope of the branch
        - Other development related comments that do not provide explanations
    - The deliverable should be linked to a Jira issue and only contain changes stated in the issue
    - The deliverable is buildable
    - The deliverable is provided as a BitBucket Pull Request
    - The deliverable passes the merge checks:
        - Pipeline runs successfully
        - SonarQube quality report passes:
            - Code coverage on new code: >= 80%
            - Quality reports should pass with an 'A'
            - Code duplication should be <= 2%
        - Code is approved by at least one other developer
        - All unittests succeed
    - The deliverable branch should be deleted after the pull request is merged
