using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using LogService.Persistence.Logs;
using LogService.TestData;
using TestCore.Utils.UnitTestsHelpers;

namespace LogService.Tests.Persistence.CustomLogs;

public class LogsDaoTests
{
    private readonly Guid UserId = Guid.Empty;
    private readonly ILogsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public LogsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();
        _sut = new LogsDao(configuration, _mongoDatabase.Object);
    }

    [Fact]
    public async Task TestThatToPaginatedListAsyncReturnsResultSetWhenSuccessful()
    {
        var mockLogs = LogInfoFactory.GetLogs();
        var mockResult = new[] { new ResultSetResponse<DataLog>(mockLogs) };
        _mongoDatabase.MockPagination(mockResult);

        var actual = await _sut.ToPaginatedListAsync(10, 0, UserId);

        Assert.Equal(mockLogs.First(), actual.Items.First());
    }
}