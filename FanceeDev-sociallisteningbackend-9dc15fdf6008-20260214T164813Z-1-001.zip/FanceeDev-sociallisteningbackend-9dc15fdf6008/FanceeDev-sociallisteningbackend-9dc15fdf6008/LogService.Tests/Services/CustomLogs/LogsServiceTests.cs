using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using LogService.Persistence.Logs;
using LogService.Services.Logs;
using LogService.TestData;

namespace LogService.Tests.Services.CustomLogs;

public class LogsServiceTests
{
    private readonly Guid _userId = Guid.NewGuid();
    private readonly LogsService _sut;
    private readonly Mock<ILogsDao> _mockedLogsDao = new();

    public LogsServiceTests()
    {
        _sut = new(_mockedLogsDao.Object);
    }

    [Fact]
    public async Task TestThatGetLogsAsyncCallsGetLogsAsync()
    {
        var mockLogs = LogInfoFactory.GetLogs();

        _mockedLogsDao
            .Setup(ld => ld.ToPaginatedListAsync(10, 0, _userId, It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new ResultSetResponse<DataLog>(mockLogs));

        var actual = await _sut.ToListAsync(_userId, 10, 0, It.IsAny<DateTime>(), It.IsAny<DateTime>());

        Assert.Equal(mockLogs, actual.Items);
    }

    [Fact]
    public async Task TestThatToListAsyncWithoutUserWorks()
    {
        var mockLogs = LogInfoFactory.GetLogs();

        _mockedLogsDao
            .Setup(ld => ld.ToPaginatedListAsync(10, 0, null, It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new ResultSetResponse<DataLog>(mockLogs));

        var actual = await _sut.ToListAsync(10, 0, It.IsAny<DateTime>(), It.IsAny<DateTime>());

        Assert.Equal(mockLogs, actual.Items);
    }
}