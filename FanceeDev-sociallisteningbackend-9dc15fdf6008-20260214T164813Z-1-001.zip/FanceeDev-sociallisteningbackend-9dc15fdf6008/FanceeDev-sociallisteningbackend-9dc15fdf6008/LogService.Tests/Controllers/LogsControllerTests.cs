using System.Security.Claims;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using LogService.Controllers;
using LogService.Services.Logs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using TestCore.Utils.UnitTestsHelpers;

namespace LogService.Tests.Controllers;

public class LogsControllerTests
{
    private static readonly Guid OrganizerUserId = Guid.NewGuid();
    private static readonly User UserOrganizer = new() { FanceeUsersId = OrganizerUserId, UserId = OrganizerUserId, Type = UserType.Organization };
    private static readonly Guid AdminUserId = Guid.NewGuid();
    private static readonly User UserAdmin = new() { FanceeUsersId = AdminUserId, UserId = AdminUserId, Type = UserType.Admin };

    private readonly Mock<ILogsService> _mockedLogsService = new();
    private readonly LogsController _sut;

    public LogsControllerTests()
    {
        _sut = new(_mockedLogsService.Object)
        {
            ControllerContext =
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new(new ClaimsIdentity(new[]
                    {
                        new Claim("user", UserOrganizer.FanceeUsersId.ToString()),
                        new Claim("platformUserId", UserOrganizer.UserId.ToString()),
                        new Claim("type", UserOrganizer.Type.ToString())
                    }))
                }
            }
        };
    }

    [Fact]
    public async Task TestThatLogsCallsLogsServiceLogsAsync()
    {
        _mockedLogsService.Setup(x => x.ToListAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<int>(),
                It.IsAny<DateTime?>(), It.IsAny<DateTime?>()))
            .ReturnsAsync(new ResultSetResponse<DataLog>(new List<DataLog>()));

        var request = new PaginatedRequest<SearchQueryFilter>();
        var actual = await _sut.List(request, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedLogsService.Verify(x => x.ToListAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<DateTime?>(), It.IsAny<DateTime?>()), Times.Once);
    }

    [Fact]
    public async Task TestThatLogsCallsAdminLogsServiceLogsAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var resultSet = new ResultSetResponse<DataLog>(new List<DataLog>());
        _mockedLogsService.Setup(x => x.ToListAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<DateTime?>(), It.IsAny<DateTime?>()))
            .ReturnsAsync(resultSet);

        var request = new PaginatedRequest<SearchQueryFilter>();
        var actual = await _sut.List(request, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedLogsService.Verify(x => x.ToListAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<DateTime?>(), It.IsAny<DateTime?>()), Times.Once);
    }
}