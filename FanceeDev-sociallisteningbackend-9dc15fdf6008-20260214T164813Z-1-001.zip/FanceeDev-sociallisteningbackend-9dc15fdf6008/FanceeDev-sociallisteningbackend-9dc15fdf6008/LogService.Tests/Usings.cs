global using Xunit;
global using Moq;
global using MongoDB.Driver;