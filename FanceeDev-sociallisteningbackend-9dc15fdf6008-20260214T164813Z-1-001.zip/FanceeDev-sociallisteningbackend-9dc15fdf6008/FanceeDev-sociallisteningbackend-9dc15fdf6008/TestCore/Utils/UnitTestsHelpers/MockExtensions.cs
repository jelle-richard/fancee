using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Entries;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using Moq;

namespace TestCore.Utils.UnitTestsHelpers;

public static class MockExtensions
{
    public static void Mock<TModel>(this Mock<IMongoDatabase> database, IEnumerable<TModel> entities)
    {
        database.Mock<TModel, TModel>(entities);
    }

    public static void Mock<TModel, TProjection>(this Mock<IMongoDatabase> database, IEnumerable<TProjection> entities)
    {
        Mock<IMongoCollection<GenericEntry>> mockedEntries = new();
        Mock<IMongoCollection<TModel>> mockedCollection = new();
        Mock<IAsyncCursor<TProjection>> cursor = new();

        database.Setup(x => x.GetCollection<GenericEntry>(It.IsAny<string>(), It.IsAny<MongoCollectionSettings>()))
            .Returns(mockedEntries.Object);
        database.Setup(x => x.GetCollection<TModel>(It.IsAny<string>(), It.IsAny<MongoCollectionSettings>()))
            .Returns(mockedCollection.Object);

        cursor.Setup(x => x.Current).Returns(entities);
        cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true)
            .ReturnsAsync(false);
        cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);

        mockedEntries.Setup(x => x.AggregateAsync(It.IsAny<PipelineDefinition<GenericEntry, TProjection>>(),
            It.IsAny<AggregateOptions>(),
            It.IsAny<CancellationToken>())).ReturnsAsync(cursor.Object);

        mockedCollection
            .Setup(x => x.FindAsync(It.IsAny<FilterDefinition<TModel>>(),
                It.IsAny<FindOptions<TModel, TProjection>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(cursor.Object);
    }

    public static Mock<IMongoCollection<TModel>> MockCollection<TModel>(this Mock<IMongoDatabase> database, IEnumerable<TModel>? items = null)
    {
        Mock<IMongoCollection<TModel>> mockedCollection = new();
        Mock<IAsyncCursor<TModel>> cursor = new();

        database.Setup(x => x.GetCollection<TModel>(It.IsAny<string>(), It.IsAny<MongoCollectionSettings>()))
            .Returns(mockedCollection.Object);

        if (items != null)
            cursor.Setup(x => x.Current).Returns(items);
        cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true)
            .ReturnsAsync(false);
        cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);

        mockedCollection
            .Setup(x => x.FindAsync(It.IsAny<FilterDefinition<TModel>>(),
                It.IsAny<FindOptions<TModel, TModel>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(cursor.Object);

        return mockedCollection;
    }

    public static void MockPagination<TModel>(this Mock<IMongoDatabase> database,
        IEnumerable<ResultSetResponse<TModel>> resultSet)
    {
        database.MockPagination<TModel, TModel>(resultSet);
    }

    public static void MockPagination<TModel, TResult>(this Mock<IMongoDatabase> database,
        IEnumerable<ResultSetResponse<TResult>> resultSet)
    {
        Mock<IMongoCollection<TModel>> mockedCollection = new();
        Mock<IAsyncCursor<ResultSetResponse<TResult>>> cursor = new();

        database.Setup(x => x.GetCollection<TModel>(It.IsAny<string>(), It.IsAny<MongoCollectionSettings>()))
            .Returns(mockedCollection.Object);

        cursor.Setup(x => x.Current).Returns(resultSet);
        cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true)
            .ReturnsAsync(false);
        cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);

        mockedCollection.Setup(x => x.AggregateAsync(
            It.IsAny<PipelineDefinition<TModel, ResultSetResponse<TResult>>>(),
            It.IsAny<AggregateOptions?>(),
            It.IsAny<CancellationToken>())).ReturnsAsync(cursor.Object);
    }

    public static void MockIndexes<TModel>(this Mock<IMongoDatabase> database)
    {
        Mock<IMongoIndexManager<TModel>> mongoIndexManager = new();
        Mock<IMongoCollection<TModel>> mockedCollection = new();

        database.Setup(x => x.GetCollection<TModel>(It.IsAny<string>(), It.IsAny<MongoCollectionSettings>()))
            .Returns(mockedCollection.Object);

        mockedCollection.Setup(x => x.Indexes).Returns(mongoIndexManager.Object);

        mongoIndexManager
            .Setup(x => x.CreateManyAsync(
                It.IsAny<IEnumerable<CreateIndexModel<TModel>>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Array.Empty<string>());
    }

    public static Mock<IMongoClient> MockLogClient(this Mock<IMongoCollection<Log>> mockedMongoCollection)
    {
        Mock<IMongoDatabase> database = new();
        Mock<IMongoClient> mockedClient = new();

        mockedClient.Setup(c => c.GetDatabase(It.IsAny<string>(), It.IsAny<MongoDatabaseSettings>()))
            .Returns(database.Object);
        database.Setup(x => x.GetCollection<Log>(It.IsAny<string>(), It.IsAny<MongoCollectionSettings>()))
            .Returns(mockedMongoCollection.Object);
        mockedMongoCollection.Setup(x => x.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()));

        return mockedClient;
    }

    public static void VerifyLogging<T>(this Mock<ILogger<T>> logger, string expectedMessage, LogLevel expectedLogLevel = LogLevel.Information, Times? times = null)
    {
        Func<object, Type, bool> state = (v, t) => v?.ToString()?.CompareTo(expectedMessage) == 0;
        logger.Verify(
            x => x.Log(
                It.Is<LogLevel>(l => l == expectedLogLevel),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => state(v, t)),
                It.IsAny<Exception>(),
                It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)), times ?? Times.Once());
    }

    public static void VerifyLogging(this Mock<ILogger> logger, string expectedMessage, LogLevel expectedLogLevel = LogLevel.Information, Times? times = null)
    {
        Func<object, Type, bool> state = (v, t) => v?.ToString()?.CompareTo(expectedMessage) == 0;
        logger.Verify(
            x => x.Log(
                It.Is<LogLevel>(l => l == expectedLogLevel),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => state(v, t)),
                It.IsAny<Exception>(),
                It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)), times ?? Times.Once());
    }

    /// <summary>
    /// Version of VerifyLogging with the difference of validating a part of the message that is logged ends with a specified string.
    /// This is used to verify logging statements which include DateTime stamps.
    /// </summary>
    /// <param name="logger"></param>
    /// <param name="contains"></param>
    /// <param name="expectedLogLevel"></param>
    /// <param name="times"></param>
    public static void VerifyLoggingEndsWith(this Mock<ILogger> logger, string contains, LogLevel expectedLogLevel = LogLevel.Information, Times? times = null)
    {
        Func<object, Type, bool> state = (v, t) => v.ToString()!.EndsWith(contains);
        logger.Verify(
            x => x.Log(
                It.Is<LogLevel>(l => l == expectedLogLevel),
                It.IsAny<EventId>(),
                It.Is<It.IsAnyType>((v, t) => state(v, t)),
                It.IsAny<Exception>(),
                It.Is<Func<It.IsAnyType, Exception?, string>>((v, t) => true)), times ?? Times.Once());
    }
}