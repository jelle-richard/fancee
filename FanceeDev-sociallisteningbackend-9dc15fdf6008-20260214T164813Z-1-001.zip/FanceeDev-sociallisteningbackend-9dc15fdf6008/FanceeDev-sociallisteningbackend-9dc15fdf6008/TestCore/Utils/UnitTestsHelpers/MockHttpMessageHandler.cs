﻿using System.Net;

namespace TestCore.Utils.UnitTestsHelpers;

public class MockHttpMessageHandler : HttpMessageHandler
{
    public string? Input { get; private set; }
    public int NumberOfCalls { get; private set; }
    private string? _response;
    private HttpStatusCode _statusCode;

    public MockHttpMessageHandler(HttpStatusCode statusCode, string? response = null)
    {
        _response = response;
        _statusCode = statusCode;
    }

    public void SetResponse(string newResponse, HttpStatusCode statusCode)
    {
        _response = newResponse;
        _statusCode = statusCode;
    }

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        NumberOfCalls++;
        if (request.Content != null)
            Input = await request.Content.ReadAsStringAsync(cancellationToken);

        return new()
        {
            StatusCode = _statusCode,
            Content = new StringContent(_response != null ? _response : string.Empty)
        };
    }
}