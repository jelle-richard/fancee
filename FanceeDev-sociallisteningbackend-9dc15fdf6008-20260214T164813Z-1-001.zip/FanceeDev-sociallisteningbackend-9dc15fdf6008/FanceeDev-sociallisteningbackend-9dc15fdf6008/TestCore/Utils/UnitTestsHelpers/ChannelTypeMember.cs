using FanceeAnalyticsData.Models.Analytics;

namespace TestCore.Utils.UnitTestsHelpers;

public class ChannelTypeMember : EnumMember<ChannelType>
{
}