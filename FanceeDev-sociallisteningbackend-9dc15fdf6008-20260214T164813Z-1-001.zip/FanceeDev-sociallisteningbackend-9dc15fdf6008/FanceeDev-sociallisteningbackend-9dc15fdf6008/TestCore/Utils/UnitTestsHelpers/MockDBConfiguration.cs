﻿using Microsoft.Extensions.Configuration;

namespace TestCore.Utils.UnitTestsHelpers;

public static class MockDBConfiguration
{
    public static IConfiguration GetDBConfiguration(Dictionary<string, string>? keyValuePairs = null) =>
        new ConfigurationBuilder()
            .AddInMemoryCollection((keyValuePairs ?? new Dictionary<string, string>())!)
            .Build();
}