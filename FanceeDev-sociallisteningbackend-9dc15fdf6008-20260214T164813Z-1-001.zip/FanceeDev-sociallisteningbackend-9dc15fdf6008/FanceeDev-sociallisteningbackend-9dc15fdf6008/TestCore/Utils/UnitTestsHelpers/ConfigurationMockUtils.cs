﻿using Microsoft.Extensions.Configuration;

namespace TestCore.Utils.UnitTestsHelpers;

public static class ConfigurationMockUtils
{
    /// <summary>
    ///     Creates a new configuration mock without any values.
    /// </summary>
    /// <returns></returns>
    public static IConfiguration Create() => Create(new());

    /// <summary>
    ///     Creates a new configuration mock with the given values.
    /// </summary>
    /// <param name="values"></param>
    /// <returns></returns>
    public static IConfiguration Create(Dictionary<string, string?> values) =>
        new ConfigurationBuilder()
            .AddInMemoryCollection(values)
            .Build();
}