using FanceeAnalyticsData.Models.Analytics;

namespace TestCore.Utils.UnitTestsHelpers;

public class SubscriptionTypeMember : EnumMember<SubscriptionType>
{
}