﻿using System.Security.Claims;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Mvc;

namespace TestCore.Utils.UnitTestsHelpers;

public static class ControllerContextExtensions
{
    public static void SetUser(this ControllerContext context, User user)
    {
        context.AddOrUpdateClaim(new("user", user.FanceeUsersId.ToString()));
        context.AddOrUpdateClaim(new("platformUserId", user.UserId.ToString()));
        context.AddOrUpdateClaim(new("type", user.Type.ToString()));
    }

    public static void SetUserId(this ControllerContext context, string userId)
    {
        context.AddOrUpdateClaim(new("user", userId));
    }

    private static void AddOrUpdateClaim(this ControllerContext context, Claim newClaim)
    {
        if (context.HttpContext.User.Identity is not ClaimsIdentity identity)
            return;

        var existingClaim = identity.FindFirst(newClaim.Type);
        if (existingClaim != null)
            identity.RemoveClaim(existingClaim);

        identity.AddClaim(newClaim);
    }
}