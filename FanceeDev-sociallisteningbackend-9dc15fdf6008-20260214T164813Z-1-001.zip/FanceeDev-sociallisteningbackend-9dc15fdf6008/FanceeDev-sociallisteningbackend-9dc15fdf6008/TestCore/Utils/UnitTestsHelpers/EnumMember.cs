﻿namespace TestCore.Utils.UnitTestsHelpers;

public class EnumMember<TEnum> where TEnum : struct, Enum
{
    protected EnumMember()
    {
    }

    public static IEnumerable<object[]> Data()
    {
        return Enum.GetValues<TEnum>().Select(type => new object[] { type });
    }
}