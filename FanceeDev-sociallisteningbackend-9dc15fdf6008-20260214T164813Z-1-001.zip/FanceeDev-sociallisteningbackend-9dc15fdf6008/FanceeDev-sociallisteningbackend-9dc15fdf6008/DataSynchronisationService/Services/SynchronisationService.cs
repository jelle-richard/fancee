using DataSynchronisationService.Exceptions;
using DataSynchronisationService.Jobs.Inputs;
using DataSynchronisationService.Persistence.Generic;
using SocialListeningCore.Dtos.CronJobs;
using SocialListeningCore.Dtos.Enums;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;
using SocialListeningCore.Services.Scheduler;
using SocialListeningCore.Utils.Cron;

namespace DataSynchronisationService.Services;

public class SynchronisationService(
    ISchedulerService<RequestTicketingDataInput> schedulerService,
    IEnumerable<DataMessageStrategy.DataMessageStrategy> messageStrategies,
    IGenericTicketingDataDao ticketingDao) : ISynchronisationService
{
    public async Task RunAsync(RequestTicketingDataInput input)
    {
        var lastCreatedDateTime = await RetrieveLastInsertedDateTime(input.Type.ToString().ToLower());
        var message = GenerateRabbitMessage(input.Type, input.SyncType, lastCreatedDateTime);
        var strategy = messageStrategies.FirstOrDefault(s => s.Type == input.Type) ?? throw new UnknownStrategyRequiredForSynchronisationMessageException();

        await strategy.ExecuteAsync(message);
    }

    public List<CronJobResponse<RequestTicketingDataInput>> InitializeSyncJobs()
    {
        var ticketingDataTypes = Enum.GetValues<TicketingDataType>();
        var jobTypes = Enum.GetValues<SynchronisationType>();
        var jobs = new List<CronJobResponse<RequestTicketingDataInput>>();

        foreach (var ticketingDataType in ticketingDataTypes)
        {
            jobs.AddRange(jobTypes.Select(jobType => new RequestTicketingDataInput
                {
                    Name = $"{nameof(RequestTicketingDataInput)} - {ticketingDataType.ToString()} - {jobType.ToString()}",
                    Cron = CronConstants.CronRunEveryMinute,
                    Type = ticketingDataType,
                    SyncType = jobType
                }
            ).Select(schedulerService.AddOrUpdateSchedule));
        }

        return jobs;
    }

    private async Task<DateTime?> RetrieveLastInsertedDateTime(string collection) =>
        (await ticketingDao.GetLastCreatedRecordAsync(collection))?.CreatedOn;

    private static IRequestTicketingDataMessage GenerateRabbitMessage(TicketingDataType type, SynchronisationType syncType, DateTime? lastCreatedDateTime) =>
        type switch
        {
            TicketingDataType.Clients => new RequestTicketingUserDataMessage
            {
                RequestCreatedFrom = lastCreatedDateTime,
                SyncType = syncType
            },
            TicketingDataType.Events => new RequestTicketingEventDataMessage
            {
                RequestCreatedFrom = lastCreatedDateTime,
                SyncType = syncType
            },
            var _ => throw new ArgumentOutOfRangeException(nameof(type), type, null)
        };
}