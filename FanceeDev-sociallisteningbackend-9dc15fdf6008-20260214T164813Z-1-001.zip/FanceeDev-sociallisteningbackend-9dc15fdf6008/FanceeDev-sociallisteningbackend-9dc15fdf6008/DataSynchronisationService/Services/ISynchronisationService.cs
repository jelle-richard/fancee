using DataSynchronisationService.Jobs.Inputs;
using SocialListeningCore.Dtos.CronJobs;
using SocialListeningCore.Services.Cron;

namespace DataSynchronisationService.Services;

public interface ISynchronisationService : ICronService<RequestTicketingDataInput>
{
    /// <summary>
    /// Used to initialize the Synchronisation jobs on startup of application.
    /// </summary>
    /// <returns></returns>
    public List<CronJobResponse<RequestTicketingDataInput>> InitializeSyncJobs();
}