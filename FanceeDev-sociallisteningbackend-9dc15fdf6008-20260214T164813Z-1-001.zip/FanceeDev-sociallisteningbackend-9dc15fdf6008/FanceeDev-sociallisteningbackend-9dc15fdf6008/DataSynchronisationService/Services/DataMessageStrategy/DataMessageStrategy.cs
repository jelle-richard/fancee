﻿using DataSynchronisationService.Exceptions;
using DataSynchronisationService.Persistence.Generic;
using Fs.MessageBus.Publishers;
using SocialListeningCore.Dtos.Enums;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Services.DataMessageStrategy;

public abstract class DataMessageStrategy
{
    /// <summary>
    /// Gets the type of data of which this strategy is being used for.
    /// </summary>
    public abstract TicketingDataType Type { get; }

    /// <summary>
    /// Executes specific logic based on the type of data in the message.
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public abstract Task ExecuteAsync(IRequestTicketingDataMessage message);

    /// <summary>
    /// Handles data update synchronisation.
    /// </summary>
    /// <param name="reply"></param>
    /// <returns></returns>
    protected abstract Task SynchronizeUpdate(IRequestTicketingDataMessage reply);

    /// <summary>
    /// Handles data creation/insertion synchronisation.
    /// </summary>
    /// <param name="reply"></param>
    /// <returns></returns>
    protected abstract Task SynchronizeCreate(IRequestTicketingDataMessage reply);

    protected async Task ExecuteStrategyAsync<TItem>(
        IRequestTicketingDataMessage message,
        IMessagePublisher<IRequestTicketingDataMessage> publisher,
        IGenericDao<TItem> dataDao)
    {
        if (message.SyncType == SynchronisationType.ValidateExistingAndOrUpdate)
            message.RequestUpdateFor = await dataDao.RetrieveExistingDataAsync();

        var reply = publisher.Call<IRequestTicketingDataMessage>(message);

        if (reply is null)
            return;

        await ExecuteSyncStrategy(reply);
    }

    private async Task ExecuteSyncStrategy(IRequestTicketingDataMessage reply)
    {
        switch (reply.SyncType)
        {
            case SynchronisationType.FetchNewlyCreated:
                await SynchronizeCreate(reply);
                break;

            case SynchronisationType.ValidateExistingAndOrUpdate:
                await SynchronizeUpdate(reply);
                break;

            default:
                throw new UnknownSynchronisationTypeException(reply.SyncType.ToString());
        }
    }
}