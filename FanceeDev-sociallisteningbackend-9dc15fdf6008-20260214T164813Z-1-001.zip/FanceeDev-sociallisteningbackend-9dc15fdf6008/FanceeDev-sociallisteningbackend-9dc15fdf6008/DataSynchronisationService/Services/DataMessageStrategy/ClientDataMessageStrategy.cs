﻿using System.Linq.Expressions;
using System.Text.Json;
using DataSynchronisationService.Persistence.Generic;
using DataSynchronisationService.Persistence.Users;
using FanceeAnalyticsData.Models.TicketingData;
using Fs.MessageBus.Publishers;
using Microsoft.IdentityModel.Tokens;
using MongoDB.Driver;
using SocialListeningCore.Dtos.Enums;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Services.DataMessageStrategy;

public class ClientDataMessageStrategy(IMessagePublisher<IRequestTicketingDataMessage> dataRequestPublisher, IClientDao clientDao, IUserDao userDao) : DataMessageStrategy
{
    public override TicketingDataType Type => TicketingDataType.Clients;

    public override async Task ExecuteAsync(IRequestTicketingDataMessage message)
    {
        await ExecuteStrategyAsync(message, dataRequestPublisher, clientDao);
    }

    protected override async Task SynchronizeCreate(IRequestTicketingDataMessage reply)
    {
        if (reply.SerializedCreatedData.IsNullOrEmpty())
            return;

        var created = JsonSerializer.Deserialize<Client[]>(reply.SerializedCreatedData);

        if (created is { Length: > 0 })
            await Task.WhenAll(created.Select(ProcessClient));
    }

    protected override async Task SynchronizeUpdate(IRequestTicketingDataMessage reply)
    {
        if (reply.SerializedUpdatedData.IsNullOrEmpty())
            return;

        var existingUsers = JsonSerializer.Deserialize<Client[]>(reply.SerializedUpdatedData);

        if (existingUsers is { Length: > 0 })
        {
            await DeleteOutdatedClientsUsers(reply.RequestUpdateFor, existingUsers);
            await Task.WhenAll(existingUsers.Select(ProcessClient));
        }
    }

    private async Task DeleteOutdatedClientsUsers(IEnumerable<Guid> socialClientIds, IEnumerable<Client> existingUsers)
    {
        var ticketingClientIds = existingUsers.Select(c => c.UserId).ToList();
        var idsNotInTicketing = socialClientIds.Except(ticketingClientIds).ToList();

        await clientDao.DeleteByIdsAsync(idsNotInTicketing);
        await userDao.DeleteByIdsAsync(idsNotInTicketing);
    }

    private async Task ProcessClient(Client client)
    {
        await InsertOrUpdate(clientDao, client, i => i.UserId, client.UserId);
        if (client.User is not null)
            await InsertOrUpdate(userDao, client.User, i => i.UserId, client.UserId);
    }

    private static async Task InsertOrUpdate<TItem, TFilter>(IGenericDao<TItem> genericDao, TItem item, Expression<Func<TItem, TFilter>> filterExpression, TFilter value)
    {
        var filter = new FilterDefinitionBuilder<TItem>().Eq(filterExpression, value);
        var recordExists = await genericDao.AnyAsync(filter);

        if (recordExists)
            await genericDao.UpdateAsync(item);
        else
            await genericDao.CreateAsync(item);
    }
}