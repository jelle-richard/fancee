using System.Linq.Expressions;
using System.Text.Json;
using DataSynchronisationService.Persistence.Events;
using DataSynchronisationService.Persistence.Generic;
using FanceeAnalyticsData.Models.TicketingData;
using Fs.MessageBus.Publishers;
using Microsoft.IdentityModel.Tokens;
using MongoDB.Driver;
using SocialListeningCore.Dtos.Enums;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Services.DataMessageStrategy;

public class EventDataMessageStrategy(IMessagePublisher<IRequestTicketingDataMessage> dataRequestPublisher, IEventDao eventDao) : DataMessageStrategy
{
    public override TicketingDataType Type => TicketingDataType.Events;

    public override async Task ExecuteAsync(IRequestTicketingDataMessage message)
    {
        await ExecuteStrategyAsync(message, dataRequestPublisher, eventDao);
    }

    protected override async Task SynchronizeCreate(IRequestTicketingDataMessage reply)
    {
        if (reply.SerializedCreatedData.IsNullOrEmpty())
            return;

        var created = JsonSerializer.Deserialize<Event[]>(reply.SerializedCreatedData);

        if (created is { Length: > 0 })
            await Task.WhenAll(created.Select(ProcessEvent));
    }

    protected override async Task SynchronizeUpdate(IRequestTicketingDataMessage reply)
    {
        if (reply.SerializedUpdatedData.IsNullOrEmpty())
            return;

        var existingEvents = JsonSerializer.Deserialize<Event[]>(reply.SerializedUpdatedData);

        if (existingEvents is { Length: > 0 })
        {
            await DeleteOutdatedEvents(reply.RequestUpdateFor, existingEvents);
            await Task.WhenAll(existingEvents.Select(ProcessEvent));
        }
    }

    private async Task DeleteOutdatedEvents(IEnumerable<Guid> socialEventIds, IEnumerable<Event> existingEvents)
    {
        var ticketingClientIds = existingEvents.Select(c => c.EventId).ToList();
        var idsNotInTicketing = socialEventIds.Except(ticketingClientIds).ToList();

        await eventDao.DeleteByIdsAsync(idsNotInTicketing);
    }

    private async Task ProcessEvent(Event @event)
    {
        await InsertOrUpdate(eventDao, @event, i => i.EventId, @event.EventId);
    }

    private static async Task InsertOrUpdate<TItem, TFilter>(IGenericDao<TItem> genericDao, TItem item, Expression<Func<TItem, TFilter>> filterExpression, TFilter value)
    {
        var filter = new FilterDefinitionBuilder<TItem>().Eq(filterExpression, value);
        var recordExists = await genericDao.AnyAsync(filter);

        if (recordExists)
            await genericDao.UpdateAsync(item);
        else
            await genericDao.CreateAsync(item);
    }
}