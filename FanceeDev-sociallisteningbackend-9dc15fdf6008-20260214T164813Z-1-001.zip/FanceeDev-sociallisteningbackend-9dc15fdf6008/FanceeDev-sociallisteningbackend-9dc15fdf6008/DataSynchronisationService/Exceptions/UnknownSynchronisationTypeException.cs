namespace DataSynchronisationService.Exceptions;

public class UnknownSynchronisationTypeException(string? message) : Exception(message);