using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Dtos.Enums;

namespace DataSynchronisationService.Jobs.Inputs;

public class RequestTicketingDataInput : BasicCron
{
    public required TicketingDataType Type { get; set; }
    public required SynchronisationType SyncType { get; set; }
}