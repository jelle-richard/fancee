using CronScheduler.Extensions.StartupInitializer;
using DataSynchronisationService.Services;
using SocialListeningCore.Logging;

namespace DataSynchronisationService.Jobs;

public class InitRequestTicketingDataJob(IServiceProvider serviceProvider, ILoggerFactory loggerFactory) : IStartupJob
{
    private static readonly string Name = nameof(InitRequestTicketingDataJob);
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("[{DateTime}]: {Name} started.", DateTime.UtcNow, Name);
        await Task.Run(() => serviceProvider.GetRequiredService<ISynchronisationService>().InitializeSyncJobs(), cancellationToken);
        _logger.LogInformation("[{DateTime}]: {Name} stopped.", DateTime.UtcNow, Name);
    }
}