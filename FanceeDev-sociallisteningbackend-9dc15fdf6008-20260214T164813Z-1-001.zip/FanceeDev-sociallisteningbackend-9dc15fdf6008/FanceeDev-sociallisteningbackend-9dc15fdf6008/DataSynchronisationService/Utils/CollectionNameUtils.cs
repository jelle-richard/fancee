using System.Text.RegularExpressions;
using FanceeAnalyticsData.Models;

namespace DataSynchronisationService.Utils;

public static partial class CollectionNameUtils
{
    /// <summary>
    /// Used to transform the enum into a string representation for a mongo DB collection.
    /// E.g. TicketingUsers => ticketing_users.
    /// </summary>
    /// <param name="collectionName"></param>
    /// <returns></returns>
    public static string GetCollectionName(this CollectionName collectionName) =>
        collectionName.ToString().AddUnderscores().ToLower();

    [GeneratedRegex("(?<!^)([A-Z])")]
    private static partial Regex UnderscorePositionFinderRegex();

    private static string AddUnderscores(this string collectionName) =>
        UnderscorePositionFinderRegex().Replace(collectionName, "_$1");
}