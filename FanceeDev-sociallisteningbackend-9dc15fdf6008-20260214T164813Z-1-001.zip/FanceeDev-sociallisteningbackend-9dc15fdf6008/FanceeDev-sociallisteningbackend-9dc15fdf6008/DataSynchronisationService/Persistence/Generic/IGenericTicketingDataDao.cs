using FanceeAnalyticsData.Models.Analytics;

namespace DataSynchronisationService.Persistence.Generic;

public interface IGenericTicketingDataDao
{
    /// <summary>
    /// Retrieves the record that has been inserted last based on created on datetime.
    /// </summary>
    /// <param name="collectionId"></param>
    /// <returns></returns>
    public Task<BasicMongoModel?> GetLastCreatedRecordAsync(string collectionId);

    /// <summary>
    /// Retrieves the record that has been updated last based on updated on datetime.
    /// </summary>
    /// <param name="collectionId"></param>
    /// <returns></returns>
    public Task<BasicMongoModel?> GetLastUpdatedRecordAsync(string collectionId);
}