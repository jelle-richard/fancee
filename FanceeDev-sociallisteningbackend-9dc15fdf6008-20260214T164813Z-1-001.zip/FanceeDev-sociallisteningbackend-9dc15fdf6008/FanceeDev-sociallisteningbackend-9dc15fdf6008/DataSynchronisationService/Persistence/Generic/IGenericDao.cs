using MongoDB.Driver;

namespace DataSynchronisationService.Persistence.Generic;

public interface IGenericDao<TModel>
{
    /// <summary>
    /// Deletes records in a collection if they exist in the List of Guids.
    /// </summary>
    /// <param name="ids"></param>
    /// <returns></returns>
    public Task DeleteByIdsAsync(IEnumerable<Guid> ids);

    /// <summary>
    /// Checks if any of the records exist in the collection by usage of a FilterDefinition.
    /// </summary>
    /// <param name="filter"></param>
    /// <returns></returns>
    public Task<bool> AnyAsync(FilterDefinition<TModel> filter);

    /// <summary>
    /// Creates a new record in the collection
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    public Task CreateAsync(TModel model);

    /// <summary>
    /// Updates an existing model in the collection by usage of a FilterDefinition.
    /// </summary>
    /// <param name="model"></param>
    /// <param name="filter"></param>
    /// <returns></returns>
    public Task UpdateAsync(TModel model, FilterDefinition<TModel>? filter = null);

    /// <summary>
    /// Retrieves a list of Guids of existing data in the collection.
    /// </summary>
    /// <returns></returns>
    public Task<IList<Guid>> RetrieveExistingDataAsync();
}