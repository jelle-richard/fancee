using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Persistence;

namespace DataSynchronisationService.Persistence.Generic;

public class GenericTicketingDataDao(IConfiguration configuration, IMongoClient context) : BaseMongoDao<BasicMongoModel>(
    configuration.GetValue<string>("Mongo:Database:Default"),
    string.Empty,
    context), IGenericTicketingDataDao
{
    public async Task<BasicMongoModel?> GetLastCreatedRecordAsync(string collectionId)
    {
        var sortDefinition = new SortDefinitionBuilder<BasicMongoModel>().Descending(item => item.CreatedOn);
        return await GetAsync(collectionId, sortDefinition);
    }

    public async Task<BasicMongoModel?> GetLastUpdatedRecordAsync(string collectionId)
    {
        var sortDefinition = new SortDefinitionBuilder<BasicMongoModel>().Descending(item => item.UpdatedOn);
        return await GetAsync(collectionId, sortDefinition);
    }

    private async Task<BasicMongoModel?> GetAsync(string collectionId, SortDefinition<BasicMongoModel> sortDefinition)
    {
        var cursor = await Collection(collectionId).Find(FilterDefinition<BasicMongoModel>.Empty).Sort(sortDefinition).ToCursorAsync();
        return await cursor.FirstOrDefaultAsync();
    }
}