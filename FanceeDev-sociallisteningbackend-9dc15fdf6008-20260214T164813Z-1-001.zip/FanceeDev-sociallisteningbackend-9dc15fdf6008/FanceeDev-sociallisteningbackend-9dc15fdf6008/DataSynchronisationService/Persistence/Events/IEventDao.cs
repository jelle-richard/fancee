using DataSynchronisationService.Persistence.Generic;
using FanceeAnalyticsData.Models.TicketingData;

namespace DataSynchronisationService.Persistence.Events;

public interface IEventDao : IGenericDao<Event>;