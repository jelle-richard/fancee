using DataSynchronisationService.Utils;
using FanceeAnalyticsData.Models;
using FanceeAnalyticsData.Models.TicketingData;
using MongoDB.Driver;
using SocialListeningCore.Persistence;

namespace DataSynchronisationService.Persistence.Events;

public class EventDao(IConfiguration configuration, IMongoClient context) : BaseMongoDao<Event>(
    configuration.GetValue<string>(
        "Mongo:Database:Default"),
    CollectionName.Events.GetCollectionName(),
    context), IEventDao
{
    public async Task DeleteByIdsAsync(IEnumerable<Guid> ids)
    {
        var deletionFilter = Builders<Event>.Filter.In(e => e.EventId, ids);
        await DeleteByFilterAsync(deletionFilter);
    }

    public async Task<bool> AnyAsync(FilterDefinition<Event> filter) =>
        await (await Collection().FindAsync(filter)).AnyAsync();

    public async Task CreateAsync(Event model) => await Collection().InsertOneAsync(model);

    public async Task UpdateAsync(Event model, FilterDefinition<Event>? filter = null)
    {
        filter ??= new FilterDefinitionBuilder<Event>().Eq(e => e.EventId, model.EventId);
        var updateDefintion = BuildEventUpdateDefinition(model);

        await Collection().UpdateOneAsync(filter, updateDefintion);
    }

    public async Task<IList<Guid>> RetrieveExistingDataAsync()
    {
        var cursor = await Collection().FindAsync(FilterDefinition<Event>.Empty);
        return (await cursor.ToListAsync()).Select(e => e.EventId).ToList();
    }

    private async Task DeleteByFilterAsync(FilterDefinition<Event> deletionFilter) =>
        await Collection().DeleteOneAsync(deletionFilter);

    private static UpdateDefinition<Event> BuildEventUpdateDefinition(Event model)
    {
        return Builders<Event>.Update
            .Set(e => e.EventId, model.EventId)
            .Set(e => e.Name, model.Name)
            .Set(e => e.Description, model.Description)
            .Set(e => e.Status, model.Status)
            .Set(e => e.Type, model.Type)
            .Set(e => e.OrganizationId, model.OrganizationId)
            .Set(e => e.StartDate, model.StartDate)
            .Set(e => e.EndDate, model.EndDate)
            .Set(e => e.AddressId, model.AddressId)
            .Set(e => e.Address, model.Address)
            .Set(e => e.MinimumAge, model.ReservationTimeMinutes)
            .Set(e => e.ReservationTimeMinutes, model.ReservationTimeMinutes)
            .Set(e => e.Products, model.Products)
            .Set(e => e.Shops, model.Shops);
    }
}