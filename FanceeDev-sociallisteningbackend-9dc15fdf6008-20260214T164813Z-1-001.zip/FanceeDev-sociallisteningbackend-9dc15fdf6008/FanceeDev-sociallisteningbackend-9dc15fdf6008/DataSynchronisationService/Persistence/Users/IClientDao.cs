using DataSynchronisationService.Persistence.Generic;
using FanceeAnalyticsData.Models.TicketingData;

namespace DataSynchronisationService.Persistence.Users;

public interface IClientDao : IGenericDao<Client>;