using DataSynchronisationService.Utils;
using FanceeAnalyticsData.Models;
using FanceeAnalyticsData.Models.TicketingData;
using MongoDB.Driver;
using SocialListeningCore.Persistence;

namespace DataSynchronisationService.Persistence.Users;

public class ClientDao(IConfiguration configuration, IMongoClient context) : BaseMongoDao<Client>(
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionName.Clients.GetCollectionName(),
    context), IClientDao
{
    public async Task DeleteByIdsAsync(IEnumerable<Guid> ids)
    {
        var deletionFilter = Builders<Client>.Filter.In(c => c.UserId, ids);
        await DeleteByFilterAsync(deletionFilter);
    }

    public async Task<IList<Guid>> RetrieveExistingDataAsync()
    {
        var cursor = await Collection().FindAsync(FilterDefinition<Client>.Empty);
        return (await cursor.ToListAsync()).Select(c => c.UserId).ToList();
    }

    public async Task<bool> AnyAsync(FilterDefinition<Client> filter) =>
        await (await Collection().FindAsync(filter)).AnyAsync();

    public async Task CreateAsync(Client model) => await Collection().InsertOneAsync(model);

    public async Task UpdateAsync(Client model, FilterDefinition<Client>? filter = null)
    {
        filter ??= new FilterDefinitionBuilder<Client>().Eq(c => c.UserId, model.UserId);
        var updateDefinition = BuildClientUpdateDefinition(model);

        await Collection().UpdateOneAsync(filter, updateDefinition);
    }

    public async Task DeleteByIdAsync(Guid id)
    {
        var deletionFilter = Builders<Client>.Filter.Eq(c => c.UserId, id);
        await DeleteByFilterAsync(deletionFilter);
    }

    private async Task DeleteByFilterAsync(FilterDefinition<Client> deletionFilter) =>
        await Collection().DeleteOneAsync(deletionFilter);

    private static UpdateDefinition<Client> BuildClientUpdateDefinition(Client model)
    {
        return Builders<Client>.Update
            .Set(c => c.UserId, model.UserId)
            .Set(c => c.Referer, model.Referer)
            .Set(c => c.FacebookId, model.FacebookId);
    }
}