using DataSynchronisationService.Utils;
using FanceeAnalyticsData.Models;
using FanceeAnalyticsData.Models.TicketingData;
using MongoDB.Driver;
using SocialListeningCore.Persistence;

namespace DataSynchronisationService.Persistence.Users;

public class UserDao(IConfiguration configuration, IMongoClient context) : BaseMongoDao<User>(
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionName.TicketingUsers.GetCollectionName(),
    context), IUserDao
{
    public async Task DeleteByIdsAsync(IEnumerable<Guid> ids)
    {
        var deletionFilter = Builders<User>.Filter.In(c => c.UserId, ids);
        await DeleteByFilterAsync(deletionFilter);
    }

    public async Task<bool> AnyAsync(FilterDefinition<User> filter)
    {
        var cursor = await Collection().FindAsync(filter);
        return await cursor.AnyAsync();
    }

    public async Task CreateAsync(User model) => await Collection().InsertOneAsync(model);

    public async Task UpdateAsync(User model, FilterDefinition<User>? filter = null)
    {
        filter ??= new FilterDefinitionBuilder<User>().Eq(c => c.UserId, model.UserId);
        var updateDefinition = BuildClientUpdateDefinition(model);

        await Collection().UpdateOneAsync(filter, updateDefinition);
    }

    public async Task<IList<Guid>> RetrieveExistingDataAsync()
    {
        var cursor = await Collection().FindAsync(FilterDefinition<User>.Empty);
        return (await cursor.ToListAsync()).Select(c => c.UserId).ToList();
    }

    private async Task DeleteByFilterAsync(FilterDefinition<User> deletionFilter)
    {
        await Collection().DeleteOneAsync(deletionFilter);
    }

    private static UpdateDefinition<User> BuildClientUpdateDefinition(User model) =>
        Builders<User>.Update
            .Set(c => c.UserId, model.UserId)
            .Set(c => c.FanceeUsersId, model.FanceeUsersId)
            .Set(c => c.Type, model.Type)
            .Set(c => c.Email, model.Email)
            .Set(c => c.LastLogin, model.LastLogin)
            .Set(c => c.DateOfBirth, model.DateOfBirth)
            .Set(c => c.AccountVerifyId, model.AccountVerifyId)
            .Set(c => c.UserContactInfo, model.UserContactInfo);
}