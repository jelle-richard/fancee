using DataSynchronisationService.Jobs;
using DataSynchronisationService.Jobs.Inputs;
using DataSynchronisationService.Persistence.Events;
using DataSynchronisationService.Persistence.Generic;
using DataSynchronisationService.Persistence.Users;
using DataSynchronisationService.Services;
using DataSynchronisationService.Services.DataMessageStrategy;
using FanceeAnalyticsData.Models.TicketingData;
using SocialListeningCore;
using SocialListeningCore.Logging;
using SocialListeningCore.Services.Cron;
using SocialListeningCore.Services.Scheduler;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "DataSynchronisationService",
        EndpointName = "DataSynchronisationService v1"
    }
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddScheduler(sb =>
    {
        sb.Services.AddStartupJob<InitRequestTicketingDataJob>();
        _ = sb.AddUnobservedTaskExceptionHandler(sp =>
        {
            var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger(MongoLogger.Name);
            return
                (sender, args) =>
                {
                    logger.MongoLogException(null, args.Exception);
                    args.SetObserved();
                };
        });
    });
};

builder.AddDependency<ISynchronisationService, SynchronisationService>(ServiceLifetime.Scoped);
builder.AddDependency<ICronService<RequestTicketingDataInput>, SynchronisationService>(ServiceLifetime.Scoped);
builder.AddDependency<ISchedulerService<RequestTicketingDataInput>, SchedulerService<RequestTicketingDataInput, ISynchronisationService>>(ServiceLifetime.Scoped);
builder.AddDependency<IGenericTicketingDataDao, GenericTicketingDataDao>(ServiceLifetime.Scoped);

builder.AddDependency<DataMessageStrategy, ClientDataMessageStrategy>(ServiceLifetime.Scoped);
builder.AddDependency<DataMessageStrategy, EventDataMessageStrategy>(ServiceLifetime.Scoped);

builder.AddDependency<IGenericDao<User>, UserDao>(ServiceLifetime.Scoped);
builder.AddDependency<IGenericDao<Client>, ClientDao>(ServiceLifetime.Scoped);
builder.AddDependency<IGenericDao<Event>, EventDao>(ServiceLifetime.Scoped);

builder.AddDependency<IClientDao, ClientDao>(ServiceLifetime.Scoped);
builder.AddDependency<IUserDao, UserDao>(ServiceLifetime.Scoped);
builder.AddDependency<IEventDao, EventDao>(ServiceLifetime.Scoped);

var app = builder.Build();
await app.RunStartupJobsAync();
app.Run();