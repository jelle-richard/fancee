using OrganizationService.Persistence.Organizations;
using OrganizationService.Services.Organizations;
using SocialListeningCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "OrganizationService",
        EndpointName = "OrganizationService v1"
    }
};

builder.AddDependency<IOrganizationsService, OrganizationsService>(ServiceLifetime.Scoped);
builder.AddDependency<IOrganizationsDao, OrganizationsDao>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();