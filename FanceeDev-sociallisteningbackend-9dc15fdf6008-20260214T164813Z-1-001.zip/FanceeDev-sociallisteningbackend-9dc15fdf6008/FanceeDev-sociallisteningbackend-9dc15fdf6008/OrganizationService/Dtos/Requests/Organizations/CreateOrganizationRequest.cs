using FanceeAnalyticsData.Models.Analytics;

namespace OrganizationService.Dtos.Requests.Organizations;

public class CreateOrganizationRequest
{
    public string? OrganizationName { get; set; }
    public CountryCode CountryOfOperation { get; set; }
    public string? ChamberOfCommerce { get; set; }
    public string? IBAN { get; set; }
    public string? BIC { get; set; }
    public string? VATIdentifier { get; set; }
}