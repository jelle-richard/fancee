using System.Text.Json.Serialization;
using FanceeAnalyticsData.Models.Analytics;

namespace OrganizationService.Dtos.Requests.Organizations;

public class UpdateOrganizationRequest
{
    public string? OrganizationName { get; set; }

    public CountryCode CountryOfOperation { get; set; }

    public string? ChamberOfCommerce { get; set; }

    [JsonPropertyName("iban")]
    public string? IBAN { get; set; }

    [JsonPropertyName("bic")]
    public string? BIC { get; set; }

    [JsonPropertyName("vatIdentifier")]
    public string? VATIdentifier { get; set; }
}