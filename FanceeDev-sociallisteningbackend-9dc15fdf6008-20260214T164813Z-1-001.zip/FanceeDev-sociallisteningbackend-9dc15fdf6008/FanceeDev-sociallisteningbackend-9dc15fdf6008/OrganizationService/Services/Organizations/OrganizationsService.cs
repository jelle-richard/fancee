using FanceeAnalyticsData.Models.Analytics;
using OrganizationService.Dtos.Requests.Organizations;
using OrganizationService.Persistence.Organizations;

namespace OrganizationService.Services.Organizations;

public class OrganizationsService(IOrganizationsDao organizationsDao) : IOrganizationsService
{
    public async Task<IEnumerable<Organization>> ToListAsync() => await organizationsDao.ToListAsync();

    public async Task<IEnumerable<Organization>> ToListAsync(Guid userId) => await organizationsDao.ToListAsync(userId);

    public async Task<Organization> ByIdAsync(string id, Guid userId) => await organizationsDao.ByIdAsync(id, userId);

    public async Task<Organization> ByIdAsync(string id) => await organizationsDao.ByIdAsync(id);

    public async Task<Organization> CreateAsync(CreateOrganizationRequest request, Guid userId) =>
        await organizationsDao.CreateAsync(new()
        {
            OrganizationName = request.OrganizationName,
            CountryOfOperation = request.CountryOfOperation,
            ChamberOfCommerce = request.ChamberOfCommerce,
            IBAN = request.IBAN,
            BIC = request.BIC,
            VATIdentifier = request.VATIdentifier,
            UserId = userId
        });

    public async Task<Organization> UpdateAsync(string id, UpdateOrganizationRequest request, Guid userId)
    {
        var organization = await organizationsDao.ByIdAsync(id);

        CheckAndUpdate(request, organization);

        return await organizationsDao.UpdateAsync(organization);
    }

    public async Task<bool> DeleteAsync(string id) => await organizationsDao.DeleteAsync(id);

    private static void CheckAndUpdate(UpdateOrganizationRequest request, Organization organizationToUpdate)
    {
        if (request.OrganizationName != organizationToUpdate!.OrganizationName)
            organizationToUpdate.OrganizationName = request.OrganizationName;

        if (request.CountryOfOperation != organizationToUpdate!.CountryOfOperation)
            organizationToUpdate.CountryOfOperation = request.CountryOfOperation;

        if (request.ChamberOfCommerce != organizationToUpdate!.ChamberOfCommerce)
            organizationToUpdate.ChamberOfCommerce = request.ChamberOfCommerce;

        if (request.IBAN != organizationToUpdate!.IBAN)
            organizationToUpdate.IBAN = request.IBAN;

        if (request.BIC != organizationToUpdate!.BIC)
            organizationToUpdate.BIC = request.BIC;

        if (request.VATIdentifier != organizationToUpdate!.VATIdentifier)
            organizationToUpdate.VATIdentifier = request.VATIdentifier;
    }
}