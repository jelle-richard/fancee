using FanceeAnalyticsData.Models.Analytics;
using OrganizationService.Dtos.Requests.Organizations;

namespace OrganizationService.Services.Organizations;

public interface IOrganizationsService
{
    /// <summary>
    /// Gets all organizations.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<Organization>> ToListAsync();

    /// <summary>
    /// Gets user's own organization, currently user always has one organization.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<IEnumerable<Organization>> ToListAsync(Guid userId);

    /// <summary>
    /// Gets an organizations by id based on userId.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<Organization> ByIdAsync(string id, Guid userId);

    /// <summary>
    /// Gets an organization by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<Organization> ByIdAsync(string id);

    /// <summary>
    /// Creates an organization by request.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="user">person who creates the organization</param>
    /// <returns></returns>
    public Task<Organization> CreateAsync(CreateOrganizationRequest request, Guid userId);

    /// <summary>
    /// Updates an organization by id and request based on userId.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="request"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<Organization> UpdateAsync(string id, UpdateOrganizationRequest request, Guid userId);

    /// <summary>
    /// Deletes an organization by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<bool> DeleteAsync(string id);
}