using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;

namespace OrganizationService.Persistence.Organizations;

public class OrganizationsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<Organization>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Organizations"),
    mongoDatabase), IOrganizationsDao
{
    public async Task<Organization> ByIdAsync(string id, Guid userId)
    {
        var filter = Builders<Organization>.Filter.Eq(dbItem => dbItem.Id, id);
        filter &= Builders<Organization>.Filter.Eq(dbItem => dbItem.UserId, userId);

        return await Collection.Find(filter).FirstOrDefaultAsync() ?? throw new OrganizationNotFoundException(id);
    }

    public async Task<Organization> ByIdAsync(string id)
    {
        var filter = Builders<Organization>.Filter.Eq(dbItem => dbItem.Id, id);

        return await Collection.Find(filter).FirstOrDefaultAsync() ?? throw new OrganizationNotFoundException(id);
    }

    public async Task<IEnumerable<Organization>> ToListAsync()
    {
        var filter = Builders<Organization>.Filter.Empty;

        return await Collection.Find(filter).ToListAsync();
    }

    public async Task<IEnumerable<Organization>> ToListAsync(Guid userId)
    {
        var filter = Builders<Organization>.Filter.Eq(dbItem => dbItem.UserId, userId);

        return await Collection.Find(filter).ToListAsync();
    }

    public override UpdateDefinition<Organization> GetUpdateDefinition(Organization? model)
    {
        try
        {
            return Builders<Organization>.Update.Combine(
                new List<UpdateDefinition<Organization>>
                {
                    Builders<Organization>.Update.Set(nameof(model.FirstName), model?.FirstName),
                    Builders<Organization>.Update.Set(nameof(model.LastName), model?.LastName),
                    Builders<Organization>.Update.Set(nameof(model.OrganizationName), model?.OrganizationName),
                    Builders<Organization>.Update.Set(nameof(model.CountryOfOperation), model?.CountryOfOperation),
                    Builders<Organization>.Update.Set(nameof(model.ChamberOfCommerce), model?.ChamberOfCommerce),
                    Builders<Organization>.Update.Set(nameof(model.IBAN), model?.IBAN),
                    Builders<Organization>.Update.Set(nameof(model.BIC), model?.BIC),
                    Builders<Organization>.Update.Set(nameof(model.VATIdentifier), model?.VATIdentifier),
                    base.GetUpdateDefinition(model)
                }
            );
        }
        catch
        {
            return base.GetUpdateDefinition(model);
        }
    }
}