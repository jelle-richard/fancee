using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Persistence;

namespace OrganizationService.Persistence.Organizations;

public interface IOrganizationsDao : IMongoDao<Organization>
{
    /// <summary>
    /// Gets all organzanitions.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<Organization>> ToListAsync();

    /// <summary>
    /// Gets all organzanitions based on userId.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<IEnumerable<Organization>> ToListAsync(Guid userId);

    /// <summary>
    /// Gets the organization by id based on userId.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<Organization> ByIdAsync(string id, Guid userId);

    /// <summary>
    /// Gets the organization by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<Organization> ByIdAsync(string id);
}