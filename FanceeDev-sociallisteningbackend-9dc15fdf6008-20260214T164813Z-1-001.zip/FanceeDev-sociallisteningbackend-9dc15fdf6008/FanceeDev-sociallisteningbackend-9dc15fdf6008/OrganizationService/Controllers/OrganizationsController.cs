using System.Net.Mime;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using OrganizationService.Dtos.Requests.Organizations;
using OrganizationService.Services.Organizations;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Logging;
using SocialListeningCore.Utils.HttpContext;

namespace OrganizationService.Controllers;

[Authorize]
[ApiController]
[Produces(MediaTypeNames.Application.Json)]
[Route("/[controller]")]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class OrganizationsController(IOrganizationsService organizationsService, ILoggerFactory loggerFactory) : ControllerBase
{
    private Guid UserId => User.GetUserId();
    private UserType CurrentUserType => User.GetUserType() ?? UserType.Organization;
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);

    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<Organization>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<Organization>>>> List()
    {
        if (CurrentUserType.HasFlag(UserType.Admin))
        {
            return Ok(new ApiResponse<IEnumerable<Organization>>
            {
                Data = await organizationsService.ToListAsync()
            });
        }

        return Ok(new ApiResponse<IEnumerable<Organization>>
        {
            Data = await organizationsService.ToListAsync(UserId)
        });
    }

    [HttpGet]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<Organization>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Organization>>> Single(string id)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        var result = (CurrentUserType.HasFlag(UserType.Admin)
                         ? await organizationsService.ByIdAsync(id)
                         : await organizationsService.ByIdAsync(id, UserId))
                     ?? throw new OrganizationNotFoundException(id);

        return Ok(new ApiResponse<Organization> { Data = result });
    }

    [HttpPost]
    [ProducesResponseType(typeof(ApiResponse<Organization>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<Organization>>> Create([FromQuery] CreateOrganizationRequest request)
    {
        if (!CurrentUserType.HasFlag(UserType.Admin))
            throw new MissingPermissionException();

        var organizationCreated = await organizationsService.CreateAsync(request, UserId);

        _logger.MongoLogInfo(UserId, $"{organizationCreated.OrganizationName} created.", new
        {
            organizationId = organizationCreated.Id,
            organizationName = organizationCreated.OrganizationName,
            countryOfOperation = organizationCreated.CountryOfOperation,
            chamberOfCommerce = organizationCreated.ChamberOfCommerce,
            iBAN = organizationCreated.IBAN,
            bIC = organizationCreated.BIC,
            vATIdentifier = organizationCreated.VATIdentifier,
            userId = organizationCreated.UserId
        });

        return Created(string.Empty, new ApiResponse<Organization> { Data = organizationCreated });
    }

    [HttpPatch]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<Organization>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Organization>>> Update(string id, [FromBody] UpdateOrganizationRequest organizationToUpdate)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        var organization = await organizationsService.ByIdAsync(id);

        if (UserId != organization.UserId || !CurrentUserType.HasFlag(UserType.Admin))
            throw new MissingPermissionException();

        var organizationUpdated = await organizationsService.UpdateAsync(id, organizationToUpdate, UserId);

        _logger.MongoLogInfo(UserId, $"Organization {organizationUpdated.OrganizationName} updated.", new
        {
            organizationId = organizationUpdated.Id,
            organizationName = organizationUpdated.OrganizationName,
            countryOfOperation = organizationUpdated.CountryOfOperation,
            chamberOfCommerce = organizationUpdated.ChamberOfCommerce,
            iBAN = organizationUpdated.IBAN,
            bIC = organizationUpdated.BIC,
            vATIdentifier = organizationUpdated.VATIdentifier,
            userId = organizationUpdated.UserId
        });

        return Ok(new ApiResponse<Organization>
        {
            Data = organizationUpdated
        });
    }

    [HttpDelete]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<bool>>> Delete(string id)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        if (!CurrentUserType.HasFlag(UserType.Admin))
            throw new MissingPermissionException();

        var isDeleted = await organizationsService.DeleteAsync(id);
        if (!isDeleted)
            throw new OrganizationNotFoundException(id);

        _logger.MongoLogInfo(UserId, $"Organizaiton {id} deleted.");

        return Ok(new ApiResponse<bool> { Data = true });
    }
}