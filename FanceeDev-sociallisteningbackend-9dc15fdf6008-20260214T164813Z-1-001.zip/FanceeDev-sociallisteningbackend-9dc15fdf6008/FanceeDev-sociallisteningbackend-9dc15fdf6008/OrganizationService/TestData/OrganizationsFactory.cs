using FanceeAnalyticsData.Models.Analytics;

namespace OrganizationService.TestData;

public static class OrganizationsFactory
{
    public static Organization GetMockedOrganization() =>
        new()
        {
            Email = "test@mail.com",
            FirstName = "Jan",
            LastName = "Piet",
            OrganizationName = "Een company",
            CountryOfOperation = CountryCode.NL,
            ChamberOfCommerce = "123",
            IBAN = "NL12XXXX12345678",
            BIC = "123",
            VATIdentifier = "123",
            UserId = Guid.NewGuid()
        };

    public static Organization[] GetMockedOrganizations() =>
    [
        new()
        {
            Email = "test@mail.com",
            FirstName = "Jan",
            LastName = "Piet",
            OrganizationName = "Een company",
            CountryOfOperation = CountryCode.NL,
            ChamberOfCommerce = "123",
            IBAN = "NL12XXXX12345678",
            BIC = "123",
            VATIdentifier = "123",
            UserId = Guid.NewGuid()
        },
        new()
        {
            Email = "hello@mail.com",
            FirstName = "San",
            LastName = "Wan",
            OrganizationName = "myOrg",
            CountryOfOperation = CountryCode.NL,
            ChamberOfCommerce = "123",
            IBAN = "NL12XXXX12345678",
            BIC = "123",
            VATIdentifier = "123",
            UserId = Guid.NewGuid()
        }
    ];
}