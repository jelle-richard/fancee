using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Dtos.Environment;

namespace SocialListeningCore.Services.DeploymentEnvironments;

public interface IDeploymentEnvironmentService : IMongoService<DeploymentEnvironment>
{
    /// <summary>
    /// Gets the hostedDeploymentEnvironment.
    /// </summary>
    /// <returns></returns>
    public Task<HostedDeploymentEnvironment> GetAsync();

    /// <summary>
    /// Checks whether there is any hostedDeploymentEnvironment in collection.
    /// </summary>
    /// <returns>true/false</returns>
    public Task<bool> AnyAsync();
}