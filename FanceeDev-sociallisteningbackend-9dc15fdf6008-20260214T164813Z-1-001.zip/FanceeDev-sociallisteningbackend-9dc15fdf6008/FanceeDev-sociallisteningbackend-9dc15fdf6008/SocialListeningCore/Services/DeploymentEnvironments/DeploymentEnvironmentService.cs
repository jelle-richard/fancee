using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using SocialListeningCore.Dtos.Environment;
using SocialListeningCore.Persistence.DeploymentEnvironments;

namespace SocialListeningCore.Services.DeploymentEnvironments;

public class DeploymentEnvironmentService(IHttpContextAccessor httpContext, IDeploymentEnvironmentDao deploymentEnvironmentDao, IConfiguration configuration) : MongoService<DeploymentEnvironment, IDeploymentEnvironmentDao>(deploymentEnvironmentDao), IDeploymentEnvironmentService
{
    private const string ConfigEnvironmentSection = "Environment";
    private const string ConfigDefaultKey = "Default";

    private readonly IDeploymentEnvironmentDao _deploymentEnvironmentDao = deploymentEnvironmentDao;
    private HostedDeploymentEnvironment? _cachedEnvironment;

    public async Task<HostedDeploymentEnvironment> GetAsync()
    {
        if (_cachedEnvironment != null)
            return _cachedEnvironment;

        var host = GetHost();
        var deploymentEnvironment = await _deploymentEnvironmentDao.ByHostAsync(host);

        return _cachedEnvironment = new()
        {
            Id = deploymentEnvironment.Id,
            Domain = deploymentEnvironment.Domain,
            Name = deploymentEnvironment.Name,
            Port = deploymentEnvironment.Port,
            FrontendBaseUrl = deploymentEnvironment.FrontendBaseUrl,
            IsHttps = httpContext.HttpContext?.Request.IsHttps ?? false,
            RemoteIpAddress = httpContext.HttpContext?.Connection.RemoteIpAddress
        };
    }

    public async Task<bool> AnyAsync() => await _deploymentEnvironmentDao.AnyAsync();

    /// <summary>
    /// Gets the host from the current request.
    /// If it can't be found, the fallback defined in the configuration file is used.
    /// </summary>
    /// <returns></returns>
    private string GetHost()
    {
        var host = httpContext.HttpContext?.Request.Host.Host;

        if (!string.IsNullOrWhiteSpace(host))
            return host.ToLowerInvariant();

        host = configuration.GetValue<string>($"{ConfigEnvironmentSection}:{ConfigDefaultKey}");

        return host?.ToLowerInvariant() ?? string.Empty;
    }
}