using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Dtos.CronJobs;

namespace SocialListeningCore.Services.Scheduler;

public interface ISchedulerService<TBasicCron>
    where TBasicCron : BasicCron
{
    /// <summary>
    /// Adds a new BasicCron job to the schedule or updates an existing one.
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public CronJobResponse<TBasicCron> AddOrUpdateSchedule(TBasicCron input);

    /// <summary>
    /// Stops and removes an existing BasicCron from the schedule.
    /// </summary>
    /// <param name="name"></param>
    /// <returns></returns>
    public CronJobResponse<TBasicCron> StopJob(string name);
}