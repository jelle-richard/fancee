using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.CronJobs;
using SocialListeningCore.Jobs;
using SocialListeningCore.Logging;
using SocialListeningCore.Services.Cron;

namespace SocialListeningCore.Services.Scheduler;

public class SchedulerService<TBasicCron, TCronService>(
    IServiceProvider serviceProvider,
    ISchedulerRegistration schedulerRegistration,
    ILoggerFactory loggerFactory) :
    ISchedulerService<TBasicCron> where TBasicCron : BasicCron
    where TCronService : ICronService<TBasicCron>
{
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);

    public CronJobResponse<TBasicCron> AddOrUpdateSchedule(TBasicCron input)
    {
        var jobOptions = new SchedulerOptions
        {
            CronSchedule = input.Cron!,
            RunImmediately = false
        };
        var job = new BasicJob<TBasicCron, TCronService>(
            serviceProvider.CreateScope().ServiceProvider,
            _logger,
            jobOptions,
            input
        );

        var result = schedulerRegistration.AddOrUpdate(input.Name!, job, jobOptions);

        if (result)
            _logger.LogInformation("[{dateTime}]: Started job: {name}", DateTime.UtcNow, input.Name);
        else
            _logger.LogWarning("[{dateTime}]: Failed to start job: {name}", DateTime.UtcNow, input.Name);

        return new()
        {
            JobName = input.Name,
            Input = input,
            IsRunning = result
        };
    }

    public CronJobResponse<TBasicCron> StopJob(string name)
    {
        var result = schedulerRegistration.Remove(name);
        if (result)
            _logger.LogInformation("[{dateTime}]: Stopped job: {name}", DateTime.UtcNow, name);
        else
            _logger.LogWarning("[{dateTime}]: Failed to stop job: {name}. Job not found.", DateTime.UtcNow, name);

        return new()
        {
            JobName = name,
            IsStopped = result
        };
    }
}