using Fs.MessageBus.Publishers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using SocialListeningCore.Dtos.MailProvider;
using SocialListeningCore.Exceptions;
using SocialListeningCore.MessageBus.Messages.Mail;
using ViewRenderer;

namespace SocialListeningCore.Services.Mailer;

public class Mailer(IMessagePublisher<AddMailMessage> publisher, IObjectModelValidator validator, IViewRenderer viewRenderer) : IMailer
{
    public IViewRenderer ViewRenderer { get; } = viewRenderer;

    public void Send(Mail mail)
    {
        var context = new ControllerContext();
        validator.Validate(context, null, string.Empty, mail);

        if (!context.ModelState.IsValid)
            throw new InvalidMailException(context.ModelState);

        publisher.Publish(new() { Mail = mail });
    }
}