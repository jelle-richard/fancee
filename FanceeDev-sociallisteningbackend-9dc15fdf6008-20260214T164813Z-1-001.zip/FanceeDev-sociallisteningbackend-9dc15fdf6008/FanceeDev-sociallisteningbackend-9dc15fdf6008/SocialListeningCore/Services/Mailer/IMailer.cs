using ViewRenderer;

namespace SocialListeningCore.Services.Mailer;

public interface IMailer
{
    public IViewRenderer ViewRenderer { get; }
    
    /// <summary>
    /// Sends an Mail object to the RabbitMq Queue.
    /// </summary>
    /// <param name="mail"></param>
    public void Send(Dtos.MailProvider.Mail mail);
}