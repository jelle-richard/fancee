using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Persistence;

namespace SocialListeningCore.Services;

public abstract class MongoService<TModel, TDao>(TDao mongoDao) : IMongoService<TModel>
    where TModel : BasicMongoModel
    where TDao : IMongoDao<TModel>
{

    public async Task<TModel> CreateAsync(TModel model) => await mongoDao.CreateAsync(model);

    public async Task<TModel?> GetAsync(string id) => await mongoDao.GetAsync(id);

    public async Task<IEnumerable<TModel>> GetListAsync() => await mongoDao.GetListAsync();

    public async Task<TModel> UpdateAsync(TModel model, bool IsUpsert) => await mongoDao.UpdateAsync(model, null, null, IsUpsert);
}