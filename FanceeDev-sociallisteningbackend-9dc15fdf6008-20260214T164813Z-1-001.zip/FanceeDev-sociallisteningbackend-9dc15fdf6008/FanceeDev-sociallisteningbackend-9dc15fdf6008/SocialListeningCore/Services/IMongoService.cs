using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Services;

public interface IMongoService<TModel> where TModel : BasicMongoModel
{
    /// <summary>
    /// Creates a new entry of the given model in MongoDB. The collection is determined by the field CollectionId.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>The latest version of the model</returns>
    public Task<TModel> CreateAsync(TModel model);

    /// <summary>
    /// Updates an entry of the given model in MongoDB. The update/lookup query is determined bij the GetUpdateFilter function and will replace the entire model.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>The latest version of the model</returns>
    public Task<TModel> UpdateAsync(TModel model, bool IsUpsert);

    /// <summary>
    /// Gets a single model, based on ID.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>A single model</returns>
    public Task<TModel?> GetAsync(string id);

    /// <summary>
    /// Gets a list of models.
    /// </summary>
    /// <returns>A list of models</returns>
    public Task<IEnumerable<TModel>> GetListAsync();
}