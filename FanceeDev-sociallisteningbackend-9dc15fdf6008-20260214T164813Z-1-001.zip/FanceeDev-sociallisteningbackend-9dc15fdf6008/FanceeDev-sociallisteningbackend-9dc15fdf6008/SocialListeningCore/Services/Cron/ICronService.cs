using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Services.Cron;

public interface ICronService<in TBasicCron>
    where TBasicCron : BasicCron
{
    /// <summary>
    /// Method for BasicJobs to run service specific code.
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public Task RunAsync(TBasicCron input);
}