using System.Text.Json;

namespace SocialListeningCore.Services.Cache;

/// <summary>
/// ICacheService interface.
/// Contains all methods that need to be implemented for a cache provider.
/// </summary>
public interface ICacheService
{
    /// <summary>
    /// Sets the serializer options for JSON.
    /// </summary>
    /// <param name="options"></param>
    public void SetJsonSerializerOptions(JsonSerializerOptions options);

    /// <summary>
    /// Caches the given object.
    /// </summary>
    /// <param name="key">Key of the cached object</param>
    /// <param name="objectToCache">Object to cache</param>
    /// <param name="lifetimeDays">Lifetime of the cached object in days</param>
    /// <returns></returns>
    public Task CacheObjectAsync<T>(string key, T objectToCache, int lifetimeDays);

    /// <summary>
    /// Caches the given object for the specified lifetime.
    /// </summary>
    /// <param name="key">Key of the cached object</param>
    /// <param name="objectToCache">Object to cache</param>
    /// <param name="lifetime">Lifetime of the cached object</param>
    /// <returns></returns>
    public Task CacheObjectAsync<T>(string key, T objectToCache, TimeSpan lifetime);

    /// <summary>
    /// Gets the token with details from the cache.
    /// </summary>
    /// <param name="key">Token to get details from</param>
    /// <returns></returns>
    public Task<T?> GetCachedObjectAsync<T>(string key);

    /// <summary>
    /// Removes a cache entry by key.
    /// </summary>
    /// <param name="key"></param>
    /// <returns></returns>
    public Task RemoveCacheByKeyAsync(string key);
}