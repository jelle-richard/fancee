using System.Text.Json;
using FanceeAuthentication.Dtos;
using FanceeAuthentication.Providers.Cache;
using Microsoft.Extensions.Caching.Distributed;

namespace SocialListeningCore.Services.Cache;

public class RedisCacheService(IDistributedCache cache) : ICacheService, ICacheProvider
{
    private JsonSerializerOptions? _jsonOptions;

    public async Task CacheTokenAsync(string token, TokenCache tokenCache, TimeSpan lifetime)
        => await CacheObjectAsync($"token-{token}", tokenCache, lifetime);

    public async Task<TokenCache?> CachedTokenAsync(string token)
        => await GetCachedObjectAsync<TokenCache>($"token-{token}");

    public async Task RemoveCachedTokenAsync(string token)
        => await RemoveCacheByKeyAsync($"token-{token}");

    public void SetJsonSerializerOptions(JsonSerializerOptions options)
        => _jsonOptions = options;

    public async Task CacheObjectAsync<T>(string key, T objectToCache, int lifetimeDays)
        => await CacheObjectAsync(key, objectToCache, TimeSpan.FromDays(lifetimeDays));

    public async Task CacheObjectAsync<T>(string key, T objectToCache, TimeSpan lifetime)
        => await cache.SetStringAsync(key, JsonSerializer.Serialize(objectToCache, _jsonOptions), new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = lifetime });

    public async Task RemoveCacheByKeyAsync(string key)
        => await cache.RemoveAsync(key);

    public async Task<T?> GetCachedObjectAsync<T>(string key)
    {
        var cachedObject = await cache.GetStringAsync(key);

        return string.IsNullOrEmpty(cachedObject) ? default : JsonSerializer.Deserialize<T>(cachedObject, _jsonOptions);
    }
}