using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MongoDB.Driver;
using SocialListeningCore.Bootstrap.Modules;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Dtos.Swagger;
using SocialListeningCore.Middleware;
using SocialListeningCore.Persistence.Connections;
using SocialListeningCore.Persistence.DeploymentEnvironments;
using SocialListeningCore.Persistence.Entries;
using SocialListeningCore.Persistence.Users;
using SocialListeningCore.Services.DeploymentEnvironments;
using SocialListeningCore.Settings;
using SocialListeningCore.Utils.Validation;
using ViewRenderer;

namespace SocialListeningCore;

public class Startup(WebApplicationBuilder builder)
{
    public ConfigurationManager Configuration => _builder.Configuration;
    public bool IsCiCd => builder.Configuration.GetValue<bool?>("CI_CD") == true;
    public event EventHandler<IServiceCollection>? OnConfigureServices;

    public bool UseRabbitMq { get; set; } = true;
    public bool UseAuthenticationAndAuthorization { get; set; } = true;
    public bool UseRedis { get; set; } = true;
    public bool UseSharedSettings { get; set; } = true;
    public SwaggerOptions? SwaggerOptions { get; set; }

    private readonly WebApplicationBuilder _builder = builder;

    private List<IStartupModule>? _startupModules;

    /// <summary>
    /// Adds a new service.
    /// </summary>
    /// <typeparam name="TService"></typeparam>
    /// <typeparam name="TImplementation"></typeparam>
    /// <param name="lifetime"></param>
    public void AddDependency<TService, TImplementation>(ServiceLifetime lifetime)
        where TService : class where TImplementation : class, TService
    {
        if (lifetime == ServiceLifetime.Scoped)
            _builder.Services.AddScoped<TService, TImplementation>();
        else if (lifetime == ServiceLifetime.Singleton)
            _builder.Services.AddSingleton<TService, TImplementation>();
        else if (lifetime == ServiceLifetime.Transient)
            _builder.Services.AddTransient<TService, TImplementation>();
    }

    /// <summary>
    /// Adds a new service.
    /// </summary>
    /// <typeparam name="TService"></typeparam>
    /// <param name="dependency"></param>
    /// <param name="lifetime"></param>
    public void AddDependency<TService>(Func<IServiceProvider, TService> dependency, ServiceLifetime lifetime)
        where TService : class
    {
        if (lifetime == ServiceLifetime.Scoped)
            _builder.Services.AddScoped(dependency);
        else if (lifetime == ServiceLifetime.Singleton)
            _builder.Services.AddSingleton(dependency);
        else if (lifetime == ServiceLifetime.Transient)
            _builder.Services.AddTransient(dependency);
    }

    /// <summary>
    /// Configures the builder services and configures the WebApplication.
    /// Returns the built WebApplication instance.
    /// </summary>
    /// <returns></returns>
    public WebApplication Build()
    {
        _startupModules =
        [
            new SwaggerStartupModule(SwaggerOptions!, UseAuthenticationAndAuthorization),
            new MongoDbStartupModule(),
            new RedisStartupModule(UseRedis),
            new MessageBrokerStartupModule(UseRabbitMq, IsCiCd),
            new AuthenticationAndAuthorizationStartupModule(UseAuthenticationAndAuthorization)
        ];

        ConfigureSettings();
        ConfigureServices();

        var app = _builder.Build();

        Configure(app);

        return app;
    }

    private void ConfigureSettings()
    {
        if (!UseSharedSettings)
            return;

        _builder.WebHost.AddSharedSettings("sharedsettings.json");
    }

    private void Configure(WebApplication app)
    {
        if (app.Environment.IsDevelopment())
            app.UseDeveloperExceptionPage();

        app.UseRouting()
            .UseApiExceptionMiddleware();

        foreach (var startupModule in _startupModules!)
        {
            if (startupModule is IConfigurableStartupModule configurableModule)
                configurableModule.Configure(app);
        }

        app.UseAuthorization();

        app.MapControllers();
    }

    private void ConfigureServices()
    {
        _builder.Services.AddRouting(options => options.LowercaseUrls = true);
        _builder.Services.AddControllers().AddJsonOptions(options =>
        {
            options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
            options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        });

        ConfigureApiBehaviorOptions();
        _builder.Services.AddHttpContextAccessor();

        _builder.Services.AddSingleton<IMongoClient>(sp => new MongoClient(builder.Configuration.GetConnectionString("Mongo")));

        foreach (var startupModule in _startupModules!)
            startupModule.Build(_builder);

        OnConfigureServices?.Invoke(this, _builder.Services);

        ConfigureDependencies();
    }

    private void ConfigureApiBehaviorOptions()
    {
        _builder.Services.Configure<ApiBehaviorOptions>(options =>
        {
            options.InvalidModelStateResponseFactory =
                actionContext => new BadRequestObjectResult(new ApiResponse<object>
                {
                    Data = null,
                    Errors = actionContext.ModelState.ToDictionaryList()
                });
        });
    }

    private void ConfigureDependencies()
    {
        _builder.Services.AddHttpClient();

        AddUtilDependencies();

        _builder.Services.AddRazorPages();
        _builder.Services.AddViewRenderer();
    }

    private void AddUtilDependencies()
    {
        _builder.Services.AddScoped<IGenericEntriesDao, GenericEntriesDao>();
        _builder.Services.AddScoped<IConnectionsDao, ConnectionsDao>();
        _builder.Services.AddScoped<IUserDao, UserDao>();
        _builder.Services.AddScoped<IDeploymentEnvironmentService, DeploymentEnvironmentService>();
        _builder.Services.AddScoped<IDeploymentEnvironmentDao, DeploymentEnvironmentDao>();
    }
}