using System.Net;
using System.Net.Mime;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Utils;

namespace SocialListeningCore.Middleware;

public class ApiExceptionMiddleware(RequestDelegate next, IHostEnvironment environment, ILogger<ApiExceptionMiddleware> logger)
{
    public async Task Invoke(HttpContext httpContext)
    {
        try
        {
            await next(httpContext);
        }
        catch (ApiException ex)
        {
            if (httpContext.Response.HasStarted)
                throw;

            var response = new ApiResponse<object>();
            response.AddError(ex.ErrorCode, ex.Message);

            await SendErrorAsync(httpContext, response, (int)ex.StatusCode, ex.ContentType);
        }
        catch (Exception ex)
        {
            if (httpContext.Response.HasStarted)
                throw;

            var errorMessage = "Internal server error has occurred. Please try again later.";
            if (!environment.IsProduction())
                errorMessage = $"EXCEPTION ({ex.Source}): {ex.Message}";

            logger.LogError(ex, "An unknown error has occured. See details for more info.");

            var response = new ApiResponse<object>();
            response.AddError(ErrorCode.ExceptionExternalService, errorMessage);

            await SendErrorAsync(httpContext, response, (int)HttpStatusCode.InternalServerError, MediaTypeNames.Application.Json);
        }
    }

    private static async Task SendErrorAsync(HttpContext httpContext, ApiResponse<object> response, int statusCode, string contentType)
    {
        httpContext.Response.Clear();
        httpContext.Response.StatusCode = statusCode;
        httpContext.Response.ContentType = contentType;

        await httpContext.Response.WriteAsync(JsonSerializer.Serialize(response, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        }));
    }
}

/// <summary>
/// Extension method used to add the middleware to the HTTP request pipeline.
/// </summary>
public static class ApiExceptionMiddlewareExtensions
{
    public static IApplicationBuilder UseApiExceptionMiddleware(this IApplicationBuilder builder) => builder.UseMiddleware<ApiExceptionMiddleware>();
}