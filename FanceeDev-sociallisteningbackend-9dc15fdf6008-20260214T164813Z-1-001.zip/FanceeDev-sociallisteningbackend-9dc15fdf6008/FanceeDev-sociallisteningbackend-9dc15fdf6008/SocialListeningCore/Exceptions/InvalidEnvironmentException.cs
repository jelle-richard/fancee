namespace SocialListeningCore.Exceptions;

public class InvalidEnvironmentException(string environment) 
    : InternalServerErrorApiException($"'{environment}' is not a valid environment");