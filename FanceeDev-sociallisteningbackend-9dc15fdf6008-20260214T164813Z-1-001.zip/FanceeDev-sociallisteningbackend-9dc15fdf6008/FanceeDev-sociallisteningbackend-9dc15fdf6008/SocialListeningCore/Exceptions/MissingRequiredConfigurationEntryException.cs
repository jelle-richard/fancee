using SocialListeningCore.Utils;

namespace SocialListeningCore.Exceptions;

public class MissingRequiredConfigurationEntryException : BadRequestApiException
{
    public MissingRequiredConfigurationEntryException(string sectionName) : base($"The '{sectionName}' section in the configuration file is missing", ErrorCode.ExceptionInvalidConfiguration)
    {
    }

    public MissingRequiredConfigurationEntryException(string sectionName, string entryName) : base($"The required entry '{entryName}' is missing in the '{sectionName}' section", ErrorCode.ExceptionInvalidConfiguration)
    {
    }
}