namespace SocialListeningCore.Exceptions;

[Serializable]
public class MissingPermissionException() 
    : UnauthorizedApiException("Missing permission to perform the action");