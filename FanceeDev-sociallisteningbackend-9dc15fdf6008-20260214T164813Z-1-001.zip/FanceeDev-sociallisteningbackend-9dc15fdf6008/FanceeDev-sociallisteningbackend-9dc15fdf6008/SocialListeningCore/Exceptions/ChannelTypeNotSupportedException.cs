using System.Runtime.Serialization;
using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Exceptions;

[Serializable]
public class ChannelTypeNotSupportedException : NotSupportedException
{
    public ChannelTypeNotSupportedException(ChannelType channelType, string source) : base($"""ChannelType "{channelType}" not supported (Source: {source})""")
    {
    }

    protected ChannelTypeNotSupportedException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}