namespace SocialListeningCore.Exceptions;

public class ChannelNotFoundException(string channelId) 
    : NotFoundApiException($"Channel {channelId} not found");