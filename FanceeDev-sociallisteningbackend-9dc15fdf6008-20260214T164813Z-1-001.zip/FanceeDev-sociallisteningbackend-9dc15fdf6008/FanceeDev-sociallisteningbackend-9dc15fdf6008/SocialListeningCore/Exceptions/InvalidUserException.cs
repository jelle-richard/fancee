namespace SocialListeningCore.Exceptions;

public class InvalidUserException() 
    : NotFoundApiException("The requested user could not be found");