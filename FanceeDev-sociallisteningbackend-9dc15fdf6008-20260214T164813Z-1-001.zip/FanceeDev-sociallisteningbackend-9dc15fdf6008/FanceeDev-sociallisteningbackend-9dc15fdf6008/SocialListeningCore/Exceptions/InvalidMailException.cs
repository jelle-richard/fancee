using Microsoft.AspNetCore.Mvc.ModelBinding;
using SocialListeningCore.Utils.Validation;

namespace SocialListeningCore.Exceptions;

public class InvalidMailException(ModelStateDictionary state) 
    : BadRequestApiException($"One or more validation errors occured. See {nameof(Errors)} for more details")
{
    public IDictionary<string, List<string>> Errors { get; set; } = state.ToDictionaryList();
}