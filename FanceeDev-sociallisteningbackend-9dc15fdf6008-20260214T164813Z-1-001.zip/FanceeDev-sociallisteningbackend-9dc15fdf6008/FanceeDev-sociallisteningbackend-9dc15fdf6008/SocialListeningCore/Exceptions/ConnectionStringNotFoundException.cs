namespace SocialListeningCore.Exceptions;

public class ConnectionStringNotFoundException() : Exception("Connection string not set or not valid");