namespace SocialListeningCore.Exceptions;

public class InvalidUserCredentialsException() 
    : BadRequestApiException("No user with the given credentials could be found");