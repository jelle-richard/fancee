namespace SocialListeningCore.Exceptions;

public class SessionNotFoundException() 
    : NotFoundApiException("Session could not be found");