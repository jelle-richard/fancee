namespace SocialListeningCore.Exceptions;

public class MongoDatabaseStringNotFoundException() : Exception("Database string not set or not valid");