using System.Runtime.Serialization;
using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Exceptions;

[Serializable]
public class SubscriptionTypeNotSupportedException : NotSupportedException
{
    public SubscriptionTypeNotSupportedException(SubscriptionType subscriptionType) : base($"""SubscriptionType "{subscriptionType}" not supported""")
    {
    }

    protected SubscriptionTypeNotSupportedException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}