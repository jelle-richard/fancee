namespace SocialListeningCore.Exceptions;

public class SubscriptionNotFoundException() 
    : NotFoundApiException("Subscription(s) not found");