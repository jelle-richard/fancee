namespace SocialListeningCore.Exceptions;

public class OrganizationNotFoundException(string? organizationId) 
    : NotFoundApiException($"Organization {organizationId} could not be found");