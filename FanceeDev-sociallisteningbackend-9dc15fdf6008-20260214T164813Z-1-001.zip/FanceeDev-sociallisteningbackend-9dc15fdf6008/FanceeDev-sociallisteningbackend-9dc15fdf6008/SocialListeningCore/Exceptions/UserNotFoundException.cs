namespace SocialListeningCore.Exceptions;

public class UserNotFoundException() 
    : NotFoundApiException($"The requested user couldn't be found");