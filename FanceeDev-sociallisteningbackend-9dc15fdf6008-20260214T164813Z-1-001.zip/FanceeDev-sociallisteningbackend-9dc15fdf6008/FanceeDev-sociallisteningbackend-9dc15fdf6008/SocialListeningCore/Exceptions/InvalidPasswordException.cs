namespace SocialListeningCore.Exceptions;

public class InvalidPasswordException() 
    : BadRequestApiException("Invalid password provided");