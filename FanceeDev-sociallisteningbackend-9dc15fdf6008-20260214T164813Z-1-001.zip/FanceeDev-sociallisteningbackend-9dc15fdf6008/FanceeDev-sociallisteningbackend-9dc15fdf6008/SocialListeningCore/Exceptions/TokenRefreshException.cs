namespace SocialListeningCore.Exceptions;

public class TokenRefreshException() : BadRequestApiException("The token cannot be refreshed as it is invalid or expired");