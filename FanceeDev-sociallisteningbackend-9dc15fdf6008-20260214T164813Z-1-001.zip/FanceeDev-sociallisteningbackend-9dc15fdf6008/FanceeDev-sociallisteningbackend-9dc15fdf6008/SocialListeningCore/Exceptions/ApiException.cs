using System.Net;
using System.Net.Mime;
using System.Runtime.Serialization;
using SocialListeningCore.Utils;

namespace SocialListeningCore.Exceptions;

/// <summary>
/// Base exception class for deriving API exceptions.
/// </summary>
public class ApiException : Exception
{
    public HttpStatusCode StatusCode { get; set; }
    public string ContentType { get; set; } = MediaTypeNames.Application.Json;
    public ErrorCode ErrorCode { get; set; }

    public ApiException()
    {
    }

    protected ApiException(string message) : base(message)
    {
    }

    protected ApiException(string message, HttpStatusCode statusCode, ErrorCode errorCode) : base(message)
    {
        StatusCode = statusCode;
        ErrorCode = errorCode;
    }
}

//note: please keep the classes below in order of HTTP status code
public class BadRequestApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionInvalidData)
    : ApiException(message, HttpStatusCode.BadRequest, errorCode);

public class UnauthorizedApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionInvalidData)
    : ApiException(message, HttpStatusCode.Unauthorized, errorCode);

public class ForbiddenApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionInvalidData)
    : ApiException(message, HttpStatusCode.Forbidden, errorCode);

public class NotFoundApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionNoData)
    : ApiException(message, HttpStatusCode.NotFound, errorCode);

public class RequestTimeoutApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionExternalService)
    : ApiException(message, HttpStatusCode.RequestTimeout, errorCode);

public class LockedApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionUnsupported)
    : ApiException(message, HttpStatusCode.Locked, errorCode);

public class TooManyRequestsApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionTooManyRequests)
    : ApiException(message, HttpStatusCode.TooManyRequests, errorCode);

public class InternalServerErrorApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionInternalService)
    : ApiException(message, HttpStatusCode.InternalServerError, errorCode);

public class ServiceUnavailableApiException(string message, ErrorCode errorCode = ErrorCode.ExceptionExternalService)
    : ApiException(message, HttpStatusCode.ServiceUnavailable, errorCode);
