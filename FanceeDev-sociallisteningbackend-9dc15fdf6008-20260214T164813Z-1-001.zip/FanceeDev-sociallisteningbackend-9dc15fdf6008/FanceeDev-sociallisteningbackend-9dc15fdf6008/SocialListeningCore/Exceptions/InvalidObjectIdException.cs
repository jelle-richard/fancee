namespace SocialListeningCore.Exceptions;

public class InvalidObjectIdException() 
    : BadRequestApiException("The requested objectId is not valid");