using System.Net;
using System.Runtime.Serialization;
using SocialListeningCore.Utils;

namespace SocialListeningCore.Exceptions;


public class CollectionNotFoundException() 
    : NotFoundApiException("Missing collectionId from query");