using System.Runtime.Serialization;

namespace SocialListeningCore.Exceptions;

/// <summary>
/// Used for throwing exceptions in the persistence layer
/// </summary>
[Serializable]
public abstract class PersistenceException : Exception
{
    protected PersistenceException(string message) : base(message)
    {
    }

    protected PersistenceException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}