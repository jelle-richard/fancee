using Microsoft.AspNetCore.Builder;

namespace SocialListeningCore.Bootstrap.Modules;

internal interface IConfigurableStartupModule
{
    public void Configure(WebApplication app);
}