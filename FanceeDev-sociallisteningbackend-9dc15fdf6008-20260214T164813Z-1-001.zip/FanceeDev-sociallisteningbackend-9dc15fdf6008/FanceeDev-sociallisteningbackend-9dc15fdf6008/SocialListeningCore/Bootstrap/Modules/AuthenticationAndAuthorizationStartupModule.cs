using FanceeAuthentication.Utils;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace SocialListeningCore.Bootstrap.Modules;

internal class AuthenticationAndAuthorizationStartupModule(bool useAuthenticationAndAuthorization) : IStartupModule, IConfigurableStartupModule
{
    public void Configure(WebApplication app)
    {
        if (!useAuthenticationAndAuthorization)
            return;

        app.UseAuthentication();
        app.UseAuthorization();
    }

    public void Build(WebApplicationBuilder builder)
    {
        if (!useAuthenticationAndAuthorization)
            return;

        AddAuthentication(builder);
        AddAuthorization(builder);
    }

    /// <summary>
    /// Adds authentication to the builder.
    /// </summary>
    /// <param name="builder"></param>
    private static void AddAuthentication(WebApplicationBuilder builder)
    {
        builder.Services.AddAuthentication(FanceeAuthenticationExtensions.AuthenticationScheme)
            .AddFanceeAuthentication(new()
            {
                ConnectionString = builder.Configuration.GetConnectionString("FanceeUsers")!,
                TokenConfig = new()
                {
                    TakeoverLifetimeMinutes = 3600,
                    Issuer = builder.Configuration.GetValue<string>("Jwt:Issuer")!,
                    SigningKey = builder.Configuration.GetValue<string>("Jwt:SigningKey")!,
                    LifetimeHours = builder.Configuration.GetValue<int>("Jwt:LifetimeHours"),
                    RefreshDays = builder.Configuration.GetValue<int>("Jwt:RefreshDays")
                }
            });
    }

    /// <summary>
    /// Adds authorization to the builder.
    /// </summary>
    /// <param name="builder"></param>
    private static void AddAuthorization(WebApplicationBuilder builder)
    {
        builder.Services.AddAuthorization(options =>
        {
            options.DefaultPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .AddAuthenticationSchemes(FanceeAuthenticationExtensions.AuthenticationScheme)
                .Build();
        });
    }
}