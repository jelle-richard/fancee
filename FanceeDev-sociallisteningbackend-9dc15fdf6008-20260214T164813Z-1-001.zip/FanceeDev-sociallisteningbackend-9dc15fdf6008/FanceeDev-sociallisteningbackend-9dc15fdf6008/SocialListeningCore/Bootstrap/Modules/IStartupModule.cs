using Microsoft.AspNetCore.Builder;

namespace SocialListeningCore.Bootstrap.Modules;

internal interface IStartupModule
{
    public void Build(WebApplicationBuilder builder);
}