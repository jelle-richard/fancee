using Fs.MessageBus.Utils;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SocialListeningCore.Exceptions;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;
using SocialListeningCore.MessageBus.Messages.Mail;
using SocialListeningCore.MessageBus.Publishers;
using SocialListeningCore.MessageBus.Subscribers;
using SocialListeningCore.Services.Mailer;

namespace SocialListeningCore.Bootstrap.Modules;

internal class MessageBrokerStartupModule(bool useMessageBroker, bool isCiCd) : IStartupModule
{
    public void Build(WebApplicationBuilder builder)
    {
        if (!useMessageBroker || isCiCd)
            return;

        RegisterMessages(builder.Services);

        var connectionString = builder.Configuration.GetConnectionString("RabbitMQ") ?? throw new MissingRequiredConfigurationEntryException("ConnectionStrings", "RabbitMQ");

        builder.Services.AddMessageBus(connectionString);

        // Note: the mailer can only be instantiated if RabbitMQ is enabled.
        builder.Services.AddScoped<IMailer, Mailer>();
    }

    private static void RegisterMessages(IServiceCollection services)
    {
        services.RegisterMessage<AddMailMessage, AddMailPublisher>();
        services.RegisterMessage<IRequestTicketingDataMessage, RequestTicketingDataPublisher>();
    }
}