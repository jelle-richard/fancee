using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using SocialListeningCore.Dtos.Swagger;
using SocialListeningCore.Utils;

namespace SocialListeningCore.Bootstrap.Modules;

internal class SwaggerStartupModule(SwaggerOptions swaggerOptions, bool useAuthenticationAndAuthorization) : IStartupModule, IJsonSerializerModule, IConfigurableStartupModule
{
    public void Configure(WebApplication app)
    {
        if (swaggerOptions == null || app.Environment.IsProduction())
            return;

        app.UseSwagger();
        app.UseSwaggerUI(options =>
        {
            options.SwaggerEndpoint(swaggerOptions.EndpointUrl, swaggerOptions.EndpointName);
            options.EnablePersistAuthorization();
            options.EnableTryItOutByDefault();
            options.DisplayRequestDuration();
        });
    }

    public void SetJsonSerializerOptions(JsonOptions options)
    {
        if (swaggerOptions?.EnumsAsStrings ?? false)
            options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    }

    public void Build(WebApplicationBuilder builder)
    {
        if (swaggerOptions == null)
            return;

        builder.Services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc(swaggerOptions.Version,
                new() { Title = swaggerOptions.Title, Version = swaggerOptions.Version });

            options.MapType<DateTime>(() => new()
            {
                Type = "string",
                Example = new OpenApiString(DateTime.UtcNow.ToString(DateFormat.DefaultApiResponse))
            });

            if (!useAuthenticationAndAuthorization)
                return;

            options.AddSecurityDefinition("Bearer", GetSwaggerSecurityDefinition());
            options.AddSecurityRequirement(GetSwaggerSecurityRequirement());
        });
    }

    private static OpenApiSecurityScheme GetSwaggerSecurityDefinition() =>
        new()
        {
            Name = "Authorization",
            Type = SecuritySchemeType.ApiKey,
            Scheme = "Bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Description = "Enter 'Bearer' [space] [token]"
        };

    private static OpenApiSecurityRequirement GetSwaggerSecurityRequirement() =>
        new()
        {
            {
                new()
                {
                    Reference = new()
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
                Array.Empty<string>()
            }
        };
}