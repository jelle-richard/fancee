using Microsoft.AspNetCore.Mvc;

namespace SocialListeningCore.Bootstrap.Modules;

internal interface IJsonSerializerModule
{
    public void SetJsonSerializerOptions(JsonOptions options);
}