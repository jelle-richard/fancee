using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Serializers;
using MongoDB.Driver;
using SocialListeningCore.Logging;

namespace SocialListeningCore.Bootstrap.Modules;

internal class MongoDbStartupModule : IStartupModule
{
    /// <summary>
    /// Configures MongoDb.
    /// </summary>
    public void Build(WebApplicationBuilder builder)
    {
        BsonSerializer.RegisterSerializer(new GuidSerializer(BsonType.String));
        ConfigureLogging(builder);
    }

    private static void ConfigureLogging(WebApplicationBuilder builder)
    {
        IConfiguration configuration = builder.Configuration;
        var client = new MongoClient(configuration.GetConnectionString("Mongo"));
        var mongoConfiguration = new MongoConfiguration(configuration.GetValue<string>("Mongo:Database:Default")!, client);
        builder.Logging.AddProvider(new MongoLoggerProvider(mongoConfiguration));
    }
}