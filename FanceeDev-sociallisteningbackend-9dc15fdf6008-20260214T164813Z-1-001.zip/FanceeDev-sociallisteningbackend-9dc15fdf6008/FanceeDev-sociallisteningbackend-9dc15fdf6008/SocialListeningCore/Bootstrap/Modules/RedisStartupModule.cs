using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SocialListeningCore.Services.Cache;

namespace SocialListeningCore.Bootstrap.Modules;

internal class RedisStartupModule(bool useRedis) : IStartupModule
{
    public void Build(WebApplicationBuilder builder)
    {
        if (!useRedis)
            return;

        builder.Services.AddStackExchangeRedisCache(options => options.Configuration = builder.Configuration.GetConnectionString("Redis"));
        builder.Services.AddScoped<ICacheService, RedisCacheService>();
    }
}