using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Persistence.DeploymentEnvironments;

public interface IDeploymentEnvironmentDao : IMongoDao<DeploymentEnvironment>
{
    /// <summary>
    /// Gets deploymentEnvironment by host.
    /// </summary>
    /// <param name="host"></param>
    /// <returns></returns>
    public Task<DeploymentEnvironment> ByHostAsync(string host);
}