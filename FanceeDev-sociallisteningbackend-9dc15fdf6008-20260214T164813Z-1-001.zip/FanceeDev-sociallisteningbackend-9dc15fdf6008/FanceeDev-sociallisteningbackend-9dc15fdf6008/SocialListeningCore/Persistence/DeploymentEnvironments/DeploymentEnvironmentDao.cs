using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Persistence.DeploymentEnvironments;

public class DeploymentEnvironmentDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<DeploymentEnvironment>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("DeploymentEnvironments"),
    mongoDatabase), IDeploymentEnvironmentDao
{
    public async Task<DeploymentEnvironment> ByHostAsync(string host)
    {
        return await GetAsync(Filter.Eq(de => de.Domain, host)) ?? throw new InvalidEnvironmentException(host);
    }
}