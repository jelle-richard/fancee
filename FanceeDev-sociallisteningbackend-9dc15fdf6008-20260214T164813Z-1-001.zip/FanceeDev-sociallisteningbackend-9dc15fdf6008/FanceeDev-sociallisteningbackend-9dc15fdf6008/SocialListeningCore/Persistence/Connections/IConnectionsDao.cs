using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;

namespace SocialListeningCore.Persistence.Connections;

public interface IConnectionsDao : IMongoDao<Connection>
{
    /// <summary>
    /// Gets a list of Connections based on a given SubscriptionType.
    /// </summary>
    /// <param name="type"></param>
    /// <returns>A list of Connections</returns>
    public Task<IEnumerable<Connection>> ToListAsync(SubscriptionType type);

    /// <summary>
    /// Gets a paginated list of posts, sorted by category.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<Connection>> ToPaginatedListAsync(DaoRequest request, int limit, int offset);
}