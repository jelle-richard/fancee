using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Persistence.Connections;

public class ConnectionsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<Connection>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Connections"),
    mongoDatabase), IConnectionsDao
{
    public async Task<IEnumerable<Connection>> ToListAsync(SubscriptionType type)
    {
        var builder = Builders<Connection>.Filter;

        var filter = builder.And(
            builder.Eq("meta.status_code", "SUCCESS"),
            builder.Eq(dbItem => dbItem.SubscriptionType, type)
        );

        return (await Collection.FindAsync(filter)).ToList();
    }

    public async Task<ResultSetResponse<Connection>> ToPaginatedListAsync(DaoRequest request, int limit, int offset)
    {
        var filter = request.SubscriptionId == null
            ? Builders<Connection>.Filter.Empty
            : Builders<Connection>.Filter.Eq(dbItem => dbItem.SubscriptionId, request.SubscriptionId);

        var sort = Builders<Connection>.Sort.Descending(dbItem => dbItem.CreatedOn);

        return await GetPaginatedListAsync(limit, offset, filter, sort);
    }
}