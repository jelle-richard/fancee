using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using MongoDB.Bson;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;

namespace SocialListeningCore.Persistence;

public abstract class MongoDao<TModel> : IMongoDao<TModel>
    where TModel : BasicMongoModel
{
    protected FilterDefinitionBuilder<TModel> Filter => Builders<TModel>.Filter;
    protected UpdateDefinitionBuilder<TModel> Update => Builders<TModel>.Update;

    protected IMongoCollection<TModel> Collection => Db.GetCollection<TModel>(CollectionId);
    protected readonly IMongoDatabase Db;
    protected readonly string? CollectionId;

    protected MongoDao(string? connectionString, string? databaseId, string? collectionId = null, IMongoDatabase? mongoDatabase = null)
    {
        Db = mongoDatabase ?? new MongoClient(connectionString).GetDatabase(databaseId);
        CollectionId = collectionId;
    }

    public virtual FilterDefinition<TModel> GetFilterDefinition(TModel? model)
    {
        return model == null ? Filter.Empty : Filter.Eq(dbItem => dbItem.Id, model.Id);
    }

    public virtual UpdateDefinition<TModel> GetUpdateDefinition(TModel? model)
    {
        return Builders<TModel>.Update.Set(dbItem => dbItem.UpdatedOn, DateTime.UtcNow);
    }

    public async Task<TModel> CreateAsync(TModel model)
    {
        await GetCollection().InsertOneAsync(model);
        return model;
    }

    public async Task<bool> AnyAsync(FilterDefinition<TModel>? filter = null, FindOptions<TModel, TModel>? findOptions = null, string? collectionId = null)
    {
        var cursor = await GetCollection(collectionId ?? CollectionId).FindAsync(filter ?? Filter.Empty, findOptions);
        return await cursor.AnyAsync();
    }

    public async Task<TModel?> GetAsync(string id) => await GetAsync(Filter.Eq(dbItem => dbItem.Id, id));

    public async Task<TModel?> GetAsync(FilterDefinition<TModel> filter, FindOptions<TModel, TModel>? findOptions = null, string? collectionId = null)
    {
        var cursor = await GetCollection(collectionId ?? CollectionId).FindAsync(filter, findOptions);
        return await cursor.SingleOrDefaultAsync();
    }

    public async Task<DeleteResult> DeleteListAsync(FilterDefinition<TModel> filter, string collectionId) => await GetCollection(collectionId).DeleteManyAsync(filter);

    public async Task<IEnumerable<TModel>> GetListAsync(FilterDefinition<TModel>? filter = null, FindOptions<TModel, TModel>? findOptions = null, string? collectionId = null)
    {
        var cursor = await GetCollection(collectionId ?? CollectionId).FindAsync(filter ?? Filter.Empty, findOptions);
        return await cursor.ToListAsync();
    }

    public async Task<IEnumerable<TProjection>> GetListAsync<TProjection>(FilterDefinition<TModel>? filter = null, FindOptions<TModel, TProjection>? findOptions = null, string? collectionId = null)
    {
        var cursor = await GetCollection(collectionId ?? CollectionId).FindAsync(filter ?? Filter.Empty, findOptions);
        return await cursor.ToListAsync();
    }

    public async Task<ResultSetResponse<T>> GetPaginatedListAsync<T>(int limit, int offset, FilterDefinition<T>? filter = null, SortDefinition<T>? sortDefinition = null, IEnumerable<BsonDocument>? projectStages = null, string? collectionId = null)
    {
        filter ??= Builders<T>.Filter.Empty;

        return await CreatePipelineAndGetAsync<ResultSetResponse<T>>(
            MongoHelper.PaginationStages(filter.RenderToBsonDocument(), limit, offset, sortDefinition?.RenderToBsonDocument(), projectStages),
            collectionId) ?? new();
    }

    public virtual async Task<TModel> UpdateAsync(TModel model, FilterDefinition<TModel>? filter = null, string? collectionId = null, bool isUpsert = false)
    {
        filter ??= GetFilterDefinition(model);

        FindOneAndUpdateOptions<TModel> options = new()
        {
            ReturnDocument = ReturnDocument.After
        };

        var coll = GetCollection(collectionId ?? CollectionId);
        var result = await coll.FindOneAndUpdateAsync(filter, GetUpdateDefinition(model), options);

        if (!isUpsert || result != null)
            return result;

        await coll.InsertOneAsync(model);
        return model;
    }

    public async Task<UpdateResult> UpdateOneAsync(FilterDefinition<TModel> filter, UpdateDefinition<TModel> update, string? collectionId = null) => await GetCollection(collectionId).UpdateOneAsync(filter, update);

    public async Task<UpdateResult> UpdateManyAsync(FilterDefinition<TModel> filter, UpdateDefinition<TModel> update, string? collectionId = null) => await GetCollection(collectionId).UpdateManyAsync(filter, update);

    public async Task<IEnumerable<T>> GetListByAggregationAsync<T>(PipelineDefinition<TModel, T> pipeline, AggregateOptions? options = null, string? collectionId = null)
    {
        var cursor = await GetCollection(collectionId ?? CollectionId).AggregateAsync(pipeline, options);
        return await cursor.ToListAsync();
    }

    public async Task<T?> GetByAggregationAsync<T>(PipelineDefinition<TModel, T> pipeline, AggregateOptions? options = null, string? collectionId = null)
    {
        var result = await GetListByAggregationAsync(pipeline, options, collectionId);
        return result.FirstOrDefault();
    }

    public async Task ReplaceListAsync(IEnumerable<TModel> models, string? collectionId = null, bool isUpsert = true)
    {
        var writeModelList = models.Select(record => new ReplaceOneModel<TModel>(GetFilterDefinition(record), record) { IsUpsert = isUpsert });
        await GetCollection(collectionId ?? CollectionId).BulkWriteAsync(writeModelList);
    }

    public virtual async Task<bool> DeleteAsync(string id)
    {
        var result = await GetCollection().DeleteOneAsync(Filter.Eq(dbItem => dbItem.Id, id));
        return result.IsAcknowledged && result.DeletedCount == 1;
    }

    protected async Task<IEnumerable<T>> CreatePipelineAndGetListAsync<T>(IEnumerable<BsonDocument> pipelineStages, string? collectionId)
    {
        var pipeline = PipelineDefinition<TModel, T>.Create(pipelineStages);
        return await GetListByAggregationAsync(pipeline, null, collectionId);
    }

    protected async Task<T?> CreatePipelineAndGetAsync<T>(IEnumerable<BsonDocument> pipelineStages, string? collectionId)
    {
        var pipeline = PipelineDefinition<TModel, T>.Create(pipelineStages);
        return await GetByAggregationAsync(pipeline, null, collectionId);
    }

    private IMongoCollection<TModel> GetCollection(string? collectionId = null)
    {
        if (!string.IsNullOrEmpty(collectionId) && collectionId != CollectionId)
            return Db.GetCollection<TModel>(collectionId);

        return Collection ?? throw new CollectionNotFoundException();
    }
}