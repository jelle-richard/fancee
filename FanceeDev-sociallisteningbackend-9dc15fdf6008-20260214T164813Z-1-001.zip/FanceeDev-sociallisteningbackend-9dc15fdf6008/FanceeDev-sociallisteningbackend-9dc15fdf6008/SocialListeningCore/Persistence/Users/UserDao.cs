using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Persistence.Users;

public class UserDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<User>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Users"),
    mongoDatabase), IUserDao
{
    public async Task<User> ByFanceeUsersIdAsync(Guid fanceeUsersId)
    {
        var filter = Filter.Eq(u => u.FanceeUsersId, fanceeUsersId);

        return await Collection.Find(filter).FirstOrDefaultAsync() ?? throw new UserNotFoundException();
    }

    public async Task<UpdateResult> UpdateLastLoginAsync(Guid userId)
    {
        var filter = Filter.Eq(user => user.FanceeUsersId, userId);
        var update = Update.Combine(Update.Set(user => user.LastLogin, DateTime.UtcNow), Update.Set(user => user.UpdatedOn, DateTime.UtcNow));
        return await UpdateOneAsync(filter, update);
    }

    public async Task<UpdateResult> UpdateOrganizationIdAsync(Guid userId, string organizationId)
    {
        var filter = Filter.Eq(user => user.FanceeUsersId, userId);
        var update = Update.Combine(Update.Set(user => user.OrganizationId, organizationId), Update.Set(user => user.UpdatedOn, DateTime.UtcNow));
        return await UpdateOneAsync(filter, update);
    }
}