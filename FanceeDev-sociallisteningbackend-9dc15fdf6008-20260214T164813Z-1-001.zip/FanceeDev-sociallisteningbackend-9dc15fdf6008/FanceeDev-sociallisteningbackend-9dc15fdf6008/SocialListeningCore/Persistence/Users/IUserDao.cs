using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;

namespace SocialListeningCore.Persistence.Users;

public interface IUserDao : IMongoDao<User>
{
    /// <summary>
    /// Gets a user by fancee users id.
    /// </summary>
    /// <param name="fanceeUsersId"></param>
    /// <returns></returns>
    public Task<User> ByFanceeUsersIdAsync(Guid fanceeUsersId);

    /// <summary>
    /// Updates a users last login date.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns>A mongodb UpdateResult</returns>
    public Task<UpdateResult> UpdateLastLoginAsync(Guid userId);

    /// <summary>
    /// Updates a users last login date.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns>A mongodb UpdateResult</returns>
    public Task<UpdateResult> UpdateOrganizationIdAsync(Guid userId, string organizationId);
}