using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using MongoDB.Bson;
using MongoDB.Driver;

namespace SocialListeningCore.Persistence;

public interface IMongoDao<TModel> where TModel : BasicMongoModel
{
    /// <summary>
    /// Gets a FilterDefinition to determine which entry should be updated if similar data would be retrieved from a data source.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>The latest version of the model</returns>
    public FilterDefinition<TModel> GetFilterDefinition(TModel? model);

    /// <summary>
    /// Gets an UpdateDefinition to determine which variables should be updated when requested.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>The latest version of the model</returns>
    public UpdateDefinition<TModel> GetUpdateDefinition(TModel? model);

    /// <summary>
    /// Creates a new entry of the given model in MongoDB. The collection is determined by the field CollectionId.
    /// </summary>
    /// <param name="model"></param>
    /// <returns>The latest version of the model</returns>
    public Task<TModel> CreateAsync(TModel model);

    /// <summary>
    /// Updates an entry of the given model in MongoDB, based on parameter 'filter' for the lookup, and collectionId for a specific collection.
    /// </summary>
    /// <param name="model"></param>
    /// <param name="filter"></param>
    /// <param name="collectionId"></param>
    /// <param name="isUpsert"></param>
    /// <returns>The latest version of the model</returns>
    public Task<TModel> UpdateAsync(TModel model, FilterDefinition<TModel>? filter = null, string? collectionId = null, bool isUpsert = false);

    /// <summary>
    /// Updates a single mongodb item by filter with a given update definition of what to update.
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="update"></param>
    /// <param name="collectionId"></param>
    /// <returns>The updated model</returns>
    public Task<UpdateResult> UpdateOneAsync(FilterDefinition<TModel> filter, UpdateDefinition<TModel> update, string? collectionId = null);

    /// <summary>
    /// Updates many mongodb items by filter with a given update definition of what to update.
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="update"></param>
    /// <param name="collectionId"></param>
    /// <returns>The update result (stats)</returns>
    public Task<UpdateResult> UpdateManyAsync(FilterDefinition<TModel> filter, UpdateDefinition<TModel> update, string? collectionId = null);

    /// <summary>
    /// Replace all given models from a list for a given collection.
    /// </summary>
    /// <param name="models"></param>
    /// <param name="collectionId"></param>
    /// <param name="isUpsert"></param>
    /// <returns></returns>
    public Task ReplaceListAsync(IEnumerable<TModel> models, string? collectionId = null, bool isUpsert = true);

    /// <summary>
    /// Deletes a model based on ID.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>A bool, presenting the success or failure of delete.</returns>
    public Task<bool> DeleteAsync(string id);

    /// <summary>
    /// Deletes all models that match the given filter in a specific collection.
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="collectionId"></param>
    /// <returns></returns>
    public Task<DeleteResult> DeleteListAsync(FilterDefinition<TModel> filter, string collectionId);

    /// <summary>
    /// Checks whether there is any items in collection
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="findOptions"></param>
    /// <param name="collectionId"></param>
    /// <returns>true/false</returns>
    public Task<bool> AnyAsync(FilterDefinition<TModel>? filter = null, FindOptions<TModel, TModel>? findOptions = null, string? collectionId = null);

    /// <summary>
    /// Gets a single model, based on ID.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>A single model</returns>
    public Task<TModel?> GetAsync(string id);

    /// <summary>
    /// Gets a single model, based on a custom filter definition (query).
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="findOptions"></param>
    /// <param name="collectionId"></param>
    /// <returns>A single model</returns>
    public Task<TModel?> GetAsync(FilterDefinition<TModel> filter, FindOptions<TModel, TModel>? findOptions = null, string? collectionId = null);

    /// <summary>
    /// Gets a list of models, based on a custom filter definition (query).
    /// </summary>
    /// <param name="filter"></param>
    /// <param name="findOptions"></param>
    /// <param name="collectionId"></param>
    /// <returns>A list of models</returns>
    public Task<IEnumerable<TModel>> GetListAsync(FilterDefinition<TModel>? filter = null, FindOptions<TModel, TModel>? findOptions = null, string? collectionId = null);

    /// <summary>
    /// Gets a projected list by filter and findOptions.
    /// </summary>
    /// <typeparam name="TProjection"></typeparam>
    /// <param name="filter"></param>
    /// <param name="findOptions"></param>
    /// <param name="collectionId"></param>
    /// <returns>The projected list</returns>
    public Task<IEnumerable<TProjection>> GetListAsync<TProjection>(FilterDefinition<TModel>? filter = null, FindOptions<TModel, TProjection>? findOptions = null, string? collectionId = null);

    /// <summary>
    /// Gets a paginated list of models, based on 'custom' filter, sort and projection.
    /// </summary>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="filter"></param>
    /// <param name="sortDefinition"></param>
    /// <param name="projectStages"></param>
    /// <param name="collectionId"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<T>> GetPaginatedListAsync<T>(int limit, int offset, FilterDefinition<T>? filter = null, SortDefinition<T>? sortDefinition = null, IEnumerable<BsonDocument>? projectStages = null, string? collectionId = null);

    /// <summary>
    /// Gets a list of models, based on an aggregation pipeline (query).
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="pipeline"></param>
    /// <param name="options"></param>
    /// <param name="collectionId"></param>
    /// <returns>A list of models</returns>
    public Task<IEnumerable<T>> GetListByAggregationAsync<T>(PipelineDefinition<TModel, T> pipeline, AggregateOptions? options = null, string? collectionId = null);

    /// <summary>
    /// Gets a single model, based on an aggregation pipeline (query).
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="pipeline"></param>
    /// <param name="options"></param>
    /// <param name="collectionId"></param>
    /// <returns>A single model</returns>
    public Task<T?> GetByAggregationAsync<T>(PipelineDefinition<TModel, T> pipeline, AggregateOptions? options = null, string? collectionId = null);
}