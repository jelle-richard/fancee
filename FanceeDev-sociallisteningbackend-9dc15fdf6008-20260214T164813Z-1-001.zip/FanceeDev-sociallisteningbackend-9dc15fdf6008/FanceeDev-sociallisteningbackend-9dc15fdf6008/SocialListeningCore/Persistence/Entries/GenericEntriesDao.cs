using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using SocialListeningCore.Helpers;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Persistence.Entries;

public class GenericEntriesDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<GenericEntry>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    null,
    mongoDatabase), IGenericEntriesDao
{
    public override FilterDefinition<GenericEntry> GetFilterDefinition(GenericEntry? model)
    {
        if (model == null)
            return base.GetFilterDefinition(model);

        if (!Enum.TryParse(model.SubscriptionType, out SubscriptionType subscriptionType))
            return base.GetFilterDefinition(model);

        return subscriptionType.ToFilterDefinition(model, Filter);
    }

    public override UpdateDefinition<GenericEntry> GetUpdateDefinition(GenericEntry? model)
    {
        try
        {
            return Builders<GenericEntry>.Update.Combine(
                new List<UpdateDefinition<GenericEntry>>
                {
                    Builders<GenericEntry>.Update.Set("Data", model?.Data),
                    Builders<GenericEntry>.Update.Set("Query", model?.Query),
                    base.GetUpdateDefinition(model)
                }
            );
        }
        catch
        {
            return base.GetUpdateDefinition(model);
        }
    }

    public async Task<bool> DeleteListForSubscriptionAsync(string subscriptionId, SubscriptionType type)
    {
        var filter = Filter.Eq(dbItem => dbItem.SubscriptionId, subscriptionId);
        var result = await DeleteListAsync(filter, CollectionSettings.GetCollectionName(type)!);

        return result.IsAcknowledged && result.DeletedCount > 0;
    }

    public async Task<GenericEntry?> GetAsync(SubscriptionType type) =>
        await GetAsync(Builders<GenericEntry>.Filter.Empty, null,
            CollectionSettings.GetCollectionName(type));

    public async Task<IEnumerable<GenericEntry>> GetListAsync(SubscriptionType type) =>
        await GetListAsync(Builders<GenericEntry>.Filter.Empty, null,
            CollectionSettings.GetCollectionName(type));

    public async Task<IEnumerable<TEntry>> ToListAsync<TEntry>(string subscriptionId, SubscriptionType type, DateTime? startDate = null, DateTime? endDate = null) where TEntry : Entry
    {
        var filter = EntryHelper.GetLookupDefinition<TEntry>(subscriptionId, startDate, endDate);
        var collectionId = CollectionSettings.GetCollectionName(type);
        var findOptions = new FindOptions<TEntry, TEntry>
        {
            Sort = EntryHelper.GetSortDefinition<TEntry>()
        };
        var collection = Db.GetCollection<TEntry>(collectionId);
        var cursor = await collection.FindAsync(filter ?? Builders<TEntry>.Filter.Empty, findOptions);
        return await cursor.ToListAsync();
    }

    public async Task<IEnumerable<GenericEntry>> GetListByDatesAsync(string? subscriptionId, SubscriptionType type, DateTime? startDate = null, DateTime? endDate = null, DateRange dateRange = DateRange.DAILY)
    {
        var filter = EntryHelper.GetLookupDefinition<GenericEntry>(subscriptionId, startDate, endDate);
        var findOptions = new FindOptions<GenericEntry, GenericEntry>
        {
            Sort = EntryHelper.GetSortDefinition<GenericEntry>()
        };
        var collectionId = CollectionSettings.GetCollectionName(type);

        return await GetListAsync(filter, findOptions, collectionId);
    }

    public async Task<GenericEntry?> GetLastEntryAsync(string? subscriptionId, SubscriptionType type, DateTime? startDate = null, DateTime? endDate = null)
    {
        var filter = EntryHelper.GetLookupDefinition<GenericEntry>(subscriptionId, startDate, endDate);
        var findOptions = new FindOptions<GenericEntry, GenericEntry>
        {
            Sort = EntryHelper.GetSortDefinition<GenericEntry>(),
            Limit = 1
        };
        var collectionId = CollectionSettings.GetCollectionName(type);

        return await GetAsync(filter, findOptions, collectionId);
    }
}