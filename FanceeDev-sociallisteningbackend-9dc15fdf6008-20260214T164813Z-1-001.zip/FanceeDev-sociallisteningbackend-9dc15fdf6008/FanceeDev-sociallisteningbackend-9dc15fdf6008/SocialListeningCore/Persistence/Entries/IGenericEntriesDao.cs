using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;

namespace SocialListeningCore.Persistence.Entries;

public interface IGenericEntriesDao : IEntryDao<GenericEntry>
{
    /// <summary>
    /// Gets a list of entries between startDate and endDate, produced by a specific subscription.
    /// </summary>
    /// <param name="subscriptionId"></param>
    /// <param name="type"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns>A list of entries</returns>
    public Task<IEnumerable<TEntry>> ToListAsync<TEntry>(string subscriptionId, SubscriptionType type, DateTime? startDate = null, DateTime? endDate = null) where TEntry : Entry;

    /// <summary>
    /// Gets a list of entries between a startDate and/or endDate, produced by a specific subscription
    /// </summary>
    /// <param name="subscriptionId"></param>
    /// <param name="type"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="dateRange"></param>
    /// <returns>A list of entries</returns>
    public Task<IEnumerable<GenericEntry>> GetListByDatesAsync(string? subscriptionId, SubscriptionType type, DateTime? startDate = null, DateTime? endDate = null, DateRange dateRange = DateRange.DAILY);

    /// <summary>
    /// Returns the latest known entry of a type.
    /// </summary>
    /// <param name="subscriptionId"></param>
    /// <param name="type"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns>A single GenericEntry</returns>
    public Task<GenericEntry?> GetLastEntryAsync(string? subscriptionId, SubscriptionType type, DateTime? startDate = null, DateTime? endDate = null);

    /// <summary>
    /// Deletes all entries by subscriptionId.
    /// </summary>
    /// <param name="subscriptionId"></param>
    /// <param name="type"></param>
    /// <returns></returns>
    public Task<bool> DeleteListForSubscriptionAsync(string subscriptionId, SubscriptionType type);
}