using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;

namespace SocialListeningCore.Persistence.Entries;

public interface IEntryDao<TModel> : IMongoDao<TModel> where TModel : Entry
{
    public Task<TModel?> GetAsync(SubscriptionType type);
    public Task<IEnumerable<TModel>> GetListAsync(SubscriptionType type);
}