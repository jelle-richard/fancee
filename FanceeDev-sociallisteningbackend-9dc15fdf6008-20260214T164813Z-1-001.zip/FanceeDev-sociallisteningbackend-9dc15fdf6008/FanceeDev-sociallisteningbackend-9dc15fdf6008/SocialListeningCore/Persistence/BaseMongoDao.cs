using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;

namespace SocialListeningCore.Persistence;

public class BaseMongoDao<TModel>
{
    private readonly IMongoCollection<TModel>? _collection;
    private readonly IMongoDatabase _db;

    protected BaseMongoDao(string? mongoDatabase, string collectionName, IMongoClient context)
    {
        if (mongoDatabase.IsNullOrEmpty())
            throw new MongoDatabaseStringNotFoundException();

        _db = context.GetDatabase(mongoDatabase);

        if (!collectionName.IsNullOrEmpty())
            _collection = _db.GetCollection<TModel>(collectionName);
    }

    protected IMongoCollection<TModel> Collection(string? collectionName = null)
    {
        if (_collection is not null)
            return _collection;

        if (collectionName is null)
            throw new CollectionNotFoundException();

        return _db.GetCollection<TModel>(collectionName);
    }
}