using SocialListeningCore.Dtos.MailProvider;

namespace SocialListeningCore.Persistence.MailQueues;

public interface IMailQueueDao : IMongoDao<ScheduledMail>
{
}