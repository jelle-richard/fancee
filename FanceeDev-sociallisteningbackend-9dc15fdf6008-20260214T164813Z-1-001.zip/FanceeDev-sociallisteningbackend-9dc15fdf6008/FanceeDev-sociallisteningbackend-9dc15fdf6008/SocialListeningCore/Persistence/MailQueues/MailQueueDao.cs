using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using SocialListeningCore.Dtos.MailProvider;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Persistence.MailQueues;

public class MailQueueDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<ScheduledMail>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("MailQueues"),
    mongoDatabase), IMailQueueDao;