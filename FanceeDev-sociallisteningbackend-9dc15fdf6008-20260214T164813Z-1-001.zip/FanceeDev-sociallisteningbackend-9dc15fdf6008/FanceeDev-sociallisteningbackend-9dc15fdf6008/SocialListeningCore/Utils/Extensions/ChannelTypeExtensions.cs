using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;

namespace SocialListeningCore.Utils.Extensions;

public static class ChannelTypeExtensions
{
    /// <summary>
    /// Returns all of related subscriptionTypes based on given channelType.
    /// </summary>
    /// <param name="channelType"></param>
    /// <returns></returns>
    /// <exception cref="NotSupportedException"></exception>
    public static IEnumerable<SubscriptionType> ToSubscriptionTypes(this ChannelType channelType) => channelType switch
    {
        ChannelType.FACEBOOK => [SubscriptionType.FB, SubscriptionType.FB_POSTS, SubscriptionType.FB_GEO_LIKES, SubscriptionType.FB_AGE_AND_GENDER],
        ChannelType.FACEBOOKADS => [SubscriptionType.FA_CAMPAIGN, SubscriptionType.FA_ADS, SubscriptionType.FA_GEO, SubscriptionType.FA_VIDEO, SubscriptionType.FA_CONVERSION, SubscriptionType.FA_AGE_AND_GENDER],
        ChannelType.FACEBOOKPUBLICDATA => [SubscriptionType.FBPD_PAGE, SubscriptionType.FBPD_POSTS, SubscriptionType.FBPD_URL_SHARES],
        ChannelType.INSTAGRAM => [SubscriptionType.IGI, SubscriptionType.IGI_PROFILE_DATA, SubscriptionType.IGI_MEDIA, SubscriptionType.IGI_COUNTRY, SubscriptionType.IGI_AGE_AND_GENDER],
        ChannelType.INSTAGRAMPUBLICDATA => [SubscriptionType.IGPD2_POSTS, SubscriptionType.IGPD2_HASHTAGS, SubscriptionType.IGPD2_PROFILES],
        ChannelType.GOOGLEANALYTICS => [SubscriptionType.GA_TRAFFIC, SubscriptionType.GA_PAID_TRAFFIC, SubscriptionType.GA_USER, SubscriptionType.GA_SEARCH, SubscriptionType.GA_TECHNOLOGY, SubscriptionType.GA_CONTENT, SubscriptionType.GA_ECOMMERCE, SubscriptionType.GA_SOCIAL, SubscriptionType.GA_EVENTS],
        ChannelType.GOOGLEANALYTICS4 => [SubscriptionType.GAWA_DEVICE, SubscriptionType.GAWA_ENGAGEMENT, SubscriptionType.GAWA_PUBLISHING, SubscriptionType.GAWA_USER_ACQUISITION, SubscriptionType.GAWA_TRAFFIC_ACQUISITION, SubscriptionType.GAWA_ECOM_ITEMS],
        ChannelType.GOOGLETRENDS => [SubscriptionType.GT],
        ChannelType.YOUTUBE => [SubscriptionType.YT_VIDEO],
        ChannelType.YOUTUBEV2 => [SubscriptionType.YT2_AD_PERFORMANCE, SubscriptionType.YT2_CHANNEL, SubscriptionType.YT2_DEMOGRAPHIC, SubscriptionType.YT2_DEVICE, SubscriptionType.YT2_GEO, SubscriptionType.YT2_TRAFFIC_SOURCE, SubscriptionType.YT2_VIDEO],
        ChannelType.LINKEDIN => [SubscriptionType.LIP_PAGE, SubscriptionType.LIP_POST, SubscriptionType.LIP_COUNTRY],
        ChannelType.GOOGLEADS => [SubscriptionType.AW_CAMPAIGN, SubscriptionType.AW_AD, SubscriptionType.AW_KEYWORD, SubscriptionType.AW_PLACEMENT, SubscriptionType.AW_CONVERSION, SubscriptionType.AW_SEARCH_QUERY, SubscriptionType.AW_SHOPPING, SubscriptionType.AW_GEO, SubscriptionType.AW_AGE, SubscriptionType.AW_GENDER],
        ChannelType.TIKTOK => new[] { SubscriptionType.TIKBA_PROFILE, SubscriptionType.TIKBA_VIDEO, SubscriptionType.TIKBA_COUNTRY, SubscriptionType.TIKBA_GENDER },
        var _ => throw new ChannelTypeNotSupportedException(channelType, "ToSubscriptionTypes")
    };

    /// <summary>
    /// Returns the corresponding ChannelType based on given subscriptionType
    /// </summary>
    /// <param name="subscriptionType"></param>
    /// <returns></returns>
    /// <exception cref="SubscriptionTypeNotSupportedException"></exception>
    public static ChannelType ToChannelType(this SubscriptionType subscriptionType) => subscriptionType switch
    {
        SubscriptionType.FB or SubscriptionType.FB_POSTS or SubscriptionType.FB_GEO_LIKES or SubscriptionType.FB_AGE_AND_GENDER => ChannelType.FACEBOOK,
        SubscriptionType.FA_CAMPAIGN or SubscriptionType.FA_ADS or SubscriptionType.FA_GEO or SubscriptionType.FA_VIDEO or SubscriptionType.FA_CONVERSION or SubscriptionType.FA_AGE_AND_GENDER => ChannelType.FACEBOOKADS,
        SubscriptionType.FBPD_PAGE or SubscriptionType.FBPD_POSTS or SubscriptionType.FBPD_URL_SHARES => ChannelType.FACEBOOKPUBLICDATA,
        SubscriptionType.IGI or SubscriptionType.IGI_CITY or SubscriptionType.IGI_COUNTRY or SubscriptionType.IGI_AGE_AND_GENDER or SubscriptionType.IGI_MEDIA or SubscriptionType.IGI_PROFILE_DATA => ChannelType.INSTAGRAM,
        SubscriptionType.IGPD2_PROFILES or SubscriptionType.IGPD2_POSTS or SubscriptionType.IGPD2_HASHTAGS => ChannelType.INSTAGRAMPUBLICDATA,
        SubscriptionType.GA_TRAFFIC or SubscriptionType.GA_PAID_TRAFFIC or SubscriptionType.GA_SEARCH or SubscriptionType.GA_USER or SubscriptionType.GA_TECHNOLOGY or SubscriptionType.GA_CONTENT or SubscriptionType.GA_ECOMMERCE or SubscriptionType.GA_SOCIAL or SubscriptionType.GA_EVENTS => ChannelType.GOOGLEANALYTICS,
        SubscriptionType.GAWA or SubscriptionType.GAWA_DEVICE or SubscriptionType.GAWA_ECOM_ITEMS or SubscriptionType.GAWA_ENGAGEMENT or SubscriptionType.GAWA_PUBLISHING or SubscriptionType.GAWA_TRAFFIC_ACQUISITION or SubscriptionType.GAWA_USER_ACQUISITION => ChannelType.GOOGLEANALYTICS4,
        SubscriptionType.GT => ChannelType.GOOGLETRENDS,
        SubscriptionType.YT_VIDEO => ChannelType.YOUTUBE,
        SubscriptionType.YT2_AD_PERFORMANCE or SubscriptionType.YT2_CHANNEL or SubscriptionType.YT2_DEMOGRAPHIC or SubscriptionType.YT2_DEVICE or SubscriptionType.YT2_GEO or SubscriptionType.YT2_TRAFFIC_SOURCE or SubscriptionType.YT2_VIDEO => ChannelType.YOUTUBEV2,
        SubscriptionType.LIP_PAGE or SubscriptionType.LIP_POST or SubscriptionType.LIP_COUNTRY => ChannelType.LINKEDIN,
        SubscriptionType.AW_CAMPAIGN or SubscriptionType.AW_AD or SubscriptionType.AW_KEYWORD or SubscriptionType.AW_PLACEMENT or SubscriptionType.AW_CONVERSION or SubscriptionType.AW_SEARCH_QUERY or SubscriptionType.AW_SHOPPING or SubscriptionType.AW_GEO or SubscriptionType.AW_AGE or SubscriptionType.AW_GENDER => ChannelType.GOOGLEADS,
        SubscriptionType.TIKBA_PROFILE or SubscriptionType.TIKBA_VIDEO or SubscriptionType.TIKBA_COUNTRY or SubscriptionType.TIKBA_GENDER => ChannelType.TIKTOK,
        var _ => throw new SubscriptionTypeNotSupportedException(subscriptionType)
    };

    /// <summary>
    /// Returns the corresponding SuperMetrics DataSource ID (ds_id).
    /// </summary>
    /// <param name="channelType"></param>
    /// <returns>ds_id as string</returns>
    /// <exception cref="NotSupportedException"></exception>
    public static string ToDSID(this ChannelType channelType) => channelType switch
    {
        ChannelType.FACEBOOK => "FB",
        ChannelType.FACEBOOKADS => "FA",
        ChannelType.FACEBOOKPUBLICDATA => "FBPD",
        ChannelType.GOOGLEANALYTICS => "GA",
        ChannelType.GOOGLEANALYTICS4 => "GAWA",
        ChannelType.INSTAGRAM => "IGI",
        ChannelType.INSTAGRAMPUBLICDATA => "IGPD2",
        ChannelType.GOOGLETRENDS => "GT",
        ChannelType.YOUTUBE => "YT",
        ChannelType.YOUTUBEV2 => "YT2",
        ChannelType.LINKEDIN => "LIP",
        ChannelType.GOOGLEADS => "AW",
        ChannelType.TIKTOK => "TIKBA",
        var _ => throw new ChannelTypeNotSupportedException(channelType, "ToDSID")
    };

    /// <summary>
    /// Returns the corresponding SuperMetrics DateRangeType for a given SubscriptionType.
    /// </summary>
    /// <param name="subscriptionType"></param>
    /// <returns>DateRangeType as string</returns>
    public static string ToDefaultDateRangeType(this SubscriptionType subscriptionType) => subscriptionType switch
    {
        SubscriptionType.FB_POSTS or SubscriptionType.IGI_MEDIA or SubscriptionType.IGPD2_POSTS or SubscriptionType.LIP_POST or SubscriptionType.TIKBA_VIDEO or SubscriptionType.YT2_VIDEO or SubscriptionType.FBPD_POSTS or SubscriptionType.IGPD2_POSTS => "last_30_days_inc",
        var _ => "last_2_days_inc"
    };
}