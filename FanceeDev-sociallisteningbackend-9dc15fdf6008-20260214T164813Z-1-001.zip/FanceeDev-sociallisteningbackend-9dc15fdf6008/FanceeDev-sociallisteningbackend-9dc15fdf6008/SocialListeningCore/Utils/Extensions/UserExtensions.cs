using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;

namespace SocialListeningCore.Utils.Extensions;

public static class UserExtensions
{
    public static UserResponse ToResponse(this User user) =>
        new()
        {
            Id = user.FanceeUsersId,
            OrganizationId = user.OrganizationId,
            Type = user.Type,
            Email = user.Email,
            FirstName = user.FirstName,
            LastName = user.LastName,
            AvatarFilePath = null,
            LastLogin = user.LastLogin,
            CreatedOn = user.CreatedOn,
            UpdatedOn = user.UpdatedOn,
            IsVerified = user.IsVerified
        };
}