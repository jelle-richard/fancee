namespace SocialListeningCore.Utils.String;

/// <summary>
/// Contains handy string utilities
/// </summary>
public static class StringUtils
{
    /// <summary>
    /// Converts the first character of a string to an uppercase.
    /// </summary>
    /// <param name="str"></param>
    /// <returns></returns>
    public static string UcFirst(this string str)
    {
        if (string.IsNullOrWhiteSpace(str))
            return str;

        return char.ToUpperInvariant(str[0]) + str[1..];
    }
}