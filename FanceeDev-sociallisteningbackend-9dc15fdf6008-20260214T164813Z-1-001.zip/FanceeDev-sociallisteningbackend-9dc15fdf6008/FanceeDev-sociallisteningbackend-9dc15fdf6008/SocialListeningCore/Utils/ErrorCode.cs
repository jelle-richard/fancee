namespace SocialListeningCore.Utils;

/// <summary>
/// Contains all the error codes used in the system.
/// </summary>
public enum ErrorCode
{
    ExceptionInvalidData = 89701,
    ExceptionRelogRequired = 89702,
    ExceptionExternalService = 89703,
    ExceptionInternalService = 89704,
    ExceptionInvalidConfiguration = 89705,
    ExceptionObjectInUse = 89706,
    ExceptionOutdatedInformation = 89707,
    ExceptionNoData = 89708,
    ExceptionTooManyRequests = 89709,
    ExceptionInsufficientFunds = 89710,
    ExceptionFeatureNotEnabled = 89711,
    ExceptionInsufficientStock = 89712,
    ExceptionUnsupported = 89713
}