using System.Security.Claims;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;

namespace SocialListeningCore.Utils.HttpContext;

public static class UserUtils
{
    /// <summary>
    /// Gets the user id of the claims principal.
    /// </summary>
    /// <param name="claimsPrincipal"></param>
    /// <returns></returns>
    public static Guid GetUserId(this ClaimsPrincipal claimsPrincipal) =>
        claimsPrincipal.GetGuidFromClaim("platformUserId") ?? throw new UserNotFoundException();

    /// <summary>
    /// Gets the FanceeUsers id from the claims principal.
    /// </summary>
    /// <param name="claimsPrincipal"></param>
    /// <returns></returns>
    /// <exception cref="UserNotFoundException"></exception>
    public static Guid GetFanceeUsersId(this ClaimsPrincipal claimsPrincipal) =>
        claimsPrincipal.GetGuidFromClaim("user") ?? throw new UserNotFoundException();

    /// <summary>
    /// Gets the type of the claims principal.
    /// </summary>
    /// <param name="claimsPrincipal"></param>
    /// <returns></returns>
    public static UserType? GetUserType(this ClaimsPrincipal claimsPrincipal)
    {
        var type = claimsPrincipal?.Claims.FirstOrDefault(c => c.Type == "type")?.Value;

        if (string.IsNullOrWhiteSpace(type))
            return null;

        if (!Enum.TryParse<UserType>(type, out var userType))
            return null;

        return userType;
    }

    private static Guid? GetGuidFromClaim(this ClaimsPrincipal claimsPrincipal, string key)
    {
        var value = claimsPrincipal?.Claims.FirstOrDefault(c => c.Type == key)?.Value;

        if (!Guid.TryParse(value, out var guid))
            return null;

        return guid;
    }
}