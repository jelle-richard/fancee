using System.Globalization;
using System.Text;

namespace SocialListeningCore.Utils.Country;

public static class CountryUtils
{
    private static Dictionary<string, string>? _countryNameAndCode;

    public static Dictionary<string, string> Countries()
    {
        if (_countryNameAndCode != null)
            return _countryNameAndCode;

        var countryNameAndCode = new Dictionary<string, string>();
        var cultures = CultureInfo.GetCultures(CultureTypes.AllCultures & ~CultureTypes.NeutralCultures);
        foreach (var culture in cultures)
        {
            var region = new RegionInfo(culture.Name);
            var nonDiacriticsName = RemoveDiacritics(region.EnglishName);
            if (!countryNameAndCode.ContainsKey(nonDiacriticsName))
                countryNameAndCode.Add(nonDiacriticsName, region.TwoLetterISORegionName);
        }

        _countryNameAndCode = countryNameAndCode;

        return countryNameAndCode;
    }

    public static string? GetCountryCode(string countryName)
    {
        if (Countries().TryGetValue(RemoveDiacritics(countryName), out var result))
            return result;
        return null;
    }

    private static string RemoveDiacritics(string text)
    {
        ReadOnlySpan<char> normalizedString = text.Normalize(NormalizationForm.FormD);
        var i = 0;
        Span<char> span = stackalloc char[text.Length];

        foreach (var c in normalizedString)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                span[i++] = c;
        }

        return new string(span).Normalize(NormalizationForm.FormC);
    }
}