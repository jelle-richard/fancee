using Microsoft.AspNetCore.Mvc.ModelBinding;
using SocialListeningCore.Utils.String;

namespace SocialListeningCore.Utils.Validation;

public static class ModelStateUtils
{
    public static IDictionary<string, List<string>> ToDictionaryList(this ModelStateDictionary state)
    {
        return state.Where(modelState => modelState.Value != null && modelState.Value.Errors.Count > 0)
            .ToDictionary(kvp => kvp.Key.Replace("$.", string.Empty).UcFirst(),
                kvp => kvp.Value!.Errors
                    .Select(e => e.ErrorMessage)
                    .ToList());
    }
}