using Cronos;

namespace SocialListeningCore.Utils.Cron;

public static class CronHelper
{
    public static bool TryParse(string? expression)
    {
        try
        {
            CronExpression.Parse(expression, CronFormat.Standard);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static string GetSimpleCronSchema(int addedMinutes) => $"{(DateTime.UtcNow.Minute + addedMinutes) % 60} * * * *";
}