namespace SocialListeningCore.Utils.Cron;

public static class CronConstants
{
    public const string CronRunEveryMinute = "* * * * *";
    public const string CronRunAt3Pm = "0 15 * * *";
    public const string CronRunEvery5Minutes = "*/5 * * * *";
    public const string CronRunEveryHour = "0 * * * *";
}