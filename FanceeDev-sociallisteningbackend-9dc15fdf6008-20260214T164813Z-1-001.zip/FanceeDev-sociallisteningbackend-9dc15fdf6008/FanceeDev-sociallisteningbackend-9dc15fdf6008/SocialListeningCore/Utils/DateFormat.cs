namespace SocialListeningCore.Utils;

/// <summary>
/// Contains commonly used date formats.
/// </summary>
public static class DateFormat
{
    public const string YearMonthDayHourMinuteSecond = "yyyy-MM-dd HH:mm:ss";
    public const string DefaultApiResponse = YearMonthDayHourMinuteSecond;
    public const string DayMonthYearHourMinute = "dd-MM-yyyy HH:mm";
    public const string YearMonthDay = "yyyy-MM-dd";
    public const string YearMonth = "yyyy-MM";
}