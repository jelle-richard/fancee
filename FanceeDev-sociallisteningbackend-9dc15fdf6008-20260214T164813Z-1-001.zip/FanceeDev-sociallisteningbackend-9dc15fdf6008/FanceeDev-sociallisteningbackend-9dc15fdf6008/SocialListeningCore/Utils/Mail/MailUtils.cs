using MailTemplates.Models;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Utils.Mail;

public static class MailUtils
{
    /// <summary>
    /// Sets the default values that are needed by any mail.
    /// </summary>
    /// <param name="model"></param>
    /// <param name="subject"></param>
    /// <param name="organizationDetails"></param>
    /// <param name="baseUrl"></param>
    /// <returns></returns>
    public static MailModel SetDefaultValues(this MailModel model, string subject, OrganizationDetailsSettings organizationDetails, string baseUrl)
    {
        model.Socials = GetSocialMediaInfo(organizationDetails, baseUrl).ToList();
        model.PlatformUrl = baseUrl;
        model.PlatformName = organizationDetails.PlatformName;
        model.PlatformLogoUrl = $"{baseUrl}/assets/images/logos/platform.png";
        model.Title = subject;

        return model;
    }

    /// <summary>
    /// Gets the social media buttons for use in the mail footer.
    /// </summary>
    /// <param name="organizationSettings"></param>
    /// <param name="baseUrl"></param>
    /// <returns></returns>
    public static IEnumerable<MailModel.SocialMediaEntryInfo> GetSocialMediaInfo(OrganizationDetailsSettings organizationSettings, string baseUrl)
    {
        if (organizationSettings.Socials.FacebookUrl != null)
            yield return new() { Name = "Facebook", Url = organizationSettings.Socials.FacebookUrl, LogoUrl = $"{baseUrl}/assets/images/logos/socials/facebook.png" };

        if (organizationSettings.Socials.TwitterUrl != null)
            yield return new() { Name = "Twitter", Url = organizationSettings.Socials.TwitterUrl, LogoUrl = $"{baseUrl}/assets/images/logos/socials/twitter.png" };

        if (organizationSettings.Socials.InstagramUrl != null)
            yield return new() { Name = "Instagram", Url = organizationSettings.Socials.InstagramUrl, LogoUrl = $"{baseUrl}/assets/images/logos/socials/instagram.png" };
    }
}