using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;

namespace SocialListeningCore.Logging;

public static class MongoLoggerExtensions
{
    public static Log MongoLogInfo(this ILogger logger, Guid? userId, string message, object? data = null, Exception? exception = null) => logger.MongoLog(LogLevel.Information, userId, message, data, exception);

    public static Log MongoLogWarning(this ILogger logger, Guid? userId, string message, object? data = null, Exception? exception = null) => logger.MongoLog(LogLevel.Warning, userId, message, data, exception);

    public static Log MongoLogException(this ILogger logger, Guid? userId, Exception exception) => logger.MongoLog(LogLevel.Error, userId, exception.Message, null, exception);

    public static Log MongoLog(this ILogger logger, LogLevel logLevel, Guid? userId, string message, object? data = null, Exception? exception = null)
    {
        var log = new Log(message)
        {
            UserId = userId,
            Level = logLevel,
            Exception = exception?.StackTrace
        };

        // Do not remove!
        // Must be separate 'if' statement for MongoDB to recognize default 'null' value.
        // Setting the field explicitly to null breaks mongodb.
        if (data != null)
            log.Data = data.ToBsonDocument();

        logger.Log(logLevel, new(), log, exception, (item, exception) => item.Message);

        return log;
    }
}