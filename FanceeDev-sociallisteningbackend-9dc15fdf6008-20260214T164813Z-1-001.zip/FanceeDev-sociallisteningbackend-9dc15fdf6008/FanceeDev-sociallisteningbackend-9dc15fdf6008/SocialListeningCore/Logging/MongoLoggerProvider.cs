using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;

namespace SocialListeningCore.Logging;

public sealed class MongoLoggerProvider(MongoConfiguration configuration) : ILoggerProvider
{
    public ILogger CreateLogger(string categoryName) => new MongoLogger(categoryName, configuration.Client, configuration.DatabaseName);

    public void Dispose()
    {
        //Doesn't have anything to dispose.
    }
}