using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;

namespace SocialListeningCore.Logging;

public class MongoLogger(string categoryName, IMongoClient mongoClient, string databaseName) : ILogger
{
    public const string Name = nameof(MongoLogger);
    private readonly IMongoCollection<Log> _logCollection = mongoClient.GetDatabase(databaseName).GetCollection<Log>("logs");

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
        if (IsEnabled(logLevel) && state is Log log)
            _logCollection.InsertOne(log);
    }

    public bool IsEnabled(LogLevel logLevel) => categoryName == Name;

    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => state as IDisposable;
}