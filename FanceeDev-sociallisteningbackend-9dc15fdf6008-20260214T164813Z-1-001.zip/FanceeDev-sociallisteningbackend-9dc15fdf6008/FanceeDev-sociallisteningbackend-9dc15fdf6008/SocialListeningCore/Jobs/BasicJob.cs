using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Services.Cron;
using SocialListeningCore.Services.Scheduler;

namespace SocialListeningCore.Jobs;

public class BasicJob<TBasicCron, TCronService>(IServiceProvider serviceProvider, ILogger logger, SchedulerOptions options, TBasicCron input) : IScheduledJob
    where TBasicCron : BasicCron
    where TCronService : ICronService<TBasicCron>
{
    public string Name => input.Name!;

    public async Task ExecuteAsync(CancellationToken cancellationToken)
    {
        logger.LogInformation("[{DateTime}]: {CronSchedule} - {Name} is now running.", DateTime.UtcNow, options.CronSchedule, Name);

        if (input.RunOnce)
            serviceProvider.GetRequiredService<ISchedulerService<TBasicCron>>().StopJob(Name);

        await serviceProvider.GetRequiredService<TCronService>().RunAsync(input);
    }
}