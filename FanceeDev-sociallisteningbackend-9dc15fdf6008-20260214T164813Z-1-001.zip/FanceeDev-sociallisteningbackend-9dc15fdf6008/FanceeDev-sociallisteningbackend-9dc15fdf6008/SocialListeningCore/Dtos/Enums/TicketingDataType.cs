namespace SocialListeningCore.Dtos.Enums;

/// <summary>
/// Keep in line with <see cref="FanceeAnalyticsData.Models.CollectionName"/> .
/// </summary>
public enum TicketingDataType
{
    Clients,
    Events
}