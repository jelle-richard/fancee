namespace SocialListeningCore.Dtos.Enums;

public enum SynchronisationType
{
    FetchNewlyCreated = 1,
    ValidateExistingAndOrUpdate = 2
}