using System.Net;
using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Dtos.Environment;

public class HostedDeploymentEnvironment : DeploymentEnvironment
{
    public string Scheme => IsHttps ? SchemeHttps : SchemeHttp;

    private const string SchemeHttps = "https";
    private const string SchemeHttp = "http";

    public bool IsHttps { get; set; }
    public IPAddress? RemoteIpAddress { get; set; }

    public new string Domain
    {
        get => _domain + (Port != null ? $":{Port}" : string.Empty);
        set => _domain = value;
    }

    private string? _domain;
}