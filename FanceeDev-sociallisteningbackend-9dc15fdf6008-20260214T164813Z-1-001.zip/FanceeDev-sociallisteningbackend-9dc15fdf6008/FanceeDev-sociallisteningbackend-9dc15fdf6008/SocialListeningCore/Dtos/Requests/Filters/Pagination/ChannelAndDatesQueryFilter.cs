namespace SocialListeningCore.Dtos.Requests.Filters.Pagination;

public class ChannelAndDatesQueryFilter : IPaginationFilter
{
    public string ChannelId { get; set; } = string.Empty;
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
}