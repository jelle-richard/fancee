namespace SocialListeningCore.Dtos.Requests.Filters.Pagination;

public class QueryFilter<TFieldOption>(TFieldOption orderBy, bool ascending) : IPaginationFilter
    where TFieldOption : struct, Enum
{
    public TFieldOption OrderBy { get; set; } = orderBy;
    public bool OrderByAscending { get; set; } = ascending;

    public QueryFilter() : this(default, false)
    {
    }
}