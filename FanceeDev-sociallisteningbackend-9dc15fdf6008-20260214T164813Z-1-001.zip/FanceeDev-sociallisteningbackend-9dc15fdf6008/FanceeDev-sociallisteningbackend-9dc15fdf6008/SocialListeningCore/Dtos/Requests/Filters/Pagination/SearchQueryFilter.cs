namespace SocialListeningCore.Dtos.Requests.Filters.Pagination;

public class SearchQueryFilter : IPaginationFilter
{
    public string SearchQuery { get; set; } = string.Empty;
}