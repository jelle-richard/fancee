namespace SocialListeningCore.Dtos.Requests.Filters.Pagination;

public interface IPaginationFilter
{
}