namespace SocialListeningCore.Dtos.Requests.Filters.Pagination;

public class SumQueryFilter<TFieldOption> : QueryFilter<TFieldOption> where TFieldOption : struct, Enum
{
    public string[] ChannelIds { get; set; } = Array.Empty<string>();
    public DateTime StartDate { get; set; } = DateTime.UtcNow;
    public DateTime EndDate { get; set; } = DateTime.UtcNow;
} 