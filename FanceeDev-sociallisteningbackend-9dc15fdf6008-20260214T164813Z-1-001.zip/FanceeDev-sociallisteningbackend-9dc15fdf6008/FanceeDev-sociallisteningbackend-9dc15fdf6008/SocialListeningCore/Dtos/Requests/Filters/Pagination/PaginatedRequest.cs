using System.ComponentModel.DataAnnotations;

namespace SocialListeningCore.Dtos.Requests.Filters.Pagination;

public class PaginatedRequest<TFilter> where TFilter : IPaginationFilter, new()
{
    [Range(1, 100)]
    public int PageSize { get; set; } = 10;

    [Range(1, int.MaxValue)]
    public int Page { get; set; } = 1;

    public TFilter Options { get; set; } = new();

    public int GetOffset() => PageSize * (Page - 1);
}