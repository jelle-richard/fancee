using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.IdentityModel.Tokens;

namespace SocialListeningCore.Dtos.Requests.Subscriptions;

public class CreateSubscriptionRequest : IValidatableObject
{
    [Required]
    public string? ChannelId { get; set; }

    [Required]
    [JsonPropertyName("type")]
    public SubscriptionType SubscriptionType { get; set; }

    [Required]
    public string Query { get; set; } = string.Empty;

    [Required]
    public string Cron { get; set; } = string.Empty;

    public bool RequestHistory { get; set; } = true;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if(string.IsNullOrWhiteSpace(Query))
            yield return new("Requested query cannot be empty.");
    }
}