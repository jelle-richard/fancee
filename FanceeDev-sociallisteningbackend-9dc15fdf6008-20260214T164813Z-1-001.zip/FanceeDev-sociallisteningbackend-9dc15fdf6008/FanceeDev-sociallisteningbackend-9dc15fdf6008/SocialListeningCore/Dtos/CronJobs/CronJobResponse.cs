using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Dtos.CronJobs;

public class CronJobResponse<TBasicCron> where TBasicCron : BasicCron
{
    public string? JobName { get; set; }
    public TBasicCron? Input { get; set; }
    public bool IsRunning { get; set; }
    public bool IsStopped { get; set; }
}