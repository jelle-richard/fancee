using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Bson.Serialization.Attributes;

namespace SocialListeningCore.Dtos.Responses;

[BsonIgnoreExtraElements]
public class EntryResponse(SubscriptionType type) : Entry(type)
{
    [BsonElement("data")]
    public dynamic? Data { get; set; }

    [BsonElement("query")]
    public dynamic? Query { get; set; }
}