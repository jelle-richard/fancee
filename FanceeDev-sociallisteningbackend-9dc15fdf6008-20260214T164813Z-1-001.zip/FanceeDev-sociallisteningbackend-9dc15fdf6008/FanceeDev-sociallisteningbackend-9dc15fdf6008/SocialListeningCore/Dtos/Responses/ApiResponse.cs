using SocialListeningCore.Utils;

namespace SocialListeningCore.Dtos.Responses;

/// <summary>
/// Base class for all API responses.
/// </summary>
/// <typeparam name="TData"></typeparam>
public class ApiResponse<TData>
{
    public TData? Data { get; set; }
    public IDictionary<string, List<string>>? Errors { get; set; }

    /// <summary>
    /// Adds a new error with the given error code and message.
    /// </summary>
    /// <param name="code"></param>
    /// <param name="message"></param>
    public void AddError(ErrorCode code, string message)
    {
        AddError($"FAN-{(int)code}", message);
    }

    /// <summary>
    /// Adds a new error to the list.
    /// </summary>
    /// <param name="key"></param>
    /// <param name="error"></param>
    public void AddError(string key, string error)
    {
        Errors ??= new Dictionary<string, List<string>>();

        if (Errors.TryGetValue(key, out var value))
        {
            value.Add(error);
            return;
        }

        Errors.Add(key, [error]);
    }
}