namespace SocialListeningCore.Dtos.Responses;

public class PaginatedResponse<TResponseModel>
{
    public int Pages => (int)Math.Ceiling((double)TotalItems / PageSize);
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalItems { get; set; }
    public IEnumerable<TResponseModel>? Items { get; set; }
}