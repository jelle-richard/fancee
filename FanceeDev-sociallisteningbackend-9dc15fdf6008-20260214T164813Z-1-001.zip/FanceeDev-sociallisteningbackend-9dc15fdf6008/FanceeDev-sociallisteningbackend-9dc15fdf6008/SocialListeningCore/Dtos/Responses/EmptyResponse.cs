namespace SocialListeningCore.Dtos.Responses;

/// <summary>
/// Used for APIs where no data is returned.
/// </summary>
public class EmptyResponse
{
}