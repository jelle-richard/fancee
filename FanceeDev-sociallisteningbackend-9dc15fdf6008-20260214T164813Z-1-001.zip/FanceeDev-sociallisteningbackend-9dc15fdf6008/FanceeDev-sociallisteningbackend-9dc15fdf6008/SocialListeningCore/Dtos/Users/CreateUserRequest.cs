using System.ComponentModel.DataAnnotations;
using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Dtos.Users;

public class CreateUserRequest : IValidatableObject
{
    [Required]
    [EmailAddress]
    [MaxLength(254)]
    public string? Email { get; set; }

    [Required]
    [MinLength(5)]
    public string? Password { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? PhoneNumber { get; set; }

    public UserType UserType { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        Email = Email?.ToLowerInvariant();

        yield return ValidationResult.Success!;
    }
}