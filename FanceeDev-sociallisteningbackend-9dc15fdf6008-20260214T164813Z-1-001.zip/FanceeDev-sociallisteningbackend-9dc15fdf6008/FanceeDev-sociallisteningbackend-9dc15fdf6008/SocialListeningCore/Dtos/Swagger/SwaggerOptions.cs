namespace SocialListeningCore.Dtos.Swagger;

/// <summary>
/// Used for specifying the configuration for the Swagger API documentation generator.
/// </summary>
public class SwaggerOptions
{
    public string? Title { get; set; }
    public string Version { get; set; } = "v1";
    public string EndpointUrl { get; set; } = "/swagger/v1/swagger.json";
    public string? EndpointName { get; set; }
    public bool EnumsAsStrings { get; set; } = true;
}