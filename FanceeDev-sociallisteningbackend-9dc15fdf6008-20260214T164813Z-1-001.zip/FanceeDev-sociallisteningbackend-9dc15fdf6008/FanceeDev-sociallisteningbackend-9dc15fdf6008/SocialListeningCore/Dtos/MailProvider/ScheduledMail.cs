using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace SocialListeningCore.Dtos.MailProvider;

public class ScheduledMail(Mail mail) : BasicMongoModel
{
    [BsonElement("mail")]
    public Mail Mail { get; set; } = mail;

    [BsonElement("send_status")]
    [BsonRepresentation(BsonType.String)]
    public SendStatus SendStatus { get; set; }
}