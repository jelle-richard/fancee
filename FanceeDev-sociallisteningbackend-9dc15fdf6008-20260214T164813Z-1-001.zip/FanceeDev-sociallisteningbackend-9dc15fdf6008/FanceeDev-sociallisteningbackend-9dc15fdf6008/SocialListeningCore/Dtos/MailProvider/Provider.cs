namespace SocialListeningCore.Dtos.MailProvider;

public enum Provider
{
    Default,
    Mailchimp
}