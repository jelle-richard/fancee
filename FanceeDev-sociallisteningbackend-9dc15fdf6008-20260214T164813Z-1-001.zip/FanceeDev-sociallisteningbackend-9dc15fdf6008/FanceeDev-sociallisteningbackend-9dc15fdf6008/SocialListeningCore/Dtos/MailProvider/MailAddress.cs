using System.ComponentModel.DataAnnotations;

namespace SocialListeningCore.Dtos.MailProvider;

public class MailAddress(string email, string? name)
{
    [StringLength(100)]
    public string? Name { get; set; } = name;

    [EmailAddress]
    [Required]
    [StringLength(254)]
    public string Email { get; set; } = email;
}