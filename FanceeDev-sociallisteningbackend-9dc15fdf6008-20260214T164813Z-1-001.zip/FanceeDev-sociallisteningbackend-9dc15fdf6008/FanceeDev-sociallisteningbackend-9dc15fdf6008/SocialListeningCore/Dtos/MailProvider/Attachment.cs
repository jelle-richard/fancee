using System.ComponentModel.DataAnnotations;

namespace SocialListeningCore.Dtos.MailProvider;

public class Attachment(string fileName, string type, string base64Content)
{
    [Required]
    [StringLength(250)]
    public string FileName { get; set; } = fileName;

    [Required]
    [StringLength(250)]
    public string Type { get; set; } = type;

    [Required]
    public string Base64Content { get; set; } = base64Content;
}