using System.ComponentModel.DataAnnotations;
using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Dtos.MailProvider;

public class Mail : BasicMongoModel, IValidatableObject
{
    public MailAddress? From { get; set; }

    public IEnumerable<MailAddress> To { get; set; } = Array.Empty<MailAddress>();

    public IEnumerable<MailAddress> Cc { get; set; } = Array.Empty<MailAddress>();

    public IEnumerable<MailAddress> Bcc { get; set; } = Array.Empty<MailAddress>();

    public IEnumerable<Header> Headers { get; set; } = Array.Empty<Header>();

    [StringLength(250)]
    public string Subject { get; set; } = string.Empty;

    public string TextContent { get; set; } = string.Empty;

    public string HtmlContent { get; set; } = string.Empty;

    public IEnumerable<Attachment> Attachments { get; set; } = Array.Empty<Attachment>();

    public DateTime? SendOn { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!To.Any() && !Cc.Any() && !Bcc.Any())
            yield return new("Atleast one is required: To, Cc, Bcc", new[] { nameof(To), nameof(Cc), nameof(Bcc) });

        if (string.IsNullOrWhiteSpace(TextContent) && string.IsNullOrWhiteSpace(HtmlContent))
            yield return new("Atleast one is required: TextContent, HtmlContent", new[] { nameof(TextContent), nameof(HtmlContent) });

        if (SendOn != null && SendOn < DateTime.UtcNow)
            yield return new($"{nameof(SendOn)} cannot be in the past", new[] { nameof(SendOn) });
    }
}