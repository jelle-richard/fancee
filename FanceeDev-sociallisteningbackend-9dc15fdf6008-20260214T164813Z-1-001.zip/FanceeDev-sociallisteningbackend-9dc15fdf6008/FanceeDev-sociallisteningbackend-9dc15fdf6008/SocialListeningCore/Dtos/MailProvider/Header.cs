using System.ComponentModel.DataAnnotations;

namespace SocialListeningCore.Dtos.MailProvider;

public class Header(string name, string value)
{
    [Required]
    [StringLength(250)]
    public string Name { get; set; } = name;

    [Required]
    [StringLength(250)]
    public string Value { get; set; } = value;
}