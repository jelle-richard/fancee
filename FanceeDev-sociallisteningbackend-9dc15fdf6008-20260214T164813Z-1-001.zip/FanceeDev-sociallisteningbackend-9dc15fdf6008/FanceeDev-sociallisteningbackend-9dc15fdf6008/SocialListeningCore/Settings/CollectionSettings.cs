using FanceeAnalyticsData.Models.Analytics;

namespace SocialListeningCore.Settings;

/// <summary>
/// Manage all collection names.
/// </summary>
public static class CollectionSettings
{
    private static readonly Dictionary<string, string> Collections = new()
    {
        { "Channels", "channels" },
        { "ChannelSettings", "channel_settings" },
        { "Subscriptions", "subscriptions" },
        { "SubscriptionSettings", "subscription_settings" },
        { "Connections", "connections" },
        { "Logs", "logs" },
        { "Posts", "posts" },
        { "Users", "users" },
        { "Organizations", "organizations" },
        { "PasswordResets", "password_resets" },
        { "DeploymentEnvironments", "deployment_environments" },
        { "MailQueues", "mail_queues" }
    };

    public static string? GetCollectionName(SubscriptionType subscriptionType) => $"entries_{subscriptionType.ToString().ToLower()}";

    public static string? GetCollectionName(string key)
    {
        if (Collections.TryGetValue(key, out var value))
            return value;

        throw new KeyNotFoundException($"The collection '{key}' was not found.");
    }

    public static void AddCollection(string key, string name)
    {
        if (!Collections.TryAdd(key, name))
            throw new ArgumentException($"The collection '{key}' already exists.");
    }

    public static void UpdateCollection(string key, string name)
    {
        if (!Collections.ContainsKey(key))
            throw new KeyNotFoundException($"The collection '{key}' was not found.");

        Collections[key] = name;
    }

    public static void RemoveCollection(string key)
    {
        if (!Collections.ContainsKey(key))
            throw new KeyNotFoundException($"The collection '{key}' was not found.");

        Collections.Remove(key);
    }
}