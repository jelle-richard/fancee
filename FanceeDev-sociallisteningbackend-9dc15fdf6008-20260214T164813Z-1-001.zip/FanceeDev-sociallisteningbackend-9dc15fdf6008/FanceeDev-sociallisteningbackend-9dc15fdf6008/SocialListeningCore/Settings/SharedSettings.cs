using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration.Json;

namespace SocialListeningCore.Settings;

public static class SharedSettings
{
    public static IWebHostBuilder AddSharedSettings(this IWebHostBuilder builder, string sharedFileName)
    {
        if (builder == null || string.IsNullOrEmpty(sharedFileName))
            return builder!;

        builder.ConfigureAppConfiguration((hostingContext, config) =>
        {
            var fileNames = new List<string>
            {
                sharedFileName,
                $"{Path.GetFileNameWithoutExtension(sharedFileName)}.{hostingContext.HostingEnvironment.EnvironmentName}{Path.GetExtension(sharedFileName)}"
            };

            var parentDir = Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory);

            if (parentDir == null)
                return;

            var index = 0;

            foreach (var fileName in fileNames)
            {
                var filePathRun = Path.Combine(parentDir.FullName, fileName);
                var filePathPublish = Path.Combine(hostingContext.HostingEnvironment.ContentRootPath, fileName);
                var jsonConfig = new JsonConfigurationSource
                {
                    Optional = true,
                    ReloadOnChange = true
                };

                if (File.Exists(filePathRun))
                    jsonConfig.Path = filePathRun;
                else if (File.Exists(filePathPublish))
                    jsonConfig.Path = filePathPublish;
                else
                    continue;

                jsonConfig.ResolveFileProvider();

                config.Sources.Insert(index++, jsonConfig);
            }
        });

        return builder;
    }
}