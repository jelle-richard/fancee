using Fs.MessageBus.Subscribers;
using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;

namespace SocialListeningCore.MessageBus.Subscribers;

public class RequestTicketingDataSubscriber(IConnection connection) : RabbitMessageSubscriber<IRequestTicketingDataMessage>(connection, Config)
{
    private static readonly RabbitOptions Config = new()
    {
        Exchange = RabbitConfig.Exchanges.Default,
        RoutingKey = RabbitConfig.RoutingKeys.RequestTicketingData,
        QueueOptions = new() { Name = RabbitConfig.Queues.RequestTicketingData }
    };
}