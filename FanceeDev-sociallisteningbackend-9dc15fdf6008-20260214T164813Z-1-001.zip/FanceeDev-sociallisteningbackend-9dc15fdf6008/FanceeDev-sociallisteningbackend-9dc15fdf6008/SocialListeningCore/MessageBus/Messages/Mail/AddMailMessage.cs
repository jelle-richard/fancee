using Fs.MessageBus.Models;

namespace SocialListeningCore.MessageBus.Messages.Mail;

public class AddMailMessage : IMessage, IExternalMessage
{
    public required Dtos.MailProvider.Mail Mail { get; set; }
}