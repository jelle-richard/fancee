using Fs.MessageBus.Models;
using SocialListeningCore.Dtos.Enums;

namespace SocialListeningCore.MessageBus.Messages.DataSynchronisation;

public interface IRequestTicketingDataMessage : IMessage, IExternalMessage
{
    public TicketingDataType Type { get; }
    public SynchronisationType SyncType { get; set; }
    public DateTime? RequestCreatedFrom { get; set; }
    public IList<Guid> RequestUpdateFor { get; set; }
    public string SerializedUpdatedData { get; set; }
    public string SerializedCreatedData { get; set; }
}