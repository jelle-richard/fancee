using SocialListeningCore.Dtos.Enums;

namespace SocialListeningCore.MessageBus.Messages.DataSynchronisation;

public class RequestTicketingUserDataMessage : IRequestTicketingDataMessage
{
    public TicketingDataType Type => TicketingDataType.Clients;
    public SynchronisationType SyncType { get; set; }
    public DateTime? RequestCreatedFrom { get; set; }
    public IList<Guid> RequestUpdateFor { get; set; } = [];
    public string SerializedUpdatedData { get; set; } = string.Empty;
    public string SerializedCreatedData { get; set; } = string.Empty;
}