using Fs.MessageBus.Publishers;
using Fs.MessageBus.Utils.Rabbit;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;
using IConnection = RabbitMQ.Client.IConnection;

namespace SocialListeningCore.MessageBus.Publishers;

public class RequestTicketingDataPublisher : RabbitMessagePublisher<IRequestTicketingDataMessage>
{
    private static readonly RabbitOptions Config = new()
    {
        Exchange = RabbitConfig.Exchanges.Default,
        RoutingKey = RabbitConfig.RoutingKeys.RequestTicketingData,
        QueueOptions = new() { Name = RabbitConfig.Queues.RequestTicketingData }
    };

    public RequestTicketingDataPublisher(IConnection connection) : base(connection, Config)
    {
        ConfigureRpc();
    }
}