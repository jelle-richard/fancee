using Fs.MessageBus.Publishers;
using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;
using SocialListeningCore.MessageBus.Messages.Mail;

namespace SocialListeningCore.MessageBus.Publishers;

public class AddMailPublisher(IConnection connection) : RabbitMessagePublisher<AddMailMessage>(connection, Config)
{
    private static readonly RabbitOptions Config = new()
    {
        Exchange = RabbitConfig.Exchanges.Default,
        RoutingKey = RabbitConfig.RoutingKeys.AddMail,
        QueueOptions = new() { Name = RabbitConfig.Queues.AddMail }
    };
}