using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Utils.Extensions;

namespace SocialListeningCore.Helpers;

public static class SubscriptionHelper
{
    public static Subscription ToSubscription(this CreateSubscriptionRequest create)
    {
        Subscription subscription = new()
        {
            ChannelId = create.ChannelId,
            Input = new()
            {
                DsId = create.SubscriptionType.ToChannelType().ToDSID(),
                DateRangeType = create.SubscriptionType.ToDefaultDateRangeType(),
                MaxRows = 10000
            },
            SubscriptionType = create.SubscriptionType,
            Cron = create.Cron,
            RunOnce = false
        };
        if (create.Query.Count(c => c == '|') == 1)
        {
            var fields = create.Query.Split('|');
            subscription.Input.DsAccounts = fields[0];
            subscription.Input.DsUser = fields[1];
        }
        else
            subscription.Input.DsAccounts = create.Query;

        return subscription;
    }
}