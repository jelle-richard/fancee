using Microsoft.AspNetCore.Http;
using UAParser;

namespace SocialListeningCore.Helpers;

public static class UserAgentHelper
{
    /// <summary>
    /// Gets device info from the User-Agent header.
    /// </summary>
    /// <param name="headers"></param>
    /// <returns></returns>
    public static string? GetDeviceFromHeaders(IHeaderDictionary? headers)
    {
        if (!(headers?.ContainsKey("User-Agent") ?? false))
            return null;

        var userAgent = headers.UserAgent.ToString();
        var parts = new List<string>();

        var info = Parser.GetDefault().Parse(userAgent);

        if (!string.IsNullOrEmpty(info.Device?.Model))
            parts.Add($"{info.Device.Model},");

        parts.Add(info.UA.ToString());

        if (string.IsNullOrEmpty(info.OS.Family) || info.OS.Family == "Other")
            return string.Join(' ', parts);

        var version = string.Empty;
        if (!string.IsNullOrEmpty(info.OS.Major))
            version = $" {info.OS.Major}";

        parts.Add($"({info.OS.Family}{version})");

        return string.Join(' ', parts);
    }
}