using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Bson;
using MongoDB.Driver;

namespace SocialListeningCore.Helpers;

public static class EntryHelper
{
    private static readonly string _dateFieldName = "query.date";

    public static FilterDefinition<TEntry> GetLookupDefinition<TEntry>(string? subscriptionId, DateTime? startDate = null, DateTime? endDate = null) where TEntry : Entry
    {
        var builder = Builders<TEntry>.Filter;
        var filters = new List<FilterDefinition<TEntry>>
        {
            builder.Eq(dbItem => dbItem.SubscriptionId, subscriptionId),
            builder.Ne(_dateFieldName, BsonNull.Value)
        };

        if (startDate != null)
            filters.Add(builder.Gte(_dateFieldName, startDate));
        if (endDate != null)
            filters.Add(builder.Lte(_dateFieldName, endDate));

        return builder.And(filters);
    }

    public static SortDefinition<TEntry> GetSortDefinition<TEntry>(bool descending = true) where TEntry : Entry
    {
        var builder = Builders<TEntry>.Sort;
        return descending ? builder.Descending(_dateFieldName) : builder.Ascending(_dateFieldName);
    }
}