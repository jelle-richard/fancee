using System.Dynamic;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Logging;
using SocialListeningCore.Persistence.Entries;

namespace SocialListeningCore.Helpers;

public static class ConnectionHelper
{
    public static async Task<Connection> TransformDataAsync(this Connection connection, IGenericEntriesDao genericEntriesDao, string? collectionId, bool isBulkReplace, ILogger logger)
    {
        var fields = connection.Meta!.query.fields;
        var data = connection.Data!;

        List<Task> tasks = [];
        List<GenericEntry> entries = [];

        // WARNING: Skip first entry, it's the list of column id/names.
        for (var i = 1; i < data.Count; i++)
        {
            ExpandoObject? newDataItem = new();
            var objectIsValid = true;
            for (var j = 0; j < fields.Count; j++)
            {
                string? fieldName = fields[j].field_id;
                object? newValue = Field.Transform(fields[j].data_type, data[i][j], out bool fieldIsValid);
                objectIsValid &= fieldIsValid;
                newDataItem.TryAdd(fieldName, newValue);
            }

            if (!objectIsValid)
            {
                logger.MongoLogWarning(connection.UserId, "Parser error in field transformer", new
                {
                    subscriptionType = connection.SubscriptionType.ToString(),
                    subscriptionId = connection.SubscriptionId,
                    entry = newDataItem
                });
                continue;
            }

            GenericEntry entry = new(connection.SubscriptionType)
            {
                SubscriptionId = connection.SubscriptionId,
                Data = newDataItem,
                Query = ConnectionDataHelper.EnrichData(newDataItem, connection.SubscriptionType)
            };

            if (isBulkReplace)
            {
                entries.Add(entry);
                if (entries.Count <= 100)
                    continue;
                await genericEntriesDao.ReplaceListAsync(entries.ToList(), collectionId);
                entries = [];
            }
            else
            {
                tasks.Add(genericEntriesDao.UpdateAsync(entry, genericEntriesDao.GetFilterDefinition(entry),
                    collectionId, true));
            }
        }

        if (entries.Count > 0)
            await genericEntriesDao.ReplaceListAsync(entries.ToList(), collectionId);

        await Task.WhenAll(tasks);

        connection.Data = null;

        return connection;
    }

    public static IEnumerable<Field> FieldsToList(List<dynamic> fields)
    {
        List<Field> result = [];
        foreach (var field in fields)
        {
            result.Add(new()
            {
                Field_id = field.field_id,
                Field_name = field.field_name,
                Field_type = field.data_type
            });
        }

        return result;
    }
}