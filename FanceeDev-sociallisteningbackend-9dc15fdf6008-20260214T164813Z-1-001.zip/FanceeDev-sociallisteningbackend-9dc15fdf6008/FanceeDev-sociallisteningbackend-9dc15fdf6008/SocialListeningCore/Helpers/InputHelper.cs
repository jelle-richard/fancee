using System.Dynamic;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Utils.Extensions;

namespace SocialListeningCore.Helpers;

public static class InputHelper
{
    public static Input MockData(ChannelType channelType) => new()
    {
        DsId = channelType.ToDSID(),
        DateRangeType = "last_2_days_inc",
        MaxRows = 1000
    };

    public static FilterDefinition<GenericEntry> ToFilterDefinition(this SubscriptionType subscriptionType, GenericEntry model, FilterDefinitionBuilder<GenericEntry> builder)
    {
        var filterStrings = subscriptionType.ToFiltersAsString().Split(",");

        var filter = builder.And(builder.Eq(dbItem => dbItem.SubscriptionId, model.SubscriptionId));

        foreach (var filterString in filterStrings)
            filter &= builder.Eq($"data.{filterString}", ((IDictionary<string, object>)model.Data!)[filterString]);

        return filter;
    }

    public static dynamic MockDataProperties(this SubscriptionType subscriptionType)
    {
        dynamic data = new ExpandoObject();

        var filterStrings = subscriptionType.ToFiltersAsString().Split(",");

        foreach (var filterString in filterStrings)
        {
            if (filterString.ToLower() == "date")
                ((IDictionary<string, object>)data)[filterString] = DateTime.UtcNow;
            else if (filterString == "post_ID")
                ((IDictionary<string, object>)data)[filterString] = int.MinValue;
            else
                ((IDictionary<string, object>)data)[filterString] = string.Empty;
        }

        return data;
    }

    public static Input ToInput(this ChannelType channelType) => MockData(channelType);

    public static Input ToInput(this SubscriptionType subscriptionType) => subscriptionType.ToChannelType().ToInput();

    public static string ToFiltersAsString(this SubscriptionType subscriptionType) => subscriptionType switch
    {
        SubscriptionType.FA_CAMPAIGN => "profileID,adcampaign_id,Date",
        SubscriptionType.FA_ADS => "profileID,ad_id,adcampaign_id,promoted_post_id,Date",
        SubscriptionType.FA_GEO => "profileID,ad_id,adcampaign_id,Country,Region,Date",
        SubscriptionType.FA_VIDEO => "profileID,ad_id,adcampaign_id,video_asset_id,video_asset_video_id,Date",
        SubscriptionType.FA_CONVERSION => "profileID,ad_id,adcampaign_id,platform_position,publisher_platform,Date",
        SubscriptionType.FA_AGE_AND_GENDER => "profileID,ad_id,Age,Gender,Date",
        SubscriptionType.FB => "profileid,Date",
        SubscriptionType.FB_POSTS => "post_ID",
        SubscriptionType.FB_GEO_LIKES => "profileid,Date,country",
        SubscriptionType.FB_AGE_AND_GENDER => "profileid,Date,gender,age",
        SubscriptionType.FBPD_PAGE => "username,today",
        SubscriptionType.FBPD_POSTS => "post_id,updated_time",
        SubscriptionType.FBPD_URL_SHARES => "og_object_id,today",
        SubscriptionType.GT => "date,search_term",
        SubscriptionType.GAWA => "date",
        SubscriptionType.GAWA_PUBLISHING => "date,language,deviceCategory,platform,propertyName,sessionMedium,sessionSource",
        SubscriptionType.GAWA_DEVICE => "date,deviceCategory,language,platform,propertyName,streamName",
        SubscriptionType.GAWA_ENGAGEMENT => "date,contentGroup,eventName,hostName,propertyName,streamName,unifiedScreenClass",
        SubscriptionType.GAWA_ECOM_ITEMS => "date,itemCategory,itemName,propertyID",
        SubscriptionType.GAWA_USER_ACQUISITION => "firstUserCampaignId,firstUserCampaignName,firstUserCreativeId,firstUserGoogleAdsAdGroupId,firstUserGoogleAdsAdGroupName,firstUserGoogleAdsAdNetworkType,firstUserMedium,date",
        SubscriptionType.GAWA_TRAFFIC_ACQUISITION => "sessionCampaignName,sessionDefaultChannelGrouping,sessionGoogleAdsAdGroupName,sessionGoogleAdsAdNetworkType,sessionGoogleAdsKeyword,sessionMedium,sessionSource,date",
        SubscriptionType.IGI or SubscriptionType.IGI_PROFILE_DATA => "account_id,date",
        SubscriptionType.IGI_MEDIA => "media_id",
        SubscriptionType.IGI_CITY => "account_id,audience_city_only_dim,today",
        SubscriptionType.IGI_COUNTRY => "account_id,audience_country_dim,today",
        SubscriptionType.IGI_AGE_AND_GENDER => "account_id,audience_age,audience_gender,today",
        SubscriptionType.IGPD2_PROFILES => "ig_id,today",
        SubscriptionType.IGPD2_HASHTAGS => "post_id,today",
        SubscriptionType.IGPD2_POSTS => "post_id,today",
        SubscriptionType.GA_TRAFFIC => "adContent,Campaign,channelGrouping,fullReferrer,Keyword,medium,profileID,Date",
        SubscriptionType.GA_PAID_TRAFFIC => "adContent,adGroup,adMatchedQuery,adMatchType,adwordsAdGroupId,adwordsCampaignId,adwordsCreativeId,Campaign,profileID,Date",
        SubscriptionType.GA_CONTENT => "ExitPagePath,LandingPagePath,NextPagePath,PagePath,PageTitle,PreviousPagePath,profileID,Date",
        SubscriptionType.GA_TECHNOLOGY => "Browser,BrowserVersion,deviceCategory,Hostname,OperatingSystem,OperatingSystemVersion,ScreenResolution,profileID,Date",
        SubscriptionType.GA_USER => "City,Continent,Country,Language,RegionIsoCode,profileID,Date",
        SubscriptionType.GA_ECOMMERCE => "productBrand,productCategoryHierarchy,productListName,productListPosition,ProductName,ProductSku,profileID,Date",
        SubscriptionType.GA_SOCIAL => "hasSocialSourceReferral,socialActivityContentUrl,socialEngagementType,socialInteractionNetwork,socialInteractionNetworkAction,socialInteractionTarget,socialNetwork,profileID,Date",
        SubscriptionType.GA_SEARCH => "SearchDestinationPage,SearchKeyword,SearchStartPage,profileID,Date",
        SubscriptionType.GA_EVENTS => "EventLabel,EventCategory,EventAction,profileID,Date",
        SubscriptionType.YT_VIDEO => "profileID,Date,account",
        SubscriptionType.YT2_CHANNEL => "channel,today",
        SubscriptionType.YT2_AD_PERFORMANCE or SubscriptionType.YT2_TRAFFIC_SOURCE => "channel,date",
        SubscriptionType.YT2_DEMOGRAPHIC => "channel,ageGroup,gender,today",
        SubscriptionType.YT2_DEVICE => "channel,date,deviceType,operatingSystem",
        SubscriptionType.YT2_GEO => "channel,country,today",
        SubscriptionType.YT2_VIDEO => "channel,video,date",
        SubscriptionType.LIP_PAGE => "profileID,today",
        SubscriptionType.LIP_POST => "update_id,update_source_share_id,date",
        SubscriptionType.LIP_COUNTRY => "profileID,follower_country,today",
        SubscriptionType.AW_CAMPAIGN => "profileID,CampaignID,Date",
        SubscriptionType.AW_AD => "profileID,CampaignID,Date,AdID,Network",
        SubscriptionType.AW_KEYWORD => "profileID,AdgroupID,KeywordID,Date",
        SubscriptionType.AW_PLACEMENT => "profileID,CampaignID,Date",
        SubscriptionType.AW_CONVERSION => "profileID,CampaignID,Date,ConversionTrackerId,ExternalConversionSource",
        SubscriptionType.AW_SEARCH_QUERY => "profileID,CampaignID,Date,KeywordID,QueryTargetingStatus,Searchterm",
        SubscriptionType.AW_SHOPPING => "profileID,StoreId,OfferId,CampaignID,MerchantId",
        SubscriptionType.AW_GEO => "profileID,CampaignID,Date,Countryname,Region,City,Metroarea",
        SubscriptionType.AW_AGE => "profileID,CampaignID,Date,Age",
        SubscriptionType.AW_GENDER => "profileID,CampaignID,Date,Gender",
        SubscriptionType.TIKBA_PROFILE => "profile__username,profile__date",
        SubscriptionType.TIKBA_VIDEO => "videos__video_id",
        SubscriptionType.TIKBA_COUNTRY => "territories__username,territories__country,today",
        SubscriptionType.TIKBA_GENDER => "gender__username,gender__gender,today",
        _ => throw new SubscriptionTypeNotSupportedException(subscriptionType)
    };
}