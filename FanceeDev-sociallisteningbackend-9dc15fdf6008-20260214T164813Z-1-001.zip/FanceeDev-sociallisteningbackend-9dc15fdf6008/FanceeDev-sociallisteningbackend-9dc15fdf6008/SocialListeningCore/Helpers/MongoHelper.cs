using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;

namespace SocialListeningCore.Helpers;

public static class MongoHelper
{
    public static BsonDocument RenderToBsonDocument<T>(this FilterDefinition<T> filter)
    {
        var serializerRegistry = BsonSerializer.SerializerRegistry;
        var documentSerializer = serializerRegistry.GetSerializer<T>();
        return filter.Render(documentSerializer, serializerRegistry);
    }

    public static BsonDocument RenderToBsonDocument<T>(this SortDefinition<T> sort)
    {
        var serializerRegistry = BsonSerializer.SerializerRegistry;
        var documentSerializer = serializerRegistry.GetSerializer<T>();
        return sort.Render(documentSerializer, serializerRegistry);
    }

    public static BsonDocument PipelineStage(string id, IEnumerable<BsonElement> bsonElements) => new(id, new BsonDocument(bsonElements));

    public static BsonDocument PipelineStage(string id, BsonValue element) => new(id, element);

    public static BsonDocument SortStage(string id = "query.date", int direction = 1)
    {
        return PipelineStage("$sort", new BsonElement[]
        {
            new(id, direction)
        });
    }

    public static BsonDocument UnwindStage(string fieldName, bool preserveNullAndEmptyArrays = false)
    {
        return PipelineStage("$unwind", new BsonElement[]
        {
            new("path", fieldName),
            new("preserveNullAndEmptyArrays", preserveNullAndEmptyArrays)
        });
    }

    public static BsonDocument LimitStage(int limit) => PipelineStage("$limit", limit);

    public static BsonDocument SkipStage(int skip) => PipelineStage("$skip", skip);

    public static BsonDocument LookupStage(string from, string localField, string foreignField, string fieldAs)
    {
        return PipelineStage("$lookup", new BsonElement[]
        {
            new("from", from),
            new("localField", localField),
            new("foreignField", foreignField),
            new("as", fieldAs)
        });
    }

    public static BsonDocument GroupStage(IEnumerable<BsonElement> bsonElements) => PipelineStage("$group", bsonElements);

    public static BsonDocument DefaultGroupStage(IEnumerable<BsonElement> bsonElements) => DefaultGroupStage(BsonNull.Value, bsonElements);

    public static BsonDocument DefaultGroupStage(BsonValue? id = null, IEnumerable<BsonElement>? bsonElements = null)
    {
        var groupList = new BsonElement[]
        {
            new("_id", id ?? BsonNull.Value),
            new("first", new BsonDocument("$first", "$$ROOT")),
            new("last", new BsonDocument("$last", "$$ROOT"))
        }.ToList();

        if (bsonElements != null)
            groupList.AddRange(bsonElements);

        return PipelineStage("$group", groupList);
    }

    public static BsonDocument ProjectStage(IEnumerable<BsonElement> bsonElements) => PipelineStage("$project", bsonElements);

    public static BsonDocument GenericMatchStage(IEnumerable<BsonElement> matches) => PipelineStage("$match", matches);

    public static BsonDocument MatchStage(string? subscriptionId, DateTime? startDate, DateTime? endDate, IEnumerable<BsonElement>? extraMatches = null)
    {
        var matchList = new List<BsonElement>
        {
            new("subscription_id", ObjectId.Parse(subscriptionId))
        };

        if (startDate != null || endDate != null)
        {
            var dateMatch = new BsonDocument();
            if (startDate != null)
                dateMatch.Add(new BsonElement("$gte", startDate));

            if (endDate != null)
                dateMatch.Add(new BsonElement("$lt", endDate));

            matchList.Add(new("query.date", dateMatch));
        }

        if (extraMatches != null)
            matchList.AddRange(extraMatches);

        return PipelineStage("$match", matchList);
    }

    public static IEnumerable<BsonDocument> PaginationStages(BsonDocument matchStage, int limit, int offset, BsonDocument? sortStage = null, IEnumerable<BsonDocument>? projectStages = null)
    {
        var data = new List<BsonDocument>
        {
            SkipStage(offset),
            LimitStage(limit)
        };

        if (sortStage != null)
            data.Insert(0, new("$sort", sortStage));

        if (projectStages != null)
            data.AddRange(projectStages);

        var facetDocument = new List<BsonElement>
        {
            new("Items", new BsonArray(data)),
            new("TotalItems", new BsonArray(new[]
            {
                PipelineStage("$count", "count")
            }))
        };

        return new[]
        {
            new BsonDocument("$match", matchStage),
            new BsonDocument("$facet", new BsonDocument(facetDocument)),
            UnwindStage("$TotalItems", true),
            ProjectStage(new BsonElement[]
            {
                new("Items", "$Items"),
                new("TotalItems", new BsonDocument("$ifNull", new BsonArray(new BsonValue[] { "$TotalItems.count", 0 })))
            })
        };
    }
}