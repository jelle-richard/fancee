using Cronos;
using CronScheduler.Extensions.Internal;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SubscriptionService.Controllers;
using SubscriptionService.Dtos.Requests.Subscriptions;
using SubscriptionService.Dtos.Responses;
using SubscriptionService.Exceptions;
using SubscriptionService.Jobs;
using SubscriptionService.Services.Subscriptions;
using SubscriptionNotFoundException = SocialListeningCore.Exceptions.SubscriptionNotFoundException;

namespace SubscriptionService.Tests.Controllers;

public class SubscriptionsControllerTests
{
    private static readonly string InvalidId = "Ïnvalid Id";
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    private readonly SubscriptionsController _sut;
    private readonly Mock<ISubscriptionsService> _mockedSubscriptionService = new();
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ILogger<SubscriptionRunnerJob>> _logger = new();

    public SubscriptionsControllerTests()
    {
        _sut = new(_mockedSubscriptionService.Object);
    }

    [Fact]
    public async Task TestThatSingleReturnsSubscriptionWhenFound()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedSubscriptionService.Setup(ss => ss.GetAsync(SubscriptionId))
            .ReturnsAsync(subscription);

        var actual = await _sut.Single(SubscriptionId);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<Subscription>>(actualResult.Value);

        Assert.NotNull(response.Data);
        Assert.Null(response.Errors);

        Assert.IsType<Subscription>(response.Data);

        var actualSubscription = response.Data!;

        Assert.Equal(subscription.Input, actualSubscription.Input);
        Assert.Equal(subscription.Id, actualSubscription.Id);
        Assert.Equal(subscription.Name, actualSubscription.Name);
    }

    [Fact]
    public async Task TestThatSingleThrowsSubscriptionNotFoundExceptionWhenSubscriptionNotFound()
    {
        _mockedSubscriptionService.Setup(ss => ss.GetAsync(SubscriptionId))
            .ThrowsAsync(new SubscriptionNotFoundException());

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.Single(SubscriptionId));
    }

    [Fact]
    public async Task TestThatSingleThrowsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.Single(InvalidId));
    }

    [Fact]
    public async Task TestThatStartSingleThrowsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.StartSingle(InvalidId));
    }

    [Fact]
    public async Task TestThatUpdateThrowsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () =>
            await _sut.Update(InvalidId, new()));
    }

    [Fact]
    public async Task TestThatUpdateThrowsInvalidObjectIdExceptionWhenSubscriptionIsNull()
    {
        UpdateSubscriptionRequest update = new() { Cron = "* * * * *" };
        _mockedSubscriptionService.Setup(ss => ss.UpdateAsync(SubscriptionId, update))
            .ThrowsAsync(new InvalidObjectIdException());

        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.Update(SubscriptionId, update));
    }

    [Fact]
    public async Task TestThatCreateReturnsSubscriptionWhenInputIsValid()
    {
        var validCron = "* * * * *";
        CreateSubscriptionRequest create = new()
        {
            Cron = validCron,
            Query = "test",
            RequestHistory = true,
            SubscriptionType = SubscriptionType.FB_POSTS
        };

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Active = true,
            Cron = validCron,
            Input = SubscriptionType.FB_POSTS.ToInput(),
            SubscriptionType = SubscriptionType.FB_POSTS,
            RunOnce = false
        };

        _mockedSubscriptionService.Setup(ss => ss.CreateAsync(create))
            .ReturnsAsync(subscription);
        _mockedSubscriptionService.Setup(ss => ss.AddOrUpdateSubscriptionSchedule(subscription))
            .Returns(new SubscriptionCronJob
            {
                Subscription = subscription,
                IsRunning = true
            });

        var actual = await _sut.Create(create);

        var actualResult = Assert.IsType<CreatedResult>(actual.Result);

        Assert.Equal($"/{subscription.Id}", actualResult.Location);

        var response = Assert.IsType<ApiResponse<Subscription>>(actualResult.Value);

        Assert.NotNull(response.Data);
        Assert.Null(response.Errors);

        Assert.IsType<Subscription>(response.Data);

        var actualSubscription = response.Data!;

        Assert.Equal(subscription, actualSubscription);
        Assert.True(actualSubscription.Active);
    }

    [Fact]
    public async Task TestThatCreateThrowsInvalidCronExceptionWhenCronIsInvalid()
    {
        CreateSubscriptionRequest create = new()
        {
            Cron = "invalidCron",
            Query = "test",
            RequestHistory = false,
            SubscriptionType = SubscriptionType.GT
        };

        await Assert.ThrowsAsync<InvalidCronException>(async () => await _sut.Create(create));
    }

    [Fact]
    public async Task TestThatCreateThrowsInvalidCronExceptionWhenQueryIsInvalid()
    {
        CreateSubscriptionRequest create = new()
        {
            Cron = "* * * * *",
            RequestHistory = false,
            SubscriptionType = SubscriptionType.GT
        };

        await Assert.ThrowsAsync<InvalidCronException>(async () => await _sut.Create(create));
    }

    [Fact]
    public async Task List_ShouldReturnListOfModels_WhenSuccessfulTestThatListReturnsListOfSubscriptionsWhenSuccessful()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            RunOnce = false
        };

        Subscription[] list = [subscription, subscription];

        _mockedSubscriptionService.Setup(ss => ss.ToListAsync())
            .ReturnsAsync(list);

        var actual = await _sut.GetAllSubscriptionsUnderChannel();
        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        Assert.Equal(StatusCodes.Status200OK, actualResult.StatusCode);

        var response = Assert.IsType<ApiResponse<IEnumerable<Subscription>>>(actualResult.Value);

        Assert.NotNull(response.Data);
        Assert.Equal(list, response.Data);
    }

    [Fact]
    public async Task TestThatStartAllReturnsListOfSubscriptionCronJobWhenSuccessful()
    {
        _mockedSubscriptionService.Setup(ss => ss.StartAllAsync())
            .ReturnsAsync(new List<SubscriptionCronJob>());

        var actual = await _sut.StartAllCronJobs();
        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        Assert.Equal(StatusCodes.Status200OK, actualResult.StatusCode);

        var response = Assert.IsType<ApiResponse<IEnumerable<SubscriptionCronJob>>>(actualResult.Value);
        var responseData = Assert.IsAssignableFrom<IEnumerable<SubscriptionCronJob>>(response.Data);
    }

    [Fact]
    public async Task TestThatStopAllReturnsListOfSubscriptionCronJobWhenSuccessful()
    {
        _mockedSubscriptionService.Setup(ss => ss.StopAllAsync())
            .ReturnsAsync(new List<SubscriptionCronJob> { new() { IsRunning = true } });

        var actual = await _sut.StopAllCronJobs();
        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        Assert.Equal(StatusCodes.Status200OK, actualResult.StatusCode);

        var response = Assert.IsType<ApiResponse<IEnumerable<SubscriptionCronJob>>>(actualResult.Value);
        var responseData = Assert.IsAssignableFrom<IEnumerable<SubscriptionCronJob>>(response.Data);

        foreach (var item in responseData)
            Assert.True(item.IsRunning);
    }

    [Fact]
    public async Task TestThatStartSingleReturnsSubscriptionCronJobWhenSuccessful()
    {
        _mockedSubscriptionService.Setup(ss => ss.StartByIdAsync(SubscriptionId))
            .ReturnsAsync(new SubscriptionCronJob { IsRunning = true });

        var actual = await _sut.StartSingle(SubscriptionId);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        Assert.Equal(StatusCodes.Status200OK, actualResult.StatusCode);

        var response = Assert.IsType<ApiResponse<SubscriptionCronJob>>(actualResult.Value);

        Assert.Null(response.Errors);

        var startedResult = Assert.IsType<SubscriptionCronJob>(response.Data);
        Assert.True(startedResult.IsRunning);
    }

    [Fact]
    public void TestThatListOfCronWorksSuccessful()
    {
        var cronExpression = CronExpression.Parse("* * * * *");
        var cronJob = new SubscriptionRunnerJob(_mockedServiceProvider.Object, new(), new(), _logger.Object);

        _mockedSubscriptionService.Setup(ss => ss.ListAllAsync())
            .Returns(new[] { new SchedulerTaskWrapper(cronExpression, cronJob, DateTimeOffset.Now, TimeZoneInfo.Local) });

        var actual = _sut.ListAllCronJobs();

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        Assert.Equal(StatusCodes.Status200OK, actualResult.StatusCode);

        var response = Assert.IsType<ApiResponse<IEnumerable<SchedulerTaskWrapper>>>(actualResult.Value);

        Assert.Null(response.Errors);

        var startedResult = Assert.IsAssignableFrom<IEnumerable<SchedulerTaskWrapper>>(response.Data);
    }
    
    [Fact]
    public async Task TestThatStopSingleReturnsSubscriptionCronJobWhenSuccessful()
    {
        _mockedSubscriptionService.Setup(ss => ss.StopByIdAsync(SubscriptionId))
            .ReturnsAsync(new SubscriptionCronJob { IsRunning = true });

        var actual = await _sut.StopSingle(SubscriptionId);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);

        Assert.Equal(StatusCodes.Status200OK, actualResult.StatusCode);

        var response = Assert.IsType<ApiResponse<SubscriptionCronJob>>(actualResult.Value);

        Assert.Null(response.Errors);

        var startedResult = Assert.IsType<SubscriptionCronJob>(response.Data);
        Assert.True(startedResult.IsRunning);
    }

    [Fact]
    public async Task TestThatStopSingleThrowsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.StopSingle(InvalidId));
    }

    [Fact]
    public async Task TestThatUpdateReturnsUpdatedSubscriptionWhenInputIsValid()
    {
        UpdateSubscriptionRequest update = new() { Cron = "* * * * 5" };
        Subscription subscription = new();

        _mockedSubscriptionService.Setup(ss => ss.UpdateAsync(SubscriptionId, update))
            .ReturnsAsync(subscription);

        var actual = await _sut.Update(SubscriptionId, update);
        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<Subscription>>(actualResult.Value);

        Assert.NotNull(response.Data);
        Assert.Null(response.Errors);

        var responseData = Assert.IsType<Subscription>(response.Data);

        Assert.Equal(subscription, responseData);
    }

    [Fact]
    public async Task TestThatUpdateThrowsInvalidCronExceptionWhenCronIsInvalid()
    {
        UpdateSubscriptionRequest update = new() { Cron = "invalidCron" };

        await Assert.ThrowsAsync<InvalidCronException>(async () => await _sut.Update(SubscriptionId, update));
    }

    [Fact]
    public async Task TestThatDeleteReturnsTrueWhenInputIsValid()
    {
        _mockedSubscriptionService.Setup(ss => ss.DeleteByIdAsync(SubscriptionId))
            .ReturnsAsync(true);

        var actual = await _sut.Delete(SubscriptionId);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<bool>>(actualResult.Value);

        var data = Assert.IsType<bool>(response.Data);

        Assert.True(data);
    }

    [Fact]
    public async Task TestThatDeleteReturnsFalseWhenInputIsInvalid()
    {
        _mockedSubscriptionService.Setup(ss => ss.DeleteByIdAsync(SubscriptionId))
            .ReturnsAsync(false);

        var actual = await _sut.Delete(SubscriptionId);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<bool>>(actualResult.Value);

        var data = Assert.IsType<bool>(response.Data);

        Assert.False(data);
    }

    [Fact]
    public async Task TestThatDeleteShouldThrowsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.Delete(InvalidId));
    }

    [Fact]
    public async Task TestThatEntriesBetweenDatesBySubscriptionIdReturnsListOfModelsWhenInputIsValid()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedSubscriptionService.Setup(ss => ss.GetAsync(SubscriptionId))
            .ReturnsAsync(subscription);

        var entries = new[]
        {
            new EntryResponse(SubscriptionType.FBPD_PAGE),
            new EntryResponse(SubscriptionType.FBPD_PAGE),
            new EntryResponse(SubscriptionType.FBPD_PAGE)
        };

        _mockedSubscriptionService.Setup(ss => ss.EntriesAsync(subscription, It.IsAny<DateTime>(), It.IsAny<DateTime>(), DateRange.DAILY))
            .ReturnsAsync(entries);

        var actual = await _sut.EntriesBetweenDatesBySubscriptionId(SubscriptionId, DateTime.MinValue, DateTime.MaxValue);
        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<IEnumerable<EntryResponse>>>(actualResult.Value);

        Assert.NotNull(response.Data);
        Assert.Equal(entries, response.Data);
    }

    [Fact]
    public async Task TestThatEntriesBetweenDatesBySubscriptionIdThrowsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () =>
            await _sut.EntriesBetweenDatesBySubscriptionId(InvalidId, DateTime.MinValue, DateTime.MaxValue));
    }

    [Fact]
    public async Task TestThatRunNewHistorySubscriptionByIdReturnsSubscriptionCronJobWhenInputIsValid()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedSubscriptionService.Setup(ss => ss.GetAsync(SubscriptionId))
            .ReturnsAsync(subscription);
        _mockedSubscriptionService.Setup(ss => ss.AddOrUpdateSubscriptionSchedule(It.IsAny<Subscription>()))
            .Returns(new SubscriptionCronJob { Subscription = subscription, IsRunning = true });

        var actual = await _sut.RunNewHistorySubscriptionById(SubscriptionId);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<SubscriptionCronJob>>(actualResult.Value);

        var data = Assert.IsType<SubscriptionCronJob>(response.Data);

        Assert.True(data.IsRunning);
    }

    [Fact]
    public async Task TestThatRefreshSubscriptionsByChannelIdWorks()
    {
        var subscriptions = new List<Subscription>
        {
            new()
            {
                Id = "subscription_1",
                Cron = "* * * * *",
                Input = SubscriptionType.FB.ToInput()
            },
            new()
            {
                Id = "subscription_2",
                Cron = "* * * * *",
                Input = SubscriptionType.FB_POSTS.ToInput()
            }
        };

        _mockedSubscriptionService.Setup(cs => cs.ToListByChannelIdAsync(It.IsAny<string>()))
            .ReturnsAsync(subscriptions);

        foreach (var subscription in subscriptions)
        {
            _mockedSubscriptionService.Setup(ss => ss.AddOrUpdateSubscriptionSchedule(subscription))
                .Returns(new SubscriptionCronJob { Subscription = subscription, IsRunning = true });
        }

        var actual = await _sut.RefreshSuscriptionsByChannelId("ChannelId");

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<IEnumerable<SubscriptionCronJob>>>(actualResult.Value);

        var data = Assert.IsAssignableFrom<IEnumerable<SubscriptionCronJob>>(response.Data);

        Assert.NotEmpty(data);
    }

    [Fact]
    public async Task TestThatRunNewHistorySubscriptionByIdReturnsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.RunNewHistorySubscriptionById(InvalidId));
    }
}