using System.Security.Claims;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Logging;
using SubscriptionService.Controllers;
using SubscriptionService.Dtos.Requests.Settings;
using SubscriptionService.Exceptions;
using SubscriptionService.Services.Settings;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Controllers;

public class SubscriptionSettingsControllerTests
{
    private static readonly Guid OrganizerUserId = Guid.NewGuid();
    private static readonly User UserOrganizer = new() { FanceeUsersId = OrganizerUserId, UserId = OrganizerUserId, Type = UserType.Organization };
    private static readonly Guid AdminUserId = Guid.NewGuid();
    private static readonly User UserAdmin = new() { FanceeUsersId = AdminUserId, UserId = AdminUserId, Type = UserType.Admin };

    private readonly SubscriptionSettingsController _sut;
    private readonly Mock<ISubscriptionSettingsService> _mockedSubscriptionSettingsService = new();
    private readonly LoggerFactory _factory = new();
    private readonly Mock<IMongoCollection<Log>> _mockedMongoCollection = new();

    public SubscriptionSettingsControllerTests()
    {
        _factory.AddProvider(new MongoLoggerProvider(new(string.Empty, _mockedMongoCollection.MockLogClient().Object)));

        _sut = new(_mockedSubscriptionSettingsService.Object, _factory)
        {
            ControllerContext =
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new(new ClaimsIdentity(new[]
                    {
                        new Claim("user", UserOrganizer.FanceeUsersId.ToString()),
                        new Claim("platformUserId", UserOrganizer.UserId.ToString()),
                        new Claim("type", UserType.Organization.ToString())
                    }))
                }
            }
        };
    }

    [Fact]
    public async Task TestThatUpdateCallsSubscriptionSettingsServiceUpdateSubscriptionSettingAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var request = new UpdateSubscriptionSettingsRequest
        {
            Fields = "test,test1",
            Split = "split,split2"
        };

        _mockedSubscriptionSettingsService.Setup(sss => sss.UpdateSubscriptionSettingAsync(SubscriptionType.FB, request, UserAdmin.FanceeUsersId))
            .ReturnsAsync(new SubscriptionSetting
            {
                SubscriptionName = "Test Update",
                SubscriptionType = SubscriptionType.FB,
                Split = request.Split,
                Fields = request.Fields
            });

        var actual = await _sut.UpdateSubscriptionSetting(SubscriptionType.FB, request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedSubscriptionSettingsService.Verify(os => os.UpdateSubscriptionSettingAsync(SubscriptionType.FB, request, UserAdmin.FanceeUsersId), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatUpdateCallsSubscriptionSettingsServiceUpdateSubscriptionSettingAsyncWhenOrganizer()
    {
        var request = new UpdateSubscriptionSettingsRequest
        {
            Fields = "test,test1",
            Split = "split,split2"
        };

        await Assert.ThrowsAsync<MissingPermissionException>(async () => await _sut.UpdateSubscriptionSetting(SubscriptionType.FB, request));
    }

    [Fact]
    public async Task TestThatDeleteSubscriptionSettingCallsSubscriptionSettingServiceDeleteAsyncWhenOrganizer()
    {
        await Assert.ThrowsAsync<MissingPermissionException>(async () => await _sut.DeleteSubscriptionSetting(SubscriptionType.FB));
    }

    [Fact]
    public async Task TestThatDeleteSubscriptionSettingThrowsExceptionWhenSubscriptionTypeForbiddenToBeDeleted()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        await Assert.ThrowsAsync<SubscriptionTypeForbiddenException>(async () => await _sut.DeleteSubscriptionSetting(SubscriptionType.FB));
    }

    [Fact]
    public async Task TestThatDeleteSubscriptionSettingCallsSubscriptionSettingServiceDeleteAsyncWhenFailed()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        _mockedSubscriptionSettingsService.Setup(sss => sss.DeleteAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<SubscriptionTypeNotFoundException>(async () => await _sut.DeleteSubscriptionSetting(SubscriptionType.FB_POSTS));
    }

    [Fact]
    public async Task TestThatDeleteSubscriptionSettingCallsSubscriptionSettingServiceDeleteAsyncWhenSuccessful()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        _mockedSubscriptionSettingsService.Setup(sss => sss.DeleteAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(true);

        var actual = await _sut.DeleteSubscriptionSetting(SubscriptionType.FB_POSTS);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedSubscriptionSettingsService.Verify(sss => sss.DeleteAsync(It.IsAny<SubscriptionType>()), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }
}