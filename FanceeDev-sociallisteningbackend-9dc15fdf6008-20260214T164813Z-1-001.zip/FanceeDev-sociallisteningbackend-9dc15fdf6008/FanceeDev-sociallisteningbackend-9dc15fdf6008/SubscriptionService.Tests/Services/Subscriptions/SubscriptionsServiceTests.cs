using System.Dynamic;
using System.Net;
using System.Text.Json;
using Cronos;
using CronScheduler.Extensions.Internal;
using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence.Connections;
using SocialListeningCore.Persistence.Entries;
using SubscriptionService.Dtos.Requests.Subscriptions;
using SubscriptionService.Exceptions;
using SubscriptionService.Jobs;
using SubscriptionService.Persistence.Channels;
using SubscriptionService.Persistence.Settings;
using SubscriptionService.Persistence.Subscriptions;
using SubscriptionService.Services.Subscriptions;
using SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;
using SubscriptionService.Utils;
using TestCore.Utils.UnitTestsHelpers;
using SubscriptionNotFoundException = SubscriptionService.Exceptions.SubscriptionNotFoundException;

namespace SubscriptionService.Tests.Services.Subscriptions;

public class SubscriptionsServiceTests
{
    private static JsonSerializerOptions Options => new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    private static readonly string ConnectionId = ObjectId.GenerateNewId().ToString();

    private static readonly Channel ValidNonErrorChannel = new()
    {
        Id = "channelId",
        CreatedOn = default,
        UpdatedOn = default,
        ChannelType = ChannelType.FACEBOOK,
        Status = ChannelStatus.Active,
        HasError = false,
        Name = "Facebook Channel Connection for unit test",
        Request = null,
        RequestDisplayName = null,
        UserId = Guid.NewGuid(),
        Owner = null
    };

    private readonly Mock<ISubscriptionsDao> _mockedSubscriptionsDao = new();
    private readonly Mock<IConnectionsDao> _mockedConnectionsDao = new();
    private readonly Mock<IGenericEntriesDao> _mockedGenericEntriesDao = new();
    private readonly Mock<ISubscriptionSettingsDao> _mockedSubscriptionSettingsDao = new();
    private readonly Mock<ISchedulerRegistration> _mockedSchedulerRegistration = new();
    private readonly Mock<ILoggerFactory> _mockedLoggerFactory = new();
    private readonly Mock<ILogger> _mockedLogger = new();
    private readonly Mock<IHttpClientFactory> _mockedHttpClientFactory = new();
    private readonly Mock<IChannelDao> _mockedChannelDao = new();
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<IServiceScopeFactory> _mockedServiceScopeFactory = new();
    private readonly List<ISuperMetricsHandler> _mockedSuperMetricsHandlers = [];
    private readonly MockHttpMessageHandler _httpMessageHandler;
    private readonly ISubscriptionsService _sut;

    public SubscriptionsServiceTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration(new()
        {
            { "ConnectionStrings:SuperMetrics", "https://www.google.com/" },
            { "SuperMetrics:ApiKey", "key" }
        });

        var successHandler = new Mock<ISuperMetricsHandler>();
        var expiredHandler = new Mock<ISuperMetricsHandler>();

        successHandler.Setup(sh => sh.StatusCode)
            .Returns([HttpStatusCode.OK]);
        successHandler.Setup(sh => sh.HandleAsync(It.IsAny<Connection>(), It.IsAny<Subscription>()))
            .ReturnsAsync((Connection x, Subscription y) => x);

        expiredHandler.Setup(sh => sh.StatusCode)
            .Returns([HttpStatusCode.Forbidden]);
        expiredHandler.Setup(sh => sh.HandleAsync(It.IsAny<Connection>(), It.IsAny<Subscription>()))
            .ReturnsAsync((Connection x, Subscription y) => x);

        _mockedSuperMetricsHandlers.Add(successHandler.Object);
        _mockedSuperMetricsHandlers.Add(expiredHandler.Object);

        _httpMessageHandler = new(HttpStatusCode.OK);
        _mockedHttpClientFactory.Setup(cf => cf.CreateClient("supermetrics"))
            .Returns(new HttpClient(_httpMessageHandler));

        _mockedLoggerFactory.Setup(lf => lf.CreateLogger(It.IsAny<string>())).Returns(_mockedLogger.Object);

        _mockedServiceScope.Setup(sc => sc.ServiceProvider)
            .Returns(_mockedServiceProvider.Object);

        _mockedServiceScopeFactory.Setup(ssf => ssf.CreateScope())
            .Returns(_mockedServiceScope.Object);

        _mockedServiceProvider.Setup(ss => ss.GetService(typeof(IServiceScopeFactory)))
            .Returns(_mockedServiceScopeFactory.Object);

        _sut = new SubscriptionsService(
            configuration,
            _mockedSubscriptionsDao.Object,
            _mockedConnectionsDao.Object,
            _mockedGenericEntriesDao.Object,
            _mockedSubscriptionSettingsDao.Object,
            _mockedSchedulerRegistration.Object,
            _mockedLoggerFactory.Object,
            _mockedHttpClientFactory.Object,
            _mockedChannelDao.Object,
            _mockedServiceProvider.Object,
            _mockedSuperMetricsHandlers
        );
    }

    [Fact]
    public void TestThatHistorySubscriptionNameReturnsAsExpected()
    {
        var subscription = new Subscription
        {
            Id = "1234",
            SubscriptionType = SubscriptionType.IGI_PROFILE_DATA,
            IsHistory = true,
            AdditionalInfo = "-test"
        };

        Assert.Equal("1234-IGI_PROFILE_DATA-history-test", subscription.Name);
    }

    [Fact]
    public void TestThatLiveSubscriptionNameReturnsAsExcepted()
    {
        var subscription = new Subscription
        {
            Id = "1234",
            SubscriptionType = SubscriptionType.IGI_PROFILE_DATA,
            IsHistory = false,
            AdditionalInfo = "-test"
        };

        Assert.Equal("1234-IGI_PROFILE_DATA-live-test", subscription.Name);
    }

    [Fact]
    public void TestThatInputCopyReturnsCopyInputWhenFieldsAreValid()
    {
        var expected = SubscriptionType.FBPD_PAGE.ToInput();
        Input actual = new(expected);

        Assert.Equal(expected.DsId, actual.DsId);
        Assert.Equal(expected.DsAccounts, actual.DsAccounts);
        Assert.Equal(expected.DateRangeType, actual.DateRangeType);
        Assert.Equal(expected.DsUser, actual.DsUser);
        Assert.Equal(expected.StartDate, actual.StartDate);
        Assert.Equal(expected.EndDate, actual.EndDate);
        Assert.Equal(expected.Fields, actual.Fields);
        Assert.Equal(expected.Filter, actual.Filter);
        Assert.Equal(expected.MaxRows, actual.MaxRows);
        Assert.Equal(expected.Settings?.ReportType, actual.Settings?.ReportType);
    }

    [Fact]
    public async Task TestThatFirstBySubscriptionTypeAsyncReturnsSubscriptionWhenSubscriptionExists()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedSubscriptionsDao.Setup(sd => sd.FirstBySubscriptionTypeAsync(SubscriptionType.FBPD_PAGE))
            .ReturnsAsync(subscription);

        var actual = await _sut.FirstBySubscriptionTypeAsync(SubscriptionType.FBPD_PAGE);

        Assert.NotNull(actual);

        Assert.Equal(subscription.Id, actual!.Id);
        Assert.Equal(subscription.Input, actual!.Input);
        Assert.Equal(subscription.Name, actual!.Name);
    }

    [Fact]
    public void TestThatListAllAsyncReturnsTheCronjobList()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = "* * * * *"
        };

        SubscriptionRunnerJob job = new(_mockedServiceProvider.Object, subscription,
            new() { CronSchedule = subscription.Cron },
            new Mock<ILogger<SubscriptionRunnerJob>>().Object);

        Dictionary<string, SchedulerTaskWrapper> jobs = new()
        {
            { subscription.Name, new(CronExpression.Parse(subscription.Cron), job, DateTimeOffset.Now, TimeZoneInfo.Local) }
        };

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(jobs);

        var actual = _sut.ListAllAsync();

        Assert.Equal(jobs.Values, actual);
    }

    [Fact]
    public async Task TestThatFirstAsyncReturnsSubscriptionWhenSubscriptionExists()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_PAGE.ToInput(),
            SubscriptionType = SubscriptionType.FBPD_PAGE
        };

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByChannelIdAsync(ChannelId))
            .ReturnsAsync(new[] { subscription });

        var actual = await _sut.FirstAsync(ChannelId, [SubscriptionType.FBPD_PAGE]);

        Assert.NotNull(actual);

        Assert.Equal(subscription.Id, actual!.Id);
        Assert.Equal(subscription.Input, actual!.Input);
        Assert.Equal(subscription.Name, actual!.Name);
    }

    [Theory]
    [InlineData("dsAccount")]
    [InlineData("dsAccount|dsUser")]
    public async Task TestThatCreateAsyncReturnsSubscriptionWhenInputIsValid(string query)
    {
        var cron = "53/* * * *";

        CreateSubscriptionRequest subscriptionInput = new()
        {
            SubscriptionType = SubscriptionType.FB_POSTS,
            Cron = cron,
            Query = query,
            RequestHistory = false
        };
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FB_POSTS.ToInput(),
            Cron = cron
        };
        if (query.Count(c => c == '|') == 1)
        {
            var fields = query.Split('|');
            subscription.Input.DsAccounts = fields[0];
            subscription.Input.DsUser = fields[1];
        }
        else
            subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.CreateAsync(It.IsAny<Subscription>()))
            .ReturnsAsync(subscription);

        var actual = await _sut.CreateAsync(subscriptionInput);

        Assert.Equal(subscription.Id, actual.Id);
        Assert.Equal(subscription.Input, actual.Input);
        Assert.Equal(subscription.Name, actual.Name);
        Assert.Equal(cron, actual.Cron);
        Assert.False(actual.RunOnce);
    }

    [Fact]
    public async Task TestThatCreateAsyncThrowsSubscriptionTypeNotSupportedExceptionWhenSubscriptionTypeIsInvalid()
    {
        CreateSubscriptionRequest create = new()
        {
            Cron = "* * * * *",
            Query = "test",
            RequestHistory = false,
            SubscriptionType = (SubscriptionType)int.MaxValue
        };
        await Assert.ThrowsAsync<SubscriptionTypeNotSupportedException>(() => _sut.CreateAsync(create));
    }

    [Fact]
    public async Task TestThatGetListAsyncReturnsListOfSubscriptionsWhenFound()
    {
        var cron = "53/* * * *";
        var query = "test";
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FB.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription });

        var actual = await _sut.GetListAsync();

        Assert.Single(actual);

        var actualFirst = actual.First();

        Assert.Equal(actualFirst.Id, SubscriptionId);
        Assert.Equal(subscription.Input, actualFirst.Input);
        Assert.Equal(subscription.Name, actualFirst.Name);
        Assert.Equal(cron, actualFirst.Cron);
        Assert.False(actualFirst.RunOnce);
    }

    [Fact]
    public async Task TestThatToListAsyncReturnsListOfSubscriptionsWhenFound()
    {
        var cron = "53/* * * *";
        var query = "test";
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(new Dictionary<string, SchedulerTaskWrapper>());
        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription });

        var actual = await _sut.ToListAsync();

        Assert.Single(actual);

        var actualFirst = actual.First();

        Assert.Equal(actualFirst.Id, SubscriptionId);
        Assert.Equal(subscription.Input, actualFirst.Input);
        Assert.Equal(subscription.Name, actualFirst.Name);
        Assert.Equal(cron, actualFirst.Cron);
        Assert.False(actualFirst.RunOnce);
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncReturnsListOfSubscriptionsWhenFound()
    {
        var cron = "53/* * * *";
        var query = "test";
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(new Dictionary<string, SchedulerTaskWrapper>());
        _mockedSubscriptionsDao.Setup(sd => sd.ToListByChannelIdAsync(ChannelId))
            .ReturnsAsync(new[] { subscription });

        var actual = await _sut.ToListByChannelIdAsync(ChannelId);

        Assert.Single(actual);

        var actualFirst = actual.First();

        Assert.Equal(actualFirst.Id, SubscriptionId);
        Assert.Equal(subscription.Input, actualFirst.Input);
        Assert.Equal(subscription.Name, actualFirst.Name);
        Assert.Equal(cron, actualFirst.Cron);
        Assert.False(actualFirst.RunOnce);
    }

    [Fact]
    public async Task TestThatInstagramStartsASecondaryCronJob()
    {
        var cron = "53/* * * *";
        var query = "test";
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            SubscriptionType = SubscriptionType.IGI_MEDIA,
            Input = SubscriptionType.IGI_MEDIA.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(new Dictionary<string, SchedulerTaskWrapper>());
        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                It.IsAny<string>(),
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(true);
        _mockedSubscriptionsDao.Setup(sd => sd.ListByChannelStatusAsync(ChannelStatus.Active)).ReturnsAsync(new[] { subscription });

        await _sut.StartAllAsync();

        _mockedSchedulerRegistration.Verify(c => c.AddOrUpdate(
                It.IsAny<string>(),
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()),
            Times.Exactly(2));
    }

    [Fact]
    public async Task TestThatStopAllAsyncReturnsTrueWhenFoundAndStopped()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription, subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.Remove(subscription.Name))
            .Returns(true);

        await _sut.StopAllAsync();

        _mockedLogger.VerifyLogging(
            $"Stopped subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(2));
    }

    [Fact]
    public async Task TestThatStopAllAsyncReturnsFalseWhenNotFound()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription, subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.Remove(subscription.Name))
            .Returns(false);

        await _sut.StopAllAsync();

        _mockedLogger.VerifyLogging(
            $"Failed to stop subscription job: {subscription.Name}. Job not found.",
            LogLevel.Warning,
            Times.Exactly(2));
    }

    [Fact]
    public void TestThatAddOrUpdateSubscriptionScheduleAddsOrUpdatesWhenSuccessful()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                subscription.Name,
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(true);

        _sut.AddOrUpdateSubscriptionSchedule(subscription);

        _mockedLogger.VerifyLogging(
            $"Started subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(1));
    }

    [Fact]
    public void TestThatAddOrUpdateSubscriptionScheduleShouldNotAddOrUpdateWhenFailed()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                subscription.Name,
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(false);

         _sut.AddOrUpdateSubscriptionSchedule(subscription);

        _mockedLogger.VerifyLogging(
            string.Format("Failed to start subscription job: {0}", subscription.Name),
            LogLevel.Warning,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatAddOrUpdateInactiveSubscriptionScheduleAddsOrUpdatesCronJobWhenSucccessful()
    {
        var jobName = "SubscriptionActivationJob";

        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                jobName,
                It.IsAny<SubscriptionActivateRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(true);

        await _sut.AddOrUpdateInactiveSubscriptionSchedule();

        _mockedLogger.VerifyLogging(
            $"Started subscription activation job: {jobName}",
            LogLevel.Information,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatAddOrUpdateInactiveSubscriptionScheduleAddsOrUpdatesCronJobWhenFailed()
    {
        var jobName = "SubscriptionActivationJob";

        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                jobName,
                It.IsAny<SubscriptionActivateRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(false);

        await _sut.AddOrUpdateInactiveSubscriptionSchedule();

        _mockedLogger.VerifyLogging(
            $"Failed to start subscription activation job: {jobName}",
            LogLevel.Warning,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatStartAllInactiveSubscriptionsAsyncStartsAllInactiveSubs()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription, subscription });

        Dictionary<string, SchedulerTaskWrapper> jobs = new();
        _mockedSchedulerRegistration.Setup(sr => sr.Jobs).Returns(jobs);

        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                subscription.Name,
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(true);

        var actual = await _sut.StartAllInactiveSubscriptionsAsync();

        _mockedLogger.VerifyLogging(
            $"Started subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(2));

        foreach (var item in actual)
            Assert.True(item.IsRunning);
    }

    [Fact]
    public async Task TestThatStartAllAsyncReturnsListOfSubscriptionCronJobWhenFoundAndStarted()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.ListByChannelStatusAsync(ChannelStatus.Active))
            .ReturnsAsync(new[] { subscription, subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                subscription.Name,
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(true);

        var actual = await _sut.StartAllAsync();

        _mockedLogger.VerifyLogging(
            $"Started subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(2));

        foreach (var item in actual)
            Assert.True(item.IsRunning);
    }

    [Fact]
    public async Task TestThatStartAllAsyncReturnsListOfSubscriptionCronJobWhenFailed()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.ListByChannelStatusAsync(ChannelStatus.Active))
            .ReturnsAsync(new[] { subscription, subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                subscription.Name,
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(false);

        var actual = await _sut.StartAllAsync();

        _mockedLogger.VerifyLogging(
            $"Failed to start subscription job: {subscription.Name}",
            LogLevel.Warning,
            Times.Exactly(2));

        foreach (var item in actual)
            Assert.False(item.IsRunning);
    }

    [Fact]
    public void TestThatStopSubscriptionJobReturnsTrueWhenFoundAndStopped()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.Remove(subscription.Name))
            .Returns(true);

        var actual = _sut.StopSubscriptionJob(subscription.Name);

        Assert.True(actual.IsRunning);

        _mockedLogger.VerifyLogging(
            $"Stopped subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(1));
    }

    [Fact]
    public void TestThatStopSubscriptionJobReturnsFalseWhenNotFound()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.Remove(subscription.Name))
            .Returns(false);

        var actual = _sut.StopSubscriptionJob(subscription.Name);

        Assert.False(actual.IsRunning);

        _mockedLogger.VerifyLogging(
            $"Failed to stop subscription job: {subscription.Name}. Job not found.",
            LogLevel.Warning,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatStartByIdAsyncReturnsSubscriptionCronJobWhenSuccessful()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(new Dictionary<string, SchedulerTaskWrapper>());
        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(subscription.Id))
            .ReturnsAsync(subscription);
        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(
                subscription.Name,
                It.IsAny<SubscriptionRunnerJob>(),
                It.IsAny<SchedulerOptions>()))
            .Returns(true);

        var actual = await _sut.StartByIdAsync(subscription.Id);

        Assert.True(actual.IsRunning);

        _mockedLogger.VerifyLogging(
            $"Started subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatStartByIdAsyncReturnsSubscriptionCronJobWhenAlreadyRunning()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        Dictionary<string, SchedulerTaskWrapper> jobs = new();

        SubscriptionRunnerJob job = new(_mockedServiceProvider.Object, subscription,
            new() { CronSchedule = "* * * * *" },
            new Mock<ILogger<SubscriptionRunnerJob>>().Object);

        jobs.Add(subscription.Name, new(CronExpression.Parse("* * * * *"), job, DateTimeOffset.Now, TimeZoneInfo.Local));

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(jobs);
        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(subscription.Id))
            .ReturnsAsync(subscription);

        var actual = await _sut.StartByIdAsync(subscription.Id);

        Assert.True(actual.IsRunning);

        _mockedLogger.VerifyLogging(
            $"Tried to start job but was already running: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatStopByIdAsyncReturnsTrueWhenSuccessful()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(subscription.Id))
            .ReturnsAsync(subscription);

        _mockedSchedulerRegistration.Setup(sr => sr.Remove(subscription.Name))
            .Returns(true);

        var actual = await _sut.StopByIdAsync(subscription.Id);

        Assert.True(actual.IsRunning);

        _mockedLogger.VerifyLogging(
            $"Stopped subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(1));
    }
    
    [Fact]
    public async Task TestThatUpdateAsyncReturnsModelWhenSuccessful()
    {
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };
        UpdateSubscriptionRequest update = new() { Cron = "1 2 3 4 5" };

        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(model);
        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(model);

        var actual = await _sut.UpdateAsync(SubscriptionId, update);

        Assert.NotNull(actual);
        Assert.Equal(model.Cron, actual!.Cron);
    }

    [Fact]
    public async Task TestThatCallServerAsyncReturnsConnectionWhenSuccessful()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_PAGE.ToInput(),
            SubscriptionType = SubscriptionType.FBPD_PAGE,
            Cron = "* * * * *"
        };

        SubscriptionSetting subscriptionSetting = new()
        {
            SubscriptionType = SubscriptionType.FB_AGE_AND_GENDER,
            SubscriptionName = "foo",
            Split = "profileid,Date,gender,age",
            Fields = "age,Date,gender,profile,profileid,page_fans,page_impressions_unique"
        };

        dynamic? meta = new ExpandoObject();
        meta.query = new ExpandoObject();
        meta.query.fields = GetTestingFields();

        Connection connection = new()
        {
            Id = ConnectionId,
            SubscriptionId = subscription.Id,
            Data = GetTestingData(),
            Meta = meta,
            Input = subscription.Input
        };

        _mockedChannelDao.Setup(cd => cd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(ValidNonErrorChannel);

        _mockedConnectionsDao.Setup(cd => cd.CreateAsync(It.IsAny<Connection>()))
            .ReturnsAsync(connection);

        _httpMessageHandler.SetResponse(JsonSerializer.Serialize(connection, Options), HttpStatusCode.OK);

        _mockedGenericEntriesDao.Setup(ged => ged.UpdateAsync(
                It.IsAny<GenericEntry>(),
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(new GenericEntry(SubscriptionType.FBPD_PAGE));

        _mockedSubscriptionSettingsDao.Setup(ss => ss.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(subscriptionSetting);

        subscription.Fields = meta.query.fields;
        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(subscription);

        var actual = await _sut.CallServerAsync(subscription);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatCallServerAsyncThrowsNoHandlerExceptionWhenNoImplementationFound()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_PAGE.ToInput(),
            SubscriptionType = SubscriptionType.FBPD_PAGE,
            Cron = "* * * * *"
        };

        SubscriptionSetting subscriptionSetting = new()
        {
            SubscriptionType = SubscriptionType.FB_AGE_AND_GENDER,
            SubscriptionName = "foo",
            Split = "profileid,Date,gender,age",
            Fields = "age,Date,gender,profile,profileid,page_fans,page_impressions_unique"
        };

        dynamic? meta = new ExpandoObject();
        meta.query = new ExpandoObject();
        meta.query.fields = GetTestingFields();

        Connection connection = new()
        {
            Id = ConnectionId,
            SubscriptionId = subscription.Id,
            Data = GetTestingData(),
            Meta = meta,
            Input = subscription.Input
        };

        _mockedChannelDao.Setup(cd => cd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(ValidNonErrorChannel);

        _mockedConnectionsDao.Setup(cd => cd.CreateAsync(It.IsAny<Connection>()))
            .ReturnsAsync(connection);

        _httpMessageHandler.SetResponse(JsonSerializer.Serialize(connection, Options), HttpStatusCode.Locked);

        _mockedGenericEntriesDao.Setup(ged => ged.UpdateAsync(
                It.IsAny<GenericEntry>(),
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(new GenericEntry(SubscriptionType.FBPD_PAGE));

        _mockedSubscriptionSettingsDao.Setup(ss => ss.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(subscriptionSetting);

        subscription.Fields = meta.query.fields;
        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(subscription);

        await Assert.ThrowsAsync<NoHandlerException>(() => _sut.CallServerAsync(subscription));
    }

    [Fact]
    public async Task TestThatCallServerAsyncReplacesAllWhenSubscriptionIsHistory()
    {
        var subscriptionType = SubscriptionType.FB;
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = subscriptionType.ToInput(),
            SubscriptionType = subscriptionType,
            Cron = "* * * * *",
            IsHistory = true
        };

        SubscriptionSetting subscriptionSetting = new()
        {
            SubscriptionType = SubscriptionType.FB_AGE_AND_GENDER,
            SubscriptionName = "foo",
            Split = "profileid,Date,gender,age",
            Fields = "age,Date,gender,profile,profileid,page_fans,page_impressions_unique"
        };
        dynamic? meta = new ExpandoObject();
        meta.query = new ExpandoObject();
        meta.query.fields = GetTestingFields();

        Connection connection = new()
        {
            Id = ConnectionId,
            SubscriptionId = subscription.Id,
            Data = GetTestingData(),
            Meta = meta,
            Input = subscription.Input
        };

        _mockedChannelDao.Setup(cd => cd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(ValidNonErrorChannel);

        _mockedConnectionsDao.Setup(cd => cd.CreateAsync(It.IsAny<Connection>()))
            .ReturnsAsync(connection);

        _httpMessageHandler.SetResponse(JsonSerializer.Serialize(connection, Options), HttpStatusCode.OK);

        _mockedGenericEntriesDao.Setup(ged => ged.ReplaceListAsync(
            It.IsAny<GenericEntry[]>(),
            It.IsAny<string>(),
            It.IsAny<bool>()));

        _mockedSubscriptionSettingsDao.Setup(ss => ss.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(subscriptionSetting);

        subscription.Fields = meta.query.fields;
        _mockedSubscriptionsDao.Setup(sd => sd.UpdateAsync(
                It.IsAny<Subscription>(),
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(subscription);

        var actual = await _sut.CallServerAsync(subscription);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatCallServerAsyncReturnsErrorWhenFailedRemovesCronAndCallsChannelDao()
    {
        var subscriptionType = SubscriptionType.FB;
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = subscriptionType.ToInput(),
            SubscriptionType = subscriptionType,
            Cron = "* * * * *"
        };

        SubscriptionSetting subscriptionSetting = new()
        {
            SubscriptionType = SubscriptionType.FB_AGE_AND_GENDER,
            SubscriptionName = "foo",
            Split = "profileid,Date,gender,age",
            Fields = "age,Date,gender,profile,profileid,page_fans,page_impressions_unique"
        };

        Connection connection = new()
        {
            Id = ConnectionId,
            SubscriptionId = subscription.Id,
            Input = subscription.Input,
            SubscriptionType = subscription.SubscriptionType,
            Error = new()
            {
                Code = "QUERY_AUTH_UNAVAILABLE"
            }
        };

        _mockedChannelDao.Setup(cd => cd.GetAsync(It.IsAny<string>()))
            .ReturnsAsync(ValidNonErrorChannel);

        _mockedConnectionsDao.Setup(cd => cd.CreateAsync(It.IsAny<Connection>()))
            .ReturnsAsync(connection);

        _mockedSubscriptionSettingsDao.Setup(ss => ss.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(subscriptionSetting);

        _httpMessageHandler.SetResponse(JsonSerializer.Serialize(connection, Options), HttpStatusCode.Forbidden);

        var actual = await _sut.CallServerAsync(subscription);

        Assert.NotNull(actual.Error);
    }

    [Fact]
    public void TestThatCalculateDifferenceBetweenEntriesReturnsFullListWhenInvalid()
    {
        var expected = new[] { new GenericEntry((SubscriptionType)(-1)) };
        var actual = SubscriptionServiceHelper.CalculateDifferenceBetweenEntries(expected);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatDeleteByIdAsyncReturnsTrueWhenSuccessful()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(new Dictionary<string, SchedulerTaskWrapper>());
        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(SubscriptionId))
            .ReturnsAsync(subscription);
        _mockedSubscriptionsDao.Setup(sd => sd.DeleteAsync(SubscriptionId))
            .ReturnsAsync(true);

        var actual = await _sut.DeleteByIdAsync(SubscriptionId);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatDeleteByIdAsyncReturnsFalseWhenFailed()
    {
        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(SubscriptionId))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(() => _sut.DeleteByIdAsync(SubscriptionId));
    }

    [Fact]
    public async Task TestThatEntriesAsyncReturnsListOfModelsWhenInputIsValid()
    {
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        var entries = new[]
        {
            new EntryResponse(SubscriptionType.FBPD_PAGE),
            new EntryResponse(SubscriptionType.FBPD_PAGE),
            new EntryResponse(SubscriptionType.FBPD_PAGE)
        };

        _mockedGenericEntriesDao.Setup(ged => ged.ToListAsync<EntryResponse>(
                model.Id,
                It.IsAny<SubscriptionType>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>()))
            .ReturnsAsync(entries);

        var actual = await _sut.EntriesAsync(model, DateTime.MinValue, DateTime.MaxValue);

        Assert.Equal(entries, actual);
    }

    [Theory]
    [InlineData(SubscriptionType.FB)]
    [InlineData(SubscriptionType.GT)]
    public async Task TestThatEntriesWithDifferencesAsyncReturnsListOfDiffedModelsWhenInputIsValid(SubscriptionType subscriptionType)
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            Input = subscriptionType.ToInput()
        };

        List<GenericEntry> genericEntries = [];

        for (var i = 0; i < 10; i++)
            genericEntries.Add(CreateEntryWithData(subscriptionType, i));

        var lastEntry = CreateEntryWithData(subscriptionType, 20);

        _mockedGenericEntriesDao.Setup(ged => ged.GetListByDatesAsync(
                It.IsAny<string>(),
                It.IsAny<SubscriptionType>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                DateRange.DAILY))
            .ReturnsAsync(genericEntries);

        _mockedGenericEntriesDao.Setup(ged => ged.GetLastEntryAsync(
                It.IsAny<string>(),
                It.IsAny<SubscriptionType>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>()))
            .ReturnsAsync(lastEntry);

        var actual = await _sut.EntriesWithDifferencesAsync(subscription, DateTime.MinValue, DateTime.MaxValue);

        switch (subscriptionType)
        {
            case SubscriptionType.FB:
                foreach (var item in actual.ToList())
                {
                    Assert.NotNull(item.Data?.page_followers_DIFF);
                    Assert.NotNull(item.Data?.page_fans_DIFF);
                    Assert.NotNull(item.Data?.page_stories_DIFF);
                    Assert.NotNull(item.Data?.page_video_views_DIFF);
                }

                break;

            case SubscriptionType.GT:
                foreach (var item in actual.ToList())
                    Assert.NotNull(item.Data?.interest_DIFF);
                break;
        }
    }

    private static GenericEntry CreateEntryWithData(SubscriptionType type, int index)
    {
        var entry = new GenericEntry(type) { Data = new ExpandoObject() };
        switch (type)
        {
            case SubscriptionType.GT:
                entry.Data.date = DateTime.UtcNow.AddDays(index * -1);
                entry.Data.interest = index;
                break;

            case SubscriptionType.FB:
                entry.Data.Date = DateTime.UtcNow.AddDays(index * -1);
                entry.Data.page_followers = index;
                entry.Data.page_fans = index * 2;
                entry.Data.page_stories = index * 3;
                entry.Data.page_video_views = index * 4d;
                break;
        }

        return entry;
    }

    private static List<Field> GetTestingFields() =>
    [
        new() { Field_id = "today", Data_type = "string.time.date" },
        new() { Field_id = "Date", Data_type = "string.time.date" },
        new() { Field_id = "date", Data_type = "string.time.date" },
        new() { Field_id = "post_created_time_of_day", Data_type = "string.text.value" },
        new() { Field_id = "post_message", Data_type = "string.text.value" },
        new() { Field_id = "timestamp", Data_type = "string.time.datetime" },
        new() { Field_id = "media_caption", Data_type = "string.text.value" }
    ];

    private static List<object?[]> GetTestingData()
    {
        var message = "Testing message #test1 #test2 @test3 @test4 TEST5 TEST6 👁👄👁";
        var date = "2022-01-01";
        var time = "12:34:56";
        var dateTime = $"{date} {time}";
        var list = new List<object?[]>
        {
            new object?[]
            {
                "Date",
                "Date for GT",
                "Date for FB",
                "Time for FB_POSTS",
                "Content for FB_POSTS",
                "DateTime for IGI_MEDIA",
                "Content for IGI_MEDIA"
            }
        };

        for (var i = 0; i < 120; i++)
        {
            list.Add([
                date,
                date,
                date,
                time,
                message,
                dateTime,
                message
            ]);
        }

        return list;
    }
}