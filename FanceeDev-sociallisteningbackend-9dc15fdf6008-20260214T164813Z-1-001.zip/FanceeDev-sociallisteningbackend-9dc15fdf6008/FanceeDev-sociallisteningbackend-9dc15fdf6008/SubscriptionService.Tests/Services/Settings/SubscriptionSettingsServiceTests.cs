using FanceeAnalyticsData.Models.Analytics;
using SubscriptionService.Dtos.Requests.Settings;
using SubscriptionService.Dtos.Responses;
using SubscriptionService.Exceptions;
using SubscriptionService.Persistence.Settings;
using SubscriptionService.Services.Settings;
using SubscriptionService.Services.Subscriptions;
using SubscriptionNotFoundException = SocialListeningCore.Exceptions.SubscriptionNotFoundException;

namespace SubscriptionService.Tests.Services.Settings;

public class SubscriptionSettingsServiceTests
{
    private readonly SubscriptionSettingsService _sut;
    private readonly Mock<ISubscriptionsService> _mockedSubscriptionService = new();
    private readonly Mock<ISubscriptionSettingsDao> _mockedSubscriptionSettingsDao = new();
    private readonly Guid UserId = new();

    public SubscriptionSettingsServiceTests()
    {
        _sut = new(_mockedSubscriptionSettingsDao.Object, _mockedSubscriptionService.Object);
    }

    [Fact]
    public async Task TestThatAnyAsyncCallsSubscriptionSettingsDaoAnyAsync()
    {
        _mockedSubscriptionSettingsDao.Setup(ssd => ssd.AnyAsync(
                It.IsAny<FilterDefinition<SubscriptionSetting>>(),
                It.IsAny<FindOptions<SubscriptionSetting, SubscriptionSetting>>(),
                It.IsAny<string>()))
            .ReturnsAsync(true);

        var actual = await _sut.AnyAsync();

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatSeedSubscriptionSettingsCallsSubscriptionSettingsDaoCreateAsync()
    {
        await _sut.SeedSubscriptionSettings();

        _mockedSubscriptionSettingsDao.Verify(ssd => ssd.CreateAsync(It.IsAny<SubscriptionSetting>()), Times.Exactly(Enum.GetNames(typeof(SubscriptionType)).Length));
    }

    [Theory]
    [InlineData("RequestField", "RequestField", "RequestSplit", "RequestSplit")]
    [InlineData(null, "ToUpdateField", "RequestSplit", "RequestSplit")]
    [InlineData("RequestField", "RequestField", null, "ToUpdateSplit")]
    [InlineData(null, "ToUpdateField", null, "ToUpdateSplit")]
    public async Task TestThatUpdateSubscriptionSettingAsyncCallsUpdateAsync(string requestField, string updatedField, string requestSplit, string updatedSplit)
    {
        var request = new UpdateSubscriptionSettingsRequest
        {
            Fields = requestField,
            Split = requestSplit
        };

        var toUpdate = new SubscriptionSetting
        {
            SubscriptionName = "TestName",
            SubscriptionType = SubscriptionType.FB,
            Fields = "ToUpdateField",
            Split = "ToUpdateSplit"
        };

        var updated = new SubscriptionSetting
        {
            SubscriptionName = "TestName",
            SubscriptionType = SubscriptionType.FB,
            Fields = updatedField,
            Split = updatedSplit
        };

        _mockedSubscriptionSettingsDao.Setup(ssd => ssd.GetSettingsByTypeAsync(SubscriptionType.FB)).ReturnsAsync(toUpdate);

        _mockedSubscriptionSettingsDao.Setup(ssd => ssd.UpdateAsync(
                It.IsAny<SubscriptionSetting>(),
                It.IsAny<FilterDefinition<SubscriptionSetting>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(updated);

        var actual = await _sut.UpdateSubscriptionSettingAsync(SubscriptionType.FB, request, UserId);

        Assert.NotNull(actual);
        Assert.IsType<SubscriptionSetting>(actual);
        Assert.Equal(updated.Split, actual.Split);
        Assert.Equal(updated.Fields, actual.Fields);
        Assert.Equal(updated.SubscriptionName, actual.SubscriptionName);
        Assert.Equal(updated.SubscriptionType, actual.SubscriptionType);

        if (requestField != null)
            Assert.Equal(request.Fields, actual.Fields);
        if (requestSplit != null)
            Assert.Equal(request.Split, actual.Split);
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsSettingsNotFoundExceptionWhenSubscriptionSettingNotFound()
    {
        _mockedSubscriptionSettingsDao.Setup(ssd => ssd.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync((SubscriptionSetting)null!);

        await Assert.ThrowsAsync<SettingsNotFoundException>(async () => await _sut.DeleteAsync(SubscriptionType.FB_POSTS));
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsSubscriptionNotFoundExceptionWhenSubscriptionNotFound()
    {
        _mockedSubscriptionSettingsDao.Setup(ssd => ssd.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(new SubscriptionSetting { Id = "id" });
        _mockedSubscriptionService.Setup(ss => ss.FirstBySubscriptionTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync((Subscription)null!);

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.DeleteAsync(SubscriptionType.FB));
    }

    [Fact]
    public async Task TestThatDeleteAsyncReturnsTrueWhenSuccessful()
    {
        _mockedSubscriptionSettingsDao.Setup(ssd => ssd.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(new SubscriptionSetting { Id = "id" });
        _mockedSubscriptionService.Setup(ss => ss.FirstBySubscriptionTypeAsync(It.IsAny<SubscriptionType>()))
            .ReturnsAsync(new Subscription { Id = "subscriptionId" });
        _mockedSubscriptionService.Setup(ss => ss.StopByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(new SubscriptionCronJob());
        _mockedSubscriptionSettingsDao.Setup(ssd => ssd.DeleteAsync(It.IsAny<string>()))
            .ReturnsAsync(true);

        var actual = await _sut.DeleteAsync(SubscriptionType.FB);

        Assert.True(actual);

        _mockedSubscriptionSettingsDao.Verify(ssd => ssd.GetSettingsByTypeAsync(It.IsAny<SubscriptionType>()), Times.Once);
        _mockedSubscriptionService.Verify(ss => ss.FirstBySubscriptionTypeAsync(It.IsAny<SubscriptionType>()), Times.Once);
        _mockedSubscriptionService.Verify(ss => ss.StopByIdAsync(It.IsAny<string>()), Times.Once);
        _mockedSubscriptionSettingsDao.Verify(ssd => ssd.DeleteAsync(It.IsAny<string>()), Times.Once);
    }
}