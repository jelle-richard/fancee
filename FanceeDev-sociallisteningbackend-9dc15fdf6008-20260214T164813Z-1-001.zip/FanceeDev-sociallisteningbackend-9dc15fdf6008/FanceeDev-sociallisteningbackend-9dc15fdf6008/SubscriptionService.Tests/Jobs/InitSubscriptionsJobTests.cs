using CronScheduler.Extensions.StartupInitializer;
using Microsoft.Extensions.Logging;
using SubscriptionService.Dtos.Responses;
using SubscriptionService.Jobs;
using SubscriptionService.Services.Subscriptions;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Jobs;

public class InitSubscriptionsJobTests
{
    private readonly IStartupJob _sut;
    private readonly Mock<ISubscriptionsService> _subscriptionsService = new();
    private readonly Mock<ILogger<InitSubscriptionsJob>> _logger = new();

    public InitSubscriptionsJobTests()
    {
        _sut = new InitSubscriptionsJob(
            _logger.Object,
            _subscriptionsService.Object
        );
    }

    [Fact]
    public async Task TestThatExecuteAsyncStartsSubscriptionsWhenSuccessful()
    {
        _subscriptionsService.Setup(x => x.StartAllAsync()).ReturnsAsync(new List<SubscriptionCronJob>());
        _subscriptionsService.Setup(x => x.AddOrUpdateInactiveSubscriptionSchedule()).ReturnsAsync(new SubscriptionCronJob());

        await _sut.ExecuteAsync();

        _logger.VerifyLogging(
            $"{nameof(InitSubscriptionsJob)} started",
            LogLevel.Information,
            Times.Once());

        _logger.VerifyLogging(
            $"{nameof(InitSubscriptionsJob)} ended",
            LogLevel.Information,
            Times.Once());
    }
}