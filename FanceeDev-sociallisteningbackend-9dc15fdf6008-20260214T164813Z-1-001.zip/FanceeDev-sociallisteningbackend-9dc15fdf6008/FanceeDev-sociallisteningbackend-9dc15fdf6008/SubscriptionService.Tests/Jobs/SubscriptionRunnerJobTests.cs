using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Helpers;
using SubscriptionService.Dtos.Responses;
using SubscriptionService.Jobs;
using SubscriptionService.Services.Subscriptions;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Jobs;

public class SubscriptionRunnerJobTests
{
    private readonly Mock<ISubscriptionsService> _subscriptionsService = new();
    private readonly Mock<ILogger<SubscriptionRunnerJob>> _logger = new();
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<IServiceScopeFactory> _mockedServiceScopeFactory = new();

    [Fact]
    public async Task TestThatExecuteAsyncStartsSubscriptionWhenSuccessful()
    {
        Subscription subscription = new()
        {
            Id = ObjectId.GenerateNewId().ToString(),
            Cron = "* * * * *",
            Input = SubscriptionType.GT.ToInput(),
            RunOnce = true
        };

        Connection connection = new()
        {
            SubscriptionId = subscription.Id
        };

        SchedulerOptions options = new()
        {
            CronSchedule = subscription.Cron
        };

        _subscriptionsService.Setup(x => x.CallServerAsync(subscription)).ReturnsAsync(connection);
        _subscriptionsService.Setup(x => x.StopSubscriptionJob(subscription.Name)).Returns(new SubscriptionCronJob { IsRunning = true });

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ISubscriptionsService)))
            .Returns(_subscriptionsService.Object);

        SubscriptionRunnerJob _sut = new(_mockedServiceProvider.Object, subscription, options, _logger.Object);

        await _sut.ExecuteAsync(CancellationToken.None);

        _logger.VerifyLogging(
            $"{options.CronSchedule} - {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(1));
    }
}