using CronScheduler.Extensions.StartupInitializer;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using SubscriptionService.Jobs;
using SubscriptionService.Services.Settings;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Jobs;

public class InitSubscriptionSettingsJobTests
{
    private readonly IStartupJob _sut;
    private readonly Mock<ISubscriptionSettingsService> _mockedSubscriptionSettingsService = new();
    private readonly Mock<ILogger<InitSubscriptionSettingsJob>> _logger = new();
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public InitSubscriptionSettingsJobTests()
    {
        _sut = new InitSubscriptionSettingsJob(
            _logger.Object,
            _mockedSubscriptionSettingsService.Object
        );
    }

    [Fact]
    public async Task TestThatExecuteAsyncSeedsAdminWhenSuccessful()
    {
        var subscriptionSetting = new SubscriptionSetting
        {
            SubscriptionType = SubscriptionType.FB,
            SubscriptionName = "test",
            Split = "profileid,Date",
            Fields = "Date,profile,profileid"
        };

        _mongoDatabase.Mock(new[] { subscriptionSetting });

        _mockedSubscriptionSettingsService.Setup(us => us.AnyAsync()).ReturnsAsync(false);
        _mockedSubscriptionSettingsService.Setup(us => us.CreateAsync(It.IsAny<SubscriptionSetting>()))
            .ReturnsAsync(subscriptionSetting);

        await _sut.ExecuteAsync();

        _logger.VerifyLogging(
            $"{nameof(InitSubscriptionSettingsJob)} started",
            LogLevel.Information,
            Times.Once());

        _logger.VerifyLogging(
            $"{nameof(InitSubscriptionSettingsJob)} ended",
            LogLevel.Information,
            Times.Once());
    }

    [Fact]
    public async Task TestThatExecuteAsyncDoesNothingWhenAlreadySeeded()
    {
        _mockedSubscriptionSettingsService.Setup(us => us.AnyAsync()).ReturnsAsync(true);

        await _sut.ExecuteAsync();

        _logger.VerifyLogging(
            $"{nameof(InitSubscriptionSettingsJob)} started",
            LogLevel.Information,
            Times.Once());

        _logger.VerifyLogging(
            $"{nameof(InitSubscriptionSettingsJob)} ended",
            LogLevel.Information,
            Times.Once());
    }
}