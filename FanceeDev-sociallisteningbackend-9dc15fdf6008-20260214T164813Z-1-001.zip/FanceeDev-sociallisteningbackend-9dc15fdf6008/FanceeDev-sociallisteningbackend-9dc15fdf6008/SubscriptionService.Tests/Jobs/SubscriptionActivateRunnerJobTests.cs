using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Helpers;
using SubscriptionService.Dtos.Responses;
using SubscriptionService.Jobs;
using SubscriptionService.Services.Subscriptions;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Jobs;

public class SubscriptionActivateRunnerJobTests
{
    private const string Name = "SubscriptionActivationJob";
    private readonly Mock<ISubscriptionsService> _subscriptionsService = new();
    private readonly Mock<ILogger<SubscriptionRunnerJob>> _logger = new();
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();

    [Fact]
    public async Task TestThatExecuteAsyncStartsSubscriptionWhenSuccessful()
    {
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ISubscriptionsService)))
            .Returns(_subscriptionsService.Object);

        Subscription subscription = new()
        {
            Id = ObjectId.GenerateNewId().ToString(),
            Cron = "* * * * *",
            Input = SubscriptionType.GT.ToInput(),
            RunOnce = true
        };

        SchedulerOptions options = new()
        {
            CronSchedule = subscription.Cron
        };

        _subscriptionsService.Setup(x => x.StartAllInactiveSubscriptionsAsync())
            .ReturnsAsync(new List<SubscriptionCronJob>());

        SubscriptionActivateRunnerJob _sut = new(_mockedServiceProvider.Object, options, _logger.Object);

        await _sut.ExecuteAsync(CancellationToken.None);

        _logger.VerifyLogging(
            $"{options.CronSchedule} - {Name} started",
            LogLevel.Information,
            Times.Exactly(1));
        _logger.VerifyLogging(
            $"{options.CronSchedule} - {Name} ended",
            LogLevel.Information,
            Times.Exactly(1));
    }
}