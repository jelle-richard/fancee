using FanceeAnalyticsData.Models.Analytics;
using SubscriptionService.Exceptions;
using SubscriptionService.Persistence.Settings;
using SubscriptionService.TestData;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Persistence.Settings;

public class SubscriptionSettingsDaoTests
{
    private readonly Mock<IAsyncCursor<SubscriptionSetting>> Cursor = new();
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<IMongoCollection<SubscriptionSetting>> _mockedCollection = new();
    private readonly ISubscriptionSettingsDao _sut;

    public SubscriptionSettingsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new SubscriptionSettingsDao(configuration, _mongoDatabase.Object);

        _mongoDatabase
            .Setup(x => x.GetCollection<SubscriptionSetting>(
                It.IsAny<string>(), null))
            .Returns(_mockedCollection.Object);

        _mockedCollection
            .Setup(x => x.FindAsync(
                It.IsAny<FilterDefinition<SubscriptionSetting>>(),
                It.IsAny<FindOptions<SubscriptionSetting>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Cursor.Object);

        Cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        Cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
    }

    [Fact]
    public async Task TestThatGetFieldsByTypeAsyncReturnsSubscriptionSetting()
    {
        var subscriptionSettings = SubscriptionSettingsFactory.GetMockedSubscriptionSetting();

        Cursor.Setup(x => x.Current).Returns(new[] { subscriptionSettings });

        var actual = await _sut.GetSettingsByTypeAsync(subscriptionSettings.SubscriptionType);

        Assert.Equal(subscriptionSettings, actual);
    }

    [Fact]
    public async Task TestThatGetFieldsByTypeAsyncThrowsSettingsNotFoundExceptionWhenNotFound()
    {
        Cursor.Setup(x => x.Current).Returns(Array.Empty<SubscriptionSetting>());

        await Assert.ThrowsAsync<SettingsNotFoundException>(async () => await _sut.GetSettingsByTypeAsync(SubscriptionType.FB_AGE_AND_GENDER));
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinition()
    {
        var organization = SubscriptionSettingsFactory.GetMockedSubscriptionSetting();

        Assert.NotNull(_sut.GetUpdateDefinition(organization));
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinitionWhenModelIsNull()
    {
        Assert.NotNull(_sut.GetUpdateDefinition(null));
    }
}