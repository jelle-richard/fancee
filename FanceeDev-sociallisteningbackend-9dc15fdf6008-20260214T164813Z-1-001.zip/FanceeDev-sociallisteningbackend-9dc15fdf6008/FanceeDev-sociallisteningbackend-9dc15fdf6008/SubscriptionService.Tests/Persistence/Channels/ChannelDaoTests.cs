using FanceeAnalyticsData.Models.Analytics;
using SubscriptionService.Persistence.Channels;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Persistence.Channels;

public class ChannelDaoTests
{
    private const string ChannelId = "channelId";
    private readonly ChannelDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public ChannelDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new(configuration, _mongoDatabase.Object);
    }

    [Fact]
    public async Task TestThatUpdateStatusAndMailStatusAsyncReturnsSuccessfulUpdateResult()
    {
        var expected = new UpdateResult.Acknowledged(1, 1, null);
        var mockedCollection = _mongoDatabase.MockCollection<Channel>();
        mockedCollection.Setup(mc => mc.UpdateOneAsync(
            It.IsAny<FilterDefinition<Channel>>(),
            It.IsAny<UpdateDefinition<Channel>>(),
            It.IsAny<UpdateOptions>(),
            It.IsAny<CancellationToken>())).ReturnsAsync(expected);

        var actual = await _sut.UpdateStatusAndMailStatusAsync(ChannelId, ChannelStatus.Expired, true);

        Assert.Equal(expected, actual);
    }
}