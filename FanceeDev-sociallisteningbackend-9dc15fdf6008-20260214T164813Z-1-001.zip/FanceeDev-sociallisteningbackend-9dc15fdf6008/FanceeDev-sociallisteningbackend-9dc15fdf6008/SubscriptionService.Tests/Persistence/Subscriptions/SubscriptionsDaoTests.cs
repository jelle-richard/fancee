using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Utils.Cron;
using SubscriptionService.Persistence.Subscriptions;
using TestCore.Utils.UnitTestsHelpers;

namespace SubscriptionService.Tests.Persistence.Subscriptions;

public class SubscriptionsDaoTests
{
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    private readonly Mock<IAsyncCursor<Subscription>> _cursor = new();
    private readonly ISubscriptionsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<IMongoCollection<Subscription>> _mockedCollection = new();

    public SubscriptionsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new SubscriptionsDao(configuration, _mongoDatabase.Object);

        _mongoDatabase
            .Setup(x => x.GetCollection<Subscription>(
                It.IsAny<string>(), null))
            .Returns(_mockedCollection.Object);

        _mockedCollection
            .Setup(x => x.FindAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(_cursor.Object);

        _cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        _cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinitionWhenSuccessful()
    {
        Subscription model = new()
        {
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };
        Assert.NotNull(_sut.GetUpdateDefinition(model));
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnUpdateDefinitionWhenModelIsNull()
    {
        Assert.NotNull(_sut.GetUpdateDefinition(null));
    }

    [Fact]
    public async Task TestThatCreateAsyncReturnsCreatedSubscriptionWhenSuccessful()
    {
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };

        _mockedCollection
            .SetupSequence(x => x.InsertOneAsync(
                model,
                It.IsAny<InsertOneOptions>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        var actual = await _sut.CreateAsync(model);

        Assert.Equal(model, actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsSubscriptionWhenSuccessful()
    {
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };

        _cursor.Setup(x => x.Current).Returns(new[] { model });

        var actual = await _sut.GetAsync(model.Id);

        Assert.Equal(model, actual);
    }

    [Fact]
    public async Task TestThatFirstBySubscriptionTypeAsyncReturnsSubscriptionWhenSuccessful()
    {
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput(),
            SubscriptionType = SubscriptionType.GT
        };

        _cursor.Setup(x => x.Current).Returns(new[] { model });

        var actual = await _sut.FirstBySubscriptionTypeAsync(model.SubscriptionType);

        Assert.Equal(model, actual);
    }

    [Fact]
    public async Task TestThatFirstAsyncReturnsSubscriptionWhenSuccessful()
    {
        var channelId = "channelId";

        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput(),
            SubscriptionType = SubscriptionType.GT
        };

        _cursor.Setup(x => x.Current).Returns(new[] { model });

        var actual = await _sut.FirstAsync(channelId, new[] { SubscriptionType.GT, SubscriptionType.FB });

        Assert.Equal(model, actual);
    }

    [Fact]
    public async Task TestThatFirstAsyncThrowsSubscriptionNotFoundExceptionWhenNotFound()
    {
        var channelId = "channelId";

        _cursor.Setup(x => x.Current).Returns(Array.Empty<Subscription>());

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.FirstAsync(channelId, new[] { SubscriptionType.FB }));
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsNullWhenNothingFound()
    {
        _cursor.Setup(x => x.Current).Returns(Array.Empty<Subscription>());

        Assert.Null(await _sut.GetAsync(string.Empty));
    }

    [Fact]
    public async Task TestThatUpdateOneAsyncWorksWhenInputIsValid()
    {
        var expected = new UpdateResult.Acknowledged(1, 1, null);
        var mockedCollection = _mongoDatabase.MockCollection<Subscription>();

        mockedCollection.Setup(mc => mc.UpdateOneAsync(
            It.IsAny<FilterDefinition<Subscription>>(),
            It.IsAny<UpdateDefinition<Subscription>>(),
            It.IsAny<UpdateOptions>(),
            It.IsAny<CancellationToken>())).ReturnsAsync(expected);

        var actual = await _sut.UpdateOneAsync(It.IsNotNull<FilterDefinition<Subscription>>(), It.IsNotNull<UpdateDefinition<Subscription>>());

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatGetListAsyncReturnsListOfModelsWhenSuccessful()
    {
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };

        List<Subscription> asList = [model, model];

        Subscription[] asArray = [model, model];

        _cursor.Setup(x => x.Current).Returns(asArray);

        var actual = await _sut.GetListAsync();

        Assert.Equal(asList, actual);
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncReturnsListOfModelsWhenSuccessful()
    {
        var channelId = string.Empty;
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };

        List<Subscription> asList = [model, model];

        Subscription[] asArray = [model, model];

        _cursor.Setup(x => x.Current).Returns(asArray);

        var actual = await _sut.ToListByChannelIdAsync(channelId);

        Assert.Equal(asList, actual);
    }

    [Fact]
    public async Task TestThatUpdateFieldsAsyncReturnsUpdateResultWhenSuccessful()
    {
        var subscription = new Subscription { Id = "", ChannelId = "", SubscriptionType = SubscriptionType.FB };
        var expected = new UpdateResult.Acknowledged(1, 1, null);

        _mockedCollection.Setup(mc => mc.UpdateOneAsync(
            It.IsAny<FilterDefinition<Subscription>>(),
            It.IsAny<UpdateDefinition<Subscription>>(),
            It.IsAny<UpdateOptions>(),
            It.IsAny<CancellationToken>())).ReturnsAsync(expected);

        var actual = await _sut.UpdateFieldsAsync(subscription);
        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncThrowsSubscriptionNotFoundExceptionWhenListEmpty()
    {
        var channelId = string.Empty;

        _cursor.Setup(x => x.Current).Returns(Array.Empty<Subscription>());

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.ToListByChannelIdAsync(channelId));
    }

    [Fact]
    public async Task TestThatUpdateAsyncReturnsModelWhenSuccessful()
    {
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };

        _mockedCollection
            .SetupSequence(x => x.FindOneAndUpdateAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<UpdateDefinition<Subscription>>(),
                It.IsAny<FindOneAndUpdateOptions<Subscription>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(model);

        var actual = await _sut.UpdateAsync(model);

        Assert.Equal(model, actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncReturnsTrueWhenSuccessful()
    {
        _mockedCollection
            .SetupSequence(x => x.DeleteOneAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new DeleteResult.Acknowledged(1));

        var actual = await _sut.DeleteAsync(string.Empty);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncReturnsFalseWhenFailed()
    {
        _mockedCollection
            .SetupSequence(x => x.DeleteOneAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(DeleteResult.Unacknowledged.Instance);

        var actual = await _sut.DeleteAsync(string.Empty);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatListByChannelStatusAsyncReturnsChannelsByStatus()
    {
        var expectedData = new List<Subscription>
        {
            new()
            {
                Id = "sub1",
                CreatedOn = default,
                UpdatedOn = default,
                ChannelId = "channelId1",
                SubscriptionType = SubscriptionType.FA_CAMPAIGN,
                Cron = CronConstants.CronRunEvery5Minutes,
                Active = true,
                RunOnce = false,
                IsHistory = false
            },
            new()
            {
                Id = "sub2",
                CreatedOn = default,
                UpdatedOn = default,
                ChannelId = "channelId1",
                SubscriptionType = SubscriptionType.FA_CAMPAIGN,
                Cron = CronConstants.CronRunEvery5Minutes,
                Active = true,
                RunOnce = false,
                IsHistory = false
            }
        }.ToArray();

        _mockedCollection.SetupSequence(c =>
            c.AggregateAsync(
                It.IsAny<PipelineDefinition<Subscription, Subscription>>(),
                It.IsAny<AggregateOptions>(),
                It.IsAny<CancellationToken>())
        ).ReturnsAsync(_cursor.Object);

        _cursor.Setup(c => c.Current)
            .Returns(expectedData);

        var actual = (await _sut.ListByChannelStatusAsync(ChannelStatus.Active)).ToArray();

        Assert.Equal(expectedData[0], actual[0]);
        Assert.Equal(expectedData[1], actual[1]);
    }
}