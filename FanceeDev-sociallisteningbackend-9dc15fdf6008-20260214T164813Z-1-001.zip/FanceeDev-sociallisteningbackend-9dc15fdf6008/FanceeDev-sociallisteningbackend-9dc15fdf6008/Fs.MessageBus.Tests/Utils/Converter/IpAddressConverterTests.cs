﻿using System.Net;
using System.Text;
using System.Text.Json;
using Fs.MessageBus.Utils.Converter;
using Xunit;

namespace Fs.MessageBus.Tests.Utils.Converter;

public class IpAddressConverterTests
{
    public static readonly object?[][] ReadTestData =
    {
        new object?[] { "malformed", null },
        new object?[] { "127.0.0.1", IPAddress.Parse("127.0.0.1") },
        new object?[] { "01ed:fec9:6734:ea44:1656:8d90:03b5:22f0", IPAddress.Parse("01ed:fec9:6734:ea44:1656:8d90:03b5:22f0") },
        new object?[] { "6.170.165.137", IPAddress.Parse("6.170.165.137") }
    };

    public static readonly object?[][] WriteTestData =
    {
        new object?[] { null, "null" },
        new object?[] { IPAddress.Parse("127.0.0.1"), "\"127.0.0.1\"" },
        new object?[] { IPAddress.Parse("01ed:fec9:6734:ea44:1656:8d90:03b5:22f0"), "\"1ed:fec9:6734:ea44:1656:8d90:3b5:22f0\"" },
        new object?[] { IPAddress.Parse("6.170.165.137"), "\"6.170.165.137\"" }
    };

    private readonly IpAddressConverter _sut;

    public IpAddressConverterTests()
    {
        _sut = new();
    }

    [Theory]
    [InlineData(typeof(IPAddress), true)]
    [InlineData(typeof(int), false)]
    public void TestThatCanConvertReturnsExpectedResult(Type input, bool expected)
    {
        var actual = _sut.CanConvert(input);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [MemberData(nameof(ReadTestData))]
    public void TestThatReadReturnsExpectedResult(string value, IPAddress? expected)
    {
        var json = "{\"ip\":\"" + value + "\"}";
        var reader = new Utf8JsonReader(Encoding.UTF8.GetBytes(json));

        // We forward the reader here, so it starts at the value
        reader.Read();
        reader.Read();
        reader.Read();

        var actual = _sut.Read(ref reader, typeof(IPAddress), new());

        Assert.Equal(expected, actual);
    }

    [Theory]
    [MemberData(nameof(WriteTestData))]
    public void TestThatWriteWritesIpAddress(IPAddress? value, string expected)
    {
        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream);

        _sut.Write(writer, value, new());

        writer.Flush();

        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal(expected, actual);
    }
}