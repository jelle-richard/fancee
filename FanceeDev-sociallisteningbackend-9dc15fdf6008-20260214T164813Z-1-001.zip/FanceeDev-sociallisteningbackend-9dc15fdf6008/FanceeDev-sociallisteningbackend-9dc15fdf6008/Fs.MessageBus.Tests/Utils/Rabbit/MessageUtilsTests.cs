using System.Runtime.Serialization;
using System.Text;
using Fs.MessageBus.Models;
using Fs.MessageBus.Utils.Rabbit;
using Moq;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Xunit;

namespace Fs.MessageBus.Tests.Utils.Rabbit;

public class MessageUtilsTests
{
    [Theory]
    [InlineData(typeof(MessageUtilsTests), false)]
    [InlineData(typeof(UnitTestMessage), true)]
    [InlineData(typeof(UnitTestMessageWithMultipleInterfaces), true)]
    public void TestThatIsRabbitMessageReturnsTheExpectedValue(Type typeToCheck, bool expected)
    {
        var actual = typeToCheck.IsRabbitMessage();

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatGetTypeFromReceivedEventReturnsNullOnInvalidHeader()
    {
        var mockedArgs = new Mock<BasicDeliverEventArgs>();

        var actual = mockedArgs.Object.GetTypeFromReceivedEvent();

        Assert.Null(actual);
    }

    [Fact]
    public void TestThatGetTypeFromReceivedEventReturnsNullWhenHeaderValueIsNotAnByteArray()
    {
        var mockedProperties = new Mock<IBasicProperties>();

        mockedProperties.SetupGet(p => p.Headers).Returns(new Dictionary<string, object>
        {
            { RabbitConfig.Headers.MessageType, "Invalid value for message-type header" }
        });

        var args = new BasicDeliverEventArgs(default, default, default, default, default, mockedProperties.Object, default);

        var actual = args.GetTypeFromReceivedEvent();

        Assert.Null(actual);
    }

    [Theory]
    [InlineData(typeof(UnitTestMessage), typeof(UnitTestMessage))]
    [InlineData(typeof(UnitTestMessageWithMultipleInterfaces), typeof(UnitTestMessageWithMultipleInterfaces))]
    [InlineData(typeof(MessageUtilsTests), null)]
    [InlineData(typeof(IInterfaceMessage), typeof(IInterfaceMessage))]
    public void TestThatGetTypeFromReceivedEventReturnsCorrectType(Type typeToEncode, Type expected)
    {
        var mockedProperties = new Mock<IBasicProperties>();

        mockedProperties.SetupGet(p => p.Headers).Returns(new Dictionary<string, object>
        {
            { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes(typeToEncode.FullName!) }
        });

        var args = new BasicDeliverEventArgs(default, default, default, default, default, mockedProperties.Object, default);

        var actual = args.GetTypeFromReceivedEvent();

        Assert.Equal(expected?.FullName, actual?.FullName);
    }

    [Fact]
    public void TestThatGetTypeFromReceivedEventReturnsNullOnInvalidByteArray()
    {
        var mockedProperties = new Mock<IBasicProperties>();

        mockedProperties.SetupGet(p => p.Headers).Returns(new Dictionary<string, object>
        {
            { RabbitConfig.Headers.MessageType, Encoding.UTF8.GetBytes("I am random data.") }
        });

        var args = new BasicDeliverEventArgs(default, default, default, default, default, mockedProperties.Object, default);

        var actual = args.GetTypeFromReceivedEvent();

        Assert.Null(actual);
    }

    #region Classes for this test suite

    public class UnitTestMessage : IMessage
    {
    }

    public class UnitTestMessageWithMultipleInterfaces : IMessage, ISerializable
    {
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
        }
    }

    public interface IInterfaceMessage : IMessage
    {
    }

    #endregion
}