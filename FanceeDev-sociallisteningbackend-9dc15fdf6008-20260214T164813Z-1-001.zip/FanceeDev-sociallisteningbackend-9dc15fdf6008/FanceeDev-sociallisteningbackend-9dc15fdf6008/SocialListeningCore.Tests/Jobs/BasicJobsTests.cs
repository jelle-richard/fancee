using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Jobs;
using SocialListeningCore.Services.Cron;
using SocialListeningCore.Services.Scheduler;
using SocialListeningCore.Utils.Cron;

namespace SocialListeningCore.Tests.Jobs;

public class BasicJobsTests
{
    private static readonly SchedulerOptions Options = new()
    {
        CronSchedule = CronConstants.CronRunEvery5Minutes,
        CronTimeZone = "Europe/Amsterdam",
        RunImmediately = false
    };

    private static readonly BasicCron InputRunOnce = new()
    {
        Id = "Id",
        CreatedOn = default,
        UpdatedOn = default,
        Name = "BasicCron",
        Cron = CronConstants.CronRunEvery5Minutes,
        Active = true,
        RunOnce = true
    };

    private static readonly BasicCron Input = new()
    {
        Id = "Id",
        CreatedOn = default,
        UpdatedOn = default,
        Name = "BasicCron",
        Cron = CronConstants.CronRunEvery5Minutes,
        Active = true,
        RunOnce = false
    };

    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ILogger> _mockedLogger = new();
    private readonly Mock<ISchedulerService<BasicCron>> _mockedSchedulerService = new();
    private readonly Mock<ICronService<BasicCron>> _mockedBasicCronService = new();
    private BasicJob<BasicCron, ICronService<BasicCron>>? _sut;

    [Fact]
    public async Task TestThatBasicJobCallsUnderlyingMethodsSuccessfullyWhenRunOnce()
    {
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ISchedulerService<BasicCron>)))
            .Returns(_mockedSchedulerService.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ICronService<BasicCron>)))
            .Returns(_mockedBasicCronService.Object);

        _sut = new(_mockedServiceProvider.Object, _mockedLogger.Object, Options, InputRunOnce);
        await _sut.ExecuteAsync(It.IsAny<CancellationToken>());

        _mockedSchedulerService.Verify(ss => ss.StopJob(InputRunOnce.Name!), Times.Exactly(1));
        _mockedBasicCronService.Verify(bcs => bcs.RunAsync(InputRunOnce), Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatBasicJobCallsUnderlyingMethodsSuccessfully()
    {
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ISchedulerService<BasicCron>)))
            .Returns(_mockedSchedulerService.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ICronService<BasicCron>)))
            .Returns(_mockedBasicCronService.Object);

        _sut = new(_mockedServiceProvider.Object, _mockedLogger.Object, Options, Input);
        await _sut.ExecuteAsync(It.IsAny<CancellationToken>());

        _mockedSchedulerService.Verify(ss => ss.StopJob(Input.Name!), Times.Exactly(0));
        _mockedBasicCronService.Verify(bcs => bcs.RunAsync(Input), Times.Exactly(1));
    }
}