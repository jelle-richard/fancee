using System.Text;
using System.Text.Json;
using FanceeAuthentication.Dtos;
using Microsoft.Extensions.Caching.Distributed;
using SocialListeningCore.Services.Cache;

namespace SocialListeningCore.Tests.Services.Cache;

public class RedisCacheServiceTests
{
    private const string ValidToken = "ValidToken";
    private const string InvalidToken = "InvalidToken";
    private static readonly Guid ValidUserId = Guid.NewGuid();

    private readonly RedisCacheService _sut;
    private readonly Mock<IDistributedCache> _mockedCacheService;

    public RedisCacheServiceTests()
    {
        _mockedCacheService = new();

        var json = JsonSerializer.Serialize(new TokenCache
        {
            UserId = ValidUserId,
            Valid = true
        });

        _mockedCacheService.Setup(c => c.GetAsync(ValidToken, default)).ReturnsAsync(Encoding.UTF8.GetBytes(json));

        _sut = new(_mockedCacheService.Object);
    }

    [Fact]
    public async Task TestThatGetCachedObjectAsyncGetsCachedObject()
    {
        var actual = await _sut.GetCachedObjectAsync<TokenCache>(ValidToken);

        Assert.NotNull(actual);
        Assert.Equal(ValidUserId, actual.UserId);
        Assert.True(actual.Valid);
    }

    [Fact]
    public async Task TestThatCacheObjectAsyncWithIntDaysCachesForGivenDays()
    {
        var cache = new TokenCache { UserId = ValidUserId, Valid = true };

        await _sut.CacheObjectAsync(ValidToken, cache, 1);

        _mockedCacheService.Verify(c => c.SetAsync(
                ValidToken,
                It.IsAny<byte[]>(), It.Is<DistributedCacheEntryOptions>(dceo =>
                    dceo.AbsoluteExpirationRelativeToNow == TimeSpan.FromDays(1)), default),
            Times.Once);

        var verify = await _sut.GetCachedObjectAsync<TokenCache>(ValidToken);

        Assert.NotNull(verify);
        Assert.Equal(ValidUserId, verify.UserId);
        Assert.True(verify.Valid);
    }

    [Fact]
    public async Task TestThatCacheObjectAsyncWithTimespanCachesForGivenTimespan()
    {
        var cache = new TokenCache { UserId = ValidUserId, Valid = true };

        await _sut.CacheObjectAsync(ValidToken, cache, TimeSpan.FromMinutes(42));

        _mockedCacheService.Verify(c => c.SetAsync(
                ValidToken,
                It.IsAny<byte[]>(), It.Is<DistributedCacheEntryOptions>(dceo =>
                    dceo.AbsoluteExpirationRelativeToNow == TimeSpan.FromMinutes(42)), default),
            Times.Once);

        var verify = await _sut.GetCachedObjectAsync<TokenCache>(ValidToken);

        Assert.NotNull(verify);
        Assert.Equal(ValidUserId, verify.UserId);
        Assert.True(verify.Valid);
    }

    [Fact]
    public async Task TestThatGetCachedObjectAsyncReturnsNullOnKey()
    {
        _mockedCacheService.Setup(c => c.GetAsync(InvalidToken, default)).ReturnsAsync(Array.Empty<byte>());

        var actual = await _sut.GetCachedObjectAsync<TokenCache>(InvalidToken);

        Assert.Null(actual);
        _mockedCacheService.Verify(c => c.GetAsync(InvalidToken, default), Times.Once);
    }

    [Fact]
    public async Task TestThatRemoveCacheByKeyAsyncRemovesCacheEntry()
    {
        await _sut.RemoveCacheByKeyAsync(ValidToken);

        _mockedCacheService.Verify(c => c.RemoveAsync(ValidToken, default));
    }
}