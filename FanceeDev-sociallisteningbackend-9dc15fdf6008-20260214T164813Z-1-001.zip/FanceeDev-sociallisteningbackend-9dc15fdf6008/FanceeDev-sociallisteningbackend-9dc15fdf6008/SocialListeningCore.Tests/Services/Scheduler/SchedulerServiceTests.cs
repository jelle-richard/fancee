using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.CronJobs;
using SocialListeningCore.Services.Cron;
using SocialListeningCore.Services.Scheduler;
using SocialListeningCore.Utils.Cron;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Services.Scheduler;

public class SchedulerServiceTests
{
    private static readonly BasicCron Input = new()
    {
        Id = "BasicCron1",
        Name = "BasicCron1",
        Cron = CronConstants.CronRunEvery5Minutes,
        Active = true,
        RunOnce = false
    };

    private readonly SchedulerService<BasicCron, ICronService<BasicCron>> _sut;
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<IServiceScopeFactory> _mockedServiceScopeFactory = new();
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<ILoggerFactory> _mockedLoggerFactory = new();
    private readonly Mock<ILogger> _mockedLogger = new();
    private readonly Mock<ISchedulerRegistration> _mockedSchedulerRegistration = new();

    public SchedulerServiceTests()
    {
        _mockedLoggerFactory.Setup(lf => lf.CreateLogger(It.IsAny<string>()))
            .Returns(_mockedLogger.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory)))
            .Returns(_mockedServiceScopeFactory.Object);

        _mockedServiceScopeFactory.Setup(ssf => ssf.CreateScope())
            .Returns(_mockedServiceScope.Object);

        _mockedServiceScope.Setup(ss => ss.ServiceProvider)
            .Returns(_mockedServiceProvider.Object);

        _sut = new(
            _mockedServiceProvider.Object,
            _mockedSchedulerRegistration.Object,
            _mockedLoggerFactory.Object
        );
    }

    [Fact]
    public void TestThatAddOrUpdateScheduleAddsJob()
    {
        _mockedSchedulerRegistration.Setup(sr =>
            sr.AddOrUpdate(Input.Name!, It.IsAny<IScheduledJob>(), It.IsAny<SchedulerOptions>())
        ).Returns(true);

        var actual = _sut.AddOrUpdateSchedule(Input);

        _mockedSchedulerRegistration.Verify(sr =>
                sr.AddOrUpdate(Input.Name!, It.IsAny<IScheduledJob>(), It.IsAny<SchedulerOptions>()),
            Times.Exactly(1)
        );

        _mockedLogger.VerifyLoggingEndsWith(
            $"Started job: {Input.Name!}",
            LogLevel.Information,
            Times.Exactly(1));

        Assert.NotNull(actual);
        Assert.IsType<CronJobResponse<BasicCron>>(actual);
        Assert.True(actual.IsRunning);
    }

    [Fact]
    public void TestThatAddOrUpdateScheduleFailsAddingJob()
    {
        _mockedSchedulerRegistration.Setup(sr =>
            sr.AddOrUpdate(Input.Name!, It.IsAny<IScheduledJob>(), It.IsAny<SchedulerOptions>())
        ).Returns(false);

        var actual = _sut.AddOrUpdateSchedule(Input);

        _mockedSchedulerRegistration.Verify(sr =>
                sr.AddOrUpdate(Input.Name!, It.IsAny<IScheduledJob>(), It.IsAny<SchedulerOptions>()),
            Times.Exactly(1)
        );

        _mockedLogger.VerifyLoggingEndsWith(
            $"Failed to start job: {Input.Name!}",
            LogLevel.Warning,
            Times.Exactly(1));

        Assert.NotNull(actual);
        Assert.IsType<CronJobResponse<BasicCron>>(actual);
        Assert.False(actual.IsRunning);
    }

    [Fact]
    public void TestThatStopJobStopsJob()
    {
        _mockedSchedulerRegistration.Setup(sr =>
            sr.Remove(Input.Name!)
        ).Returns(true);

        var actual = _sut.StopJob(Input.Name!);

        _mockedSchedulerRegistration.Verify(sr =>
                sr.Remove(Input.Name!),
            Times.Exactly(1)
        );

        _mockedLogger.VerifyLoggingEndsWith(
            $"Stopped job: {Input.Name!}",
            LogLevel.Information,
            Times.Exactly(1));

        Assert.NotNull(actual);
        Assert.IsType<CronJobResponse<BasicCron>>(actual);
        Assert.True(actual.IsStopped);
    }

    [Fact]
    public void TestThatStopJobFailsStoppingJob()
    {
        _mockedSchedulerRegistration.Setup(sr =>
            sr.Remove(Input.Name!)
        ).Returns(false);

        var actual = _sut.StopJob(Input.Name!);

        _mockedSchedulerRegistration.Verify(sr =>
                sr.Remove(Input.Name!),
            Times.Exactly(1)
        );

        _mockedLogger.VerifyLoggingEndsWith(
            $"Failed to stop job: {Input.Name!}. Job not found.",
            LogLevel.Warning,
            Times.Exactly(1));

        Assert.NotNull(actual);
        Assert.IsType<CronJobResponse<BasicCron>>(actual);
        Assert.False(actual.IsStopped);
    }
}