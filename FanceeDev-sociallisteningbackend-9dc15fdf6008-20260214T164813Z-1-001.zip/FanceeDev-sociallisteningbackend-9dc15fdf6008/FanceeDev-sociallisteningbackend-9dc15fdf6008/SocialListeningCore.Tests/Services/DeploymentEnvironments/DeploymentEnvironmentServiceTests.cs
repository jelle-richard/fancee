using System.Net;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Http;
using SocialListeningCore.Persistence.DeploymentEnvironments;
using SocialListeningCore.Services.DeploymentEnvironments;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Services.DeploymentEnvironments;

public class DeploymentEnvironmentServiceTests
{
    private readonly DeploymentEnvironmentService _sut;
    private readonly Mock<IDeploymentEnvironmentDao> _mockedDeploymentEnvironmentDao;
    private readonly Mock<IHttpContextAccessor> _mockedHttpContext = new();

    public DeploymentEnvironmentServiceTests()
    {
        _mockedDeploymentEnvironmentDao = new();

        _mockedHttpContext.Setup(hc => hc.HttpContext!.Request.IsHttps).Returns(false);
        _mockedHttpContext.Setup(hc => hc.HttpContext!.Request.Host).Returns(new HostString("localhost"));
        _mockedHttpContext.Setup(hc => hc.HttpContext!.Connection.RemoteIpAddress).Returns(IPAddress.Parse("127.0.0.1"));

        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "Environment:Default", "unit.test" }
        });

        _sut = new(_mockedHttpContext.Object, _mockedDeploymentEnvironmentDao.Object, mockedConfiguration);
    }

    [Fact]
    public async Task TestThatGetAsyncGetsTheHostedDeploymentEnvironment()
    {
        var deploymentEnvironmentId = Guid.NewGuid().ToString();

        _mockedDeploymentEnvironmentDao.Setup(ded => ded.ByHostAsync(It.IsAny<string>())).ReturnsAsync(new DeploymentEnvironment
        {
            Id = deploymentEnvironmentId,
            Domain = "localhost",
            Name = "UnitTest"
        });

        var actual = await _sut.GetAsync();

        Assert.NotNull(actual);
        Assert.Equal(deploymentEnvironmentId, actual.Id);
        Assert.Equal("localhost", actual.Domain);
        Assert.Equal("UnitTest", actual.Name);
        Assert.False(actual.IsHttps);
        Assert.Equal("http", actual.Scheme);
        Assert.Equal("127.0.0.1", actual.RemoteIpAddress!.ToString());
    }

    [Fact]
    public async Task TestThatGetAsyncGetsTheCachedEnvironmentIfCalledAlready()
    {
        var deploymentEnvironmentId = Guid.NewGuid().ToString();

        _mockedDeploymentEnvironmentDao.Setup(ded => ded.ByHostAsync(It.IsAny<string>())).ReturnsAsync(new DeploymentEnvironment
        {
            Id = deploymentEnvironmentId,
            Domain = "localhost",
            Name = "UnitTest"
        });

        var _ = await _sut.GetAsync();
        var actual = await _sut.GetAsync();

        Assert.NotNull(actual);

        _mockedDeploymentEnvironmentDao.Verify(ded => ded.ByHostAsync(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsDomainWithPort()
    {
        _mockedDeploymentEnvironmentDao.Setup(ded => ded.ByHostAsync(It.IsAny<string>())).ReturnsAsync(new DeploymentEnvironment
        {
            Id = Guid.NewGuid().ToString(),
            Domain = "localhost",
            Name = "UnitTest",
            Port = 8010
        });

        var actual = await _sut.GetAsync();

        Assert.Equal("localhost:8010", actual.Domain);
    }

    [Fact]
    public async Task TestThatGetHostFallsBackToConfigurationIfNoHostIsFound()
    {
        _mockedHttpContext.Setup(hc => hc.HttpContext!.Request.Host).Returns(new HostString(""));
        _mockedDeploymentEnvironmentDao.Setup(ded => ded.ByHostAsync("unit.test")).ReturnsAsync(new DeploymentEnvironment
        {
            Id = Guid.NewGuid().ToString(),
            Domain = "unit.test",
            Name = "UnitTest"
        });

        var actual = await _sut.GetAsync();

        Assert.Equal("unit.test", actual.Domain);
    }
}