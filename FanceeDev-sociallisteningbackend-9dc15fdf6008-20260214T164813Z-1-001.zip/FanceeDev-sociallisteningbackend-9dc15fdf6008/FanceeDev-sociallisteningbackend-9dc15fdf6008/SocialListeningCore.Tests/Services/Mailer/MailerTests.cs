using Fs.MessageBus.Publishers;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using SocialListeningCore.Dtos.MailProvider;
using SocialListeningCore.MessageBus.Messages.Mail;
using ViewRenderer;

namespace SocialListeningCore.Tests.Services.Mailer;

public class MailerTests
{
    private static readonly Mail Model = new()
    {
        Id = null,
        CreatedOn = default,
        UpdatedOn = default,
        From = new("unit@test.com", "unittest"),
        To = new[] { new MailAddress("unit@test.com", "unittest") },
        Headers = null,
        Subject = "unit test",
        TextContent = "I am text content and don't have to pretend to be anything!",
        HtmlContent = "I am pretending to be HTML Content!",
        Attachments = null,
        SendOn = null
    };

    private readonly Mock<IMessagePublisher<AddMailMessage>> _mockedPublisher = new();
    private readonly Mock<IObjectModelValidator> _mockedValidator = new();
    private readonly Mock<IViewRenderer> _mockedViewRender = new();
    private readonly SocialListeningCore.Services.Mailer.Mailer _sut;

    public MailerTests()
    {
        _sut = new(_mockedPublisher.Object, _mockedValidator.Object, _mockedViewRender.Object);
    }

    [Fact]
    public void TestThatViewRendererReturnsViewRenderer()
    {
        var viewRenderer = _sut.ViewRenderer;
        Assert.IsAssignableFrom<IViewRenderer>(viewRenderer);
    }

    [Fact]
    public void TestThatSendCallsUnderlyingMethodsSucessfully()
    {
        _sut.Send(Model);

        _mockedPublisher.Verify(p => p.Publish(It.IsAny<AddMailMessage>()), Times.Once);
    }
}