using System.Text.Json;
using SocialListeningCore.Exceptions;

namespace SocialListeningCore.Tests.Exceptions;

public class ApiExceptionsTests
{
    [Fact]
    public void CollectionNotFoundExceptionShouldBeSerializable()
    {
        var exception = new CollectionNotFoundException();
        var json = JsonSerializer.Serialize(exception);
        var deserializedException = JsonSerializer.Deserialize<CollectionNotFoundException>(json);

        TestApiException(exception, deserializedException);
    }

    private static void TestApiException<TException>(TException a, TException? b) where TException : ApiException
    {
        Assert.NotNull(b);
        Assert.Equal(a.StatusCode, b.StatusCode);
        Assert.Equal(a.ErrorCode, b.ErrorCode);
        Assert.Equal(a.Message, b.Message);
        Assert.Equal(a.StackTrace, b.StackTrace);
    }
}