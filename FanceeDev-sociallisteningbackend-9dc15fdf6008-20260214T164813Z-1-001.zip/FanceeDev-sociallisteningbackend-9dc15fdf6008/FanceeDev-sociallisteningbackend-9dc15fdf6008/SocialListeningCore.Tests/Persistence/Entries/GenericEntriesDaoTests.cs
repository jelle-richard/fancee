using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence.Entries;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Persistence.Entries;

public class GenericEntriesDaoTests
{
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    public readonly Mock<IAsyncCursor<GenericEntry>> Cursor = new();
    private readonly IGenericEntriesDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<IMongoCollection<GenericEntry>> _mockedCollection = new();

    public GenericEntriesDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new GenericEntriesDao(configuration, _mongoDatabase.Object);

        _mongoDatabase
            .Setup(x => x.GetCollection<GenericEntry>(
                It.IsAny<string>(), null))
            .Returns(_mockedCollection.Object);

        _mockedCollection
            .Setup(x => x.AggregateAsync(
                It.IsAny<PipelineDefinition<GenericEntry, GenericEntry>>(),
                It.IsAny<AggregateOptions>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Cursor.Object);

        _mockedCollection
            .Setup(x => x.FindAsync(
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<FindOptions<GenericEntry>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Cursor.Object);

        _mockedCollection
            .Setup(x => x.FindAsync(
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<FindOptions<GenericEntry, GenericEntry>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Cursor.Object);

        Cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        Cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public void TestThatGetFilterDefinitionReturnsFilterDefinitionWhenSuccessful(SubscriptionType subscriptionType)
    {
        Assert.NotNull(_sut.GetFilterDefinition(new(subscriptionType) { Data = subscriptionType.MockDataProperties() }));
    }

    [Fact]
    public void TestThatGetSortDefinitionReturnsSortDescendingWhenSuccessful()
    {
        Assert.NotNull(EntryHelper.GetSortDefinition<GenericEntry>());
    }

    [Fact]
    public void TestThatGetSortDefinitionReturnsSortAscendingWhenSuccessful()
    {
        Assert.NotNull(EntryHelper.GetSortDefinition<GenericEntry>(false));
    }

    [Fact]
    public void TestThatGetFilterDefinitionReturnsFilterDefinitionWhenInputIsNull()
    {
        Assert.NotNull(_sut.GetFilterDefinition(null));
    }

    [Fact]
    public void TestThatGetFilterDefinitionReturnsFilterDefinitionWhenSubscriptionTypeIsInvalid()
    {
        Assert.Throws<SubscriptionTypeNotSupportedException>(() => _sut.GetFilterDefinition(new((SubscriptionType)999)));
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinitionWhenSuccessful(SubscriptionType subscriptionType)
    {
        Assert.NotNull(_sut.GetUpdateDefinition(new(subscriptionType)));
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinitionWhenModelIsNull()
    {
        Assert.NotNull(_sut.GetUpdateDefinition(null));
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatGetAsyncReturnsSingleModelWhenInputIsValid(SubscriptionType subscriptionType)
    {
        Cursor.Setup(x => x.Current).Returns(new[] { new GenericEntry(subscriptionType) });

        Assert.NotNull(await _sut.GetAsync(subscriptionType));
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatGetLastEntryAsyncReturnsSingleModelWhenInputIsValid(SubscriptionType subscriptionType)
    {
        var id = ObjectId.GenerateNewId().ToString();
        Cursor.Setup(x => x.Current).Returns(new[] { new GenericEntry(subscriptionType) });

        Assert.NotNull(await _sut.GetLastEntryAsync(id, subscriptionType));
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatAnyAsyncReturnsTrueWhenArrayNotEmpty(SubscriptionType subscriptionType)
    {
        Cursor.Setup(x => x.Current).Returns(new[] { new GenericEntry(subscriptionType) });

        var actualData = await _sut.AnyAsync();

        Assert.True(actualData);
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatGetListAsyncReturnsListOfModelsWhenInputIsValid(SubscriptionType subscriptionType)
    {
        var expectedData = new[] { new GenericEntry(subscriptionType), new GenericEntry(subscriptionType) };

        Cursor.Setup(x => x.Current).Returns(expectedData);

        var actualData = await _sut.GetListAsync(subscriptionType);

        Assert.Equal(expectedData, actualData);
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatToListAsyncReturnsListOfModelsWhenSuccessful(SubscriptionType subscriptionType)
    {
        var subscriptionId = ObjectId.GenerateNewId().ToString();
        var expectedData = new[] { new GenericEntry(subscriptionType), new GenericEntry(subscriptionType) };

        Cursor.Setup(x => x.Current).Returns(expectedData);

        var actualData = await _sut.ToListAsync<GenericEntry>(subscriptionId, subscriptionType);

        Assert.Equal(expectedData, actualData);
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatGetListByDatesAsyncReturnsListOfModelsWhenInputIsValid(SubscriptionType subscriptionType)
    {
        var subscriptionId = ObjectId.GenerateNewId().ToString();
        var expectedData = new[] { new GenericEntry(subscriptionType), new GenericEntry(subscriptionType) };

        Cursor.Setup(x => x.Current).Returns(expectedData);

        var actualData = await _sut.GetListByDatesAsync(subscriptionId, subscriptionType);

        Assert.Equal(expectedData, actualData);
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatGetListAsyncReturnsListOfModelsWhenFilterIsValid(SubscriptionType subscriptionType)
    {
        var expectedData = new[] { new GenericEntry(subscriptionType), new GenericEntry(subscriptionType) };

        Cursor.Setup(x => x.Current).Returns(expectedData);

        var actualData = await _sut.GetListAsync(Builders<GenericEntry>.Filter.Empty, null, "dummyCollectionId");

        Assert.Equal(expectedData, actualData);
    }

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public async Task TestThatGetListByAggregationAsyncReturnsListOfModelsWhenPipelineIsValid(SubscriptionType subscriptionType)
    {
        var expectedData = new[] { new GenericEntry(subscriptionType), new GenericEntry(subscriptionType) };

        Cursor.Setup(x => x.Current).Returns(expectedData);

        var actualData = await _sut.GetListByAggregationAsync(new EmptyPipelineDefinition<GenericEntry>(), null, "dummyCollectionId");

        Assert.Equal(expectedData, actualData);
    }

    [Fact]
    public async Task TestThatDeleteListForSubscriptionAsyncReturnsDeleteResultWhenSuccessful()
    {
        _mockedCollection
            .Setup(x => x.DeleteManyAsync(
                It.IsAny<FilterDefinition<GenericEntry>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new DeleteResult.Acknowledged(2));

        var actual = await _sut.DeleteListForSubscriptionAsync(SubscriptionId, SubscriptionType.FB);

        Assert.True(actual);
    }
}