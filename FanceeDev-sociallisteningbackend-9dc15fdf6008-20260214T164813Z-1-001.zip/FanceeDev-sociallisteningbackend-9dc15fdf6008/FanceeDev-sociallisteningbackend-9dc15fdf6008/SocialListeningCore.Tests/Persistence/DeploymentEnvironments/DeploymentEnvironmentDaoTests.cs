using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Persistence.DeploymentEnvironments;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Persistence.DeploymentEnvironments;

public class DeploymentEnvironmentDaoTests
{
    private readonly DeploymentEnvironmentDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<IMongoCollection<DeploymentEnvironment>> _mockedCollection = new();

    public DeploymentEnvironmentDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new(configuration, _mongoDatabase.Object);

        _mongoDatabase
            .Setup(x => x.GetCollection<DeploymentEnvironment>(
                It.IsAny<string>(), null))
            .Returns(_mockedCollection.Object);
    }

    [Fact]
    public async Task TestThatByHostAsyncGetsTheFirstHost()
    {
        var deploymentEnvironments = new List<DeploymentEnvironment>
        {
            new() { Domain = "localhost", Name = "localhost" }
        };

        _mongoDatabase.Mock(deploymentEnvironments);

        var actual = await _sut.ByHostAsync("localhost");

        Assert.NotNull(actual);
        Assert.Equal(deploymentEnvironments.First().Name, actual.Name);
    }
}