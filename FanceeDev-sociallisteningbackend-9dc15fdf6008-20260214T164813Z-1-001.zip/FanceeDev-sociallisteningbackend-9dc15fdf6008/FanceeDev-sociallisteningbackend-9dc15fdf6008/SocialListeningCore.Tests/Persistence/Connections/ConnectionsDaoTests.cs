using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence.Connections;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Persistence.Connections;

public class ConnectionsDaoTests
{
    public readonly Mock<IAsyncCursor<Connection>> Cursor = new();
    private readonly IConnectionsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<IMongoCollection<Connection>> _mockedCollection = new();

    public ConnectionsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new ConnectionsDao(configuration, _mongoDatabase.Object);

        _mongoDatabase
            .Setup(x => x.GetCollection<Connection>(
                It.IsAny<string>(), null))
            .Returns(_mockedCollection.Object);

        _mockedCollection
            .Setup(x => x.FindAsync(
                It.IsAny<FilterDefinition<Connection>>(),
                It.IsAny<FindOptions<Connection>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Cursor.Object);

        Cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        Cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
    }

    [Fact]
    public async Task TestThatCreateAsyncReturnsConnectionWhenSuccessful()
    {
        Connection connection = new()
        {
            Id = ObjectId.GenerateNewId().ToString(),
            SubscriptionId = ObjectId.GenerateNewId().ToString(),
            Data = null,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedCollection
            .SetupSequence(x => x.InsertOneAsync(
                connection,
                It.IsAny<InsertOneOptions>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        var actual = await _sut.CreateAsync(connection);

        Assert.Equal(connection, actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsConnectionWhenSuccessful()
    {
        Connection? connection = new()
        {
            Id = ObjectId.GenerateNewId().ToString(),
            SubscriptionId = ObjectId.GenerateNewId().ToString(),
            Data = null,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        Cursor.Setup(x => x.Current).Returns(new[] { connection });

        var actual = await _sut.GetAsync(connection.Id);

        Assert.Equal(connection, actual);
    }

    [Fact]
    public async Task TestThatGetAsyncThrowsReturnsNullWhenNothingFound()
    {
        Cursor.Setup(x => x.Current).Returns(Array.Empty<Connection>());

        Assert.Null(await _sut.GetAsync(string.Empty));
    }

    [Fact]
    public async Task TestThatToListAsyncReturnsListOfConnectionWhenSuccessful()
    {
        Connection? connection = new()
        {
            Id = ObjectId.GenerateNewId().ToString(),
            SubscriptionId = ObjectId.GenerateNewId().ToString(),
            Data = null,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        Connection[] list = [connection, connection];

        Cursor.Setup(x => x.Current).Returns(list);

        var actual = await _sut.ToListAsync(SubscriptionType.FBPD_PAGE);

        Assert.NotNull(actual);
        Assert.Equal(list, actual);
    }

    [Fact]
    public async Task TestThatUpdateAsyncReturnsConnectionWhenSuccessful()
    {
        Connection? connection = new()
        {
            Id = ObjectId.GenerateNewId().ToString(),
            SubscriptionId = ObjectId.GenerateNewId().ToString(),
            Data = null,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedCollection
            .SetupSequence(x => x.FindOneAndUpdateAsync(
                It.IsAny<FilterDefinition<Connection>>(),
                It.IsAny<UpdateDefinition<Connection>>(),
                It.IsAny<FindOneAndUpdateOptions<Connection>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(connection);

        var actual = await _sut.UpdateAsync(connection);

        Assert.Equal(connection, actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncReturnsTrueWhenSuccessful()
    {
        _mockedCollection
            .SetupSequence(x => x.DeleteOneAsync(
                It.IsAny<FilterDefinition<Connection>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(new DeleteResult.Acknowledged(1));

        var actual = await _sut.DeleteAsync(string.Empty);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncReturnsFalseWhenFailed()
    {
        _mockedCollection
            .SetupSequence(x => x.DeleteOneAsync(
                It.IsAny<FilterDefinition<Connection>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(DeleteResult.Unacknowledged.Instance);

        var actual = await _sut.DeleteAsync(string.Empty);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatToPaginatedListAsyncReturnsSuccessful()
    {
        var mockConnections = new[] { new Connection() };
        var mockResult = new[] { new ResultSetResponse<Connection>(mockConnections) };
        _mongoDatabase.MockPagination(mockResult);

        var request = new DaoRequest();

        var actual = await _sut.ToPaginatedListAsync(request, It.IsAny<int>(), It.IsAny<int>());

        Assert.NotNull(actual);
    }
}