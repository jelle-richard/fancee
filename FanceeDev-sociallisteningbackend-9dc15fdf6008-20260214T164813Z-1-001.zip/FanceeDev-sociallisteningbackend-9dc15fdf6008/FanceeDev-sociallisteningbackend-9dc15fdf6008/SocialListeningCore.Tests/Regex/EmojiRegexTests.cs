using SocialListeningCore.Helpers;

namespace SocialListeningCore.Tests.Regex;

public class EmojiRegexTests
{
    [Fact]
    public void TestThatEmojiRegexReturnsEmojisWhenSuccessful()
    {
        var text = "Spanish music-lovers! 🇪🇸 2ND NIGHT ADDED for Carl Cox & ASW Live showcase on OCTOBER 8th " +
                   "at Auditorio Torremolinos. \r\n\r\nThis time a more intimate show, join our legendary label " +
                   "co-founders Carl Cox & Christopher Coe + a stellar line-up of live electronic artists to be " +
                   "unveiled. Stay tuned and see you on the dancefloor! 🎶\r\n\r\n🎟 ❌ TICKETS ON SALE via " +
                   "https://thisistorremolinos.com/ \r\n\r\n#ASWLive";

        var actual = ConnectionDataHelper.EmojisMatch(text);

        Assert.NotEmpty(actual);
    }

    [Fact]
    public void TestThatEmojiRegexReturnsDistinctEmojisWhenSameEmojiFound()
    {
        var text = "Lorem 😂😂 ipsum";

        var actual = ConnectionDataHelper.EmojisMatch(text);

        Assert.Single(actual);
    }

    [Fact]
    public void TestThatEmojiRegexReturnsCorrectFlagNotSeparatedEmojisWhenFlagEmojiDetected()
    {
        var text = "Spanish music-lovers! 🇪🇸 2ND NIGHT...";

        var actual = ConnectionDataHelper.EmojisMatch(text);

        Assert.Single(actual);
    }

    [Fact]
    public void TestThatEmojiRegexReturnsEmptyWhenNotFound()
    {
        var text = "Lorem ipsum";

        var actual = ConnectionDataHelper.EmojisMatch(text);

        Assert.Empty(actual);
    }
}