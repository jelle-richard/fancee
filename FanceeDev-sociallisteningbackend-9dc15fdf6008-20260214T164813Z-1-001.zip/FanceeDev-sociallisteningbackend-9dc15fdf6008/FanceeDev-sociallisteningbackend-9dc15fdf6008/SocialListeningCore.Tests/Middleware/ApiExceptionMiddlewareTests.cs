using System.Net;
using System.Net.Mime;
using System.Text;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Middleware;

namespace SocialListeningCore.Tests.Middleware;

public class ApiExceptionMiddlewareTests
{
    private readonly Mock<RequestDelegate> _mockedNext = new();
    private readonly Mock<IWebHostEnvironment> _mockedEnvironment = new();
    private readonly Mock<ILogger<ApiExceptionMiddleware>> _mockedLogger = new();
    private ApiExceptionMiddleware _sut;

    public ApiExceptionMiddlewareTests()
    {
        _sut = new(_mockedNext.Object, _mockedEnvironment.Object, _mockedLogger.Object);
    }

    [Fact]
    public async Task TestThatInvokeCallsNextDelegate()
    {
        var next = new Mock<RequestDelegate>();
        var context = new Mock<HttpContext>();

        _sut = new(next.Object, _mockedEnvironment.Object, _mockedLogger.Object);

        await _sut.Invoke(context.Object);

        next.Verify(r => r.Invoke(context.Object));
    }

    [Fact]
    public async Task TestThatInvokeReturnsErrorMessageOnApiException()
    {
        var next = new Mock<RequestDelegate>();
        var context = new DefaultHttpContext();

        next.Setup(r => r.Invoke(context)).Throws(new ApiException { StatusCode = HttpStatusCode.TooManyRequests });

        _sut = new(next.Object, _mockedEnvironment.Object, _mockedLogger.Object);

        await _sut.Invoke(context);

        Assert.Equal(MediaTypeNames.Application.Json, context.Response.ContentType);
        Assert.Equal(HttpStatusCode.TooManyRequests, (HttpStatusCode)context.Response.StatusCode);
    }

    [Fact]
    public async Task TestThatInvokeReturnsErrorMessageOnException()
    {
        var next = new Mock<RequestDelegate>();
        var context = new DefaultHttpContext();

        _mockedEnvironment.Setup(e => e.EnvironmentName).Returns("Production");
        next.Setup(r => r.Invoke(context)).Throws(new Exception());

        _sut = new(next.Object, _mockedEnvironment.Object, _mockedLogger.Object);

        await _sut.Invoke(context);

        var body = Encoding.UTF8.GetString(context.Response.BodyWriter.GetSpan());
        Assert.Equal(MediaTypeNames.Application.Json, context.Response.ContentType);
        Assert.Equal(HttpStatusCode.InternalServerError, (HttpStatusCode)context.Response.StatusCode);
        Assert.Contains("Internal server error", body);
    }

    [Fact]
    public async Task TestThatInvokeReturnsDetailedErrorMessageOnExceptionWhenEnvironmentIsDevelopment()
    {
        var next = new Mock<RequestDelegate>();
        var context = new DefaultHttpContext();

        _mockedEnvironment.Setup(e => e.EnvironmentName).Returns("Development");
        next.Setup(r => r.Invoke(context)).Throws(new Exception("UnitTest"));

        _sut = new(next.Object, _mockedEnvironment.Object, _mockedLogger.Object);

        await _sut.Invoke(context);

        var body = Encoding.UTF8.GetString(context.Response.BodyWriter.GetSpan());
        Assert.Equal(MediaTypeNames.Application.Json, context.Response.ContentType);
        Assert.Equal(HttpStatusCode.InternalServerError, (HttpStatusCode)context.Response.StatusCode);
        Assert.Contains("EXCEPTION (Moq): ", body);
    }

    [Fact]
    public async Task TestThatInvokeThrowsExceptionWhenResponseHasStartedWhenApiExceptionIsThrown()
    {
        var next = new Mock<RequestDelegate>();
        var context = new Mock<HttpContext>();

        context.Setup(h => h.Response.HasStarted).Returns(true);
        next.Setup(r => r.Invoke(context.Object)).Throws<ApiException>();

        _sut = new(next.Object, _mockedEnvironment.Object, _mockedLogger.Object);

        await Assert.ThrowsAsync<ApiException>(async () => await _sut.Invoke(context.Object));
    }

    [Fact]
    public async Task TestThatInvokeThrowsExceptionWhenResponseHasStartedWhenExceptionIsThrown()
    {
        var next = new Mock<RequestDelegate>();
        var context = new Mock<HttpContext>();

        context.Setup(h => h.Response.HasStarted).Returns(true);
        next.Setup(r => r.Invoke(context.Object)).Throws<Exception>();

        _sut = new(next.Object, _mockedEnvironment.Object, _mockedLogger.Object);

        await Assert.ThrowsAsync<Exception>(async () => await _sut.Invoke(context.Object));
    }
}