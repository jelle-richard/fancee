using SocialListeningCore.Dtos.Responses;

namespace SocialListeningCore.Tests.Dtos.Responses;

public class PaginatedResponseTests
{
    [Theory]
    [InlineData(1, 1, 1)]
    [InlineData(5, 4, 1)]
    [InlineData(4, 5, 2)]
    [InlineData(10, 120, 12)]
    public void TestThatPagesCalculatesCorrectly(int pageSize, int totalItems, int expected)
    {
        var response = new PaginatedResponse<object>
        {
            Page = 1,
            PageSize = pageSize,
            TotalItems = totalItems,
            Items = new List<object>()
        };

        Assert.Equal(expected, response.Pages);
    }
}