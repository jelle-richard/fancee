using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Utils;

namespace SocialListeningCore.Tests.Dtos.Responses;

public class ApiResponseTests
{
    private const string ValidKey = "UnitKey";
    private const string ValidMessage = "A message that contains the details of the error";
    private const string UnsetKey = "unittest";

    private readonly ApiResponse<object> _sut;

    public ApiResponseTests()
    {
        _sut = new()
        {
            Data = new(),
            Errors = new Dictionary<string, List<string>>
            {
                { ValidKey, [ValidMessage] }
            }
        };
    }

    [Fact]
    public void TestThatAddErrorWithKeyThatDoesNotExistsCreatesNewEntry()
    {
        _sut.AddError(UnsetKey, "This is a unittest error for testing");

        Assert.NotNull(_sut.Errors);
        Assert.Equal(2, _sut.Errors.Count);
        Assert.Single(_sut.Errors[UnsetKey]);
    }

    [Fact]
    public void TestThatAddErrorWithKeyThatExistsAddsTheErrorToTheList()
    {
        Assert.NotNull(_sut.Errors);
        Assert.Single(_sut.Errors[ValidKey]);

        _sut.AddError(ValidKey, "another error message");

        Assert.Equal(2, _sut.Errors[ValidKey].Count);
    }

    [Fact]
    public void TestThatAddErrorConvertsErrorCodeToFanErrorCode()
    {
        const string actualKey = "FAN-89701";

        _sut.AddError(ErrorCode.ExceptionInvalidData, "Invalid data was provided.");

        Assert.NotNull(_sut.Errors);
        Assert.Single(_sut.Errors[actualKey]);
    }
}