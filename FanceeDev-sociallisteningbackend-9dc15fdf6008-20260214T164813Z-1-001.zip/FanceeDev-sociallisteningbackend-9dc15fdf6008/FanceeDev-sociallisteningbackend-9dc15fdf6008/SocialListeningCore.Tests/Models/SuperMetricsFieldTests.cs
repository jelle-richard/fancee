using FanceeAnalyticsData.Models.Analytics.SuperMetrics;

namespace SocialListeningCore.Tests.Models;

public class SuperMetricsFieldTests
{
    [Fact]
    public void TestThatTransformDateTimeReturnsDateWhenValidFormat()
    {
        Field field = new()
        {
            Data_type = "string.time.datetime",
            Format = ["yyyy-MM-dd HH:mm:ss"]
        };

        var date = field.Transform("2001-02-03 04:05:06");

        Assert.IsType<DateTime>(date);

        var datetime = (DateTime)date!;

        Assert.Equal(2001, datetime.Year);
        Assert.Equal(2, datetime.Month);
        Assert.Equal(3, datetime.Day);

        Assert.Equal(4, datetime.Hour);
        Assert.Equal(5, datetime.Minute);
        Assert.Equal(6, datetime.Second);
    }

    [Fact]
    public void TestThatTransformDateTimeReturnsStringWhenInvalidFormat()
    {
        Field field = new()
        {
            Data_type = "string.time.datetime",
            Format = ["yyyy-MM-dd HH:mm:ss"]
        };

        var date = field.Transform("GiveMeAnError");

        Assert.IsType<string>(date);

        var error = (string)date!;

        Assert.Equal($"ERROR: with type {field.Data_type}: String '' was not recognized as a valid DateTime.", error);
    }

    [Fact]
    public void TestThatTransformDateReturnsDateWhenValidFormat()
    {
        Field field = new()
        {
            Data_type = "string.time.date",
            Format = ["yyyy-MM-dd"]
        };

        var date = field.Transform("2001-02-03");

        Assert.IsType<DateTime>(date);

        var datetime = (DateTime)date!;

        Assert.Equal(2001, datetime.Year);
        Assert.Equal(2, datetime.Month);
        Assert.Equal(3, datetime.Day);
    }

    [Fact]
    public void TestThatTransformDateReturnsStringWhenInvalidFormat()
    {
        Field field = new()
        {
            Data_type = "string.time.date",
            Format = ["yyyy-MM-dd"]
        };

        var date = field.Transform("GiveMeAnError");
        Assert.IsType<string>(date);
        var error = (string)date!;

        Assert.Equal($"ERROR: with type {field.Data_type}: String '' was not recognized as a valid DateTime.", error);
    }

    [Theory]
    [InlineData("float.currency.value", 14.6d)]
    [InlineData("float.number.percentage", 14.6d)]
    [InlineData("float.number.ratio", 14.6d)]
    [InlineData("float.number.value", 14.6d)]
    public void TestThatTransformDoubleReturnsDoubleWhenValid(string type, double value)
    {
        Test<double>(type, value);
    }

    [Theory]
    [InlineData("float.currency.value", "error")]
    [InlineData("float.number.percentage", "error")]
    [InlineData("float.number.ratio", "error")]
    [InlineData("float.number.value", "error")]
    public void TestThatTransformDoubleReturnsNullWhenValueIsString(string type, string value)
    {
        TestNull(type, value);
    }

    [Theory]
    [InlineData("int.currency.value", 123)]
    [InlineData("int.duration.seconds", 123)]
    [InlineData("int.number.percentage", 123)]
    [InlineData("int.number.value", 123)]
    public void TestThatTransformIntReturnsIntWhenValid(string type, int value)
    {
        Test<int>(type, value);
    }

    [Theory]
    [InlineData("int.currency.value", "")]
    [InlineData("int.duration.seconds", "")]
    [InlineData("int.number.percentage", "")]
    [InlineData("int.number.value", "")]
    public void TestThatTransformIntReturnsNullWhenInvalid(string type, dynamic value)
    {
        TestNull(type, value);
    }

    [Fact]
    public void TestThatTransformGeoDoubleReturnsDoubleWhenValid()
    {
        Test<double>("string.geo.latitude", 66.538d);
        Test<double>("string.geo.longitude", 66.538d);
    }

    [Fact]
    public void TestThatTransformGeoStringReturnsStringWhenValid()
    {
        Test<string>("string.geo.latitude", "66.538");
        Test<string>("string.geo.longitude", "66.538");
    }

    [Theory]
    [InlineData("bool", true)]
    [InlineData("bool", false)]
    public void TestThatTransformBoolReturnsBoolWhenValid(string type, bool value)
    {
        Test<bool>(type, value);
    }

    [Fact]
    public void TestThatTransformUnknownTypeReturnsNullWhenUnknown()
    {
        TestNull("unknownTypeString", "dummy");
    }

    [Theory]
    [InlineData("string.currency.code", "test")]
    [InlineData("string.geo.city", "test")]
    [InlineData("string.geo.continent", "test")]
    [InlineData("string.geo.coordinates", "test")]
    [InlineData("string.geo.country", "test")]
    [InlineData("string.geo.country.twolettercode", "test")]
    [InlineData("string.geo.metro", "test")]
    [InlineData("string.geo.region", "test")]
    [InlineData("string.geo.street", "test")]
    [InlineData("string.geo.zip", "test")]
    [InlineData("string.language.locale", "test")]
    [InlineData("string.language.twolettercode", "test")]
    [InlineData("string.language.value", "test")]
    [InlineData("string.person.age", "test")]
    [InlineData("string.person.gender", "test")]
    [InlineData("string.text.email", "test")]
    [InlineData("string.text.json", "test")]
    [InlineData("string.text.percentage", "test")]
    [InlineData("string.text.phone", "test")]
    [InlineData("string.text.url", "test")]
    [InlineData("string.text.value", "test")]
    [InlineData("string.time.dayofmonth", "test")]
    [InlineData("string.time.dayofweek", "test")]
    [InlineData("string.time.dayofweekiso", "test")]
    [InlineData("string.time.gmtoffset", "test")]
    [InlineData("string.time.hm", "test")]
    [InlineData("string.time.hms", "test")]
    [InlineData("string.time.hour", "test")]
    [InlineData("string.time.minute", "test")]
    [InlineData("string.time.month", "test")]
    [InlineData("string.time.quarter", "test")]
    [InlineData("string.time.timezone", "test")]
    [InlineData("string.time.week", "test")]
    [InlineData("string.time.weekiso", "test")]
    [InlineData("string.time.year", "test")]
    [InlineData("string.time.yearmonth", "test")]
    [InlineData("string.time.yearweek", "test")]
    [InlineData("string.time.yearweekiso", "test")]
    public void TestThatTransformStringReturnsStringWhenValid(string type, string value)
    {
        Test<string>(type, value);
    }

    private static void Test<TDataType>(string datatype, dynamic value)
    {
        Field field = new() { Data_type = datatype };
        object? transformedValue = field.Transform(value);
        Assert.IsType<TDataType>(transformedValue);
        Assert.Equal(value, transformedValue);
    }

    private static void TestNull(string datatype, dynamic value)
    {
        Field field = new() { Data_type = datatype };
        object? transformedValue = field.Transform(value);
        Assert.Null(transformedValue);
    }
}