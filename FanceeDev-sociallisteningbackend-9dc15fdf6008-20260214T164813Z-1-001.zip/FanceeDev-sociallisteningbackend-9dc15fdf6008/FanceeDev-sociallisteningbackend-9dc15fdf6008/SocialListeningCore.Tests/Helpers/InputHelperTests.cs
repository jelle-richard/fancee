using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Helpers;

public class InputHelperTests
{
    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public void TestThatToInputReturnsSubscriptionTypeWhenSuccessful(SubscriptionType type)
    {
        var actual = type.ToInput();

        Assert.True(actual != null);
        Assert.IsType<Input>(actual);
        Assert.NotNull(actual.DsId);
    }

    [Fact]
    public void TestThatToInputThrowsSubscriptionTypeNotSupportedExceptionWhenSubscriptionTypeNotSupport()
    {
        var subscriptionType = (SubscriptionType)int.MaxValue;

        Assert.Throws<SubscriptionTypeNotSupportedException>(() => subscriptionType.ToInput());
    }
}