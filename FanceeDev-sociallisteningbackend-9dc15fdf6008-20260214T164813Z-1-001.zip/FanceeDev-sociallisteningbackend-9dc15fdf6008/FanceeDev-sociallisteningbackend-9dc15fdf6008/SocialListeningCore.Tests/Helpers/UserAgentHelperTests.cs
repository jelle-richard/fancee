using Microsoft.AspNetCore.Http;
using SocialListeningCore.Helpers;

namespace SocialListeningCore.Tests.Helpers;

public class UserAgentHelperTests
{
    [Fact]
    public void TestThatGetDeviceFromHeadersReturnsNullWhenHeadersAreNull()
    {
        var actual = UserAgentHelper.GetDeviceFromHeaders(null);

        Assert.Null(actual);
    }

    [Fact]
    public void TestThatGetDeviceFromHeadersReturnsNullWhenUserAgentHeaderIsMissing()
    {
        var actual = UserAgentHelper.GetDeviceFromHeaders(new HeaderDictionary());

        Assert.Null(actual);
    }

    [Fact]
    public void TestThatGetDeviceFromHeadersReturnsCorrectDeviceStringWhenSuccessful()
    {
        var headers = new HeaderDictionary
        {
            { "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0" }
        };

        var actual = UserAgentHelper.GetDeviceFromHeaders(headers);

        Assert.Equal("Firefox 75.0 (Windows 10)", actual);
    }
}