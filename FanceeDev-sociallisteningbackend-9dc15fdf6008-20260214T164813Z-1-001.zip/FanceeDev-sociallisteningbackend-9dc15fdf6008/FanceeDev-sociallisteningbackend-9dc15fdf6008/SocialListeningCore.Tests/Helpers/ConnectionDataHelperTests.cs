using System.Dynamic;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Helpers;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Helpers;

public class ConnectionDataHelperTests
{
    private const string MockMessage = "MEDIA #hashtag @Mention Mock message for testing purposes";

    [Theory]
    [MemberData(nameof(SubscriptionTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public void TestThatEnrichDataWorksForEveryType(SubscriptionType subscriptionType)
    {
        var data = MockData(subscriptionType);
        var actual = ConnectionDataHelper.EnrichData(data, subscriptionType);

        Assert.NotNull(actual);
    }

    [Fact]
    public void TestThatEnrichDataLinkedInCountryWorksWhenCountryIsUnknown()
    {
        var data = MockData(SubscriptionType.LIP_COUNTRY);
        data.follower_country = "UnsupportedCountryName";

        BsonDocument actual = ConnectionDataHelper.EnrichData(data, SubscriptionType.LIP_COUNTRY);

        Assert.NotNull(actual);
        Assert.Equal(BsonNull.Value, actual.GetValue("countryCode"));
    }

    private static dynamic MockData(SubscriptionType subscriptionType)
    {
        dynamic x = new ExpandoObject();
        x.date = DateTime.Now;
        x.Date = DateTime.Now;
        x.today = DateTime.Now;

        switch (subscriptionType)
        {
            case SubscriptionType.FB_POSTS:
                x.post_created_time_of_day = "12:34:56";
                x.post_message = MockMessage;
                break;

            case SubscriptionType.FBPD_POSTS:
                x.updated_time = DateTime.Now;
                x.message = MockMessage;
                break;

            case SubscriptionType.TIKBA_PROFILE:
                x.profile__date = DateTime.Now;
                break;

            case SubscriptionType.TIKBA_VIDEO:
                x.videos__create_date = DateTime.Now;
                x.videos__create_datetime = DateTime.Now;
                x.videos__caption = MockMessage;
                break;

            case SubscriptionType.IGI_MEDIA:
                x.timestamp = DateTime.Now;
                x.media_caption = MockMessage;
                break;

            case SubscriptionType.YT2_VIDEO:
                x.video_published_at = DateTime.Now;
                x.video_description = MockMessage;
                break;

            case SubscriptionType.YT2_GEO:
                x.country = "Netherlands";
                break;

            case SubscriptionType.LIP_POST:
                x.update_title = MockMessage;
                break;

            case SubscriptionType.LIP_COUNTRY:
                x.follower_country = "Netherlands";
                break;
        }

        return x;
    }
}