using Fs.MessageBus.Utils.Rabbit;
using RabbitMQ.Client;
using SocialListeningCore.MessageBus.Publishers;

namespace SocialListeningCore.Tests.MessageBus.Publishers;

public class AddMailPublisherTests
{
    [Fact]
    public void TestThatAddMailPublisherSetsTheCorrectOptions()
    {
        var mockedModel = new Mock<IModel>();
        var mockedConnection = new Mock<IConnection>();
        mockedConnection.Setup(c => c.CreateModel()).Returns(mockedModel.Object);

        var sut = new AddMailPublisher(mockedConnection.Object);
        
        var options = sut.Options;

        Assert.Equal(RabbitConfig.Exchanges.Default, options.Exchange);
        Assert.Equal(RabbitConfig.RoutingKeys.AddMail, options.RoutingKey);
        Assert.Equal(RabbitConfig.Queues.AddMail, options.QueueOptions.Name);
        Assert.Null(sut.Options.CorrelationId);
        Assert.Null(sut.Options.ReplyTo);
    }
}