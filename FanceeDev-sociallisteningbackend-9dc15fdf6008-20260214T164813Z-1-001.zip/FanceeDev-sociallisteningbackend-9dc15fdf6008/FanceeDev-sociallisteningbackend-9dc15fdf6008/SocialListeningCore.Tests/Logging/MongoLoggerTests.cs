using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Logging;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Logging;

public class MongoLoggerTests
{
    private static readonly Guid UserId = Guid.Empty;
    private readonly Mock<IMongoCollection<Log>> _mockedMongoCollection = new();
    private readonly LoggerFactory _factory = new();

    private readonly ILogger _logger;

    public MongoLoggerTests()
    {
        _factory.AddProvider(new MongoLoggerProvider(new(string.Empty, _mockedMongoCollection.MockLogClient().Object)));

        _logger = _factory.CreateLogger(MongoLogger.Name);
    }

    [Fact]
    public void TestThatLoggerCallsMongoInsertOneWhenSetupIsOk()
    {
        var log = _logger.MongoLogInfo(UserId, "My Testing Message");
        _mockedMongoCollection.Verify(c => c.InsertOne(log,
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }
}