using Microsoft.Extensions.Configuration;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Tests.Settings;

public class OrganizationDetailsSettingsTests
{
    [Fact]
    public void TestThatFromConfigurationGetsSettingsFromConfiguration()
    {
        var properties = new Dictionary<string, string>
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:Website", "UnitTest@mail.com" },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:PlatformName", "UnitTest (test)" }
        };

        var configuration = new ConfigurationBuilder().AddInMemoryCollection(properties!).Build();

        var actual = OrganizationDetailsSettings.FromConfiguration(configuration);

        Assert.Equal("UnitTest B.V.", actual.Name);
        Assert.Equal("UnitTest@mail.com", actual.Website);
        Assert.Equal("83493845", actual.ChamberOfCommerceIdentifier);
        Assert.Equal("NL92TEST483399991243", actual.Iban);
        Assert.Equal("3582935", actual.VatCode);
        Assert.Equal("EUR", actual.PlatformBaseCurrency);
        Assert.Equal("Hamburgerstraße", actual.Address.Street);
        Assert.Equal("843-855", actual.Address.HouseNumber);
        Assert.Equal("4921DB", actual.Address.PostalCode);
        Assert.Equal("München", actual.Address.City);
        Assert.Equal("DE", actual.Address.CountryCode);
        Assert.Equal("UnitTest (test)", actual.PlatformName);
        Assert.Null(actual.Socials.FacebookUrl);
        Assert.Null(actual.Socials.TwitterUrl);
        Assert.Null(actual.Socials.InstagramUrl);
    }

    [Fact]
    public void TestThatFromConfigurationHandlesOptionalParameters()
    {
        var properties = new Dictionary<string, string>
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:Socials:FacebookUrl", "https://facebook.com/unit_test" },
            { "OrganizationDetails:Socials:TwitterUrl", "https://twitter.com/unit_test" },
            { "OrganizationDetails:Socials:InstagramUrl", "https://instagram.com/unit_test" }
        };

        var configuration = new ConfigurationBuilder().AddInMemoryCollection(properties!).Build();

        var actual = OrganizationDetailsSettings.FromConfiguration(configuration);

        Assert.Null(actual.ChamberOfCommerceIdentifier);
        Assert.Null(actual.VatCode);
        Assert.Equal("https://facebook.com/unit_test", actual.Socials.FacebookUrl);
        Assert.Equal("https://twitter.com/unit_test", actual.Socials.TwitterUrl);
        Assert.Equal("https://instagram.com/unit_test", actual.Socials.InstagramUrl);
    }

    [Fact]
    public void TestThatFromConfigurationThrowsMissingRequiredConfigurationEntryExceptionOnMissingSection()
    {
        var configuration = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string>()!).Build();

        Assert.Throws<MissingRequiredConfigurationEntryException>(() => OrganizationDetailsSettings.FromConfiguration(configuration));
    }
}