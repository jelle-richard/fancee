using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Tests.Settings;

public class CollectionSettingsTests
{
    [Theory]
    [InlineData("Channels", "channels")]
    [InlineData("Subscriptions", "subscriptions")]
    public void TestThatGetCollectionNameReturnsCollectionName(string key, string name)
    {
        var actual = CollectionSettings.GetCollectionName(key);

        Assert.Equal(actual, name);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_POSTS, "entries_fb_posts")]
    [InlineData(SubscriptionType.IGI_MEDIA, "entries_igi_media")]
    public void TestThatGetCollectionNameBySubscriptionTypeReturnsCollectionName(SubscriptionType key, string name)
    {
        var actual = CollectionSettings.GetCollectionName(key);

        Assert.Equal(actual, name);
    }

    [Fact]
    public void TestThatGetCollectionNameThrowsKeyNotFoundExceptionWhenKeyNotFound()
    {
        Assert.Throws<KeyNotFoundException>(() => CollectionSettings.GetCollectionName("UnknownCollection"));
    }

    [Fact]
    public void TestThatAddCollectionAddsNewItemToCollectionsWhenSuccessful()
    {
        CollectionSettings.AddCollection("newCollection", "newCollectionName");

        var collectionName = CollectionSettings.GetCollectionName("newCollection");

        Assert.Equal("newCollectionName", collectionName);
    }

    [Fact]
    public void TestThatAddCollectionThrowsArgumentExceptionWhenCollectionAlreadyExists()
    {
        CollectionSettings.AddCollection("myCollection", "myCollectionName");

        Assert.Throws<ArgumentException>(() => CollectionSettings.AddCollection("myCollection", "myCollection"));
    }

    [Fact]
    public void TestThatUpdateColletionUpdatesCollectionNameWhenSuccessful()
    {
        CollectionSettings.AddCollection("myFanceeCollection", "myFanceeCollectionName");
        CollectionSettings.UpdateCollection("myFanceeCollection", "newFanceeCollectionName");

        var updatedCollectionName = CollectionSettings.GetCollectionName("myFanceeCollection");

        Assert.Equal("newFanceeCollectionName", updatedCollectionName);
    }

    [Fact]
    public void TestThatUpdateCollectionThrowsKeyNotFoundExceptionWhenCollectionNotFound()
    {
        Assert.Throws<KeyNotFoundException>(() => CollectionSettings.UpdateCollection("UnknownCollection", "myCollectionName"));
    }

    [Fact]
    public void TestThatRemoveColletionRemovesCollectionWhenSuccessful()
    {
        CollectionSettings.AddCollection("myWrongCollection", "myWrongCollectionName");
        CollectionSettings.RemoveCollection("myWrongCollection");

        Assert.Throws<KeyNotFoundException>(() => CollectionSettings.GetCollectionName("myWrongCollection"));
    }

    [Fact]
    public void TestThatRemoveCollectionThrowsKeyNotFoundExceptionWhenCollectionNotFound()
    {
        Assert.Throws<KeyNotFoundException>(() => CollectionSettings.RemoveCollection("UnknownCollection"));
    }
}