using Microsoft.AspNetCore.Hosting;
using SocialListeningCore.Settings;

namespace SocialListeningCore.Tests.Settings;

public class SharedSettingsTests
{
    [Fact]
    public void TestThatAddSharedSettingsReturnsBuildWhenBuildIsNull()
    {
        WebHostBuilder? builder = null;

        var actual = builder?.AddSharedSettings("sharedsettings.json");

        Assert.Null(actual);
        Assert.Equal(builder, actual);
    }

    [Fact]
    public void TestThatAddSharedSettingsReturnsBuildWhenSharedFileNameIsNullOrEmpty()
    {
        var builder = new WebHostBuilder();

        var actual = builder.AddSharedSettings(string.Empty);

        Assert.NotNull(actual);
        Assert.Equal(builder, actual);
    }

    [Fact]
    public void TestThatAddSharedSettingsAddsConfigurationSources()
    {
        var builder = new WebHostBuilder();

        var actual = builder.AddSharedSettings("sharedsettings.json");

        Assert.NotNull(actual);
    }
}