using SocialListeningCore.Utils.Country;

namespace SocialListeningCore.Tests.Utils.Country;

public static class CountryUtilsTests
{
    [Fact]
    public static void TestThatConsecutiveCallsToCountryReturnThePreviousResults()
    {
        var expected = CountryUtils.Countries();
        var actual = CountryUtils.Countries();

        Assert.Equal(expected, actual);
    }

    [Fact]
    public static void TestThatGetCountryCodeReturnsNullWhenInvalid() => Assert.Null(CountryUtils.GetCountryCode("InvalidCountryName"));
}