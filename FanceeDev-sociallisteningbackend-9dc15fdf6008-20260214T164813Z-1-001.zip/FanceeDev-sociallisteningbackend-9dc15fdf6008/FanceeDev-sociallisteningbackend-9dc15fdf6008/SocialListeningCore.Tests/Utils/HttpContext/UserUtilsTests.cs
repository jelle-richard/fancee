using System.Security.Claims;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Utils.HttpContext;

namespace SocialListeningCore.Tests.Utils.HttpContext;

public class UserUtilsTests
{
    [Fact]
    public void TestThatGetUserIdReturnsNullWhenUserClaimIsNotFound()
    {
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new List<Claim>()));

        Assert.Throws<UserNotFoundException>(() => principal.GetUserId());
    }

    [Fact]
    public void TestThatGetUserTypeReturnsNullOnInvalidClaimsPrincipal()
    {
        ClaimsPrincipal? principal = null;

        // ReSharper disable once ExpressionIsAlwaysNull
        Assert.Null(principal!.GetUserType());
    }

    [Fact]
    public void TestThatGetUserTypeReturnsNullWhenUserTypeClaimIsNotFound()
    {
        var principal = new ClaimsPrincipal(new ClaimsIdentity(Enumerable.Empty<Claim>()));

        Assert.Null(principal.GetUserType());
    }

    [Theory]
    [InlineData("invalid")]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("  ")]
    public void TestThatGetUserTypeReturnsNullOnInvalidEnumValue(string claimValue)
    {
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim("type", claimValue)
        }));

        Assert.Null(principal.GetUserType());
    }

    [Theory]
    [InlineData(UserType.Organization)]
    [InlineData(UserType.Admin)]
    public void TestThatGetUserTypeReturnsUserType(UserType claimValue)
    {
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim("type", claimValue.ToString())
        }));

        Assert.Equal(claimValue, principal.GetUserType());
    }

    [Fact]
    public void TestThatGetUsersIdReturnsUserClaim()
    {
        var userId = Guid.NewGuid();

        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim("platformUserId", userId.ToString())
        }));

        Assert.Equal(userId, principal.GetUserId());
    }

    [Fact]
    public void TestThatGetFanceeUsersIdReturnsUserClaim()
    {
        var userId = Guid.NewGuid();

        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim("user", userId.ToString())
        }));

        Assert.Equal(userId, principal.GetFanceeUsersId());
    }

    [Fact]
    public void TestThatGetFanceeUsersIdThrowsUserNotFoundExceptionOnInvalidClaim()
    {
        var principal = new ClaimsPrincipal(new ClaimsIdentity(new[]
        {
            new Claim("user", "invalid")
        }));

        Assert.Throws<UserNotFoundException>(() => principal.GetFanceeUsersId());
    }
}