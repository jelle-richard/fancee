using MailTemplates.Models;
using SocialListeningCore.Settings;
using SocialListeningCore.Utils.Mail;

namespace SocialListeningCore.Tests.Utils.Mail;

public class MailUtilsTests
{
    [Fact]
    public void TestThatGetSocialMediaInfoReturnsEmptyObjectOnInvalidSocialMediaSettings()
    {
        var details = new OrganizationDetailsSettings();

        var actual = MailUtils.GetSocialMediaInfo(details, "http://unit.test");

        Assert.Empty(actual);
    }

    [Theory]
    [InlineData(null, null, null, 0)]
    [InlineData("https://facebook.com/unittest", null, null, 1)]
    [InlineData(null, "https://twitter.com/unittest", null, 1)]
    [InlineData(null, null, "https://instagram.com/unittest", 1)]
    [InlineData("https://facebook.com/unittest", null, "https://instagram.com/unittest", 2)]
    [InlineData("https://facebook.com/unittest", "https://twitter.com/unittest", "https://instagram.com/unittest", 3)]
    [InlineData(null, "https://twitter.com/unittest", "https://instagram.com/unittest", 2)]
    public void TestThatGetSocialMediaInfoSetsTheCorrectValues(string facebookUrl, string twitterUrl, string instagramUrl, int expectedCount)
    {
        var details = new OrganizationDetailsSettings
        {
            Socials = new()
            {
                FacebookUrl = facebookUrl,
                TwitterUrl = twitterUrl,
                InstagramUrl = instagramUrl
            }
        };

        var actual = MailUtils.GetSocialMediaInfo(details, "http://unit.test").ToList();

        Assert.Equal(expectedCount, actual.Count);

        if (facebookUrl != null)
            Assert.Equal("http://unit.test/assets/images/logos/socials/facebook.png", actual.FirstOrDefault(x => x.Name == "Facebook")?.LogoUrl);

        if (twitterUrl != null)
            Assert.Equal("http://unit.test/assets/images/logos/socials/twitter.png", actual.FirstOrDefault(x => x.Name == "Twitter")?.LogoUrl);

        if (instagramUrl != null)
            Assert.Equal("http://unit.test/assets/images/logos/socials/instagram.png", actual.FirstOrDefault(x => x.Name == "Instagram")?.LogoUrl);
    }

    [Fact]
    public void TestThatSetDefaultValuesSetsDefaultValues()
    {
        var model = new UnitTestMailModel();
        var details = new OrganizationDetailsSettings
        {
            PlatformName = "UnitTest",
            Socials = new() { TwitterUrl = "https://twitter.com/unittest" }
        };

        var actual = (UnitTestMailModel)model.SetDefaultValues("Test mail", details, "http://unit.test");

        Assert.Equal("Test mail", actual.Title);
        Assert.Equal("UnitTest", actual.PlatformName);
        Assert.Equal("http://unit.test/assets/images/logos/platform.png", actual.PlatformLogoUrl);
        Assert.Equal("http://unit.test", actual.PlatformUrl);
        Assert.Equal("https://twitter.com/unittest", actual.Socials.First().Url);
    }

    #region Unit Test Classes

    public class UnitTestMailModel : MailModel
    {
    }

    #endregion
}