using SocialListeningCore.Utils.String;

namespace SocialListeningCore.Tests.Utils.Strings;

public class StringUtilsTests
{
    [Theory]
    [InlineData("unit", "Unit")]
    [InlineData("uNIT", "UNIT")]
    [InlineData("", "")]
    [InlineData("  ", "  ")]
    [InlineData(" unit", " unit")]
    [InlineData("1unit", "1unit")]
    [InlineData("\tunit", "\tunit")]
    public void TestThatUcFirstProducesExpectedResult(string input, string expected)
    {
        var actual = input.UcFirst();

        Assert.Equal(expected, actual);
    }
}