using Microsoft.AspNetCore.Mvc.ModelBinding;
using SocialListeningCore.Utils.Validation;

namespace SocialListeningCore.Tests.Utils.Validation;

public class ModelStateUtilsTests
{
    [Fact]
    public void TestThatToDictionaryListReturnsListWithErrors()
    {
        var modelState = new ModelStateDictionary();
        modelState.AddModelError("prop1", "prop1 is required");
        modelState.AddModelError("prop2", "Max length of prop2 is 20");
        modelState.AddModelError("prop2", "Min length of prop2 is 19");
        modelState.AddModelError("$.test", "Error occurred");

        var actual = modelState.ToDictionaryList();

        Assert.NotEmpty(actual);
        Assert.Single(actual["Prop1"]);
        Assert.Equal(2, actual["Prop2"].Count);
        Assert.Single(actual["Test"]);
    }

    [Fact]
    public void TestThatToDictionaryListReturnsEmptyListWhenNoErrorsAreFound()
    {
        var modelState = new ModelStateDictionary();
        modelState.AddModelError("key", "");
        modelState["key"]!.Errors.Clear();

        var actual = modelState.ToDictionaryList();

        Assert.Empty(actual);
    }
}