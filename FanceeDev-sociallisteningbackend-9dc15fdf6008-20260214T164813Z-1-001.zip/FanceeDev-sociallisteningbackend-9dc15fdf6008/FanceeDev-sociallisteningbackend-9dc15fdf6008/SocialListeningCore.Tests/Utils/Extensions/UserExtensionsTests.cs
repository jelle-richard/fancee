using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Utils.Extensions;

namespace SocialListeningCore.Tests.Utils.Extensions;

public class UserExtensionsTests
{
    [Fact]
    public void TestThatToResponseReturnsUserResponse()
    {
        var user = new User
        {
            FanceeUsersId = Guid.NewGuid(),
            OrganizationId = "OrgId",
            Type = UserType.Organization,
            Email = "user@mail.com",
            FirstName = "Jan",
            LastName = "Piet",
            LastLogin = DateTime.Now,
            CreatedOn = DateTime.Now.AddDays(-2),
            UpdatedOn = DateTime.Now.AddDays(-1),
            IsVerified = true
        };

        var actual = user.ToResponse();

        Assert.Equal(actual.Id, user.FanceeUsersId);
        Assert.Equal(actual.OrganizationId, user.OrganizationId);
        Assert.Equal(actual.Type, user.Type);
        Assert.Equal(actual.Email, user.Email);
        Assert.Equal(actual.FirstName, user.FirstName);
        Assert.Equal(actual.LastName, user.LastName);
        Assert.Null(actual.AvatarFilePath);
        Assert.Equal(actual.LastLogin, user.LastLogin);
        Assert.Equal(actual.CreatedOn, user.CreatedOn);
        Assert.Equal(actual.UpdatedOn, user.UpdatedOn);
        Assert.True(actual.IsVerified);
    }
}