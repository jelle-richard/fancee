using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Utils.Extensions;
using TestCore.Utils.UnitTestsHelpers;

namespace SocialListeningCore.Tests.Utils.Extensions;

public class ChannelTypeExtensionsTests
{
    [Theory]
    [MemberData(nameof(ChannelTypeMember.Data), MemberType = typeof(ChannelTypeMember))]
    public void TestThatToSubscriptionTypesReturnsListOfRelatedSubscriptionType(ChannelType channelType) => Assert.NotEmpty(channelType.ToSubscriptionTypes());

    [Theory]
    [MemberData(nameof(ChannelTypeMember.Data), MemberType = typeof(ChannelTypeMember))]
    public void TestThatToDSidReturns(ChannelType channelType) => Assert.NotEmpty(channelType.ToDSID());

    [Theory]
    [MemberData(nameof(ChannelTypeMember.Data), MemberType = typeof(SubscriptionTypeMember))]
    public void TestThatToToDefaultDateRangeTypeReturns(SubscriptionType subscriptionType) => Assert.NotEmpty(subscriptionType.ToDefaultDateRangeType());

    [Fact]
    public void TestThatToDSidThrowNotSupportExceptionWhenInvalid() => Assert.Throws<ChannelTypeNotSupportedException>(() => ((ChannelType)(-1)).ToDSID());

    [Fact]
    public void TestThatToSubscriptionTypesThrowNotSupportExceptionWhenChannelTypeNotSupported() => Assert.Throws<ChannelTypeNotSupportedException>(() => ((ChannelType)int.MaxValue).ToSubscriptionTypes());

    [Theory]
    [InlineData(SubscriptionType.FA_CAMPAIGN)]
    [InlineData(SubscriptionType.FA_AGE_AND_GENDER)]
    [InlineData(SubscriptionType.FA_ADS)]
    [InlineData(SubscriptionType.FA_CONVERSION)]
    [InlineData(SubscriptionType.FA_GEO)]
    [InlineData(SubscriptionType.FA_VIDEO)]
    public void TestThatToChannelTypeReturnsFacebookAds(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.FACEBOOKADS, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.FB)]
    [InlineData(SubscriptionType.FB_POSTS)]
    [InlineData(SubscriptionType.FB_GEO_LIKES)]
    [InlineData(SubscriptionType.FB_AGE_AND_GENDER)]
    public void TestThatToChannelTypeReturnsFacebook(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.FACEBOOK, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.FBPD_PAGE)]
    [InlineData(SubscriptionType.FBPD_POSTS)]
    [InlineData(SubscriptionType.FBPD_URL_SHARES)]
    public void TestThatToChannelTypeReturnsFacebookPublicData(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.FACEBOOKPUBLICDATA, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.IGI)]
    [InlineData(SubscriptionType.IGI_CITY)]
    [InlineData(SubscriptionType.IGI_COUNTRY)]
    [InlineData(SubscriptionType.IGI_AGE_AND_GENDER)]
    [InlineData(SubscriptionType.IGI_MEDIA)]
    [InlineData(SubscriptionType.IGI_PROFILE_DATA)]
    public void TestThatToChannelTypeReturnsInstagram(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.INSTAGRAM, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.IGPD2_POSTS)]
    [InlineData(SubscriptionType.IGPD2_HASHTAGS)]
    [InlineData(SubscriptionType.IGPD2_PROFILES)]
    public void TestThatToChannelTypeReturnsInstagramPublicData(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.INSTAGRAMPUBLICDATA, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.GA_TRAFFIC)]
    [InlineData(SubscriptionType.GA_PAID_TRAFFIC)]
    [InlineData(SubscriptionType.GA_SEARCH)]
    [InlineData(SubscriptionType.GA_USER)]
    [InlineData(SubscriptionType.GA_TECHNOLOGY)]
    [InlineData(SubscriptionType.GA_CONTENT)]
    [InlineData(SubscriptionType.GA_ECOMMERCE)]
    [InlineData(SubscriptionType.GA_SOCIAL)]
    [InlineData(SubscriptionType.GA_EVENTS)]
    public void TestThatToChannelTypeReturnsGoogleAnalytics(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.GOOGLEANALYTICS, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.GAWA)]
    [InlineData(SubscriptionType.GAWA_DEVICE)]
    [InlineData(SubscriptionType.GAWA_ECOM_ITEMS)]
    [InlineData(SubscriptionType.GAWA_ENGAGEMENT)]
    [InlineData(SubscriptionType.GAWA_PUBLISHING)]
    [InlineData(SubscriptionType.GAWA_TRAFFIC_ACQUISITION)]
    [InlineData(SubscriptionType.GAWA_USER_ACQUISITION)]
    public void TestThatToChannelTypeReturnsGoogleAnalytics4(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.GOOGLEANALYTICS4, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.GT)]
    public void TestThatToChannelTypeReturnsGoogleTrends(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.GOOGLETRENDS, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.YT_VIDEO)]
    public void TestThatToChannelTypeReturnsYoutube(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.YOUTUBE, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.YT2_AD_PERFORMANCE)]
    [InlineData(SubscriptionType.YT2_CHANNEL)]
    [InlineData(SubscriptionType.YT2_DEMOGRAPHIC)]
    [InlineData(SubscriptionType.YT2_DEVICE)]
    [InlineData(SubscriptionType.YT2_GEO)]
    [InlineData(SubscriptionType.YT2_TRAFFIC_SOURCE)]
    [InlineData(SubscriptionType.YT2_VIDEO)]
    public void TestThatToChannelTypeReturnsYoutubeV2(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.YOUTUBEV2, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.LIP_COUNTRY)]
    [InlineData(SubscriptionType.LIP_PAGE)]
    [InlineData(SubscriptionType.LIP_POST)]
    public void TestThatToChannelTypeReturnsLinkedIn(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.LINKEDIN, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.AW_AD)]
    [InlineData(SubscriptionType.AW_AGE)]
    [InlineData(SubscriptionType.AW_CAMPAIGN)]
    [InlineData(SubscriptionType.AW_CONVERSION)]
    [InlineData(SubscriptionType.AW_GENDER)]
    [InlineData(SubscriptionType.AW_GEO)]
    [InlineData(SubscriptionType.AW_KEYWORD)]
    [InlineData(SubscriptionType.AW_PLACEMENT)]
    [InlineData(SubscriptionType.AW_SEARCH_QUERY)]
    [InlineData(SubscriptionType.AW_SHOPPING)]
    public void TestThatToChannelTypeReturnsGoogleAds(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.GOOGLEADS, subscriptionType.ToChannelType());

    [Theory]
    [InlineData(SubscriptionType.TIKBA_VIDEO)]
    [InlineData(SubscriptionType.TIKBA_GENDER)]
    [InlineData(SubscriptionType.TIKBA_COUNTRY)]
    [InlineData(SubscriptionType.TIKBA_PROFILE)]
    public void TestThatToChannelTypeReturnsTikTok(SubscriptionType subscriptionType) => Assert.Equal(ChannelType.TIKTOK, subscriptionType.ToChannelType());

    [Fact]
    public void TestThatToChannelTypeThrowsNotSupportExceptionWhenSubscriptionTypeNotSupport() => Assert.Throws<SubscriptionTypeNotSupportedException>(() => ((SubscriptionType)int.MaxValue).ToChannelType());
}