using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Responses;
using SuperMetricsService.Controllers;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Dtos.Requests.Sum;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Dtos.Responses.Sum;
using SuperMetricsService.Enums;
using SuperMetricsService.Services.Dashboard;
using SuperMetricsService.Tests.TestData;

namespace SuperMetricsService.Tests.Controllers;

public class DashboardControllerTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private readonly DashboardController _sut;
    private readonly Mock<IDashboardService> _mockedDashboardService = new();

    public DashboardControllerTests()
    {
        _sut = new(_mockedDashboardService.Object);
    }

    [Fact]
    public async Task TestThatSumFollowersReturnsFollowersAsync()
    {
        var dummyItems = new GainedAndLostSumGroup("dummy", Array.Empty<GainedAndLostSumItem>());
        var response = new SumResponse<GainedAndLostSumGroup>(dummyItems, dummyItems, new[] { dummyItems });

        _mockedDashboardService.Setup(ls => ls.SumGainedAndLostAsync(It.IsAny<SumRequest>())).ReturnsAsync(response);

        var actual = await _sut.SumFollowers([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<SumResponse<GainedAndLostSumGroup>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<SumResponse<GainedAndLostSumGroup>>(apiResponse.Data);

        Assert.Equal(response, actualResponse);

        _mockedDashboardService.Verify(ld => ld.SumGainedAndLostAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumReachReturnsReachAsync()
    {
        var dummyItems = new GainedAndLostSumGroup("dummy", Array.Empty<GainedAndLostSumItem>());
        var response = new SumResponse<GainedAndLostSumGroup>(dummyItems, dummyItems, new[] { dummyItems });

        _mockedDashboardService.Setup(ls => ls.SumGainedAndLostAsync(It.IsAny<SumRequest>())).ReturnsAsync(response);

        var actual = await _sut.SumReach([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<SumResponse<GainedAndLostSumGroup>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<SumResponse<GainedAndLostSumGroup>>(apiResponse.Data);

        Assert.Equal(response, actualResponse);

        _mockedDashboardService.Verify(ld => ld.SumGainedAndLostAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumEngagementReturnsEngagementAsync()
    {
        var dummyItems = SumFactory.GetMockedEngagementSumItems("12345", "EngagementTest", 10);
        var dummyGroup = new EngagementSumGroup(DateTime.UtcNow.ToString("yyyy-MM-dd"), dummyItems);
        var response = new SumResponse<EngagementSumGroup>(dummyGroup, dummyGroup, new[] { dummyGroup });

        _mockedDashboardService.Setup(ls => ls.SumEngagementAsync(It.IsAny<SumRequest>())).ReturnsAsync(response);

        var actual = await _sut.SumEngagement([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<SumResponse<EngagementSumGroup>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<SumResponse<EngagementSumGroup>>(apiResponse.Data);

        Assert.Equal(response, actualResponse);

        _mockedDashboardService.Verify(ld => ld.SumEngagementAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumCommentsByDayReturnsCommentsAsync()
    {
        var dummyItems = SumFactory.GetMockedCommentsSumItems("12345", "CommentsByDay", 10);
        var dummyGroup = new CommentsSumGroup("dummy", dummyItems);
        var response = new SumResponse<CommentsSumGroup>(dummyGroup, dummyGroup, new[] { dummyGroup });

        _mockedDashboardService.Setup(ls => ls.CommentsAvgByDayAsync(It.IsAny<SumRequest>())).ReturnsAsync(response);

        var actual = await _sut.SumCommentsByDay([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<SumResponse<CommentsSumGroup>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<SumResponse<CommentsSumGroup>>(apiResponse.Data);
        Assert.Equal(response, actualResponse);

        _mockedDashboardService.Verify(ld => ld.CommentsAvgByDayAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumCommentsByHourReturnsCommentsAsync()
    {
        var dummyItems = SumFactory.GetMockedCommentsSumItems("12345", "CommentsByHour", 10);
        var dummyGroup = new CommentsSumGroup("dummy", dummyItems);
        var response = new SumResponse<CommentsSumGroup>(dummyGroup, dummyGroup, new[] { dummyGroup });

        _mockedDashboardService.Setup(ls => ls.CommentsAvgByHourAsync(It.IsAny<SumRequest>())).ReturnsAsync(response);

        var actual = await _sut.SumCommentsByHour([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<SumResponse<CommentsSumGroup>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<SumResponse<CommentsSumGroup>>(apiResponse.Data);

        Assert.Equal(response, actualResponse);

        _mockedDashboardService.Verify(ld => ld.CommentsAvgByHourAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumPostsReturnsSuccessfulAsync()
    {
        var dummyItems = SumFactory.GetMockedPostsSumItems("12345", "Posts", 10);
        var request = new PaginatedRequest<SumQueryFilter<PostField>>();
        var response = new ResultSetResponse<PostsSumItem>(dummyItems);

        _mockedDashboardService.Setup(ls => ls.PostsAsync(It.IsAny<PaginatedSumRequest<PostField>>())).ReturnsAsync(response);

        var actual = await _sut.Posts(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Verify(ld => ld.PostsAsync(It.IsAny<PaginatedSumRequest<PostField>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumCampaignsReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedCampaignsSumItems("12345", "SumCampaignTest", 1).First();

        _mockedDashboardService.Setup(ls => ls.SumCampaignsAsync(It.IsAny<SumRequest>())).ReturnsAsync(expected);

        var actual = await _sut.SumCampaigns([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<CampaignsSumItem>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<CampaignsSumItem>(apiResponse.Data);

        Assert.Equal(expected, actualResponse);

        _mockedDashboardService.Verify(ld => ld.SumCampaignsAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumAgeReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedAgeAndGenderSumItems("12345", "Age", 10);

        _mockedDashboardService.Setup(ls => ls.AgeAndGendersAsync(It.IsAny<SumRequest>())).ReturnsAsync(expected);

        var actual = await _sut.Age([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<IEnumerable<AgeAndGenderSumItem>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<IEnumerable<AgeAndGenderSumItem>>(apiResponse.Data);

        Assert.Equal(expected, actualResponse);

        _mockedDashboardService.Verify(ld => ld.AgeAndGendersAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumGenderReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedAgeAndGenderSumItems("12345", "Gender", 10);

        _mockedDashboardService.Setup(ls => ls.AgeAndGendersAsync(It.IsAny<SumRequest>())).ReturnsAsync(expected);

        var actual = await _sut.Gender([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<IEnumerable<AgeAndGenderSumItem>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<IEnumerable<AgeAndGenderSumItem>>(apiResponse.Data);

        Assert.Equal(expected, actualResponse);

        _mockedDashboardService.Verify(ld => ld.AgeAndGendersAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumEmotionsReturnsSuccessfulAsync()
    {
        var dummyDate = DateTime.UtcNow;
        var dummyItems = SumFactory.GetMockedEmotionSumItems("12345", "Emotion", 10);
        var dummyGroup = new EmotionsSumGroup(dummyDate.ToString("yyyy-MM-dd"), dummyItems);
        var response = new SumResponse<EmotionsSumGroup>(dummyGroup, dummyGroup, new[] { dummyGroup });

        _mockedDashboardService.Setup(ls => ls.SumEmotionsAsync(It.IsAny<SumRequest>())).ReturnsAsync(response);

        var actual = await _sut.Emotions([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<SumResponse<EmotionsSumGroup>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<SumResponse<EmotionsSumGroup>>(apiResponse.Data);

        Assert.Equal(response, actualResponse);

        _mockedDashboardService.Verify(ld => ld.SumEmotionsAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumMentionsReturnsSuccessfulAsync()
    {
        var dummyItems = SumFactory.GetMockedKeywordsSumItems(10);

        _mockedDashboardService.Setup(ls => ls.MentionsAsync(It.IsAny<SumRequest>())).ReturnsAsync(dummyItems);

        var actual = await _sut.Mentions([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<IEnumerable<TopKeyword>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<IEnumerable<TopKeyword>>(response.Data);

        Assert.Equal(dummyItems, actualResponse);

        _mockedDashboardService.Verify(ld => ld.MentionsAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumHashtagsReturnsSuccessfulAsync()
    {
        var dummyItems = SumFactory.GetMockedKeywordsSumItems(10);

        _mockedDashboardService.Setup(ls => ls.HashtagsAsync(It.IsAny<SumRequest>())).ReturnsAsync(dummyItems);

        var actual = await _sut.Hashtags([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<IEnumerable<TopKeyword>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<IEnumerable<TopKeyword>>(response.Data);

        Assert.Equal(dummyItems, actualResponse);

        _mockedDashboardService.Verify(ld => ld.HashtagsAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSumCaptionsReturnsSuccessfulAsync()
    {
        var dummyItems = SumFactory.GetMockedKeywordsSumItems(10);

        _mockedDashboardService.Setup(ls => ls.CaptionsAsync(It.IsAny<SumRequest>())).ReturnsAsync(dummyItems);

        var actual = await _sut.Captions([ChannelId], DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<IEnumerable<TopKeyword>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<IEnumerable<TopKeyword>>(response.Data);

        Assert.Equal(dummyItems, actualResponse);

        _mockedDashboardService.Verify(ld => ld.CaptionsAsync(It.IsAny<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCampaignsReturnsSuccessfulAsync()
    {
        var dummyItems = SumFactory.GetMockedCampaignsSumItems("12345", "Campaigns", 10);
        var request = new PaginatedRequest<SumQueryFilter<CampaignField>>();
        var response = new ResultSetResponse<CampaignsSumItem>(dummyItems);

        _mockedDashboardService.Setup(ls => ls.CampaignsAsync(It.IsAny<PaginatedSumRequest<CampaignField>>())).ReturnsAsync(response);

        var actual = await _sut.Campaigns(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Verify(ld => ld.CampaignsAsync(It.IsAny<PaginatedSumRequest<CampaignField>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCampaignReturnsSuccessfulAsync()
    {
        var dummyItems = SumFactory.GetMockedCampaignsSumItems("12345", "Campaigns", 10).ToArray();
        _mockedDashboardService.Setup(ls => ls.CampaignAsync(It.IsNotNull<SumRequest>(), "")).ReturnsAsync(dummyItems);

        var actual = await _sut.Campaign("", "", DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Verify(ld => ld.CampaignAsync(It.IsNotNull<SumRequest>(), ""), Times.Once);
    }

    [Fact]
    public async Task TestThatCampaignAgeAndGenderReturnsSuccessfulAsync()
    {
        var campaignId = "1";
        var dummyItems = SumFactory.GetMockedCampaignsAgeAndGenderSumItems("", "", 10);

        _mockedDashboardService.Setup(ls => ls.CampaignAgeAndGenderAsync(It.IsAny<SumRequest>(), It.IsAny<string>())).ReturnsAsync(dummyItems);

        var actual = await _sut.CampaignAgeAndGender(campaignId, ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        var okObject = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<IEnumerable<CampaignAgeAndGenderSumItem>>>(okObject.Value);
        var actualResponse = Assert.IsAssignableFrom<IEnumerable<CampaignAgeAndGenderSumItem>>(response.Data);

        Assert.Equal(dummyItems, actualResponse);

        _mockedDashboardService.Verify(ld => ld.CampaignAgeAndGenderAsync(It.IsAny<SumRequest>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatFollowersChartDataReturnsSuccessfulAsync()
    {
        var expected = new List<ChartSumItem<GainedAndLostSumItem>>()
        {
            new()
            {
                ChannelId = "1",
                SubscriptionId = "2",
                SubscriptionType = SubscriptionType.IGI_MEDIA,
                Values = new List<GainedAndLostSumItem>()
                {
                    new()
                    {
                        SubscriptionId = "1",
                        Date = DateTime.UtcNow,
                        IsPrediction = false,
                        Value = 10,
                        Gained = 0,
                        Lost = 0
                    },
                    new()
                    {
                        SubscriptionId = "1",
                        Date = DateTime.UtcNow.AddDays(1),
                        IsPrediction = false,
                        Value = null,
                        Gained = 0,
                        Lost = 0
                    },
                    new()
                    {
                        SubscriptionId = "1",
                        Date = DateTime.UtcNow.AddDays(1),
                        IsPrediction = false,
                        Value = 20,
                        Gained = 0,
                        Lost = 0
                    }
                }
            }
        };
        _mockedDashboardService.Setup(ls => ls.ChartAsync<GainedAndLostSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>()))
            .ReturnsAsync(expected);

        var actual = await _sut.FollowersChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow.AddDays(1));

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var value = Assert.IsType<ApiResponse<IEnumerable<ChartSumItem<GainedAndLostSumItem>>>>(actualResult.Value);
        var charts = value.Data!.FirstOrDefault()!.Values!.ToList();
        Assert.Equal(15, charts[1].Value);

        _mockedDashboardService.Verify(ld => ld.ChartAsync<GainedAndLostSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>()), Times.Once);
    }

    [Fact]
    public async Task TestThatReachChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<GainedAndLostSumItem>();
        _mockedDashboardService.Setup(ls => ls.ChartAsync<GainedAndLostSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);

        var actual = await _sut.ReachChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Verify(ld => ld.ChartAsync<GainedAndLostSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>()), Times.Once);
    }

    [Fact]
    public async Task TestThatEngagementChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<EngagementSumItem>();
        _mockedDashboardService.Setup(ls => ls.ChartAsync<EngagementSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);

        var actual = await _sut.EngagementChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Verify(ld => ld.ChartAsync<EngagementSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAgeChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<AgeAndGenderSumItem>();
        _mockedDashboardService.Setup(ls => ls.AgeAndGendersChartAsync(It.IsNotNull<SumRequest>())).ReturnsAsync(expected);

        var actual = await _sut.AgeChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Verify(ld => ld.AgeAndGendersChartAsync(It.IsNotNull<SumRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGenderChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<AgeAndGenderSumItem>();
        _mockedDashboardService.Setup(ls => ls.AgeAndGendersChartAsync(It.IsNotNull<SumRequest>())).ReturnsAsync(expected);

        var actual = await _sut.GenderChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.AgeAndGendersChartAsync(It.IsNotNull<SumRequest>())).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatHashtagsChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<TopKeyword>();
        _mockedDashboardService.Setup(ls => ls.TopKeywordsChartAsync(It.IsNotNull<SumRequest>(), KeywordCategory.CAPTION)).ReturnsAsync(expected);

        var actual = await _sut.HashtagsChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.TopKeywordsChartAsync(It.IsNotNull<SumRequest>(), KeywordCategory.CAPTION)).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatMentionsChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<TopKeyword>();
        _mockedDashboardService.Setup(ls => ls.TopKeywordsChartAsync(It.IsNotNull<SumRequest>(), KeywordCategory.CAPTION)).ReturnsAsync(expected);

        var actual = await _sut.MentionsChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.TopKeywordsChartAsync(It.IsNotNull<SumRequest>(), KeywordCategory.CAPTION)).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatCaptionsChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<TopKeyword>();
        _mockedDashboardService.Setup(ls => ls.TopKeywordsChartAsync(It.IsNotNull<SumRequest>(), KeywordCategory.CAPTION)).ReturnsAsync(expected);

        var actual = await _sut.CaptionsChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.TopKeywordsChartAsync(It.IsNotNull<SumRequest>(), KeywordCategory.CAPTION)).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatPostsChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<PostsSumItem>();
        _mockedDashboardService.Setup(ls => ls.ChartAsync<PostsSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);

        var actual = await _sut.PostsChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.ChartAsync<PostsSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatCampaignsChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<CampaignsSumItem>();
        _mockedDashboardService.Setup(ls => ls.ChartAsync<CampaignsSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);

        var actual = await _sut.CampaignsChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.ChartAsync<CampaignsSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatCountriesChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<CountrySumItem>();
        _mockedDashboardService.Setup(ls => ls.ChartAsync<CountrySumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);

        var actual = await _sut.CountriesChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.ChartAsync<CountrySumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatCommentsChartDataReturnsSuccessfulAsync()
    {
        var expected = SumFactory.GetMockedChartData<CommentsSumItem>();
        _mockedDashboardService.Setup(ls => ls.ChartAsync<CommentsSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);

        var actual = await _sut.CommentsChart([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Setup(ls => ls.ChartAsync<CommentsSumItem>(It.IsNotNull<SumRequest>(), It.IsAny<bool>(), It.IsAny<bool>())).ReturnsAsync(expected);
    }

    [Fact]
    public async Task TestThatGenderSumReturnsOk()
    {
        var expected = new List<AgeAndGenderSumItem>()
        {
            new AgeAndGenderSumItem
            {
                SubscriptionId = null,
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = null,
                Gender = "male",
                Followers = 333,
                Percentage = 33.33m
            },
            new AgeAndGenderSumItem()
            {
                SubscriptionId = null,
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = null,
                Gender = "female",
                Followers = 333,
                Percentage = 33.33m
            },
            new AgeAndGenderSumItem()
            {
                SubscriptionId = null,
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = null,
                Gender = "unknown",
                Followers = 333,
                Percentage = 33.33m
            },
        };

        _mockedDashboardService.Setup(dd => dd.GenderSumAsync(It.IsAny<SumRequest>()))
            .ReturnsAsync(expected);

        var actual = await _sut.GenderSum([ChannelId], DateTime.UtcNow, DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedDashboardService.Verify(dd => dd.GenderSumAsync(It.IsAny<SumRequest>()), Times.Once);
    }
}