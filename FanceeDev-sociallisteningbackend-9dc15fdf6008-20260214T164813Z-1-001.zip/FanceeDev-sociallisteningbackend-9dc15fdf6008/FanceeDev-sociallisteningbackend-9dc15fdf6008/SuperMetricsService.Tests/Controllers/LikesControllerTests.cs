using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Controllers;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Services.Likes;

namespace SuperMetricsService.Tests.Controllers;

public class LikesControllerTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private static readonly string InvalidId = "InvalidId";
    private readonly LikesController _sut;
    private readonly Mock<ILikesService> _mockedLikesService = new();

    public LikesControllerTests()
    {
        _sut = new(_mockedLikesService.Object);
    }

    [Fact]
    public async Task TestThatCountryLikesHistoryCallsLikesServiceCountryLikesAsync()
    {
        _mockedLikesService.Setup(ls => ls.CountryLikesAsync(ChannelId, It.IsAny<CountryCode>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<LikesHistory>());

        var actual = await _sut.CountryLikesHistory(ChannelId, CountryCode.NL, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedLikesService.Verify(ld => ld.CountryLikesAsync(ChannelId, It.IsAny<CountryCode>(), It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGeoLikesWithGainsCallsLikesServiceGeoLikesWithGainsAsync()
    {
        _mockedLikesService.Setup(ls => ls.GeoLikesWithGainsAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<GeoLikesStatistics>());

        var actual = await _sut.GeoLikes(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedLikesService.Verify(ld => ld.GeoLikesWithGainsAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGenderLikesCallsLikesServiceGenderLikesAsync()
    {
        _mockedLikesService.Setup(ls => ls.GenderLikesAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<GenderLikesStatistics>());

        var actual = await _sut.GenderLikes(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedLikesService.Verify(ld => ld.GenderLikesAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatEmotionLikesCallsLikesServiceEmotionLikesAsync()
    {
        _mockedLikesService.Setup(ls => ls.EmotionLikesAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<EmotionLikes>());

        var actual = await _sut.EmotionLikes(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedLikesService.Verify(ld => ld.EmotionLikesAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAgeLikesCallsLikesServiceAgeLikesAsync()
    {
        _mockedLikesService.Setup(ls => ls.AgeLikesAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new List<AgeLikesStatistics>());

        var actual = await _sut.AgeLikes(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedLikesService.Verify(ld => ld.AgeLikesAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCountryLikesHistoryThrowsInvalidObjectIdExceptionWhenSubscriptionsNotFound()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(() => _sut.CountryLikesHistory(InvalidId, CountryCode.NL, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatGeoLikesThrowsInvalidObjectIdExceptionWhenSubscriptionsNotFound()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(() => _sut.GeoLikes(InvalidId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatGenderLikesThrowsInvalidObjectIdExceptionWhenSubscriptionsNotFound()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(() => _sut.GenderLikes(InvalidId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatEmotionLikesThrowsInvalidObjectIdExceptionWhenSubscriptionsNotFound()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(() => _sut.EmotionLikes(InvalidId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatAgeLikesThrowsInvalidObjectIdExceptionWhenSubscriptionsNotFound()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(() => _sut.AgeLikes(InvalidId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow));
    }
}