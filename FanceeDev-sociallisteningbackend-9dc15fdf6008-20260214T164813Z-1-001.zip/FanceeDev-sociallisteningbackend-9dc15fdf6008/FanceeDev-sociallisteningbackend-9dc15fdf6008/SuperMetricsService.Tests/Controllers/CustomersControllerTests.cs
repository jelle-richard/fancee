﻿using Microsoft.AspNetCore.Mvc;
using SuperMetricsService.Controllers;
using SuperMetricsService.Dtos.Responses.Customers;
using SuperMetricsService.Services.Customers;

namespace SuperMetricsService.Tests.Controllers;

public class CustomersControllerTests
{
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    private readonly CustomersController _sut;
    private readonly Mock<ICustomersService> _mockedCustomersService = new();

    public CustomersControllerTests()
    {
        _sut = new(_mockedCustomersService.Object);
    }

    [Fact]
    public async Task TestThatCustomersInformationCallsCustomersServiceCustomersInformationAsync()
    {
        _mockedCustomersService.Setup(cis => cis.CustomersInformationAsync(SubscriptionId))
            .ReturnsAsync(new List<Customer>());

        var actual = await _sut.CustomersInformationAsync(SubscriptionId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedCustomersService.Verify(cis => cis.CustomersInformationAsync(SubscriptionId), Times.Once);
    }
}