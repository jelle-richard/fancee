using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Controllers;
using SuperMetricsService.Dtos.Responses.ChannelInfo;
using SuperMetricsService.Services.ChannelInfo;

namespace SuperMetricsService.Tests.Controllers;

public class ChannelInfoControllerTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private static readonly string InvalidId = "InvalidId";
    private readonly ChannelInfoController _sut;
    private readonly Mock<IChannelInfoService> _mockedChannelInfoService = new();

    public ChannelInfoControllerTests()
    {
        _sut = new(_mockedChannelInfoService.Object);
    }

    [Fact]
    public async Task TestThatChannelReachCallsChannelInfoServiceChannelReachAsync()
    {
        _mockedChannelInfoService.Setup(gs => gs.ChannelReachAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()))
            .ReturnsAsync(new ChannelReach());

        var actual = await _sut.ChannelReach(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelInfoService.Verify(gs => gs.ChannelReachAsync(ChannelId, It.IsAny<DateTime>(), It.IsAny<DateTime>()), Times.Once);
    }

    [Fact]
    public async Task TestThatChannelReachThrowsInvalidObjectIdExceptionWhenSubscriptionsNotFound()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(() => _sut.ChannelReach(InvalidId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow));
    }

    [Fact]
    public async Task TestThatGrowthCallsChannelInfoServiceChannelGrowthAsync()
    {
        _mockedChannelInfoService.Setup(gs => gs.ChannelGrowthAsync(ChannelId))
            .ReturnsAsync(new List<ChannelGrowth>());

        var actual = await _sut.ChannelGrowth(ChannelId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelInfoService.Verify(gs => gs.ChannelGrowthAsync(ChannelId));
    }

    [Fact]
    public async Task TestThatChannelGrowthThrowsInvalidObjectIdExceptionWhenSubscriptionsNotFound()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(() => _sut.ChannelGrowth(InvalidId));
    }
}