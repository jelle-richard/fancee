using FanceeAnalyticsData.Models.Analytics.Api;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Controllers;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;
using SuperMetricsService.Services.Posts;

namespace SuperMetricsService.Tests.Controllers;

public class PostsControllerTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private readonly PostsController _sut;
    private readonly Mock<IPostsService> _mockedPostsService = new();
    private readonly ApiRequest _genericApiRequest = new(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

    public PostsControllerTests()
    {
        _sut = new(_mockedPostsService.Object);
    }

    [Fact]
    public async Task TestThatListCallsPostsServiceListAsync()
    {
        _mockedPostsService.Setup(ps => ps.ListAsync(It.IsAny<ApiRequest>()))
            .ReturnsAsync(new List<Post>());

        var actual = await _sut.List(_genericApiRequest);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedPostsService.Verify(ld => ld.ListAsync(_genericApiRequest), Times.Once);
    }

    [Fact]
    public async Task TestThatTopPostsCallsPostsServiceTopListAsync()
    {
        _mockedPostsService.Setup(ps => ps.TopListPaginatedAsync(It.IsAny<PaginatedRequest<ChannelAndDatesQueryFilter>>(), It.IsAny<PostRequestCategory>()))
            .ReturnsAsync(new ResultSetResponse<Post>());

        var actual = await _sut.TopPostsPaginated(new(), PostRequestCategory.REACH);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedPostsService.Verify(ld => ld.TopListPaginatedAsync(It.IsAny<PaginatedRequest<ChannelAndDatesQueryFilter>>(), It.IsAny<PostRequestCategory>()), Times.Once);
    }

    [Fact]
    public async Task TestThatBestDayOfWeekCallsPostsServiceAvgPerDayOfWeekAsync()
    {
        _mockedPostsService.Setup(ls => ls.AvgPerDayOfWeekAsync(_genericApiRequest, It.IsAny<PostRequestCategory>()))
            .ReturnsAsync(new List<AvgPerDayOfWeek>());

        var actual = await _sut.BestDayOfWeek(_genericApiRequest, PostRequestCategory.REACH);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedPostsService.Verify(ld => ld.AvgPerDayOfWeekAsync(_genericApiRequest, It.IsAny<PostRequestCategory>()), Times.Once);
    }

    [Fact]
    public async Task TestThatBestTimeHourCallsPostsServiceAvgPerTimeOfDayAsync()
    {
        _mockedPostsService.Setup(ls => ls.AvgPerTimeOfDayAsync(_genericApiRequest, It.IsAny<PostRequestCategory>()))
            .ReturnsAsync(new List<AvgPerHour>());

        var actual = await _sut.BestTimeHour(_genericApiRequest, PostRequestCategory.REACH);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedPostsService.Verify(ld => ld.AvgPerTimeOfDayAsync(_genericApiRequest, It.IsAny<PostRequestCategory>()), Times.Once);
    }

    [Fact]
    public async Task TestThatTopKeywordsCallsPostsServiceTopKeywordsAsync()
    {
        _mockedPostsService.Setup(ls => ls.TopKeywordsAsync(_genericApiRequest, It.IsAny<KeywordCategory>()))
            .ReturnsAsync(new List<TopKeyword>());

        var actual = await _sut.TopKeywords(_genericApiRequest, KeywordCategory.HASH);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedPostsService.Verify(ld => ld.TopKeywordsAsync(_genericApiRequest, It.IsAny<KeywordCategory>()), Times.Once);
    }

    [Fact]
    public async Task TestThatListThrowsInvalidObjectIdExceptionWhenIdIsInvalid()
    {
        await Assert.ThrowsAsync<InvalidObjectIdException>(async () =>
            await _sut.List(new("InvalidId", DateTime.UtcNow.AddDays(-10), DateTime.UtcNow)));
    }
}