using SuperMetricsService.Enums;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.TestData;

public class SumTypeMember : EnumMember<SumType>
{
}