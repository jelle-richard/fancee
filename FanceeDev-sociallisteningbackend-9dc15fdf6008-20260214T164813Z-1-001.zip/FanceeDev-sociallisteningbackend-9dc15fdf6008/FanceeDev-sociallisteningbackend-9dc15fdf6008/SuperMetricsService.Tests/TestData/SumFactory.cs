using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Dtos.Responses.Posts;

namespace SuperMetricsService.Tests.TestData;

public static class SumFactory
{
    public static IEnumerable<EngagementSumItem> GetMockedEngagementSumItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;
        var comments = 1;
        var likes = 1;
        var shares = 1;

        var list = new List<EngagementSumItem>();

        for (var i = 0; i < amount; i++)
            list.Add(new() { Date = dummyDate.AddDays(i), Comments = comments++, Likes = likes++, Shares = shares++, Source = source, SubscriptionId = subscriptionId });

        return list;
    }

    public static IEnumerable<CommentsSumItem> GetMockedCommentsSumItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;

        var list = new List<CommentsSumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Date = dummyDate.AddDays(i),
                Hour = i.ToString(),
                Comments = i,
                Source = source,
                SubscriptionId = subscriptionId
            });
        }

        return list;
    }

    public static IEnumerable<PostsSumItem> GetMockedPostsSumItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;

        var list = new List<PostsSumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Date = dummyDate.AddDays(i),
                Source = source,
                SubscriptionId = subscriptionId,
                Message = $"message ${i}",
                PostType = $"posttype ${i}",
                Paid = false,
                Name = $"name ${i}",
                Likes = i,
                Clicks = i + 1,
                Comments = i + 2,
                Shares = i + 3,
                Views = i + 4,
                Thumbnail = "thumbnail",
                Time = "12:00"
            });
        }

        return list;
    }

    public static IEnumerable<EmotionsSumItem> GetMockedEmotionSumItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;
        var list = new List<EmotionsSumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Source = source,
                SubscriptionId = subscriptionId,
                Date = dummyDate.AddDays(i),
                Wow = i,
                Thankful = i + 2,
                Sorry = i + 3,
                Pride = i + 4,
                Anger = i + 5,
                Haha = i + 6,
                Like = i + 7,
                Love = i + 8
            });
        }

        return list;
    }

    public static IEnumerable<AgeAndGenderSumItem> GetMockedAgeAndGenderSumItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;
        var list = new List<AgeAndGenderSumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Source = source,
                SubscriptionId = subscriptionId,
                Date = dummyDate.AddDays(i),
                Age = "30-35",
                Gender = "Male",
                Followers = i,
                Percentage = i * 0.1m
            });
        }

        return list;
    }

    public static IEnumerable<CountrySumItem> GetMockedCountrySumItems(string subscriptionId, string channelId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;
        var list = new List<CountrySumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Source = source,
                ChannelId = channelId,
                SubscriptionId = subscriptionId,
                Date = dummyDate.AddDays(i),
                CountryCode = (CountryCode)i,
                Followers = i,
                Percentage = i + 1,
                GainedPercentage = i + 2
            });
        }

        return list;
    }

    public static IEnumerable<GainedAndLostSumItem> GetMockedGainedAndListItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;
        var list = new List<GainedAndLostSumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Source = source,
                SubscriptionId = subscriptionId,
                Date = dummyDate.AddDays(i),
                Gained = i,
                Lost = i + 1,
                Value = i + 2
            });
        }

        return list;
    }

    public static IEnumerable<GeoLikesStatistics> GetMockedGeoLikes(int amount)
    {
        var list = new List<GeoLikesStatistics>();

        for (var i = 0; i < amount; i++)
            list.Add(new((CountryCode)i, i, 1));

        return list;
    }

    public static IEnumerable<TopKeyword> GetMockedKeywordsSumItems(int amount)
    {
        var list = new List<TopKeyword>();

        for (var i = 0; i < amount; i++)
            list.Add(new(i.ToString(), i));

        return list;
    }

    public static IEnumerable<CampaignsSumItem> GetMockedCampaignsSumItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;

        var list = new List<CampaignsSumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Date = dummyDate.AddDays(i),
                StartDate = dummyDate,
                Source = source,
                SubscriptionId = subscriptionId,
                ChannelId = "1",
                CampaignId = $"CampaignId_{i}",
                Name = $"CampaignName_{i}",
                Status = $"Status_{i}",
                Cost = i,
                Budget = i + 1,
                Impressions = i + 2,
                Clicks = i + 3,
                CPC = i + 4,
                CTR = i + 5,
                Conversion = i + 6
            });
        }

        return list;
    }

    public static IEnumerable<CampaignAgeAndGenderSumItem> GetMockedCampaignsAgeAndGenderSumItems(string subscriptionId, string source, int amount)
    {
        var dummyDate = DateTime.UtcNow;

        var list = new List<CampaignAgeAndGenderSumItem>();

        for (var i = 0; i < amount; i++)
        {
            list.Add(new()
            {
                Date = dummyDate.AddDays(i),
                Age = $"Age-{i}",
                Gender = $"Male-{i}",
                Source = source,
                SubscriptionId = subscriptionId,
                CampaignId = $"CampaignId_{i}",
                Cost = i,
                Impressions = i + 1,
                Views = i + 2,
                Clicks = i + 3,
                Conversions = i + 4
            });
        }

        return list;
    }

    public static IEnumerable<ChartSumItem<TSumItem>> GetMockedChartData<TSumItem>(Func<int, TSumItem>? func = null) where TSumItem : new() => new ChartSumItem<TSumItem>[] {
        new()
        {
            ChannelId = "1",
            SubscriptionId = "2",
            SubscriptionType = SubscriptionType.IGI_MEDIA,
            Values = Enumerable.Range(0, 10).Select((i) => func != null ? func.Invoke(i) : new())
        }
    };
}