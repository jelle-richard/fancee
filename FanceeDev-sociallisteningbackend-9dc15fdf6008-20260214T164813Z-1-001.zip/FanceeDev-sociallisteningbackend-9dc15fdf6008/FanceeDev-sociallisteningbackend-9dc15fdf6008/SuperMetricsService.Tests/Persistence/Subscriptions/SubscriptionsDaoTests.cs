using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Services.Cache;
using SuperMetricsService.Persistence.Subscriptions;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Persistence.Subscriptions;

public class SubscriptionsDaoTests
{
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    private readonly ISubscriptionsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();

    public SubscriptionsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _mockedCacheService.Setup(cs => cs.CacheObjectAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<int>()));
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<Subscription>(It.IsAny<string>())).ReturnsAsync((Subscription?)null);
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<IEnumerable<Subscription>>(It.IsAny<string>())).ReturnsAsync((Subscription[]?)null);

        _sut = new SubscriptionsDao(configuration, _mockedCacheService.Object, _mongoDatabase.Object);
    }

    [Fact]
    public async Task TestThatFirstAsyncReturnsModelWhenSuccessful()
    {
        var channelId = "channelId";

        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput(),
            SubscriptionType = SubscriptionType.GT
        };

        _mongoDatabase.Mock(new[] { model });

        var actual = await _sut.FirstAsync(channelId, [SubscriptionType.GT, SubscriptionType.FB]);

        Assert.Equal(model, actual);
    }

    [Fact]
    public async Task TestThatFirstAsyncThrowsSubscriptionNotFoundExceptionWhenNotFound()
    {
        var channelId = "channelId";

        _mongoDatabase.Mock(Array.Empty<Subscription>());

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.FirstAsync(channelId, [SubscriptionType.FB]));
    }

    [Fact]
    public async Task TestThatToListFromSubscriptionIdsAsyncWorks()
    {
        var expected = new[]
        {
            new Subscription
            {
                Id = SubscriptionId,
                Cron = "* * * * *",
                RunOnce = false,
                Input = SubscriptionType.GT.ToInput(),
                SubscriptionType = SubscriptionType.GT
            }
        };

        _mongoDatabase.Mock(expected);

        var actual = await _sut.ToListFromSubscriptionIdsAsync([SubscriptionId]);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatToListFromSubscriptionIdsAsyncThrowsNotFound()
    {
        _mongoDatabase.Mock(Array.Empty<Subscription>());
        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.ToListFromSubscriptionIdsAsync([""]));
    }

    [Fact]
    public async Task TestThatToListByTypeAndChannelIdsAsyncWorks()
    {
        var expected = new[]
        {
            new Subscription
            {
                Id = SubscriptionId,
                Cron = "* * * * *",
                RunOnce = false,
                Input = SubscriptionType.GT.ToInput(),
                SubscriptionType = SubscriptionType.GT
            }
        };

        _mongoDatabase.Mock(expected);

        var actual = await _sut.ToListByTypeAndChannelIdsAsync(["1234"], [SubscriptionType.GT]);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatToListByTypeAndChannelIdsAsyncThrowsNotFound()
    {
        _mongoDatabase.Mock(Array.Empty<Subscription>());
        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.ToListByTypeAndChannelIdsAsync(["1234"], [SubscriptionType.GT]));
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncReturnsListOfModelsWhenSuccessful()
    {
        var channelId = string.Empty;
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };
        List<Subscription> asList = [model, model];
        Subscription[] asArray = [model, model];

        _mongoDatabase.Mock(asArray);

        var actual = await _sut.ToListByChannelIdAsync(channelId);

        Assert.Equal(asList, actual);
    }

    [Fact]
    public async Task TestThatToListByTypeAndChannelIdAsyncReturnsListFromCacheSuccessful()
    {
        var channelId = string.Empty;
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };
        List<Subscription> expected = [model, model];

        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<IEnumerable<Subscription>>(It.IsAny<string>())).ReturnsAsync(expected);

        var actual = await _sut.ToListByTypeAndChannelIdsAsync(["1234"], [SubscriptionType.GT]);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncThrowsSubscriptionNotFoundExceptionWhenListEmpty()
    {
        var channelId = string.Empty;
        _mongoDatabase.Mock(Array.Empty<Subscription>());
        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.ToListByChannelIdAsync(channelId));
    }
}