﻿using SuperMetricsService.Persistence.Customers;
using SuperMetricsService.TestData;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Persistence.Customers;

public class CustomersDaoTests
{
    private readonly string subscriptionId = "placeholder";
    private readonly ICustomersDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public CustomersDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new CustomersDao(configuration, _mongoDatabase.Object);
    }

    [Fact]
    public async Task TestThatCustomersInformationAsyncReturnsListWhenSuccessful()
    {
        var customersInformation = CustomersInformationFactory.GetCustomersInformation();
        _mongoDatabase.Mock(customersInformation);

        var actual = (await _sut.CustomersInformationAsync(subscriptionId)).ToList();

        Assert.Equal(customersInformation.Count, actual.Count);
        Assert.Equal(customersInformation.First().EventName, actual.First().EventName);
    }
}