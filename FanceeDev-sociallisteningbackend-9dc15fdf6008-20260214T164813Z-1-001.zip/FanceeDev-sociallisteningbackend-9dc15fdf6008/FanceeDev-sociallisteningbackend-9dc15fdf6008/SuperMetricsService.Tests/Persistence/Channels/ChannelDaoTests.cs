using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Persistence.Channels;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Persistence.Channels;

public class ChannelDaoTests
{
    private readonly ChannelDao _sut;
    private readonly Mock<IMongoDatabase> _mockedMongoDatabase = new();
    private readonly Mock<IMongoCollection<Channel>> _mockedCollection;
    private readonly Mock<IAsyncCursor<Channel>> _mockedCursor = new();

    private static readonly Channel Channel = new()
    {
        Id = "channelId",
        CreatedOn = default,
        UpdatedOn = default,
        ChannelType = ChannelType.FACEBOOK,
        Status = ChannelStatus.Setup,
        HasError = false,
        Name = "Facebook",
        Request = null,
        RequestDisplayName = null,
        UserId = Guid.NewGuid(),
        Owner = null
    };

    public ChannelDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _mockedCollection = _mockedMongoDatabase.MockCollection<Channel>();
        _sut = new(configuration, _mockedMongoDatabase.Object);
        _mockedCursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        _mockedCursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
    }

    [Fact]
    public async Task TestThatBySubscriptionIdAsyncReturnsChannel()
    {
        _mockedCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Channel>>(),
                It.IsAny<FindOptions<Channel>>(),
                It.IsAny<CancellationToken>()
            )
        ).ReturnsAsync(_mockedCursor.Object);

        _mockedCursor.Setup(c => c.Current)
            .Returns(
                [
                    Channel
                ]
            );

        var actual = await _sut.ByIdAsync(Channel.Id!);
        Assert.NotNull(actual);
        Assert.Equal(Channel, actual);

    }

    [Fact]
    public async Task TestThatBySubscriptionIdAsyncReturnsNullValue()
    {
        _mockedCollection.Setup(c => c.FindAsync(
                It.IsAny<FilterDefinition<Channel>>(),
                It.IsAny<FindOptions<Channel>>(),
                It.IsAny<CancellationToken>()
            )
        ).ReturnsAsync(_mockedCursor.Object);

        _mockedCursor.Setup(c => c.Current)
            .Returns(
                []
            );

        var actual = await _sut.ByIdAsync(Channel.Id!);
        Assert.Null(actual);
    }
}