using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Persistence.Likes;
using SuperMetricsService.TestData;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Persistence.Likes;

public class LikesDaoTests
{
    private readonly string _subscriptionId = ObjectId.Empty.ToString();
    private readonly ILikesDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public LikesDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new LikesDao(configuration, _mongoDatabase.Object);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_GEO_LIKES, null, null)]
    [InlineData(SubscriptionType.IGI_COUNTRY, null, null)]
    [InlineData(SubscriptionType.YT2_GEO, null, null)]
    [InlineData(SubscriptionType.LIP_COUNTRY, null, null)]
    [InlineData(SubscriptionType.TIKBA_COUNTRY, null, null)]
    [InlineData(SubscriptionType.FB, null, "2021-01-01")]
    [InlineData(SubscriptionType.FB, "2021-01-01", null)]
    [InlineData(SubscriptionType.FB, "2021-01-01", "2021-01-01")]
    public async Task TestThatGeoLikesAsyncReturnsListWhenSuccessful(SubscriptionType type, string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var expectedData = new GeoLikesStatistics[] { new(), new() };

        _mongoDatabase.Mock(expectedData);

        var actualData = await _sut.GeoLikesAsync(new(_subscriptionId, type, startDate, endDate));

        Assert.Equal(expectedData, actualData);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_AGE_AND_GENDER, null, null)]
    [InlineData(SubscriptionType.IGI_AGE_AND_GENDER, null, null)]
    [InlineData(SubscriptionType.YT2_DEMOGRAPHIC, null, null)]
    [InlineData(SubscriptionType.TIKBA_GENDER, null, null)]
    [InlineData(SubscriptionType.FB, null, "2021-01-01")]
    [InlineData(SubscriptionType.FB, "2021-01-01", null)]
    [InlineData(SubscriptionType.FB, "2021-01-01", "2021-01-01")]
    public async Task TestThatGenderLikesAsyncReturnsListWhenSuccessful(SubscriptionType type, string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var expectedData = new GenderLikesStatistics[] { new(), new() };
        _mongoDatabase.Mock(expectedData);

        var actualData = await _sut.GenderLikesAsync(new(_subscriptionId, type, startDate, endDate));

        Assert.Equal(expectedData, actualData);
    }

    [Theory]
    [InlineData(SubscriptionType.FB, null, null)]
    [InlineData(SubscriptionType.FB, null, "2021-01-01")]
    [InlineData(SubscriptionType.IGI_COUNTRY, "2021-01-01", null)]
    [InlineData(SubscriptionType.FB, "2021-01-01", "2021-01-01")]
    public async Task TestThatCountryLikesAsyncReturnsListWhenSuccessful(SubscriptionType type, string? startDateString, string? endDateString)
    {
        var startDate = startDateString == null ? DateTime.UtcNow : DateTime.Parse(startDateString);
        var endDate = endDateString == null ? DateTime.UtcNow : DateTime.Parse(endDateString);

        var expectedData = new LikesHistory[] { new(), new() };
        _mongoDatabase.Mock(expectedData);

        var actualData = await _sut.CountryLikesAsync(new(_subscriptionId, type, startDate, endDate), CountryCode.NL);

        Assert.Equal(expectedData, actualData);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_POSTS, null, null)]
    [InlineData(SubscriptionType.FB, null, "2021-01-01")]
    [InlineData(SubscriptionType.FB, "2021-01-01", null)]
    [InlineData(SubscriptionType.FB, "2021-01-01", "2021-01-01")]
    public async Task TestThatEmotionLikesAsyncReturnsListWhenSuccessful(SubscriptionType type, string? startDateString, string? endDateString)
    {
        var startDate = startDateString == null ? DateTime.UtcNow : DateTime.Parse(startDateString);
        var endDate = endDateString == null ? DateTime.UtcNow : DateTime.Parse(endDateString);

        var expectedData = LikesFactory.MockedEmotionLikes();
        _mongoDatabase.Mock(expectedData);

        var actualData = (await _sut.EmotionLikesAsync(new(_subscriptionId, type, startDate, endDate))).ToList();

        Assert.Equal(expectedData.Length, actualData.Count);
        Assert.Equal(expectedData.First().Emotion, actualData.First().Emotion);
        Assert.Equal(expectedData.First().Amount, actualData.First().Amount);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_AGE_AND_GENDER, null, null)]
    [InlineData(SubscriptionType.IGI_AGE_AND_GENDER, null, null)]
    [InlineData(SubscriptionType.YT2_DEMOGRAPHIC, null, null)]
    [InlineData(SubscriptionType.FB, null, "2021-01-01")]
    [InlineData(SubscriptionType.FB, "2021-01-01", null)]
    [InlineData(SubscriptionType.FB, "2021-01-01", "2021-01-01")]
    public async Task TestThatAgeLikesAsyncReturnsListWhenSuccessful(SubscriptionType type, string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var expectedData = LikesFactory.MockedAgeLikes();
        _mongoDatabase.Mock(expectedData);

        var actualData = (await _sut.AgeLikesAsync(new(_subscriptionId, type, startDate, endDate))).ToList();

        Assert.Equal(expectedData.Length, actualData.Count);
        Assert.Equal(expectedData.First().Age, actualData.First().Age);
        Assert.Equal(expectedData.First().LikesAmount, actualData.First().LikesAmount);
    }
}