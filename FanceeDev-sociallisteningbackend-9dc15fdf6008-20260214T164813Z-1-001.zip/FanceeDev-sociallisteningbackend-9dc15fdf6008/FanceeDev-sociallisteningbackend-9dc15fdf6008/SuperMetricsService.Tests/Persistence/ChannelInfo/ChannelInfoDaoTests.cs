using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Persistence.ChannelInfo;
using SuperMetricsService.TestData;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Persistence.ChannelInfo;

public class ChannelInfoDaoTests
{
    private readonly string SubscriptionId = ObjectId.Empty.ToString();
    private readonly IChannelInfoDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public ChannelInfoDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new ChannelInfoDao(configuration, _mongoDatabase.Object);
    }

    [Theory]
    [InlineData(null, null, SubscriptionType.FB)]
    [InlineData(null, "2021-01-01", SubscriptionType.FB)]
    [InlineData("2021-01-01", null, SubscriptionType.IGI_PROFILE_DATA)]
    [InlineData("2021-01-01", "2021-01-01", SubscriptionType.IGI_PROFILE_DATA)]
    public async Task TestThatChannelReachAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString, SubscriptionType subscriptionType)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var expectedData = ChannelInfoFactory.GetChannelReach();
        _mongoDatabase.Mock(expectedData);

        var actualData = await _sut.ChannelReachAsync(new(SubscriptionId, subscriptionType, startDate, endDate));

        Assert.Equal(expectedData.First().TotalFollowers, actualData.TotalFollowers);
        Assert.Equal(expectedData.First().AverageAge, actualData.AverageAge);
    }

    [Theory]
    [InlineData(null, null)]
    [InlineData(null, "2021-01-01")]
    [InlineData("2021-01-01", null)]
    [InlineData("2021-01-01", "2021-01-01")]
    public async Task TestThatChannelReachFollowersAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var expectedData = ChannelInfoFactory.GetChannelReach();
        _mongoDatabase.Mock(expectedData);

        var actualData = await _sut.ChannelReachFollowersAsync(new(SubscriptionId, SubscriptionType.IGI, startDate, endDate));

        Assert.Equal(expectedData.First().TotalFollowers, actualData.TotalFollowers);
        Assert.Equal(expectedData.First().AverageAge, actualData.AverageAge);
    }

    [Theory]
    [InlineData(SubscriptionType.FB)]
    public async Task TestThatChannelGrowthAsyncReturnsListWhenSuccessful(SubscriptionType subscriptionType)
    {
        var expectedData = ChannelInfoFactory.GetChannelGrowths();
        _mongoDatabase.Mock(expectedData);

        var actual = await _sut.ChannelGrowthAsync(SubscriptionId, subscriptionType);

        Assert.Equal(expectedData.First().Gained, actual.First().Gained);
    }
}