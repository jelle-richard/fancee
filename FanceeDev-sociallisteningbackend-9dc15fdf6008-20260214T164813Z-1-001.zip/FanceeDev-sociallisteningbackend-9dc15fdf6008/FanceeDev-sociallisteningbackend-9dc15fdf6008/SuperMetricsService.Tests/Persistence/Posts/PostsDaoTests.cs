using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;
using SuperMetricsService.Persistence.Posts;
using SuperMetricsService.TestData;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Persistence.Posts;

public class PostsDaoTests
{
    private readonly string SubscriptionId = ObjectId.Empty.ToString();
    private readonly IPostsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public PostsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new PostsDao(configuration, _mongoDatabase.Object);
    }

    [Theory]
    [InlineData(null, null)]
    [InlineData(null, "2021-01-01")]
    [InlineData("2021-01-01", null)]
    [InlineData("2021-01-01", "2021-01-01")]
    public async Task TestThatToListAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var posts = PostsFactory.GetMockedPosts();
        _mongoDatabase.Mock(posts);

        var actual = await _sut.ToListAsync(new(SubscriptionId, SubscriptionType.FB_POSTS, startDate, endDate));

        Assert.Equal(posts.Length, actual.Count());
        Assert.Equal(posts.First().Message, actual.First().Message);
        Assert.Equal(posts.First().Date, actual.First().Date);
        Assert.Equal(posts.First().TotalReach, actual.First().TotalReach);
    }

    [Theory]
    [InlineData(null, null, 5)]
    [InlineData(null, "2021-01-01", 10)]
    [InlineData("2021-01-01", null, 5)]
    [InlineData("2021-01-01", "2021-01-01", 3)]
    public async Task TestThatTopListAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString, int amount)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var posts = PostsFactory.GetMockedTopPosts();
        _mongoDatabase.Mock(posts);

        var actual = (await _sut.TopListAsync(new(SubscriptionId, SubscriptionType.FB, startDate, endDate), PostRequestCategory.REACH, amount)).ToList();

        Assert.Equal(posts.Length, actual.Count);
        Assert.Equal(posts.First().Message, actual.First().Message);
        Assert.Equal(posts.First().Date, actual.First().Date);
        Assert.Equal(posts.First().TotalReach, actual.First().TotalReach);
    }

    [Theory]
    [InlineData(null, null, 5)]
    [InlineData(null, "2021-01-01", 10)]
    [InlineData("2021-01-01", null, 5)]
    [InlineData("2021-01-01", "2021-01-01", 3)]
    public async Task TestThatTopListPaginatedAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString, int amount)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);
        var posts = PostsFactory.GetMockedTopPosts();

        _mongoDatabase.MockPagination<GenericEntry, Post>(new[] { new ResultSetResponse<Post> { Items = posts, TotalItems = posts.Length } });

        var actual = await _sut.TopListPaginatedAsync(new(SubscriptionId, SubscriptionType.FB, startDate, endDate), PostRequestCategory.REACH, amount, 0);

        Assert.Equal(posts.Length, actual.Items.Count());
        Assert.Equal(posts.First().Message, actual.Items.First().Message);
        Assert.Equal(posts.First().Date, actual.Items.First().Date);
        Assert.Equal(posts.First().TotalReach, actual.Items.First().TotalReach);
    }

    [Theory]
    [InlineData(null, null)]
    [InlineData(null, "2021-01-01")]
    [InlineData("2021-01-01", null)]
    [InlineData("2021-01-01", "2021-01-01")]
    public async Task TestThatAvgPerDayOfWeekAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var avgs = PostsFactory.GetMockedAvgPerDays();
        _mongoDatabase.Mock(avgs);

        var actual = (await _sut.AvgPerDayOfWeekAsync(new(SubscriptionId, SubscriptionType.FB, startDate, endDate), PostRequestCategory.REACH)).ToList();

        Assert.Equal(avgs.Length, actual.Count);
        Assert.Equal(avgs.First().DayOfWeek, actual.First().DayOfWeek);
        Assert.Equal(avgs.First().Average, actual.First().Average);
    }

    [Theory]
    [InlineData(null, null)]
    [InlineData(null, "2021-01-01")]
    [InlineData("2021-01-01", null)]
    [InlineData("2021-01-01", "2021-01-01")]
    public async Task TestThatAvgPerTimeOfDayAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var avgs = PostsFactory.GetMockedAvgPerHours();
        _mongoDatabase.Mock(avgs);

        var actual = (await _sut.AvgPerTimeOfDayAsync(new(SubscriptionId, SubscriptionType.FB_POSTS, startDate, endDate), PostRequestCategory.REACH)).ToList();

        Assert.Equal(avgs.Length, actual.Count);
        Assert.Equal(avgs.First().Hour, actual.First().Hour);
        Assert.Equal(avgs.First().Average, actual.First().Average);
    }

    [Theory]
    [InlineData(null, null)]
    [InlineData(null, "2021-01-01")]
    [InlineData("2021-01-01", null)]
    [InlineData("2021-01-01", "2021-01-01")]
    public async Task TopKeywordsAsyncReturnsListWhenSuccessful(string? startDateString, string? endDateString)
    {
        DateTime? startDate = startDateString == null ? null : DateTime.Parse(startDateString);
        DateTime? endDate = endDateString == null ? null : DateTime.Parse(endDateString);

        var topKeywords = PostsFactory.GetTopKeywords();
        _mongoDatabase.Mock(topKeywords);

        var actual = (await _sut.TopKeywordsAsync(new(SubscriptionId, SubscriptionType.FB_POSTS, startDate, endDate), KeywordCategory.HASH)).ToList();

        Assert.Equal(topKeywords.Count, actual.Count);
        Assert.Equal(topKeywords.First().Word, actual.First().Word);
        Assert.Equal(topKeywords.First().Amount, actual.First().Amount);
    }

    [Fact]
    public async Task TestThatReplaceListAsyncRunsWhenModelsAreOk()
    {
        var entryList = new[] { new GenericEntry(SubscriptionType.FB_POSTS) };
        var collection = _mongoDatabase.MockCollection(entryList);
        collection.Setup(col => col.BulkWriteAsync(It.IsAny<IEnumerable<WriteModel<GenericEntry>>>(), It.IsAny<BulkWriteOptions>(), It.IsAny<CancellationToken>()));

        await _sut.ReplaceListAsync(entryList);

        collection.Verify(col => col.BulkWriteAsync(It.IsAny<IEnumerable<WriteModel<GenericEntry>>>(), It.IsAny<BulkWriteOptions>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAsyncThrowsCollectionNotFoundWhenCollectionIsMissing()
    {
        await Assert.ThrowsAsync<CollectionNotFoundException>(async () => await _sut.GetAsync(Builders<GenericEntry>.Filter.Empty));
    }
}