﻿using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers;
using SuperMetricsService.Persistence.Dashboard;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Persistence.Dashboard;

public class DashboardDaoTests
{
    private readonly string SubscriptionId = ObjectId.Empty.ToString();
    private readonly IDashboardDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public DashboardDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new DashboardDao(configuration, _mongoDatabase.Object);
    }

    [Theory]
    [InlineData(SubscriptionType.FB)]
    [InlineData(SubscriptionType.IGI)]
    public async Task TestThatGetsSumOfFollowersPerSubscriptionSuccessfully(SubscriptionType subscriptionType)
    {
        var request = new SumDaoRequest(SumType.Followers, SubscriptionId, subscriptionType, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<GainedAndLostSumItem> { new(), new() };
        _mongoDatabase.Mock<GenericEntry, GainedAndLostSumItem>(expected);

        var actual = await _sut.GetSumListAsync<GainedAndLostSumItem>(request, null, false);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(SubscriptionType.FB)]
    [InlineData(SubscriptionType.IGI_PROFILE_DATA)]
    public async Task TestThatGetsSumOfReachPerSubscriptionSuccessfully(SubscriptionType subscriptionType)
    {
        var request = new SumDaoRequest(SumType.Reach, SubscriptionId, subscriptionType, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<GainedAndLostSumItem> { new(), new() };
        _mongoDatabase.Mock<GenericEntry, GainedAndLostSumItem>(expected);

        var actual = await _sut.GetSumListAsync<GainedAndLostSumItem>(request, null, false);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_POSTS)]
    [InlineData(SubscriptionType.IGI_MEDIA)]
    public async Task TestThatGetsSumOfCommentsPerSubscriptionSuccessfully(SubscriptionType subscriptionType)
    {
        var request = new SumDaoRequest(SumType.Comments, SubscriptionId, subscriptionType, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<CommentsSumItem> { new(), new() };
        _mongoDatabase.Mock<GenericEntry, CommentsSumItem>(expected);

        var actual = await _sut.GetSumListAsync<CommentsSumItem>(request, null, false);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_POSTS)]
    [InlineData(SubscriptionType.IGI_MEDIA)]
    public async Task TestThatGetsSumOfEngagementPerSubscriptionSuccessfully(SubscriptionType subscriptionType)
    {
        var request = new SumDaoRequest(SumType.Engagement, SubscriptionId, subscriptionType, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<EngagementSumItem> { new(), new() };
        _mongoDatabase.Mock<GenericEntry, EngagementSumItem>(expected);

        var actual = await _sut.GetSumListAsync<EngagementSumItem>(request, null, false);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(SubscriptionType.FBPD_PAGE)]
    [InlineData(SubscriptionType.IGI_PROFILE_DATA)]
    public async Task TestThatGetSumListAsyncReturnsListWithPaddedDays(SubscriptionType subscriptionType)
    {
        var expected = new List<GainedAndLostSumItem>()
        {
            new ()
            {
                Date = DateTime.UtcNow,
                IsPrediction = false,
                Value = 10,
                Gained = 0,
                Lost = 0
            },
            new ()
            {
                Date = DateTime.UtcNow.AddDays(1),
                IsPrediction = false,
                Value = 12,
                Gained = 0,
                Lost = 0
            },
        };
        var request = new SumDaoRequest(SumType.Followers, SubscriptionId, subscriptionType, DateTime.UtcNow, DateTime.UtcNow.AddDays(4));
        _mongoDatabase.Mock<GenericEntry, GainedAndLostSumItem>(expected);

        var actual = (await _sut.GetSumListAsync<GainedAndLostSumItem>(request)).ToList();
        Assert.Equal(expected[0], actual[0]);
        Assert.Equal(expected[1], actual[1]);
        Assert.Equal(5, actual.Count);
    }

    [Theory]
    [InlineData(SubscriptionType.AW_CAMPAIGN)]
    [InlineData(SubscriptionType.FA_CAMPAIGN)]
    public async Task TestThatGetSingleCampaignReturnsSuccessfully(SubscriptionType subscriptionType)
    {
        var request = new SumDaoRequest(SumType.Campaigns, SubscriptionId, subscriptionType, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<CampaignsSumItem> { new(), new() };
        _mongoDatabase.Mock<GenericEntry, CampaignsSumItem>(expected);

        var actual = await _sut.GetCampaignSumListAsync<CampaignsSumItem>(request, "");

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatGetSingleCampaignThrowsExceptionWhenInvalid()
    {
        var request = new SumDaoRequest(SumType.Campaigns, SubscriptionId, SubscriptionType.GAWA, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<CampaignsSumItem> { new(), new() };
        _mongoDatabase.Mock<GenericEntry, CampaignsSumItem>(expected);

        await Assert.ThrowsAsync<SubscriptionTypeNotSupportedException>(async () => await _sut.GetCampaignSumListAsync<CampaignsSumItem>(request, ""));
    }

    [Fact]
    public async Task TestThatGetSumFirstReturnsSuccessfully()
    {
        var request = new SumDaoRequest(SumType.Posts, SubscriptionId, SubscriptionType.FB_POSTS, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<CampaignsSumItem> { new() { CampaignId = "1" }, new() { CampaignId = "2" } };
        _mongoDatabase.Mock<GenericEntry, CampaignsSumItem>(expected);

        var actual = await _sut.GetSumFirstAsync<CampaignsSumItem>(request, It.IsAny<BsonDocument>());

        Assert.Equal(expected[0], actual);
    }

    [Fact]
    public async Task TestThatGetSumLastReturnsSuccessfully()
    {
        var request = new SumDaoRequest(SumType.Campaigns, SubscriptionId, SubscriptionType.GAWA, DateTime.UtcNow, DateTime.UtcNow);
        var expected = new List<CampaignsSumItem> { new() { CampaignId = "1" }, new() { CampaignId = "2" } };
        _mongoDatabase.Mock<GenericEntry, CampaignsSumItem>(expected);

        var actual = await _sut.GetSumLastAsync<CampaignsSumItem>(request, It.IsAny<BsonDocument>());

        Assert.Equal(expected[0], actual);
    }
}