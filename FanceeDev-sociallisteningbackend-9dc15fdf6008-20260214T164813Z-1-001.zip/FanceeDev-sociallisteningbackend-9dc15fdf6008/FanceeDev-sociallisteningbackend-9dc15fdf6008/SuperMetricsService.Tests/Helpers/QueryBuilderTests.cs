using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Helpers.Queries;

namespace SuperMetricsService.Tests.Helpers;

public class QueryBuilderTests
{
    [Fact]
    public void TestThatConstructorThrowsSubscriptionTypeNotSupportedExceptionWhenChannelInvalid()
    {
        Assert.Throws<SubscriptionTypeNotSupportedException>(() => new QueryBuilder(new() { SubscriptionType = (SubscriptionType)int.MaxValue }));
    }

    [Fact]
    public void TestThatBuildThrowsChannelTypeNotSupportedExceptionWhenChannelNotSupported()
    {
        var builder = new QueryBuilder(new() { SubscriptionType = SubscriptionType.GAWA });
        Assert.Throws<ChannelTypeNotSupportedException>(builder.Build);
    }

    [Theory]
    [InlineData(SubscriptionType.FB)]
    [InlineData(SubscriptionType.IGI)]
    [InlineData(SubscriptionType.YT2_CHANNEL)]
    [InlineData(SubscriptionType.LIP_PAGE)]
    [InlineData(SubscriptionType.TIKBA_PROFILE)]
    public void TestThatBuildThrowsNotImplementedExceptionWhenChannelNotImplemented(SubscriptionType subscriptionType)
    {
        var builder = new QueryBuilder(new() { SubscriptionType = subscriptionType });
        Assert.Throws<NotImplementedException>(builder.Build);
    }
}