using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers;
using SuperMetricsService.Tests.TestData;

namespace SuperMetricsService.Tests.Helpers;

public class PostsHelperTests
{
    [Fact]
    public void TestThatGetFieldNameThrowsChannelTypeNotSupportedExceptionWhenChannelInvalid()
    {
        Assert.Throws<ChannelTypeNotSupportedException>(() => PostRequestCategory.REACH.GetFieldName((ChannelType)int.MaxValue));
    }

    [Theory]
    [InlineData(PostRequestCategory.REACH, ChannelType.FACEBOOK)]
    [InlineData(PostRequestCategory.REACTION, ChannelType.FACEBOOK)]
    [InlineData(PostRequestCategory.LIKES, ChannelType.FACEBOOK)]
    [InlineData(PostRequestCategory.REACH, ChannelType.INSTAGRAM)]
    [InlineData(PostRequestCategory.REACTION, ChannelType.INSTAGRAM)]
    [InlineData(PostRequestCategory.LIKES, ChannelType.INSTAGRAM)]
    public void TestThatGetFieldNameReturnsStringWhenSuccessful(PostRequestCategory category, ChannelType channelType)
    {
        Assert.NotNull(category.GetFieldName(channelType));
    }

    [Fact]
    public void TestThatProjectionStepThrowsChannelTypeNotSupportedExceptionWhenChannelInvalid()
    {
        Assert.Throws<ChannelTypeNotSupportedException>(() => PostsHelper.ProjectionStep((ChannelType)int.MaxValue));
    }

    [Theory]
    [InlineData(ChannelType.FACEBOOK)]
    [InlineData(ChannelType.INSTAGRAM)]
    public void TestThatProjectionStepReturnsArrayWhenSuccessful(ChannelType channelType)
    {
        Assert.NotEmpty(PostsHelper.ProjectionStep(channelType));
    }

    [Theory]
    [MemberData(nameof(PostFieldMember.Data), MemberType = typeof(PostFieldMember))]
    public void TestThatFieldOrderByForPostsWorksForEveryField(PostField postField)
    {
        var ascending = true;
        var posts = SumFactory.GetMockedPostsSumItems("", "", 10);
        var orderedPosts = posts.FieldOrderBy(postField, ascending).ToList();

        var left = orderedPosts.First();
        var right = orderedPosts.Last();

        Assert.True(ComparePostsSumItems(left, right, postField, ascending));
    }

    [Theory]
    [MemberData(nameof(PostFieldMember.Data), MemberType = typeof(PostFieldMember))]
    public void TestThatFieldOrderByDescendingForPostsWorksForEveryField(PostField postField)
    {
        var ascending = false;
        var posts = SumFactory.GetMockedPostsSumItems("", "", 10);
        var orderedPosts = posts.FieldOrderBy(postField, ascending).ToList();

        var left = orderedPosts.First();
        var right = orderedPosts.Last();

        Assert.True(ComparePostsSumItems(left, right, postField, ascending));
    }

    private static bool ComparePostsSumItems(PostsSumItem left, PostsSumItem right, PostField field, bool ascending)
        => ascending
            ? ComparePostsSumItemsAscending(left, right, field)
            : ComparePostsSumItemsDescending(left, right, field);

    private static bool ComparePostsSumItemsAscending(PostsSumItem left, PostsSumItem right, PostField field)
        => field switch
        {
            PostField.Name => left.Name?.CompareTo(right.Name) <= 0,
            PostField.Date => left.Date <= right.Date,
            PostField.Type => left.PostType?.CompareTo(right.PostType) <= 0,
            PostField.Likes => left.Likes <= right.Likes,
            PostField.Shares => left.Shares <= right.Shares,
            PostField.Views => left.Views <= right.Views,
            PostField.Comments => left.Comments <= right.Comments,
            PostField.Paid => left.Paid == false || right.Paid == true,
            PostField.Message => left.Message?.CompareTo(right.Message) <= 0,
            PostField.Clicks => left.Clicks <= right.Clicks,
            _ => throw new ArgumentOutOfRangeException(nameof(field), field, null)
        };

    private static bool ComparePostsSumItemsDescending(PostsSumItem left, PostsSumItem right, PostField field)
        => field switch
        {
            PostField.Name => left.Name?.CompareTo(right.Name) > 0,
            PostField.Date => left.Date > right.Date,
            PostField.Type => left.PostType?.CompareTo(right.PostType) > 0,
            PostField.Likes => left.Likes > right.Likes,
            PostField.Shares => left.Shares > right.Shares,
            PostField.Views => left.Views > right.Views,
            PostField.Comments => left.Comments > right.Comments,
            PostField.Paid => left.Paid == true || right.Paid == false,
            PostField.Message => left.Message?.CompareTo(right.Message) > 0,
            PostField.Clicks => left.Clicks > right.Clicks,
            _ => throw new ArgumentOutOfRangeException(nameof(field), field, null)
        };
}