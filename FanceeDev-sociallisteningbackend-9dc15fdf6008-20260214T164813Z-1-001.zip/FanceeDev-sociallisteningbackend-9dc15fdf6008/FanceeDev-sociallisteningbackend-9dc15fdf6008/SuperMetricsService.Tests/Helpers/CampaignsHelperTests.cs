using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers;
using SuperMetricsService.Tests.TestData;

namespace SuperMetricsService.Tests.Helpers;

public class CampaignsHelperTests
{
    [Theory]
    [MemberData(nameof(CampaignFieldMember.Data), MemberType = typeof(CampaignFieldMember))]
    public void TestThatFieldOrderByForCampaignsWorksForEveryField(CampaignField field)
    {
        var ascending = true;
        var items = SumFactory.GetMockedCampaignsSumItems("", "", 10);
        var orderedList = items.FieldOrderBy(field, ascending).ToList();

        var left = orderedList.First();
        var right = orderedList.Last();

        Assert.True(CompareCampaignsSumItems(left, right, field, ascending));
    }

    [Theory]
    [MemberData(nameof(CampaignFieldMember.Data), MemberType = typeof(CampaignFieldMember))]
    public void TestThatFieldOrderByDescendingForCampaignsWorksForEveryField(CampaignField field)
    {
        var ascending = false;
        var items = SumFactory.GetMockedCampaignsSumItems("", "", 10);
        var orderedList = items.FieldOrderBy(field, ascending).ToList();

        var left = orderedList.First();
        var right = orderedList.Last();

        Assert.True(CompareCampaignsSumItems(left, right, field, ascending));
    }

    private static bool CompareCampaignsSumItems(CampaignsSumItem left, CampaignsSumItem right, CampaignField field, bool ascending)
        => ascending
            ? CompareAscending(left, right, field)
            : CompareDescending(left, right, field);

    private static bool CompareAscending(CampaignsSumItem left, CampaignsSumItem right, CampaignField field)
        => field switch
        {
            CampaignField.Name => left.Name?.CompareTo(right.Name) <= 0,
            CampaignField.Date => left.Date <= right.Date,
            CampaignField.StartDate => left.StartDate <= right.StartDate,
            CampaignField.Cost => left.Cost <= right.Cost,
            CampaignField.Budget => left.Budget <= right.Budget,
            CampaignField.Clicks => left.Clicks <= right.Clicks,
            CampaignField.Conversion => left.Conversion <= right.Conversion,
            CampaignField.CPC => left.Conversion <= right.Conversion,
            CampaignField.CTR => left.Conversion <= right.Conversion,
            CampaignField.Status => left.Conversion <= right.Conversion,
            CampaignField.Impressions => left.Impressions <= right.Impressions,
            _ => throw new ArgumentOutOfRangeException(nameof(field), field, null)
        };

    private static bool CompareDescending(CampaignsSumItem left, CampaignsSumItem right, CampaignField field)
        => field switch
        {
            CampaignField.Name => left.Name?.CompareTo(right.Name) > 0,
            CampaignField.Date => left.Date >= right.Date,
            CampaignField.StartDate => left.StartDate >= right.StartDate,
            CampaignField.Cost => left.Cost > right.Cost,
            CampaignField.Budget => left.Budget > right.Budget,
            CampaignField.Clicks => left.Clicks > right.Clicks,
            CampaignField.Conversion => left.Conversion > right.Conversion,
            CampaignField.CPC => left.Conversion > right.Conversion,
            CampaignField.CTR => left.Conversion > right.Conversion,
            CampaignField.Status => left.Conversion > right.Conversion,
            CampaignField.Impressions => left.Impressions > right.Impressions,
            _ => throw new ArgumentOutOfRangeException(nameof(field), field, null)
        };
}