using FanceeAnalyticsData.Models.Analytics;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers;
using SuperMetricsService.Tests.TestData;

namespace SuperMetricsService.Tests.Helpers;

public class SumTypeExtensionsTests
{
    [Theory]
    [MemberData(nameof(SumTypeMember.Data), MemberType = typeof(SumTypeMember))]
    public void TestThatProjectionsReturnSuccessful(SumType sumType)
    {
        foreach (var subscriptionType in sumType.ToSubscriptionTypes())
            Assert.NotNull(sumType.ToProjection(subscriptionType));
    }

    [Theory]
    [MemberData(nameof(SumTypeMember.Data), MemberType = typeof(SumTypeMember))]
    public void TestThatProjectionsReturnSuccessfulWithInvalidType(SumType sumType) => Assert.NotNull(sumType.ToProjection((SubscriptionType)(-1)));

    [Theory]
    [MemberData(nameof(SumTypeMember.Data), MemberType = typeof(SumTypeMember))]
    public void TestThatEverySumTypeHasAToSubscriptionTypesOutput(SumType sumType) => Assert.NotEmpty(sumType.ToSubscriptionTypes());

    [Fact]
    public void TestThatUnsupportedSumTypeHasAToSubscriptionTypes() => Assert.Empty(((SumType)(-1)).ToSubscriptionTypes());

    [Fact]
    public void TestThatUnsupportedSumTypeHasAToProjection() => Assert.NotEmpty(((SumType)(-1)).ToProjection(SubscriptionType.FB));

    [Fact]
    public void TestThatSumDaoRequestCanCreateAndCopySuccesful()
    {
        var expected = new SumDaoRequest
        {
            SumType = SumType.Comments
        };

        var actual = new SumDaoRequest(expected);

        Assert.Equal(expected.SumType, actual.SumType);
    }
}