using CronScheduler.Extensions.StartupInitializer;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SuperMetricsService.Jobs;
using TestCore.Utils.UnitTestsHelpers;

namespace SuperMetricsService.Tests.Jobs;

public class InitDatabaseJobTests
{
    private readonly IStartupJob _sut;
    private readonly IConfiguration _configuration = new ConfigurationBuilder().Build();
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<ILogger<InitDatabaseJob>> _logger = new();

    public InitDatabaseJobTests()
    {
        _sut = new InitDatabaseJob(
            _logger.Object,
            _configuration,
            _mongoDatabase.Object
        );
    }

    [Fact]
    public async Task TestThatExecuteAsyncCreatesIndexesWhenSuccessful()
    {
        _mongoDatabase.MockIndexes<GenericEntry>();
        _mongoDatabase.MockIndexes<Connection>();

        await _sut.ExecuteAsync();

        _logger.VerifyLogging(
            $"{nameof(InitDatabaseJob)} started",
            LogLevel.Information,
            Times.Once());

        _logger.VerifyLogging(
            $"{nameof(InitDatabaseJob)} ended",
            LogLevel.Information,
            Times.Once());
    }
}