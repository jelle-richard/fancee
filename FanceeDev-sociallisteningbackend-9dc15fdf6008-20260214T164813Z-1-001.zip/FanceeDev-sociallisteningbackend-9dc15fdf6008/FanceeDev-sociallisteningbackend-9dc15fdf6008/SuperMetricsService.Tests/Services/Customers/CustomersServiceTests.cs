﻿using SuperMetricsService.Persistence.Customers;
using SuperMetricsService.Services.Customers;
using SuperMetricsService.TestData;

namespace SuperMetricsService.Tests.Services.Customers;

public class CustomersServiceTests
{
    private const string SubscriptionId = "placeholder";
    private readonly CustomersService _sut;
    private readonly Mock<ICustomersDao> _mockedCustomersDao = new();

    public CustomersServiceTests()
    {
        _sut = new(_mockedCustomersDao.Object);
    }

    [Fact]
    public async Task TestThatCustomersInformationAsyncCallsCustomersDaoCustomersInforamtionAsync()
    {
        var customersInformation = CustomersInformationFactory.GetCustomersInformation();

        _mockedCustomersDao.Setup(cid => cid.CustomersInformationAsync(SubscriptionId)).ReturnsAsync(new[] { customersInformation.First() });

        var actual = await _sut.CustomersInformationAsync(SubscriptionId);

        Assert.Single(actual);
        Assert.Equal(customersInformation.First(), actual.First());
    }
}