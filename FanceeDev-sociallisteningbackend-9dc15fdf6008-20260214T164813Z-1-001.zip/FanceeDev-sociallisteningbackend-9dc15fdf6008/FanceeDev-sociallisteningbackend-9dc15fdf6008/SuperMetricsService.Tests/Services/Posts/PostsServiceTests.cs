using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Posts;
using SuperMetricsService.Enums;
using SuperMetricsService.Persistence.Posts;
using SuperMetricsService.Persistence.Subscriptions;
using SuperMetricsService.Services.Posts;
using SuperMetricsService.TestData;

namespace SuperMetricsService.Tests.Services.Posts;

public class PostsServiceTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();

    private readonly PostsService _sut;
    private readonly Mock<IPostsDao> _mockedPostsDao = new();
    private readonly Mock<ISubscriptionsDao> _mockedSubscriptionsDao = new();

    private readonly ApiRequest _genericApiRequest = new(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

    public PostsServiceTests()
    {
        _sut = new(_mockedPostsDao.Object, _mockedSubscriptionsDao.Object);
        SetupGetSubscription(SubscriptionType.FB_POSTS);
    }

    [Fact]
    public async Task TestThatListAsyncCallsPostsDaoToListAsync()
    {
        var mockedPosts = PostsFactory.GetMockedPosts();

        _mockedPostsDao.Setup(ld => ld.ToListAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(mockedPosts);

        var actual = await _sut.ListAsync(_genericApiRequest);

        Assert.NotEmpty(actual);
        Assert.Equal(mockedPosts.First(), actual.First());
    }

    [Theory]
    [InlineData(PostRequestCategory.LIKES)]
    [InlineData(PostRequestCategory.REACH)]
    [InlineData(PostRequestCategory.REACTION)]
    public async Task TestThatTopListAsyncCallsPostsDaoTopListAsync(PostRequestCategory category)
    {
        var mockedTopPosts = PostsFactory.GetMockedTopPosts();

        _mockedPostsDao.Setup(ld => ld.TopListAsync(It.IsAny<DaoRequest>(), It.IsAny<PostRequestCategory>(), 5))
            .ReturnsAsync(mockedTopPosts);

        var actual = await _sut.TopListAsync(_genericApiRequest, category, 5);

        Assert.NotEmpty(actual);

        Assert.Equal(mockedTopPosts.First(), actual.First());
    }

    [Theory]
    [InlineData(PostRequestCategory.LIKES)]
    [InlineData(PostRequestCategory.REACH)]
    [InlineData(PostRequestCategory.REACTION)]
    public async Task TestThatTopListPaginatedAsyncCallsPostsDaoTopListPaginatedAsync(PostRequestCategory category)
    {
        var expected = new ResultSetResponse<Post>
        {
            Items = PostsFactory.GetMockedTopPosts(),
            TotalItems = 300
        };

        _mockedPostsDao.Setup(ld => ld.TopListPaginatedAsync(It.IsAny<DaoRequest>(), It.IsAny<PostRequestCategory>(), It.IsAny<int>(), It.IsAny<int>()))
            .ReturnsAsync(expected);

        var actual = await _sut.TopListPaginatedAsync(new(), category);

        Assert.NotEmpty(actual.Items);
        Assert.Equal(expected.Items.First(), actual.Items.First());
    }

    [Theory]
    [InlineData(PostRequestCategory.LIKES)]
    [InlineData(PostRequestCategory.REACH)]
    [InlineData(PostRequestCategory.REACTION)]
    public async Task TestThatAvgPerDayOfWeekAsyncCallsPostsDaoAvgPerDayOfWeekAsync(PostRequestCategory category)
    {
        var avgPerDayOfWeeks = PostsFactory.GetMockedAvgPerDays();

        _mockedPostsDao.Setup(ld => ld.AvgPerDayOfWeekAsync(It.IsAny<DaoRequest>(), It.IsAny<PostRequestCategory>()))
            .ReturnsAsync(avgPerDayOfWeeks);

        var actual = await _sut.AvgPerDayOfWeekAsync(_genericApiRequest, category);

        Assert.NotEmpty(actual);
        Assert.Equal(avgPerDayOfWeeks, actual.ToArray());
    }

    [Theory]
    [InlineData(PostRequestCategory.LIKES)]
    [InlineData(PostRequestCategory.REACH)]
    [InlineData(PostRequestCategory.REACTION)]
    public async Task TestThatAvgPerTimeOfDayAsyncCallsAvgPerTimeOfDayAsync(PostRequestCategory category)
    {
        var mockedAvgPerTimeHours = PostsFactory.GetMockedAvgPerHours();

        _mockedPostsDao.Setup(ld => ld.AvgPerTimeOfDayAsync(It.IsAny<DaoRequest>(), It.IsAny<PostRequestCategory>()))
            .ReturnsAsync(mockedAvgPerTimeHours);

        var actual = await _sut.AvgPerTimeOfDayAsync(_genericApiRequest, category);

        Assert.NotEmpty(actual);
        Assert.Equal(mockedAvgPerTimeHours, actual.ToArray());
    }

    [Theory]
    [InlineData(KeywordCategory.HASH)]
    [InlineData(KeywordCategory.TAG)]
    [InlineData(KeywordCategory.CAPTION)]
    public async Task TestThatTopKeywordsAsyncCallsPostsDaoTopKeywordsAsync(KeywordCategory category)
    {
        var topKeywords = PostsFactory.GetTopKeywords();

        _mockedPostsDao.Setup(ld => ld.TopKeywordsAsync(It.IsAny<DaoRequest>(), It.IsAny<KeywordCategory>()))
            .ReturnsAsync(new[] { topKeywords.First() });

        var actual = await _sut.TopKeywordsAsync(_genericApiRequest, category);

        Assert.Single(actual);
        Assert.Equal(topKeywords.First().Word, actual.First().Word);
    }

    private void SetupGetSubscription(SubscriptionType subscriptionType)
    {
        _mockedSubscriptionsDao.Setup(sd => sd.FirstAsync(It.IsAny<string>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(new Subscription
            {
                Id = SubscriptionId,
                ChannelId = ChannelId,
                Input = subscriptionType.ToInput(),
                SubscriptionType = subscriptionType
            });
    }
}