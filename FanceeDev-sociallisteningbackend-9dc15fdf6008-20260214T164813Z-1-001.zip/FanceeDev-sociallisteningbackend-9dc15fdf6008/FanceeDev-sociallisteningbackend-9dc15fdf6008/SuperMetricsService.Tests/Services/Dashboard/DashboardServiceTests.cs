using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Utils.Cron;
using SuperMetricsService.Dtos.Dashboard;
using SuperMetricsService.Dtos.Requests.Sum;
using SuperMetricsService.Enums;
using SuperMetricsService.Helpers;
using SuperMetricsService.Persistence.Channels;
using SuperMetricsService.Persistence.Dashboard;
using SuperMetricsService.Persistence.Likes;
using SuperMetricsService.Persistence.Posts;
using SuperMetricsService.Persistence.Subscriptions;
using SuperMetricsService.Services.Dashboard;
using SuperMetricsService.Tests.TestData;

namespace SuperMetricsService.Tests.Services.Dashboard;

public class DashboardServiceTests
{
    private readonly DashboardService _sut;
    private readonly Mock<IDashboardDao> _mockedDashboardDao = new();
    private readonly Mock<ILikesDao> _mockedLikesDao = new();
    private readonly Mock<IPostsDao> _mockedPostsDao = new();
    private readonly Mock<ISubscriptionsDao> _mockedSubscriptionsDao = new();
    private readonly Mock<IChannelDao> _mockedChannelDao = new();

    public DashboardServiceTests()
    {
        _sut = new(
            _mockedDashboardDao.Object,
            _mockedLikesDao.Object,
            _mockedPostsDao.Object,
            _mockedSubscriptionsDao.Object,
            _mockedChannelDao.Object
        );
    }

    [Fact]
    public async Task TestThatSumFollowersReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Followers, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription() };
        var mockSumItems = new[] { new GainedAndLostSumItem() };

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<GainedAndLostSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.SumGainedAndLostAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumReachReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Reach, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = new[] { new GainedAndLostSumItem() };

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<GainedAndLostSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.SumGainedAndLostAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumEngagementReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Engagement, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription() };
        var mockSumItems = SumFactory.GetMockedEngagementSumItems("", "", 10);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<EngagementSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.SumEngagementAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumCommentsByDayReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Comments, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription() };
        var mockSumItems = new[] { new CommentsSumItem() };

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CommentsSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.CommentsAvgByDayAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumCommentsByHourReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Comments, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription() };
        var mockSumItems = new[] { new CommentsSumItem() };

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CommentsSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.CommentsAvgByHourAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumPostsReturnsSuccessfulAsync()
    {
        var request = new PaginatedSumRequest<PostField>(SumType.Posts, [""], DateTime.Now, DateTime.Now, PostField.Date, false);
        var mockSubscriptions = new[] { SubscriptionType.FB_POSTS, SubscriptionType.YT2_VIDEO }.Select(e => new Subscription { ChannelId = "1", Id = e.ToString(), SubscriptionType = e }).ToArray();
        var expected = new List<PostsSumItem>();
        foreach (var mockSubscription in mockSubscriptions)
        {
            var singleSubscriptionList = SumFactory.GetMockedPostsSumItems(mockSubscription.Id!, mockSubscription.SubscriptionType.ToString(), 5).ToArray();

            _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<PostsSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
                .ReturnsAsync(singleSubscriptionList);

            expected.AddRange(singleSubscriptionList);
        }

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        var actual = await _sut.PostsAsync(request);

        Assert.NotNull(actual);
        Assert.Equal(actual.TotalItems, expected.Count);
    }

    [Fact]
    public async Task TestThatCampaignsReturnsSuccessfulAsync()
    {
        var request = new PaginatedSumRequest<CampaignField>(SumType.Campaigns, [""], DateTime.Now, DateTime.Now, CampaignField.Date, false);
        var mockSubscriptions = new[] { SubscriptionType.AW_CAMPAIGN }.Select(e => new Subscription { ChannelId = "1", Id = e.ToString(), SubscriptionType = e }).ToArray();
        var expected = new List<CampaignsSumItem>();
        foreach (var mockSubscription in mockSubscriptions)
        {
            var singleSubscriptionList = SumFactory.GetMockedCampaignsSumItems(mockSubscription.Id!, mockSubscription.SubscriptionType.ToString(), 5).ToArray();

            _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CampaignsSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
                .ReturnsAsync(singleSubscriptionList);

            expected.AddRange(singleSubscriptionList);
        }

        var expectedGroupCount = expected.GroupBy(e => e.CampaignId).Count();

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        var actual = await _sut.CampaignsAsync(request);

        Assert.NotNull(actual);
        Assert.Equal(expectedGroupCount, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatSumCampaignReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Campaigns, [""], DateTime.Now, DateTime.Now);
        var mockSubscription = new Subscription { ChannelId = "1", Id = ObjectId.GenerateNewId().ToString(), SubscriptionType = SubscriptionType.AW_CAMPAIGN };
        var expected = SumFactory.GetMockedCampaignsSumItems(mockSubscription.Id!, mockSubscription.SubscriptionType.ToString(), 5).ToArray();

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CampaignsSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(expected);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(new[] { mockSubscription });

        var actual = await _sut.SumCampaignsAsync(request);

        Assert.NotNull(actual);
        Assert.Equal(expected.Sum(item => item.Budget), actual.Budget);
    }

    [Theory]
    [InlineData(SubscriptionType.FB_POSTS)]
    [InlineData(SubscriptionType.IGI_MEDIA)]
    public async Task TestThatSingleCampaignReturnsSuccessfulAsync(SubscriptionType subscriptionType)
    {
        var mockSubscription = new Subscription { ChannelId = "1", Id = ObjectId.GenerateNewId().ToString(), SubscriptionType = subscriptionType };
        var expected = SumFactory.GetMockedCampaignsSumItems(mockSubscription.Id!, mockSubscription.SubscriptionType.ToString(), 5).ToArray();

        _mockedDashboardDao.Setup(dd => dd.GetCampaignSumListAsync<CampaignsSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<string>()))
            .ReturnsAsync(expected);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(new[] { mockSubscription });

        var actual = await _sut.CampaignAsync(new(SumType.Campaigns, [""], DateTime.Now, DateTime.Now), "");

        Assert.NotNull(actual);
        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatSumAgeReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Age, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription() };
        var mockSumItems = new[] { new AgeAndGenderSumItem { Date = DateTime.UtcNow, Age = "", Followers = 0, Gender = "" } };

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<AgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.SumAgeAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatGenderSumAsyncSumsFollowersAndCalculatesGendersFromGivenSubscriptionChannels()
    {
        var channelIds = new string[]
        {
            "channelId1",
            "channelId2",
            "channelId3"
        };

        var subscriptions = new List<Subscription>()
        {
            new()
            {
                Id = "SubscriptionId1",
                CreatedOn = default,
                UpdatedOn = default,
                Cron = CronConstants.CronRunEvery5Minutes,
                Active = true,
                RunOnce = false,
                Name = "Subscription1",
                AdditionalInfo = null,
                ChannelId = "ChannelId1",
                Input = null,
                SubscriptionType = SubscriptionType.FA_CAMPAIGN,
                IsHistory = false,
                Fields = null
            },
            new()
            {
                Id = "SubscriptionId2",
                CreatedOn = default,
                UpdatedOn = default,
                Cron = CronConstants.CronRunEvery5Minutes,
                Active = true,
                RunOnce = false,
                Name = "Subscription2",
                AdditionalInfo = null,
                ChannelId = "ChannelId2",
                Input = null,
                SubscriptionType = SubscriptionType.FA_CAMPAIGN,
                IsHistory = false,
                Fields = null
            },
            new()
            {
                Id = "SubscriptionId3",
                CreatedOn = default,
                UpdatedOn = default,
                Cron = CronConstants.CronRunEvery5Minutes,
                Active = true,
                RunOnce = false,
                Name = "Subscription3",
                AdditionalInfo = null,
                ChannelId = "ChannelId3",
                Input = null,
                SubscriptionType = SubscriptionType.FA_CAMPAIGN,
                IsHistory = false,
                Fields = null
            }
        };

        var subscriptionFollowerSums = new List<AgeAndGenderSumItem>()
        {
            new()
            {
                SubscriptionId = "subscriptionId1",
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = "0-12",
                Gender = "male",
                Followers = 300,
                Percentage = null
            },
            new()
            {
                SubscriptionId = "subscriptionId1",
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = "13-25",
                Gender = "male",
                Followers = 300,
                Percentage = null
            },
            new()
            {
                SubscriptionId = "subscriptionId1",
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = "26-39",
                Gender = "male",
                Followers = 300,
                Percentage = null
            },
            new()
            {
                SubscriptionId = "subscriptionId1",
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = "0-12",
                Gender = "female",
                Followers = 300,
                Percentage = null
            },
            new()
            {
                SubscriptionId = "subscriptionId1",
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = "13-25",
                Gender = "female",
                Followers = 300,
                Percentage = null
            },
            new()
            {
                SubscriptionId = "subscriptionId1",
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = "026-39",
                Gender = "female",
                Followers = 300,
                Percentage = null
            },
            new()
            {
                SubscriptionId = "subscriptionId1",
                Source = null,
                Date = default,
                IsPrediction = false,
                Age = "0-12",
                Gender = "unknown",
                Followers = 300,
                Percentage = null
            },
        };

        var request = new SumRequest(SumType.Followers, channelIds, default, default);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes()))
            .ReturnsAsync(subscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<AgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), null, false))
            .ReturnsAsync(subscriptionFollowerSums);

        var actual = (await _sut.GenderSumAsync(request)).ToList();
        
        Assert.NotEmpty(actual);
        
        var femaleResult = actual.FirstOrDefault(g => g.Gender == "female");
        var maleResult = actual.FirstOrDefault(g => g.Gender == "male");
        var unknownResult = actual.FirstOrDefault(g => g.Gender == "unknown");

        Assert.NotNull(femaleResult);
        Assert.NotNull(maleResult);
        Assert.NotNull(unknownResult);
        
        Assert.Equal(2700, femaleResult.Followers);
        Assert.Equal(2700, maleResult.Followers);
        Assert.Equal(900, unknownResult.Followers);

        var femalePercentage = Math.Round(2700m / 6300m * 100, 2);
        var malePercentage = Math.Round(2700m / 6300m * 100, 2);
        var unknownPercentage = Math.Round(900m / 6300m * 100, 2);
        
        Assert.Equal(femalePercentage, femaleResult.Percentage);
        Assert.Equal(malePercentage, maleResult.Percentage);
        Assert.Equal(unknownPercentage, unknownResult.Percentage);

        _mockedSubscriptionsDao.Verify(sd => sd.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes()), Times.Exactly(1));
        _mockedDashboardDao.Verify(dd => dd.GetSumListAsync<AgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), null, false), Times.Exactly(3));
    }

    [Fact]
    public async Task TestThatSumGenderReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Gender, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = new[] { new AgeAndGenderSumItem { Date = DateTime.UtcNow, Age = "", Followers = 0, Gender = "" } };

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<AgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.SumGenderAsync(request);

        Assert.NotNull(actual);
    }

    [Theory]
    [InlineData(SumType.Age)]
    [InlineData(SumType.Gender)]
    [InlineData(SumType.AgeAndGender)]
    public async Task TestThatAgeAndGendersReturnsSuccessfulAsync(SumType sumType)
    {
        var request = new SumRequest(sumType, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = SumFactory.GetMockedAgeAndGenderSumItems("", "", 10);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<AgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.AgeAndGendersAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatAgeAndGendersThrowsWhenInvalidAsync()
    {
        var request = new SumRequest(SumType.Posts, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = SumFactory.GetMockedAgeAndGenderSumItems("", "", 10);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<AgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        await Assert.ThrowsAsync<NotSupportedException>(() => _sut.AgeAndGendersAsync(request));
    }

    [Theory]
    [InlineData(SumType.Age)]
    [InlineData(SumType.Gender)]
    [InlineData(SumType.AgeAndGender)]
    public async Task TestThatCampaignSumAgeAndGenderReturnsSuccessfulAsync(SumType sumType)
    {
        var request = new SumRequest(sumType, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = SumFactory.GetMockedCampaignsAgeAndGenderSumItems("", "", 20).Concat(SumFactory.GetMockedCampaignsAgeAndGenderSumItems("", "", 10));

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetCampaignSumListAsync<CampaignAgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<string>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.CampaignAgeAndGenderAsync(request, "1");

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumEmotionsReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Emotions, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = SumFactory.GetMockedEmotionSumItems("", "", 10);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<EmotionsSumItem>(It.IsAny<SumDaoRequest>(), null, It.IsAny<bool>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.SumEmotionsAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumHashtagsReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Keywords, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = SumFactory.GetMockedKeywordsSumItems(10);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedPostsDao.Setup(dd => dd.TopKeywordsAsync(It.IsAny<DaoRequest>(), It.IsAny<KeywordCategory>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.HashtagsAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumMentionsReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Keywords, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = SumFactory.GetMockedKeywordsSumItems(10);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedPostsDao.Setup(dd => dd.TopKeywordsAsync(It.IsAny<DaoRequest>(), It.IsAny<KeywordCategory>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.MentionsAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumCaptionsReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Keywords, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription() };
        var mockSumItems = SumFactory.GetMockedKeywordsSumItems(10);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedPostsDao.Setup(dd => dd.TopKeywordsAsync(It.IsAny<DaoRequest>(), It.IsAny<KeywordCategory>()))
            .ReturnsAsync(mockSumItems);

        var actual = await _sut.CaptionsAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatSumCountriesReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Country, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { SubscriptionType.AW_CAMPAIGN }.Select(e => new Subscription { ChannelId = "1", Id = e.ToString(), SubscriptionType = e }).ToArray();
        var expected = SumFactory.GetMockedCountrySumItems("", "", "", 20).Concat(SumFactory.GetMockedCountrySumItems("", "", "", 10));

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CountrySumItem>(It.IsAny<SumDaoRequest>(), null, It.IsAny<bool>()))
            .ReturnsAsync(expected);

        _mockedDashboardDao.Setup(dd => dd.GetSumLastAsync<CountrySumItem>(It.IsAny<SumDaoRequest>(), null))
            .ReturnsAsync(expected.Last());

        var actual = await _sut.CountriesAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatChartAsyncReturnsSuccessfulWithoutPreviousPeriodAsync()
    {
        var request = new SumRequest(SumType.Country, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription { Id = "1" } };
        var expected = SumFactory.GetMockedCountrySumItems("", "", "", 20).Concat(SumFactory.GetMockedCountrySumItems("", "", "", 10));

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CountrySumItem>(It.IsAny<SumDaoRequest>(), null, It.IsAny<bool>()))
            .ReturnsAsync(expected);

        var actual = await _sut.ChartAsync<CountrySumItem>(request, false);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatChartAsyncReturnsSuccessfulIncludingThePreviousPeriodAsync()
    {
        var request = new SumRequest(SumType.Country, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription { Id = "1" } };
        var expected = SumFactory.GetMockedCountrySumItems("", "", "", 20).Concat(SumFactory.GetMockedCountrySumItems("", "", "", 10));

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CountrySumItem>(It.IsAny<SumDaoRequest>(), null, It.IsAny<bool>()))
            .ReturnsAsync(expected);

        _mockedDashboardDao.Setup(dd => dd.GetSumFirstAsync<CountrySumItem>(It.IsAny<SumDaoRequest>(), null))
            .ReturnsAsync(expected.First());

        var actual = await _sut.ChartAsync<CountrySumItem>(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatAgeAndGendersChartAsyncReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.AgeAndGender, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription { Id = "1" } };
        var expected = SumFactory.GetMockedAgeAndGenderSumItems("", "", 20).Concat(SumFactory.GetMockedAgeAndGenderSumItems("", "", 10));

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<AgeAndGenderSumItem>(It.IsAny<SumDaoRequest>(), null, It.IsAny<bool>()))
            .ReturnsAsync(expected);

        var actual = await _sut.AgeAndGendersChartAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatTopKeywordsChartAsyncReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Keywords, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { new Subscription(), new Subscription { Id = "1" } };
        var expected = SumFactory.GetMockedKeywordsSumItems(20);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedPostsDao.Setup(dd => dd.TopKeywordsAsync(It.IsAny<DaoRequest>(), It.IsAny<KeywordCategory>()))
            .ReturnsAsync(expected);

        var actual = await _sut.TopKeywordsChartAsync(request, KeywordCategory.HASH);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatCampaignsChartAsyncReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Campaigns, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { SubscriptionType.AW_CAMPAIGN }.Select(e => new Subscription { ChannelId = "1", Id = e.ToString(), SubscriptionType = e }).ToArray();
        var expected = SumFactory.GetMockedCampaignsSumItems("1", "2", 20);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CampaignsSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(expected);

        var actual = await _sut.CampaignsChartAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatCountriesChartAsyncReturnsSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Country, [""], DateTime.Now, DateTime.Now);
        var mockSubscriptions = new[] { SubscriptionType.AW_CAMPAIGN }.Select(e => new Subscription { ChannelId = "1", Id = e.ToString(), SubscriptionType = e }).ToArray();
        var expected = SumFactory.GetMockedCountrySumItems("subscriptionId", "channelId", "2", 20);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(It.IsAny<string[]>(), It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(mockSubscriptions);

        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CountrySumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(expected);

        var actual = await _sut.CountriesChartAsync(request);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatCountriesChartAsyncUsesCountryRankSuccessfulAsync()
    {
        var request = new SumRequest(SumType.Country, ["channel_1", "channel_2"], DateTime.Now, DateTime.Now);

        var mockFollowerSubscriptions = new[] { SubscriptionType.FB, SubscriptionType.IGI }.Select((e, index) => new Subscription { Id = $"subscription_{index + 1}", ChannelId = $"channel_{index + 1}", SubscriptionType = e }).ToArray();
        var mockSubscriptions = new[] { SubscriptionType.FB_GEO_LIKES, SubscriptionType.IGI_COUNTRY }.Select((e, index) => new Subscription { Id = $"subscription_{index + 1}", ChannelId = $"channel_{index + 1}", SubscriptionType = e }).ToArray();

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(request.ChannelIds, SumType.Followers.ToSubscriptionTypes()))
            .ReturnsAsync(mockFollowerSubscriptions);

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByTypeAndChannelIdsAsync(request.ChannelIds, request.Type.ToSubscriptionTypes()))
            .ReturnsAsync(mockSubscriptions);

        // Mock 'Total followers' request
        var expectedTotalsItem = new GainedAndLostSumItem { Value = 5000 };
        _mockedDashboardDao.Setup(dd => dd.GetSumLastAsync<GainedAndLostSumItem>(It.IsAny<SumDaoRequest>(), It.IsAny<BsonDocument>()))
            .ReturnsAsync(expectedTotalsItem);

        // Mock Facebook "Data" request
        var expectedFacebook = SumFactory.GetMockedCountrySumItems("subscription_1", "channel_1", "source_1", 10);
        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CountrySumItem>(It.Is<SumDaoRequest>(request => request.SubscriptionType == SubscriptionType.FB_GEO_LIKES), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(expectedFacebook);

        // Mock Instagram "Data" request
        var expectedInstagram = SumFactory.GetMockedCountrySumItems("subscription_2", "channel_2", "source_2", 10);
        _mockedDashboardDao.Setup(dd => dd.GetSumListAsync<CountrySumItem>(It.Is<SumDaoRequest>(request => request.SubscriptionType == SubscriptionType.IGI_COUNTRY), It.IsAny<BsonDocument>(), It.IsAny<bool>()))
            .ReturnsAsync(expectedInstagram);

        var actual = await _sut.CountriesChartAsync(request);
        Assert.NotNull(actual);

        var facebookChartData = actual.FirstOrDefault(chart => chart.ChannelId == "channel_1");
        Assert.NotNull(facebookChartData);

        var instagramChartData = actual.FirstOrDefault(chart => chart.ChannelId == "channel_2");
        Assert.NotNull(instagramChartData);

        Assert.Equal(facebookChartData.Values?.FirstOrDefault()?.CountryCode, instagramChartData.Values?.FirstOrDefault()?.CountryCode);
    }
}