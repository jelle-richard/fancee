using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.ChannelInfo;
using SuperMetricsService.Persistence.ChannelInfo;
using SuperMetricsService.Persistence.Subscriptions;
using SuperMetricsService.Services.ChannelInfo;
using SuperMetricsService.TestData;

namespace SuperMetricsService.Tests.Services.ChannelInfos;

public class ChannelInfoServiceTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    private readonly ChannelInfoService _sut;
    private readonly Mock<IChannelInfoDao> _mockedChannelInfoDao = new();
    private readonly Mock<ISubscriptionsDao> _mockedSubscriptionsDao = new();

    public ChannelInfoServiceTests()
    {
        _sut = new(_mockedChannelInfoDao.Object, _mockedSubscriptionsDao.Object);
    }

    [Fact]
    public async Task TestThatChannelReachAsyncCallsChannelInfoDaoChannelReachAsync()
    {
        MockSubscriptionTypes(new[] { SubscriptionType.FB, SubscriptionType.FB_AGE_AND_GENDER, SubscriptionType.FB_GEO_LIKES, SubscriptionType.FB_POSTS });

        _mockedChannelInfoDao.Setup(gd => gd.ChannelReachAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(new ChannelReach
            {
                Name = "",
                Description = "",
                TotalFollowers = 1,
                IncreasedFollowers = 2,
                PercentIncreaseFollowers = 3,
                Reach = 4,
                ActiveFollowers = 5,
                AverageAge = 6,
                PercentMen = 7,
                PercentWomen = 8,
                Shares = 9,
                Likes = 10,
                Comments = 11,
                ClicksOnPage = 12
            });

        var actual = await _sut.ChannelReachAsync(ChannelId, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow);

        Assert.Equal(1, actual.TotalFollowers);

        _mockedChannelInfoDao.Verify(gd => gd.ChannelReachAsync(It.IsAny<DaoRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatChannelReachAsyncCallsChannelReachFollowersWhenInstagram()
    {
        MockSubscriptionTypes(new[] { SubscriptionType.IGI, SubscriptionType.IGI_PROFILE_DATA });

        _mockedChannelInfoDao.Setup(gd => gd.ChannelReachAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(new ChannelReach());
        _mockedChannelInfoDao.Setup(gd => gd.ChannelReachFollowersAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(new ChannelReach());

        var actual = await _sut.ChannelReachAsync(ChannelId, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow);

        _mockedChannelInfoDao.Verify(gd => gd.ChannelReachAsync(It.IsAny<DaoRequest>()), Times.Once);
        _mockedChannelInfoDao.Verify(gd => gd.ChannelReachFollowersAsync(It.IsAny<DaoRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatChannelGrowthAsyncCallsChannelInfoDaoChannelGrowthAsync()
    {
        var mockedChannelGrowths = ChannelInfoFactory.GetChannelGrowths();

        MockSubscriptionTypes(new[] { SubscriptionType.FB, SubscriptionType.FB_AGE_AND_GENDER, SubscriptionType.FB_GEO_LIKES, SubscriptionType.FB_POSTS });

        _mockedChannelInfoDao.Setup(cid => cid.ChannelGrowthAsync(It.IsAny<string>(), It.IsAny<SubscriptionType>()))
            .ReturnsAsync(mockedChannelGrowths);

        var actual = await _sut.ChannelGrowthAsync(ChannelId);

        Assert.Equal(mockedChannelGrowths.First().Gained, actual.First().Gained);

        _mockedChannelInfoDao.Verify(cid => cid.ChannelGrowthAsync(It.IsAny<string>(), It.IsAny<SubscriptionType>()), Times.Once);
    }

    private void MockSubscriptionTypes(IEnumerable<SubscriptionType> subscriptionTypes)
    {
        List<Subscription> subscriptions = new();
        foreach (var subscriptionType in subscriptionTypes)
        {
            subscriptions.Add(
                new()
                {
                    Id = SubscriptionId,
                    ChannelId = ChannelId,
                    Input = subscriptionType.ToInput(),
                    SubscriptionType = subscriptionType
                });
        }

        _mockedSubscriptionsDao.Setup(sd => sd.ToListByChannelIdAsync(It.IsAny<string>()))
            .ReturnsAsync(subscriptions);
    }
}