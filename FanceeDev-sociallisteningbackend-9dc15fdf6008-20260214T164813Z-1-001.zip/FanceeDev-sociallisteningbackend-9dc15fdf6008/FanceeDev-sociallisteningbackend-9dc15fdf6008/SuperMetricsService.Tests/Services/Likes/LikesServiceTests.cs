using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Helpers;
using SuperMetricsService.Dtos.Responses.Likes;
using SuperMetricsService.Persistence.Likes;
using SuperMetricsService.Persistence.Subscriptions;
using SuperMetricsService.Services.Likes;
using SuperMetricsService.TestData;

namespace SuperMetricsService.Tests.Services.Likes;

public class LikesServiceTests
{
    private readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    private readonly LikesService _sut;
    private readonly Mock<ILikesDao> _mockedLikesDao = new();
    private readonly Mock<ISubscriptionsDao> _mockedSubscriptionsDao = new();

    public LikesServiceTests()
    {
        _sut = new(_mockedLikesDao.Object, _mockedSubscriptionsDao.Object);
        _mockedSubscriptionsDao.Setup(sd => sd.ToListByChannelIdAsync(ChannelId))
            .ReturnsAsync(new[]
            {
                new Subscription
                {
                    Id = SubscriptionId,
                    ChannelId = ChannelId,
                    SubscriptionType = SubscriptionType.FB
                },
                new Subscription
                {
                    Id = SubscriptionId,
                    ChannelId = ChannelId,
                    SubscriptionType = SubscriptionType.FB_AGE_AND_GENDER
                },
                new Subscription
                {
                    Id = SubscriptionId,
                    ChannelId = ChannelId,
                    SubscriptionType = SubscriptionType.FB_GEO_LIKES
                },
                new Subscription
                {
                    Id = SubscriptionId,
                    ChannelId = ChannelId,
                    SubscriptionType = SubscriptionType.FB_POSTS
                }
            });
    }

    [Fact]
    public async Task TestThatGeoLikesAsyncCallsLikesDaoGeoLikesAsync()
    {
        SetupGetSubscription(SubscriptionType.FB_GEO_LIKES);

        _mockedLikesDao.Setup(ld => ld.GeoLikesAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(new List<GeoLikesStatistics>
            {
                new()
                {
                    CountryCode = CountryCode.NL,
                    LikesAmount = 123
                }
            });

        var actual = await _sut.GeoLikesAsync(ChannelId, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow);

        Assert.Single(actual);
        Assert.Equal(123, actual.First().LikesAmount);

        _mockedLikesDao.Verify(ld => ld.GeoLikesAsync(It.IsAny<DaoRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCountryLikesAsyncCallsLikesDaoCountryLikesAsync()
    {
        SetupGetSubscription(SubscriptionType.FB_GEO_LIKES);
        _mockedLikesDao.Setup(ld => ld.CountryLikesAsync(It.IsAny<DaoRequest>(), It.IsAny<CountryCode>()))
            .ReturnsAsync(new List<LikesHistory>
            {
                new()
                {
                    Date = DateTime.UtcNow.AddDays(-1),
                    LikesAmount = 111
                },
                new()
                {
                    Date = DateTime.UtcNow,
                    LikesAmount = 117
                }
            });

        var actual = await _sut.CountryLikesAsync(ChannelId, CountryCode.NL, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow);

        Assert.Equal(2, actual.Count());
        Assert.Equal(111, actual.First().LikesAmount);

        _mockedLikesDao.Verify(ld => ld.CountryLikesAsync(It.IsAny<DaoRequest>(), It.IsAny<CountryCode>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGeoLikesWithGainsAsyncCallsLikesDaoGeoLikesWithGainAsync()
    {
        SetupGetSubscription(SubscriptionType.FB_GEO_LIKES);
        _mockedLikesDao.Setup(ld => ld.GeoLikesAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(new List<GeoLikesStatistics>
            {
                new()
                {
                    CountryCode = CountryCode.NL,
                    LikesAmount = 123,
                    LikesGained = 789
                }
            });

        var actual = await _sut.GeoLikesWithGainsAsync(ChannelId, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow);

        Assert.Single(actual);
        Assert.Equal(123, actual.First().LikesAmount);
        Assert.Equal(789, actual.First().LikesGained);
        Assert.Equal(0, actual.First().ImprovementPercentage);

        _mockedLikesDao.Verify(ld => ld.GeoLikesAsync(It.IsAny<DaoRequest>()), Times.AtLeastOnce);
    }

    [Fact]
    public async Task TestThatEmotionLikesAsyncCallsLikesDaoEmotionLikesAsync()
    {
        SetupGetSubscription(SubscriptionType.FB_POSTS);
        var emotionLikes = LikesFactory.MockedEmotionLikes();

        _mockedLikesDao.Setup(ld => ld.EmotionLikesAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(emotionLikes);

        var actual = await _sut.EmotionLikesAsync(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.Equal(emotionLikes.Length, actual.Count());
        Assert.Equal(emotionLikes.First().Amount, actual.First().Amount);
        Assert.Equal(emotionLikes.First().Emotion, actual.First().Emotion);

        _mockedLikesDao.Verify(ld => ld.EmotionLikesAsync(It.IsAny<DaoRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGenderLikesAsyncCallsLikesDaoGenderLikesAsync()
    {
        SetupGetSubscription(SubscriptionType.FB_AGE_AND_GENDER);
        var genderLikesStatistics = LikesFactory.MockGenderLikes();

        _mockedLikesDao.Setup(ld => ld.GenderLikesAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(genderLikesStatistics);

        var actual = await _sut.GenderLikesAsync(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.Equal(genderLikesStatistics.Length, actual.Count());
        Assert.Equal(genderLikesStatistics.First().Gender, actual.First().Gender);
        Assert.Equal(genderLikesStatistics.First().LikesAmount, actual.First().LikesAmount);

        _mockedLikesDao.Verify(ld => ld.GenderLikesAsync(It.IsAny<DaoRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAgeLikesAsyncCallsLikesDaoAgeLikesAsync()
    {
        SetupGetSubscription(SubscriptionType.FB_AGE_AND_GENDER);
        var ageLikesStatistics = LikesFactory.MockedAgeLikes();

        _mockedLikesDao.Setup(ld => ld.AgeLikesAsync(It.IsAny<DaoRequest>()))
            .ReturnsAsync(ageLikesStatistics);

        var actual = await _sut.AgeLikesAsync(ChannelId, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow);

        Assert.Equal(ageLikesStatistics.Length, actual.Count());
        Assert.Equal(ageLikesStatistics.First().Age, actual.First().Age);
        Assert.Equal(ageLikesStatistics.First().LikesAmount, actual.First().LikesAmount);

        _mockedLikesDao.Verify(ld => ld.AgeLikesAsync(It.IsAny<DaoRequest>()), Times.Once);
    }

    private void SetupGetSubscription(SubscriptionType subscriptionType)
    {
        _mockedSubscriptionsDao.Setup(sd => sd.FirstAsync(ChannelId, It.IsAny<SubscriptionType[]>()))
            .ReturnsAsync(new Subscription
            {
                Id = SubscriptionId,
                ChannelId = ChannelId,
                Input = subscriptionType.ToInput(),
                SubscriptionType = subscriptionType
            });
    }
}