using DataSynchronisationService.Persistence.Users;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.TicketingData;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using TestCore.Utils.UnitTestsHelpers;

namespace DataSynchronisationService.Tests.Persistence.Users;

public class ClientDaoTests
{
    private static readonly Guid UserId = Guid.NewGuid();

    private static readonly Client Client = new()
    {
        Id = "objectId1",
        CreatedOn = default,
        UpdatedOn = default,
        UserId = UserId,
        FacebookId = null,
        Referer = null,
        User = new()
        {
            Id = "ObjectId2",
            CreatedOn = default,
            UpdatedOn = default,
            UserId = UserId,
            FanceeUsersId = UserId,
            Type = UserType.Client,
            Email = "client@unit.test.com"
        }
    };

    private readonly Mock<IMongoCollection<Client>> _mockedClientCollection = new();
    private readonly Mock<IMongoDatabase> _mockedMongoDatabase = new();
    private readonly Mock<IMongoClient> _mockedContext = new();
    private readonly Mock<IAsyncCursor<Client>> _mockedCursor = new();
    private readonly ClientDao _sut;

    public ClientDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration(
            new()
            {
                { "Mongo:Database:Default", "test_database" },
                { "ConnectionStrings:Mongo", "Mongo" }
            }
        );

        _mockedMongoDatabase.Setup(md => md.GetCollection<Client>(It.IsAny<string>(), null))
            .Returns(_mockedClientCollection.Object);

        _mockedClientCollection.Setup(c =>
            c.FindAsync(
                It.IsAny<FilterDefinition<Client>>(),
                It.IsAny<FindOptions<Client>>(),
                It.IsAny<CancellationToken>()
            )
        ).ReturnsAsync(_mockedCursor.Object);

        _mockedCursor.SetupSequence(c => c.MoveNextAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(true).ReturnsAsync(false);

        _mockedContext.Setup(c => c.GetDatabase(It.IsAny<string>(), null))
            .Returns(_mockedMongoDatabase.Object);

        _sut = new(configuration, _mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAnyAsyncCallsCursorMethodsAndReturnsValue()
    {
        _mockedCursor.Setup(c => c.Current)
            .Returns([Client]);

        var filter = new FilterDefinitionBuilder<Client>().Eq(c => c.UserId, UserId);
        var actual = await _sut.AnyAsync(filter);

        _mockedCursor.Verify(c => c.Current, Times.Once);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatCreateAsyncCallsCollectionInsertOneAsync()
    {
        await _sut.CreateAsync(Client);
        _mockedClientCollection.Verify(c => c.InsertOneAsync(Client, null, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsCollectionMethods()
    {
        var filter = Builders<Client>.Filter.Eq(c => c.Id, Client.Id);

        await _sut.UpdateAsync(Client, filter);

        _mockedClientCollection.Verify(c => c.UpdateOneAsync(
                filter,
                It.IsAny<UpdateDefinition<Client>>(),
                null,
                It.IsAny<CancellationToken>()),
            Times.Once
        );
    }

    [Fact]
    public async Task TestThatRetrieveExistingDataAsyncCallsCursorMethodsAndReturnsExpectedIds()
    {
        var expectedClientList = new List<Client> { Client };
        var expectedUserIdList = new List<Guid> { Client.UserId };

        _mockedCursor.Setup(c => c.Current).Returns(expectedClientList);

        var actual = await _sut.RetrieveExistingDataAsync();

        _mockedCursor.Verify(c => c.Current, Times.Once);

        Assert.Equal(expectedUserIdList, actual);
    }

    [Fact]
    public async Task TestThatDeleteByIdAsyncCallsDeleteByFilterAsync()
    {
        await _sut.DeleteByIdAsync(UserId);

        _mockedClientCollection.Verify(c =>
                c.DeleteOneAsync(
                    It.IsAny<FilterDefinition<Client>>(),
                    It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteByIdsAsyncCallsDeleteByFilterAsync()
    {
        var ids = new List<Guid> { UserId };
        await _sut.DeleteByIdsAsync(ids);

        _mockedClientCollection.Verify(c =>
                c.DeleteOneAsync(
                    It.IsAny<FilterDefinition<Client>>(),
                    It.IsAny<CancellationToken>()),
            Times.Once);
    }

    [Fact]
    public void TestThatCreatingDaoWithoutConfigurationThrowsMongoDatabaseStringNotFoundException() =>
        Assert.Throws<MongoDatabaseStringNotFoundException>(() => new ClientDao(MockDBConfiguration.GetDBConfiguration(
            new()
            {
                { "ConnectionStrings:Mongo", "Mongo" }
            }
        ), _mockedContext.Object));
}