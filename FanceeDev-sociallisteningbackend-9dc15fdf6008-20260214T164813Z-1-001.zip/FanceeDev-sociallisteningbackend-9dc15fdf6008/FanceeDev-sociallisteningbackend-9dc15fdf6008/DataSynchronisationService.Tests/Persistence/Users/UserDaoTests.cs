using DataSynchronisationService.Persistence.Users;
using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using TestCore.Utils.UnitTestsHelpers;
using User = FanceeAnalyticsData.Models.TicketingData.User;

namespace DataSynchronisationService.Tests.Persistence.Users;

public class UserDaoTests
{
    private static readonly Guid UserId = Guid.NewGuid();

    private static readonly User User = new()
    {
        Id = "ObjectId2",
        CreatedOn = default,
        UpdatedOn = default,
        UserId = UserId,
        FanceeUsersId = UserId,
        Type = UserType.Client,
        Email = "user@unit.test.com"
    };

    private readonly Mock<IMongoCollection<User>> _mockedUserCollection = new();
    private readonly Mock<IMongoDatabase> _mockedMongoDatabase = new();
    private readonly Mock<IMongoClient> _mockedContext = new();
    private readonly Mock<IAsyncCursor<User>> _mockedCursor = new();
    private readonly UserDao _sut;

    public UserDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration(
            new()
            {
                { "Mongo:Database:Default", "test_database" },
                { "ConnectionStrings:Mongo", "Mongo" }
            }
        );

        _mockedContext.Setup(c => c.GetDatabase(It.IsAny<string>(), null))
            .Returns(_mockedMongoDatabase.Object);

        _mockedMongoDatabase.Setup(md => md.GetCollection<User>(It.IsAny<string>(), null))
            .Returns(_mockedUserCollection.Object);

        _mockedUserCollection.Setup(c =>
            c.FindAsync(
                It.IsAny<FilterDefinition<User>>(),
                It.IsAny<FindOptions<User>>(),
                It.IsAny<CancellationToken>()
            )
        ).ReturnsAsync(_mockedCursor.Object);

        _mockedCursor.SetupSequence(c => c.MoveNextAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(true).ReturnsAsync(false);

        _sut = new(configuration, _mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAnyAsyncCallsCursorMethodsAndReturnsValue()
    {
        _mockedCursor.Setup(c => c.Current)
            .Returns(new List<User> { User });

        var filter = new FilterDefinitionBuilder<User>().Eq(u => u.UserId, UserId);
        var actual = await _sut.AnyAsync(filter);

        _mockedCursor.Verify(c => c.Current, Times.Once);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatCreateAsyncCallsCollectionInsertOneAsync()
    {
        await _sut.CreateAsync(User);
        _mockedUserCollection.Verify(c => c.InsertOneAsync(User, null, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsCollectionMethods()
    {
        var filter = Builders<User>.Filter.Eq(u => u.Id, User.Id);

        await _sut.UpdateAsync(User, filter);

        _mockedUserCollection.Verify(c =>
                c.UpdateOneAsync(
                    filter,
                    It.IsAny<UpdateDefinition<User>>(),
                    null,
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task TestThatDeleteByIdsAsyncCallsCollectionDeleteOneAsync()
    {
        await _sut.DeleteByIdsAsync([UserId]);

        _mockedUserCollection.Verify(c =>
                c.DeleteOneAsync(It.IsAny<FilterDefinition<User>>(), It.IsAny<CancellationToken>()),
            Times.Once
        );
    }
}