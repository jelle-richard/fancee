using DataSynchronisationService.Persistence.Generic;
using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using TestCore.Utils.UnitTestsHelpers;

namespace DataSynchronisationService.Tests.Persistence.Generic;

public class GenericTicketingDataDaoTests
{
    private const string CollectionName = "unit-test-collection";

    private static readonly DateTime Now = DateTime.UtcNow;

    private static readonly List<BasicMongoModel> Models =
    [
        new()
        {
            Id = "1",
            CreatedOn = Now,
            UpdatedOn = Now
        },

        new()
        {
            Id = "2",
            CreatedOn = DateTime.UtcNow.AddDays(1),
            UpdatedOn = DateTime.UtcNow.AddDays(1)
        },

        new()
        {
            Id = "3",
            CreatedOn = DateTime.UtcNow.AddDays(2),
            UpdatedOn = DateTime.UtcNow.AddDays(2)
        },

        new()
        {
            Id = "4",
            CreatedOn = DateTime.UtcNow.AddDays(3),
            UpdatedOn = DateTime.UtcNow.AddDays(3)
        }
    ];

    private readonly Mock<IMongoCollection<BasicMongoModel>> _mockedBasicMongoModelCollection = new();
    private readonly Mock<IMongoDatabase> _mockedMongoDatabase = new();
    private readonly Mock<IMongoClient> _mockedContext = new();
    private readonly Mock<IAsyncCursor<BasicMongoModel>> _mockedCursor = new();
    private readonly GenericTicketingDataDao _sut;

    public GenericTicketingDataDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration(
            new()
            {
                { "Mongo:Database:Default", "test_database" },
                { "ConnectionStrings:Mongo", "Mongo" }
            }
        );

        _mockedContext.Setup(c => c.GetDatabase(It.IsAny<string>(), null))
            .Returns(_mockedMongoDatabase.Object);

        _mockedMongoDatabase.Setup(md => md.GetCollection<BasicMongoModel>(It.IsAny<string>(), null))
            .Returns(_mockedBasicMongoModelCollection.Object);

        _mockedBasicMongoModelCollection.Setup(c =>
            c.FindAsync(
                It.IsAny<FilterDefinition<BasicMongoModel>>(),
                It.IsAny<FindOptions<BasicMongoModel>>(),
                It.IsAny<CancellationToken>()
            )
        ).ReturnsAsync(_mockedCursor.Object);

        _mockedCursor.SetupSequence(c => c.MoveNextAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(true).ReturnsAsync(false);

        _sut = new(configuration, _mockedContext.Object);
    }

    [Fact]
    public async Task TestThatGetLastCreatedRecordAsyncShouldReturnLastCreatedRecord()
    {
        _mockedCursor.Setup(c => c.Current).Returns(Models);

        var actual = await _sut.GetLastCreatedRecordAsync(CollectionName);

        Assert.Equal(Models.FirstOrDefault(), actual);
    }

    [Fact]
    public async Task TestThatGetLastUpdatedRecordAsyncShouldReturnLastUpdatedRecord()
    {
        _mockedCursor.Setup(c => c.Current).Returns(Models);

        var actual = await _sut.GetLastUpdatedRecordAsync(CollectionName);

        Assert.Equal(Models.FirstOrDefault(), actual);
    }
}