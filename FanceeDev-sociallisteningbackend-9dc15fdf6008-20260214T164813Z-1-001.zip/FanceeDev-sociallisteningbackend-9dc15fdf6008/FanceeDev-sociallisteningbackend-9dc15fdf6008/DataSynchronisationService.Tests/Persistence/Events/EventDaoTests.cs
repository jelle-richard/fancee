using DataSynchronisationService.Persistence.Events;
using DataSynchronisationService.Tests.MockData;
using FanceeAnalyticsData.Models.TicketingData;
using MongoDB.Driver;
using TestCore.Utils.UnitTestsHelpers;

namespace DataSynchronisationService.Tests.Persistence.Events;

public class EventDaoTests
{
    private readonly Mock<IMongoCollection<Event>> _mockedEventCollection = new();
    private readonly Mock<IMongoDatabase> _mockedMongoDatabase = new();
    private readonly Mock<IMongoClient> _mockedContext = new();
    private readonly Mock<IAsyncCursor<Event>> _mockedCursor = new();
    private readonly EventDao _sut;

    public EventDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration(
            new()
            {
                { "Mongo:Database:Default", "test_database" },
                { "ConnectionStrings:Mongo", "Mongo" }
            }
        );

        _mockedContext.Setup(c => c.GetDatabase(It.IsAny<string>(), null))
            .Returns(_mockedMongoDatabase.Object);

        _mockedMongoDatabase.Setup(md => md.GetCollection<Event>(It.IsAny<string>(), null))
            .Returns(_mockedEventCollection.Object);

        _mockedEventCollection.Setup(c =>
            c.FindAsync(
                It.IsAny<FilterDefinition<Event>>(),
                It.IsAny<FindOptions<Event>>(),
                It.IsAny<CancellationToken>()
            )
        ).ReturnsAsync(_mockedCursor.Object);

        _mockedCursor.SetupSequence(c => c.MoveNextAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(true).ReturnsAsync(false);

        _sut = new(configuration, _mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAnyAsyncCallsCursorMethodsAndReturnsValue()
    {
        _mockedCursor.Setup(c => c.Current)
            .Returns(new List<Event> { MockedEvents.Event });

        var filter = new FilterDefinitionBuilder<Event>().Eq(u => u.EventId, MockedEvents.EventIds[0]);
        var actual = await _sut.AnyAsync(filter);

        _mockedCursor.Verify(c => c.Current, Times.Once);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatCreateAsyncCallsCollectionInsertOneAsync()
    {
        await _sut.CreateAsync(MockedEvents.Event);
        _mockedEventCollection.Verify(c => c.InsertOneAsync(MockedEvents.Event, null, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsCollectionMethods()
    {
        var filter = Builders<Event>.Filter.Eq(u => u.Id, MockedEvents.Event.Id);

        await _sut.UpdateAsync(MockedEvents.Event, filter);

        _mockedEventCollection.Verify(c =>
                c.UpdateOneAsync(
                    filter,
                    It.IsAny<UpdateDefinition<Event>>(),
                    null,
                    It.IsAny<CancellationToken>()
                ),
            Times.Once
        );
    }

    [Fact]
    public async Task TestThatDeleteByIdAsyncCallsCollectionDeleteOneAsync()
    {
        await _sut.DeleteByIdsAsync(MockedEvents.EventIds);

        _mockedEventCollection.Verify(c =>
                c.DeleteOneAsync(It.IsAny<FilterDefinition<Event>>(), It.IsAny<CancellationToken>()),
            Times.Once
        );
    }
}