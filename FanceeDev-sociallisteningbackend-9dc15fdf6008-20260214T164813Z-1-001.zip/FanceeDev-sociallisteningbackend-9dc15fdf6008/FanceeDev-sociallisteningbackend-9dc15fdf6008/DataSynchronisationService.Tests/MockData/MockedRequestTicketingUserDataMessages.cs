using System.Text.Json;
using SocialListeningCore.Dtos.Enums;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedRequestTicketingUserDataMessages
{
    public static readonly List<Guid> ExistingUserIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly RequestTicketingUserDataMessage UpdateRequest = new()
    {
        SyncType = SynchronisationType.ValidateExistingAndOrUpdate,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingUserIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = string.Empty
    };

    public static readonly RequestTicketingUserDataMessage UpdateRequestReply = new()
    {
        SyncType = SynchronisationType.ValidateExistingAndOrUpdate,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingUserIds,
        SerializedUpdatedData = JsonSerializer.Serialize(MockedClients.Clients),
        SerializedCreatedData = string.Empty
    };

    public static readonly RequestTicketingUserDataMessage CreateRequestReply = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingUserIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = JsonSerializer.Serialize(MockedClients.Clients)
    };

    public static readonly RequestTicketingUserDataMessage CreateRequest = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingUserIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = string.Empty
    };

    public static readonly RequestTicketingUserDataMessage FaultyRequest = new()
    {
        SyncType = (SynchronisationType)5,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingUserIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = string.Empty
    };
}