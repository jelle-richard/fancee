using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.TicketingData;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedClients
{
    public static readonly Guid UserId = Guid.NewGuid();

    public static readonly Client Client = new()
    {
        Id = "1",
        CreatedOn = default,
        UpdatedOn = default,
        UserId = UserId,
        FacebookId = null,
        Referer = null,
        User = new()
        {
            Id = "1",
            CreatedOn = default,
            UpdatedOn = default,
            UserId = UserId,
            FanceeUsersId = UserId,
            Type = UserType.Client,
            Email = "mail@unit.test.com",
            LastLogin = default,
            DateOfBirth = default,
            AccountVerifyId = null,
            UserContactInfo = new()
            {
                FirstName = "unit",
                LastName = "test",
                AddressId = Guid.NewGuid(),
                PhoneNumber = "0612345678",
                Address = new()
                {
                    Id = Guid.NewGuid(),
                    CountryCode = "NL",
                    PostalCode = "1000AA",
                    Street = "Straatweg",
                    City = "Amsterdam",
                    HouseNumber = "100",
                    Venue = null,
                    Latitude = null,
                    Longitude = null
                }
            }
        }
    };

    public static readonly Client[] Clients =
    [
        Client
    ];
}