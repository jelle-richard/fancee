using FanceeAnalyticsData.Models.TicketingData;
using FanceeAnalyticsData.Models.TicketingData.Enums;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedEvents
{
    public static readonly Guid[] EventIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] OrganizationIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] AddressIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly Guid[] ProductIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly string[] ShopCodes =
    [
        "ShopCode A",
        "ShopCode B"
    ];

    public static readonly Event Event = new()
    {
        Id = "ObjectId1",
        CreatedOn = default,
        UpdatedOn = default,
        EventId = EventIds[0],
        OrganizationId = OrganizationIds[0],
        Name = "Event A",
        Type = EventType.Normal,
        StartDate = default,
        EndDate = default,
        Status = EventStatus.Active,
        Description = "Description",
        AddressId = AddressIds[0],
        ReservationTimeMinutes = 30,
        Address = new()
        {
            Id = AddressIds[0],
            CountryCode = "NL",
            PostalCode = "0000AA",
            Street = "Street",
            City = "City",
            HouseNumber = "420",
            Venue = "Venue"
        },
        Products =
        [
            new()
            {
                Id = ProductIds[0],
                Name = "Product A",
                Stock = 100,
                PriceCents = 1000,
                FeeCents = 50,
                Description = "Description of Product A",
                MaximumPurchasePerOrder = 5,
                PackQuantity = 0,
                Type = ProductType.Product
            }
        ],
        Shops =
        [
            new()
            {
                Code = ShopCodes[0],
                Name = "Shop A",
                Active = true,
                Tags =
                [
                    "Tag A",
                    "Tag B"
                ]
            }
        ]
    };

    public static readonly Event[] Events =
    [
        Event
    ];
}