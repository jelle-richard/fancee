using System.Text.Json;
using SocialListeningCore.Dtos.Enums;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Tests.MockData;

public static class MockedRequestTicketingEventDataMessages
{
    public static readonly List<Guid> ExistingEventIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    public static readonly RequestTicketingEventDataMessage UpdateRequest = new()
    {
        SyncType = SynchronisationType.ValidateExistingAndOrUpdate,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingEventIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = string.Empty
    };

    public static readonly RequestTicketingEventDataMessage UpdateRequestReply = new()
    {
        SyncType = SynchronisationType.ValidateExistingAndOrUpdate,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingEventIds,
        SerializedUpdatedData = JsonSerializer.Serialize(MockedEvents.Events),
        SerializedCreatedData = string.Empty
    };

    public static readonly RequestTicketingEventDataMessage CreateRequestReply = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingEventIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = JsonSerializer.Serialize(MockedEvents.Events)
    };

    public static readonly RequestTicketingEventDataMessage CreateRequest = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingEventIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = string.Empty
    };

    public static readonly RequestTicketingEventDataMessage FaultyRequest = new()
    {
        SyncType = (SynchronisationType)5,
        RequestCreatedFrom = DateTime.UtcNow,
        RequestUpdateFor = ExistingEventIds,
        SerializedUpdatedData = string.Empty,
        SerializedCreatedData = string.Empty
    };
}