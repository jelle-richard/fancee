using DataSynchronisationService.Jobs;
using DataSynchronisationService.Services;
using Microsoft.Extensions.Logging;
using TestCore.Utils.UnitTestsHelpers;

namespace DataSynchronisationService.Tests.Jobs;

public class InitRequestTicketingDataJobTests
{
    private const string Name = nameof(InitRequestTicketingDataJob);
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ISynchronisationService> _mockedSynchronisationService = new();
    private readonly Mock<ILogger> _mockedLogger = new();
    private readonly Mock<ILoggerFactory> _mockedLoggerFactory = new();

    private readonly InitRequestTicketingDataJob _sut;

    public InitRequestTicketingDataJobTests()
    {
        _mockedLoggerFactory.Setup(lf => lf.CreateLogger(It.IsAny<string>()))
            .Returns(_mockedLogger.Object);

        _sut = new(_mockedServiceProvider.Object, _mockedLoggerFactory.Object);
    }

    [Fact]
    public async Task TestThatExecuteAsyncCallsUnderlyingMethods()
    {
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ISynchronisationService)))
            .Returns(_mockedSynchronisationService.Object);

        await _sut.ExecuteAsync();

        _mockedServiceProvider.Verify(sp => sp.GetService(typeof(ISynchronisationService)), Times.Once);
        _mockedSynchronisationService.Verify(ss => ss.InitializeSyncJobs(), Times.Once);

        _mockedLogger.VerifyLoggingEndsWith(
            $"{Name} started.",
            LogLevel.Information,
            Times.Exactly(1));
        _mockedLogger.VerifyLoggingEndsWith(
            $"{Name} stopped.",
            LogLevel.Information,
            Times.Exactly(1));
    }
}