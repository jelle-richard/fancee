using DataSynchronisationService.Jobs.Inputs;
using DataSynchronisationService.Persistence.Generic;
using DataSynchronisationService.Services;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Dtos.Enums;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;
using SocialListeningCore.Services.Scheduler;
using SocialListeningCore.Utils.Cron;

namespace DataSynchronisationService.Tests.Services;

public class SynchronisationServiceTests
{
    private static readonly DateTime CreatedNow = DateTime.UtcNow;
    private static readonly DateTime UpdatedNow = DateTime.UtcNow;

    private static readonly BasicMongoModel BasicMongoModel = new()
    {
        Id = "1",
        CreatedOn = CreatedNow,
        UpdatedOn = UpdatedNow
    };

    private static readonly RequestTicketingDataInput Input = new()
    {
        Id = "1",
        CreatedOn = CreatedNow,
        UpdatedOn = UpdatedNow,
        Name = "RequestTicketingDataInput",
        Cron = CronConstants.CronRunEveryMinute,
        Active = true,
        RunOnce = false,
        Type = TicketingDataType.Clients,
        SyncType = SynchronisationType.FetchNewlyCreated
    };

    private static readonly RequestTicketingDataInput FaultyInput = new()
    {
        Id = "1",
        CreatedOn = CreatedNow,
        UpdatedOn = UpdatedNow,
        Name = "RequestTicketingDataInput",
        Cron = CronConstants.CronRunEveryMinute,
        Active = true,
        RunOnce = false,
        Type = (TicketingDataType)2,
        SyncType = SynchronisationType.FetchNewlyCreated
    };

    private readonly Mock<ISchedulerService<RequestTicketingDataInput>> _mockedSchedulerService = new();
    private readonly Mock<IGenericTicketingDataDao> _mockedGenericTicketingDataDao = new();
    private readonly Mock<DataSynchronisationService.Services.DataMessageStrategy.DataMessageStrategy> _mockedClientDataStrategy = new();
    private readonly Mock<DataSynchronisationService.Services.DataMessageStrategy.DataMessageStrategy> _mockedProductDataStrategy = new();
    private readonly List<DataSynchronisationService.Services.DataMessageStrategy.DataMessageStrategy> _mockedDataMessageStrategies = [];

    private readonly SynchronisationService _sut;

    public SynchronisationServiceTests()
    {
        _mockedGenericTicketingDataDao.Setup(gtdd => gtdd.GetLastCreatedRecordAsync(It.IsAny<string>()))
            .ReturnsAsync(BasicMongoModel);

        _mockedGenericTicketingDataDao.Setup(gtdd => gtdd.GetLastUpdatedRecordAsync(It.IsAny<string>()))
            .ReturnsAsync(BasicMongoModel);

        _mockedProductDataStrategy.Setup(pds => pds.Type)
            .Returns((TicketingDataType)2);

        _mockedClientDataStrategy.Setup(cds => cds.Type)
            .Returns(TicketingDataType.Clients);

        _mockedDataMessageStrategies.AddRange([_mockedClientDataStrategy.Object, _mockedProductDataStrategy.Object]);

        _sut = new(_mockedSchedulerService.Object, _mockedDataMessageStrategies, _mockedGenericTicketingDataDao.Object);
    }

    [Fact]
    public async Task TestThatRunAsyncCallsUnderlyingMethods()
    {
        await _sut.RunAsync(Input);

        _mockedGenericTicketingDataDao.Verify(gtdd => gtdd.GetLastCreatedRecordAsync(It.IsAny<string>()), Times.Once);
        _mockedClientDataStrategy.Verify(cds => cds.ExecuteAsync(It.IsAny<RequestTicketingUserDataMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRunAsyncThrowsArgumentOutOfRangeException()
    {
        await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() => _sut.RunAsync(FaultyInput));

        _mockedGenericTicketingDataDao.Verify(gtdd => gtdd.GetLastCreatedRecordAsync(It.IsAny<string>()), Times.Once);
        _mockedClientDataStrategy.Verify(cds => cds.ExecuteAsync(It.IsAny<RequestTicketingUserDataMessage>()), Times.Never);
    }

    [Fact]
    public void TestThatInitializeSyncJobsInitializesSyncJobsBasedOnEnums()
    {
        var amountOfJobs = Enum.GetValues<TicketingDataType>().Length * Enum.GetValues<SynchronisationType>().Length;

        var actual = _sut.InitializeSyncJobs();

        Assert.Equal(amountOfJobs, actual.Count);
    }
}