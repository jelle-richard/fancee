using DataSynchronisationService.Exceptions;
using DataSynchronisationService.Persistence.Events;
using DataSynchronisationService.Services.DataMessageStrategy;
using DataSynchronisationService.Tests.MockData;
using FanceeAnalyticsData.Models.TicketingData;
using Fs.MessageBus.Publishers;
using MongoDB.Driver;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Tests.Services.DataMessageStrategy;

public class EventDataMessageStrategyTests
{
    private readonly Mock<IMessagePublisher<IRequestTicketingDataMessage>> _mockedPublisher = new();
    private readonly Mock<IEventDao> _mockedEventDao = new();

    private readonly EventDataMessageStrategy _sut;

    public EventDataMessageStrategyTests()
    {
        _sut = new(_mockedPublisher.Object, _mockedEventDao.Object);
    }

    [Fact]
    public async Task TestThatExecuteUpdateRequestCallsUnderlyingInsertMethods()
    {
        _mockedEventDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingEventDataMessages.ExistingEventIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingEventDataMessages.UpdateRequestReply);

        _mockedEventDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()))
            .ReturnsAsync(false);

        await _sut.ExecuteAsync(MockedRequestTicketingEventDataMessages.UpdateRequest);

        _mockedEventDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Once);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()), Times.Once);

        _mockedEventDao.Verify(cd => cd.CreateAsync(It.IsAny<Event>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteUpdateRequestCallsUnderlyingUpdateMethods()
    {
        _mockedEventDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingEventDataMessages.ExistingEventIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingEventDataMessages.UpdateRequestReply);

        _mockedEventDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()))
            .ReturnsAsync(true);

        await _sut.ExecuteAsync(MockedRequestTicketingEventDataMessages.UpdateRequest);

        _mockedEventDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Once);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.UpdateAsync(It.IsAny<Event>(), It.IsAny<FilterDefinition<Event>?>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteCreateRequestCallsUnderlyingInsertMethods()
    {
        _mockedEventDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingEventDataMessages.ExistingEventIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingEventDataMessages.UpdateRequestReply);

        _mockedEventDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()))
            .ReturnsAsync(false);

        await _sut.ExecuteAsync(MockedRequestTicketingEventDataMessages.CreateRequestReply);

        _mockedEventDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Never);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.CreateAsync(It.IsAny<Event>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteCreateRequestCallsUnderlyingUpdateMethods()
    {
        _mockedEventDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingEventDataMessages.ExistingEventIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingEventDataMessages.CreateRequestReply);

        _mockedEventDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()))
            .ReturnsAsync(true);

        await _sut.ExecuteAsync(MockedRequestTicketingEventDataMessages.CreateRequest);

        _mockedEventDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Never);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.UpdateAsync(It.IsAny<Event>(), It.IsAny<FilterDefinition<Event>?>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteThrowsUnknownSynchronisationTypeException()
    {
        _mockedEventDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingEventDataMessages.ExistingEventIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingEventDataMessages.FaultyRequest);

        _mockedEventDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<UnknownSynchronisationTypeException>(() => _sut.ExecuteAsync(MockedRequestTicketingEventDataMessages.FaultyRequest));

        _mockedEventDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Never);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedEventDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Event>>()), Times.Never);
        _mockedEventDao.Verify(cd => cd.UpdateAsync(It.IsAny<Event>(), It.IsAny<FilterDefinition<Event>?>()), Times.Never);
    }
}