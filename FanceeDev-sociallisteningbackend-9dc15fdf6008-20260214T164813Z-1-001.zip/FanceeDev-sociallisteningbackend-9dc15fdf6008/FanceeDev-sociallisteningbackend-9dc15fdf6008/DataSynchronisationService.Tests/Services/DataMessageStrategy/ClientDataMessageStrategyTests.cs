using DataSynchronisationService.Exceptions;
using DataSynchronisationService.Persistence.Users;
using DataSynchronisationService.Services.DataMessageStrategy;
using DataSynchronisationService.Tests.MockData;
using FanceeAnalyticsData.Models.TicketingData;
using Fs.MessageBus.Publishers;
using MongoDB.Driver;
using SocialListeningCore.MessageBus.Messages.DataSynchronisation;
using User = FanceeAnalyticsData.Models.TicketingData.User;

namespace DataSynchronisationService.Tests.Services.DataMessageStrategy;

public class ClientDataMessageStrategyTests
{
    private readonly Mock<IMessagePublisher<IRequestTicketingDataMessage>> _mockedPublisher = new();
    private readonly Mock<IClientDao> _mockedClientDao = new();
    private readonly Mock<IUserDao> _mockedUserDao = new();

    private readonly ClientDataMessageStrategy _sut;

    public ClientDataMessageStrategyTests()
    {
        _sut = new(_mockedPublisher.Object, _mockedClientDao.Object, _mockedUserDao.Object);
    }

    [Fact]
    public async Task TestThatExecuteUpdateRequestCallsUnderlyingInsertMethods()
    {
        _mockedClientDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingUserDataMessages.ExistingUserIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingUserDataMessages.UpdateRequestReply);

        _mockedUserDao.Setup(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()))
            .ReturnsAsync(false);

        _mockedClientDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()))
            .ReturnsAsync(false);

        await _sut.ExecuteAsync(MockedRequestTicketingUserDataMessages.UpdateRequest);

        _mockedClientDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Once);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()), Times.Once);

        _mockedUserDao.Verify(ud => ud.CreateAsync(It.IsAny<User>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.CreateAsync(It.IsAny<Client>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteUpdateRequestCallsUnderlyingUpdateMethods()
    {
        _mockedClientDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingUserDataMessages.ExistingUserIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingUserDataMessages.UpdateRequestReply);

        _mockedUserDao.Setup(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()))
            .ReturnsAsync(true);

        _mockedClientDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()))
            .ReturnsAsync(true);

        await _sut.ExecuteAsync(MockedRequestTicketingUserDataMessages.UpdateRequest);

        _mockedClientDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Once);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.UpdateAsync(It.IsAny<User>(), It.IsAny<FilterDefinition<User>?>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.UpdateAsync(It.IsAny<Client>(), It.IsAny<FilterDefinition<Client>?>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteCreateRequestCallsUnderlyingInsertMethods()
    {
        _mockedClientDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingUserDataMessages.ExistingUserIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingUserDataMessages.UpdateRequestReply);

        _mockedUserDao.Setup(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()))
            .ReturnsAsync(false);

        _mockedClientDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()))
            .ReturnsAsync(false);

        await _sut.ExecuteAsync(MockedRequestTicketingUserDataMessages.CreateRequestReply);

        _mockedClientDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Never);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.CreateAsync(It.IsAny<User>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.CreateAsync(It.IsAny<Client>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteCreateRequestCallsUnderlyingUpdateMethods()
    {
        _mockedClientDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingUserDataMessages.ExistingUserIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingUserDataMessages.CreateRequestReply);

        _mockedUserDao.Setup(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()))
            .ReturnsAsync(true);

        _mockedClientDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()))
            .ReturnsAsync(true);

        await _sut.ExecuteAsync(MockedRequestTicketingUserDataMessages.CreateRequest);

        _mockedClientDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Never);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.UpdateAsync(It.IsAny<User>(), It.IsAny<FilterDefinition<User>?>()), Times.Once);
        _mockedClientDao.Verify(cd => cd.UpdateAsync(It.IsAny<Client>(), It.IsAny<FilterDefinition<Client>?>()), Times.Once);
    }

    [Fact]
    public async Task TestThatExecuteThrowsUnknownSynchronisationTypeException()
    {
        _mockedClientDao.Setup(cd => cd.RetrieveExistingDataAsync())
            .ReturnsAsync(MockedRequestTicketingUserDataMessages.ExistingUserIds);

        _mockedPublisher.Setup(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()))
            .Returns(MockedRequestTicketingUserDataMessages.FaultyRequest);

        _mockedUserDao.Setup(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()))
            .ReturnsAsync(true);

        _mockedClientDao.Setup(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<UnknownSynchronisationTypeException>(() => _sut.ExecuteAsync(MockedRequestTicketingUserDataMessages.FaultyRequest));

        _mockedClientDao.Verify(cd => cd.RetrieveExistingDataAsync(), Times.Never);
        _mockedPublisher.Verify(p => p.Call<IRequestTicketingDataMessage>(It.IsAny<IRequestTicketingDataMessage>()), Times.Once);
        _mockedUserDao.Verify(ud => ud.AnyAsync(It.IsAny<FilterDefinition<User>>()), Times.Never);
        _mockedClientDao.Verify(cd => cd.AnyAsync(It.IsAny<FilterDefinition<Client>>()), Times.Never);
        _mockedUserDao.Verify(ud => ud.UpdateAsync(It.IsAny<User>(), It.IsAny<FilterDefinition<User>?>()), Times.Never);
        _mockedClientDao.Verify(cd => cd.UpdateAsync(It.IsAny<Client>(), It.IsAny<FilterDefinition<Client>?>()), Times.Never);
    }
}