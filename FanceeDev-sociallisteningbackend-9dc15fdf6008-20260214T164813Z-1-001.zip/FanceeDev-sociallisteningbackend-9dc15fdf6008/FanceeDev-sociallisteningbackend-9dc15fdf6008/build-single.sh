#!/usr/bin/env bash

if [ -z "$1" ]
  then
    echo "Usage: build-single.sh [service]"
    exit 1
fi

if [[ -z "$NUGET_USERNAME" ]]
  then
    echo "NUGGET_USERNAME variable not set"
    exit 1
fi

if [[ -z "$NUGET_PASSWORD" ]]
  then
    echo "NUGGET_PASSWORD variable not set"
    exit 1
fi

service=$1

serviceLowercase=$(echo "$service" | tr "[:upper:]" "[:lower:]") ;
  
docker build -t "docker.fanc.ee/$serviceLowercase:dev" -f $service/Dockerfile --build-arg NUGET_USERNAME --build-arg NUGET_PASSWORD . ;
docker image push "docker.fanc.ee/$serviceLowercase:dev" ;
docker rmi "docker.fanc.ee/$serviceLowercase:dev" ;
