using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Entries;

namespace SubscriptionService.Utils;

public static class SubscriptionServiceHelper
{
    public static IEnumerable<GenericEntry> CalculateDifferenceBetweenEntries(IEnumerable<GenericEntry> entries, bool removeLastEntry = true)
    {
        var diffList = entries.ToList();
        var fieldNames = GetFieldUpdateTable(Enum.Parse<SubscriptionType>(diffList[0].SubscriptionType));

        if (fieldNames.Length == 0)
            return diffList;

        for (var i = 0; i < diffList.Count - 1; i++)
        {
            IDictionary<string, object> currentData = diffList[i].Data!;
            IDictionary<string, object> nextData = diffList[i + 1].Data!;

            foreach (var field in fieldNames)
            {
                if (currentData[field] is int)
                {
                    var value = (int)currentData[field];
                    var valueNext = (int)nextData[field];

                    currentData.Add(field + "_DIFF", valueNext - value);
                }

                if (currentData[field] is double)
                {
                    var value = (double)currentData[field];
                    var valueNext = (double)nextData[field];

                    currentData.Add(field + "_DIFF", valueNext - value);
                }
            }
        }

        if (removeLastEntry)
            diffList.RemoveAt(diffList.Count - 1);

        return diffList;
    }

    private static string[] GetFieldUpdateTable(SubscriptionType subscriptionType) => subscriptionType switch
    {
        SubscriptionType.GT => ["interest"],
        SubscriptionType.FB => ["page_followers", "page_fans", "page_stories", "page_video_views"],
        var _ => Array.Empty<string>()
    };
}