using FanceeAnalyticsData.Models.Analytics;

namespace SubscriptionService.TestData;

public static class SubscriptionSettingsFactory
{
    public static SubscriptionSetting GetMockedSubscriptionSetting() =>
        new()
        {
            Id = "123",
            SubscriptionType = SubscriptionType.FB_AGE_AND_GENDER,
            SubscriptionName = "foo",
            Split = "profileid,Date,gender,age",
            Fields = "age,Date,gender,profile,profileid,page_fans,page_impressions_unique"
        };
}