using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;

namespace SubscriptionService.Exceptions;

public class SubscriptionTypeForbiddenException(SubscriptionType subscriptionType) 
    : ForbiddenApiException($"Subscription type {subscriptionType} can not be deleted");