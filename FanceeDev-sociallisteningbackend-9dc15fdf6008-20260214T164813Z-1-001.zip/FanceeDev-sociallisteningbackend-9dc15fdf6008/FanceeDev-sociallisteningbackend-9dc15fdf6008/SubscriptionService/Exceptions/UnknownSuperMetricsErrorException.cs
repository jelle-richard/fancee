using SocialListeningCore.Exceptions;

namespace SubscriptionService.Exceptions;

public class UnknownSuperMetricsErrorException() 
    : InternalServerErrorApiException("SuperMetrics gave an unknown error");
