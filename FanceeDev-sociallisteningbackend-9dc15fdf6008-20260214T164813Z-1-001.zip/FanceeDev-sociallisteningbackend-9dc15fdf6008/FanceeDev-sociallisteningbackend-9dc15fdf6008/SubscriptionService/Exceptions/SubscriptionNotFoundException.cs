using SocialListeningCore.Exceptions;
namespace SubscriptionService.Exceptions;

public class SubscriptionNotFoundException(string id) 
    : NotFoundApiException($"Subscription with id ${id} could not be found");