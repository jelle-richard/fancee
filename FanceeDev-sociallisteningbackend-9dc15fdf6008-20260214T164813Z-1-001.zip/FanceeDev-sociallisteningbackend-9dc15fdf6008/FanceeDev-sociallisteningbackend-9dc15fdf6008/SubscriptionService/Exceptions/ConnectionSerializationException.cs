using SocialListeningCore.Exceptions;

namespace SubscriptionService.Exceptions;

public class ConnectionSerializationException()
    : InternalServerErrorApiException("Something went wrong retrieving data from SuperMetrics");