using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;

namespace SubscriptionService.Exceptions;

public class SettingsNotFoundException(SubscriptionType subscriptionType)
    : NotFoundApiException($"Settings with subscription type '{subscriptionType}' could not be found.");
