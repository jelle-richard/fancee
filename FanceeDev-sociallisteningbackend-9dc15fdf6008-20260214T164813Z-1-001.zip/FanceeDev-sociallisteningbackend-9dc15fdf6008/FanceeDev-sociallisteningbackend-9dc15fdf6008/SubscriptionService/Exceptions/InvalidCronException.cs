using SocialListeningCore.Exceptions;

namespace SubscriptionService.Exceptions;

public class InvalidCronException()
    : BadRequestApiException("Invalid cron configuration");