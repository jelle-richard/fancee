using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;

namespace SubscriptionService.Exceptions;

public class SubscriptionTypeNotFoundException(SubscriptionType subscriptionType) 
    : NotFoundApiException($"Subscription type {subscriptionType} can not be found");