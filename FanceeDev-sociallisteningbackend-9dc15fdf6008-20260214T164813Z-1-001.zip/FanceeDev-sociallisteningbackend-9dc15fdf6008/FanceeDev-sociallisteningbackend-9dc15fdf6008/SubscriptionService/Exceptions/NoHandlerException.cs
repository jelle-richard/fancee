using SocialListeningCore.Exceptions;

namespace SubscriptionService.Exceptions;

public class NoHandlerException() 
    : InternalServerErrorApiException("No implementation for SuperMetrics response found");