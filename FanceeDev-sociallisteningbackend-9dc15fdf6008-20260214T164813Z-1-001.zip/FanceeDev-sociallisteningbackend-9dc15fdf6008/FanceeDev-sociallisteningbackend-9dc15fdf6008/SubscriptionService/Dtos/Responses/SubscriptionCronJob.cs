using FanceeAnalyticsData.Models.Analytics;

namespace SubscriptionService.Dtos.Responses;

public class SubscriptionCronJob
{
    public string? JobName { get; set; }
    public Subscription? Subscription { get; set; }
    public bool IsRunning { get; set; } = false;
}