using System.Text.Json.Serialization;

namespace SubscriptionService.Dtos.Requests.Settings;

public class UpdateSubscriptionSettingsRequest
{
    [JsonPropertyName("fields")]
    public string? Fields { get; set; }

    [JsonPropertyName("split")]
    public string? Split { get; set; }
}