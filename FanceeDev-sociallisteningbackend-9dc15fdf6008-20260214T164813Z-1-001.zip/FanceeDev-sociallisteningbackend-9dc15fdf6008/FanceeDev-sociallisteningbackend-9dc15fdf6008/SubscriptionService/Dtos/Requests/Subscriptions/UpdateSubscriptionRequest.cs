﻿namespace SubscriptionService.Dtos.Requests.Subscriptions;

public class UpdateSubscriptionRequest
{
    public string? Cron { get; set; }
}