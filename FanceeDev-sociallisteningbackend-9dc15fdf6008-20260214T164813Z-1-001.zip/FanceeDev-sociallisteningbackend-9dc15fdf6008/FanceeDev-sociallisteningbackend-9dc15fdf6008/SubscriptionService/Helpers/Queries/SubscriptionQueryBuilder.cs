using FanceeAnalyticsData.Models.Analytics;
using Microsoft.IdentityModel.Tokens;
using MongoDB.Bson;
using SocialListeningCore.Helpers;

namespace SubscriptionService.Helpers.Queries;

public static class SubscriptionQueryBuilder
{
    public static IEnumerable<BsonDocument> BuildByStatusQuery(ChannelStatus status, string? subscriptionId = null)
    {
        var matchList = new List<BsonElement>
        {
            new("channel.status", status.ToString())
        };

        if (!subscriptionId.IsNullOrEmpty())
            matchList.Add(new("_id", ObjectId.Parse(subscriptionId)));

        return new List<BsonDocument>
        {
            MongoHelper.LookupStage("channels", "channel_id", "_id", "channel"),
            MongoHelper.GenericMatchStage(matchList)
        };
    }
}