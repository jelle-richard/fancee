using CronScheduler.Extensions.StartupInitializer;
using SubscriptionService.Services.Subscriptions;

namespace SubscriptionService.Jobs;

/// <summary>
/// Starts all the Subscriptions with their respective cron query.
/// </summary>
public class InitSubscriptionsJob(ILogger<InitSubscriptionsJob> logger, ISubscriptionsService subscriptionService) : IStartupJob
{
    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        logger.LogInformation("{job} started", nameof(InitSubscriptionsJob));
        await subscriptionService.StartAllAsync();
        await subscriptionService.AddOrUpdateInactiveSubscriptionSchedule();
        logger.LogInformation("{job} ended", nameof(InitSubscriptionsJob));
    }
}