using CronScheduler.Extensions.StartupInitializer;
using SubscriptionService.Services.Settings;

namespace SubscriptionService.Jobs;

/// <summary>
/// Seeds the subscription settings.
/// </summary>
public class InitSubscriptionSettingsJob(ILogger<InitSubscriptionSettingsJob> logger, ISubscriptionSettingsService subscriptionSettingsService) : IStartupJob
{
    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        logger.LogInformation("{job} started", nameof(InitSubscriptionSettingsJob));
        await subscriptionSettingsService.SeedSubscriptionSettings();
        logger.LogInformation("{job} ended", nameof(InitSubscriptionSettingsJob));
    }
}