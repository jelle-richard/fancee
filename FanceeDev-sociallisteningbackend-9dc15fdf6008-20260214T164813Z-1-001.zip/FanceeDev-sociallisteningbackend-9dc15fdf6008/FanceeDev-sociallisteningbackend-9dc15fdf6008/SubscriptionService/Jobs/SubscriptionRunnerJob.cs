using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using SubscriptionService.Services.Subscriptions;

namespace SubscriptionService.Jobs;

/// <summary>
/// ScheduledJob that activates when a given Subscription cron query goes off.
/// </summary>
public class SubscriptionRunnerJob(IServiceProvider serviceProvider, Subscription subscription, SchedulerOptions options, ILogger logger)
    : IScheduledJob
{
    public string Name => subscription.Name;

    private readonly ILogger _logger = logger ?? throw new ArgumentNullException(nameof(logger));

    public async Task ExecuteAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("{cronSchedule} - {name}", options.CronSchedule, Name);

        if (subscription.RunOnce)
            serviceProvider.GetRequiredService<ISubscriptionsService>().StopSubscriptionJob(Name);

        await serviceProvider.GetRequiredService<ISubscriptionsService>().CallServerAsync(subscription);
    }
}