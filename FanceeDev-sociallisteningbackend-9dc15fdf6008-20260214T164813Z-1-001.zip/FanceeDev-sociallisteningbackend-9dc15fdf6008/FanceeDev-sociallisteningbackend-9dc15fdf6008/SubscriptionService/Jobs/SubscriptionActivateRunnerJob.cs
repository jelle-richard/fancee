using CronScheduler.Extensions.Scheduler;
using SubscriptionService.Services.Subscriptions;

namespace SubscriptionService.Jobs;

/// <summary>
/// ScheduledJob that starts all inactive subscriptions in every 5 minutes.
/// Inactive subscriptions are subscriptions which created through ChannelService in MongoDB but are not running yet.
/// </summary>
public class SubscriptionActivateRunnerJob(IServiceProvider serviceProvider, SchedulerOptions options, ILogger logger) : IScheduledJob
{
    public string Name => "SubscriptionActivationJob";

    public async Task ExecuteAsync(CancellationToken cancellationToken)
    {
        logger.LogInformation("{cronSchedule} - {name} started", options.CronSchedule, Name);
        await serviceProvider.GetRequiredService<ISubscriptionsService>().StartAllAsync();
        logger.LogInformation("{cronSchedule} - {name} ended", options.CronSchedule, Name);
    }
}