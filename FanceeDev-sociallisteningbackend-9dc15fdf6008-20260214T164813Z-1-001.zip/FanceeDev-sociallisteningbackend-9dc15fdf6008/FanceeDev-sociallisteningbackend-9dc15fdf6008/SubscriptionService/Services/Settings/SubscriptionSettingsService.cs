using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Services;
using SubscriptionService.Dtos.Requests.Settings;
using SubscriptionService.Exceptions;
using SubscriptionService.Persistence.Settings;
using SubscriptionService.Services.Subscriptions;
using SubscriptionNotFoundException = SocialListeningCore.Exceptions.SubscriptionNotFoundException;

namespace SubscriptionService.Services.Settings;

public class SubscriptionSettingsService : MongoService<SubscriptionSetting, ISubscriptionSettingsDao>, ISubscriptionSettingsService
{
    private readonly ISubscriptionSettingsDao _mongoSettingsDao;
    private readonly ISubscriptionsService _subscriptionsService;
    private IEnumerable<SubscriptionType> _subscriptionTypes = Array.Empty<SubscriptionType>();

    public SubscriptionSettingsService(ISubscriptionSettingsDao mongoSettingsDao, ISubscriptionsService subscriptionsService) : base(mongoSettingsDao)
    {
        _mongoSettingsDao = mongoSettingsDao;
        _subscriptionsService = subscriptionsService;
    }

    public async Task<bool> AnyAsync() => await _mongoSettingsDao.AnyAsync();

    public async Task SeedSubscriptionSettings()
    {
        var activeSettings = await _mongoSettingsDao.GetListAsync();
        _subscriptionTypes = activeSettings.Select(setting => setting.SubscriptionType);

        await SeedFacebook();
        await SeedFacebookAds();
        await SeedFacebookPublicData();
        await SeedGoogleAnalyticsFour();
        await SeedGoogleAnalytics();
        await SeedGoogleTrends();
        await SeedInstagramInsights();
        await SeedInstagramPublicData();
        await SeedYoutube();
        await SeedYoutubeV2();
        await SeedLinkedInCompanyPages();
        await SeedGoogleAds();
        await SeedTikTok();
    }

    public async Task<SubscriptionSetting> UpdateSubscriptionSettingAsync(SubscriptionType subscriptionType, UpdateSubscriptionSettingsRequest request, Guid userId)
    {
        var subscriptionSetting = await _mongoSettingsDao.GetSettingsByTypeAsync(subscriptionType);

        if (!string.IsNullOrEmpty(request.Split))
            subscriptionSetting.Split = request.Split;

        if (!string.IsNullOrEmpty(request.Fields))
            subscriptionSetting.Fields = request.Fields;

        return await _mongoSettingsDao.UpdateAsync(subscriptionSetting);
    }

    public async Task<bool> DeleteAsync(SubscriptionType subscriptionType)
    {
        var subscriptionSetting = await _mongoSettingsDao.GetSettingsByTypeAsync(subscriptionType)
                                  ?? throw new SettingsNotFoundException(subscriptionType);

        var subscription = await _subscriptionsService.FirstBySubscriptionTypeAsync(subscriptionType)
                           ?? throw new SubscriptionNotFoundException();

        await _subscriptionsService.StopByIdAsync(subscription.Id!);

        return await _mongoSettingsDao.DeleteAsync(subscriptionSetting.Id!);
    }

    private async Task CreateSubscriptionSettings(IEnumerable<SubscriptionSetting> settings)
    {
        foreach (var subscriptionSetting in settings.Where(setting => !_subscriptionTypes.Contains(setting.SubscriptionType)))
        {
            subscriptionSetting.Split = subscriptionSetting.SubscriptionType.ToFiltersAsString();
            await _mongoSettingsDao.CreateAsync(subscriptionSetting);
        }
    }

    private async Task SeedFacebook() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.FB,
            SubscriptionName = "Facebook",
            Fields = "Date,profile,profileid,page_fan_adds,page_followers," +
                     "page_fan_adds_unique,page_fan_removes,page_fan_removes_unique,NetFanGrowth," +
                     "FanGrowthRate,FanChurnRate,page_fans_online_per_day," +
                     "page_fans,page_impressions,page_impressions_nonviral," +
                     "page_impressions_nonviral_unique,page_impressions_organic," +
                     "page_impressions_organic_unique,page_impressions_paid," +
                     "page_impressions_paid_unique,page_impressions_unique," +
                     "page_impressions_viral_unique,page_negative_feedback," +
                     "page_negative_feedback_unique," +
                     "page_places_checkin_total," +
                     "page_places_checkin_total_unique," +
                     "page_post_engagements,page_posts_impressions," +
                     "page_posts_impressions_nonviral_unique,page_posts_impressions_organic_unique," +
                     "page_posts_impressions_paid_unique,page_posts_impressions_unique," +
                     "page_posts_impressions_viral_unique," +
                     "page_video_repeat_views,page_video_views,page_video_views_10s," +
                     "page_video_views_10s_autoplayed,page_video_views_10s_click_to_play," +
                     "page_video_views_10s_organic,page_video_views_10s_paid," +
                     "page_video_views_10s_unique,page_video_views_autoplayed," +
                     "page_video_views_click_to_play,page_video_views_organic," +
                     "page_video_views_paid,page_video_views_unique"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FB_AGE_AND_GENDER,
            SubscriptionName = "Facebook age and gender",
            Fields = "age,Date,gender,profile,profileid,page_fans,page_impressions_unique"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FB_GEO_LIKES,
            SubscriptionName = "Facebook likes per geo location",
            Fields = "country,Date,profile,profileid,page_fans,page_impressions_unique"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FB_POSTS,
            SubscriptionName = "Facebook posts",
            Fields = "dataSourceName,Date,post_caption,post_created_time_of_day," +
                     "post_description,post_full_picture,post_ID,post_link,post_linkto,post_message," +
                     "post_name,post_object_id,post_picture,post_privacy,post_status_type,post_story," +
                     "post_type,post_video_length,profile,profileid,video_title,video_universal_id," +
                     "post_comments_on_post,post_comments_toplevel," +
                     "post_engaged_users,post_impressions,post_impressions_fan,post_impressions_fan_unique," +
                     "post_impressions_nonviral,post_impressions_nonviral_unique,post_impressions_organic," +
                     "post_impressions_organic_unique,post_impressions_paid," +
                     "post_impressions_paid_unique,post_impressions_unique,post_impressions_viral," +
                     "post_impressions_viral_unique,post_likes_on_post," +
                     "post_link_clicks,post_link_clicks_unique," +
                     "post_negative_feedback,post_negative_feedback_unique,post_other_clicks," +
                     "post_other_clicks_unique,post_photo_views,post_photo_views_unique," +
                     "post_positive_feedback,post_reactions_anger,post_reactions_haha," +
                     "post_reactions_like,post_reactions_love,post_reactions_pride,post_reactions_sorry," +
                     "post_reactions_thankful,post_reactions_wow,post_shares_on_post," +
                     "post_story_adds_unique,post_video_complete_views_30s," +
                     "post_video_complete_views_30s_autoplayed,post_video_complete_views_30s_click_to_play," +
                     "post_video_complete_views_30s_organic,post_video_complete_views_30s_paid," +
                     "post_video_complete_views_30s_unique,post_video_view_time," +
                     "post_video_view_time_organic,post_video_views,post_video_views_10s," +
                     "post_video_views_10s_autoplayed,post_video_views_10s_click_to_play," +
                     "post_video_views_10s_organic,post_video_views_10s_paid," +
                     "post_video_views_10s_sound_on,post_video_views_10s_unique," +
                     "post_video_views_autoplayed,post_video_views_click_to_play," +
                     "post_video_views_organic,post_video_views_paid," +
                     "post_video_views_sound_on,post_video_views_unique," +
                     "reels_blue_reels_play_count,reels_impressions_unique,total_reel_video_reactions," +
                     "reel_video_likes_by_reaction_type_like,reel_video_likes_by_reaction_type_love," +
                     "reel_video_likes_by_reaction_type_care,reel_video_likes_by_reaction_type_haha," +
                     "reel_video_likes_by_reaction_type_wow,reel_video_likes_by_reaction_type_sad," +
                     "reel_video_likes_by_reaction_type_angry,reel_video_social_actions_share," +
                     "reel_video_social_actions_comment,reel_video_view_time",
            Filter = "post_ID =~ [0-9]+"
        }
    });

    private async Task SeedFacebookAds() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.FA_CAMPAIGN,
            SubscriptionName = "Facebook Ads - Campaign",
            Fields = "account_status,profileID,profile,adcampaign_id,adcampaign_name,campaign_budget_remaining," +
                     "campaign_daily_budget,campaign_end_date,campaign_lifetime_budget,campaign_start_date," +
                     "campaignbuyingtype,campaignconfigured_status,campaignobjective,campaignspend_cap,campaignstatus," +
                     "currency,dataSourceName,Date,platform_position,publisher_platform,spend_cap,cost,cost_eur," +
                     "cost_gbp,cost_usd,reach,store_visits_point_estimate,Clicks,CTR,CPC,quality_score_ecvr"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FA_ADS,
            SubscriptionName = "Facebook Ads - Ads",
            Fields = "account_status,profileID,profile,ad_id,ad_name,adbid_info,adcampaign_id,adcampaign_name," +
                     "adconfigured_status,adset_id,adset_name,adsetbudget_remaining,adsetconfigured_status,adsetdaily_budget," +
                     "adsetend_time,adsetlifetime_budget,adsetstart_time,adsetstatus,adsetupdated_time,adstatus,bidamount," +
                     "bidinfo,bidtype,campaign_end_date,campaign_start_date,campaignbuyingtype,campaignconfigured_status," +
                     "campaignobjective,campaignstatus,creative_body,creative_call_to_action_type,creative_image_url," +
                     "creative_link_url,creative_name,creative_object_story_spec_link,creative_object_type," +
                     "creative_object_url,creative_template_url,creative_thumbnail_url,creative_title," +
                     "creative_url_tags,currency,dataSourceName,Date,destinationURL,device_platform,impression_device," +
                     "platform_position,promoted_post_caption,promoted_post_created_time,promoted_post_description," +
                     "promoted_post_destination_url,promoted_post_full_picture,promoted_post_icon,promoted_post_id," +
                     "promoted_post_id_ig,promoted_post_message,promoted_post_name,promoted_post_permalink_url," +
                     "promoted_post_permalink_url_ig,promoted_post_picture,promoted_post_privacy,promoted_post_privacy_description," +
                     "promoted_post_source,promoted_post_story,promoted_post_type,publisher_platform,spend_cap,timezone_id," +
                     "utm_campaign,utm_content,utm_medium,utm_source,utm_term,action_app_custom_event," +
                     "action_app_custom_event.fb_mobile_achievement_unlocked,action_app_custom_event.fb_mobile_activate_app," +
                     "action_app_custom_event.fb_mobile_add_payment_info,action_app_custom_event.fb_mobile_add_to_cart," +
                     "action_app_custom_event.fb_mobile_add_to_wishlist,action_app_custom_event.fb_mobile_complete_registration," +
                     "action_app_custom_event.fb_mobile_content_view,action_app_custom_event.fb_mobile_initiated_checkout," +
                     "action_app_custom_event.fb_mobile_level_achieved,action_app_custom_event.fb_mobile_purchase," +
                     "action_app_custom_event.fb_mobile_search,action_app_custom_event.fb_mobile_spent_credits," +
                     "action_app_custom_event.fb_mobile_tutorial_completion,action_app_custom_event.other," +
                     "action_app_engagement,action_app_install,action_app_story,action_app_use,action_checkin," +
                     "action_comment,action_credit_spent,action_follow,action_games.plays,action_gift_sale,action_leadgen.other," +
                     "action_like,action_link_click,action_mention,action_mobile_app_install,action_page_engagement," +
                     "action_photo_view,action_post,action_post_engagement,action_post_like,action_receive_offer," +
                     "action_rsvp,action_tab_view,action_value_app_custom_event.fb_mobile_purchase," +
                     "action_value_app_custom_event.fb_mobile_spent_credits,action_video_play,action_video_view," +
                     "Actions,actionvalue,call_to_action_clicks,Clicks,cost,cost_eur,cost_gbp,cost_usd,estimated_ad_recallers," +
                     "estimated_ad_recallers_lower_bound,estimated_ad_recallers_upper_bound,impressions,landing_page_views," +
                     "offsite_conversion_value,offsite_conversion_value_fb_pixel_add_payment_info,offsite_conversion_value_fb_pixel_add_to_cart," +
                     "offsite_conversion_value_fb_pixel_add_to_wishlist,offsite_conversion_value_fb_pixel_complete_registration," +
                     "offsite_conversion_value_fb_pixel_custom,offsite_conversion_value_fb_pixel_initiate_checkout," +
                     "offsite_conversion_value_fb_pixel_lead,offsite_conversion_value_fb_pixel_purchase,offsite_conversion_value_fb_pixel_search," +
                     "offsite_conversion_value_fb_pixel_view_content,offsite_conversions,offsite_conversions_fb_pixel_add_payment_info," +
                     "offsite_conversions_fb_pixel_add_to_cart,offsite_conversions_fb_pixel_add_to_wishlist,offsite_conversions_fb_pixel_complete_registration," +
                     "offsite_conversions_fb_pixel_custom,offsite_conversions_fb_pixel_initiate_checkout,offsite_conversions_fb_pixel_lead," +
                     "offsite_conversions_fb_pixel_purchase,offsite_conversions_fb_pixel_search,offsite_conversions_fb_pixel_view_content," +
                     "offsite_conversions_key_page_view,offsite_conversions_leads,offsite_conversions_other,offsite_conversions_registrations," +
                     "outbound_clicks,post_save,reach,unique_action_comment,unique_action_follow,unique_action_like,unique_action_link_click," +
                     "unique_action_mention,unique_action_page_engagement,unique_action_photo_view,unique_action_post,unique_action_post_engagement," +
                     "unique_action_post_reaction,unique_action_video_play,unique_action_video_view,unique_inline_link_clicks," +
                     "unique_outbound_clicks,UniqueActions,UniqueClicks"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FA_VIDEO,
            SubscriptionName = "Facebook Ads - Video",
            Fields = "profileID,profile,ad_id,ad_name,adcampaign_id,adcampaign_name,adset_id,adset_name,adstatus,dataSourceName,Date," +
                     "platform_position,publisher_platform,video_asset_id,video_asset_video_id,action_video_view,video_10_sec_watched_actions," +
                     "video_15_sec_watched_actions,video_30_sec_watched_actions,video_average_watch_time,video_p100_watched_actions," +
                     "video_p25_watched_actions,video_p50_watched_actions,video_p75_watched_actions,video_p95_watched_actions," +
                     "video_thruplay_watched_actions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FA_CONVERSION,
            SubscriptionName = "Facebook Ads - Conversion",
            Fields = "profileID,profile,ActionDestination,ActionDevice,ActionTypeWithCustomLabels,ActionVideoType,ad_id,ad_name," +
                     "adcampaign_id,adcampaign_name,adset_id,adset_name,dataSourceName,Date,destinationURL,platform_position," +
                     "publisher_platform,Actions,actionvalue,UniqueActions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FA_GEO,
            SubscriptionName = "Facebook Ads - Geo",
            Fields = "profileID,profile,ad_id,ad_name,adcampaign_id,adcampaign_name,adset_id,adset_name,adsetstatus,campaignobjective," +
                     "Country,Countryname,dataSourceName,Date,Region,action_leadgen.other,action_link_click,action_video_view," +
                     "Clicks,cost,cost_eur,cost_gbp,cost_usd,impressions,reach"
        },
        new()
        {
            SubscriptionType = SubscriptionType.FA_AGE_AND_GENDER,
            SubscriptionName = "Facebook Ads - Age and Gender",
            Fields = "profileID,profile,ad_id,ad_name,adcampaign_id,adcampaign_name,adset_id,adset_name,adsetstatus,Age,campaignobjective," +
                     "dataSourceName,Date,Gender,action_leadgen.other,action_link_click,action_video_view,Clicks,cost,cost_eur,cost_gbp," +
                     "cost_usd,impressions,reach,Frequency,Actions,UniqueActions,ActionRate,SocialSpend,UniqueActionRate,actionvalue," +
                     "quality_score_ecvr,quality_score_ectr,CTR,CPC"
        }
    });

    private async Task SeedFacebookPublicData() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.FBPD_PAGE,
            SubscriptionName = "Facebook Public Data - Page",
            Fields = "about,awards,can_post,category,company_overview,cover_source,dataSourceName,description,founded," +
                     "general_info,has_added_app,is_community_page,is_published,is_verified,link,location_city,location_city_id," +
                     "location_country,location_country_code,location_latitude,location_located_in,location_longitude,location_name," +
                     "location_region,location_region_id,location_state,location_street,location_zip,mission,name,name_with_location_descriptor," +
                     "page_id,phone,products,today,username,website,checkins,fan_count,talking_about_count",
            Settings = new("Page")
        },
        new()
        {
            SubscriptionType = SubscriptionType.FBPD_POSTS,
            SubscriptionName = "Facebook Public Data - Page",
            Fields = "application_category,application_link,application_name,caption,created_date,created_time,dataSourceName,description,from_id," +
                     "from_name,link,message,name,permalink_url,picture,place,post_id,source,status_type,story,story_tags,type,updated_date,updated_time," +
                     "comments_count,likes_count,posts,reactions_count,shares_count",
            Settings = new("PagePosts")
        },
        new()
        {
            SubscriptionType = SubscriptionType.FBPD_URL_SHARES,
            SubscriptionName = "Facebook Public Data - Url Shares",
            Fields = "og_object_description,og_object_id,og_object_title,og_object_type,og_object_updated_time,today,url,comment_count," +
                     "comment_plugin_count,reaction_count,share_count",
            Settings = new("UrlShares")
        }
    });

    private async Task SeedGoogleAnalyticsFour() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.GAWA,
            SubscriptionName = "Google analytics 4",
            Fields = "browser,dataSourceName,date,deviceCategory,language,platform,propertyName," +
                     "streamName,active28DayUsers,active7DayUsers,activeUsers,addToCarts,checkouts," +
                     "conversions,ecommercePurchases,engagedSessions,eventCount,eventValue,firstTimePurchasers," +
                     "itemListClicks,itemListViews,itemPromotionClicks,itemPromotionViews,itemPurchaseQuantity," +
                     "itemRevenue,itemViews,newUsers,screenPageViews,sessions,totalAdRevenue,totalPurchasers," +
                     "totalRevenue,totalUsers,transactions,userEngagementDuration"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GAWA_DEVICE,
            SubscriptionName = "Google analytics 4 device",
            Fields = "browser,dataSourceName,date,deviceCategory,language,platform,propertyName," +
                     "streamName,active28DayUsers,active7DayUsers,activeUsers,addToCarts,checkouts," +
                     "conversions,ecommercePurchases,engagedSessions,eventCount,eventValue,firstTimePurchasers," +
                     "itemListClicks,itemListViews,itemPromotionClicks,itemPromotionViews,itemPurchaseQuantity," +
                     "itemRevenue,itemViews,newUsers,screenPageViews,sessions,totalAdRevenue,totalPurchasers," +
                     "totalRevenue,totalUsers,transactions,userEngagementDuration"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GAWA_ECOM_ITEMS,
            SubscriptionName = "Google analytics 4 E-Commerse items",
            Fields = "dataSourceName,date,itemBrand,itemCategory,itemListName,itemName,itemPromotionName," +
                     "propertyName,propertyID,activeUsers,engagedSessions,firstTimePurchasers,sessions,totalPurchasers,totalUsers"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GAWA_ENGAGEMENT,
            SubscriptionName = "Google analytics 4 engagement",
            Fields = "contentGroup,dataSourceName,date,eventName,hostName,propertyName,streamName,unifiedScreenClass,activeUsers,addToCarts," +
                     "checkouts,conversions,ecommercePurchases,engagedSessions,eventCount,eventValue,firstTimePurchasers,itemListClicks," +
                     "itemListViews,itemPromotionClicks,itemPromotionViews,itemViews,newUsers,screenPageViews," +
                     "sessions,totalAdRevenue,totalPurchasers,totalRevenue,totalUsers,transactions,userEngagementDuration"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GAWA_PUBLISHING,
            SubscriptionName = "Google analytics 4 publishing",
            Fields = "dataSourceName,date,deviceCategory,language,platform,propertyName,sessionMedium,sessionSource,active28DayUsers," +
                     "active7DayUsers,activeUsers,addToCarts,adUnitExposure,checkouts,conversions,ecommercePurchases,engagedSessions," +
                     "eventValue,firstTimePurchasers,itemListClicks,itemListViews,itemPromotionClicks,itemPromotionViews," +
                     "itemViews,newUsers,publisherAdClicks,publisherAdImpressions,screenPageViews,sessions,totalAdRevenue," +
                     "totalPurchasers,totalRevenue,totalUsers,transactions,userEngagementDuration"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GAWA_TRAFFIC_ACQUISITION,
            SubscriptionName = "Google analytics 4 traffic acquisition",
            Fields = "dataSourceName,date,sessionCampaignName,sessionDefaultChannelGrouping,sessionGoogleAdsAdGroupName," +
                     "sessionGoogleAdsAdNetworkType,sessionGoogleAdsKeyword,sessionMedium,sessionSource,activeUsers,addToCarts," +
                     "checkouts,conversions,ecommercePurchases,engagedSessions,eventValue,firstTimePurchasers,itemListClicks," +
                     "itemListViews,itemPromotionClicks,itemPromotionViews,itemViews,newUsers," +
                     "screenPageViews,sessions,totalAdRevenue,totalPurchasers,totalRevenue,totalUsers,transactions,userEngagementDuration"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GAWA_USER_ACQUISITION,
            SubscriptionName = "Google analytics 4 user acquisition",
            Fields = "dataSourceName,date,firstUserCampaignId,firstUserCampaignName,firstUserCreativeId,firstUserGoogleAdsAdGroupId," +
                     "firstUserGoogleAdsAdGroupName,firstUserGoogleAdsAdNetworkType,firstUserMedium,activeUsers,addToCarts," +
                     "checkouts,conversions,ecommercePurchases,engagedSessions,eventValue,firstTimePurchasers,itemListClicks," +
                     "itemListViews,itemPromotionClicks,itemPromotionViews,itemViews,newUsers," +
                     "screenPageViews,sessions,totalAdRevenue,totalPurchasers,totalRevenue,totalUsers,transactions,userEngagementDuration"
        }
    });

    private async Task SeedGoogleAnalytics() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.GA_CONTENT,
            SubscriptionName = "Google analytics content",
            Fields = "dataSourceName,Date,ExitPagePath,LandingPagePath,NextPagePath,PagePath,PageTitle," +
                     "PreviousPagePath,profile,profileID,Entrances,Exits,pageDownloadTime,pageLoadSample," +
                     "pageLoadTime,pageValue,Pageviews,redirectionTime,serverConnectionTime,serverResponseTime," +
                     "speedMetricsSample,TimeOnPage"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_ECOMMERCE,
            SubscriptionName = "Google analytics ecommerce",
            Fields = "dataSourceName,Date,productBrand,productCategoryHierarchy,productListName,productListPosition," +
                     "ProductName,ProductSku,profile,profileID,ItemQuantity,ItemRevenue,localItemRevenue," +
                     "localProductRefundAmount,productAddsToCart,productCheckouts,productDetailViews,productListClicks," +
                     "productListViews,productRefundAmount,productRefunds,productRemovesFromCart,productRevenuePerPurchase," +
                     "quantityAddedToCart,quantityCheckedOut,quantityRefunded,quantityRemovedFromCart,Uniquepurchases"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_EVENTS,
            SubscriptionName = "Google analytics events",
            Fields = "dataSourceName,Date,EventAction,EventCategory,EventLabel,profile,profileID,EventValue,Pageviews," +
                     "Sessions,TotalEvents,users"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_PAID_TRAFFIC,
            SubscriptionName = "Google analytics paid traffic",
            Fields = "adContent,adGroup,adMatchedQuery,adMatchType,adwordsAdGroupId,adwordsCampaignId," +
                     "adwordsCreativeId,Campaign,dataSourceName,Date,profile,profileID,AdClicks,AdCost," +
                     "Bounces,goalCompletionsAll,goalStartsAll,GoalValueAll,Pageviews,sessionDuration," +
                     "Sessions,totalValue,users"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_SEARCH,
            SubscriptionName = "Google analytics search",
            Fields = "dataSourceName,Date,profile,profileID,SearchCategory,SearchDestinationPage," +
                     "SearchKeyword,SearchStartPage,SearchUsed,avgSearchDepth_noncalc,searchExits," +
                     "searchRefinements,searchResultViews,searchSessions,Searchuniques"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_SOCIAL,
            SubscriptionName = "Google analytics social",
            Fields = "dataSourceName,Date,hasSocialSourceReferral,profile,profileID,socialActivityContentUrl," +
                     "socialEngagementType,socialInteractionNetwork,socialInteractionNetworkAction,socialInteractionTarget," +
                     "socialNetwork,Pageviews,Sessions,socialInteractions,uniqueSocialInteractions,users"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_TECHNOLOGY,
            SubscriptionName = "Google analytics technology",
            Fields = "Browser,BrowserVersion,dataSourceName,Date,deviceCategory,Hostname,OperatingSystem," +
                     "OperatingSystemVersion,profile,profileID,ScreenResolution,Bounces,NewVisits_noncalc," +
                     "Pageviews,sessionDuration,Sessions,TimeOnPage,TimeOnSite_hours,users"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_TRAFFIC,
            SubscriptionName = "Google analytics traffic",
            Fields = "adContent,Campaign,channelGrouping,dataSourceName,Date,fullReferrer,Keyword,medium," +
                     "profile,profileID,ReferralPath,Source,AdClicks,AdCost,Bounces,goal10completions," +
                     "goal11completions,goal12completions,goal13completions,goal14completions,goal15completions," +
                     "goal16completions,goal17completions,goal18completions,goal19completions,goal1completions," +
                     "goal20completions,goal2completions,goal3completions,goal4completions,goal5completions," +
                     "goal6completions,goal7completions,goal8completions,goal9completions,goalCompletionsAll," +
                     "goalStartsAll,GoalValueAll,Impressions,Pageviews,sessionDuration,Sessions,totalValue," +
                     "TransactionRevenue,Transactions,users"
        },
        new()
        {
            SubscriptionType = SubscriptionType.GA_USER,
            SubscriptionName = "Google analytics user",
            Fields = "City,Continent,Country,dataSourceName,Date,Language,profile,profileID," +
                     "RegionIsoCode,Bounces,NewVisits_noncalc,Pageviews,sessionDuration,Sessions,TimeOnPage,users"
        }
    });

    private async Task SeedInstagramInsights() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.IGI,
            SubscriptionName = "Instagram insights",
            Fields = "account_id,biography,dataSourceName,date,ig_id,name,username," +
                     "website,followers_count,follows_count,media_count"
        },
        new()
        {
            SubscriptionType = SubscriptionType.IGI_AGE_AND_GENDER,
            SubscriptionName = "Instagram insights age and gender",
            Fields = "account_id,audience_age,audience_gender,today,followers_count"
        },
        new()
        {
            SubscriptionType = SubscriptionType.IGI_CITY,
            SubscriptionName = "Instagram insights city",
            Fields = "account_id,audience_city_only_dim,today,followers_count"
        },
        new()
        {
            SubscriptionType = SubscriptionType.IGI_COUNTRY,
            SubscriptionName = "Instagram insights country",
            Fields = "account_id,audience_country_dim,today,followers_count"
        },
        new()
        {
            SubscriptionType = SubscriptionType.IGI_MEDIA,
            SubscriptionName = "Instagram insights media",
            Fields = "account_id,dataSourceName,date,ig_id,media_caption,media_id,media_permalink," +
                     "media_shortcode,media_thumbnail_url,media_type,media_url,name,timestamp,username," +
                     "website,media_comments_count,media_engagement,media_impressions,media_like_count," +
                     "media_reach,media_saved,media_story_exits,media_story_impressions,media_story_reach," +
                     "media_story_replies,media_story_taps_back,media_story_taps_forward,media_video_views," +
                     "media_product_type,media_reel_plays,media_reel_shares,media_reel_total_interactions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.IGI_PROFILE_DATA,
            SubscriptionName = "Instagram insights profile data",
            Fields = "account_id,biography,dataSourceName,date,ig_id,name,username,website,email_contacts," +
                     "get_directions_clicks,impressions,phone_call_clicks,profile_views,reach," +
                     "text_message_clicks,website_clicks"
        }
    });

    private async Task SeedInstagramPublicData() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.IGPD2_PROFILES,
            SubscriptionName = "Instagram Public Data - Profiles",
            Fields = "biography,ig_id,name,profile_picture_url,today,username,website,followers,follows,total_post_count",
            Settings = new("BusinessDiscoveryAccount")
        },
        new()
        {
            SubscriptionType = SubscriptionType.IGPD2_HASHTAGS,
            SubscriptionName = "Instagram Public Data - Hashtags",
            Fields = "caption_length,caption_length_no_hashtags,found_hashtags,hashtag_count,hashtag_name,post_caption,post_id," +
                     "post_media_url,post_permalink,post_timestamp,post_type,today,post_comments,post_likes",
            Settings = new("HashtagSearchMedia")
        },
        new()
        {
            SubscriptionType = SubscriptionType.IGPD2_POSTS,
            SubscriptionName = "Instagram Public Data - Posts",
            Fields = "post_caption,post_id,post_media_url,post_permalink,post_timestamp,post_type,today,comments_per_post," +
                     "likes_per_post,post_comments,post_likes,posts",
            Settings = new("BusinessDiscoveryMedia")
        }
    });

    private async Task SeedGoogleTrends() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.GT,
            SubscriptionName = "Google trends",
            Fields = "dayOfWeekNameIso,dayOfMonth,country_name,date,search_term,interest"
        }
    });

    private async Task SeedYoutube() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.YT_VIDEO,
            SubscriptionName = "Youtube video",
            Fields = "account,dataSourceName,Date,profile,profileID,comments,dislikes,likes,shares,views"
        }
    });

    private async Task SeedYoutubeV2() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.YT2_AD_PERFORMANCE,
            SubscriptionName = "Youtube V2 Ad Performance",
            Fields = "adType,channel,channel_country,channel_custom_url,channel_description,channel_hidden_subscribers," +
                     "channel_published_at,channel_thumbnail_url,channel_title,channel_url,dataSourceName,date," +
                     "adImpressions,cpm,grossRevenue,grossRevenue_eur,grossRevenue_gbp",
            Settings = new("AdPerformance")
        },
        new()
        {
            SubscriptionType = SubscriptionType.YT2_CHANNEL,
            SubscriptionName = "Youtube V2 Channel",
            Fields = "channel,channel_custom_url,channel_description,channel_published_at,channel_thumbnail_url,channel_title," +
                     "channel_url,dataSourceName,today,views,likes,dislikes,shares,subscribersGained,subscribersLost,videosAddedToPlaylists," +
                     "videosRemovedFromPlaylists,estimatedMinutesWatched,cardImpressions,cardClicks,cardClickRate,averageViewDuration_seconds," +
                     "avgTimeViewed_minutes,avgTimeViewed_hms,averageViewPercentage,annotationImpressions,annotationClickableImpressions," +
                     "annotationClosableImpressions,annotationClicks,annotationClickThroughRate,annotationCloses,annotationCloseRate," +
                     "cardTeaserImpressions,cardTeaserClicks,cardTeaserClickRate,channel_views,channel_subscribers,channel_videos",
            Settings = new("ChannelTotals")
        },
        new()
        {
            SubscriptionType = SubscriptionType.YT2_DEMOGRAPHIC,
            SubscriptionName = "Youtube V2 Demographic",
            Fields = "ageGroup,channel,gender,today,viewerPercentage",
            Settings = new("Demographic")
        },
        new()
        {
            SubscriptionType = SubscriptionType.YT2_DEVICE,
            SubscriptionName = "Youtube V2 Device",
            Fields = "channel,channel_country,channel_custom_url,channel_description,channel_hidden_subscribers,channel_published_at," +
                     "channel_thumbnail_url,channel_title,channel_url,dataSourceName,date,deviceType,operatingSystem," +
                     "youtubeProduct,estimatedMinutesWatched,views",
            Settings = new("Device")
        },
        new()
        {
            SubscriptionType = SubscriptionType.YT2_GEO,
            SubscriptionName = "Youtube V2 Geo",
            Fields = "channel,channel_country,channel_custom_url,channel_description,channel_hidden_subscribers,channel_published_at," +
                     "channel_thumbnail_url,channel_title,channel_url,country,dataSourceName,query_date_range_start," +
                     "annotationClickableImpressions,annotationClicks,annotationClickThroughRate,annotationClosableImpressions," +
                     "annotationCloseRate,annotationCloses,annotationImpressions,averageViewDuration_seconds,averageViewPercentage," +
                     "avgTimeViewed_hms,avgTimeViewed_minutes,cardClickRate,cardClicks,cardImpressions,cardTeaserClickRate," +
                     "cardTeaserClicks,cardTeaserImpressions,comments,dislikes,estimatedMinutesWatched,likes,shares,videosAddedToPlaylists,videosRemovedFromPlaylists,views",
            Settings = new("Geo")
        },
        new()
        {
            SubscriptionType = SubscriptionType.YT2_TRAFFIC_SOURCE,
            SubscriptionName = "Youtube V2 Traffic Source",
            Fields = "channel,channel_country,channel_custom_url,channel_description,channel_hidden_subscribers,channel_published_at," +
                     "channel_thumbnail_url,channel_title,channel_url,dataSourceName,date,insightTrafficSourceType," +
                     "estimatedMinutesWatched,views",
            Settings = new("TrafficSources")
        },
        new()
        {
            SubscriptionType = SubscriptionType.YT2_VIDEO,
            SubscriptionName = "Youtube V2 Video",
            Fields = "channel,channel_title,channel_url,dataSourceName,date,liveBroadcastContent,video,video_description," +
                     "video_embeddable,video_failure_reason,video_made_for_kids,video_privacy_status,video_public_stats_viewable," +
                     "video_published_at,video_published_date,video_rejection_reason,video_thumbnail_url,video_title,video_upload_status," +
                     "video_url,annotationClickableImpressions,annotationClicks,annotationClickThroughRate,annotationClosableImpressions," +
                     "annotationCloseRate,annotationCloses,annotationImpressions,averageViewDuration_seconds,averageViewPercentage,avgTimeViewed_hms," +
                     "avgTimeViewed_minutes,cardClickRate,cardClicks,cardImpressions,cardTeaserClickRate,cardTeaserClicks,cardTeaserImpressions," +
                     "comments,dislikes,estimatedMinutesWatched,likes,shares,subscribersGained,subscribersLost,videosAddedToPlaylists,videosRemovedFromPlaylists,views",
            Settings = new("LatestVideos")
        }
    });

    private async Task SeedLinkedInCompanyPages() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.LIP_PAGE,
            SubscriptionName = "LinkedIn Company Pages - Page",
            Fields = "profile,profileID,today,page_clicks,page_comments,page_engagements,page_impressions,page_likes," +
                     "page_shares,follower_count,total_share_engagements,total_shares,total_share_comments,total_share_likes," +
                     "total_share_clicks,total_share_impressions_unique,total_share_impressions,total_share_engagement_rate," +
                     "page_views,total_page_views"
        },
        new()
        {
            SubscriptionType = SubscriptionType.LIP_POST,
            SubscriptionName = "LinkedIn Company Pages - Post",
            Fields = "date,profile,profileID,update_description,update_eyebrow_url,update_id,update_image_url,update_share_comment," +
                     "update_share_media_category,update_source_name,update_source_share_id,update_title,update_url,update_visibility," +
                     "page_comments,page_impressions,page_likes,page_engagements"
        },
        new()
        {
            SubscriptionType = SubscriptionType.LIP_COUNTRY,
            SubscriptionName = "LinkedIn Company Pages - Followers by Country",
            Fields = "follower_country,profile,profileID,today,follower_count_organic,follower_count_paid"
        }
    });

    private async Task SeedGoogleAds() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.AW_CAMPAIGN,
            SubscriptionName = "Google Ads - Campaign",
            Fields = "Accountname_fromAW,AdvertisingChannelSubType,AdvertisingChannelType,Biddingstrategy,BiddingstrategyID,BiddingstrategyType,CampaignID," +
                     "campaignlabels,Campaignname,Campaignstatus,Currencycode,dataSourceName,Date,profileID,Budget_noncalc,Clicks,Conversions,ConversionValue," +
                     "Cost,Cost_eur,Cost_gbp,engagements,Impressions,interactions,TotalAmount,videoimpressions,videoviews,Viewthroughconversions,Ctr,CPC,CPM," +
                     "engagementrate,interactionrate,Bouncerate,AveragePageviews,ConversionRate,Budget,startDate"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_AD,
            SubscriptionName = "Google Ads - Ad",
            Fields = "Accountname_fromAW,Adapprovalstatus,AdgroupID,adgrouplabels,Adgroupname,Adgroupstatus,AdID,adlabels,Adstatus,Adtype,CampaignID," +
                     "campaignlabels,Campaignname,Campaignstatus,Currencycode,CustomUrlParameters,dataSourceName,Date,Description,Description1," +
                     "Description2,DestinationURL,DisplayURL,finalURL,Headline,HeadlinePart1,HeadlinePart2,HeadlinePart3,Imageadname,ImageadURL," +
                     "ImageCreativeImageHeight,ImageCreativeImageWidth,LongHeadline,Network,path1,path2,placeholder_dim,profileID,ShortHeadline," +
                     "TextAdDescription1,TextAdDescription2,TrackingUrlTemplate,ActiveViewImpressions,AveragePosition_noncalc,Clicks,Conversions," +
                     "ConversionValue,Cost,Cost_eur,Cost_gbp,engagements,GmailForwards,GmailSaves,GmailSecondaryClicks,Impressions,interactions," +
                     "videoimpressions,VideoQuartile100Views,videoviews,Viewthroughconversions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_KEYWORD,
            SubscriptionName = "Google Ads - Keyword",
            Fields = "Accountname_fromAW,AdgroupID,Adgroupname,Adgroupstatus,Campaignname,Campaignstatus,CreativeQualityScore,Currencycode,dataSourceName," +
                     "Date,Keyword,KeyworddestinationURL,KeywordID,keywordlabels,Keywordstatus,Matchtype,Network,Networkwithsearchpartners,PostClickQualityScore," +
                     "profileID,Qualityscore,AveragePosition_noncalc,Clicks,Conversions,ConversionValue,Cost,Cost_eur,Cost_gbp,engagements,Impressions," +
                     "interactions,Viewthroughconversions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_PLACEMENT,
            SubscriptionName = "Google Ads - Placement",
            Fields = "Accountname_fromAW,CampaignID,Campaignname,Campaignstatus,CustomUrlParameters,dataSourceName,Date,Domain," +
                     "Network,PlacementdestinationURL,Placementstatus,profileID,ActiveViewImpressions,Clicks,Conversions,ConversionValue," +
                     "Cost,Cost_eur,Cost_gbp,engagements,Impressions,interactions,videoviews"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_CONVERSION,
            SubscriptionName = "Google Ads - Conversion",
            Fields = "Accountname_fromAW,AdvertisingChannelSubType,AdvertisingChannelType,Biddingstrategy,BiddingstrategyID," +
                     "BiddingstrategyType,CampaignID,campaignlabels,Campaignname,Campaignstatus,ConversionCategory,ConversionTrackerId," +
                     "ConversionTypeName,dataSourceName,Date,ExternalConversionSource,profileID,Conversions,ConversionValue," +
                     "EstimatedCrossDeviceConversions,EstimatedTotalConversions,EstimatedTotalConversionValue,Viewthroughconversions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_SEARCH_QUERY,
            SubscriptionName = "Google Ads - Search Query",
            Fields = "Accountname_fromAW,CampaignID,Campaignname,Campaignstatus,dataSourceName,Date,Keyword,KeywordID,profileID," +
                     "QueryTargetingStatus,Searchterm,Clicks,Conversions,ConversionValue,Cost,Cost_eur,Cost_gbp," +
                     "engagements,Impressions,interactions,Viewthroughconversions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_SHOPPING,
            SubscriptionName = "Google Ads - Shopping",
            Fields = "Accountname_fromAW,Brand,CampaignID,Campaignname,Campaignstatus,CategoryL1,CategoryL2,CategoryL3," +
                     "CategoryL4,CategoryL5,CustomAttribute0,CustomAttribute1,CustomAttribute2,CustomAttribute3,CustomAttribute4," +
                     "dataSourceName,Date,Language,MerchantId,OfferId,ProductCondition,ProductTitle,ProductTypeL1," +
                     "ProductTypeL2,ProductTypeL3,ProductTypeL4,ProductTypeL5,profileID,StoreId,Clicks,Cost,Impressions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_GEO,
            SubscriptionName = "Google Ads - Geo",
            Fields = "Accountname_fromAW,AdgroupID,Adgroupname,CampaignID,Campaignname,Campaignstatus,City,Countryname," +
                     "dataSourceName,Date,Metroarea,profileID,Region,Clicks,Conversions,ConversionValue,Cost," +
                     "Cost_eur,Cost_gbp,Impressions,videoviews,Viewthroughconversions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_AGE,
            SubscriptionName = "Google Ads - Age",
            Fields = "Accountname_fromAW,CampaignID,Campaignname,Campaignstatus,dataSourceName,Date,Age," +
                     "profileID,Clicks,Conversions,ConversionValue,Cost,Cost_gbp,Impressions,videoviews," +
                     "Ctr,CPC,CPM,engagements,interactions"
        },
        new()
        {
            SubscriptionType = SubscriptionType.AW_GENDER,
            SubscriptionName = "Google Ads - Gender",
            Fields = "Accountname_fromAW,CampaignID,Campaignname,Campaignstatus,dataSourceName,Date,Gender," +
                     "profileID,Clicks,Conversions,ConversionValue,Cost,Cost_gbp,Impressions,videoviews," +
                     "Ctr,CPC,CPM,engagements,interactions"
        }
    });

    private async Task SeedTikTok() => await CreateSubscriptionSettings(new SubscriptionSetting[]
    {
        new()
        {
            SubscriptionType = SubscriptionType.TIKBA_PROFILE,
            SubscriptionName = "TikTok Organic - Profile",
            Fields = "profile__date,profile__display_name,profile__profile_image_url,profile__username,profile__comments," +
                     "profile__likes,profile__new_followers,profile__profile_followers__current_followers," +
                     "profile__profile_views,profile__shares,profile__total_engagement,profile__video_views"
        },
        new()
        {
            SubscriptionType = SubscriptionType.TIKBA_VIDEO,
            SubscriptionName = "TikTok Organic - Video",
            Fields = "videos__caption,videos__create_date,videos__create_datetime,videos__display_name,videos__embed_url," +
                     "videos__share_url,videos__thumbnail_url,videos__username,videos__video_id,videos__comments,videos__likes," +
                     "videos__reach,videos__shares,videos__total_time_watched_h,videos__total_time_watched_min," +
                     "videos__total_time_watched_sec,videos__video_completion_rate,videos__video_duration_min," +
                     "videos__video_duration_sec,videos__video_views,today"
        },
        new()
        {
            SubscriptionType = SubscriptionType.TIKBA_COUNTRY,
            SubscriptionName = "TikTok Organic - Country",
            Fields = "territories__country,territories__display_name,territories__username,territories__distribution,today"
        },
        new()
        {
            SubscriptionType = SubscriptionType.TIKBA_GENDER,
            SubscriptionName = "TikTok Organic - Gender",
            Fields = "gender__display_name,gender__gender,gender__username,gender__distribution,today"
        }
    });
}