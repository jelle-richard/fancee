using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Services;
using SubscriptionService.Dtos.Requests.Settings;

namespace SubscriptionService.Services.Settings;

public interface ISubscriptionSettingsService : IMongoService<SubscriptionSetting>
{
    /// <summary>
    /// Checks whether there are any items in the collection.
    /// </summary>
    /// <returns></returns>
    public Task<bool> AnyAsync();

    /// <summary>
    /// Seeds all subscription settings for each subscription type.
    /// </summary>
    /// <returns></returns>
    public Task SeedSubscriptionSettings();

    /// <summary>
    /// Updates subscription setting split and fields by subscription type.
    /// </summary>
    /// <param name="subscriptionType"></param>
    /// <param name="request"></param>
    /// <param name="userId"></param>
    /// <returns>SubscriptionSetting</returns>
    public Task<SubscriptionSetting> UpdateSubscriptionSettingAsync(SubscriptionType subscriptionType, UpdateSubscriptionSettingsRequest request, Guid userId);

    /// <summary>
    /// Deletes subscriptionsetting by subscriptiontype.
    /// </summary>
    /// <param name="subscriptionType"></param>
    /// <returns>true/false</returns>
    public Task<bool> DeleteAsync(SubscriptionType subscriptionType);
}