using System.Net;
using FanceeAnalyticsData.Models.Analytics;

namespace SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;

public interface ISuperMetricsHandler
{
    public HttpStatusCode[] StatusCode { get; }

    /// <summary>
    /// Handles the output of the SuperMetrics API call in Connection.
    /// </summary>
    /// <param name="conn"></param>
    /// <param name="subscription"></param>
    /// <returns></returns>
    public Task<Connection> HandleAsync(Connection conn, Subscription subscription);
}