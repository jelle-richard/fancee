using System.Net.Mime;
using System.Text;
using System.Text.Json;
using CronScheduler.Extensions.Internal;
using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Entries;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Logging;
using SocialListeningCore.Persistence.Connections;
using SocialListeningCore.Persistence.Entries;
using SocialListeningCore.Services;
using SocialListeningCore.Utils.Cron;
using SocialListeningCore.Utils.Extensions;
using SubscriptionService.Dtos.Requests.Subscriptions;
using SubscriptionService.Dtos.Responses;
using SubscriptionService.Exceptions;
using SubscriptionService.Jobs;
using SubscriptionService.Persistence.Channels;
using SubscriptionService.Persistence.Settings;
using SubscriptionService.Persistence.Subscriptions;
using SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;
using SubscriptionService.Utils;
using SubscriptionNotFoundException = SubscriptionService.Exceptions.SubscriptionNotFoundException;

namespace SubscriptionService.Services.Subscriptions;

public class SubscriptionsService(
    IConfiguration configuration,
    ISubscriptionsDao subscriptionsDao,
    IConnectionsDao connectionsDao,
    IGenericEntriesDao genericEntriesDao,
    ISubscriptionSettingsDao subscriptionSettingsDao,
    ISchedulerRegistration schedulerRegistration,
    ILoggerFactory loggerFactory,
    IHttpClientFactory httpClientFactory,
    IChannelDao channelDao,
    IServiceProvider serviceProvider,
    IEnumerable<ISuperMetricsHandler> superMetricsHandlers)
    : MongoService<Subscription, ISubscriptionsDao>(subscriptionsDao), ISubscriptionsService
{
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);
    private readonly ISubscriptionsDao _subscriptionsDao = subscriptionsDao;

    public async Task<Subscription> CreateAsync(CreateSubscriptionRequest create) => await _subscriptionsDao.CreateAsync(create.ToSubscription());

    public async Task<Subscription?> FirstBySubscriptionTypeAsync(SubscriptionType type) => await _subscriptionsDao.FirstBySubscriptionTypeAsync(type);

    public async Task<IEnumerable<EntryResponse>> EntriesAsync(Subscription subscription, DateTime? startDate = null, DateTime? endDate = null, DateRange dateRange = DateRange.DAILY) => await genericEntriesDao.ToListAsync<EntryResponse>(subscription.Id!, subscription.SubscriptionType, startDate, endDate);

    public async Task<IEnumerable<GenericEntry>> EntriesWithDifferencesAsync(Subscription subscription, DateTime? startDate = null, DateTime? endDate = null, DateRange dateRange = DateRange.DAILY)
    {
        var result = await genericEntriesDao.ToListAsync<GenericEntry>(subscription.Id!, subscription.SubscriptionType, startDate, endDate);
        var latestEntry = await genericEntriesDao.GetLastEntryAsync(subscription.Id, subscription.SubscriptionType, startDate, endDate);

        if (latestEntry != null)
            result = new[] { latestEntry }.Concat(result);

        return SubscriptionServiceHelper.CalculateDifferenceBetweenEntries(result.Reverse());
    }

    public async Task<IEnumerable<Subscription>> ToListAsync()
    {
        var subscriptions = (await GetListAsync()).ToArray();
        foreach (var sub in subscriptions)
            sub.Active = schedulerRegistration.Jobs.Any(dbItem => dbItem.Key == sub.Name);

        return subscriptions;
    }

    public async Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId)
    {
        var subscriptions = (await _subscriptionsDao.ToListByChannelIdAsync(channelId)).ToArray();
        foreach (var sub in subscriptions)
            sub.Active = schedulerRegistration.Jobs.Any(dbItem => dbItem.Key == sub.Name);

        return subscriptions;
    }

    public async Task<ResultSetResponse<Connection>> PaginatedConnectionListAsync(string id, PaginatedRequest<SearchQueryFilter> request) => await connectionsDao.ToPaginatedListAsync(new() { SubscriptionId = id }, request.PageSize, request.GetOffset());

    public async Task<bool> DeleteByIdAsync(string id)
    {
            var sub = await GetAsync(id) ?? throw new SubscriptionNotFoundException(id);

            if (schedulerRegistration.Jobs.Any(dbItem => dbItem.Key == sub.Name))
                StopSubscriptionJob(sub.Name);

            await genericEntriesDao.DeleteListForSubscriptionAsync(id, sub.SubscriptionType);

            return await _subscriptionsDao.DeleteAsync(id);
    }

    public SubscriptionCronJob AddOrUpdateSubscriptionSchedule(Subscription subscription)
    {
        var jobOptions = new SchedulerOptions
        {
            CronSchedule = subscription.Cron!,
            RunImmediately = false
        };
        var job = new SubscriptionRunnerJob(
            serviceProvider.CreateScope().ServiceProvider,
            subscription,
            jobOptions,
            _logger
        );

        var result = schedulerRegistration.AddOrUpdate(subscription.Name, job, jobOptions);

        if (result)
            _logger.LogInformation("Started subscription job: {name}", subscription.Name);
        else
            _logger.LogWarning("Failed to start subscription job: {name}", subscription.Name);

        return new()
        {
            JobName = subscription.Name,
            Subscription = subscription,
            IsRunning = result
        };
    }

    public async Task<SubscriptionCronJob> AddOrUpdateInactiveSubscriptionSchedule()
    {
        var jobOptions = new SchedulerOptions
        {
            CronSchedule = CronConstants.CronRunEvery5Minutes,
            RunImmediately = false
        };

        var job = new SubscriptionActivateRunnerJob(serviceProvider.CreateScope().ServiceProvider, jobOptions, _logger);

        var result = await Task.Run(() => schedulerRegistration.AddOrUpdate("SubscriptionActivationJob", job, jobOptions));

        if (result)
            _logger.LogInformation("Started subscription activation job: {name}", job.Name);
        else
            _logger.LogWarning("Failed to start subscription activation job: {name}", job.Name);

        return new()
        {
            JobName = job.Name,
            IsRunning = result
        };
    }

    public async Task<IEnumerable<SubscriptionCronJob>> StartAllInactiveSubscriptionsAsync()
    {
        var filter = Builders<Subscription>.Filter.Nin(dbItem => $"{dbItem.Id}-{dbItem.SubscriptionType.ToString()}-live", schedulerRegistration.Jobs.Keys);

        return StartSubscriptions(await _subscriptionsDao.GetListAsync(filter));
    }

    public async Task<IEnumerable<SubscriptionCronJob>> StartAllAsync() => StartSubscriptions(await _subscriptionsDao.ListByChannelStatusAsync(ChannelStatus.Active));

    public async Task<IEnumerable<SubscriptionCronJob>> StopAllAsync()
    {
        var result = new List<SubscriptionCronJob>();

        var subscriptions = await _subscriptionsDao.GetListAsync();
        foreach (var sub in subscriptions)
            result.Add(StopSubscriptionJob(sub.Name));

        return result;
    }

    public IEnumerable<SchedulerTaskWrapper> ListAllAsync() => schedulerRegistration.Jobs.Values;

    public SubscriptionCronJob StopSubscriptionJob(string name)
    {
        var result = schedulerRegistration.Remove(name);
        if (result)
            _logger.LogInformation("Stopped subscription job: {name}", name);
        else
            _logger.LogWarning("Failed to stop subscription job: {name}. Job not found.", name);

        return new()
        {
            JobName = name,
            IsRunning = result
        };
    }

    public async Task<SubscriptionCronJob> StopByIdAsync(string id)
    {
        var subscription = await _subscriptionsDao.GetAsync(id) ?? throw new SubscriptionNotFoundException(id);

        return StopSubscriptionJob(subscription.Name);
    }

    public async Task<SubscriptionCronJob> StartByIdAsync(string id)
    {
        var subscription = await _subscriptionsDao.GetAsync(id) ?? throw new SubscriptionNotFoundException(id);

        var jobIsAlreadyRunning = schedulerRegistration.Jobs.Any(dbItem => dbItem.Key == subscription.Name);
        if (!jobIsAlreadyRunning)
            return AddOrUpdateSubscriptionSchedule(subscription);

        _logger.LogInformation("Tried to start job but was already running: {name}", subscription.Name);
        return new()
        {
            JobName = subscription.Name,
            IsRunning = true,
            Subscription = subscription
        };

    }

    public async Task<Subscription?> FirstAsync(string channelId, SubscriptionType[] subscriptionType)
    {
        var subscriptions = await _subscriptionsDao.ToListByChannelIdAsync(channelId);
        return subscriptions.FirstOrDefault(s => subscriptionType.Contains(s.SubscriptionType)) ??
               throw new ChannelNotFoundException(channelId);
    }

    public async Task<Subscription> UpdateAsync(string id, UpdateSubscriptionRequest update)
    {
        var subscription = await _subscriptionsDao.GetAsync(id) ?? throw new SubscriptionNotFoundException(id);

        if (!string.IsNullOrEmpty(update.Cron)) subscription.Cron = update.Cron;

        return await _subscriptionsDao.UpdateAsync(subscription);
    }

    public async Task<Connection> CallServerAsync(Subscription subscription)
    {
        var channel = await channelDao.GetAsync(subscription.ChannelId!);

        if (channel is null)
        {
            StopSubscriptionJob(subscription.Name);
            throw new ChannelNotFoundException(subscription.ChannelId!);
        }
        
        var settings = await subscriptionSettingsDao.GetSettingsByTypeAsync(subscription.SubscriptionType);

        subscription.Input.FieldsAsString = settings.Fields;
        subscription.Input.Filter = settings.Filter;
        subscription.Input.Settings = settings.Settings;

        var input = JsonSerializer.Serialize(subscription.Input!);
        StringContent content = new(input, Encoding.UTF8, MediaTypeNames.Application.Json);

        using var response = await GetClient().PostAsync($"{configuration.GetConnectionString("SuperMetrics")}query/data/json", content);
        var result = await response.Content.ReadAsStringAsync();

        var conn = BsonSerializer.Deserialize<Connection>(result) ?? throw new ConnectionSerializationException();

        conn.SubscriptionId = subscription.Id;
        conn.SubscriptionType = subscription.SubscriptionType;
        conn.Input = subscription.Input;

        _logger.LogWarning("Calling subscription for channel:  {channelName} - Response: {response}", channel.Name, response.StatusCode.ToString());

        var handler = superMetricsHandlers.FirstOrDefault(t => t.StatusCode.Contains(response.StatusCode)) ?? throw new NoHandlerException();
        return await handler.HandleAsync(conn, subscription);
    }

    public async Task RunAsync(Subscription input) => await CallServerAsync(input);

    private IEnumerable<SubscriptionCronJob> StartSubscriptions(IEnumerable<Subscription> subscriptions)
    {
        var result = new List<SubscriptionCronJob>();

        foreach (var sub in subscriptions)
        {
            sub.Input.DateRangeType = sub.SubscriptionType.ToDefaultDateRangeType();
            result.Add(AddOrUpdateSubscriptionSchedule(sub));

            if (sub.SubscriptionType != SubscriptionType.IGI_MEDIA)
                continue;

            var storySubscription = new Subscription
            {
                Id = sub.Id,
                AdditionalInfo = "-stories",
                ChannelId = sub.ChannelId,
                Input = new(sub.Input)
                {
                    DateRangeType = "last_5_days_inc",
                    Filter = "media_product_type == STORY"
                },
                Cron = CronConstants.CronRunEveryMinute,
                IsHistory = false,
                Active = true,
                Fields = sub.Fields,
                SubscriptionType = sub.SubscriptionType
            };
            result.Add(AddOrUpdateSubscriptionSchedule(storySubscription));
        }

        return result;
    }

    private HttpClient GetClient()
    {
        var apiKey = configuration.GetValue<string>("SuperMetrics:ApiKey");
        if (string.IsNullOrEmpty(apiKey))
            throw new NotSupportedException("SuperMetrics:ApiKey not found. Value required in secrets.json");

        var client = httpClientFactory.CreateClient("supermetrics");
        client.Timeout = TimeSpan.FromMinutes(5);
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
        client.DefaultRequestHeaders.Accept.Add(new(MediaTypeNames.Application.Json));

        return client;
    }
}