using CronScheduler.Extensions.Internal;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using FanceeAnalyticsData.Models.Analytics.Entries;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Services;
using SocialListeningCore.Services.Cron;
using SubscriptionService.Dtos.Requests.Subscriptions;
using SubscriptionService.Dtos.Responses;

namespace SubscriptionService.Services.Subscriptions;

public interface ISubscriptionsService : IMongoService<Subscription>, ICronService<Subscription>
{
    /// <summary>
    /// Creates a new Subscription that collects data from SuperMetrics per cron timing.
    /// </summary>
    /// <param name="create"></param>
    /// <returns>The newly created Subscription</returns>
    public Task<Subscription> CreateAsync(CreateSubscriptionRequest create);

    /// <summary>
    /// Updates a Subscription that collects data from SuperMetrics per cron timing.
    /// </summary>
    /// <param name="update"></param>
    /// <returns>The newly created Subscription</returns>
    public Task<Subscription> UpdateAsync(string id, UpdateSubscriptionRequest update);

    /// <summary>
    /// Gets the first subscription of a given channel id and SubscriptionType(s).
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="subscriptionType"></param>
    /// <returns>A single Subscription (or null if none are found.)</returns>
    public Task<Subscription?> FirstAsync(string channelId, SubscriptionType[] subscriptionType);

    /// <summary>
    /// Gets the first Subscription, based on the SubscriptionType.
    /// </summary>
    /// <param name="type"></param>
    /// <returns>The 'first' Subscription by creation date.</returns>
    public Task<Subscription?> FirstBySubscriptionTypeAsync(SubscriptionType type);

    /// <summary>
    /// Returns a set of entries belonging to the specific Subscription, between startDate and endDate.
    /// </summary>
    /// <param name="subscription"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns>A list of entries</returns>
    public Task<IEnumerable<EntryResponse>> EntriesAsync(Subscription subscription, DateTime? startDate = null, DateTime? endDate = null, DateRange dateRange = DateRange.DAILY);

    /// <summary>
    /// Returns a set of entries belonging to the specific Subscription, between startDate and endDate.
    /// Uses a hardcoded list of fields that will be used to calculate differences between entry points.
    /// </summary>
    /// <param name="subscription"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="dateRange"></param>
    /// <returns></returns>
    public Task<IEnumerable<GenericEntry>> EntriesWithDifferencesAsync(Subscription subscription, DateTime? startDate = null, DateTime? endDate = null, DateRange dateRange = DateRange.DAILY);

    /// <summary>
    /// Gets a list of all subscriptions.
    /// </summary>
    /// <returns>All subscriptions</returns>
    public Task<IEnumerable<Subscription>> ToListAsync();

    /// <summary>
    /// Gets a list of all subscriptions for a given channel.
    /// </summary>
    /// <returns>All subscriptions</returns>
    public Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId);

    /// <summary>
    /// Gets a paginated list of connections for a given subscription id.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<Connection>> PaginatedConnectionListAsync(string id, PaginatedRequest<SearchQueryFilter> request);

    /// <summary>
    /// Calls the SuperMetrics server with the input requirements based on the given Subscription.
    /// This will then parse the result and fill the MongoDB as (GenericEntry) entries.
    /// </summary>
    /// <param name="subscription"></param>
    /// <returns>The Connection that was made, either successfull or not.</returns>
    public Task<Connection> CallServerAsync(Subscription subscription);

    /// <summary>
    /// Starts all cronjobs for all subscriptions.
    /// </summary>
    /// <returns>list of SubscriptionCronJobs</returns>
    public Task<IEnumerable<SubscriptionCronJob>> StartAllAsync();

    /// <summary>
    /// Stops all cronjobs for all subscriptions.
    /// </summary>
    /// <returns>list of SubscriptionCronJobs</returns>
    public Task<IEnumerable<SubscriptionCronJob>> StopAllAsync();

    /// <summary>
    /// Returns a list of all active cron jobs.
    /// </summary>
    /// <returns>list of SchedulerTaskWrapper</returns>
    public IEnumerable<SchedulerTaskWrapper> ListAllAsync();

    /// <summary>
    /// Starts a cronjob based on the id of a Subscription.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>SubscriptionCronjob</returns>
    public Task<SubscriptionCronJob> StartByIdAsync(string id);

    /// <summary>
    /// Stops a cronjob based on the id of a Subscription.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>SubscriptionCronjob</returns>
    public Task<SubscriptionCronJob> StopByIdAsync(string id);

    /// <summary>
    /// Removes a Subscription by id from the database. The active SubscriptionJob will also be stopped and removed.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>True/False if the removal was successfull.</returns>
    public Task<bool> DeleteByIdAsync(string id);

    /// <summary>
    /// Stops a cronjob based on the name of a SubscriptionJob. Mainly used by 'SubscriptionRunnerJob' when 'RunOnce' is set to true.
    /// </summary>
    /// <param name="name"></param>
    /// <returns>True/False if the cronjob was found/stopped.</returns>
    public SubscriptionCronJob StopSubscriptionJob(string name);

    /// <summary>
    /// Adds or updates a (running) cronjob, based on a Subscription.
    /// </summary>
    /// <param name="subscription"></param>
    /// <returns>SubscriptionCron where isRunning is true if the cronjob was either added or updated, False otherwise.</returns>
    public SubscriptionCronJob AddOrUpdateSubscriptionSchedule(Subscription subscription);

    /// <summary>
    /// Add or updates a cronjob for inactive subscriptions
    /// </summary>
    /// <returns>SubscriptionCronJob</returns>
    public Task<SubscriptionCronJob> AddOrUpdateInactiveSubscriptionSchedule();

    /// <summary>
    /// Starts all inactive subscriptions which are created and save in MongoDB but are not started yet.
    /// </summary>
    /// <returns>list of SubscriptionCronJobs</returns>
    public Task<IEnumerable<SubscriptionCronJob>> StartAllInactiveSubscriptionsAsync();
}