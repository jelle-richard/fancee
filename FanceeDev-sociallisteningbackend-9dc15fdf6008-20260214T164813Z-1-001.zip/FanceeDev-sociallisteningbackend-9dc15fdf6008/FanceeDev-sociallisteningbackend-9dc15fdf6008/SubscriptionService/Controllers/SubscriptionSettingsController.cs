using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Logging;
using SocialListeningCore.Utils.HttpContext;
using SubscriptionService.Dtos.Requests.Settings;
using SubscriptionService.Exceptions;
using SubscriptionService.Services.Settings;

namespace SubscriptionService.Controllers;

[Authorize]
[ApiController]
[Route("/[controller]")]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class SubscriptionSettingsController(ISubscriptionSettingsService subscriptionSettingService, ILoggerFactory loggerFactory) : ControllerBase
{
    private Guid UserId => User.GetUserId();
    private UserType CurrentUserType => User.GetUserType() ?? UserType.Organization;
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);

    [HttpPatch]
    [ProducesResponseType(typeof(ApiResponse<SubscriptionSetting>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SubscriptionSetting>>> UpdateSubscriptionSetting(SubscriptionType subscriptionType, [FromQuery] UpdateSubscriptionSettingsRequest update)
    {
        if (!CurrentUserType.HasFlag(UserType.Admin))
            throw new MissingPermissionException();

        var updatedSubscriptionSetting = await subscriptionSettingService.UpdateSubscriptionSettingAsync(subscriptionType, update, UserId);

        _logger.MongoLogInfo(UserId, $"updated {subscriptionType}.", new
        {
            subscriptiontype = subscriptionType.ToString(),
            fields = update.Fields,
            split = update.Split
        });

        return Ok(new ApiResponse<SubscriptionSetting> { Data = updatedSubscriptionSetting });
    }

    [HttpDelete]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<bool>>> DeleteSubscriptionSetting(SubscriptionType subscriptionType)
    {
        if (!CurrentUserType.HasFlag(UserType.Admin))
            throw new MissingPermissionException();

        if (!Enum.GetName(subscriptionType)!.Contains('_'))
            throw new SubscriptionTypeForbiddenException(subscriptionType);

        var isDeleted = await subscriptionSettingService.DeleteAsync(subscriptionType);
        if (!isDeleted)
            throw new SubscriptionTypeNotFoundException(subscriptionType);

        _logger.MongoLogInfo(UserId, $"Subscriptiontype settings of subscriptiontype {subscriptionType} deleted.");

        return Ok(new ApiResponse<bool> { Data = true });
    }
}