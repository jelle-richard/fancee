using System.Net;
using System.Net.Mime;
using CronScheduler.Extensions.Internal;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Utils.Cron;
using SocialListeningCore.Utils.Extensions;
using SubscriptionService.Dtos.Requests.Subscriptions;
using SubscriptionService.Dtos.Responses;
using SubscriptionService.Exceptions;
using SubscriptionService.Services.Subscriptions;

namespace SubscriptionService.Controllers;

[Authorize]
[ApiController]
[Route("/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class SubscriptionsController(ISubscriptionsService subscriptionsService) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<Subscription>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<Subscription>>>> GetAllSubscriptionsUnderChannel(string? channelId = null) =>
        Ok(new ApiResponse<IEnumerable<Subscription>>
        {
            Data = channelId == null ? await subscriptionsService.ToListAsync() : await subscriptionsService.ToListByChannelIdAsync(channelId)
        });

    [HttpGet]
    [Route("start")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<SubscriptionCronJob>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<SubscriptionCronJob>>>> StartAllCronJobs() =>
        Ok(new ApiResponse<IEnumerable<SubscriptionCronJob>>
        {
            Data = await subscriptionsService.StartAllAsync()
        });

    [HttpGet]
    [Route("stop")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<SubscriptionCronJob>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<SubscriptionCronJob>>>> StopAllCronJobs() =>
        Ok(new ApiResponse<IEnumerable<SubscriptionCronJob>>
        {
            Data = await subscriptionsService.StopAllAsync()
        });

    [HttpGet]
    [Route("cron")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<SchedulerTaskWrapper>>), StatusCodes.Status200OK)]
    public ActionResult<ApiResponse<IEnumerable<SchedulerTaskWrapper>>> ListAllCronJobs() =>
        Ok(new ApiResponse<IEnumerable<SchedulerTaskWrapper>>
        {
            Data = subscriptionsService.ListAllAsync()
        });

    [HttpPost]
    [ProducesResponseType(typeof(ApiResponse<Subscription>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<Subscription>>> Create([FromQuery] CreateSubscriptionRequest create)
    {
        if (!CronHelper.TryParse(create.Cron))
            throw new InvalidCronException();

        if (string.IsNullOrWhiteSpace(create.Query))
            throw new InvalidCronException();

        var subscription = await subscriptionsService.CreateAsync(create);
        subscription.Active = subscriptionsService.AddOrUpdateSubscriptionSchedule(subscription).IsRunning;

        if (!create.RequestHistory)
            return Created($"/{subscription.Id}", new ApiResponse<Subscription> { Data = subscription });

        Subscription historySubscription = new()
        {
            Id = subscription.Id,
            Input = new(subscription.Input) { DateRangeType = "last_6_months_inc" },
            SubscriptionType = subscription.SubscriptionType,
            Cron = CronConstants.CronRunEveryMinute,
            RunOnce = true,
            Active = true,
            IsHistory = true
        };

        subscriptionsService.AddOrUpdateSubscriptionSchedule(historySubscription);

        return Created($"/{subscription.Id}", new ApiResponse<Subscription> { Data = subscription });
    }

    [HttpGet]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<Subscription>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Subscription>>> Single(string id)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<Subscription>
        {
            Data = await subscriptionsService.GetAsync(id)
        });
    }

    [HttpGet]
    [Route("{id}/connections")]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<Connection>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<Connection>>>> PaginatedConnectionsListBySubscriptionId(string id, [FromQuery] PaginatedRequest<SearchQueryFilter> request)
    {
        var result = await subscriptionsService.PaginatedConnectionListAsync(id, request);

        return Ok(new ApiResponse<PaginatedResponse<Connection>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("{id}/entries")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<EntryResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<EntryResponse>>>> EntriesBetweenDatesBySubscriptionId(string id, DateTime? startDate = null, DateTime? endDate = null, DateRange dateRange = DateRange.DAILY)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        var subscription = await subscriptionsService.GetAsync(id);

        return Ok(new ApiResponse<IEnumerable<EntryResponse>>
        {
            Data = await subscriptionsService.EntriesAsync(subscription, startDate, endDate, dateRange)
        });
    }

    [HttpPut]
    [Route("{id}/update")]
    [ProducesResponseType(typeof(ApiResponse<SubscriptionCronJob>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SubscriptionCronJob>>> RunNewHistorySubscriptionById(string id, [FromQuery] string? dateRange = null)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        var subscription = await subscriptionsService.GetAsync(id);

        if (subscription.SubscriptionType.ToChannelType() == ChannelType.TIKTOK)
            dateRange = "last_60_days_inc";

        Subscription historySubscription = new()
        {
            Id = subscription.Id,
            ChannelId = subscription.ChannelId,
            Input = new(subscription.Input)
            {
                DateRangeType = dateRange ?? "last_6_months_inc",
                StartDate = null,
                EndDate = null
            },
            SubscriptionType = subscription.SubscriptionType,
            Cron = CronConstants.CronRunEveryMinute,
            RunOnce = true,
            Active = true,
            IsHistory = true
        };

        return Ok(new ApiResponse<SubscriptionCronJob>
        {
            Data = subscriptionsService.AddOrUpdateSubscriptionSchedule(historySubscription)
        });
    }

    [HttpPut]
    [Route("update")]
    [ProducesResponseType(typeof(ApiResponse<SubscriptionCronJob>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<SubscriptionCronJob>>>> RefreshSuscriptionsByChannelId([FromQuery] string channelId)
    {
        var subscriptions = await subscriptionsService.ToListByChannelIdAsync(channelId);
        var cronJobs = new List<SubscriptionCronJob>();
        foreach (var subscription in subscriptions)
        {
            Subscription historySubscription = new()
            {
                Id = subscription.Id,
                Input = new(subscription.Input)
                {
                    DateRangeType = subscription.SubscriptionType.ToChannelType() == ChannelType.TIKTOK ? "last_60_days_inc" : "last_6_months_inc",
                    StartDate = null,
                    EndDate = null
                },
                SubscriptionType = subscription.SubscriptionType,
                Cron = CronConstants.CronRunEveryMinute,
                RunOnce = true,
                Active = true,
                IsHistory = true,
                ChannelId = subscription.ChannelId
            };
            cronJobs.Add(subscriptionsService.AddOrUpdateSubscriptionSchedule(historySubscription));
        }

        return Ok(new ApiResponse<IEnumerable<SubscriptionCronJob>>
        {
            Data = cronJobs
        });
    }

    [HttpGet]
    [Route("{id}/start")]
    [ProducesResponseType(typeof(ApiResponse<SubscriptionCronJob>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SubscriptionCronJob>>> StartSingle(string id)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<SubscriptionCronJob> { Data = await subscriptionsService.StartByIdAsync(id) });
    }

    [HttpGet]
    [Route("{id}/stop")]
    [ProducesResponseType(typeof(ApiResponse<SubscriptionCronJob>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<SubscriptionCronJob>>> StopSingle(string id)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<SubscriptionCronJob> { Data = await subscriptionsService.StopByIdAsync(id) });
    }

    [HttpPatch]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<Subscription>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Subscription>>> Update(string id, [FromQuery] UpdateSubscriptionRequest update)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        if (!CronHelper.TryParse(update.Cron))
            throw new InvalidCronException();

        return Ok(new ApiResponse<Subscription> { Data = await subscriptionsService.UpdateAsync(id, update) });
    }

    [HttpDelete]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<bool>>> Delete(string id)
    {
        if (!ObjectId.TryParse(id, out var _))
            throw new InvalidObjectIdException();

        return Ok(new ApiResponse<bool> { Data = await subscriptionsService.DeleteByIdAsync(id) });
    }
}