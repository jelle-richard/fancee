using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore;
using SocialListeningCore.Logging;
using SocialListeningCore.Persistence.MailQueues;
using SocialListeningCore.Services.Cron;
using SocialListeningCore.Services.DeploymentEnvironments;
using SocialListeningCore.Services.Scheduler;
using SubscriptionService.Jobs;
using SubscriptionService.Persistence.Channels;
using SubscriptionService.Persistence.Settings;
using SubscriptionService.Persistence.Subscriptions;
using SubscriptionService.Services.Settings;
using SubscriptionService.Services.Subscriptions;
using SubscriptionService.Services.Subscriptions.SuperMetricsConnectionHandling;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "SubscriptionService",
        EndpointName = "SubscriptionService v1"
    }
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddScheduler(sb =>
    {
        sb.Services.AddStartupJob<InitSubscriptionSettingsJob>();
        sb.Services.AddStartupJob<InitSubscriptionsJob>();

        _ = sb.AddUnobservedTaskExceptionHandler(sp =>
        {
            var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger(MongoLogger.Name);
            return
                (sender, args) =>
                {
                    logger.MongoLogException(null, args.Exception);
                    args.SetObserved();
                };
        });
    });
};
builder.AddDependency<IDeploymentEnvironmentService, DeploymentEnvironmentService>(ServiceLifetime.Scoped);
builder.AddDependency<ISubscriptionsDao, SubscriptionsDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISubscriptionsService, SubscriptionsService>(ServiceLifetime.Scoped);
builder.AddDependency<ISubscriptionSettingsDao, SubscriptionSettingsDao>(ServiceLifetime.Scoped);
builder.AddDependency<ISubscriptionSettingsService, SubscriptionSettingsService>(ServiceLifetime.Scoped);
builder.AddDependency<IChannelDao, ChannelDao>(ServiceLifetime.Scoped);
builder.AddDependency<IMailQueueDao, MailQueueDao>(ServiceLifetime.Scoped);

builder.AddDependency<ICronService<Subscription>, SubscriptionsService>(ServiceLifetime.Scoped);
builder.AddDependency<ISchedulerService<Subscription>, SchedulerService<Subscription, ISubscriptionsService>>(ServiceLifetime.Scoped);

builder.AddDependency<ISuperMetricsHandler, SuperMetricsSuccessHandler>(ServiceLifetime.Scoped);
builder.AddDependency<ISuperMetricsHandler, SuperMetricsErrorHandler>(ServiceLifetime.Scoped);

var app = builder.Build();
await app.RunStartupJobsAync();
app.Run();