using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;
using SubscriptionService.Helpers.Queries;

namespace SubscriptionService.Persistence.Subscriptions;

public class SubscriptionsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<Subscription>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Subscriptions"),
    mongoDatabase), ISubscriptionsDao
{
    public async Task<IEnumerable<Subscription>> ListByChannelStatusAsync(ChannelStatus status)
    {
        var pipeline = SubscriptionQueryBuilder.BuildByStatusQuery(status);
        return await CreatePipelineAndGetListAsync<Subscription>(pipeline, CollectionSettings.GetCollectionName("Subscriptions"));
    }

    public async Task<Subscription> FirstBySubscriptionTypeAsync(SubscriptionType type)
    {
        var filter = Filter.Eq(dbItem => dbItem.SubscriptionType, type);

        return await Collection.Find(filter).FirstAsync();
    }

    public async Task<Subscription> FirstAsync(string channelId, IEnumerable<SubscriptionType> subscriptionType)
    {
        var filter = Filter.And(
            Filter.Eq(dbItem => dbItem.ChannelId, channelId),
            Filter.In(dbItem => dbItem.SubscriptionType, subscriptionType)
        );

        return await Collection.Find(filter).FirstOrDefaultAsync() ??
               throw new SubscriptionNotFoundException();
    }

    public async Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId)
    {
        var filter = Filter.Eq(dbItem => dbItem.ChannelId, channelId);

        var subscriptions = await Collection.Find(filter).ToListAsync();
        if (!subscriptions.Any())
            throw new SubscriptionNotFoundException();

        return subscriptions;
    }

    public override UpdateDefinition<Subscription> GetUpdateDefinition(Subscription? model)
    {
        if (model == null)
            return base.GetUpdateDefinition(model);

        return Builders<Subscription>.Update.Combine(
            new List<UpdateDefinition<Subscription>>
            {
                Builders<Subscription>.Update.Set(dbItem => dbItem.Cron, model.Cron),
                base.GetUpdateDefinition(model)
            }
        );
    }

    public async Task<UpdateResult> UpdateFieldsAsync(Subscription subscription)
    {
        var filter = Filter.Eq(dbItem => dbItem.Id, subscription.Id);
        var update = Update.Set(dbItem => dbItem.Fields, subscription.Fields)
            .Set(dbItem => dbItem.UpdatedOn, DateTime.UtcNow);

        return await UpdateOneAsync(filter, update);
    }
}