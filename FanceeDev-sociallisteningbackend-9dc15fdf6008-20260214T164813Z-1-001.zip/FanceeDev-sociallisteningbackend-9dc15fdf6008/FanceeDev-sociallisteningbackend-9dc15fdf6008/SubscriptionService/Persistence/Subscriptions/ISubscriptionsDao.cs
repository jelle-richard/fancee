using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Persistence;

namespace SubscriptionService.Persistence.Subscriptions;

public interface ISubscriptionsDao : IMongoDao<Subscription>
{
    /// <summary>
    /// Gets the 'first' Subscription based on a given SubscriptionType.
    /// </summary>
    /// <param name="type"></param>
    /// <returns>The first Subscription if found. otherwise null.</returns>
    public Task<Subscription> FirstBySubscriptionTypeAsync(SubscriptionType type);

    /// <summary>
    /// Gets the first subscription for a given channelId from a list of subscriptionType.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="subscriptionType"></param>
    /// <returns></returns>
    public Task<Subscription> FirstAsync(string channelId, IEnumerable<SubscriptionType> subscriptionType);

    /// <summary>
    /// Returns a list of subscriptions linked to a given channel.
    /// </summary>
    /// <param name="channelId"></param>
    /// <returns>A list of subscriptions</returns>
    public Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId);

    /// <summary>
    /// Updates the Field list returned by SuperMetrics (includes DisplayName, Name and Type).
    /// </summary>
    /// <param name="subscription"></param>
    /// <returns>Result of update</returns>
    public Task<UpdateResult> UpdateFieldsAsync(Subscription subscription);

    /// <summary>
    /// Retrieves a list of subscriptions filtered on channel status.
    /// </summary>
    /// <param name="status"></param>
    /// <returns></returns>
    public Task<IEnumerable<Subscription>> ListByChannelStatusAsync(ChannelStatus status);
}