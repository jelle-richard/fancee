using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;

namespace SubscriptionService.Persistence.Channels;

public class ChannelDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<Channel>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Channels"),
    mongoDatabase), IChannelDao
{
    public async Task<UpdateResult> UpdateStatusAndMailStatusAsync(string id, ChannelStatus status, bool hasError)
    {
        var filter = Filter.Eq(dbItem => dbItem.Id, id);
        var update = Update.Set(dbItem => dbItem.Status, status)
            .Set(dbItem => dbItem.HasError, hasError)
            .Set(dbItem => dbItem.UpdatedOn, DateTime.UtcNow);

        return await UpdateOneAsync(filter, update);
    }
}