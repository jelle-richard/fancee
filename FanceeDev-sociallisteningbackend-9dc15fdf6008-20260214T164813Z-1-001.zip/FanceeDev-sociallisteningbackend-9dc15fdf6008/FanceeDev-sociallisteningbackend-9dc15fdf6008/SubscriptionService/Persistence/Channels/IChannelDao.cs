using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using Channel = FanceeAnalyticsData.Models.Analytics.Channel;

namespace SubscriptionService.Persistence.Channels;

public interface IChannelDao : IMongoDao<Channel>
{
    /// <summary>
    /// Updates the status and mail status of a channel.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="status"></param>
    /// <param name="hasError"></param>
    /// <returns></returns>
    public Task<UpdateResult> UpdateStatusAndMailStatusAsync(string id, ChannelStatus status, bool hasError);
}