using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;
using SubscriptionService.Exceptions;

namespace SubscriptionService.Persistence.Settings;

public class SubscriptionSettingsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<SubscriptionSetting>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("SubscriptionSettings"),
    mongoDatabase), ISubscriptionSettingsDao
{
    public async Task<SubscriptionSetting> GetSettingsByTypeAsync(SubscriptionType subscriptionType)
    {
        var filter = Filter.Eq(f => f.SubscriptionType, subscriptionType);
        var items = await GetListAsync(filter);
        return items.FirstOrDefault() ?? throw new SettingsNotFoundException(subscriptionType);
    }

    public override UpdateDefinition<SubscriptionSetting> GetUpdateDefinition(SubscriptionSetting? setting)
    {
        if (setting == null)
            return base.GetUpdateDefinition(setting);

        return Builders<SubscriptionSetting>.Update.Combine(
            new List<UpdateDefinition<SubscriptionSetting>>
            {
                Builders<SubscriptionSetting>.Update.Set(dbItem => dbItem.Split, setting.Split),
                Builders<SubscriptionSetting>.Update.Set(dbItem => dbItem.Fields, setting.Fields),
                base.GetUpdateDefinition(setting)
            });
    }
}