using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Persistence;

namespace SubscriptionService.Persistence.Settings;

public interface ISubscriptionSettingsDao : IMongoDao<SubscriptionSetting>
{
    /// <summary>
    /// Gets the subscription settings for the subscription type.
    /// </summary>
    /// <param name="subscriptionType"></param>
    /// <returns>SubscriptionSetting</returns>
    public Task<SubscriptionSetting> GetSettingsByTypeAsync(SubscriptionType subscriptionType);
}