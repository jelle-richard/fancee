using CronService.Jobs;
using SocialListeningCore;
using SocialListeningCore.Logging;
using SocialListeningCore.Persistence.DeploymentEnvironments;
using SocialListeningCore.Services.DeploymentEnvironments;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    UseAuthenticationAndAuthorization = false
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddScheduler(sb =>
    {
        sb.Services.AddStartupJob<InitEnvironmentJob>();

        _ = sb.AddUnobservedTaskExceptionHandler(sp =>
        {
            var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger(MongoLogger.Name);
            return
                (sender, args) =>
                {
                    logger.MongoLogException(null, args.Exception);
                    args.SetObserved();
                };
        });
    });
};

builder.AddDependency<IDeploymentEnvironmentDao, DeploymentEnvironmentDao>(ServiceLifetime.Scoped);
builder.AddDependency<IDeploymentEnvironmentService, DeploymentEnvironmentService>(ServiceLifetime.Scoped);

var app = builder.Build();
await app.RunStartupJobsAync();
app.Run();