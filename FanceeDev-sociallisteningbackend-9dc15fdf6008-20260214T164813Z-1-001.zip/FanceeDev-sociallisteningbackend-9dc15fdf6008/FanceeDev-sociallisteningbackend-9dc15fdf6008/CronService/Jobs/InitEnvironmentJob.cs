using CronScheduler.Extensions.StartupInitializer;
using SocialListeningCore.Services.DeploymentEnvironments;

namespace CronService.Jobs;

/// <summary>
/// Seeds MongoDb with environment variables.
/// </summary>
public class InitEnvironmentJob(
    ILogger<InitEnvironmentJob> logger,
    IDeploymentEnvironmentService deploymentEnvironmentService) : IStartupJob
{
    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        logger.LogInformation("{job} started", nameof(InitEnvironmentJob));

        if (await deploymentEnvironmentService.AnyAsync())
            return;

        _ = await deploymentEnvironmentService.CreateAsync(new()
        {
            Domain = "localhost",
            Name = "localhost",
            Port = 8080,
            FrontendBaseUrl = "http://localhost:8080"
        });

        _ = await deploymentEnvironmentService.CreateAsync(new()
        {
            Domain = "staging.fanc.ee",
            FrontendBaseUrl = "https://staging.fanc.ee",
            Name = "Staging"
        });

        logger.LogInformation("{job} ended", nameof(InitEnvironmentJob));
    }
}