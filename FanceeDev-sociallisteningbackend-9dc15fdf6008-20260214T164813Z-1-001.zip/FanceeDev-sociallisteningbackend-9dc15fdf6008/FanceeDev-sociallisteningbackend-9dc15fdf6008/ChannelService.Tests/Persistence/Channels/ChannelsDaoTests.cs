using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using ChannelService.Persistence.Channels;
using ChannelService.TestData;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using SocialListeningCore.Exceptions;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Persistence.Channels;

public class ChannelsDaoTests
{
    private const string ChannelId = "channelId";
    public readonly Mock<IAsyncCursor<Channel>> Cursor = new();
    private readonly Guid _userId = new();
    private readonly IChannelsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public ChannelsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new ChannelsDao(configuration, _mongoDatabase.Object);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsModelWhenCalledByAdmin()
    {
        var mockedChannel = ChannelsFactory.GetMockedChannels();
        _mongoDatabase.Mock(mockedChannel);

        var actual = await _sut.ByIdAsync(ChannelId);

        Assert.Equal(mockedChannel.First(), actual);
    }

    [Fact]
    public async Task TestThatHasErrorListAsyncReturnsChannelsWithError()
    {
        var mockedChannels = ChannelsFactory.GetMockedChannels();
        var mockedCollection = _mongoDatabase.MockCollection(new[] { mockedChannels[2], mockedChannels[3] });
        mockedCollection.SetupSequence(x => x.FindAsync(
            It.IsAny<FilterDefinition<Channel>>(),
            It.IsAny<FindOptions<Channel>>(),
            It.IsAny<CancellationToken>())
        ).ReturnsAsync(Cursor.Object);

        _mongoDatabase.Setup(md => md.GetCollection<Channel>(It.IsAny<string>(), null))
            .Returns(mockedCollection.Object);

        mockedChannels = [mockedChannels[2], mockedChannels[3]];

        Cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        Cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
        Cursor.Setup(c => c.Current)
            .Returns(mockedChannels);

        var actual = await _sut.HasErrorListAsync(ChannelStatus.Expired);

        Assert.Equal(mockedChannels.First(), actual.First());
    }

    [Fact]
    public async Task TestThatUpdateErrorStateAsyncReturnsSuccessfulUpdateResult()
    {
        var expected = new UpdateResult.Acknowledged(1, 1, null);
        var mockedCollection = _mongoDatabase.MockCollection<Channel>();
        mockedCollection.Setup(mc => mc.UpdateOneAsync(
            It.IsAny<FilterDefinition<Channel>>(),
            It.IsAny<UpdateDefinition<Channel>>(),
            It.IsAny<UpdateOptions>(),
            It.IsAny<CancellationToken>())).ReturnsAsync(expected);

        var actual = await _sut.UpdateErrorStateAsync(ChannelId, true);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncThrowsChannelNotFoundExceptionWhenChannelNotFoundCalledByAdmin()
    {
        _mongoDatabase.Mock(Array.Empty<Channel>());
        await Assert.ThrowsAsync<ChannelNotFoundException>(async () => await _sut.ByIdAsync(ChannelId));
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsModelWhenCalledByOrganizer()
    {
        var mockedChannels = ChannelsFactory.GetMockedChannels();
        _mongoDatabase.Mock(mockedChannels);

        var actual = await _sut.ByIdAsync(ChannelId, _userId);

        Assert.Equal(mockedChannels.First(), actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncThrowsChannelNotFoundExceptionWhenChannelNotFoundCalledByOrganizer()
    {
        _mongoDatabase.Mock(Array.Empty<Channel>());
        await Assert.ThrowsAsync<ChannelNotFoundException>(async () => await _sut.ByIdAsync(ChannelId, _userId));
    }

    [Fact]
    public async Task TestThatToListAsyncReturnsListCalledByOrganizer()
    {
        var mockedChannels = ChannelsFactory.GetMockedChannels();
        _mongoDatabase.Mock(mockedChannels);

        var actual = await _sut.ToListAsync(_userId);

        Assert.Equal(mockedChannels, actual);
    }

    [Fact]
    public async Task TestThatToListAsyncReturnsListCalledByAdmin()
    {
        var mockedChannels = ChannelsFactory.GetMockedChannels();
        _mongoDatabase.Mock(mockedChannels);

        var actual = await _sut.ToListAsync();

        Assert.Equal(mockedChannels, actual);
    }

    [Fact]
    public async Task TestThatUpdateAsyncReturnsModelWhenSuccessful()
    {
        var mockedChannels = ChannelsFactory.GetMockedChannels();
        var mockedCollection = _mongoDatabase.MockCollection(mockedChannels);

        mockedCollection
            .SetupSequence(x => x.FindOneAndUpdateAsync(
                It.IsAny<FilterDefinition<Channel>>(),
                It.IsAny<UpdateDefinition<Channel>>(),
                It.IsAny<FindOneAndUpdateOptions<Channel>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(mockedChannels.First());

        var actual = await _sut.UpdateAsync(mockedChannels.First());

        Assert.Equal(mockedChannels.First(), actual);
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinitionWhenSuccessful()
    {
        var channel = ChannelsFactory.GetMockedChannels();

        Assert.NotNull(_sut.GetUpdateDefinition(channel.First()));
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinitionWhenModelIsNull()
    {
        Assert.NotNull(_sut.GetUpdateDefinition(null));
    }

    [Fact]
    public async Task TestThatToPaginatedListAsyncReturnsSetWhenSuccessful()
    {
        var userChannelResponses = ChannelsFactory.GetMockedUserChannels();
        var mockResult = new[] { new ResultSetResponse<UserChannelResponse>(userChannelResponses) };
        _mongoDatabase.MockPagination<Channel, UserChannelResponse>(mockResult);

        var actual = await _sut.ToPaginatedListAsync(10, 0, _userId);

        Assert.Equal(userChannelResponses.Length, actual.TotalItems);
        Assert.Equal(userChannelResponses, actual.Items);
    }

    [Theory]
    [InlineData(true, true)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(false, false)]
    public async Task TestThatToPaginatedTableAsyncReturnsSetWhenSuccessful(bool ascending, bool forUser)
    {
        var userChannelResponses = ChannelsFactory.GetMockedChannels();
        var mockResult = new[] { new ResultSetResponse<Channel>(userChannelResponses) };
        _mongoDatabase.MockPagination<Channel, Channel>(mockResult);

        var actual = await _sut.ToPaginatedTableAsync(10, 0, ChannelsTableField.Name, ascending, forUser ? _userId : null);

        Assert.Equal(userChannelResponses.Length, actual.TotalItems);
        Assert.Equal(userChannelResponses, actual.Items);
    }
}