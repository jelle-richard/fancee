using ChannelService.Persistence.ChannelSettings;
using FanceeAnalyticsData.Models.Analytics;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Persistence.Channels;

public class ChannelSettingsDaoTests
{
    private const string ChannelId = "channelId";
    private readonly IChannelSettingsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();

    public ChannelSettingsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new ChannelSettingsDao(configuration, _mongoDatabase.Object);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsModelWhenCalledByOrganizer()
    {
        var expected = new ChannelSettings();
        _mongoDatabase.Mock(new[] { expected });

        var actual = await _sut.ByChannelIdAsync(ChannelId);

        Assert.Equal(expected, actual);
    }
}