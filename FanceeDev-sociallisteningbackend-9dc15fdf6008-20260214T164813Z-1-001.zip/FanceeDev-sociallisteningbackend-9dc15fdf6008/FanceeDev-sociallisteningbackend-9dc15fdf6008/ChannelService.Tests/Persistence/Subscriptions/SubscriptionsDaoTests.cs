using ChannelService.Persistence.Subscriptions;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Persistence.Subscriptions;

public class SubscriptionsDaoTests
{
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();
    public readonly Mock<IAsyncCursor<Subscription>> Cursor = new();
    private readonly ISubscriptionsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<IMongoCollection<Subscription>> _mockedCollection = new();

    public SubscriptionsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new SubscriptionsDao(configuration, _mongoDatabase.Object);

        _mongoDatabase
            .Setup(x => x.GetCollection<Subscription>(
                It.IsAny<string>(), null))
            .Returns(_mockedCollection.Object);

        _mockedCollection
            .Setup(x => x.FindAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Cursor.Object);

        Cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        Cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncReturnsListOfModelsWhenSuccessful()
    {
        var channelId = string.Empty;
        Subscription model = new()
        {
            Id = SubscriptionId,
            Cron = "* * * * *",
            RunOnce = false,
            Input = SubscriptionType.GT.ToInput()
        };

        List<Subscription> asList = [model, model];

        Subscription[] asArray = [model, model];

        Cursor.Setup(x => x.Current).Returns(asArray);

        var actual = await _sut.ToListByChannelIdAsync(channelId);

        Assert.Equal(asList, actual);
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncThrowsSubscriptionNotFoundExceptionWhenListIsEmpty()
    {
        var channelId = string.Empty;

        Cursor.Setup(x => x.Current).Returns(Array.Empty<Subscription>());

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(async () => await _sut.ToListByChannelIdAsync(channelId));
    }
}