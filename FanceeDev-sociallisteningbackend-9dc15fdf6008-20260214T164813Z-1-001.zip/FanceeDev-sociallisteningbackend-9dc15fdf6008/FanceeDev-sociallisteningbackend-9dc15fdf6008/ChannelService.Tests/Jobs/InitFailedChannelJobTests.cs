using ChannelService.Jobs;
using ChannelService.Services.Channels;
using Microsoft.Extensions.Logging;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Jobs;

public class InitFailedChannelJobTests
{
    private const string Name = nameof(InitFailedChannelJob);
    private readonly Mock<IChannelsService> _mockedChannelsService = new();
    private readonly Mock<ILogger<InitFailedChannelJob>> _mockedLogger = new();

    [Fact]
    public async Task TestThatExecuteAsyncStartsJobWhenSuccessful()
    {
        var sut = new InitFailedChannelJob(_mockedChannelsService.Object, _mockedLogger.Object);

        await sut.ExecuteAsync(CancellationToken.None);

        _mockedLogger.VerifyLogging(
            $"{Name} started",
            LogLevel.Information,
            Times.Exactly(1));
        _mockedLogger.VerifyLogging(
            $"{Name} ended",
            LogLevel.Information,
            Times.Exactly(1));
        _mockedChannelsService.Verify(cs => cs.AddOrUpdateFailedChannelJobAsync(), Times.Once);
    }
}