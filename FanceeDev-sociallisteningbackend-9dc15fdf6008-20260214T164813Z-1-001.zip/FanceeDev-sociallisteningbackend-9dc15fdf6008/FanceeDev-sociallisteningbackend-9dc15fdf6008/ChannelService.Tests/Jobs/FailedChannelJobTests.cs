using ChannelService.Jobs;
using ChannelService.Services.Channels;
using CronScheduler.Extensions.Scheduler;
using Microsoft.Extensions.Logging;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Jobs;

public class FailedChannelJobTests
{
    private const string Name = nameof(FailedChannelJob);
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<IChannelsService> _mockedChannelsService = new();
    private readonly Mock<ILogger<FailedChannelJob>> _mockedLogger = new();

    private readonly SchedulerOptions _mockedCronSchedule = new()
    {
        CronSchedule = "* * * * *"
    };

    public FailedChannelJobTests()
    {
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IChannelsService)))
            .Returns(_mockedChannelsService.Object);
    }

    [Fact]
    public async Task TestThatExecuteAsyncStartsJobWhenSuccessful()
    {
        var sut = new FailedChannelJob(_mockedServiceProvider.Object, _mockedCronSchedule, _mockedLogger.Object);

        await sut.ExecuteAsync(CancellationToken.None);

        _mockedLogger.VerifyLogging(
            $"{_mockedCronSchedule.CronSchedule} - {Name} started",
            LogLevel.Information,
            Times.Exactly(1));
        _mockedLogger.VerifyLogging(
            $"{_mockedCronSchedule.CronSchedule} - {Name} ended",
            LogLevel.Information,
            Times.Exactly(1));
        _mockedChannelsService.Verify(cs => cs.SendFailedChannelConnectionMailsAsync(), Times.Once);
    }
}