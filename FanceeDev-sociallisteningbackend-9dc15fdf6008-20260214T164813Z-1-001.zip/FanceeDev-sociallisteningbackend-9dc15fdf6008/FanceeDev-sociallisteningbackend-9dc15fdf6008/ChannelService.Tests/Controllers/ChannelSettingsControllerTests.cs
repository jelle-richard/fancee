using ChannelService.Controllers;
using ChannelService.Services.ChannelSettings;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Responses;

namespace ChannelService.Tests.Controllers;

public class ChannelsSettingsControllerTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();

    private readonly ChannelSettingsController _sut;
    private readonly Mock<IChannelSettingsService> _mockedChannelSettingsService = new();

    public ChannelsSettingsControllerTests()
    {
        _sut = new(_mockedChannelSettingsService.Object);
    }

    [Fact]
    public async Task TestThatSingleGetWorks()
    {
        var expected = new ChannelSettings();
        _mockedChannelSettingsService.Setup(css => css.ByChannelIdAsync(It.IsNotNull<string>())).ReturnsAsync(expected);

        var single = await _sut.Single(ChannelId);

        var actualResult = Assert.IsType<OkObjectResult>(single.Result);
        var response = Assert.IsType<ApiResponse<ChannelSettings>>(actualResult.Value);
        var actual = Assert.IsType<ChannelSettings>(response.Data);

        Assert.Equal(expected, actual);
    }
}