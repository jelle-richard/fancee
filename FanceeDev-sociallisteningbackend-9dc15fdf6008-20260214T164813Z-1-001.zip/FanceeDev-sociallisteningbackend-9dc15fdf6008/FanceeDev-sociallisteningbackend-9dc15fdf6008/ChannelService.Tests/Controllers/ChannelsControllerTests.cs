using System.Security.Claims;
using ChannelService.Controllers;
using ChannelService.Dtos.Requests.Channels;
using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using ChannelService.Helpers;
using ChannelService.Services.Channels;
using ChannelService.Services.Subscriptions;
using ChannelService.TestData;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Logging;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Controllers;

public class ChannelsControllerTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();

    private static readonly Guid OrganizerUserId = Guid.NewGuid();
    private static readonly User UserOrganizer = new() { FanceeUsersId = OrganizerUserId, UserId = OrganizerUserId, Type = UserType.Organization };
    private static readonly Guid AdminUserId = Guid.NewGuid();
    private static readonly User UserAdmin = new() { FanceeUsersId = AdminUserId, UserId = AdminUserId, Type = UserType.Admin };

    private readonly ChannelsController _sut;
    private readonly Mock<IChannelsService> _mockedChannelsService = new();
    private readonly Mock<ISubscriptionsService> _mockedSubscriptionsService = new();
    private readonly LoggerFactory _factory = new();
    private readonly Mock<IMongoCollection<Log>> _mockedMongoCollection = new();

    public ChannelsControllerTests()
    {
        _factory.AddProvider(new MongoLoggerProvider(new(string.Empty, _mockedMongoCollection.MockLogClient().Object)));

        _sut = new(_mockedChannelsService.Object, _mockedSubscriptionsService.Object,
            _factory)
        {
            ControllerContext =
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new(new ClaimsIdentity(new[]
                    {
                        new Claim("user", UserOrganizer.FanceeUsersId.ToString()),
                        new Claim("platformUserId", UserOrganizer.UserId.ToString()),
                        new Claim("type", UserType.Organization.ToString())
                    }))
                }
            }
        };
    }

    [Fact]
    public async Task TestThatListCallsChannelsServiceToListAsync()
    {
        var mockedPaginatedResult = new ResultSetResponse<UserChannelResponse>(ChannelsFactory.GetMockedUserChannels());

        _mockedChannelsService
            .Setup(cs => cs.ToListAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<int>()))
            .ReturnsAsync(mockedPaginatedResult);

        var request = new PaginatedRequest<SearchQueryFilter>();
        var actual = await _sut.List(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelsService.Verify(
            cs => cs.ToListAsync(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<int>()), Times.Once);
    }

    [Fact]
    public async Task TestThatListCallsChannelsServiceToListAsyncWithAdminRole()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var mockedPaginatedResult = new ResultSetResponse<UserChannelResponse>(ChannelsFactory.GetMockedUserChannels());

        _mockedChannelsService
            .Setup(cs => cs.ToListAsync(It.IsAny<int>(), It.IsAny<int>()))
            .ReturnsAsync(mockedPaginatedResult);

        var request = new PaginatedRequest<SearchQueryFilter> { Page = 1, PageSize = 10 };
        var actual = await _sut.List(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelsService.Verify(
            cs => cs.ToListAsync(It.IsAny<int>(), It.IsAny<int>()), Times.Once);
    }

    [Fact]
    public async Task TestThatTableQueryForAdminCallsChannelsServiceAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var mockedPaginatedResult = new ResultSetResponse<Channel>(ChannelsFactory.GetMockedChannels());
        var request = new PaginatedRequest<QueryFilter<ChannelsTableField>>()
        {
            Options = new() { OrderBy = ChannelsTableField.Name, OrderByAscending = true },
            Page = 0,
            PageSize = 20
        };

        _mockedChannelsService
            .Setup(cs => cs.ChannelsAsync(request.Options, It.IsAny<int>(), It.IsAny<int>()))
            .ReturnsAsync(mockedPaginatedResult);

        var actual = await _sut.TableQuery(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelsService.Verify(
            cs => cs.ChannelsAsync(It.IsAny<QueryFilter<ChannelsTableField>>(), It.IsAny<int>(), It.IsAny<int>()), Times.Once);
    }

    [Fact]
    public async Task TestThatTableQueryForOrganiozrersCallsChannelsServiceAsync()
    {
        _sut.ControllerContext.SetUser(UserOrganizer);

        var mockedPaginatedResult = new ResultSetResponse<Channel>(ChannelsFactory.GetMockedChannels());
        var request = new PaginatedRequest<QueryFilter<ChannelsTableField>>()
        {
            Options = new() { OrderBy = ChannelsTableField.Name, OrderByAscending = true },
            Page = 0,
            PageSize = 20
        };

        _mockedChannelsService
            .Setup(cs => cs.ChannelsAsync(UserOrganizer.UserId, request.Options, It.IsAny<int>(), It.IsAny<int>()))
            .ReturnsAsync(mockedPaginatedResult);

        var actual = await _sut.TableQuery(request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelsService.Verify(
            cs => cs.ChannelsAsync(It.IsAny<Guid>(), It.IsAny<QueryFilter<ChannelsTableField>>(), It.IsAny<int>(), It.IsAny<int>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSingleCallsChannelsServiceByIdAsync()
    {
        var mockedChannelResponse = new UserChannelResponse(ChannelsFactory.GetMockedChannels().First(), null);
        var id = ObjectId.GenerateNewId().ToString();

        _mockedChannelsService.Setup(cs => cs.ByIdAsync(id, UserOrganizer.FanceeUsersId))
            .ReturnsAsync(mockedChannelResponse);

        var actual = await _sut.Single(id);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelsService.Verify(cs => cs.ByIdAsync(id, UserOrganizer.FanceeUsersId), Times.Once);
    }

    [Fact]
    public async Task TestThatSingleCallsChannelsServiceByIdAsyncCalledByAdmin()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var mockedChannel = new UserChannelResponse(ChannelsFactory.GetMockedChannels().First(), null);
        var id = ObjectId.GenerateNewId().ToString();

        _mockedChannelsService.Setup(cs => cs.ByIdAsync(id))
            .ReturnsAsync(mockedChannel);

        var actual = await _sut.Single(id);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedChannelsService.Verify(cs => cs.ByIdAsync(id), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateCallsChannelsServiceCreateAsync()
    {
        var request = new CreateSuperMetricsChannelRequest
        {
            PlatformUserId = UserOrganizer.FanceeUsersId,
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel",
            AccountsId = "myAccountId",
            UserId = "myUserId",
            Owner = new()
        };

        var mockedCreatedChannel = ChannelsFactory.GetMockedChannels().First();

        _mockedSubscriptionsService.Setup(ss => ss.CreateAsync(It.IsAny<CreateSubscriptionRequest>()))
            .ReturnsAsync(new Subscription { Id = SubscriptionId });

        _mockedChannelsService.Setup(cs => cs.CreateAsync(request, UserOrganizer.FanceeUsersId))
            .ReturnsAsync(mockedCreatedChannel);

        var actual = await _sut.CreateSuperMetricsChannel(request);

        Assert.IsType<CreatedResult>(actual.Result);

        _mockedChannelsService.Verify(cs => cs.CreateAsync(request, UserOrganizer.FanceeUsersId), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateAsyncCreatesChannelForOtherUserWhenUserIsAdmin()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var channelOwner = new ChannelOwner()
        {
            Email = "test@email.nl",
            FirstName = "First",
            LastName = "Last",
            OrganizationId = "1",
            OrganizationName = "OrgName"
        };
        var request = new CreateSuperMetricsChannelRequest
        {
            PlatformUserId = UserOrganizer.UserId,
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel",
            AccountsId = "myAccountId",
            UserId = "myUserId",
            Owner = channelOwner
        };

        var mockedCreatedChannel = ChannelsFactory.GetMockedChannels().First();
        mockedCreatedChannel.Owner = channelOwner;

        _mockedSubscriptionsService.Setup(ss => ss.CreateAsync(It.IsAny<CreateSubscriptionRequest>()))
            .ReturnsAsync(new Subscription { Id = SubscriptionId });

        _mockedChannelsService.Setup(cs => cs.CreateAsync(request, UserOrganizer.UserId))
            .ReturnsAsync(mockedCreatedChannel);

        var actual = await _sut.CreateSuperMetricsChannel(request);
        var createdResult = Assert.IsType<CreatedResult>(actual.Result);
        var apiResponse = Assert.IsType<ApiResponse<CreateChannelResponse>>(createdResult.Value);

        Assert.Equal(request.Owner, apiResponse.Data?.Channel?.Owner);

        _mockedChannelsService.Verify(cs => cs.CreateAsync(request, UserOrganizer.UserId), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatCreateAsyncThrowsMissingPermissionExceptionWhenUserIsNotAdmin()
    {
        var request = new CreateSuperMetricsChannelRequest
        {
            PlatformUserId = UserAdmin.UserId,
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel",
            AccountsId = "myAccountId",
            UserId = "myUserId",
            Owner = new()
        };

        await Assert.ThrowsAsync<MissingPermissionException>(async () => await _sut.CreateSuperMetricsChannel(request));
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task TestThatUpdateCallsChannelsServiceUpdateAsyncCalledByAdmin(bool containsData)
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var id = ObjectId.GenerateNewId().ToString();
        var request = new UpdateChannelRequest();
        if (containsData)
            request.Name = "newName";

        var mockedUpdatedChannel = ChannelsFactory.GetMockedChannels().First();
        mockedUpdatedChannel.Name = containsData ? request.Name : "oldName";

        _mockedChannelsService.Setup(cs => cs.UpdateAsync(id, request))
            .ReturnsAsync(mockedUpdatedChannel);

        var actual = await _sut.Update(id, request);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<Channel>>(actualResult.Value);
        var actualChannel = Assert.IsType<Channel>(response.Data);

        Assert.Equal(mockedUpdatedChannel.Name, actualChannel.Name);
        _mockedChannelsService.Verify(cs => cs.UpdateAsync(id, request), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task TestThatUpdateCallsChannelsServiceUpdateAsync(bool containsData)
    {
        var id = ObjectId.GenerateNewId().ToString();
        var request = new UpdateChannelRequest();
        if (containsData)
            request.Name = "newName";

        var mockedUpdatedChannel = ChannelsFactory.GetMockedChannels().First();
        mockedUpdatedChannel.Name = containsData ? request.Name : "oldName";

        _mockedChannelsService.Setup(cs => cs.UpdateAsync(id, request, UserOrganizer.FanceeUsersId))
            .ReturnsAsync(mockedUpdatedChannel);

        var actual = await _sut.Update(id, request);

        var actualResult = Assert.IsType<OkObjectResult>(actual.Result);
        var response = Assert.IsType<ApiResponse<Channel>>(actualResult.Value);
        var actualChannel = Assert.IsType<Channel>(response.Data);

        Assert.Equal(mockedUpdatedChannel.Name, actualChannel.Name);
        _mockedChannelsService.Verify(cs => cs.UpdateAsync(id, request, UserOrganizer.FanceeUsersId), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatDeleteCallsChannelsServiceDeleteAsync()
    {
        var channelDeleted = new UserChannelResponse
        {
            Id = ChannelId,
            ChannelType = ChannelType.FACEBOOK,
            Name = "MyChannel"
        };
        _mockedChannelsService.Setup(ss => ss.ByIdAsync(ChannelId, It.IsAny<Guid>()))
            .ReturnsAsync(channelDeleted);

        _mockedSubscriptionsService.Setup(ss => ss.ToListByChannelIdAsync(ChannelId))
            .ReturnsAsync(new Subscription[]
            {
                new()
                {
                    Id = SubscriptionId,
                    Cron = "* * * * *",
                    Input = SubscriptionType.FB_POSTS.ToInput(),
                    SubscriptionType = SubscriptionType.FB_POSTS,
                    RunOnce = false
                },
                new()
                {
                    Id = SubscriptionId,
                    Cron = "* * * * *",
                    Input = SubscriptionType.FB_POSTS.ToInput(),
                    SubscriptionType = SubscriptionType.FB_POSTS,
                    RunOnce = false
                }
            });

        _mockedSubscriptionsService.Setup(ss => ss.DeleteByIdAsync(SubscriptionId))
            .ReturnsAsync(true);

        _mockedChannelsService.Setup(cs => cs.DeleteAsync(ChannelId))
            .ReturnsAsync(true);

        var actual = await _sut.Delete(ChannelId);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedChannelsService.Verify(cs => cs.DeleteAsync(ChannelId), Times.Once);
        _mockedSubscriptionsService.Verify(ss => ss.DeleteByIdAsync(SubscriptionId), Times.AtLeast(2));

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatDeleteCallsChannelsServiceDeleteAsyncCalledByAdmin()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var channelDeleted = new UserChannelResponse
        {
            Id = ChannelId,
            ChannelType = ChannelType.FACEBOOK,
            Name = "MyChannel"
        };
        _mockedChannelsService.Setup(ss => ss.ByIdAsync(ChannelId))
            .ReturnsAsync(channelDeleted);

        _mockedSubscriptionsService.Setup(ss => ss.ToListByChannelIdAsync(ChannelId))
            .ReturnsAsync(new Subscription[]
            {
                new()
                {
                    Id = SubscriptionId,
                    Cron = "* * * * *",
                    Input = SubscriptionType.FB_POSTS.ToInput(),
                    SubscriptionType = SubscriptionType.FB_POSTS,
                    RunOnce = false
                },
                new()
                {
                    Id = SubscriptionId,
                    Cron = "* * * * *",
                    Input = SubscriptionType.FB_POSTS.ToInput(),
                    SubscriptionType = SubscriptionType.FB_POSTS,
                    RunOnce = false
                }
            });

        _mockedSubscriptionsService.Setup(ss => ss.DeleteByIdAsync(SubscriptionId))
            .ReturnsAsync(true);

        _mockedChannelsService.Setup(cs => cs.DeleteAsync(ChannelId))
            .ReturnsAsync(true);

        var actual = await _sut.Delete(ChannelId);

        Assert.IsType<OkObjectResult>(actual.Result);
        _mockedChannelsService.Verify(cs => cs.ByIdAsync(ChannelId), Times.Once);
        _mockedChannelsService.Verify(cs => cs.DeleteAsync(ChannelId), Times.Once);
        _mockedSubscriptionsService.Verify(ss => ss.DeleteByIdAsync(SubscriptionId), Times.AtLeast(2));

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatDeleteThrowsChannelNotFoundExceptionWhenChannelNotFound()
    {
        _mockedChannelsService.Setup(cs => cs.ByIdAsync(
                ChannelId,
                It.IsAny<Guid>()))
            .ThrowsAsync(new ChannelNotFoundException(ChannelId));

        await Assert.ThrowsAsync<ChannelNotFoundException>(async () => await _sut.Delete(ChannelId));
    }

    [Fact]
    public async Task TestThatGetAllSubscriptionsUnderChannelReturnsSubscriptions()
    {
        _mockedSubscriptionsService.Setup(cs => cs.ToListByChannelIdAsync(It.IsAny<string>()))
            .ReturnsAsync(new List<Subscription> { new() });

        var actual = await _sut.GetAllSubscriptionsUnderChannel("channelId");

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedSubscriptionsService.Verify(cs => cs.ToListByChannelIdAsync(It.IsAny<string>()), Times.Once);
    }

    [Theory]
    [InlineData(ChannelsTableField.Name)]
    [InlineData(ChannelsTableField.Type)]
    [InlineData(ChannelsTableField.User)]
    [InlineData(ChannelsTableField.Organization)]
    [InlineData(ChannelsTableField.Owner)]
    [InlineData(ChannelsTableField.Email)]
    [InlineData(ChannelsTableField.Status)]
    [InlineData(ChannelsTableField.CreatedOn)]
    public void TestThatChannelsTableFieldToFieldIdWorksForEveryType(ChannelsTableField tableField) => Assert.IsType<string>(tableField.ToFieldId());

    [Fact]
    public void TestThatChannelsTableThrowsExceptionWhenInvalid() => Assert.Throws<NotSupportedException>(() => ((ChannelsTableField)(-1)).ToFieldId());
     
}