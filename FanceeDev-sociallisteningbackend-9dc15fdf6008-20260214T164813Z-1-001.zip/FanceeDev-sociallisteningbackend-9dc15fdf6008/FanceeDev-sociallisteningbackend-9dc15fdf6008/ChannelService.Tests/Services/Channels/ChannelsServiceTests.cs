using ChannelService.Dtos.Requests.Channels;
using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using ChannelService.Persistence.Channels;
using ChannelService.Services.Channels;
using ChannelService.TestData;
using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using MailTemplates.Models;
using MailTemplates.Templates;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.Environment;
using SocialListeningCore.Dtos.MailProvider;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Persistence.Users;
using SocialListeningCore.Services.DeploymentEnvironments;
using SocialListeningCore.Services.Mailer;
using TestCore.Utils.UnitTestsHelpers;
using ViewRenderer;

namespace ChannelService.Tests.Services.Channels;

public class ChannelsServiceTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();

    private static readonly IEnumerable<Channel> ExpiredChannels =
    [
        new()
        {
            Id = "ChannelId1",
            CreatedOn = default,
            UpdatedOn = default,
            ChannelType = ChannelType.FACEBOOK,
            Status = ChannelStatus.Expired,
            HasError = true,
            Name = "Channel1",
            Owner = new()
            {
                OrganizationId = "OrgId",
                OrganizationName = "OrgName",
                FirstName = "Unit",
                LastName = "Testing",
                Email = "unit@test.company.com"
            }
        }
    ];

    private static readonly IEnumerable<Channel> ErrorChannels =
    [
        new()
        {
            Id = "ChannelId1",
            CreatedOn = default,
            UpdatedOn = default,
            ChannelType = ChannelType.FACEBOOK,
            Status = ChannelStatus.Error,
            HasError = true,
            Name = "Channel1",
            Owner = new()
            {
                OrganizationId = "OrgId",
                OrganizationName = "OrgName",
                FirstName = "Unit",
                LastName = "Testing",
                Email = "unit@test.company.com"
            }
        }
    ];

    private readonly Guid _userId = Guid.NewGuid();
    private readonly ChannelsService _sut;
    private readonly Mock<IChannelsDao> _mockedChannelsDao = new();
    private readonly Mock<IUserDao> _mockedUserDao = new();
    private readonly Mock<IViewRenderer> _mockedViewRenderer = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ILoggerFactory> _mockedLoggerFactory = new();
    private readonly Mock<ISchedulerRegistration> _mockedSchedulerRegistration = new();
    private readonly Mock<ILogger> _mockedLogger = new();
    private readonly Mock<IMailer> _mockedMailer = new();

    private readonly IEnumerable<UserChannelResponse> _mockedUserChannels = ChannelsFactory.GetMockedUserChannels();

    public ChannelsServiceTests()
    {
        var mockedScopeFactory = new Mock<IServiceScopeFactory>();
        var mockedServiceScope = new Mock<IServiceScope>();

        mockedServiceScope.Setup(ss => ss.ServiceProvider)
            .Returns(_mockedServiceProvider.Object);

        mockedScopeFactory.Setup(sf => sf.CreateScope())
            .Returns(mockedServiceScope.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory)))
            .Returns(mockedScopeFactory.Object);

        _mockedLoggerFactory.Setup(lf => lf.CreateLogger(It.IsAny<string>())).Returns(_mockedLogger.Object);

        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformName", "Fancee" },
            { "OrganizationDetails:SupportEmail", "info@wearefancee.com" }
        });
        _sut = new(
            _mockedChannelsDao.Object,
            _mockedUserDao.Object,
            _mockedViewRenderer.Object,
            _mockedDeploymentEnvironmentService.Object,
            mockedConfiguration,
            _mockedServiceProvider.Object,
            _mockedLoggerFactory.Object,
            _mockedSchedulerRegistration.Object,
            _mockedMailer.Object
        );
    }

    [Fact]
    public async Task TestThatToListAsyncCallsChannelsDaoToListAsyncWithUserId()
    {
        var response = new ResultSetResponse<UserChannelResponse>(_mockedUserChannels);

        _mockedChannelsDao.Setup(cs => cs.ToPaginatedListAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<Guid>()))
            .ReturnsAsync(response);

        var actual = await _sut.ToListAsync(_userId, 5);

        Assert.NotEmpty(actual.Items);
        Assert.Equal(_mockedUserChannels.First(), actual.Items.First());
    }

    [Fact]
    public async Task TestThatChannelsAsyncForAdminsCallsChannelsDaoToListAsyncWithUserId()
    {
        var request = new QueryFilter<ChannelsTableField> { OrderBy = ChannelsTableField.Name, OrderByAscending = true };
        var response = new ResultSetResponse<Channel>(_mockedUserChannels);

        _mockedChannelsDao.Setup(cs => cs.ToPaginatedTableAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<ChannelsTableField>(), It.IsAny<bool>(), null))
            .ReturnsAsync(response);

        var actual = await _sut.ChannelsAsync(request, 10);

        Assert.NotEmpty(actual.Items);
        Assert.Equal(_mockedUserChannels.First(), actual.Items.First());
    }

    [Fact]
    public async Task TestThatChannelsAsyncForUsersCallsChannelsDaoToListAsyncWithUserId()
    {
        var request = new QueryFilter<ChannelsTableField> { OrderBy = ChannelsTableField.Name, OrderByAscending = true };
        var response = new ResultSetResponse<Channel>(_mockedUserChannels);

        _mockedChannelsDao.Setup(cs => cs.ToPaginatedTableAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<ChannelsTableField>(), It.IsAny<bool>(), It.IsAny<Guid>()))
            .ReturnsAsync(response);

        var actual = await _sut.ChannelsAsync(_userId, request, 10);

        Assert.NotEmpty(actual.Items);
        Assert.Equal(_mockedUserChannels.First(), actual.Items.First());
    }

    [Fact]
    public async Task TestThatToListAsyncCallsChannelsDaoToListAsync()
    {
        var response = new ResultSetResponse<UserChannelResponse>(_mockedUserChannels);

        _mockedChannelsDao.Setup(cs => cs.ToPaginatedListAsync(It.IsAny<int>(), It.IsAny<int>(), null))
            .ReturnsAsync(response);

        var actual = await _sut.ToListAsync(10);

        Assert.NotEmpty(actual.Items);
        Assert.Equal(_mockedUserChannels.First(), actual.Items.First());
    }

    [Fact]
    public async Task TestThatByIdAsyncCallsChannelsDaoByIdAsync()
    {
        var mockedChannelResponse = new UserChannelResponse(ChannelsFactory.GetMockedChannels().First(), null);
        _mockedChannelsDao.Setup(cs => cs.ByIdAsync(ChannelId, _userId))
            .ReturnsAsync(mockedChannelResponse);

        var actual = await _sut.ByIdAsync(ChannelId, _userId);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatCreateAsyncCallsCreateAsync()
    {
        var createChannelRequest = new CreateSuperMetricsChannelRequest
        {
            ChannelType = ChannelType.FACEBOOK
        };

        var channelCreated = new Channel
        {
            ChannelType = createChannelRequest.ChannelType
        };

        _mockedChannelsDao.Setup(cs => cs.CreateAsync(It.IsAny<Channel>()))
            .ReturnsAsync(channelCreated);

        var actual = await _sut.CreateAsync(createChannelRequest, _userId);

        Assert.NotNull(actual);
        Assert.IsType<Channel>(actual);
        Assert.Equal(channelCreated, actual);
        Assert.Equal(createChannelRequest.ChannelType, actual.ChannelType);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task TestThatUpdateAsyncCallsUpdateAsync(bool containsNewData)
    {
        var request = new UpdateChannelRequest();
        if (containsNewData)
            request.Name = "newName";

        var channelToUpdate = new Channel
        {
            Id = ChannelId,
            ChannelType = ChannelType.FACEBOOK,
            Name = "oldName"
        };

        var channelUpdated = new Channel
        {
            Id = ChannelId,
            ChannelType = ChannelType.FACEBOOK,
            Name = containsNewData ? request.Name : channelToUpdate.Name
        };

        _mockedChannelsDao.Setup(cs => cs.ByIdAsync(ChannelId, _userId))
            .ReturnsAsync(channelToUpdate);

        _mockedChannelsDao.Setup(cs => cs.UpdateAsync(
                It.IsAny<Channel>(),
                It.IsAny<FilterDefinition<Channel>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(channelUpdated);

        var actual = await _sut.UpdateAsync(ChannelId, request, _userId);

        Assert.NotNull(actual);
        Assert.IsType<Channel>(actual);
        Assert.Equal(channelUpdated, actual);
        Assert.Equal(channelUpdated.Name, actual.Name);
    }

    [Fact]
    public async Task TestThatUpdateAsyncThrowsChannelNotFoundExceptionWhenChannelNotFound()
    {
        var request = new UpdateChannelRequest
        {
            Name = "newName"
        };

        _mockedChannelsDao.Setup(cs => cs.ByIdAsync(
                ChannelId,
                It.IsAny<Guid>()))
            .ThrowsAsync(new ChannelNotFoundException(ChannelId));

        await Assert.ThrowsAsync<ChannelNotFoundException>(async () =>
            await _sut.UpdateAsync(ChannelId, request, _userId));
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsDeleteAsync()
    {
        var channelToDelete = new Channel
        {
            Id = ChannelId,
            ChannelType = ChannelType.FACEBOOK
        };

        _mockedChannelsDao.Setup(cs => cs.ByIdAsync(ChannelId, _userId))
            .ReturnsAsync(channelToDelete);
        _mockedChannelsDao.Setup(cs => cs.DeleteAsync(ChannelId))
            .ReturnsAsync(true);

        var actual = await _sut.DeleteAsync(ChannelId);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncReturnsFalseWhenChannelNotFound()
    {
        _mockedChannelsDao.Setup(cs => cs.DeleteAsync(ChannelId))
            .ReturnsAsync(false);

        var actual = await _sut.DeleteAsync(ChannelId);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatAddOrUpdateFailedChannelJobAsyncAddsOrUpdatesJob()
    {
        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(It.IsAny<string>(), It.IsAny<IScheduledJob>(), It.IsAny<SchedulerOptions>()))
            .Returns(true);

        await _sut.AddOrUpdateFailedChannelJobAsync();

        _mockedLogger.VerifyLogging(
            "Started job: FailedChannelJob",
            LogLevel.Information,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatAddOrUpdateFailedChannelJobAsyncFailsJob()
    {
        _mockedSchedulerRegistration.Setup(sr => sr.AddOrUpdate(It.IsAny<string>(), It.IsAny<IScheduledJob>(), It.IsAny<SchedulerOptions>()))
            .Returns(false);

        await _sut.AddOrUpdateFailedChannelJobAsync();

        _mockedLogger.VerifyLogging(
            "Failed to start job: FailedChannelJob",
            LogLevel.Warning,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatByIdAsyncOverloadThrowsChannelNotFoundException()
    {
        _mockedChannelsDao.Setup(cd => cd.ByIdAsync(It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<ChannelNotFoundException>(() => _sut.ByIdAsync(ChannelId, _userId));
    }

    [Fact]
    public async Task TestThatByIdAsyncThrowsChannelNotFoundException()
    {
        _mockedChannelsDao.Setup(cd => cd.ByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<ChannelNotFoundException>(() => _sut.ByIdAsync(ChannelId));
    }

    [Fact]
    public async Task TestThatSendFailedChannelConnectionMailsAsyncCallsUnderlyingMethodsSuccessfully()
    {
        _mockedChannelsDao.Setup(cd => cd.HasErrorListAsync(ChannelStatus.Expired))
            .ReturnsAsync(ExpiredChannels);
        _mockedChannelsDao.Setup(cd => cd.HasErrorListAsync(ChannelStatus.Error))
            .ReturnsAsync(ErrorChannels);
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(new HostedDeploymentEnvironment
            {
                Id = "DeploymentId",
                CreatedOn = default,
                UpdatedOn = default,
                Name = "Testing",
                FrontendBaseUrl = "FrontendBaseUrl",
                IsHttps = false,
                RemoteIpAddress = null,
                Domain = "Domain.com"
            });

        _mockedViewRenderer.Setup(vr => vr.RenderViewAsync(Templates.SuperMetricsErrorInChannelNotice, It.IsAny<MailModel>()))
            .ReturnsAsync("I am an email content string :)");
        _mockedViewRenderer.Setup(vr => vr.RenderViewAsync(Templates.SuperMetricsLostConnectionNotice, It.IsAny<MailModel>()))
            .ReturnsAsync("I am an email content string :)");

        await _sut.SendFailedChannelConnectionMailsAsync();

        _mockedChannelsDao.Verify(cd => cd.HasErrorListAsync(ChannelStatus.Expired), Times.Exactly(1));
        _mockedChannelsDao.Verify(cd => cd.HasErrorListAsync(ChannelStatus.Error), Times.Exactly(1));
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Exactly(1));

        _mockedViewRenderer.Verify(vr => vr.RenderViewAsync(Templates.SuperMetricsErrorInChannelNotice, It.IsAny<MailModel>()), Times.Exactly(1));
        _mockedViewRenderer.Verify(vr => vr.RenderViewAsync(Templates.SuperMetricsLostConnectionNotice, It.IsAny<MailModel>()), Times.Exactly(1));

        _mockedMailer.Verify(mqd => mqd.Send(It.IsAny<Mail>()), Times.Exactly(2));
        _mockedChannelsDao.Verify(cd => cd.UpdateErrorStateAsync(It.IsAny<string>(), false), Times.Exactly(2));
    }
}