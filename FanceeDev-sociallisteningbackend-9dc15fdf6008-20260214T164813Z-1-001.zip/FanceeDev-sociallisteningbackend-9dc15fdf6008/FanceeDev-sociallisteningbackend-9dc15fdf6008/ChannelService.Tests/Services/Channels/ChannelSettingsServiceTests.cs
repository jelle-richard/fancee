using System.Net;
using ChannelService.Persistence.Channels;
using ChannelService.Persistence.ChannelSettings;
using ChannelService.Services.ChannelSettings;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Services.Cache;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Services.Channels;

public class ChannelSettingsServiceTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private readonly Mock<IChannelSettingsDao> _mockedChannelSettingsDao = new();
    private readonly Mock<IChannelsDao> _mockedChannelsDao = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();
    private readonly Mock<IHttpClientFactory> _mockedHttpClientFactory = new();
    private readonly ChannelSettingsService _sut;

    public ChannelSettingsServiceTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        MockHttpMessageHandler httpMessageHandler = new(HttpStatusCode.OK);
        _mockedHttpClientFactory.Setup(cf => cf.CreateClient("supermetrics")).Returns(new HttpClient(httpMessageHandler));

        _sut = new(configuration,
            _mockedCacheService.Object,
            _mockedChannelSettingsDao.Object,
            _mockedChannelsDao.Object,
            _mockedHttpClientFactory.Object);
    }

    [Fact]
    public async Task TestThatByChannelIdAsyncReturnsSuccessfully()
    {
        var mockedChannel = new Channel { Id = ChannelId, ChannelType = ChannelType.FACEBOOK };
        var mockedChannelSettings = new ChannelSettings { ChannelId = ChannelId };
        var cacheId = $"channel-{ChannelId}-settings";

        _mockedCacheService.Setup(cs => cs.CacheObjectAsync(It.IsAny<string>(), It.IsAny<object>(), It.IsAny<int>()));

        _mockedChannelSettingsDao.Setup(csd => csd.CreateAsync(It.IsAny<ChannelSettings>()));

        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<ChannelSettings>(It.IsAny<string>()))
            .ReturnsAsync((ChannelSettings?)null);

        _mockedChannelsDao.Setup(cs => cs.ByIdAsync(ChannelId))
            .ReturnsAsync(mockedChannel);

        _mockedChannelSettingsDao.Setup(csd => csd.ByChannelIdAsync(ChannelId))
            .ReturnsAsync(mockedChannelSettings);

        var actual = await _sut.ByChannelIdAsync(ChannelId);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatByChannelIdAsyncReturnsSuccessfullyFromCache()
    {
        var mockedChannel = new Channel { Id = ChannelId, ChannelType = ChannelType.FACEBOOK };
        var mockedChannelSettings = new ChannelSettings { ChannelId = ChannelId };
        var cacheId = $"channel-{ChannelId}-settings";

        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<ChannelSettings>(It.IsAny<string>()))
            .ReturnsAsync(mockedChannelSettings);

        var actual = await _sut.ByChannelIdAsync(ChannelId);

        Assert.NotNull(actual);
    }
}