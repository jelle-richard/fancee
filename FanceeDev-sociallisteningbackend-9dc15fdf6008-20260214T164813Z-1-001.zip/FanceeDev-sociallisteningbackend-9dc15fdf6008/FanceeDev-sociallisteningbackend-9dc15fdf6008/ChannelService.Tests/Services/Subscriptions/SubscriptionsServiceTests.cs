using System.Net;
using ChannelService.Persistence.Subscriptions;
using ChannelService.Services.Subscriptions;
using CronScheduler.Extensions.Internal;
using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Persistence.Entries;
using TestCore.Utils.UnitTestsHelpers;

namespace ChannelService.Tests.Services.Subscriptions;

public class SubscriptionsServiceTests
{
    private static readonly string ChannelId = ObjectId.GenerateNewId().ToString();
    private static readonly string SubscriptionId = ObjectId.GenerateNewId().ToString();

    private readonly Mock<ISubscriptionsDao> _mockedSubscriptionsDao = new();
    private readonly Mock<IGenericEntriesDao> _mockedGenericEntriesDao = new();
    private readonly Mock<ISchedulerRegistration> _mockedSchedulerRegistration = new();
    private readonly Mock<ILoggerFactory> _mockedLoggerFactory = new();
    private readonly Mock<ILogger> _mockedLogger = new();
    private readonly Mock<IHttpClientFactory> _mockedHttpClientFactory = new();

    private readonly ISubscriptionsService _sut;

    public SubscriptionsServiceTests()
    {
        MockHttpMessageHandler httpMessageHandler = new(HttpStatusCode.OK);
        _mockedHttpClientFactory.Setup(cf => cf.CreateClient("supermetrics"))
            .Returns(new HttpClient(httpMessageHandler));

        _mockedLoggerFactory.Setup(lf => lf.CreateLogger(It.IsAny<string>())).Returns(_mockedLogger.Object);

        _sut = new SubscriptionsService(
            _mockedSubscriptionsDao.Object,
            _mockedGenericEntriesDao.Object,
            _mockedSchedulerRegistration.Object,
            _mockedLoggerFactory.Object
        );
    }

    [Theory]
    [InlineData("dsAccount")]
    [InlineData("dsAccount|dsUser")]
    public async Task TestThatCreateAsyncReturnsSubscriptionWhenInputIsValid(string query)
    {
        var cron = "53/* * * *";

        CreateSubscriptionRequest subscriptionInput = new()
        {
            SubscriptionType = SubscriptionType.FB_POSTS,
            Cron = cron,
            Query = query,
            RequestHistory = false
        };
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FB_POSTS.ToInput(),
            Cron = cron
        };
        if (query.Count(c => c == '|') == 1)
        {
            var fields = query.Split('|');
            subscription.Input.DsAccounts = fields[0];
            subscription.Input.DsUser = fields[1];
        }
        else
            subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.CreateAsync(It.IsAny<Subscription>()))
            .ReturnsAsync(subscription);

        var actual = await _sut.CreateAsync(subscriptionInput);

        Assert.Equal(subscription.Id, actual.Id);
        Assert.Equal(subscription.Input, actual.Input);
        Assert.Equal(subscription.Name, actual.Name);
        Assert.Equal(cron, actual.Cron);
        Assert.False(actual.RunOnce);
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncReturnsEmptyArrayWhenCatchingException()
    {
        _mockedSubscriptionsDao.Setup(sd => sd.ToListByChannelIdAsync(It.IsNotNull<string>())).ThrowsAsync(new SubscriptionNotFoundException());
        var actual = await _sut.ToListByChannelIdAsync(It.IsNotNull<string>());
        Assert.Empty(actual);
    }

    [Fact]
    public async Task TestThatCreateAsyncThrowsSubscriptionTypeNotSupportedExceptionWhenSubscriptionTypeNotValid()
    {
        CreateSubscriptionRequest create = new()
        {
            Cron = "* * * * *",
            Query = "test",
            RequestHistory = false,
            SubscriptionType = (SubscriptionType)int.MaxValue
        };
        await Assert.ThrowsAsync<SubscriptionTypeNotSupportedException>(() => _sut.CreateAsync(create));
    }

    [Fact]
    public async Task TestThatToListByChannelIdAsyncReturnsListOfSubscriptionsWhenFound()
    {
        var cron = "53/* * * *";
        var query = "test";
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(new Dictionary<string, SchedulerTaskWrapper>());
        _mockedSubscriptionsDao.Setup(sd => sd.ToListByChannelIdAsync(ChannelId))
            .ReturnsAsync(new[] { subscription });

        var actual = await _sut.ToListByChannelIdAsync(ChannelId);

        Assert.Single(actual);

        var actualFirst = actual.First();

        Assert.Equal(actualFirst.Id, SubscriptionId);
        Assert.Equal(subscription.Input, actualFirst.Input);
        Assert.Equal(subscription.Name, actualFirst.Name);
        Assert.Equal(cron, actualFirst.Cron);
        Assert.False(actualFirst.RunOnce);
    }

    [Fact]
    public void TestThatStopSubscriptionJobReturnsTrueWhenFoundAndStopped()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.Remove(subscription.Name))
            .Returns(true);

        var actual = _sut.StopSubscriptionJob(subscription.Name);

        Assert.True(actual);

        _mockedLogger.VerifyLogging(
            $"Stopped subscription job: {subscription.Name}",
            LogLevel.Information,
            Times.Exactly(1));
    }

    [Fact]
    public void TestThatStopSubscriptionJobReturnsFalseWhenNotFound()
    {
        var cron = "53/* * * *";
        var query = "test";

        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_POSTS.ToInput(),
            Cron = cron
        };
        subscription.Input.DsAccounts = query;

        _mockedSubscriptionsDao.Setup(sd => sd.GetListAsync(
                It.IsAny<FilterDefinition<Subscription>>(),
                It.IsAny<FindOptions<Subscription, Subscription>>(),
                It.IsAny<string>()))
            .ReturnsAsync(new[] { subscription });

        _mockedSchedulerRegistration.Setup(sr => sr.Remove(subscription.Name))
            .Returns(false);

        var actual = _sut.StopSubscriptionJob(subscription.Name);

        Assert.False(actual);

        _mockedLogger.VerifyLogging(
            $"Failed to stop subscription job: {subscription.Name}. Job not found.",
            LogLevel.Warning,
            Times.Exactly(1));
    }

    [Fact]
    public async Task TestThatDeleteByIdAsyncReturnsTrueWhenSuccessful()
    {
        Subscription subscription = new()
        {
            Id = SubscriptionId,
            Input = SubscriptionType.FBPD_PAGE.ToInput()
        };

        _mockedSchedulerRegistration.Setup(sr => sr.Jobs)
            .Returns(new Dictionary<string, SchedulerTaskWrapper>());
        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(SubscriptionId))
            .ReturnsAsync(subscription);
        _mockedSubscriptionsDao.Setup(sd => sd.DeleteAsync(SubscriptionId))
            .ReturnsAsync(true);

        var actual = await _sut.DeleteByIdAsync(SubscriptionId);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatDeleteByIdAsyncReturnsFalseWhenFailed()
    {
        _mockedSubscriptionsDao.Setup(sd => sd.GetAsync(SubscriptionId))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<SubscriptionNotFoundException>(() => _sut.DeleteByIdAsync(SubscriptionId));
    }
}