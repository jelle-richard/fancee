using CronScheduler.Extensions.StartupInitializer;
using CronService.Jobs;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.Extensions.Logging;
using SocialListeningCore.Services.DeploymentEnvironments;
using TestCore.Utils.UnitTestsHelpers;

namespace CronService.Tests.Jobs;

public class InitEnvironmentJobTests
{
    private readonly IStartupJob _sut;
    private readonly Mock<ILogger<InitEnvironmentJob>> _logger = new();
    private readonly Mock<IDeploymentEnvironmentService> _deploymentEnvironmentService = new();

    public InitEnvironmentJobTests()
    {
        _sut = new InitEnvironmentJob(
            _logger.Object,
            _deploymentEnvironmentService.Object
        );
    }

    [Fact]
    public async Task TestThatExecuteAsyncSeedsEnvironmentWhenSuccessful()
    {
        _deploymentEnvironmentService.Setup(x => x.AnyAsync()).ReturnsAsync(false);
        _deploymentEnvironmentService.Setup(x => x.CreateAsync(It.IsAny<DeploymentEnvironment>()));

        await _sut.ExecuteAsync();

        _logger.VerifyLogging(
            $"{nameof(InitEnvironmentJob)} started",
            LogLevel.Information,
            Times.Once());

        _logger.VerifyLogging(
            $"{nameof(InitEnvironmentJob)} ended",
            LogLevel.Information,
            Times.Once());
    }
}