using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using SocialListeningCore.Persistence;

namespace LogService.Persistence.Logs;

public interface ILogsDao : IMongoDao<DataLog>
{
    /// <summary>
    /// Retrieves all logs from a given user between startDate and endDate.
    /// If startDate and endDate are null, the request will get all existing logs.
    /// Pagination is required for logs.
    /// </summary>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="userId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<DataLog>> ToPaginatedListAsync(int limit, int offset, Guid? userId = null, DateTime? startDate = null, DateTime? endDate = null);
}