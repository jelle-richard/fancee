using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;

namespace LogService.Persistence.Logs;

public class LogsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<DataLog>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Logs"),
    mongoDatabase), ILogsDao
{
    public async Task<ResultSetResponse<DataLog>> ToPaginatedListAsync(int limit, int offset, Guid? userId = null, DateTime? startDate = null, DateTime? endDate = null)
    {
        var filter = BuildFindFilter(userId, startDate, endDate);
        var sort = Builders<DataLog>.Sort.Descending(dbItem => dbItem.CreatedOn);
        return await GetPaginatedListAsync(limit, offset, filter, sort);
    }

    private FilterDefinition<DataLog> BuildFindFilter(Guid? userId = null, DateTime? startDate = null, DateTime? endDate = null)
    {
        var filter = Filter.Empty;

        if (userId != null)
            filter &= Filter.Eq(dbItem => dbItem.UserId, userId);
        if (startDate != null)
            filter &= Filter.Gte(dbItem => dbItem.CreatedOn, startDate);
        if (endDate != null)
            filter &= Filter.Lte(dbItem => dbItem.CreatedOn, endDate);

        return filter;
    }
}