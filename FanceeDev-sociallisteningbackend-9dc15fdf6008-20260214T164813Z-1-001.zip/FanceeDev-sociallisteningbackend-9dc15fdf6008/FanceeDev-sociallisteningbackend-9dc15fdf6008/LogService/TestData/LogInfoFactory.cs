using System.Dynamic;
using FanceeAnalyticsData.Models.Analytics;

namespace LogService.TestData;

public static class LogInfoFactory
{
    public static IEnumerable<DataLog> GetLogs()
    {
        var userId = Guid.Empty;
        dynamic testData = new ExpandoObject();
        testData.name = "Name";
        testData.value = 15;

        return new List<DataLog>
        {
            new("Test info") { Level = LogLevel.Information, UserId = userId },
            new("Test error") { Level = LogLevel.Error, UserId = userId },
            new("Test debug") { Level = LogLevel.Debug, Exception = "Test Exception", UserId = userId, Data = testData }
        };
    }
}