using LogService.Persistence.Logs;
using LogService.Services.Logs;
using SocialListeningCore;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "LogService",
        EndpointName = "LogService v1"
    }
};

builder.AddDependency<ILogsService, LogsService>(ServiceLifetime.Scoped);
builder.AddDependency<ILogsDao, LogsDao>(ServiceLifetime.Scoped);

var app = builder.Build();
app.Run();