using System.Net.Mime;
using FanceeAnalyticsData.Models.Analytics;
using LogService.Services.Logs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Utils.HttpContext;

namespace LogService.Controllers;

[Authorize]
[ApiController]
[Produces(MediaTypeNames.Application.Json)]
[Route("/[controller]")]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class LogsController(ILogsService logsService) : ControllerBase
{
    private UserType CurrentUserType => User.GetUserType() ?? UserType.Organization;

    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<DataLog>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<DataLog>>>> List([FromQuery] PaginatedRequest<SearchQueryFilter> request, DateTime? startDate, DateTime? endDate)
    {
        var result = CurrentUserType.HasFlag(UserType.Admin)
            ? await logsService.ToListAsync(request.PageSize, request.GetOffset(), startDate, endDate)
            : await logsService.ToListAsync(User.GetUserId(), request.PageSize, request.GetOffset(), startDate, endDate);

        return Ok(new ApiResponse<PaginatedResponse<DataLog>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }
}