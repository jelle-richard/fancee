using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;

namespace LogService.Services.Logs;

public interface ILogsService
{
    /// <summary>
    /// Retrieves all logs from a given user between startDate and endDate.
    /// If startDate and endDate are null, the request will get all existing logs.
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<DataLog>> ToListAsync(Guid userId, int limit, int offset, DateTime? startDate, DateTime? endDate);

    /// <summary>
    /// Retrieves all logs between startDate and endDate.
    /// If startDate and endDate are null, the request will get all existing logs.
    /// </summary>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<DataLog>> ToListAsync(int limit, int offset, DateTime? startDate, DateTime? endDate);
}