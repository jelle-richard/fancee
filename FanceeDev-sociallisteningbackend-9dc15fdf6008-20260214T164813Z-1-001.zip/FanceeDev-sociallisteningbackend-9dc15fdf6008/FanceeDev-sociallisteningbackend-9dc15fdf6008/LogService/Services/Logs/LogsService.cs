using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using LogService.Persistence.Logs;

namespace LogService.Services.Logs;

public class LogsService(ILogsDao logsDao) : ILogsService
{
    public async Task<ResultSetResponse<DataLog>> ToListAsync(int limit, int offset, DateTime? startDate, DateTime? endDate) => await logsDao.ToPaginatedListAsync(limit, offset, null, startDate, endDate);

    public async Task<ResultSetResponse<DataLog>> ToListAsync(Guid userId, int limit, int offset, DateTime? startDate, DateTime? endDate) => await logsDao.ToPaginatedListAsync(limit, offset, userId, startDate, endDate);
}