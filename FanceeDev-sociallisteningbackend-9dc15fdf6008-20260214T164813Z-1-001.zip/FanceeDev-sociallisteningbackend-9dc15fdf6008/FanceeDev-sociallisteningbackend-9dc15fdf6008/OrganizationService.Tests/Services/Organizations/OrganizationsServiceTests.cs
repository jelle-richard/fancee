using FanceeAnalyticsData.Models.Analytics;
using OrganizationService.Dtos.Requests.Organizations;
using OrganizationService.Persistence.Organizations;
using OrganizationService.Services.Organizations;
using OrganizationService.TestData;

namespace OrganizationService.Tests.Services.Organizations;

public class OrganizationsServiceTests
{
    private static readonly string OrganizationId = ObjectId.GenerateNewId().ToString();
    private readonly Guid UserId = new();
    private readonly OrganizationsService _sut;
    private readonly Mock<IOrganizationsDao> _mockedOrganizationsDao = new();

    public OrganizationsServiceTests()
    {
        _sut = new(_mockedOrganizationsDao.Object);
    }

    [Fact]
    public async Task TestThatToListAsyncCallsOrganizationsDaoToListAsync()
    {
        var mockedOrgs = OrganizationsFactory.GetMockedOrganizations();

        _mockedOrganizationsDao
            .Setup(od => od.ToListAsync())
            .ReturnsAsync(mockedOrgs);

        var actual = await _sut.ToListAsync();

        Assert.NotEmpty(actual);
        Assert.Equal(mockedOrgs, actual);
    }

    [Fact]
    public async Task TestThatToListAsyncWithUserIdCallsOrganizationsDaoToListAsync()
    {
        var mockedOrgs = OrganizationsFactory.GetMockedOrganizations();

        _mockedOrganizationsDao
            .Setup(od => od.ToListAsync(It.IsAny<Guid>()))
            .ReturnsAsync(mockedOrgs);

        var actual = await _sut.ToListAsync(UserId);

        Assert.NotEmpty(actual);
        Assert.Equal(mockedOrgs, actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncCallsOrganizationsDaoByIdAsync()
    {
        var mockedOrg = OrganizationsFactory.GetMockedOrganization();

        _mockedOrganizationsDao.Setup(od => od.ByIdAsync(It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(mockedOrg);

        var actual = await _sut.ByIdAsync(OrganizationId, UserId);

        Assert.NotNull(actual);
        Assert.Equal(mockedOrg, actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncOnlyWithIdCallsOrganizationsDaoByIdAsync()
    {
        var mockedOrg = OrganizationsFactory.GetMockedOrganization();

        _mockedOrganizationsDao.Setup(od => od.ByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(mockedOrg);

        var actual = await _sut.ByIdAsync(OrganizationId);

        Assert.NotNull(actual);
        Assert.Equal(mockedOrg, actual);
    }

    [Fact]
    public async Task TestThatCreateAsyncCallsOrganizationsDaoCreateAsync()
    {
        var request = new CreateOrganizationRequest
        {
            OrganizationName = "My org",
            CountryOfOperation = CountryCode.NL
        };

        var orgCreated = new Organization
        {
            OrganizationName = "My org",
            CountryOfOperation = request.CountryOfOperation,
            Email = "test@mail.com",
            FirstName = "Jan",
            LastName = "Piet",
            UserId = UserId
        };

        var user = new User
        {
            Email = "test@mail.com",
            FirstName = "Jan",
            LastName = "Piet",
            UserId = UserId
        };

        _mockedOrganizationsDao.Setup(od => od.CreateAsync(It.IsAny<Organization>()))
            .ReturnsAsync(orgCreated);

        var actual = await _sut.CreateAsync(request, UserId);

        Assert.NotNull(actual);
        Assert.IsType<Organization>(actual);
        Assert.Equal(orgCreated, actual);
        Assert.Equal(user.Email, actual.Email);
        Assert.Equal(user.FirstName, actual.FirstName);
        Assert.Equal(user.LastName, actual.LastName);
        Assert.Equal(request.OrganizationName, actual.OrganizationName);
        Assert.Equal(request.CountryOfOperation, actual.CountryOfOperation);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsOrganizationsDaoUpdateAsync()
    {
        var request = new UpdateOrganizationRequest
        {
            OrganizationName = "newName",
            CountryOfOperation = CountryCode.AD,
            ChamberOfCommerce = "newCoC",
            IBAN = "newIBAN",
            BIC = "newBIC",
            VATIdentifier = "newVAT"
        };

        var orgToUpdate = new Organization
        {
            Email = "old@mail.com",
            FirstName = "oldFirstName",
            LastName = "oldLastName",
            CountryOfOperation = CountryCode.BE
        };

        var orgUpdated = new Organization
        {
            OrganizationName = "newName",
            CountryOfOperation = CountryCode.AD,
            ChamberOfCommerce = "newCoC",
            IBAN = "newIBAN",
            BIC = "newBIC",
            VATIdentifier = "newVAT"
        };

        _mockedOrganizationsDao.Setup(od => od.ByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(orgToUpdate);
        _mockedOrganizationsDao.Setup(od => od.UpdateAsync(
                It.IsAny<Organization>(),
                It.IsAny<FilterDefinition<Organization>>(),
                It.IsAny<string>(),
                It.IsAny<bool>()))
            .ReturnsAsync(orgUpdated);

        var actual = await _sut.UpdateAsync(OrganizationId, request, UserId);

        Assert.NotNull(actual);
        Assert.IsType<Organization>(actual);
        Assert.Equal(orgUpdated, actual);
        Assert.Equal(request.OrganizationName, actual.OrganizationName);
        Assert.Equal(request.IBAN, actual.IBAN);
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsDeleteOrganizationsDaoAsync()
    {
        var organizationToDelete = OrganizationsFactory.GetMockedOrganization();

        _mockedOrganizationsDao.Setup(od => od.ByIdAsync(It.IsAny<string>()))
            .ReturnsAsync(organizationToDelete);
        _mockedOrganizationsDao.Setup(od => od.DeleteAsync(It.IsAny<string>()))
            .ReturnsAsync(true);

        var actual = await _sut.DeleteAsync(OrganizationId);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncReturnsFalseWhenOrganizationNotFound()
    {
        _mockedOrganizationsDao.Setup(od => od.DeleteAsync(It.IsAny<string>()))
            .ReturnsAsync(false);

        var actual = await _sut.DeleteAsync(OrganizationId);

        Assert.False(actual);
    }
}