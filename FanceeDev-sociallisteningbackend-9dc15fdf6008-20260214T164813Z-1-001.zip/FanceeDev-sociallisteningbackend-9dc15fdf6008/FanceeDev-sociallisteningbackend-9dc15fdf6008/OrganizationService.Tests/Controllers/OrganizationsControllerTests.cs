using System.Security.Claims;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OrganizationService.Controllers;
using OrganizationService.Dtos.Requests.Organizations;
using OrganizationService.Services.Organizations;
using OrganizationService.TestData;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Logging;
using TestCore.Utils.UnitTestsHelpers;

namespace OrganizationService.Tests.Controllers;

public class OrganizationsControllerTests
{
    private static readonly string OrganizationId = ObjectId.GenerateNewId().ToString();

    private static readonly Guid OrganizerUserId = Guid.NewGuid();
    private static readonly User UserOrganizer = new() { FanceeUsersId = OrganizerUserId, UserId = OrganizerUserId, Type = UserType.Organization };
    private static readonly Guid AdminUserId = Guid.NewGuid();
    private static readonly User UserAdmin = new() { FanceeUsersId = AdminUserId, UserId = AdminUserId, Type = UserType.Admin };

    private readonly OrganizationsController _sut;
    private readonly Mock<IOrganizationsService> _mockedOrganizationsService = new();
    private readonly LoggerFactory _factory = new();
    private readonly Mock<IMongoCollection<Log>> _mockedMongoCollection = new();

    public OrganizationsControllerTests()
    {
        _factory.AddProvider(new MongoLoggerProvider(new(string.Empty, _mockedMongoCollection.MockLogClient().Object)));

        _sut = new(_mockedOrganizationsService.Object, _factory)
        {
            ControllerContext =
            {
                HttpContext = new DefaultHttpContext
                {
                    User = new(new ClaimsIdentity(new[]
                    {
                        new Claim("user", UserOrganizer.FanceeUsersId.ToString()),
                        new Claim("platformUserId", UserOrganizer.UserId.ToString()),
                        new Claim("type", UserType.Organization.ToString())
                    }))
                }
            }
        };
    }

    [Fact]
    public async Task TestThatListCallsOrganizationsServiceToListAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);
        var organizations = OrganizationsFactory.GetMockedOrganizations();

        _mockedOrganizationsService.Setup(os => os.ToListAsync())
            .ReturnsAsync(organizations);

        var actual = await _sut.List();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationsService.Verify(os => os.ToListAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatListCallsOrganizationsServiceToListAsync_WhenCalledByRegularUser()
    {
        var organizations = OrganizationsFactory.GetMockedOrganizations();

        _mockedOrganizationsService.Setup(os => os.ToListAsync(UserOrganizer.FanceeUsersId))
            .ReturnsAsync(organizations);

        var actual = await _sut.List();

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationsService.Verify(os => os.ToListAsync(UserOrganizer.FanceeUsersId), Times.Once);
    }

    [Fact]
    public async Task TestThatSingleCallsOrganizationsServiceByIdAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        _mockedOrganizationsService.Setup(os => os.ByIdAsync(OrganizationId))
            .ReturnsAsync(new Organization());

        var actual = await _sut.Single(OrganizationId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationsService.Verify(os => os.ByIdAsync(OrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatSingleCallsOrganizationsServiceByIdAsync_WhenCalledByRegularUser()
    {
        _mockedOrganizationsService.Setup(os => os.ByIdAsync(OrganizationId, UserOrganizer.FanceeUsersId))
            .ReturnsAsync(new Organization());

        var actual = await _sut.Single(OrganizationId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationsService.Verify(os => os.ByIdAsync(OrganizationId, UserOrganizer.FanceeUsersId), Times.Once);
    }

    [Fact]
    public async Task TestThatSingleThrowsOrganizationNotFoundExceptionWhenOrganizationNotFound()
    {
        await Assert.ThrowsAsync<OrganizationNotFoundException>(async () => await _sut.Single(OrganizationId));
    }

    [Fact]
    public async Task TestThatSingleThrowsInvalidObjectIdExceptionWhenIdNotValid()
    {
        var id = "123";

        _mockedOrganizationsService.Setup(os => os.ByIdAsync(id, UserOrganizer.FanceeUsersId))
            .ReturnsAsync(new Organization());

        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.Single(id));
    }

    [Fact]
    public async Task TestThatCreateCallsOrganizationsServiceCreateAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var orgName = "MyOrg";
        var request = new CreateOrganizationRequest
        {
            OrganizationName = orgName,
            CountryOfOperation = CountryCode.NL
        };

        var orgCreated = new Organization
        {
            Id = Guid.NewGuid().ToString(),
            OrganizationName = orgName,
            CountryOfOperation = CountryCode.NL,
            ChamberOfCommerce = "CoC",
            IBAN = "IBAN",
            BIC = "BIC",
            VATIdentifier = "VAT",
            UserId = UserAdmin.FanceeUsersId
        };

        _mockedOrganizationsService.Setup(os => os.CreateAsync(request, UserAdmin.FanceeUsersId))
            .ReturnsAsync(orgCreated);

        var actual = await _sut.Create(request);

        Assert.IsType<CreatedResult>(actual.Result);

        _mockedOrganizationsService.Verify(os => os.CreateAsync(request, UserAdmin.FanceeUsersId), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatCreateThrowsMissingPermissionExceptionWhenUserIsNotAdmin()
    {
        var request = new CreateOrganizationRequest
        {
            OrganizationName = "MyOrg",
            CountryOfOperation = CountryCode.NL
        };

        await Assert.ThrowsAsync<MissingPermissionException>(async () => await _sut.Create(request));
    }

    [Fact]
    public async Task TestThatUpdateCallsOrganizationsServiceUpdateAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        var request = new UpdateOrganizationRequest
        {
            OrganizationName = "newName",
            CountryOfOperation = CountryCode.AD,
            ChamberOfCommerce = "newCoC",
            IBAN = "newIBAN",
            BIC = "newBIC",
            VATIdentifier = "newVAT"
        };
        _mockedOrganizationsService.Setup(os => os.ByIdAsync(OrganizationId))
            .ReturnsAsync(new Organization
            {
                UserId = UserAdmin.FanceeUsersId
            });
        _mockedOrganizationsService.Setup(os => os.UpdateAsync(OrganizationId, request, UserAdmin.FanceeUsersId))
            .ReturnsAsync(new Organization
            {
                OrganizationName = request.OrganizationName,
                CountryOfOperation = request.CountryOfOperation,
                ChamberOfCommerce = request.ChamberOfCommerce,
                IBAN = request.IBAN,
                BIC = request.BIC,
                VATIdentifier = request.VATIdentifier
            });

        var actual = await _sut.Update(OrganizationId, request);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationsService.Verify(os => os.UpdateAsync(OrganizationId, request, UserAdmin.FanceeUsersId), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatUpdateThrowsInvalidObjectIdExceptionWhenIdNotValid()
    {
        var id = "123";
        var request = new UpdateOrganizationRequest
        {
            OrganizationName = "newName",
            CountryOfOperation = CountryCode.AD,
            ChamberOfCommerce = "newCoC",
            IBAN = "newIBAN",
            BIC = "newBIC",
            VATIdentifier = "newVAT"
        };

        _mockedOrganizationsService.Setup(os => os.UpdateAsync(id, request, UserOrganizer.FanceeUsersId))
            .ReturnsAsync(new Organization());

        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.Update(id, request));
    }

    [Fact]
    public async Task TestThatUpdateThrowsMissingPermissionExceptionWhenUserIsNotAdmin()
    {
        var request = new UpdateOrganizationRequest
        {
            OrganizationName = "newName",
            CountryOfOperation = CountryCode.AD,
            ChamberOfCommerce = "newCoC",
            IBAN = "newIBAN",
            BIC = "newBIC",
            VATIdentifier = "newVAT"
        };
        _mockedOrganizationsService.Setup(os => os.ByIdAsync(OrganizationId))
            .ReturnsAsync(new Organization
            {
                UserId = UserAdmin.FanceeUsersId
            });

        await Assert.ThrowsAsync<MissingPermissionException>(async () => await _sut.Update(OrganizationId, request));
    }

    [Fact]
    public async Task TestThatDeleteCallsOrganizationsServiceDeleteAsync()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        _mockedOrganizationsService.Setup(os => os.DeleteAsync(OrganizationId))
            .ReturnsAsync(true);

        var actual = await _sut.Delete(OrganizationId);

        Assert.IsType<OkObjectResult>(actual.Result);

        _mockedOrganizationsService.Verify(os => os.DeleteAsync(OrganizationId), Times.Once);

        _mockedMongoCollection.Verify(c => c.InsertOne(
            It.IsAny<Log>(),
            It.IsAny<InsertOneOptions>(),
            It.IsAny<CancellationToken>()), Times.Once());
    }

    [Fact]
    public async Task TestThatDeleteThrowsInvalidObjectIdException_WhenIdNotValid()
    {
        var id = "123";

        _mockedOrganizationsService.Setup(os => os.DeleteAsync(id))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<InvalidObjectIdException>(async () => await _sut.Delete(id));
    }

    [Fact]
    public async Task TestThatDeleteThrowsMissingPermissionExceptionWhenUserIsNotAdmin()
    {
        await Assert.ThrowsAsync<MissingPermissionException>(async () => await _sut.Delete(OrganizationId));
    }

    [Fact]
    public async Task TestThatDeleteThrowsOrganizationNotFoundExceptionWhenOrganizationNotFound()
    {
        _sut.ControllerContext.SetUser(UserAdmin);

        await Assert.ThrowsAsync<OrganizationNotFoundException>(async () => await _sut.Delete(OrganizationId));
    }
}