using FanceeAnalyticsData.Models.Analytics;
using OrganizationService.Persistence.Organizations;
using OrganizationService.TestData;
using SocialListeningCore.Exceptions;
using TestCore.Utils.UnitTestsHelpers;

namespace OrganizationService.Tests.Persistence.Organizations;

public class OrganizationsDaoTests
{
    private const string OrganizationId = "organizationId";
    public readonly Mock<IAsyncCursor<Organization>> Cursor = new();
    private readonly Guid UserId = new();
    private readonly IOrganizationsDao _sut;
    private readonly Mock<IMongoDatabase> _mongoDatabase = new();
    private readonly Mock<IMongoCollection<Organization>> _mockedCollection = new();

    public OrganizationsDaoTests()
    {
        var configuration = MockDBConfiguration.GetDBConfiguration();

        _sut = new OrganizationsDao(configuration, _mongoDatabase.Object);

        _mongoDatabase
            .Setup(x => x.GetCollection<Organization>(
                It.IsAny<string>(), null))
            .Returns(_mockedCollection.Object);

        _mockedCollection
            .Setup(x => x.FindAsync(
                It.IsAny<FilterDefinition<Organization>>(),
                It.IsAny<FindOptions<Organization>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Cursor.Object);

        Cursor.SetupSequence(x => x.MoveNextAsync(It.IsAny<CancellationToken>())).ReturnsAsync(true).ReturnsAsync(false);
        Cursor.SetupSequence(x => x.MoveNext(It.IsAny<CancellationToken>())).Returns(true).Returns(false);
    }

    [Fact]
    public async Task TestThatUpdateAsyncReturnsOrganizationWhenSuccessful()
    {
        var organization = OrganizationsFactory.GetMockedOrganization();

        _mockedCollection
            .SetupSequence(x => x.FindOneAndUpdateAsync(
                It.IsAny<FilterDefinition<Organization>>(),
                It.IsAny<UpdateDefinition<Organization>>(),
                It.IsAny<FindOneAndUpdateOptions<Organization>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(organization);

        var actual = await _sut.UpdateAsync(organization);

        Assert.Equal(organization, actual);
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinition()
    {
        var organization = OrganizationsFactory.GetMockedOrganization();

        Assert.NotNull(_sut.GetUpdateDefinition(organization));
    }

    [Fact]
    public void TestThatGetUpdateDefinitionReturnsUpdateDefinitionWhenModelIsNull()
    {
        Assert.NotNull(_sut.GetUpdateDefinition(null));
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsOrganization()
    {
        var mockedOrganization = OrganizationsFactory.GetMockedOrganization();

        Cursor.Setup(x => x.Current).Returns(new[] { mockedOrganization });

        var actual = await _sut.ByIdAsync(OrganizationId, UserId);

        Assert.Equal(mockedOrganization, actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsOrganizationWhenCalledByAdmin()
    {
        var mockedOrganization = OrganizationsFactory.GetMockedOrganization();

        Cursor.Setup(x => x.Current).Returns(new[] { mockedOrganization });

        var actual = await _sut.ByIdAsync(OrganizationId);

        Assert.Equal(mockedOrganization, actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsNullWhenNotFound()
    {
        Cursor.Setup(x => x.Current).Returns(Array.Empty<Organization>());

        await Assert.ThrowsAsync<OrganizationNotFoundException>(async () => await _sut.ByIdAsync(OrganizationId, UserId));
    }

    [Fact]
    public async Task TestThatByIdAsyncThrowsExceptionWhenNotFoundAndCalledByAdmin()
    {
        Cursor.Setup(x => x.Current).Returns(Array.Empty<Organization>());

        await Assert.ThrowsAsync<OrganizationNotFoundException>(async () => await _sut.ByIdAsync(OrganizationId));
    }

    [Fact]
    public async Task TestThatToListAsyncReturnsListCalledByAdmin()
    {
        var mockedOrganizations = OrganizationsFactory.GetMockedOrganizations();

        Cursor.Setup(x => x.Current).Returns(mockedOrganizations);

        var actual = await _sut.ToListAsync();

        Assert.Equal(mockedOrganizations, actual);
    }

    [Fact]
    public async Task TestThatToListAsyncReturnsList()
    {
        var mockedOrganizations = OrganizationsFactory.GetMockedOrganizations();

        Cursor.Setup(x => x.Current).Returns(mockedOrganizations);

        var actual = await _sut.ToListAsync(UserId);

        Assert.Equal(mockedOrganizations, actual);
    }
}