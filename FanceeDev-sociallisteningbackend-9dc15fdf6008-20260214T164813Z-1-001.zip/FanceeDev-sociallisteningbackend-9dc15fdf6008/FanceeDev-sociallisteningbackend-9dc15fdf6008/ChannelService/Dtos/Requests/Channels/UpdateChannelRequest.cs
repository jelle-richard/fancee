﻿namespace ChannelService.Dtos.Requests.Channels;

public class UpdateChannelRequest
{
    public string? Name { get; set; }
}