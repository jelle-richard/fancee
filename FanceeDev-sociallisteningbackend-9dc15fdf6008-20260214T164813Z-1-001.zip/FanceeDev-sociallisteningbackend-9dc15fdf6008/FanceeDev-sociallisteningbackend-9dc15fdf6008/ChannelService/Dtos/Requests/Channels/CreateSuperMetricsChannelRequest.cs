using System.ComponentModel.DataAnnotations;
using FanceeAnalyticsData.Models.Analytics;

namespace ChannelService.Dtos.Requests.Channels;

public class CreateSuperMetricsChannelRequest : CreateChannelRequest
{
    [Required]
    public string? Name { get; set; }

    [Required]
    public string? UserId { get; set; }

    [Required]
    public string? AccountsId { get; set; }

    [Required]
    public ChannelOwner? Owner { get; set; }
}