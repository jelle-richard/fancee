using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using FanceeAnalyticsData.Models.Analytics;

namespace ChannelService.Dtos.Requests.Channels;

public class CreateChannelRequest
{
    [Required]
    [JsonPropertyName("type")]
    public ChannelType ChannelType { get; set; }

    [Required]
    public Guid PlatformUserId { get; set; }
}