using FanceeAnalyticsData.Models.Analytics;

namespace ChannelService.Dtos.Responses.Channels;

public class CreateChannelResponse
{
    public Channel? Channel { get; set; }
    public IEnumerable<Subscription>? Subscriptions { get; set; }
}