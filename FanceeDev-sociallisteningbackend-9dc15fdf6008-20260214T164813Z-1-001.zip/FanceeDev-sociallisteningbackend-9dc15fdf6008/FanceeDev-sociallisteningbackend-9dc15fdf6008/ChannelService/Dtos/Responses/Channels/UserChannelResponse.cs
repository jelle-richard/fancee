using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Bson.Serialization.Attributes;

namespace ChannelService.Dtos.Responses.Channels;

[BsonIgnoreExtraElements]
public class UserChannelResponse : Channel
{
    [BsonElement("user")]
    public User? User { get; set; }

    public UserChannelResponse()
    {
    }

    public UserChannelResponse(Channel channel, User? user) : base(channel)
    {
        User = user;
    }
}