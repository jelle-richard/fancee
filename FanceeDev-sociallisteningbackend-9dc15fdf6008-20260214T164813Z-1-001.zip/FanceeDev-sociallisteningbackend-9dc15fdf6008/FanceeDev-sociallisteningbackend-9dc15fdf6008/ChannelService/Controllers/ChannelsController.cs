using System.Net.Mime;
using ChannelService.Dtos.Requests.Channels;
using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using ChannelService.Services.Channels;
using ChannelService.Services.Subscriptions;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Dtos.Responses;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Logging;
using SocialListeningCore.Utils.Cron;
using SocialListeningCore.Utils.Extensions;
using SocialListeningCore.Utils.HttpContext;

namespace ChannelService.Controllers;

[Authorize]
[ApiController]
[Route("/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class ChannelsController(IChannelsService channelsService, ISubscriptionsService subscriptionsService, ILoggerFactory loggerFactory) : ControllerBase
{
    private Guid UserId => User.GetUserId();
    private UserType CurrentUserType => User.GetUserType() ?? UserType.Organization;
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);

    [HttpGet]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<UserChannelResponse>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<UserChannelResponse>>>> List([FromQuery] PaginatedRequest<SearchQueryFilter> request)
    {
        var result = CurrentUserType.HasFlag(UserType.Admin)
            ? await channelsService.ToListAsync(request.PageSize, request.GetOffset())
            : await channelsService.ToListAsync(UserId, request.PageSize, request.GetOffset());

        return Ok(new ApiResponse<PaginatedResponse<UserChannelResponse>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("table")]
    [ProducesResponseType(typeof(ApiResponse<PaginatedResponse<Channel>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<PaginatedResponse<Channel>>>> TableQuery([FromQuery] PaginatedRequest<QueryFilter<ChannelsTableField>> request)
    { 
        var result = CurrentUserType.HasFlag(UserType.Admin)
            ? await channelsService.ChannelsAsync(request.Options, request.PageSize, request.GetOffset())
            : await channelsService.ChannelsAsync(UserId, request.Options, request.PageSize, request.GetOffset());

        return Ok(new ApiResponse<PaginatedResponse<Channel>>
        {
            Data = new()
            {
                Items = result.Items,
                TotalItems = result.TotalItems,
                Page = request.Page,
                PageSize = request.PageSize
            }
        });
    }

    [HttpGet]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<UserChannelResponse>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<UserChannelResponse>>> Single(string id)
    {
        if (CurrentUserType.HasFlag(UserType.Admin))
            return Ok(new ApiResponse<UserChannelResponse> { Data = await channelsService.ByIdAsync(id) });
        return Ok(new ApiResponse<UserChannelResponse> { Data = await channelsService.ByIdAsync(id, UserId) });
    }

    [HttpPost]
    [ProducesResponseType(typeof(ApiResponse<CreateChannelResponse>), StatusCodes.Status201Created)]
    public async Task<ActionResult<ApiResponse<CreateChannelResponse>>> CreateSuperMetricsChannel([FromBody] CreateSuperMetricsChannelRequest request)
    {
        if (request.PlatformUserId != UserId && !CurrentUserType.HasFlag(UserType.Admin))
            throw new MissingPermissionException();
        var channel = await channelsService.CreateAsync(request, request.PlatformUserId);
        var subscriptions = await CreateChannelSubscriptionsAsync(channel);
        _logger.MongoLogInfo(request.PlatformUserId, $"New {channel.ChannelType} channel created.", new
        {
            channelId = channel.Id,
            channelType = channel.ChannelType.ToString()
        });
        return Created($"/{channel.Id}", new ApiResponse<CreateChannelResponse> { Data = new() { Channel = channel, Subscriptions = subscriptions } });
    }

    [HttpPatch]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<Channel>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<Channel>>> Update(string id, [FromBody] UpdateChannelRequest update)
    {
        var channelUpdated = CurrentUserType.HasFlag(UserType.Admin)
            ? await channelsService.UpdateAsync(id, update)
            : await channelsService.UpdateAsync(id, update, UserId);

        _logger.MongoLogInfo(UserId, $"{channelUpdated.ChannelType} channel \"{channelUpdated.Name}\" updated.", new
        {
            channelId = channelUpdated.Id,
            channelType = channelUpdated.ChannelType.ToString(),
            channelName = channelUpdated.Name
        });

        return Ok(new ApiResponse<Channel>
        {
            Data = channelUpdated
        });
    }

    [HttpDelete]
    [Route("{id}")]
    [ProducesResponseType(typeof(ApiResponse<bool>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<bool>>> Delete(string id)
    {
        var channel = CurrentUserType.HasFlag(UserType.Admin)
            ? await channelsService.ByIdAsync(id)
            : await channelsService.ByIdAsync(id, UserId);
        var subscriptions = await subscriptionsService.ToListByChannelIdAsync(channel!.Id!);

        foreach (var sub in subscriptions)
            await subscriptionsService.DeleteByIdAsync(sub.Id!);

        await channelsService.DeleteAsync(channel!.Id!);

        _logger.MongoLogInfo(UserId, $"{channel.ChannelType} channel \"{channel.Name}\" deleted.", new
        {
            channelId = channel.Id,
            channelType = channel.ChannelType.ToString(),
            channelName = channel.Name
        });

        return Ok(new ApiResponse<bool> { Data = true });
    }

    [HttpGet]
    [Route("{id}/subscriptions")]
    [ProducesResponseType(typeof(ApiResponse<IEnumerable<Subscription>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<IEnumerable<Subscription>>>> GetAllSubscriptionsUnderChannel(string id) =>
        Ok(new ApiResponse<IEnumerable<Subscription>>
        {
            Data = await subscriptionsService.ToListByChannelIdAsync(id)
        });

    private async Task<IEnumerable<Subscription>> CreateChannelSubscriptionsAsync(Channel channel)
    {
        var subscriptions = await subscriptionsService.ToListByChannelIdAsync(channel.Id!);
        if (!subscriptions.Any())
        {
            foreach (var subscriptionType in channel.ChannelType.ToSubscriptionTypes())
                await CreateSubscriptionAsync(channel, subscriptionType);
        }

        return subscriptions;
    }

    private async Task<Subscription> CreateSubscriptionAsync(Channel channel, SubscriptionType subscriptionType) =>
        await subscriptionsService.CreateAsync(new()
        {
            SubscriptionType = subscriptionType,
            ChannelId = channel?.Id,
            Cron = CronConstants.CronRunAt3Pm,
            Query = channel?.Request!
        });
}