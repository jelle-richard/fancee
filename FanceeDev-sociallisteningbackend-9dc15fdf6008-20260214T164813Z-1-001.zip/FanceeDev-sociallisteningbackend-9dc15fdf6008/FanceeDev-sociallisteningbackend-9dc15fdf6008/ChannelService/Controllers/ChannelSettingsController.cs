using System.Net.Mime;
using ChannelService.Services.ChannelSettings;
using FanceeAnalyticsData.Models.Analytics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SocialListeningCore.Dtos.Responses;

namespace ChannelService.Controllers;

[Authorize]
[ApiController]
[Route("/[controller]")]
[Produces(MediaTypeNames.Application.Json)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status404NotFound)]
[ProducesResponseType(typeof(EmptyResponse), StatusCodes.Status400BadRequest)]
public class ChannelSettingsController(IChannelSettingsService channelSettingsService) : ControllerBase
{
    [HttpGet]
    [Route("{channelId}")]
    [ProducesResponseType(typeof(ApiResponse<ChannelSettings>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ApiResponse<ChannelSettings>>> Single(string channelId) => Ok(new ApiResponse<ChannelSettings> { Data = await channelSettingsService.ByChannelIdAsync(channelId) });
}