using ChannelService.Jobs;
using ChannelService.Persistence.Channels;
using ChannelService.Persistence.ChannelSettings;
using ChannelService.Persistence.Subscriptions;
using ChannelService.Services.Channels;
using ChannelService.Services.ChannelSettings;
using ChannelService.Services.Subscriptions;
using SocialListeningCore;
using SocialListeningCore.Logging;
using SocialListeningCore.Persistence.MailQueues;
using SocialListeningCore.Services.DeploymentEnvironments;

var builder = new Startup(WebApplication.CreateBuilder(args))
{
    SwaggerOptions = new()
    {
        Title = "ChannelService",
        EndpointName = "ChannelService v1"
    }
};

builder.OnConfigureServices += (_, collection) =>
{
    collection.AddScheduler(sb =>
    {
        sb.Services.AddStartupJob<InitFailedChannelJob>();
        _ = sb.AddUnobservedTaskExceptionHandler(sp =>
        {
            var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger(MongoLogger.Name);
            return
                (sender, args) =>
                {
                    logger.MongoLogException(null, args.Exception);
                    args.SetObserved();
                };
        });
    });
};

builder.AddDependency<IChannelsDao, ChannelsDao>(ServiceLifetime.Scoped);
builder.AddDependency<IChannelsService, ChannelsService>(ServiceLifetime.Scoped);
builder.AddDependency<IChannelSettingsDao, ChannelSettingsDao>(ServiceLifetime.Scoped);
builder.AddDependency<IChannelSettingsService, ChannelSettingsService>(ServiceLifetime.Scoped);
builder.AddDependency<ISubscriptionsService, SubscriptionsService>(ServiceLifetime.Scoped);
builder.AddDependency<ISubscriptionsDao, SubscriptionsDao>(ServiceLifetime.Scoped);
builder.AddDependency<IMailQueueDao, MailQueueDao>(ServiceLifetime.Scoped);
builder.AddDependency<IDeploymentEnvironmentService, DeploymentEnvironmentService>(ServiceLifetime.Scoped);

var app = builder.Build();
await app.RunStartupJobsAync();
app.Run();