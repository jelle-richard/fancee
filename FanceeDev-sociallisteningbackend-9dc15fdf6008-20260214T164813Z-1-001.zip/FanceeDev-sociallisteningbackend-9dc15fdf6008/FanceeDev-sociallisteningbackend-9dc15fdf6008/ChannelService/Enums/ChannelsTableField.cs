namespace ChannelService.Enums;

public enum ChannelsTableField
{
    Name,
    Type,
    Status,
    User,
    Organization,
    Owner,
    Email,
    CreatedOn
}