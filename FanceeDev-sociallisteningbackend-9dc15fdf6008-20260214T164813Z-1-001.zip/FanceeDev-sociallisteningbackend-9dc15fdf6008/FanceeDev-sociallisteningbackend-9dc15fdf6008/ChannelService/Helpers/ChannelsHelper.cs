
using ChannelService.Enums;

namespace ChannelService.Helpers;

public static class ChannelsHelper
{
    public static string ToFieldId(this ChannelsTableField field) => field switch
    {
        ChannelsTableField.Name => "Name",
        ChannelsTableField.Type => "ChannelType",
        ChannelsTableField.User => "UserId",
        ChannelsTableField.Organization => "Owner.OrganizationName",
        ChannelsTableField.Owner => "Owner.FirstName",
        ChannelsTableField.Email => "Owner.Email",
        ChannelsTableField.Status => "Status",
        ChannelsTableField.CreatedOn => "CreatedOn",
        _ => throw new NotSupportedException("ToFieldId")
    };
}