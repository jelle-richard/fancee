using ChannelService.Dtos.Responses.Channels;
using FanceeAnalyticsData.Models.Analytics;

namespace ChannelService.TestData;

public static class ChannelsFactory
{
    public static Channel[] GetMockedChannels() =>
    [
        new()
        {
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel",
            Request = "request",
            UserId = Guid.NewGuid(),
            HasError = false
        },
        new()
        {
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel2",
            Request = "request2",
            UserId = Guid.NewGuid(),
            HasError = false
        },
        new()
        {
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel3",
            Request = "request3",
            UserId = Guid.NewGuid(),
            HasError = true
        },
        new()
        {
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel4",
            Request = "request4",
            UserId = Guid.NewGuid(),
            HasError = true
        }
    ];

    public static UserChannelResponse[] GetMockedUserChannels() =>
    [
        new()
        {
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel",
            Request = "request",
            UserId = Guid.NewGuid()
        },
        new()
        {
            ChannelType = ChannelType.FACEBOOK,
            Name = "myChannel2",
            Request = "request2",
            UserId = Guid.NewGuid()
        }
    ];
}