using ChannelService.Dtos.Requests.Channels;
using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using ChannelService.Jobs;
using ChannelService.Persistence.Channels;
using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using MailTemplates.Models;
using MailTemplates.Models.Analytics;
using MailTemplates.Templates;
using SocialListeningCore.Dtos.MailProvider;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Logging;
using SocialListeningCore.Persistence.Users;
using SocialListeningCore.Services.DeploymentEnvironments;
using SocialListeningCore.Services.Mailer;
using SocialListeningCore.Settings;
using SocialListeningCore.Utils.Cron;
using SocialListeningCore.Utils.Mail;
using ViewRenderer;

namespace ChannelService.Services.Channels;

public class ChannelsService(
    IChannelsDao channelsDao,
    IUserDao userDao,
    IViewRenderer viewRenderer,
    IDeploymentEnvironmentService deploymentEnvironmentService,
    IConfiguration configuration,
    IServiceProvider serviceProvider,
    ILoggerFactory loggerFactory,
    ISchedulerRegistration schedulerRegistration,
    IMailer mailer)
    : IChannelsService
{
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);

    public async Task<Channel> CreateAsync(CreateSuperMetricsChannelRequest request, Guid userId) =>
        await channelsDao.CreateAsync(
            new()
            {
                Name = request.Name,
                Status = ChannelStatus.Active,
                ChannelType = request.ChannelType,
                Request = $"{request.AccountsId}|{request.UserId}",
                UserId = userId,
                Owner = request.Owner
            });

    public async Task<UserChannelResponse> ByIdAsync(string id) => await ToUserChannelAsync(await channelsDao.ByIdAsync(id) ?? throw new ChannelNotFoundException(id));

    public async Task<UserChannelResponse> ByIdAsync(string id, Guid userId)
    {
        // TODO: When MessageBus is implemented in SocialListening. Use rabbit message to reset the cache if there were any changes made to channels and/or subscriptions.
        var channel = await ToUserChannelAsync(await channelsDao.ByIdAsync(id, userId) ?? throw new ChannelNotFoundException(id));

        return channel;
    }

    public async Task<ResultSetResponse<Channel>> ChannelsAsync(QueryFilter<ChannelsTableField> filter, int limit, int offset = 0) => await channelsDao.ToPaginatedTableAsync(limit, offset, filter.OrderBy, filter.OrderByAscending);

    public async Task<ResultSetResponse<Channel>> ChannelsAsync(Guid userId, QueryFilter<ChannelsTableField> filter, int limit, int offset = 0) => await channelsDao.ToPaginatedTableAsync(limit, offset, filter.OrderBy, filter.OrderByAscending, userId);

    public async Task<ResultSetResponse<UserChannelResponse>> ToListAsync(int limit, int offset = 0) => await channelsDao.ToPaginatedListAsync(limit, offset);

    public async Task<ResultSetResponse<UserChannelResponse>> ToListAsync(Guid userId, int limit, int offset = 0) => await channelsDao.ToPaginatedListAsync(limit, offset, userId);

    public async Task<Channel> UpdateAsync(string id, UpdateChannelRequest update) => await UpdateAsync(await ByIdAsync(id), update);

    public async Task<Channel> UpdateAsync(string id, UpdateChannelRequest update, Guid userId) => await UpdateAsync(await ByIdAsync(id, userId), update);

    public async Task<bool> DeleteAsync(string id) => await channelsDao.DeleteAsync(id);

    public async Task SendFailedChannelConnectionMailsAsync()
    {
        var expiredChannels = await channelsDao.HasErrorListAsync(ChannelStatus.Expired);
        var errorChannels = await channelsDao.HasErrorListAsync(ChannelStatus.Error);
        var organizationDetailSettings = OrganizationDetailsSettings.FromConfiguration(configuration);
        var deploymentEnvironment = await deploymentEnvironmentService.GetAsync();

        await SendMailForErrorChannelsAsync(errorChannels, organizationDetailSettings, deploymentEnvironment);
        await SendMailForExpiredChannelsAsync(expiredChannels, organizationDetailSettings, deploymentEnvironment);
    }

    public async Task AddOrUpdateFailedChannelJobAsync()
    {
        var jobOptions = new SchedulerOptions
        {
            CronSchedule = CronConstants.CronRunEvery5Minutes,
            RunImmediately = false
        };

        var job = new FailedChannelJob(serviceProvider.CreateScope().ServiceProvider, jobOptions, _logger);

        var result = await Task.Run(() => schedulerRegistration.AddOrUpdate(job.Name, job, jobOptions));

        if (result)
            _logger.LogInformation("Started job: {name}", job.Name);
        else
            _logger.LogWarning("Failed to start job: {name}", job.Name);
    }

    private async Task<Channel> UpdateAsync(Channel channel, UpdateChannelRequest update)
    {
        channel.Name = update.Name ?? channel.Name;

        return await channelsDao.UpdateAsync(channel);
    }

    private async Task<UserChannelResponse> ToUserChannelAsync(Channel channel)
    {
        try
        {
            var user = await userDao.ByFanceeUsersIdAsync(channel.UserId);
            return new(channel, user);
        }
        catch
        {
            // Ignored for now. Used to have users in mongodb, but after migration, the users are now only in ticketing.
        }

        return new(channel, null);
    }

    private async Task SendMailForErrorChannelsAsync(IEnumerable<Channel> channels, OrganizationDetailsSettings organizationDetailSettings, DeploymentEnvironment deploymentEnvironment)
    {
        await SendMailForChannelsAsync(channels, organizationDetailSettings, deploymentEnvironment,
            Templates.SuperMetricsErrorInChannelNoticeSubject,
            Templates.SuperMetricsErrorInChannelNotice,
            channel => new SuperMetricsErrorInChannelModel
            {
                ChannelName = channel.Name ?? string.Empty,
                OrganizationName = channel.Owner?.OrganizationName ?? string.Empty
            });
    }

    private async Task SendMailForExpiredChannelsAsync(IEnumerable<Channel> channels, OrganizationDetailsSettings organizationDetailSettings, DeploymentEnvironment deploymentEnvironment)
    {
        await SendMailForChannelsAsync(channels, organizationDetailSettings, deploymentEnvironment,
            Templates.SuperMetricsLostConnectionNoticeSubject,
            Templates.SuperMetricsLostConnectionNotice,
            channel => new SuperMetricsLostConnectionModel
            {
                ChannelName = channel.Name ?? string.Empty,
                OrganizationName = channel.Owner?.OrganizationName ?? string.Empty
            });
    }

    private async Task SendMailForChannelsAsync(IEnumerable<Channel> channels, OrganizationDetailsSettings organizationDetailSettings, DeploymentEnvironment deploymentEnvironment, string templateSubject, string templateView, Func<Channel, MailModel> modelBuilder)
    {
        foreach (var channel in channels)
        {
            var organizationName = channel.Owner?.OrganizationName ?? string.Empty;

            var subject = templateSubject.Replace("%organizationName%", organizationName).Replace("%platformName%", organizationDetailSettings.PlatformName);
            var htmlContent = await viewRenderer.RenderViewAsync(templateView, modelBuilder(channel).SetDefaultValues(subject, organizationDetailSettings, deploymentEnvironment.FrontendBaseUrl));

            // TODO(SOC-537): When data from Ticketing is available and organizations can manage their own channels, replace support email with country manager email
            var toEmail = organizationDetailSettings.SupportEmail;
            var mail = new Mail
            {
                From = new(organizationDetailSettings.SupportEmail, organizationDetailSettings.PlatformName),
                To = [new(toEmail, organizationDetailSettings.PlatformName)],
                Subject = subject,
                HtmlContent = htmlContent
            };
            mailer.Send(mail);
            await channelsDao.UpdateErrorStateAsync(channel.Id, false);
        }
    }
}