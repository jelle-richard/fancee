using ChannelService.Dtos.Requests.Channels;
using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using SocialListeningCore.Dtos.Requests.Filters.Pagination;

namespace ChannelService.Services.Channels;

public interface IChannelsService
{
    /// <summary>
    /// Creates a channel by request and saved with userId.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="userId"></param>
    /// <returns>created channel</returns>
    public Task<Channel> CreateAsync(CreateSuperMetricsChannelRequest request, Guid userId);

    /// <summary>
    /// Gets all channels.
    /// </summary>
    /// <returns>list of channels</returns>
    public Task<ResultSetResponse<UserChannelResponse>> ToListAsync(int limit, int offset = 0);

    /// <summary>
    /// Gets all channels with this userId.
    /// Requires a specific userId to filter on.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns>list of channels</returns>
    public Task<ResultSetResponse<UserChannelResponse>> ToListAsync(Guid userId, int limit, int offset = 0);

    /// <summary>
    /// Gets all the channels for a table with filter, sort and pagination options.
    /// </summary>
    /// <param name="filter"></param>
    /// <returns>list of channels</returns>
    public Task<ResultSetResponse<Channel>> ChannelsAsync(QueryFilter<ChannelsTableField> filter, int limit, int offset = 0);

    /// <summary>
    /// Gets all the channels for a table with filter, sort and pagination options.
    /// Requires a specific userId to filter on.
    /// </summary>
    /// <param name="filter"></param>
    /// <returns>list of channels</returns>
    public Task<ResultSetResponse<Channel>> ChannelsAsync(Guid userId, QueryFilter<ChannelsTableField> filter, int limit, int offset = 0);

    /// <summary>
    /// Gets a channel by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>a channel</returns>
    public Task<UserChannelResponse> ByIdAsync(string id);

    /// <summary>
    /// Gets a channel by id.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="userId"></param>
    /// <returns>a channel</returns>
    public Task<UserChannelResponse> ByIdAsync(string id, Guid userId);

    /// <summary>
    /// Updates a channel by id.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="update"></param>
    /// <returns>a updated channel</returns>
    public Task<Channel> UpdateAsync(string id, UpdateChannelRequest update);

    /// <summary>
    /// Updates a channel by id.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="update"></param>
    /// <param name="userId"></param>
    /// <returns>a updated channel</returns>
    public Task<Channel> UpdateAsync(string id, UpdateChannelRequest update, Guid userId);

    /// <summary>
    /// Deletes a channel by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>True/False if the removal was successfull.</returns>
    public Task<bool> DeleteAsync(string id);

    /// <summary>
    /// Sends emails for every channel with a failed connection.
    /// </summary>
    /// <returns></returns>
    public Task SendFailedChannelConnectionMailsAsync();

    /// <summary>
    /// Adds or updates the FailedChannelJob to the cron scheduler.
    /// </summary>
    /// <returns></returns>
    public Task AddOrUpdateFailedChannelJobAsync();
}