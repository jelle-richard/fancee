namespace ChannelService.Services.ChannelSettings;

public interface IChannelSettingsService
{
    /// <summary>
    /// Gets a channelSettings by ChannelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <returns>a ChannelSettings</returns>
    public Task<FanceeAnalyticsData.Models.Analytics.ChannelSettings> ByChannelIdAsync(string channelId);
}