using System.Net.Mime;
using ChannelService.Persistence.Channels;
using ChannelService.Persistence.ChannelSettings;
using FanceeAnalyticsData.Models.Analytics.SuperMetrics.Channels;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Services.Cache;
using SocialListeningCore.Utils.Extensions;

namespace ChannelService.Services.ChannelSettings;

public class ChannelSettingsService(IConfiguration configuration, ICacheService cacheService, IChannelSettingsDao channelSettingsDao, IChannelsDao channelsDao, IHttpClientFactory httpClientFactory)
    : IChannelSettingsService
{
    public async Task<FanceeAnalyticsData.Models.Analytics.ChannelSettings> ByChannelIdAsync(string channelId)
    {
        var cacheId = $"channel-{channelId}-settings";
        var settings = await cacheService.GetCachedObjectAsync<FanceeAnalyticsData.Models.Analytics.ChannelSettings>(cacheId);

        if (settings != null)
            return settings;

        settings = await channelSettingsDao.ByChannelIdAsync(channelId);
        if (settings == null)
        {
            var channel = await channelsDao.ByIdAsync(channelId) ?? throw new ChannelNotFoundException(channelId);
            using var response = await GetClient().GetAsync($"{configuration.GetConnectionString("SuperMetrics")}query/fields?ds_id={channel.ChannelType.ToDSID()}");
            var result = await response.Content.ReadFromJsonAsync<ChannelFieldsResponse>();

            if (!response.IsSuccessStatusCode)
                throw new ChannelNotFoundException(channelId);

            settings = await channelSettingsDao.CreateAsync(new()
            {
                ChannelId = channel.Id,
                Fields = result?.Data
            });
        }

        await cacheService.CacheObjectAsync(cacheId, settings, 1);
        return settings;
    }

    private HttpClient GetClient()
    {
        var managementApiKey = configuration.GetValue<string>("SuperMetrics:ApiKey");
        if (string.IsNullOrEmpty(managementApiKey))
            throw new NotSupportedException("SuperMetrics:ApiKey not found. Value required in secrets.json");

        var client = httpClientFactory.CreateClient("supermetrics");
        client.Timeout = TimeSpan.FromMinutes(5);
        client.DefaultRequestHeaders.Add("Authorization", $"Bearer {managementApiKey}");
        client.DefaultRequestHeaders.Accept.Add(new(MediaTypeNames.Application.Json));

        return client;
    }
}