using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Services;

namespace ChannelService.Services.Subscriptions;

public interface ISubscriptionsService : IMongoService<Subscription>
{
    /// <summary>
    /// Creates a new Subscription that collects data from SuperMetrics per cron timing.
    /// </summary>
    /// <param name="create"></param>
    /// <returns>The newly created Subscription</returns>
    public Task<Subscription> CreateAsync(CreateSubscriptionRequest create);

    /// <summary>
    /// Gets a list of all subscriptions for a given channel.
    /// </summary>
    /// <returns>All subscriptions</returns>
    public Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId);

    /// <summary>
    /// Removes a Subscription by id from the database. The active SubscriptionJob will also be stopped and removed.
    /// </summary>
    /// <param name="id"></param>
    /// <returns>True/False if the removal was successfull.</returns>
    public Task<bool> DeleteByIdAsync(string id);

    /// <summary>
    /// Stops a cronjob based on the name of a SubscriptionJob. Mainly used by 'SubscriptionRunnerJob' when 'RunOnce' is set to true.
    /// </summary>
    /// <param name="name"></param>
    /// <returns>True/False if the cronjob was found/stopped.</returns>
    public bool StopSubscriptionJob(string name);
}