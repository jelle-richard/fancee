using ChannelService.Persistence.Subscriptions;
using CronScheduler.Extensions.Scheduler;
using FanceeAnalyticsData.Models.Analytics;
using SocialListeningCore.Dtos.Requests.Subscriptions;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Helpers;
using SocialListeningCore.Logging;
using SocialListeningCore.Persistence.Entries;
using SocialListeningCore.Services;

namespace ChannelService.Services.Subscriptions;

public class SubscriptionsService(
    ISubscriptionsDao subscriptionsDao,
    IGenericEntriesDao genericEntriesDao,
    ISchedulerRegistration schedulerRegistration,
    ILoggerFactory loggerFactory)
    : MongoService<Subscription, ISubscriptionsDao>(subscriptionsDao), ISubscriptionsService
{
    private readonly ILogger _logger = loggerFactory.CreateLogger(MongoLogger.Name);
    private readonly ISubscriptionsDao _subscriptionsDao = subscriptionsDao;

    public async Task<Subscription> CreateAsync(CreateSubscriptionRequest create) => await _subscriptionsDao.CreateAsync(create.ToSubscription());

    public async Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId)
    {
        try
        {
            var subscriptions = (await _subscriptionsDao.ToListByChannelIdAsync(channelId)).ToList();
            foreach (var sub in subscriptions)
                sub.Active = schedulerRegistration.Jobs.Any(dbItem => dbItem.Key == sub.Name);

            return subscriptions;
        }
        catch (SubscriptionNotFoundException)
        {
            return Array.Empty<Subscription>();
        }
    }

    public async Task<bool> DeleteByIdAsync(string id)
    {
        var sub = await GetAsync(id) ?? throw new SubscriptionNotFoundException();

        if (schedulerRegistration.Jobs.Any(dbItem => dbItem.Key == sub.Name))
            StopSubscriptionJob(sub.Name);

        await genericEntriesDao.DeleteListForSubscriptionAsync(id, sub.SubscriptionType);

        return await _subscriptionsDao.DeleteAsync(id);
    }

    public bool StopSubscriptionJob(string name)
    {
        var result = schedulerRegistration.Remove(name);
        if (result)
            _logger.LogInformation("Stopped subscription job: {name}", name);
        else
            _logger.LogWarning("Failed to stop subscription job: {name}. Job not found.", name);

        return result;
    }
}