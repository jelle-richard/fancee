using ChannelService.Services.Channels;
using CronScheduler.Extensions.StartupInitializer;

namespace ChannelService.Jobs;

/// <summary>
/// Adds the FailedChannelJob to the cron scheduler.
/// </summary>
public class InitFailedChannelJob(IChannelsService channelsService, ILogger<InitFailedChannelJob> logger) : IStartupJob
{
    public string Name => "InitFailedChannelJob";

    public async Task ExecuteAsync(CancellationToken cancellationToken = default)
    {
        logger.LogInformation("{job} started", nameof(InitFailedChannelJob));
        await channelsService.AddOrUpdateFailedChannelJobAsync();
        logger.LogInformation("{job} ended", nameof(InitFailedChannelJob));
    }
}