using ChannelService.Services.Channels;
using CronScheduler.Extensions.Scheduler;

namespace ChannelService.Jobs;

/// <summary>
/// Sends emails for every failed connection for channels.
/// </summary>
public class FailedChannelJob(IServiceProvider serviceProvider, SchedulerOptions options, ILogger logger) : IScheduledJob
{
    public string Name => "FailedChannelJob";

    public async Task ExecuteAsync(CancellationToken cancellationToken)
    {
        logger.LogInformation("{cronSchedule} - {name} started", options.CronSchedule, Name);
        await serviceProvider.GetRequiredService<IChannelsService>().SendFailedChannelConnectionMailsAsync();
        logger.LogInformation("{cronSchedule} - {name} ended", options.CronSchedule, Name);
    }
}