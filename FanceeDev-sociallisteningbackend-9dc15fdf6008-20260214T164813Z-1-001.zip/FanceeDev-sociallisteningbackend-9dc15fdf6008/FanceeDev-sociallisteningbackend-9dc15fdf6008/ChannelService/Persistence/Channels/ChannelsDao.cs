using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using ChannelService.Helpers;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;

namespace ChannelService.Persistence.Channels;

public class ChannelsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<Channel>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Channels"),
    mongoDatabase), IChannelsDao
{
    public async Task<Channel?> ByIdAsync(string id)
    {
        var filter = Builders<Channel>.Filter.Eq(dbItem => dbItem.Id, id);

        return await Collection.Find(filter).FirstOrDefaultAsync() ?? throw new ChannelNotFoundException(id);
    }

    public async Task<Channel?> ByIdAsync(string id, Guid userId)
    {
        var filter = Builders<Channel>.Filter.Eq(dbItem => dbItem.Id, id);
        filter &= Builders<Channel>.Filter.Eq(dbItem => dbItem.UserId, userId);

        return await Collection.Find(filter).FirstOrDefaultAsync() ?? throw new ChannelNotFoundException(id);
    }

    public async Task<IEnumerable<Channel>> ToListAsync(Guid userId)
    {
        var filter = Builders<Channel>.Filter.Eq(dbItem => dbItem.UserId, userId);

        return await Collection.Find(filter).ToListAsync();
    }

    public async Task<IEnumerable<Channel>> ToListAsync() => await Collection.Find(Builders<Channel>.Filter.Empty).ToListAsync();

    public async Task<ResultSetResponse<UserChannelResponse>> ToPaginatedListAsync(int limit, int offset, Guid? userId = null)
    {
        var filter = userId == null
            ? Builders<UserChannelResponse>.Filter.Empty
            : Builders<UserChannelResponse>.Filter.Eq(dbItem => dbItem.UserId, userId);

        return await GetPaginatedListAsync(limit, offset, filter);
    }

    public async Task<ResultSetResponse<Channel>> ToPaginatedTableAsync(int limit, int offset, ChannelsTableField sortField, bool ascending, Guid? userId = null)
    {
        var filter = userId == null
            ? Builders<Channel>.Filter.Empty
            : Builders<Channel>.Filter.Eq(dbItem => dbItem.UserId, userId);

        var sort = ascending
            ? Builders<Channel>.Sort.Ascending(sortField.ToFieldId())
            : Builders<Channel>.Sort.Descending(sortField.ToFieldId());

        return await GetPaginatedListAsync(limit, offset, filter, sort);
    }

    public async Task<IEnumerable<Channel>> HasErrorListAsync(ChannelStatus status)
    {
        var filter = Builders<Channel>.Filter.Eq(dbItem => dbItem.HasError, true) &
                     Builders<Channel>.Filter.Eq(dbItem => dbItem.Status, status);

        return await GetListAsync(filter);
    }

    public async Task<UpdateResult> UpdateErrorStateAsync(string? id, bool state)
    {
        var filter = Builders<Channel>.Filter.Eq(dbItem => dbItem.Id, id);
        var update = Builders<Channel>.Update.Set(dbItem => dbItem.HasError, state)
            .Set(dbItem => dbItem.UpdatedOn, DateTime.UtcNow);

        return await UpdateOneAsync(filter, update);
    }

    public override UpdateDefinition<Channel> GetUpdateDefinition(Channel? model)
    {
        try
        {
            return Update.Combine(
                new List<UpdateDefinition<Channel>>
                {
                    Update.Set(nameof(model.Name), model?.Name),
                    base.GetUpdateDefinition(model)
                }
            );
        }
        catch
        {
            return base.GetUpdateDefinition(model);
        }
    }
}