using ChannelService.Dtos.Responses.Channels;
using ChannelService.Enums;
using FanceeAnalyticsData.Models.Analytics;
using FanceeAnalyticsData.Models.Analytics.Api;
using MongoDB.Driver;
using SocialListeningCore.Persistence;

namespace ChannelService.Persistence.Channels;

public interface IChannelsDao : IMongoDao<Channel>
{
    /// <summary>
    /// Gets the channel based on given id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<Channel?> ByIdAsync(string id);

    /// <summary>
    /// Gets the channel based on given id and userId.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<Channel?> ByIdAsync(string id, Guid userId);

    /// <summary>
    /// Gets all channels.
    /// </summary>
    /// <returns>list of channels</returns>
    public Task<IEnumerable<Channel>> ToListAsync();

    /// <summary>
    /// Gets a list of channels filtered by userId.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<IEnumerable<Channel>> ToListAsync(Guid userId);

    /// <summary>
    /// Gets a paginated list of channels, filtered by userId.
    /// If userId is null, will return channels without user filter.
    /// </summary>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="userId"></param>
    /// <returns>List of Channels</returns>
    public Task<ResultSetResponse<UserChannelResponse>> ToPaginatedListAsync(int limit, int offset, Guid? userId = null);

    /// <summary>
    /// Gets a paginated list of channels, filtered by userId.
    /// If userId is null, will return all channels.
    /// </summary>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="sortField"></param>
    /// <param name="ascending"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<ResultSetResponse<Channel>> ToPaginatedTableAsync(int limit, int offset, ChannelsTableField sortField, bool ascending, Guid? userId = null);

    /// <summary>
    /// Retrieves a list of channels which have the boolean field has_errors set to true.
    /// </summary>
    /// <param name="status"></param>
    /// <returns></returns>
    public Task<IEnumerable<Channel>> HasErrorListAsync(ChannelStatus status);

    /// <summary>
    /// Updates the has_errors field of a channel to the given state.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="state"></param>
    /// <returns></returns>
    public Task<UpdateResult> UpdateErrorStateAsync(string? id, bool state);
}