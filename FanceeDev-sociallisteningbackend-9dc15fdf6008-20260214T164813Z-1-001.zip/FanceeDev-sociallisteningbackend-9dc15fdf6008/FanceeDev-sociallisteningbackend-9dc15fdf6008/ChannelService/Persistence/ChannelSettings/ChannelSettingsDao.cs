using MongoDB.Driver;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;

namespace ChannelService.Persistence.ChannelSettings;

public class ChannelSettingsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<FanceeAnalyticsData.Models.Analytics.ChannelSettings>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("ChannelSettings"),
    mongoDatabase), IChannelSettingsDao
{
    public async Task<FanceeAnalyticsData.Models.Analytics.ChannelSettings?> ByChannelIdAsync(string channelId) => await Collection.Find(Filter.Eq(dbItem => dbItem.ChannelId, channelId)).FirstOrDefaultAsync();
}