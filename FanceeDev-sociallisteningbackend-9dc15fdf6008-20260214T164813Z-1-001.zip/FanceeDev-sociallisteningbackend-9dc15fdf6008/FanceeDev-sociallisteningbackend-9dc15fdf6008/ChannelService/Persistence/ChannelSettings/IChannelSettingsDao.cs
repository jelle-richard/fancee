using SocialListeningCore.Persistence;

namespace ChannelService.Persistence.ChannelSettings;

public interface IChannelSettingsDao : IMongoDao<FanceeAnalyticsData.Models.Analytics.ChannelSettings>
{
    /// <summary>
    /// Gets the channelsettings based on given channelId.
    /// </summary>
    /// <param name="channelId"></param>
    /// <returns></returns>
    public Task<FanceeAnalyticsData.Models.Analytics.ChannelSettings?> ByChannelIdAsync(string channelId);
}