using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Exceptions;
using SocialListeningCore.Persistence;
using SocialListeningCore.Settings;

namespace ChannelService.Persistence.Subscriptions;

public class SubscriptionsDao(IConfiguration configuration, IMongoDatabase? mongoDatabase = null) : MongoDao<Subscription>(configuration.GetConnectionString("Mongo"),
    configuration.GetValue<string>("Mongo:Database:Default"),
    CollectionSettings.GetCollectionName("Subscriptions"),
    mongoDatabase), ISubscriptionsDao
{
    public async Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId)
    {
        var filter = Filter.Eq(dbItem => dbItem.ChannelId, channelId);

        var subscriptions = await Collection.Find(filter).ToListAsync();
        if (!subscriptions.Any())
            throw new SubscriptionNotFoundException();

        return subscriptions;
    }

    public async Task<UpdateResult> UpdateAccountsByChannelId(string? channelId, string? user, string? accounts)
    {
        var filter = Filter.Eq(dbItem => dbItem.ChannelId, channelId);
        var update = Update
            .Set(dbItem => dbItem.Input.DsAccounts, accounts)
            .Set(dbItem => dbItem.Input.DsUser, user)
            .Set(dbItem => dbItem.UpdatedOn, DateTime.UtcNow);
        return await UpdateManyAsync(filter, update);
    }
}