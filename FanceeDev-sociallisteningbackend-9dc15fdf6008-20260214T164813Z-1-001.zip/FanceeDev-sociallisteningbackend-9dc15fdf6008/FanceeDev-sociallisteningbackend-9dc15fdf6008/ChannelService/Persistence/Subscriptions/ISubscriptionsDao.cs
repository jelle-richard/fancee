using FanceeAnalyticsData.Models.Analytics;
using MongoDB.Driver;
using SocialListeningCore.Persistence;

namespace ChannelService.Persistence.Subscriptions;

public interface ISubscriptionsDao : IMongoDao<Subscription>
{
    /// <summary>
    /// Returns a list of subscriptions linked to a given channel.
    /// </summary>
    /// <param name="channelId"></param>
    /// <returns>A list of subscriptions</returns>
    public Task<IEnumerable<Subscription>> ToListByChannelIdAsync(string channelId);

    /// <summary>
    /// Updates the 'DsUser' and 'DsAccounts' fields for SuperMetrics related requests.
    /// </summary>
    /// <param name="channelId"></param>
    /// <param name="user"></param>
    /// <param name="accounts"></param>
    /// <returns>The result of the update</returns>
    public Task<UpdateResult> UpdateAccountsByChannelId(string? channelId, string? user, string? accounts);
}