using AccountingUtils.Providers.Bank.Ing;
using AccountingUtils.Providers.Bank.Models;
using ClosedXML.Excel;

namespace AccountingUtils.Services.Bank.Ing.Exporters;

internal class IngPayoutExportService
{
    internal const int MaximumRowsPerDocument = 1000;

    private readonly IXLWorksheet _worksheet;
    private readonly PayoutExportInfo _payoutExportInfo;

    private readonly Dictionary<ExportFieldType, string> _fieldLocations = new()
    {
        { ExportFieldType.DebtorName, "C1" },
        { ExportFieldType.DebtorIban, "C2" },
        { ExportFieldType.ExecuteOn, "C4" },
        { ExportFieldType.ReceiverName, "B" },
        { ExportFieldType.ReceiverIban, "C" },
        { ExportFieldType.ValueEur, "D" },
        { ExportFieldType.Description, "E" },
        { ExportFieldType.Reference, "F" },
        { ExportFieldType.TotalPayout, "C8" },
        { ExportFieldType.TotalTransactions, "C9" }
    };

    private readonly Dictionary<ExportFieldType, int> _tableLocation = new()
    {
        { ExportFieldType.FirstTableRow, 12 },
        { ExportFieldType.LastTableRow, 1011 }
    };

    public IngPayoutExportService(IXLWorksheet worksheet, PayoutExportInfo payoutExportInfo)
    {
        _worksheet = worksheet;
        _payoutExportInfo = payoutExportInfo;
    }

    public void Create()
    {
        WriteSenderInformation();
        WritePayoutRows();
        UpdateFormulas();
    }

    private void WriteSenderInformation()
    {
        SetCellValue(ExportFieldType.DebtorName, _payoutExportInfo.DebtorBankAccountHolderName);
        SetCellValue(ExportFieldType.DebtorIban, _payoutExportInfo.DebtorIban);
        SetCellValue(ExportFieldType.ExecuteOn, _payoutExportInfo.ExecuteOn.ToDateTime(new(23, 59, 59)));
    }

    private void WritePayoutRows()
    {
        var currentRow = _tableLocation[ExportFieldType.FirstTableRow];

        foreach (var row in _payoutExportInfo.Rows)
        {
            WritePayoutRow(row, currentRow);
            ++currentRow;
        }
    }

    /// <summary>
    /// OpenXML does not support referencing tables as done in the original formulas (e.g. SUM(Table13[Bedrag])),
    /// So we have to update the formula to be a standard range SUM/COUNT.
    /// </summary>
    private void UpdateFormulas()
    {
        var tablePayoutRange = $"{_fieldLocations[ExportFieldType.ValueEur]}{_tableLocation[ExportFieldType.FirstTableRow]}:{_fieldLocations[ExportFieldType.ValueEur]}{_tableLocation[ExportFieldType.LastTableRow]}";

        UpdateFormula(_worksheet.Cell(_fieldLocations[ExportFieldType.TotalPayout]), $"SUM({tablePayoutRange})");
        UpdateFormula(_worksheet.Cell(_fieldLocations[ExportFieldType.TotalTransactions]), $"COUNT({tablePayoutRange})");
    }

    private void WritePayoutRow(PayoutRow row, int rowIndex)
    {
        SetCellValue($"{_fieldLocations[ExportFieldType.ReceiverName]}{rowIndex}", row.BankAccountHolderName);
        SetCellValue($"{_fieldLocations[ExportFieldType.ReceiverIban]}{rowIndex}", row.ReceiverIban);
        SetCellValue($"{_fieldLocations[ExportFieldType.ValueEur]}{rowIndex}", row.ValueEurCents / 100m);
        SetCellValue($"{_fieldLocations[ExportFieldType.Description]}{rowIndex}", row.Description);
        SetCellValue($"{_fieldLocations[ExportFieldType.Reference]}{rowIndex}", row.Reference);
    }

    private void SetCellValue(ExportFieldType field, string? value) =>
        SetCellValue(_fieldLocations[field], value);

    private void SetCellValue(ExportFieldType field, DateTime value) =>
        SetCellValue(_fieldLocations[field], value);

    private void SetCellValue(string cell, string? value)
    {
        _worksheet.Cell(cell)
            .SetValue(value);
    }

    private void SetCellValue(string cell, decimal value)
    {
        _worksheet.Cell(cell)
            .SetValue(value);
    }

    private void SetCellValue(string cell, DateTime value)
    {
        _worksheet.Cell(cell)
            .SetValue(value);
    }
    
    /// <summary>
    /// Updates the formula in a cell and recalculates the value.
    /// </summary>
    /// <param name="cell"></param>
    /// <param name="newFormula"></param>
    private static void UpdateFormula(IXLCell cell, string newFormula)
    {
        cell.FormulaA1 = newFormula;
        cell.SetValue(cell.Value); // Setting the value like this forces a recalculation of the formula.
    }
}