using AccountingUtils.Providers.Bank.Models;
using ClosedXML.Excel;

namespace AccountingUtils.Services.Bank.Ing.Exporters;

public class IngBankAccountExportService
{
    private const int HeaderStartRow = 1;
    private const int ContentStartRow = 2;
    private const string CurrencyFormat = "€ #,##0.00";

    private static readonly string[] HeaderNames =
    {
        "Holder name",
        "Bank account number",
        "BIC",
        "Payout",
        "Reference",
        "Description"
    };

    private readonly IXLWorksheet _worksheet;
    private readonly IList<PayoutRow> _rows;

    public IngBankAccountExportService(IXLWorksheet worksheet, IList<PayoutRow> rows)
    {
        _worksheet = worksheet;
        _rows = rows;
    }

    public void Create()
    {
        WriteHeader();
        WritePayoutRows();
        ApplyStyles();
    }

    private void WriteHeader()
    {
        for (var i = 0; i < HeaderNames.Length; i++)
            SetHeaderValue(i + 1, HeaderNames[i]);
    }

    private void WritePayoutRows()
    {
        for (var i = 0; i < _rows.Count; i++)
        {
            var row = _rows[i];
            var rowIndex = ContentStartRow + i;

            SetCellValue(rowIndex, 1, row.BankAccountHolderName);
            SetBankAccountNumberValue(rowIndex, 2, row.ReceiverBankAccountNumber ?? string.Empty);
            SetCellValue(rowIndex, 3, row.ReceiverBic);
            SetCurrencyValue(rowIndex, 4, row.ValueEurCents / 100m);
            SetCellValue(rowIndex, 5, row.Reference);
            SetCellValue(rowIndex, 6, row.Description);
        }
    }

    private void ApplyStyles()
    {
        _worksheet.Row(1).Style.Font.Bold = true;

        _worksheet.Columns(1, HeaderNames.Length)
            .AdjustToContents(1, _rows.Count + 1);
    }

    private void SetHeaderValue(int column, string? value) =>
        SetCellValue(HeaderStartRow, column, value);

    private void SetCurrencyValue(int row, int column, decimal value)
    {
        var cell = SetCellValue(row, column, value);
        cell.Style.NumberFormat.SetFormat(CurrencyFormat);
    }

    private void SetBankAccountNumberValue(int row, int column, string value)
    {
        var cell = SetCellValue(row, column, value);

        if (int.TryParse(value, out var _))
            cell.DataType = XLDataType.Number;

        cell.Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Left);
    }

    private IXLCell SetCellValue(int row, int column, string? value) =>
        _worksheet.Cell(row, column)
            .SetDataType(XLDataType.Text)
            .SetValue(value);

    private IXLCell SetCellValue(int row, int column, decimal value) =>
        _worksheet.Cell(row, column)
            .SetDataType(XLDataType.Number)
            .SetValue(value);
}