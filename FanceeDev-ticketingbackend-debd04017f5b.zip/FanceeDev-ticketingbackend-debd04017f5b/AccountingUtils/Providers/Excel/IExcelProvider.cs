using ClosedXML.Excel;

namespace AccountingUtils.Providers.Excel;

internal interface IExcelProvider
{
    /// <summary>
    /// Creates a new workbook.
    /// </summary>
    /// <returns></returns>
    public IXLWorkbook CreateWorkbook();

    /// <summary>
    /// Creates a new workbook with the stream as input file.
    /// </summary>
    /// <param name="stream"></param>
    /// <returns></returns>
    public IXLWorkbook CreateWorkbook(Stream stream);
}