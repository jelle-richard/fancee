using ClosedXML.Excel;

namespace AccountingUtils.Providers.Excel;

internal class ExcelProvider : IExcelProvider
{
    public IXLWorkbook CreateWorkbook() => new XLWorkbook();

    public IXLWorkbook CreateWorkbook(Stream stream) => new XLWorkbook(stream);
}