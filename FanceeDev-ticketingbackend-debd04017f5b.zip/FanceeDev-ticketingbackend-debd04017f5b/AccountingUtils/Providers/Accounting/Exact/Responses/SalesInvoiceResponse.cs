using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class SalesInvoiceResponse : ResultItemResponse<SalesInvoiceResponse>
{
    [JsonPropertyName("InvoiceID")] public Guid InvoiceId { get; set; }

    public int? InvoiceNumber { get; set; }
}