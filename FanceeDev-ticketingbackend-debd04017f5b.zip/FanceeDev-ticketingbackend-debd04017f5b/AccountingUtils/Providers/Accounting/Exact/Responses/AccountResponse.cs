using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class AccountResponse : ResultItemResponse<AccountResponse>
{
    [JsonPropertyName("ID")] public Guid Id { get; set; }

    public string? AddressLine1 { get; set; }

    public string? AddressLine2 { get; set; }

    public string? AddressLine3 { get; set; }

    public string? Country { get; set; }

    [JsonPropertyName("Postcode")] public string? PostalCode { get; set; }
    
    public string? City { get; set; }

    public bool? Blocked { get; set; }

    public string Email { get; set; } = default!;

    public string Name { get; set; } = default!;

    public string Status { get; set; } = default!;
}