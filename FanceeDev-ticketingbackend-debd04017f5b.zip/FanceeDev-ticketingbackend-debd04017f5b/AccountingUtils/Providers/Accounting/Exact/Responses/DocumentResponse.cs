using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class DocumentResponse : ResultItemResponse<DocumentResponse>
{
    [JsonPropertyName("ID")] public Guid Id { get; set; }

    [JsonPropertyName("Account")] public Guid? AccountId { get; set; }

    [JsonPropertyName("Category")] public Guid? CategoryId { get; set; }

    public string? CategoryDescription { get; set; }

    public string? DocumentViewUrl { get; set; }

    public string? Subject { get; set; }

    public int? Type { get; set; }

    public string? TypeDescription { get; set; }

    public int? SalesInvoiceNumber { get; set; }
}