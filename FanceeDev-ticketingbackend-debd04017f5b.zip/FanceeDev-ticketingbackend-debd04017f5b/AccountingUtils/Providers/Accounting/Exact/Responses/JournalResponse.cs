using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class JournalResponse : ResultItemResponse<JournalResponse>
{
    [JsonPropertyName("ID")] public Guid Id { get; set; }

    public string Code { get; set; } = default!;

    public Guid? Bank { get; set; }

    [JsonPropertyName("BankAccountBICCode")]
    public string? BankAccountBicCode { get; set; }

    public string? BankAccountCountry { get; set; }

    public string? BankAccountDescription { get; set; }

    [JsonPropertyName("BankAccountIBAN")] public string? BankAccountIban { get; set; }

    [JsonPropertyName("BankAccountID")] public Guid? BankAccountId { get; set; }

    public string? BankName { get; set; }

    public bool AllowVariableCurrency { get; set; }

    public string? Currency { get; set; }

    public string? Description { get; set; }

    public int Division { get; set; }

    [JsonPropertyName("IsBlocked")] public bool Blocked { get; set; }

    public JournalType Type { get; set; }

    public enum JournalType
    {
        Cash = 10,
        Bank = 12,
        PaymentService = 16,
        Sales = 20,
        ReturnInvoice = 21,
        Purchase = 22,
        ReceivedReturnInvoice = 23,
        GeneralJournal = 90
    }
}