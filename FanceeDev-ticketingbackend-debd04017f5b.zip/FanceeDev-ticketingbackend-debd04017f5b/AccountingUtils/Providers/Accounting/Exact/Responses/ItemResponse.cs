using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class ItemResponse : ResultItemResponse<ItemResponse>
{
    [JsonPropertyName("ID")] public Guid Id { get; set; }

    public string? Code { get; set; }

    public string? CostPriceCurrency { get; set; }

    public decimal? CostPriceStandard { get; set; }

    public string? Description { get; set; }

    public string? ExtraDescription { get; set; }

    public string? Notes { get; set; }

    public string? Unit { get; set; }

    public string? UnitDescription { get; set; }

    /// <summary>
    /// A = Area
    /// L = Length
    /// O = Other
    /// T = Time
    /// V = Volume
    /// W = Weight
    /// </summary>
    public string? UnitType { get; set; }
}