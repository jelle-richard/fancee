using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class AccountingDivisionResponse : ResultItemResponse<AccountingDivisionResponse>
{
    [JsonPropertyName("AccountingDivision")]
    public int AccountingDivision { get; set; }
}