using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class ExactMetadata
{
    [JsonPropertyName("uri")] public string? Uri { get; set; }

    [JsonPropertyName("type")] public string? Type { get; set; }
}