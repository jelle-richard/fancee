using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class BaseResponse<TModel> where TModel : ResultItemResponse<TModel>
{
    [JsonPropertyName("d")] public ResultResponse<TModel> Data { get; set; } = default!;
}