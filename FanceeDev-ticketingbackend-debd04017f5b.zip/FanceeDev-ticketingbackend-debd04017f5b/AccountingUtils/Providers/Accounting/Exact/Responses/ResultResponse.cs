using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class ResultResponse<TModel> where TModel : ResultItemResponse<TModel>
{
    [JsonPropertyName("results")] public IEnumerable<TModel> Results { get; set; } = new List<TModel>();
}