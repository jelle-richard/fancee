using System.Reflection;
using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public abstract class ResultItemResponse<TModel> where TModel : ResultItemResponse<TModel>
{
    [JsonPropertyName("__metadata")] public ExactMetadata? Metadata { get; set; }

    /// <summary>
    /// Gets all the available properties for the request.
    /// Only gets the properties from the derived class.
    /// </summary>
    /// <returns></returns>
    public static string[] GetRequestPropertyNames()
    {
        return typeof(TModel)
            .GetProperties(BindingFlags.Instance | BindingFlags.Public)
            .Where(p => p.DeclaringType != typeof(ResultItemResponse<TModel>))
            .Select(p => p.GetCustomAttribute<JsonPropertyNameAttribute>()?.Name ?? p.Name)
            .ToArray();
    }
}