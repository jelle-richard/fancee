using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class DocumentAttachmentResponse : ResultItemResponse<DocumentAttachmentResponse>
{
    [JsonPropertyName("ID")] public Guid Id { get; set; }

    public string? FileName { get; set; }

    public long FileSize { get; set; }

    public string? Url { get; set; }

    [JsonPropertyName("Document")] public Guid? DocumentId { get; set; }
}