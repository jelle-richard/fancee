using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Responses;

public class BaseCreateResponse<TModel> where TModel : ResultItemResponse<TModel>
{
    [JsonPropertyName("d")] public TModel Data { get; set; } = default!;
}