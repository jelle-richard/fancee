using AccountingUtils.Providers.Accounting.Exact.Requests;
using AccountingUtils.Providers.Accounting.Exact.Responses;

namespace AccountingUtils.Providers.Accounting.Exact;

public interface IExactProvider
{
    /// <summary>
    /// Sets the bearer token used for API requests.
    /// </summary>
    /// <param name="token"></param>
    /// <returns></returns>
    public IExactProvider SetToken(string token);

    /// <summary>
    /// Gets the URl where the frontend needs to redirect to in order to start the Exact integration process.
    /// </summary>
    /// <param name="oAuthRedirectUrl"></param>
    /// <returns></returns>
    public string OAuthRedirectUrl(string oAuthRedirectUrl);

    /// <summary>
    /// Gets a token from the authorization code.
    /// </summary>
    /// <param name="code">Authorization code from Exact</param>
    /// <param name="oAuthRedirectUrl">Must be the same URL as used in the <see cref="OAuthRedirectUrl" /> call</param>
    /// <returns></returns>
    public Task<TokenResponse> TokenAsync(string code, string oAuthRedirectUrl);

    /// <summary>
    /// Refreshes the bearer token with a refresh token.
    /// </summary>
    /// <param name="refreshToken"></param>
    /// <returns></returns>
    public Task<TokenResponse> RefreshTokenAsync(string refreshToken);

    public Task<int> CurrentDivisionAsync();

    /// <summary>
    /// Gets the journals.
    /// </summary>
    /// <param name="division"></param>
    /// <returns></returns>
    public Task<IEnumerable<JournalResponse>> JournalsAsync(int division);

    /// <summary>
    /// Gets the accounts.
    /// </summary>
    /// <param name="division"></param>
    /// <param name="name"></param>
    /// <returns></returns>
    public Task<IEnumerable<AccountResponse>> AccountsAsync(int division, string? name);

    /// <summary>
    /// Gets the items.
    /// </summary>
    /// <param name="division"></param>
    /// <returns></returns>
    public Task<IEnumerable<ItemResponse>> ItemsAsync(int division);

    /// <summary>
    /// Creates a new user.
    /// </summary>
    /// <param name="division"></param>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<Guid> CreateUserAsync(int division, CreateUserRequest request);

    /// <summary>
    /// Creates a new sales invoice.
    /// </summary>
    /// <param name="division"></param>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<SalesInvoiceResponse> CreateSalesInvoiceAsync(int division, CreateSalesInvoiceRequest request);

    /// <summary>
    /// Attaches the PDF content to an Sales Invoice.
    /// </summary>
    /// <param name="division"></param>
    /// <param name="subject"></param>
    /// <param name="type"></param>
    /// <param name="fileName"></param>
    /// <param name="base64Content"></param>
    /// <param name="accountId"></param>
    /// <returns></returns>
    public Task<Guid> UploadDocumentAsync(int division, string subject, DocumentType type, string fileName, string base64Content, Guid accountId);
}