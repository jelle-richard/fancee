namespace AccountingUtils.Providers.Accounting.Exact.Exceptions;

public class ExactMissingDataException(string property)
    : Exception($"Could not get property '{property}' from the Exact response");