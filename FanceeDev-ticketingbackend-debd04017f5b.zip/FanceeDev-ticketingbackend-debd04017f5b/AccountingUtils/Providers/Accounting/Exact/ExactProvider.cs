using AccountingUtils.Config;
using AccountingUtils.Providers.Accounting.Exact.Exceptions;
using AccountingUtils.Providers.Accounting.Exact.Requests;
using AccountingUtils.Providers.Accounting.Exact.Responses;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact;

public class ExactProvider : IExactProvider
{
    public string? Token { get; private set; }

    private readonly IExactConfiguration _exactConfiguration;
    private readonly HttpClient _httpClient;

    public ExactProvider(IExactConfiguration exactConfiguration, IHttpClientFactory httpClientFactory)
    {
        _exactConfiguration = exactConfiguration;
        _httpClient = httpClientFactory.CreateClient("Exact");
    }

    public IExactProvider SetToken(string token)
    {
        Token = token;

        return this;
    }

    public string OAuthRedirectUrl(string oAuthRedirectUrl)
    {
        var request = new OAuthRedirectUrlRequest
        {
            ClientId = _exactConfiguration.ClientId,
            RedirectUri = oAuthRedirectUrl,
            ResponseType = "code",
            ForceLogin = 0
        };

        var url = $"{_exactConfiguration.BaseUrl}/oauth2/auth";

        return request.BuildUrl(url);
    }

    public async Task<TokenResponse> TokenAsync(string code, string oAuthRedirectUrl)
    {
        var request = new TokenRequest
        {
            Code = code,
            RedirectUri = oAuthRedirectUrl,
            GrantType = "authorization_code",
            ClientId = _exactConfiguration.ClientId,
            ClientSecret = _exactConfiguration.ClientSecret
        };

        return await HttpUtils.RunJsonAsync<TokenResponse>(async () =>
            await _httpClient.PostAsync("oauth2/token", request.GetHttpContent())
        );
    }

    public async Task<TokenResponse> RefreshTokenAsync(string refreshToken)
    {
        var request = new TokenRefreshRequest
        {
            RefreshToken = refreshToken,
            GrantType = "refresh_token",
            ClientId = _exactConfiguration.ClientId,
            ClientSecret = _exactConfiguration.ClientSecret
        };

        return await HttpUtils.RunJsonAsync<TokenResponse>(async () =>
            await _httpClient.PostAsync("oauth2/token", request.GetHttpContent())
        );
    }

    public async Task<int> CurrentDivisionAsync()
    {
        var request = new SelectRequest(AccountingDivisionResponse.GetRequestPropertyNames());

        var result = await HttpUtils.RunJsonAsync<BaseResponse<AccountingDivisionResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .GetAsync(request.BuildUrl("v1/current/Me"))
        );

        return result.Data.Results.FirstOrDefault()?.AccountingDivision
               ?? throw new ExactMissingDataException(nameof(AccountingDivisionResponse.AccountingDivision));
    }

    public async Task<IEnumerable<ItemResponse>> ItemsAsync(int division)
    {
        var request = new SelectRequest(ItemResponse.GetRequestPropertyNames());

        var items = await HttpUtils.RunJsonAsync<BaseResponse<ItemResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .GetAsync(request.BuildUrl($"v1/{division}/logistics/Items"))
        );

        return items.Data.Results;
    }

    public async Task<Guid> CreateUserAsync(int division, CreateUserRequest request)
    {
        var result = await HttpUtils.RunJsonAsync<BaseCreateResponse<AccountResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .PostAsync($"v1/{division}/crm/Accounts", request.GetHttpContent())
        );

        return result.Data.Id;
    }

    public async Task<SalesInvoiceResponse> CreateSalesInvoiceAsync(int division, CreateSalesInvoiceRequest request)
    {
        var result = await HttpUtils.RunJsonAsync<BaseCreateResponse<SalesInvoiceResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .PostAsync($"v1/{division}/salesinvoice/SalesInvoices", request.GetHttpContent()));

        return result.Data;
    }

    public async Task<Guid> UploadDocumentAsync(int division, string subject, DocumentType type, string fileName, string base64Content, Guid accountId)
    {
        var documentId = await CreateDocumentAsync(division, subject, (int)type, accountId);
        await CreateDocumentAttachmentAsync(division, documentId, fileName, base64Content);

        return documentId;
    }

    public async Task<IEnumerable<JournalResponse>> JournalsAsync(int division)
    {
        var request = new SelectRequest(JournalResponse.GetRequestPropertyNames());

        var journals = await HttpUtils.RunJsonAsync<BaseResponse<JournalResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .GetAsync(request.BuildUrl($"v1/{division}/financial/Journals"))
        );

        return journals.Data.Results;
    }

    public async Task<IEnumerable<AccountResponse>> AccountsAsync(int division, string? name)
    {
        var filters = new List<string>(2) { "Status eq 'C'" };

        if (!string.IsNullOrEmpty(name))
            filters.Add($"Name eq '{name}'");

        var request = new FilteredSelectRequest(
            filters.ToArray(),
            AccountResponse.GetRequestPropertyNames());

        var accounts = await HttpUtils.RunJsonAsync<BaseResponse<AccountResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .GetAsync(request.BuildUrl($"v1/{division}/crm/Accounts"))
        );

        return accounts.Data.Results;
    }

    private async Task<Guid> CreateDocumentAsync(int division, string subject, int type, Guid accountId)
    {
        var request = new CreateDocumentRequest
        {
            Subject = subject,
            Type = type,
            AccountId = accountId
        };

        var result = await HttpUtils.RunJsonAsync<BaseCreateResponse<DocumentResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .PostAsync($"v1/{division}/documents/Documents", request.GetHttpContent())
        );

        return result.Data.Id;
    }

    private async Task<DocumentAttachmentResponse> CreateDocumentAttachmentAsync(int division, Guid documentId, string fileName, string base64Content)
    {
        var request = new CreateDocumentAttachmentRequest
        {
            DocumentId = documentId,
            FileName = fileName,
            Content = base64Content
        };

        var result = await HttpUtils.RunJsonAsync<BaseCreateResponse<DocumentAttachmentResponse>>(async () =>
            await _httpClient.SetBearerToken(Token!)
                .PostAsync($"v1/{division}/documents/DocumentAttachments", request.GetHttpContent())
        );

        return result.Data;
    }
}