using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class CreateDocumentRequest : JsonPostData
{
    public string Subject { get; set; } = default!;

    public int Type { get; set; }

    [JsonPropertyName("Account")] public Guid? AccountId { get; set; }
}