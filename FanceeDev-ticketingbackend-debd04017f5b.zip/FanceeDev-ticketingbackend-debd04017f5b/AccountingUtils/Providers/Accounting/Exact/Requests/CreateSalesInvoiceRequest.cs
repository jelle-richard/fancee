using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class CreateSalesInvoiceRequest : JsonPostData
{
    public string Journal { get; set; } = default!;

    public Guid OrderedBy { get; set; }

    public IEnumerable<SalesInvoiceLine> SalesInvoiceLines { get; set; } = default!;

    public decimal? AmountDiscount { get; set; }

    public decimal? AmountDiscountExclVat { get; set; }

    public string? Currency { get; set; }

    public string? Description { get; set; }

    [JsonPropertyName("Document")] public Guid? DocumentId { get; set; }

    public DateTime OrderDate { get; set; }

    [JsonPropertyName("YourRef")] public string? PlatformInvoiceNumber { get; set; }

    public class SalesInvoiceLine
    {
        public Guid Item { get; set; }

        public string? Notes { get; set; }

        public decimal? UnitPrice { get; set; }

        public decimal? Quantity { get; set; }
    }
}