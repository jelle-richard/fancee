using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class SelectRequest : QueryData
{
    [JsonPropertyName("$select")] public string Select => string.Join(',', _fields);

    private readonly string[] _fields;

    public SelectRequest(params string[] fields)
    {
        _fields = fields;
    }
}