using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class OAuthRedirectUrlRequest : QueryData
{
    [JsonPropertyName("client_id")] public string ClientId { get; init; } = default!;

    [JsonPropertyName("redirect_uri")] public string RedirectUri { get; init; } = default!;

    [JsonPropertyName("response_type")] public string ResponseType { get; init; } = default!;

    [JsonPropertyName("force_login")] public int ForceLogin { get; init; }
}