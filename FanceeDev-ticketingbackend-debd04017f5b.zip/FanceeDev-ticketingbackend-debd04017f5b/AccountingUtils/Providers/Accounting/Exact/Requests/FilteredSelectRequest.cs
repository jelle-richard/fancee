using System.Text.Json.Serialization;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class FilteredSelectRequest : SelectRequest
{
    [JsonPropertyName("$filter")] public string Filter => string.Join($" {_concatOperator} ", _filters);

    private readonly string[] _filters;
    private readonly string _concatOperator;

    public FilteredSelectRequest(string[] filters, string[] fields, string concatOperator = "and") : base(fields)
    {
        _filters = filters;
        _concatOperator = concatOperator;
    }
}