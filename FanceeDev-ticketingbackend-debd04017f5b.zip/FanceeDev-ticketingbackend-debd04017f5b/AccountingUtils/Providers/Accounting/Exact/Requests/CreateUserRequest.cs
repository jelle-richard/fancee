using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class CreateUserRequest : JsonPostData
{
    public string Name { get; set; } = default!;

    public string Email { get; set; } = default!;

    public string? AddressLine1 { get; set; }

    public string? AddressLine2 { get; set; }

    public string? AddressLine3 { get; set; }

    public string? Country { get; set; }

    [JsonPropertyName("Postcode")] public string? PostalCode { get; set; }

    public string? City { get; set; }

    public string? Code { get; set; }

    [JsonPropertyName("Phone")] public string? PhoneNumber { get; set; }

    /// <summary>
    /// A = None
    /// S = Suspect
    /// P = Prospect
    /// C = Customer
    /// </summary>
    public string? Status { get; set; }

    [JsonPropertyName("VATNumber")] public string? VatNumber { get; set; }

    [JsonPropertyName("ChamberOfCommerce")]
    public string? ChamberOfCommerceNumber { get; set; }
}