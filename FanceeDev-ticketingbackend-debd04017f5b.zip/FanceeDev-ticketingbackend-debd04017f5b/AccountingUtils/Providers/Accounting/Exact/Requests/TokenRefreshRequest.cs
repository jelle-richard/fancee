using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class TokenRefreshRequest : UrlEncodedPostData
{
    [JsonPropertyName("refresh_token")] public string RefreshToken { get; init; } = default!;

    [JsonPropertyName("grant_type")] public string GrantType { get; init; } = default!;

    [JsonPropertyName("client_id")] public string ClientId { get; init; } = default!;

    [JsonPropertyName("client_secret")] public string ClientSecret { get; init; } = default!;
}