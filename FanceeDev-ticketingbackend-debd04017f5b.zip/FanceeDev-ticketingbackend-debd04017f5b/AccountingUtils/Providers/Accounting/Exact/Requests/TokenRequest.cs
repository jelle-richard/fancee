using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class TokenRequest : UrlEncodedPostData
{
    [JsonPropertyName("code")] public string Code { get; init; } = default!;

    [JsonPropertyName("redirect_uri")] public string RedirectUri { get; init; } = default!;

    [JsonPropertyName("grant_type")] public string GrantType { get; init; } = default!;

    [JsonPropertyName("client_id")] public string ClientId { get; init; } = default!;

    [JsonPropertyName("client_secret")] public string ClientSecret { get; init; } = default!;
}