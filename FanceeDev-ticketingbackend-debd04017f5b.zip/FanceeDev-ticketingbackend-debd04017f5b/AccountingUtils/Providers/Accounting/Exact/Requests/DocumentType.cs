namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public enum DocumentType
{
    SalesEntry = 10,
    PurchaseEntry = 20
}