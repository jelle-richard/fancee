using System.Text.Json.Serialization;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Providers.Accounting.Exact.Requests;

public class CreateDocumentAttachmentRequest : JsonPostData
{
    [JsonPropertyName("Attachment")] public string Content { get; set; } = default!;

    [JsonPropertyName("Document")] public Guid DocumentId { get; set; }

    /// <summary>
    /// Note: must include extension
    /// </summary>
    public string FileName { get; set; } = default!;
}