using AccountingUtils.Providers.Bank.Models;

namespace AccountingUtils.Providers.Bank;

public interface IBankExportProvider
{
    /// <summary>
    /// Creates a new export. Can be split into multiple output files.
    /// </summary>
    /// <param name="info"></param>
    public IList<byte[]> CreatePayoutExport(PayoutExportInfo info);
}