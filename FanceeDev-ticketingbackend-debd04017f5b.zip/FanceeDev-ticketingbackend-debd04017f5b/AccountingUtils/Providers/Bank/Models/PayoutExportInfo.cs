namespace AccountingUtils.Providers.Bank.Models;

public class PayoutExportInfo
{
    public string DebtorBankAccountHolderName { get; init; } = default!;
    public string DebtorIban { get; init; } = default!;
    public DateOnly ExecuteOn { get; init; }
    public IEnumerable<PayoutRow> Rows { get; init; } = default!;
}