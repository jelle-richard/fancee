namespace AccountingUtils.Providers.Bank.Models;

public class PayoutRow
{
    public string BankAccountHolderName { get; init; } = default!;
    public string? ReceiverIban { get; init; }
    public string? ReceiverBankAccountNumber { get; init; }
    public string? ReceiverBic { get; init; }
    public int ValueEurCents { get; init; }
    public string? Description { get; init; }
    public string? Reference { get; init; }
}