namespace AccountingUtils.Providers.Bank.Ing;

internal enum ExportFieldType
{
    DebtorName,
    DebtorIban,
    ExecuteOn,
    FirstTableRow,
    LastTableRow,
    ReceiverName,
    ReceiverIban,
    ValueEur,
    Description,
    Reference,
    TotalPayout,
    TotalTransactions
}