using AccountingUtils.Providers.Bank.Models;
using AccountingUtils.Providers.Excel;
using AccountingUtils.Resources;
using AccountingUtils.Services.Bank.Ing.Exporters;
using AccountingUtils.Utils;

namespace AccountingUtils.Providers.Bank.Ing;

/// <summary>
/// Bank export provider for the Dutch ING bank.
/// </summary>
public class IngBankExportProvider : IBankExportProvider
{
    private readonly IExcelProvider _excelProvider;

    internal IngBankExportProvider(IExcelProvider excelProvider)
    {
        _excelProvider = excelProvider;
    }

    public IList<byte[]> CreatePayoutExport(PayoutExportInfo info)
    {
        var (ibanList, bankAccountList) = Split(info);
        var bankAccountExports = new List<byte[]>(1);

        var ibanExport = ibanList.Chunk(IngPayoutExportService.MaximumRowsPerDocument)
            .Select(rc => GetPayoutExport(
                new()
                {
                    DebtorBankAccountHolderName = info.DebtorBankAccountHolderName,
                    DebtorIban = info.DebtorIban,
                    ExecuteOn = info.ExecuteOn,
                    Rows = rc
                },
                ResourceUtils.Get(ResourceNames.IngPayoutTemplate))
            )
            .ToList();

        if (bankAccountList.Any())
            bankAccountExports.Add(GetBankAccountExport(bankAccountList));

        return ibanExport
            .Concat(bankAccountExports)
            .ToList();
    }

    private byte[] GetPayoutExport(PayoutExportInfo info, Stream template)
    {
        var workbook = _excelProvider.CreateWorkbook(template);
        var worksheet = workbook.Worksheet(1);

        new IngPayoutExportService(worksheet, info).Create();

        var exportStream = new MemoryStream();
        workbook.SaveAs(exportStream);

        return exportStream.ToArray();
    }

    private byte[] GetBankAccountExport(IEnumerable<PayoutRow> rows)
    {
        var workbook = _excelProvider.CreateWorkbook();
        var worksheet = workbook.AddWorksheet();

        new IngBankAccountExportService(worksheet, rows.ToList()).Create();

        var exportStream = new MemoryStream();
        workbook.SaveAs(exportStream);

        return exportStream.ToArray();
    }

    private static (IList<PayoutRow> ibanList, IList<PayoutRow> bankAccountList) Split(PayoutExportInfo info)
    {
        var ibanList = new List<PayoutRow>();
        var bankAccountList = new List<PayoutRow>();

        foreach (var payoutRow in info.Rows)
        {
            if (string.IsNullOrEmpty(payoutRow.ReceiverIban))
                bankAccountList.Add(payoutRow);
            else
                ibanList.Add(payoutRow);
        }

        return (ibanList, bankAccountList);
    }
}