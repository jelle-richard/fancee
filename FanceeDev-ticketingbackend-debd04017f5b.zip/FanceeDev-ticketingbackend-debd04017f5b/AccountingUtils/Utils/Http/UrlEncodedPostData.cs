namespace AccountingUtils.Utils.Http;

public abstract class UrlEncodedPostData
{
    public HttpContent GetHttpContent() =>
        new FormUrlEncodedContent(ReflectionUtils.ToDictionary(this));
}