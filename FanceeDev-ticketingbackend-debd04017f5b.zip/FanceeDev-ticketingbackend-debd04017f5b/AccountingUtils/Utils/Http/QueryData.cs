using Microsoft.AspNetCore.WebUtilities;

namespace AccountingUtils.Utils.Http;

public abstract class QueryData
{
    public string BuildUrl(string baseUrl) =>
        QueryHelpers.AddQueryString(baseUrl, ReflectionUtils.ToDictionary(this));
}