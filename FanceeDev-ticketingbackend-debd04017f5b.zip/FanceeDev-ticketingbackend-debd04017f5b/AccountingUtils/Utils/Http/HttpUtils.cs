using System.Net.Http.Headers;
using System.Net.Http.Json;
using AccountingUtils.Utils.Exceptions;

namespace AccountingUtils.Utils.Http;

public static class HttpUtils
{
    /// <summary>
    /// Adds a bearer token to the authorization header.
    /// </summary>
    /// <param name="httpClient"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public static HttpClient SetBearerToken(this HttpClient httpClient, string value) =>
        httpClient.AddAuthorization("Bearer", value);

    /// <summary>
    /// Executes the request and JSON decodes the response into the <see cref="TModel"/>.
    /// </summary>
    /// <param name="call"></param>
    /// <typeparam name="TModel"></typeparam>
    /// <returns></returns>
    /// <exception cref="InvalidHttpCallException"></exception>
    public static async Task<TModel> RunJsonAsync<TModel>(Func<Task<HttpResponseMessage>> call)
    {
        HttpResponseMessage response;

        try
        {
            response = await call();
        }
        catch (Exception ex)
        {
            throw new InvalidHttpCallException(ex);
        }

        response.EnsureSuccessStatusCode();

        return await response.ParseAsync<TModel>();
    }

    /// <summary>
    /// JSON decodes the response message into the <see cref="TModel"/>.
    /// </summary>
    /// <param name="response"></param>
    /// <typeparam name="TModel"></typeparam>
    /// <returns></returns>
    /// <exception cref="InvalidJsonResponseException"></exception>
    private static async Task<TModel> ParseAsync<TModel>(this HttpResponseMessage response)
    {
        try
        {
            return await response.Content.ReadFromJsonAsync<TModel>() ?? throw new InvalidJsonResponseException(typeof(TModel).Name);
        }
        catch (Exception ex) when (ex is not InvalidJsonResponseException)
        {
            throw new InvalidJsonResponseException(ex);
        }
    }

    /// <summary>
    /// Adds an authentication scheme to the request headers.
    /// </summary>
    /// <param name="httpClient"></param>
    /// <param name="scheme"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    private static HttpClient AddAuthorization(this HttpClient httpClient, string scheme, string value)
    {
        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(scheme, value);

        return httpClient;
    }
}