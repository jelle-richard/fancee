using System.Net.Mime;
using System.Text;
using System.Text.Json;

namespace AccountingUtils.Utils.Http;

public abstract class JsonPostData
{
    public HttpContent GetHttpContent() =>
        new StringContent(JsonSerializer.Serialize(this, GetType()), Encoding.UTF8, MediaTypeNames.Application.Json);
}