namespace AccountingUtils.Utils.Exceptions;

public class InvalidHttpCallException(Exception innerException)
    : Exception("An error occured while performing a HTTP call. See inner exception for more details", innerException);