namespace AccountingUtils.Utils.Exceptions;

public class InvalidJsonResponseException : Exception
{
    public InvalidJsonResponseException(Exception? innerException) : base("The JSON is malformed", innerException)
    {
    }

    public InvalidJsonResponseException(string type) : base($"The JSON is malformed or cannot be transformed to type '{type}'")
    {
    }
}