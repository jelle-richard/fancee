using DataSynchronisationService.BackgroundTasks.MessageBus;
using DataSynchronisationService.Exceptions;
using DataSynchronisationService.Services.DataMessageStrategy;
using Fs.MessageBus.Publishers;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using WebApiCore.Dtos;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Tests.BackgroundTasks.MessageBus;

public class RequestTicketingDataListenerTests
{
    private static readonly RequestTicketingUserDataMessage Message = new()
    {
        SyncType = SynchronisationType.FetchNewlyCreated,
        RequestCreatedFrom = DateTime.UtcNow.AddDays(-20),
        RequestUpdateFor = null,
        SerializedUpdatedData = null,
        SerializedCreatedData = null
    };

    private readonly Mock<IDataMessageStrategy> _mockedClientDataMessageStrategy = new();
    private readonly Mock<IServiceScopeFactory> _mockedServiceScopeFactory = new();
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ILogger<RequestTicketingDataListener>> _mockedLogger = new();
    private readonly Mock<IMessagePublisher<IRequestTicketingDataReplyMessage>> _mockedPublisher = new();
    private readonly Mock<IMessageSubscriber<IRequestTicketingDataMessage>> _mockedSubscriber = new();
    private readonly List<IDataMessageStrategy> _messageStrategies = [];
    private readonly RequestTicketingDataListener _sut;

    public RequestTicketingDataListenerTests()
    {
        _messageStrategies.Add(_mockedClientDataMessageStrategy.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory)))
            .Returns(_mockedServiceScopeFactory.Object);

        _mockedServiceScopeFactory.Setup(ssf => ssf.CreateScope())
            .Returns(_mockedServiceScope.Object);

        _mockedServiceScope.Setup(ss => ss.ServiceProvider)
            .Returns(_mockedServiceProvider.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(ILogger<RequestTicketingDataListener>)))
            .Returns(_mockedLogger.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IEnumerable<IDataMessageStrategy>)))
            .Returns(_messageStrategies);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IMessagePublisher<IRequestTicketingDataReplyMessage>)))
            .Returns(_mockedPublisher.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IMessageSubscriber<IRequestTicketingDataMessage>)))
            .Returns(_mockedSubscriber.Object);

        _mockedClientDataMessageStrategy.Setup(cdms => cdms.Type)
            .Returns(TicketingDataType.Clients);

        _sut = new(_mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatProcessAsyncCallsStrategyAndReturnsMessage()
    {
        _mockedClientDataMessageStrategy.Setup(cdms => cdms.ExecuteAsync(Message));

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IEnumerable<IDataMessageStrategy>)))
            .Returns(_messageStrategies);

        _sut.UnitTestRegisterDependencies();
        await _sut.ProcessAsync(Message);

        _mockedClientDataMessageStrategy.Verify(cdms => cdms.ExecuteAsync(Message), Times.Once);
    }

    [Fact]
    public async Task TestThatProcessAsyncThrowsTicketingDataSynchronisationMessageNotAvailableException()
    {
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IEnumerable<IDataMessageStrategy>)))
            .Returns(_messageStrategies);

        _sut.UnitTestRegisterDependencies();
        await Assert.ThrowsAsync<TicketingDataSynchronisationMessageNotAvailableException>(() => _sut.ProcessAsync(null!));

        _mockedClientDataMessageStrategy.Verify(cdms => cdms.ExecuteAsync(null!), Times.Never);
    }

    [Fact]
    public async Task TestThatProcessAsyncThrowsUnknownStrategyRequiredForSynchronisationMessageException()
    {
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IEnumerable<IDataMessageStrategy>)))
            .Returns(new List<IDataMessageStrategy>());

        _sut.UnitTestRegisterDependencies();
        await Assert.ThrowsAsync<UnknownStrategyRequiredForSynchronisationMessageException>(() => _sut.ProcessAsync(Message));

        _mockedClientDataMessageStrategy.Verify(cdms => cdms.ExecuteAsync(Message), Times.Never);
    }
}