using EventService.Services.Shop;
using WebApiCore.BackgroundTasks;
using WebApiCore.MessageBus.Messages.ShopViews;

namespace EventService.BackgroundTasks.MessageBus;

public class CleanShopViewsCacheListener : MessageBusHostedService<CleanShopViewsInCacheMessage, CleanShopViewsCacheListener>, ISimpleMessageBus<CleanShopViewsInCacheMessage>
{
    protected override string LogPrefix => $"[{nameof(CleanShopViewsCacheListener)}]";

    private IShopService _shopService = default!;

    public CleanShopViewsCacheListener(IServiceProvider serviceProvider) : base(serviceProvider)
    {
    }

    public async Task ProcessAsync(CleanShopViewsInCacheMessage? message)
    {
        if (message == null)
            return;

        await _shopService.DeleteViewsInCacheAsync();
    }

    protected override void RegisterDependencies()
    {
        _shopService = ServiceProvider.GetRequiredService<IShopService>();
    }
}