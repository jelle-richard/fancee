using EventService.Services.Event;
using WebApiCore.BackgroundTasks;
using WebApiCore.MessageBus.Messages.Event;

namespace EventService.BackgroundTasks.MessageBus;

public class ConcludeEventsListener : MessageBusHostedService<ConcludeEventsMessage, ConcludeEventsListener>, ISimpleMessageBus<ConcludeEventsMessage>
{
    protected override string LogPrefix => $"[{nameof(ConcludeEventsListener)}]";

    private IEventsService _eventsService = default!;

    public ConcludeEventsListener(IServiceProvider serviceProvider) : base(serviceProvider)
    {
    }

    public async Task ProcessAsync(ConcludeEventsMessage? message)
    {
        await _eventsService.ConcludeAsync();
    }

    protected override void RegisterDependencies()
    {
        _eventsService = ServiceProvider.GetRequiredService<IEventsService>();
    }
}