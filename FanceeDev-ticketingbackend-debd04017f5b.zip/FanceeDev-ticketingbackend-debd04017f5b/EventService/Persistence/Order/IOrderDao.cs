using EventService.Dtos.Responses.Event;

namespace EventService.Persistence.Order;

public interface IOrderDao
{
    /// <summary>
    /// Gets the amount of orders placed for the events of the organization.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<int> TotalOrdersAsync(Guid organizationId);

    /// <summary>
    /// Gets the amount of orders placed for the events of the platform.
    /// </summary>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="countryCodes"></param>
    /// <returns></returns>
    public Task<int> TotalOrdersAsync(DateTime startDate, DateTime endDate, IEnumerable<string> countryCodes);

    /// <summary>
    /// Gets the amount of orders placed for the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<int> EventOrdersAsync(Guid eventId);

    /// <summary>
    /// Gets the average ages of all orders for the organization per gender.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<AverageAgesGenderResponse> AverageAgeByGendersAsync(Guid organizationId);

    /// <summary>
    /// Gets the average ages of all orders for the platform per gender.
    /// </summary>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="countryCodes"></param>
    /// <returns></returns>
    public Task<AverageAgesGenderResponse> AverageAgeByGendersAsync(DateTime startDate, DateTime endDate, List<string> countryCodes);

    /// <summary>
    /// Gets the average ages of the event per gender.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="eventStartDate"></param>
    /// <returns></returns>
    public Task<AverageAgesGenderResponse> AverageEventAgeByGendersAsync(Guid eventId, DateTime eventStartDate);

    /// <summary>
    /// Gets the amount of unique customers over all organization events per gender.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<UniqueCustomersGenderResponse> UniqueCustomersByGendersAsync(Guid organizationId);

    /// <summary>
    /// Gets the amount of unique customers over all platform events per gender.
    /// </summary>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="countryCodes"></param>
    /// <returns></returns>
    public Task<UniqueCustomersGenderResponse> UniqueCustomersByGendersAsync(DateTime startDate, DateTime endDate, List<string> countryCodes);

    /// <summary>
    /// Gets the amount of unique customers for the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<UniqueCustomersGenderResponse> UniqueEventCustomersByGendersAsync(Guid eventId);

    /// <summary>
    /// Gets the amount of customers per country for the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<IEnumerable<EventCustomersCountryStatisticsResponse>> CustomerCountryStatisticsAsync(Guid eventId);

    /// <summary>
    /// Gets the amount of customers per city for the event and the given country.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="countryCode"></param>
    /// <returns></returns>
    public Task<IEnumerable<EventCustomersCityStatisticsResponse>> CustomerCityStatisticsAsync(Guid eventId, string countryCode);

    /// <summary>
    /// Retrieves all orders by eventId and where not status is refused.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<List<FanceeData.Models.Ticketing.Order>> AllByEventId(Guid eventId);

    /// <summary>
    /// Retrieves all ids of orders which need to be refunded for an event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    Task<IList<Guid>> RefundableOrderIdsAsync(Guid eventId);
}