using EventService.Dtos.Responses.Event;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Utils;

namespace EventService.Persistence.Order;

public class OrderDao : IOrderDao
{
    private static readonly PaymentStatus[] MarkAsSoldPaymentStates = { PaymentStatus.Authorised };

    private static readonly PaymentStatus[] AcceptableRefundStates =
    {
        PaymentStatus.Authorised,
        PaymentStatus.Pending,
        PaymentStatus.Received,
        PaymentStatus.PartialRefund
    };

    private readonly TicketingContext _dbContext;

    public OrderDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<List<FanceeData.Models.Ticketing.Order>> AllByEventId(Guid eventId)
    {
        return await _dbContext.Orders
            .Where(o => o.IssuedProducts.Any(ip => ip.Product.EventId == eventId))
            .Where(o => o.PaymentStatus != PaymentStatus.Refused)
            .Include(o => o.ClientOrder)
            .ThenInclude(co => co.Client)
            .ThenInclude(c => c.User)
            .ThenInclude(u => u.UserContactInfo)
            .ToListAsync();
    }

    public async Task<int> TotalOrdersAsync(Guid organizationId)
    {
        return await _dbContext.Orders.Where(o => o.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.OrganizationId == organizationId)
            .Where(o => MarkAsSoldPaymentStates.Contains(o.PaymentStatus))
            .CountAsync();
    }

    public async Task<IList<Guid>> RefundableOrderIdsAsync(Guid eventId)
    {
        return await _dbContext.Orders
            .Where(o => o.IssuedProducts.Any(ip => ip.Product.EventId == eventId && ip.Product.Event.Status == EventStatus.Cancelled))
            .Where(o => AcceptableRefundStates.Contains(o.PaymentStatus))
            .Select(o => o.Id)
            .ToListAsync();
    }

    public async Task<int> TotalOrdersAsync(DateTime startDate, DateTime endDate, IEnumerable<string> countryCodes)
    {
        return await _dbContext.Orders.Where(o => o.CreatedAt > startDate)
            .Where(o => !o.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.Organization.IsDemo)
            .Where(o => countryCodes.Contains(o.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.Organization.CountryCode))
            .Where(o => o.CreatedAt < endDate)
            .CountAsync();
    }

    public async Task<int> EventOrdersAsync(Guid eventId)
    {
        return await _dbContext.Orders.Where(o => o.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId == eventId)
            .Where(o => MarkAsSoldPaymentStates.Contains(o.PaymentStatus))
            .CountAsync();
    }

    public async Task<AverageAgesGenderResponse> AverageEventAgeByGendersAsync(Guid eventId, DateTime eventStartDate)
    {
        var averageTotalBirthdateSeconds = await AverageEventClientOrderBirthdateSecondsAsync(eventId, eventStartDate);
        var averageMaleBirthdateSeconds = await AverageEventClientOrderBirthdateSecondsAsync(eventId, Gender.Male, eventStartDate);
        var averageFemaleBirthdateSeconds = await AverageEventClientOrderBirthdateSecondsAsync(eventId, Gender.Female, eventStartDate);
        var averageNeutralBirthdateSeconds = await AverageEventClientOrderBirthdateSecondsAsync(eventId, Gender.Neutral, eventStartDate);
        var averageUnknownBirthdateSeconds = await AverageEventClientOrderBirthdateSecondsAsync(eventId, null, eventStartDate);

        var averageTotalBirthdate = eventStartDate.AddSeconds(-averageTotalBirthdateSeconds);
        var averageMaleBirthdate = eventStartDate.AddSeconds(-averageMaleBirthdateSeconds);
        var averageFemaleBirthdate = eventStartDate.AddSeconds(-averageFemaleBirthdateSeconds);
        var averageNeutralBirthdate = eventStartDate.AddSeconds(-averageNeutralBirthdateSeconds);
        var averageUnknownBirthdate = eventStartDate.AddSeconds(-averageUnknownBirthdateSeconds);

        return new()
        {
            TotalAverageAge = averageTotalBirthdateSeconds == 0 ? null : averageTotalBirthdate.GetAge(eventStartDate.ToDateOnly()),
            MaleAverageAge = averageMaleBirthdateSeconds == 0 ? null : averageMaleBirthdate.GetAge(eventStartDate.ToDateOnly()),
            FemaleAverageAge = averageFemaleBirthdateSeconds == 0 ? null : averageFemaleBirthdate.GetAge(eventStartDate.ToDateOnly()),
            NeutralAverageAge = averageNeutralBirthdateSeconds == 0 ? null : averageNeutralBirthdate.GetAge(eventStartDate.ToDateOnly()),
            UnknownAverageAge = averageUnknownBirthdateSeconds == 0 ? null : averageUnknownBirthdate.GetAge(eventStartDate.ToDateOnly())
        };
    }

    public async Task<UniqueCustomersGenderResponse> UniqueEventCustomersByGendersAsync(Guid eventId) =>
        new()
        {
            UniqueMaleCustomers = await UniqueEventCustomersByGenderAsync(eventId, Gender.Male),
            UniqueFemaleCustomers = await UniqueEventCustomersByGenderAsync(eventId, Gender.Female),
            UniqueNeutralCustomers = await UniqueEventCustomersByGenderAsync(eventId, Gender.Neutral),
            UniqueUnknownCustomers = await UniqueEventCustomersByGenderAsync(eventId, null)
        };

    public async Task<IEnumerable<EventCustomersCountryStatisticsResponse>> CustomerCountryStatisticsAsync(Guid eventId)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId == eventId)
            .Where(co => !string.IsNullOrEmpty(co.Address.CountryCode))
            .GroupBy(co => co.Address.CountryCode)
            .Select(group => new EventCustomersCountryStatisticsResponse
            {
                CountryCode = group.Key,
                Amount = group.Count()
            })
            .ToListAsync();
    }

    public async Task<IEnumerable<EventCustomersCityStatisticsResponse>> CustomerCityStatisticsAsync(Guid eventId, string countryCode)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId == eventId)
            .Where(co => co.Address.CountryCode == countryCode)
            .Where(co => !string.IsNullOrEmpty(co.Address.City))
            .GroupBy(co => co.Address.City)
            .Select(group => new EventCustomersCityStatisticsResponse
            {
                City = group.Key,
                Amount = group.Count()
            })
            .ToListAsync();
    }

    public async Task<UniqueCustomersGenderResponse> UniqueCustomersByGendersAsync(Guid organizationId) =>
        new()
        {
            UniqueMaleCustomers = await UniqueCustomersByGenderAsync(organizationId, Gender.Male),
            UniqueFemaleCustomers = await UniqueCustomersByGenderAsync(organizationId, Gender.Female),
            UniqueNeutralCustomers = await UniqueCustomersByGenderAsync(organizationId, Gender.Neutral),
            UniqueUnknownCustomers = await UniqueCustomersByGenderAsync(organizationId, null)
        };

    public async Task<UniqueCustomersGenderResponse> UniqueCustomersByGendersAsync(DateTime startDate, DateTime endDate, List<string> countryCodes) =>
        new()
        {
            UniqueMaleCustomers = await UniqueCustomersByGenderAsync(startDate, endDate, Gender.Male, countryCodes),
            UniqueFemaleCustomers = await UniqueCustomersByGenderAsync(startDate, endDate, Gender.Female, countryCodes),
            UniqueNeutralCustomers = await UniqueCustomersByGenderAsync(startDate, endDate, Gender.Neutral, countryCodes),
            UniqueUnknownCustomers = await UniqueCustomersByGenderAsync(startDate, endDate, null, countryCodes)
        };

    public async Task<AverageAgesGenderResponse> AverageAgeByGendersAsync(Guid organizationId)
    {
        var now = DateTime.UtcNow;

        var averageTotalBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(organizationId, now);
        var averageMaleBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(organizationId, Gender.Male, now);
        var averageFemaleBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(organizationId, Gender.Female, now);
        var averageNeutralBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(organizationId, Gender.Neutral, now);
        var averageUnknownBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(organizationId, null, now);

        var averageTotalBirthdate = now.AddSeconds(-averageTotalBirthdateSeconds);
        var averageMaleBirthdate = now.AddSeconds(-averageMaleBirthdateSeconds);
        var averageFemaleBirthdate = now.AddSeconds(-averageFemaleBirthdateSeconds);
        var averageNeutralBirthdate = now.AddSeconds(-averageNeutralBirthdateSeconds);
        var averageUnknownBirthdate = now.AddSeconds(-averageUnknownBirthdateSeconds);

        return new()
        {
            TotalAverageAge = averageTotalBirthdateSeconds == 0 ? null : averageTotalBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            MaleAverageAge = averageMaleBirthdateSeconds == 0 ? null : averageMaleBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            FemaleAverageAge = averageFemaleBirthdateSeconds == 0 ? null : averageFemaleBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            NeutralAverageAge = averageNeutralBirthdateSeconds == 0 ? null : averageNeutralBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            UnknownAverageAge = averageUnknownBirthdateSeconds == 0 ? null : averageUnknownBirthdate.GetAge(DateTime.UtcNow.ToDateOnly())
        };
    }

    public async Task<AverageAgesGenderResponse> AverageAgeByGendersAsync(DateTime startDate, DateTime endDate, List<string> countryCodes)
    {
        var now = DateTime.UtcNow;

        var averageTotalBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(startDate, endDate, now, countryCodes);
        var averageMaleBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(startDate, endDate, Gender.Male, now, countryCodes);
        var averageFemaleBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(startDate, endDate, Gender.Female, now, countryCodes);
        var averageNeutralBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(startDate, endDate, Gender.Neutral, now, countryCodes);
        var averageUnknownBirthdateSeconds = await AverageClientOrderBirthdateSecondsAsync(startDate, endDate, null, now, countryCodes);

        var averageTotalBirthdate = now.AddSeconds(-averageTotalBirthdateSeconds);
        var averageMaleBirthdate = now.AddSeconds(-averageMaleBirthdateSeconds);
        var averageFemaleBirthdate = now.AddSeconds(-averageFemaleBirthdateSeconds);
        var averageNeutralBirthdate = now.AddSeconds(-averageNeutralBirthdateSeconds);
        var averageUnknownBirthdate = now.AddSeconds(-averageUnknownBirthdateSeconds);

        return new()
        {
            TotalAverageAge = averageTotalBirthdateSeconds == 0 ? null : averageTotalBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            MaleAverageAge = averageMaleBirthdateSeconds == 0 ? null : averageMaleBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            FemaleAverageAge = averageFemaleBirthdateSeconds == 0 ? null : averageFemaleBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            NeutralAverageAge = averageNeutralBirthdateSeconds == 0 ? null : averageNeutralBirthdate.GetAge(DateTime.UtcNow.ToDateOnly()),
            UnknownAverageAge = averageUnknownBirthdateSeconds == 0 ? null : averageUnknownBirthdate.GetAge(DateTime.UtcNow.ToDateOnly())
        };
    }

    private async Task<int> UniqueCustomersByGenderAsync(Guid organizationId, Gender? gender)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.OrganizationId == organizationId)
            .Where(co => co.Gender == gender)
            .GroupBy(co => co.ClientId)
            .CountAsync();
    }

    private async Task<int> UniqueCustomersByGenderAsync(DateTime startDate, DateTime endDate, Gender? gender, IEnumerable<string> countryCodes)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.CreatedAt > startDate)
            .Where(co => co.Order.CreatedAt < endDate)
            .Where(co => !co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.Organization.IsDemo)
            .Where(co => countryCodes.Contains(co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.Organization.CountryCode))
            .Where(co => co.Gender == gender)
            .GroupBy(co => co.ClientId)
            .CountAsync();
    }

    private async Task<int> UniqueEventCustomersByGenderAsync(Guid eventId, Gender? gender)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId == eventId)
            .Where(co => co.Gender == gender)
            .GroupBy(co => co.ClientId)
            .CountAsync();
    }

    private async Task<double> AverageClientOrderBirthdateSecondsAsync(Guid organizationId, Gender? gender, DateTime now)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.OrganizationId == organizationId)
            .Where(co => co.Gender == gender)
            .Where(co => co.Birthdate != null)
            .Select(co => (DateTime)co.Birthdate!)
            .AverageAsync(bd => TicketingContext.DateDiffSecondBig(bd, now)) ?? 0;
    }

    private async Task<double> AverageClientOrderBirthdateSecondsAsync(DateTime startDate, DateTime endDate, Gender? gender, DateTime now, IEnumerable<string> countryCodes)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.CreatedAt > startDate)
            .Where(co => co.Order.CreatedAt < endDate)
            .Where(co => co.Gender == gender)
            .Where(co => countryCodes.Contains(co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.Organization.CountryCode))
            .Where(co => co.Birthdate != null)
            .Select(co => (DateTime)co.Birthdate!)
            .AverageAsync(bd => TicketingContext.DateDiffSecondBig(bd, now)) ?? 0;
    }

    private async Task<double> AverageClientOrderBirthdateSecondsAsync(Guid organizationId, DateTime now)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.OrganizationId == organizationId)
            .Where(co => co.Birthdate != null)
            .Select(co => (DateTime)co.Birthdate!)
            .AverageAsync(bd => TicketingContext.DateDiffSecondBig(bd, now)) ?? 0;
    }

    private async Task<double> AverageClientOrderBirthdateSecondsAsync(DateTime startDate, DateTime endDate, DateTime now, IEnumerable<string> countryCodes)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.CreatedAt > startDate)
            .Where(co => co.Order.CreatedAt < endDate)
            .Where(co => co.Birthdate != null)
            .Where(co => !co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.Organization.IsDemo)
            .Where(co => countryCodes.Contains(co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.Organization.CountryCode))
            .Select(co => (DateTime)co.Birthdate!)
            .AverageAsync(bd => TicketingContext.DateDiffSecondBig(bd, now)) ?? 0;
    }

    private async Task<double> AverageEventClientOrderBirthdateSecondsAsync(Guid eventId, Gender? gender, DateTime eventStartDate)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId == eventId)
            .Where(co => co.Gender == gender)
            .Where(co => co.Birthdate != null)
            .Select(co => (DateTime)co.Birthdate!)
            .AverageAsync(bd => TicketingContext.DateDiffSecondBig(bd, eventStartDate)) ?? 0;
    }

    private async Task<double> AverageEventClientOrderBirthdateSecondsAsync(Guid eventId, DateTime eventStartDate)
    {
        return await _dbContext.ClientOrders
            .Where(co => co.Order.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId == eventId)
            .Where(co => co.Birthdate != null)
            .Select(co => (DateTime)co.Birthdate!)
            .AverageAsync(bd => TicketingContext.DateDiffSecondBig(bd, eventStartDate)) ?? 0;
    }
}