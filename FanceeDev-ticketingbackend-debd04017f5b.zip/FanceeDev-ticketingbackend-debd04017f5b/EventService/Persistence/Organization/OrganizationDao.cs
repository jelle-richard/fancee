﻿using System.Linq.Expressions;
using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using WebApiCore.Utils.Query;

namespace EventService.Persistence.Organization;

public class OrganizationDao : IOrganizationDao
{
    private readonly TicketingContext _dbContext;

    public OrganizationDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<int> DefaultReservationTimeMinutes(Guid id)
    {
        return await _dbContext.Organizations.Where(o => o.Id == id)
            .Select(o => o.DefaultReservationTimeMinutes)
            .FirstAsync();
    }
    
    public async Task<FanceeData.Models.Ticketing.Organization?> ByIdAsync(Guid organizationId, Expression<Func<IQueryable<FanceeData.Models.Ticketing.Organization>, IIncludableQueryable<FanceeData.Models.Ticketing.Organization, object>>> include)
    {
        return await _dbContext.Organizations.Where(o => o.Id == organizationId)
            .IncludeMany(include)
            .FirstOrDefaultAsync();
    }

    public async Task<IEnumerable<Guid>> ByRangeAsync(DateTime minimum, DateTime maximum, string[] countryCodes)
    {
        return await _dbContext.Organizations
            .Where(o => o.Events.Any(e => e.StartDate >= minimum && e.StartDate <= maximum))
            .Where(o => countryCodes.Contains(o.CountryCode))
            .Select(o => o.Id)
            .ToListAsync();
    }
}