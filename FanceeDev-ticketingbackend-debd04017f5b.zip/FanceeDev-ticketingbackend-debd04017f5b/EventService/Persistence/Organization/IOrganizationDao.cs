﻿using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore.Query;

namespace EventService.Persistence.Organization;

public interface IOrganizationDao
{
    /// <summary>
    /// Gets the default reservation time in minutes.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<int> DefaultReservationTimeMinutes(Guid id);

    /// <summary>
    /// Gets the organization by id.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="include"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.Organization?> ByIdAsync(Guid organizationId, Expression<Func<IQueryable<FanceeData.Models.Ticketing.Organization>, IIncludableQueryable<FanceeData.Models.Ticketing.Organization, object>>> include);

    /// <summary>
    /// Retrieves all organizations which have events in the given DateTime range.
    /// </summary>
    /// <param name="minimum"></param>
    /// <param name="maximum"></param>
    /// <param name="countryCodes"></param>
    /// <returns></returns>
    Task<IEnumerable<Guid>> ByRangeAsync(DateTime minimum, DateTime maximum, string[] countryCodes);
}