using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace EventService.Persistence.EventMedia;

public class EventMediaDao : IEventMediaDao
{
    private readonly TicketingContext _dbContext;

    public EventMediaDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task InsertAsync(FanceeData.Models.Ticketing.EventMedia model)
    {
        await _dbContext.EventMedia.AddAsync(model);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<int> NextPositionAsync(Guid eventId)
    {
        return 1 + (await _dbContext.EventMedia.Where(em => em.EventId == eventId)
            .MaxAsync(em => (int?)em.Position) ?? 0);
    }

    public async Task<bool> OwnerOfMediaAsync(Guid fileId, Guid eventId, Guid organizationId)
    {
        return await _dbContext.EventMedia.Where(em => em.FileId == fileId && em.EventId == eventId && em.Event.OrganizationId == organizationId)
            .AnyAsync();
    }

    public async Task<FanceeData.Models.Ticketing.EventMedia?> ByIdAsync(Guid fileId, Guid eventId)
    {
        return await _dbContext.EventMedia.Where(em => em.FileId == fileId && em.EventId == eventId)
            .Include(em => em.File)
            .FirstOrDefaultAsync();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.EventMedia>> ForEventAsync(Guid eventId)
    {
        return await _dbContext.EventMedia.Where(em => em.EventId == eventId)
            .ToListAsync();
    }

    public async Task DeleteAsync(FanceeData.Models.Ticketing.EventMedia eventMedia)
    {
        var file = eventMedia.File;

        _dbContext.EventMedia.Remove(eventMedia);
        _dbContext.Files.Remove(file);

        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateAsync(FanceeData.Models.Ticketing.EventMedia eventMedia)
    {
        _dbContext.EventMedia.Update(eventMedia);

        await _dbContext.SaveChangesAsync();
    }

    public async Task<int> RepositionMediaAsync(IList<FanceeData.Models.Ticketing.EventMedia> media, IList<Guid> fileIds)
    {
        foreach (var m in media)
            m.Position = fileIds.IndexOf(m.FileId) + 1;

        _dbContext.EventMedia.UpdateRange(media);

        return await _dbContext.SaveChangesAsync();
    }

    public async Task<int> RepositionMediaAsync(Guid eventId, int updateAfterPosition)
    {
        return await _dbContext.EventMedia.Where(pm => pm.EventId == eventId)
            .Where(pm => pm.Position > updateAfterPosition)
            .ExecuteUpdateAsync(q => q.SetProperty(
                    pm => pm.Position, pm => pm.Position - 1
                )
            );
    }
}