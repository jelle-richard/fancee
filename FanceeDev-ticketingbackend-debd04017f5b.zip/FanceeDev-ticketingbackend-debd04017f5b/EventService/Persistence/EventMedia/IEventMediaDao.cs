namespace EventService.Persistence.EventMedia;

public interface IEventMediaDao
{
    /// <summary>
    /// Inserts a new event media record.
    /// </summary>
    /// <param name="model"></param>
    /// <returns></returns>
    public Task InsertAsync(FanceeData.Models.Ticketing.EventMedia model);

    /// <summary>
    /// Gets the next position number. MAX(position) + 1.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<int> NextPositionAsync(Guid eventId);

    /// <summary>
    /// Checks if the given organization is the owner of the given event.
    /// </summary>
    /// <param name="fileId"></param>
    /// <param name="eventId"></param>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<bool> OwnerOfMediaAsync(Guid fileId, Guid eventId, Guid organizationId);

    /// <summary>
    /// Gets the event media by file and event id.
    /// </summary>
    /// <param name="fileId"></param>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.EventMedia?> ByIdAsync(Guid fileId, Guid eventId);

    /// <summary>
    /// Gets all event media for a event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.EventMedia>> ForEventAsync(Guid eventId);

    /// <summary>
    /// Deletes a event media record.
    /// </summary>
    /// <param name="eventMedia"></param>
    /// <returns></returns>
    public Task DeleteAsync(FanceeData.Models.Ticketing.EventMedia eventMedia);

    /// <summary>
    /// Updates a event media record.
    /// </summary>
    /// <param name="eventMedia"></param>
    /// <returns></returns>
    public Task UpdateAsync(FanceeData.Models.Ticketing.EventMedia eventMedia);

    /// <summary>
    /// Repositions event media.
    /// </summary>
    /// <param name="media"></param>
    /// <param name="fileIds"></param>
    /// <returns></returns>
    public Task<int> RepositionMediaAsync(IList<FanceeData.Models.Ticketing.EventMedia> media, IList<Guid> fileIds);

    /// <summary>
    /// Repositions all event media after <see cref="updateAfterPosition" /> by decreasing them by one.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="updateAfterPosition"></param>
    /// <returns></returns>
    public Task<int> RepositionMediaAsync(Guid eventId, int updateAfterPosition);
}