﻿using FanceeData.Models.Ticketing;

namespace EventService.Persistence.PaymentMethod;

public interface IPaymentMethodDao
{
    /// <summary>
    /// Gets all the payment methods that are available for the given event.
    /// Enum indicates who should pay for the associated costs (null if no payment methods are configured for the event).
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<IEnumerable<(FanceeData.Models.Ticketing.PaymentMethod, PaidBy?)>> AvailablePaymentMethodsAsync(Guid eventId);
}