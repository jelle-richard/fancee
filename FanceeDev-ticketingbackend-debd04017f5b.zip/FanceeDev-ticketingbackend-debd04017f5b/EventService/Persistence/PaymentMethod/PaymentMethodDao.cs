﻿using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace EventService.Persistence.PaymentMethod;

public class PaymentMethodDao : IPaymentMethodDao
{
    private static readonly string[] ExcludedPaymentMethodBrandCodes = ["cash", "pin"];
    private readonly TicketingContext _dbContext;

    public PaymentMethodDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<(FanceeData.Models.Ticketing.PaymentMethod, PaidBy?)>> AvailablePaymentMethodsAsync(Guid eventId)
    {
        return await _dbContext.PaymentMethods.Where(pm => pm.Active)
            .Where(pm => !ExcludedPaymentMethodBrandCodes.Contains(pm.BrandCode))
            .OrderBy(pm => pm.Order)
            .Select(pm => new ValueTuple<FanceeData.Models.Ticketing.PaymentMethod, PaidBy?>(
                pm,
                pm.Events.Where(e => e.EventId == eventId)
                    .Where(e => e.PaymentMethodId == pm.Id)
                    .Select(e => (PaidBy?)e.PaidBy)
                    .FirstOrDefault()
            ))
            .ToListAsync();
    }
}