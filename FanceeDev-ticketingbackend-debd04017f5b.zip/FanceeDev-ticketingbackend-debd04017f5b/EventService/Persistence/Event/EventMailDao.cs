using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace EventService.Persistence.Event;

public class EventMailDao : IEventMailDao
{
    private readonly TicketingContext _dbContext;

    public EventMailDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task AddOrUpdateAsync(EventMail eventMail)
    {
        var exists = await _dbContext.EventMails.AnyAsync(sm => sm.EventId == eventMail.EventId && sm.Type == eventMail.Type);

        if (exists)
            _dbContext.EventMails.Update(eventMail);
        else
            await _dbContext.EventMails.AddAsync(eventMail);

        await _dbContext.SaveChangesAsync();
    }

    public async Task<EventMail?> GetAsync(Guid eventId, EventMailType type)
    {
        return await _dbContext.EventMails.Where(em => em.EventId == eventId)
            .Where(em => em.Type == type)
            .FirstOrDefaultAsync();
    }
}