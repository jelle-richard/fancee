using FanceeData.Models.Ticketing;

namespace EventService.Persistence.Event;

public interface IEventMailDao
{
    /// <summary>
    /// Adds or updates the shop mail.
    /// </summary>
    /// <param name="eventMail"></param>
    /// <returns></returns>
    public Task AddOrUpdateAsync(EventMail eventMail);

    /// <summary>
    /// Gets an event mail by the event id and mail type.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="type"></param>
    /// <returns></returns>
    public Task<EventMail?> GetAsync(Guid eventId, EventMailType type);
}