using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace EventService.Persistence.Event;

public class EventCancellationDao : IEventCancellationDao
{
    private readonly TicketingContext _dbContext;

    public EventCancellationDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task AddAsync(EventCancellation eventCancellation)
    {
        await _dbContext.EventCancellations.AddAsync(eventCancellation);
        await _dbContext.SaveChangesAsync();
    }
    
    public async Task<EventCancellation?> GetAsync(Guid id) => await _dbContext.EventCancellations
        .Include(ec => ec.Event)
        .Include(ec => ec.Organization)
        .ThenInclude(o => o.User)
        .ThenInclude(u => u.UserContactInfo)
        .FirstOrDefaultAsync(ec => ec.Id == id);
}