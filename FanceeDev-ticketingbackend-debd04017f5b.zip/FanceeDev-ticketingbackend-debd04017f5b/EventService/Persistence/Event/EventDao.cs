using System.Linq.Expressions;
using EventService.Dtos.Responses.Event;
using EventService.Dtos.Responses.Events;
using EventService.Dtos.Shared.Event;
using EventService.Persistence.Shop;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Persistence;
using WebApiCore.Dtos.Responses.File;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Contract;
using WebApiCore.Utils;
using WebApiCore.Utils.Query;

namespace EventService.Persistence.Event;

public class EventDao : IEventDao
{
    private static readonly PaymentStatus[] MarkAsSoldPaymentStates = [PaymentStatus.Authorised, PaymentStatus.PartialRefund, PaymentStatus.Refund];

    private readonly TicketingContext _dbContext;
    private readonly IShopDao _shopDao;

    public EventDao(TicketingContext dbContext, IShopDao shopDao)
    {
        _dbContext = dbContext;
        _shopDao = shopDao;
    }

    public async Task InsertAsync(FanceeData.Models.Ticketing.Event @event)
    {
        foreach (var category in @event.Categories)
            _dbContext.SetEntityState(category, EntityState.Unchanged);

        var paymentMethods = @event.PaymentMethods.ToList();
        @event.PaymentMethods = new List<EventPaymentMethod>();

        await _dbContext.Events.AddAsync(@event);
        await _dbContext.SaveChangesAsync();

        foreach (var paymentMethod in paymentMethods)
        {
            paymentMethod.EventId = @event.Id;
            paymentMethod.Event = null;
        }

        await _dbContext.EventsPaymentMethods.AddRangeAsync(paymentMethods);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<PaginatedResultSet<EventListItemResponse>> ListAsync(int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes, HostedDeploymentEnvironment env)
    {
        var query = _dbContext.Events
            .Where(e => !e.Organization.IsDemo);

        return await ListEventItemsAsync(query, limit, offset, searchQuery, minimumStartDate, maximumStartDate, eventStates, countryCodes, Array.Empty<string>(), env);
    }

    public async Task<PaginatedResultSet<EventListItemResponse>> ListAsync(Guid organizationId, int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes, HostedDeploymentEnvironment env)
    {
        var query = _dbContext.Events
            .Where(e => e.OrganizationId == organizationId);

        return await ListEventItemsAsync(query, limit, offset, searchQuery, minimumStartDate, maximumStartDate, eventStates, countryCodes, Array.Empty<string>(), env);
    }

    public async Task<IEnumerable<SelectOption<Guid>>> ListSelectOptionsAsync(Guid? organizationId, IList<Guid> eventIds, string? searchQuery)
    {
        return await _dbContext.Events.Where(e => organizationId == null || e.OrganizationId == organizationId)
            .Where(e => !eventIds.Any() || eventIds.Contains(e.Id))
            .Where(e => searchQuery == null || e.Name.Contains(searchQuery))
            .OrderByDescending(e => e.StartDate)
            .Take(SelectOption<Guid>.ListLimit)
            .Select(e => new SelectOption<Guid>
            {
                Id = e.Id,
                Label = e.Name,
                Note = organizationId == null
                    ? e.Organization.Name
                    : e.StartDate.ToString(DateFormat.DefaultApiResponse)
            })
            .ToListAsync();
    }

    public async Task<PaginatedResultSet<EventListItemResponse>> ListByAppTeamAsync(Guid appTeamId, int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, HostedDeploymentEnvironment env)
    {
        var products = await _dbContext.AppTeams.Where(at => at.Id == appTeamId)
            .SelectMany(at => at.Products)
            .ToListAsync();

        var query = _dbContext.Events.Where(e => products.Select(p => p.EventId).Contains(e.Id));

        return await ListEventItemsAsync(query, limit, offset, searchQuery, minimumStartDate, maximumStartDate, eventStates, Array.Empty<string>(), Array.Empty<string>(), env);
    }

    public async Task<FanceeData.Models.Ticketing.Event?> GetEventAsync(Guid eventId, Guid organizationId, Expression<Func<IQueryable<FanceeData.Models.Ticketing.Event>, IIncludableQueryable<FanceeData.Models.Ticketing.Event, object>>>? include)
    {
        return await _dbContext.Events.Where(e => e.Id == eventId && e.OrganizationId == organizationId)
            .IncludeMany(include)
            .FirstOrDefaultAsync();
    }

    public async Task UpdateAsync(FanceeData.Models.Ticketing.Event @event)
    {
        _dbContext.Entry(@event)?.DetectChanges();
        _dbContext.Events.Update(@event);

        await _dbContext.SaveChangesAsync();
    }

    public async Task<int> UpdateStatusAsync(Guid id, EventStatus status)
    {
        return await _dbContext.Events
            .Where(e => e.Id == id)
            .ExecuteUpdateAsync(q =>
                q.SetProperty(e => e.Status, e => status)
            );
    }

    public async Task DeleteAsync(Guid eventId)
    {
        var eventEntity = await _dbContext.Events.Where(e => e.Id == eventId)
            .Include(e => e.Shops)
            .ThenInclude(s => s.ItemsInShop)
            .Include(e => e.Shops)
            .ThenInclude(s => s.ItemsInShop)
            .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
            .ThenInclude(e => e.ShopElement)
            .Include(e => e.Shops)
            .ThenInclude(s => s.ShopFieldRequirements)
            .FirstAsync();

        foreach (var shop in eventEntity.Shops)
        {
            await _shopDao.DeleteItemsInShopAsync(shop);
            _dbContext.ShopFieldRequirements.RemoveRange(shop.ShopFieldRequirements);
        }

        _dbContext.Events.Remove(eventEntity);

        await _dbContext.SaveChangesAsync();
    }

    public async Task<FanceeData.Models.Ticketing.Event?> CopyableEventAsync(Guid eventId, bool copyShops, bool copyProducts, bool copyPaymentMethods, bool copyCategories, bool copyTags, bool copyMedia)
    {
        var query = _dbContext.Events.Include(e => e.Address)
            .Where(e => e.Id == eventId);

        if (copyShops)
        {
            query = query.Include(e => e.Shops)
                .ThenInclude(s => s.ShopDesign)
                .ThenInclude(sd => sd.HeaderMedia)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ShopQueue)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ShopFieldRequirements);
        }

        if (copyProducts)
        {
            query = query
                .Include(e => e.Products)
                .ThenInclude(p => p.TicketOption)
                .ThenInclude(to => to.Design)
                .ThenInclude(d => d.DesignElements)
                .ThenInclude(de => ((TicketDesignQrElement)de).File);

            query = query
                .Include(e => e.Products)
                .ThenInclude(p => p.TicketOption)
                .ThenInclude(to => to.Design)
                .ThenInclude(d => d.DesignElements)
                .ThenInclude(de => ((TicketDesignMediaElement)de).File);

            query = query
                .Include(e => e.Products)
                .ThenInclude(pm => pm.ProductMedia);
        }

        if (copyShops && copyProducts)
        {
            query = query.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => iis.ShopElement)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => iis.Product)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement);
        }

        if (copyPaymentMethods)
            query = query.Include(e => e.PaymentMethods);

        if (copyCategories)
            query = query.Include(e => e.Categories);

        if (copyTags)
            query = query.Include(e => e.Tags);

        if (copyMedia)
            query = query.Include(e => e.EventMedia);

        return await query.AsNoTrackingWithIdentityResolution()
            .FirstOrDefaultAsync();
    }

    public async Task<IEnumerable<AgendaEventResponse>> EventsAgendaAsync(DateTime startDate, DateTime endDate, IEnumerable<string> allowedCountries, HostedDeploymentEnvironment env)
    {
        return await _dbContext.Events.Where(e => e.StartDate >= startDate)
            .Where(e => e.StartDate <= endDate)
            .Where(e => !e.Organization.IsDemo)
            .Where(e => allowedCountries.Contains(e.Organization.CountryCode))
            .Select(e => new AgendaEventResponse
            {
                Id = e.Id,
                Organization = new()
                {
                    Avatar = e.Organization.User.UserMedia == null || e.Organization.User.UserMedia.File == null
                        ? null
                        : new FileResponse
                        {
                            Id = e.Organization.User.UserMedia.File.Id,
                            Url = $"{env.Scheme}://{env.ContentDeliveryNetworkBaseUrl}/{e.Organization.User.UserMedia.File.Path}",
                            MimeType = e.Organization.User.UserMedia.File.MimeType,
                            OriginalFileName = e.Organization.User.UserMedia.File.OriginalFileName
                        },
                    Name = $"{e.Organization.User.UserContactInfo.FirstName} {e.Organization.User.UserContactInfo.LastName}"
                },
                Name = e.Name,
                StartDate = e.StartDate,
                EndDate = e.EndDate,
                ShopCodes = new(e.Shops.Select(s => new KeyValuePair<string, string>(s.Name, s.Code))),
                Type = e.Type,
                Status = e.Status == EventStatus.Active && e.EndDate < DateTime.UtcNow ? EventStatus.Concluded : e.Status
            })
            .ToListAsync();
    }

    public async Task<DateTime?> StartDateAsync(Guid eventId)
    {
        return await _dbContext.Events.Where(e => e.Id == eventId)
            .Select(e => (DateTime?)e.StartDate)
            .FirstOrDefaultAsync();
    }

    public async Task<RevenueResponse> EventRevenuesAsync(Guid eventId, IList<MappedOrganizationContractFee> contractFees)
    {
        var query = _dbContext.Orders.Where(o => o.ReservationReferenceNavigation.ReservedProducts.First().Product.EventId == eventId);
        var response = await RevenueFromQueryAsync(query);

        if (response == null)
            return new();

        response.PlatformExpensesCents += await EventPlatformCostsAsync(eventId, contractFees);

        return response;
    }

    public async Task<RevenueResponse> RevenuesAsync(Guid organizationId, IList<ContractFee> contractFees)
    {
        var query = _dbContext.Orders.Where(o => o.ReservationReferenceNavigation.ReservedProducts.First().Product.Event.OrganizationId == organizationId);
        var response = await RevenueFromQueryAsync(query);

        if (response == null)
            return new();

        response.PlatformExpensesCents += await PlatformCostsAsync(organizationId, contractFees);

        return response;
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Event>> UpcomingEventProductsAsync(Guid organizationId)
    {
        return await _dbContext.Events.Where(e => e.OrganizationId == organizationId)
            .Where(e => e.StartDate > DateTime.UtcNow)
            .Where(e => e.Status != EventStatus.Cancelled)
            .Where(e => e.Products.Count > 0)
            .Include(e => e.Products)
            .ToListAsync();
    }

    public async Task<int> ConcludeAsync()
    {
        var excludedEventStatuses = new[]
        {
            EventStatus.Concluded,
            EventStatus.Cancelled,
            EventStatus.Unpublished
        };

        return await _dbContext.Events.Where(e => DateTime.UtcNow >= e.EndDate)
            .Where(e => !excludedEventStatuses.Contains(e.Status))
            .ExecuteUpdateAsync(s =>
                s.SetProperty(u => u.Status, EventStatus.Concluded)
            );
    }

    public async Task<IEnumerable<EventExportItemResponse>> OrganizationEventExportItemsResponseAsync(Guid organizationId, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates)
    {
        var query = _dbContext.Events.Where(e => e.OrganizationId == organizationId);

        return await BuildEventExportItemsResponseAsync(query, searchQuery, minimumStartDate, maximumStartDate, eventStates, Enumerable.Empty<string>());
    }

    public async Task<IEnumerable<EventExportItemResponse>> PlatformEventExportItemsResponseAsync(string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes)
    {
        var query = _dbContext.Events
            .Where(e => !e.Organization.IsDemo);

        return await BuildEventExportItemsResponseAsync(query, searchQuery, minimumStartDate, maximumStartDate, eventStates, countryCodes);
    }

    public async Task<IEnumerable<EventExportItemResponse>> PlatformEventExportItemsResponseAsync(Guid organizationId, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes)
    {
        var query = _dbContext.Events
            .Where(e => !e.Organization.IsDemo)
            .Where(e => e.OrganizationId == organizationId);

        return await BuildEventExportItemsResponseAsync(query, searchQuery, minimumStartDate, maximumStartDate, eventStates, countryCodes);
    }

    public async Task<List<EventBalance>> BalanceMutationsAsync(List<MappedOrganizationContractFee> contractFees, string? searchQuery)
    {
        var balances = new List<EventBalance>();

        foreach (var contract in contractFees)
        {
            var query = _dbContext.Events.AsQueryable();

            var newMaximumDate = DateTimeUtils.Min(contract.PeriodEnd, DateTime.UtcNow);
            query = query.Where(e => e.OrganizationId == contract.OrganizationId);

            if (!string.IsNullOrWhiteSpace(searchQuery))
                query = query.Where(e => e.Name.Contains(searchQuery));

            query = query.Where(e => e.Products.Any(p =>
                p.IssuedProducts.Any(i =>
                    i.CreatedOn > contract.PeriodStart && i.CreatedOn <= newMaximumDate)));

            var eventBalances = await query.Select(e => new EventBalance
            {
                EventId = e.Id,
                Status = e.Status,
                StartDate = e.StartDate,
                EndDate = e.EndDate,
                EventName = e.Name,
                UserId = e.Organization.UserId,
                UserEmail = e.Organization.User.Email,
                CountryCode = e.Organization.CountryCode,
                OrganizationCurrency = e.Organization.CurrencyNavigation
            }).ToListAsync();

            foreach (var balance in eventBalances)
                await CalculateEventBalanceAsync(balance, query, contract, newMaximumDate);

            balances.AddRange(eventBalances);
        }

        MergeMultipleEventBalanceOccurrences(balances);
        return balances;
    }

    public async Task<bool> CancelableAsync(Guid eventId) =>
        await _dbContext.Events
            .Where(e => e.Id == eventId)
            .AnyAsync(e => e.StartDate > DateTime.UtcNow && e.Status != EventStatus.Cancelled);

    public async Task<EventResponse?> GetAsync(Guid eventId, Guid organizationId, HostedDeploymentEnvironment env)
    {
        return await _dbContext.Events.Where(e => e.Id == eventId && e.OrganizationId == organizationId)
            .Select(e => new EventResponse
            {
                Id = e.Id,
                SeatsIoEventId = e.SeatsIoEventId,
                Name = e.Name,
                StartDate = e.StartDate,
                EndDate = e.EndDate,
                Description = e.Description,
                Categories = e.Categories.Select(ec => ec.Name).ToArray(),
                Type = e.Type,
                Tags = e.Tags.Select(t => t.Name).ToArray(),
                MinAge = e.MinimumAge,
                Address = e.AddressId == null
                    ? null
                    : new AddressResponse
                    {
                        Venue = e.Address.Venue,
                        CountryCode = e.Address.CountryCode,
                        PostalCode = e.Address.PostalCode,
                        Street = e.Address.Street,
                        City = e.Address.City,
                        HouseNumber = e.Address.HouseNumber,
                        Latitude = e.Address.Latitude,
                        Longitude = e.Address.Longitude
                    },
                Status = e.Status == EventStatus.Active && e.EndDate < DateTime.UtcNow ? EventStatus.Concluded : e.Status,
                HeaderMedia = e.EventMedia.OrderBy(em => em.Position)
                    .Select(em => new ImageFileResponse
                    {
                        Id = em.File.Id,
                        Url = $"{env.Scheme}://{env.ContentDeliveryNetworkBaseUrl}/{em.File.Path}",
                        MimeType = em.File.MimeType,
                        OriginalFileName = em.File.OriginalFileName,
                        FocalPointHeightPercentage = em.FocalPointHeightPercentage,
                        FocalPointWidthPercentage = em.FocalPointWidthPercentage
                    }),
                TimezoneIdentification = e.TimezoneIdentification,
                IsSealed = e.IsSealed
            })
            .FirstOrDefaultAsync();
    }

    public async Task<PaginatedResultSet<EventListItemResponse>> ListAsync(Guid organizationId, int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, HostedDeploymentEnvironment env)
    {
        var query = _dbContext.Events.Where(e => e.OrganizationId == organizationId);

        return await ListEventItemsAsync(query, limit, offset, searchQuery, minimumStartDate, maximumStartDate, eventStates, Array.Empty<string>(), Array.Empty<string>(), env);
    }

    private static async Task<RevenueResponse?> RevenueFromQueryAsync(IQueryable<FanceeData.Models.Ticketing.Order> query)
    {
        return await query
            .Where(o => MarkAsSoldPaymentStates.Contains(o.PaymentStatus))
            .Where(o => o.TotalCostCents != null)
            .GroupBy(o => true)
            .Select(o => new RevenueResponse
            {
                PlatformExpensesCents = o.Where(o2 => o2.PaymentMethod.BrandCode != "cash").Sum(o2 => o2.PaymentFeeCents) ?? 0,
                OnlineSalesRevenueCents = o.Where(o2 => o2.PaymentMethod.BrandCode != "cash").Sum(o2 => o2.TotalCostCents) ?? 0,
                CashSalesRevenueCents = o.Where(o2 => o2.PaymentMethod.BrandCode == "cash").Sum(o2 => o2.TotalCostCents) ?? 0
            })
            .FirstOrDefaultAsync();
    }

    private static void MergeMultipleEventBalanceOccurrences(List<EventBalance> balances)
    {
        var mergedEvents = balances.GroupBy(b => b.EventId)
            .Where(g => g.Count() > 1)
            .Select(g => new EventBalance
            {
                EventId = g.Key,
                EventName = g.First().EventName,
                UserId = g.First().UserId,
                UserEmail = g.First().UserEmail,
                CountryCode = g.First().CountryCode,
                TotalAmountOfTicketFeeCentsReceived = g.Sum(b => b.TotalAmountOfTicketFeeCentsReceived),
                TotalAmountOfOrderTotalCostsCentsReceived = g.Sum(b => b.TotalAmountOfOrderTotalCostsCentsReceived),
                TotalAmountOfIssuedTickets = g.Sum(b => b.TotalAmountOfIssuedTickets),
                TotalAmountOfPaymentFeeCentsReceived = g.Sum(b => b.TotalAmountOfPaymentFeeCentsReceived),
                TotalAmountOfScannedTickets = g.Sum(b => b.TotalAmountOfScannedTickets),
                OrganizationCurrency = g.First().OrganizationCurrency
            }).ToList();

        foreach (var mergedEvent in mergedEvents)
        {
            balances.RemoveAll(b => b.EventId == mergedEvent.EventId);
            balances.Add(mergedEvent);
        }
    }

    private async Task CalculateEventBalanceAsync(EventBalance balance, IQueryable<FanceeData.Models.Ticketing.Event> query, ContractFee contractFee, DateTime maximumDate)
    {
        var tickets = query
            .SelectMany(e => e.Products
                .Where(p => p.Type == ProductType.Ticket || p.Type == ProductType.SeatedTicket)
                .Where(p => p.EventId == balance.EventId))
            .SelectMany(p => p.IssuedProducts)
            .Where(ip => ip.CreatedOn > contractFee.PeriodStart && ip.CreatedOn <= maximumDate);

        balance.TotalAmountOfScannedTickets = await tickets
            .Where(ip => ip.IssuedTicket.TicketScans != null)
            .Where(ip => ip.IssuedTicket.TicketScans.Any(ts => ts.State == ScanState.Scanned))
            .CountAsync();

        balance.TotalAmountOfIssuedTickets = await tickets.CountAsync();

        balance.TotalAmountOfTicketFeeCentsReceived = await tickets
            .Where(ip => ip.Product.Type == ProductType.Ticket)
            .Where(ip => ip.Order != null)
            .Where(ip => ip.Order.PaymentStatus == PaymentStatus.Authorised)
            .SumAsync(ip => contractFee.TicketFeeCents);

        balance.TotalAmountOfTicketFeeCentsReceived += (await _dbContext.Orders
                .Where(o => o.PaymentStatus == PaymentStatus.Authorised)
                .Where(o => o.CreatedAt > contractFee.PeriodStart && o.CreatedAt <= maximumDate)
                .SelectMany(o => o.ReservationReferenceNavigation.ReservedProducts.Where(rp => rp.Product.Type == ProductType.Ticket))
                .Select(rp => new
                    {
                        HistoryPricing = rp.Product.PriceHistories
                            .Where(pph => pph.Date < rp.ReservationReferenceNavigation.OrderReference.CreatedAt)
                            .OrderByDescending(pph => pph.Date)
                            .FirstOrDefault(),
                        HasPriceHistoryAfterOrder = rp.Product.PriceHistories.Any(pph => pph.Date > rp.ReservationReferenceNavigation.OrderReference.CreatedAt),
                        ProductPricing = rp.Product.PriceCents ?? 0 + (rp.Product.FeeCents ?? 0),
                        rp.Product.PackQuantity,
                        rp.Quantity
                    }
                ).ToListAsync()
            )
            .Sum(i => (int)Math.Round(
                (i.HasPriceHistoryAfterOrder
                    ? (i.HistoryPricing?.FeeCents ?? 0) + (i.HistoryPricing?.PriceCents ?? 0) * i.Quantity * i.PackQuantity / 100m * contractFee.TicketFeePercentage
                    : i.ProductPricing / 100m * contractFee.TicketFeePercentage) * i.Quantity * i.PackQuantity
            ));

        balance.TotalAmountOfSeatedTicketFeeCentsReceived = await tickets
            .Where(ip => ip.Product.Type == ProductType.SeatedTicket)
            .Where(ip => ip.Order != null)
            .Where(ip => ip.Order.PaymentStatus == PaymentStatus.Authorised)
            .SumAsync(ip => contractFee.SeatedTicketFeeCents);

        balance.TotalAmountOfSeatedTicketFeeCentsReceived += (await _dbContext.Orders
                .Where(o => o.PaymentStatus == PaymentStatus.Authorised)
                .Where(o => o.CreatedAt > contractFee.PeriodStart && o.CreatedAt <= maximumDate)
                .SelectMany(o => o.ReservationReferenceNavigation.ReservedProducts.Where(rp => rp.Product.Type == ProductType.SeatedTicket))
                .Select(rp => new
                    {
                        HistoryPricing = rp.Product.PriceHistories
                            .Where(pph => pph.Date < rp.ReservationReferenceNavigation.OrderReference.CreatedAt)
                            .OrderByDescending(pph => pph.Date)
                            .FirstOrDefault(),
                        HasPriceHistoryAfterOrder = rp.Product.PriceHistories.Any(pph => pph.Date > rp.ReservationReferenceNavigation.OrderReference.CreatedAt),
                        ProductPricing = rp.Product.PriceCents ?? 0 + (rp.Product.FeeCents ?? 0),
                        rp.Product.PackQuantity,
                        rp.Quantity
                    }
                ).ToListAsync()
            )
            .Sum(i => (int)Math.Round(
                (i.HasPriceHistoryAfterOrder
                    ? (i.HistoryPricing?.FeeCents ?? 0) + (i.HistoryPricing?.PriceCents ?? 0) * i.Quantity * i.PackQuantity / 100m * contractFee.SeatedTicketFeePercentage
                    : i.ProductPricing / 100m * contractFee.SeatedTicketFeePercentage) * i.Quantity * i.PackQuantity
            ));

        balance.TotalAmountOfGuestListFeeCentsReceived = await tickets
            .Where(ip => ip.Type == IssuedProductType.GuestTicket)
            .SumAsync(ip => contractFee.GuestListFeeCents);

        balance.TotalAmountOfPaymentFeeCentsReceived = await tickets
            .Where(ip => ip.OrderId != null)
            .Where(ip => ip.Order.PaymentStatus == PaymentStatus.Authorised)
            .GroupBy(ip => ip.OrderId)
            .Select(g => g.First().Order.PaymentFeeCents ?? 0)
            .SumAsync();

        balance.TotalAmountOfOrderTotalCostsCentsReceived = await tickets
            .Where(ip => ip.OrderId != null)
            .Where(ip => ip.Order.PaymentStatus == PaymentStatus.Authorised)
            .GroupBy(ip => ip.OrderId)
            .Select(g => g.First().Order.TotalCostCents ?? 0)
            .SumAsync();

        var clientOrders = await tickets
            .Where(ip => ip.OrderId != null)
            .Where(ip => ip.Order.PaymentStatus == PaymentStatus.Authorised)
            .Where(ip => ip.Order.ClientOrder != null)
            .Select(ip => ip.Order.ClientOrder)
            .ToListAsync();

        balance.TotalAmountOfTicketPlusCostsCentsReceived = clientOrders
            .DistinctBy(ip => ip.OrderId)
            .Sum(ip => ip.TicketServicePlusCostCents);
    }

    private static async Task<PaginatedResultSet<EventListItemResponse>> ListEventItemsAsync(IQueryable<FanceeData.Models.Ticketing.Event> query, int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes, string[] shopCodes, HostedDeploymentEnvironment env)
    {
        query = ApplyQueryFilters(query, searchQuery, minimumStartDate, maximumStartDate, eventStates, countryCodes);
        query = query.OrderBy(e => e.StartDate);

        var totalCount = await query.CountAsync();
        var items = await query.Skip(offset)
            .Take(limit)
            .Select(e => new EventListItemResponse
            {
                Id = e.Id,
                SeatsIoEventId = e.SeatsIoEventId,
                Organization = new()
                {
                    Avatar = e.Organization.User.UserMedia == null || e.Organization.User.UserMedia.File == null
                        ? null
                        : new FileResponse
                        {
                            Id = e.Organization.User.UserMedia.File.Id,
                            Url = $"{env.Scheme}://{env.ContentDeliveryNetworkBaseUrl}/{e.Organization.User.UserMedia.File.Path}",
                            MimeType = e.Organization.User.UserMedia.File.MimeType,
                            OriginalFileName = e.Organization.User.UserMedia.File.OriginalFileName
                        },
                    Name = $"{e.Organization.User.UserContactInfo.FirstName} {e.Organization.User.UserContactInfo.LastName}"
                },
                Name = e.Name,
                Date = e.StartDate,
                Shops = e.Shops.Where(s => !shopCodes.Any() || shopCodes.Contains(s.Code)).Select(s => new EventListShopItemResponse
                {
                    Code = s.Code,
                    Name = s.Name,
                    Active = s.Active && s.EndDate > DateTime.UtcNow && s.ItemsInShop.Any() && e.Status == EventStatus.Active && e.EndDate > DateTime.UtcNow && e.PaymentMethods.Any(),
                    IsSecuredUntil = s.IsSecuredUntil,
                    HeaderMedia = s.ShopDesign.HeaderMedia
                        .OrderBy(hm => hm.Position)
                        .Select(pm => new ImageFileResponse
                        {
                            Id = pm.File.Id,
                            Url = $"{env.Scheme}://{env.ContentDeliveryNetworkBaseUrl}/{pm.File.Path}",
                            MimeType = pm.File.MimeType,
                            OriginalFileName = pm.File.OriginalFileName,
                            FocalPointHeightPercentage = pm.FocalPointHeightPercentage,
                            FocalPointWidthPercentage = pm.FocalPointWidthPercentage
                        }),
                    Tags = s.Tags.Select(t => t.Name).ToArray(),
                    Securable = !s.SharedShops.Any()
                }),
                Type = e.Type,
                Tags = e.Tags.Select(t => t.Name).ToArray(),
                Status = e.Status == EventStatus.Active && e.EndDate < DateTime.UtcNow ? EventStatus.Concluded : e.Status,
                Deletable = !e.Products.Any(p => p.ReservedProducts.Any() || p.IssuedProducts.Any())
            })
            .ToListAsync();

        return new()
        {
            TotalItems = totalCount,
            Items = items
        };
    }

    private static IQueryable<FanceeData.Models.Ticketing.Event> ApplyQueryFilters(IQueryable<FanceeData.Models.Ticketing.Event> query, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes)
    {
        if (!string.IsNullOrWhiteSpace(searchQuery))
        {
            query = query.Where(e =>
                e.Name.Contains(searchQuery) ||
                e.Organization.Name.Contains(searchQuery));
        }

        if (minimumStartDate != null)
            query = query.Where(e => e.EndDate >= minimumStartDate);

        if (maximumStartDate != null)
            query = query.Where(e => e.StartDate <= maximumStartDate);

        eventStates = eventStates?.ToArray();
        if (eventStates?.Any() ?? false)
        {
            query = query.Where(e => eventStates.Contains(e.Status));

            if (eventStates.Contains(EventStatus.Active))
                query = query.Where(e => e.Status != EventStatus.Active || e.EndDate > DateTime.UtcNow);
        }

        countryCodes = countryCodes.ToList();
        if (countryCodes.Any())
            query = query.Where(e => countryCodes.Contains(e.Organization.CountryCode));

        return query;
    }

    private static async Task<IEnumerable<EventExportItemResponse>> BuildEventExportItemsResponseAsync(IQueryable<FanceeData.Models.Ticketing.Event> query, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes)
    {
        query = ApplyQueryFilters(query, searchQuery, minimumStartDate, maximumStartDate, eventStates, countryCodes);

        return await query.OrderBy(e => e.StartDate)
            .Select(e => new EventExportItemResponse
            {
                Name = e.Name,
                Type = e.Type,
                StartDate = e.StartDate,
                EndDate = e.EndDate,
                Description = e.Description,
                City = e.Address.City,
                PostalCode = e.Address.PostalCode,
                Street = e.Address.Street,
                HouseNumber = e.Address.HouseNumber,
                ReservationTimeMinutes = e.ReservationTimeMinutes,
                CreatedOn = e.CreatedOn
            }).ToListAsync();
    }

    private async Task<int> EventPlatformCostsAsync(Guid eventId, IList<MappedOrganizationContractFee> contractFees) =>
        await EventPlatformCostsAsync(eventId, ProductType.Product, contractFees) +
        await EventPlatformCostsAsync(eventId, ProductType.Ticket, contractFees) +
        await EventPlatformCostsAsync(eventId, ProductType.SeatedTicket, contractFees);

    private async Task<int> EventPlatformCostsAsync(Guid eventId, ProductType productType, IList<MappedOrganizationContractFee> contractFees)
    {
        var totalFeeCostCents = 0;

        foreach (var contractFee in contractFees)
        {
            var maximumDate = DateTimeUtils.Min(contractFee.PeriodEnd, DateTime.UtcNow);
            var percentage = productType switch
            {
                ProductType.Product => contractFee.ProductFeePercentage,
                ProductType.Ticket => contractFee.TicketFeePercentage,
                ProductType.SeatedTicket => contractFee.SeatedTicketFeePercentage,
                var _ => 0
            };

            var query = _dbContext.ReservedProducts
                .Where(rp => rp.Product.EventId == eventId)
                .Where(rp => rp.ReservationReferenceNavigation.OrderReference.CreatedAt > contractFee.PeriodStart)
                .Where(rp => rp.ReservationReferenceNavigation.OrderReference.CreatedAt <= maximumDate)
                .Where(rp => MarkAsSoldPaymentStates.Contains(rp.ReservationReferenceNavigation.OrderReference.PaymentStatus))
                .Where(rp => rp.ReservationReferenceNavigation.OrderReference.TotalCostCents != null)
                .Where(rp => rp.Product.Type == productType);

            //Guest list fee addition
            if (productType == ProductType.Ticket)
            {
                totalFeeCostCents += await query
                    .Where(rp => rp.IssuedProducts.Any(ip => ip.Type == IssuedProductType.GuestTicket))
                    .SumAsync(rp => rp.Quantity * contractFee.GuestListFeeCents);
            }

            //Static fee addition
            totalFeeCostCents += productType switch
            {
                ProductType.Product => await query.SumAsync(rp => rp.Quantity * rp.Product.PackQuantity * contractFee.ProductFeeCents),
                ProductType.Ticket => await query.SumAsync(rp => rp.Quantity * rp.Product.PackQuantity * contractFee.TicketFeeCents),
                ProductType.SeatedTicket => await query.SumAsync(rp => rp.Quantity * rp.Product.PackQuantity * contractFee.SeatedTicketFeeCents),
                var _ => 0
            };

            //Percentual fee addition
            totalFeeCostCents += (await query.Select(rp => new
                    {
                        HistoryPricing = rp.Product.PriceHistories
                            .Where(pph => pph.Date < rp.ReservationReferenceNavigation.OrderReference.CreatedAt)
                            .OrderByDescending(pph => pph.Date)
                            .FirstOrDefault(),
                        HasPriceHistoryAfterOrder = rp.Product.PriceHistories.Any(pph => pph.Date > rp.ReservationReferenceNavigation.OrderReference.CreatedAt),
                        ProductPricing = rp.Product.PriceCents ?? 0 + (rp.Product.FeeCents ?? 0),
                        rp.Product.PackQuantity,
                        rp.Quantity
                    })
                    .ToListAsync()
                )
                .Sum(i =>
                    (int)Math.Round(
                        (i.HasPriceHistoryAfterOrder
                            ? (i.HistoryPricing?.FeeCents ?? 0) + (i.HistoryPricing?.PriceCents ?? 0) * i.Quantity * i.PackQuantity / 100m * percentage
                            : i.ProductPricing / 100m * percentage) * i.Quantity * i.PackQuantity
                    ));
        }

        return totalFeeCostCents;
    }

    private async Task<int> PlatformCostsAsync(Guid organizationId, IList<ContractFee> contractFees) =>
        await ProductFeeCostsAsync(organizationId, ProductType.Product, contractFees) +
        await ProductFeeCostsAsync(organizationId, ProductType.Ticket, contractFees) +
        await ProductFeeCostsAsync(organizationId, ProductType.SeatedTicket, contractFees) +
        await GuestListFeeCostsAsync(organizationId, contractFees);

    private async Task<int> ProductFeeCostsAsync(Guid organizationId, ProductType productType, IEnumerable<ContractFee> contractFees)
    {
        var platformCosts = 0;
        var baseQuery = _dbContext.ReservedProducts
            .Where(rp => rp.Product.Event.OrganizationId == organizationId)
            .Where(rp => MarkAsSoldPaymentStates.Contains(rp.ReservationReferenceNavigation.OrderReference.PaymentStatus))
            .Where(rp => rp.Product.Type == productType);

        foreach (var contractFee in contractFees)
        {
            var maximumDate = DateTimeUtils.Min(contractFee.PeriodEnd, DateTime.UtcNow);
            var percentage = productType switch
            {
                ProductType.Product => contractFee.ProductFeePercentage,
                ProductType.Ticket => contractFee.TicketFeePercentage,
                ProductType.SeatedTicket => contractFee.SeatedTicketFeePercentage,
                var _ => 0
            };

            var query = baseQuery
                .Where(rp => rp.ReservationReferenceNavigation.OrderReference.CreatedAt > contractFee.PeriodStart)
                .Where(rp => rp.ReservationReferenceNavigation.OrderReference.CreatedAt <= maximumDate);

            platformCosts += productType switch
            {
                ProductType.Product => await query.SumAsync(rp => rp.Quantity * rp.Product.PackQuantity * contractFee.ProductFeeCents),
                ProductType.Ticket => await query.SumAsync(rp => rp.Quantity * rp.Product.PackQuantity * contractFee.TicketFeeCents),
                ProductType.SeatedTicket => await query.SumAsync(rp => rp.Quantity * rp.Product.PackQuantity * contractFee.SeatedTicketFeeCents),
                var _ => 0
            };

            platformCosts += (await query.Select(rp => new
                    {
                        HistoryPricing = rp.Product.PriceHistories
                            .Where(pph => pph.Date < rp.ReservationReferenceNavigation.OrderReference.CreatedAt)
                            .OrderByDescending(pph => pph.Date)
                            .FirstOrDefault(),
                        HasPriceHistoryAfterOrder = rp.Product.PriceHistories.Any(pph => pph.Date > rp.ReservationReferenceNavigation.OrderReference.CreatedAt),
                        ProductPricing = rp.Product.PriceCents ?? 0 + (rp.Product.FeeCents ?? 0),
                        rp.Product.PackQuantity,
                        rp.Quantity
                    })
                    .ToListAsync()
                )
                .Sum(i =>
                    (int)Math.Round(
                        (i.HasPriceHistoryAfterOrder
                            ? (i.HistoryPricing?.FeeCents ?? 0) + (i.HistoryPricing?.PriceCents ?? 0) * i.Quantity * i.PackQuantity / 100m * percentage
                            : i.ProductPricing / 100m * percentage) * i.Quantity * i.PackQuantity
                    ));
        }

        return platformCosts;
    }

    private async Task<int> GuestListFeeCostsAsync(Guid organizationId, IEnumerable<ContractFee> contractFees)
    {
        var costs = 0;

        var baseQuery = _dbContext.IssuedProducts
            .Where(ip => ip.Product.Event.OrganizationId == organizationId)
            .Where(ip => ip.Type == IssuedProductType.GuestTicket)
            .Where(ip => ip.Origin == IssuedProductOrigin.PlatformGuestList);

        foreach (var contractFee in contractFees)
        {
            var query = baseQuery
                .Where(ip => ip.CreatedOn >= contractFee.PeriodStart)
                .Where(ip => ip.CreatedOn < contractFee.PeriodEnd);

            costs += await query.CountAsync() * contractFee.GuestListFeeCents;
        }

        return costs;
    }
}