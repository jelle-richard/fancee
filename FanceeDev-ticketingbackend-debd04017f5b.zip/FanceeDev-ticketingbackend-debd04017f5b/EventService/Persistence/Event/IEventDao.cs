﻿using System.Linq.Expressions;
using EventService.Dtos.Responses.Event;
using EventService.Dtos.Responses.Events;
using EventService.Dtos.Shared.Event;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore.Query;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Persistence;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Contract;

namespace EventService.Persistence.Event;

public interface IEventDao
{
    /// <summary>
    /// Inserts a new event.
    /// </summary>
    /// <param name="event"></param>
    /// <returns></returns>
    public Task InsertAsync(FanceeData.Models.Ticketing.Event @event);

    /// <summary>
    /// Lists all the events for an organization.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="searchQuery"></param>
    /// <param name="minimumStartDate"></param>
    /// <param name="maximumStartDate"></param>
    /// <param name="eventStates"></param>
    /// <param name="countryCodes"></param>
    /// <param name="env"></param>
    /// <returns></returns>
    public Task<PaginatedResultSet<EventListItemResponse>> ListAsync(Guid organizationId, int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes, HostedDeploymentEnvironment env);

    /// <summary>
    /// Lists all the events of the platform.
    /// </summary>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="searchQuery"></param>
    /// <param name="minimumStartDate"></param>
    /// <param name="maximumStartDate"></param>
    /// <param name="eventStates"></param>
    /// <param name="countryCodes"></param>
    /// <param name="env"></param>
    /// <returns></returns>
    public Task<PaginatedResultSet<EventListItemResponse>> ListAsync(int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes, HostedDeploymentEnvironment env);

    /// <summary>
    /// Lists the options for a select element.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="eventIds"></param>
    /// <param name="searchQuery"></param>
    /// <returns></returns>
    public Task<IEnumerable<SelectOption<Guid>>> ListSelectOptionsAsync(Guid? organizationId, IList<Guid> eventIds, string? searchQuery);

    /// <summary>
    /// Lists all the events for an app team.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="searchQuery"></param>
    /// <param name="minimumStartDate"></param>
    /// <param name="maximumStartDate"></param>
    /// <param name="eventStates"></param>
    /// <param name="env"></param>
    /// <returns></returns>
    public Task<PaginatedResultSet<EventListItemResponse>> ListByAppTeamAsync(Guid appTeamId, int limit, int offset, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, HostedDeploymentEnvironment env);

    /// <summary>
    /// Gets the given event for the given organization.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="organizationId"></param>
    /// <param name="env"></param>
    /// <returns></returns>
    public Task<EventResponse?> GetAsync(Guid eventId, Guid organizationId, HostedDeploymentEnvironment env);

    /// <summary>
    /// Gets the event for the organization.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="organizationId"></param>
    /// <param name="include"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.Event?> GetEventAsync(Guid eventId, Guid organizationId, Expression<Func<IQueryable<FanceeData.Models.Ticketing.Event>, IIncludableQueryable<FanceeData.Models.Ticketing.Event, object>>>? include);

    /// <summary>
    /// Updates an event.
    /// </summary>
    /// <param name="event"></param>
    /// <returns></returns>
    public Task UpdateAsync(FanceeData.Models.Ticketing.Event @event);

    /// <summary>
    /// Updates the status of an event.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="status"></param>
    /// <returns></returns>
    public Task<int> UpdateStatusAsync(Guid id, EventStatus status);

    /// <summary>
    /// Deletes an event
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task DeleteAsync(Guid eventId);

    /// <summary>
    /// Gets an event with all the required entities for the desired copy.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="copyShops"></param>
    /// <param name="copyProducts"></param>
    /// <param name="copyPaymentMethods"></param>
    /// <param name="copyCategories"></param>
    /// <param name="copyTags"></param>
    /// <param name="copyMedia"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.Event?> CopyableEventAsync(Guid eventId, bool copyShops, bool copyProducts, bool copyPaymentMethods, bool copyCategories, bool copyTags, bool copyMedia);

    /// <summary>
    /// Gets all events between provided dates.
    /// </summary>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="allowedCountries"></param>
    /// <param name="env"></param>
    /// <returns></returns>
    public Task<IEnumerable<AgendaEventResponse>> EventsAgendaAsync(DateTime startDate, DateTime endDate, IEnumerable<string> allowedCountries, HostedDeploymentEnvironment env);

    /// <summary>
    /// Gets the start date of the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<DateTime?> StartDateAsync(Guid eventId);

    /// <summary>
    /// Gets the revenues of an event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="contractFees"></param>
    /// <returns></returns>
    public Task<RevenueResponse> EventRevenuesAsync(Guid eventId, IList<MappedOrganizationContractFee> contractFees);

    /// <summary>
    /// Gets the revenues from all the events of the organization.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="contractFees"></param>
    /// <returns></returns>
    public Task<RevenueResponse> RevenuesAsync(Guid organizationId, IList<ContractFee> contractFees);

    /// <summary>
    /// Gets the upcoming events with associated products.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.Event>> UpcomingEventProductsAsync(Guid organizationId);

    /// <summary>
    /// Sets the status of all finished events to 'Concluded'.
    /// </summary>
    /// <returns></returns>
    public Task<int> ConcludeAsync();

    /// <summary>
    /// Gets the events of an organization as export items.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="searchQuery"></param>
    /// <param name="minimumStartDate"></param>
    /// <param name="maximumStartDate"></param>
    /// <param name="eventStates"></param>
    /// <returns></returns>
    public Task<IEnumerable<EventExportItemResponse>> OrganizationEventExportItemsResponseAsync(Guid organizationId, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates);

    /// <summary>
    /// Gets the events of the platform as export items.
    /// </summary>
    /// <param name="searchQuery"></param>
    /// <param name="minimumStartDate"></param>
    /// <param name="maximumStartDate"></param>
    /// <param name="eventStates"></param>
    /// <param name="countryCodes"></param>
    /// <returns></returns>
    public Task<IEnumerable<EventExportItemResponse>> PlatformEventExportItemsResponseAsync(string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes);

    /// <summary>
    /// Gets the events of the platform as export items.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="searchQuery"></param>
    /// <param name="minimumStartDate"></param>
    /// <param name="maximumStartDate"></param>
    /// <param name="eventStates"></param>
    /// <param name="countryCodes"></param>
    /// <returns></returns>
    public Task<IEnumerable<EventExportItemResponse>> PlatformEventExportItemsResponseAsync(Guid organizationId, string? searchQuery, DateTime? minimumStartDate, DateTime? maximumStartDate, IEnumerable<EventStatus>? eventStates, IEnumerable<string> countryCodes);

    /// <summary>
    /// Gets the balance mutations of events.
    /// </summary>
    /// <param name="contractFees"></param>
    /// <param name="searchQuery"></param>
    /// <returns></returns>
    public Task<List<EventBalance>> BalanceMutationsAsync(List<MappedOrganizationContractFee> contractFees, string? searchQuery);

    /// <summary>
    /// Validates if an event can be canceled.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> CancelableAsync(Guid eventId);
}