using FanceeData.Models.Ticketing;

namespace EventService.Persistence.Event;

public interface IEventCancellationDao
{
    /// <summary>
    /// Adds a new Event cancellation record.
    /// </summary>
    /// <param name="eventCancellation"></param>
    /// <returns></returns>
    public Task AddAsync(EventCancellation eventCancellation);

    /// <summary>
    /// Retrieves an event cancellation for generation of emails.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<EventCancellation?> GetAsync(Guid id);
}