using WebApiCore.Dtos.Persistence;

namespace EventService.Persistence.Product;

public interface IProductsDao
{
    /// <summary>
    /// Lists the options for a select element.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="productIds"></param>
    /// <param name="searchQuery"></param>
    /// <param name="eventIds"></param>
    /// <param name="onlyUpcoming"></param>
    /// <returns></returns>
    public Task<IEnumerable<SelectOption<Guid>>> ListSelectOptionsAsync(Guid organizationId, IList<Guid> productIds, string? searchQuery, IList<Guid> eventIds, bool onlyUpcoming);
}