﻿using System.Linq.Expressions;
using EventService.Dtos.Responses.Product;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Utils.Query;

namespace EventService.Persistence.Product;

public class ProductDao : IProductDao
{
    private static readonly PaymentStatus[] MarkAsSoldPaymentStates = { PaymentStatus.Authorised };

    private static readonly PaymentStatus[] MarkAsPendingPaymentStates =
    {
        PaymentStatus.AuthenticationFinished,
        PaymentStatus.AuthenticationNotRequired,
        PaymentStatus.ChallengeShopper,
        PaymentStatus.IdentifyShopper,
        PaymentStatus.PartiallyAuthorised,
        PaymentStatus.Pending,
        PaymentStatus.PresentToShopper,
        PaymentStatus.Received,
        PaymentStatus.RedirectShopper,
        PaymentStatus.Unknown
    };

    private readonly TicketingContext _dbContext;

    public ProductDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task InsertAsync(FanceeData.Models.Ticketing.Product product)
    {
        await _dbContext.Products.AddAsync(product);
        await _dbContext.SaveChangesAsync();
    }

    public async Task InsertAsync(IEnumerable<FanceeData.Models.Ticketing.Product> products)
    {
        await _dbContext.Products.AddRangeAsync(products);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Product>> GetAllAsync(Guid eventId, Guid organizationId, params Expression<Func<FanceeData.Models.Ticketing.Product, object>>[] includes)
    {
        return await _dbContext.Products.Where(p => p.EventId == eventId && p.Event.OrganizationId == organizationId)
            .IncludeMany(includes)
            .Include(p => p.ProductMedia)
            .ThenInclude(m => m.File)
            .ToListAsync();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Product>> GetAllAsync(IEnumerable<Guid> productIds, Guid organizationId, params Expression<Func<FanceeData.Models.Ticketing.Product, object>>[] includes)
    {
        return await _dbContext.Products.Where(p => productIds.Contains(p.Id) && p.Event.OrganizationId == organizationId)
            .IncludeMany(includes)
            .ToListAsync();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Product>> GetAllExcludingAsync(Guid eventId, Guid organizationId, IEnumerable<Guid> excludedIds, params Expression<Func<FanceeData.Models.Ticketing.Product, object>>[] includes)
    {
        return await _dbContext.Products.Where(p => p.EventId == eventId && p.Event.OrganizationId == organizationId && !excludedIds.Contains(p.Id))
            .IncludeMany(includes)
            .ToListAsync();
    }

    public async Task<bool> BelongsToEventAsync(Guid productId, Guid eventId)
    {
        return await _dbContext.Products.Where(p => p.Id == productId && p.EventId == eventId)
            .AnyAsync();
    }

    public async Task<bool> OwnerOfProductsAsync(Guid organizationId, IEnumerable<Guid> productIds)
    {
        var count = await _dbContext.Products.Where(p => productIds.Contains(p.Id) && p.Event.OrganizationId == organizationId).CountAsync();

        return count == productIds.Count();
    }

    public async Task UpdateBatchAsync(IEnumerable<FanceeData.Models.Ticketing.Product> products)
    {
        _dbContext.Products.UpdateRange(products);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<ProductType> ProductTypeAsync(Guid productId)
    {
        return await _dbContext.Products.Where(p => p.Id == productId).Select(p => p.Type).FirstOrDefaultAsync();
    }

    public async Task DeleteAsync(Guid productId)
    {
        var productEntity = new FanceeData.Models.Ticketing.Product { Id = productId };

        _dbContext.Attach(productEntity);

        await DeleteAsync(productEntity);
    }

    public async Task DeleteAsync(FanceeData.Models.Ticketing.Product product)
    {
        var itemInShops = await _dbContext.ItemsInShops.Where(i => i.ProductId == product.Id).ToListAsync();

        _dbContext.ItemsInShops.RemoveRange(itemInShops);
        _dbContext.Products.Remove(product);

        await _dbContext.SaveChangesAsync();
    }

    // Note: Deletable prerequisites are also found in ProductAdapter.ToIdentifiedProductDto
    public async Task<bool> HasSalesOrReservationsAsync(IEnumerable<Guid> productIds)
    {
        return await _dbContext.Products.Where(p => productIds.Contains(p.Id) && (p.ReservedProducts.Any() || p.IssuedProducts.Any()))
            .AnyAsync();
    }

    public async Task<bool> HasSalesOrReservationsAsync(Guid eventId)
    {
        return await _dbContext.Products.Where(p => p.EventId == eventId && (p.ReservedProducts.Any() || p.IssuedProducts.Any()))
            .AnyAsync();
    }

    public async Task LogPriceChangeAsync(Guid productId, int? oldPrice, int? oldFee)
    {
        var entity = new ProductPriceHistory
        {
            ProductId = productId,
            Date = DateTime.UtcNow,
            PriceCents = oldPrice,
            FeeCents = oldFee
        };

        await _dbContext.ProductPriceHistories.AddAsync(entity);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<IEnumerable<ProductSalesResponse>> EventProductSalesAsync(Guid eventId)
    {
        return await _dbContext.Products.Where(p => p.EventId == eventId)
            .Select(p => new ProductSalesResponse
            {
                Id = p.Id,
                Name = p.Name,
                PriceCents = p.PriceCents,
                PackQuantity = p.PackQuantity,
                PendingReservationsAmount = p.ReservedProducts
                    .Where(rp => rp.ReservationReferenceNavigation.ExpiresOn > DateTime.UtcNow)
                    .Where(rp => rp.ReservationReferenceNavigation.OrderReference == null)
                    .Sum(rp => rp.Quantity),
                PendingPaymentsAmount = _dbContext.Orders.SelectMany(o => o.ReservationReferenceNavigation.ReservedProducts)
                    .Where(rp => rp.ProductId == p.Id)
                    .Where(rp => rp.ReservationReferenceNavigation.ExpiresOn > DateTime.UtcNow)
                    .Where(rp => MarkAsPendingPaymentStates.Contains(rp.ReservationReferenceNavigation.OrderReference.PaymentStatus))
                    .Select(rp => rp.Quantity)
                    .Sum(),
                SoldAmount = _dbContext.Orders.SelectMany(o => o.ReservationReferenceNavigation.ReservedProducts)
                    .Where(rp => rp.ProductId == p.Id)
                    .Where(rp => MarkAsSoldPaymentStates.Contains(rp.ReservationReferenceNavigation.OrderReference.PaymentStatus))
                    .Select(rp => rp.Quantity)
                    .Sum(),
                GuestAmount = _dbContext.IssuedProducts.Where(ip => ip.ProductId == p.Id)
                    .Where(ip => ip.Type == IssuedProductType.GuestTicket)
                    .GroupBy(ip => true)
                    .Select(g => new GuestAmount
                    {
                        DeductedAmount = g.Count(i => i.DeductStock),
                        NotDeductedAmount = g.Count(i => !i.DeductStock)
                    })
                    .FirstOrDefault() ?? new() { DeductedAmount = 0, NotDeductedAmount = 0 },
                Stock = p.Stock
            })
            .ToListAsync();
    }

    public async Task<int> TotalProductsSoldAsync(Guid organizationId)
    {
        return await _dbContext.ReservedProducts.Where(rp => rp.Product.Event.OrganizationId == organizationId)
            .Where(rp => MarkAsSoldPaymentStates.Contains(rp.ReservationReferenceNavigation.OrderReference.PaymentStatus))
            .SumAsync(rp => rp.Quantity);
    }

    public async Task<int> TotalProductsSoldAsync(DateTime startDate, DateTime endDate, IEnumerable<string> countryCodes)
    {
        return await _dbContext.ReservedProducts.Where(rp => rp.ReservationReferenceNavigation.CreatedOn > startDate)
            .Where(rp => !rp.Product.Event.Organization.IsDemo)
            .Where(rp => countryCodes.Contains(rp.Product.Event.Organization.CountryCode))
            .Where(rp => rp.ReservationReferenceNavigation.CreatedOn < endDate)
            .Where(rp => MarkAsSoldPaymentStates.Contains(rp.ReservationReferenceNavigation.OrderReference.PaymentStatus))
            .SumAsync(rp => rp.Quantity);
    }

    public async Task<int> EventProductsSoldAsync(Guid eventId)
    {
        return await _dbContext.ReservedProducts.Where(rp => rp.Product.EventId == eventId)
            .Where(rp => MarkAsSoldPaymentStates.Contains(rp.ReservationReferenceNavigation.OrderReference.PaymentStatus))
            .SumAsync(rp => rp.Quantity);
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Product>> ProductShopsAsync(Guid eventId, Guid organizationId)
    {
        return await _dbContext.Products.Where(p => p.EventId == eventId && p.Event.OrganizationId == organizationId)
            .Include(p => p.ProductMedia)
            .ThenInclude(pm => pm.File)
            .Include(p => p.ItemInShops)
            .ThenInclude(iis => iis.Shop)
            .Include(p => p.AccordionShopElements)
            .ThenInclude(ase => ase.AccordionElement.ItemInShop.Shop)
            .ToListAsync();
    }

    public async Task<bool> TicketOptionsDesignIdInTicketIdAsync(Guid eventId, IEnumerable<Guid> productIds)
    {
        return await _dbContext.TicketOptions
            .Where(ti => ti.Product.EventId == eventId)
            .Where(ti => productIds.Contains(ti.ProductId))
            .AnyAsync();
    }
}