﻿using System.Linq.Expressions;
using EventService.Dtos.Responses.Product;
using FanceeData.Models.Ticketing;

namespace EventService.Persistence.Product;

public interface IProductDao
{
    /// <summary>
    /// Inserts a new product.
    /// </summary>
    /// <param name="product"></param>
    /// <returns></returns>
    public Task InsertAsync(FanceeData.Models.Ticketing.Product product);

    /// <summary>
    /// Inserts multiple products.
    /// </summary>
    /// <param name="products"></param>
    /// <returns></returns>
    public Task InsertAsync(IEnumerable<FanceeData.Models.Ticketing.Product> products);

    /// <summary>
    /// Gets all products.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="organizationId"></param>
    /// <param name="includes"></param>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.Product>> GetAllAsync(Guid eventId, Guid organizationId, params Expression<Func<FanceeData.Models.Ticketing.Product, object>>[] includes);

    /// <summary>
    /// Gets all the products with the given ids.
    /// </summary>
    /// <param name="productIds"></param>
    /// <param name="organizationId"></param>
    /// <param name="includes"></param>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.Product>> GetAllAsync(IEnumerable<Guid> productIds, Guid organizationId, params Expression<Func<FanceeData.Models.Ticketing.Product, object>>[] includes);

    /// <summary>
    /// Gets all products excluding the given ids.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="organizationId"></param>
    /// <param name="excludedIds"></param>
    /// <param name="includes"></param>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.Product>> GetAllExcludingAsync(Guid eventId, Guid organizationId, IEnumerable<Guid> excludedIds, params Expression<Func<FanceeData.Models.Ticketing.Product, object>>[] includes);

    /// <summary>
    /// Checks if the given product belongs to the event.
    /// </summary>
    /// <param name="productId"></param>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> BelongsToEventAsync(Guid productId, Guid eventId);

    /// <summary>
    /// Checks if the given organization is the owner of all the given products.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="productIds"></param>
    /// <returns></returns>
    public Task<bool> OwnerOfProductsAsync(Guid organizationId, IEnumerable<Guid> productIds);

    /// <summary>
    /// Deletes a product by it's id.
    /// </summary>
    /// <param name="productId"></param>
    /// <returns></returns>
    public Task DeleteAsync(Guid productId);

    /// <summary>
    /// Deletes a product.
    /// </summary>
    /// <param name="product"></param>
    /// <returns></returns>
    public Task DeleteAsync(FanceeData.Models.Ticketing.Product product);

    /// <summary>
    /// Updates the given products.
    /// </summary>
    /// <param name="products"></param>
    /// <returns></returns>
    public Task UpdateBatchAsync(IEnumerable<FanceeData.Models.Ticketing.Product> products);

    /// <summary>
    /// Gets the type of the product.
    /// </summary>
    /// <param name="productId"></param>
    /// <returns></returns>
    public Task<ProductType> ProductTypeAsync(Guid productId);

    /// <summary>
    /// Returns whether the given products have any sales or reservation.
    /// </summary>
    /// <param name="productIds"></param>
    /// <returns></returns>
    public Task<bool> HasSalesOrReservationsAsync(IEnumerable<Guid> productIds);

    /// <summary>
    /// Returns whether the event has sales or reservations
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<bool> HasSalesOrReservationsAsync(Guid eventId);

    /// <summary>
    /// Creates a new ProductPriceHistory entry for the given product.
    /// </summary>
    /// <param name="productId"></param>
    /// <param name="oldPrice"></param>
    /// <param name="oldFee"></param>
    /// <returns></returns>
    public Task LogPriceChangeAsync(Guid productId, int? oldPrice, int? oldFee);

    /// <summary>
    /// Gets the product sales of an event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<IEnumerable<ProductSalesResponse>> EventProductSalesAsync(Guid eventId);

    /// <summary>
    /// Gets the total amount of sold products for all events of the organization.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<int> TotalProductsSoldAsync(Guid organizationId);

    /// <summary>
    /// Gets the total amount of sold products for all events of the platform.
    /// </summary>
    /// <param name="startDate"></param>
    /// <param name="endDate"></param>
    /// <param name="countryCodes"></param>
    /// <returns></returns>
    public Task<int> TotalProductsSoldAsync(DateTime startDate, DateTime endDate, IEnumerable<string> countryCodes);

    /// <summary>
    /// Gets the amount of sold products for the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <returns></returns>
    public Task<int> EventProductsSoldAsync(Guid eventId);

    /// <summary>
    /// Gets the products for the given event and which shops they're sold in.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="organizationId"></param>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.Product>> ProductShopsAsync(Guid eventId, Guid organizationId);

    /// <summary>
    /// Returns whether the ticket belongs to the event.
    /// </summary>
    /// <param name="eventId"></param>
    /// <param name="productIds"></param>
    /// <returns></returns>
    Task<bool> TicketOptionsDesignIdInTicketIdAsync(Guid eventId, IEnumerable<Guid> productIds);
}