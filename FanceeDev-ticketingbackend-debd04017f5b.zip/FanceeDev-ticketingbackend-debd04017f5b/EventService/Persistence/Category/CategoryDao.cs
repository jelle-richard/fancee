﻿using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace EventService.Persistence.Category;

public class CategoryDao : ICategoryDao
{
    private readonly TicketingContext _dbContext;

    public CategoryDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<EventCategory>> GetAllActiveSubCategoriesAsync()
    {
        return await _dbContext.EventCategories.Where(ec => ec.Active && ec.Parent != null)
            .ToListAsync();
    }
}