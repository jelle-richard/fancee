﻿using FanceeData.Models.Ticketing;

namespace EventService.Persistence.Category;

public interface ICategoryDao
{
    /// <summary>
    /// Gets all the active sub categories.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<EventCategory>> GetAllActiveSubCategoriesAsync();
}