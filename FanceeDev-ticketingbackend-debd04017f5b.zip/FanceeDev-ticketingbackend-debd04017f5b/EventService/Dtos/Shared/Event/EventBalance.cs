using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Shared.Event;

public class EventBalance
{
    public Guid EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public EventStatus Status { get; set; }
    public Guid UserId { get; set; }
    public string UserEmail { get; set; } = string.Empty;
    public string CountryCode { get; set; } = string.Empty;
    public int TotalAmountOfTicketFeeCentsReceived { get; set; }
    public int TotalAmountOfSeatedTicketFeeCentsReceived { get; set; }
    public int TotalAmountOfGuestListFeeCentsReceived { get; set; }
    public int TotalAmountOfPaymentFeeCentsReceived { get; set; }
    public int TotalAmountOfOrderTotalCostsCentsReceived { get; set; }
    public int TotalAmountOfTicketPlusCostsCentsReceived { get; set; }
    public int TotalAmountOfIssuedTickets { get; set; }
    public int TotalAmountOfScannedTickets { get; set; }
    public Currency OrganizationCurrency { get; set; } = default!;
}