namespace EventService.Dtos.Shared.Event;

public enum MailType
{
    GuestList,
    DefaultShopMail,
    SealedTicketsMail
}