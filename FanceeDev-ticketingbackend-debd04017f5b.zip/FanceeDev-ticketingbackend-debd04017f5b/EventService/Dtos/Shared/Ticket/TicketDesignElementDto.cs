using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EventService.Dtos.Shared.Ticket;

public abstract class TicketDesignElementDto : IValidatableObject
{
    public const int Columns = 3;
    public const int Rows = 4;

    [Required]
    [JsonPropertyOrder(-1)]
    public ElementKind? Kind { get; set; }

    [Required]
    public PositionDto? Position { get; set; }

    [Required]
    public SizeDto? Size { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (Position!.Column + Size!.ColumnSpan - 1 > Columns)
            yield return new("Element out of range", new[] { nameof(Position.Column) });

        if (Position.Row + Size.RowSpan - 1 > Rows)
            yield return new("Element out of range", new[] { nameof(Position.Row) });
    }
}