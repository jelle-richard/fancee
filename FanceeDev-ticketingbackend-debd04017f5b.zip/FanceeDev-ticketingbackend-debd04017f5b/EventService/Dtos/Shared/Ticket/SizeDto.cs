using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Shared.Ticket;

public class SizeDto
{
    [Range(1, TicketDesignElementDto.Rows)]
    public int RowSpan { get; set; }

    [Range(1, TicketDesignElementDto.Columns)]
    public int ColumnSpan { get; set; }
}