namespace EventService.Dtos.Shared.Ticket;

public class QrElementDto : TicketDesignElementDto
{
    public Guid? FileId { get; set; }
}