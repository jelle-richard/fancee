using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Shared.Ticket;

public class MediaElementDto : TicketDesignElementDto
{
    [Required]
    public Guid? FileId { get; set; }
}