namespace EventService.Dtos.Shared.Ticket;

public enum ElementKind
{
    Qr,
    Media,
    UpcomingEvents
}