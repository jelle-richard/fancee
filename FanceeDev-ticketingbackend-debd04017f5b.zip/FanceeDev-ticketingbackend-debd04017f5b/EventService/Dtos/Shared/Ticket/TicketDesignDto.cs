using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Shared.Ticket;

public class TicketDesignDto : IValidatableObject
{
    [Required]
    public IList<TicketDesignElementDto>? Elements { get; set; }

    [Required]
    public IList<Guid>? TicketIds { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (Elements is not { Count: >= 1 })
        {
            yield return new("At least one element is required", new[] { nameof(Elements) });
            yield break;
        }

        if (TicketIds is not { Count: >= 1 })
        {
            yield return new("At least one ticket id is required", new[] { nameof(TicketIds) });
            yield break;
        }

        if (Elements.Count(e => e is QrElementDto) != 1)
            yield return new("Exactly one QR element should be provided", new[] { nameof(Elements) });

        var overlapResult = ValidateOverlap(Elements);
        if (overlapResult != null)
            yield return overlapResult;
    }

    private static ValidationResult? ValidateOverlap(IEnumerable<TicketDesignElementDto> elements)
    {
        var occupiedSpaces = new bool[3, 4];

        foreach (var element in elements.Where(e => e is not QrElementDto))
        {
            for (var x = 0; x < element.Size!.ColumnSpan; x++)
            {
                for (var y = 0; y < element.Size.RowSpan; y++)
                {
                    var xx = element.Position!.Column - 1 + x;
                    var yy = element.Position.Row - 1 + y;

                    if (occupiedSpaces[xx, yy])
                        return new($"Elements cannot overlap at grid position: {xx + 1},{yy + 1}", new[] { nameof(Elements) });

                    occupiedSpaces[xx, yy] = true;
                }
            }
        }

        return null;
    }
}