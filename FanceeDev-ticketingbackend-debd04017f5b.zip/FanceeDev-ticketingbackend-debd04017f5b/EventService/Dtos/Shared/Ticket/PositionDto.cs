using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Shared.Ticket;

public class PositionDto
{
    [Range(1, TicketDesignElementDto.Rows)]
    public int Row { get; set; }

    [Range(1, TicketDesignElementDto.Columns)]
    public int Column { get; set; }
}