using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Shared.Ticket;

public class UpcomingEventsElementDto : TicketDesignElementDto
{
    [Required]
    [Range(1, 5)]
    public int? Amount { get; set; }
}