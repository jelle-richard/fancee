﻿using WebApiCore.Dtos.Responses.File;

namespace EventService.Dtos.Responses.Events;

public class OrganizationResponse
{
    public string Name { get; set; } = default!;
    public FileResponse? Avatar { get; set; }
}