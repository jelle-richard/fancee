using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Responses.Events;

public class EventBalanceResponse
{
    public Guid EventId { get; set; }
    public string EventName { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public EventStatus Status { get; set; }
    public Guid UserId { get; set; }
    public string UserEmail { get; set; } = string.Empty;
    public string CountryCode { get; set; } = string.Empty;
    public EventBalanceCentsReceivedResponse OrganizationCurrencyEventBalanceCentsReceivedResponse { get; set; } = default!;
    public EventBalanceCentsReceivedResponse PlatformCurrencyEventBalanceCentsReceivedResponse { get; set; } = default!;
    public int TotalAmountOfIssuedTickets { get; set; }
    public int TotalAmountOfScannedTickets { get; set; }
}