using CsvHelper.Configuration.Attributes;
using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Responses.Events;

public class EventExportItemResponse
{
    public string Name { get; set; } = default!;

    public EventType Type { get; set; }

    [Format("yyyy-MM-dd HH:mm:ss")]
    public DateTime StartDate { get; set; }

    [Format("yyyy-MM-dd HH:mm:ss")]
    public DateTime EndDate { get; set; }

    public string? Description { get; set; }

    public string? City { get; set; }

    public string? PostalCode { get; set; }

    public string? Street { get; set; }

    public string? HouseNumber { get; set; }

    public int ReservationTimeMinutes { get; set; }

    public DateTime CreatedOn { get; set; }
}