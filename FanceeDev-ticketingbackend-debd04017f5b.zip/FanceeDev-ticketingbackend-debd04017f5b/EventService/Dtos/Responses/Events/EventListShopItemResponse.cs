using WebApiCore.Dtos.Responses.File;

namespace EventService.Dtos.Responses.Events;

public class EventListShopItemResponse
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public bool Active { get; set; }
    public DateTime? IsSecuredUntil { get; set; }
    public IEnumerable<ImageFileResponse> HeaderMedia { get; set; } = [];
    public ICollection<string> Tags { get; set; } = [];
    public bool Securable { get; set; }
}