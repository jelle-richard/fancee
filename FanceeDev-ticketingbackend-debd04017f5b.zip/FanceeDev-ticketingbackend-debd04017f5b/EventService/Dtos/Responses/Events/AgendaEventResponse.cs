using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Responses.Events;

public class AgendaEventResponse
{
    public Guid Id { get; set; }
    public OrganizationResponse Organization { get; set; } = default!;
    public string Name { get; set; } = default!;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public Dictionary<string, string> ShopCodes { get; set; } = new();
    public EventType Type { get; set; }
    public EventStatus Status { get; set; }
}