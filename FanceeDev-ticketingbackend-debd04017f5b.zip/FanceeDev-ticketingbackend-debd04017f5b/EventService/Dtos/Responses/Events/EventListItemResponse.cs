using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Responses.Events;

public class EventListItemResponse
{
    public Guid Id { get; set; }
    public Guid? SeatsIoEventId { get; set; }
    public OrganizationResponse Organization { get; set; } = default!;
    public string Name { get; set; } = default!;
    public DateTime Date { get; set; }
    public IEnumerable<EventListShopItemResponse> Shops { get; set; } = [];
    public EventType Type { get; set; }
    public EventStatus Status { get; set; }
    public bool Deletable { get; set; }
    public IEnumerable<string> Tags { get; set; } = [];
}