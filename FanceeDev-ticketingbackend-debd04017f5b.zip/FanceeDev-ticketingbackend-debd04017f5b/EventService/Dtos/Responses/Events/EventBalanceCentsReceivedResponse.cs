using WebApiCore.Dtos.Responses.Currency;

namespace EventService.Dtos.Responses.Events;

public class EventBalanceCentsReceivedResponse
{
    public long TotalAmountOfTicketFeeCentsReceived { get; set; }
    public long TotalAmountOfSeatedTicketFeeCentsReceived { get; set; }
    public long TotalAmountOfPaymentFeeCentsReceived { get; set; }
    public long TotalAmountOfGuestListFeeCentsReceived { get; set; }
    public long TotalAmountOfOrderTotalCostsCentsReceived { get; set; }
    public long TotalAmountOfTicketPlusCostsCentsReceived { get; set; }
    public required CurrencyResponse Currency { get; set; }
}