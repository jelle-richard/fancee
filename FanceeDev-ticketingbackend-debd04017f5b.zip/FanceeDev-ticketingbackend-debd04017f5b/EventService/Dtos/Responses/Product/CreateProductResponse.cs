﻿namespace EventService.Dtos.Responses.Product;

public class CreateProductResponse
{
    public Guid Id { get; set; }
}