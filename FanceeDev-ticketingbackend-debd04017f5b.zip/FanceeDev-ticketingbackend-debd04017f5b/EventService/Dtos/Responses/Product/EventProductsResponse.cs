using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Responses.Product;

public class EventProductsResponse
{
    public Guid Id { get; set; }
    public string Name { get; set; } = default!;
    public DateTime StartDate { get; set; }
    public EventType Type { get; set; }
    public IEnumerable<ProductIdentifierResponse> Products { get; set; } = new List<ProductIdentifierResponse>();
}