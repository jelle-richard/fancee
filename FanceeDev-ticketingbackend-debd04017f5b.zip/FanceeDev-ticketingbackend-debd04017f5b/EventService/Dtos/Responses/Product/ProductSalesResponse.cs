namespace EventService.Dtos.Responses.Product;

public class ProductSalesResponse
{
    public Guid Id { get; set; }
    public string Name { get; set; } = default!;
    public int? PriceCents { get; set; }
    public int Stock { get; set; }
    public int PendingReservationsAmount { get; set; }
    public int PendingPaymentsAmount { get; set; }
    public GuestAmount GuestAmount { get; set; } = new();
    public int SoldAmount { get; set; }
    public int PackQuantity { get; set; }
}