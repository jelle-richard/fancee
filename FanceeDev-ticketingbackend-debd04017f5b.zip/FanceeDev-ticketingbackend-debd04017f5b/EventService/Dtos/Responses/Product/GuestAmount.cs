namespace EventService.Dtos.Responses.Product;

public class GuestAmount
{
    public int DeductedAmount { get; set; }
    public int NotDeductedAmount { get; set; }
}