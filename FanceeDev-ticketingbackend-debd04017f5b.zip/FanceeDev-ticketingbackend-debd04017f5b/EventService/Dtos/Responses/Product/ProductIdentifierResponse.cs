using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Responses.Product;

public class ProductIdentifierResponse
{
    public Guid Id { get; set; }
    public string Name { get; set; } = default!;
    public ProductType Type { get; set; }
}