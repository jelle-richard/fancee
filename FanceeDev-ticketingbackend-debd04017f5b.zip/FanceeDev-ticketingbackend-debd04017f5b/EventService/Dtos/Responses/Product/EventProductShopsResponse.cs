using WebApiCore.Dtos.Responses.File;

namespace EventService.Dtos.Responses.Product;

public class EventProductShopsResponse
{
    public required Guid Id { get; set; }
    public required string Name { get; set; }
    public required FileResponse? Media { get; set; }
    public required IEnumerable<string> Shops { get; set; }
}