using EventService.Dtos.Shared.Ticket;

namespace EventService.Dtos.Responses.Ticket;

public class MediaElementResponse : MediaElementDto
{
    public string FileUrl { get; set; } = default!;
}