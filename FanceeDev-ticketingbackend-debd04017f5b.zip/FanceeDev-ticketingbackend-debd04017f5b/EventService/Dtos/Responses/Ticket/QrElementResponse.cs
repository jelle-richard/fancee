using EventService.Dtos.Shared.Ticket;

namespace EventService.Dtos.Responses.Ticket;

public class QrElementResponse : QrElementDto
{
    public string? FileUrl { get; set; }
}