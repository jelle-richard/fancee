using WebApiCore.Dtos.Responses.File;

namespace EventService.Dtos.Responses.Shops;

public class ShopListItemResponse
{
    public string Code { get; set; } = default!;
    public string Name { get; set; } = default!;
    public IEnumerable<ImageFileResponse> HeaderMedia { get; set; } = Array.Empty<ImageFileResponse>();
    public bool InUse { get; set; }
    public int NumberOfViews { get; set; }
}