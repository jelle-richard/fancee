﻿namespace EventService.Dtos.Responses.Event;

public class CreateEventResponse
{
    public Guid Id { get; set; }
}