namespace EventService.Dtos.Responses.Event;

public class AverageAgesGenderResponse
{
    public int? TotalAverageAge { get; set; }
    public int? MaleAverageAge { get; set; }
    public int? FemaleAverageAge { get; set; }
    public int? NeutralAverageAge { get; set; }
    public int? UnknownAverageAge { get; set; }
}