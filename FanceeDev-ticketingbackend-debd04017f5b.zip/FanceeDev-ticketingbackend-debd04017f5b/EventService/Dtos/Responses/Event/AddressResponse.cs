﻿using WebApiCore.Dtos.Shared.Address;

namespace EventService.Dtos.Responses.Event;

public class AddressResponse : IAddressDto
{
    public string? Venue { get; set; }
    public string? CountryCode { get; set; }
    public string? PostalCode { get; set; }
    public string? Street { get; set; }
    public string? City { get; set; }
    public string? HouseNumber { get; set; }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
}