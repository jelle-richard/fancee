namespace EventService.Dtos.Responses.Event;

public class EventCustomersCountryStatisticsResponse
{
    public required string CountryCode { get; set; }
    public required int Amount { get; set; }
}