namespace EventService.Dtos.Responses.Event;

public class EventCustomersCityStatisticsResponse
{
    public required string City { get; set; }
    public required int Amount { get; set; }
}