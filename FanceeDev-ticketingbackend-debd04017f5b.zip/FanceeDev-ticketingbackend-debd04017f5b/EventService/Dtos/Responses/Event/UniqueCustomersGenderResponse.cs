namespace EventService.Dtos.Responses.Event;

public class UniqueCustomersGenderResponse
{
    public int UniqueMaleCustomers { get; set; }
    public int UniqueFemaleCustomers { get; set; }
    public int UniqueNeutralCustomers { get; set; }
    public int UniqueUnknownCustomers { get; set; }
}