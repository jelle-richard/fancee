namespace EventService.Dtos.Responses.Event;

public class RevenueResponse
{
    public long OnlineSalesRevenueCents { get; set; }
    public long CashSalesRevenueCents { get; set; }
    public long PlatformExpensesCents { get; set; }
    public long ProfitCents { get; set; }
}