﻿using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses.File;

namespace EventService.Dtos.Responses.Event;

public class EventResponse
{
    public Guid Id { get; set; }
    public Guid? SeatsIoEventId { get; set; }
    public string Name { get; set; } = default!;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string? Description { get; set; }
    public string[]? Categories { get; set; }
    public EventType Type { get; set; }
    public int? MinAge { get; set; }
    public AddressResponse? Address { get; set; }
    public EventStatus Status { get; set; }
    public IEnumerable<string>? Tags { get; set; }
    public IEnumerable<ImageFileResponse> HeaderMedia { get; set; } = Array.Empty<ImageFileResponse>();
    public string TimezoneIdentification { get; set; } = default!;
    public bool IsSealed { get; set; }
}