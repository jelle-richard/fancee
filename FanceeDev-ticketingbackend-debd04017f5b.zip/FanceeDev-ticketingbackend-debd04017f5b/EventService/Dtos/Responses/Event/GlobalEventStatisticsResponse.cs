namespace EventService.Dtos.Responses.Event;

public class GlobalEventStatisticsResponse
{
    public int ProductsSoldAmount { get; set; }
    public int OrdersPlacedAmount { get; set; }
    public int TicketsScannedAmount { get; set; }
    public AverageAgesGenderResponse AverageAges { get; set; } = default!;
    public UniqueCustomersGenderResponse UniqueCustomers { get; set; } = default!;
}