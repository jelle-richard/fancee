using EventService.Dtos.Shared.Event;

namespace EventService.Dtos.Responses.Event;

public class EventMailResponse
{
    public string SenderName { get; set; } = default!;

    public string Subject { get; set; } = default!;

    public string Content { get; set; } = default!;

    public MailType Type { get; set; }
}