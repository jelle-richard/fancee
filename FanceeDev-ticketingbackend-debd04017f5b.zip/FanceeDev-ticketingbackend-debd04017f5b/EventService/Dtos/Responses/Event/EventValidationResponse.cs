namespace EventService.Dtos.Responses.Event;

public class EventValidationResponse
{
    public bool CanBePublished => HasShops && HasSellableProducts && HasPaymentMethod;
    public required bool HasShops { get; set; }
    public required bool HasSellableProducts { get; set; }
    public required bool HasPaymentMethod { get; set; }
}