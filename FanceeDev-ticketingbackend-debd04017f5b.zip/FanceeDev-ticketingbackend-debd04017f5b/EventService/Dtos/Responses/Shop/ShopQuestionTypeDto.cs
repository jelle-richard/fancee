namespace EventService.Dtos.Responses.Shop;

public enum ShopQuestionTypeDto
{
    Open,
    YesNo,
    Choice
}