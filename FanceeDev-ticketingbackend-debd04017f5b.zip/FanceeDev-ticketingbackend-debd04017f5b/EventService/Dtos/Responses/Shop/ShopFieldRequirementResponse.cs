using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Responses.Shop;

public class ShopFieldRequirementResponse
{
    public ShopField Field { get; set; }
    public bool Enabled { get; set; }
    public bool Required { get; set; }
}