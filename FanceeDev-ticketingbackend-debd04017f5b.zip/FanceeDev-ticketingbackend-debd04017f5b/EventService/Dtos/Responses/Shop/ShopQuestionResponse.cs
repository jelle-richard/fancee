namespace EventService.Dtos.Responses.Shop;

public class ShopQuestionResponse
{
    public Guid Id { get; set; }
    public bool Required { get; set; }
    public int Position { get; set; }
    public string Question { get; set; } = default!;
    public ShopQuestionTypeDto Type { get; set; }
    public IEnumerable<string> Choices { get; set; } = Array.Empty<string>();
}