using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses.Shop;
using WebApiCore.Dtos.Shared.ShopElement;

namespace EventService.Dtos.Responses.Shop;

public class ShopResponse
{
    public string Name { get; set; } = default!;
    public string Code { get; set; } = default!;
    public bool Secured { get; set; }
    public DateTime? SecuredUntil { get; set; }
    public bool Active { get; set; }
    public ShopLayout Layout { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public ShopDesignResponse Design { get; set; } = default!;
    public int NumberOfViews { get; set; }
    public IList<ShopElementDto> Elements { get; set; } = Array.Empty<ShopElementDto>();
    public IEnumerable<ShopFieldRequirementResponse> ShopFields { get; set; } = Array.Empty<ShopFieldRequirementResponse>();
    public IEnumerable<ShopQuestionResponse> Questions { get; set; } = Array.Empty<ShopQuestionResponse>();
    public IEnumerable<string> Tags { get; set; } = Array.Empty<string>();
    public ShopAnalyticsResponse Analytics { get; set; } = default!;
}