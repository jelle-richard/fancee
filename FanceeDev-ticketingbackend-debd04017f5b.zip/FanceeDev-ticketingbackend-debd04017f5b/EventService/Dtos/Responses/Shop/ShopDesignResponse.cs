﻿using WebApiCore.Dtos.Responses.File;

namespace EventService.Dtos.Responses.Shop;

public class ShopDesignResponse
{
    public IEnumerable<ImageFileResponse> HeaderMedia { get; set; } = Array.Empty<ImageFileResponse>();
    public FileResponse? BackgroundMedia { get; set; }
    public string? PrimaryColor { get; set; }
    public string? TextColor { get; set; }
    public string? BackdropColor { get; set; }
    public string? BackgroundColor { get; set; }
}