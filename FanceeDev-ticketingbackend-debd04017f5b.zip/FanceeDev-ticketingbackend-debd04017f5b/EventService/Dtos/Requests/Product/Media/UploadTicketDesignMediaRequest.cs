using System.ComponentModel.DataAnnotations;
using WebApiCore.Dtos.Requests;
using WebApiCore.Utils;
using WebApiCore.Utils.Validation.Attributes;

namespace EventService.Dtos.Requests.Product.Media;

public class UploadTicketDesignMediaRequest : UploadMediaRequest
{
    [Required]
    [MaximumFileSize(FileSizeUtils.Megabyte)]
    [AllowedFileTypes(FileTypes.Jpg | FileTypes.Png)]
    public override IFormFile? Media { get; set; }

    [Range(0, 100)]
    public int? FocalPointWidthPercentage { get; set; }

    [Range(0, 100)]
    public int? FocalPointHeightPercentage { get; set; }
}