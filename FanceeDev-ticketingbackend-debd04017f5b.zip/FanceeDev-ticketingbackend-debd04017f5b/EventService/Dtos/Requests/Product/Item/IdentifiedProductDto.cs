﻿using System.ComponentModel.DataAnnotations;
using WebApiCore.Dtos.Shared.Product;

namespace EventService.Dtos.Requests.Product.Item;

public class IdentifiedProductDto : ProductDto
{
    [Required]
    public Guid Id { get; set; }

    public bool Deletable { get; set; }
    
    public bool HasReservationsOrSales { get; set; }
}