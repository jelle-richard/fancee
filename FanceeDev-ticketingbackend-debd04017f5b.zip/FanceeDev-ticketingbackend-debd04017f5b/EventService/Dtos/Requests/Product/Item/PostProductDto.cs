﻿using WebApiCore.Dtos.Shared.Product;

namespace EventService.Dtos.Requests.Product.Item;

public class PostProductDto : ProductDto
{
}