using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;

namespace EventService.Dtos.Requests.Product;

public class ProductSelectOptionsRequest : SelectOptionsRequest<Guid>
{
    [FromQuery]
    public IList<Guid>? EventIds { get; set; }

    [FromQuery]
    public bool OnlyUpcoming { get; set; } = false;

    public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        EventIds ??= [];

        return base.Validate(validationContext);
    }
}