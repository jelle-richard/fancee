using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Requests.Media;

public class RepositionMediaRequest : IValidatableObject
{
    public IEnumerable<Guid> Positions { get; set; } = Array.Empty<Guid>();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!Positions.Any())
            yield return new("At least one position record is required", new[] { nameof(Positions) });
    }
}