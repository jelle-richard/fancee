﻿using System.ComponentModel.DataAnnotations;
using WebApiCore.Dtos.Requests;
using WebApiCore.Utils;
using WebApiCore.Utils.Validation.Attributes;

namespace EventService.Dtos.Requests.Shop;

public class UploadBackgroundMediaRequest : UploadMediaRequest
{
    [Required]
    [MaximumFileSize(FileSizeUtils.Megabyte * 2)]
    [AllowedFileTypes(FileTypes.Jpg | FileTypes.Png | FileTypes.Gif)]
    public override IFormFile? Media { get; set; }

    [Range(0, 100)]
    public int? FocalPointWidthPercentage { get; set; }

    [Range(0, 100)]
    public int? FocalPointHeightPercentage { get; set; }
}