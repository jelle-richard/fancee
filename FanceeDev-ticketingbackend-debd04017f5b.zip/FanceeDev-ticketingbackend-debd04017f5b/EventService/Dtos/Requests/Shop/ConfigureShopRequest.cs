using System.ComponentModel.DataAnnotations;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Requests.Shop;
using WebApiCore.Utils.String;

namespace EventService.Dtos.Requests.Shop;

public class ConfigureShopRequest : IValidatableObject
{
    [Required]
    [MaxLength(50)]
    public string? Name { get; set; }

    [Required]
    public ShopLayout? Layout { get; set; }

    [Required]
    public DateTime? StartDate { get; set; }

    [Required]
    public DateTime? EndDate { get; set; }

    [Required]
    public IList<ShopFieldRequirementRequest> ShopFields { get; set; } = null!;

    [Required]
    public UpdateShopDesignRequest? Design { get; set; }

    [Required]
    public ShopAnalyticsRequest Analytics { get; set; } = default!;

    public string[]? Tags { get; set; } = Array.Empty<string>();

    [Required]
    public bool? Active { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        Name = Name.HtmlSanitize().HtmlDecode().RemoveDoubleWhitespace();

        if (StartDate >= EndDate)
            yield return new($"{nameof(StartDate)} cannot be the same or after the {nameof(EndDate)}", new[] { nameof(StartDate) });

        if (!ShopFields.Any())
            yield return new($"{nameof(ShopFields)} are missing", new[] { nameof(ShopFields) });

        if (!ShopFields.Any(sf => sf is { Field: ShopField.Email, Enabled: true, Required: true }))
            yield return new($"{nameof(ShopFields)} requires the email field to be required and enabled", new[] { nameof(ShopFields) });
    }

    public IList<ShopTag> GetShopTags(string shopCode) => Tags?.Select(t => new ShopTag { ShopCode = shopCode, Name = t }).ToList() ?? new List<ShopTag>();
}