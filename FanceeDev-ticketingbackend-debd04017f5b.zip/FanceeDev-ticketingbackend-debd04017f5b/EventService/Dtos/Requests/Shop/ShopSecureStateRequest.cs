using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Requests.Shop;

public class ShopSecureStateRequest : IValidatableObject
{
    [Required]
    public bool IsSecured { get; set; }

    public DateTime? SecureStateExpiresOn { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (SecureStateExpiresOn != null && SecureStateExpiresOn < DateTime.UtcNow.AddMinutes(-15))
            yield return new("You cannot mark a shop as secured in the past", new[] { nameof(SecureStateExpiresOn) });
    }
}