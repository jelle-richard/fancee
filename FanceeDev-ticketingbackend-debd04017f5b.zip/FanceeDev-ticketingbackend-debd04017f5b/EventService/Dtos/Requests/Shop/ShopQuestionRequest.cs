using System.ComponentModel.DataAnnotations;
using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Requests.Shop;

public class ShopQuestionRequest : IValidatableObject
{
    public bool Required { get; set; }

    [Required]
    [StringLength(512, MinimumLength = 1)]
    public string Question { get; set; } = string.Empty;

    [Required]
    public ShopQuestionType Type { get; set; }

    public IEnumerable<ShopQuestionChoiceDto> Choices { get; set; } = new List<ShopQuestionChoiceDto>();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        Question = Question.Trim();

        if (Question.Length == 0)
            yield return new("Shop question cannot be empty", new[] { nameof(Question) });

        if (Type == ShopQuestionType.Choice && Choices.Count() < 2)
            yield return new($"When the question type is set to {ShopQuestionType.Choice.ToString()} at least two choices need to be provided", new[] { nameof(Type), nameof(Choices) });
    }
}