﻿using System.ComponentModel.DataAnnotations;
using WebApiCore.Utils.Validation.Attributes;

namespace EventService.Dtos.Requests.Shop;

public class UpdateShopDesignRequest
{
    [Required]
    [StringLength(6, MinimumLength = 6)]
    [Color]
    public string? PrimaryColor { get; set; }

    [Required]
    [StringLength(6, MinimumLength = 6)]
    [Color]
    public string? TextColor { get; set; }

    [Required]
    [StringLength(6, MinimumLength = 6)]
    [Color]
    public string? BackdropColor { get; set; }

    [Required]
    [StringLength(6, MinimumLength = 6)]
    [Color]
    public string? BackgroundColor { get; set; }
}