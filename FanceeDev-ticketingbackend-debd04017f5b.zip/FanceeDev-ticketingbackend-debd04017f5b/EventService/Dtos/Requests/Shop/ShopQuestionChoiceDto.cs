using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Requests.Shop;

public class ShopQuestionChoiceDto : IValidatableObject
{
    [Required]
    [StringLength(255, MinimumLength = 1)]
    public string Value { get; set; } = string.Empty;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        Value = Value.Trim();

        if (Value.Length == 0)
            yield return new("Shop question choice value cannot be empty", new[] { nameof(Value) });
    }
}