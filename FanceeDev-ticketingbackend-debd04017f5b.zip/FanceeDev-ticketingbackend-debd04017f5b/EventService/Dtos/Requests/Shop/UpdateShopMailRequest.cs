using System.ComponentModel.DataAnnotations;
using AngleSharp.Css.Values;
using AngleSharp.Html;
using WebApiCore.Utils.String;

namespace EventService.Dtos.Requests.Shop;

public class UpdateShopMailRequest : IValidatableObject
{
    public enum MailType
    {
        Purchase
    }

    [Required]
    public string SenderName { get; set; } = default!;

    [Required]
    public string Subject { get; set; } = default!;

    [Required]
    public string Content { get; set; } = default!;

    [Required]
    public MailType? Type { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Since Outlook on Windows does not support RGBA, we have to enable HEX.
        Color.UseHex = true;

        Content = Content.HtmlSanitize(new MinifyMarkupFormatter());

        yield return ValidationResult.Success!;
    }
}