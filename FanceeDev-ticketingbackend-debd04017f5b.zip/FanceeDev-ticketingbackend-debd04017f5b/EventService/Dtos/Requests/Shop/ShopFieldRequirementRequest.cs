using System.ComponentModel.DataAnnotations;
using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Requests.Shop;

public class ShopFieldRequirementRequest
{
    [Required]
    public ShopField Field { get; set; }

    [Required]
    public bool Enabled { get; set; }

    [Required]
    public bool Required { get; set; }
}