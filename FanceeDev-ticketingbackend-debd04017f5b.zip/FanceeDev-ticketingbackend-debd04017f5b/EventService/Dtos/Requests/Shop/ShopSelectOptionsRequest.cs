using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using WebApiCore.Dtos.Requests;

namespace EventService.Dtos.Requests.Shop;

public class ShopSelectOptionsRequest : SelectOptionsRequest<string>
{
    [FromQuery]
    public IList<Guid>? EventIds { get; set; }

    public override IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        EventIds ??= [];

        return base.Validate(validationContext);
    }
}