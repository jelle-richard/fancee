using System.ComponentModel.DataAnnotations;
using AngleSharp.Css.Values;
using AngleSharp.Html;
using EventService.Dtos.Shared.Event;
using WebApiCore.Utils.String;

namespace EventService.Dtos.Requests.Event;

public class UpdateEventMailRequest : IValidatableObject
{
    [Required]
    [StringLength(100)]
    public string SenderName { get; set; } = default!;

    [Required]
    [StringLength(100)]
    public string Subject { get; set; } = default!;

    [Required]
    public string Content { get; set; } = default!;

    [Required]
    public MailType? Type { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        // Since Outlook on Windows does not support RGBA, we have to enable HEX.
        Color.UseHex = true;

        Content = Content.HtmlSanitize(new MinifyMarkupFormatter());

        yield return ValidationResult.Success!;
    }
}