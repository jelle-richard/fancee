namespace EventService.Dtos.Requests.Event;

public class CopyEventRequest
{
    public bool CopyShops { get; set; }
    public bool CopyProducts { get; set; }
    public bool CopyPaymentMethods { get; set; }
    public bool CopyCategories { get; set; }
    public bool CopyTags { get; set; }
    public bool CopyMedia { get; set; }
}