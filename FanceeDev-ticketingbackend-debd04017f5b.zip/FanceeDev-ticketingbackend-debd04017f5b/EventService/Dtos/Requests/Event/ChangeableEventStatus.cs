﻿namespace EventService.Dtos.Requests.Event;

public enum ChangeableEventStatus
{
    Unpublished,
    Active,
    Cancelled,
    Concept
}