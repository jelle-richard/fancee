using System.ComponentModel.DataAnnotations;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils;

namespace EventService.Dtos.Requests.Event;

public class EventsDateFilterRequest
{
    [Required]
    public DateTime? StartDate { get; set; }

    [Required]
    public DateTime? EndDate { get; set; }

    public void Prepare<T>(ApiResponse<T> response)
    {
        if (StartDate >= EndDate)
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(StartDate)}' cannot be the same or after '{nameof(EndDate)}'");
    }
}