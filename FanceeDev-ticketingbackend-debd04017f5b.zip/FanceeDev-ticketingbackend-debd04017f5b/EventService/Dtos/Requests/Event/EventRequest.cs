using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils;
using WebApiCore.Utils.String;
using WebApiCore.Utils.Validation.Attributes;

namespace EventService.Dtos.Requests.Event;

public partial class EventRequest
{
    [Required]
    [StringLength(100, MinimumLength = 3, ErrorMessage = "Event name must be between 3 and 100 characters")]
    public string? Name { get; set; }

    [Required]
    public EventType? Type { get; set; }

    [Range(0, 100)]
    public int? MinAge { get; set; } = null;

    [Required]
    [PresentOrLater]
    public DateTime? StartDate { get; set; }

    [Required]
    public DateTime? EndDate { get; set; }

    public string? Description { get; set; }

    [Required]
    public string[]? Categories { get; set; }

    public CreateEventAddressRequest? Address { get; set; }

    public Guid OrganizationId { get; private set; }

    public IEnumerable<string>? Tags { get; set; }

    public int? ReservationTimeMinutes { get; set; } = null;

    [Required]
    [StringLength(50)]
    public string? TimezoneIdentification { get; set; }

    public Guid? SeatsIoEventId { get; set; }

    public bool IsSealed { get; set; }

    protected bool ValidateEndDate { get; init; } = true;

    private IList<EventCategory>? _eventCategories;

    public IList<EventTag> GetEventTags(Guid eventId) => Tags?.Select(t => new EventTag { EventId = eventId, Name = t }).ToList() ?? new List<EventTag>();
    public IList<EventCategory> GetEventCategories() => _eventCategories!;

    /// <summary>
    /// Prepares the request for use
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="response"></param>
    /// <param name="categoryValidationCallback"></param>
    /// <param name="validCountryCallback"></param>
    /// <param name="tagsValidationCallback"></param>
    /// <param name="verifySeatsIoEventIdCallback"></param>
    public async Task Prepare<T>(
        Guid organizationId,
        ApiResponse<T> response,
        Func<IEnumerable<string>, Task<IList<EventCategory>>>? categoryValidationCallback,
        Func<string, Task<bool>>? validCountryCallback,
        Func<IEnumerable<string>, Task<IList<Profanity>>>? tagsValidationCallback,
        Func<Guid, Task<bool>>? verifySeatsIoEventIdCallback)
    {
        Name = Name.HtmlSanitize().HtmlDecode().RemoveDoubleWhitespace();
        Description = Description?.HtmlSanitize(allowBase64Image: true);

        OrganizationId = organizationId;

        if (StartDate >= EndDate)
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(StartDate)}' cannot be the same or after '{nameof(EndDate)}'");

        if (ValidateEndDate && EndDate < DateTime.UtcNow)
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(EndDate)}' cannot be before the current time");

        if (categoryValidationCallback != null)
            _eventCategories = await categoryValidationCallback.Invoke(Categories!);

        if (validCountryCallback != null && Address?.CountryCode != null && !await validCountryCallback.Invoke(Address.CountryCode))
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(Address)}.{nameof(Address.CountryCode)}' is not valid");

        if (tagsValidationCallback != null && Tags != null)
        {
            var profanities = await tagsValidationCallback.Invoke(Tags);

            Tags = Tags.Select(tag => profanities.Aggregate(tag, (current, profanity) => current.Replace(profanity.Word, string.Empty, StringComparison.InvariantCultureIgnoreCase))).ToList();
        }

        if (StripHTML().Replace(Description ?? "", string.Empty).Length > 2000)
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(Description)}' is to big, please refrain to 2000 characters.");

        if (!DateTimeUtils.TimezoneIdentifications.Contains(TimezoneIdentification))
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(TimezoneIdentification)}' is not valid");

        await ValidateSeatsIoEventId(verifySeatsIoEventIdCallback, response);
    }

    /// <summary>
    /// Validates the SeatsIO Event Id for seating events.
    /// </summary>
    /// <param name="verifySeatsIoEventIdCallback"></param>
    /// <param name="response"></param>
    /// <typeparam name="T"></typeparam>
    private async Task ValidateSeatsIoEventId<T>(Func<Guid, Task<bool>>? verifySeatsIoEventIdCallback, ApiResponse<T> response)
    {
        if (Type != EventType.Seating)
        {
            SeatsIoEventId = null;
            return;
        }

        if (SeatsIoEventId == null)
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(SeatsIoEventId)}' is required when event type is seating");
        else if (verifySeatsIoEventIdCallback != null && !await verifySeatsIoEventIdCallback((Guid)SeatsIoEventId))
            response.AddError(ErrorCode.ExceptionInvalidData, $"'{nameof(SeatsIoEventId)}' is not a valid SeatsIO event id");
    }

    [GeneratedRegex("<.*?>")]
    private static partial Regex StripHTML();
}