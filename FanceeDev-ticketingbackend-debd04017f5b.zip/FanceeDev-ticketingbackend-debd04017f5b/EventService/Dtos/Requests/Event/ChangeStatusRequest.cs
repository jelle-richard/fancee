﻿using System.ComponentModel.DataAnnotations;

namespace EventService.Dtos.Requests.Event;

public class ChangeStatusRequest
{
    [Required]
    public ChangeableEventStatus? Status { get; set; }
}