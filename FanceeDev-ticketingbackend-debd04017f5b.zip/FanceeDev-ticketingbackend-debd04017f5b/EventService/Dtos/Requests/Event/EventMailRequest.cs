using System.ComponentModel.DataAnnotations;
using EventService.Dtos.Shared.Event;

namespace EventService.Dtos.Requests.Event;

public class EventMailRequest
{
    [Required]
    public MailType Type { get; set; }
}