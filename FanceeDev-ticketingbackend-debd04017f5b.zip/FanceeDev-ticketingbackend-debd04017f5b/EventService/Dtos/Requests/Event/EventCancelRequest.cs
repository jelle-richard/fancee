using FanceeData.Models.Ticketing;

namespace EventService.Dtos.Requests.Event;

public class EventCancelRequest
{
    public string? Reason { get; set; }
    public required EventCancellationRefundOption PreferredRefundOption { get; set; } = EventCancellationRefundOption.FullRefund;
}