﻿using System.ComponentModel.DataAnnotations;
using WebApiCore.Dtos.Shared.Address;

namespace EventService.Dtos.Requests.Event;

public class CreateEventAddressRequest : IAddressDto
{
    public string? Venue { get; set; }

    [StringLength(2, MinimumLength = 2)]
    public string? CountryCode { get; set; }

    public string? City { get; set; }

    public string? PostalCode { get; set; }

    public string? Street { get; set; }

    public string? HouseNumber { get; set; }

    public decimal? Latitude { get; set; }

    public decimal? Longitude { get; set; }

    /// <summary>
    /// Returns true if all values in the request are null or empty.
    /// </summary>
    /// <returns></returns>
    public bool IsEmpty() =>
        string.IsNullOrWhiteSpace(Venue)
        && string.IsNullOrWhiteSpace(CountryCode)
        && string.IsNullOrWhiteSpace(City)
        && string.IsNullOrWhiteSpace(PostalCode)
        && string.IsNullOrWhiteSpace(Street)
        && string.IsNullOrWhiteSpace(HouseNumber)
        && Latitude == null
        && Longitude == null;
}