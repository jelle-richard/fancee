using System.ComponentModel.DataAnnotations;
using WebApiCore.Dtos.Requests.Filters.Pagination;
using WebApiCore.Dtos.Shared.Filters;
using WebApiCore.Utils;

namespace EventService.Dtos.Requests.Event;

public class EventsBalanceMutationsRequestFilter : SearchQueryFilter, IValidatableObject
{
    [Required]
    public RangeFilter<DateTime> DateRange { get; set; } = default!;

    public IEnumerable<string>? CountryCodes { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (DateRange.Maximum is null || DateRange.Minimum is null)
            yield return new("Minimum and/or maximum date can not be null.");

        var minimum = (DateTime)DateRange.Minimum!;
        var maximum = (DateTime)DateRange.Maximum!;

        if (maximum - minimum > TimeSpan.FromDays(365))
            yield return new("Maximum difference between the minimum- and maxmimum date is 1 year.");

        if (CountryCodes != null && CountryCodes.Any(code => code.Length != 2))
            yield return new("Every country code must be exactly two characters long to comply with the ISO 3166 standard");

        DateRange = new()
        {
            Minimum = minimum.ToDateOnly().ToDateTime(new(0, 0)),
            Maximum = maximum.ToDateOnly().ToDateTime(new(23, 59, 59))
        };
    }
}