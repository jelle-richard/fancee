using System.ComponentModel.DataAnnotations;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Requests.Filters.Pagination;
using WebApiCore.Dtos.Shared.Filters;

namespace EventService.Dtos.Requests.Event;

public class EventsRequestFilter : SearchQueryFilter, IValidatableObject
{
    public IEnumerable<EventStatus>? EventStates { get; set; } = new List<EventStatus>();

    public RangeFilter<DateTime>? DateRange { get; set; }

    public IEnumerable<string>? CountryCodes { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (CountryCodes != null && CountryCodes.Any(code => code.Length != 2))
            yield return new("Every country code must be exactly two characters long to comply with the ISO 3166 standard");

        DateRange = new()
        {
            Minimum = DateRange?.Minimum?.Date,
            Maximum = DateRange?.Maximum == null ? null : DateRange?.Maximum?.Date + new TimeSpan(23, 59, 59)
        };
    }
}