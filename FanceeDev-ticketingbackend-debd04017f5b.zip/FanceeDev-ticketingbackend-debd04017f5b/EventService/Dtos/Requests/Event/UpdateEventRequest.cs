﻿namespace EventService.Dtos.Requests.Event;

public class UpdateEventRequest : EventRequest
{
    public UpdateEventRequest()
    {
        ValidateEndDate = false;
    }
}