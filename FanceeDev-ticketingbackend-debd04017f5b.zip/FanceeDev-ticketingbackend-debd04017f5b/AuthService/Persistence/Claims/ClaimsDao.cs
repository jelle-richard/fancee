using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Persistence.Claims;

public class ClaimsDao : IClaimsDao
{
    private readonly TicketingContext _dbContext;

    public ClaimsDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<string>> UserClaimsAsync(Guid userId)
    {
        return await _dbContext.UserClaim.Where(uc => uc.UserId == userId)
            .Select(uc => uc.ClaimValue)
            .ToListAsync();
    }

    public async Task AlterUserClaimsAsync(Guid userId, IEnumerable<string> claims)
    {
        var userClaims = _dbContext.UserClaim.Where(uc => uc.UserId == userId);
        _dbContext.UserClaim.RemoveRange(userClaims);

        await _dbContext.SaveChangesAsync();

        var claimEntities = claims.Select(c => new UserClaim
        {
            ClaimValue = c,
            UserId = userId,
            ClaimType = ClaimType.Permission
        });

        await _dbContext.UserClaim.AddRangeAsync(claimEntities);
        await _dbContext.SaveChangesAsync();
    }
}