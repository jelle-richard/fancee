using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AuthService.Persistence.Claims;

public interface IClaimsDao
{
    /// <summary>
    /// Gets the claims that are assigned to the user.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<IEnumerable<string>> UserClaimsAsync(Guid userId);

    /// <summary>
    /// Alters the users claims by overwriting them with the new claims.
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="claims"></param>
    /// <returns></returns>
    public Task AlterUserClaimsAsync(Guid userId, IEnumerable<string> claims);
}