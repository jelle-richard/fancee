﻿using System;
using System.Linq.Expressions;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;

namespace AuthService.Persistence.User;

public interface IUserContactInfoDao
{
    /// <summary>
    /// Gets the users contact info by user id
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="includes"></param>
    /// <returns></returns>
    public Task<UserContactInfo> GetAsync(Guid userId, params Expression<Func<UserContactInfo, object>>[] includes);
}