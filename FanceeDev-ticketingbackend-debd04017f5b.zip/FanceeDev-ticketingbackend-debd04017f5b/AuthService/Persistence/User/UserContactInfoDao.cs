﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Utils.Query;

namespace AuthService.Persistence.User;

public class UserContactInfoDao : IUserContactInfoDao
{
    private readonly TicketingContext _dbContext;

    public UserContactInfoDao(TicketingContext context)
    {
        _dbContext = context;
    }

    public async Task<UserContactInfo> GetAsync(Guid userId, params Expression<Func<UserContactInfo, object>>[] includes)
    {
        return await _dbContext.UserContactInfos.Where(uci => uci.UserId == userId)
            .IncludeMany(includes)
            .FirstOrDefaultAsync();
    }
}