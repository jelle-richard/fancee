#nullable enable

using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;

namespace AuthService.Persistence.User;

public interface IUserDao
{
    /// <summary>
    /// Gets a user by email with optional table includes.
    /// </summary>
    /// <param name="email"></param>
    /// <param name="includes"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.User?> GetAsync(string email, params Expression<Func<FanceeData.Models.Ticketing.User, object>>[] includes);

    /// <summary>
    /// Gets a user by id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.User?> GetAsync(Guid id);

    /// <summary>
    /// Gets a user by id.
    /// </summary>
    /// <param name="id"></param>
    /// <param name="includes"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.User?> GetAsync(Guid id, params Expression<Func<FanceeData.Models.Ticketing.User, object>>[] includes);

    /// <summary>
    /// Checks if the user exists by its id.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<bool> ExistsAsync(Guid userId);

    /// <summary>
    /// Gets the user by fancee users id.
    /// </summary>
    /// <param name="fanceeUsersId"></param>
    /// <param name="includes"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.User?> ByFanceeUsersIdAsync(Guid fanceeUsersId, params Expression<Func<FanceeData.Models.Ticketing.User, object>>[] includes);

    /// <summary>
    /// Updates a user's record.
    /// </summary>
    /// <param name="user"></param>
    /// <returns></returns>
    public Task UpdateAsync(FanceeData.Models.Ticketing.User user);

    /// <summary>
    /// Gets the currency of a organization.
    /// </summary>
    /// <param name="email"></param>
    /// <returns></returns>
    public Task<Currency?> OrganizationCurrencyAsync(string email);

    /// <summary>
    /// Gets the amount of new changelog entries since last login.
    /// </summary>
    /// <param name="date"></param>
    /// <param name="userType"></param>
    /// <param name="countryCode"></param>
    /// <returns></returns>
    public Task<int> ChangelogsAfterDateAsync(DateTime date, UserType userType, string[] countryCode);

    /// <summary>
    /// Gets the admin country manager or null for given userId.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<CountryManager?> AdminCountryManagerAsync(Guid userId);

    /// <summary>
    /// Gets the organizations that the user can manage.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<IEnumerable<Organization>> ManagedOrganizationsAsync(Guid userId);

    /// <summary>
    /// Gets the users claims for the specified organization.
    /// </summary>
    /// <param name="organizationId"></param>
    /// <param name="managingUserId"></param>
    /// <returns></returns>
    public Task<IEnumerable<string>> ManageableOrganizationUserClaims(Guid organizationId, Guid managingUserId);
}