#nullable enable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using WebApiCore.Utils.Query;

namespace AuthService.Persistence.User;

public class UserDao : IUserDao
{
    private readonly TicketingContext _dbContext;

    public UserDao(TicketingContext context)
    {
        _dbContext = context;
    }

    public async Task<FanceeData.Models.Ticketing.User?> GetAsync(string email, params Expression<Func<FanceeData.Models.Ticketing.User, object>>[] includes)
    {
        return await _dbContext.Users.Where(u => u.Email == email)
            .IncludeMany(includes)
            .FirstOrDefaultAsync();
    }

    public async Task<FanceeData.Models.Ticketing.User?> GetAsync(Guid id) => await _dbContext.Users.FindAsync(id);

    public async Task<FanceeData.Models.Ticketing.User?> GetAsync(Guid id, params Expression<Func<FanceeData.Models.Ticketing.User, object>>[] includes)
    {
        return await _dbContext.Users.Where(u => u.Id == id)
            .IncludeMany(includes)
            .FirstOrDefaultAsync();
    }

    public async Task<bool> ExistsAsync(Guid userId)
    {
        return await _dbContext.Users.Where(u => u.Id == userId)
            .AnyAsync();
    }

    public async Task<FanceeData.Models.Ticketing.User?> ByFanceeUsersIdAsync(Guid fanceeUsersId, params Expression<Func<FanceeData.Models.Ticketing.User, object>>[] includes)
    {
        return await _dbContext.Users.Where(u => u.FanceeUsersId == fanceeUsersId)
            .IncludeMany(includes)
            .FirstOrDefaultAsync();
    }

    public async Task UpdateAsync(FanceeData.Models.Ticketing.User user)
    {
        _dbContext.Users.Update(user);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<Currency?> OrganizationCurrencyAsync(string email)
    {
        return await _dbContext.Organizations.Where(o => o.User.Email == email)
            .Select(o => o.CurrencyNavigation)
            .FirstOrDefaultAsync();
    }

    public async Task<int> ChangelogsAfterDateAsync(DateTime date, UserType userType, string[] countryCode)
    {
        var query = _dbContext.Changelogs.Where(c => c.ReleaseDate > date)
            .Where(c => c.AppliesToUserType == userType);

        if (!countryCode.IsNullOrEmpty())
            query = query.Where(c => countryCode.Contains(c.CountryCode));

        return await query.CountAsync();
    }

    public async Task<CountryManager?> AdminCountryManagerAsync(Guid userId)
    {
        var countryManager = await _dbContext.Admins
            .Where(a => a.UserId == userId && a.Role == AdminRole.CountryManager)
            .FirstOrDefaultAsync();

        if (countryManager == null)
            return null;

        return await _dbContext.CountryManagers.Where(cm => cm.UserId == countryManager.UserId)
            .FirstAsync();
    }

    public async Task<IEnumerable<Organization>> ManagedOrganizationsAsync(Guid userId)
    {
        return await _dbContext.Organizations.Where(o => o.UserId == userId || o.OrganizationUsers.Any(ou => ou.UserId == userId))
            .Include(o => o.User.UserMedia.File)
            .ToListAsync();
    }

    public async Task<IEnumerable<string>> ManageableOrganizationUserClaims(Guid organizationId, Guid managingUserId)
    {
        return await _dbContext.OrganizationUserClaims.Where(ouc => ouc.OrganizationId == organizationId || ouc.OrganizationId == managingUserId)
            .Where(ouc => ouc.UserId == managingUserId)
            .Select(ouc => ouc.ClaimValue)
            .ToListAsync();
    }
}