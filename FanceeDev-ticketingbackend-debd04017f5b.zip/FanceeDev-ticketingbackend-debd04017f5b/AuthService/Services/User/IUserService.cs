using System;
using System.Threading.Tasks;

namespace AuthService.Services.User;

public interface IUserService
{
    /// <summary>
    /// Gets the fancee user id by user id.
    /// </summary>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task<Guid> FanceeUsersIdAsync(Guid userId);
}