using System;
using System.Threading.Tasks;
using AuthService.Persistence.User;
using WebApiCore.Exceptions.User;

namespace AuthService.Services.User;

public class UserService : IUserService
{
    private readonly IUserDao _userDao;

    public UserService(IUserDao userDao)
    {
        _userDao = userDao;
    }

    public async Task<Guid> FanceeUsersIdAsync(Guid userId) => (await _userDao.GetAsync(userId))?.FanceeUsersId ?? throw new UserNotFoundException();
}