using WebApiCore.Exceptions;

namespace AuthService.Services.Auth.Exceptions;

/// <summary>
/// Exception that signals that the termination date of admin country manager has been reached.
/// </summary>
public class InvalidTerminationDateOfCountryManagerException()
    : BadRequestApiException("Termination date of admin country manager has been reached");