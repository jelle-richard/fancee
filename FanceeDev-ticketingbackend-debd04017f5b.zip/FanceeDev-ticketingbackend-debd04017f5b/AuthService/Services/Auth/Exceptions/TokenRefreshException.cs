using WebApiCore.Exceptions;
using WebApiCore.Utils;

namespace AuthService.Services.Auth.Exceptions;

public class TokenRefreshException()
    : BadRequestApiException("The token is not valid or is expired", ErrorCode.ExceptionRelogRequired);