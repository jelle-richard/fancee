﻿using WebApiCore.Exceptions;

namespace AuthService.Services.Auth.Exceptions;

/// <summary>
/// Exception that signals that the given token is invalid.
/// </summary>
public class InvalidTokenException()
    : BadRequestApiException("Invalid token provided");