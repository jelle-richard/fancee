using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AuthService.Dtos.Requests.Auth;
using AuthService.Dtos.Responses.Auth;
using AuthService.Dtos.Responses.Sessions;

namespace AuthService.Services.Auth;

/// <summary>
/// AuthService interface.
/// </summary>
public interface IAuthService
{
    /// <summary>
    /// Gets a new token for the email and password.
    /// </summary>
    /// <param name="email">Email of the user that wants to log in</param>
    /// <param name="password">Password of the user that wants to log in</param>
    /// <returns>TokenResponse object with the token that is used for further authentication</returns>
    public Task<TokenResponse> TokenAsync(string email, string password);

    /// <summary>
    /// Gets a new token for the app team id.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <returns></returns>
    public Task<AppTeamTokenResponse> TokenAsync(Guid appTeamId);

    /// <summary>
    /// Invalidates the given token.
    /// </summary>
    /// <param name="token">The token to invalidate</param>
    /// <returns></returns>
    public Task InvalidateAsync(string token);

    /// <summary>
    /// Invalidates the given token.
    /// </summary>
    /// <param name="token"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    public Task InvalidateByAdminAsync(string token, Guid userId);

    /// <summary>
    /// Gets all valid sessions for the user.
    /// </summary>
    /// <param name="fanceeUsersId"></param>
    /// <returns></returns>
    public Task<IEnumerable<SessionResponse>> ValidSessionsAsync(Guid fanceeUsersId);

    /// <summary>
    /// Refreshes a token.
    /// </summary>
    /// <param name="token"></param>
    /// <returns></returns>
    public Task<TokenResponse> RefreshTokenAsync(string token);

    /// <summary>
    /// Refreshes an app team token.
    /// </summary>
    /// <param name="token"></param>
    /// <returns></returns>
    public Task<AppTeamTokenResponse> RefreshAppTeamTokenAsync(string token);

    /// <summary>
    /// Gets a takeover token.
    /// </summary>
    /// <param name="request"></param>
    /// <param name="adminFanceeUsersId"></param>
    /// <param name="adminUserId"></param>
    /// <returns></returns>
    public Task<TokenResponse> TakeoverTokenAsync(TakeoverRequest request, Guid adminFanceeUsersId, Guid adminUserId);
}