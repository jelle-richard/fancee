using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AuthService.Dtos;
using AuthService.Dtos.Requests.Auth;
using AuthService.Dtos.Responses.Auth;
using AuthService.Dtos.Responses.Sessions;
using AuthService.Persistence.User;
using AuthService.Services.Auth.Exceptions;
using AuthService.Utils.Adapter.Claim;
using AuthService.Utils.Adapter.Organization;
using AuthService.Utils.Adapter.Session;
using AuthService.Utils.Token;
using AuthService.Utils.UserAgent;
using FanceeAuthentication.Exceptions;
using FanceeAuthentication.Providers.Authentication;
using FanceeAuthentication.Providers.Session;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Dtos.Responses.File;
using WebApiCore.Exceptions;
using WebApiCore.Services.AppTeam;
using WebApiCore.Services.Country;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Logging;
using WebApiCore.Utils;
using WebApiCore.Utils.Adapter.Currency;
using WebApiCore.Utils.HttpContext;
using Client = FanceeUsers.Models.Client;
using InvalidTokenException = AuthService.Services.Auth.Exceptions.InvalidTokenException;
using UserNotFoundException = WebApiCore.Exceptions.User.UserNotFoundException;

namespace AuthService.Services.Auth;

public class AuthService : IAuthService
{
    private readonly IUserDao _userDao;
    private readonly IUserContactInfoDao _userContactInfoDao;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IAuthenticationProvider _authenticationProvider;
    private readonly ISessionProvider _sessionProvider;
    private readonly IAppTeamService _appTeamService;
    private readonly IJwtTokenProvider _jwtTokenProvider;
    private readonly IDeploymentEnvironmentService _deploymentEnvironmentService;
    private readonly ICountryService _countryService;
    private readonly IUserLoggingService _userLoggingService;

    public AuthService(IUserDao userDao, IUserContactInfoDao userContactInfoDao, IHttpContextAccessor httpContextAccessor, IAuthenticationProvider authenticationProvider, ISessionProvider sessionProvider, IAppTeamService appTeamService, IJwtTokenProvider jwtTokenProvider, IDeploymentEnvironmentService deploymentEnvironmentService, ICountryService countryService, IUserLoggingService userLoggingService)
    {
        _userDao = userDao;
        _userContactInfoDao = userContactInfoDao;
        _httpContextAccessor = httpContextAccessor;
        _authenticationProvider = authenticationProvider;
        _sessionProvider = sessionProvider;
        _appTeamService = appTeamService;
        _jwtTokenProvider = jwtTokenProvider;
        _deploymentEnvironmentService = deploymentEnvironmentService;
        _countryService = countryService;
        _userLoggingService = userLoggingService;
    }

    public async Task<TokenResponse> TokenAsync(string email, string password)
    {
        FanceeAuthentication.Dtos.Responses.TokenResponse tokenResponse;

        try
        {
            tokenResponse = await _authenticationProvider.TokenAsync(email, password, Client.Ticketing, async userId =>
            {
                var ticketingUser = await _userDao.ByFanceeUsersIdAsync(userId);

                return new()
                {
                    Device = UserAgentUtils.GetDeviceFromHeaders(_httpContextAccessor.HttpContext?.Request.Headers) ?? "Unknown",
                    IpAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress ?? IPAddress.None,
                    UserId = ticketingUser?.Id,
                    UserType = ((int?)ticketingUser?.Type)?.ToString() ?? string.Empty
                };
            });
        }
        catch (AuthenticationException)
        {
            throw new UserNotFoundException();
        }
        catch (DbUpdateException)
        {
            // Note: a DbUpdateException can occur when we try to issue 2 tokens at the exact same time for
            // the same user.
            // E.g. when this method gets called twice in the same second. Sadly, we can not rate-limit this API
            // as doing so will block the login API for everyone with the same IP (problematic if multiple
            // users try to login on a shared network in quick concession (e.g. logging in while purchasing products)).
            throw new TooManyRequestsException();
        }

        var response = await CreateTokenResponseAsync(tokenResponse, email);

        if (response.User == null)
            return response.Token;

        if (response.User.Type.IsAdmin())
        {
            await ValidateTerminationDateForCountryManagerAsync(response);

            await _userLoggingService.LogAsync(response.User.Id, "Has logged into the CRM");
        }

        if (response.User.Type.IsOrganization() || response.User.Type.IsClient())
        {
            var env = await _deploymentEnvironmentService.GetAsync();
            var manageableOrganizations = await _userDao.ManagedOrganizationsAsync(response.User.Id);
            var manageableOrganizationsResponse = new List<ManageableOrganization>();

            foreach (var manageableOrganization in manageableOrganizations)
            {
                IEnumerable<string> manageableClaims;
                if (manageableOrganization.UserId == response.User.Id)
                    manageableClaims = response.User.UserClaims.Select(uc => uc.ClaimValue);
                else
                    manageableClaims = await _userDao.ManageableOrganizationUserClaims(manageableOrganization.Id, response.User.Id);

                manageableOrganizationsResponse.Add(manageableOrganization.ToManageableOrganization(env, response.User.Id, manageableClaims));
            }

            response.Token.ManageableOrganizations = manageableOrganizationsResponse.OrderByDescending(mor => mor.IsOwner);
        }

        response.User.LastLogin = DateTime.UtcNow;
        await _userDao.UpdateAsync(response.User);

        return response.Token;
    }

    public async Task<AppTeamTokenResponse> TokenAsync(Guid appTeamId)
    {
        if (!await _appTeamService.ExistsAsync(appTeamId))
            throw new AppTeamNotFoundException();

        var refreshableUntil = DateTimeOffset.UtcNow.AddDays(_jwtTokenProvider.RefreshDays);

        var token = _jwtTokenProvider.New(new AppTeamTokenMetadata
        {
            TeamId = appTeamId,
            RefreshableUntil = refreshableUntil.ToUnixTimeSeconds()
        }, out var validUntil, out _);

        var appTeamMetadata = await _appTeamService.OrganizationAppTeamMetadataAsync(appTeamId);

        return new()
        {
            Token = token,
            ValidUntil = validUntil,
            RefreshableUntil = refreshableUntil.DateTime,
            Name = appTeamMetadata.Name,
            Organization = appTeamMetadata.Organization.Name,
            Claims = appTeamMetadata.ParseClaimsFromAppTeam()
        };
    }

    public async Task InvalidateAsync(string token)
    {
        var fanceeUsersId = _httpContextAccessor.HttpContext?.User.GetFanceeUsersId() ?? throw new FanceeAuthentication.Exceptions.UserNotFoundException();

        await InvalidateAsync(token, fanceeUsersId);
    }

    public async Task InvalidateByAdminAsync(string token, Guid userId)
    {
        if (!(_httpContextAccessor.HttpContext?.User.IsAdmin() ?? false))
            throw new InvalidTokenException();

        var fanceeUsersId = (await _userDao.GetAsync(userId))
            ?.FanceeUsersId ?? throw new FanceeAuthentication.Exceptions.UserNotFoundException();

        await InvalidateAsync(token, fanceeUsersId);
    }

    public async Task<IEnumerable<SessionResponse>> ValidSessionsAsync(Guid fanceeUsersId)
    {
        return (await _sessionProvider.ActiveSessionsAsync(fanceeUsersId, Client.Ticketing))
            .OrderBy(st => st.ValidUntil)
            .ToSessionResponses();
    }

    public async Task<TokenResponse> RefreshTokenAsync(string token)
    {
        try
        {
            var newToken = await _authenticationProvider.RefreshTokenAsync(token, Client.Ticketing);
            var user = await _userDao.ByFanceeUsersIdAsync(newToken.UserId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization);

            var response = await CreateTokenResponseAsync(newToken, user);

            return response.Token;
        }
        catch (AuthenticationException)
        {
            throw new TokenRefreshException();
        }
        catch (DbUpdateConcurrencyException)
        {
            // Note: a DbUpdateConcurrencyException can occur when we try to refresh 2 tokens at the exact same time for
            // the same user.
            // E.g. when this method gets called twice in the same second. Sadly, we can not rate-limit this API
            // as doing so will block the login API for everyone with the same IP (problematic if multiple
            // users try to refresh on a shared network in quick concession).
            throw new TooManyRequestsException();
        }
    }

    public async Task<AppTeamTokenResponse> RefreshAppTeamTokenAsync(string token)
    {
        var tokenMetadata = _jwtTokenProvider.Parse<AppTeamTokenMetadata>(token, true);

        if (DateTime.UtcNow > DateTimeOffset.FromUnixTimeSeconds(tokenMetadata.RefreshableUntil))
            throw new TokenRefreshException();

        return await TokenAsync(tokenMetadata.TeamId);
    }

    public async Task<TokenResponse> TakeoverTokenAsync(TakeoverRequest request, Guid adminFanceeUsersId, Guid adminUserId)
    {
        var user = await _userDao.GetAsync((Guid)request.AccountId!, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization) ?? throw new UserNotFoundException();

        if (user.Type.IsAdmin())
            throw new UserNotFoundException();

        try
        {
            var newToken = await _authenticationProvider.AdminTakeoverTokenAsync((Guid)user.FanceeUsersId!, Client.Ticketing, adminFanceeUsersId, request.AdminPassword, async userId =>
            {
                var ticketingUser = await _userDao.ByFanceeUsersIdAsync(userId);

                return new()
                {
                    Device = UserAgentUtils.GetDeviceFromHeaders(_httpContextAccessor.HttpContext?.Request.Headers) ?? "Unknown",
                    IpAddress = _httpContextAccessor.HttpContext?.Connection.RemoteIpAddress ?? IPAddress.None,
                    UserId = ticketingUser?.Id,
                    UserType = ticketingUser?.Type.ToString() ?? string.Empty
                };
            });

            var result = await CreateTokenResponseAsync(newToken, user);

            await _userLoggingService.LogAsync(adminUserId, $"Has performed an account takeover on the organization {user.Email}");

            if (!result.User.Type.IsOrganization())
                return result.Token;

            var env = await _deploymentEnvironmentService.GetAsync();
            result.Token.ManageableOrganizations = (await _userDao.ManagedOrganizationsAsync(result.User.Id))
                .Select(mo => mo.ToManageableOrganization(env, result.User.Id, []))
                .OrderByDescending(mor => mor.IsOwner);

            return result.Token;
        }
        catch (AuthenticationException)
        {
            throw new UserNotFoundException();
        }
        catch (DbUpdateException)
        {
            // Note: a DbUpdateException can occur when we try to issue 2 tokens at the exact same time for
            // the same user.
            // E.g. when this method gets called twice in the same second. Sadly, we can not rate-limit this API
            // as doing so will block the login API for everyone with the same IP (problematic if multiple
            // users try to login on a shared network in quick concession (e.g. logging in while purchasing products)).
            throw new TooManyRequestsException();
        }
    }

    private async Task InvalidateAsync(string token, Guid fanceeUsersId)
    {
        try
        {
            await _sessionProvider.InvalidateAsync(token, fanceeUsersId, Client.Ticketing);
        }
        catch (FanceeAuthentication.Exceptions.InvalidTokenException)
        {
            throw new InvalidTokenException();
        }
    }

    private async Task<CreateTokenResult> CreateTokenResponseAsync(FanceeAuthentication.Dtos.Responses.TokenResponse tokenResponse, string email)
    {
        var user = await _userDao.GetAsync(email, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization);

        return await CreateTokenResponseAsync(tokenResponse, user);
    }

    private async Task<CreateTokenResult> CreateTokenResponseAsync(FanceeAuthentication.Dtos.Responses.TokenResponse tokenResponse, FanceeData.Models.Ticketing.User user)
    {
        if (user == null)
        {
            // We have a valid login, but cannot find a user locally.
            // This means the user is created at another platform and we should ask for additional data.

            return new()
            {
                Token = new()
                {
                    Token = tokenResponse.Token,
                    ValidUntil = tokenResponse.ValidUntil,
                    RefreshableUntil = tokenResponse.RefreshableUntil,
                    User = null
                },
                User = null
            };
        }

        var userContactInfo = await _userContactInfoDao.GetAsync(user.Id, uci => uci.Address);

        var newChangelogs = 0;
        Currency currency = null;

        if (user.IsOrganization())
            currency = await _userDao.OrganizationCurrencyAsync(user.Email);

        var countryCodes = user.Type.IsAdmin()
            ? (await _countryService.RestrictCountryCodesAsync(user.Id, null)).ToArray()
            : [];

        if (user.LastLogin != null)
            newChangelogs = await _userDao.ChangelogsAfterDateAsync((DateTime)user.LastLogin, user.Type, countryCodes);

        ImageFileResponse imageFileResponse = null;
        if (user.UserMedia?.File != null)
        {
            var env = await _deploymentEnvironmentService.GetAsync();

            imageFileResponse = new()
            {
                Id = user.UserMedia.File.Id,
                Url = $"{env.Scheme}://{env.ContentDeliveryNetworkBaseUrl}/{user.UserMedia.File.Path}",
                FocalPointHeightPercentage = user.UserMedia.FocalPointHeightPercentage,
                FocalPointWidthPercentage = user.UserMedia.FocalPointWidthPercentage
            };
        }

        var response = new TokenResponse
        {
            Token = tokenResponse.Token,
            ValidUntil = tokenResponse.ValidUntil,
            RefreshableUntil = tokenResponse.RefreshableUntil,
            Claims = user.UserClaims.Where(uc => uc.ClaimType == ClaimType.Permission).Select(uc => uc.ClaimValue),
            User = new()
            {
                Id = user.Id,
                Email = user.Email,
                FirstName = userContactInfo?.FirstName,
                LastName = userContactInfo?.LastName,
                Type = user.Type,
                AvatarFile = imageFileResponse,
                LastLogin = user.LastLogin,
                Currency = currency?.ToCurrencyResponse(),
                CountryCodes = countryCodes,
                IsProfileComplete = user.Organization?.IsProfileComplete ?? true,
                ChangelogsSinceLastLogin = newChangelogs,
                PublicCode = user.Organization?.PublicCode
            }
        };

        return new()
        {
            Token = response,
            User = user
        };
    }

    private async Task ValidateTerminationDateForCountryManagerAsync(CreateTokenResult response)
    {
        var countryManager = await _userDao.AdminCountryManagerAsync(response.User.Id);

        if (countryManager != null && countryManager.TerminatedOn >= DateTime.UtcNow)
            throw new InvalidTerminationDateOfCountryManagerException();
    }
}