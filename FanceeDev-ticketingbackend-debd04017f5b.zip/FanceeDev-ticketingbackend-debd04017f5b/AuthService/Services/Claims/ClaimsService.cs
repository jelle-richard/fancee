using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthService.Persistence.Claims;
using AuthService.Persistence.User;
using AuthService.Utils.Adapter.Claim;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses.Claim;
using WebApiCore.Exceptions.User;
using WebApiCore.Persistence.AppTeam;
using WebApiCore.Utils.Claim;

namespace AuthService.Services.Claims;

public class ClaimsService : IClaimsService
{
    private readonly IClaimsDao _claimsDao;
    private readonly IUserDao _userDao;
    private readonly IAppTeamDao _appTeamDao;

    public ClaimsService(IClaimsDao claimsDao, IUserDao userDao, IAppTeamDao appTeamDao)
    {
        _claimsDao = claimsDao;
        _userDao = userDao;
        _appTeamDao = appTeamDao;
    }

    public IEnumerable<ClaimHierarchyCategoriesResponse> ListPlatformClaims(UserType? limitTo) => ClaimUtil.ListPlatformClaims(limitTo);

    public async Task<IEnumerable<string>> UserClaimsAsync(Guid userId) => !await _userDao.ExistsAsync(userId) ? throw new UserNotFoundException() : await _claimsDao.UserClaimsAsync(userId);

    public async Task AlterUserClaimsAsync(Guid userId, IEnumerable<string> claims, UserType? userType)
    {
        if (!await _userDao.ExistsAsync(userId))
            throw new UserNotFoundException();

        claims = claims.ToList();

        ClaimUtil.ValidateClaims(claims, userType);

        await _claimsDao.AlterUserClaimsAsync(userId, claims);
    }

    public async Task<IEnumerable<string>> AppTeamClaimsAsync(Guid appTeamId)
    {
        var appTeam = await _appTeamDao.OrganizationAppTeamMetadataAsync(appTeamId);

        return appTeam.ParseClaimsFromAppTeam();
    }
}