using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses.Claim;

namespace AuthService.Services.Claims;

public interface IClaimsService
{
    /// <summary>
    /// Gets the permissions of the platform per category with a hierarchy of dependencies.
    /// </summary>
    /// <param name="limitTo">If not null, this method will filter the claims that apply to the user type.</param>
    /// <returns></returns>
    public IEnumerable<ClaimHierarchyCategoriesResponse> ListPlatformClaims(UserType? limitTo);

    /// <summary>
    /// Gets the claims that are assigned to the user.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<string>> UserClaimsAsync(Guid userId);

    /// <summary>
    /// Alters the users claims by overwriting them with the new claims.
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="claims"></param>
    /// <param name="userType"></param>
    public Task AlterUserClaimsAsync(Guid userId, IEnumerable<string> claims, UserType? userType);

    /// <summary>
    /// Gets the current claims of the app team.
    /// </summary>
    /// <param name="appTeamId"></param>
    /// <returns></returns>
    public Task<IEnumerable<string>> AppTeamClaimsAsync(Guid appTeamId);
}