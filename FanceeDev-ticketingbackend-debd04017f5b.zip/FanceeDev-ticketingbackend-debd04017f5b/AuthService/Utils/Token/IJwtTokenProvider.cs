using System;
using FanceeAuthentication.Providers.Token;

namespace AuthService.Utils.Token;

public interface IJwtTokenProvider
{
    public int RefreshDays { get; }

    /// <summary>
    /// Generates a new token with the metadata.
    /// </summary>
    /// <param name="tokenMetadata">Metadata to embed in the token</param>
    /// <param name="expiresAt">DateTime when the token will expire</param>
    /// <param name="refreshableUntil">DateTime when the token is refreshable</param>
    /// <param name="isTakeover">If true, the takeover time will be used instead</param>
    /// <returns></returns>
    public string New(ITokenMetadata tokenMetadata, out DateTime expiresAt, out DateTime refreshableUntil, bool isTakeover = false);

    /// <summary>
    /// Parses the token into the <see cref="ITokenMetadata" />.
    /// </summary>
    /// <param name="token"></param>
    /// <param name="allowExpired"></param>
    /// <returns></returns>
    public TTokenMetadata Parse<TTokenMetadata>(string token, bool allowExpired = false) where TTokenMetadata : ITokenMetadata, new();
}