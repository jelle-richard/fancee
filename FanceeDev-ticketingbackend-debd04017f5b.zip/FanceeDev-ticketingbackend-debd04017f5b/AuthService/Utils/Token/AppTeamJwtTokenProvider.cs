using FanceeAuthentication.Configurations;
using FanceeAuthentication.Providers.Token;

namespace AuthService.Utils.Token;

public class AppTeamJwtTokenProvider : JwtTokenProvider, IJwtTokenProvider
{
    public int RefreshDays => TokenConfig.RefreshDays;

    public AppTeamJwtTokenProvider(TokenConfig tokenConfig) : base(tokenConfig)
    {
    }
}