using System;
using FanceeAuthentication.Providers.Token;
using FanceeAuthentication.Utils.Attributes;

namespace AuthService.Utils.Token;

public class AppTeamTokenMetadata : ITokenMetadata
{
    [TokenName("team")]
    public Guid TeamId { get; set; }

    [TokenName("ref_until")]
    public long RefreshableUntil { get; set; }
}