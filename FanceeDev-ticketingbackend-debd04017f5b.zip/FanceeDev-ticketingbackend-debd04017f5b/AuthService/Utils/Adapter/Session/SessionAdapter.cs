﻿using System.Collections.Generic;
using System.Linq;
using AuthService.Dtos.Responses.Sessions;

namespace AuthService.Utils.Adapter.Session;

public static class SessionAdapter
{
    public static IEnumerable<SessionResponse> ToSessionResponses(this IEnumerable<FanceeAuthentication.Dtos.Responses.SessionResponse> sessionTokens) =>
        sessionTokens.Select(st => st.ToSessionResponse());

    public static SessionResponse ToSessionResponse(this FanceeAuthentication.Dtos.Responses.SessionResponse sessionToken) =>
        new()
        {
            Token = sessionToken.Token,
            Device = sessionToken.Device,
            IpAddress = sessionToken.IpAddress,
            IssuedOn = sessionToken.IssuedOn,
            ValidUntil = sessionToken.ValidUntil
        };
}