using System.Collections.Generic;
using FanceeData.Models.Ticketing;

namespace AuthService.Utils.Adapter.Claim;

public static class ClaimAdapter
{
    public static IEnumerable<string> ParseClaimsFromAppTeam(this AppTeam appTeam)
    {
        if (appTeam.ScanningEnabled)
            yield return "scan";

        if (appTeam.SalesEnabled)
            yield return "sales";

        if (appTeam.StatisticsEnabled)
            yield return "statistics";

        if (appTeam.CashEnabled)
            yield return "organization.sale.payments.cash"; //Todo: Should be changed to "cash" the next time app changes are being developed
    }
}