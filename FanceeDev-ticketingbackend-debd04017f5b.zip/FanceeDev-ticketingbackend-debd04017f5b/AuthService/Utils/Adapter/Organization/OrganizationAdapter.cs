using System;
using System.Collections.Generic;
using AuthService.Dtos.Responses.Auth;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Responses.File;

namespace AuthService.Utils.Adapter.Organization;

public static class OrganizationAdapter
{
    public static ManageableOrganization ToManageableOrganization(this FanceeData.Models.Ticketing.Organization organization, HostedDeploymentEnvironment env, Guid currentUserId, IEnumerable<string> claims) =>
        new()
        {
            Id = organization.Id,
            Name = organization.Name,
            IsOwner = organization.UserId == currentUserId,
            Claims = claims,
            Avatar = organization.User.UserMedia?.File == null
                ? null
                : new ImageFileResponse
                {
                    Id = organization.User.UserMedia.File.Id,
                    Url = $"{env.Scheme}://{env.ContentDeliveryNetworkBaseUrl}/{organization.User.UserMedia.File.Path}",
                    MimeType = organization.User.UserMedia.File.MimeType,
                    OriginalFileName = organization.User.UserMedia.File.OriginalFileName,
                    FocalPointWidthPercentage = organization.User.UserMedia.FocalPointWidthPercentage,
                    FocalPointHeightPercentage = organization.User.UserMedia.FocalPointHeightPercentage
                }
        };
}