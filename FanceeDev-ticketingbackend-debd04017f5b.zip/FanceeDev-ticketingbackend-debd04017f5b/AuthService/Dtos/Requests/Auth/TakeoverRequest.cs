using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AuthService.Dtos.Requests.Auth;

public class TakeoverRequest : IValidatableObject
{
    [Required]
    public Guid? AccountId { get; set; }

    [Required]
    public string AdminPassword { get; set; }

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (AccountId == Guid.Empty)
            yield return new("Invalid account id", new[] { nameof(AccountId) });

        if (string.IsNullOrWhiteSpace(AdminPassword))
            yield return new("Invalid password", new[] { nameof(AdminPassword) });
    }
}