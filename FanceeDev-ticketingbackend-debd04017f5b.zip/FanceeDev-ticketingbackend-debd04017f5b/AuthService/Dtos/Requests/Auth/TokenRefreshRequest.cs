using System.ComponentModel.DataAnnotations;

namespace AuthService.Dtos.Requests.Auth;

public class TokenRefreshRequest
{
    [Required]
    public string Token { get; set; }
}