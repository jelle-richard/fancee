using System;
using System.ComponentModel.DataAnnotations;

namespace AuthService.Dtos.Requests.Auth;

public class AppTeamTokenRequest
{
    [Required]
    public Guid? TeamId { get; set; }
}