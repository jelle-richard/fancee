using System.ComponentModel.DataAnnotations;

namespace AuthService.Dtos.Requests.Auth;

public class TokenRequest
{
    [Required]
    [EmailAddress]
    [StringLength(254, MinimumLength = 3)]
    public string Email { get; set; }

    [Required]
    [MinLength(3)]
    public string Password { get; set; }
}