using System.Collections.Generic;

namespace AuthService.Dtos.Requests.Claims;

public class AlterClaimsRequest
{
    public HashSet<string> Claims { get; set; }
}