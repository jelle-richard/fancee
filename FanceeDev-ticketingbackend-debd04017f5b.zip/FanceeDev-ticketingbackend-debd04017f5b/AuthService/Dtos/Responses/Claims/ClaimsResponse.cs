using System.Collections.Generic;

namespace AuthService.Dtos.Responses.Claims;

public class ClaimsResponse
{
    public IEnumerable<string> Claims { get; set; }
}