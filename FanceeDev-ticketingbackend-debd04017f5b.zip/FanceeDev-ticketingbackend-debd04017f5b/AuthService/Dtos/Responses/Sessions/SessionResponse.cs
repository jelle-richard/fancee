﻿using System;

namespace AuthService.Dtos.Responses.Sessions;

public class SessionResponse
{
    public string Token { get; set; }
    public string Device { get; set; }
    public string IpAddress { get; set; }
    public DateTime IssuedOn { get; set; }
    public DateTime ValidUntil { get; set; }
}