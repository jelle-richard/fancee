﻿using System;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses.Currency;
using WebApiCore.Dtos.Responses.File;

namespace AuthService.Dtos.Responses.Auth;

/// <summary>
/// DTO that represents the basic user info provided with the token API
/// </summary>
public class UserResponse
{
    public Guid Id { get; set; }
    public string Email { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public UserType Type { get; set; }
    public ImageFileResponse AvatarFile { get; set; }
    public DateTime? LastLogin { get; set; }
    public CurrencyResponse Currency { get; set; }
    public string[] CountryCodes { get; set; }
    public bool IsProfileComplete { get; set; }
    public int ChangelogsSinceLastLogin { get; set; }
    public string PublicCode { get; set; }
}