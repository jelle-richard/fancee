using System;
using System.Collections.Generic;

namespace AuthService.Dtos.Responses.Auth;

public class AppTeamTokenResponse
{
    public string Token { get; set; }
    public string Name { get; set; }
    public string Organization { get; set; }
    public DateTime ValidUntil { get; set; }
    public DateTime RefreshableUntil { get; set; }
    public IEnumerable<string> Claims { get; set; }
}