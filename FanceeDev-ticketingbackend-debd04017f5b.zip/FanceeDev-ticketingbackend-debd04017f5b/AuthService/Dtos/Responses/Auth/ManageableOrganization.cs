#nullable enable

using System;
using System.Collections.Generic;
using WebApiCore.Dtos.Responses.File;

namespace AuthService.Dtos.Responses.Auth;

public class ManageableOrganization
{
    public required Guid Id { get; set; }
    public required string Name { get; set; }
    public required bool IsOwner { get; set; }
    public required ImageFileResponse? Avatar { get; set; }
    public required IEnumerable<string> Claims { get; set; }
}