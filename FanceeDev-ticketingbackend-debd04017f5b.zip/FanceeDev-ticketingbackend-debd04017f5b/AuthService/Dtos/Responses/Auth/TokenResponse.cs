using System;
using System.Collections.Generic;

namespace AuthService.Dtos.Responses.Auth;

/// <summary>
/// DTO that represents all info needed for the token API
/// </summary>
public class TokenResponse
{
    public string Token { get; set; }
    public DateTime ValidUntil { get; set; }
    public DateTime RefreshableUntil { get; set; }
    public IEnumerable<string> Claims { get; set; }
    public UserResponse User { get; set; }
    public IEnumerable<ManageableOrganization> ManageableOrganizations { get; set; } = new List<ManageableOrganization>();
}