﻿using System;
using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Providers.Currency.ExchangeRateApi.Dtos;
using CurrencyService.Utils.Adapter;

namespace CurrencyService.Tests.Utils.Adapter;

public class ExchangeRateAdapterTests
{
    [Fact]
    public void TestThatToExchangeRatesMapsCorrectData()
    {
        var response = new LatestResponse
        {
            Result = "success",
            TimeLastUpdateUtc = "Mon, 17 Jan 2022 00:00:01 +0000",
            TimeLastUpdateUnix = 1642412050,
            TimeNextUpdateUnix = 1642464001,
            TimeNextUpdateUtc = "Tue, 18 Jan 2022 00:00:01 +0000",
            Documentation = "https://www.exchangerate-api.com/docs",
            TermsOfUse = "https://www.exchangerate-api.com/terms",
            ConversionRates = new()
            {
                { CurrencyCode.EUR, 1.0m },
                { CurrencyCode.USD, 1.14m },
                { CurrencyCode.DKK, 7.44m }
            }
        };

        var actual = response.ToExchangeRates();

        Assert.NotNull(actual);
        Assert.Equal(response.ConversionRates, actual.Rates);
        Assert.Equal(new(2022, 1, 17, 9, 34, 10, DateTimeKind.Utc), actual.LastAlteration);
    }
}