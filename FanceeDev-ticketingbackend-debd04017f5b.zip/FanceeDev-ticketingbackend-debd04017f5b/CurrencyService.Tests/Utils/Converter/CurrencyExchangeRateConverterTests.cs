﻿using System.Buffers;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Utils.Converter;

namespace CurrencyService.Tests.Utils.Converter;

public class CurrencyExchangeRateConverterTests
{
    private readonly CurrencyExchangeRateConverter _sut;

    public CurrencyExchangeRateConverterTests()
    {
        _sut = new();
    }

    [Fact]
    public void TestThatReadReturnsCorrectDictionaryWithValidValues()
    {
        var json = "{\"EUR\": 1.0, \"USD\": 1.14, \"DKK\": 0.0042, \"GBP\": 124.05}";
        var reader = GetReader(json);

        reader.Read();

        var actual = _sut.Read(ref reader, typeof(Dictionary<CurrencyCode, decimal>), new());

        Assert.NotNull(actual);
        Assert.Equal(4, actual.Count);
        Assert.Equal(1m, actual[CurrencyCode.EUR]);
        Assert.Equal(1.14m, actual[CurrencyCode.USD]);
        Assert.Equal(0.0042m, actual[CurrencyCode.DKK]);
        Assert.Equal(124.05m, actual[CurrencyCode.GBP]);
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfTokenTypeIsNotStartObject()
    {
        Assert.Throws<JsonException>(() =>
        {
            var json = "[]";
            var reader = GetReader(json);

            reader.Read();

            _sut.Read(ref reader, typeof(Dictionary<CurrencyCode, decimal>), new());
        });
    }

    [Fact]
    public void TestThatReadSkipsInvalidEnumValues()
    {
        var json = "{\"EUR\": 1.0, \"Invalid\": 1.14, \"DKK\": 0.0042}";
        var reader = GetReader(json);

        reader.Read();

        var actual = _sut.Read(ref reader, typeof(Dictionary<CurrencyCode, decimal>), new());

        Assert.NotNull(actual);
        Assert.Equal(2, actual.Count);
        Assert.Equal(1m, actual[CurrencyCode.EUR]);
        Assert.Equal(0.0042m, actual[CurrencyCode.DKK]);
    }

    [Fact]
    public void TestThatReadReturnsEmptyDictionaryOnEmptyObject()
    {
        var json = "{}";
        var reader = GetReader(json);

        reader.Read();

        var actual = _sut.Read(ref reader, typeof(Dictionary<CurrencyCode, decimal>), new());

        Assert.NotNull(actual);
        Assert.Empty(actual);
    }

    [Fact]
    public void TestThatWriteWritesCorrectJsonValue()
    {
        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        var dict = new Dictionary<CurrencyCode, decimal>
        {
            { CurrencyCode.EUR, 1.0m },
            { CurrencyCode.USD, 1.14m }
        };

        _sut.Write(writer, dict, new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, Converters = { new CurrencyExchangeRateConverter() } });

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal("{\"EUR\":1.0,\"USD\":1.14}", actual);
    }

    private static Utf8JsonReader GetReader(string json)
    {
        var sequence = new ReadOnlySequence<byte>(Encoding.UTF8.GetBytes(json));

        return new(sequence);
    }
}