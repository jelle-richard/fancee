﻿using System;
using System.Threading.Tasks;
using CurrencyService.BackgroundTasks.MessageBus;
using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Providers.Currency;
using CurrencyService.Services;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.Exceptions;
using WebApiCore.MessageBus.Messages.Currency;

namespace CurrencyService.Tests.BackgroundTasks.MessageBus;

public class UpdateCurrencyExchangeRatesListenerTests
{
    private readonly UpdateCurrencyExchangeRatesListener _sut;
    private readonly Mock<IMessageSubscriber<UpdateCurrencyExchangeRatesMessage>> _mockedSubscriber = new();
    private readonly Mock<ILogger<UpdateCurrencyExchangeRatesListener>> _mockedLogger = new();
    private readonly Mock<IExchangeRateProvider> _mockedExchangeRateProvider = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();

    public UpdateCurrencyExchangeRatesListenerTests()
    {
        var mockedScope = new Mock<IServiceScope>();
        var mockedScopeFactory = new Mock<IServiceScopeFactory>();
        var mockedServiceProvider = new Mock<IServiceProvider>();
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedScopeFactory.Object);
        mockedScopeFactory.Setup(sf => sf.CreateScope()).Returns(mockedScope.Object);

        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<UpdateCurrencyExchangeRatesMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<UpdateCurrencyExchangeRatesListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IExchangeRateProvider))).Returns(_mockedExchangeRateProvider.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ICurrencyService))).Returns(_mockedCurrencyService.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToMessageSubscriber()
    {
        _sut.UnitTestRegisterDependencies();

        await _sut.StartAsync(default);

        _mockedSubscriber.Verify(s => s.Bind(It.IsAny<Func<UpdateCurrencyExchangeRatesMessage?, Task>>()), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Information, "[UpdateCurrencyExchangeRatesListener] Started");
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsFromMessageSubscriber()
    {
        await _sut.StopAsync(default);

        _mockedSubscriber.Verify(s => s.Unbind());
        _mockedLogger.VerifyCalled(LogLevel.Information, "[UpdateCurrencyExchangeRatesListener] Stopped");
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageUpdatesCurrencyExchangeRates()
    {
        var rates = new ExchangeRates();

        _mockedExchangeRateProvider.Setup(erp => erp.GetAsync(CurrencyCode.EUR)).ReturnsAsync(rates);
        _mockedSubscriber.Setup(s => s.Bind(It.IsAny<Func<UpdateCurrencyExchangeRatesMessage?, Task>>()))
            .Callback((Func<UpdateCurrencyExchangeRatesMessage, Task> callback) => callback.Invoke(new()).Wait());

        _sut.UnitTestRegisterDependencies();

        await _sut.StartAsync(default);

        _mockedExchangeRateProvider.Verify(erp => erp.GetAsync(CurrencyCode.EUR), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.UpdateExchangeRatesAsync(rates), Times.Once);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageLogsMessageIfExceptionOccurs()
    {
        _mockedExchangeRateProvider.Setup(erp => erp.GetAsync(CurrencyCode.EUR)).ThrowsAsync(new());
        _mockedSubscriber.Setup(s => s.Bind(It.IsAny<Func<UpdateCurrencyExchangeRatesMessage?, Task>>()))
            .Callback((Func<UpdateCurrencyExchangeRatesMessage, Task> callback) => callback.Invoke(new()).Wait());

        _sut.UnitTestRegisterDependencies();

        await _sut.StartAsync(default);

        _mockedExchangeRateProvider.Verify(erp => erp.GetAsync(CurrencyCode.EUR), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.UpdateExchangeRatesAsync(It.IsAny<ExchangeRates>()), Times.Never);
        _mockedLogger.VerifyCalled(LogLevel.Error, "[UpdateCurrencyExchangeRatesListener] Unexpected error occured. See inner exception for more details.");
    }

    [Fact]
    public async Task TestThatUpdateCurrencyExchangeRatesListenerLogsMessageIfConfigurationIsIncorrect()
    {
        var mockedScope = new Mock<IServiceScope>();
        var mockedScopeFactory = new Mock<IServiceScopeFactory>();
        var mockedServiceProvider = new Mock<IServiceProvider>();
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedScopeFactory.Object);
        mockedScopeFactory.Setup(sf => sf.CreateScope()).Returns(mockedScope.Object);

        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<UpdateCurrencyExchangeRatesMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<UpdateCurrencyExchangeRatesListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IExchangeRateProvider))).Throws(new MissingRequiredConfigurationEntryException("", ""));
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ICurrencyService))).Returns(_mockedCurrencyService.Object);

        var sut = new UpdateCurrencyExchangeRatesListener(mockedServiceProvider.Object);

        sut.UnitTestRegisterDependencies();

        await sut.StartAsync(default);

        _mockedSubscriber.Verify(s => s.Bind(It.IsAny<Func<UpdateCurrencyExchangeRatesMessage?, Task>>()), Times.Never);
        _mockedLogger.VerifyCalled(LogLevel.Critical, "[UpdateCurrencyExchangeRatesListener] Unable to update currency exchange rates because the application is not configured correctly.");
    }
}