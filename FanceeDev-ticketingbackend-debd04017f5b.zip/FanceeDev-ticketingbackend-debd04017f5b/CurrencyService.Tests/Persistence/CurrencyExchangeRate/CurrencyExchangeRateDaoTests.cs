﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CurrencyService.Persistence.CurrencyExchangeRate;
using FanceeData.Contexts;

namespace CurrencyService.Tests.Persistence.CurrencyExchangeRate;

public class CurrencyExchangeRateDaoTests
{
    private readonly CurrencyExchangeRateDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public CurrencyExchangeRateDaoTests()
    {
        _mockedContext = new();
        _mockedContext.Setup(c => c.CurrencyExchangeRates).ReturnsDbSet(new List<FanceeData.Models.Ticketing.CurrencyExchangeRate>
        {
            new() { CurrencyShortCode = "EUR", Rate = 1m },
            new() { CurrencyShortCode = "USD", Rate = 1.14m },
            new() { CurrencyShortCode = "DKK", Rate = 4.53m }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAllAsyncReturnsAllEntities()
    {
        var actual = await _sut.AllAsync();

        Assert.Equal(3, actual.Count);
        _mockedContext.Verify(c => c.CurrencyExchangeRates, Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateRangeAsyncUpdatesEntities()
    {
        var rates = new List<FanceeData.Models.Ticketing.CurrencyExchangeRate>
        {
            new() { CurrencyShortCode = "USD", Rate = 1.15m }
        };

        await _sut.UpdateRangeAsync(rates);

        _mockedContext.Verify(c => c.CurrencyExchangeRates.UpdateRange(rates), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}