using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CurrencyService.Persistence.Currency;
using FanceeData.Contexts;

namespace CurrencyService.Tests.Persistence.Currency;

public class CurrencyDaoTests
{
    private readonly CurrencyDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public CurrencyDaoTests()
    {
        _mockedContext.Setup(c => c.Currencies)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Currency>
            {
                new()
                {
                    ShortCode = "EUR",
                    Name = "Euro",
                    Character = "€",
                    Active = true
                },
                new()
                {
                    ShortCode = "USD",
                    Name = "Dollar",
                    Character = "$",
                    Active = true
                },
                new()
                {
                    ShortCode = "GBP",
                    Name = "Pound",
                    Character = "£",
                    Active = true
                },
                new()
                {
                    ShortCode = "TEST",
                    Name = "Tester",
                    Character = "^",
                    Active = false
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatActiveCurrenciesAsyncOnlyRetrievesActiveCurrencies()
    {
        var actual = await _sut.ActiveCurrenciesAsync();

        Assert.Equal(3, actual.Count());
        Assert.Null(actual.FirstOrDefault(c => c.ShortCode == "TEST"));
    }

    [Fact]
    public async Task TestThatByShortCodeAsyncReturnsNullOnUnknownCurrency()
    {
        var actual = await _sut.ByShortCodeAsync("UNKNOWN");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByShortCodeAsyncGetsCurrency()
    {
        var actual = await _sut.ByShortCodeAsync("EUR");

        Assert.NotNull(actual);
        Assert.Equal("EUR", actual.ShortCode);
        Assert.Equal("Euro", actual.Name);
    }
}