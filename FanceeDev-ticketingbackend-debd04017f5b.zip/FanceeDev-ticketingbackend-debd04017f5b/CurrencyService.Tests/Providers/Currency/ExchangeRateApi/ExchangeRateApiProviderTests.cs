﻿using System.Linq;
using System.Threading.Tasks;
using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Providers.Currency.ExchangeRateApi;
using CurrencyService.Providers.Currency.ExchangeRateApi.Dtos;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.Exceptions;
using WebApiCore.Utils.Http;

namespace CurrencyService.Tests.Providers.Currency.ExchangeRateApi;

public class ExchangeRateApiProviderTests
{
    private readonly ExchangeRateApiProvider _sut;
    private readonly Mock<IJsonHttpClient> _mockedJsonHttpClient;
    private readonly Mock<ILogger<ExchangeRateApiProvider>> _mockedLogger;

    public ExchangeRateApiProviderTests()
    {
        var mockedConfig = ConfigurationMockUtils.Create(new()
        {
            { "ExchangeRateApi:ApiKey", "randomapikey" },
            { "ExchangeRateApi:ApiUrl", "https://v6.exchangerate-api.com/v6" }
        });

        _mockedJsonHttpClient = new();
        _mockedLogger = new();

        _sut = new(mockedConfig, _mockedJsonHttpClient.Object, _mockedLogger.Object);
    }

    [Fact]
    public void TestThatExchangeRateApiProviderThrowsMissingRequiredConfigurationEntryExceptionOnInvalidApiKey()
    {
        Assert.Throws<MissingRequiredConfigurationEntryException>(() =>
        {
            var mockedConfig = ConfigurationMockUtils.Create(new() { { "ExchangeRateApi:ApiUrl", "http://localhost" } });

            var _ = new ExchangeRateApiProvider(mockedConfig, _mockedJsonHttpClient.Object, _mockedLogger.Object);
        });
    }

    [Fact]
    public void TestThatExchangeRateApiProviderThrowsMissingRequiredConfigurationEntryExceptionOnInvalidApiUrl()
    {
        Assert.Throws<MissingRequiredConfigurationEntryException>(() =>
        {
            var mockedConfig = ConfigurationMockUtils.Create(new() { { "ExchangeRateApi:ApiKey", "randomapikey" } });

            var _ = new ExchangeRateApiProvider(mockedConfig, _mockedJsonHttpClient.Object, _mockedLogger.Object);
        });
    }

    [Fact]
    public async Task TestThatGetAsyncCallsExchangeRateApi()
    {
        _mockedJsonHttpClient.Setup(jhc => jhc.GetAsync<LatestResponse>(It.IsAny<string>())).ReturnsAsync(new LatestResponse
        {
            TimeLastUpdateUnix = 1642422348,
            ConversionRates = new() { { CurrencyCode.USD, 1.14m } }
        });

        var actual = await _sut.GetAsync(CurrencyCode.EUR);

        Assert.Equal(CurrencyCode.USD, actual.Rates.First().Key);
        Assert.Equal(1.14m, actual.Rates.First().Value);

        const string url = "https://v6.exchangerate-api.com/v6/randomapikey/latest/EUR";

        _mockedJsonHttpClient.Verify(jhc => jhc.GetAsync<LatestResponse>(url), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAsyncThrowsApiRequestFailedExceptionOnNull()
    {
        _mockedJsonHttpClient.Setup(jhc => jhc.GetAsync<LatestResponse>(It.IsAny<string>()))!.ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ApiRequestFailedException>(async () => await _sut.GetAsync(CurrencyCode.EUR));

        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGetAsyncThrowsApiRequestFailedExceptionOnException()
    {
        _mockedJsonHttpClient.Setup(jhc => jhc.GetAsync<LatestResponse>(It.IsAny<string>())).ThrowsAsync(new());

        await Assert.ThrowsAsync<ApiRequestFailedException>(async () => await _sut.GetAsync(CurrencyCode.EUR));

        _mockedLogger.VerifyCalled(LogLevel.Error, "Request to ExchangeRate-API failed. See inner exception for more details.");
    }
}