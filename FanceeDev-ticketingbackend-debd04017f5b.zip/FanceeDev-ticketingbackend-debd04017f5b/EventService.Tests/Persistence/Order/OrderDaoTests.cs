using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Order;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Order;

public class OrderDaoTests
{
    private static readonly List<Guid> MockedOrganizationIds = new() { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private static readonly List<Guid> MockedClientIds = new() { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private static readonly List<Guid> MockedEventIds = new() { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    private static readonly List<FanceeData.Models.Ticketing.Order> MockedOrders = new()
    {
        new()
        {
            PaymentStatus = PaymentStatus.Authorised,
            CreatedAt = DateTime.UtcNow.AddDays(-1),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = MockedEventIds[0],
                            Event = new()
                            {
                                Id = MockedEventIds[0],
                                OrganizationId = MockedOrganizationIds[0],
                                Organization = new()
                                {
                                    IsDemo = false,
                                    CountryCode = "NL"
                                }
                            }
                        }
                    }
                }
            },
            IssuedProducts = new List<IssuedProduct>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    ProductId = Guid.NewGuid(),
                    OrderId = Guid.NewGuid(),
                    Product = new()
                    {
                        EventId = MockedEventIds[0],
                        Event = new()
                        {
                            Id = MockedEventIds[0],
                            Status = EventStatus.Cancelled
                        }
                    }
                }
            }
        },
        new()
        {
            PaymentStatus = PaymentStatus.Refund,
            CreatedAt = DateTime.UtcNow.AddDays(-1),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = MockedEventIds[0],
                            Event = new()
                            {
                                Id = MockedEventIds[0],
                                OrganizationId = MockedOrganizationIds[0],
                                Organization = new()
                                {
                                    IsDemo = false,
                                    CountryCode = "NL"
                                }
                            }
                        }
                    }
                }
            },
            IssuedProducts = new List<IssuedProduct>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    ProductId = Guid.NewGuid(),
                    OrderId = Guid.NewGuid(),
                    Product = new()
                    {
                        EventId = MockedEventIds[0],
                        Event = new()
                        {
                            Id = MockedEventIds[0],
                            Status = EventStatus.Cancelled
                        }
                    }
                }
            }
        },
        new()
        {
            PaymentStatus = PaymentStatus.Authorised,
            CreatedAt = DateTime.UtcNow.AddDays(-4),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = MockedEventIds[0],
                            Event = new()
                            {
                                Id = MockedEventIds[0],
                                OrganizationId = MockedOrganizationIds[0],
                                Organization = new()
                                {
                                    IsDemo = true,
                                    CountryCode = "NL"
                                }
                            }
                        }
                    }
                }
            },
            IssuedProducts = new List<IssuedProduct>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    ProductId = Guid.NewGuid(),
                    OrderId = Guid.NewGuid(),
                    Product = new()
                    {
                        EventId = MockedEventIds[0],
                        Event = new()
                        {
                            Id = MockedEventIds[0],
                            Status = EventStatus.Cancelled
                        }
                    }
                }
            }
        },
        new()
        {
            PaymentStatus = PaymentStatus.Authorised,
            CreatedAt = DateTime.UtcNow.AddDays(-1),
            IssuedProducts = new List<IssuedProduct>(),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = MockedEventIds[1],
                            Event = new()
                            {
                                Id = MockedEventIds[1],
                                OrganizationId = MockedOrganizationIds[0],
                                Organization = new()
                                {
                                    IsDemo = false,
                                    CountryCode = "NL"
                                }
                            }
                        }
                    }
                }
            }
        },
        new()
        {
            PaymentStatus = PaymentStatus.Authorised,
            CreatedAt = DateTime.UtcNow.AddDays(-4),
            IssuedProducts = new List<IssuedProduct>(),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = MockedEventIds[2],
                            Event = new()
                            {
                                Id = MockedEventIds[2],
                                OrganizationId = MockedOrganizationIds[1],
                                Organization = new()
                                {
                                    IsDemo = false,
                                    CountryCode = "NL"
                                }
                            }
                        }
                    }
                }
            }
        },
        new()
        {
            PaymentStatus = PaymentStatus.AuthenticationFinished,
            CreatedAt = new(2020, 01, 01),
            IssuedProducts = new List<IssuedProduct>(),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = MockedEventIds[3],
                            Event = new()
                            {
                                OrganizationId = MockedOrganizationIds[2],
                                Organization = new()
                                {
                                    CountryCode = "NL",
                                    IsDemo = false
                                }
                            }
                        }
                    }
                }
            }
        },
        new()
        {
            PaymentStatus = PaymentStatus.AuthenticationFinished,
            CreatedAt = new(2020, 01, 01),
            IssuedProducts = new List<IssuedProduct>(),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = MockedEventIds[3],
                            Event = new()
                            {
                                OrganizationId = MockedOrganizationIds[2],
                                Organization = new()
                                {
                                    CountryCode = "NL",
                                    IsDemo = false
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    private static readonly List<ClientOrder> MockedClientOrders = new()
    {
        new()
        {
            Gender = Gender.Male,
            ClientId = MockedClientIds[0],
            Birthdate = null,
            Order = MockedOrders[0],
            Client = new() { User = new() },
            Address = new()
            {
                CountryCode = "NL",
                City = "Den Haag"
            }
        },
        new()
        {
            Gender = Gender.Male,
            ClientId = MockedClientIds[1],
            Birthdate = null,
            Order = MockedOrders[1],
            Client = new() { User = new() },
            Address = new()
            {
                CountryCode = "BE",
                City = "Antwerpen"
            }
        },
        new()
        {
            Gender = Gender.Male,
            ClientId = MockedClientIds[2],
            Birthdate = null,
            Order = MockedOrders[2],
            Client = new() { User = new() },
            Address = new()
            {
                CountryCode = "BE",
                City = "Antwerpen"
            }
        },
        new()
        {
            Gender = Gender.Male,
            ClientId = MockedClientIds[3],
            Birthdate = null,
            Order = MockedOrders[3],
            Client = new() { User = new() },
            Address = new()
            {
                CountryCode = "NL",
                City = "Den Haag"
            }
        },
        new()
        {
            Gender = Gender.Male,
            ClientId = MockedClientIds[4],
            Birthdate = null,
            Order = MockedOrders[4],
            Client = new() { User = new() },
            Address = new()
            {
                CountryCode = "NL",
                City = "Den Haag"
            }
        },
        new()
        {
            Gender = Gender.Male,
            ClientId = MockedClientIds[3],
            Birthdate = null,
            Order = MockedOrders[0],
            Client = new() { User = new() },
            Address = new()
            {
                CountryCode = "NL",
                City = "Rotterdam"
            }
        },
        new()
        {
            Gender = Gender.Male,
            ClientId = MockedClientIds[4],
            Birthdate = null,
            Order = MockedOrders[0],
            Client = new() { User = new() },
            Address = new()
            {
                CountryCode = "NL",
                City = "Rotterdam"
            }
        },
        new()
        {
            Birthdate = new(1990, 1, 1),
            Gender = Gender.Male,
            Order = MockedOrders[5],
            Address = new()
            {
                CountryCode = "NL",
                City = "Rotterdam"
            },
            Client = new()
            {
                User = new()
            }
        },
        new()
        {
            Birthdate = new(1992, 1, 1),
            Gender = Gender.Female,
            Order = MockedOrders[6],
            Address = new()
            {
                CountryCode = "NL",
                City = "Rotterdam"
            },
            Client = new()
            {
                User = new()
            }
        }
    };

    private readonly OrderDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public OrderDaoTests()
    {
        _sut = new(_mockedContext.Object);

        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(MockedOrders);

        _mockedContext.Setup(c => c.ClientOrders)
            .ReturnsDbSet(MockedClientOrders);
    }

    [Fact]
    public async Task TestThatAllForRefundAsyncReturnsOrderIdsList()
    {
        var actual = await _sut.RefundableOrderIdsAsync(MockedEventIds[0]);

        Assert.NotNull(actual);
        Assert.NotEmpty(actual);
        Assert.Equal(MockedOrders.FirstOrDefault()!.Id, actual.FirstOrDefault());
    }

    [Fact]
    public async Task TestThatAllForRefundAsyncReturnsEmptyList()
    {
        var actual = await _sut.RefundableOrderIdsAsync(Guid.NewGuid());

        Assert.NotNull(actual);
        Assert.Empty(actual);
    }

    [Fact]
    public async Task TestThatTotalOrdersPlacedAsyncCountsPaidOrders()
    {
        var actual = await _sut.TotalOrdersAsync(MockedOrganizationIds[0]);

        Assert.Equal(3, actual);
    }

    [Fact]
    public async Task TestThatTotalOrdersPlacedAsyncForPlatformCountsPaidOrders()
    {
        var actual = await _sut.TotalOrdersAsync(DateTime.UtcNow.AddDays(-3), DateTime.UtcNow, new[] { "NL" });

        Assert.Equal(3, actual);
    }

    [Fact]
    public async Task TestThatUniqueCustomersGenderAsyncSortByUniqueClients()
    {
        var actual = await _sut.UniqueCustomersByGendersAsync(MockedOrganizationIds[0]);

        Assert.Equal(5, actual.UniqueMaleCustomers);
    }

    [Fact]
    public async Task TestThatUniqueCustomersGenderAsyncSortByUniqueClientsBetweenDates()
    {
        var actual = await _sut.UniqueCustomersByGendersAsync(DateTime.UtcNow.AddDays(-2), DateTime.UtcNow, new() { "NL" });

        Assert.Equal(4, actual.UniqueMaleCustomers);
    }

    [Fact]
    public async Task TestThatUniqueEventCustomersGenderAsyncSortByUniqueClients()
    {
        var actual = await _sut.UniqueEventCustomersByGendersAsync(MockedEventIds[0]);

        Assert.Equal(5, actual.UniqueMaleCustomers);
    }

    [Fact]
    public async Task TestThatEventOrdersAsyncCountsOrdersPlacedForEvent()
    {
        var actual = await _sut.EventOrdersAsync(MockedEventIds[0]);

        Assert.Equal(2, actual);
    }

    [Fact]
    public async Task TestThatCustomerCountryStatisticsAsyncReturnsListOfEventCustomersCountryStatisticsResponse()
    {
        var actual = (await _sut.CustomerCountryStatisticsAsync(MockedEventIds[0])).ToList();

        Assert.NotNull(actual);
        Assert.Equal(2, actual.Count);
        Assert.Equal("NL", actual.First().CountryCode);
        Assert.Equal(3, actual.First().Amount);
        Assert.Equal("BE", actual.Last().CountryCode);
        Assert.Equal(2, actual.Last().Amount);
    }

    [Fact]
    public async Task TestThatCustomerCityStatisticsAsyncReturnsListOfEventCustomersCityStatisticsResponse()
    {
        var actual = (await _sut.CustomerCityStatisticsAsync(MockedEventIds[0], "NL")).ToList();

        Assert.NotNull(actual);
        Assert.Equal(2, actual.Count);
        Assert.Equal("Den Haag", actual.First().City);
        Assert.Equal(1, actual.First().Amount);
        Assert.Equal("Rotterdam", actual[1].City);
        Assert.Equal(2, actual[1].Amount);
    }

    [Fact]
    public async Task TestThatAverageEventAgeByGendersAsyncReturnsCorrectAverageAgesGenderResponse()
    {
        var actual = await _sut.AverageEventAgeByGendersAsync(MockedEventIds[3], new(2000, 1, 1));

        Assert.Equal(8, actual.FemaleAverageAge);
        Assert.Equal(10, actual.MaleAverageAge);
        Assert.Null(actual.NeutralAverageAge);
        Assert.Equal(9, actual.TotalAverageAge);
        Assert.Null(actual.UnknownAverageAge);
    }

    [Fact]
    public async Task TestThatAverageAgeByGendersAsyncReturnsCorrectAverageAgeByGenders()
    {
        var actual = await _sut.AverageAgeByGendersAsync(MockedOrganizationIds[2]);

        Assert.Equal(DateTime.Now.Year - 1992, actual.FemaleAverageAge);
        Assert.Equal(DateTime.Now.Year - 1990, actual.MaleAverageAge);
        Assert.Null(actual.NeutralAverageAge);
        Assert.Equal(DateTime.Now.Year - 1991, actual.TotalAverageAge);
        Assert.Null(actual.UnknownAverageAge);
    }

    [Fact]
    public async Task TestThatCustomerCityStatisticsAsyncReturnsCorrectCustomerCityStatistics()
    {
        var actual = await _sut.CustomerCityStatisticsAsync(MockedEventIds[3], "NL");

        Assert.Single(actual);
    }

    [Fact]
    public async Task TestThatAverageAgeByGendersAsyncWithCountryCodeReturnsCorrectAverageAgeByGenders()
    {
        var actual = await _sut.AverageAgeByGendersAsync(
            new(1900, 01, 01),
            new(2100, 01, 01),
            new() { "NL", "BE" }
        );

        Assert.Equal(DateTime.Now.Year - 1992, actual.FemaleAverageAge);
        Assert.Equal(DateTime.Now.Year - 1990, actual.MaleAverageAge);
        Assert.Null(actual.NeutralAverageAge);
        Assert.Equal(DateTime.Now.Year - 1991, actual.TotalAverageAge);
        Assert.Null(actual.UnknownAverageAge);
    }

    [Fact]
    public async Task TestThatAllByEventIdReturnsOrdersByEventId()
    {
        var actual = await _sut.AllByEventId(MockedEventIds[0]);

        Assert.NotNull(actual);
        Assert.NotEmpty(actual);
    }

    [Fact]
    public async Task TestThatAllByEventIdReturnsEmptyCollectionWhenNothingFound()
    {
        var actual = await _sut.AllByEventId(Guid.NewGuid());

        Assert.NotNull(actual);
        Assert.Empty(actual);
    }
}