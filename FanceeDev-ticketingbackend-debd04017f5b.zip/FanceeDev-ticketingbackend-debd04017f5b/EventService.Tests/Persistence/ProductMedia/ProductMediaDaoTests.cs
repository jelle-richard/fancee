﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.ProductMedia;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.ProductMedia;

public class ProductMediaDaoTests
{
    private static readonly Guid[] MockedProductIds = { Guid.NewGuid(), Guid.NewGuid() };
    private static readonly Guid[] MockedFileIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    public static readonly object[][] OwnerOfMediaTestData =
    {
        new object[] { MockedFileIds[0], MockedProductIds[0], ValidOrganizationId, true },
        new object[] { MockedFileIds[0], MockedProductIds[0], new Guid(), false }
    };

    private readonly ProductMediaDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public ProductMediaDaoTests()
    {
        _mockedContext = new();
        _mockedContext.Setup(c => c.ProductMedia).ReturnsDbSet(new List<FanceeData.Models.Ticketing.ProductMedia>
        {
            new() { ProductId = MockedProductIds[0], Position = 1, FileId = MockedFileIds[0], File = new() { Path = "test.png" }, Product = new() { Event = new() { OrganizationId = ValidOrganizationId } } },
            new() { ProductId = MockedProductIds[1], Position = 59, FileId = MockedFileIds[1] },
            new() { ProductId = MockedProductIds[0], Position = 2, FileId = MockedFileIds[2] },
            new() { ProductId = MockedProductIds[0], Position = 3, FileId = MockedFileIds[3] }
        });
        _mockedContext.Setup(c => c.Files).ReturnsDbSet(Array.Empty<File>());

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInsertAsyncAddsNewProductMedia()
    {
        var model = new FanceeData.Models.Ticketing.ProductMedia();
        await _sut.InsertAsync(model);

        _mockedContext.Verify(c => c.ProductMedia.AddAsync(model, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatNextPositionAsyncGetsTheNextPositionNumber()
    {
        var actual = await _sut.NextPositionAsync(MockedProductIds[0]);

        Assert.Equal(4, actual);
    }

    [Fact]
    public async Task TestThatDeleteRemovesTheProductMedia()
    {
        var pm = new FanceeData.Models.Ticketing.ProductMedia
        {
            File = new() { Id = Guid.NewGuid() },
            Position = 1,
            ProductId = Guid.NewGuid()
        };

        await _sut.DeleteAsync(pm);

        _mockedContext.Verify(c => c.ProductMedia.Remove(pm), Times.Once);
        _mockedContext.Verify(c => c.Files.Remove(pm.File), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Theory]
    [MemberData(nameof(OwnerOfMediaTestData))]
    public async Task TestThatOwnerOfMediaReturnsExpectedResult(Guid fileId, Guid productId, Guid organizationId, bool expected)
    {
        var actual = await _sut.OwnerOfMediaAsync(fileId, productId, organizationId);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsProductMedia()
    {
        var actual = await _sut.ByIdAsync(MockedFileIds[0], MockedProductIds[0]);

        Assert.NotNull(actual);
        Assert.Equal("test.png", actual!.File.Path);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsNullWhenNoEntityIsFound()
    {
        var actual = await _sut.ByIdAsync(Guid.NewGuid(), Guid.NewGuid());

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatUpdateAsyncSavesChangesAsync()
    {
        await _sut.UpdateAsync(new()
        {
            FocalPointHeightPercentage = 55
        });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatForProductAsyncReturnsAllMediaForProduct()
    {
        var actual = (await _sut.ForProductAsync(MockedProductIds[0])).ToList();

        Assert.Equal(3, actual.Count);
    }

    [Fact]
    public async Task TestThatRepositionMediaAsyncWithFileIdsUpdatesPosition()
    {
        var fileIds = new[]
        {
            MockedFileIds[0],
            MockedFileIds[3],
            MockedFileIds[2]
        };

        var media = (await _sut.ForProductAsync(MockedProductIds[0])).ToList();

        await _sut.RepositionMediaAsync(media, fileIds);

        _mockedContext.Verify(c => c.ProductMedia.UpdateRange(It.Is<IEnumerable<FanceeData.Models.Ticketing.ProductMedia>>(pm => pm.Count() == 3)), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatRepositionMediaAsyncWithUpdateAfterPositionRepositionsMedia()
    {
        var actual = await _sut.RepositionMediaAsync(MockedProductIds[0], 2);

        Assert.Equal(1, actual);
    }
}