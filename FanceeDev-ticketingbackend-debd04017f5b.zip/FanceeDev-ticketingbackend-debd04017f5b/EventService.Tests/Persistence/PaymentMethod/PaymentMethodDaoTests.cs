﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.PaymentMethod;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.PaymentMethod;

public class PaymentMethodDaoTests
{
    private static readonly FanceeData.Models.Ticketing.Event ValidEvent = new()
    {
        Id = Guid.NewGuid()
    };

    private static readonly Guid[] ValidPaymentMethodIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    private static readonly FanceeData.Models.Ticketing.PaymentMethod ValidPaymentMethod = new()
    {
        Id = ValidPaymentMethodIds[0],
        Name = "IDeal",
        Provider = PaymentProvider.Adyen,
        Active = true,
        FeeStaticCents = 10,
        Order = 3,
        Events = new List<EventPaymentMethod>
        {
            new() { Event = ValidEvent, EventId = ValidEvent.Id, PaymentMethodId = ValidPaymentMethodIds[0], PaidBy = PaidBy.Organization }
        }
    };

    private static readonly FanceeData.Models.Ticketing.PaymentMethod InvalidPaymentMethod = new()
    {
        Id = ValidPaymentMethodIds[1],
        Name = "PayPal",
        Provider = PaymentProvider.Adyen,
        Active = false,
        FeeStaticCents = 10,
        FeePercentage = 1.0m,
        Order = 2,
        Events = new List<EventPaymentMethod>
        {
            new() { Event = ValidEvent, EventId = ValidEvent.Id, PaymentMethodId = ValidPaymentMethodIds[1], PaidBy = PaidBy.Client }
        }
    };

    private static readonly List<FanceeData.Models.Ticketing.PaymentMethod> PaymentMethods = new()
    {
        ValidPaymentMethod,
        InvalidPaymentMethod,
        new()
        {
            Id = ValidPaymentMethodIds[2],
            Name = "Bancontact",
            Provider = PaymentProvider.Adyen,
            Active = true,
            FeeStaticCents = null,
            FeePercentage = 2.3m,
            Order = 1,
            Events = new List<EventPaymentMethod>
            {
                new() { Event = ValidEvent, EventId = ValidEvent.Id, PaymentMethodId = ValidPaymentMethodIds[2], PaidBy = PaidBy.Client }
            }
        }
    };

    private readonly PaymentMethodDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public PaymentMethodDaoTests()
    {
        _mockedContext.Setup(c => c.PaymentMethods).ReturnsDbSet(PaymentMethods);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAvailablePaymentMethodsAsyncReturnsExpectedResult()
    {
        var actual = (await _sut.AvailablePaymentMethodsAsync(ValidEvent.Id)).ToList();

        Assert.Equal(2, actual.Count);

        var (firstPmv, firstPaidBy) = actual[0];
        var (secondPmv, secondPaidBy) = actual[1];

        Assert.Equal("Bancontact", firstPmv.Name);
        Assert.Equal(PaidBy.Client, firstPaidBy);
        Assert.Equal("IDeal", secondPmv.Name);
        Assert.Equal(PaidBy.Organization, secondPaidBy);
    }
}