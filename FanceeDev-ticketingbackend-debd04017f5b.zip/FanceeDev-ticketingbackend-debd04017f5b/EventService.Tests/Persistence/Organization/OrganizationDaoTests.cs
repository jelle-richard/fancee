﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Persistence.Organization;
using FanceeData.Contexts;

namespace EventService.Tests.Persistence.Organization;

public class OrganizationDaoTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly OrganizationDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private static readonly IEnumerable<FanceeData.Models.Ticketing.Organization> Organizations = new List<FanceeData.Models.Ticketing.Organization>
    {
        new()
        {
            Id = ValidOrganizationId,
            User = new()
            {
                Email = "unit@test.com",
                UserContactInfo = new()
            },
            CountryCode = "NL",
            Events = new List<FanceeData.Models.Ticketing.Event>
            {
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-100)
                },
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-100)
                },
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-100)
                },
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-50)
                },
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-50)
                },
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-10)
                },
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-10)
                }
            }
        },
        new()
        {
            Id = ValidOrganizationId,
            User = new()
            {
                Email = "unit@test.com",
                UserContactInfo = new()
            },
            CountryCode = "NL",
            Events = new List<FanceeData.Models.Ticketing.Event>
            {
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-100)
                },
                new()
                {
                    StartDate = DateTime.UtcNow.AddDays(-100)
                }
            }
        }
    };
    public OrganizationDaoTests()
    {
        _sut = new(_mockedContext.Object);

        _mockedContext.Setup(c => c.Organizations).ReturnsDbSet(Organizations);
    }
    
    

    [Fact]
    public async Task TestThatDefaultReservationTimeMinutesReturnsOrganizationDefaultReservationTime()
    {
        var actual = await _sut.DefaultReservationTimeMinutes(ValidOrganizationId);

        Assert.Equal(8, actual);
        Assert.IsType<int>(actual);
    }

    [Fact]
    public async Task TestThatByRangeRetrievesOrganizationWithEventsInRange()
    {
        var actual = await _sut.ByRangeAsync(DateTime.UtcNow.AddDays(-80), DateTime.UtcNow, new List<string> { "NL" }.ToArray());
        Assert.Single(actual);
    }

    [Fact]
    public async Task TestThatByRangeRetrievesOrganizationWithEventsInRangeReturnsEmptyIfLookupHasCountryCodeWithNoOrganizations()
    {
        var actual = await _sut.ByRangeAsync(DateTime.UtcNow.AddDays(-80), DateTime.UtcNow, new List<string> { "DE" }.ToArray());
        Assert.Empty(actual);
    }
}