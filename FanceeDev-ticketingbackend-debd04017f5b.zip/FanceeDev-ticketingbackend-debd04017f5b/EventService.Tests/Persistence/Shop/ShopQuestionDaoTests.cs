using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Persistence.Shop;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Shop;

public class ShopQuestionDaoTests
{
    private static readonly Guid MockedQuestionId = Guid.NewGuid();

    public static readonly object[][] GetAsyncTestData =
    {
        new object[] { MockedQuestionId, true },
        new object[] { Guid.NewGuid(), false }
    };

    private static readonly Guid MockedQuestionWithAnswersId = Guid.NewGuid();

    private readonly ShopQuestionDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public ShopQuestionDaoTests()
    {
        _mockedContext = new();

        _mockedContext.Setup(c => c.ShopQuestions)
            .ReturnsDbSet(new List<ShopQuestion>
            {
                new()
                {
                    Id = MockedQuestionId,
                    Position = 0,
                    Required = false,
                    Question = "Gaan deze unit tests wel goed?",
                    Type = ShopQuestionType.Open
                }
            });

        _mockedContext.Setup(c => c.ShopQuestionAnswers)
            .ReturnsDbSet(new List<ShopQuestionAnswer>
            {
                new()
                {
                    Answer = "\"Nee\"",
                    ShopQuestionId = MockedQuestionWithAnswersId
                },
                new()
                {
                    Answer = "Kijk maar ff.",
                    ShopQuestionId = MockedQuestionWithAnswersId
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Theory]
    [MemberData(nameof(GetAsyncTestData))]
    public async Task TestThatGetAsyncReturnsShopQuestionById(Guid shopQuestionId, bool expected)
    {
        var actual = await _sut.GetAsync(shopQuestionId);

        if (expected)
        {
            Assert.NotNull(actual);
            Assert.Equal(shopQuestionId, actual.Id);
        }
        else Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncDeletesShopQuestionById()
    {
        var shopQuestion = await _sut.GetAsync(MockedQuestionId);

        Assert.NotNull(shopQuestion);

        await _sut.DeleteAsync(shopQuestion);

        _mockedContext.Verify(c => c.ShopQuestions.Remove(shopQuestion), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesShopQuestion()
    {
        var shopQuestion = await _sut.GetAsync(MockedQuestionId);

        Assert.NotNull(shopQuestion);

        await _sut.UpdateAsync(shopQuestion);

        _mockedContext.Verify(c => c.ShopQuestions.Update(shopQuestion), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatHasAnswersAsyncReturnsWhetherShopQuestionHasAnswers()
    {
        Assert.False(await _sut.HasAnswersAsync(MockedQuestionId));
        Assert.True(await _sut.HasAnswersAsync(MockedQuestionWithAnswersId));
    }

    [Fact]
    public async Task TestThatCreateAsyncCreatesShopQuestion()
    {
        await _sut.CreateAsync(new ShopQuestion());

        _mockedContext.Verify(c => c.ShopQuestions.AddAsync(It.IsAny<ShopQuestion>(), default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateAsyncCreatesShopQuestions()
    {
        await _sut.CreateAsync(new List<ShopQuestion>());

        _mockedContext.Verify(c => c.ShopQuestions.AddRange(It.IsAny<IEnumerable<ShopQuestion>>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}