using System;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Shop;
using FanceeData.Contexts;
using JetBrains.Annotations;

namespace EventService.Tests.Persistence.Shop;

[TestSubject(typeof(ShopsDao))]
public class ShopsDaoTests
{
    private static readonly Guid[] OrganizationIds = [Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid[] EventIds = [Guid.NewGuid(), Guid.NewGuid()];

    private readonly ShopsDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public ShopsDaoTests()
    {
        _mockedContext.Setup(c => c.Shops).ReturnsDbSet([
            new()
            {
                Code = "CODE1",
                Name = "Friend shop",
                StartDate = DateTime.UtcNow.AddDays(-5),
                EventId = EventIds[0],
                Event = new()
                {
                    OrganizationId = OrganizationIds[0],
                    Name = "Blue Wings Festival"
                }
            },
            new()
            {
                Code = "CODE2",
                Name = "VIP shop",
                StartDate = DateTime.UtcNow.AddDays(-4),
                EventId = EventIds[0],
                Event = new()
                {
                    OrganizationId = OrganizationIds[0],
                    Name = "Blue Wings Festival"
                }
            },
            new()
            {
                Code = "CODE3",
                Name = "New shop",
                StartDate = DateTime.UtcNow.AddDays(-3),
                EventId = EventIds[1],
                Event = new()
                {
                    OrganizationId = OrganizationIds[1],
                    Name = "Open Air Festival"
                }
            }
        ]);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsExpectedResult()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [], null, [])).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal("CODE2", actual[0].Id);
        Assert.Equal("VIP shop", actual[0].Label);
        Assert.Equal("Blue Wings Festival", actual[0].Header);
        Assert.Null(actual[0].Note);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsFiltersOnShopCode()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], ["CODE1"], null, [])).ToList();

        Assert.Single(actual);
        Assert.Equal("CODE1", actual[0].Id);
        Assert.Equal("Friend shop", actual[0].Label);
        Assert.Equal("Blue Wings Festival", actual[0].Header);
        Assert.Null(actual[0].Note);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsFiltersOnEventName()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [], "Blue Wings", [])).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal("CODE2", actual[0].Id);
        Assert.Equal("VIP shop", actual[0].Label);
        Assert.Equal("Blue Wings Festival", actual[0].Header);
        Assert.Null(actual[0].Note);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsFiltersOnShopName()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [], "VIP", [])).ToList();

        Assert.Single(actual);
        Assert.Equal("CODE2", actual[0].Id);
        Assert.Equal("VIP shop", actual[0].Label);
        Assert.Equal("Blue Wings Festival", actual[0].Header);
        Assert.Null(actual[0].Note);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsFiltersOnEventId()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[1], [], null, [EventIds[1]])).ToList();

        Assert.Single(actual);
        Assert.Equal("CODE3", actual[0].Id);
        Assert.Equal("New shop", actual[0].Label);
        Assert.Equal("Open Air Festival", actual[0].Header);
        Assert.Null(actual[0].Note);
    }
}