using System.Threading.Tasks;
using EventService.Persistence.Shop;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Shop;

public class ShopMailDaoTests
{
    private readonly ShopMailDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public ShopMailDaoTests()
    {
        _mockedContext.Setup(c => c.ShopMails).ReturnsDbSet(new ShopMail[]
        {
            new()
            {
                ShopCode = "Shop1",
                Type = ShopMailType.Purchase,
                SenderName = "Harry Organization",
                Content = "<h1>Content</h1>",
                Subject = "Unit purchase mail"
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncAddsNewShopMail()
    {
        var shopMail = new ShopMail
        {
            ShopCode = "Shop2",
            Type = ShopMailType.Purchase,
            SenderName = "Unit Tester",
            Subject = "Unit purchase mail",
            Content = "Mail content!"
        };

        await _sut.AddOrUpdateAsync(shopMail);

        _mockedContext.Verify(c => c.ShopMails.AddAsync(shopMail, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
        _mockedContext.Verify(c => c.ShopMails.Update(It.IsAny<ShopMail>()), Times.Never);
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncUpdatesShopMail()
    {
        var shopMail = new ShopMail
        {
            ShopCode = "Shop1",
            Type = ShopMailType.Purchase,
            SenderName = "Harry The Organization",
            Subject = "Unit purchase mail",
            Content = "New content"
        };

        await _sut.AddOrUpdateAsync(shopMail);

        _mockedContext.Verify(c => c.ShopMails.Update(shopMail), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
        _mockedContext.Verify(c => c.ShopMails.AddAsync(It.IsAny<ShopMail>(), default), Times.Never);
    }
}