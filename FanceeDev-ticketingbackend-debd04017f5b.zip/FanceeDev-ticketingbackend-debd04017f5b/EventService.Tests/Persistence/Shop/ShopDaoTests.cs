using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Shop;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Environment;

namespace EventService.Tests.Persistence.Shop;

public class ShopDaoTests
{
    private static readonly Guid[] MockedEventIds = { Guid.NewGuid(), Guid.NewGuid() };

    public static readonly object[][] UniqueNameForEventTestData =
    {
        new object[] { "My First Shop", MockedEventIds[0], false },
        new object[] { "My Third Shop", MockedEventIds[0], true },
        new object[] { "My First Shop", MockedEventIds[1], true }
    };

    private static readonly Guid UserId = Guid.NewGuid();

    private readonly ShopDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly List<ItemInShop> _itemsInShops = new()
    {
        new()
        {
            Id = Guid.NewGuid(),
            ShopCode = "UnitTestCode1",
            Position = 1,
            ShopElement = new DividerElement()
        },
        new()
        {
            Id = Guid.NewGuid(),
            ShopCode = "UnitTestCode1",
            Position = 2,
            ShopElement = new AccordionElement
            {
                Elements = new AccordionShopElement[]
                {
                    new() { ShopElement = new NoticeElement() },
                    // note: nested accordions is not officially supported, but we test for correctness anyway
                    new()
                    {
                        ShopElement = new AccordionElement
                        {
                            Elements = new AccordionShopElement[] { new() { ShopElement = new TextBlockElement() } }
                        }
                    }
                }
            }
        }
    };

    private readonly HostedDeploymentEnvironment _deploymentEnvironment = new()
    {
        Id = Guid.NewGuid(),
        Name = "UnitTestEnv",
        Domain = "localhost",
        IsHttps = false
    };

    private readonly List<FanceeData.Models.Ticketing.Shop> _shops = new()
    {
        new()
        {
            Code = "UnitTestCode1",
            Name = "My First Shop",
            NumberOfViews = 100,
            EventId = MockedEventIds[0],
            Event = new() { Id = MockedEventIds[0], OrganizationId = UserId },
            ReservedProducts = new List<ReservedProduct>(),
            ShopDesign = new()
            {
                HeaderMedia = new List<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>
                {
                    new()
                    {
                        Position = 1,
                        File = new()
                        {
                            Id = Guid.NewGuid(),
                            Path = "unit/file/path"
                        },
                        FocalPointHeightPercentage = null,
                        FocalPointWidthPercentage = null
                    }
                }
            }
        },
        new()
        {
            Code = "UnitTestCode2",
            Name = "My Second Shop",
            NumberOfViews = 200,
            EventId = MockedEventIds[0],
            Event = new() { Id = MockedEventIds[0], OrganizationId = UserId },
            ReservedProducts = new List<ReservedProduct>(),
            ShopDesign = new()
            {
                HeaderMedia = new List<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>()
            }
        },
        new()
        {
            Code = "jf9293jf9JJJpal",
            Name = "Friend Shop",
            NumberOfViews = 300,
            EventId = MockedEventIds[1],
            Event = new() { Id = MockedEventIds[1], OrganizationId = UserId },
            ReservedProducts = new List<ReservedProduct>(),
            ShopDesign = new()
            {
                HeaderMedia = new List<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>
                {
                    new()
                    {
                        Position = 1,
                        File = new()
                        {
                            Id = Guid.NewGuid(),
                            Path = "unit/file/path"
                        },
                        FocalPointHeightPercentage = 50,
                        FocalPointWidthPercentage = 50
                    }
                }
            }
        },
        new()
        {
            Code = "InUse",
            Name = "InUseShop",
            NumberOfViews = 400,
            EventId = MockedEventIds[0],
            Event = new() { Id = MockedEventIds[0], OrganizationId = UserId },
            ReservedProducts = new List<ReservedProduct>
            {
                new()
            },
            ShopDesign = new()
            {
                HeaderMedia = new List<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>()
            }
        }
    };

    public ShopDaoTests()
    {
        _mockedContext.Setup(c => c.Files).ReturnsDbSet([]);
        _mockedContext.Setup(c => c.Shops).ReturnsDbSet(_shops);
        _mockedContext.Setup(c => c.ShopElements).ReturnsDbSet([]);
        _mockedContext.Setup(c => c.ShopsInCombinedShops).ReturnsDbSet([]);
        _mockedContext.Setup(c => c.AccordionShopElements).ReturnsDbSet([]);
        _mockedContext.Setup(c => c.ItemsInShops).ReturnsDbSet(_itemsInShops);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatCreateCreatesShop()
    {
        var shop = new FanceeData.Models.Ticketing.Shop { Code = "UnitTest" };
        await _sut.CreateAsync(shop);

        _mockedContext.Verify(c => c.Shops.AddAsync(shop, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatListAsyncListsShopsForEvent()
    {
        var actual = (await _sut.ListAsync(UserId, MockedEventIds[0], _deploymentEnvironment))?.ToList() ?? null;

        Assert.NotNull(actual);

        Assert.Equal(3, actual.Count);
        Assert.Null(actual.First().HeaderMedia.First().FocalPointHeightPercentage);
        Assert.Equal("UnitTestCode1", actual.First().Code);
        Assert.Equal("My First Shop", actual.First().Name);
        Assert.Equal(100, actual.First().NumberOfViews);
        Assert.Equal("UnitTestCode2", actual.ElementAt(1).Code);
        Assert.Equal("My Second Shop", actual.ElementAt(1).Name);
        Assert.Equal(200, actual.ElementAt(1).NumberOfViews);

        var inUseShop = actual.FirstOrDefault(sli => sli.InUse);

        Assert.NotNull(inUseShop);
        Assert.True(inUseShop.Code == "InUse");
        Assert.True(_shops.First(s => s.Code == "InUse").ReservedProducts.Any());

        var notInUseShop = actual.FirstOrDefault(sli => !sli.InUse);

        Assert.NotNull(notInUseShop);
        Assert.True(notInUseShop.Code != "InUse");
        Assert.False(_shops.First(s => s.Code != "InUse").ReservedProducts.Any());
    }

    [Theory]
    [MemberData(nameof(UniqueNameForEventTestData))]
    public async Task TestThatUniqueNameForEventAsyncReturnsExpectedValue(string name, Guid eventId, bool expected)
    {
        var actual = await _sut.UniqueNameForEventAsync(name, eventId);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData("UnitTestCode1", false)]
    [InlineData("jdsfjksdofwdjfl", true)]
    public async Task TestThatIsUniqueAsyncReturnsExpectedValue(string code, bool expected)
    {
        // We must setup a hardcoded value here, as FindAsync will not return the expected value from the test data list.
        _mockedContext.Setup(c => c.Shops.FindAsync("UnitTestCode1")).ReturnsAsync(new FanceeData.Models.Ticketing.Shop());

        var actual = await _sut.IsUniqueAsync(code);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatByCodeAsyncReturnsShop()
    {
        var actual = await _sut.ByCodeAsync("UnitTestCode1");

        Assert.NotNull(actual);
        Assert.Equal("My First Shop", actual!.Name);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesShop()
    {
        var shop = new FanceeData.Models.Ticketing.Shop
        {
            Code = "UnitTestCode1",
            Name = "Updated name"
        };

        await _sut.UpdateAsync(shop);

        _mockedContext.Verify(c => c.Shops.Update(shop), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncDeletesShop()
    {
        var shop = new FanceeData.Models.Ticketing.Shop
        {
            Code = "UnitTestCode1",
            ItemsInShop = [new()],
            ShopsInCombinedShop = [new()]
        };

        await _sut.DeleteAsync(shop);

        _mockedContext.Verify(c => c.ItemsInShops.RemoveRange(shop.ItemsInShop), Times.Once);
        _mockedContext.Verify(c => c.ShopsInCombinedShops.RemoveRange(shop.ShopsInCombinedShop), Times.Once);
        _mockedContext.Verify(c => c.Shops.Remove(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaAsyncReturnsIfNoMediaIsAvailable()
    {
        await _sut.DeleteBackgroundMediaAsync(new());

        _mockedContext.Verify(c => c.Files.Remove(It.IsAny<File>()), Times.Never);
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaAsyncRemovesFile()
    {
        var design = new ShopDesign
        {
            BackgroundMediaFile = new()
            {
                Id = Guid.NewGuid(),
                Name = "UnitFile"
            }
        };

        await _sut.DeleteBackgroundMediaAsync(design);

        _mockedContext.Verify(c => c.Files.Remove(design.BackgroundMediaFile), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteItemsInShopAsyncRemovesAllItems()
    {
        var shop = _mockedContext.Object.Shops.First();
        shop.ItemsInShop = _itemsInShops.Where(iis => iis.ShopCode == shop.Code).ToList();

        await _sut.DeleteItemsInShopAsync(shop);

        _mockedContext.Verify(c => c.ItemsInShops.RemoveRange(shop.ItemsInShop), Times.Once);
        _mockedContext.Verify(c => c.ShopElements.RemoveRange(It.Is<IEnumerable<ShopElement>>(e => e.Count() == 3)), Times.Once);
        _mockedContext.Verify(c => c.AccordionShopElements.RemoveRange(It.Is<IList<AccordionShopElement>>(l => l.Count == 2)), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Theory]
    [InlineData("InUse", true)]
    [InlineData("UnitTestCode1", false)]
    public async Task TestThatInUseReturnsExpectedResult(string shopCode, bool expected)
    {
        var actual = await _sut.InUseAsync(shopCode);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatShopCodesAsyncReturnsAllShopCodes()
    {
        var actual = await _sut.ShopCodesAsync(MockedEventIds[0]);

        Assert.Equal(3, actual.Count());
    }

    [Fact]
    public async Task TestThatItemsInShopAsyncGetsItemsInShop()
    {
        var actual = await _sut.ItemsInShopAsync("UnitTestCode1");

        Assert.Equal(2, actual.Count());
    }

    [Fact]
    public async Task TestThatInsertShopElementInsertsShopElement()
    {
        var elem = new NoticeElement();

        await _sut.InsertShopElement(elem);

        _mockedContext.Verify(c => c.ShopElements.AddAsync(elem, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}