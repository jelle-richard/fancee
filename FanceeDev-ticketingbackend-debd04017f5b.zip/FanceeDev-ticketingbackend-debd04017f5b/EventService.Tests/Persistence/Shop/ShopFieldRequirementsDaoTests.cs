using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Persistence.Shop;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Shop;

public class ShopFieldRequirementsDaoTests
{
    private static readonly string[] ShopCodes = { "test 1", "test 2", "test 3" };
    private static readonly Guid[] EventIds = { Guid.NewGuid(), Guid.NewGuid() };

    private static readonly List<ShopFieldRequirement> _shopFieldRequirements = new()
    {
        new()
        {
            Field = ShopField.Birthdate
        },
        new()
        {
            Field = ShopField.Birthdate
        }
    };

    private readonly List<FanceeData.Models.Ticketing.Shop> _shops = new()
    {
        new()
        {
            Code = ShopCodes[0],
            EventId = EventIds[0],
            ShopFieldRequirements = new List<ShopFieldRequirement>
            {
                _shopFieldRequirements[0]
            }
        },
        new()
        {
            Code = ShopCodes[1],
            EventId = EventIds[0],
            ShopFieldRequirements = new List<ShopFieldRequirement>
            {
                _shopFieldRequirements[1]
            }
        },
        new()
        {
            Code = ShopCodes[2],
            EventId = EventIds[1],
            ShopFieldRequirements = new List<ShopFieldRequirement>
            {
                _shopFieldRequirements[1]
            }
        }
    };

    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly ShopFieldRequirementDao _sut;

    public ShopFieldRequirementsDaoTests()
    {
        _mockedContext.Setup(c => c.Shops).ReturnsDbSet(_shops);
        _mockedContext.Setup(c => c.ShopFieldRequirements).ReturnsDbSet(_shopFieldRequirements);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByEventIdAndShopFieldAsyncReturnsExpected()
    {
        var actual = await _sut.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(EventIds[0], ShopField.Birthdate);

        Assert.NotNull(actual);
        Assert.Contains(_shops[0], actual);
        Assert.Contains(_shops[1], actual);
        Assert.DoesNotContain(_shops[2], actual);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesRecord()
    {
        await _sut.UpdateAsync(It.IsAny<List<ShopFieldRequirement>>());

        _mockedContext.Verify(c => c.ShopFieldRequirements.UpdateRange(It.IsAny<List<ShopFieldRequirement>>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatAddAsyncCreatesNewShopFieldRequirement()
    {
        var shopFieldRequirements = new List<ShopFieldRequirement>
        {
            new()
            {
                Code = "unitTest",
                Field = ShopField.Birthdate,
                Required = true,
                Enabled = true
            }
        };

        await _sut.AddAsync(shopFieldRequirements);

        _mockedContext.Verify(c => c.ShopFieldRequirements.AddRangeAsync(shopFieldRequirements, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}