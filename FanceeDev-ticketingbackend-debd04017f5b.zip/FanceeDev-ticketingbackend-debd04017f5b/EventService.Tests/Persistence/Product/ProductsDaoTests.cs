using System;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Product;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;

namespace EventService.Tests.Persistence.Product;

[TestSubject(typeof(ProductsDao))]
public class ProductsDaoTests
{
    private static readonly Guid[] OrganizationIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid[] ProductIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid[] EventIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];

    private static readonly FanceeData.Models.Ticketing.Event[] Events =
    [
        new()
        {
            Id = EventIds[0],
            Name = "Event 1",
            StartDate = DateTime.UtcNow.AddMinutes(-1),
            EndDate = DateTime.UtcNow.AddMinutes(-1),
            OrganizationId = OrganizationIds[0],
            Status = EventStatus.Active
        },
        new()
        {
            Id = EventIds[1],
            Name = "Event 2",
            StartDate = DateTime.UtcNow.AddMinutes(1),
            EndDate = DateTime.UtcNow.AddMinutes(1),
            OrganizationId = OrganizationIds[1],
            Status = EventStatus.Active
        },
        new()
        {
            Id = EventIds[2],
            Name = "Event 3",
            StartDate = DateTime.UtcNow.AddMinutes(1),
            EndDate = DateTime.UtcNow.AddMinutes(1),
            OrganizationId = OrganizationIds[1],
            Status = EventStatus.Active
        },
        new()
        {
            Id = EventIds[3],
            Name = "Event 4",
            StartDate = DateTime.UtcNow.AddMinutes(1),
            EndDate = DateTime.UtcNow.AddMinutes(1),
            OrganizationId = OrganizationIds[2],
            Status = EventStatus.Active
        },
        new()
        {
            Id = EventIds[4],
            Name = "Event 5",
            StartDate = DateTime.UtcNow.AddMinutes(-1),
            EndDate = DateTime.UtcNow.AddMinutes(-1),
            OrganizationId = OrganizationIds[2],
            Status = EventStatus.Active
        },
        new()
        {
            Id = EventIds[5],
            Name = "Event 6",
            StartDate = DateTime.UtcNow.AddMinutes(1),
            EndDate = DateTime.UtcNow.AddMinutes(1),
            OrganizationId = OrganizationIds[2],
            Status = EventStatus.Cancelled
        }
    ];

    private readonly ProductsDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public ProductsDaoTests()
    {
        _mockedContext.Setup(c => c.Products).ReturnsDbSet([
            new()
            {
                Id = ProductIds[0],
                Name = "Product 1",
                EventId = Events[0].Id,
                Event = Events[0]
            },
            new()
            {
                Id = ProductIds[1],
                Name = "Product 2",
                EventId = Events[0].Id,
                Event = Events[0]
            },
            new()
            {
                Id = ProductIds[2],
                Name = "Product 3",
                EventId = Events[1].Id,
                Event = Events[1]
            },
            new()
            {
                Id = ProductIds[3],
                Name = "Product 4",
                EventId = Events[2].Id,
                Event = Events[2]
            },
            new()
            {
                Id = ProductIds[4],
                Name = "Product 5",
                EventId = Events[3].Id,
                Event = Events[3]
            },
            new()
            {
                Id = ProductIds[5],
                Name = "Product 6",
                EventId = Events[4].Id,
                Event = Events[4]
            },
            new()
            {
                Id = ProductIds[6],
                Name = "Product 7",
                EventId = Events[5].Id,
                Event = Events[5]
            }
        ]);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsExpectedResult()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [], null, [], false)).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Contains(actual, so => so.Id == ProductIds[0]);
        Assert.Contains(actual, so => so.Id == ProductIds[1]);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncFiltersOnProductId()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [ProductIds[0]], null, [], false)).ToList();

        Assert.Single(actual);
        Assert.Equal(ProductIds[0], actual[0].Id);
        Assert.Equal("Product 1", actual[0].Label);
        Assert.Equal("Event 1", actual[0].Header);
        Assert.StartsWith($"{DateTime.UtcNow.Year}", actual[0].Note);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncFiltersOnEventId()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[1], [], null, [EventIds[1]], false)).ToList();

        Assert.Single(actual);
        Assert.Equal(ProductIds[2], actual[0].Id);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncFiltersOnProductName()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[1], [], "Product 3", [], false)).ToList();

        Assert.Single(actual);
        Assert.Equal(ProductIds[2], actual[0].Id);
        Assert.Equal("Product 3", actual[0].Label);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncFiltersOnEventName()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[1], [], "Event 3", [], false)).ToList();

        Assert.Single(actual);
        Assert.Equal(ProductIds[3], actual[0].Id);
        Assert.Equal("Product 4", actual[0].Label);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsUpcoming()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[2], [], null, [], true)).ToList();

        Assert.Single(actual);
        Assert.Equal(ProductIds[4], actual[0].Id);
        Assert.Equal("Product 5", actual[0].Label);
    }
}