﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Product;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;

namespace EventService.Tests.Persistence.Product;

[TestSubject(typeof(ProductDao))]
public class ProductDaoTests
{
    private const string ValidOrganizationEmail = "unit@test.com";
    private const string InvalidOrganizationEmail = "in@valid.com";

    private static readonly Guid InvalidProductTypeProductId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid InvalidOrganizationId = Guid.NewGuid();
    private static readonly Guid ProductFileId = Guid.NewGuid();
    private static readonly Guid[] MockedProductIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private static readonly Guid[] MockedEventIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    private static readonly IList<FanceeData.Models.Ticketing.Product> Products = new List<FanceeData.Models.Ticketing.Product>
    {
        new()
        {
            Id = MockedProductIds[0],
            Type = ProductType.Ticket,
            EventId = MockedEventIds[0],
            Event = new()
            {
                Id = MockedEventIds[0],
                OrganizationId = ValidOrganizationId,
                Organization = new() { User = new() { Email = ValidOrganizationEmail } }
            },
            ReservedProducts = new List<ReservedProduct>(),
            IssuedProducts = new List<IssuedProduct>(),
            Name = "Test product",
            ProductMedia = new List<FanceeData.Models.Ticketing.ProductMedia>
            {
                new()
                {
                    FileId = ProductFileId,
                    File = new()
                    {
                        Id = ProductFileId
                    }
                }
            },
            ItemInShops = new List<ItemInShop>
            {
                new()
                {
                    ProductId = MockedProductIds[0],
                    Shop = new()
                    {
                        Name = "Test shop"
                    }
                }
            }
        },
        new()
        {
            Id = MockedProductIds[1],
            Type = ProductType.Ticket,
            EventId = MockedEventIds[0],
            Event = new()
            {
                Id = MockedEventIds[0],
                OrganizationId = ValidOrganizationId,
                Organization = new() { User = new() { Email = ValidOrganizationEmail } }
            },
            ReservedProducts = new List<ReservedProduct> { new() { Id = Guid.NewGuid(), ProductId = MockedProductIds[1], Quantity = 1, ReservationReference = Guid.NewGuid() } },
            IssuedProducts = new List<IssuedProduct>()
        },
        new()
        {
            Id = MockedProductIds[2],
            Type = ProductType.Product,
            EventId = MockedEventIds[0],
            Event = new()
            {
                Id = MockedEventIds[0],
                OrganizationId = ValidOrganizationId,
                Organization = new() { User = new() { Email = ValidOrganizationEmail } }
            },
            ReservedProducts = new List<ReservedProduct>(),
            IssuedProducts = new List<IssuedProduct>()
        },
        new()
        {
            Id = MockedProductIds[3],
            Type = ProductType.Ticket,
            EventId = MockedEventIds[0],
            Event = new()
            {
                Id = MockedEventIds[0],
                OrganizationId = ValidOrganizationId,
                Organization = new() { User = new() { Email = ValidOrganizationEmail } }
            },
            ReservedProducts = new List<ReservedProduct>(),
            IssuedProducts = new List<IssuedProduct> { new() { OrderId = Guid.NewGuid(), IssuedTicket = new() { Code = "Test" } } }
        },
        new()
        {
            Id = MockedProductIds[4],
            Type = ProductType.Product,
            EventId = MockedEventIds[1],
            Event = new()
            {
                Id = MockedEventIds[1],
                OrganizationId = ValidOrganizationId,
                Organization = new() { User = new() { Email = ValidOrganizationEmail } }
            },
            ReservedProducts = new List<ReservedProduct>(),
            IssuedProducts = new List<IssuedProduct>()
        },
        new()
        {
            Id = InvalidProductTypeProductId,
            Type = ProductType.Product,
            EventId = MockedEventIds[2],
            Event = new()
            {
                Id = MockedEventIds[2],
                OrganizationId = InvalidOrganizationId,
                Organization = new() { User = new() { Email = InvalidOrganizationEmail } }
            },
            ReservedProducts = new List<ReservedProduct>(),
            IssuedProducts = new List<IssuedProduct>()
        }
    };

    public static readonly object[][] SalesReservationsTests =
    {
        new object[] { new[] { Products[0].Id, Products[1].Id }, true },
        new object[] { new[] { Products[0].Id, Products[4].Id }, false },
        new object[] { new[] { Products[3].Id }, true }
    };

    public static readonly object[][] ProductTypeTestData =
    {
        new object[] { Products[0].Id, ProductType.Ticket },
        new object[] { Products[3].Id, ProductType.Ticket },
        new object[] { InvalidProductTypeProductId, ProductType.Product }
    };

    public static readonly object[][] ProductOwnerTestData =
    {
        new object[] { MockedEventIds[0], Products[0].Id, true },
        new object[] { MockedEventIds[2], Products[0].Id, false },
        new object[] { MockedEventIds[2], InvalidProductTypeProductId, true },
        new object[] { MockedEventIds[0], InvalidProductTypeProductId, false }
    };

    public static readonly object[][] SalesOrReservationTestData =
    {
        new object[] { Guid.NewGuid(), false },
        new object[] { Guid.NewGuid(), false },
        new object[] { MockedEventIds[0], true }
    };

    private readonly ProductDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public ProductDaoTests()
    {
        _mockedContext = new();
        _mockedContext.Setup(c => c.Products).ReturnsDbSet(Products);
        _mockedContext.Setup(c => c.ProductPriceHistories).ReturnsDbSet(new List<ProductPriceHistory>());
        _mockedContext.Setup(c => c.TicketOptions).ReturnsDbSet(new List<TicketOption>
        {
            new()
            {
                Product = new()
                {
                    EventId = MockedEventIds[0]
                },
                ProductId = MockedProductIds[0]
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInsertAsyncInsertsProduct()
    {
        var model = new FanceeData.Models.Ticketing.Product
        {
            Id = InvalidProductTypeProductId
        };

        await _sut.InsertAsync(model);

        _mockedContext.Verify(c => c.SaveChangesAsync(default));
    }

    [Fact]
    public async Task TestThatInsertAsyncInsertsMultipleProducts()
    {
        var models = new FanceeData.Models.Ticketing.Product[]
        {
            new(),
            new()
        };

        await _sut.InsertAsync(models);

        _mockedContext.Verify(c => c.Products.AddRangeAsync(models, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncRemovesProductById()
    {
        _mockedContext.Setup(c => c.ItemsInShops).ReturnsDbSet(Products[0].ItemInShops);

        await _sut.DeleteAsync(Products[0].Id);

        _mockedContext.Verify(c => c.ItemsInShops.RemoveRange(Products[0].ItemInShops));
        _mockedContext.Verify(c => c.Attach(It.IsAny<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedContext.Verify(c => c.Products.Remove(It.IsAny<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncRemovesProductByProduct()
    {
        _mockedContext.Setup(c => c.ItemsInShops).ReturnsDbSet(Products[0].ItemInShops);

        await _sut.DeleteAsync(Products[0]);

        _mockedContext.Verify(c => c.ItemsInShops.RemoveRange(Products[0].ItemInShops));
        _mockedContext.Verify(c => c.Products.Remove(It.IsAny<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
        _mockedContext.Verify(c => c.Attach(It.IsAny<FanceeData.Models.Ticketing.Product>()), Times.Never);
    }

    [Theory]
    [MemberData(nameof(ProductTypeTestData))]
    public async Task TestThatProductTypeAsyncReturnsProductType(Guid productId, ProductType expected)
    {
        var actual = await _sut.ProductTypeAsync(productId);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [MemberData(nameof(ProductOwnerTestData))]
    public async Task TestThatOwnerOfProductAsyncReturnsExpectedResult(Guid eventId, Guid productId, bool expected)
    {
        var actual = await _sut.BelongsToEventAsync(productId, eventId);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatOwnerOfProductsAsyncReturnsTrueWhenAllProductsBelongToOrganization()
    {
        var actual = await _sut.OwnerOfProductsAsync(ValidOrganizationId, new[] { Products[0].Id, Products[1].Id, Products[4].Id });

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatOwnerOfProductsAsyncReturnsFalseWhenNotAllProductsBelongToOrganization()
    {
        var actual = await _sut.OwnerOfProductsAsync(ValidOrganizationId, new[] { Products[0].Id, InvalidProductTypeProductId });

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatUpdateBatchAsyncUpdatesGivenProducts()
    {
        var list = new List<FanceeData.Models.Ticketing.Product>
        {
            new()
            {
                Id = Guid.NewGuid() // 95 
            }
        };

        await _sut.UpdateBatchAsync(list);

        _mockedContext.Verify(c => c.Products.UpdateRange(list), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAllAsyncReturnsAllProductsThatBelongToEvent()
    {
        var actual = await _sut.GetAllAsync(MockedEventIds[0], ValidOrganizationId, p => p.TicketOption);

        Assert.Equal(4, actual.Count());
    }

    [Fact]
    public async Task TestThatGetAllAsyncReturnsEmptyListIfEventDoesNotBelongToOrganization()
    {
        var actual = await _sut.GetAllAsync(MockedEventIds[1], InvalidOrganizationId, p => p.TicketOption);

        Assert.Empty(actual);
    }

    [Fact]
    public async Task TestThatGetAllAsyncWithProductIdsReturnsCorrectProducts()
    {
        var actual = (await _sut.GetAllAsync(new[] { Products[1].Id, Products[3].Id }, ValidOrganizationId, p => p.TicketOption)).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal(MockedEventIds[0], actual[0].EventId);
        Assert.Equal(MockedEventIds[0], actual[1].EventId);
    }

    [Fact]
    public async Task TestThatGetAllAsyncWithProductIdsReturnsEmptyListIfProductIdDoesNotBelongToOrganization()
    {
        var actual = await _sut.GetAllAsync(new[] { Products[0].Id, Products[1].Id }, InvalidOrganizationId, p => p.TicketOption);

        Assert.Empty(actual);
    }

    [Fact]
    public async Task TestThatGetAllAsyncWithProductIdsOnlyReturnsProductsThatBelongsToOrganization()
    {
        var actual = (await _sut.GetAllAsync(new[] { Products[2].Id, InvalidProductTypeProductId }, ValidOrganizationId, p => p.TicketOption)).ToList();

        Assert.Single(actual);
        Assert.Equal(MockedEventIds[0], actual[0].EventId);
    }

    [Theory]
    [MemberData(nameof(SalesReservationsTests))]
    public async Task TestThatHasSalesOrReservationReturnsExpectedResult(IEnumerable<Guid> ids, bool expected)
    {
        var actual = await _sut.HasSalesOrReservationsAsync(ids);

        Assert.Equal(expected, actual);
    }

    [Theory]
    [MemberData(nameof(SalesOrReservationTestData))]
    public async Task TestThatHasSalesOrReservationByEventReturnsExpectedResult(Guid eventId, bool expected)
    {
        var actual = await _sut.HasSalesOrReservationsAsync(eventId);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatLogPriceChangeInsertsNewProductPriceHistoryRecord()
    {
        await _sut.LogPriceChangeAsync(Products[0].Id, 4921, 100);

        _mockedContext.Verify(c => c.ProductPriceHistories.AddAsync(It.Is<ProductPriceHistory>(pph => pph.PriceCents == 4921 && pph.FeeCents == 100), default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAllExcludingAsyncGetsAllButGivenIds()
    {
        var actual = (await _sut.GetAllExcludingAsync(MockedEventIds[0], ValidOrganizationId, new List<Guid> { Products[0].Id })).ToList();

        Assert.Equal(3, actual.Count);
        Assert.Equal(Products[1].Id, actual[0].Id);
        Assert.Equal(Products[2].Id, actual[1].Id);
        Assert.Equal(Products[3].Id, actual[2].Id);
    }

    [Fact]
    public async Task TestThatEventProductSalesAsyncGetsEventProducts()
    {
        var productId1 = Guid.NewGuid();
        var productId2 = Guid.NewGuid();
        _mockedContext.Setup(c => c.Products)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Product>
            {
                new()
                {
                    Id = productId1,
                    EventId = MockedEventIds[0],
                    Name = "Unit product 1",
                    PriceCents = 100,
                    Stock = 5000,
                    ReservedProducts = new List<ReservedProduct>
                    {
                        new()
                        {
                            ProductId = productId1,
                            Quantity = 3,
                            ReservationReferenceNavigation = new()
                            {
                                ExpiresOn = DateTime.UtcNow.AddMinutes(5)
                            }
                        }
                    }
                },
                new()
                {
                    Id = productId2,
                    EventId = MockedEventIds[0],
                    Name = "Unit product 2",
                    PriceCents = 150,
                    Stock = 200,
                    ReservedProducts = new List<ReservedProduct>
                    {
                        new()
                        {
                            ProductId = productId2,
                            Quantity = 4,
                            ReservationReferenceNavigation = new()
                            {
                                ExpiresOn = DateTime.UtcNow.AddMinutes(4),
                                OrderReference = new()
                                {
                                    PaymentStatus = PaymentStatus.Authorised
                                }
                            }
                        }
                    }
                }
            });

        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Order>
            {
                new()
                {
                    ReservationReferenceNavigation = new()
                    {
                        ReservedProducts = new List<ReservedProduct>
                        {
                            new()
                            {
                                ProductId = productId2,
                                Quantity = 4,
                                ReservationReferenceNavigation = new()
                                {
                                    ExpiresOn = DateTime.UtcNow.AddMinutes(4),
                                    OrderReference = new()
                                    {
                                        PaymentStatus = PaymentStatus.Authorised
                                    }
                                }
                            }
                        }
                    }
                }
            });

        _mockedContext.Setup(c => c.IssuedProducts).ReturnsDbSet(new IssuedProduct[]
        {
            new()
            {
                Type = IssuedProductType.GuestTicket,
                DeductStock = true,
                ProductId = productId1
            },
            new()
            {
                Type = IssuedProductType.GuestTicket,
                DeductStock = true,
                ProductId = productId1
            },
            new()
            {
                Type = IssuedProductType.PlatformTicket,
                DeductStock = true,
                ProductId = productId1
            },
            new()
            {
                Type = IssuedProductType.GuestTicket,
                DeductStock = false,
                ProductId = productId1
            }
        });

        var actual = (await _sut.EventProductSalesAsync(MockedEventIds[0])).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal(3, actual[0].PendingReservationsAmount);
        Assert.Equal(4, actual[1].SoldAmount);
        Assert.Equal(2, actual[0].GuestAmount.DeductedAmount);
        Assert.Equal(1, actual[0].GuestAmount.NotDeductedAmount);
    }

    [Fact]
    public async Task TestThatTotalProductsSoldAsyncCountsAmountOfProductsSold()
    {
        var organizationId = Guid.NewGuid();
        _mockedContext.Setup(c => c.ReservedProducts)
            .ReturnsDbSet(new List<ReservedProduct>
            {
                new()
                {
                    Quantity = 2,
                    Product = new()
                    {
                        Event = new()
                        {
                            OrganizationId = organizationId
                        }
                    },
                    ReservationReferenceNavigation = new()
                    {
                        OrderReference = new()
                        {
                            PaymentStatus = PaymentStatus.Authorised
                        }
                    }
                },
                new()
                {
                    Quantity = 3,
                    Product = new()
                    {
                        Event = new()
                        {
                            OrganizationId = organizationId
                        }
                    },
                    ReservationReferenceNavigation = new()
                    {
                        OrderReference = new()
                        {
                            PaymentStatus = PaymentStatus.Authorised
                        }
                    }
                }
            });

        var actual = await _sut.TotalProductsSoldAsync(organizationId);

        Assert.Equal(5, actual);
    }

    [Fact]
    public async Task TestThatTotalProductsSoldAsyncForPlatformCountsAmountOfProductsSold()
    {
        _mockedContext.Setup(c => c.ReservedProducts)
            .ReturnsDbSet(new List<ReservedProduct>
            {
                new()
                {
                    Quantity = 2,
                    ReservationReferenceNavigation = new()
                    {
                        CreatedOn = DateTime.UtcNow.AddDays(-2),
                        OrderReference = new()
                        {
                            PaymentStatus = PaymentStatus.Authorised
                        }
                    },
                    Product = new()
                    {
                        Event = new()
                        {
                            Organization = new()
                            {
                                IsDemo = true,
                                CountryCode = "NL"
                            }
                        }
                    }
                },
                new()
                {
                    Quantity = 3,
                    ReservationReferenceNavigation = new()
                    {
                        CreatedOn = DateTime.UtcNow.AddDays(-1),
                        OrderReference = new()
                        {
                            PaymentStatus = PaymentStatus.Authorised
                        }
                    },
                    Product = new()
                    {
                        Event = new()
                        {
                            Organization = new()
                            {
                                IsDemo = false,
                                CountryCode = "NL"
                            }
                        }
                    }
                },
                new()
                {
                    Quantity = 3,
                    ReservationReferenceNavigation = new()
                    {
                        CreatedOn = DateTime.UtcNow.AddDays(-11),
                        OrderReference = new()
                        {
                            PaymentStatus = PaymentStatus.Authorised
                        }
                    },
                    Product = new()
                    {
                        Event = new()
                        {
                            Organization = new()
                            {
                                IsDemo = false,
                                CountryCode = "NL"
                            }
                        }
                    }
                }
            });

        var actual = await _sut.TotalProductsSoldAsync(DateTime.UtcNow.AddDays(-5), DateTime.UtcNow, new[] { "NL" });

        Assert.Equal(3, actual);
    }

    [Fact]
    public async Task TestThatEventProductsSoldCountsAmountOfSoldProducts()
    {
        var eventId = Guid.NewGuid();
        _mockedContext.Setup(c => c.ReservedProducts)
            .ReturnsDbSet(new List<ReservedProduct>
            {
                new()
                {
                    Quantity = 2,
                    Product = new()
                    {
                        EventId = eventId
                    },
                    ReservationReferenceNavigation = new()
                    {
                        OrderReference = new()
                        {
                            PaymentStatus = PaymentStatus.Authorised
                        }
                    }
                },
                new()
                {
                    Quantity = 6,
                    Product = new()
                    {
                        EventId = eventId
                    },
                    ReservationReferenceNavigation = new()
                    {
                        OrderReference = new()
                        {
                            PaymentStatus = PaymentStatus.Authorised
                        }
                    }
                }
            });

        var actual = await _sut.EventProductsSoldAsync(eventId);

        Assert.Equal(8, actual);
    }

    [Fact]
    public async Task TestThatProductShopsAsyncReturnsEventProductsWithShopInfo()
    {
        var actual = (await _sut.ProductShopsAsync(MockedEventIds[0], ValidOrganizationId)).ToList();

        Assert.NotNull(actual);
        Assert.NotEmpty(actual);
        Assert.Contains(actual, product => product.ItemInShops.Any(iis => iis.Shop.Name == "Test shop"));
        Assert.Contains(actual, product => product.ProductMedia.Any(pm => pm.File != null));
    }

    [Fact]
    public async Task TestThatTicketOptionsDesignIdInTicketIdAsyncReturnsTrueIfTicketOptionsDesignIdInTicketId()
    {
        var actual = await _sut.TicketOptionsDesignIdInTicketIdAsync(MockedEventIds[0], MockedProductIds);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatTicketOptionsDesignIdInTicketIdAsyncReturnsFalseIfTicketOptionsDesignIdInTicketId()
    {
        var actual = await _sut.TicketOptionsDesignIdInTicketIdAsync(MockedEventIds[1], MockedProductIds);

        Assert.False(actual);
    }
}