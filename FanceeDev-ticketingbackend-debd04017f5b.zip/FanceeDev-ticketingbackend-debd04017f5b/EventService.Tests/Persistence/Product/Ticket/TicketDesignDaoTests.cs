using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using EventService.Persistence.Product.Ticket;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Product.Ticket;

public class TicketDesignDaoTests
{
    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid[] FileIds = { Guid.NewGuid(), Guid.NewGuid() };

    public static readonly object[][] MediaBelongsToEventAsyncTestData =
    {
        new object[] { ValidEventId, FileIds[0], true },
        new object[] { ValidEventId, FileIds[1], false },
        new object[] { Guid.Empty, FileIds[0], false }
    };

    public static readonly object[][] MediaInUseAsyncTestData =
    {
        new object[] { FileIds[0], true },
        new object[] { FileIds[1], false }
    };

    private static readonly Guid[] DesignIds = { Guid.NewGuid() };
    private static readonly Guid[] ProductIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    private readonly TicketDesignDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public TicketDesignDaoTests()
    {
        var design = new TicketDesign
        {
            Id = DesignIds[0],
            DesignElements = new TicketDesignElement[]
            {
                new TicketDesignQrElement(),
                new TicketDesignUpcomingEventsElement(),
                new TicketDesignMediaElement()
            }
        };

        _mockedContext.Setup(c => c.TicketOptions).ReturnsDbSet(new TicketOption[]
        {
            new()
            {
                Product = new()
                {
                    EventId = ValidEventId,
                    Name = "Test Product #1"
                },
                ProductId = ProductIds[0],
                TicketDesignId = Guid.NewGuid(),
                Design = new() { DesignElements = Array.Empty<TicketDesignElement>() }
            },
            new()
            {
                Product = new()
                {
                    EventId = ValidEventId,
                    Name = "Test Product #2"
                },
                TicketDesignId = null,
                ProductId = ProductIds[1]
            },
            new()
            {
                Product = new()
                {
                    EventId = Guid.Empty,
                    Name = "Test Product #3"
                },
                ProductId = ProductIds[2],
                TicketDesignId = Guid.NewGuid(),
                Design = new() { DesignElements = Array.Empty<TicketDesignElement>() }
            },
            new()
            {
                Product = new()
                {
                    EventId = ValidEventId,
                    Name = "Test Product #4"
                },
                ProductId = ProductIds[3],
                TicketDesignId = DesignIds[0],
                Design = design
            },
            new()
            {
                Product = new()
                {
                    EventId = ValidEventId,
                    Name = "Test Product #5"
                },
                ProductId = ProductIds[4],
                TicketDesignId = DesignIds[0],
                Design = design
            }
        });

        _mockedContext.Setup(c => c.TicketDesignMedia).ReturnsDbSet(new TicketDesignMedia[]
        {
            new()
            {
                FileId = FileIds[0],
                EventId = ValidEventId
            },
            new()
            {
                FileId = FileIds[1],
                EventId = Guid.Empty
            }
        });

        _mockedContext.Setup(c => c.TicketDesignMediaElements).ReturnsDbSet(new TicketDesignMediaElement[]
        {
            new() { FileId = FileIds[0] }
        });

        _mockedContext.Setup(c => c.TicketDesignQrElements).ReturnsDbSet(Array.Empty<TicketDesignQrElement>());
        _mockedContext.Setup(c => c.TicketDesignElements).ReturnsDbSet(Array.Empty<TicketDesignElement>());
        _mockedContext.Setup(c => c.TicketDesigns).ReturnsDbSet(Array.Empty<TicketDesign>());

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsTicketDesign()
    {
        var actual = (await _sut.GetAsync(ValidEventId)).ToList();

        Assert.Single(actual);

        var (actualProductIds, actualTicketDesign) = actual[0];

        Assert.Equal(2, actualProductIds.Count());
        Assert.NotNull(actualTicketDesign);
    }

    [Fact]
    public async Task TestThatForTicketsAsyncReturnsTicketOptionsForTicketIds()
    {
        var actual = (await _sut.ForTicketsAsync(ValidEventId, new[] { ProductIds[0] })).ToList();

        Assert.Single(actual);
        Assert.Equal("Test Product #1", actual[0].Product.Name);
    }

    [Fact]
    public async Task TestThatUpdateRangeAsyncUpdatesTicketOptions()
    {
        var ticketOptions = new TicketOption[] { new(), new() };

        await _sut.UpdateRangeAsync(ticketOptions);

        _mockedContext.Verify(c => c.TicketOptions.UpdateRange(It.IsAny<IEnumerable<TicketOption>>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteDesignsAsyncRemovesDesign()
    {
        var ticketOptions = new TicketOption[]
        {
            new(),
            new() { Design = new() },
            new()
            {
                Design = new()
                {
                    DesignElements = new List<TicketDesignElement>
                    {
                        new TicketDesignQrElement()
                    }
                }
            }
        };

        await _sut.DeleteDesignsAsync(ticketOptions);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Exactly(2));
    }

    [Fact]
    public async Task TestThatInsertMediaAsyncInsertsNewMedia()
    {
        var media = new TicketDesignMedia();

        await _sut.InsertMediaAsync(media);

        _mockedContext.Verify(c => c.TicketDesignMedia.AddAsync(media, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Theory]
    [MemberData(nameof(MediaBelongsToEventAsyncTestData))]
    public async Task TestThatMediaBelongsToEventAsyncReturnsExpectedResult(Guid eventId, Guid fileId, bool expected)
    {
        var actual = await _sut.MediaBelongsToEventAsync(eventId, fileId);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatMediaByIdAsyncReturnsNullOnInvalidId()
    {
        var actual = await _sut.MediaByIdAsync(Guid.Empty, Guid.Empty);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatMediaByIdAsyncReturnsMedia()
    {
        var actual = await _sut.MediaByIdAsync(ValidEventId, FileIds[0]);

        Assert.NotNull(actual);
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncRemovesMedia()
    {
        var media = new TicketDesignMedia();

        await _sut.DeleteMediaAsync(media);

        _mockedContext.Verify(c => c.TicketDesignMedia.Remove(media), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaAsyncUpdatesMedia()
    {
        var media = new TicketDesignMedia();

        await _sut.UpdateMediaAsync(media);

        _mockedContext.Verify(c => c.TicketDesignMedia.Update(media), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Theory]
    [MemberData(nameof(MediaInUseAsyncTestData))]
    public async Task TestThatMediaInUseAsyncReturnsExceptedResult(Guid fileId, bool expected)
    {
        var actual = await _sut.MediaInUseAsync(fileId);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task InsertTicketDesignAsyncShouldCallInsertionMethods()
    {
        var ticketDesign = new TicketDesign();

        await _sut.InsertTicketDesignAsync(ticketDesign);

        _mockedContext.Verify(c => c.TicketDesigns.AddAsync(ticketDesign, It.IsAny<CancellationToken>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task InsertInsertMediaRangeAsyncShouldCallInsertionMethods()
    {
        IEnumerable<TicketDesignMedia> ticketDesign = new List<TicketDesignMedia>();

        await _sut.InsertMediaRangeAsync(ticketDesign);

        _mockedContext.Verify(c => c.TicketDesignMedia.AddRangeAsync(ticketDesign, It.IsAny<CancellationToken>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task CopyableTicketDesignsAsyncShouldReturnTicketDesign()
    {
        var id = Guid.NewGuid();
        var ticketDesign = new TicketDesign
        {
            Id = id,
            DesignElements = new List<TicketDesignElement>
            {
                new TicketDesignMediaElement
                {
                    Id = Guid.NewGuid()
                },
                new TicketDesignQrElement
                {
                    Id = Guid.NewGuid()
                }
            }
        };

        _mockedContext.Setup(c => c.TicketDesigns)
            .ReturnsDbSet(new List<TicketDesign> { ticketDesign });

        var actual = await _sut.CopyableTicketDesignsAsync(id);

        Assert.NotNull(actual);
    }
}