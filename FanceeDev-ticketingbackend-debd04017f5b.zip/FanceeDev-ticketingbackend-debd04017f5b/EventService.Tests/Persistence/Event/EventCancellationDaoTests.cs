using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Event;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Event;

public class EventCancellationDaoTests
{
    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationUserId = Guid.NewGuid();
    private static readonly Guid ValidEventCancellationId = Guid.NewGuid();
    private static readonly Guid UnCancellableEventId = Guid.NewGuid();

    private static readonly FanceeData.Models.Ticketing.Organization ValidOrganization = new()
    {
        Id = ValidOrganizationId,
        UserId = ValidOrganizationUserId,
        MailchimpKey = null,
        CustomTermFileId = null,
        ApproximatedAnnualSalesAmount = 0,
        DefaultReservationTimeMinutes = 0,
        Name = "Unit testing Co.",
        User = new()
        {
            Id = ValidOrganizationUserId,
            FanceeUsersId = null,
            Type = UserType.Organization,
            Email = "email",
            LastLogin = null,
            CreatedOn = default,
            DateOfBirth = null,
            AccountVerifyId = null,
            UserContactInfo = new()
            {
                UserId = ValidOrganizationUserId,
                FirstName = "Rick",
                LastName = "Woolschot"
            }
        }
    };

    private static readonly FanceeData.Models.Ticketing.Event ValidEvent = new()
    {
        Id = ValidEventId,
        OrganizationId = ValidOrganizationId,
        Name = "Event name",
        Type = EventType.Normal,
        StartDate = DateTime.UtcNow.AddYears(-1),
        EndDate = DateTime.UtcNow.AddYears(1),
        Status = EventStatus.Active,
        Organization = ValidOrganization
    };

    private static readonly EventCancellation ValidEventCancellation = new()
    {
        Id = ValidEventCancellationId,
        OrganizationId = ValidOrganizationId,
        EventId = ValidEventId,
        RequestedOn = DateTime.UtcNow,
        PreferredRefundOption = EventCancellationRefundOption.FullRefund,
        CancelReason = "Canceled because unit test",
        Organization = ValidOrganization,
        Event = ValidEvent
    };

    private static readonly List<FanceeData.Models.Ticketing.Event> Events = new()
    {
        new()
        {
            Id = UnCancellableEventId,
            Name = "UnCancellableEvent",
            StartDate = DateTime.UtcNow
        },
        new()
        {
            Id = ValidEventId,
            Name = "CancellableEvent",
            StartDate = DateTime.UtcNow.AddYears(1)
        }
    };

    private static readonly List<EventCancellation> EventCancellations = new()
    {
        ValidEventCancellation,
        new()
        {
            Id = Guid.NewGuid(),
            OrganizationId = ValidOrganizationId,
            EventId = UnCancellableEventId,
            RequestedOn = DateTime.UtcNow,
            PreferredRefundOption = EventCancellationRefundOption.FullRefund,
            CancelReason = "Canceled because unit test",
            Organization = ValidOrganization,
            Event = Events[0]
        }
    };

    private readonly EventCancellationDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public EventCancellationDaoTests()
    {
        _mockedContext.Setup(c => c.EventCancellations)
            .ReturnsDbSet(EventCancellations);

        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(Events);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAddAsyncCallsContextMethods()
    {
        var model = EventCancellations.First();

        await _sut.AddAsync(model);

        _mockedContext.Verify(c => c.EventCancellations, Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
    
    [Fact]
    public async Task TestThatGetAsyncReturnsEventCancellationWhenValidEventCancellationIsFound()
    {
        var actual = await _sut.GetAsync(ValidEventCancellationId);

        Assert.NotNull(actual);
        Assert.Equal(EventCancellations.First(), actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsNullWhenNoEventCancellationIsFound()
    {
        var actual = await _sut.GetAsync(Guid.NewGuid());

        Assert.Null(actual);
    }
}