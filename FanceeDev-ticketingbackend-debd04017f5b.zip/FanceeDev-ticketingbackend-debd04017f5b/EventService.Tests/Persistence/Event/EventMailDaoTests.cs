using System;
using System.Threading.Tasks;
using EventService.Persistence.Event;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Event;

public class EventMailDaoTests
{
    private static readonly Guid ValidEventId = Guid.NewGuid();

    private readonly EventMailDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public EventMailDaoTests()
    {
        _mockedContext.Setup(c => c.EventMails).ReturnsDbSet(new EventMail[]
        {
            new()
            {
                EventId = ValidEventId,
                Type = EventMailType.DefaultShopMail,
                SenderName = "Harry Organization",
                Content = "<h1>Content</h1>"
            }
        });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncAddsNewEventMail()
    {
        var eventMail = new EventMail
        {
            EventId = ValidEventId,
            Type = EventMailType.GuestList,
            SenderName = "Unit Tester",
            Content = "Mail content!"
        };

        await _sut.AddOrUpdateAsync(eventMail);

        _mockedContext.Verify(c => c.EventMails.AddAsync(eventMail, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
        _mockedContext.Verify(c => c.EventMails.Update(It.IsAny<EventMail>()), Times.Never);
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncUpdatesEventMail()
    {
        var eventMail = new EventMail
        {
            EventId = ValidEventId,
            Type = EventMailType.DefaultShopMail,
            SenderName = "Harry The Organization",
            Content = "New content"
        };

        await _sut.AddOrUpdateAsync(eventMail);

        _mockedContext.Verify(c => c.EventMails.Update(eventMail), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
        _mockedContext.Verify(c => c.EventMails.AddAsync(It.IsAny<EventMail>(), default), Times.Never);
    }

    [Fact]
    public async Task TestThatRetrievingUnknownEventMailReturnsNull()
    {
        var actual = await _sut.GetAsync(Guid.NewGuid(), EventMailType.DefaultShopMail);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsEventMail()
    {
        var actual = await _sut.GetAsync(ValidEventId, EventMailType.DefaultShopMail);

        Assert.NotNull(actual);
        Assert.Equal("<h1>Content</h1>", actual.Content);
    }
}