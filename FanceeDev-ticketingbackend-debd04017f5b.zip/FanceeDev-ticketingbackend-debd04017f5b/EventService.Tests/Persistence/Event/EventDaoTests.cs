﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Event;
using EventService.Persistence.Shop;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Contract;

namespace EventService.Tests.Persistence.Event;

[TestSubject(typeof(EventDao))]
public class EventDaoTests
{
    private static readonly Guid[] OrganizationIds = [Guid.NewGuid(), Guid.NewGuid()];

    public static readonly object[][] ListByOrganizationTestData =
    [
        [OrganizationIds[0], 4],
        [OrganizationIds[1], 4]
    ];

    private static readonly Guid[] MockedEventIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];

    public static readonly object[][] GetInvalidEventTestData =
    [
        [Guid.NewGuid(), OrganizationIds[0]],
        [MockedEventIds[1], Guid.NewGuid()]
    ];

    private static readonly Guid ValidProductId = Guid.NewGuid();
    private static readonly Guid ValidEventId = Guid.NewGuid();

    private static readonly Guid ActiveShopOrganizationId = Guid.NewGuid();
    private static readonly Guid AppTeamId = Guid.NewGuid();
    private static readonly Guid FileId = Guid.NewGuid();
    private static readonly Guid AddressId = Guid.NewGuid();

    private static readonly Guid RevenueEventId = Guid.NewGuid();
    private static readonly Guid RevenueOrganizationId = Guid.NewGuid();

    private static readonly HostedDeploymentEnvironment HostedDeploymentEnvironment = new()
    {
        Id = Guid.NewGuid(),
        Name = "UnitTestEnv",
        Domain = "localhost",
        IsHttps = false
    };

    private static readonly FanceeData.Models.Ticketing.Organization Organization1 = new()
    {
        Id = OrganizationIds[0],
        Name = "UnitTest B.V.",
        User = new()
        {
            UserMedia = new()
            {
                File = new()
                {
                    Id = FileId,
                    Name = "IdentifiedItemDto"
                }
            },
            UserContactInfo = new()
            {
                FirstName = "Unit",
                LastName = "Tester",
                AddressId = Guid.NewGuid(),
                PhoneNumber = "0612345678"
            }
        },
        CountryCode = "NL"
    };

    private static readonly FanceeData.Models.Ticketing.Organization Organization2 = new()
    {
        Id = OrganizationIds[1],
        Name = "UnitTest Inc.",
        User = new()
        {
            UserMedia = new(),
            UserContactInfo = new()
            {
                FirstName = "Unitta",
                LastName = "Testeroni",
                AddressId = Guid.NewGuid(),
                PhoneNumber = "0687654321"
            }
        },
        CountryCode = "NL"
    };

    private static readonly ShopFieldRequirement ShopFieldRequirement = new()
    {
        Code = "kf9i20",
        Field = ShopField.Email,
        Required = true,
        Enabled = true
    };

    private static readonly List<ContractFee> ContractFees =
    [
        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-60),
            PeriodEnd = DateTime.UtcNow.AddDays(-40),
            ProductFeeCents = 83,
            ProductFeePercentage = 1,
            TicketFeeCents = 83,
            TicketFeePercentage = 1,
            SeatedTicketFeeCents = 150,
            SeatedTicketFeePercentage = 1,
            GuestListFeeCents = 20
        },

        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-39),
            PeriodEnd = DateTime.UtcNow.AddDays(-20),
            ProductFeeCents = 83,
            ProductFeePercentage = 1,
            TicketFeeCents = 83,
            TicketFeePercentage = 2,
            SeatedTicketFeeCents = 150,
            SeatedTicketFeePercentage = 2,
            GuestListFeeCents = 20
        }
    ];

    private static readonly Guid[] ValidEventIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid[] ValidOrganizationIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid[] ValidProductIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid[] ValidOrderIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];
    private static readonly Guid[] ValidReservedProductIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];

    private static readonly List<MappedOrganizationContractFee> MappedOrganizationContractFee =
    [
        new()
        {
            PeriodStart = DateTime.UtcNow.AddYears(-2),
            PeriodEnd = DateTime.UtcNow.AddDays(-30),
            ProductFeeCents = 100,
            ProductFeePercentage = 1,
            TicketFeeCents = 100,
            TicketFeePercentage = 1,
            SeatedTicketFeeCents = 150,
            SeatedTicketFeePercentage = 1,
            GuestListFeeCents = 100,
            OrganizationId = ValidOrganizationIds[0]
        },

        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-30),
            PeriodEnd = DateTime.UtcNow.AddYears(2),
            ProductFeeCents = 150,
            ProductFeePercentage = 2,
            TicketFeeCents = 150,
            TicketFeePercentage = 2,
            SeatedTicketFeeCents = 200,
            SeatedTicketFeePercentage = 4,
            GuestListFeeCents = 150,
            OrganizationId = ValidOrganizationIds[0]
        }
    ];

    private static readonly Guid[] ValidClientIds = [Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid()];

    private static readonly List<FanceeData.Models.Ticketing.Event> Events =
    [
        new()
        {
            Id = ValidEventIds[0],
            OrganizationId = ValidOrganizationIds[0],
            Name = "BalanceEventCalculation1",
            Type = EventType.Normal,
            Status = EventStatus.Active,
            StartDate = DateTime.UtcNow.AddMonths(-6),
            Organization = new()
            {
                Id = ValidOrganizationIds[0],
                CountryCode = CountryCode.NL.ToString(),
                User = new()
                {
                    Email = "unit@test.nl"
                }
            },
            Products = new List<FanceeData.Models.Ticketing.Product>
            {
                new()
                {
                    Id = ValidProductIds[0],
                    EventId = ValidEventIds[0],
                    Stock = 0,
                    PriceCents = 1000,
                    FeeCents = 100,
                    Type = ProductType.Ticket,
                    IssuedProducts = new List<IssuedProduct>
                    {
                        new()
                        {
                            Product = new()
                            {
                                Type = ProductType.Ticket
                            },
                            Id = Guid.NewGuid(),
                            ReservedProductId = ValidReservedProductIds[0],
                            ProductId = ValidProductIds[0],
                            OrderId = ValidOrderIds[0],
                            Type = IssuedProductType.HardcopyTicket,
                            CreatedOn = DateTime.UtcNow.AddMonths(-6),
                            ReservedProduct = new()
                            {
                                Id = ValidReservedProductIds[0],
                                ReservationReference = default,
                                ProductId = ValidProductIds[0],
                                Quantity = 5
                            },
                            Order = new()
                            {
                                Id = ValidOrderIds[0],
                                CreatedAt = DateTime.UtcNow.AddDays(-1),
                                TotalCostCents = 5500,
                                PaymentFeeCents = 150,
                                PaymentFeePaidBy = PaidBy.Organization,
                                PaymentStatus = PaymentStatus.Authorised,
                                ClientOrder = new()
                                {
                                    OrderId = ValidOrderIds[0],
                                    ClientId = ValidClientIds[0],
                                    TicketServicePlusCostCents = 1000
                                }
                            },
                            IssuedTicket = new()
                            {
                                Code = Guid.NewGuid().ToString(),
                                State = TicketState.Active,
                                TicketScans = new List<TicketScan>
                                {
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Scanned
                                    }
                                }
                            }
                        }
                    }
                },
                new()
                {
                    Id = ValidProductIds[1],
                    EventId = ValidEventIds[0],
                    Stock = 0,
                    PriceCents = 1500,
                    FeeCents = 100,
                    Type = ProductType.Ticket,
                    IssuedProducts = new List<IssuedProduct>
                    {
                        new()
                        {
                            Product = new()
                            {
                                Type = ProductType.Ticket
                            },
                            Id = Guid.NewGuid(),
                            ReservedProductId = ValidReservedProductIds[0],
                            ProductId = ValidProductIds[1],
                            OrderId = ValidOrderIds[0],
                            Type = IssuedProductType.HardcopyTicket,
                            CreatedOn = DateTime.UtcNow.AddMonths(-6),
                            ReservedProduct = new()
                            {
                                Id = ValidReservedProductIds[0],
                                ReservationReference = default,
                                ProductId = ValidProductIds[1],
                                Quantity = 10
                            },
                            Order = new()
                            {
                                Id = ValidOrderIds[0],
                                CreatedAt = DateTime.UtcNow.AddDays(-11),
                                TotalCostCents = 16000,
                                PaymentFeeCents = 150,
                                PaymentFeePaidBy = PaidBy.Organization,
                                PaymentStatus = PaymentStatus.Authorised,
                                ClientOrder = new()
                                {
                                    OrderId = ValidOrderIds[0],
                                    ClientId = ValidClientIds[0],
                                    TicketServicePlusCostCents = 1000
                                }
                            },
                            IssuedTicket = new()
                            {
                                Code = Guid.NewGuid().ToString(),
                                State = TicketState.Active,
                                TicketScans = new List<TicketScan>
                                {
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Scanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Unscanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Scanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Unscanned
                                    }
                                }
                            }
                        },
                        new()
                        {
                            Product = new()
                            {
                                Type = ProductType.Ticket
                            },
                            Id = Guid.NewGuid(),
                            ReservedProductId = ValidReservedProductIds[1],
                            ProductId = ValidProductIds[1],
                            OrderId = ValidOrderIds[1],
                            Type = IssuedProductType.PlatformProduct,
                            CreatedOn = DateTime.UtcNow.AddMonths(-6),
                            ReservedProduct = new()
                            {
                                Id = ValidReservedProductIds[1],
                                ReservationReference = default,
                                ProductId = ValidProductIds[1],
                                Quantity = 1
                            },
                            Order = new()
                            {
                                Id = ValidOrderIds[1],
                                CreatedAt = DateTime.UtcNow.AddDays(-44),
                                TotalCostCents = 1600,
                                PaymentFeeCents = 150,
                                PaymentFeePaidBy = PaidBy.Organization,
                                PaymentStatus = PaymentStatus.Authorised,
                                ClientOrder = new()
                                {
                                    OrderId = ValidOrderIds[1],
                                    ClientId = ValidClientIds[1],
                                    TicketServicePlusCostCents = 1000
                                }
                            },
                            IssuedTicket = new()
                            {
                                Code = Guid.NewGuid().ToString(),
                                State = TicketState.Active,
                                TicketScans = new List<TicketScan>
                                {
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Scanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Unscanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Scanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Unscanned
                                    }
                                }
                            }
                        },
                        new()
                        {
                            Product = new()
                            {
                                Type = ProductType.Ticket
                            },
                            Id = Guid.NewGuid(),
                            ProductId = ValidProductIds[1],
                            Type = IssuedProductType.GuestTicket,
                            CreatedOn = DateTime.UtcNow.AddMonths(-6),
                            IssuedTicket = new()
                            {
                                Code = Guid.NewGuid().ToString(),
                                State = TicketState.Active
                            }
                        }
                    }
                },
                new()
                {
                    Id = ValidProductIds[2],
                    EventId = ValidEventIds[0],
                    Stock = 10,
                    PriceCents = 8500,
                    FeeCents = 150,
                    Type = ProductType.SeatedTicket,
                    IssuedProducts = new List<IssuedProduct>
                    {
                        new()
                        {
                            Product = new()
                            {
                                Type = ProductType.SeatedTicket
                            },
                            Id = Guid.NewGuid(),
                            ReservedProductId = ValidReservedProductIds[3],
                            ProductId = ValidProductIds[2],
                            OrderId = ValidOrderIds[0],
                            Type = IssuedProductType.PlatformTicket,
                            CreatedOn = DateTime.UtcNow.AddMonths(-1),
                            ReservedProduct = new()
                            {
                                Id = ValidReservedProductIds[3],
                                ReservationReference = default,
                                ProductId = ValidProductIds[2],
                                Quantity = 2
                            },
                            Order = new()
                            {
                                Id = ValidOrderIds[0],
                                CreatedAt = DateTime.UtcNow.AddDays(-6),
                                TotalCostCents = 17000,
                                PaymentFeeCents = 50,
                                PaymentFeePaidBy = PaidBy.Organization,
                                PaymentStatus = PaymentStatus.Authorised,
                                ClientOrder = new()
                                {
                                    OrderId = ValidOrderIds[0],
                                    ClientId = ValidClientIds[0],
                                    TicketServicePlusCostCents = 1000
                                }
                            },
                            IssuedTicket = new()
                            {
                                Code = Guid.NewGuid().ToString(),
                                State = TicketState.Active,
                                TicketScans = new List<TicketScan>
                                {
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Scanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Unscanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Scanned
                                    },
                                    new()
                                    {
                                        Id = Guid.NewGuid(),
                                        State = ScanState.Unscanned
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },

        new()
        {
            Id = ValidEventIds[1],
            OrganizationId = ValidOrganizationIds[0],
            Name = "BalanceEventCalculation2",
            Type = EventType.Normal,
            StartDate = DateTime.UtcNow.AddMonths(2),
            EndDate = DateTime.UtcNow.AddMonths(2).AddDays(2),
            Status = EventStatus.Cancelled,
            Organization = new()
            {
                Id = ValidOrganizationIds[0],
                CountryCode = CountryCode.NL.ToString(),
                User = new()
                {
                    Email = "unit@test.nl"
                }
            },
            Products = new List<FanceeData.Models.Ticketing.Product>
            {
                new()
                {
                    Id = ValidProductIds[2],
                    EventId = ValidEventIds[1],
                    PriceCents = 100,
                    FeeCents = 10,
                    Type = ProductType.Ticket,
                    IssuedProducts = new List<IssuedProduct>
                    {
                        new()
                        {
                            Product = new()
                            {
                                Type = ProductType.Ticket
                            },
                            Id = Guid.NewGuid(),
                            ReservedProductId = ValidReservedProductIds[2],
                            ProductId = ValidProductIds[2],
                            OrderId = ValidOrderIds[2],
                            Type = IssuedProductType.HardcopyTicket,
                            CreatedOn = DateTime.Now.AddYears(-1),
                            ReservedProduct = new()
                            {
                                Id = ValidReservedProductIds[2],
                                ProductId = ValidProductIds[2],
                                Quantity = 10
                            },
                            Order = new()
                            {
                                Id = ValidOrderIds[2],
                                PaymentStatus = PaymentStatus.Authorised,
                                TotalCostCents = 1600,
                                PaymentFeeCents = 50,
                                PaymentFeePaidBy = PaidBy.Client,
                                ClientOrder = new()
                                {
                                    OrderId = ValidOrderIds[2],
                                    ClientId = ValidClientIds[2],
                                    TicketServicePlusCostCents = 1000
                                }
                            },
                            IssuedTicket = new()
                            {
                                TicketScans = new List<TicketScan>
                                {
                                    new()
                                    {
                                        State = ScanState.Scanned
                                    }
                                }
                            }
                        }
                    }
                },
                new()
                {
                    Id = ValidProductIds[2],
                    EventId = ValidEventIds[1],
                    PriceCents = 100,
                    FeeCents = 10,
                    Type = ProductType.Ticket,
                    IssuedProducts = new List<IssuedProduct>
                    {
                        new()
                        {
                            Product = new()
                            {
                                Type = ProductType.Ticket
                            },
                            Id = Guid.NewGuid(),
                            ReservedProductId = ValidReservedProductIds[2],
                            ProductId = ValidProductIds[2],
                            OrderId = ValidOrderIds[2],
                            Type = IssuedProductType.HardcopyTicket,
                            CreatedOn = DateTime.Now.AddYears(-1),
                            ReservedProduct = new()
                            {
                                Id = ValidReservedProductIds[2],
                                ProductId = ValidProductIds[2],
                                Quantity = 20
                            },
                            Order = new()
                            {
                                Id = ValidOrderIds[2],
                                PaymentStatus = PaymentStatus.Authorised,
                                TotalCostCents = 3200,
                                PaymentFeeCents = 50,
                                PaymentFeePaidBy = PaidBy.Client,
                                ClientOrder = new()
                                {
                                    OrderId = ValidOrderIds[2],
                                    ClientId = ValidClientIds[2],
                                    TicketServicePlusCostCents = 1000
                                }
                            },
                            IssuedTicket = new()
                            {
                                TicketScans = new List<TicketScan>
                                {
                                    new()
                                    {
                                        State = ScanState.Scanned
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },

        new()
        {
            Id = ValidEventIds[2],
            OrganizationId = ValidOrganizationIds[0],
            Name = "BalanceEventCalculation2",
            Type = EventType.Normal,
            StartDate = DateTime.UtcNow.AddMonths(2),
            EndDate = DateTime.UtcNow.AddMonths(2).AddDays(2),
            Status = EventStatus.Active,
            Organization = new()
            {
                Id = ValidOrganizationIds[0],
                CountryCode = CountryCode.NL.ToString(),
                User = new()
                {
                    Email = "unit@test.nl"
                }
            },
            Products = new List<FanceeData.Models.Ticketing.Product>()
        }
    ];

    private static readonly Guid PlatformExpensesEventId = Guid.NewGuid();

    private static readonly Guid[] PlatformExpensesOrderIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    private static readonly IList<FanceeData.Models.Ticketing.Order> PlatformExpensesOrders = new List<FanceeData.Models.Ticketing.Order>
    {
        new()
        {
            Id = PlatformExpensesOrderIds[0],
            PaymentStatus = PaymentStatus.Authorised,
            TotalCostCents = 1000,
            PaymentFeeCents = 1500,
            PaymentFeePaidBy = PaidBy.Organization,
            CreatedAt = DateTime.UtcNow.AddDays(-21),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        ReservationReferenceNavigation = new()
                        {
                            OrderReference = new()
                            {
                                CreatedAt = DateTime.UtcNow.AddDays(-21)
                            }
                        },
                        Quantity = 2,
                        Product = new()
                        {
                            PriceCents = 1000,
                            FeeCents = null,
                            PackQuantity = 1,
                            EventId = PlatformExpensesEventId,
                            Event = new()
                            {
                                Id = PlatformExpensesEventId,
                                Organization = new()
                                {
                                    Id = default,
                                    Contract = new()
                                    {
                                        ProductFeeCents = 10,
                                        TicketFeeCents = 10,
                                        GuestListFeeCents = 10,
                                        Signed = true
                                    }
                                }
                            },
                            Type = ProductType.Ticket,
                            PriceHistories = new List<ProductPriceHistory>()
                        }
                    }
                }
            },
            PaymentMethod = new()
            {
                Id = default,
                Name = "paypal",
                Provider = PaymentProvider.Adyen,
                BrandCode = "paypal"
            }
        },
        new()
        {
            Id = PlatformExpensesOrderIds[1],
            PaymentStatus = PaymentStatus.Authorised,
            TotalCostCents = 1000,
            PaymentFeeCents = 3400,
            PaymentFeePaidBy = PaidBy.Organization,
            CreatedAt = DateTime.UtcNow.AddDays(-23),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        ReservationReferenceNavigation = new()
                        {
                            OrderReference = new()
                            {
                                CreatedAt = DateTime.UtcNow.AddDays(-23)
                            }
                        },
                        Quantity = 1,
                        Product = new()
                        {
                            PriceCents = 1500,
                            FeeCents = null,
                            PackQuantity = 1,
                            EventId = PlatformExpensesEventId,
                            Event = new()
                            {
                                Id = PlatformExpensesEventId,
                                Organization = new()
                                {
                                    Id = default,
                                    Contract = new()
                                    {
                                        ProductFeeCents = 120,
                                        TicketFeeCents = 140,
                                        GuestListFeeCents = 10,
                                        Signed = true
                                    }
                                }
                            },
                            Type = ProductType.Ticket,
                            PriceHistories = new List<ProductPriceHistory>()
                        }
                    }
                }
            },
            PaymentMethod = new()
            {
                Id = default,
                Name = "paypal",
                Provider = PaymentProvider.Adyen,
                BrandCode = "paypal"
            }
        },
        new()
        {
            Id = PlatformExpensesOrderIds[2],
            PaymentStatus = PaymentStatus.Authorised,
            TotalCostCents = 2000,
            PaymentFeeCents = 50,
            PaymentFeePaidBy = PaidBy.Organization,
            CreatedAt = DateTime.UtcNow.AddDays(-19),
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        ReservationReferenceNavigation = new()
                        {
                            OrderReference = new()
                            {
                                CreatedAt = DateTime.UtcNow.AddDays(-21)
                            }
                        },
                        Quantity = 2,
                        Product = new()
                        {
                            PriceCents = 555,
                            FeeCents = null,
                            PackQuantity = 1,
                            EventId = PlatformExpensesEventId,
                            Event = new()
                            {
                                Id = PlatformExpensesEventId,
                                Organization = new()
                                {
                                    Id = default,
                                    Contract = new()
                                    {
                                        ProductFeeCents = 10,
                                        ProductFeePercentage = 1,
                                        TicketFeeCents = 10,
                                        TicketFeePercentage = 1,
                                        GuestListFeeCents = 10,
                                        Signed = true
                                    }
                                }
                            },
                            Type = ProductType.Product,
                            PriceHistories = new List<ProductPriceHistory>()
                        }
                    }
                }
            },
            PaymentMethod = new()
            {
                Id = default,
                Name = "paypal",
                Provider = PaymentProvider.Adyen,
                BrandCode = "paypal"
            }
        }
    };

    private static readonly IList<ReservedProduct> PlatformExpensesReservedProduct = new List<ReservedProduct>
    {
        new()
        {
            Id = default,
            ReservationReference = default,
            ProductId = default,
            Quantity = 5,
            ShopCode = null,
            ReservationReferenceNavigation = new()
            {
                OrderReference = PlatformExpensesOrders[0]
            },
            Product = new()
            {
                EventId = PlatformExpensesEventId,
                Type = ProductType.Ticket,
                Event = new()
                {
                    Id = PlatformExpensesEventId,
                    Organization = new()
                    {
                        Id = default,
                        Contract = new()
                        {
                            ProductFeeCents = 10,
                            TicketFeeCents = 10,
                            GuestListFeeCents = 10,
                            Signed = true
                        }
                    }
                }
            },
            Shop = null,
            IssuedProducts = new List<IssuedProduct>()
        },
        new()
        {
            Id = default,
            ReservationReference = default,
            ProductId = default,
            Quantity = 3,
            ShopCode = null,
            ReservationReferenceNavigation = new()
            {
                OrderReference = PlatformExpensesOrders[1]
            },
            Product = new()
            {
                EventId = PlatformExpensesEventId,
                Type = ProductType.Ticket,
                Event = new()
                {
                    Id = PlatformExpensesEventId,
                    Organization = new()
                    {
                        Id = default,
                        Contract = new()
                        {
                            ProductFeeCents = 120,
                            TicketFeeCents = 140,
                            GuestListFeeCents = 10,
                            Signed = true
                        }
                    }
                }
            },
            Shop = null,
            IssuedProducts = new List<IssuedProduct>()
        }
    };

    private readonly EventDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly Mock<IShopDao> _mockedShopDao = new();

    private readonly HostedDeploymentEnvironment _deploymentEnvironment = new()
    {
        Id = Guid.NewGuid(),
        Name = "UnitTestEnv",
        Domain = "localhost",
        IsHttps = false
    };

    private readonly FanceeData.Models.Ticketing.Event _activeShopEvent = new()
    {
        Id = Guid.NewGuid(),
        OrganizationId = ActiveShopOrganizationId,
        Name = "UnitName",
        Organization = new()
        {
            Name = "Organization BV",
            User = new()
            {
                UserMedia = new()
                {
                    File = new()
                    {
                        Path = "filepath"
                    }
                },
                UserContactInfo = new()
                {
                    FirstName = "First",
                    LastName = "Last"
                }
            }
        },
        StartDate = DateTime.UtcNow.AddHours(1),
        EndDate = DateTime.UtcNow.AddHours(10),
        Status = EventStatus.Active,
        Type = EventType.Normal,
        Products = new List<FanceeData.Models.Ticketing.Product>
        {
            new()
            {
                Name = "Product1",
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                }
            }
        },
        PaymentMethods = new List<EventPaymentMethod>
        {
            new()
        },
        Shops = new List<FanceeData.Models.Ticketing.Shop>
        {
            new()
            {
                Code = "SHOPCODE12345",
                Name = "ActiveShopName",
                Active = true,
                EndDate = DateTime.UtcNow.AddHours(10),
                ShopDesign = new()
                {
                    HeaderMedia = Array.Empty<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>()
                },
                ItemsInShop = new List<ItemInShop>
                {
                    new()
                }
            }
        }
    };

    private readonly FanceeData.Models.Ticketing.Event _event = new()
    {
        Id = ValidEventId,
        Name = "UnitTestEventInsert",
        Description = "Event for unittesting",
        StartDate = DateTime.UtcNow.AddDays(-5),
        EndDate = DateTime.UtcNow.AddDays(5),
        OrganizationId = OrganizationIds[0],
        Organization = Organization1,
        Type = EventType.Normal,
        Status = EventStatus.Active,
        Address = new()
        {
            City = "Unitcity"
        },
        Categories = new List<EventCategory>
        {
            new()
            {
                Name = "Unitcategory"
            }
        },
        Products = new List<FanceeData.Models.Ticketing.Product>
        {
            new()
            {
                Id = ValidProductId,
                EventId = ValidEventId,
                Name = "productName"
            }
        },
        Shops = new List<FanceeData.Models.Ticketing.Shop>
        {
            new()
            {
                Code = "AUnitShopCode",
                Name = "UnitShop",
                Active = true,
                EndDate = DateTime.UtcNow.AddDays(5),
                ItemsInShop = new List<ItemInShop>
                {
                    new()
                    {
                        Id = Guid.NewGuid(),
                        ProductId = ValidProductId
                    }
                }
            }
        },
        PaymentMethods = new List<EventPaymentMethod>
        {
            new()
            {
                PaymentMethod = new()
                {
                    Name = "UnitPaymentMethod"
                }
            }
        }
    };

    private readonly FanceeData.Models.Ticketing.Shop _appTeamAssignedShop = new()
    {
        Code = "UnitShopCode",
        Name = "UnitShopName",
        EventId = MockedEventIds[0],
        ShopDesign = new()
        {
            HeaderMedia = Array.Empty<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>()
        }
    };

    private readonly List<FanceeData.Models.Ticketing.Order> _revenueOrders =
    [
        new()
        {
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = RevenueEventId,
                            Event = new()
                            {
                                OrganizationId = RevenueOrganizationId
                            }
                        }
                    }
                }
            },
            PaymentStatus = PaymentStatus.Authorised,
            TotalCostCents = 1000,
            PaymentMethod = new()
            {
                BrandCode = "ideal"
            }
        },

        new()
        {
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = RevenueEventId,
                            Event = new()
                            {
                                OrganizationId = RevenueOrganizationId
                            }
                        }
                    }
                }
            },
            PaymentStatus = PaymentStatus.Authorised,
            TotalCostCents = 1000,
            PaymentMethod = new()
            {
                BrandCode = "paypal"
            }
        },

        new()
        {
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = RevenueEventId,
                            Event = new()
                            {
                                OrganizationId = RevenueOrganizationId
                            }
                        }
                    }
                }
            },
            PaymentStatus = PaymentStatus.Authorised,
            TotalCostCents = 1000,
            PaymentMethod = new()
            {
                BrandCode = "cash"
            }
        },

        new()
        {
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = RevenueEventId,
                            Event = new()
                            {
                                OrganizationId = RevenueOrganizationId
                            }
                        }
                    }
                }
            },
            PaymentStatus = PaymentStatus.Error,
            TotalCostCents = 1000,
            PaymentMethod = new()
            {
                BrandCode = "paypal"
            }
        },

        new()
        {
            ReservationReferenceNavigation = new()
            {
                ReservedProducts = new List<ReservedProduct>
                {
                    new()
                    {
                        Product = new()
                        {
                            EventId = Guid.NewGuid(),
                            Event = new()
                            {
                                OrganizationId = RevenueOrganizationId
                            }
                        }
                    }
                }
            },
            PaymentStatus = PaymentStatus.Authorised,
            TotalCostCents = 1000,
            PaymentMethod = new()
            {
                BrandCode = "paypal"
            }
        }
    ];

    private readonly List<IssuedProduct> _issuedProducts =
    [
        new()
        {
            CreatedOn = DateTime.Now.AddDays(-50),
            Type = IssuedProductType.GuestTicket,
            Origin = IssuedProductOrigin.PlatformGuestList,
            Product = new()
            {
                Event = new()
                {
                    OrganizationId = RevenueOrganizationId
                }
            }
        }
    ];

    private readonly List<ReservedProduct> _revenueReservedProducts =
    [
        new()
        {
            Product = new()
            {
                EventId = RevenueEventId,
                Event = new()
                {
                    Name = "first",
                    OrganizationId = RevenueOrganizationId,
                    Organization = new()
                    {
                        Contract = new()
                        {
                            Start = DateTime.UtcNow.AddDays(-1),
                            End = DateTime.UtcNow.AddDays(+1),
                            ProductFeeCents = 83,
                            TicketFeeCents = 83
                        }
                    }
                },
                Type = ProductType.Product
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    CreatedAt = DateTime.UtcNow.AddDays(-30),
                    PaymentStatus = PaymentStatus.Authorised,
                    TotalCostCents = 1000,
                    PaymentFeeCents = 50
                }
            },
            Quantity = 3,
            IssuedProducts = new List<IssuedProduct>()
        },

        new()
        {
            Product = new()
            {
                EventId = RevenueEventId,
                Event = new()
                {
                    Name = "2nd",
                    OrganizationId = RevenueOrganizationId,
                    Organization = new()
                    {
                        Contract = new()
                        {
                            Start = DateTime.UtcNow.AddDays(-1),
                            End = DateTime.UtcNow.AddDays(+1),
                            ProductFeeCents = 83,
                            TicketFeeCents = 83
                        }
                    }
                },
                Type = ProductType.Product
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    CreatedAt = DateTime.UtcNow.AddDays(-30),
                    PaymentStatus = PaymentStatus.Authorised,
                    TotalCostCents = 1000,
                    PaymentFeeCents = 50
                }
            },
            Quantity = 3,
            IssuedProducts = new List<IssuedProduct>()
        },

        new()
        {
            Product = new()
            {
                EventId = RevenueEventId,
                Event = new()
                {
                    Name = "third",
                    OrganizationId = RevenueOrganizationId,
                    Organization = new()
                    {
                        Contract = new()
                        {
                            Start = DateTime.UtcNow.AddDays(-1),
                            End = DateTime.UtcNow.AddDays(+1),
                            ProductFeeCents = 83,
                            TicketFeeCents = 83
                        }
                    }
                },
                Type = ProductType.Product
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    CreatedAt = DateTime.UtcNow,
                    PaymentStatus = PaymentStatus.Authorised,
                    TotalCostCents = 1000,
                    PaymentFeeCents = 50
                }
            },
            Quantity = 3,
            IssuedProducts = new List<IssuedProduct>()
        },

        new()
        {
            Product = new()
            {
                EventId = RevenueEventId,
                Event = new()
                {
                    Name = "4th",
                    OrganizationId = RevenueOrganizationId,
                    Organization = new()
                    {
                        Contract = new()
                        {
                            Start = DateTime.UtcNow.AddDays(-1),
                            End = DateTime.UtcNow.AddDays(+1),
                            ProductFeeCents = 83,
                            TicketFeeCents = 83
                        }
                    }
                },
                Type = ProductType.Product
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    CreatedAt = DateTime.UtcNow.AddDays(-50),
                    PaymentStatus = PaymentStatus.Authorised,
                    TotalCostCents = 1000,
                    PaymentFeeCents = 50
                }
            },
            Quantity = 3,
            IssuedProducts = new List<IssuedProduct>()
        },

        new()
        {
            Product = new()
            {
                EventId = RevenueEventId,
                Event = new()
                {
                    Name = "5th",
                    OrganizationId = RevenueOrganizationId,
                    Organization = new()
                    {
                        Contract = new()
                        {
                            Start = DateTime.UtcNow.AddDays(-1),
                            End = DateTime.UtcNow.AddDays(+1),
                            ProductFeeCents = 83,
                            TicketFeeCents = 83
                        }
                    }
                },
                Type = ProductType.Ticket
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    CreatedAt = DateTime.UtcNow.AddDays(-50),
                    PaymentStatus = PaymentStatus.Authorised,
                    TotalCostCents = 1000,
                    PaymentFeeCents = 50
                }
            },
            Quantity = 3,
            IssuedProducts = new List<IssuedProduct>()
        },

        new()
        {
            Product = new()
            {
                EventId = RevenueEventId,
                Event = new()
                {
                    Name = "six",
                    OrganizationId = RevenueOrganizationId,
                    Organization = new()
                    {
                        Contract = new()
                        {
                            Start = DateTime.UtcNow.AddDays(-1),
                            End = DateTime.UtcNow.AddDays(+1),
                            ProductFeeCents = 83,
                            TicketFeeCents = 83
                        }
                    }
                },
                Type = ProductType.Ticket
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    CreatedAt = DateTime.UtcNow.AddDays(-50),
                    PaymentStatus = PaymentStatus.Authorised,
                    TotalCostCents = null,
                    PaymentFeeCents = null
                }
            },
            Quantity = 3,
            IssuedProducts = new List<IssuedProduct>()
        },

        new()
        {
            Product = new()
            {
                EventId = Guid.NewGuid(),
                Event = new()
                {
                    Name = "seven",
                    OrganizationId = RevenueOrganizationId,
                    Organization = new()
                    {
                        Contract = new()
                        {
                            Start = DateTime.UtcNow.AddDays(-1),
                            End = DateTime.UtcNow.AddDays(+1),
                            ProductFeeCents = 83,
                            TicketFeeCents = 83
                        }
                    }
                },
                Type = ProductType.Ticket
            },
            ReservationReferenceNavigation = new()
            {
                OrderReference = new()
                {
                    CreatedAt = DateTime.UtcNow,
                    PaymentStatus = PaymentStatus.Authorised,
                    TotalCostCents = 1000,
                    PaymentFeeCents = 50
                }
            },
            Quantity = 3,
            IssuedProducts = new List<IssuedProduct>()
        }
    ];

    public EventDaoTests()
    {
        _mockedContext.Setup(c => c.ShopFieldRequirements)
            .ReturnsDbSet(new List<ShopFieldRequirement>());

        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                new()
                {
                    Id = MockedEventIds[0],
                    StartDate = DateTime.UtcNow.AddDays(-5),
                    EndDate = DateTime.UtcNow.AddDays(5),
                    Name = "UnittestEvent",
                    Description = "Unit event description",
                    Shops = new List<FanceeData.Models.Ticketing.Shop>
                    {
                        new()
                        {
                            Code = "kf9i20",
                            Name = "Shopname1",
                            ShopFieldRequirements = new List<ShopFieldRequirement>
                            {
                                ShopFieldRequirement
                            }
                        }
                    },
                    Address = new()
                    {
                        City = "UnitCity",
                        PostalCode = "1234AB",
                        HouseNumber = "1"
                    },
                    ReservationTimeMinutes = 8,
                    CreatedOn = DateTime.UtcNow.AddDays(-10),
                    Type = EventType.Normal,
                    Status = EventStatus.Unpublished,
                    OrganizationId = OrganizationIds[0],
                    Organization = Organization1,
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = ValidProductId,
                            EventId = MockedEventIds[0],
                            ReservedProducts = new List<ReservedProduct>(),
                            IssuedProducts = new List<IssuedProduct>()
                        }
                    },
                    PaymentMethods = new List<EventPaymentMethod>
                    {
                        new()
                        {
                            PaymentMethodId = Guid.NewGuid(),
                            PaidBy = PaidBy.Organization
                        }
                    }
                },
                new()
                {
                    Id = MockedEventIds[1],
                    StartDate = DateTime.UtcNow.AddDays(-10),
                    EndDate = DateTime.UtcNow.AddDays(10),
                    Name = "PartyEvent2",
                    Description = "Unit event description",
                    Shops = new List<FanceeData.Models.Ticketing.Shop>
                    {
                        new()
                        {
                            Code = "fier14",
                            Name = "Shopname2"
                        }
                    },
                    Address = new()
                    {
                        Id = AddressId,
                        City = "UnitCity",
                        PostalCode = "1234AB",
                        HouseNumber = "1",
                        Venue = "TestVenue"
                    },
                    ReservationTimeMinutes = 8,
                    CreatedOn = DateTime.UtcNow.AddDays(-10),
                    Type = EventType.Seating,
                    Status = EventStatus.Unpublished,
                    OrganizationId = OrganizationIds[0],
                    Organization = Organization1,
                    AddressId = AddressId,
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            EventId = MockedEventIds[1],
                            ReservedProducts = new List<ReservedProduct>(),
                            IssuedProducts = new List<IssuedProduct>()
                        }
                    },
                    PaymentMethods = new List<EventPaymentMethod>
                    {
                        new()
                        {
                            PaymentMethodId = Guid.NewGuid(),
                            PaidBy = PaidBy.Organization
                        }
                    }
                },
                new()
                {
                    Id = MockedEventIds[2],
                    StartDate = DateTime.UtcNow.AddDays(-10),
                    EndDate = DateTime.UtcNow.AddDays(10),
                    Name = "UnittestEvent3",
                    Description = "Unit event description",
                    Shops = new List<FanceeData.Models.Ticketing.Shop>(),
                    Type = EventType.Timeslotted,
                    Status = EventStatus.Cancelled,
                    OrganizationId = OrganizationIds[1],
                    Organization = Organization2,
                    Address = new()
                    {
                        Id = AddressId,
                        City = "UnitCity",
                        PostalCode = "1234AB",
                        HouseNumber = "1",
                        Venue = "TestVenue"
                    },
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            EventId = MockedEventIds[2],
                            ReservedProducts = new List<ReservedProduct>(),
                            IssuedProducts = new List<IssuedProduct>()
                        }
                    },
                    PaymentMethods = new List<EventPaymentMethod>
                    {
                        new()
                        {
                            PaymentMethodId = Guid.NewGuid(),
                            PaidBy = PaidBy.Organization
                        }
                    }
                },
                _event,
                new()
                {
                    Id = MockedEventIds[3],
                    StartDate = DateTime.UtcNow.AddDays(-10),
                    EndDate = DateTime.UtcNow.AddDays(-9),
                    Name = "UnittestEvent4",
                    Description = "Unit event description",
                    Shops = new List<FanceeData.Models.Ticketing.Shop>(),
                    Address = new()
                    {
                        Id = AddressId,
                        City = "UnitCity",
                        PostalCode = "1234AB",
                        HouseNumber = "1",
                        Venue = "TestVenue"
                    },
                    Type = EventType.Normal,
                    Status = EventStatus.Active,
                    OrganizationId = OrganizationIds[1],
                    Organization = Organization2,
                    Products = new List<FanceeData.Models.Ticketing.Product>(),
                    PaymentMethods = new List<EventPaymentMethod>()
                },
                new()
                {
                    Id = MockedEventIds[4],
                    StartDate = DateTime.UtcNow.AddDays(-15),
                    EndDate = DateTime.UtcNow.AddDays(-10),
                    Name = "UnittestEvent5",
                    Description = "Unit event description",
                    Shops = new List<FanceeData.Models.Ticketing.Shop>(),
                    Address = new()
                    {
                        Id = AddressId,
                        City = "UnitCity",
                        PostalCode = "1234AB",
                        HouseNumber = "1",
                        Venue = "TestVenue"
                    },
                    Type = EventType.Normal,
                    Status = EventStatus.SoldOut,
                    OrganizationId = OrganizationIds[1],
                    Organization = Organization2,
                    Products = new List<FanceeData.Models.Ticketing.Product>(),
                    PaymentMethods = new List<EventPaymentMethod>()
                },
                new()
                {
                    Id = MockedEventIds[5],
                    StartDate = DateTime.UtcNow.AddDays(-15),
                    EndDate = DateTime.UtcNow.AddDays(-10),
                    Name = "UnittestEvent6",
                    Description = "Unit event description",
                    Shops = new List<FanceeData.Models.Ticketing.Shop>(),
                    Address = new()
                    {
                        Id = AddressId,
                        City = "UnitCity",
                        PostalCode = "1234AB",
                        HouseNumber = "1",
                        Venue = "TestVenue"
                    },
                    Type = EventType.Normal,
                    Status = EventStatus.Unpublished,
                    OrganizationId = OrganizationIds[1],
                    Organization = Organization2,
                    Products = new List<FanceeData.Models.Ticketing.Product>(),
                    PaymentMethods = new List<EventPaymentMethod>()
                },
                new()
                {
                    Id = MockedEventIds[6],
                    StartDate = DateTime.UtcNow.AddDays(-15),
                    EndDate = DateTime.UtcNow.AddDays(-8),
                    Name = "UnittestEvent6",
                    Description = "Unit event description",
                    Shops = new List<FanceeData.Models.Ticketing.Shop>(),
                    Address = new()
                    {
                        Id = AddressId,
                        City = "UnitCity",
                        PostalCode = "1234AB",
                        HouseNumber = "1",
                        Venue = "TestVenue"
                    },
                    Type = EventType.Normal,
                    Status = EventStatus.Unpublished,
                    OrganizationId = OrganizationIds[0],
                    Organization = Organization1,
                    Products = new List<FanceeData.Models.Ticketing.Product>(),
                    PaymentMethods = new List<EventPaymentMethod>()
                }
            });

        _mockedContext.Setup(c => c.ItemsInShops)
            .ReturnsDbSet(new List<ItemInShop>());

        _mockedContext.Setup(c => c.EventsPaymentMethods)
            .ReturnsDbSet(new List<EventPaymentMethod>());

        _mockedContext.Setup(c => c.AppTeams)
            .ReturnsDbSet(new List<AppTeam>
            {
                new()
                {
                    Id = AppTeamId,
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = ValidProductId,
                            EventId = ValidEventId
                        }
                    }
                }
            });

        _sut = new(_mockedContext.Object, _mockedShopDao.Object);
    }

    [Fact]
    public async Task TestThatUpdateStatusAsyncCallsDbMethods()
    {
        var actual = await _sut.UpdateStatusAsync(ValidEventId, EventStatus.Cancelled);

        Assert.Equal(1, actual);
    }

    [Fact]
    public async Task TestThatListByAppTeamAsyncGetsEventsListingForAppTeamBasedOnAssignedProducts()
    {
        var actual = await _sut.ListByAppTeamAsync(AppTeamId, 10, 0, null, null, null, null, _deploymentEnvironment);

        Assert.Single(actual.Items);
    }

    [Fact]
    public async Task TestThatInsertInsertsNewEvent()
    {
        _mockedContext.Setup(c => c.SetEntityState(_event, EntityState.Added));

        await _sut.InsertAsync(_event);

        _mockedContext.Verify(c => c.Events.AddAsync(It.IsAny<FanceeData.Models.Ticketing.Event>(), default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Exactly(2));
    }

    [Theory]
    [MemberData(nameof(ListByOrganizationTestData))]
    public async Task TestThatListAsyncListsAllEventsOfTheGivenOrganization(Guid organizationId, int expectedAmount)
    {
        var actual = await _sut.ListAsync(organizationId, 100, 0, string.Empty, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.Equal(expectedAmount, actual.Items.Count());
        Assert.Equal(expectedAmount, actual.TotalItems);
    }

    [Theory]
    [MemberData(nameof(ListByOrganizationTestData))]
    public async Task TestThatListAsyncListsAllEventsOfTheGivenOrganizationForThePlatform(Guid organizationId, int expectedAmount)
    {
        var actual = await _sut.ListAsync(organizationId, 100, 0, string.Empty, null, null, Array.Empty<EventStatus>(), new[] { "NL" }, _deploymentEnvironment);

        Assert.Equal(expectedAmount, actual.Items.Count());
        Assert.Equal(expectedAmount, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatListAsyncWithLimitLimitsTheResultSet()
    {
        var actual = await _sut.ListAsync(OrganizationIds[0], 1, 0, string.Empty, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.Equal(4, actual.TotalItems);
        Assert.Single(actual.Items);
        Assert.Equal("UnittestEvent6", actual.Items.First().Name);
    }

    [Fact]
    public async Task TaskThatListAsyncWithOffsetOffsetsTheResultSet()
    {
        var actual = await _sut.ListAsync(OrganizationIds[0], 1, 1, string.Empty, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.Equal(4, actual.TotalItems);
        Assert.Single(actual.Items);
        Assert.Equal("PartyEvent2", actual.Items.First().Name);
    }

    [Fact]
    public async Task TestThatListAsyncFiltersResultsBasedOnSearchQuery()
    {
        var actual = await _sut.ListAsync(OrganizationIds[0], 100, 0, "arty", null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.Equal(1, actual.TotalItems);
        Assert.Single(actual.Items);
        Assert.Equal("PartyEvent2", actual.Items.First().Name);
    }

    [Fact]
    public async Task TestThatListAsyncWithoutOrganizationListsAllEvents()
    {
        var actual = await _sut.ListAsync(100, 0, string.Empty, null, null, Array.Empty<EventStatus>(), new[] { "NL" }, _deploymentEnvironment);

        Assert.Equal(8, actual.Items.Count());
        Assert.Equal(8, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatListAsyncWithoutOrganizationWithLimitLimitsTheResultSet()
    {
        var actual = await _sut.ListAsync(1, 0, string.Empty, null, null, Array.Empty<EventStatus>(), new[] { "NL" }, _deploymentEnvironment);

        Assert.Equal(8, actual.TotalItems);
        Assert.Single(actual.Items);
        Assert.Equal("UnittestEvent5", actual.Items.First().Name);
    }

    [Fact]
    public async Task TestThatListAsyncWithoutOrganizationWithOffsetOffsetsTheResultSet()
    {
        var actual = await _sut.ListAsync(1, 1, string.Empty, null, null, Array.Empty<EventStatus>(), new[] { "NL" }, _deploymentEnvironment);

        Assert.Equal(8, actual.TotalItems);
        Assert.Single(actual.Items);
        Assert.Equal("UnittestEvent6", actual.Items.First().Name);
    }

    [Fact]
    public async Task TestThatListAsyncWithoutOrganizationFiltersResultsBasedOnSearchQuery()
    {
        var actual = await _sut.ListAsync(100, 0, "arty", null, null, Array.Empty<EventStatus>(), new[] { "NL" }, _deploymentEnvironment);

        Assert.Equal(1, actual.TotalItems);
        Assert.Single(actual.Items);
        Assert.Equal("PartyEvent2", actual.Items.First().Name);
    }

    [Fact]
    public async Task TestThatGetAsyncGetsEventResponse()
    {
        var actual = await _sut.GetAsync(MockedEventIds[0], OrganizationIds[0], HostedDeploymentEnvironment);

        Assert.NotNull(actual);
        Assert.Equal(MockedEventIds[0], actual.Id);
        Assert.Equal("UnittestEvent", actual.Name);
        Assert.Null(actual.Address);
    }

    [Fact]
    public async Task TestThatGetAsyncGetsEventResponseWithAddress()
    {
        var actual = await _sut.GetAsync(MockedEventIds[1], OrganizationIds[0], HostedDeploymentEnvironment);

        Assert.NotNull(actual);
        Assert.NotNull(actual.Address);
        Assert.Equal("TestVenue", actual.Address?.Venue);
        Assert.Equal("PartyEvent2", actual.Name);
    }

    [Theory]
    [MemberData(nameof(GetInvalidEventTestData))]
    public async Task TestThatGetAsyncReturnsNullOnInvalidEvent(Guid eventId, Guid organizationId)
    {
        var actual = await _sut.GetAsync(eventId, organizationId, HostedDeploymentEnvironment);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatGetEventAsyncIncludesRequestedData()
    {
        var actual = await _sut.GetEventAsync(MockedEventIds[1], OrganizationIds[0], i => i.Include(e => e.Address));

        Assert.NotNull(actual?.Address);
        Assert.Equal("TestVenue", actual.Address.Venue);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsUpdate()
    {
        var @event = await _sut.GetEventAsync(MockedEventIds[1], OrganizationIds[0], i => i.Include(e => e.Categories).Include(e => e.Address));
        @event!.Name = "Updated!";

        await _sut.UpdateAsync(@event);

        _mockedContext.Verify(c => c.Events.Update(@event), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default));
    }

    [Fact]
    public async Task TestThatDeleteAsyncRemovesEvent()
    {
        await _sut.DeleteAsync(MockedEventIds[0]);

        _mockedShopDao.Verify(sd => sd.DeleteItemsInShopAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Once);
        _mockedContext.Verify(c => c.Events.Remove(It.IsAny<FanceeData.Models.Ticketing.Event>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatCopyableEventAsyncReturnsNullOnNonExistingEvent()
    {
        var actual = await _sut.CopyableEventAsync(Guid.NewGuid(), false, false, false, false, false, false);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatCopyableEventRetrievesEvent()
    {
        var actual = await _sut.CopyableEventAsync(ValidEventId, true, true, true, true, true, true);

        Assert.IsType<FanceeData.Models.Ticketing.Event>(actual);
        Assert.Equal(ValidEventId, actual.Id);
    }

    [Fact]
    public async Task TestThatEventsAgendaAsyncGetsAllEvents()
    {
        var actual = await _sut.EventsAgendaAsync(DateTime.UtcNow.AddDays(-25), DateTime.UtcNow.AddDays(25), new[] { "NL" }, _deploymentEnvironment);

        Assert.Equal(8, actual.Count());
    }

    [Fact]
    public async Task TestThatEventRevenueAsyncCalculatesEventSpecificRevenues()
    {
        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(_revenueOrders);

        _mockedContext.Setup(c => c.ReservedProducts)
            .ReturnsDbSet(_revenueReservedProducts);

        var actual = await _sut.EventRevenuesAsync(RevenueEventId, new List<MappedOrganizationContractFee>());

        Assert.Equal(1000, actual.CashSalesRevenueCents);
        Assert.Equal(2000, actual.OnlineSalesRevenueCents);
        Assert.Equal(0, actual.ProfitCents);
    }

    [Fact]
    public async Task TestThatEventRevenueAsyncCalculatesCorrectPlatformExpenses()
    {
        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(PlatformExpensesOrders);

        _mockedContext.Setup(c => c.ReservedProducts)
            .ReturnsDbSet(PlatformExpensesReservedProduct);

        var actual = await _sut.EventRevenuesAsync(PlatformExpensesEventId, new List<MappedOrganizationContractFee>());

        Assert.Equal(4950, actual.PlatformExpensesCents);
    }

    [Fact]
    public async Task TestThatRevenuesAsyncCalculatesAllEventRevenues()
    {
        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(_revenueOrders);

        _mockedContext.Setup(c => c.ReservedProducts)
            .ReturnsDbSet(_revenueReservedProducts);

        _mockedContext.Setup(c => c.IssuedProducts)
            .ReturnsDbSet(_issuedProducts);

        var actual = await _sut.RevenuesAsync(RevenueOrganizationId, ContractFees);

        Assert.Equal(1000, actual.CashSalesRevenueCents);
        Assert.Equal(3000, actual.OnlineSalesRevenueCents);
    }

    [Fact]
    public async Task TestThatRevenuesAsyncReturnsDefaultRevenueResponse()
    {
        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Order>());

        var actual = await _sut.RevenuesAsync(OrganizationIds[0], ContractFees);

        Assert.Equal(0, actual.CashSalesRevenueCents);
        Assert.Equal(0, actual.OnlineSalesRevenueCents);
        Assert.Equal(0, actual.PlatformExpensesCents);
        Assert.Equal(0, actual.ProfitCents);
    }

    [Fact]
    public async Task TestThatEventRevenuesAsyncReturnsDefaultRevenueResponse()
    {
        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Order>());

        var actual = await _sut.EventRevenuesAsync(ValidEventId, new List<MappedOrganizationContractFee>());

        Assert.Equal(0, actual.CashSalesRevenueCents);
        Assert.Equal(0, actual.OnlineSalesRevenueCents);
        Assert.Equal(0, actual.PlatformExpensesCents);
        Assert.Equal(0, actual.ProfitCents);
    }

    [Fact]
    public async Task TestThatStartDateAsyncReturnsNullOnInvalidEventId()
    {
        var actual = await _sut.StartDateAsync(Guid.NewGuid());

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatStartDateAsyncGetsStartDateFromValidEvent()
    {
        var actual = await _sut.StartDateAsync(ValidEventId);

        Assert.IsType<DateTime>(actual);
        Assert.NotNull(actual);
        Assert.Equal(_event.StartDate, actual);
    }

    [Fact]
    public async Task TestThatUpcomingEventProductsOnlySelectsUpcomingNonCancelledEventsWithProducts()
    {
        var organizationId = Guid.NewGuid();
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                new() //Should not be fetched due to having a surpassed start date
                {
                    OrganizationId = organizationId,
                    Name = "Unit event 1",
                    StartDate = DateTime.UtcNow.AddDays(-10),
                    Status = EventStatus.Concluded,
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Type = ProductType.Ticket,
                            Name = "Unit product 1"
                        }
                    }
                },
                new() //Should be fetched as a valid event
                {
                    OrganizationId = organizationId,
                    Name = "Unit event 2",
                    StartDate = DateTime.UtcNow.AddDays(5),
                    Status = EventStatus.Active,
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Type = ProductType.Ticket,
                            Name = "Unit product 1"
                        }
                    }
                },
                new() //Should not be fetched due to having no products
                {
                    OrganizationId = organizationId,
                    Name = "Unit event 3",
                    StartDate = DateTime.UtcNow.AddDays(5),
                    Status = EventStatus.Unpublished,
                    Products = new List<FanceeData.Models.Ticketing.Product>()
                },
                new() //Should not be fetched due to being cancelled
                {
                    OrganizationId = organizationId,
                    Name = "Unit event 4",
                    StartDate = DateTime.UtcNow.AddDays(50),
                    Status = EventStatus.Cancelled,
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Type = ProductType.Product,
                            Name = "Unit product 3"
                        }
                    }
                },
                new() //Should be fetched as a valid event
                {
                    OrganizationId = organizationId,
                    Name = "Unit event 5",
                    StartDate = DateTime.UtcNow.AddDays(5),
                    Status = EventStatus.Active,
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Type = ProductType.Ticket,
                            Name = "Unit product 4"
                        },
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Type = ProductType.Product,
                            Name = "Unit product 5"
                        },
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Type = ProductType.Ticket,
                            Name = "Unit product 6"
                        }
                    }
                }
            });

        var actual = await _sut.UpcomingEventProductsAsync(organizationId);

        Assert.Equal(2, actual.Count());
    }

    [Fact]
    public async Task TestThatListEventItemsAsyncSearchesBetweenDates()
    {
        var actual = await _sut.ListAsync(OrganizationIds[0], 10, 0, null, DateTime.UtcNow.AddDays(-10), DateTime.UtcNow, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.Equal(4, actual.TotalItems);
        Assert.Equal(4, actual.Items.Count());
        Assert.Equal("UnittestEvent6", actual.Items.First().Name);
    }

    [Fact]
    public async Task TestThatListEventItemsAsyncFiltersOnEventStates()
    {
        var actual = await _sut.ListAsync(OrganizationIds[0], 10, 0, null, null, null, new[] { EventStatus.Active }, _deploymentEnvironment);

        Assert.Equal(1, actual.TotalItems);
        Assert.Single(actual.Items);
        Assert.Equal("UnitTestEventInsert", actual.Items.First().Name);
    }

    [Fact]
    public async Task TestThatListEventsGetsShopAsActiveOnPassedChecks()
    {
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                _activeShopEvent
            });

        var actual = await _sut.ListAsync(ActiveShopOrganizationId, 1, 0, null, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.True(actual.Items.First().Shops.First().Active);
    }

    [Fact]
    public async Task TestThatListEventsGetsShopAsInactiveOnInactiveShop()
    {
        _activeShopEvent.Shops.First().Active = false;
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                _activeShopEvent
            });

        var actual = await _sut.ListAsync(ActiveShopOrganizationId, 1, 0, null, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.False(actual.Items.First().Shops.First().Active);
    }

    [Fact]
    public async Task TestThatListEventsGetsShopAsInactiveOnSurpassedShopEndDate()
    {
        _activeShopEvent.Shops.First().EndDate = DateTime.UtcNow.AddHours(-1);
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                _activeShopEvent
            });

        var actual = await _sut.ListAsync(ActiveShopOrganizationId, 1, 0, null, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.False(actual.Items.First().Shops.First().Active);
    }

    [Fact]
    public async Task TestThatListEventsGetsShopAsInactiveForShopWithoutItems()
    {
        _activeShopEvent.Shops.First().ItemsInShop = Array.Empty<ItemInShop>();
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                _activeShopEvent
            });

        var actual = await _sut.ListAsync(ActiveShopOrganizationId, 1, 0, null, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.False(actual.Items.First().Shops.First().Active);
    }

    [Fact]
    public async Task TestThatListEventsGetsShopAsInactiveWhenEventDoesNotBearActiveStatus()
    {
        _activeShopEvent.Status = EventStatus.Cancelled;
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                _activeShopEvent
            });

        var actual = await _sut.ListAsync(ActiveShopOrganizationId, 1, 0, null, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.False(actual.Items.First().Shops.First().Active);
    }

    [Fact]
    public async Task TestThatListEventsGetsShopAsInactiveWhenEventIsExpired()
    {
        _activeShopEvent.EndDate = DateTime.UtcNow.AddHours(-1);
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                _activeShopEvent
            });

        var actual = await _sut.ListAsync(ActiveShopOrganizationId, 1, 0, null, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.False(actual.Items.First().Shops.First().Active);
    }

    [Fact]
    public async Task TestThatListEventsGetsShopAsInactiveWhenEventHasNoPaymentOptions()
    {
        _activeShopEvent.PaymentMethods = Array.Empty<EventPaymentMethod>();
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Event>
            {
                _activeShopEvent
            });

        var actual = await _sut.ListAsync(ActiveShopOrganizationId, 1, 0, null, null, null, Array.Empty<EventStatus>(), _deploymentEnvironment);

        Assert.False(actual.Items.First().Shops.First().Active);
    }

    [Fact]
    public async Task TestThatConcludeAsyncSetsStatusOfFinishedEvents()
    {
        var actual = await _sut.ConcludeAsync();

        Assert.Equal(2, actual);
    }

    [Fact]
    public async Task TestThatOrganizationEventExportItemsResponseAsyncFetchesEventsAsExportItems()
    {
        var actual = (await _sut.OrganizationEventExportItemsResponseAsync(OrganizationIds[0], null, null, null, Array.Empty<EventStatus>())).ToList();

        Assert.Equal(4, actual.Count);
        Assert.Equal("UnittestEvent6", actual.First().Name);
    }

    [Fact]
    public async Task TestThatPlatformEventExportItemsResponseAsyncFetchesEventsAsExportItems()
    {
        var actual = (await _sut.PlatformEventExportItemsResponseAsync(null, null, null, Array.Empty<EventStatus>(), new[] { "NL" })).ToList();

        Assert.Equal(8, actual.Count);
        Assert.Equal("UnittestEvent5", actual.First().Name);
    }

    [Fact]
    public async Task TestThatPlatformEventExportItemsResponseAsyncFetchesEventsAsExportItemsForOrganization()
    {
        var actual = (await _sut.PlatformEventExportItemsResponseAsync(OrganizationIds[0], null, null, null, Array.Empty<EventStatus>(), new[] { "NL" })).ToList();

        Assert.Equal(4, actual.Count);
        Assert.Equal("UnittestEvent6", actual.First().Name);
    }

    [Fact(Skip = "This test fails at the beginning of the month")]
    public async Task TestThatEventBalanceAsyncReturnsCorrectCalculations()
    {
        _mockedContext.Setup(c => c.Events)
            .ReturnsDbSet(Events);

        _mockedContext.Setup(c => c.Orders)
            .ReturnsDbSet(PlatformExpensesOrders);

        var eventsBalancesResponse = await _sut.BalanceMutationsAsync(MappedOrganizationContractFee, null);

        Assert.Equal(2, eventsBalancesResponse[0].TotalAmountOfIssuedTickets);
        Assert.Equal(1600, eventsBalancesResponse[0].TotalAmountOfOrderTotalCostsCentsReceived);
        Assert.Equal(2, eventsBalancesResponse[0].TotalAmountOfScannedTickets);
        Assert.Equal(200, eventsBalancesResponse[0].TotalAmountOfTicketFeeCentsReceived);
        Assert.Equal(50, eventsBalancesResponse[0].TotalAmountOfPaymentFeeCentsReceived);
        Assert.Equal(1000, eventsBalancesResponse[0].TotalAmountOfTicketPlusCostsCentsReceived);

        Assert.Equal(5, eventsBalancesResponse[1].TotalAmountOfIssuedTickets);
        Assert.Equal(24100, eventsBalancesResponse[1].TotalAmountOfOrderTotalCostsCentsReceived);
        Assert.Equal(4, eventsBalancesResponse[1].TotalAmountOfScannedTickets);
        Assert.Equal(370, eventsBalancesResponse[1].TotalAmountOfTicketFeeCentsReceived);
        Assert.Equal(350, eventsBalancesResponse[1].TotalAmountOfPaymentFeeCentsReceived);
        Assert.Equal(0, eventsBalancesResponse[1].TotalAmountOfTicketPlusCostsCentsReceived);
    }

    [Fact]
    public async Task TestThatCancelableAsyncReturnsFalseWhenEventAlreadyCanceled()
    {
        var actual = await _sut.CancelableAsync(ValidEventIds[1]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatCancelableAsyncReturnsFalseWhenEventStarted()
    {
        var actual = await _sut.CancelableAsync(ValidEventIds[0]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatCancelableAsyncReturnsTrueWhenEventIsNotCanceled()
    {
        var actual = await _sut.CancelableAsync(ValidEventIds[2]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatCancelableAsyncReturnsTrueWhenEventNotStarted()
    {
        var actual = await _sut.CancelableAsync(ValidEventIds[2]);

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncReturnsExpectedResult()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [], null)).ToList();

        Assert.Equal(4, actual.Count);
        Assert.Equal("UnittestEvent", actual[0].Label);
        Assert.StartsWith($"{DateTime.UtcNow.Year}", actual[0].Note);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncFiltersOnEventIds()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [ValidEventId], null)).ToList();

        Assert.Single(actual);
        Assert.Equal(ValidEventId, actual[0].Id);
        Assert.Equal("UnitTestEventInsert", actual[0].Label);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncFiltersOnName()
    {
        var actual = (await _sut.ListSelectOptionsAsync(OrganizationIds[0], [], "UnitTestEventInsert")).ToList();

        Assert.Single(actual);
        Assert.Equal(ValidEventId, actual[0].Id);
        Assert.Equal("UnitTestEventInsert", actual[0].Label);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncListsAll()
    {
        var actual = (await _sut.ListSelectOptionsAsync(null, [], null)).ToList();

        Assert.Equal(8, actual.Count);
        Assert.Equal("UnittestEvent", actual[0].Label);
        Assert.Equal("UnitTest B.V.", actual[0].Note);
    }
}