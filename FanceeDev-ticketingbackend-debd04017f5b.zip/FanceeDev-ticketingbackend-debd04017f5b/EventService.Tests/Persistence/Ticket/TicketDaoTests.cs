﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Persistence.Ticket;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Ticket;

public class TicketDaoTests
{
    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private static readonly Guid[] MockedProductIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    private readonly TicketDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public TicketDaoTests()
    {
        var validEvent = new FanceeData.Models.Ticketing.Event
        {
            Id = ValidEventId,
            OrganizationId = ValidOrganizationId
        };

        var products = new List<FanceeData.Models.Ticketing.Product>
        {
            new()
            {
                Id = MockedProductIds[0],
                Name = "First Ticket",
                Type = ProductType.Ticket,
                EventId = ValidEventId,
                Event = validEvent
            },
            new()
            {
                Id = MockedProductIds[1],
                Name = "Second Ticket",
                Type = ProductType.Ticket,
                EventId = ValidEventId,
                Event = validEvent
            },
            new()
            {
                Id = MockedProductIds[2],
                Name = "Third Ticket",
                Type = ProductType.Ticket,
                EventId = ValidEventId,
                Event = validEvent
            }
        };

        var ticketOptions = new List<TicketOption>
        {
            new()
            {
                ProductId = products[0].Id,
                Product = products[0],
                Swappable = true
            },
            new()
            {
                ProductId = products[1].Id,
                Product = products[1]
            },
            new()
            {
                ProductId = products[2].Id,
                Product = products[2]
            }
        };

        _mockedContext = new();
        _mockedContext.Setup(c => c.Products).ReturnsDbSet(products);
        _mockedContext.Setup(c => c.TicketOptions).ReturnsDbSet(ticketOptions);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatDeleteAsyncRemovesGivenTicket()
    {
        var itemInShops = new List<ItemInShop>
        {
            new()
            {
                ProductId = MockedProductIds[0],
            }
        };
        
        _mockedContext.Setup(c => c.ItemsInShops).ReturnsDbSet(itemInShops);
        
        await _sut.DeleteAsync(MockedProductIds[0]);

        _mockedContext.Verify(c => c.ItemsInShops.RemoveRange(itemInShops));
        _mockedContext.Verify(c => c.Attach(It.IsAny<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedContext.Verify(c => c.Attach(It.IsAny<TicketOption>()), Times.Once);
        _mockedContext.Verify(c => c.TicketOptions.Remove(It.IsAny<TicketOption>()));
        _mockedContext.Verify(c => c.Products.Remove(It.IsAny<FanceeData.Models.Ticketing.Product>()));
        _mockedContext.Verify(c => c.SaveChangesAsync(default));
    }

    [Fact]
    public async Task TestThatTotalTicketsScannedAsyncCountsScannedTicketsOfOrganization()
    {
        var organizationId = Guid.NewGuid();

        _mockedContext.Setup(c => c.TicketScans)
            .ReturnsDbSet(new List<TicketScan>
            {
                new()
                {
                    State = ScanState.Scanned,
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                Event = new()
                                {
                                    OrganizationId = organizationId
                                }
                            }
                        }
                    }
                },
                new()
                {
                    State = ScanState.Unscanned,
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                Event = new()
                                {
                                    OrganizationId = organizationId
                                }
                            }
                        }
                    }
                },
                new()
                {
                    State = ScanState.Scanned,
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                Event = new()
                                {
                                    OrganizationId = organizationId
                                }
                            }
                        }
                    }
                }
            });

        var actual = await _sut.TotalTicketsScannedAsync(organizationId);

        Assert.Equal(2, actual);
    }

    [Fact]
    public async Task TestThatTotalTicketsScannedAsyncForPlatformCountsScannedTickets()
    {
        _mockedContext.Setup(c => c.TicketScans)
            .ReturnsDbSet(new List<TicketScan>
            {
                new()
                {
                    State = ScanState.Scanned,
                    DateTime = DateTime.UtcNow.AddDays(-1),
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                Event = new()
                                {
                                    Organization = new()
                                    {
                                        IsDemo = false,
                                        CountryCode = "NL"
                                    }
                                }
                            }
                        }
                    }
                },
                new()
                {
                    State = ScanState.Unscanned,
                    DateTime = DateTime.UtcNow.AddDays(-2),
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                Event = new()
                                {
                                    Organization = new()
                                    {
                                        IsDemo = true,
                                        CountryCode = "NL"
                                    }
                                }
                            }
                        }
                    }
                },
                new()
                {
                    State = ScanState.Scanned,
                    DateTime = DateTime.UtcNow.AddDays(-3),
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                Event = new()
                                {
                                    Organization = new()
                                    {
                                        IsDemo = false,
                                        CountryCode = "NL"
                                    }
                                }
                            }
                        }
                    }
                },
                new()
                {
                    State = ScanState.Scanned,
                    DateTime = DateTime.UtcNow.AddDays(-1),
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                Event = new()
                                {
                                    Organization = new()
                                    {
                                        IsDemo = false,
                                        CountryCode = "NL"
                                    }
                                }
                            }
                        }
                    }
                }
            });

        var actual = await _sut.TotalTicketsScannedAsync(DateTime.UtcNow.AddDays(-2), DateTime.UtcNow, new[] { "NL" });

        Assert.Equal(2, actual);
    }

    [Fact]
    public async Task TestThatEventTicketsScannedAsyncCountsScannedTicketsOfOrganization()
    {
        var eventId = Guid.NewGuid();

        _mockedContext.Setup(c => c.TicketScans)
            .ReturnsDbSet(new List<TicketScan>
            {
                new()
                {
                    State = ScanState.Scanned,
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                EventId = eventId
                            }
                        }
                    }
                },
                new()
                {
                    State = ScanState.Unscanned,
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                EventId = eventId
                            }
                        }
                    }
                },
                new()
                {
                    State = ScanState.Scanned,
                    IssuedTicket = new()
                    {
                        IssuedProduct = new()
                        {
                            Product = new()
                            {
                                EventId = eventId
                            }
                        }
                    }
                }
            });

        var actual = await _sut.EventTicketsScannedAsync(eventId);

        Assert.Equal(2, actual);
    }
}