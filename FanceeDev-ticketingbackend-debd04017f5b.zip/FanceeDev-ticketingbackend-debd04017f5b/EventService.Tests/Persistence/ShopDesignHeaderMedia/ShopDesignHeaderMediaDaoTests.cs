﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using EventService.Persistence.ShopDesignHeaderMedia;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.ShopDesignHeaderMedia;

public class ShopDesignHeaderMediaDaoTests
{
    private static readonly Guid[] MockedFileIds = { Guid.NewGuid(), Guid.NewGuid() };
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ShopDesignHeaderMediaDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public ShopDesignHeaderMediaDaoTests()
    {
        _mockedContext = new();
        _mockedContext.Setup(c => c.ShopDesignHeaderMedia).ReturnsDbSet(new List<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>
        {
            new()
            {
                ShopCode = "UnitShop",
                Position = 1,
                FileId = MockedFileIds[0],
                File = new()
                {
                    Id = MockedFileIds[0],
                    Name = "TestFile"
                },
                FocalPointHeightPercentage = null,
                FocalPointWidthPercentage = null
            },
            new()
            {
                ShopCode = "UnitShop",
                Position = 2,
                FileId = MockedFileIds[1],
                File = new()
                {
                    Id = MockedFileIds[1],
                    Name = "SecondTestFile"
                },
                ShopDesign = new()
                {
                    Shop = new()
                    {
                        Event = new()
                        {
                            OrganizationId = ValidOrganizationId
                        }
                    }
                },
                FocalPointHeightPercentage = null,
                FocalPointWidthPercentage = null
            }
        });

        _mockedContext.Setup(c => c.Files).ReturnsDbSet(new List<File>());

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatNextPositionAsyncReturnsNextNumber()
    {
        var actual = await _sut.NextPositionAsync("UnitShop");

        Assert.Equal(3, actual);
    }

    [Fact]
    public async Task TestThatNextPositionAsyncReturns1IfNoOtherMediaExist()
    {
        var actual = await _sut.NextPositionAsync("NoOtherMedia");

        Assert.Equal(1, actual);
    }

    [Fact]
    public async Task TestThatFindReturnsNullIfNoValidShopCodeAndFileCombinationIsFound()
    {
        var actual = await _sut.FindAsync("Invalid", Guid.NewGuid());

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatFindReturnsValidShopDesignHeaderMedia()
    {
        var actual = await _sut.FindAsync("UnitShop", MockedFileIds[0]);

        Assert.NotNull(actual);
        Assert.Equal("TestFile", actual!.File.Name);
    }

    [Fact]
    public async Task TestThatOwnerOfMediaAsyncReturnsFalseIfOrganizationIsNotOwner()
    {
        var actual = await _sut.OwnerOfMediaAsync(MockedFileIds[1], "UnitShop", new());

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatOwnerOfMediaAsyncReturnsTrueIfOrganizationIsOwner()
    {
        var actual = await _sut.OwnerOfMediaAsync(MockedFileIds[1], "UnitShop", ValidOrganizationId);

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatDeleteAsyncRemovesFileAndHeaderMedia()
    {
        var item = _mockedContext.Object.ShopDesignHeaderMedia.First(sdhm => sdhm.ShopCode == "UnitShop" && sdhm.Position == 2);

        await _sut.DeleteAsync(item);

        _mockedContext.Verify(c => c.ShopDesignHeaderMedia.Remove(item), Times.Once);
        _mockedContext.Verify(c => c.Files.Remove(item.File), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncSavesChangesAsync()
    {
        var updatedShopDesignHeaderMedia = new FanceeData.Models.Ticketing.ShopDesignHeaderMedia
        {
            FocalPointHeightPercentage = 55,
            FocalPointWidthPercentage = 40
        };

        await _sut.UpdateAsync(updatedShopDesignHeaderMedia);

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatForShopAsyncReturnsShopDesignHeaderMediaForShop()
    {
        var actual = (await _sut.ForShopAsync("UnitShop")).ToList();

        Assert.Equal(2, actual.Count);
    }

    [Fact]
    public async Task TestThatRepositionMediaAsyncWithFileIdsUpdatesPosition()
    {
        var fileIds = new[]
        {
            MockedFileIds[1],
            MockedFileIds[0]
        };

        var media = (await _sut.ForShopAsync("UnitShop")).ToList();

        await _sut.RepositionMediaAsync(media, fileIds);

        _mockedContext.Verify(c => c.ShopDesignHeaderMedia.UpdateRange(It.Is<IEnumerable<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>>(pm => pm.Count() == 2)), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatRepositionMediaAsyncWithUpdateAfterPositionRepositionsMedia()
    {
        var actual = await _sut.RepositionMediaAsync("UnitShop", 1);

        Assert.Equal(1, actual);
    }

    [Fact]
    public async Task TestThatInheritMediaAsyncInheritsEventMedia()
    {
        var fileId = Guid.NewGuid();
        var shopCode = "TestCode";

        _mockedContext.Setup(c => c.Shops)
            .ReturnsDbSet(new List<FanceeData.Models.Ticketing.Shop>
            {
                new()
                {
                    Code = shopCode,
                    Event = new()
                    {
                        EventMedia = new List<FanceeData.Models.Ticketing.EventMedia>
                        {
                            new()
                            {
                                FileId = fileId
                            }
                        }
                    }
                }
            });

        await _sut.InheritMediaAsync(shopCode);

        _mockedContext.Verify(c => c.ShopDesignHeaderMedia.AddAsync(It.IsAny<FanceeData.Models.Ticketing.ShopDesignHeaderMedia>(), It.IsAny<CancellationToken>()), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }
}