﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Category;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Persistence.Category;

public class CategoryDaoTests
{
    private readonly CategoryDao _sut;

    private readonly IList<EventCategory> _eventCategories = new List<EventCategory>
    {
        new()
        {
            Active = true,
            Name = "Parent1",
            Parent = null,
            Order = 0
        },
        new()
        {
            Active = false,
            Name = "Inactive1",
            Parent = "Parent1",
            Order = 0
        },
        new()
        {
            Active = true,
            Name = "Active1",
            Parent = "Parent1",
            Order = 1
        }
    };

    public CategoryDaoTests()
    {
        var mockedContext = new Mock<TicketingContext>();

        mockedContext.Setup(c => c.EventCategories).ReturnsDbSet(_eventCategories);

        _sut = new(mockedContext.Object);
    }

    [Fact]
    public async Task TestThatGetAllActiveSubCategoriesGetsAllActiveSubCategories()
    {
        var actual = (await _sut.GetAllActiveSubCategoriesAsync()).ToList();

        Assert.Single(actual);
        Assert.Equal("Active1", actual.First().Name);
    }
}