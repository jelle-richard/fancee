using System;
using System.Buffers;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using EventService.Dtos.Responses.Ticket;
using EventService.Dtos.Shared.Ticket;
using EventService.Utils.Converter;

namespace EventService.Tests.Utils.Converter;

public class TicketDesignElementDtoConverterTests
{
    private readonly TicketDesignElementDtoConverter _sut;

    public TicketDesignElementDtoConverterTests()
    {
        _sut = new();
    }

    [Theory]
    [InlineData(typeof(QrElementDto), true)]
    [InlineData(typeof(QrElementResponse), true)]
    [InlineData(typeof(MediaElementDto), true)]
    [InlineData(typeof(MediaElementResponse), true)]
    [InlineData(typeof(UpcomingEventsElementDto), true)]
    [InlineData(typeof(object), false)]
    [InlineData(typeof(string), false)]
    public void TestThatCanConvertReturnsExceptedValue(Type type, bool expected)
    {
        var actual = _sut.CanConvert(type);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfTokenIsNotStartObject()
    {
        Assert.Throws<JsonException>(() =>
        {
            var jsonBytes = "[]"u8.ToArray();
            var sequence = new ReadOnlySequence<byte>(jsonBytes);
            var reader = new Utf8JsonReader(sequence);

            reader.Read();

            _sut.Read(ref reader, typeof(QrElementDto), new());
        });
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfTokenIsNotPropertyName()
    {
        Assert.Throws<JsonException>(() =>
        {
            var jsonBytes = "{}"u8.ToArray();
            var sequence = new ReadOnlySequence<byte>(jsonBytes);
            var reader = new Utf8JsonReader(sequence);

            reader.Read();

            _sut.Read(ref reader, typeof(QrElementDto), new());
        });
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfPropertyIsNotKind()
    {
        Assert.Throws<JsonException>(() =>
        {
            var jsonBytes = """{"notKind": "value"}"""u8.ToArray();
            var sequence = new ReadOnlySequence<byte>(jsonBytes);
            var reader = new Utf8JsonReader(sequence);

            reader.Read();

            _sut.Read(ref reader, typeof(QrElementDto), new());
        });
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfPropertyValueIsNotString()
    {
        Assert.Throws<JsonException>(() =>
        {
            var jsonBytes = """{"kind": 23}"""u8.ToArray();
            var sequence = new ReadOnlySequence<byte>(jsonBytes);
            var reader = new Utf8JsonReader(sequence);

            reader.Read();

            _sut.Read(ref reader, typeof(QrElementDto), new());
        });
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfPropertyValueIsNotValidEnumValue()
    {
        Assert.Throws<JsonException>(() =>
        {
            var jsonBytes = """{"kind": "invalid enum value"}"""u8.ToArray();
            var sequence = new ReadOnlySequence<byte>(jsonBytes);
            var reader = new Utf8JsonReader(sequence);

            reader.Read();

            _sut.Read(ref reader, typeof(QrElementDto), new());
        });
    }

    [Fact]
    public void TestThatReadParsesQrJsonCorrectly()
    {
        var fileId = Guid.NewGuid();

        var json = $$"""{"kind": "Qr", "Position": {"row": 2, "column": 1}, "size": {"rowSpan": 1, "columnSpan": 1}, "fileId": "{{fileId.ToString()}}"}""";
        var sequence = new ReadOnlySequence<byte>(Encoding.UTF8.GetBytes(json));
        var reader = new Utf8JsonReader(sequence);

        reader.Read();

        var actual = _sut.Read(ref reader, typeof(QrElementDto), new() { PropertyNameCaseInsensitive = true, Converters = { new JsonStringEnumConverter() } });

        Assert.NotNull(actual);
        Assert.IsType<QrElementDto>(actual);
        Assert.NotNull(actual.Position);
        Assert.Equal(2, actual.Position.Row);
        Assert.Equal(1, actual.Position.Column);
        Assert.NotNull(actual.Size);
        Assert.Equal(1, actual.Size.RowSpan);
        Assert.Equal(1, actual.Size.ColumnSpan);
        Assert.Equal(fileId, ((QrElementDto)actual).FileId);
    }

    [Fact]
    public void TestThatReadParsesMediaJsonCorrectly()
    {
        var fileId = Guid.NewGuid();

        var json = $$"""{"kind": "Media", "Position": {"row": 3, "column": 2}, "size": {"rowSpan": 4, "columnSpan": 3}, "fileId": "{{fileId}}"}""";
        var sequence = new ReadOnlySequence<byte>(Encoding.UTF8.GetBytes(json));
        var reader = new Utf8JsonReader(sequence);

        reader.Read();

        var actual = _sut.Read(ref reader, typeof(MediaElementDto), new() { PropertyNameCaseInsensitive = true, Converters = { new JsonStringEnumConverter() } });

        Assert.NotNull(actual);
        Assert.IsType<MediaElementDto>(actual);
        Assert.NotNull(actual.Position);
        Assert.Equal(3, actual.Position.Row);
        Assert.Equal(2, actual.Position.Column);
        Assert.NotNull(actual.Size);
        Assert.Equal(4, actual.Size.RowSpan);
        Assert.Equal(3, actual.Size.ColumnSpan);
        Assert.Equal(fileId, ((MediaElementDto)actual).FileId);
    }

    [Fact]
    public void TestThatReadParsesUpcomingEventsJsonCorrectly()
    {
        var jsonBytes = """{"kind": "UpcomingEvents", "Position": {"row": 3, "column": 2}, "size": {"rowSpan": 4, "columnSpan": 3}, "amount": 3}"""u8.ToArray();
        var sequence = new ReadOnlySequence<byte>(jsonBytes);
        var reader = new Utf8JsonReader(sequence);

        reader.Read();

        var actual = _sut.Read(ref reader, typeof(UpcomingEventsElementDto), new() { PropertyNameCaseInsensitive = true, Converters = { new JsonStringEnumConverter() } });

        Assert.NotNull(actual);
        Assert.IsType<UpcomingEventsElementDto>(actual);
        Assert.NotNull(actual.Position);
        Assert.Equal(3, actual.Position.Row);
        Assert.Equal(2, actual.Position.Column);
        Assert.NotNull(actual.Size);
        Assert.Equal(4, actual.Size.RowSpan);
        Assert.Equal(3, actual.Size.ColumnSpan);
        Assert.Equal(3, ((UpcomingEventsElementDto)actual).Amount);
    }

    [Fact]
    public void TestThatWriteWritesQrElementResponse()
    {
        var fileId = Guid.NewGuid();

        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, new QrElementResponse
        {
            Kind = ElementKind.Qr,
            FileId = fileId,
            FileUrl = "https://unit.test/image.jpg",
            Position = new() { Column = 1, Row = 1 },
            Size = new() { ColumnSpan = 3, RowSpan = 4 }
        }, new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, Converters = { new JsonStringEnumConverter() } });

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal($$$"""{"kind":"Qr","fileUrl":"https://unit.test/image.jpg","fileId":"{{{fileId}}}","position":{"row":1,"column":1},"size":{"rowSpan":4,"columnSpan":3}}""", actual);
    }

    [Fact]
    public void TestThatWriteWritesQrElementDto()
    {
        var fileId = Guid.NewGuid();

        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, new QrElementDto
        {
            Kind = ElementKind.Qr,
            FileId = fileId,
            Position = new() { Column = 1, Row = 1 },
            Size = new() { ColumnSpan = 3, RowSpan = 4 }
        }, new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, Converters = { new JsonStringEnumConverter() } });

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal($$$"""{"kind":"Qr","fileId":"{{{fileId}}}","position":{"row":1,"column":1},"size":{"rowSpan":4,"columnSpan":3}}""", actual);
    }

    [Fact]
    public void TestThatWriteWritesMediaElementResponse()
    {
        var fileId = Guid.NewGuid();

        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, new MediaElementResponse
        {
            Kind = ElementKind.Media,
            FileId = fileId,
            FileUrl = "https://unit.test/image.jpg",
            Position = new() { Column = 1, Row = 1 },
            Size = new() { ColumnSpan = 3, RowSpan = 4 }
        }, new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, Converters = { new JsonStringEnumConverter() } });

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal($$$"""{"kind":"Media","fileUrl":"https://unit.test/image.jpg","fileId":"{{{fileId}}}","position":{"row":1,"column":1},"size":{"rowSpan":4,"columnSpan":3}}""", actual);
    }

    [Fact]
    public void TestThatWriteWritesMediaElementDto()
    {
        var fileId = Guid.NewGuid();

        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, new MediaElementDto
        {
            Kind = ElementKind.Media,
            FileId = fileId,
            Position = new() { Column = 1, Row = 1 },
            Size = new() { ColumnSpan = 3, RowSpan = 4 }
        }, new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, Converters = { new JsonStringEnumConverter() } });

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal($$$"""{"kind":"Media","fileId":"{{{fileId}}}","position":{"row":1,"column":1},"size":{"rowSpan":4,"columnSpan":3}}""", actual);
    }

    [Fact]
    public void TestThatWriteWritesUpcomingEventsElementDto()
    {
        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, new UpcomingEventsElementDto
        {
            Kind = ElementKind.UpcomingEvents,
            Amount = 4,
            Position = new() { Column = 2, Row = 2 },
            Size = new() { ColumnSpan = 3, RowSpan = 4 }
        }, new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, Converters = { new JsonStringEnumConverter() } });

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal("""{"kind":"UpcomingEvents","amount":4,"position":{"row":2,"column":2},"size":{"rowSpan":4,"columnSpan":3}}""", actual);
    }

    [Fact]
    public void TestThatWriteThrowsArgumentExceptionOnUnsupportedObject()
    {
        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        Assert.Throws<ArgumentException>(() =>
        {
            _sut.Write(writer, new UnitTestElement
            {
                Kind = ElementKind.UpcomingEvents,
                Position = new() { Column = 2, Row = 2 },
                Size = new() { ColumnSpan = 3, RowSpan = 4 }
            }, new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, Converters = { new JsonStringEnumConverter() } });
        });
    }

    #region Unit Test Classes

    private class UnitTestElement : TicketDesignElementDto
    {
    }

    #endregion
}