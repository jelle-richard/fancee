﻿using EventService.Dtos.Requests.Event;
using EventService.Utils.Adapter;

namespace EventService.Tests.Utils.Adapter;

public class AddressAdapterTests
{
    [Fact]
    public void TestThatToAddressReturnsNullWhenNullIsGiven()
    {
        CreateEventAddressRequest? request = null;

        var actual = request.ToAddress();

        Assert.Null(actual);
    }

    [Fact]
    public void TestThatToAddressReturnsNullOnEmptyCreateEventAddressRequest()
    {
        var request = new CreateEventAddressRequest();

        var actual = request.ToAddress();

        Assert.Null(actual);
    }

    [Fact]
    public void TestThatToAddressConvertsCreateAddressRequestToAddress()
    {
        const string venue = "my-venue";
        const string country = "NL";
        const string city = "my-city";
        const string postalCode = "1234AB";
        const string street = "my-street";
        const string houseNumber = "85fe";
        const decimal latitude = (decimal)51.895420;
        const decimal longitude = (decimal)4.530047;

        var input = new CreateEventAddressRequest
        {
            Venue = venue,
            CountryCode = country,
            City = city,
            PostalCode = postalCode,
            Street = street,
            HouseNumber = houseNumber,
            Latitude = latitude,
            Longitude = longitude
        };

        var actual = input.ToAddress();

        Assert.NotNull(actual);
        Assert.Equal(venue, actual!.Venue);
        Assert.Equal(country, actual.CountryCode);
        Assert.Equal(city, actual.City);
        Assert.Equal(postalCode, actual.PostalCode);
        Assert.Equal(street, actual.Street);
        Assert.Equal(houseNumber, actual.HouseNumber);
        Assert.Equal(latitude, actual.Latitude);
        Assert.Equal(longitude, actual.Longitude);
    }
}