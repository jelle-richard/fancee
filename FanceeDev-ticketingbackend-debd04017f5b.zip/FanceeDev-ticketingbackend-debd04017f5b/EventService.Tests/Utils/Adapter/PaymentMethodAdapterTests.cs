﻿using System.Collections.Generic;
using System.Linq;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses.Event;
using WebApiCore.Exceptions.Payment;
using WebApiCore.Utils.Adapter.PaymentMethod;

namespace EventService.Tests.Utils.Adapter;

public class PaymentMethodAdapterTests
{
    private readonly PaymentMethod _validPaymentMethod = new()
    {
        Name = "UnitTestMethod",
        Provider = PaymentProvider.Adyen,
        FeeStaticCents = 124,
        FeePercentage = 1.03m,
        Active = true,
        Order = 1
    };

    [Theory]
    [InlineData(PaidBy.Client, PaidByDto.Client)]
    [InlineData(PaidBy.Organization, PaidByDto.Organization)]
    [InlineData(null, null)]
    public void TestThatToPaidByDtoReturnsMappedPaidBy(PaidBy? input, PaidByDto? expected)
    {
        var actual = input.ToPaidByDto();

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(PaymentProvider.Adyen, PaymentProviderDto.Adyen)]
    public void TestThatToPaymentProviderDtoReturnsMappedPaymentProvider(PaymentProvider input, PaymentProviderDto expected)
    {
        var actual = input.ToPaymentProviderDto();

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(PaidBy.Client, PaidByDto.Client)]
    [InlineData(PaidBy.Organization, PaidByDto.Organization)]
    public void TestThatToAvailablePaymentMethodResponseReturnsMappedAvailablePaymentMethodResponse(PaidBy? paidBy, PaidByDto expectedPaidBy)
    {
        var method = (_validPaymentMethod, paidBy);

        var actual = method.ToAvailablePaymentMethodResponse();

        Assert.NotNull(actual);
        Assert.Equal(expectedPaidBy, actual.PaidBy);
        Assert.Equal("UnitTestMethod", actual.Name);
        Assert.Equal(124, actual.FeeStaticCents);
        Assert.Equal(1.03m, actual.FeePercentage);
        Assert.Equal(PaymentProviderDto.Adyen, actual.Provider);
    }

    [Fact]
    public void TestThatToAvailablePaymentMethodResponsesMapsMultiplePaymentMethods()
    {
        var methods = new List<(PaymentMethod, PaidBy?)>
        {
            (_validPaymentMethod, PaidBy.Client),
            (_validPaymentMethod, PaidBy.Organization)
        };

        var actual = methods.ToAvailablePaymentMethodResponses().ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal(PaidByDto.Client, actual[0].PaidBy);
        Assert.Equal(PaidByDto.Organization, actual[1].PaidBy);
    }

    [Theory]
    [InlineData(PaidByDto.Client, PaidBy.Client)]
    [InlineData(PaidByDto.Organization, PaidBy.Organization)]
    public void TestThatToPaidByReturnsCorrectMapping(PaidByDto? input, PaidBy expected)
    {
        var actual = input.ToPaidBy();

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatToPaidByThrowsInvalidPaidByExceptionOnNull()
    {
        PaidByDto? input = null;

        // ReSharper disable once ExpressionIsAlwaysNull
        Assert.Throws<InvalidPaidByException>(() => input.ToPaidBy());
    }
}