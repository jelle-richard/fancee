﻿using System;
using System.Collections.Generic;
using System.Linq;
using EventService.Utils.Adapter;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Shared.Product;

namespace EventService.Tests.Utils.Adapter;

public class ProductAdapterTests
{
    [Fact]
    public void TestThatToProductReturnsProduct()
    {
        var productItem = new ProductDto
        {
            Name = "UnitProduct",
            PriceCents = 2495,
            Stock = 100,
            TicketOptions = null,
            Type = ProductType.Product,
            SaleStart = DateTime.UtcNow.AddMinutes(-1),
            SaleEnd = DateTime.UtcNow.AddMinutes(1)
        };

        var actual = productItem.ToProduct(Guid.NewGuid());

        Assert.NotNull(actual);
        Assert.Equal(productItem.Name, actual.Name);
        Assert.Equal(productItem.PriceCents, actual.PriceCents);
        Assert.Equal(productItem.Stock, actual.Stock);
        Assert.True(DateTime.UtcNow >= actual.SaleStart);
        Assert.True(DateTime.UtcNow <= actual.SaleEnd);
    }

    [Fact]
    public void TestThatToProductReturnsProductWithTicketOption()
    {
        var productItem = new ProductDto
        {
            Name = "UnitProduct",
            PriceCents = 2495,
            Stock = 100,
            TicketOptions = new()
            {
                Swappable = true,
                MaximumPreArrivalTimeMinutes = 10,
                ScanNotification = "Hello"
            },
            Type = ProductType.Ticket,
            SaleStart = DateTime.UtcNow.AddMinutes(-1),
            SaleEnd = DateTime.UtcNow.AddMinutes(1)
        };

        var actual = productItem.ToProduct(Guid.NewGuid());

        Assert.NotNull(actual);
        Assert.Equal(productItem.Name, actual.Name);
        Assert.Equal(productItem.PriceCents, actual.PriceCents);
        Assert.Equal(productItem.Stock, actual.Stock);
        Assert.True(DateTime.UtcNow >= actual.SaleStart);
        Assert.True(DateTime.UtcNow <= actual.SaleEnd);
        Assert.True(actual.TicketOption.Swappable);
        Assert.Null(actual.TicketOption.PartialAccessStart);
        Assert.Null(actual.TicketOption.PartialAccessEnd);
        Assert.Equal(productItem.TicketOptions.MaximumPreArrivalTimeMinutes, actual.TicketOption.MaximumPreArrivalTimeMinutes);
        Assert.Equal(productItem.TicketOptions.ScanNotification, actual.TicketOption.ScanNotification);
    }

    [Fact]
    public void TestThatToIdentifiedProductDtoReturnsIdentifiedProductDto()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        var product = new Product
        {
            Id = productId,
            Name = "UnitProduct",
            Description = "Test",
            Stock = 10000,
            Event = new(),
            PriceCents = 192595,
            Type = ProductType.Product,
            ProductMedia = new List<ProductMedia>
            {
                new() { ProductId = productId, Position = 1, FileId = fileId, File = new() { Id = fileId, Path = "uploads/unit/test.png" } }
            },
            WaveLinkedProductId = Guid.NewGuid(),
            ItemInShops = new List<ItemInShop>(),
            ApplicableDiscounts = new List<DiscountApplicableTo>(),
            IssuedProducts = new List<IssuedProduct>(),
            FeeCents = 123,
            SaleStart = DateTime.UtcNow,
            SaleEnd = DateTime.UtcNow,
            MaximumPurchasePerOrder = 1,
            IsSharedCapacityEligible = true,
            MarkSoldOutOnSaleWindowExpired = true,
            PackQuantity = 1
        };

        var actual = product.ToIdentifiedProductDto(new() { ContentDeliveryNetworkBaseUrl = "localhost", Id = Guid.NewGuid(), IsHttps = false, Name = "unittest", RemoteIpAddress = null });

        Assert.NotNull(actual);
        Assert.Equal(product.Id, actual!.Id);
        Assert.Equal(product.Name, actual.Name);
        Assert.Equal(product.Stock, actual.Stock);
        Assert.Equal(product.PriceCents, actual.PriceCents);
        Assert.NotEmpty(actual.Media);
        Assert.False(actual.Deletable);
        Assert.Equal("http://localhost/uploads/unit/test.png", actual.Media.First().Url);
        Assert.Equal(fileId, actual.Media.First().Id);
    }

    [Fact]
    public void TestThatToIdentifiedProductDtoReturnsIdentifiedProductDtoWithTicketOptions()
    {
        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = "UnitProduct",
            Description = "Test",
            Stock = 10000,
            Event = new(),
            PriceCents = 192595,
            Type = ProductType.Ticket,
            TicketOption = new()
            {
                Swappable = false,
                MaximumPreArrivalTimeMinutes = 9
            },
            WaveLinkedProductId = Guid.NewGuid(),
            ItemInShops = new List<ItemInShop>(),
            ApplicableDiscounts = new List<DiscountApplicableTo>(),
            IssuedProducts = new List<IssuedProduct>(),
            FeeCents = 123,
            SaleStart = DateTime.UtcNow,
            SaleEnd = DateTime.UtcNow,
            MaximumPurchasePerOrder = 1,
            IsSharedCapacityEligible = true,
            MarkSoldOutOnSaleWindowExpired = true,
            PackQuantity = 1
        };

        var actual = product.ToIdentifiedProductDto(new() { ContentDeliveryNetworkBaseUrl = "localhost", Id = Guid.NewGuid(), IsHttps = true, Name = "unittest", RemoteIpAddress = null });

        Assert.NotNull(actual);
        Assert.Equal(product.Id, actual!.Id);
        Assert.Equal(product.Name, actual.Name);
        Assert.Equal(product.Stock, actual.Stock);
        Assert.Equal(product.PriceCents, actual.PriceCents);
        Assert.False(actual.TicketOptions.Swappable);
        Assert.False(actual.Deletable);
        Assert.Equal(product.TicketOption.MaximumPreArrivalTimeMinutes, actual.TicketOptions.MaximumPreArrivalTimeMinutes);
    }

    [Fact]
    public void TestThatToIdentifiedProductDtosReturnsListOfIdentifiedProductDtos()
    {
        var products = new List<Product>
        {
            new()
            {
                Id = Guid.NewGuid(),
                Name = "UnitProduct",
                Description = "Test",
                Stock = 10000,
                Event = new(),
                PriceCents = 192595,
                Type = ProductType.Product,
                WaveLinkedProductId = Guid.NewGuid(),
                ItemInShops = new List<ItemInShop>(),
                ApplicableDiscounts = new List<DiscountApplicableTo>(),
                IssuedProducts = new List<IssuedProduct>(),
                FeeCents = 123,
                SaleStart = DateTime.UtcNow,
                SaleEnd = DateTime.UtcNow,
                MaximumPurchasePerOrder = 1,
                IsSharedCapacityEligible = true,
                MarkSoldOutOnSaleWindowExpired = true,
                PackQuantity = 1
            },
            new()
            {
                Id = Guid.NewGuid(),
                Name = "Product B",
                Description = null,
                Stock = 10000,
                Event = new(),
                PriceCents = 532,
                Type = ProductType.Product,
                WaveLinkedProductId = Guid.NewGuid(),
                ItemInShops = new List<ItemInShop>(),
                ApplicableDiscounts = new List<DiscountApplicableTo>(),
                IssuedProducts = new List<IssuedProduct>(),
                FeeCents = 123,
                SaleStart = DateTime.UtcNow,
                SaleEnd = DateTime.UtcNow,
                MaximumPurchasePerOrder = 1,
                IsSharedCapacityEligible = true,
                MarkSoldOutOnSaleWindowExpired = true,
                PackQuantity = 1
            }
        };

        var actual = products.ToIdentifiedProductDtos(new() { ContentDeliveryNetworkBaseUrl = "localhost", Id = Guid.NewGuid(), IsHttps = true, Name = "unittest", RemoteIpAddress = null }).ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal("UnitProduct", actual[0].Name);
        Assert.Equal("Product B", actual[1].Name);
    }

    [Fact]
    public void TestThatToEventProductShopsResponseReturnsEventProductShopsResponse()
    {
        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = "Test product",
            ProductMedia = new List<ProductMedia>
            {
                new()
                {
                    File = new()
                    {
                        Id = Guid.NewGuid()
                    }
                }
            },
            ItemInShops = new List<ItemInShop>
            {
                new()
                {
                    Shop = new()
                    {
                        Name = "Test shop"
                    }
                }
            },
            AccordionShopElements = new List<AccordionShopElement>
            {
                new()
                {
                    AccordionElement = new()
                    {
                        ItemInShop = new()
                        {
                            Shop = new()
                            {
                                Name = "Another shop"
                            }
                        }
                    }
                },
                new()
                {
                    AccordionElement = new()
                    {
                        ItemInShop = new()
                        {
                            Shop = new()
                            {
                                Name = "Test shop"
                            }
                        }
                    }
                }
            }
        };

        var actual = product.ToEventProductShopsResponse(new() { ContentDeliveryNetworkBaseUrl = "localhost", Id = Guid.NewGuid(), IsHttps = true, Name = "unittest", RemoteIpAddress = null });
        var actualShops = actual.Shops.ToList();

        Assert.NotNull(actual.Name);
        Assert.NotNull(actual.Media);
        Assert.NotEmpty(actual.Shops);
        Assert.Equal(2, actualShops.Count);
        Assert.Equal("Test shop", actualShops[0]);
        Assert.Equal("Another shop", actualShops[1]);
    }

    [Fact]
    public void TestThatToIdentifiedProductDtoReturnsDeletableTrue()
    {
        var product = new Product
        {
            Id = Guid.NewGuid(),
            Name = "UnitProduct",
            WaveLinkedProductId = null,
            ItemInShops = new List<ItemInShop>(),
            ApplicableDiscounts = new List<DiscountApplicableTo>(),
            IssuedProducts = new List<IssuedProduct>(),
            Type = ProductType.Product,
            Stock = 10000,
            Event = new(),
            PriceCents = 192595,
            ProductMedia = new List<ProductMedia>
            {
                new() { ProductId = Guid.NewGuid(), Position = 1, FileId = Guid.NewGuid(), File = new() { Id = Guid.NewGuid(), Path = "uploads/unit/test.png" } }
            },
            FeeCents = 123,
            Description = "",
            SaleStart = DateTime.UtcNow,
            SaleEnd = DateTime.UtcNow,
            MaximumPurchasePerOrder = 1,
            IsSharedCapacityEligible = true,
            MarkSoldOutOnSaleWindowExpired = true,
            PackQuantity = 1
        };

        var actual = product.ToIdentifiedProductDto(new() { ContentDeliveryNetworkBaseUrl = "localhost", Id = Guid.NewGuid(), IsHttps = true, Name = "unittest", RemoteIpAddress = null });

        Assert.True(actual.Deletable);
    }
}