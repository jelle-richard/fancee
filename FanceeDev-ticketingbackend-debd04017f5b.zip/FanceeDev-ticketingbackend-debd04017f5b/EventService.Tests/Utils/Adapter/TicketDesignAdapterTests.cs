using System;
using System.Collections.Generic;
using System.Linq;
using EventService.Dtos.Responses.Ticket;
using EventService.Dtos.Shared.Ticket;
using EventService.Utils.Adapter;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Utils.Adapter;

public class TicketDesignAdapterTests
{
    private static readonly Guid[] FileIds = { Guid.NewGuid(), Guid.NewGuid() };

    [Fact]
    public void TestThatToTicketDesignDtosMapsTicketDesigns()
    {
        var ticketDesigns = new (IEnumerable<Guid>, TicketDesign)[]
        {
            new(new[] { Guid.Empty }, new()
            {
                DesignElements = new TicketDesignElement[]
                {
                    new TicketDesignMediaElement
                    {
                        FileId = FileIds[0],
                        File = new() { Path = "file1.png" },
                        Row = 1,
                        Column = 1,
                        RowSpan = 1,
                        ColumnSpan = 1
                    },
                    new TicketDesignUpcomingEventsElement
                    {
                        Amount = 2,
                        Row = 1,
                        Column = 2,
                        RowSpan = 1,
                        ColumnSpan = 2
                    },
                    new TicketDesignQrElement
                    {
                        FileId = FileIds[1],
                        File = new() { Path = "file2.jpg" },
                        Row = 2,
                        Column = 2,
                        RowSpan = 2,
                        ColumnSpan = 2
                    }
                }
            })
        };

        var actual = ticketDesigns.ToTicketDesignDtos("https://unit.test").ToList();

        Assert.Single(actual);
        Assert.Single(actual[0].TicketIds!);
        Assert.IsType<MediaElementResponse>(actual[0].Elements![0]);
        Assert.IsType<UpcomingEventsElementDto>(actual[0].Elements![1]);
        Assert.IsType<QrElementResponse>(actual[0].Elements![2]);

        var actualMedia = (MediaElementResponse)actual[0].Elements![0];
        var actualUpcomingEvents = (UpcomingEventsElementDto)actual[0].Elements![1];
        var actualQr = (QrElementResponse)actual[0].Elements![2];

        Assert.Equal(ElementKind.Media, actualMedia.Kind);
        Assert.Equal(FileIds[0], actualMedia.FileId);
        Assert.Equal("https://unit.test/file1.png", actualMedia.FileUrl);

        Assert.Equal(ElementKind.UpcomingEvents, actualUpcomingEvents.Kind);
        Assert.Equal(2, actualUpcomingEvents.Amount);

        Assert.Equal(ElementKind.Qr, actualQr.Kind);
        Assert.Equal(FileIds[1], actualQr.FileId);
        Assert.Equal("https://unit.test/file2.jpg", actualQr.FileUrl);
    }

    [Fact]
    public void TestThatToTicketDesignDtosAllowsNullForQrFile()
    {
        var ticketDesigns = new (IEnumerable<Guid>, TicketDesign)[]
        {
            new(new[] { Guid.Empty }, new()
            {
                DesignElements = new TicketDesignElement[]
                {
                    new TicketDesignQrElement
                    {
                        FileId = null,
                        File = null,
                        Row = 2,
                        Column = 2,
                        RowSpan = 2,
                        ColumnSpan = 2
                    }
                }
            })
        };

        var actual = ticketDesigns.ToTicketDesignDtos("https://unit.test").ToList();

        Assert.Single(actual);
        Assert.Single(actual[0].TicketIds!);
        Assert.Single(actual[0].Elements!);
        Assert.IsType<QrElementResponse>(actual[0].Elements![0]);

        var actualQr = (QrElementResponse)actual[0].Elements![0];

        Assert.NotNull(actualQr);
        Assert.Null(actualQr.FileId);
        Assert.Null(actualQr.FileUrl);
    }
}