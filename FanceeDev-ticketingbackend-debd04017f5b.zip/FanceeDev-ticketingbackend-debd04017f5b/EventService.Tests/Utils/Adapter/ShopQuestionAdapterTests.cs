using System;
using System.Collections.Generic;
using System.Linq;
using EventService.Dtos.Requests.Shop;
using EventService.Utils.Adapter;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Utils.Adapter;

public class ShopQuestionAdapterTests
{
    [Fact]
    public void TestThatToShopQuestionReturnsShopQuestion()
    {
        var request = new ShopQuestionRequest
        {
            Required = true,
            Question = "What's the answer to life, the universe and everything?",
            Type = ShopQuestionType.Choice,
            Choices = new List<ShopQuestionChoiceDto>
            {
                new()
                {
                    Value = "42"
                },
                new()
                {
                    Value = "That's not a question"
                },
                new()
                {
                    Value = "A towel, it says, is about the most massively useful thing an interstellar hitchhiker can have"
                }
            }
        };

        var shopQuestion = request.ToShopQuestion("ShopCode");

        Assert.NotNull(shopQuestion);
        Assert.Equal("ShopCode", shopQuestion.ShopCode);
        Assert.True(shopQuestion.Required);
        Assert.Equal("What's the answer to life, the universe and everything?", shopQuestion.Question);
        Assert.Equal(ShopQuestionType.Choice, shopQuestion.Type);
        Assert.Equal(3, shopQuestion.ShopQuestionChoices.Count);

        var choices = shopQuestion.ShopQuestionChoices.ToList();

        Assert.Equal("42", choices[0].Value);
        Assert.Equal("That's not a question", choices[1].Value);
        Assert.Equal("A towel, it says, is about the most massively useful thing an interstellar hitchhiker can have", choices[2].Value);
    }

    [Fact]
    public void TestThatToShopQuestionReturnsShopQuestionWithId()
    {
        var request = new ShopQuestionRequest
        {
            Required = true,
            Question = "Is it true that we have to unit test everything?",
            Type = ShopQuestionType.Choice,
            Choices = new List<ShopQuestionChoiceDto>
            {
                new()
                {
                    Value = "Yes."
                },
                new()
                {
                    Value = "Very yes."
                },
                new()
                {
                    Value = "Ja."
                }
            }
        };

        var shopQuestionId = Guid.NewGuid();
        var shopQuestion = request.ToShopQuestion("ShopCode", shopQuestionId);

        Assert.NotNull(shopQuestion);
        Assert.Equal("ShopCode", shopQuestion.ShopCode);
        Assert.True(shopQuestion.Required);
        Assert.Equal("Is it true that we have to unit test everything?", shopQuestion.Question);
        Assert.Equal(ShopQuestionType.Choice, shopQuestion.Type);
        Assert.Equal(3, shopQuestion.ShopQuestionChoices.Count);
        Assert.Equal(shopQuestionId, shopQuestion.Id);

        var choices = shopQuestion.ShopQuestionChoices.ToList();

        Assert.Equal("Yes.", choices[0].Value);
        Assert.Equal("Very yes.", choices[1].Value);
        Assert.Equal("Ja.", choices[2].Value);
    }
}