using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using EventService.Dtos.Requests.Shop;
using EventService.Services.Exceptions;
using EventService.Utils.Adapter;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Shared.ShopElement;

namespace EventService.Tests.Utils.Adapter;

public class ShopAdapterTests
{
    [Fact]
    public void TestThatToShopReturnsShop()
    {
        var start = DateTime.UtcNow;
        var end = DateTime.UtcNow.AddDays(1);

        var request = new ConfigureShopRequest
        {
            StartDate = start,
            EndDate = end,
            Layout = ShopLayout.List,
            Name = "First Shop",
            ShopFields = new List<ShopFieldRequirementRequest>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                },
                new()
                {
                    Field = ShopField.FirstName,
                    Enabled = true,
                    Required = false
                },
                new()
                {
                    Field = ShopField.LastName,
                    Enabled = true,
                    Required = false
                }
            },
            Active = true,
            Design = new()
            {
                PrimaryColor = "#FFFFFF",
                BackdropColor = "#FFFFFF",
                BackgroundColor = "#FFFFFF",
                TextColor = "#FFFFFF"
            },
            Analytics = new()
            {
                TiktokPixelId = null,
                GoogleAnalyticsId = "G-UnitAnalyticsIds",
                FacebookAccessCode = "fb-access",
                FacebookPixelId = "fb-pixel"
            }
        };

        var actual = request.ToShop(Guid.NewGuid(), "UnitCode");

        Assert.NotNull(actual);
        Assert.Equal(start, actual.StartDate);
        Assert.Equal(end, actual.EndDate);
        Assert.Equal(request.Layout, actual.Layout);
        Assert.Equal(request.Name, actual.Name);
        Assert.Equal(request.Design.PrimaryColor, actual.ShopDesign.PrimaryColor);
        Assert.Equal(request.Design.BackdropColor, actual.ShopDesign.BackdropColor);
        Assert.Equal(request.Design.BackgroundColor, actual.ShopDesign.BackgroundColor);
        Assert.Equal(request.Design.TextColor, actual.ShopDesign.TextColor);
        Assert.Equal(request.Analytics.GoogleAnalyticsId, actual.GoogleAnalyticsId);
        Assert.Equal(request.Analytics.FacebookPixelId, actual.FacebookPixelId);
        Assert.Equal(request.Analytics.FacebookAccessCode, actual.FacebookAccessCode);
        Assert.Null(actual.TikTokPixelId);
    }

    [Fact]
    public void TestThatToShopResponseReturnsShopResponse()
    {
        var fileId = Guid.NewGuid();

        var shop = new Shop
        {
            Name = "UnitTest",
            Code = "jdfej9fj",
            Layout = ShopLayout.Webshop,
            Active = true,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1),
            NumberOfViews = 100,
            ShopDesign = new()
            {
                PrimaryColor = "FFFFFF",
                TextColor = "FFF000",
                BackdropColor = "000FFF",
                BackgroundColor = "F0F0F0",
                BackgroundMediaFile = new() { Id = Guid.NewGuid(), Path = "backgrounds/jdiwj.png" },
                HeaderMedia = new List<ShopDesignHeaderMedia>
                {
                    new()
                    {
                        FileId = fileId,
                        Position = 1,
                        File = new()
                        {
                            Id = fileId,
                            Path = "headers/jdfijwef.gif"
                        },
                        FocalPointWidthPercentage = 55,
                        FocalPointHeightPercentage = 50
                    }
                }
            },
            ItemsInShop = new List<ItemInShop>
            {
                new() { Position = 2, ProductId = Guid.Empty },
                new() { Position = 3, ShopElement = new ExternalLinkElement { Link = "unit.test" } },
                new()
                {
                    Position = 1, ShopElement = new AccordionElement
                    {
                        Icon = "trash",
                        Title = "Parking Tickets",
                        Elements = new AccordionShopElement[]
                        {
                            new() { Position = 2, ProductId = Guid.Empty },
                            new() { Position = 1, ShopElement = new NoticeElement { Content = "Doetinchem Centraal Parking", Variant = NoticeVariant.Info } }
                        }
                    }
                }
            },
            ShopFieldRequirements = new List<ShopFieldRequirement>
            {
                new()
                {
                    Field = ShopField.Email,
                    Required = true,
                    Enabled = true
                }
            },
            TikTokPixelId = null,
            GoogleAnalyticsId = "G-UnitAnalyticsIds"
        };

        var actual = shop.ToShopResponse(new()
        {
            Id = Guid.NewGuid(),
            ContentDeliveryNetworkBaseUrl = "localhost",
            Name = "localhost",
            RemoteIpAddress = IPAddress.Parse("127.0.0.1")
        });

        Assert.NotNull(actual);
        Assert.Equal(shop.Name, actual.Name);
        Assert.Equal(shop.Code, actual.Code);
        Assert.Equal(shop.Layout, actual.Layout);
        Assert.Equal(shop.Active, actual.Active);
        Assert.Equal(shop.StartDate, actual.StartDate);
        Assert.Equal(shop.EndDate, actual.EndDate);
        Assert.Equal(shop.NumberOfViews, actual.NumberOfViews);
        Assert.NotNull(actual.Design);
        Assert.Equal(shop.ShopDesign.PrimaryColor, actual.Design.PrimaryColor);
        Assert.Equal(shop.ShopDesign.TextColor, actual.Design.TextColor);
        Assert.Equal(shop.ShopDesign.BackdropColor, actual.Design.BackdropColor);
        Assert.Equal(shop.ShopDesign.BackgroundColor, actual.Design.BackgroundColor);
        Assert.Equal(shop.ShopDesign.BackgroundMediaFile.Id, actual.Design.BackgroundMedia?.Id);
        Assert.Equal(shop.ShopDesign.HeaderMedia.First().FocalPointWidthPercentage, actual.Design.HeaderMedia.First().FocalPointWidthPercentage);
        Assert.Equal(shop.ShopDesign.HeaderMedia.First().FocalPointHeightPercentage, actual.Design.HeaderMedia.First().FocalPointHeightPercentage);
        Assert.Equal("http://localhost/backgrounds/jdiwj.png", actual.Design.BackgroundMedia?.Url);
        Assert.False(actual.Secured);
        Assert.Null(actual.SecuredUntil);

        actual.Design.HeaderMedia = actual.Design.HeaderMedia.ToList();
        Assert.Single(actual.Design.HeaderMedia);
        Assert.Single(actual.ShopFields);
        Assert.Equal(ShopField.Email, actual.ShopFields.First().Field);
        Assert.Equal(shop.ShopDesign.HeaderMedia.First().FileId, actual.Design.HeaderMedia.First().Id);
        Assert.Equal("http://localhost/headers/jdfijwef.gif", actual.Design.HeaderMedia.First().Url);
        Assert.Equal("G-UnitAnalyticsIds", actual.Analytics.GoogleAnalyticsId);
        Assert.Null(actual.Analytics.TiktokPixelId);

        Assert.Equal(3, actual.Elements.Count);
        Assert.IsType<IdentifiedAccordionElementDto>(actual.Elements[0]);
        Assert.IsType<ProductElementDto>(actual.Elements[1]);
        Assert.IsType<IdentifiedExternalLinkElementDto>(actual.Elements[2]);

        var actualAccordionElement = (IdentifiedAccordionElementDto)actual.Elements[0];
        Assert.NotNull(actualAccordionElement.Elements);
        Assert.Equal(2, actualAccordionElement.Elements.Count);
        Assert.IsType<IdentifiedNoticeElementDto>(actualAccordionElement.Elements[0]);
        Assert.IsType<ProductElementDto>(actualAccordionElement.Elements[1]);
    }

    [Fact]
    public void TestThatToShopResponseWithoutMediaReturnsNullOrEmptyValues()
    {
        var shop = new Shop
        {
            Name = "UnitTest",
            Code = "jdfej9fj",
            Layout = ShopLayout.Webshop,
            Active = true,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1),
            IsSecuredUntil = DateTime.UtcNow.AddDays(1),
            ShopDesign = new()
            {
                PrimaryColor = "FFFFFF",
                TextColor = "FFF000",
                BackdropColor = "000FFF",
                BackgroundColor = "F0F0F0",
                BackgroundMediaFile = null,
                HeaderMedia = null
            },
            ItemsInShop = new List<ItemInShop>()
        };

        var actual = shop.ToShopResponse(new()
        {
            Id = Guid.NewGuid(),
            ContentDeliveryNetworkBaseUrl = "localhost",
            Name = "localhost",
            RemoteIpAddress = IPAddress.Parse("127.0.0.1")
        });

        Assert.NotNull(actual);
        Assert.Null(actual.Design.BackgroundMedia);
        Assert.Empty(actual.Design.HeaderMedia);
        Assert.True(actual.Secured);
        Assert.True(actual.SecuredUntil > DateTime.UtcNow);
    }

    [Fact]
    public void TestThatFromItemsInShopConvertsItemsToIdentifiedDtos()
    {
        var productId = Guid.NewGuid();

        var items = new List<ItemInShop>
        {
            new() { Id = Guid.NewGuid(), Position = 2, ShopElement = new DividerElement { Id = Guid.NewGuid(), Name = "UnitDivider" } },
            new() { Id = Guid.NewGuid(), Position = 1, ShopElement = new ExternalLinkElement { Id = Guid.NewGuid(), Link = "https://google.com" } },
            new() { Id = Guid.NewGuid(), Position = 3, ShopElement = new NoticeElement { Id = Guid.NewGuid(), Variant = NoticeVariant.Warning, Content = "Unittest" } },
            new() { Id = Guid.NewGuid(), Position = 4, ShopElement = new TextBlockElement { Id = Guid.NewGuid(), Text = "Text", Title = "Title" } },
            new() { Id = Guid.NewGuid(), Position = 5, ProductId = productId, Product = new() { Id = productId } },
            new() { Id = Guid.NewGuid(), Position = 6, ShopElement = new SeatingMapElement { Id = Guid.NewGuid() } }
        };

        var actual = items.ToShopElementDtos().ToList();

        Assert.Equal(6, actual.Count);
        Assert.IsType<IdentifiedExternalLinkElementDto>(actual[0]);
        Assert.IsType<IdentifiedDividerElementDto>(actual[1]);
        Assert.IsType<IdentifiedNoticeElementDto>(actual[2]);
        Assert.IsType<IdentifiedTextBlockElementDto>(actual[3]);
        Assert.IsType<ProductElementDto>(actual[4]);
        Assert.IsType<IdentifiedSeatingMapElementDto>(actual[5]);
    }

    [Fact]
    public void TestThatToShopMailReturnsMappedShopMail()
    {
        var request = new UpdateShopMailRequest
        {
            Type = UpdateShopMailRequest.MailType.Purchase,
            Content = "<h1>Content</h1>",
            SenderName = "Sender Name",
            Subject = "Unit shop mail subject"
        };

        var actual = request.ToShopMail("Shop Code 1");

        Assert.NotNull(actual);
        Assert.Equal("Shop Code 1", actual.ShopCode);
        Assert.Equal(ShopMailType.Purchase, actual.Type);
        Assert.Equal("Sender Name", actual.SenderName);
        Assert.Equal("<h1>Content</h1>", actual.Content);
    }

    [Fact]
    public void TestThatToShopElementDtosThrowsInvalidShopElementExceptionOnUnsupportedElement()
    {
        var dtos = new ItemInShop[] { new() { ShopElement = new UnitTestElement() } };

        Assert.Throws<InvalidShopElementException>(() => dtos.ToShopElementDtos().ToList());
    }

    #region Unit Test Classes

    private class UnitTestElement : ShopElement
    {
        public override object Clone() => new UnitTestElement();
    }

    #endregion
}