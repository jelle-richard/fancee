using System;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Shared.Event;
using EventService.Utils.Adapter;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;
using WebApiCore.Dtos.Responses;

namespace EventService.Tests.Utils.Adapter;

[TestSubject(typeof(EventAdapter))]
public class EventAdapterTests
{
    private const string Description = "Event used for unittesting";
    private const string Name = "UnitTest Event";
    private static readonly Guid UserId = Guid.NewGuid();

    [Fact]
    public async Task TestThatToEventWithoutCategoriesReturnsEventWithoutCategories()
    {
        var start = DateTime.Now.AddMinutes(5);
        var end = DateTime.Now.AddDays(1);

        var input = new EventRequest
        {
            Address = null,
            Categories = Array.Empty<string>(),
            Tags = Array.Empty<string>(),
            Description = Description,
            EndDate = end,
            Name = Name,
            StartDate = start,
            Type = EventType.Normal
        };

        var response = new ApiResponse<object>();

        await input.Prepare(UserId, response, null, null, null, null);

        var actual = input.ToEvent(8);

        Assert.NotNull(actual);
        Assert.Equal(Name, actual.Name);
        Assert.Equal(Description, actual.Description);
        Assert.Equal(UserId, actual.OrganizationId);
        Assert.Equal(start, actual.StartDate);
        Assert.Equal(end, actual.EndDate);
        Assert.Null(actual.Address);
    }

    [Fact]
    public async Task TestThatToEventSetsSeatsIoEventId()
    {
        var seatsIoEventId = Guid.NewGuid();

        var request = new EventRequest
        {
            Address = null,
            Categories = Array.Empty<string>(),
            Tags = Array.Empty<string>(),
            Description = Description,
            EndDate = DateTime.MaxValue,
            Name = Name,
            StartDate = DateTime.MinValue,
            Type = EventType.Seating,
            SeatsIoEventId = seatsIoEventId,
            TimezoneIdentification = "Europe/Amsterdam"
        };

        var response = new ApiResponse<object>();

        await request.Prepare(UserId, response, null, null, null, null);

        var actual = request.ToEvent(25);

        Assert.NotNull(actual);
        Assert.Equal(25, actual.ReservationTimeMinutes);
        Assert.Equal(EventType.Seating, actual.Type);
        Assert.Equal(seatsIoEventId, request.SeatsIoEventId);
        Assert.Null(response.Errors);
    }

    [Fact]
    public void TestThatToEventMailReturnsMappedEventMail()
    {
        var eventId = Guid.NewGuid();
        var request = new UpdateEventMailRequest
        {
            Type = MailType.GuestList,
            Content = "<h1>Content</h1>",
            SenderName = "Sender Name"
        };

        var actual = request.ToEventMail(eventId);

        Assert.NotNull(actual);
        Assert.Equal(eventId, actual.EventId);
        Assert.Equal(EventMailType.GuestList, actual.Type);
        Assert.Equal("Sender Name", actual.SenderName);
        Assert.Equal("<h1>Content</h1>", actual.Content);
    }

    [Theory]
    [InlineData(MailType.GuestList, EventMailType.GuestList)]
    [InlineData(MailType.DefaultShopMail, EventMailType.DefaultShopMail)]
    public void TestThatToEventMailSetsCorrectType(MailType type, EventMailType expected)
    {
        var request = new UpdateEventMailRequest
        {
            Type = type,
            Content = "",
            SenderName = ""
        };

        var actual = request.ToEventMail(Guid.Empty);

        Assert.NotNull(actual);
        Assert.Equal(expected, actual.Type);
    }
}