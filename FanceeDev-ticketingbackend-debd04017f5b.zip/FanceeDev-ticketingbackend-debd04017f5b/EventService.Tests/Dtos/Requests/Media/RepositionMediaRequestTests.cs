using System;
using System.Linq;
using EventService.Dtos.Requests.Media;

namespace EventService.Tests.Dtos.Requests.Media;

public class RepositionMediaRequestTests
{
    private readonly RepositionMediaRequest _sut = new();

    [Fact]
    public void TestThatValidateReturnsErrorIfPositionsIsEmpty()
    {
        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("At least one position record is required", actual[0].ErrorMessage);
    }

    [Fact]
    public void TestThatValidateReturnsNoErrorsOnValidPositions()
    {
        _sut.Positions = new[] { Guid.Empty };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Empty(actual);
    }
}