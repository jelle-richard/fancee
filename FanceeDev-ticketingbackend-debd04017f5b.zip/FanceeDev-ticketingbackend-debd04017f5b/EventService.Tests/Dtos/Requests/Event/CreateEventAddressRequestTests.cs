﻿using EventService.Dtos.Requests.Event;

namespace EventService.Tests.Dtos.Requests.Event;

public class CreateEventAddressRequestTests
{
    public static readonly object[][] IsEmptyFalseTestData =
    {
        new object[] { new CreateEventAddressRequest { Venue = "UnitTest" } },
        new object[] { new CreateEventAddressRequest { CountryCode = "NL" } },
        new object[] { new CreateEventAddressRequest { City = "UnitTest" } },
        new object[] { new CreateEventAddressRequest { PostalCode = "UnitTest" } },
        new object[] { new CreateEventAddressRequest { Street = "UnitTest" } },
        new object[] { new CreateEventAddressRequest { HouseNumber = "UnitTest" } },
        new object[] { new CreateEventAddressRequest { Latitude = 1m } },
        new object[] { new CreateEventAddressRequest { Longitude = 1m } }
    };

    [Fact]
    public void TestThatIsEmptyReturnsTrueOnEmptyObject()
    {
        var sut = new CreateEventAddressRequest();

        Assert.True(sut.IsEmpty());
    }

    [Theory]
    [MemberData(nameof(IsEmptyFalseTestData))]
    public void TestThatIsEmptyReturnsFalseOnObjectWithData(CreateEventAddressRequest input)
    {
        Assert.False(input.IsEmpty());
    }
}