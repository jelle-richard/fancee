using System;
using System.Linq;
using EventService.Dtos.Requests.Event;

namespace EventService.Tests.Dtos.Requests.Event;

public class EventsBalanceMutationsRequestFilterTests
{
    private readonly EventsBalanceMutationsRequestFilter _sut = new();

    [Fact]
    public void TestThatValidateReturnsErrorDifferenceBetweenDatesAboveOneYear()
    {
        _sut.DateRange = new()
        {
            Minimum = DateTime.UtcNow,
            Maximum = DateTime.UtcNow.AddYears(3)
        };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Maximum difference between the minimum- and maxmimum date is 1 year.", actual.First().ErrorMessage);
    }

    [Fact]
    public void TestThatValidateReturnsInvalidCountryCodesError()
    {
        _sut.DateRange = new()
        {
            Minimum = DateTime.UtcNow,
            Maximum = DateTime.UtcNow.AddDays(20)
        };

        _sut.CountryCodes = new[] { "NLD", "GER" };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Every country code must be exactly two characters long to comply with the ISO 3166 standard", actual.First().ErrorMessage);
    }

    [Fact]
    public void TestThatValidateReturnsNoErrorsForValidRequest()
    {
        _sut.DateRange = new()
        {
            Minimum = DateTime.UtcNow,
            Maximum = DateTime.UtcNow.AddDays(20)
        };

        _sut.CountryCodes = new[] { "NL", "DE" };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Empty(actual);
    }
}