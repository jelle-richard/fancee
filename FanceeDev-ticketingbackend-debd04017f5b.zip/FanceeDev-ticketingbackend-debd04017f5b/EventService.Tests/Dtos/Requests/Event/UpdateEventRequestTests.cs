using System;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using WebApiCore.Dtos.Responses;

namespace EventService.Tests.Dtos.Requests.Event;

public class UpdateEventRequestTests
{
    [Fact]
    public async Task TestThatUpdateEventRequestDoesNotValidateEndDate()
    {
        var sut = new UpdateEventRequest
        {
            StartDate = DateTime.UtcNow.AddDays(-1),
            EndDate = DateTime.UtcNow.AddHours(-12),
            TimezoneIdentification = "Europe/Amsterdam"
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, null, null, null, null);

        Assert.Null(response.Errors);
    }
}