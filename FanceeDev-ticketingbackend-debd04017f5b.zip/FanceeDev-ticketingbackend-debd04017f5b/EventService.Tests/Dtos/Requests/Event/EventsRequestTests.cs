using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using EventService.Dtos.Requests.Event;

namespace EventService.Tests.Dtos.Requests.Event;

public class EventsRequestTests
{
    private readonly EventsRequestFilter _sut = new();

    [Fact]
    public void TestThatValidateSetsMinimumStartDateToBeginOfDay()
    {
        _sut.DateRange = new() { Minimum = new DateTime(2022, 5, 19, 12, 54, 3) };

        var context = new ValidationContext(_sut);

        var _ = _sut.Validate(context).ToList();

        Assert.Equal(0, _sut.DateRange?.Minimum?.Hour);
        Assert.Equal(0, _sut.DateRange?.Minimum?.Minute);
        Assert.Equal(0, _sut.DateRange?.Minimum?.Second);
    }

    [Fact]
    public void TestThatValidateSetsMaximumEndDateToEndOfDay()
    {
        _sut.DateRange = new() { Maximum = new DateTime(2022, 5, 19, 12, 54, 3) };

        var context = new ValidationContext(_sut);

        var _ = _sut.Validate(context).ToList();

        Assert.Equal(23, _sut.DateRange?.Maximum?.Hour);
        Assert.Equal(59, _sut.DateRange?.Maximum?.Minute);
        Assert.Equal(59, _sut.DateRange?.Maximum?.Second);
    }

    [Fact]
    public void TestThatValidateYieldsErrorForIncorrectCountryCodes()
    {
        _sut.CountryCodes = new[]
        {
            "NL",
            "BELG"
        };

        var validationResults = _sut.Validate(new(_sut)).ToList();

        Assert.Single(validationResults);
        Assert.Equal("Every country code must be exactly two characters long to comply with the ISO 3166 standard", validationResults[0].ErrorMessage);
    }
}