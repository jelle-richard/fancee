using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Responses;
using WebApiCore.Utils;

namespace EventService.Tests.Dtos.Requests.Event;

public class EventRequestTests
{
    private const string UnitTimezone = "Europe/Amsterdam";

    [Fact]
    public async Task TestThatPrepareSanitizesDescription()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            Name = "UnitTestName",
            TimezoneIdentification = UnitTimezone,
            Description = "I contain <b>HTML</b> <a href=\"https://google.com/\">and</a> <script>alert('xss code');</script>",
            Categories = Array.Empty<string>()
        };

        var userId = Guid.NewGuid();

        var response = new ApiResponse<object>();

        await sut.Prepare(userId, response, null, null, null, null);

        Assert.Equal("""I contain <b>HTML</b> <a href="https://google.com/">and</a> """, sut.Description);
        Assert.Null(response.Errors);
        Assert.Equal(userId, sut.OrganizationId);
    }

    [Fact]
    public async Task TestThatPrepareInvokesCategoriesCallback()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            Name = "UnitTestName",
            TimezoneIdentification = UnitTimezone,
            Description = "Very nice description",
            Categories = new[] { "Metal" }
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, categories =>
        {
            categories = categories.ToList();

            Assert.Single(categories);
            Assert.Equal("Metal", categories.First());

            response.AddError("unittest", "Callback was called");

            return Task.FromResult<IList<EventCategory>>(new List<EventCategory>());
        }, null, null, null);

        Assert.NotNull(response.Errors);
        Assert.Equal("Callback was called", response.Errors["unittest"].First());
    }

    [Fact]
    public async Task TestThatPrepareInvokesCountryCallback()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            Name = "UnitTestName",
            TimezoneIdentification = UnitTimezone,
            Description = "Very nice description",
            Categories = new[] { "Metal" },
            Address = new() { CountryCode = "NL" }
        };

        var response = new ApiResponse<object>();
        var callbackCalled = false;

        await sut.Prepare(Guid.NewGuid(), response, null, countryCode =>
        {
            callbackCalled = true;
            Assert.Equal("NL", countryCode);

            return Task.FromResult(true);
        }, null, null);

        Assert.True(callbackCalled);
        Assert.Null(response.Errors);
    }

    [Fact]
    public async Task TestThatPrepareInvokesCountryCallbackAndSetsErrorOnInvalidCountryCode()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            Name = "UnitTestName",
            TimezoneIdentification = UnitTimezone,
            Description = "Very nice description",
            Categories = new[] { "Metal" },
            Address = new() { CountryCode = "INV" }
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, null, countryCode =>
        {
            Assert.Equal("INV", countryCode);

            return Task.FromResult(false);
        }, null, null);

        Assert.NotNull(response.Errors);
        Assert.Equal("'Address.CountryCode' is not valid", response.Errors["FAN-89701"].First());
    }

    [Fact]
    public async Task TestThatPrepareAddsErrorIfStartDateIsAfterEndDate()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(20),
            EndDate = DateTime.UtcNow.AddMinutes(10),
            TimezoneIdentification = UnitTimezone
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, null, null, null, null);

        Assert.NotNull(response.Errors);
        Assert.Single(response.Errors);

        var errorMessage = response.Errors[$"FAN-{(int)ErrorCode.ExceptionInvalidData}"].FirstOrDefault();

        Assert.Equal("'StartDate' cannot be the same or after 'EndDate'", errorMessage);
    }

    [Fact]
    public async Task TestThatPrepareAddsErrorIfEndDateIsBeforeCurrentDate()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(-20),
            EndDate = DateTime.UtcNow.AddMinutes(-15),
            TimezoneIdentification = UnitTimezone
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, null, null, null, null);

        Assert.NotNull(response.Errors);
        Assert.Single(response.Errors);

        var errorMessage = response.Errors[$"FAN-{(int)ErrorCode.ExceptionInvalidData}"].FirstOrDefault();

        Assert.Equal("'EndDate' cannot be before the current time", errorMessage);
    }

    [Theory]
    [InlineData("My 'amazing' event.", "My 'amazing' event.")]
    [InlineData("I'm <html> safe!", "I'm safe!")]
    public async Task TestThatPrepareSanitizesName(string name, string expected)
    {
        var sut = new EventRequest
        {
            Name = name,
            TimezoneIdentification = UnitTimezone,
            Description = string.Empty,
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20)
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, null, null, null, null);

        Assert.Null(response.Errors);
        Assert.Equal(expected, sut.Name);
    }

    [Fact]
    public async Task TestThatPrepareDoesNotAcceptInvalidTimezoneIdentifications()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            Name = "UnitTestName",
            TimezoneIdentification = "Unit/Testers",
            Description = "I am a description",
            Categories = Array.Empty<string>()
        };

        var userId = Guid.NewGuid();

        var response = new ApiResponse<object>();

        await sut.Prepare(userId, response, null, null, null, null);

        Assert.NotNull(response.Errors);
        Assert.Equal(userId, sut.OrganizationId);
        Assert.Equal("'TimezoneIdentification' is not valid", response.Errors["FAN-89701"].First());
    }

    [Fact]
    public async Task TestThatPrepareSetsSeatsIoEventIdToNullForNonSeatingEvent()
    {
        var sut = new EventRequest
        {
            Type = EventType.Normal,
            SeatsIoEventId = Guid.Empty,
            TimezoneIdentification = "Europe/Amsterdam"
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.Empty, response, null, null, null, null);

        Assert.Null(response.Errors);
        Assert.Null(sut.SeatsIoEventId);
    }

    [Fact]
    public async Task TestThatPrepareSetsErrorIfSeatsIoEventIdIsMissing()
    {
        var sut = new EventRequest
        {
            Type = EventType.Seating,
            TimezoneIdentification = "Europe/Amsterdam"
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.Empty, response, null, null, null, null);

        Assert.NotNull(response.Errors);
        Assert.Equal("'SeatsIoEventId' is required when event type is seating", response.Errors["FAN-89701"].First());
    }

    [Fact]
    public async Task TestThatPrepareSetsErrorIfSeatsIoEventIdIsInvalid()
    {
        var sut = new EventRequest
        {
            Type = EventType.Seating,
            SeatsIoEventId = Guid.Empty,
            TimezoneIdentification = "Europe/Amsterdam"
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.Empty, response, null, null, null, _ => Task.FromResult(false));

        Assert.NotNull(response.Errors);
        Assert.Equal("'SeatsIoEventId' is not a valid SeatsIO event id", response.Errors["FAN-89701"].First());
    }

    [Fact]
    public async Task TestThatPrepareLimitsAndAllowsSmallDescriptionWithoutCountingHtml()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            Name = "UnitTestName",
            TimezoneIdentification = UnitTimezone,
            Description = "The unit test sentence should still be allowed even though this string included with the html is above 500 chars <b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b><b>HTML</b>",
            Categories = Array.Empty<string>()
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, null, null, null, null);

        Assert.Null(response.Errors);
    }

    [Fact]
    public async Task TestThatPrepareLimitsAndDisallowsBigDescriptionWithoutCountingHtml()
    {
        var sut = new EventRequest
        {
            StartDate = DateTime.UtcNow.AddMinutes(10),
            EndDate = DateTime.UtcNow.AddMinutes(20),
            Name = "UnitTestName",
            TimezoneIdentification = UnitTimezone,
            Description =
                "This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because witThis should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this messaThis should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars ge is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars hout HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars This should not be allowed because without HTML this message is above 2000 chars ",
            Categories = Array.Empty<string>()
        };

        var response = new ApiResponse<object>();

        await sut.Prepare(Guid.NewGuid(), response, null, null, null, null);

        Assert.NotNull(response.Errors);
        Assert.Single(response.Errors);

        var errorMessage = response.Errors[$"FAN-{(int)ErrorCode.ExceptionInvalidData}"].FirstOrDefault();

        Assert.Equal("'Description' is to big, please refrain to 2000 characters.", errorMessage);
    }
}