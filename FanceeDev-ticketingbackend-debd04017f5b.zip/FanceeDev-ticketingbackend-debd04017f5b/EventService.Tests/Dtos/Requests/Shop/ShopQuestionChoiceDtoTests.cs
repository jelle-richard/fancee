using System.Linq;
using EventService.Dtos.Requests.Shop;

namespace EventService.Tests.Dtos.Requests.Shop;

public class ShopQuestionChoiceDtoTests
{
    public static readonly object[][] EmptyValueTestData =
    {
        new object[] { "", true },
        new object[] { " ", true },
        new object[] { "                         ", true },
        new object[] { ".", false },
        new object[] { " something? ", false }
    };

    [Theory]
    [MemberData(nameof(EmptyValueTestData))]
    public void TestThatValidateYieldsErrorWhenValueIsEmpty(string value, bool expectedValidationError)
    {
        var sut = new ShopQuestionChoiceDto
        {
            Value = value
        };

        var validationResults = sut.Validate(new(sut)).ToList();

        Assert.Equal(expectedValidationError ? 1 : 0, validationResults.Count);

        if (expectedValidationError)
            Assert.Equal("Shop question choice value cannot be empty", validationResults.First().ErrorMessage);
    }
}