using System.ComponentModel.DataAnnotations;
using System.Linq;
using EventService.Dtos.Requests.Shop;

namespace EventService.Tests.Dtos.Requests.Shop;

public class UpdateShopMailRequestTests
{
    private readonly UpdateShopMailRequest _sut = new();

    [Fact]
    public void TestThatValidateSanitizesAndMinifiesHtmlContent()
    {
        _sut.Content = """
            <h1 style="color: #404040;">H1 text</h1>
            <script>alert('hello');</script>
            <div>
                <p>Test</p>
            </div
        """;

        var actual = _sut.Validate(new(_sut));

        const string expected = """<h1 style="color: #404040">H1 text</h1>  <div> <p>Test </div>""";

        Assert.Equal(ValidationResult.Success, actual.First());
        Assert.Equal(expected, _sut.Content);
    }
}