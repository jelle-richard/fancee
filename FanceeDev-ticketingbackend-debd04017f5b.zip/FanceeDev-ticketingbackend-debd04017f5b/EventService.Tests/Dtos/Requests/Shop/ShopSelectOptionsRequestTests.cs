using System;
using System.Linq;
using EventService.Dtos.Requests.Shop;
using JetBrains.Annotations;

namespace EventService.Tests.Dtos.Requests.Shop;

[TestSubject(typeof(ShopSelectOptionsRequest))]
public class ShopSelectOptionsRequestTests
{
    private readonly ShopSelectOptionsRequest _sut = new();

    [Fact]
    public void TestThatValidateSetsEventsIdsToEmptyListIfNullIsGiven()
    {
        _sut.Ids = [];
        _sut.SearchQuery = null;
        _sut.EventIds = null;

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.NotNull(_sut.EventIds);
        Assert.Empty(_sut.EventIds);
        Assert.Single(actual);
        Assert.Null(actual[0]);
    }

    [Fact]
    public void TestThatValidateKeepsEventIds()
    {
        _sut.Ids = [];
        _sut.SearchQuery = null;
        _sut.EventIds = [Guid.Empty, Guid.Empty];

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.NotNull(_sut.EventIds);
        Assert.Equal(2, _sut.EventIds.Count);
        Assert.Single(actual);
        Assert.Null(actual[0]);
    }
}