using System;
using System.Collections.Generic;
using System.Linq;
using EventService.Dtos.Requests.Shop;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Dtos.Requests.Shop;

public class CreateShopRequestTests
{
    [Fact]
    public void TestThatValidateYieldsErrorForMismatchedDates()
    {
        var sut = new ConfigureShopRequest
        {
            Name = "Unit",
            Layout = ShopLayout.Ticketshop,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(-1),
            ShopFields = new List<ShopFieldRequirementRequest>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                }
            }
        };

        var validationResults = sut.Validate(new(sut)).ToList();

        Assert.Single(validationResults);
        Assert.Equal("StartDate cannot be the same or after the EndDate", validationResults[0].ErrorMessage);
    }

    [Fact]
    public void TestThatValidateYieldsErrorForNoShopFields()
    {
        var sut = new ConfigureShopRequest
        {
            Name = "Unit",
            Layout = ShopLayout.Ticketshop,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(5),
            ShopFields = new List<ShopFieldRequirementRequest>()
        };

        var validationResults = sut.Validate(new(sut)).ToList();

        Assert.Equal("ShopFields are missing", validationResults[0].ErrorMessage);
        Assert.Equal("ShopFields requires the email field to be required and enabled", validationResults[1].ErrorMessage);
    }

    [Fact]
    public void TestThatValidateYieldsErrorForShopFieldsWithoutEmail()
    {
        var sut = new ConfigureShopRequest
        {
            Name = "Unit",
            Layout = ShopLayout.Ticketshop,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(5),
            ShopFields = new List<ShopFieldRequirementRequest>
            {
                new()
                {
                    Field = ShopField.FirstName,
                    Required = true,
                    Enabled = true
                }
            }
        };

        var validationResults = sut.Validate(new(sut)).ToList();

        Assert.Single(validationResults);
        Assert.Equal("ShopFields requires the email field to be required and enabled", validationResults[0].ErrorMessage);
    }

    [Theory]
    [InlineData("My 'amazing' shop.", "My 'amazing' shop.")]
    [InlineData("I'm <html> safe!", "I'm safe!")]
    public void TestThatValidateSanitizesShopName(string name, string expected)
    {
        var sut = new ConfigureShopRequest
        {
            Name = name,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddMinutes(30),
            ShopFields = new List<ShopFieldRequirementRequest>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                }
            }
        };

        var validationResults = sut.Validate(new(sut)).ToList();

        Assert.Empty(validationResults);
        Assert.Equal(expected, sut.Name);
    }
}