using System.Collections.Generic;
using System.Linq;
using EventService.Dtos.Requests.Shop;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Dtos.Requests.Shop;

public class ShopQuestionRequestTests
{
    public static readonly object[][] EmptyQuestionTestData =
    {
        new object[] { "", true },
        new object[] { " ", true },
        new object[] { "                         ", true },
        new object[] { ".", false },
        new object[] { " something? ", false }
    };

    [Theory]
    [MemberData(nameof(EmptyQuestionTestData))]
    public void TestThatValidateYieldsErrorForEmptyQuestion(string question, bool expectedValidationError)
    {
        var sut = new ShopQuestionRequest
        {
            Required = true,
            Question = question,
            Type = ShopQuestionType.Open,
            Choices = new List<ShopQuestionChoiceDto>()
        };

        var validationResults = sut.Validate(new(sut)).ToList();

        Assert.Equal(expectedValidationError ? 1 : 0, validationResults.Count);

        if (expectedValidationError)
            Assert.Equal("Shop question cannot be empty", validationResults.First().ErrorMessage);
    }

    [Fact]
    public void TestThatValidateYieldsErrorWhenQuestionTypeIsSetToChoiceAndNoChoicesAreGiven()
    {
        var sut = new ShopQuestionRequest
        {
            Required = true,
            Question = "Does a set of all sets contain itself?",
            Type = ShopQuestionType.Choice,
            Choices = new List<ShopQuestionChoiceDto>()
        };

        var validationResults = sut.Validate(new(sut)).ToList();

        Assert.Single(validationResults);

        Assert.Equal($"When the question type is set to {ShopQuestionType.Choice.ToString()} at least two choices need to be provided", validationResults.First().ErrorMessage);
    }
}