using System;
using System.Linq;
using EventService.Dtos.Shared.Ticket;

namespace EventService.Tests.Dtos.Shared.Ticket;

public class TicketDesignDtoTests
{
    private readonly TicketDesignDto _sut = new();

    [Fact]
    public void TestThatValidateReturnsErrorIfElementsIsNull()
    {
        _sut.Elements = null;

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("At least one element is required", actual[0].ErrorMessage);
        Assert.Equal("Elements", actual[0].MemberNames.First());
    }

    [Fact]
    public void TestThatValidateReturnsErrorIfElementsIsEmpty()
    {
        _sut.Elements = Array.Empty<TicketDesignElementDto>();

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("At least one element is required", actual[0].ErrorMessage);
        Assert.Equal("Elements", actual[0].MemberNames.First());
    }

    [Fact]
    public void TestThatValidateReturnsErrorIfTicketIdsIsNull()
    {
        _sut.Elements = new TicketDesignElementDto[] { new QrElementDto() };
        _sut.TicketIds = null;

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("At least one ticket id is required", actual[0].ErrorMessage);
        Assert.Equal("TicketIds", actual[0].MemberNames.First());
    }

    [Fact]
    public void TestThatValidateReturnsErrorIfTicketIdsIsEmpty()
    {
        _sut.Elements = new TicketDesignElementDto[] { new QrElementDto() };
        _sut.TicketIds = Array.Empty<Guid>();

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("At least one ticket id is required", actual[0].ErrorMessage);
        Assert.Equal("TicketIds", actual[0].MemberNames.First());
    }

    [Fact]
    public void TestThatValidateReturnsErrorIfNoQrElementDtoIsProvided()
    {
        _sut.Elements = new TicketDesignElementDto[]
        {
            new MediaElementDto
            {
                FileId = Guid.Empty,
                Size = new() { RowSpan = 1, ColumnSpan = 1 },
                Position = new() { Row = 1, Column = 1 }
            }
        };
        _sut.TicketIds = new[] { Guid.Empty };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Exactly one QR element should be provided", actual[0].ErrorMessage);
        Assert.Equal("Elements", actual[0].MemberNames.First());
    }

    [Fact]
    public void TestThatValidateReturnsErrorOnOverlap()
    {
        _sut.Elements = new TicketDesignElementDto[]
        {
            new MediaElementDto
            {
                FileId = Guid.Empty,
                Size = new() { RowSpan = 4, ColumnSpan = 3 },
                Position = new() { Row = 1, Column = 1 }
            },
            new UpcomingEventsElementDto
            {
                Amount = 4,
                Size = new() { RowSpan = 1, ColumnSpan = 1 },
                Position = new() { Column = 2, Row = 2 }
            },
            new QrElementDto
            {
                Size = new() { RowSpan = 1, ColumnSpan = 1 },
                Position = new() { Row = 4, Column = 3 }
            }
        };
        _sut.TicketIds = new[] { Guid.Empty };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Elements cannot overlap at grid position: 2,2", actual[0].ErrorMessage);
        Assert.Equal("Elements", actual[0].MemberNames.First());
    }

    [Fact]
    public void TestThatValidateReturnsNoErrorsIfQrElementDtoOverlapsWithOtherElement()
    {
        _sut.Elements = new TicketDesignElementDto[]
        {
            new MediaElementDto
            {
                FileId = Guid.Empty,
                Size = new() { RowSpan = 4, ColumnSpan = 3 },
                Position = new() { Row = 1, Column = 1 }
            },
            new QrElementDto
            {
                Size = new() { RowSpan = 1, ColumnSpan = 1 },
                Position = new() { Row = 4, Column = 3 }
            }
        };
        _sut.TicketIds = new[] { Guid.Empty };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Empty(actual);
    }

    [Fact]
    public void TestThatValidateReturnsNoErrorsOnValidState()
    {
        _sut.Elements = new TicketDesignElementDto[]
        {
            new MediaElementDto
            {
                FileId = Guid.Empty,
                Size = new() { RowSpan = 1, ColumnSpan = 1 },
                Position = new() { Row = 1, Column = 1 }
            },
            new QrElementDto
            {
                Size = new() { RowSpan = 1, ColumnSpan = 1 },
                Position = new() { Row = 4, Column = 3 }
            }
        };
        _sut.TicketIds = new[] { Guid.Empty };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Empty(actual);
    }
}