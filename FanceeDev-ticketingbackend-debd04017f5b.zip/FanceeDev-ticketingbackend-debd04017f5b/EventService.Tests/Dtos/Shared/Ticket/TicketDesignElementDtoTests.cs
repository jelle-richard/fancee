using System.Linq;
using EventService.Dtos.Shared.Ticket;

namespace EventService.Tests.Dtos.Shared.Ticket;

public class TicketDesignElementDtoTests
{
    private readonly TicketDesignElementDto _sut;

    public TicketDesignElementDtoTests()
    {
        _sut = new UnitTestElementDto();
    }

    [Fact]
    public void TestThatValidateReturnsNoErrorsOnValidState()
    {
        _sut.Position = new() { Column = 1, Row = 1 };
        _sut.Size = new() { ColumnSpan = 1, RowSpan = 1 };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Empty(actual);
    }

    [Theory]
    [InlineData(1, 4)]
    [InlineData(3, 2)]
    [InlineData(5, 5)]
    public void TestThatValidateReturnsElementOutOfRangeIfColumnIsOutOfRange(int column, int columnSpan)
    {
        _sut.Position = new() { Column = column, Row = 1 };
        _sut.Size = new() { ColumnSpan = columnSpan, RowSpan = 1 };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Element out of range", actual[0].ErrorMessage);
        Assert.Equal("Column", actual[0].MemberNames.First());
    }

    [Theory]
    [InlineData(1, 5)]
    [InlineData(4, 2)]
    [InlineData(6, 6)]
    public void TestThatValidateReturnsElementOutOfRangeIfRowIsOutOfRange(int row, int rowSpan)
    {
        _sut.Position = new() { Column = 1, Row = row };
        _sut.Size = new() { ColumnSpan = 1, RowSpan = rowSpan };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Element out of range", actual[0].ErrorMessage);
        Assert.Equal("Row", actual[0].MemberNames.First());
    }

    #region Unit Test Classes

    private class UnitTestElementDto : TicketDesignElementDto
    {
    }

    #endregion
}