﻿using WebApiCore.Exceptions.Payment;

namespace EventService.Tests.Services.Exceptions;

public class InvalidPaidByExceptionTests
{
    [Fact]
    public void TestThatInvalidPaidByExceptionSetsCorrectMessage()
    {
        var sut = new InvalidPaidByException("unittest");

        Assert.Equal("Paid by method: 'unittest' is invalid", sut.Message);
    }

    [Fact]
    public void TestThatInvalidPaidByExceptionSetsCorrectErrorCode()
    {
        var sut = new InvalidPaymentProviderException("unittest");

        Assert.Equal(89701, (int)sut.ErrorCode);
    }

    [Fact]
    public void TestThatInvalidPaidByExceptionSetsCorrectStatusCode()
    {
        var sut = new InvalidPaymentProviderException("unittest");

        Assert.Equal(400, (int)sut.StatusCode);
    }
}