﻿using WebApiCore.Exceptions.Payment;

namespace EventService.Tests.Services.Exceptions;

public class InvalidPaymentProviderExceptionTests
{
    [Fact]
    public void TestThatInvalidPaymentProviderExceptionSetsCorrectMessage()
    {
        var sut = new InvalidPaymentProviderException("unittest");

        Assert.Equal("Payment provider: 'unittest' is invalid", sut.Message);
    }

    [Fact]
    public void TestThatInvalidPaymentProviderExceptionSetsCorrectErrorCode()
    {
        var sut = new InvalidPaymentProviderException("unittest");

        Assert.Equal(89701, (int)sut.ErrorCode);
    }

    [Fact]
    public void TestThatInvalidPaymentProviderExceptionSetsCorrectStatusCode()
    {
        var sut = new InvalidPaymentProviderException("unittest");

        Assert.Equal(400, (int)sut.StatusCode);
    }
}