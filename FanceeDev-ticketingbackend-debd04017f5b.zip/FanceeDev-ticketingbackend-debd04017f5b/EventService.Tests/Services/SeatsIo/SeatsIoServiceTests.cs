using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Persistence.Event;
using EventService.Persistence.Product;
using EventService.Services.SeatsIo;
using EventService.Services.SeatsIo.Exceptions;
using FanceeData.Models.Ticketing;
using Fs.SeatingUtils.Providers;
using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using SeatsioDotNet.Reports.Charts;
using WebApiCore.Exceptions.Event;

namespace EventService.Tests.Services.SeatsIo;

[TestSubject(typeof(SeatsIoService))]
public class SeatsIoServiceTests
{
    private static readonly Guid EventId = Guid.NewGuid();
    private static readonly Guid OrganizationId = Guid.NewGuid();

    private readonly SeatsIoService _sut;
    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly Mock<IProductDao> _mockedProductDao = new();
    private readonly Mock<ISeatsIoProvider> _mockedSeatsIoProvider = new();

    public SeatsIoServiceTests()
    {
        _sut = new(
            _mockedEventDao.Object,
            _mockedProductDao.Object,
            _mockedSeatsIoProvider.Object
        );
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncThrowsEventNotFoundExceptionOnInvalidEventId()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.SyncCategoriesAsync(EventId, OrganizationId));

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncThrowsInvalidSeatsEventConfigurationExceptionIfSeatsIoEventIdIsNull()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                SeatsIoEventId = null,
                Type = EventType.Seating
            });

        await Assert.ThrowsAsync<InvalidSeatsEventConfigurationException>(async () => await _sut.SyncCategoriesAsync(EventId, OrganizationId));

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncThrowsInvalidSeatsEventConfigurationExceptionIfEventIsNotOfTypeSeating()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Normal
            });

        await Assert.ThrowsAsync<InvalidSeatsEventConfigurationException>(async () => await _sut.SyncCategoriesAsync(EventId, OrganizationId));

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncThrowsInvalidSeatsEventConfigurationExceptionIfEventIsNotOfTypeSeatingAndHasNoSeatsIoEventId()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                SeatsIoEventId = null,
                Type = EventType.Normal
            });

        await Assert.ThrowsAsync<InvalidSeatsEventConfigurationException>(async () => await _sut.SyncCategoriesAsync(EventId, OrganizationId));

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncThrowsInvalidSeatsIoEventExceptionIfSeatsIoEventDoesNotExist()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Seating
            });

        _mockedSeatsIoProvider.Setup(sp => sp.EventAsync(Guid.Empty.ToString()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<InvalidSeatsIoEventException>(async () => await _sut.SyncCategoriesAsync(EventId, OrganizationId));

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.EventAsync(It.IsAny<string>()), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncThrowsInvalidSeatsIoEventExceptionIfSeatsIoDoesNotREturnChartReport()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Seating
            });

        _mockedSeatsIoProvider.Setup(sp => sp.EventAsync(Guid.Empty.ToString()))
            .ReturnsAsync(new SeatsioDotNet.Events.Event { ChartKey = "key" });

        _mockedSeatsIoProvider.Setup(sp => sp.SummaryReportAsync("key"))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<InvalidSeatsIoEventException>(async () => await _sut.SyncCategoriesAsync(EventId, OrganizationId));

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.EventAsync(It.IsAny<string>()), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.SummaryReportAsync(It.IsAny<string>()), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncAddsNewProductsWhenNoExistingProductsExist()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Id = EventId,
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Seating,
                EndDate = DateTime.UtcNow.AddDays(6)
            });

        _mockedSeatsIoProvider.Setup(sp => sp.EventAsync(Guid.Empty.ToString()))
            .ReturnsAsync(new SeatsioDotNet.Events.Event
            {
                ChartKey = "key",
                Categories = new() { new() { Key = "1", Label = "First ticket" } }
            });

        _mockedSeatsIoProvider.Setup(sp => sp.SummaryReportAsync("key"))
            .ReturnsAsync(new Dictionary<string, ChartReportSummaryItem>
            {
                { "1", new ChartReportSummaryItem { Count = 5 } }
            });

        await _sut.SyncCategoriesAsync(EventId, OrganizationId);

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.EventAsync(It.IsAny<string>()), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.SummaryReportAsync(It.IsAny<string>()), Times.Once);
        _mockedProductDao.Verify(pd => pd.InsertAsync(It.Is<List<FanceeData.Models.Ticketing.Product>>(l =>
            l.Count == 1 &&
            l[0].EventId == EventId &&
            l[0].SeatsIoCategoryId == "1" &&
            l[0].Type == ProductType.SeatedTicket &&
            l[0].PriceCents == 1000 &&
            l[0].Name == "First ticket" &&
            l[0].Stock == 5 &&
            l[0].PackQuantity == 1 &&
            l[0].SaleStart <= DateTime.UtcNow &&
            l[0].SaleEnd >= DateTime.UtcNow.AddDays(5) &&
            !l[0].MarkSoldOutOnSaleWindowExpired &&
            !l[0].IsSharedCapacityEligible &&
            l[0].MaximumPurchasePerOrder == 10 &&
            !l[0].TicketOption.Swappable &&
            l[0].TicketOption.MaximumPreArrivalTimeMinutes == 60
        )), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncTruncatesLongProductNameTo35Characters()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Id = EventId,
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Seating,
                EndDate = DateTime.UtcNow.AddDays(6)
            });

        _mockedSeatsIoProvider.Setup(sp => sp.EventAsync(Guid.Empty.ToString()))
            .ReturnsAsync(new SeatsioDotNet.Events.Event
            {
                ChartKey = "key",
                Categories = new() { new() { Key = "1", Label = "This seat has a very long name, over 35 characters" } }
            });

        _mockedSeatsIoProvider.Setup(sp => sp.SummaryReportAsync("key"))
            .ReturnsAsync(new Dictionary<string, ChartReportSummaryItem>
            {
                { "1", new ChartReportSummaryItem { Count = 5 } }
            });

        await _sut.SyncCategoriesAsync(EventId, OrganizationId);

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.EventAsync(It.IsAny<string>()), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.SummaryReportAsync(It.IsAny<string>()), Times.Once);
        _mockedProductDao.Verify(pd => pd.InsertAsync(It.Is<List<FanceeData.Models.Ticketing.Product>>(l =>
            l.Count == 1 &&
            l[0].SeatsIoCategoryId == "1" &&
            l[0].Type == ProductType.SeatedTicket &&
            l[0].Name == "This seat has a very long name, ove"
        )), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncDeletesRemovedCategoriesAndKeepsNonSeatedProducts()
    {
        var productIds = new[] { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Id = EventId,
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Seating,
                EndDate = DateTime.UtcNow.AddDays(6),
                Products = new List<FanceeData.Models.Ticketing.Product>
                {
                    new() { Id = productIds[0], SeatsIoCategoryId = "1", Type = ProductType.SeatedTicket },
                    new() { Id = productIds[1], SeatsIoCategoryId = "2", Type = ProductType.SeatedTicket },
                    new() { Id = productIds[2], Type = ProductType.Ticket }
                }
            });

        _mockedSeatsIoProvider.Setup(sp => sp.EventAsync(Guid.Empty.ToString()))
            .ReturnsAsync(new SeatsioDotNet.Events.Event
            {
                ChartKey = "key",
                Categories = new()
            });

        _mockedSeatsIoProvider.Setup(sp => sp.SummaryReportAsync("key"))
            .ReturnsAsync(new Dictionary<string, ChartReportSummaryItem>());

        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.Is<IEnumerable<Guid>>(i => i.First() == productIds[1])))
            .ReturnsAsync(true);

        await _sut.SyncCategoriesAsync(EventId, OrganizationId);

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.EventAsync(It.IsAny<string>()), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.SummaryReportAsync(It.IsAny<string>()), Times.Once);
        _mockedProductDao.Verify(pd => pd.HasSalesOrReservationsAsync(It.IsAny<IEnumerable<Guid>>()), Times.Exactly(2));
        _mockedProductDao.Verify(pd => pd.DeleteAsync(It.IsAny<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedProductDao.Verify(pd => pd.UpdateBatchAsync(Enumerable.Empty<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedProductDao.Verify(pd => pd.InsertAsync(Enumerable.Empty<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncUpdatesExistingProducts()
    {
        var productIds = new[] { Guid.NewGuid(), Guid.NewGuid() };

        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Id = EventId,
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Seating,
                EndDate = DateTime.UtcNow.AddDays(6),
                Products = new List<FanceeData.Models.Ticketing.Product>
                {
                    new() { Id = productIds[0], SeatsIoCategoryId = "1", Stock = 5 },
                    new() { Id = productIds[1], SeatsIoCategoryId = "2", Stock = 1 }
                }
            });

        _mockedSeatsIoProvider.Setup(sp => sp.EventAsync(Guid.Empty.ToString()))
            .ReturnsAsync(new SeatsioDotNet.Events.Event
            {
                ChartKey = "key",
                Categories = new()
                {
                    new() { Key = "1", Label = "First ticket" },
                    new() { Key = "2", Label = "Second ticket" }
                }
            });

        _mockedSeatsIoProvider.Setup(sp => sp.SummaryReportAsync("key"))
            .ReturnsAsync(new Dictionary<string, ChartReportSummaryItem>
            {
                { "1", new ChartReportSummaryItem { Count = 5 } },
                { "2", new ChartReportSummaryItem { Count = 150 } }
            });

        await _sut.SyncCategoriesAsync(EventId, OrganizationId);

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.EventAsync(It.IsAny<string>()), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.SummaryReportAsync(It.IsAny<string>()), Times.Once);
        _mockedProductDao.Verify(pd => pd.UpdateBatchAsync(It.Is<List<FanceeData.Models.Ticketing.Product>>(l => l.Count == 1 && l[0].Stock == 150)), Times.Once);
        _mockedProductDao.Verify(pd => pd.InsertAsync(Enumerable.Empty<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSyncCategoriesAsyncAddsToExistingProducts()
    {
        var productId = Guid.NewGuid();

        _mockedEventDao.Setup(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Id = EventId,
                SeatsIoEventId = Guid.Empty,
                Type = EventType.Seating,
                EndDate = DateTime.UtcNow.AddDays(6),
                Products = new List<FanceeData.Models.Ticketing.Product>
                {
                    new() { Id = productId, SeatsIoCategoryId = "1", Stock = 5 }
                }
            });

        _mockedSeatsIoProvider.Setup(sp => sp.EventAsync(Guid.Empty.ToString()))
            .ReturnsAsync(new SeatsioDotNet.Events.Event
            {
                ChartKey = "key",
                Categories = new()
                {
                    new() { Key = "1", Label = "First ticket" },
                    new() { Key = "2", Label = "Second ticket" }
                }
            });

        _mockedSeatsIoProvider.Setup(sp => sp.SummaryReportAsync("key"))
            .ReturnsAsync(new Dictionary<string, ChartReportSummaryItem>
            {
                { "1", new ChartReportSummaryItem { Count = 5 } },
                { "2", new ChartReportSummaryItem { Count = 150 } }
            });

        await _sut.SyncCategoriesAsync(EventId, OrganizationId);

        _mockedEventDao.Verify(ed => ed.GetEventAsync(EventId, OrganizationId, q => q.Include(e => e.Products)), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.EventAsync(It.IsAny<string>()), Times.Once);
        _mockedSeatsIoProvider.Verify(sp => sp.SummaryReportAsync(It.IsAny<string>()), Times.Once);
        _mockedProductDao.Verify(pd => pd.InsertAsync(It.Is<List<FanceeData.Models.Ticketing.Product>>(l =>
            l.Count == 1 &&
            l[0].EventId == EventId &&
            l[0].SeatsIoCategoryId == "2" &&
            l[0].Type == ProductType.SeatedTicket &&
            l[0].Name == "Second ticket" &&
            l[0].Stock == 150
        )), Times.Once);
        _mockedProductDao.Verify(pd => pd.UpdateBatchAsync(Enumerable.Empty<FanceeData.Models.Ticketing.Product>()), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
        _mockedProductDao.VerifyNoOtherCalls();
        _mockedSeatsIoProvider.VerifyNoOtherCalls();
    }
}