﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Product.Item;
using EventService.Dtos.Requests.Product.Media;
using EventService.Dtos.Responses.Product;
using EventService.Persistence.Event;
using EventService.Persistence.Product;
using EventService.Persistence.ProductMedia;
using EventService.Persistence.Ticket;
using EventService.Services.Product;
using EventService.Services.Product.Exceptions;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Http;
using WebApiCore.Dtos.Requests;
using WebApiCore.Exceptions;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using File = FanceeData.Models.Ticketing.File;

namespace EventService.Tests.Services.Product;

public class ProductServiceTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ProductService _sut;
    private readonly Mock<IProductDao> _mockedProductDao = new();
    private readonly Mock<ITicketDao> _mockedTicketDao = new();
    private readonly Mock<IProductMediaDao> _mockedProductMediaDao = new();
    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();

    public ProductServiceTests()
    {
        _sut = new(_mockedTicketDao.Object, _mockedProductDao.Object, _mockedProductMediaDao.Object,
            _mockedEventDao.Object, _mockedStorageService.Object, _mockedDeploymentEnvironmentService.Object,
            _mockedUploadService.Object);
    }

    [Fact]
    public async Task TestThatOwnerOfProductCallsProductDao()
    {
        var productId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedProductDao.Setup(p => p.BelongsToEventAsync(productId, eventId)).ReturnsAsync(true);

        Assert.True(await _sut.BelongsToEvent(productId, eventId));
        _mockedProductDao.Verify(p => p.BelongsToEventAsync(productId, eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatOwnerOfProductsCallsProductDao()
    {
        var ids = new[] { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

        _mockedProductDao.Setup(p => p.OwnerOfProductsAsync(ValidOrganizationId, ids)).ReturnsAsync(true);

        Assert.True(await _sut.OwnerOfProductsAsync(ValidOrganizationId, ids));
        _mockedProductDao.Verify(p => p.OwnerOfProductsAsync(ValidOrganizationId, ids), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsProductDaoForProduct()
    {
        var id = Guid.NewGuid();

        _mockedProductDao.Setup(p => p.ProductTypeAsync(id)).ReturnsAsync(ProductType.Product);

        await _sut.DeleteAsync(id);

        _mockedProductDao.Verify(p => p.DeleteAsync(id), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsTicketDaoForTicket()
    {
        var id = Guid.NewGuid();

        _mockedProductDao.Setup(p => p.ProductTypeAsync(id)).ReturnsAsync(ProductType.Ticket);

        await _sut.DeleteAsync(id);

        _mockedTicketDao.Verify(t => t.DeleteAsync(id), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAllAsyncGetsAllProducts()
    {
        var eventId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();
        var productId = Guid.NewGuid();

        _mockedProductDao.Setup(pd => pd.GetAllAsync(eventId, organizationId, p => p.TicketOption, p => p.IssuedProducts, p => p.ReservedProducts)).ReturnsAsync(
            new List<FanceeData.Models.Ticketing.Product> { new() { Id = productId, Type = ProductType.Product } });

        var actual = await _sut.GetAllAsync(eventId, organizationId);

        Assert.NotNull(actual);
        Assert.Single(actual);

        _mockedProductDao.Verify(pd => pd.GetAllAsync(eventId, organizationId, p => p.TicketOption, p => p.IssuedProducts, p => p.ReservedProducts), Times.Once);
    }

    [Fact]
    public async Task TestThatInsertAsyncReturnsMappedProductIds()
    {
        var model = new PostProductDto
        {
            Name = "UnitTicket A",
            PriceCents = 24911,
            Stock = 49,
            Type = ProductType.Ticket,
            Description = "Hello",
            PackQuantity = 1,
            MaximumPurchasePerOrder = 15,
            WaveLinkedProductId = null,
            TicketOptions = new()
            {
                Swappable = true,
                ScanNotification = "Welcome"
            }
        };

        var actual = await _sut.InsertAsync(model, Guid.NewGuid());

        Assert.NotNull(actual);
        _mockedProductDao.Verify(pd => pd.InsertAsync(It.IsAny<FanceeData.Models.Ticketing.Product>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsUpdateProducts()
    {
        var productId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        _mockedProductDao.Setup(pd => pd.GetAllAsync(new[] { productId }, organizationId, p => p.TicketOption))
            .ReturnsAsync(new List<FanceeData.Models.Ticketing.Product>
            {
                new() { Id = productId, Name = "Change Me", Type = ProductType.Ticket }
            });

        var dto = new List<IdentifiedProductDto>
        {
            new()
            {
                Id = productId, Name = "UnitTicket", PriceCents = 1024, Stock = 2048, TicketOptions = new(),
                Type = ProductType.Ticket
            }
        };

        await _sut.UpdateAsync(dto, organizationId);

        _mockedProductDao.Verify(pd => pd.GetAllAsync(It.IsAny<IEnumerable<Guid>>(), organizationId, p => p.TicketOption),
            Times.Once);
        _mockedProductDao.Verify(
            pd => pd.UpdateBatchAsync(It.IsAny<IEnumerable<FanceeData.Models.Ticketing.Product>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateProductsAsyncDoesNotUpdateProductIfTypeIsChanged()
    {
        var productId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        var mockedProduct = new Mock<FanceeData.Models.Ticketing.Product>
        {
            Object = { Id = productId, Type = ProductType.Ticket }
        };
        var products = new List<IdentifiedProductDto> { new() { Id = productId, Type = ProductType.Product } };

        mockedProduct.SetupAllProperties();
        _mockedProductDao.Setup(pd => pd.GetAllAsync(It.IsAny<IEnumerable<Guid>>(), organizationId, p => p.TicketOption))
            .ReturnsAsync(new[] { mockedProduct.Object });

        await _sut.UpdateAsync(products, organizationId);

        mockedProduct.Verify(p => p.TicketOption, Times.Never);
    }

    [Fact]
    public async Task TestThatUpdateProductsAsyncDoesNotUpdateTicketOptionIfTypeIsNotTicket()
    {
        var productId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        var mockedProduct = new Mock<FanceeData.Models.Ticketing.Product>
        {
            Object = { Id = productId, Type = ProductType.Product }
        };
        var products = new List<IdentifiedProductDto> { new() { Id = productId, Type = ProductType.Product } };

        mockedProduct.SetupAllProperties();
        _mockedProductDao.Setup(pd => pd.GetAllAsync(It.IsAny<IEnumerable<Guid>>(), organizationId, p => p.TicketOption))
            .ReturnsAsync(new[] { mockedProduct.Object });

        await _sut.UpdateAsync(products, organizationId);

        mockedProduct.VerifySet(p => p.Name = It.IsAny<string>(), Times.Once);
        mockedProduct.Verify(p => p.TicketOption, Times.Never);
    }

    [Fact]
    public async Task TestThatUpdateProductsAsyncDoesNotUpdateTicketOptionIfPackQuantityIsChangedAndTicketHasSalesOrReservations()
    {
        var productId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        var mockedProduct = new Mock<FanceeData.Models.Ticketing.Product>
        {
            Object =
            {
                Id = productId,
                Type = ProductType.Ticket,
                PackQuantity = 5
            }
        };

        var products = new List<IdentifiedProductDto>
        {
            new()
            {
                Id = productId,
                Type = ProductType.Ticket,
                PackQuantity = 1
            }
        };

        mockedProduct.SetupAllProperties();
        _mockedProductDao.Setup(pd => pd.GetAllAsync(It.IsAny<IEnumerable<Guid>>(), organizationId, p => p.TicketOption))
            .ReturnsAsync(new[] { mockedProduct.Object });
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);

        await Assert.ThrowsAsync<ProductInUseException>(async () => await _sut.UpdateAsync(products, organizationId));

        mockedProduct.VerifySet(p => p.Name = It.IsAny<string>(), Times.Never);
        mockedProduct.Verify(p => p.TicketOption, Times.Never);
    }

    [Fact]
    public async Task TestThatUpdateAsyncWithInvalidProductDoesNotUpdate()
    {
        // ReSharper disable once CollectionNeverUpdated.Local
        var persistedProducts = new List<FanceeData.Models.Ticketing.Product>();

        var productId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        _mockedProductDao.Setup(pd => pd.GetAllAsync(new[] { productId }, organizationId, p => p.TicketOption))
            .ReturnsAsync(persistedProducts);

        var dto = new List<IdentifiedProductDto>
        {
            new() { Id = productId, Name = "UnitProduct", PriceCents = 100, Stock = 4, Type = ProductType.Product },
            new() { Id = Guid.NewGuid(), Name = "UnitTicket", PriceCents = 49, Stock = 88, Type = ProductType.Ticket }
        };

        await _sut.UpdateAsync(dto, organizationId);

        _mockedProductDao.Verify(pd => pd.GetAllAsync(It.IsAny<IEnumerable<Guid>>(), organizationId, p => p.TicketOption),
            Times.Once);
        _mockedProductDao.Verify(pd => pd.UpdateBatchAsync(persistedProducts), Times.Once);
    }

    [Fact]
    public async Task TestThatHasSalesOrReservationsWithProductIdsCallsProductDao()
    {
        var list = new[] { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

        await _sut.HasSalesOrReservations(list);

        _mockedProductDao.Verify(pd => pd.HasSalesOrReservationsAsync(list), Times.Once);
    }

    [Fact]
    public async Task TestThatHasSalesOrReservationsWithProductIdCallsHasSalesOrReservationsWithWrappedList()
    {
        await _sut.HasSalesOrReservations(Guid.NewGuid());

        _mockedProductDao.Verify(pd => pd.HasSalesOrReservationsAsync(It.IsAny<IEnumerable<Guid>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAllExcludingAsyncGetsAllProductsExcludingGivenIds()
    {
        var organizationId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        var excluded = new[] { Guid.NewGuid() };
        var actual = await _sut.GetAllExcludingAsync(eventId, organizationId, excluded);

        Assert.NotNull(actual);

        _mockedProductDao.Verify(pd => pd.GetAllExcludingAsync(eventId, organizationId, excluded, p => p.TicketOption),
            Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatUploadMediaAsyncCallsCallbackOnSuccessfulUpload()
    {
        var productId = Guid.NewGuid();

        var mockedMediaRequest = new Mock<UploadProductMediaRequest>();
        mockedMediaRequest.SetupAllProperties();
        mockedMediaRequest.Object.Media = new FormFile(new MemoryStream(), 0, 10, "unittest", "unittest.png");
        mockedMediaRequest.Setup(mr => mr.GetFileExtension()).Returns("png");
        mockedMediaRequest.Setup(mr => mr.GetMimeType()).Returns("image/png");

        _mockedProductMediaDao.Setup(pmd => pmd.NextPositionAsync(productId)).ReturnsAsync(3);
        _mockedUploadService.Setup(us =>
                us.UploadAsync(mockedMediaRequest.Object, "products", null, It.IsAny<Func<File, Task>>()))
            .ReturnsAsync((UploadMediaRequest _, string _, string _, Func<File, Task> uploadedCallback) =>
            {
                uploadedCallback(new());
                return new() { Id = It.IsAny<Guid>(), Url = "unittest" };
            });

        var actual = await _sut.UploadMediaAsync(productId, mockedMediaRequest.Object);

        Assert.NotNull(actual);
        Assert.Equal("unittest", actual.Url);

        _mockedUploadService.Verify(
            us => us.UploadAsync(mockedMediaRequest.Object, "products", null, It.IsAny<Func<File, Task>>()),
            Times.Once);
        _mockedProductMediaDao.Verify(pmd => pmd.NextPositionAsync(productId), Times.Once);
        _mockedProductMediaDao.Verify(pmd => pmd.InsertAsync(It.Is<ProductMedia>(pm => pm.Position == 3)));
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncThrowsMediaNotFoundExceptionOnInvalidFile()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedProductMediaDao.Setup(pmd => pmd.ByIdAsync(fileId, productId)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.DeleteMediaAsync(productId, Guid.NewGuid(), fileId));
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncDeletesMedia()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        var model = new ProductMedia
        {
            Position = 1,
            File = new()
            {
                Path = "uploads/products/image.png"
            }
        };

        _mockedProductMediaDao.Setup(pmd => pmd.ByIdAsync(fileId, productId)).ReturnsAsync(model);

        await _sut.DeleteMediaAsync(productId, Guid.NewGuid(), fileId);

        _mockedProductMediaDao.Verify(pmd => pmd.ByIdAsync(fileId, productId), Times.Once);
        _mockedStorageService.Verify(ss => ss.DeleteFileAsync("products", "image.png"), Times.Once);
        _mockedProductMediaDao.Verify(pmd => pmd.DeleteAsync(model), Times.Once);
        _mockedProductMediaDao.Verify(pmd => pmd.RepositionMediaAsync(productId, 1), Times.Once);
    }

    [Fact]
    public async Task TestThatOwnerOfMediaAsyncCallsProductMediaDao()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        await _sut.OwnerOfMediaAsync(organizationId, fileId, productId);

        _mockedProductMediaDao.Verify(pmd => pmd.OwnerOfMediaAsync(fileId, productId, organizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatEventProductSalesAsyncCallsProductDaoEventProductSalesAsync()
    {
        _mockedProductDao.Setup(pd => pd.EventProductSalesAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<ProductSalesResponse>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Name = "UnitProduct",
                    Stock = 100,
                    PriceCents = 100,
                    SoldAmount = 0,
                    PendingPaymentsAmount = 5,
                    PendingReservationsAmount = 10
                }
            });

        var actual = await _sut.EventProductSalesAsync(Guid.NewGuid());

        Assert.Single(actual);
        _mockedProductDao.Verify(pd => pd.EventProductSalesAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpcomingEventProductsAsyncCallsEventDaoUpcomingEventProducts()
    {
        _mockedEventDao.Setup(ed => ed.UpcomingEventProductsAsync(ValidOrganizationId))
            .ReturnsAsync(new List<FanceeData.Models.Ticketing.Event>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Name = "Unit event",
                    Products = new List<FanceeData.Models.Ticketing.Product>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Name = "Unit product",
                            Type = ProductType.Ticket
                        }
                    }
                }
            });

        var actual = await _sut.UpcomingEventProductsAsync(ValidOrganizationId);

        Assert.Single(actual);
        Assert.Equal("Unit event", actual.First().Name);
        Assert.Equal("Unit product", actual.First().Products.First().Name);

        _mockedEventDao.Verify(ed => ed.UpcomingEventProductsAsync(ValidOrganizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatProductShopsAsyncCallsProductDaoProductShopsAsync()
    {
        _mockedProductDao.Setup(pd => pd.ProductShopsAsync(It.IsAny<Guid>(), It.IsAny<Guid>()))
            .ReturnsAsync(new List<FanceeData.Models.Ticketing.Product>());

        await _sut.ProductShopsAsync(It.IsAny<Guid>(), It.IsAny<Guid>());

        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
        _mockedProductDao.Verify(pd => pd.ProductShopsAsync(It.IsAny<Guid>(), It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointAsyncThrowsMediaNotFoundExceptionForUnknownProductFile()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedProductMediaDao.Setup(pmd => pmd.ByIdAsync(fileId, productId))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.UpdateMediaFocalPointAsync(productId, fileId, new()));
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointAsyncCallsProductMediaDaoUpdateAsync()
    {
        var productId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedProductMediaDao.Setup(pmd => pmd.ByIdAsync(fileId, productId))
            .ReturnsAsync(new ProductMedia
            {
                FocalPointHeightPercentage = null,
                FocalPointWidthPercentage = null
            });

        _mockedProductMediaDao.Setup(pmd => pmd.UpdateAsync(It.IsAny<ProductMedia>()));

        await _sut.UpdateMediaFocalPointAsync(productId, fileId, new()
        {
            FocalPointHeightPercentage = 55,
            FocalPointWidthPercentage = 45
        });

        _mockedProductMediaDao.Verify(pmd => pmd.ByIdAsync(fileId, productId), Times.Once);
        _mockedProductMediaDao.Verify(pmd => pmd.UpdateAsync(It.IsAny<ProductMedia>()), Times.Once);
    }

    [Fact]
    public async Task
        TestThatRepositionMediaAsyncThrowsProductMediaNotFoundExceptionIfFileIdsDoNotMatchProductMediaCount()
    {
        var productId = Guid.NewGuid();
        var fileIds = new[] { Guid.NewGuid(), Guid.NewGuid() };

        _mockedProductMediaDao.Setup(pmd => pmd.ForProductAsync(productId)).ReturnsAsync(Array.Empty<ProductMedia>());

        await Assert.ThrowsAsync<ProductMediaNotFoundException>(async () =>
            await _sut.RepositionMediaAsync(productId, fileIds));

        _mockedProductMediaDao.Verify(pmd => pmd.ForProductAsync(productId), Times.Once);
        _mockedProductMediaDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task
        TestThatRepositionMediaAsyncThrowsProductMediaNotFoundExceptionIfFileIdsDoNotMatchProductMediaIds()
    {
        var productId = Guid.NewGuid();
        var fileIds = new[] { Guid.Empty, Guid.NewGuid() };

        _mockedProductMediaDao.Setup(pmd => pmd.ForProductAsync(productId)).ReturnsAsync(new ProductMedia[]
        {
            new() { FileId = Guid.NewGuid() },
            new() { FileId = Guid.NewGuid() }
        });

        await Assert.ThrowsAsync<ProductMediaNotFoundException>(async () =>
            await _sut.RepositionMediaAsync(productId, fileIds));

        _mockedProductMediaDao.Verify(pmd => pmd.ForProductAsync(productId), Times.Once);
        _mockedProductMediaDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRepositionMediaAsyncCallsProductMediaDaoRepositionMediaAsync()
    {
        var productId = Guid.NewGuid();
        var fileIds = new[] { Guid.Empty, Guid.NewGuid() };

        _mockedProductMediaDao.Setup(pmd => pmd.ForProductAsync(productId)).ReturnsAsync(new ProductMedia[]
        {
            new() { FileId = fileIds[1] },
            new() { FileId = fileIds[0] }
        });

        await _sut.RepositionMediaAsync(productId, fileIds);

        _mockedProductMediaDao.Verify(pmd => pmd.ForProductAsync(productId), Times.Once);
        _mockedProductMediaDao.Verify(
            pmd => pmd.RepositionMediaAsync(It.IsAny<IList<ProductMedia>>(), fileIds.ToList()), Times.Once);
    }

    [Fact]
    public async Task TestThatTicketOptionsDesignIdInTicketIdAsyncCallsTicketOptionsDesignIdInTicketIdAsync()
    {
        _mockedProductDao.Setup(pd => pd.TicketOptionsDesignIdInTicketIdAsync(It.IsAny<Guid>(), It.IsAny<IList<Guid>>()))
            .ReturnsAsync(true);

        await _sut.TicketOptionsDesignIdInTicketIdAsync(It.IsAny<Guid>(), It.IsAny<IList<Guid>>());

        _mockedProductDao.Verify(pd => pd.TicketOptionsDesignIdInTicketIdAsync(It.IsAny<Guid>(), It.IsAny<IList<Guid>>()), Times.Once);
    }
}