using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Product;
using EventService.Persistence.Product;
using EventService.Services.Product;
using JetBrains.Annotations;

namespace EventService.Tests.Services.Product;

[TestSubject(typeof(ProductsService))]
public class ProductsServiceTests
{
    private readonly ProductsService _sut;
    private readonly Mock<IProductsDao> _mockedProductsDao = new();

    public ProductsServiceTests()
    {
        _sut = new(_mockedProductsDao.Object);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncCallsProductsDaoListSelectOptionsAsync()
    {
        var request = new ProductSelectOptionsRequest();

        _mockedProductsDao.Setup(pd => pd.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<IList<Guid>>(), It.IsAny<string?>(), It.IsAny<IList<Guid>>(), It.IsAny<bool>()))
            .ReturnsAsync([
                new()
                {
                    Id = Guid.Empty,
                    Label = "Test01"
                }
            ]);

        var actual = (await _sut.ListSelectOptionsAsync(Guid.Empty, request)).ToList();

        Assert.Single(actual);
        Assert.Equal("Test01", actual[0].Label);

        _mockedProductsDao.Verify(pd => pd.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<IList<Guid>>(), It.IsAny<string?>(), It.IsAny<IList<Guid>>(), It.IsAny<bool>()), Times.Once);
        _mockedProductsDao.VerifyNoOtherCalls();
    }
}