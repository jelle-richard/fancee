using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Product.Media;
using EventService.Dtos.Responses.Ticket;
using EventService.Dtos.Shared.Ticket;
using EventService.Persistence.Product.Ticket;
using EventService.Services.Product;
using EventService.Services.Product.Exceptions;
using EventService.Services.Product.Ticket;
using EventService.Services.Product.Ticket.Exceptions;
using FanceeData.Models.Ticketing;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;
using WebApiCore.Exceptions;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;

namespace EventService.Tests.Services.Product.Ticket;

public class TicketDesignServiceTests
{
    private readonly TicketDesignService _sut;
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<ITicketDesignDao> _mockedTicketDesignDao = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();

    public TicketDesignServiceTests()
    {
        _sut = new(
            _mockedProductService.Object,
            _mockedTicketDesignDao.Object,
            _mockedUploadService.Object,
            _mockedStorageService.Object,
            _mockedDeploymentEnvironmentService.Object
        );
    }

    [Fact]
    public async Task TestThatAddOrUpdateDesignThrowsProductNotFoundExceptionIfTicketIdsIsNull()
    {
        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, new()));

        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateDesignThrowsProductNotFoundExceptionIfOrganizationIsNotOwnerOfProducts()
    {
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, new()
        {
            TicketIds = new[] { Guid.Empty }
        }));

        _mockedProductService.Verify(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateDesignThrowsMediaNotFoundExceptionIfQrMediaDoesNotBelongToEvent()
    {
        var fileId = Guid.NewGuid();

        var request = new TicketDesignDto
        {
            TicketIds = new List<Guid> { Guid.Empty },
            Elements = new List<TicketDesignElementDto>
            {
                new QrElementDto
                {
                    FileId = fileId,
                    Position = new() { Row = 1, Column = 1 },
                    Size = new() { RowSpan = 1, ColumnSpan = 1 }
                }
            }
        };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () => await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, request));

        _mockedProductService.Verify(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.ForTicketsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.Verify(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateDesignThrowsMediaNotFoundExceptionIfMediaDoesNotBelongToEvent()
    {
        var fileId = Guid.NewGuid();

        var request = new TicketDesignDto
        {
            TicketIds = new List<Guid> { Guid.Empty },
            Elements = new List<TicketDesignElementDto>
            {
                new MediaElementDto
                {
                    FileId = fileId,
                    Position = new() { Row = 1, Column = 1 },
                    Size = new() { RowSpan = 1, ColumnSpan = 1 }
                }
            }
        };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () => await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, request));

        _mockedProductService.Verify(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.ForTicketsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.Verify(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateDesignThrowsUnsupportedTicketDesignElementExceptionOnUnsupportedTicketDesignElementDto()
    {
        var request = new TicketDesignDto
        {
            TicketIds = new List<Guid> { Guid.Empty },
            Elements = new List<TicketDesignElementDto>
            {
                new UnitTestElement
                {
                    Position = new() { Row = 1, Column = 1 },
                    Size = new() { RowSpan = 1, ColumnSpan = 1 }
                }
            }
        };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);

        await Assert.ThrowsAsync<UnsupportedTicketDesignElementException>(async () => await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, request));

        _mockedProductService.Verify(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.ForTicketsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.Verify(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncAllowsQrWithMedia()
    {
        var fileId = Guid.NewGuid();

        var request = new TicketDesignDto
        {
            TicketIds = new List<Guid> { Guid.Empty },
            Elements = new List<TicketDesignElementDto>
            {
                new QrElementDto
                {
                    FileId = fileId,
                    Position = new() { Row = 1, Column = 1 },
                    Size = new() { RowSpan = 1, ColumnSpan = 1 }
                }
            }
        };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId)).ReturnsAsync(true);
        _mockedTicketDesignDao.Setup(tdd => tdd.ForTicketsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new TicketOption[]
        {
            new()
        });

        await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, request);

        _mockedProductService.Verify(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.ForTicketsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.DeleteDesignsAsync(It.IsAny<IEnumerable<TicketOption>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.UpdateRangeAsync(It.Is<IList<TicketOption>>(to =>
            to.Count == 1 &&
            to[0].Design.DesignElements.Count == 1 &&
            to[0].Design.DesignElements.First().GetType() == typeof(TicketDesignQrElement) &&
            ((TicketDesignQrElement)to[0].Design.DesignElements.First()).FileId == fileId
        )), Times.Once);
        _mockedProductService.Verify(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddOrUpdateDesignAsyncUpdatesDesign()
    {
        var fileId = Guid.NewGuid();

        var request = new TicketDesignDto
        {
            TicketIds = new List<Guid> { Guid.Empty },
            Elements = new List<TicketDesignElementDto>
            {
                new QrElementDto
                {
                    Position = new() { Row = 1, Column = 1 },
                    Size = new() { RowSpan = 1, ColumnSpan = 1 }
                },
                new MediaElementDto
                {
                    FileId = fileId,
                    Position = new() { Row = 1, Column = 2 },
                    Size = new() { RowSpan = 1, ColumnSpan = 2 }
                },
                new UpcomingEventsElementDto
                {
                    Amount = 5,
                    Position = new() { Row = 2, Column = 1 },
                    Size = new() { RowSpan = 3, ColumnSpan = 1 }
                }
            }
        };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId)).ReturnsAsync(true);
        _mockedTicketDesignDao.Setup(tdd => tdd.ForTicketsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(new TicketOption[]
        {
            new()
        });

        await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, request);

        _mockedProductService.Verify(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, fileId), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.ForTicketsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.DeleteDesignsAsync(It.IsAny<IEnumerable<TicketOption>>()), Times.Once);
        _mockedProductService.Verify(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.UpdateRangeAsync(It.Is<IList<TicketOption>>(to =>
            to.Count == 1 &&
            to[0].Design.DesignElements.Count == 3 &&
            to[0].Design.DesignElements.First().GetType() == typeof(TicketDesignQrElement) &&
            ((TicketDesignQrElement)to[0].Design.DesignElements.First()).FileId == null &&
            to[0].Design.DesignElements.ElementAt(1).GetType() == typeof(TicketDesignMediaElement) &&
            ((TicketDesignMediaElement)to[0].Design.DesignElements.ElementAt(1)).FileId == fileId &&
            to[0].Design.DesignElements.ElementAt(2).GetType() == typeof(TicketDesignUpcomingEventsElement) &&
            ((TicketDesignUpcomingEventsElement)to[0].Design.DesignElements.ElementAt(2)).Amount == 5
        )), Times.Once);
        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsTicketDesignDtos()
    {
        _mockedTicketDesignDao.Setup(tdd => tdd.GetAsync(Guid.Empty)).ReturnsAsync(new (IEnumerable<Guid>, TicketDesign)[]
        {
            new(new[] { Guid.Empty }, new()
            {
                DesignElements = new TicketDesignElement[] { new TicketDesignQrElement() }
            })
        });
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment
        {
            Domain = "unit.test",
            IsHttps = false
        });

        var actual = (await _sut.GetAsync(Guid.Empty)).ToList();

        Assert.Single(actual);
        Assert.Single(actual[0].TicketIds!);
        Assert.Single(actual[0].Elements!);
        Assert.IsType<QrElementResponse>(actual[0].Elements![0]);

        _mockedTicketDesignDao.Verify(tdd => tdd.GetAsync(Guid.Empty), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
        _mockedTicketDesignDao.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatMediaBelongsToEventAsyncCallsTicketDesignDaoMediaBelongsToEventAsync()
    {
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(true);

        var actual = await _sut.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty);

        Assert.True(actual);

        _mockedTicketDesignDao.Verify(tdd => tdd.MediaBelongsToEventAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointAsyncThrowsMediaNotFoundExceptionOnInvalidFile()
    {
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () => await _sut.UpdateMediaFocalPointAsync(Guid.Empty, Guid.Empty, new()));

        _mockedTicketDesignDao.Verify(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateMediaFocalPointAsyncCallsTicketDesignDaoUpdateMediaAsync()
    {
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(new TicketDesignMedia
        {
            FocalPointHeightPercentage = 50,
            FocalPointWidthPercentage = 50
        });

        await _sut.UpdateMediaFocalPointAsync(Guid.Empty, Guid.Empty, new()
        {
            FocalPointHeightPercentage = 10,
            FocalPointWidthPercentage = 90
        });

        _mockedTicketDesignDao.Verify(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.UpdateMediaAsync(It.Is<TicketDesignMedia>(tdm =>
            tdm.FocalPointWidthPercentage == 90 && tdm.FocalPointHeightPercentage == 10)), Times.Once);
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncThrowsMediaInUseExceptionIfFileIsInUse()
    {
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaInUseAsync(Guid.Empty)).ReturnsAsync(true);

        await Assert.ThrowsAsync<MediaInUseException>(async () => await _sut.DeleteMediaAsync(Guid.Empty, Guid.Empty));

        _mockedTicketDesignDao.Verify(tdd => tdd.MediaInUseAsync(Guid.Empty), Times.Once);
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncThrowsMediaInUseExceptionIfFileDoesNotExist()
    {
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaInUseAsync(Guid.Empty)).ReturnsAsync(false);
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () => await _sut.DeleteMediaAsync(Guid.Empty, Guid.Empty));

        _mockedTicketDesignDao.Verify(tdd => tdd.MediaInUseAsync(Guid.Empty), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncDeletesMedia()
    {
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaInUseAsync(Guid.Empty)).ReturnsAsync(false);
        _mockedTicketDesignDao.Setup(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty)).ReturnsAsync(new TicketDesignMedia
        {
            File = new() { Path = "uploads/ticketdesigns/folder/image.png" }
        });

        await _sut.DeleteMediaAsync(Guid.Empty, Guid.Empty);

        _mockedTicketDesignDao.Verify(tdd => tdd.MediaInUseAsync(Guid.Empty), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.MediaByIdAsync(Guid.Empty, Guid.Empty), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.DeleteMediaAsync(It.IsAny<TicketDesignMedia>()), Times.Once);
        _mockedStorageService.Verify(ss => ss.DeleteFileAsync(IStorageService.TicketDesignMediaStoragePool, "folder/image.png"));
        _mockedTicketDesignDao.VerifyNoOtherCalls();
        _mockedStorageService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUploadMediaAsyncUploadsMedia()
    {
        var request = new UploadTicketDesignMediaRequest
        {
            FocalPointWidthPercentage = 10,
            FocalPointHeightPercentage = 15
        };

        _mockedUploadService.Setup(us => us.UploadAsync(request, IStorageService.TicketDesignMediaStoragePool, Guid.Empty.ToString(), It.IsAny<Func<File, Task>>()))
            .Callback<UploadMediaRequest, string, string, Func<File, Task>>((_, _, _, uploadedCallback) => { uploadedCallback?.Invoke(new()); })
            .ReturnsAsync(new UploadedFile
            {
                Id = Guid.Empty,
                Url = "https://unit.test/media.png"
            });

        var actual = await _sut.UploadMediaAsync(Guid.Empty, request);

        Assert.NotNull(actual);
        Assert.Equal("https://unit.test/media.png", actual.Url);

        _mockedUploadService.Verify(us => us.UploadAsync(request, IStorageService.TicketDesignMediaStoragePool, Guid.Empty.ToString(), It.IsAny<Func<File, Task>>()), Times.Once);
        _mockedTicketDesignDao.Verify(tdd => tdd.InsertMediaAsync(It.Is<TicketDesignMedia>(tdm =>
                tdm.FocalPointWidthPercentage == 10 &&
                tdm.FocalPointHeightPercentage == 15)),
            Times.Once);
        _mockedUploadService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }
    
    [Fact]
    public async Task TestThatAddOrUpdateDesignThrowsProductNotFoundExceptionIfTicketOptionsDesignIdNotInTicketId()
    {
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(true);
        _mockedProductService.Setup(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>())).ReturnsAsync(false);

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.AddOrUpdateDesignAsync(Guid.Empty, Guid.Empty, new()
        {
            TicketIds = new[] { Guid.Empty }
        }));

        _mockedProductService.Verify(ps => ps.OwnerOfProductsAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.Verify(ps => ps.TicketOptionsDesignIdInTicketIdAsync(Guid.Empty, It.IsAny<IEnumerable<Guid>>()), Times.Once);
        _mockedProductService.VerifyNoOtherCalls();
        _mockedTicketDesignDao.VerifyNoOtherCalls();
    }
    

    #region Unit Test Classes

    private class UnitTestElement : TicketDesignElementDto
    {
    }

    #endregion
}