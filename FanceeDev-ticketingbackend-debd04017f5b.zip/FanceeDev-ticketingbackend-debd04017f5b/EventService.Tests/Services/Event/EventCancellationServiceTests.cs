using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Persistence.Event;
using EventService.Persistence.Order;
using EventService.Services.Event;
using EventService.Services.Exceptions;
using FanceeData.Models.Ticketing;
using Fs.MessageBus.Publishers;
using MailTemplates.Models;
using MailTemplates.Models.Event;
using MailTemplates.Templates;
using Microsoft.Extensions.Configuration;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.MessageBus.Messages.Event;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Mail;
using WebApiCore.Settings;

namespace EventService.Tests.Services.Event;

public class EventCancellationServiceTests
{
    private static readonly EventCancelRequest Request = new()
    {
        Reason = "Because I can",
        PreferredRefundOption = EventCancellationRefundOption.FullRefund
    };

    private static readonly OrganizationDetailsSettings OrganizationDetailsSettings = new()
    {
        PlatformName = "Name",
        PlatformLogoUrl = "baseurl",
        SupportEmail = "support@test.nl",
        PlatformBaseCurrency = "USD"
    };

    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationUserId = Guid.NewGuid();
    private static readonly Guid ValidEventCancellationId = Guid.NewGuid();

    private static readonly Organization ValidOrganization = new()
    {
        Id = ValidOrganizationId,
        UserId = ValidOrganizationUserId,
        MailchimpKey = null,
        CustomTermFileId = null,
        ApproximatedAnnualSalesAmount = 0,
        DefaultReservationTimeMinutes = 0,
        Name = "Unit testing Co.",
        User = new()
        {
            Id = ValidOrganizationUserId,
            FanceeUsersId = null,
            Type = UserType.Organization,
            Email = "email",
            LastLogin = null,
            CreatedOn = default,
            DateOfBirth = null,
            AccountVerifyId = null,
            UserContactInfo = new()
            {
                UserId = ValidOrganizationUserId,
                FirstName = "Rick",
                LastName = "Woolschot"
            }
        }
    };

    private static readonly HostedDeploymentEnvironment HostedDeploymentEnvironment = new()
    {
        Id = default,
        Name = "Name",
        Port = 0000,
        FrontendBaseUrl = "FrontendBaseUrl",
        IsHttps = false,
        Files = null,
        RemoteIpAddress = null,
        Domain = null,
        ContentDeliveryNetworkBaseUrl = null
    };

    private readonly EventCancellationService _sut;
    private readonly Mock<IEventCancellationDao> _mockedEventCancellationDao = new();
    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly Mock<IOrderDao> _mockedOrderDao = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IMailer> _mockedMailer = new();
    private readonly Mock<IMessagePublisher<EventCanceledMessage>> _mockedPublisher = new();

    private readonly IConfiguration _mockedConfiguration = ConfigurationMockUtils.Create(new()
    {
        { "OrganizationDetails:Name", "UnitTest B.V." },
        { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
        { "OrganizationDetails:Iban", "NL92TEST483399991243" },
        { "OrganizationDetails:VatCode", "3582935" },
        { "OrganizationDetails:PlatformBaseCurrency", "USD" },
        { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
        { "OrganizationDetails:Address:HouseNumber", "843-855" },
        { "OrganizationDetails:Address:PostalCode", "4921DB" },
        { "OrganizationDetails:Address:City", "München" },
        { "OrganizationDetails:Address:CountryCode", "DE" },
        { "OrganizationDetails:PlatformName", "UnitTest (test)" }
    });

    public EventCancellationServiceTests()
    {
        _sut = new(_mockedEventCancellationDao.Object, _mockedEventDao.Object, _mockedOrderDao.Object, _mockedDeploymentEnvironmentService.Object, _mockedMailer.Object, _mockedConfiguration, _mockedPublisher.Object);
    }

    [Fact]
    public async Task TestThatCreateAsyncCallsMethodsExceptForPublisher()
    {
        _mockedEventDao.Setup(ed => ed.CancelableAsync(ValidEventId))
            .ReturnsAsync(true);

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(HostedDeploymentEnvironment);

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(It.IsAny<string>(), It.IsAny<EventCancellationNoticeModel>()))
            .ReturnsAsync("I am pretending to be HTML Content!");

        _mockedEventCancellationDao.Setup(ecd => ecd.AddAsync(It.IsAny<EventCancellation>()))
            .Callback<EventCancellation>(c => c.Id = ValidEventCancellationId);

        _mockedEventCancellationDao.Setup(ecd => ecd.GetAsync(ValidEventCancellationId))
            .ReturnsAsync(new EventCancellation
            {
                Id = ValidEventCancellationId,
                OrganizationId = ValidOrganizationId,
                EventId = ValidEventId,
                RequestedOn = default,
                PreferredRefundOption = EventCancellationRefundOption.FullRefund,
                CancelReason = "a reason",
                Organization = new()
                {
                    Id = ValidOrganizationId,
                    UserId = ValidOrganizationUserId,
                    Name = "a name",
                    CountryCode = "NL"
                },
                Event = new()
                {
                    Id = ValidEventId,
                    OrganizationId = ValidOrganizationId,
                    Name = "Event Name",
                    StartDate = default
                }
            });

        _mockedOrderDao.Setup(od => od.AllByEventId(ValidEventId))
            .ReturnsAsync(new List<Order>
            {
                new()
                {
                    ClientOrder = new()
                    {
                        FirstName = "Firstname",
                        LastName = "Lastname",
                        Client = new()
                        {
                            User = new()
                            {
                                Email = "Email"
                            }
                        }
                    }
                }
            });

        _mockedOrderDao.Setup(od => od.RefundableOrderIdsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<Guid>());

        await _sut.CreateAsync(ValidEventId, ValidOrganizationId, Request);

        _mockedEventCancellationDao.Verify(ecd => ecd.AddAsync(It.IsAny<EventCancellation>()), Times.Once);
        _mockedEventDao.Verify(ed => ed.CancelableAsync(ValidEventId), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Exactly(2));
        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync(Templates.CrmEventCancellationNotice, It.IsAny<MailModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.IsAny<Mail>()), Times.Exactly(2));
        _mockedOrderDao.Verify(od => od.RefundableOrderIdsAsync(It.IsAny<Guid>()), Times.Once);
        _mockedPublisher.Verify(p => p.Publish(It.IsAny<EventCanceledMessage>()), Times.Never);
    }
    
    [Fact]
    public async Task TestThatCreateAsyncCallsMethods()
    {
        _mockedEventDao.Setup(ed => ed.CancelableAsync(ValidEventId))
            .ReturnsAsync(true);

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(HostedDeploymentEnvironment);

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync(It.IsAny<string>(), It.IsAny<EventCancellationNoticeModel>()))
            .ReturnsAsync("I am pretending to be HTML Content!");

        _mockedEventCancellationDao.Setup(ecd => ecd.AddAsync(It.IsAny<EventCancellation>()))
            .Callback<EventCancellation>(c => c.Id = ValidEventCancellationId);

        _mockedEventCancellationDao.Setup(ecd => ecd.GetAsync(ValidEventCancellationId))
            .ReturnsAsync(new EventCancellation
            {
                Id = ValidEventCancellationId,
                OrganizationId = ValidOrganizationId,
                EventId = ValidEventId,
                RequestedOn = default,
                PreferredRefundOption = EventCancellationRefundOption.FullRefund,
                CancelReason = "a reason",
                Organization = new()
                {
                    Id = ValidOrganizationId,
                    UserId = ValidOrganizationUserId,
                    Name = "a name",
                    CountryCode = "NL"
                },
                Event = new()
                {
                    Id = ValidEventId,
                    OrganizationId = ValidOrganizationId,
                    Name = "Event Name",
                    StartDate = default
                }
            });

        _mockedOrderDao.Setup(od => od.AllByEventId(ValidEventId))
            .ReturnsAsync(new List<Order>
            {
                new()
                {
                    ClientOrder = new()
                    {
                        FirstName = "Firstname",
                        LastName = "Lastname",
                        Client = new()
                        {
                            User = new()
                            {
                                Email = "Email"
                            }
                        }
                    }
                }
            });

        _mockedOrderDao.Setup(od => od.RefundableOrderIdsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new List<Guid>
            {
                Guid.NewGuid()
            });

        await _sut.CreateAsync(ValidEventId, ValidOrganizationId, Request);

        _mockedEventCancellationDao.Verify(ecd => ecd.AddAsync(It.IsAny<EventCancellation>()), Times.Once);
        _mockedEventDao.Verify(ed => ed.CancelableAsync(ValidEventId), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Exactly(2));
        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync(Templates.CrmEventCancellationNotice, It.IsAny<MailModel>()), Times.Once);
        _mockedMailer.Verify(m => m.Send(It.IsAny<Mail>()), Times.Exactly(2));
        _mockedOrderDao.Verify(od => od.RefundableOrderIdsAsync(It.IsAny<Guid>()), Times.Once);
        _mockedPublisher.Verify(p => p.Publish(It.IsAny<EventCanceledMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateAsyncThrowsStartedEventIsNotCancelableException()
    {
        _mockedEventDao.Setup(ed => ed.CancelableAsync(ValidEventId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<EventIsNotCancelableException>(() => _sut.CreateAsync(ValidEventId, ValidOrganizationId, Request));

        _mockedEventDao.Verify(ed => ed.CancelableAsync(ValidEventId), Times.Once);
        _mockedEventCancellationDao.VerifyNoOtherCalls();
        _mockedOrderDao.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCreateAsyncThrowsCancelRequestNotFoundException()
    {
        _mockedEventDao.Setup(ed => ed.CancelableAsync(ValidEventId))
            .ReturnsAsync(true);

        _mockedEventCancellationDao.Setup(ecd => ecd.AddAsync(It.IsAny<EventCancellation>()))
            .Callback<EventCancellation>(c => c.Id = ValidEventCancellationId);

        await Assert.ThrowsAsync<CancellationNotFoundException>(() => _sut.CreateAsync(ValidEventId, ValidOrganizationId, Request));

        _mockedEventCancellationDao.Verify(ecd => ecd.AddAsync(It.IsAny<EventCancellation>()), Times.Once);
        _mockedEventDao.Verify(ed => ed.CancelableAsync(ValidEventId), Times.Once);
        _mockedEventCancellationDao.Verify(ed => ed.GetAsync(ValidEventCancellationId), Times.Once);
        _mockedEventCancellationDao.VerifyNoOtherCalls();
        _mockedOrderDao.VerifyNoOtherCalls();
        _mockedDeploymentEnvironmentService.VerifyNoOtherCalls();
        _mockedMailer.VerifyNoOtherCalls();
    }
}