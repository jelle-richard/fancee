using System;
using System.Linq;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Shared.Event;
using EventService.Persistence.Event;
using EventService.Services.Event;
using EventService.Services.Event.Exceptions;
using FanceeData.Models.Ticketing;
using MailTemplates.Models;
using MailTemplates.Models.Crm;
using MailTemplates.Templates;
using Microsoft.EntityFrameworkCore;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.MailProvider;
using WebApiCore.Exceptions;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Mail;

namespace EventService.Tests.Services.Event;

public class EventMailServiceTests
{
    private readonly EventMailService _sut;
    private readonly Mock<IEventMailDao> _mockedEventMailDao = new();
    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IMailer> _mockedMailer = new();

    public EventMailServiceTests()
    {
        var configuration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:PlatformName", "Fancee" },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" }
        });

        _sut = new(_mockedEventMailDao.Object,
            _mockedEventDao.Object,
            _mockedDeploymentEnvironmentService.Object,
            _mockedMailer.Object,
            configuration
        );
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncCallsShopMailDaoAddOrUpdateAsync()
    {
        var eventId = Guid.NewGuid();
        var request = new UpdateEventMailRequest { Type = MailType.GuestList, SenderName = "Test", Content = "Content" };

        await _sut.AddOrUpdateAsync(eventId, request);

        _mockedEventMailDao.Verify(smd => smd.AddOrUpdateAsync(It.Is<EventMail>(sm =>
            sm.Type == EventMailType.GuestList &&
            sm.EventId == eventId &&
            sm.SenderName == "Test" &&
            sm.Content == "Content"
        )), Times.Once);
    }

    [Fact]
    public async Task TestThatSendEventReviewMailAsyncThrowsIfMailAddressEmailIsNull()
    {
        await Assert.ThrowsAsync<MissingEmailException>(async () => await _sut.SendEventReviewMailAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), new(null, null)));
    }

    [Fact]
    public async Task TestThatSendEventReviewMailAsyncSendsEventReviewMail()
    {
        var eventId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();
        var mailAddress = new MailAddress("test@abc.com", "Test Testersson");

        _mockedEventDao.Setup(ed => ed.GetEventAsync(eventId, organizationId, q => q.Include(e => e.Organization)
                .ThenInclude(o => o.User.UserContactInfo)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Name = "Test event",
                Organization = new()
                {
                    User = new()
                    {
                        UserContactInfo = new()
                        {
                            FirstName = "Test",
                            LastName = "Organization"
                        }
                    }
                }
            });

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment { FrontendBaseUrl = "https://frontend" });

        _mockedMailer.Setup(m => m.ViewRenderer.RenderViewAsync<MailModel>(Templates.CrmMessage, It.IsAny<CrmMessageModel>()))
            .ReturnsAsync("content");

        await _sut.SendEventReviewMailAsync(eventId, organizationId, mailAddress);

        _mockedMailer.Verify(m => m.ViewRenderer.RenderViewAsync(Templates.CrmMessage, It.IsAny<MailModel>()), Times.Once);

        _mockedMailer.Verify(m => m.Send(It.Is<Mail>(mail =>
            mail.To.Count() == 1 &&
            mail.Subject == "An organization requests for you to review an event." &&
            mail.To.First().Name == mailAddress.Name)));
    }

    [Fact]
    public async Task TestThatEventMailAsyncThrowsEventMailNotFoundExceptionForNonExistentEventMail()
    {
        _mockedEventMailDao.Setup(ed => ed.GetAsync(It.IsAny<Guid>(), It.IsAny<EventMailType>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<EventMailNotFoundException>(async () => await _sut.EventMailAsync(Guid.NewGuid(), new()
        {
            Type = MailType.DefaultShopMail
        }));

        _mockedEventMailDao.Verify(ed => ed.GetAsync(It.IsAny<Guid>(), It.IsAny<EventMailType>()), Times.Once);
    }

    [Fact]
    public async Task TestThatEventMailAsyncCallsEventMailDaoGetAsyncToRetrieveMailAsEventMailResponse()
    {
        var eventId = Guid.NewGuid();
        var request = new EventMailRequest
        {
            Type = MailType.DefaultShopMail
        };

        _mockedEventMailDao.Setup(ed => ed.GetAsync(eventId, EventMailType.DefaultShopMail))
            .ReturnsAsync(new EventMail
            {
                Content = "CustomContent",
                SenderName = "UnitTester"
            });

        var actual = await _sut.EventMailAsync(eventId, request);

        Assert.Equal("UnitTester", actual.SenderName);
        _mockedEventMailDao.Verify(ed => ed.GetAsync(eventId, EventMailType.DefaultShopMail), Times.Once);
    }
}