﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Responses.Event;
using EventService.Dtos.Responses.Events;
using EventService.Dtos.Shared.Event;
using EventService.Persistence.Event;
using EventService.Persistence.Order;
using EventService.Persistence.Organization;
using EventService.Persistence.Product;
using EventService.Persistence.Ticket;
using EventService.Services.Event;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore.Query;
using TestCore.Mocks;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Persistence;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.Contract;
using WebApiCore.Exceptions;
using WebApiCore.Persistence.Contract;
using WebApiCore.Services.Cache;
using WebApiCore.Services.Currency;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Organization;

namespace EventService.Tests.Services.Event;

public class EventsServiceTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidAppTeamId = Guid.NewGuid();

    private static readonly List<MappedOrganizationContractFee> MappedContractFees = new()
    {
        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-60),
            PeriodEnd = DateTime.UtcNow.AddDays(-40),
            ProductFeeCents = 83,
            ProductFeePercentage = 0,
            TicketFeeCents = 83,
            TicketFeePercentage = 0,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 20,
            OrganizationId = ValidOrganizationId
        },
        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-39),
            PeriodEnd = DateTime.UtcNow.AddDays(-20),
            ProductFeeCents = 83,
            ProductFeePercentage = 0,
            TicketFeeCents = 83,
            TicketFeePercentage = 0,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 20,
            OrganizationId = ValidOrganizationId
        }
    };

    private static readonly List<EventBalanceResponse> EventBalancesResponses = new()
    {
        new()
        {
            EventId = Guid.NewGuid(),
            EventName = "UnitTestEvent",
            UserId = Guid.NewGuid(),
            UserEmail = "unit@test.nl",
            CountryCode = "NL",
            TotalAmountOfIssuedTickets = 100,
            TotalAmountOfScannedTickets = 0,
            OrganizationCurrencyEventBalanceCentsReceivedResponse = new()
            {
                TotalAmountOfTicketFeeCentsReceived = 0,
                TotalAmountOfPaymentFeeCentsReceived = 0,
                TotalAmountOfOrderTotalCostsCentsReceived = 0,
                TotalAmountOfTicketPlusCostsCentsReceived = 0,
                Currency = new()
                {
                    ShortCode = "EUR",
                    Character = "€",
                    Name = "Euro",
                    Decimals = 2
                }
            },
            PlatformCurrencyEventBalanceCentsReceivedResponse = new()
            {
                TotalAmountOfTicketFeeCentsReceived = 10000,
                TotalAmountOfPaymentFeeCentsReceived = 10000,
                TotalAmountOfOrderTotalCostsCentsReceived = 10000,
                TotalAmountOfTicketPlusCostsCentsReceived = 10000,
                Currency = new()
                {
                    ShortCode = "EUR",
                    Character = "€",
                    Name = "Euro",
                    Decimals = 2
                }
            }
        }
    };

    private static readonly List<EventBalance> EventBalancesEuro = new()
    {
        new()
        {
            EventId = Guid.NewGuid(),
            EventName = "UnitTestEvent",
            UserId = Guid.NewGuid(),
            UserEmail = "unit@test.nl",
            CountryCode = "NL",
            TotalAmountOfIssuedTickets = 100,
            TotalAmountOfScannedTickets = 0,
            TotalAmountOfTicketFeeCentsReceived = 10000,
            TotalAmountOfPaymentFeeCentsReceived = 10000,
            TotalAmountOfOrderTotalCostsCentsReceived = 10000,
            TotalAmountOfTicketPlusCostsCentsReceived = 10000,
            OrganizationCurrency = new()
            {
                ShortCode = "EUR",
                Character = "€",
                Name = "Euro",
                Decimals = 2,
                Active = true
            }
        }
    };

    private static readonly List<EventBalance> EventBalancesDollar = new()
    {
        new()
        {
            EventId = Guid.NewGuid(),
            EventName = "UnitTestEvent",
            UserId = Guid.NewGuid(),
            UserEmail = "unit@test.nl",
            CountryCode = "NL",
            TotalAmountOfIssuedTickets = 100,
            TotalAmountOfScannedTickets = 0,
            TotalAmountOfTicketFeeCentsReceived = 10000,
            TotalAmountOfPaymentFeeCentsReceived = 10000,
            TotalAmountOfOrderTotalCostsCentsReceived = 10000,
            TotalAmountOfTicketPlusCostsCentsReceived = 10000,
            OrganizationCurrency = new()
            {
                ShortCode = "USD",
                Character = "$",
                Name = "Dollar",
                Decimals = 2,
                Active = true
            }
        }
    };

    private static readonly DateTime Minimum = DateTime.UtcNow.AddDays(-20);
    private static readonly DateTime Maximum = DateTime.UtcNow;

    private static readonly List<string> CountryCodes = new()
    {
        "NL",
        "BE",
        "DE",
        "FR"
    };

    private static readonly PaginatedRequest<EventsBalanceMutationsRequestFilter> Request = new()
    {
        PageSize = 10,
        Page = 1,
        Options = new()
        {
            SearchQuery = null,
            DateRange = new()
            {
                Minimum = Minimum,
                Maximum = Maximum
            },
            CountryCodes = CountryCodes
        }
    };

    private static readonly IList<Guid> ValidOrganizationIds = new List<Guid>
    {
        ValidOrganizationId
    };

    private readonly EventsService _sut;
    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly Mock<IProductDao> _mockedProductDao = new();
    private readonly Mock<IOrderDao> _mockedOrderDao = new();
    private readonly Mock<ITicketDao> _mockedTicketDao = new();
    private readonly Mock<IContractDao> _mockedContractDao = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();
    private readonly Mock<IOrganizationDao> _mockedOrganizationDao = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    private readonly PaginatedRequest<EventsRequestFilter> _request = new()
    {
        Page = 1,
        PageSize = 10,
        Options = new()
        {
            SearchQuery = "UnitFilter",
            DateRange = new(),
            EventStates = Array.Empty<EventStatus>()
        }
    };

    public EventsServiceTests()
    {
        _mockedCurrencyService.Setup(cs => cs.CurrencyAsync("EUR"))
            .ReturnsAsync(new Currency
            {
                ShortCode = "EUR",
                Character = "€",
                Name = "Euro",
                Decimals = 2,
                Active = true
            });

        var mockedConfiguration = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "Vat:Percentage:", "21" }
        });

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment
        {
            Id = Guid.NewGuid(),
            Name = "UnitTestEnv",
            Domain = "localhost",
            IsHttps = false
        });

        _mockedOrganizationDao.Setup(od => od.ByIdAsync(ValidOrganizationId, It.IsAny<Expression<Func<IQueryable<Organization>, IIncludableQueryable<Organization, object>>>>()))
            .ReturnsAsync(new Organization
            {
                Id = Guid.NewGuid(),
                User = new()
                {
                    UserContactInfo = new()
                    {
                        Address = new()
                        {
                            CountryCodeNavigation = new()
                            {
                                Code = "NL",
                                CalculateVat = true
                            }
                        }
                    }
                }
            });

        _sut = new(_mockedEventDao.Object, _mockedProductDao.Object, _mockedOrderDao.Object, _mockedTicketDao.Object, _mockedDeploymentEnvironmentService.Object, _mockedContractDao.Object, _mockedCacheService.Object, mockedConfiguration, _mockedCurrencyService.Object, _mockedOrganizationDao.Object, _mockedOrganizationService.Object);
    }

    [Fact]
    public async Task TestThatListEventsAsyncCallsListAsync()
    {
        _mockedEventDao.Setup(e => e.ListAsync(ValidOrganizationId, 10, 0, "UnitFilter", null, null, Array.Empty<EventStatus>(), Array.Empty<string>(), It.IsAny<HostedDeploymentEnvironment>()))
            .ReturnsAsync(new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 20,
                Items = new List<EventListItemResponse>()
            });

        var actual = await _sut.ListEventsAsync(_request, ValidOrganizationId);

        Assert.NotNull(actual.Items);
        Assert.Equal(20, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatListEventsAsyncForPlatformAndSpecificOrganizationCallsListAsync()
    {
        _mockedEventDao.Setup(e => e.ListAsync(ValidOrganizationId, 10, 0, "UnitFilter", null, null, Array.Empty<EventStatus>(), It.IsAny<IEnumerable<string>>(), It.IsAny<HostedDeploymentEnvironment>()))
            .ReturnsAsync(new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 20,
                Items = new List<EventListItemResponse>()
            });

        var actual = await _sut.ListEventsAsync(_request, ValidOrganizationId);

        Assert.NotNull(actual.Items);
        Assert.Equal(20, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatListAppTeamEventsAsyncCallsEventDaoListAppTeamEventsAsync()
    {
        _mockedEventDao.Setup(e => e.ListByAppTeamAsync(ValidAppTeamId, 10, 0, "UnitFilter", null, null, Array.Empty<EventStatus>(), It.IsAny<HostedDeploymentEnvironment>()))
            .ReturnsAsync(new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 20,
                Items = new List<EventListItemResponse>()
            });

        var actual = await _sut.ListAppTeamEventsAsync(_request, ValidAppTeamId);

        Assert.NotNull(actual.Items);
        Assert.Equal(20, actual.TotalItems);

        _mockedEventDao.Verify(e => e.ListByAppTeamAsync(ValidAppTeamId, 10, 0, "UnitFilter", null, null, Array.Empty<EventStatus>(), It.IsAny<HostedDeploymentEnvironment>()), Times.Once);
    }

    [Fact]
    public async Task TestThatListEventsAsyncForPlatformCallsListAsync()
    {
        _mockedEventDao.Setup(e => e.ListAsync(10, 0, "UnitFilter", null, null, Array.Empty<EventStatus>(), It.IsAny<IEnumerable<string>>(), It.IsAny<HostedDeploymentEnvironment>()))
            .ReturnsAsync(new PaginatedResultSet<EventListItemResponse>
            {
                TotalItems = 20,
                Items = new List<EventListItemResponse>()
            });

        var actual = await _sut.ListEventsAsync(_request);

        Assert.NotNull(actual.Items);
        Assert.Equal(20, actual.TotalItems);
    }

    [Fact]
    public async Task TestThatEventsAgendaAsyncCallsEventDaoEventsAgendaAsync()
    {
        _mockedEventDao.Setup(ed => ed.EventsAgendaAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>(), It.IsAny<HostedDeploymentEnvironment>()))
            .ReturnsAsync(new List<AgendaEventResponse>
            {
                new()
                {
                    Id = Guid.NewGuid(),
                    Name = "Unit event"
                }
            });

        var actual = await _sut.EventsAgendaAsync(DateTime.UtcNow.AddDays(-20), DateTime.UtcNow, It.IsAny<IEnumerable<string>>());

        _mockedEventDao.Verify(ed => ed.EventsAgendaAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>(), It.IsAny<HostedDeploymentEnvironment>()), Times.Once);
        Assert.Single(actual);
    }

    [Fact]
    public async Task TestThatGlobalStatisticsAsyncCallsDaos()
    {
        _mockedProductDao.Setup(pd => pd.TotalProductsSoldAsync(It.IsAny<Guid>()))
            .ReturnsAsync(10);

        _mockedOrderDao.Setup(od => od.TotalOrdersAsync(It.IsAny<Guid>()))
            .ReturnsAsync(10);

        _mockedTicketDao.Setup(td => td.TotalTicketsScannedAsync(It.IsAny<Guid>()))
            .ReturnsAsync(5);

        _mockedOrderDao.Setup(od => od.AverageAgeByGendersAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new AverageAgesGenderResponse());

        _mockedOrderDao.Setup(od => od.UniqueCustomersByGendersAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new UniqueCustomersGenderResponse());

        var actual = await _sut.GlobalStatisticsAsync(Guid.NewGuid());

        _mockedProductDao.Verify(pd => pd.TotalProductsSoldAsync(It.IsAny<Guid>()), Times.Once);
        _mockedOrderDao.Verify(od => od.TotalOrdersAsync(It.IsAny<Guid>()), Times.Once);
        _mockedTicketDao.Verify(td => td.TotalTicketsScannedAsync(It.IsAny<Guid>()), Times.Once);
        _mockedOrderDao.Verify(od => od.AverageAgeByGendersAsync(It.IsAny<Guid>()), Times.Once);
        _mockedOrderDao.Verify(od => od.UniqueCustomersByGendersAsync(It.IsAny<Guid>()), Times.Once);

        Assert.Equal(10, actual.ProductsSoldAmount);
        Assert.Equal(10, actual.OrdersPlacedAmount);
    }

    [Fact]
    public async Task TestThatGlobalPlatformStatisticsAsyncThrowsInvalidDateRangeExceptionForMismatchedStartAndEndDate()
    {
        await Assert.ThrowsAsync<InvalidDateRangeException>(async () => await _sut.GlobalPlatformStatisticsAsync(DateTime.UtcNow.AddDays(1), DateTime.UtcNow, new[] { "NL" }));
    }

    [Fact]
    public async Task TestThatGlobalPlatformStatisticsAsyncAsyncCallsDaos()
    {
        _mockedProductDao.Setup(pd => pd.TotalProductsSoldAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(10);

        _mockedOrderDao.Setup(od => od.TotalOrdersAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(10);

        _mockedTicketDao.Setup(td => td.TotalTicketsScannedAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(5);

        _mockedOrderDao.Setup(od => od.AverageAgeByGendersAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<List<string>>()))
            .ReturnsAsync(new AverageAgesGenderResponse());

        _mockedOrderDao.Setup(od => od.UniqueCustomersByGendersAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<List<string>>()))
            .ReturnsAsync(new UniqueCustomersGenderResponse());

        var actual = await _sut.GlobalPlatformStatisticsAsync(DateTime.UtcNow.AddDays(-10), DateTime.UtcNow, new[] { "NL" });

        _mockedProductDao.Verify(pd => pd.TotalProductsSoldAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()), Times.Once);
        _mockedOrderDao.Verify(od => od.TotalOrdersAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()), Times.Once);
        _mockedTicketDao.Verify(td => td.TotalTicketsScannedAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<IEnumerable<string>>()), Times.Once);
        _mockedOrderDao.Verify(od => od.AverageAgeByGendersAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<List<string>>()), Times.Once);
        _mockedOrderDao.Verify(od => od.UniqueCustomersByGendersAsync(It.IsAny<DateTime>(), It.IsAny<DateTime>(), It.IsAny<List<string>>()), Times.Once);

        Assert.Equal(10, actual.ProductsSoldAmount);
        Assert.Equal(10, actual.OrdersPlacedAmount);
    }

    [Fact]
    public async Task TestThatConcludeAsyncCallsEventDaoConcludeAsync()
    {
        await _sut.ConcludeAsync();

        _mockedEventDao.Verify(ed => ed.ConcludeAsync(), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatOrganizationEventsAsCsvAsyncCallsEventDaoOrganizationEventExportItemsResponseAsyncAndConvertsItemsToCsv()
    {
        _mockedEventDao.Setup(ed => ed.OrganizationEventExportItemsResponseAsync(ValidOrganizationId, null, null, null, Array.Empty<EventStatus>()))
            .ReturnsAsync(new List<EventExportItemResponse>
            {
                new()
                {
                    Name = "UnitEvent1"
                },
                new()
                {
                    Name = "UnitEvent2"
                }
            });

        var request = new EventsRequestFilter();
        var actual = await _sut.OrganizationEventsAsCsvAsync(ValidOrganizationId, request);

        Assert.NotEmpty(actual.FileContents);
        _mockedEventDao.Verify(ed => ed.OrganizationEventExportItemsResponseAsync(ValidOrganizationId, null, null, null, Array.Empty<EventStatus>()), Times.Once);
    }

    [Fact]
    public async Task TestThatPlatformEventsAsCsvAsyncCallsEventDaoPlatformEventExportItemsResponseAsyncAndConvertsItemsToCsv()
    {
        _mockedEventDao.Setup(ed => ed.PlatformEventExportItemsResponseAsync(null, null, null, Array.Empty<EventStatus>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<EventExportItemResponse>
            {
                new()
                {
                    Name = "UnitEvent1"
                },
                new()
                {
                    Name = "UnitEvent2"
                }
            });

        var request = new EventsRequestFilter();
        var actual = await _sut.PlatformEventsAsCsvAsync(request);

        Assert.NotEmpty(actual.FileContents);
        _mockedEventDao.Verify(ed => ed.PlatformEventExportItemsResponseAsync(null, null, null, Array.Empty<EventStatus>(), It.IsAny<IEnumerable<string>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatPlatformEventsAsCsvAsyncCallsEventDaoPlatformEventExportItemsResponseAsyncAndConvertsItemsToCsvForSpecificOrganization()
    {
        _mockedEventDao.Setup(ed => ed.PlatformEventExportItemsResponseAsync(It.IsAny<Guid>(), null, null, null, Array.Empty<EventStatus>(), It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(new List<EventExportItemResponse>
            {
                new()
                {
                    Name = "UnitEvent1"
                },
                new()
                {
                    Name = "UnitEvent2"
                }
            });

        var request = new EventsRequestFilter();
        var actual = await _sut.PlatformEventsAsCsvAsync(ValidOrganizationId, request);

        Assert.NotEmpty(actual.FileContents);
        _mockedEventDao.Verify(ed => ed.PlatformEventExportItemsResponseAsync(It.IsAny<Guid>(), null, null, null, Array.Empty<EventStatus>(), It.IsAny<IEnumerable<string>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatBalanceEventsAsyncRetrievesFromCache()
    {
        _mockedContractDao.Setup(cd => cd.OrganizationContractsAsync(ValidOrganizationId))
            .ReturnsAsync(MappedContractFees);

        _mockedEventDao.Setup(ed => ed.BalanceMutationsAsync(MappedContractFees, null))
            .ReturnsAsync(EventBalancesEuro);

        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<List<EventBalanceResponse>>(It.IsAny<string>()))
            .ReturnsAsync(() => EventBalancesResponses);

        await _sut.BalanceMutationsAsync(Request);

        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<List<EventBalanceResponse>>(It.IsAny<string>()), Times.Once);
        _mockedContractDao.Verify(cd => cd.OrganizationContractsAsync(ValidOrganizationId), Times.Never);
        _mockedEventDao.Verify(ed => ed.BalanceMutationsAsync(MappedContractFees, null), Times.Never);
        _mockedCacheService.Verify(cs => cs.CacheObjectAsync(It.IsAny<string>(), EventBalancesEuro, It.IsAny<TimeSpan>()), Times.Never);
    }

    [Fact]
    public async Task TestThatBalanceEventsAsyncRetrievesFromDaoAndResponseReturnsPlatformResponseForOrganisationResponse()
    {
        _mockedOrganizationDao.Setup(od => od.ByRangeAsync((DateTime)Request.Options.DateRange!.Minimum!, (DateTime)Request.Options.DateRange!.Maximum!, Request.Options.CountryCodes!.ToArray()))
            .ReturnsAsync(ValidOrganizationIds);

        _mockedContractDao.Setup(cd => cd.OrganizationContractsAsync(ValidOrganizationId))
            .ReturnsAsync(MappedContractFees);

        _mockedEventDao.Setup(ed => ed.BalanceMutationsAsync(MappedContractFees, null))
            .ReturnsAsync(EventBalancesEuro);

        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<List<EventBalanceResponse>>(It.IsAny<string>()))
            .ReturnsAsync(() => null!);

        _mockedOrganizationDao.Setup(od => od.ByRangeAsync((DateTime)Request.Options.DateRange!.Minimum!, (DateTime)Request.Options.DateRange!.Maximum!, It.IsAny<string[]>()))
            .ReturnsAsync(new List<Guid> { ValidOrganizationId });

        var actual = await _sut.BalanceMutationsAsync(Request);

        Assert.Single(actual.Items);
        Assert.Equal(1, actual.TotalItems);

        _mockedContractDao.Verify(cd => cd.OrganizationContractsAsync(ValidOrganizationId), Times.Once);
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<List<EventBalanceResponse>>(It.IsAny<string>()), Times.Once);
        _mockedCacheService.Verify(cs => cs.CacheObjectAsync(It.IsAny<string>(), It.IsAny<List<EventBalanceResponse>>(), It.IsAny<TimeSpan>()), Times.Once);
        _mockedEventDao.Verify(ed => ed.BalanceMutationsAsync(MappedContractFees, null), Times.Once);
    }

    [Fact]
    public async Task TestThatBalanceEventsAsyncRetrievesFromDaoAndResponseReturnsOrganisationResponse()
    {
        _mockedOrganizationDao.Setup(od => od.ByRangeAsync((DateTime)Request.Options.DateRange!.Minimum!, (DateTime)Request.Options.DateRange!.Maximum!, Request.Options.CountryCodes!.ToArray()))
            .ReturnsAsync(ValidOrganizationIds);

        _mockedContractDao.Setup(cd => cd.OrganizationContractsAsync(ValidOrganizationId))
            .ReturnsAsync(MappedContractFees);

        _mockedEventDao.Setup(ed => ed.BalanceMutationsAsync(MappedContractFees, null))
            .ReturnsAsync(EventBalancesDollar);

        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<List<EventBalanceResponse>>(It.IsAny<string>()))
            .ReturnsAsync(() => null!);

        await _sut.BalanceMutationsAsync(Request);

        _mockedContractDao.Verify(cd => cd.OrganizationContractsAsync(ValidOrganizationId), Times.Once);
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<List<EventBalanceResponse>>(It.IsAny<string>()), Times.Once);
        _mockedCacheService.Verify(cs => cs.CacheObjectAsync(It.IsAny<string>(), It.IsAny<List<EventBalanceResponse>>(), It.IsAny<TimeSpan>()), Times.Once);
        _mockedEventDao.Verify(ed => ed.BalanceMutationsAsync(MappedContractFees, null), Times.Once);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncCallsEventDaoListSelectOptionsAsync()
    {
        _mockedEventDao.Setup(ed => ed.ListSelectOptionsAsync(ValidOrganizationId, It.IsAny<IList<Guid>>(), It.IsAny<string?>()))
            .ReturnsAsync([
                new SelectOption<Guid>
                {
                    Id = Guid.Empty,
                    Label = "MyLabel"
                }
            ]);

        var actual = (await _sut.ListSelectOptionsAsync(ValidOrganizationId, new SelectOptionsRequest<Guid>())).ToList();

        Assert.Single(actual);
        Assert.Equal("MyLabel", actual[0].Label);

        _mockedEventDao.Verify(ed => ed.ListSelectOptionsAsync(ValidOrganizationId, It.IsAny<IList<Guid>>(), It.IsAny<string?>()), Times.Once);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncCallsEventDaoListSelectOptionsAsyncWithoutOrganizationId()
    {
        _mockedEventDao.Setup(ed => ed.ListSelectOptionsAsync(null, It.IsAny<IList<Guid>>(), It.IsAny<string?>()))
            .ReturnsAsync([
                new SelectOption<Guid>
                {
                    Id = Guid.Empty,
                    Label = "MyLabel"
                }
            ]);

        var actual = (await _sut.ListSelectOptionsAsync(new SelectOptionsRequest<Guid>())).ToList();

        Assert.Single(actual);
        Assert.Equal("MyLabel", actual[0].Label);

        _mockedEventDao.Verify(ed => ed.ListSelectOptionsAsync(null, It.IsAny<IList<Guid>>(), It.IsAny<string?>()), Times.Once);
    }
}