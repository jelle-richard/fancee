using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Dtos.Requests.Event.Media;
using EventService.Dtos.Responses.Event;
using EventService.Persistence.Event;
using EventService.Persistence.EventMedia;
using EventService.Persistence.Order;
using EventService.Persistence.Organization;
using EventService.Persistence.PaymentMethod;
using EventService.Persistence.Product;
using EventService.Persistence.Product.Ticket;
using EventService.Persistence.Shop;
using EventService.Persistence.Ticket;
using EventService.Services.Event.Exceptions;
using EventService.Services.Shop;
using FanceeData.Models.Ticketing;
using JetBrains.Annotations;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Requests.Event;
using WebApiCore.Dtos.Responses.Event;
using WebApiCore.Dtos.Shared.Contract;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Event;
using WebApiCore.Persistence.Contract;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Organization;
using WebApiCore.Services.PaymentMethod;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using File = FanceeData.Models.Ticketing.File;

namespace EventService.Tests.Services.Event;

[TestSubject(typeof(EventService.Services.Event.EventService))]
public class EventServiceTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid InvalidEventId = Guid.NewGuid();

    private static readonly List<ContractFee> ContractFees = new()
    {
        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-60),
            PeriodEnd = DateTime.UtcNow.AddDays(-40),
            ProductFeeCents = 83,
            ProductFeePercentage = 0,
            TicketFeeCents = 83,
            TicketFeePercentage = 0,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 20
        },
        new()
        {
            PeriodStart = DateTime.UtcNow.AddDays(-39),
            PeriodEnd = DateTime.UtcNow.AddDays(-20),
            ProductFeeCents = 83,
            ProductFeePercentage = 0,
            TicketFeeCents = 83,
            TicketFeePercentage = 0,
            SeatedTicketFeeCents = 0,
            SeatedTicketFeePercentage = 0,
            GuestListFeeCents = 20
        }
    };

    private readonly CopyEventRequest _copyEventRequest = new()
    {
        CopyCategories = true,
        CopyProducts = true,
        CopyShops = true,
        CopyTags = true,
        CopyPaymentMethods = true,
        CopyMedia = true
    };

    private readonly EventService.Services.Event.EventService _sut;
    private readonly Mock<IEventDao> _mockedEventDao = new();
    private readonly Mock<ITicketDesignDao> _mockedTicketDesignDao = new();
    private readonly Mock<IOrderDao> _mockedOrderDao = new();
    private readonly Mock<IOrganizationDao> _mockedOrganizationDao = new();
    private readonly Mock<IPaymentMethodDao> _mockedPaymentMethodDao = new();
    private readonly Mock<IPaymentMethodService> _mockedPaymentMethodService = new();
    private readonly Mock<IProductDao> _mockedProductDao = new();
    private readonly Mock<IShopService> _mockedShopService = new();
    private readonly Mock<ITicketDao> _mockedTicketDao = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IEventMediaDao> _mockedEventMediaDao = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IShopFieldRequirementDao> _mockedShopFieldRequirementsDao = new();
    private readonly Mock<IContractDao> _mockedContractDao = new();
    private readonly Mock<IOrganizationService> _mockedOrganizationService = new();

    private readonly List<PaymentMethod> _validPaymentMethods = new()
    {
        new()
        {
            Id = Guid.NewGuid(),
            Name = "IDeal"
        },
        new()
        {
            Id = Guid.NewGuid(),
            Name = "IDeal"
        },
        new()
        {
            Id = Guid.NewGuid(),
            Name = "PayPal"
        }
    };

    public EventServiceTests()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment
        {
            Id = Guid.NewGuid(),
            Name = "UnitTestEnv",
            Domain = "localhost",
            IsHttps = false
        });

        _sut = new(
            _mockedEventDao.Object,
            _mockedProductDao.Object,
            _mockedOrganizationDao.Object,
            _mockedPaymentMethodDao.Object,
            _mockedShopService.Object,
            _mockedOrderDao.Object,
            _mockedTicketDao.Object,
            _mockedPaymentMethodService.Object,
            _mockedUploadService.Object,
            _mockedEventMediaDao.Object,
            _mockedStorageService.Object,
            _mockedDeploymentEnvironmentService.Object,
            _mockedTicketDesignDao.Object,
            _mockedShopFieldRequirementsDao.Object,
            _mockedContractDao.Object,
            _mockedOrganizationService.Object);
    }

    [Fact]
    public async Task TestThatCreateAsyncConvertsAndInsertsCreateEventRequest()
    {
        await _sut.CreateAsync(new()
        {
            Address = new() { CountryCode = "NL" },
            Categories = Array.Empty<string>(),
            Description = "UnitTestEvent",
            EndDate = DateTime.Now.AddDays(5),
            StartDate = DateTime.Now.AddMinutes(10),
            Name = "UnitTestEvent",
            Type = EventType.Normal
        });

        _mockedEventDao.Verify(e => e.InsertAsync(It.IsAny<FanceeData.Models.Ticketing.Event>()), Times.Once);
    }

    [Fact]
    public async Task TestThatGetAsyncThrowsInvalidEventExceptionWhenEventDaoReturnsNull()
    {
        _mockedEventDao.Setup(ed => ed.GetAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<HostedDeploymentEnvironment>())).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.GetAsync(Guid.NewGuid(), Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsEventForOrganization()
    {
        var organizationId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedEventDao.Setup(ed => ed.GetAsync(eventId, organizationId, It.IsAny<HostedDeploymentEnvironment>())).ReturnsAsync(new EventResponse { Id = eventId });

        var actual = await _sut.GetAsync(eventId, organizationId);

        Assert.NotNull(actual);
        Assert.Equal(eventId, actual.Id);
    }

    [Fact]
    public async Task TestThatUpdateAsyncThrowsEventInUseExceptionIfSealStateIsChangedForEventWithSalesOrReservations()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                IsSealed = true
            });

        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<EventInUseException>(async () => await _sut.UpdateAsync(Guid.NewGuid(), Guid.NewGuid(), new()
        {
            IsSealed = false
        }));
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsShopFieldRequirementsDaoShopsAndShopFieldRequirementsByEventIdAndShopFieldAsyncWhenMinimumAge()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags))).ReturnsAsync(new FanceeData.Models.Ticketing.Event());
        _mockedShopFieldRequirementsDao.Setup(sd => sd.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate))
            .ReturnsAsync(
                It.IsAny<List<FanceeData.Models.Ticketing.Shop>>()
            );
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await _sut.UpdateAsync(ValidOrganizationId, ValidEventId, new()
        {
            Address = new() { City = "UnitTest" },
            Categories = new[] { "Metal" },
            Tags = new[] { "TestTag1" },
            Type = EventType.Seating,
            MinAge = 16
        });

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Address != null)), Times.Once);
        _mockedShopFieldRequirementsDao.Verify(sfr => sfr.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncSkipsShopFieldRequirementsDaoAddAsyncWhenMinimumAgeButShopFieldRequirementAlreadySetCorrectly()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags))).ReturnsAsync(new FanceeData.Models.Ticketing.Event());
        _mockedShopFieldRequirementsDao.Setup(sd => sd.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate))
            .ReturnsAsync(new List<FanceeData.Models.Ticketing.Shop> { new() { ShopFieldRequirements = new List<ShopFieldRequirement> { new() { Enabled = true, Required = true } } } });
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await _sut.UpdateAsync(ValidOrganizationId, ValidEventId, new()
        {
            Address = new() { City = "UnitTest" },
            Categories = new[] { "Metal" },
            Tags = new[] { "TestTag1" },
            Type = EventType.Seating,
            MinAge = 16
        });

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Address != null)), Times.Once);
        _mockedShopFieldRequirementsDao.Verify(sfr => sfr.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate), Times.Once);
        _mockedShopFieldRequirementsDao.Verify(sd => sd.AddAsync(It.IsAny<List<ShopFieldRequirement>>()), Times.Never);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsShopFieldRequirementsDaoAddAsyncWhenMinimumAge()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags))).ReturnsAsync(new FanceeData.Models.Ticketing.Event());
        _mockedShopFieldRequirementsDao.Setup(sd => sd.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate))
            .ReturnsAsync(new List<FanceeData.Models.Ticketing.Shop> { new(), new() });
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await _sut.UpdateAsync(ValidOrganizationId, ValidEventId, new()
        {
            Address = new() { City = "UnitTest" },
            Categories = new[] { "Metal" },
            Tags = new[] { "TestTag1" },
            Type = EventType.Seating,
            MinAge = 16
        });

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Address != null)), Times.Once);
        _mockedShopFieldRequirementsDao.Verify(sfr => sfr.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate), Times.Once);
        _mockedShopFieldRequirementsDao.Verify(sd => sd.AddAsync(It.Is<List<ShopFieldRequirement>>(list => list.Count == 2)), Times.Once);
        _mockedShopFieldRequirementsDao.Verify(sd => sd.UpdateAsync(It.IsAny<List<ShopFieldRequirement>>()), Times.Never);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsShopFieldRequirementsDaoUpdateAsyncWhenMinimumAgeWhileShopFieldRequirementExistsButIncorrect()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags))).ReturnsAsync(new FanceeData.Models.Ticketing.Event());
        _mockedShopFieldRequirementsDao.Setup(sd => sd.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate))
            .ReturnsAsync(new List<FanceeData.Models.Ticketing.Shop>
            {
                new()
                {
                    ShopFieldRequirements = new List<ShopFieldRequirement>
                    {
                        new() { Enabled = false, Required = false }
                    }
                },
                new()
                {
                    ShopFieldRequirements = new List<ShopFieldRequirement>
                    {
                        new() { Enabled = false, Required = false }
                    }
                }
            });
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await _sut.UpdateAsync(ValidOrganizationId, ValidEventId, new()
        {
            Address = new() { City = "UnitTest" },
            Categories = new[] { "Metal" },
            Tags = new[] { "TestTag1" },
            Type = EventType.Seating,
            MinAge = 16
        });

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Address != null)), Times.Once);
        _mockedShopFieldRequirementsDao.Verify(sfr => sfr.ShopsAndShopFieldRequirementsByEventIdAndShopFieldAsync(It.IsAny<Guid>(), ShopField.Birthdate), Times.Once());
        _mockedShopFieldRequirementsDao.Verify(sd => sd.AddAsync(It.IsAny<List<ShopFieldRequirement>>()), Times.Never);
        _mockedShopFieldRequirementsDao.Verify(sd => sd.UpdateAsync(It.Is<List<ShopFieldRequirement>>(list => list.Count == 2)), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsEventDaoUpdateAsync()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags))).ReturnsAsync(new FanceeData.Models.Ticketing.Event());
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await _sut.UpdateAsync(ValidOrganizationId, ValidEventId, new()
        {
            Address = new() { City = "UnitTest" },
            Categories = new[] { "Metal" },
            Tags = new[] { "TestTag1" },
            Type = EventType.Seating
        });

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Address != null)), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesSeatsIoEventId()
    {
        var seatsIoEventId = Guid.NewGuid();

        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags))).ReturnsAsync(new FanceeData.Models.Ticketing.Event());
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await _sut.UpdateAsync(ValidOrganizationId, ValidEventId, new()
        {
            Type = EventType.Seating,
            SeatsIoEventId = seatsIoEventId,
            Categories = Array.Empty<string>(),
            Tags = Array.Empty<string>()
        });

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.SeatsIoEventId == seatsIoEventId)), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncSetsAddressToNullIfNewAddressIsNull()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories).Include(e => e.Tags))).ReturnsAsync(new FanceeData.Models.Ticketing.Event());
        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(false);

        await _sut.UpdateAsync(ValidOrganizationId, ValidEventId, new()
        {
            Address = new(),
            Categories = new[] { "Metal" },
            Tags = new[] { "TestTag1" },
            Type = EventType.Seating
        });

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Address == null)), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncThrowsInvalidEventExceptionOnInvalidEvent()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(InvalidEventId, ValidOrganizationId, i => i.Include(e => e.Address).Include(e => e.Categories))).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.UpdateAsync(ValidOrganizationId, InvalidEventId, new()));
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsEventInUseExceptionWhenOneOrMoreProductsHasSalesOrReservations()
    {
        var eventId = Guid.NewGuid();

        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(eventId)).ReturnsAsync(true);

        await Assert.ThrowsAsync<EventInUseException>(async () => await _sut.DeleteAsync(eventId));
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsEventDaoDeleteAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedProductDao.Setup(pd => pd.HasSalesOrReservationsAsync(eventId)).ReturnsAsync(false);

        await _sut.DeleteAsync(eventId);

        _mockedProductDao.Verify(pd => pd.HasSalesOrReservationsAsync(eventId), Times.Once);
        _mockedEventDao.Verify(ed => ed.DeleteAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatAvailablePaymentMethodsCallsPaymentMethodDaoAvailablePaymentMethodsAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedPaymentMethodDao.Setup(pmd => pmd.AvailablePaymentMethodsAsync(eventId)).ReturnsAsync(new List<(PaymentMethod, PaidBy?)>
        {
            (
                new()
                {
                    Id = Guid.NewGuid(),
                    Active = true,
                    FeePercentage = 1,
                    FeeStaticCents = 10,
                    Name = "UnitTest",
                    Provider = PaymentProvider.Adyen
                },
                PaidBy.Organization
            )
        });

        var actual = (await _sut.AvailablePaymentMethodsAsync(eventId)).ToList();

        Assert.Single(actual);
        Assert.Equal(PaidByDto.Organization, actual[0].PaidBy);

        _mockedPaymentMethodDao.Verify(pmd => pmd.AvailablePaymentMethodsAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignPaymentMethodsAsyncCallsPaymentMethodServiceValidatePaymentMethodAssignmentConfiguration()
    {
        var request = new PaymentMethodRequestModel { Id = Guid.NewGuid(), PaidBy = PaidByDto.Organization };
        var eventId = Guid.NewGuid();
        var @event = new FanceeData.Models.Ticketing.Event
        {
            Id = eventId,
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    PaymentMethod = _validPaymentMethods.First(),
                    PaymentMethodId = _validPaymentMethods.First().Id,
                    EventId = eventId,
                    PaidBy = PaidBy.Client
                }
            }
        };

        _mockedPaymentMethodService.Setup(pms => pms.ByIdsAsync(new[] { (Guid)request.Id })).ReturnsAsync(new List<PaymentMethod>());
        _mockedPaymentMethodService.Setup(pms => pms.ValidatePaymentMethodAssignmentConfiguration(It.IsAny<IEnumerable<PaymentMethodRequestModel>>(), It.IsAny<IList<PaymentMethod>>()));
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.PaymentMethods)))
            .ReturnsAsync(@event);

        await _sut.AssignPaymentMethodsAsync(ValidEventId, ValidOrganizationId, new[] { request });

        _mockedPaymentMethodService.Verify(pms => pms.ValidatePaymentMethodAssignmentConfiguration(It.IsAny<IEnumerable<PaymentMethodRequestModel>>(), It.IsAny<IList<PaymentMethod>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAssignPaymentMethodsAsyncUpdatesEvent()
    {
        Guid[] paymentMethodIds = { _validPaymentMethods[0].Id, _validPaymentMethods[2].Id };
        var eventId = Guid.NewGuid();

        var @event = new FanceeData.Models.Ticketing.Event
        {
            Id = eventId,
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    PaymentMethod = _validPaymentMethods.First(),
                    PaymentMethodId = _validPaymentMethods.First().Id,
                    EventId = eventId,
                    PaidBy = PaidBy.Client
                }
            }
        };

        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.PaymentMethods))).ReturnsAsync(@event);
        _mockedPaymentMethodService.Setup(pms => pms.ByIdsAsync(paymentMethodIds)).ReturnsAsync(new List<PaymentMethod>
        {
            _validPaymentMethods.First(pmv => pmv.Id == paymentMethodIds[0]),
            _validPaymentMethods.First(pmv => pmv.Id == paymentMethodIds[1])
        });

        var request = new PaymentMethodRequestModel[]
        {
            new() { Id = paymentMethodIds[0], PaidBy = PaidByDto.Organization },
            new() { Id = paymentMethodIds[1], PaidBy = PaidByDto.Client }
        };

        await _sut.AssignPaymentMethodsAsync(ValidEventId, ValidOrganizationId, request);

        _mockedPaymentMethodService.Verify(pms => pms.ByIdsAsync(paymentMethodIds), Times.Once);
        _mockedEventDao.Verify(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.PaymentMethods)), Times.Once);
        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e =>
            e.PaymentMethods.All(pmv => pmv.PaymentMethodId == paymentMethodIds[0] || pmv.PaymentMethodId == paymentMethodIds[1]))
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatCopyEventAsyncThrowsEventNotFoundExceptionOnInvalidRequestedEvent()
    {
        _mockedEventDao.Setup(ed => ed.CopyableEventAsync(It.IsAny<Guid>(), _copyEventRequest.CopyShops, _copyEventRequest.CopyProducts, _copyEventRequest.CopyPaymentMethods, _copyEventRequest.CopyCategories, _copyEventRequest.CopyTags, _copyEventRequest.CopyMedia))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.CopyEventAsync(Guid.NewGuid(), new()));
    }

    [Fact]
    public async Task TestThatCopyEventAsyncThrowsUnsupportedCopyEventTypeExceptionIfEventTypeIsSeating()
    {
        _mockedEventDao.Setup(ed => ed.CopyableEventAsync(Guid.Empty, false, false, false, false, false, false))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event { Type = EventType.Seating });

        await Assert.ThrowsAsync<UnsupportedCopyEventTypeException>(async () => await _sut.CopyEventAsync(Guid.Empty, new()));

        _mockedEventDao.Verify(ed => ed.CopyableEventAsync(Guid.Empty, false, false, false, false, false, false), Times.Once);
        _mockedEventDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCopyEventAsyncResetsShopCodeAndCallsInsertAsync()
    {
        var eventId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var productId2 = Guid.NewGuid();
        var shopElementId = Guid.NewGuid();
        var accordionElementId = Guid.NewGuid();
        var fileId = Guid.NewGuid();
        var fileId2 = Guid.NewGuid();
        var ticketDesignId = Guid.NewGuid();
        var ticketDesignId2 = Guid.NewGuid();

        var eventToCopy = new FanceeData.Models.Ticketing.Event
        {
            Id = eventId,
            Name = "UnitEvent",
            OrganizationId = ValidOrganizationId,
            Status = EventStatus.Active,
            Type = EventType.Normal,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddHours(2),
            Description = "Unit description",
            MinimumAge = 12,
            Address = new()
            {
                CountryCode = "NL",
                PostalCode = "1234AB",
                Street = "UnitStreet",
                City = "UnitCity",
                HouseNumber = "1a",
                Venue = "UnitPlaza",
                Latitude = 0,
                Longitude = 0
            },
            EventSetting = new()
            {
                RequestOrderInformation = false,
                RequestOrderEmail = false,
                RequestEntourageInformation = false,
                RequestCoronaQuestions = false,
                MailchimpListId = "",
                CustomFailedPurchaseLandingPageUrl = "",
                CustomProcessingPurchaseLandingPageUrl = "",
                CustomSuccessfulPurchaseLandingPageUrl = ""
            },
            Shops = new List<FanceeData.Models.Ticketing.Shop>
            {
                new()
                {
                    Code = "UnitShopCode",
                    ShopDesign = new(),
                    EventId = eventId,
                    ItemsInShop = new List<ItemInShop>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Position = 1,
                            ProductId = productId,
                            ShopCode = "UnitShopCode",
                            Shop = new()
                            {
                                EventId = eventId
                            },
                            Product = new()
                            {
                                Id = productId,
                                EventId = eventId
                            }
                        },
                        new()
                        {
                            Id = Guid.NewGuid(),
                            ShopElementId = shopElementId,
                            ShopElement = new DividerElement
                            {
                                Id = shopElementId,
                                Name = "Divider name"
                            },
                            Shop = new()
                            {
                                EventId = eventId
                            }
                        },
                        new()
                        {
                            Id = Guid.NewGuid(),
                            ShopElementId = accordionElementId,
                            ShopElement = new AccordionElement
                            {
                                Id = accordionElementId,
                                Icon = "open",
                                Title = "VIP Tickets",
                                Opened = false,
                                Elements = new List<AccordionShopElement>
                                {
                                    new()
                                    {
                                        Position = 1,
                                        ProductId = productId2,
                                        Product = new()
                                        {
                                            Id = productId2,
                                            EventId = eventId
                                        }
                                    },
                                    new()
                                    {
                                        Position = 2,
                                        ShopElement = new AccordionElement()
                                    }
                                }
                            },
                            Shop = new()
                            {
                                EventId = eventId
                            }
                        }
                    }
                }
            },
            Products = new List<FanceeData.Models.Ticketing.Product>
            {
                new()
                {
                    Id = productId,
                    Name = "UnitProduct",
                    EventId = eventId,
                    Stock = 11,
                    PriceCents = 100,
                    FeeCents = 50,
                    Description = "",
                    SaleStart = null,
                    SaleEnd = null,
                    MaximumPurchasePerOrder = 20,
                    IsSharedCapacityEligible = false,
                    MarkSoldOutOnSaleWindowExpired = false,
                    PackQuantity = 1,
                    Type = ProductType.Product,
                    TicketOption = new()
                    {
                        TicketDesignId = ticketDesignId2,
                        Design = new()
                        {
                            Id = ticketDesignId2,
                            DesignElements = new List<TicketDesignElement>
                            {
                                new TicketDesignMediaElement
                                {
                                    File = new()
                                    {
                                        Id = fileId,
                                        Name = "path",
                                        MimeType = "image/jpeg",
                                        Path = "path/to/file.jpg"
                                    }
                                },
                                new TicketDesignQrElement
                                {
                                    File = new()
                                    {
                                        Id = fileId2,
                                        Name = "path",
                                        MimeType = "image/gif",
                                        Path = "/another/path/from/root.gif"
                                    }
                                }
                            }
                        }
                    },
                    ProductMedia = new List<ProductMedia>()
                },
                new()
                {
                    Id = productId2,
                    Name = "UnitProduct2",
                    EventId = eventId,
                    Stock = 11,
                    PriceCents = 100,
                    Description = "",
                    SaleStart = null,
                    SaleEnd = null,
                    MaximumPurchasePerOrder = 20,
                    IsSharedCapacityEligible = false,
                    MarkSoldOutOnSaleWindowExpired = false,
                    PackQuantity = 1,
                    Type = ProductType.Product,
                    TicketOption = new()
                    {
                        TicketDesignId = ticketDesignId,
                        Design = new()
                        {
                            Id = ticketDesignId,
                            DesignElements = new List<TicketDesignElement>
                            {
                                new TicketDesignMediaElement
                                {
                                    File = new()
                                    {
                                        Id = fileId,
                                        Name = "path",
                                        MimeType = "image/jpeg",
                                        Path = "path.jpg"
                                    }
                                },
                                new TicketDesignQrElement
                                {
                                    File = new()
                                    {
                                        Id = fileId,
                                        Name = "path",
                                        MimeType = "image/jpeg",
                                        Path = "path.png"
                                    }
                                },
                                new TicketDesignQrElement()
                            }
                        }
                    },
                    ProductMedia = new List<ProductMedia>()
                },
                new()
                {
                    Id = productId,
                    Name = "UnitProduct",
                    EventId = eventId,
                    Stock = 11,
                    PriceCents = 100,
                    Description = "",
                    SaleStart = null,
                    SaleEnd = null,
                    MaximumPurchasePerOrder = 20,
                    IsSharedCapacityEligible = false,
                    MarkSoldOutOnSaleWindowExpired = false,
                    PackQuantity = 1,
                    Type = ProductType.Product,
                    TicketOption = new()
                    {
                        TicketDesignId = ticketDesignId,
                        Design = new()
                        {
                            Id = ticketDesignId,
                            DesignElements = new List<TicketDesignElement>
                            {
                                new TicketDesignMediaElement
                                {
                                    File = new()
                                    {
                                        Id = fileId,
                                        Name = "path",
                                        MimeType = "image/jpeg",
                                        Path = "path.jpg"
                                    }
                                },
                                new TicketDesignQrElement
                                {
                                    File = new()
                                    {
                                        Id = fileId,
                                        Name = "path",
                                        MimeType = "image/jpeg",
                                        Path = "picture.jpg"
                                    }
                                },
                                new TicketDesignQrElement()
                            }
                        }
                    },
                    ProductMedia = new List<ProductMedia>()
                },
                new()
                {
                    Id = productId,
                    Name = "UnitProduct",
                    EventId = eventId,
                    Stock = 11,
                    PriceCents = 100,
                    Description = "",
                    SaleStart = null,
                    SaleEnd = null,
                    MaximumPurchasePerOrder = 20,
                    IsSharedCapacityEligible = false,
                    MarkSoldOutOnSaleWindowExpired = false,
                    PackQuantity = 1,
                    Type = ProductType.Product,
                    TicketOption = new(),
                    ProductMedia = new List<ProductMedia>()
                }
            },
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    EventId = eventId
                }
            },
            Tags = new List<EventTag>
            {
                new()
                {
                    Name = "unitTag",
                    EventId = eventId
                }
            }
        };

        var eventFileLink = new List<TicketDesignMedia>
        {
            new()
            {
                EventId = eventId,
                FileId = fileId
            },
            new()
            {
                EventId = eventId,
                FileId = fileId2
            }
        };
        _mockedShopService.Setup(ss => ss.GetUniqueCodeAsync())
            .ReturnsAsync("NewUnitShopCode");

        _mockedEventDao.Setup(ed => ed.CopyableEventAsync(It.IsAny<Guid>(), _copyEventRequest.CopyShops, _copyEventRequest.CopyProducts, _copyEventRequest.CopyPaymentMethods, _copyEventRequest.CopyCategories, _copyEventRequest.CopyTags, _copyEventRequest.CopyMedia))
            .ReturnsAsync(eventToCopy);

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.TicketDesignMediaStoragePool, It.IsAny<string>()))
            .ReturnsAsync(new MemoryStream("I'm a ticket design media"u8.ToArray()));

        _mockedTicketDesignDao.Setup(tdd => tdd.InsertMediaRangeAsync(eventFileLink));

        _mockedEventDao.Setup(ed => ed.InsertAsync(eventToCopy));

        var actual = await _sut.CopyEventAsync(Guid.NewGuid(), _copyEventRequest);

        Assert.IsType<Guid>(actual);

        _mockedShopService.Verify(ss => ss.GetUniqueCodeAsync(), Times.Once);
        _mockedEventDao.Verify(ed => ed.InsertAsync(It.IsAny<FanceeData.Models.Ticketing.Event>()), Times.Once);
    }

    [Fact]
    public async Task TestThatStatisticsAsyncThrowsEventNotFoundExceptionOnUnRetrievableEventStartDate()
    {
        _mockedEventDao.Setup(ed => ed.StartDateAsync(It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.StatisticsAsync(Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatStatisticsAsyncCallsDaos()
    {
        var eventId = Guid.NewGuid();
        var eventStartDate = DateTime.UtcNow.AddDays(-5);

        _mockedEventDao.Setup(ed => ed.StartDateAsync(eventId))
            .ReturnsAsync(eventStartDate);

        _mockedProductDao.Setup(pd => pd.EventProductsSoldAsync(eventId))
            .ReturnsAsync(10);

        _mockedOrderDao.Setup(od => od.EventOrdersAsync(eventId))
            .ReturnsAsync(5);

        _mockedTicketDao.Setup(td => td.EventTicketsScannedAsync(eventId))
            .ReturnsAsync(3);

        _mockedOrderDao.Setup(od => od.AverageEventAgeByGendersAsync(eventId, eventStartDate))
            .ReturnsAsync(new AverageAgesGenderResponse());

        _mockedOrderDao.Setup(od => od.UniqueEventCustomersByGendersAsync(eventId))
            .ReturnsAsync(new UniqueCustomersGenderResponse());

        var actual = await _sut.StatisticsAsync(eventId);

        _mockedEventDao.Verify(ed => ed.StartDateAsync(eventId), Times.Once);
        _mockedProductDao.Verify(pd => pd.EventProductsSoldAsync(eventId), Times.Once);
        _mockedOrderDao.Verify(od => od.EventOrdersAsync(eventId), Times.Once);
        _mockedTicketDao.Verify(td => td.EventTicketsScannedAsync(eventId), Times.Once);
        _mockedOrderDao.Verify(od => od.AverageEventAgeByGendersAsync(eventId, eventStartDate), Times.Once);
        _mockedOrderDao.Verify(od => od.UniqueEventCustomersByGendersAsync(eventId), Times.Once);

        Assert.Equal(10, actual.ProductsSoldAmount);
        Assert.Equal(3, actual.TicketsScannedAmount);
    }

    [Fact]
    public async Task TestThatEventRevenuesAsyncCallsEventDaoEventRevenuesAsync()
    {
        var contractFees = new List<MappedOrganizationContractFee>
        {
            new()
            {
                OrganizationId = ValidOrganizationId,
                GuestListFeeCents = 20,
                ProductFeeCents = 30,
                TicketFeeCents = 40,
                SeatedTicketFeeCents = 0,
                SeatedTicketFeePercentage = 0,
                ProductFeePercentage = 0,
                TicketFeePercentage = 0,
                PeriodStart = DateTime.MinValue,
                PeriodEnd = DateTime.MaxValue
            }
        };

        _mockedContractDao.Setup(cd => cd.OrganizationContractsAsync(ValidOrganizationId)).ReturnsAsync(contractFees);

        _mockedEventDao.Setup(ed => ed.EventRevenuesAsync(ValidEventId, contractFees))
            .ReturnsAsync(new RevenueResponse
            {
                OnlineSalesRevenueCents = 1000,
                CashSalesRevenueCents = 100,
                PlatformExpensesCents = 83,
                ProfitCents = 1017
            });

        var actual = await _sut.RevenuesAsync(ValidEventId, ValidOrganizationId);

        Assert.Equal(1017, actual.ProfitCents);

        _mockedEventDao.Verify(ed => ed.EventRevenuesAsync(ValidEventId, contractFees), Times.Once);
    }

    [Fact]
    public async Task TestThatValidateAsyncReturnsCorrectValidationResultWithInvalidEvent()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event());

        var actual = await _sut.ValidateAsync(It.IsAny<Guid>(), It.IsAny<Guid>());

        Assert.NotNull(actual);
        Assert.False(actual.HasShops);
        Assert.False(actual.HasSellableProducts);
        Assert.False(actual.HasPaymentMethod);
        Assert.False(actual.CanBePublished);
    }

    [Fact]
    public async Task TestThatValidateAsyncReturnsTrueForHasSellableProductsIfOnlyAccordionElementWithProductsAreAvailable()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop>
                        {
                            new()
                            {
                                ShopElement = new AccordionElement
                                {
                                    Elements = new List<AccordionShopElement>
                                    {
                                        new()
                                        {
                                            //note: nested accordions are not allowed, but we test for it anyway
                                            ShopElement = new AccordionElement
                                            {
                                                Elements = new AccordionShopElement[] { new() { ProductId = Guid.NewGuid() } }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            });

        var actual = await _sut.ValidateAsync(It.IsAny<Guid>(), It.IsAny<Guid>());

        Assert.NotNull(actual);
        Assert.True(actual.HasSellableProducts);
    }

    [Fact]
    public async Task TestThatValidateAsyncReturnsCorrectValidationResultWithValidEvent()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(It.IsAny<Guid>(), It.IsAny<Guid>(), i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop>
                        {
                            new()
                            {
                                ProductId = Guid.NewGuid()
                            }
                        }
                    }
                },
                PaymentMethods = new List<EventPaymentMethod>
                {
                    new()
                }
            });

        var actual = await _sut.ValidateAsync(It.IsAny<Guid>(), It.IsAny<Guid>());

        Assert.NotNull(actual);
        Assert.True(actual.HasShops);
        Assert.True(actual.HasSellableProducts);
        Assert.True(actual.HasPaymentMethod);
        Assert.True(actual.CanBePublished);
    }

    [Fact]
    public async Task TestThatUploadMediaAsyncCallsCallbackOnSuccessfulUpload()
    {
        var eventId = Guid.NewGuid();

        var mockedMediaRequest = new Mock<UploadEventMediaRequest>();
        mockedMediaRequest.SetupAllProperties();
        mockedMediaRequest.Object.Media = new FormFile(new MemoryStream(), 0, 10, "unittest", "unittest.png");
        mockedMediaRequest.Setup(mr => mr.GetFileExtension()).Returns("png");
        mockedMediaRequest.Setup(mr => mr.GetMimeType()).Returns("image/png");

        _mockedEventMediaDao.Setup(pmd => pmd.NextPositionAsync(eventId)).ReturnsAsync(3);
        _mockedUploadService.Setup(us =>
                us.UploadAsync(mockedMediaRequest.Object, "events", null, It.IsAny<Func<File, Task>>()))
            .ReturnsAsync((UploadMediaRequest _, string _, string _, Func<File, Task> uploadedCallback) =>
            {
                uploadedCallback(new());
                return new() { Id = It.IsAny<Guid>(), Url = "unittest" };
            });

        var actual = await _sut.UploadMediaAsync(eventId, mockedMediaRequest.Object);

        Assert.NotNull(actual);
        Assert.Equal("unittest", actual.Url);

        _mockedUploadService.Verify(
            us => us.UploadAsync(mockedMediaRequest.Object, "events", null, It.IsAny<Func<File, Task>>()),
            Times.Once);
        _mockedEventMediaDao.Verify(pmd => pmd.NextPositionAsync(eventId), Times.Once);
        _mockedEventMediaDao.Verify(pmd => pmd.InsertAsync(It.Is<EventMedia>(pm => pm.Position == 3)));
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncThrowsMediaNotFoundExceptionOnInvalidFile()
    {
        var eventId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        _mockedEventMediaDao.Setup(pmd => pmd.ByIdAsync(fileId, eventId)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.DeleteMediaAsync(eventId, fileId));
    }

    [Fact]
    public async Task TestThatDeleteMediaAsyncDeletesMedia()
    {
        var eventId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        var model = new EventMedia
        {
            Position = 1,
            File = new()
            {
                Path = "uploads/events/image.png"
            }
        };

        _mockedEventMediaDao.Setup(pmd => pmd.ByIdAsync(fileId, eventId)).ReturnsAsync(model);

        await _sut.DeleteMediaAsync(eventId, fileId);

        _mockedEventMediaDao.Verify(pmd => pmd.ByIdAsync(fileId, eventId), Times.Once);
        _mockedStorageService.Verify(ss => ss.DeleteFileAsync("events", "image.png"), Times.Once);
        _mockedEventMediaDao.Verify(pmd => pmd.DeleteAsync(model), Times.Once);
        _mockedEventMediaDao.Verify(pmd => pmd.RepositionMediaAsync(eventId, 1), Times.Once);
    }

    [Fact]
    public async Task TestThatOwnerOfMediaAsyncCallsEventMediaDao()
    {
        var eventId = Guid.NewGuid();
        var fileId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        await _sut.OwnerOfMediaAsync(organizationId, fileId, eventId);

        _mockedEventMediaDao.Verify(pmd => pmd.OwnerOfMediaAsync(fileId, eventId, organizationId), Times.Once);
    }

    [Fact]
    public async Task TestThatCustomerCountryStatisticsAsyncCallsOrderDaoCustomerCountryStatisticsAsync()
    {
        var eventId = Guid.NewGuid();

        _mockedOrderDao.Setup(od => od.CustomerCountryStatisticsAsync(eventId))
            .ReturnsAsync(new List<EventCustomersCountryStatisticsResponse>());

        var actual = await _sut.CustomerCountryStatisticsAsync(eventId);

        _mockedOrderDao.Verify(od => od.CustomerCountryStatisticsAsync(eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatCopyEventAsyncThrowsFileNotFoundOnCopyTicketDesignAsync()
    {
        var eventId = Guid.NewGuid();
        var productId = Guid.NewGuid();
        var shopElementId = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        var eventToCopy = new FanceeData.Models.Ticketing.Event
        {
            Id = eventId,
            Name = "UnitEvent",
            OrganizationId = ValidOrganizationId,
            Status = EventStatus.Active,
            Type = EventType.Normal,
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddHours(2),
            Description = "Unit description",
            MinimumAge = 12,
            Address = new()
            {
                CountryCode = "NL",
                PostalCode = "1234AB",
                Street = "UnitStreet",
                City = "UnitCity",
                HouseNumber = "1a",
                Venue = "UnitPlaza",
                Latitude = 0,
                Longitude = 0
            },
            EventSetting = new()
            {
                RequestOrderInformation = false,
                RequestOrderEmail = false,
                RequestEntourageInformation = false,
                RequestCoronaQuestions = false,
                MailchimpListId = "",
                CustomFailedPurchaseLandingPageUrl = "",
                CustomProcessingPurchaseLandingPageUrl = "",
                CustomSuccessfulPurchaseLandingPageUrl = ""
            },
            Shops = new List<FanceeData.Models.Ticketing.Shop>
            {
                new()
                {
                    Code = "UnitShopCode",
                    ShopDesign = new(),
                    EventId = eventId,
                    ItemsInShop = new List<ItemInShop>
                    {
                        new()
                        {
                            Id = Guid.NewGuid(),
                            Position = 1,
                            ProductId = productId,
                            ShopCode = "UnitShopCode",
                            Shop = new()
                            {
                                EventId = eventId
                            },
                            Product = new()
                            {
                                Id = productId,
                                EventId = eventId
                            }
                        },
                        new()
                        {
                            Id = Guid.NewGuid(),
                            ShopElementId = shopElementId,
                            ShopElement = new DividerElement
                            {
                                Id = shopElementId,
                                Name = "Divider name"
                            },
                            Shop = new()
                            {
                                EventId = eventId
                            }
                        }
                    }
                }
            },
            Products = new List<FanceeData.Models.Ticketing.Product>
            {
                new()
                {
                    Id = productId,
                    Name = "UnitProduct",
                    EventId = eventId,
                    Stock = 11,
                    PriceCents = 100,
                    Description = "",
                    SaleStart = null,
                    SaleEnd = null,
                    MaximumPurchasePerOrder = 20,
                    IsSharedCapacityEligible = false,
                    MarkSoldOutOnSaleWindowExpired = false,
                    PackQuantity = 1,
                    Type = ProductType.Product,
                    TicketOption = new()
                    {
                        TicketDesignId = null
                    },
                    ProductMedia = new List<ProductMedia>()
                },
                new()
                {
                    Id = productId,
                    Name = "UnitProduct",
                    EventId = eventId,
                    Stock = 11,
                    PriceCents = 100,
                    Description = "",
                    SaleStart = null,
                    SaleEnd = null,
                    MaximumPurchasePerOrder = 20,
                    IsSharedCapacityEligible = false,
                    MarkSoldOutOnSaleWindowExpired = false,
                    PackQuantity = 1,
                    Type = ProductType.Product,
                    TicketOption = new()
                    {
                        Design = new()
                        {
                            DesignElements = new List<TicketDesignElement>
                            {
                                new TicketDesignMediaElement
                                {
                                    File = new()
                                    {
                                        Id = fileId,
                                        Name = "path",
                                        MimeType = "image/jpeg"
                                    }
                                },
                                new TicketDesignQrElement
                                {
                                    File = new()
                                    {
                                        Id = fileId,
                                        Name = "path",
                                        MimeType = "image/jpeg"
                                    }
                                }
                            }
                        }
                    },
                    ProductMedia = new List<ProductMedia>()
                }
            },
            PaymentMethods = new List<EventPaymentMethod>
            {
                new()
                {
                    EventId = eventId
                }
            },
            Tags = new List<EventTag>
            {
                new()
                {
                    Name = "unitTag",
                    EventId = eventId
                }
            }
        };

        _mockedShopService.Setup(ss => ss.GetUniqueCodeAsync())
            .ReturnsAsync("NewUnitShopCode");

        _mockedEventDao.Setup(ed => ed.CopyableEventAsync(It.IsAny<Guid>(), _copyEventRequest.CopyShops, _copyEventRequest.CopyProducts, _copyEventRequest.CopyPaymentMethods, _copyEventRequest.CopyCategories, _copyEventRequest.CopyTags, _copyEventRequest.CopyMedia))
            .ReturnsAsync(eventToCopy);

        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.TicketDesignMediaStoragePool, $"{eventId}/path.jpg"));
        await Assert.ThrowsAsync<FileNotFoundException>(() => _sut.CopyEventAsync(Guid.NewGuid(), _copyEventRequest));
    }

    [Fact]
    public async Task TestThatCustomerCityStatisticsAsyncCallsOrderDaoCustomerCityStatisticsAsync()
    {
        var eventId = Guid.NewGuid();
        var countryCode = "NL";

        _mockedOrderDao.Setup(od => od.CustomerCityStatisticsAsync(eventId, countryCode))
            .ReturnsAsync(new List<EventCustomersCityStatisticsResponse>());

        var actual = await _sut.CustomerCityStatisticsAsync(eventId, countryCode);

        _mockedOrderDao.Verify(od => od.CustomerCityStatisticsAsync(eventId, countryCode), Times.Once);
    }

    [Fact]
    public async Task TestThatRevenuesAsyncCallsEventDaoRevenuesAsync()
    {
        _mockedContractDao.Setup(cd => cd.ContractFeesAsync(ValidOrganizationId))
            .ReturnsAsync(ContractFees);

        _mockedEventDao.Setup(ed => ed.RevenuesAsync(ValidOrganizationId, ContractFees))
            .ReturnsAsync(new RevenueResponse
            {
                OnlineSalesRevenueCents = 1000,
                CashSalesRevenueCents = 100,
                PlatformExpensesCents = 83,
                ProfitCents = 1017
            });

        var actual = await _sut.RevenuesAsync(ValidOrganizationId);

        Assert.Equal(1017, actual.ProfitCents);

        _mockedEventDao.Verify(ed => ed.RevenuesAsync(ValidOrganizationId, ContractFees), Times.Once);
    }
}