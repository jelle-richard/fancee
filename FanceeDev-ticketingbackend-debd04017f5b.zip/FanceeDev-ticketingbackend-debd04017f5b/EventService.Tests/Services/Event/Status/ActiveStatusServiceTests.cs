﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Persistence.Event;
using EventService.Services.Event.Status;
using EventService.Services.Event.Status.Exceptions;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Exceptions.Event;

namespace EventService.Tests.Services.Event.Status;

public class ActiveStatusServiceTests
{
    public static readonly object[][] NoActiveShopsTestData =
    {
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop> { new() { Active = false } }
            }
        },
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>()
            }
        },
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = null
            }
        }
    };

    public static readonly object[][] NoAssignedProductsTestData =
    {
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = null
                    }
                }
            }
        },
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop>()
                    }
                }
            }
        },
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop>
                        {
                            new() { ShopElementId = Guid.NewGuid() }
                        }
                    }
                }
            }
        },
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop>()
                    },
                    new()
                    {
                        Active = false,
                        ItemsInShop = new List<ItemInShop>
                        {
                            new() { ProductId = Guid.NewGuid() }
                        }
                    }
                }
            }
        },
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop>
                        {
                            new()
                            {
                                ShopElement = new AccordionElement
                                {
                                    Elements = new List<AccordionShopElement>
                                    {
                                        new()
                                        {
                                            //note: nested accordions are not allowed, but we test for it anyway
                                            ShopElement = new AccordionElement
                                            {
                                                Elements = new List<AccordionShopElement> { new() { ShopElement = new NoticeElement() } }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    };

    public static readonly object[][] NoPaymentMethodsTestData =
    {
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop> { new() { ProductId = Guid.NewGuid() } }
                    }
                },
                PaymentMethods = null
            }
        },
        new object[]
        {
            new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Unpublished,
                Shops = new List<FanceeData.Models.Ticketing.Shop>
                {
                    new()
                    {
                        Active = true,
                        ItemsInShop = new List<ItemInShop> { new() { ProductId = Guid.NewGuid() } }
                    }
                },
                PaymentMethods = new List<EventPaymentMethod>()
            }
        }
    };

    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private static readonly FanceeData.Models.Ticketing.Event ValidEvent = new()
    {
        Status = EventStatus.Unpublished,
        Shops = new List<FanceeData.Models.Ticketing.Shop>
        {
            new()
            {
                Active = true,
                ItemsInShop = new List<ItemInShop> { new() { ProductId = Guid.NewGuid() } }
            }
        },
        PaymentMethods = new List<EventPaymentMethod>
        {
            new()
        }
    };

    private static readonly FanceeData.Models.Ticketing.Event ValidAccordionOnlyEvent = new()
    {
        Status = EventStatus.Unpublished,
        Shops = new List<FanceeData.Models.Ticketing.Shop>
        {
            new()
            {
                Active = true,
                ItemsInShop = new List<ItemInShop>
                {
                    new()
                    {
                        ShopElement = new AccordionElement
                        {
                            Elements = new List<AccordionShopElement>
                            {
                                new() { ProductId = Guid.NewGuid() }
                            }
                        }
                    }
                }
            }
        },
        PaymentMethods = new List<EventPaymentMethod>
        {
            new()
        }
    };

    private static readonly FanceeData.Models.Ticketing.Event ValidSeatingEventWithNoProductsInShop = new()
    {
        Status = EventStatus.Unpublished,
        Type = EventType.Seating,
        Shops = new List<FanceeData.Models.Ticketing.Shop>
        {
            new()
            {
                Active = true,
                ItemsInShop = new List<ItemInShop>
                {
                    new()
                    {
                        ShopElement = new SeatingMapElement()
                    }
                }
            }
        },
        PaymentMethods = new List<EventPaymentMethod>
        {
            new()
        }
    };

    private static readonly FanceeData.Models.Ticketing.Event InvalidSeatingEvent = new()
    {
        Status = EventStatus.Unpublished,
        Type = EventType.Normal,
        Shops = new List<FanceeData.Models.Ticketing.Shop>
        {
            new()
            {
                Active = true,
                ItemsInShop = new List<ItemInShop>
                {
                    new()
                    {
                        ShopElement = new SeatingMapElement()
                    }
                }
            }
        },
        PaymentMethods = new List<EventPaymentMethod>
        {
            new()
        }
    };

    private readonly ActiveStatusService _sut;
    private readonly Mock<IEventDao> _mockedEventDao = new();

    public ActiveStatusServiceTests()
    {
        _sut = new(_mockedEventDao.Object);
    }

    [Fact]
    public void TestThatGetStatusReturnsActive()
    {
        Assert.Equal(ChangeableEventStatus.Active, _sut.GetStatus());
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncThrowsEventNotFoundExceptionOnInvalidEventId()
    {
        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.ChangeStatusAsync(Guid.NewGuid(), Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncReturnsIfStatusIsEqualToNewStatus()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Active
            });

        await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId);

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Event>()), Times.Never);
    }

    [Theory]
    [MemberData(nameof(NoActiveShopsTestData))]
    public async Task TestThatChangeStatusAsyncThrowsNoActiveShopsExceptionIfNoActiveShopsAreConfigured(FanceeData.Models.Ticketing.Event @event)
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(@event);

        await Assert.ThrowsAsync<NoActiveShopsException>(async () => await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId));
    }

    [Theory]
    [MemberData(nameof(NoAssignedProductsTestData))]
    public async Task TestThatChangeStatusAsyncThrowsNoAssignedProductsExceptionIfNoActiveShopsWithProductsAreConfigured(FanceeData.Models.Ticketing.Event @event)
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(@event);

        await Assert.ThrowsAsync<NoAssignedProductsException>(async () => await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncThrowsNoAssignedProductsExceptionIfShopHasSeatingMapButEventIsNotOfTypeSeating()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(InvalidSeatingEvent);

        await Assert.ThrowsAsync<NoAssignedProductsException>(async () => await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId));
    }

    [Theory]
    [MemberData(nameof(NoPaymentMethodsTestData))]
    public async Task TestThatChangeStatusAsyncThrowsNoPaymentMethodsExceptionIfNoPaymentMethodsAreConfigured(FanceeData.Models.Ticketing.Event @event)
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(@event);

        await Assert.ThrowsAsync<NoPaymentMethodsException>(async () => await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncChangesStatusOfEvent()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(ValidEvent);

        await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId);

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Status == EventStatus.Active)), Times.Once);
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncChangesStatusOfEventForEventWithOnlyNestedAccordionProducts()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(ValidAccordionOnlyEvent);

        await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId);

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Status == EventStatus.Active)), Times.Once);
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncChangesStatusForSeatingEventsWithNoProductsInShop()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, i => i.Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .Include(e => e.Shops)
                .ThenInclude(s => s.ItemsInShop)
                .ThenInclude(iis => (iis.ShopElement as AccordionElement)!.Elements)
                .ThenInclude(e => e.ShopElement)
                .Include(e => e.PaymentMethods)
            ))
            .ReturnsAsync(ValidSeatingEventWithNoProductsInShop);

        await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId);

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Status == EventStatus.Active)), Times.Once);
    }
}