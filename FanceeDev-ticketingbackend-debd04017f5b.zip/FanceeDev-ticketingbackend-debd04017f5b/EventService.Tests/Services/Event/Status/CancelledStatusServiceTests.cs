﻿using System;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Persistence.Event;
using EventService.Services.Event.Status;
using FanceeData.Models.Ticketing;
using WebApiCore.Exceptions.Event;

namespace EventService.Tests.Services.Event.Status;

public class CancelledStatusServiceTests
{
    private static readonly Guid ValidEventId = Guid.NewGuid();
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();
    private readonly CancelledStatusService _sut;
    private readonly Mock<IEventDao> _mockedEventDao = new();

    public CancelledStatusServiceTests()
    {
        _sut = new(_mockedEventDao.Object);
    }

    [Fact]
    public void TestThatGetStatusReturnsCancelled()
    {
        Assert.Equal(ChangeableEventStatus.Cancelled, _sut.GetStatus());
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncThrowsEventNotFoundExceptionOnInvalidEventId()
    {
        await Assert.ThrowsAsync<EventNotFoundException>(async () => await _sut.ChangeStatusAsync(Guid.NewGuid(), ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncReturnsIfStatusIsEqualToNewStatus()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, null))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Cancelled
            });

        await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId);

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Event>()), Times.Never);
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncChangesStatusOfEvent()
    {
        _mockedEventDao.Setup(ed => ed.GetEventAsync(ValidEventId, ValidOrganizationId, null))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Event
            {
                Status = EventStatus.Active
            });

        await _sut.ChangeStatusAsync(ValidEventId, ValidOrganizationId);

        _mockedEventDao.Verify(ed => ed.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Event>(e => e.Status == EventStatus.Cancelled)), Times.Once);
    }
}