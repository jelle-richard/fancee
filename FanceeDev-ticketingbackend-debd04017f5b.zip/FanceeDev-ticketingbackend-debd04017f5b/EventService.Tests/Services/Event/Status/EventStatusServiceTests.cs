﻿using System;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Event;
using EventService.Services.Event.Status;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;

namespace EventService.Tests.Services.Event.Status;

public class EventStatusServiceTests
{
    private readonly EventStatusService _sut;
    private readonly Mock<IStatusService> _mockedStatusService = new();
    private readonly Mock<ILogger<EventStatusService>> _mockedLogger = new();

    public EventStatusServiceTests()
    {
        _mockedStatusService.Setup(ss => ss.GetStatus()).Returns(ChangeableEventStatus.Active);

        _sut = new(new[] { _mockedStatusService.Object }, _mockedLogger.Object);
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncLogsIfThereIsNoValidServiceForStatus()
    {
        var eventId = Guid.NewGuid();

        await _sut.ChangeStatusAsync(eventId, Guid.NewGuid(), ChangeableEventStatus.Cancelled);

        _mockedStatusService.Verify(ss => ss.GetStatus(), Times.Once);
        _mockedStatusService.VerifyNoOtherCalls();
        _mockedLogger.VerifyCalled(LogLevel.Warning, $"Tried to change event status for event '{eventId}' to '{ChangeableEventStatus.Cancelled}' but no valid StatusService could be found");
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncCallsCorrespondingStatusService()
    {
        var eventId = Guid.NewGuid();
        var organizationId = Guid.NewGuid();

        await _sut.ChangeStatusAsync(eventId, organizationId, ChangeableEventStatus.Active);

        _mockedStatusService.Verify(ss => ss.GetStatus(), Times.Once);
        _mockedStatusService.Verify(ss => ss.ChangeStatusAsync(eventId, organizationId), Times.Once);
        _mockedStatusService.VerifyNoOtherCalls();
        _mockedLogger.VerifyNoOtherCalls();
    }
}