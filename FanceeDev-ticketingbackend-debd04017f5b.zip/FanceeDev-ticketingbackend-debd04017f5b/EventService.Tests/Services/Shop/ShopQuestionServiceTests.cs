using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Shop;
using EventService.Persistence.Shop;
using EventService.Services.Shop;
using EventService.Services.Shop.Exceptions;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Services.Shop;

public class ShopQuestionServiceTests
{
    private readonly ShopQuestionService _sut;
    private readonly Mock<IShopQuestionDao> _mockedShopQuestionDao = new();

    public ShopQuestionServiceTests()
    {
        _sut = new(_mockedShopQuestionDao.Object);
    }

    [Fact]
    public async Task TestThatAddAsyncCallsShopQuestionDaoCreateAsync()
    {
        var questions = new List<ShopQuestionRequest>
        {
            new()
            {
                Required = true,
                Question = "What's the answer to life, the universe and everything?",
                Type = ShopQuestionType.Choice,
                Choices = new List<ShopQuestionChoiceDto>
                {
                    new()
                    {
                        Value = "42"
                    },
                    new()
                    {
                        Value = "That's not a question"
                    },
                    new()
                    {
                        Value = "A towel, it says, is about the most massively useful thing an interstellar hitchhiker can have"
                    }
                }
            }
        };

        await _sut.AddAsync("ShopCode", questions);

        _mockedShopQuestionDao.Verify(sqd => sqd.NextPositionAsync("ShopCode"), Times.Once);
        _mockedShopQuestionDao.Verify(sqd => sqd.CreateAsync(It.IsAny<IEnumerable<ShopQuestion>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsShopDaoGetAsync()
    {
        _mockedShopQuestionDao.Setup(sqd => sqd.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new ShopQuestion());

        await _sut.DeleteAsync(It.IsAny<Guid>());

        _mockedShopQuestionDao.Verify(sqd => sqd.GetAsync(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsShopQuestionNotFoundExceptionIfShopQuestionDoesNotExist()
    {
        _mockedShopQuestionDao.Setup(sqd => sqd.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync((ShopQuestion?)null);

        await Assert.ThrowsAsync<ShopQuestionNotFoundException>(async () => await _sut.DeleteAsync(It.IsAny<Guid>()));

        _mockedShopQuestionDao.Verify(sqd => sqd.GetAsync(It.IsAny<Guid>()), Times.Once);
        _mockedShopQuestionDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsShopQuestionInUseExceptionIfShopQuestionHasAnswers()
    {
        var questionId = Guid.NewGuid();

        _mockedShopQuestionDao.Setup(sqd => sqd.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new ShopQuestion
            {
                Id = questionId,
                Position = 1,
                Required = false,
                Question = "Of je worst lust!",
                Type = ShopQuestionType.Open,
                ShopQuestionChoices = new List<ShopQuestionChoice>(),
                ShopQuestionAnswers = new List<ShopQuestionAnswer>
                {
                    new()
                    {
                        Answer = "Jazeker de hypotheker!"
                    },
                    new()
                    {
                        Answer = "Wil je me vergiftigen of zo?"
                    },
                    new()
                    {
                        Answer = "Ik ben bij uitstek veganist en vind dat deze vraag afbreuk doet aan de morele verantwoording die iedereen draagt om zich te bekommeren over dierenleed. Maar kipnuggets zijn wel lekker"
                    }
                }
            });
        _mockedShopQuestionDao.Setup(sqd => sqd.HasAnswersAsync(questionId)).ReturnsAsync(true);

        await Assert.ThrowsAsync<ShopQuestionInUseException>(async () => await _sut.DeleteAsync(questionId));

        _mockedShopQuestionDao.Verify(sqd => sqd.GetAsync(questionId), Times.Once);
        _mockedShopQuestionDao.Verify(sqd => sqd.HasAnswersAsync(questionId), Times.Once);
        _mockedShopQuestionDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsShopQuestionDaoDeleteAsync()
    {
        var questionId = Guid.NewGuid();

        _mockedShopQuestionDao.Setup(sqd => sqd.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new ShopQuestion
            {
                Id = questionId,
                Position = 1,
                Required = false,
                Question = "Moet deze vraag verwijderd worden?",
                Type = ShopQuestionType.Choice,
                ShopQuestionChoices = new List<ShopQuestionChoice>
                {
                    new() { Value = "Yes" },
                    new() { Value = "Ja" }
                },
                ShopQuestionAnswers = new List<ShopQuestionAnswer>()
            });

        await _sut.DeleteAsync(questionId);

        _mockedShopQuestionDao.Verify(sqd => sqd.GetAsync(questionId), Times.Once);
        _mockedShopQuestionDao.Verify(sqd => sqd.HasAnswersAsync(questionId), Times.Once);
        _mockedShopQuestionDao.Verify(sqd => sqd.DeleteAsync(It.IsAny<ShopQuestion>()), Times.Once);
        _mockedShopQuestionDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateAsyncThrowsShopQuestionNotFoundExceptionIfShopQuestionDoesNotExist()
    {
        _mockedShopQuestionDao.Setup(sqd => sqd.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync((ShopQuestion?)null);

        await Assert.ThrowsAsync<ShopQuestionNotFoundException>(async () => await _sut.UpdateAsync("shop", It.IsAny<Guid>(), It.IsAny<ShopQuestionRequest>()));

        _mockedShopQuestionDao.Verify(sqd => sqd.GetAsync(It.IsAny<Guid>()), Times.Once);
        _mockedShopQuestionDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatUpdateAsyncCallsShopQuestionDaoUpdateAsync()
    {
        _mockedShopQuestionDao.Setup(sqd => sqd.GetAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new ShopQuestion());

        await _sut.UpdateAsync("shop", Guid.NewGuid(), new());

        _mockedShopQuestionDao.Verify(sqd => sqd.GetAsync(It.IsAny<Guid>()), Times.Once);
        _mockedShopQuestionDao.Verify(sqd => sqd.UpdateAsync(It.IsAny<ShopQuestion>()), Times.Once);
        _mockedShopQuestionDao.VerifyNoOtherCalls();
    }
}