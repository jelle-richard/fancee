using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Shop;
using EventService.Dtos.Responses.Shops;
using EventService.Persistence.Shop;
using EventService.Persistence.ShopDesignHeaderMedia;
using EventService.Services.Exceptions;
using EventService.Services.Product;
using EventService.Services.Product.Exceptions;
using EventService.Services.Shop;
using EventService.Services.Shop.Exceptions;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using WebApiCore.Dtos.Environment;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;
using WebApiCore.Dtos.Shared.ShopElement;
using WebApiCore.Exceptions;
using WebApiCore.Exceptions.Shop;
using WebApiCore.Services.Cache;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;

namespace EventService.Tests.Services.Shop;

public class ShopServiceTests
{
    private static readonly Guid ValidOrganizationId = Guid.NewGuid();

    private readonly ShopService _sut;
    private readonly Mock<IShopDao> _mockedShopDao = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<IShopDesignHeaderMediaDao> _mockedShopDesignHeaderMediaDao = new();
    private readonly Mock<IProductService> _mockedProductService = new();
    private readonly Mock<ICacheService> _mockedCacheService = new();
    private readonly Mock<IShopCacheService> _mockedShopCacheService = new();

    private readonly FanceeData.Models.Ticketing.Shop _validShop = new()
    {
        Name = "UnitShop",
        Active = true,
        Code = "laskdjflaskdfj",
        StartDate = DateTime.UtcNow,
        EndDate = DateTime.UtcNow.AddDays(1),
        FacebookAccessCode = "fb-access",
        FacebookPixelId = "fb-pixel",
        ShopFieldRequirements = new List<ShopFieldRequirement>
        {
            new()
            {
                Field = ShopField.Email,
                Enabled = true,
                Required = false
            }
        }
    };

    private readonly HostedDeploymentEnvironment _deploymentEnvironment = new()
    {
        Id = Guid.NewGuid(),
        Name = "UnitTestEnv",
        ContentDeliveryNetworkBaseUrl = "localhost",
        IsHttps = false
    };

    public ShopServiceTests()
    {
        var mockedConfig = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string> { { "RedisCache:LifeTimeDays", "5" } }!).Build();

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(_deploymentEnvironment);

        _sut = new(_mockedShopDao.Object, _mockedDeploymentEnvironmentService.Object,
            _mockedUploadService.Object, _mockedStorageService.Object, _mockedShopDesignHeaderMediaDao.Object,
            _mockedProductService.Object, _mockedCacheService.Object, mockedConfig, _mockedShopCacheService.Object);
    }

    [Fact]
    public async Task TestThatCreateAsyncCallsShopDao()
    {
        _mockedShopDao.Setup(sd => sd.IsUniqueAsync(It.IsAny<string>())).ReturnsAsync(true);

        var request = new ConfigureShopRequest
        {
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1),
            Layout = ShopLayout.List,
            Name = "Unit Shop",
            ShopFields = new List<ShopFieldRequirementRequest>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                },
                new()
                {
                    Field = ShopField.Gender,
                    Enabled = true,
                    Required = false
                }
            },
            Active = true,
            Design = new()
            {
                PrimaryColor = "#FFFFFF",
                BackdropColor = "#FFFFFF",
                BackgroundColor = "#FFFFFF",
                TextColor = "#FFFFFF"
            },
            Analytics = new()
            {
                TiktokPixelId = null,
                GoogleAnalyticsId = "G-AnalyticsUnitId"
            }
        };

        var actual = await _sut.CreateAsync(request, Guid.NewGuid());

        Assert.NotNull(actual);
        Assert.Equal(25, actual.Length);
        _mockedShopDao.Verify(sd => sd.IsUniqueAsync(It.IsAny<string>()), Times.AtLeastOnce);
        _mockedShopDao.Verify(sd => sd.CreateAsync(It.Is<FanceeData.Models.Ticketing.Shop>(s => s.Name == "Unit Shop")),
            Times.Once);
    }

    [Fact]
    public async Task TestThatListAsyncCallsShopDao()
    {
        var organizationId = Guid.NewGuid();
        var eventId = Guid.NewGuid();

        _mockedShopDao.Setup(sd => sd.ListAsync(organizationId, eventId, _deploymentEnvironment))
            .ReturnsAsync(new List<ShopListItemResponse>
            {
                new()
                {
                    Code = "shopCode1",
                    Name = "Test1",
                    NumberOfViews = 100
                },
                new()
                {
                    Code = "shopCode2",
                    Name = "Test2",
                    NumberOfViews = 200
                }
            });
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<int>(It.IsAny<string>())).ReturnsAsync(100);

        var actual = await _sut.ListAsync(organizationId, eventId);

        Assert.NotEmpty(actual);
        _mockedShopDao.Verify(sd => sd.ListAsync(organizationId, eventId, _deploymentEnvironment), Times.Once);
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<int>(It.IsAny<string>()), Times.AtLeast(1));
    }

    [Fact]
    public async Task TestThatUniqueNameForEventAsyncCallsShopDao()
    {
        var eventId = Guid.NewGuid();

        await _sut.UniqueNameForEventAsync("unique", eventId);

        _mockedShopDao.Verify(sd => sd.UniqueNameForEventAsync("unique", eventId), Times.Once);
    }

    [Fact]
    public async Task TestThatByCodeAsyncThrowsShopNotFoundExceptionOnInvalidShopCode()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("invalid", null)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.ByCodeAsync("invalid"));
    }

    [Fact]
    public async Task TestThatByCodeAsyncGetsShop()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment
        {
            ContentDeliveryNetworkBaseUrl = "localhost",
            Name = "UnitTest",
            RemoteIpAddress = IPAddress.Parse("127.0.0.1")
        });

        var shopQuestionId = Guid.NewGuid();

        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitCode", q => q.Include(s => s.Tags)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop
            {
                Name = "UnitShop",
                Active = true,
                Layout = ShopLayout.List,
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                NumberOfViews = 500,
                ShopDesign = new()
                {
                    PrimaryColor = "FFFFFF",
                    TextColor = "000FFF",
                    BackdropColor = "FFF000",
                    BackgroundColor = "F0F0F0",
                    BackgroundMediaFile = new()
                    {
                        Id = Guid.NewGuid(),
                        Name = "shopbackground.jpg",
                        Path = "shop/background.jpg"
                    }
                },
                Tags = new[] { new ShopTag { Name = "TestTag1", ShopCode = "UnitCode" } },
                ItemsInShop = new List<ItemInShop>(),
                ShopQuestions = new List<ShopQuestion>
                {
                    new()
                    {
                        Id = shopQuestionId,
                        Question = "Test question?",
                        Type = ShopQuestionType.Choice,
                        ShopQuestionChoices = new List<ShopQuestionChoice>
                        {
                            new() { Value = "Yes" },
                            new() { Value = "No" },
                            new() { Value = "Maybe" },
                            new() { Value = "Can you repeat the question?" }
                        }
                    }
                }
            });
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<int>("UnitCode_views")).ReturnsAsync(200);

        var actual = await _sut.ByCodeAsync("UnitCode");

        Assert.NotNull(actual);
        Assert.Equal("UnitShop", actual.Name);
        Assert.Equal("F0F0F0", actual.Design.BackgroundColor);
        Assert.Equal("http://localhost/shop/background.jpg", actual.Design.BackgroundMedia?.Url);
        Assert.Equal(700, actual.NumberOfViews);

        var questions = actual.Questions.ToList();
        Assert.NotEmpty(questions);
        Assert.Single(questions);
        Assert.Equal(shopQuestionId, questions.First().Id);
        Assert.Equal(4, questions.First().Choices.Count());

        _mockedShopDao.Verify(sd => sd.ByCodeAsync("UnitCode", q => q.Include(s => s.Tags)), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<int>("UnitCode_views"), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncThrowsShopNotFoundExceptionIfInvalidShopIsGiven()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("invalid", q => q.Include(s => s.ShopDesign))).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.UpdateAsync(new(), "invalid", Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatUpdateAsyncThrowsShopNameInUseExceptionIfShopNameIsInUse()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("valid", q => q.Include(s => s.ShopDesign).Include(s => s.Tags))).ReturnsAsync(value: new()
        {
            Name = "Change Me"
        });

        await Assert.ThrowsAsync<ShopNameInUseException>(async () =>
            await _sut.UpdateAsync(new() { Name = "Changed" }, "valid", Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesShop()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("ShopCode", q => q.Include(s => s.ShopDesign).Include(s => s.Tags)))
            .ReturnsAsync(_validShop);

        await _sut.UpdateAsync(new()
        {
            Name = "UnitShop",
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1),
            Active = true,
            Layout = ShopLayout.Webshop,
            Design = new(),
            ShopFields = new List<ShopFieldRequirementRequest>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                }
            },
            Analytics = new()
            {
                TiktokPixelId = null,
                GoogleAnalyticsId = null,
                FacebookAccessCode = "fb-new-access",
                FacebookPixelId = "fb-new-pixel"
            }
        }, "ShopCode", Guid.NewGuid());

        _mockedShopDao.Verify(
            sd => sd.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Shop>(
                s => s.Name == "UnitShop" &&
                     s.FacebookAccessCode == "fb-new-access" &&
                     s.FacebookPixelId == "fb-new-pixel")
            ), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesChangedShopFieldRequirementsAsync()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("ShopCode", q => q.Include(s => s.ShopDesign).Include(s => s.Tags)))
            .ReturnsAsync(_validShop);

        await _sut.UpdateAsync(new()
        {
            Name = "UnitShop",
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1),
            Active = true,
            Layout = ShopLayout.Webshop,
            Design = new(),
            ShopFields = new List<ShopFieldRequirementRequest>
            {
                new()
                {
                    Field = ShopField.Email,
                    Enabled = true,
                    Required = true
                }
            },
            Analytics = new()
            {
                TiktokPixelId = null,
                GoogleAnalyticsId = null,
                FacebookAccessCode = "fb-new-access",
                FacebookPixelId = "fb-new-pixel"
            }
        }, "ShopCode", Guid.NewGuid());

        _mockedShopDao.Verify(
            sd => sd.UpdateAsync(It.Is<FanceeData.Models.Ticketing.Shop>(
                s => s.ShopFieldRequirements.First().Field == ShopField.Email &&
                     s.ShopFieldRequirements.First().Required == true)
            ), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncCallsShopDao()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("ShopCode", q => q.Include(s => s.ShopsInCombinedShop)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop { Code = "ShopCode" });

        await _sut.DeleteAsync("ShopCode");

        _mockedShopDao.Verify(sd => sd.ByCodeAsync("ShopCode", q => q.Include(s => s.ShopsInCombinedShop)), Times.Once);
        _mockedShopDao.Verify(sd => sd.DeleteAsync(It.Is<FanceeData.Models.Ticketing.Shop>(s => s.Code == "ShopCode")),
            Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsShopInUseExceptionOnException()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("ShopCode", q => q.Include(s => s.ShopsInCombinedShop)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop { Code = "ShopCode" });
        _mockedShopDao.Setup(sd => sd.InUseAsync("ShopCode")).ReturnsAsync(false);
        _mockedShopDao.Setup(sd => sd.DeleteAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()))
            .ThrowsAsync(new("Error occurred."));

        await Assert.ThrowsAsync<ShopInUseException>(async () => await _sut.DeleteAsync("ShopCode"));
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsShopNotFoundExceptionOnInvalidShop()
    {
        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.DeleteAsync("Invalid"));
    }

    [Fact]
    public async Task TestThatDeleteAsyncThrowsShopInUseExceptionIfItHasSalesOrPendingSales()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("InUse", q => q.Include(s => s.ShopsInCombinedShop)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop { Code = "InUse" });
        _mockedShopDao.Setup(sd => sd.InUseAsync("InUse")).ReturnsAsync(true);

        await Assert.ThrowsAsync<ShopInUseException>(async () => await _sut.DeleteAsync("InUse"));
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaAsyncThrowsShopNotFoundExceptionOnInvalidShopCode()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("invalid", q => q.Include(s => s.ShopDesign).Include(s => s.ShopDesign.BackgroundMediaFile)))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.DeleteBackgroundMediaAsync("invalid"));
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaAsyncCallsStorageServiceAndShopDao()
    {
        var shop = new FanceeData.Models.Ticketing.Shop
        {
            ShopDesign = new()
            {
                BackgroundMediaFile = new()
                {
                    Path = "uploads/shops/headers/unittest.png"
                }
            }
        };

        await _sut.DeleteBackgroundMediaAsync(shop);

        _mockedStorageService.Verify(ss => ss.DeleteFileAsync("shops", "headers/unittest.png"), Times.Once);
        _mockedShopDao.Verify(sd => sd.DeleteBackgroundMediaAsync(shop.ShopDesign), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaAsyncReturnsWhenNoBackgroundMediaFileIsPresent()
    {
        var shop = new FanceeData.Models.Ticketing.Shop
        {
            ShopDesign = new()
        };

        await _sut.DeleteBackgroundMediaAsync(shop);

        _mockedStorageService.Verify(ss => ss.DeleteFileAsync("shops", "headers/unittest.png"), Times.Never);
        _mockedShopDao.Verify(sd => sd.DeleteBackgroundMediaAsync(shop.ShopDesign), Times.Once);
    }

    [Fact]
    public async void TestThatUploadBackgroundMediaAsyncThrowsShopNotFoundExceptionOnInvalidShopCode()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("invalid", null)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.UploadBackgroundMediaAsync("invalid", new()));
    }

    [Fact]
    public async Task TestThatUploadBackgroundMediaAsyncOverwritesFile()
    {
        var request = new UploadBackgroundMediaRequest();

        _mockedUploadService.Setup(us => us.UploadAsync(request, "shops", "backgrounds", It.IsAny<Func<File, Task>>()))
            .Callback((UploadMediaRequest _, string _, string _, Func<File, Task> callback) => callback.Invoke(new()))
            .ReturnsAsync(new UploadedFile
                { Id = It.IsAny<Guid>(), Url = "http://localhost/uploads/shops/backgrounds/test.png" });
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitShop", q => q.Include(s => s.ShopDesign.BackgroundMediaFile))).ReturnsAsync(
            new FanceeData.Models.Ticketing.Shop
            {
                ShopDesign = new() { BackgroundMediaFile = new() { Path = "uploads/shops/backgrounds/unittest.png" } }
            });

        var actual = await _sut.UploadBackgroundMediaAsync("UnitShop", request);

        Assert.NotNull(actual);
        Assert.Equal("http://localhost/uploads/shops/backgrounds/test.png", actual.Url);

        _mockedShopDao.Verify(sd => sd.ByCodeAsync("UnitShop", q => q.Include(s => s.ShopDesign.BackgroundMediaFile)), Times.Once);
        _mockedStorageService.Verify(ss => ss.DeleteFileAsync("shops", "backgrounds/unittest.png"), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(request, "shops", "backgrounds", It.IsAny<Func<File, Task>>()),
            Times.Once);
        _mockedShopDao.Verify(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteBackgroundMediaWithShopCodeAsyncCallsStorageServiceAndShopDao()
    {
        var shop = new FanceeData.Models.Ticketing.Shop
        {
            ShopDesign = new()
            {
                BackgroundMediaFile = new()
                {
                    Path = "uploads/shops/headers/unittest.png"
                }
            }
        };

        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitShop", q => q.Include(s => s.ShopDesign.BackgroundMediaFile)))
            .ReturnsAsync(shop);

        await _sut.DeleteBackgroundMediaAsync("UnitShop");

        _mockedStorageService.Verify(ss => ss.DeleteFileAsync("shops", "headers/unittest.png"), Times.Once);
        _mockedShopDao.Verify(sd => sd.DeleteBackgroundMediaAsync(shop.ShopDesign), Times.Once);
    }

    [Fact]
    public async Task TestThatUploadHeaderMediaAsyncThrowsShopNotFoundExceptionOnInvalidShopCode()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("invalid", q => q.Include(s => s.ShopDesign).Include(s => s.ShopDesign.HeaderMedia)))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.UploadHeaderMediaAsync("invalid", new()));
    }

    [Fact]
    public async Task TestThatUploadHeaderMediaAsyncAddsNewHeaderMedia()
    {
        var request = new UploadHeaderMediaRequest();

        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitShop", q => q.Include(s => s.ShopDesign.HeaderMedia))).ReturnsAsync(
            new FanceeData.Models.Ticketing.Shop
                { ShopDesign = new() { HeaderMedia = new List<ShopDesignHeaderMedia>() } });
        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.NextPositionAsync("UnitShop")).ReturnsAsync(3);
        _mockedUploadService.Setup(us => us.UploadAsync(request, "shops", "headers", It.IsAny<Func<File, Task>>()))
            .Callback((UploadMediaRequest _, string _, string _, Func<File, Task> callback) => callback.Invoke(new()))
            .ReturnsAsync(new UploadedFile
                { Id = It.IsAny<Guid>(), Url = "http://localhost/uploads/shops/headers/test.png" });

        var actual = await _sut.UploadHeaderMediaAsync("UnitShop", request);

        Assert.NotNull(actual);
        Assert.Equal("http://localhost/uploads/shops/headers/test.png", actual.Url);

        _mockedUploadService.Verify(us => us.UploadAsync(request, "shops", "headers", It.IsAny<Func<File, Task>>()),
            Times.Once);
        _mockedShopDao.Verify(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Once);
        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.NextPositionAsync("UnitShop"));
    }

    [Fact]
    public async Task TestThatInheritHeaderMediaAsyncCallsShopDesignHeaderMediaDaoInheritMediaAsync()
    {
        await _sut.InheritHeaderMediaAsync("ShopCode");

        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.InheritMediaAsync("ShopCode"), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteHeaderMediaAsyncThrowsMediaNotFoundExceptionIfInvalidFileIsGiven()
    {
        var fileId = Guid.NewGuid();

        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.FindAsync("UnitShop", fileId)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.DeleteHeaderMediaAsync("UnitShop", fileId));
    }

    [Fact]
    public async Task TestThatDeleteHeaderMediaAsyncRemovesHeaderMedia()
    {
        var fileId = Guid.NewGuid();

        var headerMedia = new ShopDesignHeaderMedia
            { Position = 1, File = new() { Path = "uploads/shops/headers/test.png" } };

        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.FindAsync("UnitShop", fileId)).ReturnsAsync(headerMedia);

        await _sut.DeleteHeaderMediaAsync("UnitShop", fileId);

        _mockedStorageService.Verify(ss => ss.DeleteFileAsync("shops", "headers/test.png"), Times.Once);
        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.DeleteAsync(headerMedia), Times.Once);
        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.RepositionMediaAsync("UnitShop", 1), Times.Once);
    }

    [Fact]
    public async Task TestThatOwnerOfHeaderMediaAsyncCallsShopDesignHeaderMediaDao()
    {
        var fileId = Guid.NewGuid();

        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.OwnerOfMediaAsync(fileId, "UnitShop", ValidOrganizationId))
            .ReturnsAsync(true);

        var actual = await _sut.OwnerOfHeaderMediaAsync(fileId, "UnitShop", ValidOrganizationId);

        Assert.True(actual);

        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.OwnerOfMediaAsync(fileId, "UnitShop", ValidOrganizationId),
            Times.Once);
    }

    [Fact]
    public async Task TestThatCreateElementAsyncThrowsProductNotFoundExceptionIfUserDoesNotOwnAllProducts()
    {
        var productIds = new[] { Guid.NewGuid(), Guid.NewGuid() };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, productIds)).ReturnsAsync(false);

        var elements = new List<ShopElementDto>
        {
            new ProductElementDto { Id = productIds[0], Kind = ElementKind.Product },
            new ProductElementDto { Id = productIds[1], Kind = ElementKind.Product }
        };

        await Assert.ThrowsAsync<ProductNotFoundException>(async () =>
            await _sut.CreateElementAsync(elements, "UnitShop", ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatCreateElementAsyncThrowsProductNotFoundExceptionIfUserDoesNotOwnAllNestedProducts()
    {
        var productIds = new[] { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, productIds)).ReturnsAsync(false);

        // note: even though we don't support nested accordions,
        // we still test if they are handled correctly in the case that we
        // need to support this in the future.
        var elements = new List<ShopElementDto>
        {
            new ProductElementDto { Id = productIds[0], Kind = ElementKind.Product },
            new AccordionElementDto
            {
                Kind = ElementKind.Accordion,
                Elements = new()
                {
                    new ProductElementDto { Id = productIds[1], Kind = ElementKind.Product },
                    new AccordionElementDto
                    {
                        Kind = ElementKind.Accordion,
                        Elements = new() { new ProductElementDto { Id = productIds[2], Kind = ElementKind.Product } }
                    }
                }
            }
        };

        await Assert.ThrowsAsync<ProductNotFoundException>(async () => await _sut.CreateElementAsync(elements, "UnitShop", ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatCreateElementAsyncThrowsShopNotFoundExceptionOnInvalidShopCode()
    {
        var productIds = new[] { Guid.NewGuid(), Guid.NewGuid() };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, productIds)).ReturnsAsync(true);

        _mockedShopDao.Setup(sd => sd.ByCodeAsync("invalid", null)).ReturnsAsync(value: null);

        var elements = new List<ShopElementDto>
        {
            new ProductElementDto { Id = productIds[0], Kind = ElementKind.Product },
            new ProductElementDto { Id = productIds[1], Kind = ElementKind.Product }
        };

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.CreateElementAsync(elements, "invalid", ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatCreateElementAsyncOverwritesItemsInShop()
    {
        var productIds = new[] { Guid.NewGuid(), Guid.NewGuid() };
        var mockedList = new Mock<IList<ItemInShop>>();
        var mockedShop = new Mock<FanceeData.Models.Ticketing.Shop>
        {
            Object = { ItemsInShop = mockedList.Object }
        };
        var elements = new List<ShopElementDto>
        {
            new DividerElementDto { Kind = ElementKind.Divider, Name = "Name of divider" },
            new ExternalLinkElementDto { Kind = ElementKind.ExternalLink, Link = "https://tweakers.net" },
            new NoticeElementDto { Kind = ElementKind.Notice, Content = "test", Variant = NoticeVariant.Info },
            new TextBlockElementDto { Kind = ElementKind.TextBlock, Title = "Hello, ", Text = "UnitTest!" },
            new SeatingMapElementDto { Kind = ElementKind.SeatingMap },
            new ProductElementDto { Id = productIds[0], Kind = ElementKind.Product },
            new AccordionElementDto
            {
                Kind = ElementKind.Accordion, Icon = "user-add", Opened = true, Title = "Open me",
                Elements = new()
                {
                    new NoticeElementDto { Kind = ElementKind.Notice, Content = "test2", Variant = NoticeVariant.Danger },
                    new ProductElementDto { Id = productIds[1], Kind = ElementKind.Product }
                }
            }
        };

        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, new[] { productIds[0], productIds[1] }))
            .ReturnsAsync(true);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitShop", null)).ReturnsAsync(mockedShop.Object);

        await _sut.CreateElementAsync(elements, "UnitShop", ValidOrganizationId);

        _mockedShopDao.Verify(sd => sd.ByCodeAsync("UnitShop", null), Times.Once);
        _mockedShopDao.Verify(sd => sd.DeleteItemsInShopAsync(mockedShop.Object), Times.Once);
        mockedList.Verify(l => l.Add(It.IsAny<ItemInShop>()), Times.Exactly(7));
        _mockedShopDao.Verify(sd => sd.UpdateAsync(mockedShop.Object), Times.Once);
        _mockedShopDao.Verify(sd => sd.InsertShopElement(It.IsAny<ShopElement>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateElementAsyncThrowsInvalidShopElementExceptionOnInvalidElementAndProductId()
    {
        _mockedProductService.Setup(ps => ps.OwnerOfProductsAsync(ValidOrganizationId, It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync(true);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitShop", null)).ReturnsAsync(new FanceeData.Models.Ticketing.Shop
            { ItemsInShop = new List<ItemInShop>() });

        var elements = new List<ShopElementDto> { new ProductElementDto() };

        await Assert.ThrowsAsync<InvalidShopElementException>(async () =>
            await _sut.CreateElementAsync(elements, "UnitShop", ValidOrganizationId));
    }

    [Fact]
    public async Task TestThatInvalidateShopCacheByEventIdAsyncInvalidatesAllShopCaches()
    {
        var shopCodes = new[] { "Code1", "Code2", "Code3" };
        var eventId = Guid.NewGuid();

        _mockedShopDao.Setup(sd => sd.ShopCodesAsync(eventId)).ReturnsAsync(shopCodes);
        _mockedShopCacheService.Setup(css => css.RemoveShopCacheAsync(It.IsAny<string>()));

        await _sut.InvalidateShopCacheByEventIdAsync(eventId);

        _mockedShopDao.Verify(sd => sd.ShopCodesAsync(eventId), Times.Once);
        _mockedShopCacheService.Verify(css => css.RemoveShopCacheAsync(It.IsIn(shopCodes)), Times.Exactly(3));
    }

    [Fact]
    public async Task TestThatUpdateBackgroundMediaFocalPointAsyncThrowsShopNotFoundExceptionForUnknownShopCode()
    {
        _mockedShopDao.Setup(sd =>
                sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.ShopDesign).Include(s => s.ShopDesign.BackgroundMediaFile)))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () =>
            await _sut.UpdateBackgroundMediaFocalPointAsync("abc", new()));
    }

    [Fact]
    public async Task TestThatUpdateBackgroundMediaFocalPointAsyncRetrievesShopAndUpdatesFocalPoint()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("UnitShop", q => q.Include(s => s.ShopDesign.BackgroundMediaFile)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop
            {
                ShopDesign = new()
                {
                    BackgroundImageFocalPointHeightPercentage = null,
                    BackgroundImageFocalPointWidthPercentage = null,
                    BackgroundMediaFile = new()
                    {
                        Path = "uploads/shops/backgrounds/unittest.png"
                    }
                }
            });

        _mockedShopDao.Setup(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()));

        await _sut.UpdateBackgroundMediaFocalPointAsync("UnitShop", new()
        {
            FocalPointHeightPercentage = 55,
            FocalPointWidthPercentage = 40
        });

        _mockedShopDao.Verify(sd => sd.ByCodeAsync("UnitShop", q => q.Include(s => s.ShopDesign.BackgroundMediaFile)), Times.Once);
        _mockedShopDao.Verify(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Once);
    }

    [Fact]
    public async Task
        TestThatUpdateHeaderMediaFocalPointAsyncThrowsMediaNotFoundExceptionOnUnknownShopHeaderMediaFile()
    {
        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.FindAsync(It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<MediaNotFoundException>(async () =>
            await _sut.UpdateHeaderMediaFocalPointAsync("abc", Guid.NewGuid(), new()));

        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.FindAsync(It.IsAny<string>(), It.IsAny<Guid>()),
            Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateHeaderMediaFocalPointAsyncCallsShopDesignHeaderMediaDaoUpdateAsync()
    {
        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.FindAsync(It.IsAny<string>(), It.IsAny<Guid>()))
            .ReturnsAsync(new ShopDesignHeaderMedia
            {
                FocalPointHeightPercentage = null,
                FocalPointWidthPercentage = null
            });

        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.UpdateAsync(It.IsAny<ShopDesignHeaderMedia>()));

        await _sut.UpdateHeaderMediaFocalPointAsync("shop", Guid.NewGuid(), new()
        {
            FocalPointHeightPercentage = 55,
            FocalPointWidthPercentage = 40
        });

        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.FindAsync(It.IsAny<string>(), It.IsAny<Guid>()),
            Times.Once);
        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.UpdateAsync(It.IsAny<ShopDesignHeaderMedia>()),
            Times.Once);
    }

    [Fact]
    public async Task
        TestThatRepositionHeaderMediaAsyncThrowsShopHeaderMediaNotFoundExceptionIfFileIdsDoNotMatchHeaderMediaCount()
    {
        var fileIds = new[] { Guid.NewGuid(), Guid.NewGuid() };

        _mockedShopDesignHeaderMediaDao.Setup(sdhmd => sdhmd.ForShopAsync("shop"))
            .ReturnsAsync(Array.Empty<ShopDesignHeaderMedia>());

        await Assert.ThrowsAsync<ShopHeaderMediaNotFoundException>(async () =>
            await _sut.RepositionHeaderMediaAsync("shop", fileIds));

        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.ForShopAsync("shop"), Times.Once);
        _mockedShopDesignHeaderMediaDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task
        TestThatRepositionHeaderMediaAsyncThrowsShopHeaderMediaNotFoundExceptionIfFileIdsDoNotMatchHeaderMediaIds()
    {
        var fileIds = new[] { Guid.Empty, Guid.NewGuid() };

        _mockedShopDesignHeaderMediaDao.Setup(pmd => pmd.ForShopAsync("shop")).ReturnsAsync(new ShopDesignHeaderMedia[]
        {
            new() { FileId = Guid.NewGuid() },
            new() { FileId = Guid.NewGuid() }
        });

        await Assert.ThrowsAsync<ShopHeaderMediaNotFoundException>(async () =>
            await _sut.RepositionHeaderMediaAsync("shop", fileIds));

        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.ForShopAsync("shop"), Times.Once);
        _mockedShopDesignHeaderMediaDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRepositionHeaderMediaAsyncCallsShopDesignHeaderMediaDaoRepositionMediaAsync()
    {
        var fileIds = new[] { Guid.Empty, Guid.NewGuid() };

        _mockedShopDesignHeaderMediaDao.Setup(pmd => pmd.ForShopAsync("shop")).ReturnsAsync(new ShopDesignHeaderMedia[]
        {
            new() { FileId = fileIds[1] },
            new() { FileId = fileIds[0] }
        });

        await _sut.RepositionHeaderMediaAsync("shop", fileIds);

        _mockedShopDesignHeaderMediaDao.Verify(sdhmd => sdhmd.ForShopAsync("shop"), Times.Once);
        _mockedShopDesignHeaderMediaDao.Verify(
            sdhmd => sdhmd.RepositionMediaAsync(It.IsAny<IList<ShopDesignHeaderMedia>>(), fileIds.ToList()),
            Times.Once);
    }

    [Fact]
    public async Task TestThatElementsAsyncCallsShopDaoItemsInShopAsync()
    {
        _mockedShopDao.Setup(sd => sd.ItemsInShopAsync("shop")).ReturnsAsync(new ItemInShop[]
        {
            new()
            {
                Position = 1,
                ShopElement = new DividerElement()
            }
        });

        var actual = (await _sut.ElementsAsync("shop")).ToList();

        Assert.Single(actual);
        Assert.IsType<IdentifiedDividerElementDto>(actual[0]);
    }

    [Fact]
    public async Task TestThatElementsAsyncReturnsEmptyEnumerableIfNoElementsAreConfigured()
    {
        _mockedShopDao.Setup(sd => sd.ItemsInShopAsync("shop")).ReturnsAsync(Array.Empty<ItemInShop>());

        var actual = (await _sut.ElementsAsync("shop")).ToList();

        Assert.Empty(actual);
    }

    [Fact]
    public async Task TestThatUpdateViewsAsyncCachesShopViews()
    {
        const int currentViewsInCache = 10;
        const int newViews = 1;

        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<int>("ShopCode_views")).ReturnsAsync(currentViewsInCache);
        _mockedCacheService.Setup(cs => cs.CacheObjectAsync("ShopCode_views", currentViewsInCache + newViews, 5));

        await _sut.UpdateViewsAsync(newViews, "ShopCode");

        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<int>("ShopCode_views"), Times.Once);
        _mockedCacheService.Verify(cs => cs.CacheObjectAsync("ShopCode_views", currentViewsInCache + newViews, 5), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteViewsInCacheAsyncDeletesShopViewsInCacheAndWriteToDb()
    {
        _mockedShopDao.Setup(sd => sd.ShopCodesAsync(null))
            .ReturnsAsync(new List<string> { "shopCode1", "shopCode2" });
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("shopCode1", q => q.Include(s => s.ShopDesign).Include(s => s.Tags))).ReturnsAsync(value: new()
        {
            Name = "UnitShop1",
            Active = true,
            Code = "shopCode1",
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1)
        });
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("shopCode2", q => q.Include(s => s.ShopDesign).Include(s => s.Tags))).ReturnsAsync(value: new()
        {
            Name = "UnitShop2",
            Active = true,
            Code = "shopCode2",
            StartDate = DateTime.UtcNow,
            EndDate = DateTime.UtcNow.AddDays(1)
        });
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<int>("shopCode1_views")).ReturnsAsync(100);
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<int>("shopCode2_views")).ReturnsAsync(200);
        _mockedShopDao.Setup(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()));
        _mockedCacheService.Setup(cs => cs.RemoveCacheByKeyAsync("shopCode1_views"));
        _mockedCacheService.Setup(cs => cs.RemoveCacheByKeyAsync("shopCode2_views"));

        await _sut.DeleteViewsInCacheAsync();

        _mockedShopDao.Verify(sd => sd.ShopCodesAsync(null), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync("shopCode1", q => q.Include(s => s.ShopDesign).Include(s => s.Tags)), Times.Once);
        _mockedShopDao.Verify(sd => sd.ByCodeAsync("shopCode2", q => q.Include(s => s.ShopDesign).Include(s => s.Tags)), Times.Once);
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<int>("shopCode1_views"), Times.Once);
        _mockedCacheService.Verify(cs => cs.GetCachedObjectAsync<int>("shopCode2_views"), Times.Once);
        _mockedShopDao.Verify(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Exactly(2));
        _mockedCacheService.Verify(cs => cs.RemoveCacheByKeyAsync("shopCode1_views"), Times.Once);
        _mockedCacheService.Verify(cs => cs.RemoveCacheByKeyAsync("shopCode2_views"), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteViewsInCacheAsyncThrowsShopNotFoundExceptionWhenNotFound()
    {
        _mockedShopDao.Setup(sd => sd.ShopCodesAsync(null))
            .ReturnsAsync(new List<string> { "shopCode1", "shopCode2" });
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<int>("shopCode1_views")).ReturnsAsync(100);
        _mockedCacheService.Setup(cs => cs.GetCachedObjectAsync<int>("shopCode2_views")).ReturnsAsync(200);
        _mockedShopDao.Setup(sd => sd.ByCodeAsync("shopCode1", q => q.Include(s => s.ShopDesign).Include(s => s.Tags)))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(_sut.DeleteViewsInCacheAsync);
    }

    [Fact]
    public async Task TestThatSetShopSecureStateAsyncThrowsShopNotFoundExceptionIfShopDaoByCodeAsyncReturnsNull()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)))
            .ReturnsAsync(value: null);

        await Assert.ThrowsAsync<ShopNotFoundException>(async () => await _sut.SetShopSecureStateAsync("UnitShopCode", new()));

        _mockedShopDao.Verify(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)), Times.Once);
    }

    [Fact]
    public async Task TestThatSetShopSecureStateAsyncThrowsShopBeingSharedExceptionIfShopIsBeingShared()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop
            {
                Name = "UnitShop2",
                Active = true,
                Code = "shopCode2",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                IsSecuredUntil = null,
                SharedShops = [new()]
            });

        await Assert.ThrowsAsync<ShopBeingSharedException>(async () => await _sut.SetShopSecureStateAsync("UnitShopCode", new()));

        _mockedShopDao.Verify(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)), Times.Once);
        _mockedShopDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatSetShopSecureStateAsyncTrueForValidShopCallsShopDaoUpdateAsync()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop
            {
                Name = "UnitShop2",
                Active = true,
                Code = "shopCode2",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                IsSecuredUntil = null
            });

        _mockedShopDao.Setup(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()));

        await _sut.SetShopSecureStateAsync("UnitShopCode", new()
        {
            IsSecured = true,
            SecureStateExpiresOn = DateTime.UtcNow.AddDays(20)
        });

        _mockedShopDao.Verify(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)), Times.Once);
        _mockedShopDao.Verify(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Once);
    }

    [Fact]
    public async Task TestThatSetShopSecureStateAsyncFalseForValidShopCallsShopDaoUpdateAsync()
    {
        _mockedShopDao.Setup(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Shop
            {
                Name = "UnitShop2",
                Active = true,
                Code = "shopCode2",
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow.AddDays(1),
                IsSecuredUntil = null
            });

        _mockedShopDao.Setup(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()));

        await _sut.SetShopSecureStateAsync("UnitShopCode", new()
        {
            IsSecured = false
        });

        _mockedShopDao.Verify(sd => sd.ByCodeAsync(It.IsAny<string>(), q => q.Include(s => s.SharedShops.Take(1)!)), Times.Once);
        _mockedShopDao.Verify(sd => sd.UpdateAsync(It.IsAny<FanceeData.Models.Ticketing.Shop>()), Times.Once);
    }
}