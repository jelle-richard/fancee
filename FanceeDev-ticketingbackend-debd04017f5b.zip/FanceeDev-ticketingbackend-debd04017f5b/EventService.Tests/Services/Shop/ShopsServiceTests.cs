using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EventService.Dtos.Requests.Shop;
using EventService.Persistence.Shop;
using EventService.Services.Shop;
using JetBrains.Annotations;

namespace EventService.Tests.Services.Shop;

[TestSubject(typeof(ShopsService))]
public class ShopsServiceTests
{
    private static readonly Guid OrganizationId = Guid.NewGuid();

    private readonly ShopsService _sut;
    private readonly Mock<IShopsDao> _mockedShopsDao = new();

    public ShopsServiceTests()
    {
        _sut = new(_mockedShopsDao.Object);
    }

    [Fact]
    public async Task TestThatListSelectOptionsAsyncCallsShopsDaoListSelectOptionsAsync()
    {
        var request = new ShopSelectOptionsRequest();

        _mockedShopsDao.Setup(sd => sd.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<IList<string>>(), It.IsAny<string?>(), It.IsAny<IList<Guid>>()))
            .ReturnsAsync([new() { Id = "ShopCode", Label = "My Shop" }]);

        var actual = (await _sut.ListSelectOptionsAsync(OrganizationId, request)).ToList();

        Assert.Single(actual);
        Assert.Equal("ShopCode", actual[0].Id);

        _mockedShopsDao.Verify(sd => sd.ListSelectOptionsAsync(It.IsAny<Guid>(), It.IsAny<IList<string>>(), It.IsAny<string?>(), It.IsAny<IList<Guid>>()), Times.Once);
    }
}