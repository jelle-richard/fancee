using System.Threading.Tasks;
using EventService.Dtos.Requests.Shop;
using EventService.Persistence.Shop;
using EventService.Services.Shop;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Services.Shop;

public class ShopMailServiceTests
{
    private readonly ShopMailService _sut;
    private readonly Mock<IShopMailDao> _mockedShopMailDao = new();

    public ShopMailServiceTests()
    {
        _sut = new(_mockedShopMailDao.Object);
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncCallsShopMailDaoAddOrUpdateAsync()
    {
        var request = new UpdateShopMailRequest { Type = UpdateShopMailRequest.MailType.Purchase, SenderName = "Test", Content = "Content" };

        await _sut.AddOrUpdateAsync("Shop", request);

        _mockedShopMailDao.Verify(smd => smd.AddOrUpdateAsync(It.Is<ShopMail>(sm =>
            sm.Type == ShopMailType.Purchase &&
            sm.ShopCode == "Shop" &&
            sm.SenderName == "Test" &&
            sm.Content == "Content"
        )), Times.Once);
    }
}