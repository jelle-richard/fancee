﻿using System.Collections.Generic;
using System.Threading.Tasks;
using EventService.Persistence.Category;
using EventService.Services.Category;
using FanceeData.Models.Ticketing;

namespace EventService.Tests.Services.Category;

public class CategoryServiceTests
{
    private readonly CategoryService _sut;
    private readonly Mock<ICategoryDao> _mockedCategoryDao;

    public CategoryServiceTests()
    {
        _mockedCategoryDao = new();

        _sut = new(_mockedCategoryDao.Object);
    }

    [Fact]
    public async Task TestThatGetAllActiveSubCategoriesCallsMethodOnCategoryDao()
    {
        var categories = new List<EventCategory> { new() { Name = "TestCategory" } };

        _mockedCategoryDao.Setup(c => c.GetAllActiveSubCategoriesAsync()).ReturnsAsync(categories);

        var actual = await _sut.GetAllActiveSubCategories();

        Assert.Equal(categories, actual);
        _mockedCategoryDao.Verify(c => c.GetAllActiveSubCategoriesAsync(), Times.Once);
    }
}