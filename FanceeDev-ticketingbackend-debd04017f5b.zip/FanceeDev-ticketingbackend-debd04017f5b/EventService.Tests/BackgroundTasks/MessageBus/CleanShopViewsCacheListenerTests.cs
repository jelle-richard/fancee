using System;
using System.Threading.Tasks;
using EventService.BackgroundTasks.MessageBus;
using EventService.Services.Shop;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using WebApiCore.MessageBus.Messages.ShopViews;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace EventService.Tests.BackgroundTasks.MessageBus;

public class CleanShopViewsCacheListenerTests
{
    private readonly CleanShopViewsCacheListener _sut;
    private readonly Mock<IServiceProvider> _mockedServiceProvider = new();
    private readonly Mock<ILogger<CleanShopViewsCacheListener>> _mockedLogger = new();
    private readonly Mock<CleanShopViewsSubscriber> _mockedSubscriber = new();
    private readonly Mock<IShopService> _mockedShopService = new();

    public CleanShopViewsCacheListenerTests()
    {
        var mockedConnection = new Mock<IConnection>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);

        _mockedSubscriber = new(mockedConnection.Object);

        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<CleanShopViewsInCacheMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<CleanShopViewsCacheListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IShopService))).Returns(_mockedShopService.Object);
        _sut = new(_mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsToSubscriber()
    {
        await _sut.StartAsync(default);
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageCallsShopService()
    {
        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback?.Invoke(new());

        Assert.NotNull(actual);

        await actual!;

        _mockedShopService.Verify(ps => ps.DeleteViewsInCacheAsync(), Times.Once);
    }
}