using System;
using System.Threading.Tasks;
using EventService.BackgroundTasks.MessageBus;
using EventService.Services.Event;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Event;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace EventService.Tests.BackgroundTasks.MessageBus;

public class ConcludeEventsListenerTests
{
    private readonly ConcludeEventsListener _sut;
    private readonly Mock<ConcludeEventsSubscriber> _mockedSubscriber;
    private readonly Mock<ILogger<ConcludeEventsListener>> _mockedLogger = new();
    private readonly Mock<IEventsService> _mockedEventsService = new();

    public ConcludeEventsListenerTests()
    {
        var mockedServiceProvider = new Mock<IServiceProvider>();
        var mockedConnection = new Mock<IConnection>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);

        _mockedSubscriber = new(mockedConnection.Object);

        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<ConcludeEventsListener>))).Returns(_mockedLogger.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IEventsService))).Returns(_mockedEventsService.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<ConcludeEventsMessage>))).Returns(_mockedSubscriber.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.Callback);

        _mockedLogger.VerifyCalled(LogLevel.Information, "[ConcludeEventsListener] Started");
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsToSubscriber()
    {
        await _sut.StartAsync(default);
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.Callback);

        _mockedLogger.VerifyCalled(LogLevel.Information, "[ConcludeEventsListener] Stopped");
    }

    [Fact]
    public async Task TestThatProcessAsyncCallsEventsServiceConcludeAsync()
    {
        var message = new ConcludeEventsMessage();

        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback?.Invoke(message);

        Assert.NotNull(actual);

        await actual;

        _mockedEventsService.Verify(es => es.ConcludeAsync(), Times.Once);
        _mockedEventsService.VerifyNoOtherCalls();
    }
}