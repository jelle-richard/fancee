using DataSynchronisationService.Exceptions;
using DataSynchronisationService.Services.DataMessageStrategy;
using Fs.MessageBus.Publishers;
using WebApiCore.BackgroundTasks;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.BackgroundTasks.MessageBus;

public class RequestTicketingDataListener(IServiceProvider serviceProvider) : MessageBusHostedService<IRequestTicketingDataMessage, RequestTicketingDataListener>(serviceProvider), ISimpleMessageBus<IRequestTicketingDataMessage>
{
    protected override string LogPrefix => $"[{nameof(RequestTicketingDataListener)}]";
    private IEnumerable<IDataMessageStrategy>? _messageStrategies;
    private IMessagePublisher<IRequestTicketingDataReplyMessage>? _publisher;

    public async Task ProcessAsync(IRequestTicketingDataMessage? message)
    {
        if (message is null)
            throw new TicketingDataSynchronisationMessageNotAvailableException();

        if (_messageStrategies is null)
            throw new StrategiesNotLoadedException();

        if (_publisher is null)
            throw new PublisherNotLoadedException();

        Logger.LogInformation("[{DateTime}]: Received {Type}-{SyncType}-message. Starting and running correct strategy.", DateTime.UtcNow, message.Type, message.SyncType);

        var strategy = _messageStrategies.FirstOrDefault(s => s.Type == message.Type) ?? throw new UnknownStrategyRequiredForSynchronisationMessageException();
        var reply = await strategy.ExecuteAsync(message);

        Logger.LogInformation("[{DateTime}]: Finished {Type}-{SyncType}-message strategy. Returning data via publisher.", DateTime.UtcNow, message.Type, message.SyncType);
        _publisher.Publish(reply);
    }

    protected override void RegisterDependencies()
    {
        _messageStrategies = ServiceProvider.GetRequiredService<IEnumerable<IDataMessageStrategy>>();
        _publisher = ServiceProvider.GetRequiredService<IMessagePublisher<IRequestTicketingDataReplyMessage>>();
    }
}