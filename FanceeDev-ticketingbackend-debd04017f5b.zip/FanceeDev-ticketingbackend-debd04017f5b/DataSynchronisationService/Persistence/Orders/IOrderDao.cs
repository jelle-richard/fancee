using FanceeData.Models.Ticketing;

namespace DataSynchronisationService.Persistence.Orders;

public interface IOrderDao : ISynchronisationDao<Order>;