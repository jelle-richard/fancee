using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace DataSynchronisationService.Persistence.Orders;

public class OrderDao : IOrderDao
{
    private readonly TicketingContext _context;

    public OrderDao(TicketingContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Order>> NewlyCreatedAsync(DateTime? from)
    {
        return await _context.Orders
            .Where(o => from == null || o.CreatedAt > from)
            .Where(o => o.ReservationReferenceNavigation != null)
            .Include(o => o.IssuedProducts)
            .Include(o => o.ReservationReferenceNavigation)
            .ThenInclude(rrn => rrn.ReservedProducts)
            .ThenInclude(rp => rp.Product)
            .Include(o => o.CurrencyNavigation)
            .ToListAsync();
    }

    public async Task<IEnumerable<Order>> UpdatedSinceAsync(IList<Guid> modelIds, DateTime? until)
    {
        return await _context.Orders
            .Where(o => modelIds.Contains(o.Id))
            .Where(o => until == null || o.CreatedAt <= until)
            .Where(o => o.ReservationReferenceNavigation != null)
            .Include(o => o.IssuedProducts)
            .Include(o => o.ReservationReferenceNavigation)
            .ThenInclude(rrn => rrn.ReservedProducts)
            .ThenInclude(rp => rp.Product)
            .Include(o => o.CurrencyNavigation)
            .ToListAsync();
    }
}