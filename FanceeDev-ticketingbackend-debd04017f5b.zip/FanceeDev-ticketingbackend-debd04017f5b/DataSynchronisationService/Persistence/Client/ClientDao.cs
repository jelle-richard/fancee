using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace DataSynchronisationService.Persistence.Client;

public class ClientDao : IClientDao
{
    private readonly TicketingContext _dbContext;

    public ClientDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Client>> NewlyCreatedAsync(DateTime? from)
    {
        return await _dbContext.Clients
            .Where(u => from == null || u.User.CreatedOn >= from)
            .Include(c => c.ClientOrders)
            .ThenInclude(co => co.Order)
            .ThenInclude(o => o.IssuedProducts)
            .ThenInclude(ip => ip.Product)
            .Include(c => c.ClientOrders)
            .ThenInclude(co => co.Address)
            .Include(u => u.User)
            .ThenInclude(u => u.UserContactInfo)
            .ThenInclude(uc => uc.Address)
            .ToListAsync();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Client>> UpdatedSinceAsync(IList<Guid> modelIds, DateTime? until)
    {
        return await _dbContext.Clients
            .Where(c => until == null || c.User.CreatedOn <= until)
            .Where(u => modelIds.Contains(u.User.Id))
            .Include(c => c.ClientOrders)
            .ThenInclude(co => co.Order)
            .ThenInclude(o => o.IssuedProducts)
            .ThenInclude(ip => ip.Product)
            .Include(c => c.ClientOrders)
            .ThenInclude(co => co.Address)
            .Include(u => u.User)
            .ThenInclude(u => u.UserContactInfo)
            .ThenInclude(uc => uc.Address)
            .ToListAsync();
    }
}