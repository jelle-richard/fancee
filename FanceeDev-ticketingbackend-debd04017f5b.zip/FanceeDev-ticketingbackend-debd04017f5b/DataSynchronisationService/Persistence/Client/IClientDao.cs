namespace DataSynchronisationService.Persistence.Client;

public interface IClientDao : ISynchronisationDao<FanceeData.Models.Ticketing.Client>;