namespace DataSynchronisationService.Persistence.Event;

public interface IEventDao : ISynchronisationDao<FanceeData.Models.Ticketing.Event>;