using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace DataSynchronisationService.Persistence.Event;

public class EventDao : IEventDao
{
    private readonly TicketingContext _dbContext;

    public EventDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Event>> NewlyCreatedAsync(DateTime? from)
    {
        return await _dbContext.Events
            .Where(e => from == null || e.CreatedOn > from)
            .Include(e => e.Shops)
            .Include(e => e.Products)
            .ThenInclude(p => p.PriceHistories)
            .Include(e => e.Products)
            .ThenInclude(p => p.IssuedProducts)
            .ThenInclude(ip => ip.Order)
            .ThenInclude(o => o.ClientOrder)
            .Include(e => e.Tags)
            .Include(p => p.Address)
            .ToListAsync();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Event>> UpdatedSinceAsync(IList<Guid> modelIds, DateTime? until)
    {
        return await _dbContext.Events
            .Where(e => until == null || e.CreatedOn <= until)
            .Include(e => e.Shops)
            .Include(e => e.Products)
            .ThenInclude(p => p.PriceHistories)
            .Include(e => e.Products)
            .ThenInclude(p => p.IssuedProducts)
            .ThenInclude(ip => ip.Order)
            .ThenInclude(o => o.ClientOrder)
            .Include(e => e.Tags)
            .Include(p => p.Address)
            .ToListAsync();
    }
}