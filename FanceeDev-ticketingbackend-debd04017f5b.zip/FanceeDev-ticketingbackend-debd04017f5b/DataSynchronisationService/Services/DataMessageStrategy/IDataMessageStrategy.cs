using WebApiCore.Dtos;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Services.DataMessageStrategy;

public interface IDataMessageStrategy
{
    /// <summary>
    /// Gets the type of data of which this strategy is being used for.
    /// </summary>
    public TicketingDataType Type { get; }

    /// <summary>
    /// Executes specific logic to the type of data synchronisation.
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public Task<IRequestTicketingDataReplyMessage> ExecuteAsync(IRequestTicketingDataMessage message);
}