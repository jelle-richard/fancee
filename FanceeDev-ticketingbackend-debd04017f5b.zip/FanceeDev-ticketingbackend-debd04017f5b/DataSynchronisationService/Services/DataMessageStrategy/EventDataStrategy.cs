using System.Text.Json;
using DataSynchronisationService.Persistence.Event;
using DataSynchronisationService.Utils;
using WebApiCore.Dtos;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Services.DataMessageStrategy;

public class EventDataStrategy(IEventDao eventDao) : IDataMessageStrategy
{
    public TicketingDataType Type => TicketingDataType.Events;

    public async Task<IRequestTicketingDataReplyMessage> ExecuteAsync(IRequestTicketingDataMessage message)
    {
        if (message.SyncType == SynchronisationType.FetchNewlyCreated)
            message.SerializedCreatedData = JsonSerializer.Serialize((await eventDao.NewlyCreatedAsync(message.RequestCreatedFrom)).Select(e => e.ToDto()));

        if (message.SyncType == SynchronisationType.ValidateExistingAndOrUpdate)
            message.SerializedUpdatedData = JsonSerializer.Serialize((await eventDao.UpdatedSinceAsync(message.RequestUpdateFor, message.RequestCreatedFrom)).Select(e => e.ToDto()));

        return new RequestTicketingEventDataReplyMessage
        {
            SyncType = message.SyncType,
            RequestCreatedFrom = message.RequestCreatedFrom,
            RequestUpdateFor = message.RequestUpdateFor,
            SerializedUpdatedData = message.SerializedUpdatedData,
            SerializedCreatedData = message.SerializedCreatedData
        };
    }
}