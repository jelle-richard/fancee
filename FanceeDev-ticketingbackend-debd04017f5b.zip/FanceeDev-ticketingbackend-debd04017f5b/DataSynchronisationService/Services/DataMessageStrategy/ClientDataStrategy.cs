using System.Text.Json;
using DataSynchronisationService.Persistence.Client;
using DataSynchronisationService.Utils;
using WebApiCore.Dtos;
using WebApiCore.MessageBus.Messages.DataSynchronisation;

namespace DataSynchronisationService.Services.DataMessageStrategy;

public class UserDataStrategy(IClientDao clientDao) : IDataMessageStrategy
{
    public TicketingDataType Type => TicketingDataType.Clients;

    public async Task<IRequestTicketingDataReplyMessage> ExecuteAsync(IRequestTicketingDataMessage message)
    {
        if (message.SyncType == SynchronisationType.FetchNewlyCreated)
            message.SerializedCreatedData = JsonSerializer.Serialize((await clientDao.NewlyCreatedAsync(message.RequestCreatedFrom)).ToDto());

        if (message.SyncType == SynchronisationType.ValidateExistingAndOrUpdate)
            message.SerializedUpdatedData = JsonSerializer.Serialize((await clientDao.UpdatedSinceAsync(message.RequestUpdateFor, message.RequestCreatedFrom)).ToDto());

        return new RequestTicketingUserDataReplyMessage
        {
            SyncType = message.SyncType,
            RequestCreatedFrom = message.RequestCreatedFrom,
            RequestUpdateFor = message.RequestUpdateFor,
            SerializedUpdatedData = message.SerializedUpdatedData,
            SerializedCreatedData = message.SerializedCreatedData
        };
    }
}