﻿using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace CurrencyService.Persistence.CurrencyExchangeRate;

public class CurrencyExchangeRateDao : ICurrencyExchangeRateDao
{
    private readonly TicketingContext _dbContext;

    public CurrencyExchangeRateDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IList<FanceeData.Models.Ticketing.CurrencyExchangeRate>> AllAsync() => await _dbContext.CurrencyExchangeRates.ToListAsync();

    public async Task UpdateRangeAsync(IEnumerable<FanceeData.Models.Ticketing.CurrencyExchangeRate> exchangeRates)
    {
        _dbContext.CurrencyExchangeRates.UpdateRange(exchangeRates);

        await _dbContext.SaveChangesAsync();
    }
}