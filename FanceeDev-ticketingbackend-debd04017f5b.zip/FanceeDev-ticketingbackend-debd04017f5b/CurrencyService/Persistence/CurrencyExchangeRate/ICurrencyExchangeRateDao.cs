﻿namespace CurrencyService.Persistence.CurrencyExchangeRate;

public interface ICurrencyExchangeRateDao
{
    /// <summary>
    /// Returns all available currency exchange rates.
    /// </summary>
    /// <returns></returns>
    public Task<IList<FanceeData.Models.Ticketing.CurrencyExchangeRate>> AllAsync();

    /// <summary>
    /// Updates the given entities in the database with the newly given data.
    /// </summary>
    /// <param name="exchangeRates"></param>
    /// <returns></returns>
    public Task UpdateRangeAsync(IEnumerable<FanceeData.Models.Ticketing.CurrencyExchangeRate> exchangeRates);
}