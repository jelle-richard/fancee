using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace CurrencyService.Persistence.Currency;

public class CurrencyDao : ICurrencyDao
{
    private readonly TicketingContext _dbContext;

    public CurrencyDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Currency>> ActiveCurrenciesAsync()
    {
        return await _dbContext.Currencies.Where(c => c.Active)
            .ToListAsync();
    }

    public async Task<FanceeData.Models.Ticketing.Currency?> ByShortCodeAsync(string shortCode)
    {
        return await _dbContext.Currencies.Where(c => c.ShortCode == shortCode)
            .FirstOrDefaultAsync();
    }
}