namespace CurrencyService.Persistence.Currency;

public interface ICurrencyDao
{
    /// <summary>
    /// Gets the active currencies.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.Currency>> ActiveCurrenciesAsync();

    /// <summary>
    /// Gets a currency by the shortcode.
    /// </summary>
    /// <param name="shortCode"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.Currency?> ByShortCodeAsync(string shortCode);
}