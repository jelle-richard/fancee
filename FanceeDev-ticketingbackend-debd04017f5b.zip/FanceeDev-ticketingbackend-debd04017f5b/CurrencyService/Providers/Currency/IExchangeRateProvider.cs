﻿using CurrencyService.Dtos.Shared.Currency;

namespace CurrencyService.Providers.Currency;

public interface IExchangeRateProvider
{
    /// <summary>
    /// Gets the new conversion details with the given currency as the 'base'.
    /// </summary>
    /// <returns></returns>
    public Task<ExchangeRates> GetAsync(CurrencyCode @base);
}