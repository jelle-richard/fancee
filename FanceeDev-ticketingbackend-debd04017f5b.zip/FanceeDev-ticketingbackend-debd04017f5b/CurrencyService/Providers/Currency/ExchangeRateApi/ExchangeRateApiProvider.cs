﻿using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Providers.Currency.ExchangeRateApi.Dtos;
using CurrencyService.Utils.Adapter;
using WebApiCore.Exceptions;
using WebApiCore.Utils.Http;

namespace CurrencyService.Providers.Currency.ExchangeRateApi;

public class ExchangeRateApiProvider : IExchangeRateProvider
{
    private const string ApiName = "ExchangeRate-API";
    private const string ConfigSection = "ExchangeRateApi";
    private const string ConfigApiKey = "ApiKey";
    private const string ConfigApiUrl = "ApiUrl";

    private readonly IJsonHttpClient _httpClient;
    private readonly ILogger<ExchangeRateApiProvider> _logger;
    private readonly string _apiKey;
    private readonly string _apiUrl;

    public ExchangeRateApiProvider(IConfiguration configuration, IJsonHttpClient httpClient, ILogger<ExchangeRateApiProvider> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
        _apiKey = configuration.GetValue($"{ConfigSection}:{ConfigApiKey}", string.Empty)!;
        _apiUrl = configuration.GetValue($"{ConfigSection}:{ConfigApiUrl}", string.Empty)!;

        if (string.IsNullOrWhiteSpace(_apiKey))
            throw new MissingRequiredConfigurationEntryException(ConfigSection, ConfigApiKey);

        if (string.IsNullOrWhiteSpace(_apiUrl))
            throw new MissingRequiredConfigurationEntryException(ConfigSection, ConfigApiUrl);
    }

    public async Task<ExchangeRates> GetAsync(CurrencyCode @base)
    {
        var url = $"{_apiUrl}/{_apiKey}/latest/{@base}";

        try
        {
            var response = await _httpClient.GetAsync<LatestResponse>(url) ?? throw new ApiRequestFailedException(ApiName);

            return response.ToExchangeRates();
        }
        catch (Exception ex) when (ex is not ApiException)
        {
            _logger.LogError(ex, "Request to {api} failed. See inner exception for more details.", ApiName);

            throw new ApiRequestFailedException(ApiName);
        }
    }
}