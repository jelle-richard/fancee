﻿using System.Text.Json.Serialization;
using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Utils.Converter;

namespace CurrencyService.Providers.Currency.ExchangeRateApi.Dtos;

public class LatestResponse
{
    [JsonPropertyName("result")]
    public string Result { get; set; } = default!;

    [JsonPropertyName("documentation")]
    public string Documentation { get; set; } = default!;

    [JsonPropertyName("terms_of_use")]
    public string TermsOfUse { get; set; } = default!;

    [JsonPropertyName("time_last_update_unix")]
    public long TimeLastUpdateUnix { get; set; } = default!;

    [JsonPropertyName("time_last_update_utc")]
    public string TimeLastUpdateUtc { get; set; } = default!;

    [JsonPropertyName("time_next_update_unix")]
    public long TimeNextUpdateUnix { get; set; } = default!;

    [JsonPropertyName("time_next_update_utc")]
    public string TimeNextUpdateUtc { get; set; } = default!;

    [JsonPropertyName("conversion_rates")]
    [JsonConverter(typeof(CurrencyExchangeRateConverter))]
    public Dictionary<CurrencyCode, decimal> ConversionRates { get; set; } = default!;
}