﻿namespace CurrencyService.Dtos.Shared.Currency;

public class ExchangeRates
{
    public DateTime LastAlteration { get; set; }

    public Dictionary<CurrencyCode, decimal> Rates { get; set; } = default!;
}