﻿using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Providers.Currency;
using CurrencyService.Services;
using WebApiCore.BackgroundTasks;
using WebApiCore.Exceptions;
using WebApiCore.MessageBus.Messages.Currency;

namespace CurrencyService.BackgroundTasks.MessageBus;

public sealed class UpdateCurrencyExchangeRatesListener : MessageBusHostedService<UpdateCurrencyExchangeRatesMessage, UpdateCurrencyExchangeRatesListener>, ISimpleMessageBus<UpdateCurrencyExchangeRatesMessage>
{
    protected override string LogPrefix => $"[{nameof(UpdateCurrencyExchangeRatesListener)}]";

    private IExchangeRateProvider? _exchangeRateProvider;
    private ICurrencyService _currencyService = default!;

    public UpdateCurrencyExchangeRatesListener(IServiceProvider serviceProvider) : base(serviceProvider)
    {
    }

    /// <summary>
    /// Gets the new currency exchange rates and updates the persisted values.
    /// </summary>
    /// <returns></returns>
    public async Task ProcessAsync(UpdateCurrencyExchangeRatesMessage? message)
    {
        try
        {
            var rates = await _exchangeRateProvider!.GetAsync(CurrencyCode.EUR);

            await _currencyService.UpdateExchangeRatesAsync(rates);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "{Prefix} Unexpected error occured. See inner exception for more details.", LogPrefix);
        }
    }

    public override Task StartAsync(CancellationToken cancellationToken) =>
        _exchangeRateProvider == null
            ? Task.CompletedTask
            : base.StartAsync(cancellationToken);

    protected override void RegisterDependencies()
    {
        _currencyService = ServiceProvider.GetRequiredService<ICurrencyService>();

        try
        {
            _exchangeRateProvider = ServiceProvider.GetRequiredService<IExchangeRateProvider>();
        }
        catch (MissingRequiredConfigurationEntryException ex)
        {
            Logger.LogCritical(ex, "{Prefix} Unable to update currency exchange rates because the application is not configured correctly.", LogPrefix);
        }
    }
}