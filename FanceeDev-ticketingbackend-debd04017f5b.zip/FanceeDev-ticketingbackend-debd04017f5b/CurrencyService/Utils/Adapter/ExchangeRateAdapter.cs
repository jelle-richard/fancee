﻿using CurrencyService.Dtos.Shared.Currency;
using CurrencyService.Providers.Currency.ExchangeRateApi.Dtos;
using WebApiCore.Utils;

namespace CurrencyService.Utils.Adapter;

public static class ExchangeRateAdapter
{
    public static ExchangeRates ToExchangeRates(this LatestResponse latestResponse) =>
        new()
        {
            LastAlteration = DateTimeUtils.FromUnixTimestamp(latestResponse.TimeLastUpdateUnix),
            Rates = latestResponse.ConversionRates
        };
}