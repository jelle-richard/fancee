﻿using System.Text.Json;
using System.Text.Json.Serialization;
using CurrencyService.Dtos.Shared.Currency;

namespace CurrencyService.Utils.Converter;

public class CurrencyExchangeRateConverter : JsonConverter<Dictionary<CurrencyCode, decimal>>
{
    public override Dictionary<CurrencyCode, decimal> Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType != JsonTokenType.StartObject)
            throw new JsonException();

        var dictionary = new Dictionary<CurrencyCode, decimal>();

        while (reader.Read())
        {
            if (reader.TokenType == JsonTokenType.EndObject)
                return dictionary;

            var propertyName = reader.GetString();

            // If we can't parse the enum value, we skip it.
            // For performance, we parse with ignoreCase false first.
            if (!Enum.TryParse(propertyName, false, out CurrencyCode key) && !Enum.TryParse(propertyName, true, out key))
            {
                reader.Read(); // We need to read the 'value part' before continuing.

                continue;
            }

            reader.Read();
            dictionary.Add(key, reader.GetDecimal());
        }

        throw new JsonException();
    }

    public override void Write(Utf8JsonWriter writer, Dictionary<CurrencyCode, decimal> value, JsonSerializerOptions options) =>
        writer.WriteRawValue(JsonSerializer.Serialize(value));
}