using WebApiCore.Exceptions;
using WebApiCore.Utils;

namespace CurrencyService.Services.Exceptions;

public class PlatformBaseCurrencyNotConfiguredException()
    : InternalServerErrorApiException("The platform base currency has no matching data source", ErrorCode.ExceptionInvalidConfiguration);