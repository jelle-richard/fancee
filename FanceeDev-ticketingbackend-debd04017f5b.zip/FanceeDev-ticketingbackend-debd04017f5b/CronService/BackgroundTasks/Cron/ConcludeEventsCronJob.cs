using CronService.Utils;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Event;

namespace CronService.BackgroundTasks.Cron;

public class ConcludeEventsCronJob : MonitoredCronJob
{
    private const string ConfigKeyName = "ConcludeEvents";
    private const int MaximumTriesBeforeStaleLog = 5;

    private readonly TimeSpan _defaultTimeSpan = TimeSpan.FromSeconds(30);
    private IMessagePublisher<ConcludeEventsMessage>? _publisher;
    private IConfiguration? _configuration;

    public ConcludeEventsCronJob()
    {
        LogPrefix = $"[{nameof(ConcludeEventsCronJob)}]";

        OnOverlap += (_, skipped) =>
        {
            if (skipped >= MaximumTriesBeforeStaleLog)
                Logger!.LogCritical("{Prefix} Cron skipped {Amount} iterations after each other. This could mean a hanging RPC call", LogPrefix, skipped);
        };
    }

    public override TimeSpan GetInterval() =>
        _configuration.GetTimeSpan($"{ICronJob.ConfigSectionName}:{ConfigKeyName}", _defaultTimeSpan);

    public override void ConfigureDependencies(IServiceScope serviceScope)
    {
        Logger = serviceScope.ServiceProvider.GetRequiredService<ILogger<ConcludeEventsCronJob>>();
        _publisher = serviceScope.ServiceProvider.GetRequiredService<IMessagePublisher<ConcludeEventsMessage>>();
        _configuration = serviceScope.ServiceProvider.GetRequiredService<IConfiguration>();
    }

    public override void Execute()
    {
        Logger!.LogInformation("{Prefix} Sending conclude events cron message", LogPrefix);
        _publisher!.Call(new());
    }
}