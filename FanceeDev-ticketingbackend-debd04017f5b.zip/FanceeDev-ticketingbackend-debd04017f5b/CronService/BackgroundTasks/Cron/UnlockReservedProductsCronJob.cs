using CronService.Utils;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Product;

namespace CronService.BackgroundTasks.Cron;

public class UnlockReservedProductsCronJob : MonitoredCronJob
{
    private const string ConfigKeyName = "UnlockReservedProducts";
    private const int MaximumTriesBeforeStaleLog = 5;

    private readonly TimeSpan _defaultTimeSpan = TimeSpan.FromMinutes(1);
    private IMessagePublisher<UnlockReservedProductsMessage>? _publisher;
    private IConfiguration? _configuration;

    public UnlockReservedProductsCronJob()
    {
        LogPrefix = $"[{nameof(UnlockReservedProductsCronJob)}]";

        OnOverlap += (_, skipped) =>
        {
            if (skipped >= MaximumTriesBeforeStaleLog)
                Logger!.LogCritical("{Prefix} Cron skipped {Amount} iterations after each other. This could mean a hanging RPC call", LogPrefix, skipped);
        };
    }

    public override TimeSpan GetInterval() =>
        _configuration.GetTimeSpan($"{ICronJob.ConfigSectionName}:{ConfigKeyName}", _defaultTimeSpan);

    public override void ConfigureDependencies(IServiceScope serviceScope)
    {
        Logger = serviceScope.ServiceProvider.GetRequiredService<ILogger<UnlockReservedProductsCronJob>>();
        _publisher = serviceScope.ServiceProvider.GetRequiredService<IMessagePublisher<UnlockReservedProductsMessage>>();
        _configuration = serviceScope.ServiceProvider.GetRequiredService<IConfiguration>();
    }

    public override void Execute()
    {
        Logger!.LogInformation("{Prefix} Sending unlock products cron message", LogPrefix);
        _publisher!.Call(new());
    }
}