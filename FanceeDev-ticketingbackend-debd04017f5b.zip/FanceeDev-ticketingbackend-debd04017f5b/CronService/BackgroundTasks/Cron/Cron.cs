﻿namespace CronService.BackgroundTasks.Cron;

/// <summary>
/// Enables running of cron jobs. These are run every specified interval.
/// </summary>
/// <typeparam name="TCronJob"></typeparam>
public class Cron<TCronJob> : IHostedService, IDisposable where TCronJob : ICronJob, new()
{
    public TCronJob CronJob { get; } = new();

    private Timer? _timer;
    private bool _disposed;

    public Cron(IServiceProvider serviceProvider)
    {
        CronJob.ConfigureDependencies(serviceProvider.CreateScope());
    }

    public void Dispose()
    {
        Dispose(true);

        GC.SuppressFinalize(this);
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _timer = new(TimerTick, null, TimeSpan.Zero, CronJob.GetInterval());

        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _timer?.Change(Timeout.Infinite, 0);

        return Task.CompletedTask;
    }

    protected virtual void Dispose(bool disposing)
    {
        if (_disposed)
            return;

        if (disposing)
            _timer?.Dispose();

        _disposed = true;
    }

    /// <summary>
    /// Gets called every time the timer interval is reached.
    /// </summary>
    /// <param name="state"></param>
    private void TimerTick(object? state)
    {
        CronJob.DoWork();
    }
}