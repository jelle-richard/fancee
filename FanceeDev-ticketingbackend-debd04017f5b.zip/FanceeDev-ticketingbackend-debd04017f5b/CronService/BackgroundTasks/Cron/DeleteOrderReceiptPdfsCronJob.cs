using CronService.Utils;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Pdf;

namespace CronService.BackgroundTasks.Cron;

public class DeleteOrderReceiptPdfsCronJob : MonitoredCronJob
{
    private const string ConfigKeyName = "DeleteOrderReceiptPdfs";
    private const int MaximumTriesBeforeStaleLog = 1;

    private readonly TimeSpan _defaultTimeSpan = TimeSpan.FromMinutes(1);
    private IMessagePublisher<DeleteOrderReceiptMessage>? _publisher;
    private IConfiguration? _configuration;

    public DeleteOrderReceiptPdfsCronJob()
    {
        LogPrefix = $"[{nameof(DeleteOrderReceiptPdfsCronJob)}]";

        OnOverlap += (_, skipped) =>
        {
            if (skipped >= MaximumTriesBeforeStaleLog)
                Logger!.LogCritical("{Prefix} Cron skipped {Amount} iterations after each other. This could mean a hanging RPC call", LogPrefix, skipped);
        };
    }

    public override TimeSpan GetInterval() =>
        _configuration.GetTimeSpan($"{ICronJob.ConfigSectionName}:{ConfigKeyName}", _defaultTimeSpan);

    public override void ConfigureDependencies(IServiceScope serviceScope)
    {
        Logger = serviceScope.ServiceProvider.GetRequiredService<ILogger<DeleteOrderReceiptPdfsCronJob>>();
        _publisher = serviceScope.ServiceProvider.GetRequiredService<IMessagePublisher<DeleteOrderReceiptMessage>>();
        _configuration = serviceScope.ServiceProvider.GetRequiredService<IConfiguration>();
    }

    public override void Execute()
    {
        Logger!.LogInformation("{Prefix} Sending cron message", LogPrefix);
        _publisher!.Call(new());
    }
}