using CronService.Utils;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.ShopViews;

namespace CronService.BackgroundTasks.Cron;

public class CleanShopViewsInCacheCronJob : MonitoredCronJob
{
    private const string ConfigKeyName = "WriteShopViewsInCacheToDb";
    private const int MaximumTriesBeforeStaleLog = 1;

    private readonly TimeSpan _defaultTimeSpan = TimeSpan.FromSeconds(30);
    private IMessagePublisher<CleanShopViewsInCacheMessage>? _publisher;
    private IConfiguration? _configuration;

    public CleanShopViewsInCacheCronJob()
    {
        LogPrefix = $"[{nameof(CleanShopViewsInCacheCronJob)}]";

        OnOverlap += (_, skipped) =>
        {
            if (skipped >= MaximumTriesBeforeStaleLog)
                Logger!.LogCritical("{Prefix} Cron skipped {Amount} iterations after each other. This could mean a hanging RPC call", LogPrefix, skipped);
        };
    }

    public override TimeSpan GetInterval() =>
        _configuration.GetTimeSpan($"{ICronJob.ConfigSectionName}:{ConfigKeyName}", _defaultTimeSpan);

    public override void ConfigureDependencies(IServiceScope serviceScope)
    {
        _publisher = serviceScope.ServiceProvider.GetRequiredService<IMessagePublisher<CleanShopViewsInCacheMessage>>();
        Logger = serviceScope.ServiceProvider.GetRequiredService<ILogger<CleanShopViewsInCacheCronJob>>();
        _configuration = serviceScope.ServiceProvider.GetRequiredService<IConfiguration>();
    }

    public override void Execute()
    {
        Logger!.LogInformation("{Prefix} Removing shop views in cache and write to database", LogPrefix);
        _publisher!.Call(new());
    }
}