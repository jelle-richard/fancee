﻿using CronService.Utils;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Currency;

namespace CronService.BackgroundTasks.Cron;

public class UpdateCurrencyExchangeRatesCronJob : MonitoredCronJob
{
    private const string ConfigKeyName = "UpdateCurrencyExchangeRates";

    private readonly TimeSpan _defaultTimeSpan = TimeSpan.FromHours(24);
    private IMessagePublisher<UpdateCurrencyExchangeRatesMessage>? _publisher;
    private IConfiguration? _configuration;

    public UpdateCurrencyExchangeRatesCronJob()
    {
        LogPrefix = $"[{nameof(UpdateCurrencyExchangeRatesCronJob)}]";
    }

    public override TimeSpan GetInterval() =>
        _configuration.GetTimeSpan($"{ICronJob.ConfigSectionName}:{ConfigKeyName}", _defaultTimeSpan);

    public override void ConfigureDependencies(IServiceScope serviceScope)
    {
        _publisher = serviceScope.ServiceProvider.GetRequiredService<IMessagePublisher<UpdateCurrencyExchangeRatesMessage>>();
        Logger = serviceScope.ServiceProvider.GetRequiredService<ILogger<UpdateCurrencyExchangeRatesCronJob>>();
        _configuration = serviceScope.ServiceProvider.GetRequiredService<IConfiguration>();
    }

    public override void Execute()
    {
        Logger!.LogInformation("{Prefix} Sending cron message", LogPrefix);
        _publisher!.Call(new());
    }
}