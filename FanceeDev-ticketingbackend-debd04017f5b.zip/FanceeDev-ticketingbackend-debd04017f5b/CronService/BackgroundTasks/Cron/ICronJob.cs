﻿namespace CronService.BackgroundTasks.Cron;

public interface ICronJob
{
    public const string ConfigSectionName = "CronIntervals";

    /// <summary>
    /// Gets the interval in which the timer will tick.
    /// </summary>
    /// <returns></returns>
    public TimeSpan GetInterval();

    /// <summary>
    /// Allows the cron job to get required dependencies.
    /// </summary>
    /// <param name="serviceScope"></param>
    public void ConfigureDependencies(IServiceScope serviceScope);

    /// <summary>
    /// Executes the cron job logic.
    /// </summary>
    public void DoWork();
}