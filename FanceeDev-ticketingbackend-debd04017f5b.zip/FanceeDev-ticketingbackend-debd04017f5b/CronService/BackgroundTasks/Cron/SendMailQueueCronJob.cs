﻿using CronService.Utils;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Mail;

namespace CronService.BackgroundTasks.Cron;

public class SendMailQueueCronJob : MonitoredCronJob
{
    private const string ConfigKeyName = "SendMailQueue";
    private const int MaximumTriesBeforeStaleLog = 5;

    private readonly TimeSpan _defaultTimeSpan = TimeSpan.FromMinutes(1);
    private IMessagePublisher<SendMailQueueMessage>? _publisher;
    private IConfiguration? _configuration;

    public SendMailQueueCronJob()
    {
        LogPrefix = $"[{nameof(SendMailQueueCronJob)}]";

        OnOverlap += (_, skipped) =>
        {
            if (skipped >= MaximumTriesBeforeStaleLog)
                Logger!.LogCritical("{Prefix} Cron skipped {Amount} iterations after each other. This could mean a hanging RPC call", LogPrefix, skipped);
        };
    }

    public override TimeSpan GetInterval() =>
        _configuration.GetTimeSpan($"{ICronJob.ConfigSectionName}:{ConfigKeyName}", _defaultTimeSpan);

    public override void ConfigureDependencies(IServiceScope serviceScope)
    {
        _publisher = serviceScope.ServiceProvider.GetRequiredService<IMessagePublisher<SendMailQueueMessage>>();
        Logger = serviceScope.ServiceProvider.GetRequiredService<ILogger<SendMailQueueCronJob>>();
        _configuration = serviceScope.ServiceProvider.GetRequiredService<IConfiguration>();
    }

    public override void Execute()
    {
        Logger!.LogInformation("{Prefix} Sending cron message", LogPrefix);
        _publisher!.Call(new());
    }
}