using CronService.Utils;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Mail;

namespace CronService.BackgroundTasks.Cron;

public class RemoveSentMailsCronJob : MonitoredCronJob
{
    private const string ConfigKeyName = "RemoveSentMails";
    private const int MaximumTriesBeforeStaleLog = 5;
    private const int Limit = 25;

    private readonly TimeSpan _defaultTimeSpan = TimeSpan.FromMinutes(15);
    private IMessagePublisher<RemoveSentMailsMessage>? _publisher;
    private IConfiguration? _configuration;

    public RemoveSentMailsCronJob()
    {
        LogPrefix = $"[{nameof(RemoveSentMailsCronJob)}]";

        OnOverlap += (_, skipped) =>
        {
            if (skipped >= MaximumTriesBeforeStaleLog)
                Logger!.LogCritical("{Prefix} Cron skipped {Amount} iterations after each other. This could mean a hanging RPC call", LogPrefix, skipped);
        };
    }

    public override TimeSpan GetInterval() =>
        _configuration.GetTimeSpan($"{ICronJob.ConfigSectionName}:{ConfigKeyName}", _defaultTimeSpan);

    public override void ConfigureDependencies(IServiceScope serviceScope)
    {
        _publisher = serviceScope.ServiceProvider.GetRequiredService<IMessagePublisher<RemoveSentMailsMessage>>();
        Logger = serviceScope.ServiceProvider.GetRequiredService<ILogger<RemoveSentMailsCronJob>>();
        _configuration = serviceScope.ServiceProvider.GetRequiredService<IConfiguration>();
    }

    public override void Execute()
    {
        Logger!.LogInformation("{Prefix} Sending remove sent mails cron message", LogPrefix);

        _publisher!.Call(new()
        {
            Limit = Limit
        });
    }
}