﻿namespace CronService.BackgroundTasks.Cron;

/// <summary>
/// Used for cron jobs that need to send RPC calls without the timer overlapping if
/// the call did not return in the specified <see cref="GetInterval" />.
/// </summary>
public abstract class MonitoredCronJob : ICronJob
{
    /// <summary>
    /// Gets called every time a overlap occurs.
    /// Integer is the amount of times the overlap has occurred.
    /// </summary>
    public event EventHandler<int>? OnOverlap;

    public ILogger<MonitoredCronJob>? Logger { protected set; get; }
    public string? LogPrefix { protected set; get; }

    private readonly object _lock = new();
    private int _skipped;

    /// <inheritdoc cref="ICronJob.GetInterval" />
    public abstract TimeSpan GetInterval();

    /// <inheritdoc cref="ICronJob.ConfigureDependencies" />
    public abstract void ConfigureDependencies(IServiceScope serviceScope);

    public void DoWork()
    {
        var hasLock = false;
        try
        {
            Monitor.TryEnter(_lock, ref hasLock);
            if (!hasLock)
            {
                Interlocked.Increment(ref _skipped);

                Logger!.LogInformation("{Prefix} Previous iteration is still working after {Time}. Skipping iteration", LogPrefix, GetInterval());
                OnOverlap?.Invoke(this, _skipped);

                return;
            }

            Execute();

            Interlocked.Exchange(ref _skipped, 0);
        }
        finally
        {
            if (hasLock)
                Monitor.Exit(_lock);
        }
    }

    /// <summary>
    /// Executes the (blocking) logic.
    /// </summary>
    public abstract void Execute();
}