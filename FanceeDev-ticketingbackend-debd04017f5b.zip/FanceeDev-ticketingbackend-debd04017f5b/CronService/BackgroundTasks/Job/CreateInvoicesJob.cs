using CronScheduler.Extensions.Scheduler;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Invoices;
using WebApiCore.Utils;

namespace CronService.BackgroundTasks.Job;

public class CreateInvoicesJob : IScheduledJob
{
    public string Name => nameof(CreateInvoicesJob);
    private const string LogPrefix = $"[{nameof(CreateInvoicesJob)}]";

    private readonly IMessagePublisher<CreateInvoicesMessage> _publisher;
    private readonly ILogger<CreateInvoicesJob> _logger;

    public CreateInvoicesJob(IServiceProvider serviceProvider)
    {
        var scope = serviceProvider.CreateScope();

        _publisher = scope.ServiceProvider.GetRequiredService<IMessagePublisher<CreateInvoicesMessage>>();
        _logger = scope.ServiceProvider.GetRequiredService<ILogger<CreateInvoicesJob>>();
    }

    public Task ExecuteAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("{Prefix} Sending Create Invoices message", LogPrefix);

        var now = DateTime.UtcNow;
        var previousMonth = new DateTime(now.Year, now.Month, 1).AddMonths(-1);

        _publisher.Publish(new()
        {
            Range = DateTimeUtils.GetMonthRange(previousMonth)
        });

        return Task.CompletedTask;
    }
}