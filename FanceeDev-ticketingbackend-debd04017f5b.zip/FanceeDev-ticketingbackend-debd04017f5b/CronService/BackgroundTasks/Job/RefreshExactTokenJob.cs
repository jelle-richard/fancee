using CronScheduler.Extensions.Scheduler;
using Fs.MessageBus.Publishers;
using WebApiCore.MessageBus.Messages.Token;

namespace CronService.BackgroundTasks.Job;

public class RefreshExactTokenJob : IScheduledJob
{
    public string Name => nameof(RefreshExactTokenJob);
    private const string LogPrefix = $"[{nameof(RefreshExactTokenJob)}]";

    private readonly IMessagePublisher<RefreshExactTokenMessage> _publisher;
    private readonly ILogger<RefreshExactTokenJob> _logger;

    public RefreshExactTokenJob(IServiceProvider serviceProvider)
    {
        var provider = serviceProvider.CreateScope().ServiceProvider;

        _publisher = provider.GetRequiredService<IMessagePublisher<RefreshExactTokenMessage>>();
        _logger = provider.GetRequiredService<ILogger<RefreshExactTokenJob>>();
    }

    public Task ExecuteAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("{Prefix} Sending Refresh Exact Token message", LogPrefix);

        _publisher.Publish(new());

        return Task.CompletedTask;
    }
}