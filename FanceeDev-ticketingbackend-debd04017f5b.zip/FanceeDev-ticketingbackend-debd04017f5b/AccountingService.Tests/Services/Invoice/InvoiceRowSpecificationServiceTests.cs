using AccountingService.Persistence.Invoice;
using AccountingService.Services.Invoice;

namespace AccountingService.Tests.Services.Invoice;

public class InvoiceRowSpecificationServiceTests
{
    private readonly Mock<IInvoiceRowSpecificationDao> _mockedInvoiceRowSpecificationDao = new();
    private readonly InvoiceRowSpecificationService _sut;

    public InvoiceRowSpecificationServiceTests()
    {
        _sut = new(_mockedInvoiceRowSpecificationDao.Object);
    }

    [Fact]
    public async Task TestThatNamesAsyncCallsInvoiceRowSpecificationDaoNamesAsync()
    {
        _mockedInvoiceRowSpecificationDao.Setup(irsd => irsd.NamesAsync())
            .ReturnsAsync(new[] { "Name 1" });

        var actual = (await _sut.NamesAsync()).ToList();

        Assert.Single(actual);
        Assert.Equal("Name 1", actual[0]);

        _mockedInvoiceRowSpecificationDao.Verify(irsd => irsd.NamesAsync(), Times.Once);
    }
}