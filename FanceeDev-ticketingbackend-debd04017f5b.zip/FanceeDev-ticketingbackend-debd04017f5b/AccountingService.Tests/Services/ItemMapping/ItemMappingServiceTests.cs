using AccountingService.Dtos.Requests.Exact;
using AccountingService.Persistence.Invoice;
using AccountingService.Persistence.ItemMapping;
using AccountingService.Services.ItemMapping;
using AccountingService.Services.ItemMapping.Exceptions;
using WebApiCore.Dtos.Shared;

namespace AccountingService.Tests.Services.ItemMapping;

public class ItemMappingServiceTests
{
    private readonly ItemMappingService _sut;
    private readonly Mock<IItemMappingDao> _mockedItemMappingDao = new();
    private readonly Mock<IInvoiceRowSpecificationDao> _mockedInvoiceRowSpecificationDao = new();

    public ItemMappingServiceTests()
    {
        _sut = new(_mockedItemMappingDao.Object, _mockedInvoiceRowSpecificationDao.Object);
    }

    [Fact]
    public async Task TestThatAddAsyncThrowsInvalidInvoiceRowSpecificationNameExceptionOnInvalidSpecificationName()
    {
        var items = new List<ConfigureItemRequest>
        {
            new()
            {
                PlatformItem = "One",
                CountryItems = new CountryItem[]
                {
                    new() { CountryCode = CountryCode.NL, ExactItemCode = Guid.Empty }
                }
            }
        };

        _mockedInvoiceRowSpecificationDao.Setup(irsd => irsd.ValidAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<InvalidInvoiceRowSpecificationNameException>(async () => await _sut.AddAsync(items));

        _mockedInvoiceRowSpecificationDao.Verify(irs => irs.ValidAsync(new[] { "One" }), Times.Once);
        _mockedItemMappingDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddAsyncCallsItemMappingDaoInsertAsync()
    {
        var items = new List<ConfigureItemRequest>
        {
            new()
            {
                PlatformItem = "One",
                CountryItems = new CountryItem[]
                {
                    new() { CountryCode = null, ExactItemCode = Guid.Empty },
                    new() { CountryCode = CountryCode.NL, ExactItemCode = Guid.Empty },
                    new() { CountryCode = CountryCode.DE, ExactItemCode = Guid.Empty }
                }
            }
        };

        _mockedInvoiceRowSpecificationDao.Setup(irsd => irsd.ValidAsync(It.IsAny<IEnumerable<string>>()))
            .ReturnsAsync(true);

        await _sut.AddAsync(items);

        _mockedInvoiceRowSpecificationDao.Verify(irs => irs.ValidAsync(It.Is<IEnumerable<string>>(e => true)), Times.Once);
        _mockedItemMappingDao.Verify(imd => imd.InsertAsync(It.IsAny<FanceeData.Models.Ticketing.Exact.ItemMapping[]>()), Times.Once);
    }

    [Fact]
    public async Task TestThatMappingsAsyncReturnsConfiguredItemResponses()
    {
        _mockedItemMappingDao.Setup(imd => imd.ItemMappingsAsync()).ReturnsAsync(new FanceeData.Models.Ticketing.Exact.ItemMapping[]
        {
            new() { CountryCode = "BE", ExactItemCode = Guid.Empty, InvoiceRowSpecificationName = "UnitTest" }
        });

        var actual = (await _sut.MappingsAsync()).ToList();

        Assert.Single(actual);
        Assert.Equal("UnitTest", actual[0].PlatformItem);
        Assert.Single(actual[0].CountryItems);

        _mockedItemMappingDao.Verify(itd => itd.ItemMappingsAsync(), Times.Once);
    }
}