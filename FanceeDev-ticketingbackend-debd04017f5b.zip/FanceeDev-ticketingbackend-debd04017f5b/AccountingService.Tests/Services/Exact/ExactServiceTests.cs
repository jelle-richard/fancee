using System.Text;
using AccountingService.Persistence.Exact;
using AccountingService.Persistence.Invoice;
using AccountingService.Persistence.ItemMapping;
using AccountingService.Services.Exact;
using AccountingService.Services.Exact.Exceptions;
using AccountingService.Services.OAuth;
using AccountingService.Services.OAuth.Exceptions;
using AccountingUtils.Providers.Accounting.Exact;
using AccountingUtils.Providers.Accounting.Exact.Requests;
using AccountingUtils.Providers.Accounting.Exact.Responses;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Exact;
using FanceeData.Models.Ticketing.Invoicing;
using WebApiCore.Dtos.Shared;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Storage;

namespace AccountingService.Tests.Services.Exact;

public class ExactServiceTests
{
    private const int InvoiceId = 2942;
    private const int Division = 492582;
    private const string Journal = "test";

    private readonly ExactService _sut;
    private readonly Mock<IExactConfigurationDao> _mockedExactConfigurationDao = new();
    private readonly Mock<IExactProvider> _mockedExactProvider = new();
    private readonly Mock<IOAuthProviderTokenService> _mockedOAuthProviderTokenService = new();
    private readonly Mock<IInvoiceDao> _mockedInvoiceDao = new();
    private readonly Mock<IExactDao> _mockedExactDao = new();
    private readonly Mock<IItemMappingDao> _mockedItemMappingDao = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();

    public ExactServiceTests()
    {
        _sut = new(
            _mockedExactConfigurationDao.Object,
            _mockedExactProvider.Object,
            _mockedOAuthProviderTokenService.Object,
            _mockedInvoiceDao.Object,
            _mockedExactDao.Object,
            _mockedItemMappingDao.Object,
            _mockedCurrencyService.Object,
            _mockedStorageService.Object
        );
    }

    [Fact]
    public async Task TestThatConfigurationAsyncThrowsMissingExactConfigurationExceptionOnNullValue()
    {
        await Assert.ThrowsAsync<MissingExactConfigurationException>(async () => await _sut.ConfigurationAsync());

        _mockedExactConfigurationDao.Verify(ecd => ecd.GetAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatConfigurationAsyncCallsExactConfigurationDaoGetAsync()
    {
        var config = new ExactConfiguration { Journal = Journal };

        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync()).ReturnsAsync(config);

        var actual = await _sut.ConfigurationAsync();

        Assert.Equal(config, actual);

        _mockedExactConfigurationDao.Verify(ecd => ecd.GetAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatSetConfigurationAsyncCallsExactConfigurationDaoSetAsync()
    {
        await _sut.SetConfigurationAsync(Division, Journal);

        _mockedExactConfigurationDao.Verify(ecd => ecd.SetAsync(
            It.Is<ExactConfiguration>(ec =>
                ec.Division == Division &&
                ec.Journal == Journal)
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatRefreshTokenAsyncDoesNotRefreshIfNoRefreshTokenIsAvailable()
    {
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { RefreshToken = null });

        await Assert.ThrowsAsync<OAuthProviderTokenNotFoundException>(async () => await _sut.RefreshTokenAsync());

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedExactDao.VerifyNoOtherCalls();
        _mockedOAuthProviderTokenService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatRefreshTokenAsyncRefreshesToken()
    {
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { RefreshToken = "refresh" });
        _mockedExactProvider.Setup(ep => ep.RefreshTokenAsync("refresh"))
            .ReturnsAsync(new TokenResponse { AccessToken = "new-token" });

        var actual = await _sut.RefreshTokenAsync();

        Assert.Equal("new-token", actual);

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedExactProvider.Verify(ep => ep.RefreshTokenAsync("refresh"), Times.Once);
        _mockedOAuthProviderTokenService.Verify(oapts => oapts.AddOrUpdateAsync(It.IsAny<TokenResponse>()));
    }

    [Fact]
    public async Task TestThatAddInvoiceAsyncThrowsMissingExactConfigurationExceptionOnMissingExactConfiguration()
    {
        await Assert.ThrowsAsync<MissingExactConfigurationException>(async () => await _sut.AddInvoiceAsync(2942));

        _mockedExactConfigurationDao.Verify(ecd => ecd.GetAsync(), Times.Once);
        _mockedExactConfigurationDao.VerifyNoOtherCalls();
        _mockedExactDao.VerifyNoOtherCalls();
        _mockedInvoiceDao.VerifyNoOtherCalls();
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedItemMappingDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddInvoiceAsyncThrowsInvoiceNotFoundExceptionOnInvalidInvoiceId()
    {
        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync()).ReturnsAsync(new ExactConfiguration());

        await Assert.ThrowsAsync<InvoiceNotFoundException>(async () => await _sut.AddInvoiceAsync(InvoiceId));

        _mockedExactConfigurationDao.Verify(ecd => ecd.GetAsync(), Times.Once);
        _mockedInvoiceDao.Verify(id => id.ByIdAsync(InvoiceId), Times.Once);
        _mockedExactConfigurationDao.VerifyNoOtherCalls();
        _mockedExactDao.VerifyNoOtherCalls();
        _mockedInvoiceDao.VerifyNoOtherCalls();
        _mockedStorageService.VerifyNoOtherCalls();
        _mockedItemMappingDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddInvoiceAsyncCreatesExactUserIfUserHasNoExactAccountId()
    {
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact)).ReturnsAsync(new OAuthProviderToken { Token = "unit-token", ValidUntil = DateTime.UtcNow.AddDays(1) });
        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync()).ReturnsAsync(new ExactConfiguration { Division = 1, Journal = "100" });
        _mockedExactDao.Setup(ed => ed.ExactAccountIdByInvoiceId(InvoiceId)).ReturnsAsync(value: null);
        _mockedExactProvider.Setup(ep => ep.AccountsAsync(1, "UnitTester")).ReturnsAsync(Array.Empty<AccountResponse>());
        _mockedExactProvider.Setup(ep => ep.CreateUserAsync(1, It.IsAny<CreateUserRequest>())).ReturnsAsync(Guid.NewGuid());
        _mockedInvoiceDao.Setup(id => id.ByIdAsync(InvoiceId)).ReturnsAsync(new FanceeData.Models.Ticketing.Invoicing.Invoice
            {
                Id = InvoiceId,
                Organization = new()
                {
                    Name = "UnitTester",
                    User = new()
                    {
                        Email = "unit@mail.com",
                        UserContactInfo = new()
                    },
                    PaymentSettings = new() { VatCode = "VAT01" },
                    ChamberOfCommerceIdentifier = "NL01"
                }
            }
        );

        await _sut.AddInvoiceAsync(InvoiceId);

        _mockedExactConfigurationDao.Verify(ecd => ecd.GetAsync(), Times.Once);
        _mockedInvoiceDao.Verify(id => id.ByIdAsync(InvoiceId), Times.Once);
        _mockedExactDao.Verify(ed => ed.ExactAccountIdByInvoiceId(InvoiceId), Times.Once);
        _mockedExactDao.Verify(ed => ed.InsertAsync(It.IsAny<ExactUser>()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken(It.IsAny<string>()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.AccountsAsync(1, "UnitTester"), Times.Once);
        _mockedExactProvider.Verify(ep => ep.CreateUserAsync(1, It.IsAny<CreateUserRequest>()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.CreateSalesInvoiceAsync(1, It.IsAny<CreateSalesInvoiceRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAddInvoiceAsyncCreatesInvoice()
    {
        var exactAccountId = Guid.NewGuid();
        var documentId = Guid.NewGuid();
        var exactItemGuid = Guid.NewGuid();

        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync())
            .ReturnsAsync(new ExactConfiguration { Division = Division, Journal = Journal });
        _mockedInvoiceDao.Setup(id => id.ByIdAsync(InvoiceId))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Invoicing.Invoice
            {
                Id = InvoiceId,
                CurrencyShortCode = "EUR",
                CreatedAt = DateTime.UtcNow,
                Organization = new() { CountryCode = CountryCode.NL.ToString() },
                File = new() { Name = "unit.test" },
                Rows = new List<InvoiceRow> { new() { InvoiceRowSpecificationName = "Ticket fee", UnitPriceCents = 1234, Amount = 2 } }
            });
        _mockedExactDao.Setup(ed => ed.ExactAccountIdByInvoiceId(InvoiceId))
            .ReturnsAsync(exactAccountId);
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Token = "unit-test-token", ValidUntil = DateTime.Now.AddDays(1) });
        _mockedExactProvider.Setup(ep => ep.UploadDocumentAsync(Division, "Invoice", DocumentType.SalesEntry, "invoice.pdf", It.IsAny<string>(), exactAccountId))
            .ReturnsAsync(documentId);
        _mockedItemMappingDao.Setup(imd => imd.ItemMappingsAsync(new[] { "Ticket fee" }, CountryCode.NL.ToString()))
            .ReturnsAsync(new Dictionary<string, Guid> { { "Ticket fee", exactItemGuid } });
        _mockedCurrencyService.Setup(cs => cs.CentsToDecimalAsync(It.IsAny<string>(), It.IsAny<long>()))
            .ReturnsAsync((string _, long value) => (int)Math.Round((decimal)value / 100));
        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("invoices", "unit.test.pdf"))
            .ReturnsAsync(new MemoryStream(Encoding.UTF8.GetBytes("PDF")));

        await _sut.AddInvoiceAsync(InvoiceId);

        _mockedExactConfigurationDao.Verify(ecd => ecd.GetAsync(), Times.Once);
        _mockedInvoiceDao.Verify(id => id.ByIdAsync(InvoiceId), Times.Once);
        _mockedExactDao.Verify(ed => ed.ExactAccountIdByInvoiceId(InvoiceId));
        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedStorageService.Verify(ss => ss.DownloadFileAsync("invoices", "unit.test.pdf"), Times.Once);
        _mockedCurrencyService.Verify(cs => cs.CentsToDecimalAsync(It.IsAny<string>(), It.IsAny<long>()), Times.Exactly(3));
        _mockedItemMappingDao.Verify(imd => imd.ItemMappingsAsync(new[] { "Ticket fee" }, CountryCode.NL.ToString()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken("unit-test-token"), Times.Once);
        _mockedExactProvider.Verify(ep => ep.UploadDocumentAsync(Division, "Invoice", DocumentType.SalesEntry, "invoice.pdf", It.IsAny<string>(), exactAccountId), Times.Once);
        _mockedExactProvider.Verify(ep => ep.CreateSalesInvoiceAsync(Division, It.IsAny<CreateSalesInvoiceRequest>()), Times.Once);
    }

    [Fact]
    public async Task TestThatAddInvoiceAsyncSkipsFileUploadIfNoFileIsAvailable()
    {
        var exactAccountId = Guid.NewGuid();
        var documentId = Guid.NewGuid();
        var exactItemGuid = Guid.NewGuid();

        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync())
            .ReturnsAsync(new ExactConfiguration { Division = Division, Journal = Journal });
        _mockedInvoiceDao.Setup(id => id.ByIdAsync(InvoiceId))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Invoicing.Invoice
            {
                Id = InvoiceId,
                CurrencyShortCode = "EUR",
                CreatedAt = DateTime.UtcNow,
                Organization = new() { CountryCode = CountryCode.NL.ToString() },
                Rows = new List<InvoiceRow> { new() { InvoiceRowSpecificationName = "Ticket fee", UnitPriceCents = 1234, Amount = 2 } }
            });
        _mockedExactDao.Setup(ed => ed.ExactAccountIdByInvoiceId(InvoiceId))
            .ReturnsAsync(exactAccountId);
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Token = "unit-test-token", ValidUntil = DateTime.Now.AddDays(1) });
        _mockedExactProvider.Setup(ep => ep.UploadDocumentAsync(Division, "Invoice", DocumentType.SalesEntry, "invoice.pdf", It.IsAny<string>(), exactAccountId))
            .ReturnsAsync(documentId);
        _mockedItemMappingDao.Setup(imd => imd.ItemMappingsAsync(new[] { "Ticket fee" }, CountryCode.NL.ToString()))
            .ReturnsAsync(new Dictionary<string, Guid> { { "Ticket fee", exactItemGuid } });
        _mockedCurrencyService.Setup(cs => cs.CentsToDecimalAsync(It.IsAny<string>(), It.IsAny<long>()))
            .ReturnsAsync((string _, long value) => (int)Math.Round((decimal)value / 100));
        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("invoices", "unit.test.pdf"))
            .ReturnsAsync(new MemoryStream(Encoding.UTF8.GetBytes("PDF")));

        await _sut.AddInvoiceAsync(InvoiceId);

        _mockedExactProvider.Verify(ep => ep.SetToken("unit-test-token"), Times.Once);
        _mockedExactProvider.Verify(ep => ep.CreateSalesInvoiceAsync(Division, It.IsAny<CreateSalesInvoiceRequest>()), Times.Once);
        _mockedExactProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatAddInvoiceAsyncAddsDiscount()
    {
        var exactAccountId = Guid.NewGuid();
        var documentId = Guid.NewGuid();
        var exactItemGuid = Guid.NewGuid();

        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync())
            .ReturnsAsync(new ExactConfiguration { Division = Division, Journal = Journal });
        _mockedInvoiceDao.Setup(id => id.ByIdAsync(InvoiceId))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Invoicing.Invoice
            {
                Id = InvoiceId,
                CurrencyShortCode = "EUR",
                CreatedAt = DateTime.UtcNow,
                Organization = new() { CountryCode = CountryCode.NL.ToString() },
                Rows = new List<InvoiceRow>
                {
                    new() { InvoiceRowSpecificationName = "Ticket fee", UnitPriceCents = 1234, Amount = 2 },
                    new() { InvoiceRowSpecificationName = "Discount", UnitPriceCents = 2000, VatPercentage = 0, Amount = 1 }
                }
            });
        _mockedExactDao.Setup(ed => ed.ExactAccountIdByInvoiceId(InvoiceId))
            .ReturnsAsync(exactAccountId);
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Token = "unit-test-token", ValidUntil = DateTime.Now.AddDays(1) });
        _mockedExactProvider.Setup(ep => ep.UploadDocumentAsync(Division, "Invoice", DocumentType.SalesEntry, "invoice.pdf", It.IsAny<string>(), exactAccountId))
            .ReturnsAsync(documentId);
        _mockedItemMappingDao.Setup(imd => imd.ItemMappingsAsync(new[] { "Ticket fee" }, CountryCode.NL.ToString()))
            .ReturnsAsync(new Dictionary<string, Guid> { { "Ticket fee", exactItemGuid } });
        _mockedCurrencyService.Setup(cs => cs.CentsToDecimalAsync(It.IsAny<string>(), It.IsAny<long>()))
            .ReturnsAsync((string _, long value) => (int)Math.Round((decimal)value / 100));
        _mockedStorageService.Setup(ss => ss.DownloadFileAsync("invoices", "unit.test.pdf"))
            .ReturnsAsync(new MemoryStream(Encoding.UTF8.GetBytes("PDF")));

        await _sut.AddInvoiceAsync(InvoiceId);

        _mockedExactProvider.Verify(ep => ep.CreateSalesInvoiceAsync(
            Division,
            It.Is<CreateSalesInvoiceRequest>(csir => csir.AmountDiscount == 20 && csir.AmountDiscountExclVat == 20)
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatTokenAsyncRefreshesToken()
    {
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { RefreshToken = "refresh", ValidUntil = DateTime.UtcNow.AddHours(-5) });
        _mockedExactProvider.Setup(ep => ep.RefreshTokenAsync("refresh"))
            .ReturnsAsync(new TokenResponse { AccessToken = "new-token" });
        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync())
            .ReturnsAsync(new ExactConfiguration { Division = 2, Journal = "394" });
        _mockedInvoiceDao.Setup(id => id.ByIdAsync(InvoiceId))
            .ReturnsAsync(new FanceeData.Models.Ticketing.Invoicing.Invoice { Rows = new List<InvoiceRow>(), Organization = new() { CountryCode = "NL" } });
        _mockedExactDao.Setup(ed => ed.ExactAccountIdByInvoiceId(InvoiceId))
            .ReturnsAsync(Guid.NewGuid());
        _mockedItemMappingDao.Setup(imd => imd.ItemMappingsAsync(It.IsAny<IEnumerable<string>>(), It.IsAny<string>()))
            .ReturnsAsync(new Dictionary<string, Guid>());

        await _sut.AddInvoiceAsync(InvoiceId);

        _mockedOAuthProviderTokenService.Verify(oapts => oapts.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedOAuthProviderTokenService.Verify(oapts => oapts.AddOrUpdateAsync(It.IsAny<TokenResponse>()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.RefreshTokenAsync("refresh"), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken("new-token"), Times.Once);
    }

    [Fact]
    public async Task TestThatAddInvoiceAsyncCreatesExactUserForExistingExactContact()
    {
        _mockedOAuthProviderTokenService.Setup(oapts => oapts.ForProviderAsync(OAuthProvider.Exact)).ReturnsAsync(new OAuthProviderToken { Token = "unit-token", ValidUntil = DateTime.UtcNow.AddDays(1) });
        _mockedExactConfigurationDao.Setup(ecd => ecd.GetAsync()).ReturnsAsync(new ExactConfiguration { Division = 1, Journal = "100" });
        _mockedExactDao.Setup(ed => ed.ExactAccountIdByInvoiceId(InvoiceId)).ReturnsAsync(value: null);
        _mockedExactProvider.Setup(ep => ep.AccountsAsync(1, "UnitTester")).ReturnsAsync(new AccountResponse[] { new() { Id = Guid.NewGuid(), Name = "UnitTester" } });
        _mockedExactProvider.Setup(ep => ep.CreateUserAsync(1, It.IsAny<CreateUserRequest>())).ReturnsAsync(Guid.NewGuid());
        _mockedInvoiceDao.Setup(id => id.ByIdAsync(InvoiceId)).ReturnsAsync(new FanceeData.Models.Ticketing.Invoicing.Invoice
            {
                Id = InvoiceId,
                Organization = new()
                {
                    Name = "UnitTester",
                    User = new()
                    {
                        Email = "unit@mail.com",
                        UserContactInfo = new()
                    },
                    PaymentSettings = new() { VatCode = "VAT01" },
                    ChamberOfCommerceIdentifier = "NL01"
                }
            }
        );

        await _sut.AddInvoiceAsync(InvoiceId);

        _mockedExactConfigurationDao.Verify(ecd => ecd.GetAsync(), Times.Once);
        _mockedInvoiceDao.Verify(id => id.ByIdAsync(InvoiceId), Times.Once);
        _mockedExactDao.Verify(ed => ed.ExactAccountIdByInvoiceId(InvoiceId), Times.Once);
        _mockedExactDao.Verify(ed => ed.InsertAsync(It.IsAny<ExactUser>()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.SetToken(It.IsAny<string>()), Times.Once);
        _mockedExactProvider.Verify(ep => ep.AccountsAsync(1, "UnitTester"), Times.Once);
        _mockedExactProvider.Verify(ep => ep.CreateUserAsync(It.IsAny<int>(), It.IsAny<CreateUserRequest>()), Times.Never);
        _mockedExactProvider.Verify(ep => ep.CreateSalesInvoiceAsync(1, It.IsAny<CreateSalesInvoiceRequest>()), Times.Once);
    }
}