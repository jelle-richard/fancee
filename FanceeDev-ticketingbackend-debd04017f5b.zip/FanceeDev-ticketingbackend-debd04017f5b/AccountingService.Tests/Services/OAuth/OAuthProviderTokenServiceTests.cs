using AccountingService.Persistence.OAuth;
using AccountingService.Services.OAuth;
using AccountingService.Services.OAuth.Exceptions;
using FanceeData.Models.Ticketing;

namespace AccountingService.Tests.Services.OAuth;

public class OAuthProviderTokenServiceTests
{
    private readonly OAuthProviderTokenService _sut;
    private readonly Mock<IOAuthProviderTokenDao> _mockedOAuthProviderTokenDao = new();

    public OAuthProviderTokenServiceTests()
    {
        _sut = new(_mockedOAuthProviderTokenDao.Object);
    }

    [Fact]
    public async Task TestThatForProviderAsyncThrowsOAuthProviderTokenNotFoundExceptionOnMissingProvider()
    {
        await Assert.ThrowsAsync<OAuthProviderTokenNotFoundException>(async () => await _sut.ForProviderAsync(OAuthProvider.Exact));

        _mockedOAuthProviderTokenDao.Verify(oaptd => oaptd.ForProviderAsync(OAuthProvider.Exact), Times.Once);
    }

    [Fact]
    public async Task TestThatForProviderAsyncCallsOAuthProviderTokenDaoForProviderAsync()
    {
        _mockedOAuthProviderTokenDao.Setup(oaptd => oaptd.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken { Provider = OAuthProvider.Exact, Token = "token", RefreshToken = "refresh", ValidUntil = DateTime.UtcNow });

        var actual = await _sut.ForProviderAsync(OAuthProvider.Exact);

        Assert.NotNull(actual);
        Assert.Equal("token", actual.Token);

        _mockedOAuthProviderTokenDao.Verify(oaptd => oaptd.ForProviderAsync(OAuthProvider.Exact), Times.Once);
    }

    [Fact]
    public async Task TestThatExistsAsyncCallsOAuthProviderTokenDaoExistsAsync()
    {
        _mockedOAuthProviderTokenDao.Setup(oaptd => oaptd.ExistsAsync(OAuthProvider.Exact, 30))
            .ReturnsAsync(true);

        var actual = await _sut.ExistsAsync(OAuthProvider.Exact, 30);

        Assert.True(actual);

        _mockedOAuthProviderTokenDao.Verify(oaptd => oaptd.ExistsAsync(OAuthProvider.Exact, 30), Times.Once);
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncCallsOAuthProviderTokenDaoAddAsyncIfNoProviderTokenExists()
    {
        _mockedOAuthProviderTokenDao.Setup(oaptd => oaptd.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(value: null);

        await _sut.AddOrUpdateAsync(new()
        {
            AccessToken = "access",
            ExpiresIn = 1000,
            RefreshToken = "refresh",
            TokenType = "bearer"
        });

        _mockedOAuthProviderTokenDao.Verify(oaptd => oaptd.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedOAuthProviderTokenDao.Verify(oaptd => oaptd.AddAsync(
            It.Is<OAuthProviderToken>(oact => oact.Token == "access")
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatAddOrUpdateAsyncCallsOAuthProviderTokenDaoUpdateAsyncIfProviderAlreadyExists()
    {
        _mockedOAuthProviderTokenDao.Setup(oaptd => oaptd.ForProviderAsync(OAuthProvider.Exact))
            .ReturnsAsync(new OAuthProviderToken
            {
                Token = "old-token"
            });

        await _sut.AddOrUpdateAsync(new()
        {
            AccessToken = "access",
            ExpiresIn = 1000,
            RefreshToken = "refresh",
            TokenType = "bearer"
        });

        _mockedOAuthProviderTokenDao.Verify(oaptd => oaptd.ForProviderAsync(OAuthProvider.Exact), Times.Once);
        _mockedOAuthProviderTokenDao.Verify(oaptd => oaptd.UpdateAsync(
            It.Is<OAuthProviderToken>(oact => oact.Token == "access")
        ), Times.Once);
    }
}