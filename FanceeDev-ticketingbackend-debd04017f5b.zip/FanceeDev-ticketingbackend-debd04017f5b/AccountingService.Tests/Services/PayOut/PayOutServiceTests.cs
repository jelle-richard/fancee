using System.IO.Compression;
using AccountingService.Dtos.Shared.PayOut;
using AccountingService.Persistence.PayOut;
using AccountingService.Services.PayOut;
using AccountingService.Services.PayOut.Exceptions;
using AccountingUtils.Providers.Bank;
using AccountingUtils.Providers.Bank.Models;
using FanceeData.Models.Ticketing.Invoicing;
using TestCore.Mocks;
using WebApiCore.Dtos.Shared;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using ZipUtils.Dtos;
using ZipUtils.Providers.Zip;
using File = FanceeData.Models.Ticketing.File;

namespace AccountingService.Tests.Services.PayOut;

public class PayOutServiceTests
{
    private readonly PayOutService _sut;
    private readonly Mock<IPayOutDao> _mockedPayOutDao = new();
    private readonly Mock<IBankExportProvider> _mockedBankExportProvider = new();
    private readonly Mock<IZipProvider> _mockedZipProvider = new();
    private readonly Mock<IUploadService> _mockedUploadService = new();
    private readonly Mock<IStorageService> _mockedStorageService = new();
    private readonly Mock<ICurrencyService> _mockedCurrencyService = new();

    public PayOutServiceTests()
    {
        var config = ConfigurationMockUtils.Create(new()
        {
            { "OrganizationDetails:Name", "UnitTest B.V." },
            { "OrganizationDetails:ChamberOfCommerceIdentifier", "83493845" },
            { "OrganizationDetails:Iban", "NL92TEST483399991243" },
            { "OrganizationDetails:VatCode", "3582935" },
            { "OrganizationDetails:PlatformBaseCurrency", "EUR" },
            { "OrganizationDetails:Address:Street", "Hamburgerstraße" },
            { "OrganizationDetails:Address:HouseNumber", "843-855" },
            { "OrganizationDetails:Address:PostalCode", "4921DB" },
            { "OrganizationDetails:Address:City", "München" },
            { "OrganizationDetails:Address:CountryCode", "DE" },
            { "OrganizationDetails:PlatformName", "UnitTest (test)" },
            { "OrganizationDetails:PlatformLogoUrl", "http://unit.test/logo.png" }
        });

        _sut = new(
            _mockedPayOutDao.Object,
            _mockedBankExportProvider.Object,
            _mockedZipProvider.Object,
            config,
            _mockedUploadService.Object,
            _mockedStorageService.Object,
            _mockedCurrencyService.Object
        );
    }

    [Fact]
    public async Task TestThatDownloadFileAsyncThrowsPayOutExportNotFoundExceptionOnInvalidExportId()
    {
        _mockedPayOutDao.Setup(pod => pod.FileAsync(Guid.Empty)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<PayOutExportNotFoundException>(async () => await _sut.DownloadFileAsync(Guid.Empty));

        _mockedPayOutDao.Verify(pod => pod.FileAsync(Guid.Empty), Times.Once);
        _mockedStorageService.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatDownloadFileAsyncThrowsPayOutExportNotFoundExceptionWhenFileIsNotAvailableInStorage()
    {
        var exportId = Guid.NewGuid();

        _mockedPayOutDao.Setup(pod => pod.FileAsync(exportId)).ReturnsAsync(new File { Name = "test" });
        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.PayOutStoragePool, "test.zip")).ThrowsAsync(new());

        await Assert.ThrowsAsync<PayOutExportNotFoundException>(async () => await _sut.DownloadFileAsync(exportId));

        _mockedPayOutDao.Verify(pod => pod.FileAsync(exportId), Times.Once);
        _mockedStorageService.Verify(ss => ss.DownloadFileAsync(IStorageService.PayOutStoragePool, "test.zip"), Times.Once);
    }

    [Fact]
    public async Task TestThatDownloadFileAsyncReturnsStreamOfFile()
    {
        var exportId = Guid.NewGuid();
        var stream = new MemoryStream("file"u8.ToArray());

        _mockedPayOutDao.Setup(pod => pod.FileAsync(exportId)).ReturnsAsync(new File { Name = "test" });
        _mockedStorageService.Setup(ss => ss.DownloadFileAsync(IStorageService.PayOutStoragePool, "test.zip")).ReturnsAsync(stream);

        var actual = await _sut.DownloadFileAsync(exportId);

        Assert.NotNull(actual);
        Assert.Equal(stream, actual);

        _mockedPayOutDao.Verify(pod => pod.FileAsync(exportId), Times.Once);
        _mockedStorageService.Verify(ss => ss.DownloadFileAsync(IStorageService.PayOutStoragePool, "test.zip"), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateExportAsyncDoesNothingIfNoWalletPaymentsAreAvailable()
    {
        _mockedPayOutDao.Setup(pod => pod.UnprocessedWalletPaymentsAsync()).ReturnsAsync(Enumerable.Empty<WalletPayment>());

        var actual = await _sut.CreateExportAsync();

        Assert.NotNull(actual);
        Assert.Equal(Guid.Empty, actual.Id);

        _mockedPayOutDao.Verify(pod => pod.UnprocessedWalletPaymentsAsync(), Times.Once);
        _mockedPayOutDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatCreateExportAsyncCreatesExport()
    {
        var wp = new WalletPayment
        {
            Id = Guid.Empty,
            CurrencyShortCode = "EUR",
            RequestedAt = DateTime.UtcNow,
            AmountCents = 4949,
            Organization = new()
            {
                Name = "Test Inc",
                PaymentSettings = new()
                {
                    Iban = "NL01TEST1234567890"
                }
            }
        };

        _mockedPayOutDao.Setup(pod => pod.UnprocessedWalletPaymentsAsync()).ReturnsAsync(new[] { wp });
        _mockedBankExportProvider.Setup(bep => bep.CreatePayoutExport(It.IsAny<PayoutExportInfo>())).Returns(new List<byte[]>
        {
            new byte[] { 1, 2, 3 }
        });
        _mockedZipProvider.Setup(zp => zp.AddFiles(It.IsAny<IEnumerable<ZipEntry>>())).Returns(_mockedZipProvider.Object);
        _mockedZipProvider.Setup(zp => zp.SetCompressionLevel(CompressionLevel.Fastest)).Returns(_mockedZipProvider.Object);
        _mockedZipProvider.Setup(zp => zp.CompressAsync()).ReturnsAsync(new byte[] { 3, 9, 3 });
        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "payouts",
                null,
                "zip",
                "application/zip",
                false,
                It.IsAny<Func<File, Task>>())
            )
            .Callback((Stream _, string _, string? _, string _, string _, bool _, Func<File, Task> callback) =>
                callback(new())
            );

        var actual = await _sut.CreateExportAsync();

        Assert.NotNull(actual);
        Assert.Equal(Guid.Empty, actual.Id);

        _mockedPayOutDao.Verify(pod => pod.UnprocessedWalletPaymentsAsync(), Times.Once);
        _mockedBankExportProvider.Verify(bep => bep.CreatePayoutExport(It.IsAny<PayoutExportInfo>()), Times.Once);
        _mockedZipProvider.Verify(zp => zp.AddFiles(It.IsAny<IEnumerable<ZipEntry>>()), Times.Once);
        _mockedZipProvider.Verify(zp => zp.SetCompressionLevel(CompressionLevel.Fastest), Times.Once);
        _mockedZipProvider.Verify(zp => zp.CompressAsync(), Times.Once);
        _mockedUploadService.Verify(us => us.UploadAsync(
            It.IsAny<Stream>(),
            "payouts",
            null,
            "zip",
            "application/zip",
            false,
            It.IsAny<Func<File, Task>>()
        ), Times.Once);
        _mockedPayOutDao.Verify(pod => pod.InsertAsync(It.IsAny<PayOutExport>()), Times.Once);
        _mockedPayOutDao.Verify(pod => pod.UpdateWalletPaymentsAsync(It.IsAny<IEnumerable<WalletPayment>>()), Times.Once);
    }

    [Fact]
    public async Task TestThatCreateExportAsyncConvertsCurrency()
    {
        var wp = new WalletPayment
        {
            Id = Guid.Empty,
            CurrencyShortCode = "USD",
            RequestedAt = DateTime.UtcNow,
            AmountCents = 4949,
            Organization = new()
            {
                Name = "Test Inc",
                PaymentSettings = new()
                {
                    Iban = "NL01TEST1234567890"
                }
            }
        };

        _mockedPayOutDao.Setup(pod => pod.UnprocessedWalletPaymentsAsync()).ReturnsAsync(new[] { wp });
        _mockedBankExportProvider.Setup(bep => bep.CreatePayoutExport(It.IsAny<PayoutExportInfo>())).Returns(new List<byte[]>
        {
            new byte[] { 1, 2, 3 }
        });
        _mockedZipProvider.Setup(zp => zp.AddFiles(It.IsAny<IEnumerable<ZipEntry>>())).Returns(_mockedZipProvider.Object);
        _mockedZipProvider.Setup(zp => zp.SetCompressionLevel(CompressionLevel.Fastest)).Returns(_mockedZipProvider.Object);
        _mockedZipProvider.Setup(zp => zp.CompressAsync()).ReturnsAsync(new byte[] { 3, 9, 3 });
        _mockedUploadService.Setup(us => us.UploadAsync(
                It.IsAny<Stream>(),
                "payouts",
                null,
                "zip",
                "application/zip",
                false,
                It.IsAny<Func<File, Task>>())
            )
            .Callback((Stream _, string _, string? _, string _, string _, bool _, Func<File, Task> callback) =>
                callback(new())
            );
        _mockedCurrencyService.Setup(cs => cs.ConvertAsync("EUR", 4949)).ReturnsAsync(3000);

        var actual = await _sut.CreateExportAsync();

        Assert.NotNull(actual);

        _mockedCurrencyService.Verify(cs => cs.ConvertAsync("EUR", 4949), Times.Once);
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncThrowsPayOutExportNotFoundExceptionOnInvalidExportId()
    {
        _mockedPayOutDao.Setup(pod => pod.ByIdAsync(Guid.Empty)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<PayOutExportNotFoundException>(async () => await _sut.ChangeStatusAsync(Guid.Empty, PayOutExportStatus.Processed));

        _mockedPayOutDao.Verify(pod => pod.ByIdAsync(Guid.Empty), Times.Once);
        _mockedPayOutDao.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatChangeStatusAsyncCallsPayOutDaoUpdateAsync()
    {
        var exportId = Guid.NewGuid();

        _mockedPayOutDao.Setup(pod => pod.ByIdAsync(exportId)).ReturnsAsync(new PayOutExport());

        await _sut.ChangeStatusAsync(exportId, PayOutExportStatus.Processed);

        _mockedPayOutDao.Verify(pod => pod.ByIdAsync(exportId), Times.Once);
        _mockedPayOutDao.Verify(pod => pod.UpdateAsync(It.Is<PayOutExport>(poe => poe.Status == PayOutExportStatus.Processed)), Times.Once);
    }

    [Fact]
    public async Task TestThatListAsyncCallsPayOutDaoListAsync()
    {
        _mockedPayOutDao.Setup(pod => pod.ListAsync(2, 0, null, PayOutExportStatus.Created)).ReturnsAsync(new PaginatedResultSet<PayOutExport>
        {
            TotalItems = 50,
            Items = new PayOutExport[]
            {
                new() { Id = Guid.Empty, CreatedAt = DateTime.UtcNow, Status = PayOutExportStatus.Created },
                new() { Id = Guid.NewGuid(), CreatedAt = DateTime.UtcNow.AddHours(-5), Status = PayOutExportStatus.Created }
            }
        });

        var actual = await _sut.ListAsync(new()
        {
            Page = 1,
            PageSize = 2,
            Options = new() { Status = ExportStatus.Created }
        });

        Assert.NotNull(actual);
        Assert.Equal(50, actual.TotalItems);
        Assert.Equal(2, actual.Items.Count());

        _mockedPayOutDao.Verify(pod => pod.ListAsync(2, 0, null, PayOutExportStatus.Created), Times.Once);
    }

    [Fact]
    public async Task TestThatPendingPayoutsAsyncCallsPayOutDaoUnprocessedWalletPaymentsAmountAsync()
    {
        _mockedPayOutDao.Setup(pd => pd.UnprocessedWalletPaymentsAmountAsync())
            .ReturnsAsync(11);

        var actual = await _sut.PendingPayoutsAsync();

        Assert.Equal(11, actual);

        _mockedPayOutDao.Verify(pd => pd.UnprocessedWalletPaymentsAmountAsync(), Times.Once);
    }
}