using AccountingService.Dtos.Requests.Exact;

namespace AccountingService.Tests.Dtos.Requests.Exact;

public class ConfigureItemsRequestTests
{
    private readonly ConfigureItemsRequest _sut = new();

    [Fact]
    public void TestThatValidateReturnsNoErrorsForValidRequest()
    {
        _sut.Items = new ConfigureItemRequest[] { new() };

        var actual = _sut.Validate(new(_sut));

        Assert.Empty(actual);
    }

    [Fact]
    public void TestThatValidateReturnsErrorOnEmptyEnumerable()
    {
        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("At least 1 item is required", actual.First().ErrorMessage);
    }
}