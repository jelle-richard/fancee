using AccountingService.Dtos.Requests.Exact;
using WebApiCore.Dtos.Shared;

namespace AccountingService.Tests.Dtos.Requests.Exact;

public class ConfigureItemRequestTests
{
    private readonly ConfigureItemRequest _sut = new();

    [Fact]
    public void TestThatValidateReturnsNoErrorsOnValidRequest()
    {
        _sut.CountryItems = new CountryItem[]
        {
            new() { CountryCode = CountryCode.NL, ExactItemCode = Guid.Empty },
            new() { CountryCode = CountryCode.DE, ExactItemCode = Guid.Empty },
            new() { CountryCode = null, ExactItemCode = Guid.Empty }
        };

        var actual = _sut.Validate(new(_sut));

        Assert.Empty(actual);
    }

    [Fact]
    public void TestThatValidateReturnsErrorOnMultipleNullValuesPerMapping()
    {
        _sut.CountryItems = new CountryItem[]
        {
            new() { CountryCode = null, ExactItemCode = Guid.Empty },
            new() { CountryCode = CountryCode.DE, ExactItemCode = Guid.Empty },
            new() { CountryCode = null, ExactItemCode = Guid.Empty }
        };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Only one 'null' country code is allowed per mapping", actual.First().ErrorMessage);
    }

    [Fact]
    public void TestThatValidateReturnsErrorOnMultipleSameValueCountriesForSingleMapping()
    {
        _sut.CountryItems = new CountryItem[]
        {
            new() { CountryCode = CountryCode.UA, ExactItemCode = Guid.Empty },
            new() { CountryCode = CountryCode.UA, ExactItemCode = Guid.NewGuid() },
            new() { CountryCode = CountryCode.AT, ExactItemCode = Guid.NewGuid() }
        };

        var actual = _sut.Validate(new(_sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Cannot insert duplicate country mapping", actual.First().ErrorMessage);
    }
}