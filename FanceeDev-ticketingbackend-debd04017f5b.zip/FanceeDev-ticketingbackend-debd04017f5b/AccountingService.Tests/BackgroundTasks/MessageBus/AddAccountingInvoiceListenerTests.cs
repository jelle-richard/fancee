using AccountingService.BackgroundTasks.MessageBus;
using AccountingService.Services.Exact;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Invoices;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace AccountingService.Tests.BackgroundTasks.MessageBus;

public class AddAccountingInvoiceListenerTests
{
    private readonly AddAccountingInvoiceListener _sut;
    private readonly Mock<AddAccountingInvoiceSubscriber> _mockedSubscriber;
    private readonly Mock<ILogger<AddAccountingInvoiceListener>> _mockedLogger = new();
    private readonly Mock<IExactService> _mockedExactService = new();

    public AddAccountingInvoiceListenerTests()
    {
        var mockedConnection = new Mock<IConnection>();
        var mockedServiceProvider = new Mock<IServiceProvider>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        _mockedSubscriber = new(mockedConnection.Object);

        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<AddAccountingInvoiceMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IExactService))).Returns(_mockedExactService.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<AddAccountingInvoiceListener>))).Returns(_mockedLogger.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsToSubscriber()
    {
        await _sut.StartAsync(default);
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageCallsExactServiceAddInvoiceAsync()
    {
        var model = new AddAccountingInvoiceMessage { InvoiceId = 123 };

        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback!.Invoke(model);

        Assert.NotNull(actual);

        await actual;

        _mockedExactService.Verify(es => es.AddInvoiceAsync(123), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Information, "[AddAccountingInvoiceListener] Started");
        _mockedLogger.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageLogsOnException()
    {
        var model = new AddAccountingInvoiceMessage { InvoiceId = -1 };

        _mockedExactService.Setup(es => es.AddInvoiceAsync(-1)).ThrowsAsync(new());

        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback!.Invoke(model);

        Assert.NotNull(actual);

        await actual;

        _mockedExactService.Verify(es => es.AddInvoiceAsync(-1), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Error, "[AddAccountingInvoiceListener] Unable to create the invoice in the external invoice system");
    }
}