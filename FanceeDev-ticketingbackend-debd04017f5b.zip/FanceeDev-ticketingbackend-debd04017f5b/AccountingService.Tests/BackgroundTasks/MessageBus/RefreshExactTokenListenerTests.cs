using AccountingService.BackgroundTasks.MessageBus;
using AccountingService.Services.Exact;
using Fs.MessageBus.Subscribers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Token;
using WebApiCore.MessageBus.Subscribers.Rabbit;

namespace AccountingService.Tests.BackgroundTasks.MessageBus;

public class RefreshExactTokenListenerTests
{
    private readonly RefreshExactTokenListener _sut;
    private readonly Mock<RefreshExactTokenSubscriber> _mockedSubscriber;
    private readonly Mock<ILogger<RefreshExactTokenListener>> _mockedLogger = new();
    private readonly Mock<IExactService> _mockedExactService = new();

    public RefreshExactTokenListenerTests()
    {
        var mockedConnection = new Mock<IConnection>();
        var mockedServiceProvider = new Mock<IServiceProvider>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        _mockedSubscriber = new(mockedConnection.Object);

        mockedConnection.Setup(c => c.CreateModel()).Returns(new Mock<IModel>().Object);
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessageSubscriber<RefreshExactTokenMessage>))).Returns(_mockedSubscriber.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IExactService))).Returns(_mockedExactService.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<RefreshExactTokenListener>))).Returns(_mockedLogger.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public async Task TestThatStartAsyncBindsToSubscriber()
    {
        await _sut.StartAsync(default);

        Assert.NotNull(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatStopAsyncUnbindsToSubscriber()
    {
        await _sut.StartAsync(default);
        await _sut.StopAsync(default);

        Assert.Null(_mockedSubscriber.Object.Callback);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageAsyncCallsExactServiceRefreshTokenAsync()
    {
        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback!.Invoke(new());

        Assert.NotNull(actual);

        await actual;

        _mockedExactService.Verify(es => es.RefreshTokenAsync(), Times.Once);
    }

    [Fact]
    public async Task TestThatHandleReceivedMessageLogsOnException()
    {
        _mockedExactService.Setup(es => es.RefreshTokenAsync()).ThrowsAsync(new());

        await _sut.StartAsync(default);

        var actual = _mockedSubscriber.Object.Callback!.Invoke(new());

        Assert.NotNull(actual);

        await actual;

        _mockedExactService.Verify(es => es.RefreshTokenAsync(), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Error, "[RefreshExactTokenListener] Could not refresh Exact token");
    }
}