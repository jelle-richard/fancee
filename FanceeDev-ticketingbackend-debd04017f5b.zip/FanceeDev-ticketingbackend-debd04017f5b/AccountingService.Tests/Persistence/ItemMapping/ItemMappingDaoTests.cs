using AccountingService.Persistence.ItemMapping;
using FanceeData.Contexts;
using WebApiCore.Dtos.Shared;

namespace AccountingService.Tests.Persistence.ItemMapping;

public class ItemMappingDaoTests
{
    private static readonly Guid[] ItemMappingIds =
    [
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid(),
        Guid.NewGuid()
    ];

    private readonly ItemMappingDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly List<FanceeData.Models.Ticketing.Exact.ItemMapping> _itemMappings =
    [
        new()
        {
            Id = Guid.NewGuid(),
            InvoiceRowSpecificationName = "One",
            CountryCode = null,
            ExactItemCode = ItemMappingIds[0]
        },

        new()
        {
            Id = Guid.NewGuid(),
            InvoiceRowSpecificationName = "Two",
            CountryCode = null,
            ExactItemCode = ItemMappingIds[1]
        },

        new()
        {
            Id = Guid.NewGuid(),
            InvoiceRowSpecificationName = "Three",
            CountryCode = null,
            ExactItemCode = ItemMappingIds[2]
        },

        new()
        {
            Id = Guid.NewGuid(),
            InvoiceRowSpecificationName = "Two",
            CountryCode = CountryCode.NL.ToString(),
            ExactItemCode = ItemMappingIds[3]
        }
    ];

    public ItemMappingDaoTests()
    {
        _mockedContext.Setup(c => c.ItemMappings).ReturnsDbSet(_itemMappings);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInsertAsyncInsertsNewMappings()
    {
        var items = new FanceeData.Models.Ticketing.Exact.ItemMapping[] { new(), new() };

        await _sut.InsertAsync(items);

        _mockedContext.Verify(c => c.ItemMappings.AddRangeAsync(
                It.IsAny<FanceeData.Models.Ticketing.Exact.ItemMapping>(),
                It.IsAny<FanceeData.Models.Ticketing.Exact.ItemMapping>()),
            Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatItemMappingsAsyncReturnsItemMapping()
    {
        var actual = await _sut.ItemMappingsAsync(new[] { "One", "Two", "Three" }, CountryCode.DE.ToString());

        Assert.NotNull(actual);
        Assert.True(actual.ContainsKey("One"));
        Assert.True(actual.ContainsKey("Two"));
        Assert.True(actual.ContainsKey("Three"));
        Assert.Equal(ItemMappingIds[0], actual["One"]);
        Assert.Equal(ItemMappingIds[1], actual["Two"]);
        Assert.Equal(ItemMappingIds[2], actual["Three"]);
    }

    [Fact]
    public async Task TestThatItemMappingsAsyncReturnsItemMappingWithPriorityForCountryIfAvailable()
    {
        var actual = await _sut.ItemMappingsAsync(new[] { "Two" }, CountryCode.NL.ToString());

        Assert.NotNull(actual);
        Assert.True(actual.ContainsKey("Two"));
        Assert.Equal(ItemMappingIds[3], actual["Two"]);
    }

    [Fact]
    public async Task TestThatItemMappingsAsyncReturnsAllItemMappings()
    {
        var actual = await _sut.ItemMappingsAsync();

        Assert.Equivalent(_itemMappings, actual);
    }
}