using AccountingService.Persistence.Exact;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Exact;

namespace AccountingService.Tests.Persistence.Exact;

public class ExactConfigurationDaoTests
{
    private static readonly Guid ExactConfigurationId = Guid.NewGuid();

    private readonly ExactConfigurationDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly List<ExactConfiguration> _exactConfigurations =
    [
        new() { Id = ExactConfigurationId, Division = 2442, Journal = "Test" }
    ];

    public ExactConfigurationDaoTests()
    {
        _mockedContext.Setup(c => c.ExactConfigurations).ReturnsDbSet(_exactConfigurations);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatGetAsyncGetsConfiguration()
    {
        var actual = await _sut.GetAsync();

        Assert.NotNull(actual);
        Assert.Equal(ExactConfigurationId, actual.Id);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsNullOnMissingConfiguration()
    {
        _exactConfigurations.Clear();

        var actual = await _sut.GetAsync();

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatSetAsyncAddsNewExactConfiguration()
    {
        _exactConfigurations.Clear();

        var config = new ExactConfiguration { Id = Guid.NewGuid(), Division = 481593, Journal = "Journal" };

        await _sut.SetAsync(config);

        _mockedContext.Verify(c => c.ExactConfigurations.Remove(It.IsAny<ExactConfiguration>()), Times.Never);
        _mockedContext.Verify(c => c.ExactConfigurations.AddAsync(config, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatSetAsyncRemovesOldConfiguration()
    {
        var config = new ExactConfiguration { Id = Guid.NewGuid(), Division = 481593, Journal = "Journal" };

        await _sut.SetAsync(config);

        _mockedContext.Verify(c => c.ExactConfigurations.Remove(_exactConfigurations[0]), Times.Once);
        _mockedContext.Verify(c => c.ExactConfigurations.AddAsync(config, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}