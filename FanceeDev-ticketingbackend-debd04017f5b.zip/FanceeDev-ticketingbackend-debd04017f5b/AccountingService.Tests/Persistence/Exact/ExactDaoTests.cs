using AccountingService.Persistence.Exact;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Exact;

namespace AccountingService.Tests.Persistence.Exact;

public class ExactDaoTests
{
    private const int ValidInvoiceId = 20220101;
    private static readonly Guid ValidExactAccountId = Guid.NewGuid();

    private readonly ExactDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly List<FanceeData.Models.Ticketing.Invoicing.Invoice> _invoices =
    [
        new()
        {
            Id = ValidInvoiceId,
            Organization = new()
            {
                User = new() { ExactUser = new() { ExactAccountId = ValidExactAccountId } }
            }
        }
    ];

    public ExactDaoTests()
    {
        _mockedContext.Setup(c => c.Invoices).ReturnsDbSet(_invoices);
        _mockedContext.Setup(c => c.ExactUsers).ReturnsDbSet(new List<ExactUser>());

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatExactAccountIdByInvoiceIdReturnsNullOnInvalidInvoiceId()
    {
        var actual = await _sut.ExactAccountIdByInvoiceId(-24);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatExactAccountIdByInvoiceIdReturnsExactAccountId()
    {
        var actual = await _sut.ExactAccountIdByInvoiceId(ValidInvoiceId);

        Assert.Equal(ValidExactAccountId, actual);
    }

    [Fact]
    public async Task TestThatInsertAsyncAddsExactUser()
    {
        var exactUser = new ExactUser { ExactAccountId = Guid.NewGuid(), UserId = Guid.NewGuid() };

        await _sut.InsertAsync(exactUser);

        _mockedContext.Verify(c => c.ExactUsers.AddAsync(exactUser, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }
}