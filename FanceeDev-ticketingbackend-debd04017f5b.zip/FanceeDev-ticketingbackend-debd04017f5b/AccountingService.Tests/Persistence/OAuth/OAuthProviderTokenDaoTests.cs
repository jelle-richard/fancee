using AccountingService.Persistence.OAuth;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace AccountingService.Tests.Persistence.OAuth;

public class OAuthProviderTokenDaoTests
{
    private readonly OAuthProviderTokenDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();
    private readonly List<OAuthProviderToken> _providerTokens = new();

    public OAuthProviderTokenDaoTests()
    {
        _mockedContext.Setup(c => c.OAuthProviderTokens).ReturnsDbSet(_providerTokens);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatAddAsyncAddsNewOAuthProviderToken()
    {
        var providerToken = new OAuthProviderToken { Provider = OAuthProvider.Exact, Token = "token", RefreshToken = "refresh", ValidUntil = DateTime.UtcNow.AddDays(1) };

        await _sut.AddAsync(providerToken);

        _mockedContext.Verify(c => c.OAuthProviderTokens.AddAsync(providerToken, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesOAuthProviderToken()
    {
        var providerToken = new OAuthProviderToken { Provider = OAuthProvider.Exact, Token = "token", RefreshToken = "refresh", ValidUntil = DateTime.UtcNow.AddDays(1) };

        await _sut.UpdateAsync(providerToken);

        _mockedContext.Verify(c => c.OAuthProviderTokens.Update(providerToken), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatForProviderAsyncReturnsNullOnInvalidOAuthProvider() => Assert.Null(await _sut.ForProviderAsync(OAuthProvider.Exact));

    [Fact]
    public async Task TestThatForProviderAsyncReturnsOAuthProviderToken()
    {
        _providerTokens.Add(new() { Provider = OAuthProvider.Exact, Token = "test" });

        var actual = await _sut.ForProviderAsync(OAuthProvider.Exact);

        Assert.NotNull(actual);
        Assert.Equal("test", actual.Token);
    }

    [Fact]
    public async Task TestThatExistsAsyncReturnsFalseIfNoProviderTokenCanBeFound() =>
        Assert.False(await _sut.ExistsAsync(OAuthProvider.Exact, null));

    [Fact]
    public async Task TestThatExistsAsyncReturnsTrueForProviderToken()
    {
        _providerTokens.Add(new() { Provider = OAuthProvider.Exact, Token = "test" });

        Assert.True(await _sut.ExistsAsync(OAuthProvider.Exact, null));
    }

    [Theory]
    [InlineData(0, true)]
    [InlineData(1, true)]
    [InlineData(-5, true)]
    [InlineData(-11, false)]
    public async Task TestThatExistsAsyncReturnsExpectedResultWithRefreshExpireDays(int daysToModify, bool expected)
    {
        _providerTokens.Add(new()
        {
            Provider = OAuthProvider.Exact,
            Token = "test",
            ValidUntil = DateTime.UtcNow.AddDays(daysToModify)
        });

        var actual = await _sut.ExistsAsync(OAuthProvider.Exact, 10);

        Assert.Equal(expected, actual);
    }
}