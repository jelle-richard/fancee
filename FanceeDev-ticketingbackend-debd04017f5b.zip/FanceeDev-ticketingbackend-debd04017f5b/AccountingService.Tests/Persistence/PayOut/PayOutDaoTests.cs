using AccountingService.Persistence.PayOut;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Invoicing;

namespace AccountingService.Tests.Persistence.PayOut;

public class PayOutDaoTests
{
    private static readonly Guid ValidPayOutExportId = Guid.NewGuid();

    private readonly PayOutDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public PayOutDaoTests()
    {
        _mockedContext.Setup(c => c.PayOutExports).ReturnsDbSet(new List<PayOutExport>
        {
            new()
            {
                Id = ValidPayOutExportId,
                Status = PayOutExportStatus.Created,
                File = new() { Name = "file.zip" },
                WalletPayments = new List<WalletPayment>(),
                CreatedAt = DateTime.UtcNow.AddHours(-10)
            },
            new()
            {
                Id = Guid.NewGuid(),
                Status = PayOutExportStatus.Processed,
                File = new() { Name = "file.zip" },
                WalletPayments = new List<WalletPayment>(),
                CreatedAt = DateTime.UtcNow.AddDays(-5)
            }
        });

        _mockedContext.Setup(c => c.WalletPayments).ReturnsDbSet(new List<WalletPayment>
        {
            new()
            {
                ProcessedAt = null,
                Type = WalletPaymentType.Debit,
                Organization = new() { IsDemo = false, User = new() { Email = "expected@test.com" } },
                PayOutExports = Array.Empty<PayOutExport>()
            },
            new()
            {
                ProcessedAt = DateTime.UtcNow,
                Type = WalletPaymentType.Debit,
                Organization = new() { IsDemo = false },
                PayOutExports = Array.Empty<PayOutExport>()
            },
            new()
            {
                ProcessedAt = null,
                Type = WalletPaymentType.Credit,
                Organization = new() { IsDemo = false },
                PayOutExports = Array.Empty<PayOutExport>()
            },
            new()
            {
                ProcessedAt = null,
                Type = WalletPaymentType.Debit,
                Organization = new() { IsDemo = true },
                PayOutExports = Array.Empty<PayOutExport>()
            },
            new()
            {
                ProcessedAt = null,
                Type = WalletPaymentType.Debit,
                Organization = new() { IsDemo = false },
                PayOutExports = new List<PayOutExport>
                {
                    new()
                }
            }
        });

        _mockedContext.Setup(c => c.PayOutExports.AsQueryable()).Returns(_mockedContext.Object.PayOutExports);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInsertAsyncInsertsNewPayOutExport()
    {
        var export = new PayOutExport();

        await _sut.InsertAsync(export);

        _mockedContext.Verify(c => c.PayOutExports.AddAsync(export, default), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatUpdateWalletPaymentsAsyncUpdatesWalletPayments()
    {
        var walletPayments = new List<WalletPayment> { new() };

        await _sut.UpdateWalletPaymentsAsync(walletPayments);

        _mockedContext.Verify(c => c.WalletPayments.UpdateRange(walletPayments), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatFileAsyncReturnsNullOnInvalidExportId()
    {
        var actual = await _sut.FileAsync(Guid.Empty);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatFileAsyncReturnsFile()
    {
        var actual = await _sut.FileAsync(ValidPayOutExportId);

        Assert.NotNull(actual);
        Assert.Equal("file.zip", actual.Name);
    }

    [Fact]
    public async Task TestThatUnprocessedWalletPaymentsAsyncReturnsExpectedResults()
    {
        var actual = (await _sut.UnprocessedWalletPaymentsAsync()).ToList();

        Assert.Single(actual);
        Assert.Equal("expected@test.com", actual[0].Organization.User.Email);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsNullOnInvalidExportId()
    {
        var actual = await _sut.ByIdAsync(Guid.Empty);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsPayOutExport()
    {
        var actual = await _sut.ByIdAsync(ValidPayOutExportId);

        Assert.NotNull(actual);
        Assert.Equal(PayOutExportStatus.Created, actual.Status);
    }

    [Fact]
    public async Task TestThatUpdateAsyncUpdatesPayOutExport()
    {
        var payOutExport = new PayOutExport();

        await _sut.UpdateAsync(payOutExport);

        _mockedContext.Verify(c => c.PayOutExports.Update(payOutExport), Times.Once);
        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatListAsyncLimitsResultSet()
    {
        var actual = await _sut.ListAsync(1, 0, null, null);
        var actualItems = actual.Items.ToList();

        Assert.Equal(2, actual.TotalItems);
        Assert.Single(actualItems);
        Assert.Equal(ValidPayOutExportId, actualItems[0].Id);
    }

    [Fact]
    public async Task TestThatListAsyncOffsetsResultSet()
    {
        var actual = await _sut.ListAsync(1, 1, null, null);
        var actualItems = actual.Items.ToList();

        Assert.Equal(2, actual.TotalItems);
        Assert.Single(actualItems);
        Assert.NotEqual(ValidPayOutExportId, actualItems[0].Id);
    }

    [Fact]
    public async Task TestThatListAsyncFiltersOnIdWithSearchQuery()
    {
        var actual = await _sut.ListAsync(10, 0, ValidPayOutExportId.ToString(), null);
        var actualItems = actual.Items.ToList();

        Assert.Equal(1, actual.TotalItems);
        Assert.Single(actualItems);
        Assert.Equal(ValidPayOutExportId, actualItems[0].Id);
    }

    [Fact]
    public async Task TestThatListAsyncFiltersOnStatus()
    {
        var actual = await _sut.ListAsync(10, 0, null, PayOutExportStatus.Processed);
        var actualItems = actual.Items.ToList();

        Assert.Equal(1, actual.TotalItems);
        Assert.Single(actualItems);
        Assert.Equal(PayOutExportStatus.Processed, actualItems[0].Status);
    }

    [Fact]
    public async Task TestThatUnprocessedWalletPaymentsAmountAsyncCountsUnprocessedWalletDebitPayments()
    {
        var actual = await _sut.UnprocessedWalletPaymentsAmountAsync();

        Assert.Equal(1, actual);
    }
}