using AccountingService.Persistence.Invoice;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Invoicing;

namespace AccountingService.Tests.Persistence.Invoice;

public class InvoiceRowSpecificationDaoTests
{
    public static readonly object[][] ValidAsyncTestData =
    [
        [new[] { "One", "Two" }, true],
        [new[] { "One", "Three" }, true],
        [new[] { "One", "Two", "Three" }, true],
        [new[] { "Four" }, false],
        [new[] { "Four", "One" }, false],
        [new[] { "Two", "Four" }, false]
    ];

    private readonly InvoiceRowSpecificationDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public InvoiceRowSpecificationDaoTests()
    {
        _mockedContext.Setup(c => c.InvoiceRowSpecifications).ReturnsDbSet(new List<InvoiceRowSpecification>
        {
            new() { Name = "One" },
            new() { Name = "Two" },
            new() { Name = "Three" }
        });

        _sut = new(_mockedContext.Object);
    }

    [Theory]
    [MemberData(nameof(ValidAsyncTestData))]
    public async Task TestThatValidAsyncReturnsExpectedResult(IEnumerable<string> input, bool expected)
    {
        var actual = await _sut.ValidAsync(input);

        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task TestThatNamesAsyncReturnsAllAvailableNames()
    {
        var actual = (await _sut.NamesAsync()).ToList();

        Assert.Equal(3, actual.Count);
        Assert.Equivalent(new[] { "One", "Two", "Three" }, actual);
    }
}