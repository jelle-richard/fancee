using AccountingService.Persistence.Invoice;
using FanceeData.Contexts;

namespace AccountingService.Tests.Persistence.Invoice;

public class InvoiceDaoTests
{
    private readonly InvoiceDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    private readonly List<FanceeData.Models.Ticketing.Invoicing.Invoice> _invoices = [new() { Id = 42 }];

    public InvoiceDaoTests()
    {
        _mockedContext.Setup(c => c.Invoices).ReturnsDbSet(_invoices);

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsNullOnInvalidId()
    {
        var actual = await _sut.ByIdAsync(-1);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatByIdAsyncReturnsInvoiceById()
    {
        var actual = await _sut.ByIdAsync(42);

        Assert.NotNull(actual);
        Assert.Equal(42, actual.Id);
    }
}