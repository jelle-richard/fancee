using AccountingService.Utils.Adapter;
using AccountingUtils.Providers.Accounting.Exact.Responses;

namespace AccountingService.Tests.Utils.Adapter;

public class JournalAdapterTests
{
    [Fact]
    public void TestThatToMinimalJournalResponsesMapsJournalResponse()
    {
        var responses = new JournalResponse[]
        {
            new()
            {
                Id = Guid.Empty,
                Code = "Code",
                Description = "Description",
                Currency = "EUR"
            }
        };

        var actual = responses.ToMinimalJournalResponses().ToList();

        Assert.Single(actual);
        Assert.Equal(Guid.Empty, actual[0].Id);
        Assert.Equal("Code", actual[0].Code);
        Assert.Equal("Description", actual[0].Description);
        Assert.Equal("EUR", actual[0].Currency);
    }
}