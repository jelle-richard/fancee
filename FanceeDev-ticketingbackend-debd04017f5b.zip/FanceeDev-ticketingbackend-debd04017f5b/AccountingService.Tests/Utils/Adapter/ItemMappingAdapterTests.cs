using AccountingService.Dtos.Requests.Exact;
using AccountingService.Utils.Adapter;
using FanceeData.Models.Ticketing.Exact;
using WebApiCore.Dtos.Shared;

namespace AccountingService.Tests.Utils.Adapter;

public class ItemMappingAdapterTests
{
    [Fact]
    public void TestThatToItemMappingsMapsMultipleConfigureItemRequests()
    {
        var exactItemCode1 = Guid.NewGuid();
        var exactItemCode2 = Guid.NewGuid();

        var items = new ConfigureItemRequest[]
        {
            new()
            {
                PlatformItem = "platform-item",
                CountryItems = new CountryItem[]
                {
                    new() { CountryCode = CountryCode.AD, ExactItemCode = exactItemCode1 }
                }
            },
            new()
            {
                PlatformItem = "second-item",
                CountryItems = new CountryItem[]
                {
                    new() { CountryCode = null, ExactItemCode = exactItemCode1 },
                    new() { CountryCode = CountryCode.BE, ExactItemCode = exactItemCode2 }
                }
            }
        };

        var actual = items.ToItemMappings().ToList();

        Assert.Equal(3, actual.Count);
        Assert.Equal("platform-item", actual[0].InvoiceRowSpecificationName);
        Assert.Equal("AD", actual[0].CountryCode);
        Assert.Equal(exactItemCode1, actual[0].ExactItemCode);

        Assert.Equal("second-item", actual[1].InvoiceRowSpecificationName);
        Assert.Null(actual[1].CountryCode);
        Assert.Equal(exactItemCode1, actual[1].ExactItemCode);

        Assert.Equal("second-item", actual[2].InvoiceRowSpecificationName);
        Assert.Equal("BE", actual[2].CountryCode);
        Assert.Equal(exactItemCode2, actual[2].ExactItemCode);
    }

    [Fact]
    public void TestThatToConfiguredItemResponsesMapsItemMappings()
    {
        var exactItemCodes = new[]
        {
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid()
        };

        var mappings = new ItemMapping[]
        {
            new()
            {
                InvoiceRowSpecificationName = "Additional cost",
                CountryCode = "NL",
                ExactItemCode = exactItemCodes[0]
            },
            new()
            {
                InvoiceRowSpecificationName = "SMS",
                CountryCode = null,
                ExactItemCode = exactItemCodes[1]
            },
            new()
            {
                InvoiceRowSpecificationName = "Additional cost",
                CountryCode = "DE",
                ExactItemCode = exactItemCodes[2]
            }
        };

        var actual = mappings.ToConfiguredItemResponses().ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal("Additional cost", actual[0].PlatformItem);
        Assert.Equal("SMS", actual[1].PlatformItem);

        var countryItems = actual[0].CountryItems.ToList();
        Assert.Equal(2, countryItems.Count);
        Assert.Equal(CountryCode.NL, countryItems[0].CountryCode);
        Assert.Equal(exactItemCodes[0], countryItems[0].ExactItemCode);
        Assert.Equal(CountryCode.DE, countryItems[1].CountryCode);
        Assert.Equal(exactItemCodes[2], countryItems[1].ExactItemCode);

        countryItems = actual[1].CountryItems.ToList();
        Assert.Single(countryItems);
        Assert.Null(countryItems[0].CountryCode);
        Assert.Equal(exactItemCodes[1], countryItems[0].ExactItemCode);
    }
}