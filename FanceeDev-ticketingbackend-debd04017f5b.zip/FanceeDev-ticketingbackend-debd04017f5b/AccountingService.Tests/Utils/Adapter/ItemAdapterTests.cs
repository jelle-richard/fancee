using AccountingService.Utils.Adapter;
using AccountingUtils.Providers.Accounting.Exact.Responses;

namespace AccountingService.Tests.Utils.Adapter;

public class ItemAdapterTests
{
    [Fact]
    public void TestThatToMinimalItemResponsesMapsItemResponse()
    {
        var responses = new ItemResponse[]
        {
            new()
            {
                Id = Guid.Empty,
                Code = "Code",
                Description = "Description"
            },
            new()
            {
                Id = Guid.NewGuid(),
                Code = null,
                Description = null
            }
        };

        var actual = responses.ToMinimalItemResponses().ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal(Guid.Empty, actual[0].Id);
        Assert.Equal("Code", actual[0].Code);
        Assert.Equal("Description", actual[0].Description);
        Assert.NotEqual(Guid.Empty, actual[1].Id);
        Assert.Equal(string.Empty, actual[1].Code);
        Assert.Null(actual[1].Description);
    }
}