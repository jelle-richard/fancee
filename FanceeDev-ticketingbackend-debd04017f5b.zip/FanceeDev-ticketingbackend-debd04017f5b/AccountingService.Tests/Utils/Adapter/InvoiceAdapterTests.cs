using AccountingService.Utils.Adapter;
using FanceeData.Models.Ticketing.Invoicing;

namespace AccountingService.Tests.Utils.Adapter;

public class InvoiceAdapterTests
{
    [Fact]
    public void TestThatToExactCreateUserRequestMapsInvoice()
    {
        var invoice = new Invoice
        {
            Organization = new()
            {
                Name = "UnitBV",
                User = new()
                {
                    Email = "unit@test.com",
                    UserContactInfo = new()
                    {
                        PhoneNumber = "+3199999963",
                        Address = new()
                        {
                            Street = "UnitStreet",
                            HouseNumber = "12",
                            CountryCode = "NL",
                            PostalCode = "1234AB",
                            City = "TestCity"
                        }
                    }
                },
                PaymentSettings = new() { VatCode = "VAT01" },
                ChamberOfCommerceIdentifier = "KVK01"
            }
        };

        var actual = invoice.ToExactCreateUserRequest();

        Assert.NotNull(actual);
        Assert.Equal("UnitBV", actual.Name);
        Assert.Equal("unit@test.com", actual.Email);
        Assert.Equal("UnitStreet 12", actual.AddressLine1);
        Assert.Equal(string.Empty, actual.AddressLine2);
        Assert.Equal(string.Empty, actual.AddressLine3);
        Assert.Equal("NL", actual.Country);
        Assert.Equal("1234AB", actual.PostalCode);
        Assert.Equal("TestCity", actual.City);
        Assert.Null(actual.Code);
        Assert.Equal("+3199999963", actual.PhoneNumber);
        Assert.Equal("C", actual.Status);
        Assert.Equal("VAT01", actual.VatNumber);
        Assert.Equal("KVK01", actual.ChamberOfCommerceNumber);
    }

    [Fact]
    public void TestThatToExactCreateUserRequestHandlesNullableUserContactInfo()
    {
        var invoice = new Invoice
        {
            Organization = new()
            {
                Name = "UnitBV",
                User = new()
                {
                    Email = "unit@test.com",
                    UserContactInfo = null
                },
                PaymentSettings = new() { VatCode = "VAT01" },
                ChamberOfCommerceIdentifier = "KVK01"
            }
        };

        var actual = invoice.ToExactCreateUserRequest();

        Assert.Equal(string.Empty, actual.AddressLine1);
        Assert.Null(actual.Country);
        Assert.Null(actual.PostalCode);
        Assert.Null(actual.City);
        Assert.Null(actual.PhoneNumber);
    }

    [Fact]
    public void TestThatToExactCreateUserRequestHandlesNullableAddress()
    {
        var invoice = new Invoice
        {
            Organization = new()
            {
                Name = "UnitBV",
                User = new()
                {
                    Email = "unit@test.com",
                    UserContactInfo = new()
                    {
                        PhoneNumber = "+3199999963",
                        Address = null
                    }
                },
                PaymentSettings = new() { VatCode = "VAT01" },
                ChamberOfCommerceIdentifier = "KVK01"
            }
        };

        var actual = invoice.ToExactCreateUserRequest();

        Assert.Equal(string.Empty, actual.AddressLine1);
        Assert.Null(actual.Country);
        Assert.Null(actual.PostalCode);
        Assert.Null(actual.City);
        Assert.Equal("+3199999963", actual.PhoneNumber);
    }
}