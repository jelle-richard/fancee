using AccountingService.Utils.Adapter;

namespace AccountingService.Tests.Utils.Adapter;

public class ZipAdapterTests
{
    [Fact]
    public void TestThatToZipEntriesConvertsIEnumerableToZipEntries()
    {
        var files = new byte[][]
        {
            [1, 2, 3],
            [4, 5, 6]
        };

        var actual = files.ToZipEntries("Entry {index}").ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal(new byte[] { 1, 2, 3 }, actual[0].Bytes);
        Assert.Equal("Entry 1", actual[0].FileName);
        Assert.Equal(new byte[] { 4, 5, 6 }, actual[1].Bytes);
        Assert.Equal("Entry 2", actual[1].FileName);
    }

    [Fact]
    public void TestThatToStreamWrapsByteArrayInMemoryStream()
    {
        var bytes = new byte[] { 1, 2, 3 };

        var actual = bytes.ToStream();

        Assert.IsType<MemoryStream>(actual);

        var actualRead = new byte[4];
        var read = actual.Read(actualRead, 0, 4);

        Assert.Equal(3, read);

        // we expect the extra byte as the buffer is 4 to make sure we do not somehow have extra bytes.
        Assert.Equal(new byte[] { 1, 2, 3, 0 }, actualRead);
    }
}