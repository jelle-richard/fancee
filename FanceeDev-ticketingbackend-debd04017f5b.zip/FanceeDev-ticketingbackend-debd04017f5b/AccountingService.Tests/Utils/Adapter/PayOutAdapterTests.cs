using AccountingService.Dtos.Shared.PayOut;
using AccountingService.Utils.Adapter;
using FanceeData.Models.Ticketing.Invoicing;
using JetBrains.Annotations;
using WebApiCore.Utils;

namespace AccountingService.Tests.Utils.Adapter;

[TestSubject(typeof(PayOutAdapter))]
public class PayOutAdapterTests
{
    [Fact]
    public void TestThatToPayoutRowMapsWalletPayment()
    {
        var requestedAt = DateTime.ParseExact("2022-12-31 10:00:00", DateFormat.DefaultApiResponse, null);

        var walletPayment = new WalletPayment
        {
            Id = Guid.NewGuid(),
            RequestedAt = requestedAt,
            AmountCents = 4242,
            Organization = new()
            {
                Name = "Test Inc",
                PaymentSettings = new()
                {
                    Iban = "NL71IBAN1234567890",
                    BankAccountNumber = "BANK01",
                    Bic = "BIC01"
                }
            }
        };

        var actual = walletPayment.ToPayoutRow(3232);

        Assert.Equal(walletPayment.Id.ToString(), actual.Reference);
        Assert.Equal("Pay Out 31-12-2022", actual.Description);
        Assert.Equal(3232, actual.ValueEurCents);
        Assert.Equal("NL71IBAN1234567890", actual.ReceiverIban);
        Assert.Equal("BANK01", actual.ReceiverBankAccountNumber);
        Assert.Equal("BIC01", actual.ReceiverBic);
        Assert.Equal("Test Inc", actual.BankAccountHolderName);
    }

    [Theory]
    [InlineData(ExportStatus.Created, PayOutExportStatus.Created)]
    [InlineData(ExportStatus.Processed, PayOutExportStatus.Processed)]
    [InlineData(null, null)]
    public void TestThatToPayOutExportStatusReturnsExpectedResult(ExportStatus? input, PayOutExportStatus? expected)
    {
        var actual = input.ToPayOutExportStatus();

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(PayOutExportStatus.Created, ExportStatus.Created)]
    [InlineData(PayOutExportStatus.Processed, ExportStatus.Processed)]
    public void TestThatToExportStatusReturnsExpectedResult(PayOutExportStatus input, ExportStatus expected)
    {
        var actual = input.ToExportStatus();

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatToPayOutExportItemResponsesMapsPayOutExports()
    {
        var id = Guid.NewGuid();
        var createdAt = DateTime.UtcNow;

        var input = new PayOutExport[]
        {
            new()
            {
                Id = id,
                CreatedAt = createdAt,
                Status = PayOutExportStatus.Processed
            }
        };

        var actual = input.ToPayOutExportItemResponses().ToList();

        Assert.Single(actual);
        Assert.Equal(id, actual[0].Id);
        Assert.Equal(createdAt, actual[0].CreatedAt);
        Assert.Equal(ExportStatus.Processed, actual[0].Status);
    }
}