using System.ComponentModel.DataAnnotations;

namespace AccountingService.Dtos.Requests.Exact;

public class ConfigureItemsRequest : IValidatableObject
{
    [Required]
    public IEnumerable<ConfigureItemRequest> Items { get; set; } = new List<ConfigureItemRequest>();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (!Items.Any())
            yield return new("At least 1 item is required", new[] { nameof(Items) });
    }
}