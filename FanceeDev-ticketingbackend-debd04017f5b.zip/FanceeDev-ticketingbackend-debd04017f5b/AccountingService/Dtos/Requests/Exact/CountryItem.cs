using WebApiCore.Dtos.Shared;

namespace AccountingService.Dtos.Requests.Exact;

public class CountryItem
{
    public CountryCode? CountryCode { get; set; }
    public Guid ExactItemCode { get; set; }
}