using System.ComponentModel.DataAnnotations;

namespace AccountingService.Dtos.Requests.Exact;

public class ConfigureItemRequest : IValidatableObject
{
    public string PlatformItem { get; set; } = default!;
    public IEnumerable<CountryItem> CountryItems { get; set; } = new List<CountryItem>();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        CountryItems = CountryItems.ToList();

        if (CountryItems.Count(ci => ci.CountryCode == null) > 1)
            yield return new("Only one 'null' country code is allowed per mapping", new[] { nameof(CountryItems) });

        if (CountryItems.GroupBy(ci => ci.CountryCode).Any(g => g.Key != null && g.Count() > 1))
            yield return new("Cannot insert duplicate country mapping", new[] { nameof(CountryItems) });
    }
}