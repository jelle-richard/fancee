using System.ComponentModel.DataAnnotations;

namespace AccountingService.Dtos.Requests.Exact;

public class ConfigureRequest
{
    [Required]
    [StringLength(50)]
    public string? Journal { get; set; }
}