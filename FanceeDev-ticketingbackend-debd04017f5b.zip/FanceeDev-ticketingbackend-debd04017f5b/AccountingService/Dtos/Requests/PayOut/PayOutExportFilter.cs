using AccountingService.Dtos.Shared.PayOut;
using WebApiCore.Dtos.Requests.Filters.Pagination;

namespace AccountingService.Dtos.Requests.PayOut;

public class PayOutExportFilter : SearchQueryFilter
{
    public ExportStatus? Status { get; set; }
}