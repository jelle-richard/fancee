namespace AccountingService.Dtos.Shared.PayOut;

public enum ExportStatus
{
    Created,
    Processed
}