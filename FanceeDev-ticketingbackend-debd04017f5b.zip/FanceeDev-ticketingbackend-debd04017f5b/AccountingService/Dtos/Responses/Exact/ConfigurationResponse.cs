namespace AccountingService.Dtos.Responses.Exact;

public class ConfigurationResponse
{
    public required string Journal { get; set; }
    public required IEnumerable<ConfiguredItemResponse> Items { get; set; }
}