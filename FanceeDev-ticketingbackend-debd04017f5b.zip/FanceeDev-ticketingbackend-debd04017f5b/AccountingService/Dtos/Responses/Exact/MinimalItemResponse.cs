namespace AccountingService.Dtos.Responses.Exact;

public class MinimalItemResponse
{
    public required Guid Id { get; set; }
    public required string Code { get; set; }
    public string? Description { get; set; }
}