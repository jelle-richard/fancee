using AccountingService.Dtos.Requests.Exact;

namespace AccountingService.Dtos.Responses.Exact;

public class ConfiguredItemResponse
{
    public required string PlatformItem { get; set; }

    //todo: move CountryItem to shared.
    public required IEnumerable<CountryItem> CountryItems { get; set; }
}