using AccountingService.Dtos.Shared.PayOut;
using CsvHelper.Configuration.Attributes;

namespace AccountingService.Dtos.Responses.PayOut;

public class PayOutExportItemResponse
{
    public Guid Id { get; set; }
    
    public ExportStatus Status { get; set; }
    
    [Format("yyyy-MM-dd HH:mm:ss")]
    public DateTime CreatedAt { get; set; }
}