namespace AccountingService.Dtos.Responses.PayOut;

public class CreatePayOutExportResponse
{
    public Guid Id { get; set; }
}