using AccountingService.Services.Exact;
using WebApiCore.BackgroundTasks;
using WebApiCore.MessageBus.Messages.Invoices;

namespace AccountingService.BackgroundTasks.MessageBus;

public class AddAccountingInvoiceListener(IServiceProvider serviceProvider)
    : MessageBusHostedService<AddAccountingInvoiceMessage, AddAccountingInvoiceListener>(serviceProvider), ISimpleMessageBus<AddAccountingInvoiceMessage>
{
    protected override string LogPrefix => $"[{nameof(AddAccountingInvoiceListener)}]";

    private IExactService _exactService = default!;

    public async Task ProcessAsync(AddAccountingInvoiceMessage? message)
    {
        try
        {
            await _exactService.AddInvoiceAsync(message!.InvoiceId);
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "{LogPrefix} Unable to create the invoice in the external invoice system", LogPrefix);
        }
    }

    protected override void RegisterDependencies()
    {
        _exactService = ServiceProvider.GetRequiredService<IExactService>();
    }
}