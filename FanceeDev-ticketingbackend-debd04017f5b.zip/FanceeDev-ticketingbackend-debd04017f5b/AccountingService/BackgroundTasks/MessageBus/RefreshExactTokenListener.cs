using AccountingService.Services.Exact;
using WebApiCore.BackgroundTasks;
using WebApiCore.MessageBus.Messages.Token;

namespace AccountingService.BackgroundTasks.MessageBus;

public class RefreshExactTokenListener : MessageBusHostedService<RefreshExactTokenMessage, RefreshExactTokenListener>, ISimpleMessageBus<RefreshExactTokenMessage>
{
    protected override string LogPrefix => $"[{nameof(RefreshExactTokenListener)}]";

    private IExactService _exactService = default!;

    public RefreshExactTokenListener(IServiceProvider serviceProvider) : base(serviceProvider)
    {
    }

    public async Task ProcessAsync(RefreshExactTokenMessage? message)
    {
        try
        {
            await _exactService.RefreshTokenAsync();
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, "{LogPrefix} Could not refresh Exact token", LogPrefix);
        }
    }

    protected override void RegisterDependencies()
    {
        _exactService = ServiceProvider.GetRequiredService<IExactService>();
    }
}