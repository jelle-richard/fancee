using AccountingService.Dtos.Requests.Exact;
using AccountingService.Dtos.Responses.Exact;

namespace AccountingService.Services.ItemMapping;

public interface IItemMappingService
{
    /// <summary>
    /// Adds the item mappings.
    /// </summary>
    /// <param name="items"></param>
    /// <returns></returns>
    public Task AddAsync(IEnumerable<ConfigureItemRequest> items);

    /// <summary>
    /// Gets the configured mappings.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<ConfiguredItemResponse>> MappingsAsync();
}