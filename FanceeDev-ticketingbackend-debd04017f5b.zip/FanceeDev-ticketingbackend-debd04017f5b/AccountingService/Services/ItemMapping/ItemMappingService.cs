using AccountingService.Dtos.Requests.Exact;
using AccountingService.Dtos.Responses.Exact;
using AccountingService.Persistence.Invoice;
using AccountingService.Persistence.ItemMapping;
using AccountingService.Services.ItemMapping.Exceptions;
using AccountingService.Utils.Adapter;

namespace AccountingService.Services.ItemMapping;

public class ItemMappingService : IItemMappingService
{
    private readonly IItemMappingDao _itemMappingDao;
    private readonly IInvoiceRowSpecificationDao _invoiceRowSpecificationDao;

    public ItemMappingService(IItemMappingDao itemMappingDao, IInvoiceRowSpecificationDao invoiceRowSpecificationDao)
    {
        _itemMappingDao = itemMappingDao;
        _invoiceRowSpecificationDao = invoiceRowSpecificationDao;
    }

    public async Task AddAsync(IEnumerable<ConfigureItemRequest> items)
    {
        var models = items.ToItemMappings().ToArray();

        var invoiceSpecificationNames = models.Select(m => m.InvoiceRowSpecificationName).Distinct();

        if (!await _invoiceRowSpecificationDao.ValidAsync(invoiceSpecificationNames))
            throw new InvalidInvoiceRowSpecificationNameException();

        await _itemMappingDao.InsertAsync(models);
    }

    public async Task<IEnumerable<ConfiguredItemResponse>> MappingsAsync()
    {
        var mappings = await _itemMappingDao.ItemMappingsAsync();

        return mappings.ToConfiguredItemResponses();
    }
}