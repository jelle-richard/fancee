using WebApiCore.Exceptions;

namespace AccountingService.Services.ItemMapping.Exceptions;

public class InvalidInvoiceRowSpecificationNameException()
    : BadRequestApiException("The given invoice row specification is invalid");