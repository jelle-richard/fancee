namespace AccountingService.Services.Invoice;

public interface IInvoiceRowSpecificationService
{
    /// <summary>
    /// Gets all invoice row specification names.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<string>> NamesAsync();
}