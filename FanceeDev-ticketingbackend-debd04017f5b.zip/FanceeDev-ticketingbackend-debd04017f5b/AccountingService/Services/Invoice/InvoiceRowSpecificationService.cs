using AccountingService.Persistence.Invoice;

namespace AccountingService.Services.Invoice;

public class InvoiceRowSpecificationService : IInvoiceRowSpecificationService
{
    private readonly IInvoiceRowSpecificationDao _invoiceRowSpecificationDao;

    public InvoiceRowSpecificationService(IInvoiceRowSpecificationDao invoiceRowSpecificationDao)
    {
        _invoiceRowSpecificationDao = invoiceRowSpecificationDao;
    }

    public async Task<IEnumerable<string>> NamesAsync() => await _invoiceRowSpecificationDao.NamesAsync();
}