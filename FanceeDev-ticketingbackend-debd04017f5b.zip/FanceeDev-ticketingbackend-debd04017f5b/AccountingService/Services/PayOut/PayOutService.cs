using System.IO.Compression;
using System.Net.Mime;
using AccountingService.Dtos.Requests.PayOut;
using AccountingService.Dtos.Responses.PayOut;
using AccountingService.Persistence.PayOut;
using AccountingService.Services.PayOut.Exceptions;
using AccountingService.Utils.Adapter;
using AccountingUtils.Providers.Bank;
using AccountingUtils.Providers.Bank.Models;
using FanceeData.Models.Ticketing.Invoicing;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Storage;
using WebApiCore.Services.Upload;
using WebApiCore.Settings;
using WebApiCore.Utils;
using ZipUtils.Providers.Zip;

namespace AccountingService.Services.PayOut;

public class PayOutService : IPayOutService
{
    private readonly IPayOutDao _payOutDao;
    private readonly IBankExportProvider _bankExportProvider;
    private readonly IZipProvider _zipProvider;
    private readonly OrganizationDetailsSettings _organizationDetailsSettings;
    private readonly IUploadService _uploadService;
    private readonly IStorageService _storageService;
    private readonly ICurrencyService _currencyService;

    public PayOutService(IPayOutDao payOutDao, IBankExportProvider bankExportProvider, IZipProvider zipProvider, IConfiguration configuration, IUploadService uploadService, IStorageService storageService, ICurrencyService currencyService)
    {
        _payOutDao = payOutDao;
        _bankExportProvider = bankExportProvider;
        _zipProvider = zipProvider;
        _uploadService = uploadService;
        _storageService = storageService;
        _currencyService = currencyService;

        _organizationDetailsSettings = OrganizationDetailsSettings.FromConfiguration(configuration);
    }

    public async Task<CreatePayOutExportResponse> CreateExportAsync()
    {
        var walletPayments = (await _payOutDao.UnprocessedWalletPaymentsAsync()).ToList();

        if (walletPayments.Count == 0)
            return new();

        var exportId = await CreateExportAsync(walletPayments, DateTime.UtcNow.ToDateOnly());

        await _payOutDao.UpdateWalletPaymentsAsync(walletPayments);

        return new() { Id = exportId };
    }

    public async Task<Stream> DownloadFileAsync(Guid exportId)
    {
        var file = await _payOutDao.FileAsync(exportId) ?? throw new PayOutExportNotFoundException();

        try
        {
            return await _storageService.DownloadFileAsync(IStorageService.PayOutStoragePool, $"{file.Name}.zip");
        }
        catch (Exception)
        {
            throw new PayOutExportNotFoundException();
        }
    }

    public async Task ChangeStatusAsync(Guid exportId, PayOutExportStatus status)
    {
        var export = await _payOutDao.ByIdAsync(exportId) ?? throw new PayOutExportNotFoundException();
        export.Status = status;

        foreach (var exportWalletPayment in export.WalletPayments)
            exportWalletPayment.ProcessedAt = DateTime.UtcNow;

        await _payOutDao.UpdateAsync(export);
    }

    public async Task<PaginatedResultSet<PayOutExportItemResponse>> ListAsync(PaginatedRequest<PayOutExportFilter> request)
    {
        var result = await _payOutDao.ListAsync(
            request.PageSize,
            request.GetOffset(),
            request.Options.SearchQuery,
            request.Options.Status.ToPayOutExportStatus());

        return new()
        {
            TotalItems = result.TotalItems,
            Items = result.Items.ToPayOutExportItemResponses()
        };
    }

    public async Task<int> PendingPayoutsAsync() => await _payOutDao.UnprocessedWalletPaymentsAmountAsync();

    private async Task<Guid> CreateExportAsync(ICollection<WalletPayment> walletPayments, DateOnly executeOn)
    {
        var payoutExportInfo = await CreatePayoutExportInfoAsync(walletPayments, executeOn);

        var files = _bankExportProvider.CreatePayoutExport(payoutExportInfo)
            .ToZipEntries("Part-{index}.xlsx");

        var zip = await _zipProvider.AddFiles(files)
            .SetCompressionLevel(CompressionLevel.Fastest)
            .CompressAsync();

        var payOutExport = new PayOutExport
        {
            Status = PayOutExportStatus.Created,
            WalletPayments = walletPayments
        };

        await _uploadService.UploadAsync(
            zip.ToStream(),
            IStorageService.PayOutStoragePool,
            null,
            "zip",
            MediaTypeNames.Application.Zip,
            false,
            async file =>
            {
                payOutExport.File = file;
                await _payOutDao.InsertAsync(payOutExport);
            }
        );

        return payOutExport.Id;
    }

    private async Task<PayoutExportInfo> CreatePayoutExportInfoAsync(IEnumerable<WalletPayment> walletPayments, DateOnly executeOn)
    {
        var payOutRows = new List<PayoutRow>();

        foreach (var wp in walletPayments)
            payOutRows.Add(wp.ToPayoutRow(await ConvertCurrency(wp)));

        return new()
        {
            DebtorIban = _organizationDetailsSettings.Iban,
            DebtorBankAccountHolderName = _organizationDetailsSettings.PlatformName,
            ExecuteOn = executeOn,
            Rows = payOutRows
        };
    }

    private async Task<long> ConvertCurrency(WalletPayment walletPayment)
    {
        // The bank export file (ING) uses 'EUR' as their currency
        if (walletPayment.CurrencyShortCode == "EUR")
            return walletPayment.AmountCents;

        return await _currencyService.ConvertAsync("EUR", walletPayment.AmountCents);
    }
}