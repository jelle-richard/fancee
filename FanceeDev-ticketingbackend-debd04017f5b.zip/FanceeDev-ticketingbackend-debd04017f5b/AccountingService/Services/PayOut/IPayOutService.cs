using AccountingService.Dtos.Requests.PayOut;
using AccountingService.Dtos.Responses.PayOut;
using FanceeData.Models.Ticketing.Invoicing;
using WebApiCore.Dtos.Requests;
using WebApiCore.Dtos.Shared;

namespace AccountingService.Services.PayOut;

public interface IPayOutService
{
    /// <summary>
    /// Creates a pay out export.
    /// </summary>
    /// <returns></returns>
    public Task<CreatePayOutExportResponse> CreateExportAsync();

    /// <summary>
    /// Downloads the export file.
    /// </summary>
    /// <param name="exportId"></param>
    /// <returns></returns>
    public Task<Stream> DownloadFileAsync(Guid exportId);

    /// <summary>
    /// Changes the status of the export.
    /// </summary>
    /// <param name="exportId"></param>
    /// <param name="status"></param>
    /// <returns></returns>
    public Task ChangeStatusAsync(Guid exportId, PayOutExportStatus status);

    /// <summary>
    /// Lists the pay out exports.
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public Task<PaginatedResultSet<PayOutExportItemResponse>> ListAsync(PaginatedRequest<PayOutExportFilter> request);

    /// <summary>
    /// Counts the amount of pending payouts in order to check if an export can be created.
    /// </summary>
    /// <returns></returns>
    public Task<int> PendingPayoutsAsync();
}