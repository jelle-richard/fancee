using WebApiCore.Exceptions;

namespace AccountingService.Services.PayOut.Exceptions;

public class PayOutExportNotFoundException()
    : NotFoundApiException("The requested export could not be found");