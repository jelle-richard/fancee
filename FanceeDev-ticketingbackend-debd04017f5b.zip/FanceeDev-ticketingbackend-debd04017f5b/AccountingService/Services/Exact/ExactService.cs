using AccountingService.Persistence.Exact;
using AccountingService.Persistence.Invoice;
using AccountingService.Persistence.ItemMapping;
using AccountingService.Services.Exact.Exceptions;
using AccountingService.Services.OAuth;
using AccountingService.Services.OAuth.Exceptions;
using AccountingService.Utils.Adapter;
using AccountingUtils.Providers.Accounting.Exact;
using AccountingUtils.Providers.Accounting.Exact.Requests;
using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Exact;
using FanceeData.Models.Ticketing.Invoicing;
using WebApiCore.Services.Currency;
using WebApiCore.Services.Storage;
using WebApiCore.Utils;
using WebApiCore.Utils.String;
using File = FanceeData.Models.Ticketing.File;

namespace AccountingService.Services.Exact;

public class ExactService : IExactService
{
    private const string DiscountInvoiceRowSpecificationName = "Discount";

    private readonly IExactConfigurationDao _exactConfigurationDao;
    private readonly IExactProvider _exactProvider;
    private readonly IOAuthProviderTokenService _oAuthProviderTokenService;
    private readonly IInvoiceDao _invoiceDao;
    private readonly IExactDao _exactDao;
    private readonly IItemMappingDao _itemMappingDao;
    private readonly ICurrencyService _currencyService;
    private readonly IStorageService _storageService;

    public ExactService(IExactConfigurationDao exactConfigurationDao, IExactProvider exactProvider, IOAuthProviderTokenService oAuthProviderTokenService, IInvoiceDao invoiceDao, IExactDao exactDao, IItemMappingDao itemMappingDao, ICurrencyService currencyService, IStorageService storageService)
    {
        _exactConfigurationDao = exactConfigurationDao;
        _exactProvider = exactProvider;
        _oAuthProviderTokenService = oAuthProviderTokenService;
        _invoiceDao = invoiceDao;
        _exactDao = exactDao;
        _itemMappingDao = itemMappingDao;
        _currencyService = currencyService;
        _storageService = storageService;
    }

    public async Task<ExactConfiguration> ConfigurationAsync() => await _exactConfigurationDao.GetAsync() ?? throw new MissingExactConfigurationException();

    public async Task SetConfigurationAsync(int division, string? journal)
    {
        await _exactConfigurationDao.SetAsync(new()
        {
            Division = division,
            Journal = journal
        });
    }

    public async Task<string> RefreshTokenAsync()
    {
        var oAuthToken = await _oAuthProviderTokenService.ForProviderAsync(OAuthProvider.Exact);

        if (oAuthToken.RefreshToken == null)
            throw new OAuthProviderTokenNotFoundException(OAuthProvider.Exact.ToString());

        return await RefreshTokenAsync(oAuthToken);
    }

    public async Task<string> RefreshTokenAsync(OAuthProviderToken oAuthToken)
    {
        var result = await _exactProvider.RefreshTokenAsync(oAuthToken.RefreshToken);
        await _oAuthProviderTokenService.AddOrUpdateAsync(result);

        return result.AccessToken;
    }

    public async Task AddInvoiceAsync(int invoiceId)
    {
        var config = await _exactConfigurationDao.GetAsync() ?? throw new MissingExactConfigurationException();
        var invoice = await _invoiceDao.ByIdAsync(invoiceId) ?? throw new InvoiceNotFoundException(invoiceId);

        _exactProvider.SetToken(await TokenAsync());

        var exactAccountId = await _exactDao.ExactAccountIdByInvoiceId(invoiceId)
                             ?? await CreateExactUserAsync(config.Division, invoice);

        var request = await CreateAddInvoiceRequestAsync(invoice, config.Journal, exactAccountId);

        if (invoice.File != null)
        {
            request.DocumentId = await _exactProvider.UploadDocumentAsync(
                config.Division,
                "Invoice",
                DocumentType.SalesEntry,
                "invoice.pdf",
                await InvoicePdfBase64(invoice.File),
                exactAccountId
            );
        }

        await _exactProvider.CreateSalesInvoiceAsync(config.Division, request);
    }

    private async Task<string> InvoicePdfBase64(File file) =>
        await _storageService.DownloadFileAsync(IStorageService.InvoiceMediaStoragePool, $"{file.Name}.pdf").ToBase64Async();

    private async Task<CreateSalesInvoiceRequest> CreateAddInvoiceRequestAsync(FanceeData.Models.Ticketing.Invoicing.Invoice invoice, string journal, Guid exactAccountId)
    {
        var itemMappings = await _itemMappingDao.ItemMappingsAsync(
            invoice.Rows.Where(r => r.InvoiceRowSpecificationName != DiscountInvoiceRowSpecificationName)
                .Select(r => r.InvoiceRowSpecificationName),
            invoice.Organization.CountryCode
        );

        var discountRow = invoice.Rows.FirstOrDefault(r => r.InvoiceRowSpecificationName == DiscountInvoiceRowSpecificationName);
        var discountAmount = 0m;
        var discountAmountExclVat = 0m;

        if (discountRow != null)
        {
            discountAmount = Math.Round(discountRow.UnitPriceCents * discountRow.Amount + discountRow.UnitPriceCents * discountRow.Amount / 100 * discountRow.VatPercentage);
            discountAmountExclVat = Math.Round(discountRow.UnitPriceCents * discountRow.Amount);
        }

        discountAmount = await _currencyService.CentsToDecimalAsync("EUR", (int)discountAmount);
        discountAmountExclVat = await _currencyService.CentsToDecimalAsync("EUR", (int)discountAmountExclVat);

        return new()
        {
            Journal = journal,
            OrderedBy = exactAccountId,
            AmountDiscount = discountAmount,
            AmountDiscountExclVat = discountAmountExclVat,
            Currency = invoice.CurrencyShortCode,
            Description = $"Invoice {invoice.CreatedAt.ToString(DateFormat.YearMonth)}",
            OrderDate = invoice.CreatedAt,
            PlatformInvoiceNumber = invoice.Id.ToString(),
            SalesInvoiceLines = await CreateSalesInvoiceLinesAsync(invoice.Rows, itemMappings)
        };
    }

    private async Task<IEnumerable<CreateSalesInvoiceRequest.SalesInvoiceLine>> CreateSalesInvoiceLinesAsync(IEnumerable<InvoiceRow> rows, IReadOnlyDictionary<string, Guid> itemMappings)
    {
        var lines = new List<CreateSalesInvoiceRequest.SalesInvoiceLine>();

        foreach (var row in rows.Where(r => r.InvoiceRowSpecificationName != DiscountInvoiceRowSpecificationName))
        {
            lines.Add(new()
            {
                Item = itemMappings[row.InvoiceRowSpecificationName],
                Notes = row.Note,
                UnitPrice = await _currencyService.CentsToDecimalAsync("EUR", row.UnitPriceCents),
                Quantity = row.Amount
            });
        }

        return lines;
    }

    private async Task<string> TokenAsync()
    {
        var currentToken = await _oAuthProviderTokenService.ForProviderAsync(OAuthProvider.Exact);

        // Tokens are valid for 10 minutes and can be refreshed after 9 minutes and 30 seconds.
        if (currentToken.ValidUntil.AddSeconds(-30) > DateTime.UtcNow)
            return currentToken.Token;

        return await RefreshTokenAsync(currentToken);
    }

    private async Task<Guid> CreateExactUserAsync(int division, FanceeData.Models.Ticketing.Invoicing.Invoice invoice)
    {
        var account = (await _exactProvider.AccountsAsync(division, invoice.Organization.Name))
            .FirstOrDefault(a => a.Name == invoice.Organization.Name);

        var id = account?.Id
                 ?? await _exactProvider.CreateUserAsync(division, invoice.ToExactCreateUserRequest());

        await _exactDao.InsertAsync(new()
        {
            ExactAccountId = id,
            UserId = invoice.Organization.UserId
        });

        return id;
    }
}