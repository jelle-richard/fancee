using WebApiCore.Exceptions;

namespace AccountingService.Services.Exact.Exceptions;

public class InvoiceNotFoundException(int id)
    : NotFoundApiException($"Invoice with id '{id}' could not be found");