using WebApiCore.Exceptions;
using WebApiCore.Utils;

namespace AccountingService.Services.Exact.Exceptions;

public class MissingExactConfigurationException()
    : BadRequestApiException("Missing Exact configuration", ErrorCode.ExceptionInvalidConfiguration);