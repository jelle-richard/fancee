using FanceeData.Models.Ticketing;
using FanceeData.Models.Ticketing.Exact;

namespace AccountingService.Services.Exact;

public interface IExactService
{
    /// <summary>
    /// Gets the configuration.
    /// </summary>
    /// <returns></returns>
    public Task<ExactConfiguration> ConfigurationAsync();

    /// <summary>
    /// Sets the configuration.
    /// </summary>
    /// <param name="division"></param>
    /// <param name="journal"></param>
    /// <returns></returns>
    public Task SetConfigurationAsync(int division, string? journal);

    /// <summary>
    /// Refreshes the authentication token.
    /// </summary>
    /// <returns></returns>
    public Task<string> RefreshTokenAsync();

    /// <summary>
    /// Refreshes the authentication token.
    /// </summary>
    /// <param name="oAuthToken"></param>
    /// <returns></returns>
    public Task<string> RefreshTokenAsync(OAuthProviderToken oAuthToken);

    /// <summary>
    /// Adds a new invoice to Exact.
    /// </summary>
    /// <param name="invoiceId"></param>
    /// <returns></returns>
    public Task AddInvoiceAsync(int invoiceId);
}