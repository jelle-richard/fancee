using WebApiCore.Exceptions;

namespace AccountingService.Services.OAuth.Exceptions;

public class OAuthProviderTokenNotFoundException(string provider)
    : NotFoundApiException($"No OAuth provider token could be found for provider '{provider}'");