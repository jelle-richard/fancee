using AccountingService.Persistence.OAuth;
using AccountingService.Services.OAuth.Exceptions;
using AccountingUtils.Providers.Accounting.Exact.Responses;
using FanceeData.Models.Ticketing;

namespace AccountingService.Services.OAuth;

public class OAuthProviderTokenService : IOAuthProviderTokenService
{
    private readonly IOAuthProviderTokenDao _oAuthProviderTokenDao;

    public OAuthProviderTokenService(IOAuthProviderTokenDao oAuthProviderTokenDao)
    {
        _oAuthProviderTokenDao = oAuthProviderTokenDao;
    }

    public async Task<OAuthProviderToken> ForProviderAsync(OAuthProvider provider) => await _oAuthProviderTokenDao.ForProviderAsync(provider) ?? throw new OAuthProviderTokenNotFoundException(provider.ToString());

    public async Task AddOrUpdateAsync(TokenResponse exactTokenResponse)
    {
        var providerToken = await _oAuthProviderTokenDao.ForProviderAsync(OAuthProvider.Exact);
        var insert = providerToken == null;

        providerToken ??= new() { Provider = OAuthProvider.Exact };
        providerToken.Token = exactTokenResponse.AccessToken;
        providerToken.RefreshToken = exactTokenResponse.RefreshToken;
        providerToken.ValidUntil = DateTime.UtcNow.AddSeconds(exactTokenResponse.ExpiresIn);

        await (
            insert
                ? _oAuthProviderTokenDao.AddAsync(providerToken)
                : _oAuthProviderTokenDao.UpdateAsync(providerToken)
        );
    }

    public async Task<bool> ExistsAsync(OAuthProvider provider, int? refreshExpireDays) => await _oAuthProviderTokenDao.ExistsAsync(provider, refreshExpireDays);
}