using AccountingUtils.Providers.Accounting.Exact.Responses;
using FanceeData.Models.Ticketing;

namespace AccountingService.Services.OAuth;

public interface IOAuthProviderTokenService
{
    /// <summary>
    /// Gets the <see cref="OAuthProviderToken" /> for the <see cref="OAuthProvider" />.
    /// </summary>
    /// <param name="provider"></param>
    /// <returns></returns>
    public Task<OAuthProviderToken> ForProviderAsync(OAuthProvider provider);

    /// <summary>
    /// Adds or updates a <see cref="OAuthProviderToken" />.
    /// </summary>
    /// <param name="exactTokenResponse"></param>
    /// <returns></returns>
    public Task AddOrUpdateAsync(TokenResponse exactTokenResponse);

    /// <summary>
    /// Returns whether the <see cref="OAuthProviderToken" /> token exists for the <see cref="OAuthProvider" />.
    /// </summary>
    /// <param name="provider"></param>
    /// <param name="refreshExpireDays"></param>
    /// <returns></returns>
    public Task<bool> ExistsAsync(OAuthProvider provider, int? refreshExpireDays);
}