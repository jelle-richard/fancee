using AccountingUtils.Providers.Accounting.Exact.Requests;
using FanceeData.Models.Ticketing.Invoicing;

namespace AccountingService.Utils.Adapter;

public static class InvoiceAdapter
{
    /// <summary>
    /// Transforms a <see cref="Invoice" /> to a <see cref="CreateUserRequest" /> for adding new Exact users.
    /// </summary>
    /// <param name="invoice"></param>
    /// <returns></returns>
    public static CreateUserRequest ToExactCreateUserRequest(this Invoice invoice) =>
        new()
        {
            Name = invoice.Organization.Name,
            Email = invoice.Organization.User.Email,
            AddressLine1 = $"{invoice.Organization.User.UserContactInfo?.Address?.Street} {invoice.Organization.User.UserContactInfo?.Address?.HouseNumber}".Trim(),
            AddressLine2 = string.Empty,
            AddressLine3 = string.Empty,
            Country = invoice.Organization.User.UserContactInfo?.Address?.CountryCode,
            PostalCode = invoice.Organization.User.UserContactInfo?.Address?.PostalCode,
            City = invoice.Organization.User.UserContactInfo?.Address?.City,
            Code = null,
            PhoneNumber = invoice.Organization.User.UserContactInfo?.PhoneNumber,
            Status = "C",
            VatNumber = invoice.Organization.PaymentSettings.VatCode,
            ChamberOfCommerceNumber = invoice.Organization.ChamberOfCommerceIdentifier
        };
}