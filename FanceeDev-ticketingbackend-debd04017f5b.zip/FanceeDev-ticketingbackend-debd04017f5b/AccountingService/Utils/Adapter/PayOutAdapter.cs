using AccountingService.Dtos.Responses.PayOut;
using AccountingService.Dtos.Shared.PayOut;
using AccountingUtils.Providers.Bank.Models;
using FanceeData.Models.Ticketing.Invoicing;
using WebApiCore.Utils;

namespace AccountingService.Utils.Adapter;

public static class PayOutAdapter
{
    /// <summary>
    /// Converts a <see cref="WalletPayment" /> to a <see cref="PayoutRow" />.
    /// </summary>
    /// <param name="walletPayment"></param>
    /// <param name="valueEurCents"></param>
    /// <returns></returns>
    public static PayoutRow ToPayoutRow(this WalletPayment walletPayment, long valueEurCents) =>
        new()
        {
            Reference = walletPayment.Id.ToString(),
            Description = $"Pay Out {walletPayment.RequestedAt.ToString(DateFormat.DayMonthYear)}",
            ValueEurCents = (int)valueEurCents,
            ReceiverIban = walletPayment.Organization.PaymentSettings.Iban,
            ReceiverBankAccountNumber = walletPayment.Organization.PaymentSettings.BankAccountNumber,
            ReceiverBic = walletPayment.Organization.PaymentSettings.Bic,
            BankAccountHolderName = walletPayment.Organization.Name
        };

    /// <summary>
    /// Converts a <see cref="ExportStatus" /> to a <see cref="PayOutExportStatus" />.
    /// </summary>
    /// <param name="status"></param>
    /// <returns></returns>
    public static PayOutExportStatus? ToPayOutExportStatus(this ExportStatus? status) =>
        status switch
        {
            ExportStatus.Created => PayOutExportStatus.Created,
            ExportStatus.Processed => PayOutExportStatus.Processed,
            var _ => null
        };

    /// <summary>
    /// Converts a <see cref="PayOutExportStatus" /> to a <see cref="ExportStatus" />.
    /// </summary>
    /// <param name="status"></param>
    /// <returns></returns>
    public static ExportStatus ToExportStatus(this PayOutExportStatus status) =>
        status switch
        {
            PayOutExportStatus.Created => ExportStatus.Created,
            PayOutExportStatus.Processed => ExportStatus.Processed,
            var _ => ExportStatus.Created
        };

    /// <summary>
    /// Converts a list of <see cref="PayOutExport" /> to a list of <see cref="PayOutExportItemResponse" />.
    /// </summary>
    /// <param name="payOutExports"></param>
    /// <returns></returns>
    public static IEnumerable<PayOutExportItemResponse> ToPayOutExportItemResponses(this IEnumerable<PayOutExport> payOutExports) =>
        payOutExports.Select(poe => new PayOutExportItemResponse
        {
            Id = poe.Id,
            Status = poe.Status.ToExportStatus(),
            CreatedAt = poe.CreatedAt
        });
}