using AccountingService.Dtos.Responses.Exact;
using AccountingUtils.Providers.Accounting.Exact.Responses;

namespace AccountingService.Utils.Adapter;

public static class ItemAdapter
{
    public static IEnumerable<MinimalItemResponse> ToMinimalItemResponses(this IEnumerable<ItemResponse> responses)
    {
        return responses.Select(ir => new MinimalItemResponse
        {
            Id = ir.Id,
            Code = ir.Code ?? string.Empty,
            Description = ir.Description
        });
    }
}