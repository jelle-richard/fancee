using AccountingService.Dtos.Requests.Exact;
using AccountingService.Dtos.Responses.Exact;
using FanceeData.Models.Ticketing.Exact;
using WebApiCore.Dtos.Shared;

namespace AccountingService.Utils.Adapter;

public static class ItemMappingAdapter
{
    /// <summary>
    /// Converts a list of <see cref="ConfigureItemRequest" /> to a list of <see cref="FanceeData.Models.Ticketing.Exact.ItemMapping" />.
    /// </summary>
    /// <param name="items"></param>
    /// <returns></returns>
    public static IEnumerable<ItemMapping> ToItemMappings(this IEnumerable<ConfigureItemRequest> items)
    {
        return items.SelectMany(
            i => i.CountryItems.Select(
                ci => new ItemMapping
                {
                    InvoiceRowSpecificationName = i.PlatformItem,
                    CountryCode = ci.CountryCode?.ToString(),
                    ExactItemCode = ci.ExactItemCode
                }
            ));
    }

    /// <summary>
    /// Converts a list of <see cref="ItemMapping" /> to a list of <see cref="ConfiguredItemResponse" />.
    /// </summary>
    /// <param name="mappings"></param>
    /// <returns></returns>
    public static IEnumerable<ConfiguredItemResponse> ToConfiguredItemResponses(this IEnumerable<ItemMapping> mappings)
    {
        return mappings.GroupBy(mi => mi.InvoiceRowSpecificationName)
            .Select(g => new ConfiguredItemResponse
            {
                PlatformItem = g.Key,
                CountryItems = g.Select(im => new CountryItem
                {
                    ExactItemCode = im.ExactItemCode,
                    CountryCode = im.CountryCode == null
                        ? null
                        : Enum.Parse<CountryCode>(im.CountryCode)
                })
            });
    }
}