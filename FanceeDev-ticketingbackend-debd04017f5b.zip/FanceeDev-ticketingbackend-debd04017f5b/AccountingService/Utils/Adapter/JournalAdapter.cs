using AccountingService.Dtos.Responses.Exact;
using AccountingUtils.Providers.Accounting.Exact.Responses;

namespace AccountingService.Utils.Adapter;

public static class JournalAdapter
{
    public static IEnumerable<MinimalJournalResponse> ToMinimalJournalResponses(this IEnumerable<JournalResponse> responses)
    {
        return responses.Select(jr => new MinimalJournalResponse
        {
            Id = jr.Id,
            Code = jr.Code,
            Description = jr.Description,
            Currency = jr.Currency
        });
    }
}