using ZipUtils.Dtos;

namespace AccountingService.Utils.Adapter;

public static class ZipAdapter
{
    /// <summary>
    /// Creates ZipEntries for the given file bytes.
    /// Replaces the literal {index} with the index of the file in the <see cref="fileContents" />.
    /// </summary>
    /// <param name="fileContents"></param>
    /// <param name="fileName"></param>
    /// <returns></returns>
    public static IEnumerable<ZipEntry> ToZipEntries(this IEnumerable<byte[]> fileContents, string fileName)
    {
        return fileContents.Select((bytes, index) => new ZipEntry
        {
            Bytes = bytes,
            FileName = fileName.Replace("{index}", $"{index + 1}")
        });
    }

    /// <summary>
    /// Converts the byte array to a <see cref="Stream" />.
    /// </summary>
    /// <param name="file"></param>
    /// <returns></returns>
    public static Stream ToStream(this byte[] file) => new MemoryStream(file);
}