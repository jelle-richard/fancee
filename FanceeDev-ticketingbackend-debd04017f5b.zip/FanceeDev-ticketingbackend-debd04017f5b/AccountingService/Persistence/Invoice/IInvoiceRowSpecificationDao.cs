namespace AccountingService.Persistence.Invoice;

public interface IInvoiceRowSpecificationDao
{
    /// <summary>
    /// Returns whether all the specification names are valid.
    /// </summary>
    /// <param name="specificationNames"></param>
    /// <returns></returns>
    public Task<bool> ValidAsync(IEnumerable<string> specificationNames);

    /// <summary>
    /// Gets all invoice row specification names.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<string>> NamesAsync();
}