using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace AccountingService.Persistence.Invoice;

public class InvoiceRowSpecificationDao : IInvoiceRowSpecificationDao
{
    private readonly TicketingContext _dbContext;

    public InvoiceRowSpecificationDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<bool> ValidAsync(IEnumerable<string> specificationNames)
    {
        var names = specificationNames.ToArray();

        return await _dbContext.InvoiceRowSpecifications
            .Where(irs => names.Contains(irs.Name))
            .CountAsync() == names.Length;
    }

    public async Task<IEnumerable<string>> NamesAsync() =>
        await _dbContext.InvoiceRowSpecifications.Select(irs => irs.Name)
            .ToListAsync();
}