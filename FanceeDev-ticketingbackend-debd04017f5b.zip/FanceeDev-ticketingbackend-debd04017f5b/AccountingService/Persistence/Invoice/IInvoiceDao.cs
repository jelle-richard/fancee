namespace AccountingService.Persistence.Invoice;

public interface IInvoiceDao
{
    /// <summary>
    /// Gets the invoice by it's id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<FanceeData.Models.Ticketing.Invoicing.Invoice?> ByIdAsync(int id);
}