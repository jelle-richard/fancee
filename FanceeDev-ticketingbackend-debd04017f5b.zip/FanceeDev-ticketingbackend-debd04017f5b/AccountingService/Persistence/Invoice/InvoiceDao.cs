using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace AccountingService.Persistence.Invoice;

public class InvoiceDao : IInvoiceDao
{
    private readonly TicketingContext _dbContext;

    public InvoiceDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<FanceeData.Models.Ticketing.Invoicing.Invoice?> ByIdAsync(int id)
    {
        return await _dbContext.Invoices.Where(i => i.Id == id)
            .Include(i => i.Rows)
            .Include(i => i.File)
            .Include(i => i.Organization)
            .Include(i => i.Organization.PaymentSettings)
            .Include(i => i.Organization.User.UserContactInfo)
            .Include(i => i.Organization.User.UserContactInfo.Address)
            .FirstOrDefaultAsync();
    }
}