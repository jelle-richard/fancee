using FanceeData.Models.Ticketing.Exact;

namespace AccountingService.Persistence.Exact;

public interface IExactDao
{
    /// <summary>
    /// Inserts a new Exact User
    /// </summary>
    /// <param name="exactUser"></param>
    /// <returns></returns>
    public Task InsertAsync(ExactUser exactUser);

    /// <summary>
    /// Gets the Exact account id by the invoice id.
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public Task<Guid?> ExactAccountIdByInvoiceId(int id);
}