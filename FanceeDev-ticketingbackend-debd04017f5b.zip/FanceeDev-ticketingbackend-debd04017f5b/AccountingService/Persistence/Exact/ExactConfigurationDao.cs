using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Exact;
using Microsoft.EntityFrameworkCore;

namespace AccountingService.Persistence.Exact;

public class ExactConfigurationDao : IExactConfigurationDao
{
    private readonly TicketingContext _dbContext;

    public ExactConfigurationDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<ExactConfiguration?> GetAsync() => await _dbContext.ExactConfigurations.FirstOrDefaultAsync();

    public async Task SetAsync(ExactConfiguration configuration)
    {
        var entityToRemove = await _dbContext.ExactConfigurations.FirstOrDefaultAsync();

        if (entityToRemove != null)
            _dbContext.ExactConfigurations.Remove(entityToRemove);

        await _dbContext.ExactConfigurations.AddAsync(configuration);
        await _dbContext.SaveChangesAsync();
    }
}