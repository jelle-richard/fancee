using FanceeData.Models.Ticketing.Exact;

namespace AccountingService.Persistence.Exact;

public interface IExactConfigurationDao
{
    /// <summary>
    /// Gets the configuration.
    /// </summary>
    /// <returns></returns>
    public Task<ExactConfiguration?> GetAsync();

    /// <summary>
    /// Sets the configuration.
    /// </summary>
    /// <param name="configuration"></param>
    /// <returns></returns>
    public Task SetAsync(ExactConfiguration configuration);
}