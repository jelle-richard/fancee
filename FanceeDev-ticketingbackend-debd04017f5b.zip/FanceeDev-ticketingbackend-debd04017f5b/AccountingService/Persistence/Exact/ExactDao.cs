using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Exact;
using Microsoft.EntityFrameworkCore;

namespace AccountingService.Persistence.Exact;

public class ExactDao : IExactDao
{
    private readonly TicketingContext _dbContext;

    public ExactDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task InsertAsync(ExactUser exactUser)
    {
        await _dbContext.ExactUsers.AddAsync(exactUser);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<Guid?> ExactAccountIdByInvoiceId(int id)
    {
        return await _dbContext.Invoices.Where(i => i.Id == id)
            .Select(i => (Guid?)i.Organization.User.ExactUser.ExactAccountId)
            .FirstOrDefaultAsync();
    }
}