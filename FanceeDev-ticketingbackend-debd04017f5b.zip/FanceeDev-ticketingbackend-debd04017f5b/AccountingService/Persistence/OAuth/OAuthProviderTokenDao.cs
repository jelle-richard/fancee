using FanceeData.Contexts;
using FanceeData.Models.Ticketing;
using Microsoft.EntityFrameworkCore;

namespace AccountingService.Persistence.OAuth;

public class OAuthProviderTokenDao(TicketingContext dbContext) : IOAuthProviderTokenDao
{
    public async Task AddAsync(OAuthProviderToken providerToken)
    {
        await dbContext.OAuthProviderTokens.AddAsync(providerToken);
        await dbContext.SaveChangesAsync();
    }

    public async Task UpdateAsync(OAuthProviderToken providerToken)
    {
        dbContext.OAuthProviderTokens.Update(providerToken);

        await dbContext.SaveChangesAsync();
    }

    public async Task<OAuthProviderToken?> ForProviderAsync(OAuthProvider provider)
    {
        return await dbContext.OAuthProviderTokens.Where(oact => oact.Provider == provider)
            .FirstOrDefaultAsync();
    }

    public async Task<bool> ExistsAsync(OAuthProvider provider, int? refreshExpireDays)
    {
        return await dbContext.OAuthProviderTokens
            .Where(oact => refreshExpireDays == null || oact.ValidUntil.AddDays((int)refreshExpireDays) > DateTime.UtcNow)
            .AnyAsync(oact => oact.Provider == provider);
    }
}