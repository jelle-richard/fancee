using FanceeData.Models.Ticketing;

namespace AccountingService.Persistence.OAuth;

public interface IOAuthProviderTokenDao
{
    /// <summary>
    /// Adds a providerToken.
    /// </summary>
    /// <param name="providerToken"></param>
    /// <returns></returns>
    public Task AddAsync(OAuthProviderToken providerToken);

    /// <summary>
    /// Updates the providerToken.
    /// </summary>
    /// <param name="providerToken"></param>
    /// <returns></returns>
    public Task UpdateAsync(OAuthProviderToken providerToken);

    /// <summary>
    /// Gets the OAuthProviderToken record for the provider.
    /// </summary>
    /// <param name="provider"></param>
    /// <returns></returns>
    public Task<OAuthProviderToken?> ForProviderAsync(OAuthProvider provider);

    /// <summary>
    /// Returns whether the provider has a OAuthProviderToken record.
    /// </summary>
    /// <param name="provider">Provider to check</param>
    /// <param name="refreshExpireDays">Optional parameter to check if the refresh token has expired</param>
    /// <returns></returns>
    public Task<bool> ExistsAsync(OAuthProvider provider, int? refreshExpireDays);
}