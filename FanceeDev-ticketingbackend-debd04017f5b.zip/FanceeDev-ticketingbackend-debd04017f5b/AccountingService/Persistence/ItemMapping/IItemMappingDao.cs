namespace AccountingService.Persistence.ItemMapping;

public interface IItemMappingDao
{
    /// <summary>
    /// Inserts one or more item mappings.
    /// </summary>
    /// <param name="mappings"></param>
    /// <returns></returns>
    public Task InsertAsync(params FanceeData.Models.Ticketing.Exact.ItemMapping[] mappings);

    /// <summary>
    /// Gets all item mappings.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<FanceeData.Models.Ticketing.Exact.ItemMapping>> ItemMappingsAsync();

    /// <summary>
    /// Gets the invoice row specification to Exact item mappings.
    /// </summary>
    /// <param name="invoiceRowSpecifications"></param>
    /// <param name="countryCode"></param>
    /// <returns></returns>
    public Task<Dictionary<string, Guid>> ItemMappingsAsync(IEnumerable<string> invoiceRowSpecifications, string countryCode);
}