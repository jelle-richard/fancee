using FanceeData.Contexts;
using Microsoft.EntityFrameworkCore;

namespace AccountingService.Persistence.ItemMapping;

public class ItemMappingDao : IItemMappingDao
{
    private readonly TicketingContext _dbContext;

    public ItemMappingDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task InsertAsync(params FanceeData.Models.Ticketing.Exact.ItemMapping[] mappings)
    {
        //note(Martijn): The Where statement is there because of a problem in Moq.EntityFrameworkCore, where it needs a method call.
        await _dbContext.ItemMappings.Where(im => true).ExecuteDeleteAsync();
        await _dbContext.ItemMappings.AddRangeAsync(mappings);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<IEnumerable<FanceeData.Models.Ticketing.Exact.ItemMapping>> ItemMappingsAsync() =>
        await _dbContext.ItemMappings.ToListAsync();

    public async Task<Dictionary<string, Guid>> ItemMappingsAsync(IEnumerable<string> invoiceRowSpecifications, string countryCode)
    {
        return await _dbContext.ItemMappings.Where(im => invoiceRowSpecifications.Contains(im.InvoiceRowSpecificationName))
            .Where(im => new[] { null, countryCode }.Contains(im.CountryCode))
            .GroupBy(im => im.InvoiceRowSpecificationName)
            .Select(g => g.OrderByDescending(im => im.CountryCode).First())
            .ToDictionaryAsync(im => im.InvoiceRowSpecificationName, im => im.ExactItemCode);
    }
}