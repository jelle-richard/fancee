using FanceeData.Contexts;
using FanceeData.Models.Ticketing.Invoicing;
using Microsoft.EntityFrameworkCore;
using WebApiCore.Dtos.Shared;
using File = FanceeData.Models.Ticketing.File;

namespace AccountingService.Persistence.PayOut;

public class PayOutDao : IPayOutDao
{
    private readonly TicketingContext _dbContext;

    public PayOutDao(TicketingContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<WalletPayment>> UnprocessedWalletPaymentsAsync()
    {
        return await _dbContext.WalletPayments.Where(wp => wp.ProcessedAt == null)
            .Where(wp => wp.Type == WalletPaymentType.Debit)
            .Where(wp => !wp.Organization.IsDemo)
            .Where(wp => !wp.PayOutExports.Any())
            .Include(wp => wp.Organization)
            .Include(wp => wp.Organization.PaymentSettings)
            .ToListAsync();
    }

    public async Task<int> UnprocessedWalletPaymentsAmountAsync()
    {
        return await _dbContext.WalletPayments.Where(wp => wp.ProcessedAt == null)
            .Where(wp => wp.Type == WalletPaymentType.Debit)
            .Where(wp => !wp.Organization.IsDemo)
            .Where(wp => !wp.PayOutExports.Any())
            .CountAsync();
    }

    public async Task UpdateWalletPaymentsAsync(IEnumerable<WalletPayment> walletPayments)
    {
        _dbContext.WalletPayments.UpdateRange(walletPayments);
        await _dbContext.SaveChangesAsync();
    }

    public async Task InsertAsync(PayOutExport payOutExport)
    {
        await _dbContext.PayOutExports.AddAsync(payOutExport);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<File?> FileAsync(Guid exportId)
    {
        return await _dbContext.PayOutExports.Where(poe => poe.Id == exportId)
            .Select(poe => poe.File)
            .FirstOrDefaultAsync();
    }

    public async Task<PayOutExport?> ByIdAsync(Guid exportId)
    {
        return await _dbContext.PayOutExports.Include(poe => poe.WalletPayments).FirstOrDefaultAsync(poe => poe.Id == exportId);
    }

    public async Task UpdateAsync(PayOutExport payOutExport)
    {
        _dbContext.PayOutExports.Update(payOutExport);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<PaginatedResultSet<PayOutExport>> ListAsync(int limit, int offset, string? searchQuery, PayOutExportStatus? status)
    {
        var exports = _dbContext.PayOutExports.AsQueryable();

        if (!string.IsNullOrWhiteSpace(searchQuery))
            exports = exports.Where(poe => poe.Id.ToString().Contains(searchQuery));

        if (status != null)
            exports = exports.Where(poe => poe.Status == status);

        exports = exports.OrderByDescending(poe => poe.CreatedAt);

        var totalCount = await exports.CountAsync();
        var items = await exports.Skip(offset)
            .Take(limit)
            .ToListAsync();

        return new()
        {
            TotalItems = totalCount,
            Items = items
        };
    }
}