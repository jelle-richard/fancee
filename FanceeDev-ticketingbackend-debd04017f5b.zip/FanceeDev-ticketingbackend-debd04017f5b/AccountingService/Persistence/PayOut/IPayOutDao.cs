using FanceeData.Models.Ticketing.Invoicing;
using WebApiCore.Dtos.Shared;
using File = FanceeData.Models.Ticketing.File;

namespace AccountingService.Persistence.PayOut;

public interface IPayOutDao
{
    /// <summary>
    /// Gets all unprocessed wallet payments.
    /// </summary>
    /// <returns></returns>
    public Task<IEnumerable<WalletPayment>> UnprocessedWalletPaymentsAsync();

    /// <summary>
    /// Counts all unprocessed wallet payments.
    /// </summary>
    /// <returns></returns>
    public Task<int> UnprocessedWalletPaymentsAmountAsync();

    /// <summary>
    /// Updates all the wallet payments.
    /// </summary>
    /// <param name="walletPayments"></param>
    /// <returns></returns>
    public Task UpdateWalletPaymentsAsync(IEnumerable<WalletPayment> walletPayments);

    /// <summary>
    /// Inserts a new PayOutExport.
    /// </summary>
    /// <param name="payOutExport"></param>
    /// <returns></returns>
    public Task InsertAsync(PayOutExport payOutExport);

    /// <summary>
    /// Gets the file of the export.
    /// </summary>
    /// <param name="exportId"></param>
    /// <returns></returns>
    public Task<File?> FileAsync(Guid exportId);

    /// <summary>
    /// Gets the pay out export by id.
    /// </summary>
    /// <param name="exportId"></param>
    /// <returns></returns>
    public Task<PayOutExport?> ByIdAsync(Guid exportId);

    /// <summary>
    /// Updates the pay out export.
    /// </summary>
    /// <param name="payOutExport"></param>
    /// <returns></returns>
    public Task UpdateAsync(PayOutExport payOutExport);

    /// <summary>
    /// Lists the pay out exports.
    /// </summary>
    /// <param name="limit"></param>
    /// <param name="offset"></param>
    /// <param name="searchQuery"></param>
    /// <param name="status"></param>
    /// <returns></returns>
    public Task<PaginatedResultSet<PayOutExport>> ListAsync(int limit, int offset, string? searchQuery, PayOutExportStatus? status);
}