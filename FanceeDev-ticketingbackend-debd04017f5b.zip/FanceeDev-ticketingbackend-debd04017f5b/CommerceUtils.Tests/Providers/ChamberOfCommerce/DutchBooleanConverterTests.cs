﻿using System.Buffers;
using System.IO;
using System.Text;
using System.Text.Json;
using CommerceUtils.Providers.ChamberOfCommerce;

namespace CommerceUtils.Tests.Providers.ChamberOfCommerce;

public class DutchBooleanConverterTests
{
    private readonly DutchBooleanConverter _sut = new();

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfTokenTypeIsNotString()
    {
        Assert.Throws<JsonException>(() =>
        {
            var json = "{\"key\":2}";
            var reader = GetReader(json);

            reader.Read();
            reader.Read();
            reader.Read();

            _sut.Read(ref reader, typeof(bool), new());
        });
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfValueIsNotValidBoolean()
    {
        Assert.Throws<JsonException>(() =>
        {
            var json = "{\"key\":\"invalid\"}";
            var reader = GetReader(json);

            reader.Read();
            reader.Read();
            reader.Read();

            _sut.Read(ref reader, typeof(bool), new());
        });
    }

    [Theory]
    [InlineData("ja", true)]
    [InlineData("JA", true)]
    [InlineData("Ja", true)]
    [InlineData("jA", true)]
    [InlineData("nee", false)]
    [InlineData("NEE", false)]
    [InlineData("Nee", false)]
    [InlineData("NEe", false)]
    [InlineData("NeE", false)]
    [InlineData("neE", false)]
    [InlineData("nEE", false)]
    public void TestThatReadParsesDutchBooleanName(string name, bool expected)
    {
        var json = $"{{\"key\":\"{name}\"}}";

        var reader = GetReader(json);

        reader.Read();
        reader.Read();
        reader.Read();

        var actual = _sut.Read(ref reader, typeof(bool), new());

        Assert.Equal(expected, actual);
    }

    [Theory]
    [InlineData(true, "ja")]
    [InlineData(false, "nee")]
    public void TestThatWriteWritesExpectedString(bool input, string expected)
    {
        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, input, new());

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal($"\"{expected}\"", actual);
    }

    private static Utf8JsonReader GetReader(string json)
    {
        var sequence = new ReadOnlySequence<byte>(Encoding.UTF8.GetBytes(json));

        return new(sequence);
    }
}