﻿using System;
using System.Buffers;
using System.IO;
using System.Text;
using System.Text.Json;
using CommerceUtils.Providers.ChamberOfCommerce;

namespace CommerceUtils.Tests.Providers.ChamberOfCommerce;

public class ChamberOfCommerceDateConverterTests
{
    public static readonly object[][] ReadTestData =
    {
        new object[] { "20220203", new DateOnly(2022, 2, 3) },
        new object[] { "20221200", new DateOnly(2022, 12, 1) },
        new object[] { "20220022", new DateOnly(2022, 1, 22) },
        new object[] { "00001231", new DateOnly(DateTime.Now.Year, 12, 31) }
    };

    private readonly ChamberOfCommerceDateConverter _sut = new();

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfTokenTypeIsNotString()
    {
        Assert.Throws<JsonException>(() =>
        {
            var json = "{\"key\":2}";
            var reader = GetReader(json);

            reader.Read();
            reader.Read();
            reader.Read();

            _sut.Read(ref reader, typeof(DateOnly?), new());
        });
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfValueIsEmpty()
    {
        Assert.Throws<JsonException>(() =>
        {
            var json = "{\"key\":\"\"}";
            var reader = GetReader(json);

            reader.Read();
            reader.Read();
            reader.Read();

            _sut.Read(ref reader, typeof(DateOnly?), new());
        });
    }

    [Fact]
    public void TestThatReadThrowsJsonExceptionIfValueIsInvalid()
    {
        Assert.Throws<JsonException>(() =>
        {
            var json = "{\"key\":\"invalid\"}";
            var reader = GetReader(json);

            reader.Read();
            reader.Read();
            reader.Read();

            _sut.Read(ref reader, typeof(DateOnly?), new());
        });
    }

    [Fact]
    public void TestThatReadReturnsNullIfValueIsEightZeros()
    {
        var json = "{\"key\":\"00000000\"}";
        var reader = GetReader(json);

        reader.Read();
        reader.Read();
        reader.Read();

        var actual = _sut.Read(ref reader, typeof(DateOnly?), new());

        Assert.Null(actual);
    }

    [Theory]
    [MemberData(nameof(ReadTestData))]
    public void TestThatReadReturnsExpectedResult(string input, DateOnly expected)
    {
        var json = $"{{\"key\":\"{input}\"}}";
        var reader = GetReader(json);

        reader.Read();
        reader.Read();
        reader.Read();

        var actual = _sut.Read(ref reader, typeof(DateOnly?), new());

        Assert.Equal(expected, actual);
    }

    [Fact]
    public void TestThatWriteWritesNullIfDateOnlyIsNull()
    {
        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, null, new());

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal("null", actual);
    }

    [Fact]
    public void TestThatWriteWritesStringForDateOnly()
    {
        var stream = new MemoryStream();
        var writer = new Utf8JsonWriter(stream, new() { Indented = false });

        _sut.Write(writer, new DateOnly(2022, 10, 4), new());

        writer.Flush();
        var actual = Encoding.UTF8.GetString(stream.ToArray());

        Assert.Equal("\"20221004\"", actual);
    }

    private static Utf8JsonReader GetReader(string json)
    {
        var sequence = new ReadOnlySequence<byte>(Encoding.UTF8.GetBytes(json));

        return new(sequence);
    }
}