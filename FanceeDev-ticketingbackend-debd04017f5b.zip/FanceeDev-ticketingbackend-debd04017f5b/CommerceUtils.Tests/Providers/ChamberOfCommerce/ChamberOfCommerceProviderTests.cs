﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using CommerceUtils.Providers.ChamberOfCommerce;
using CommerceUtils.Providers.Models;
using CommerceUtils.Utils;
using Moq.Protected;

namespace CommerceUtils.Tests.Providers.ChamberOfCommerce;

public class ChamberOfCommerceProviderTests
{
    private readonly ChamberOfCommerceProvider _sut;
    private readonly Mock<HttpMessageHandler> _mockedHandler = new();
    private readonly Mock<ICustomCertificateHttpClient> _mockedCustomCertificateHttpClient = new();

    public ChamberOfCommerceProviderTests()
    {
        _mockedCustomCertificateHttpClient.Setup(cchc => cchc.AddCertificate(It.IsAny<string>())).Returns(_mockedCustomCertificateHttpClient.Object);
        _mockedCustomCertificateHttpClient.Setup(cchc => cchc.AddDefaultHeader(It.IsAny<string>(), It.IsAny<string>())).Returns(_mockedCustomCertificateHttpClient.Object);
        _mockedCustomCertificateHttpClient.Setup(cchc => cchc.SetTimeout(It.IsAny<TimeSpan>())).Returns(_mockedCustomCertificateHttpClient.Object);
        _mockedCustomCertificateHttpClient.Setup(cchc => cchc.Build()).Returns(new HttpClient(_mockedHandler.Object));

        _sut = new(_mockedCustomCertificateHttpClient.Object, "https://developers.kvk.nl/api/v2", "apikey");
    }

    [Fact]
    public void TestThatConstructorSetsTimeoutAndAddsCertificate()
    {
        var mock = new Mock<ICustomCertificateHttpClient>();
        mock.Setup(cchc => cchc.AddCertificate(It.IsAny<string>())).Returns(mock.Object);
        mock.Setup(cchc => cchc.AddDefaultHeader("apikey", It.IsAny<string>())).Returns(mock.Object);
        mock.Setup(cchc => cchc.SetTimeout(It.IsAny<TimeSpan>())).Returns(mock.Object);

        var _ = new ChamberOfCommerceProvider(mock.Object, "https://developers.kvk.nl/api/v2", "apikey");

        mock.Verify(cchc => cchc.AddCertificate("Staat_der_Nederlanden_Private_Root_CA_-_G1.cer"), Times.Once);
        mock.Verify(cchc => cchc.AddDefaultHeader("apikey", It.IsAny<string>()), Times.Once);
        mock.Verify(cchc => cchc.SetTimeout(TimeSpan.FromSeconds(10)), Times.Once);
        mock.Verify(cchc => cchc.Build(), Times.Once);
        mock.VerifyNoOtherCalls();
    }

    [Fact]
    public void TestThatSupportedCountryReturnsNlCountryCode()
    {
        Assert.Equal(CountryCode.NL, _sut.SupportedCountry());
    }

    [Fact]
    public async Task TestThatServiceHealthyAsyncCallsSslTestEndpoint()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK));

        var actual = await _sut.ServiceHealthyAsync();

        Assert.True(actual);

        _mockedHandler.Protected().Verify("SendAsync",
            Times.Once(),
            ItExpr.Is<HttpRequestMessage>(m => m.RequestUri!.ToString() == "https://ssltest.kvk.nl/"),
            ItExpr.IsAny<CancellationToken>());
    }

    [Fact]
    public async Task TestThatServiceHealthyAsyncReturnsFalseWhenStatusCodeIsNot200()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.BadGateway));

        var actual = await _sut.ServiceHealthyAsync();

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatServiceHealthyAsyncReturnsFalseOnException()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ThrowsAsync(new());

        var actual = await _sut.ServiceHealthyAsync();

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatIsValidAsyncReturnsTrueForValidIdentifier()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(Json("ValidKvkSearchResponse"), Encoding.UTF8, "application/json")
            });

        var actual = await _sut.IsValidAsync("68750110");

        Assert.True(actual);
    }

    [Fact]
    public async Task TestThatIsValidAsyncReturnsFalseForInvalidIdentifier()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.BadRequest));

        var actual = await _sut.IsValidAsync("invalid");

        Assert.False(actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsNullOnNon200StatusCode()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.BadRequest));

        var actual = await _sut.InfoAsync("68750110");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatGetAsyncReturnsNullOnException()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ThrowsAsync(new());

        var actual = await _sut.InfoAsync("68750110");

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatInfoAsyncReturnsCompanyInfoForValidIdentifier()
    {
        _mockedHandler.Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(Json("ValidKvkProfileResponse"), Encoding.UTF8, "application/json")
            });

        var actual = await _sut.InfoAsync("68750110");

        Assert.NotNull(actual);
        Assert.Equal(CountryCode.NL, actual!.Address?.Country);
        Assert.Equal("Hizzaarderlaan", actual.Address?.Street);
        Assert.Equal("3A", actual.Address?.HouseNumber);
        Assert.Equal("8823SJ", actual.Address?.PostalCode);
        Assert.Equal("Lollum", actual.Address?.City);
        Assert.Single(actual.BusinessNames);
        Assert.Equal("Test BV Donald", actual.BusinessNames.First());
    }

    private static string Json(string file) => File.ReadAllText($"./Mocks/{file}.json");
}