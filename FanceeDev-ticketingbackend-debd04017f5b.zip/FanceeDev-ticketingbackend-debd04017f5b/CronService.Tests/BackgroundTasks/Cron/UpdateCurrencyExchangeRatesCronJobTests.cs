﻿using System;
using CronService.BackgroundTasks.Cron;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Currency;

namespace CronService.Tests.BackgroundTasks.Cron;

public class UpdateCurrencyExchangeRatesCronJobTests
{
    private readonly UpdateCurrencyExchangeRatesCronJob _sut = new();

    [Fact]
    public void TestThatConfigureDependenciesGetsMessagePublisher()
    {
        var mockedPublisher = new Mock<IMessagePublisher<UpdateCurrencyExchangeRatesMessage>>();
        var mockedLogger = new Mock<ILogger<UpdateCurrencyExchangeRatesCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<UpdateCurrencyExchangeRatesMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<UpdateCurrencyExchangeRatesCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create());

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<UpdateCurrencyExchangeRatesMessage>)), Times.Once);
    }

    [Fact]
    public void TestThatDoWorkCallsPublisher()
    {
        var mockedPublisher = new Mock<IMessagePublisher<UpdateCurrencyExchangeRatesMessage>>();
        var mockedLogger = new Mock<ILogger<UpdateCurrencyExchangeRatesCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<UpdateCurrencyExchangeRatesMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<UpdateCurrencyExchangeRatesCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create());

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        _sut.DoWork();

        mockedPublisher.Verify(p => p.Call(It.IsAny<UpdateCurrencyExchangeRatesMessage>()), Times.Once);
        mockedLogger.VerifyCalled(LogLevel.Information, "[UpdateCurrencyExchangeRatesCronJob] Sending cron message");
    }

    [Fact]
    public void TestThatGetIntervalGetsIntervalFromConfiguration()
    {
        var mockedConfig = ConfigurationMockUtils.Create(new()
        {
            { "CronIntervals:UpdateCurrencyExchangeRates", "0.00:42:00" }
        });

        var mockedPublisher = new Mock<IMessagePublisher<UpdateCurrencyExchangeRatesMessage>>();
        var mockedLogger = new Mock<ILogger<UpdateCurrencyExchangeRatesCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<UpdateCurrencyExchangeRatesMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<UpdateCurrencyExchangeRatesCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(mockedConfig);

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromMinutes(42), actual);
    }

    [Fact]
    public void TestThatDefaultIntervalIs24Hours()
    {
        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromHours(24), actual);
    }
}