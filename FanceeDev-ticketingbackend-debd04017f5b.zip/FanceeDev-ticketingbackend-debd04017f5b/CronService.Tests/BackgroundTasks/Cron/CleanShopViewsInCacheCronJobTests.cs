using CronService.BackgroundTasks.Cron;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.ShopViews;

namespace CronService.Tests.BackgroundTasks.Cron;

public class CleanShopViewsInCacheCronJobTests
{
    private readonly CleanShopViewsInCacheCronJob _sut;
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<IMessagePublisher<CleanShopViewsInCacheMessage>> _mockedPublisher = new();
    private readonly Mock<ILogger<CleanShopViewsInCacheCronJob>> _mockedLogger = new();
    private readonly Dictionary<string, string?> _config = new();

    public CleanShopViewsInCacheCronJobTests()
    {
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<CleanShopViewsInCacheMessage>))).Returns(_mockedPublisher.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<CleanShopViewsInCacheCronJob>))).Returns(_mockedLogger.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut = new();
    }

    [Fact]
    public void TestThatConfigureDependenciesGetsRequiredServices()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<CleanShopViewsInCacheMessage>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(ILogger<CleanShopViewsInCacheCronJob>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IConfiguration)), Times.Once);
    }

    [Fact]
    public void TestThatGetIntervalGetsIntervalFromConfiguration()
    {
        _config.Add("CronIntervals:WriteShopViewsInCacheToDb", "0.00:01:00");
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromMinutes(1), actual);
    }

    [Fact]
    public void TestThatDefaultIntervalIs30Seconds()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromSeconds(30), actual);
    }

    [Fact]
    public void TestThatExecuteCallsPublisher()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _sut.Execute();

        _mockedLogger.VerifyCalled(LogLevel.Information, "[CleanShopViewsInCacheCronJob] Removing shop views in cache and write to database");
        _mockedPublisher.Verify(p => p.Call(It.IsAny<CleanShopViewsInCacheMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatConcludeEventsCronJobLogsStaleLogAfterFiveSkippedRpcCalls()
    {
        _mockedPublisher.Setup(p => p.Call(It.IsAny<CleanShopViewsInCacheMessage>())).Returns(() =>
        {
            Task.Delay(250).Wait();
            return "ok";
        });

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var t1 = Task.Run(() => _sut.DoWork());
        var t2 = Task.Run(() => _sut.DoWork());

        await t1;
        await t2;

        _mockedLogger.VerifyCalled(LogLevel.Critical, "[CleanShopViewsInCacheCronJob] Cron skipped 1 iterations after each other. This could mean a hanging RPC call");
    }
}