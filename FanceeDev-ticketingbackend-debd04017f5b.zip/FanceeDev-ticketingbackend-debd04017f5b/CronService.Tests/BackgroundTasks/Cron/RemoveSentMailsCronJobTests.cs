using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CronService.BackgroundTasks.Cron;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Mail;

namespace CronService.Tests.BackgroundTasks.Cron;

public class RemoveSentMailsCronJobTests
{
    private readonly RemoveSentMailsCronJob _sut;
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<IMessagePublisher<RemoveSentMailsMessage>> _mockedPublisher = new();
    private readonly Mock<ILogger<RemoveSentMailsCronJob>> _mockedLogger = new();
    private readonly Dictionary<string, string?> _config = new();

    public RemoveSentMailsCronJobTests()
    {
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<RemoveSentMailsMessage>))).Returns(_mockedPublisher.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<RemoveSentMailsCronJob>))).Returns(_mockedLogger.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut = new();
    }

    [Fact]
    public void TestThatConfigureDependenciesGetsRequiredServices()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<RemoveSentMailsMessage>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(ILogger<RemoveSentMailsCronJob>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IConfiguration)), Times.Once);
    }

    [Fact]
    public void TestThatGetIntervalGetsIntervalFromConfiguration()
    {
        _config.Add("CronIntervals:RemoveSentMails", "0.01:00:00");
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromHours(1), actual);
    }

    [Fact]
    public void TestThatDefaultIntervalIs1Hour()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromMinutes(15), actual);
    }

    [Fact]
    public void TestThatExecuteCallsPublisher()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _sut.Execute();

        _mockedLogger.VerifyCalled(LogLevel.Information, "[RemoveSentMailsCronJob] Sending remove sent mails cron message");
        _mockedPublisher.Verify(p => p.Call(It.IsAny<RemoveSentMailsMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatConcludeEventsCronJobLogsStaleLogAfterFiveSkippedRpcCalls()
    {
        _mockedPublisher.Setup(p => p.Call(It.IsAny<RemoveSentMailsMessage>())).Returns(() =>
        {
            Task.Delay(250).Wait();
            return "ok";
        });

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var t1 = Task.Run(() => _sut.DoWork());
        var t2 = Task.Run(() => _sut.DoWork());
        var t3 = Task.Run(() => _sut.DoWork());
        var t4 = Task.Run(() => _sut.DoWork());
        var t5 = Task.Run(() => _sut.DoWork());
        var t6 = Task.Run(() => _sut.DoWork());

        await t1;
        await t2;
        await t3;
        await t4;
        await t5;
        await t6;

        _mockedLogger.VerifyCalled(LogLevel.Critical, "[RemoveSentMailsCronJob] Cron skipped 5 iterations after each other. This could mean a hanging RPC call");
    }
}