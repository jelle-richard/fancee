using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CronService.BackgroundTasks.Cron;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Event;

namespace CronService.Tests.BackgroundTasks.Cron;

public class ConcludeEventsCronJobTests
{
    private readonly ConcludeEventsCronJob _sut;
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<IMessagePublisher<ConcludeEventsMessage>> _mockedPublisher = new();
    private readonly Mock<ILogger<ConcludeEventsCronJob>> _mockedLogger = new();
    private readonly Dictionary<string, string?> _config = new();

    public ConcludeEventsCronJobTests()
    {
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<ConcludeEventsMessage>))).Returns(_mockedPublisher.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<ConcludeEventsCronJob>))).Returns(_mockedLogger.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut = new();
    }

    [Fact]
    public void TestThatConfigureDependenciesGetsRequiredServices()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<ConcludeEventsMessage>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(ILogger<ConcludeEventsCronJob>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IConfiguration)), Times.Once);
    }

    [Fact]
    public void TestThatGetIntervalGetsIntervalFromConfiguration()
    {
        _config.Add("CronIntervals:ConcludeEvents", "0.00:02:00");
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromMinutes(2), actual);
    }

    [Fact]
    public void TestThatDefaultIntervalIs30Seconds()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromSeconds(30), actual);
    }

    [Fact]
    public void TestThatExecuteCallsPublisher()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _sut.Execute();

        _mockedLogger.VerifyCalled(LogLevel.Information, "[ConcludeEventsCronJob] Sending conclude events cron message");
        _mockedPublisher.Verify(p => p.Call(It.IsAny<ConcludeEventsMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatConcludeEventsCronJobLogsStaleLogAfterFiveSkippedRpcCalls()
    {
        _mockedPublisher.Setup(p => p.Call(It.IsAny<ConcludeEventsMessage>())).Returns(() =>
        {
            Task.Delay(250).Wait();
            return "ok";
        });

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var t1 = Task.Run(() => _sut.DoWork());
        var t2 = Task.Run(() => _sut.DoWork());
        var t3 = Task.Run(() => _sut.DoWork());
        var t4 = Task.Run(() => _sut.DoWork());
        var t5 = Task.Run(() => _sut.DoWork());
        var t6 = Task.Run(() => _sut.DoWork());

        await t1;
        await t2;
        await t3;
        await t4;
        await t5;
        await t6;

        _mockedLogger.VerifyCalled(LogLevel.Critical, "[ConcludeEventsCronJob] Cron skipped 5 iterations after each other. This could mean a hanging RPC call");
    }
}