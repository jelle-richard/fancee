﻿using System;
using System.Threading.Tasks;
using CronService.BackgroundTasks.Cron;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Mail;

namespace CronService.Tests.BackgroundTasks.Cron;

public class SendMailQueueCronJobTests
{
    private readonly SendMailQueueCronJob _sut;

    public SendMailQueueCronJobTests()
    {
        _sut = new();
    }

    [Fact]
    public void TestThatConfigureDependenciesGetsMessagePublisher()
    {
        var mockedPublisher = new Mock<IMessagePublisher<SendMailQueueMessage>>();
        var mockedLogger = new Mock<ILogger<SendMailQueueCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<SendMailQueueMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<SendMailQueueCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create());

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<SendMailQueueMessage>)), Times.Once);
    }

    [Fact]
    public void TestThatDoWorkCallsPublisher()
    {
        var mockedPublisher = new Mock<IMessagePublisher<SendMailQueueMessage>>();
        var mockedLogger = new Mock<ILogger<SendMailQueueCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<SendMailQueueMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<SendMailQueueCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create());

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        _sut.DoWork();

        mockedPublisher.Verify(p => p.Call(It.IsAny<SendMailQueueMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDoWorkDoesNotCallPublisherTwiceIfFirstCallIsNotYetFinished()
    {
        var mockedPublisher = new Mock<IMessagePublisher<SendMailQueueMessage>>();
        var mockedLogger = new Mock<ILogger<SendMailQueueCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<SendMailQueueMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<SendMailQueueCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create());

        mockedPublisher.Setup(p => p.Call(It.IsAny<SendMailQueueMessage>())).Returns(() =>
        {
            Task.Delay(50).Wait();
            return "ok";
        });

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        var t1 = Task.Run(() => _sut.DoWork());
        var t2 = Task.Run(() => _sut.DoWork());

        await t1;
        await t2;

        mockedPublisher.Verify(p => p.Call(It.IsAny<SendMailQueueMessage>()), Times.Once);
        mockedLogger.VerifyCalled(LogLevel.Information, "[SendMailQueueCronJob] Previous iteration is still working after 00:01:00. Skipping iteration");
    }

    [Fact]
    public async Task TestThatDoWorkLogsMessageIfCronIsSkippedFiveTimes()
    {
        var mockedPublisher = new Mock<IMessagePublisher<SendMailQueueMessage>>();
        var mockedLogger = new Mock<ILogger<SendMailQueueCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<SendMailQueueMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<SendMailQueueCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create());

        mockedPublisher.Setup(p => p.Call(It.IsAny<SendMailQueueMessage>())).Returns(() =>
        {
            Task.Delay(250).Wait();
            return "ok";
        });

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        var t1 = Task.Run(() => _sut.DoWork());
        var t2 = Task.Run(() => _sut.DoWork());
        var t3 = Task.Run(() => _sut.DoWork());
        var t4 = Task.Run(() => _sut.DoWork());
        var t5 = Task.Run(() => _sut.DoWork());
        var t6 = Task.Run(() => _sut.DoWork());

        await t1;
        await t2;
        await t3;
        await t4;
        await t5;
        await t6;

        mockedPublisher.Verify(p => p.Call(It.IsAny<SendMailQueueMessage>()), Times.Once);
        mockedLogger.VerifyCalled(LogLevel.Critical, "[SendMailQueueCronJob] Cron skipped 5 iterations after each other. This could mean a hanging RPC call");
    }

    [Fact]
    public void TestThatGetIntervalGetsIntervalFromConfiguration()
    {
        var mockedConfig = ConfigurationMockUtils.Create(new()
        {
            { "CronIntervals:SendMailQueue", "0.00:42:00" }
        });

        var mockedPublisher = new Mock<IMessagePublisher<SendMailQueueMessage>>();
        var mockedLogger = new Mock<ILogger<SendMailQueueCronJob>>();
        var mockedServiceScope = new Mock<IServiceScope>();
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<SendMailQueueMessage>))).Returns(mockedPublisher.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<SendMailQueueCronJob>))).Returns(mockedLogger.Object);
        mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(mockedConfig);

        _sut.ConfigureDependencies(mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromMinutes(42), actual);
    }

    [Fact]
    public void TestThatDefaultIntervalIs60Seconds()
    {
        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromSeconds(60), actual);
    }
}