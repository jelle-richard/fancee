﻿using System;
using System.Threading.Tasks;
using CronService.BackgroundTasks.Cron;
using Microsoft.Extensions.DependencyInjection;

namespace CronService.Tests.BackgroundTasks.Cron;

public class CronTests
{
    private readonly Mock<IServiceProvider> _mockedServiceProvider;

    public CronTests()
    {
        var mockedScopeProvider = new Mock<IServiceScopeFactory>();
        _mockedServiceProvider = new();
        _mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedScopeProvider.Object);
        mockedScopeProvider.Setup(sp => sp.CreateScope()).Returns(new Mock<IServiceScope>().Object);
    }

    [Fact]
    public void TestThatCronCallsConfigureDependencies()
    {
        var sut = new Cron<UnitTestCronJob>(_mockedServiceProvider.Object);

        Assert.NotNull(sut.CronJob.ServiceScope);

        sut.Dispose();
    }

    [Fact]
    public async Task TestThatStartAsyncStartsTimer()
    {
        var sut = new Cron<UnitTestCronJob>(_mockedServiceProvider.Object);

        await sut.StartAsync(default);

        await Task.Delay(250);

        await sut.StopAsync(default);

        Assert.True(sut.CronJob.Counter > 0);

        sut.Dispose();
    }

    [Fact]
    public async Task TestThatStopAsyncStopsTimer()
    {
        var sut = new Cron<UnitTestCronJob>(_mockedServiceProvider.Object);

        await sut.StartAsync(default);

        await Task.Delay(250);

        await sut.StopAsync(default);

        var currentCount = sut.CronJob.Counter;

        await Task.Delay(250);

        Assert.Equal(currentCount, sut.CronJob.Counter);

        sut.Dispose();
    }

    public class UnitTestCronJob : ICronJob
    {
        public IServiceScope? ServiceScope { get; private set; }
        public int Counter { get; private set; }

        public TimeSpan GetInterval() => TimeSpan.FromMilliseconds(125);

        public void ConfigureDependencies(IServiceScope serviceProvider)
        {
            ServiceScope = serviceProvider;
        }

        public void DoWork()
        {
            Counter++;

            Task.Delay(75).Wait();
        }
    }
}