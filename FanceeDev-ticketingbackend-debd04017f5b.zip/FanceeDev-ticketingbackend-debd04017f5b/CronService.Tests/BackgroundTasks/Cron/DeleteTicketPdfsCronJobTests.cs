using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CronService.BackgroundTasks.Cron;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Pdf;

namespace CronService.Tests.BackgroundTasks.Cron;

public class DeleteTicketPdfsCronJobTests
{
    private readonly DeleteTicketPdfsCronJob _sut;
    private readonly Mock<IServiceScope> _mockedServiceScope = new();
    private readonly Mock<IMessagePublisher<DeleteTicketPdfsMessage>> _mockedPublisher = new();
    private readonly Mock<ILogger<DeleteTicketPdfsCronJob>> _mockedLogger = new();
    private readonly Dictionary<string, string?> _config = new();

    public DeleteTicketPdfsCronJobTests()
    {
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<DeleteTicketPdfsMessage>))).Returns(_mockedPublisher.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(ILogger<DeleteTicketPdfsCronJob>))).Returns(_mockedLogger.Object);
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut = new();
    }

    [Fact]
    public void TestThatConfigureDependenciesGetsRequiredServices()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IMessagePublisher<DeleteTicketPdfsMessage>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(ILogger<DeleteTicketPdfsCronJob>)), Times.Once);
        _mockedServiceScope.Verify(ss => ss.ServiceProvider.GetService(typeof(IConfiguration)), Times.Once);
    }

    [Fact]
    public void TestThatGetIntervalGetsIntervalFromConfiguration()
    {
        _config.Add("CronIntervals:DeleteTicketPdfs", "0.00:02:00");
        _mockedServiceScope.Setup(ss => ss.ServiceProvider.GetService(typeof(IConfiguration))).Returns(ConfigurationMockUtils.Create(_config));

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromMinutes(2), actual);
    }

    [Fact]
    public void TestThatDefaultIntervalIsOneMinute()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var actual = _sut.GetInterval();

        Assert.Equal(TimeSpan.FromSeconds(60), actual);
    }

    [Fact]
    public void TestThatExecuteCallsPublisher()
    {
        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        _sut.Execute();

        _mockedLogger.VerifyCalled(LogLevel.Information, "[DeleteTicketPdfsCronJob] Sending cron message");
        _mockedPublisher.Verify(p => p.Call(It.IsAny<DeleteTicketPdfsMessage>()), Times.Once);
    }

    [Fact]
    public async Task TestThatDeleteTicketPdfsCronJobLogsStaleLogAfterOneSkippedRpcCall()
    {
        _mockedPublisher.Setup(p => p.Call(It.IsAny<DeleteTicketPdfsMessage>()))
            .Returns(() =>
            {
                Task.Delay(250).Wait();
                return "ok";
            });

        _sut.ConfigureDependencies(_mockedServiceScope.Object);

        var t1 = Task.Run(() => _sut.DoWork());
        var t2 = Task.Run(() => _sut.DoWork());

        await t1;
        await t2;

        _mockedLogger.VerifyCalled(LogLevel.Critical, "[DeleteTicketPdfsCronJob] Cron skipped 1 iterations after each other. This could mean a hanging RPC call");
    }
}