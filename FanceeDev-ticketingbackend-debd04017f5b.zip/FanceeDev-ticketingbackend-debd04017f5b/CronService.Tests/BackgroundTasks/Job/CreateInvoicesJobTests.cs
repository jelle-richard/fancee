using System;
using System.Threading.Tasks;
using CronService.BackgroundTasks.Job;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Invoices;

namespace CronService.Tests.BackgroundTasks.Job;

public class CreateInvoicesJobTests
{
    private readonly CreateInvoicesJob _sut;
    private readonly Mock<IMessagePublisher<CreateInvoicesMessage>> _mockedPublisher = new();
    private readonly Mock<ILogger<CreateInvoicesJob>> _mockedLogger = new();

    public CreateInvoicesJobTests()
    {
        var mockedServiceProvider = new Mock<IServiceProvider>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessagePublisher<CreateInvoicesMessage>))).Returns(_mockedPublisher.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<CreateInvoicesJob>))).Returns(_mockedLogger.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public void TestThatNameReturnsCorrectName()
    {
        Assert.Equal("CreateInvoicesJob", _sut.Name);
    }

    [Fact]
    public async Task TestThatExecuteAsyncCallsPublisher()
    {
        await _sut.ExecuteAsync(default);

        _mockedPublisher.Verify(p => p.Publish(It.IsAny<CreateInvoicesMessage>()), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Information, "[CreateInvoicesJob] Sending Create Invoices message");
    }
}