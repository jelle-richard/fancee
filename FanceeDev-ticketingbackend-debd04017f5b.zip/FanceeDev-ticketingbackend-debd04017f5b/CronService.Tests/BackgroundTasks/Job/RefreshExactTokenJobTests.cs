using System;
using System.Threading.Tasks;
using CronService.BackgroundTasks.Job;
using Fs.MessageBus.Publishers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using TestCore.Mocks;
using WebApiCore.MessageBus.Messages.Token;

namespace CronService.Tests.BackgroundTasks.Job;

public class RefreshExactTokenJobTests
{
    private readonly RefreshExactTokenJob _sut;
    private readonly Mock<IMessagePublisher<RefreshExactTokenMessage>> _mockedPublisher = new();
    private readonly Mock<ILogger<RefreshExactTokenJob>> _mockedLogger = new();

    public RefreshExactTokenJobTests()
    {
        var mockedServiceProvider = new Mock<IServiceProvider>();
        var mockedFactory = new Mock<IServiceScopeFactory>();
        var mockedScope = new Mock<IServiceScope>();

        mockedFactory.Setup(f => f.CreateScope()).Returns(mockedScope.Object);
        mockedServiceProvider.Setup(sp => sp.GetService(typeof(IServiceScopeFactory))).Returns(mockedFactory.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(IMessagePublisher<RefreshExactTokenMessage>))).Returns(_mockedPublisher.Object);
        mockedScope.Setup(s => s.ServiceProvider.GetService(typeof(ILogger<RefreshExactTokenJob>))).Returns(_mockedLogger.Object);

        _sut = new(mockedServiceProvider.Object);
    }

    [Fact]
    public void TestThatNameReturnsCorrectName()
    {
        Assert.Equal("RefreshExactTokenJob", _sut.Name);
    }

    [Fact]
    public async Task TestThatExecuteAsyncCallsPublisher()
    {
        await _sut.ExecuteAsync(default);

        _mockedPublisher.Verify(p => p.Publish(It.IsAny<RefreshExactTokenMessage>()), Times.Once);
        _mockedLogger.VerifyCalled(LogLevel.Information, "[RefreshExactTokenJob] Sending Refresh Exact Token message");
    }
}