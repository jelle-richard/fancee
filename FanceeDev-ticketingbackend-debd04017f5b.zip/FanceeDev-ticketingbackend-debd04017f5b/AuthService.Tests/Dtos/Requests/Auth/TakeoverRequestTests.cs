using System;
using System.Linq;
using AuthService.Dtos.Requests.Auth;

namespace AuthService.Tests.Dtos.Requests.Auth;

public class TakeoverRequestTests
{
    private static readonly Guid ValidAccountId = Guid.NewGuid();

    [Fact]
    public void TestThatValidateReturnsErrorOnEmptyGuid()
    {
        var sut = new TakeoverRequest
        {
            AccountId = Guid.Empty,
            AdminPassword = "password"
        };

        var actual = sut.Validate(new(sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Invalid account id", actual[0].ErrorMessage);
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("  ")]
    public void TestThatValidateReturnsErrorOnEmptyAdminPassword(string password)
    {
        var sut = new TakeoverRequest
        {
            AccountId = ValidAccountId,
            AdminPassword = password
        };

        var actual = sut.Validate(new(sut)).ToList();

        Assert.Single(actual);
        Assert.Equal("Invalid password", actual[0].ErrorMessage);
    }

    [Fact]
    public void TestThatValidateDoesNotReturnErrorsOnValidRequest()
    {
        var sut = new TakeoverRequest
        {
            AccountId = ValidAccountId,
            AdminPassword = "password"
        };

        var actual = sut.Validate(new(sut)).ToList();

        Assert.Empty(actual);
    }
}