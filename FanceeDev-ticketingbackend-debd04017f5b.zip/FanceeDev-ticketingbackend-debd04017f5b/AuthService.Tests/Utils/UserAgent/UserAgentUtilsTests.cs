﻿using AuthService.Utils.UserAgent;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;

namespace AuthService.Tests.Utils.UserAgent;

public class UserAgentUtilsTests
{
    public static readonly object[][] GetDeviceFromHeadersTestData =
    {
        new object[] { "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0", "Firefox 101.0 (Windows 10)" },
        new object[] { "Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/43.4", "Mac, Firefox 43.4 (Mac OS X)" },
        new object[] { "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36", "Chrome 77.0.3865 (Linux)" },
        new object[] { "Mozilla/5.0 (iPhone; CPU iPhone OS 15_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/100.1  Mobile/15E148 Safari/605.1.15", "iPhone, Firefox iOS 100.1 (iOS 15)" },
        new object[] { "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15", "Mac, Safari 11.1.2 (Mac OS X 10)" },
        new object[] { "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36", "Chrome 44.0.2403 (Linux)" },
        new object[] { "Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:24.0) Gecko/20100101 Firefox/24.0", "Firefox 24.0 (Ubuntu)" },
        new object[] { "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko", "IE 11.0 (Windows 10)" },
        new object[] { "Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)", "IE 6.0 (Windows 98)" },
        new object[] { "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53", "Edge 101.0.1210 (Windows 10)" },
        new object[] { "Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53", "Edge 101.0.1210" }
    };

    [Fact]
    public void TestThatGetDeviceFromHeadersReturnsNullWhenUserAgentHeaderIsNotPresent()
    {
        var headers = new HeaderDictionary();

        Assert.Null(UserAgentUtils.GetDeviceFromHeaders(headers));
    }

    [Theory]
    [MemberData(nameof(GetDeviceFromHeadersTestData))]
    public void TestThatGetDeviceFromHeadersReturnsExpectedResult(string input, string expected)
    {
        var headers = new HeaderDictionary
        {
            { "User-Agent", new StringValues(input) }
        };

        var actual = UserAgentUtils.GetDeviceFromHeaders(headers);

        Assert.Equal(expected, actual);
    }
}