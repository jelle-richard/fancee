using System;
using AuthService.Utils.Token;

namespace AuthService.Tests.Utils.Token;

public class AppTeamJwtTokenProviderTests
{
    private readonly AppTeamJwtTokenProvider _sut = new(new()
    {
        Issuer = "UnitTest",
        LifetimeHours = 2,
        TakeoverLifetimeMinutes = 3,
        SigningKey = "SuperSecretUnitTestKey!NowEvenMoreSecure!",
        RefreshDays = 7
    });

    [Fact]
    public void TestThatAppTeamJwtTokenProviderProxiesCalls()
    {
        var actual = _sut.New(new AppTeamTokenMetadata { TeamId = Guid.NewGuid() }, out var expiresAt, out var refreshableUntil);

        Assert.NotNull(actual);
        Assert.True(expiresAt > DateTime.UtcNow);
        Assert.True(refreshableUntil > expiresAt);
    }
}