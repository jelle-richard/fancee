using System;
using System.Linq;
using AuthService.Utils.Adapter.Organization;
using WebApiCore.Dtos.Environment;

namespace AuthService.Tests.Utils.Adapter.Organization;

public class OrganizationAdapterTests
{
    private static readonly HostedDeploymentEnvironment Env = new()
    {
        IsHttps = true,
        ContentDeliveryNetworkBaseUrl = "unit.test"
    };

    [Fact]
    public void TestThatToManageableOrganizationMapsOrganization()
    {
        var id = Guid.NewGuid();

        var organization = new FanceeData.Models.Ticketing.Organization
        {
            Id = id,
            Name = "Unit Test B.V.",
            UserId = Guid.Empty,
            User = new()
        };

        var actual = organization.ToManageableOrganization(Env, Guid.NewGuid(), ["organization.profile.view"]);

        Assert.Equal(id, actual.Id);
        Assert.Equal("Unit Test B.V.", actual.Name);
        Assert.False(actual.IsOwner);
        Assert.Single(actual.Claims);
        Assert.Equal("organization.profile.view", actual.Claims.First());
    }

    [Fact]
    public void TestThatToManageableOrganizationSetsIsOwner()
    {
        var id = Guid.NewGuid();

        var organization = new FanceeData.Models.Ticketing.Organization
        {
            Id = Guid.NewGuid(),
            Name = "Unit Test B.V.",
            UserId = id,
            User = new()
        };

        var actual = organization.ToManageableOrganization(Env, id, []);

        Assert.True(actual.IsOwner);
    }

    [Fact]
    public void TestThatToManageableOrganizationMapsAvatar()
    {
        var id = Guid.NewGuid();
        var fileId = Guid.NewGuid();

        var organization = new FanceeData.Models.Ticketing.Organization
        {
            Id = id,
            Name = "Unit Test B.V.",
            UserId = Guid.Empty,
            User = new()
            {
                UserMedia = new()
                {
                    FocalPointHeightPercentage = 24,
                    FocalPointWidthPercentage = 30,
                    File = new()
                    {
                        Id = fileId,
                        OriginalFileName = "hello.png",
                        MimeType = "image/png",
                        Path = "file.png"
                    }
                }
            }
        };

        var actual = organization.ToManageableOrganization(Env, Guid.Empty, []);

        Assert.NotNull(actual.Avatar);
        Assert.Equal(24, actual.Avatar.FocalPointHeightPercentage);
        Assert.Equal(30, actual.Avatar.FocalPointWidthPercentage);
        Assert.Equal("image/png", actual.Avatar.MimeType);
        Assert.Equal(fileId, actual.Avatar.Id);
        Assert.Equal("https://unit.test/file.png", actual.Avatar.Url);
        Assert.Equal("hello.png", actual.Avatar.OriginalFileName);
        Assert.Empty(actual.Claims);
    }
}