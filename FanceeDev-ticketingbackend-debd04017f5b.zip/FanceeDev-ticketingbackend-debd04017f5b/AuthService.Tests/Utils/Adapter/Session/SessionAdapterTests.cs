﻿using System;
using System.Collections.Generic;
using System.Linq;
using AuthService.Utils.Adapter.Session;
using FanceeAuthentication.Dtos.Responses;

namespace AuthService.Tests.Utils.Adapter.Session;

public class SessionAdapterTests
{
    [Fact]
    public void TestThatToSessionResponseMapsSessionToken()
    {
        var created = DateTime.UtcNow.AddHours(-1);
        var validUntil = created.AddHours(24);

        var st = new SessionResponse
        {
            Token = "my-token",
            Device = "UnitTestDevice01",
            IpAddress = "127.0.0.1",
            IssuedOn = created,
            ValidUntil = validUntil
        };

        var actual = st.ToSessionResponse();

        Assert.NotNull(actual);
        Assert.Equal("my-token", actual.Token);
        Assert.Equal("127.0.0.1", actual.IpAddress);
        Assert.Equal("UnitTestDevice01", actual.Device);
        Assert.Equal(created, actual.IssuedOn);
        Assert.Equal(validUntil, actual.ValidUntil);
    }

    [Fact]
    public void TestThatToSessionResponsesMapsMultipleSessionTokens()
    {
        var created = DateTime.UtcNow.AddHours(-1);
        var validUntil = created.AddHours(24);

        var tokens = new List<SessionResponse>
        {
            new()
            {
                Token = "my-token",
                Device = "UnitTestDevice01",
                IpAddress = "127.0.0.1",
                IssuedOn = created,
                ValidUntil = validUntil
            },
            new()
            {
                Token = "my-second-token",
                Device = "UnitTestDevice01",
                IpAddress = "127.0.0.1",
                IssuedOn = created,
                ValidUntil = validUntil
            }
        };

        var actual = tokens.ToSessionResponses().ToList();

        Assert.Equal(2, actual.Count);
        Assert.Equal("my-token", actual[0].Token);
        Assert.Equal("my-second-token", actual[1].Token);
    }
}