﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthService.Persistence.User;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace AuthService.Tests.Persistence.User;

public class UserContactInfoDaoTests
{
    private static readonly Guid[] MockedUserIds = { Guid.NewGuid(), Guid.NewGuid() };
    private readonly UserContactInfoDao _sut;

    private readonly IList<UserContactInfo> _userContactInfos = new List<UserContactInfo>
    {
        new()
        {
            Address = null,
            AddressId = null,
            FirstName = "Unit",
            LastName = "Test",
            PhoneNumber = "0612345678",
            User = new()
            {
                Id = MockedUserIds[0],
                Email = "unit@tester.com",
                Type = UserType.Organization
            },
            UserId = MockedUserIds[0]
        },
        new()
        {
            Address = null,
            AddressId = null,
            FirstName = "Unitty",
            LastName = "Development",
            PhoneNumber = "0687654321",
            User = new()
            {
                Id = MockedUserIds[1],
                Email = "unitty@development.com",
                Type = UserType.Admin
            },
            UserId = MockedUserIds[1]
        }
    };

    public UserContactInfoDaoTests()
    {
        var mockedContext = new Mock<TicketingContext>();

        mockedContext.Setup(x => x.UserContactInfos).ReturnsDbSet(_userContactInfos);
        mockedContext.Setup(c => c.UserContactInfos.FindAsync(It.IsAny<Guid>())).ReturnsAsync((object[] param) => _userContactInfos.First(u => u.UserId == (Guid)param[0]));

        _sut = new(mockedContext.Object);
    }

    [Fact]
    public async Task TestThatInvalidUserIdReturnsNoUserContactInfo()
    {
        var actual = await _sut.GetAsync(Guid.NewGuid());

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatValidUserIdGetsCorrectUserContactInfo()
    {
        var actual = await _sut.GetAsync(MockedUserIds[0]);

        Assert.NotNull(actual);
        Assert.Equal(_userContactInfos[0], actual);
    }
}