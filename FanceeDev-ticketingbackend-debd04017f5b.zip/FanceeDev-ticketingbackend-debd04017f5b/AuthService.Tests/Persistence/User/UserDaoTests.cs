﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthService.Persistence.User;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace AuthService.Tests.Persistence.User;

public class UserDaoTests
{
    private const string ValidEmail = "unit@test.com";
    private const string InvalidHashEmail = "invalid@hash.com";
    private const string UnVerifiedEmail = "un@verified.com";
    private const string InvalidEmail = "invalid@test.com";

    private static readonly Guid[] MockedUserIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };
    private static readonly Guid[] FanceeUsersIds = { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() };

    public static readonly object[][] GetByEmailTestData =
    {
        new object[] { ValidEmail, MockedUserIds[0], UserType.Admin },
        new object[] { UnVerifiedEmail, MockedUserIds[2], UserType.Host }
    };

    public static readonly object[][] GetByIdTestData =
    {
        new object[] { MockedUserIds[0], UserType.Admin },
        new object[] { MockedUserIds[2], UserType.Host }
    };

    public static readonly object[][] UsersExists =
    {
        new object[] { MockedUserIds[0], true },
        new object[] { MockedUserIds[1], true },
        new object[] { Guid.NewGuid(), false }
    };

    private readonly IList<FanceeData.Models.Ticketing.User> _users =
        new List<FanceeData.Models.Ticketing.User>
        {
            new()
            {
                Id = MockedUserIds[0],
                FanceeUsersId = FanceeUsersIds[0],
                Email = ValidEmail,
                Type = UserType.Admin,
                LastLogin = null,
                UserMedia = new()
                {
                    File = new()
                    {
                        Name = "Filename",
                        Path = "disk/folder/filename.png"
                    }
                }
            },
            new()
            {
                Id = MockedUserIds[1],
                FanceeUsersId = FanceeUsersIds[1],
                Email = InvalidHashEmail,
                Type = UserType.Organization,
                LastLogin = null
            },
            new()
            {
                Id = MockedUserIds[2],
                FanceeUsersId = FanceeUsersIds[2],
                Email = UnVerifiedEmail,
                Type = UserType.Host,
                LastLogin = DateTime.UtcNow
            }
        };

    private readonly IList<Organization> _organizations = new List<Organization>(new List<Organization>
    {
        new()
        {
            CurrencyNavigation = new()
            {
                Active = true,
                Name = "Euro",
                ShortCode = "EUR",
                Character = "€"
            },
            User = new()
            {
                Id = MockedUserIds[3],
                FanceeUsersId = FanceeUsersIds[3],
                Email = ValidEmail,
                Type = UserType.Organization,
                LastLogin = DateTime.UtcNow
            },
            UserId = MockedUserIds[3],
            CountryCode = "NL"
        }
    });

    private readonly UserDao _sut;
    private readonly Mock<TicketingContext> _mockedContext;

    public UserDaoTests()
    {
        _mockedContext = new();

        _mockedContext.Setup(x => x.Users).ReturnsDbSet(_users);
        _mockedContext.Setup(c => c.Users.FindAsync(It.IsAny<Guid>())).ReturnsAsync((object[] param) => _users.First(u => u.Id == (Guid)param[0]));
        _mockedContext.Setup(e => e.Organizations).ReturnsDbSet(_organizations);

        _sut = new(_mockedContext.Object);
    }

    [Theory]
    [MemberData(nameof(GetByEmailTestData))]
    public async Task TestThatGetAsyncWithEmailReturnsTheExpectedResult(string email, Guid id, UserType userType)
    {
        var actual = await _sut.GetAsync(email);

        Assert.NotNull(actual);
        Assert.Equal(id, actual.Id);
        Assert.Equal(userType, actual.Type);
    }

    [Theory]
    [MemberData(nameof(GetByIdTestData))]
    public async Task TestThatGetAsyncWithIdReturnsTheExpectedResult(Guid id, UserType expectedUserType)
    {
        var actual = await _sut.GetAsync(id);

        Assert.NotNull(actual);
        Assert.Equal(id, actual.Id);
        Assert.Equal(expectedUserType, actual.Type);
    }

    [Fact]
    public async Task TestThatGetAsyncWithUserIdReturnsNullOnInvalidUser()
    {
        var actual = await _sut.GetAsync(Guid.Empty, u => u.UserClaims);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatGetAsyncWithUserIdReturnsUserAndIncludes()
    {
        var actual = await _sut.GetAsync(MockedUserIds[0], u => u.UserClaims);

        Assert.NotNull(actual);
        Assert.Equal(actual.Id, MockedUserIds[0]);
    }

    [Theory]
    [MemberData(nameof(UsersExists))]
    public async Task TestThatExistsAsyncReturnsExpectedResult(Guid userId, bool expectedToExists)
    {
        var actual = await _sut.ExistsAsync(userId);

        Assert.Equal(expectedToExists, actual);
    }

    [Fact]
    public async Task TestThatUpdateUserAsyncUpdatesUser()
    {
        var user = new FanceeData.Models.Ticketing.User
        {
            Id = MockedUserIds[0],
            Email = ValidEmail,
            Type = UserType.Admin,
            LastLogin = DateTime.UtcNow,
            UserMedia = new()
            {
                File = new()
                {
                    Name = "FilenameNew",
                    Path = "disk/folder/filenameNew.png"
                }
            }
        };

        await _sut.UpdateAsync(user);

        _mockedContext.Verify(x => x.Users.Update(user), Times.Once);
        _mockedContext.Verify(x => x.SaveChangesAsync(default), Times.Once);
    }

    [Fact]
    public async Task TestThatOrganizationCurrencyReturnsNullOnMissingCurrency()
    {
        var actual = await _sut.OrganizationCurrencyAsync(InvalidEmail);

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatOrganizationCurrencyReturnsCurrencyForValidOrganization()
    {
        var actual = await _sut.OrganizationCurrencyAsync(ValidEmail);

        Assert.NotNull(actual);
        Assert.Equal("Euro", actual.Name);
        Assert.IsType<Currency>(actual);
    }

    [Fact]
    public async Task TestThatByFanceeUsersIdAsyncGetsUserByFanceeUsersId()
    {
        var actual = await _sut.ByFanceeUsersIdAsync(FanceeUsersIds[0]);

        Assert.NotNull(actual);
        Assert.Equal(MockedUserIds[0], actual.Id);
    }

    [Fact]
    public async Task TestThatChangelogsAfterDateAsyncCountsTheAmountOfChangelogsAfterDate()
    {
        _mockedContext.Setup(c => c.Changelogs)
            .ReturnsDbSet(new List<Changelog>
            {
                new()
                {
                    ReleaseDate = DateTime.UtcNow.AddDays(-1),
                    AppliesToUserType = UserType.Organization,
                    CountryCode = "NL"
                },
                new()
                {
                    ReleaseDate = DateTime.UtcNow.AddDays(-2),
                    AppliesToUserType = UserType.Organization,
                    CountryCode = "NL"
                },
                new()
                {
                    ReleaseDate = DateTime.UtcNow.AddDays(-5),
                    AppliesToUserType = UserType.Organization,
                    CountryCode = "NL"
                }
            });

        var actual = await _sut.ChangelogsAfterDateAsync(DateTime.UtcNow.AddDays(-3), UserType.Organization, new[] { "NL" });

        Assert.Equal(2, actual);
    }

    [Fact]
    public async Task TestThatAdminCountryManagerAsyncReturnsNullIfCountryManagerIsNull()
    {
        _mockedContext.Setup(c => c.Admins)
            .ReturnsDbSet(new List<Admin>());

        var actual = await _sut.AdminCountryManagerAsync(Guid.NewGuid());

        Assert.Null(actual);
    }

    [Fact]
    public async Task TestThatAdminCountryManagerAsyncReturnsCountryManager()
    {
        var userId = Guid.NewGuid();

        _mockedContext.Setup(c => c.Admins)
            .ReturnsDbSet(new List<Admin>
            {
                new()
                {
                    UserId = userId,
                    Role = AdminRole.CountryManager
                }
            });
        _mockedContext.Setup(c => c.CountryManagers)
            .ReturnsDbSet(new List<CountryManager>
            {
                new()
                {
                    UserId = userId
                }
            });

        var actual = await _sut.AdminCountryManagerAsync(userId);

        Assert.NotNull(actual);
        Assert.IsType<CountryManager>(actual);
    }

    [Fact]
    public async Task TestThatManagedOrganizationsAsyncReturnsOrganizationIdsThatUserCanManage()
    {
        var organizationIds = new[]
        {
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid(),
            Guid.NewGuid()
        };

        var userId = Guid.NewGuid();

        _mockedContext.Setup(c => c.Organizations).ReturnsDbSet(new Organization[]
        {
            new()
            {
                Id = organizationIds[0],
                UserId = userId,
                OrganizationUsers = new List<OrganizationUser>()
            },
            new()
            {
                Id = organizationIds[1],
                UserId = Guid.Empty,
                OrganizationUsers = new List<OrganizationUser> { new() { UserId = userId } }
            },
            new()
            {
                Id = organizationIds[2],
                UserId = Guid.Empty,
                OrganizationUsers = new List<OrganizationUser> { new() { UserId = Guid.NewGuid() } }
            },
            new()
            {
                Id = organizationIds[3],
                UserId = Guid.Empty,
                OrganizationUsers = new List<OrganizationUser> { new() { UserId = Guid.NewGuid() }, new() { UserId = userId } }
            }
        });

        var actual = (await _sut.ManagedOrganizationsAsync(userId)).ToList();

        Assert.Equal(organizationIds[0], actual[0].Id);
        Assert.Equal(organizationIds[1], actual[1].Id);
        Assert.Equal(organizationIds[3], actual[2].Id);
    }

    [Fact]
    public async Task TestThatManageableOrganizationUserClaimsReturnsForOrganizationId()
    {
        _mockedContext.Setup(c => c.OrganizationUserClaims).ReturnsDbSet([
            new()
            {
                OrganizationId = MockedUserIds[0],
                UserId = MockedUserIds[1],
                ClaimValue = "organization.profile.edit"
            }
        ]);

        var actual = (await _sut.ManageableOrganizationUserClaims(MockedUserIds[0], MockedUserIds[1])).ToList();

        Assert.Single(actual);
        Assert.Equal("organization.profile.edit", actual[0]);
    }

    [Fact]
    public async Task TestThatManageableOrganizationUserClaimsReturnsForManagingOrganizationId()
    {
        _mockedContext.Setup(c => c.OrganizationUserClaims).ReturnsDbSet([
            new()
            {
                OrganizationId = MockedUserIds[1],
                UserId = MockedUserIds[1],
                ClaimValue = "organization.profile.edit"
            }
        ]);

        var actual = (await _sut.ManageableOrganizationUserClaims(MockedUserIds[0], MockedUserIds[1])).ToList();

        Assert.Single(actual);
        Assert.Equal("organization.profile.edit", actual[0]);
    }
}