using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthService.Persistence.Claims;
using FanceeData.Contexts;
using FanceeData.Models.Ticketing;

namespace AuthService.Tests.Persistence.Claims;

public class ClaimsDaoTests
{
    private static readonly Guid UserId = Guid.NewGuid();
    private readonly ClaimsDao _sut;
    private readonly Mock<TicketingContext> _mockedContext = new();

    public ClaimsDaoTests()
    {
        _mockedContext.Setup(c => c.UserClaim)
            .ReturnsDbSet(new List<UserClaim>
            {
                new()
                {
                    UserId = UserId,
                    ClaimValue = "claim1"
                },
                new()
                {
                    UserId = UserId,
                    ClaimValue = "claim2"
                },
                new()
                {
                    UserId = Guid.NewGuid(),
                    ClaimValue = "claim2"
                },
                new()
                {
                    UserId = UserId,
                    ClaimValue = "claim3"
                },
                new()
                {
                    UserId = Guid.NewGuid(),
                    ClaimValue = "claim3"
                },
                new()
                {
                    UserId = UserId,
                    ClaimValue = "claim4"
                }
            });

        _sut = new(_mockedContext.Object);
    }

    [Fact]
    public async Task TestThatUserClaimsAsyncFetchesOnlyClaimsOfUser()
    {
        var actual = await _sut.UserClaimsAsync(UserId);

        Assert.Equal(4, actual.Count());
        Assert.Equal("claim1", actual.FirstOrDefault());
    }

    [Fact]
    public async Task TestThatAlterUserClaimsAsyncSavesChangesAsync()
    {
        await _sut.AlterUserClaimsAsync(UserId, new[] { "invoice.list", "invoice.details" });

        _mockedContext.Verify(c => c.SaveChangesAsync(default), Times.Exactly(2));
    }
}