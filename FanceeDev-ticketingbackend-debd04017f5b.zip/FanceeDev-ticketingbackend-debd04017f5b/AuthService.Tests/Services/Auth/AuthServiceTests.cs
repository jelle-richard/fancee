using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;
using AuthService.Dtos.Requests.Auth;
using AuthService.Persistence.User;
using AuthService.Services.Auth.Exceptions;
using AuthService.Utils.Token;
using FanceeAuthentication.Dtos;
using FanceeAuthentication.Dtos.Responses;
using FanceeAuthentication.Exceptions;
using FanceeAuthentication.Providers.Authentication;
using FanceeAuthentication.Providers.Session;
using FanceeAuthentication.Providers.Token;
using FanceeData.Models.Ticketing;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Primitives;
using WebApiCore.Dtos.Environment;
using WebApiCore.Exceptions;
using WebApiCore.Services.AppTeam;
using WebApiCore.Services.Country;
using WebApiCore.Services.DeploymentEnvironment;
using WebApiCore.Services.Logging;
using WebApiCore.Utils;
using Claim = System.Security.Claims.Claim;
using Client = FanceeUsers.Models.Client;
using InvalidTokenException = FanceeAuthentication.Exceptions.InvalidTokenException;
using UserNotFoundException = WebApiCore.Exceptions.User.UserNotFoundException;

namespace AuthService.Tests.Services.Auth;

public class AuthServiceTests
{
    private const string TestEmail = "unit@test.com";
    private const string TestPassword = "Unitt3ster!";
    private const string TestToken = "TestToken";
    private const string InvalidToken = "invalid";

    private static readonly Guid ValidUserId = Guid.NewGuid();
    private static readonly Guid AdminFanceeUsersId = Guid.NewGuid();
    private static readonly Guid FanceeUsersId = Guid.NewGuid();
    private static readonly Guid[] MockedUserIds = { Guid.NewGuid(), Guid.NewGuid() };

    private readonly AuthService.Services.Auth.AuthService _sut;

    private readonly Mock<IUserDao> _mockedUserDao = new();
    private readonly Mock<IUserContactInfoDao> _mockedUserContactInfoDao = new();
    private readonly Mock<IHttpContextAccessor> _mockedHttpContextAccessor = new();
    private readonly Mock<IAuthenticationProvider> _mockedAuthenticationProvider = new();
    private readonly Mock<ISessionProvider> _mockedSessionProvider = new();
    private readonly Mock<IAppTeamService> _mockedAppTeamService = new();
    private readonly Mock<IJwtTokenProvider> _mockedJwtTokenProvider = new();
    private readonly Mock<IDeploymentEnvironmentService> _mockedDeploymentEnvironmentService = new();
    private readonly Mock<ICountryService> _mockedCountryService = new();
    private readonly Mock<IUserLoggingService> _mockedUserLoggingService = new();

    private readonly SessionResponse _validSessionResponse = new()
    {
        IssuedOn = DateTime.UtcNow,
        ValidUntil = DateTime.UtcNow.AddHours(1),
        Device = "Unit",
        Token = "Test",
        IpAddress = "1.1.1.1"
    };

    public AuthServiceTests()
    {
        _mockedHttpContextAccessor.SetupGet(h => h.HttpContext.User.Claims).Returns(new Claim[]
        {
            new("user", ValidUserId.ToString()),
            new("type", "Admin")
        });

        _mockedHttpContextAccessor.SetupGet(h => h.HttpContext.Connection.RemoteIpAddress).Returns(IPAddress.None);
        _mockedHttpContextAccessor.SetupGet(h => h.HttpContext.Request.Headers).Returns(new HeaderDictionary
        {
            { "User-Agent", new StringValues("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0") }
        });

        _sut = new(_mockedUserDao.Object,
            _mockedUserContactInfoDao.Object,
            _mockedHttpContextAccessor.Object,
            _mockedAuthenticationProvider.Object,
            _mockedSessionProvider.Object,
            _mockedAppTeamService.Object,
            _mockedJwtTokenProvider.Object,
            _mockedDeploymentEnvironmentService.Object,
            _mockedCountryService.Object,
            _mockedUserLoggingService.Object
        );
    }

    [Fact]
    public async Task TestThatTokenAsyncThrowsExceptionOnInvalidLogin()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync(TestEmail, TestPassword, Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ThrowsAsync(new UserNotFoundException());

        await Assert.ThrowsAsync<UserNotFoundException>(async () => { await _sut.TokenAsync(TestEmail, TestPassword); });
    }

    [Theory]
    [InlineData(UserType.Client)]
    [InlineData(UserType.Ambassador)]
    [InlineData(UserType.Organization)]
    [InlineData(UserType.Admin)]
    public async Task TestThatTokenAsyncReturnsTokenResponse(UserType userType)
    {
        var mockedFileId = Guid.NewGuid();
        var mockedFilePath = "test.png";
        var mockedScheme = "http";
        var mockedContentDeliveryNetwork = "test.com";
        var mockedFocalPointWidthPercentage = 40;
        var mockedFocalPointHeightPercentage = 60;
        var mockedUserType = userType;

        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment { IsHttps = false, ContentDeliveryNetworkBaseUrl = mockedContentDeliveryNetwork });

        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync(TestEmail, TestPassword, Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ReturnsAsync(new TokenResponse { Token = TestToken, UserId = MockedUserIds[0], ValidUntil = DateTime.UtcNow.AddDays(1) });

        _mockedUserDao.Setup(u => u.GetAsync(TestEmail, It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = mockedUserType,
            UserClaims = new[] { new UserClaim { ClaimType = ClaimType.Permission, ClaimValue = "unit.claim" } },
            UserMedia = new()
            {
                File = new()
                {
                    Id = mockedFileId,
                    Path = mockedFilePath
                },
                FocalPointWidthPercentage = mockedFocalPointWidthPercentage,
                FocalPointHeightPercentage = mockedFocalPointHeightPercentage
            }
        });

        _mockedUserDao.Setup(u => u.GetAsync(It.IsAny<Guid>(), It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = mockedUserType,
            Admin = new()
            {
                Role = AdminRole.SystemDeveloper
            }
        });

        _mockedUserContactInfoDao.Setup(uci => uci.GetAsync(
            MockedUserIds[0],
            It.IsAny<Expression<Func<UserContactInfo, object>>[]>()
        )).ReturnsAsync(new UserContactInfo
        {
            FirstName = "Unit",
            LastName = "Test"
        });

        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        if (userType.IsOrganization())
        {
            var managedUserId = Guid.NewGuid();

            _mockedUserDao.Setup(ud => ud.ManagedOrganizationsAsync(It.IsAny<Guid>()))
                .ReturnsAsync([
                    new()
                    {
                        Id = MockedUserIds[0],
                        UserId = MockedUserIds[0],
                        User = new()
                    },
                    new()
                    {
                        Id = managedUserId,
                        UserId = MockedUserIds[1],
                        User = new()
                    }
                ]);

            _mockedUserDao.Setup(ud => ud.ManageableOrganizationUserClaims(managedUserId, MockedUserIds[0])).ReturnsAsync(["user.claim"]);
        }

        var actual = await _sut.TokenAsync(TestEmail, TestPassword);

        Assert.NotNull(actual);
        Assert.NotNull(actual.User);
        Assert.Equal("Unit", actual.User.FirstName);
        Assert.Equal("unit.claim", actual.Claims.FirstOrDefault());
        Assert.Equal(TestToken, actual.Token);
        Assert.Equal(mockedFileId, actual.User.AvatarFile.Id);
        Assert.Equal($"{mockedScheme}://{mockedContentDeliveryNetwork}/{mockedFilePath}", actual.User.AvatarFile.Url);
        Assert.Equal(mockedFocalPointHeightPercentage, actual.User.AvatarFile.FocalPointHeightPercentage);
        Assert.Equal(mockedFocalPointWidthPercentage, actual.User.AvatarFile.FocalPointWidthPercentage);

        if (userType.IsOrganization())
        {
            var actualManageableOrganizations = actual.ManageableOrganizations.ToList();
            Assert.Equal(2, actualManageableOrganizations.Count);
            Assert.True(actualManageableOrganizations[0].IsOwner);
            Assert.Equal("unit.claim", actualManageableOrganizations[0].Claims.First());
            Assert.False(actualManageableOrganizations[1].IsOwner);
            Assert.Equal("user.claim", actualManageableOrganizations[1].Claims.First());
        }
    }

    [Fact]
    public async Task TestThatInvalidateThrowsUserNotFoundExceptionOnInvalidUser()
    {
        _mockedHttpContextAccessor.SetupGet(h => h.HttpContext.User.Claims).Returns(new Claim[]
        {
            new("platformUserId", "invalid"),
            new("type", "Organization")
        });

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.InvalidateAsync(InvalidToken));
    }

    [Fact]
    public async Task TestThatInvalidateAsyncThrowsUserNotFoundExceptionOnInvalidUserId()
    {
        _mockedHttpContextAccessor.SetupGet(h => h.HttpContext.User.Claims).Returns(new Claim[]
        {
            new("platformUserId", "invalid user id"),
            new("type", "Admin")
        });

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.InvalidateAsync("token"));
    }

    [Fact]
    public async Task TestThatInvalidateAsyncThrowsInvalidTokenExceptionOnSessionProviderInvalidateAsyncException()
    {
        _mockedSessionProvider.Setup(sp => sp.InvalidateAsync("token", ValidUserId, Client.Ticketing))
            .ThrowsAsync(new InvalidTokenException());

        await Assert.ThrowsAsync<AuthService.Services.Auth.Exceptions.InvalidTokenException>(
            async () => await _sut.InvalidateAsync("token"));
    }

    [Fact]
    public async Task TestThatInvalidateAsyncCallsSessionProviderInvalidateAsync()
    {
        await _sut.InvalidateAsync(TestToken);

        _mockedSessionProvider.Verify(sp => sp.InvalidateAsync(TestToken, ValidUserId, Client.Ticketing), Times.Once);
    }

    [Fact]
    public async Task TestThatValidSessionsAsyncReturnsSessionResponses()
    {
        _mockedSessionProvider.Setup(sp => sp.ActiveSessionsAsync(ValidUserId, Client.Ticketing)).ReturnsAsync(new List<SessionResponse>
        {
            _validSessionResponse
        });

        var actual = await _sut.ValidSessionsAsync(ValidUserId);

        Assert.Single(actual);

        _mockedSessionProvider.Verify(std => std.ActiveSessionsAsync(ValidUserId, Client.Ticketing), Times.Once);
    }

    [Fact]
    public async Task TestThatInvalidateByAdminAsyncThrowsInvalidTokenExceptionIfUserIsNotAdmin()
    {
        _mockedHttpContextAccessor.SetupGet(h => h.HttpContext.User.Claims).Returns(new Claim[]
        {
            new("platformUserId", TestEmail),
            new("type", "Organization")
        });

        await Assert.ThrowsAsync<AuthService.Services.Auth.Exceptions.InvalidTokenException>(async () => await _sut.InvalidateByAdminAsync("token", Guid.NewGuid()));
    }

    [Fact]
    public async Task TestThatInvalidateByAdminAsyncCallsSessionProviderInvalidateAsync()
    {
        _mockedUserDao.Setup(ud => ud.GetAsync(ValidUserId))
            .ReturnsAsync(new FanceeData.Models.Ticketing.User { FanceeUsersId = FanceeUsersId });

        await _sut.InvalidateByAdminAsync("token", ValidUserId);

        _mockedSessionProvider.Verify(sp => sp.InvalidateAsync("token", FanceeUsersId, Client.Ticketing), Times.Once);
    }

    [Fact]
    public async Task TestThatTokenAsyncSetsUserToNullIfUserInSharedLoginButHasNoPlatformData()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync("user@email.com", "pass", Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ReturnsAsync(new TokenResponse { Token = "Token", UserId = ValidUserId, ValidUntil = DateTime.UtcNow.AddHours(1) });

        _mockedUserDao.Setup(ud => ud.GetAsync("user@email.com", u => u.UserMedia.File, u => u.UserClaims))
            .ReturnsAsync(value: null);

        var actual = await _sut.TokenAsync("user@email.com", "pass");

        Assert.NotNull(actual);
        Assert.Null(actual.User);
        Assert.Equal("Token", actual.Token);
    }

    [Fact]
    public async Task TestThatTokenAsyncThrowsUserNotFoundExceptionOnAuthenticationException()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync("user@email.com", "pass", Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ThrowsAsync(new InvalidUserCredentialsException());

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.TokenAsync("user@email.com", "pass"));
    }

    [Fact]
    public async Task TestThatTokenAsyncGetsUserType()
    {
        var userId = Guid.NewGuid();

        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync("user@email.com", "pass", Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .Callback<string, string, Client, Func<Guid, Task<SessionMetadata>>>((_, _, _, cb) => cb.Invoke(userId))
            .ReturnsAsync(new TokenResponse());

        _mockedUserDao.Setup(u => u.GetAsync(TestEmail, It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = UserType.Organization,
            UserClaims = new[] { new UserClaim { ClaimType = ClaimType.Permission, ClaimValue = "unit.claim" } }
        });
        _mockedUserContactInfoDao.Setup(uci => uci.GetAsync(MockedUserIds[0])).ReturnsAsync(new UserContactInfo
        {
            FirstName = "Unit",
            LastName = "Test"
        });

        var _ = await _sut.TokenAsync("user@email.com", "pass");

        _mockedUserDao.Verify(ud => ud.ByFanceeUsersIdAsync(userId), Times.Once);
    }

    [Fact]
    public async Task TestThatTokenAsyncThrowsAppTeamNotFoundExceptionOnInvalidAppTeam()
    {
        var appTeamId = Guid.NewGuid();

        _mockedAppTeamService.Setup(ats => ats.ExistsAsync(appTeamId)).ReturnsAsync(false);

        await Assert.ThrowsAsync<AppTeamNotFoundException>(async () => await _sut.TokenAsync(appTeamId));

        _mockedAppTeamService.Verify(ats => ats.ExistsAsync(appTeamId), Times.Once);
        _mockedJwtTokenProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatTokenAsyncReturnsNewAppTeamToken()
    {
        var appTeamId = Guid.NewGuid();
        var expiresAt = DateTime.UtcNow.AddHours(2);
        var refreshableUntil = expiresAt.AddDays(4);

        _mockedJwtTokenProvider.Setup(jtp => jtp.RefreshDays).Returns(4);
        _mockedAppTeamService.Setup(ats => ats.ExistsAsync(appTeamId))
            .ReturnsAsync(true);
        _mockedAppTeamService.Setup(ats => ats.OrganizationAppTeamMetadataAsync(appTeamId))
            .ReturnsAsync(new AppTeam
            {
                Name = "Unit team",
                SalesEnabled = true,
                StatisticsEnabled = true,
                ScanningEnabled = false,
                Organization = new()
                {
                    Name = "Unit Club B.V."
                }
            });
        _mockedJwtTokenProvider.Setup(jtp => jtp.New(It.Is<AppTeamTokenMetadata>(attm => attm.TeamId == appTeamId), out expiresAt, out refreshableUntil, false))
            .Returns("app-team-token");

        var actual = await _sut.TokenAsync(appTeamId);

        Assert.NotNull(actual);
        Assert.True(actual.ValidUntil > DateTime.UtcNow);
        Assert.True(actual.RefreshableUntil > actual.ValidUntil);
        Assert.Equal("app-team-token", actual.Token);
        Assert.Equal(new[] { "sales", "statistics" }, actual.Claims);
        Assert.Equal("Unit team", actual.Name);

        _mockedAppTeamService.Verify(ats => ats.ExistsAsync(appTeamId), Times.Once);
        _mockedAppTeamService.Verify(ats => ats.OrganizationAppTeamMetadataAsync(appTeamId), Times.Once);
        _mockedJwtTokenProvider.Verify(jtp => jtp.New(It.IsAny<ITokenMetadata>(), out expiresAt, out refreshableUntil, false), Times.Once);
    }

    [Fact]
    public async Task TestThatTokenAsyncThrowsExceptionIfAdminCountryManagerLogsInOnInvalidTerminationDate()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment { IsHttps = false, ContentDeliveryNetworkBaseUrl = "test.com" });

        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync(TestEmail, TestPassword, Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ReturnsAsync(new TokenResponse { Token = TestToken, UserId = MockedUserIds[0], ValidUntil = DateTime.UtcNow.AddDays(1) });

        _mockedUserDao.Setup(u => u.GetAsync(TestEmail, It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = UserType.Admin,
            UserClaims = new[] { new UserClaim { ClaimType = ClaimType.Permission, ClaimValue = "unit.claim" } },
            UserMedia = new()
        });
        _mockedUserDao.Setup(u => u.GetAsync(It.IsAny<Guid>(), It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = UserType.Admin,
            Admin = new()
            {
                Role = AdminRole.SystemDeveloper
            }
        });
        _mockedUserContactInfoDao.Setup(uci => uci.GetAsync(MockedUserIds[0])).ReturnsAsync(new UserContactInfo
        {
            FirstName = "Unit",
            LastName = "Test"
        });
        _mockedUserDao.Setup(ud => ud.AdminCountryManagerAsync(MockedUserIds[0])).ReturnsAsync(new CountryManager
        {
            UserId = MockedUserIds[0],
            TerminatedOn = DateTime.UtcNow.AddDays(10)
        });

        await Assert.ThrowsAsync<InvalidTerminationDateOfCountryManagerException>(async () => await _sut.TokenAsync(TestEmail, TestPassword));
    }

    [Fact]
    public async Task TestThatTokenAsyncReturnsTokenResponseWhenCountryManagerIsNull()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment { IsHttps = false, ContentDeliveryNetworkBaseUrl = "test.com" });

        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync(TestEmail, TestPassword, Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ReturnsAsync(new TokenResponse { Token = TestToken, UserId = MockedUserIds[0], ValidUntil = DateTime.UtcNow.AddDays(1) });

        _mockedUserDao.Setup(u => u.GetAsync(TestEmail, It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = UserType.Admin,
            UserClaims = new[] { new UserClaim { ClaimType = ClaimType.Permission, ClaimValue = "unit.claim" } },
            UserMedia = new()
        });
        _mockedUserDao.Setup(u => u.GetAsync(It.IsAny<Guid>(), It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = UserType.Admin,
            Admin = new()
            {
                Role = AdminRole.SystemDeveloper
            }
        });
        _mockedUserContactInfoDao.Setup(uci => uci.GetAsync(MockedUserIds[0])).ReturnsAsync(new UserContactInfo
        {
            FirstName = "Unit",
            LastName = "Test"
        });
        _mockedUserDao.Setup(ud => ud.AdminCountryManagerAsync(MockedUserIds[0])).ReturnsAsync(value: null);

        var actual = await _sut.TokenAsync(TestEmail, TestPassword);

        Assert.NotNull(actual);
        Assert.IsType<AuthService.Dtos.Responses.Auth.TokenResponse>(actual);
    }

    [Fact]
    public async Task TestThatTokenAsyncReturnsTokenResponseIfAdminCountryManagerLogsInOnValidTerminationDate()
    {
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync()).ReturnsAsync(new HostedDeploymentEnvironment { IsHttps = false, ContentDeliveryNetworkBaseUrl = "test.com" });

        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync(TestEmail, TestPassword, Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ReturnsAsync(new TokenResponse { Token = TestToken, UserId = MockedUserIds[0], ValidUntil = DateTime.UtcNow.AddDays(1) });

        _mockedUserDao.Setup(u => u.GetAsync(TestEmail, It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = UserType.Admin,
            UserClaims = new[] { new UserClaim { ClaimType = ClaimType.Permission, ClaimValue = "unit.claim" } },
            UserMedia = new()
        });
        _mockedUserDao.Setup(u => u.GetAsync(It.IsAny<Guid>(), It.IsAny<Expression<Func<FanceeData.Models.Ticketing.User, object>>[]>())).ReturnsAsync(() => new()
        {
            Id = MockedUserIds[0],
            Type = UserType.Admin,
            Admin = new()
            {
                Role = AdminRole.SystemDeveloper
            }
        });
        _mockedUserContactInfoDao.Setup(uci => uci.GetAsync(MockedUserIds[0])).ReturnsAsync(new UserContactInfo
        {
            FirstName = "Unit",
            LastName = "Test"
        });
        _mockedUserDao.Setup(ud => ud.AdminCountryManagerAsync(MockedUserIds[0])).ReturnsAsync(new CountryManager
        {
            UserId = MockedUserIds[0],
            TerminatedOn = DateTime.UtcNow.AddYears(-1)
        });

        var actual = await _sut.TokenAsync(TestEmail, TestPassword);

        Assert.NotNull(actual);
        Assert.IsType<AuthService.Dtos.Responses.Auth.TokenResponse>(actual);
    }

    [Fact]
    public async Task TestThatRefreshTokenAsyncThrowsTokenRefreshExceptionOnInvalidToken()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.RefreshTokenAsync("invalid", Client.Ticketing))
            .ThrowsAsync(new ExpiredTokenException());

        await Assert.ThrowsAsync<TokenRefreshException>(async () => await _sut.RefreshTokenAsync("invalid"));
    }

    [Fact]
    public async Task TestThatRefreshTokenAsyncCallsAuthenticationProviderRefreshTokenAsync()
    {
        var userId = Guid.NewGuid();
        var validUntil = DateTime.UtcNow.AddHours(6);
        var refreshableUntil = validUntil.AddDays(1);
        var client = new FanceeData.Models.Ticketing.Client
        {
            UserId = Guid.NewGuid(),
            User = new()
            {
                Id = userId,
                FanceeUsersId = FanceeUsersId,
                Email = "unit@test.com",
                LastLogin = DateTime.UtcNow
            }
        };

        _mockedAuthenticationProvider.Setup(ap => ap.RefreshTokenAsync("token", Client.Ticketing))
            .ReturnsAsync(new TokenResponse { Token = "new-token", UserId = FanceeUsersId, RefreshableUntil = refreshableUntil, ValidUntil = validUntil });
        _mockedUserDao.Setup(ud => ud.ByFanceeUsersIdAsync(FanceeUsersId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization))
            .ReturnsAsync(client.User);

        var actual = await _sut.RefreshTokenAsync("token");

        Assert.NotNull(actual);

        _mockedAuthenticationProvider.Verify(ap => ap.RefreshTokenAsync("token", Client.Ticketing), Times.Once);
        _mockedUserDao.Verify(ud => ud.ByFanceeUsersIdAsync(It.IsAny<Guid>(), u => u.UserMedia.File, u => u.UserClaims, u => u.Organization), Times.Once);
        _mockedUserContactInfoDao.Verify(ucid => ucid.GetAsync(
            It.IsAny<Guid>(),
            It.IsAny<Expression<Func<UserContactInfo, object>>>()
        ), Times.Once);
    }

    [Fact]
    public async Task TestThatRefreshAppTeamTokenAsyncThrowsTokenRefreshExceptionIfTokenCannotBeRefreshed()
    {
        _mockedJwtTokenProvider.Setup(jtp => jtp.Parse<AppTeamTokenMetadata>("token", true))
            .Returns(new AppTeamTokenMetadata
            {
                RefreshableUntil = DateTimeOffset.UtcNow.AddHours(-1).ToUnixTimeSeconds()
            });

        await Assert.ThrowsAsync<TokenRefreshException>(async () => await _sut.RefreshAppTeamTokenAsync("token"));

        _mockedJwtTokenProvider.Verify(jtp => jtp.Parse<AppTeamTokenMetadata>(It.IsAny<string>(), It.IsAny<bool>()), Times.Once);
    }

    [Fact]
    public async Task TestThatRefreshAppTeamTokenAsyncRefreshesToken()
    {
        var teamId = Guid.NewGuid();
        DateTime validUntil, refreshableUntil;

        _mockedJwtTokenProvider.Setup(jtp => jtp.Parse<AppTeamTokenMetadata>("token", true))
            .Returns(new AppTeamTokenMetadata
            {
                RefreshableUntil = DateTimeOffset.UtcNow.AddHours(1).ToUnixTimeSeconds(),
                TeamId = teamId
            });
        _mockedAppTeamService.Setup(ats => ats.ExistsAsync(teamId)).ReturnsAsync(true);
        _mockedJwtTokenProvider.Setup(jtp => jtp.RefreshDays).Returns(4);
        _mockedJwtTokenProvider.Setup(jtp => jtp.New(It.IsAny<AppTeamTokenMetadata>(), out validUntil, out refreshableUntil, false)).Returns("new-token");
        _mockedAppTeamService.Setup(ats => ats.OrganizationAppTeamMetadataAsync(teamId))
            .ReturnsAsync(new AppTeam
            {
                Name = "The App Team",
                Organization = new() { Name = "The Organization" },
                ScanningEnabled = true
            });

        var actual = await _sut.RefreshAppTeamTokenAsync("token");

        Assert.Equal("new-token", actual.Token);

        _mockedJwtTokenProvider.Verify(jtp => jtp.Parse<AppTeamTokenMetadata>("token", true), Times.Once);
        _mockedJwtTokenProvider.VerifyGet(jtp => jtp.RefreshDays, Times.Once);
        _mockedJwtTokenProvider.Verify(jtp => jtp.New(It.IsAny<AppTeamTokenMetadata>(), out validUntil, out refreshableUntil, false), Times.Once);
        _mockedAppTeamService.Verify(ats => ats.OrganizationAppTeamMetadataAsync(teamId), Times.Once);
    }

    [Fact]
    public async Task TestThatTokenAsyncThrowsTooManyRequestsExceptionOnDbUpdateException()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.TokenAsync("test@mail.com", "pass", Client.Ticketing, It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ThrowsAsync(new DbUpdateException());

        await Assert.ThrowsAsync<TooManyRequestsException>(async () => await _sut.TokenAsync("test@mail.com", "pass"));
    }

    [Fact]
    public async Task TestThatRefreshTokenAsyncThrowsTooManyRequestsExceptionOnDbUpdateConcurrencyException()
    {
        _mockedAuthenticationProvider.Setup(ap => ap.RefreshTokenAsync("token", Client.Ticketing))
            .ThrowsAsync(new DbUpdateConcurrencyException());

        await Assert.ThrowsAsync<TooManyRequestsException>(async () => await _sut.RefreshTokenAsync("token"));
    }

    [Fact]
    public async Task TestThatTakeoverTokenAsyncThrowsUserNotFoundExceptionIfAccountDoesNotExist()
    {
        var request = new TakeoverRequest
        {
            AccountId = Guid.Empty,
            AdminPassword = "test"
        };

        _mockedUserDao.Setup(ud => ud.GetAsync(Guid.Empty, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization)).ReturnsAsync(value: null);

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.TakeoverTokenAsync(request, Guid.Empty, Guid.Empty));

        _mockedUserDao.Verify(ud => ud.GetAsync(Guid.Empty, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization), Times.Once);
        _mockedUserDao.VerifyNoOtherCalls();
        _mockedAuthenticationProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatTakeoverTokenAsyncThrowsUserNotFoundExceptionIfRequestedAccountIsAdmin()
    {
        var request = new TakeoverRequest
        {
            AccountId = Guid.NewGuid(),
            AdminPassword = "test"
        };

        _mockedUserDao.Setup(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization))
            .ReturnsAsync(new FanceeData.Models.Ticketing.User { Type = UserType.Admin });

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.TakeoverTokenAsync(request, Guid.Empty, Guid.Empty));

        _mockedUserDao.Verify(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization), Times.Once);
        _mockedUserDao.VerifyNoOtherCalls();
        _mockedAuthenticationProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatTakeoverTokenAsyncThrowsUserNotFoundExceptionOnAuthenticationException()
    {
        var request = new TakeoverRequest
        {
            AccountId = Guid.NewGuid(),
            AdminPassword = "test"
        };

        _mockedUserDao.Setup(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization))
            .ReturnsAsync(new FanceeData.Models.Ticketing.User { Type = UserType.Organization, FanceeUsersId = FanceeUsersId });
        _mockedAuthenticationProvider.Setup(ap => ap.AdminTakeoverTokenAsync(FanceeUsersId, Client.Ticketing, AdminFanceeUsersId, "test", It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ThrowsAsync(new InvalidUserCredentialsException());

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.TakeoverTokenAsync(request, AdminFanceeUsersId, ValidUserId));

        _mockedUserDao.Verify(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization), Times.Once);
        _mockedAuthenticationProvider.Verify(ap => ap.AdminTakeoverTokenAsync(FanceeUsersId, Client.Ticketing, AdminFanceeUsersId, "test", It.IsAny<Func<Guid, Task<SessionMetadata>>>()), Times.Once);
        _mockedUserDao.VerifyNoOtherCalls();
        _mockedAuthenticationProvider.VerifyNoOtherCalls();
    }

    [Fact]
    public async Task TestThatTakeoverTokenAsyncThrowsTooManyRequestsExceptionOnDbUpdateException()
    {
        var request = new TakeoverRequest
        {
            AccountId = Guid.NewGuid(),
            AdminPassword = "test"
        };
        var organization = new FanceeData.Models.Ticketing.User
        {
            Id = ValidUserId,
            Type = UserType.Organization,
            FanceeUsersId = FanceeUsersId,
            UserClaims = new UserClaim[]
            {
                new() { ClaimType = ClaimType.Permission, ClaimValue = "profile.details" }
            },
            Organization = new()
        };

        _mockedUserDao.Setup(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization))
            .ReturnsAsync(organization);
        _mockedUserDao.Setup(ud => ud.ByFanceeUsersIdAsync(ValidUserId))
            .ReturnsAsync(organization);
        _mockedAuthenticationProvider.Setup(ap => ap.AdminTakeoverTokenAsync(FanceeUsersId, Client.Ticketing, AdminFanceeUsersId, "test", It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .ThrowsAsync(new DbUpdateException());

        await Assert.ThrowsAsync<TooManyRequestsException>(async () => await _sut.TakeoverTokenAsync(request, AdminFanceeUsersId, ValidUserId));
    }

    [Fact]
    public async Task TestThatTakeoverTokenAsyncCreatesTakeoverToken()
    {
        var request = new TakeoverRequest
        {
            AccountId = Guid.NewGuid(),
            AdminPassword = "test"
        };
        var user = new FanceeData.Models.Ticketing.User
        {
            Type = UserType.Organization, FanceeUsersId = FanceeUsersId, Id = ValidUserId, UserClaims = new UserClaim[]
            {
                new() { ClaimType = ClaimType.Permission, ClaimValue = "profile.details" }
            },
            Organization = new()
        };

        _mockedUserDao.Setup(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization))
            .ReturnsAsync(user);
        _mockedUserDao.Setup(ud => ud.ByFanceeUsersIdAsync(ValidUserId))
            .ReturnsAsync(user);
        _mockedAuthenticationProvider.Setup(ap => ap.AdminTakeoverTokenAsync(FanceeUsersId, Client.Ticketing, AdminFanceeUsersId, "test", It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .Callback<Guid, Client, Guid, string, Func<Guid, Task<SessionMetadata>>>((_, _, _, _, metadataCallback) => { metadataCallback.Invoke(ValidUserId); })
            .ReturnsAsync(new TokenResponse
            {
                Token = "Token",
                UserId = Guid.Empty,
                ValidUntil = DateTime.UtcNow,
                RefreshableUntil = DateTime.UtcNow
            });
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(new HostedDeploymentEnvironment { ContentDeliveryNetworkBaseUrl = "unit.test", IsHttps = false });
        _mockedUserDao.Setup(ud => ud.ManagedOrganizationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new Organization[]
            {
                new()
                {
                    Id = Guid.Empty,
                    Name = "Test",
                    User = new()
                }
            });
        _mockedUserLoggingService.Setup(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()));

        var actual = await _sut.TakeoverTokenAsync(request, AdminFanceeUsersId, ValidUserId);

        Assert.NotNull(actual);
        Assert.Equal("Token", actual.Token);
        Assert.NotEmpty(actual.Claims);
        Assert.Single(actual.ManageableOrganizations);

        _mockedUserDao.Verify(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization), Times.Once);
        _mockedUserDao.Verify(ud => ud.ByFanceeUsersIdAsync(ValidUserId), Times.Once);
        _mockedAuthenticationProvider.Verify(ap => ap.AdminTakeoverTokenAsync(FanceeUsersId, Client.Ticketing, AdminFanceeUsersId, "test", It.IsAny<Func<Guid, Task<SessionMetadata>>>()), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Once);
        _mockedUserDao.Verify(ud => ud.ManagedOrganizationsAsync(It.IsAny<Guid>()), Times.Once);
        _mockedUserLoggingService.Verify(uls => uls.LogAsync(It.IsAny<Guid>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task TestThatTakeoverTokenAsyncCreatesTakeoverTokenWithoutManageableOrganizationsForNonOrganizationUsers()
    {
        var request = new TakeoverRequest
        {
            AccountId = Guid.NewGuid(),
            AdminPassword = "test"
        };
        var user = new FanceeData.Models.Ticketing.User
        {
            Type = UserType.Client, FanceeUsersId = FanceeUsersId, Id = ValidUserId, UserClaims = new UserClaim[]
            {
                new() { ClaimType = ClaimType.Permission, ClaimValue = "profile.details" }
            },
            Organization = new()
        };

        _mockedUserDao.Setup(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization))
            .ReturnsAsync(user);
        _mockedUserDao.Setup(ud => ud.ByFanceeUsersIdAsync(ValidUserId))
            .ReturnsAsync(user);
        _mockedAuthenticationProvider.Setup(ap => ap.AdminTakeoverTokenAsync(FanceeUsersId, Client.Ticketing, AdminFanceeUsersId, "test", It.IsAny<Func<Guid, Task<SessionMetadata>>>()))
            .Callback<Guid, Client, Guid, string, Func<Guid, Task<SessionMetadata>>>((_, _, _, _, metadataCallback) => { metadataCallback.Invoke(ValidUserId); })
            .ReturnsAsync(new TokenResponse
            {
                Token = "Token",
                UserId = Guid.Empty,
                ValidUntil = DateTime.UtcNow,
                RefreshableUntil = DateTime.UtcNow
            });
        _mockedDeploymentEnvironmentService.Setup(des => des.GetAsync())
            .ReturnsAsync(new HostedDeploymentEnvironment { ContentDeliveryNetworkBaseUrl = "unit.test", IsHttps = false });
        _mockedUserDao.Setup(ud => ud.ManagedOrganizationsAsync(It.IsAny<Guid>()))
            .ReturnsAsync(new Organization[]
            {
                new()
                {
                    Id = Guid.Empty,
                    Name = "Test"
                }
            });

        var actual = await _sut.TakeoverTokenAsync(request, AdminFanceeUsersId, ValidUserId);

        Assert.NotNull(actual);
        Assert.Equal("Token", actual.Token);
        Assert.NotEmpty(actual.Claims);
        Assert.Empty(actual.ManageableOrganizations);

        _mockedUserDao.Verify(ud => ud.GetAsync((Guid)request.AccountId, u => u.UserMedia.File, u => u.UserClaims, u => u.Organization), Times.Once);
        _mockedUserDao.Verify(ud => ud.ByFanceeUsersIdAsync(ValidUserId), Times.Once);
        _mockedAuthenticationProvider.Verify(ap => ap.AdminTakeoverTokenAsync(FanceeUsersId, Client.Ticketing, AdminFanceeUsersId, "test", It.IsAny<Func<Guid, Task<SessionMetadata>>>()), Times.Once);
        _mockedDeploymentEnvironmentService.Verify(des => des.GetAsync(), Times.Never);
        _mockedUserDao.Verify(ud => ud.ManagedOrganizationsAsync(It.IsAny<Guid>()), Times.Never);
    }
}