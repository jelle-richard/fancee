using System;
using System.Threading.Tasks;
using AuthService.Persistence.User;
using AuthService.Services.User;
using WebApiCore.Exceptions.User;

namespace AuthService.Tests.Services.User;

public class UserServiceTests
{
    private readonly UserService _sut;
    private readonly Mock<IUserDao> _mockedUserDao = new();

    public UserServiceTests()
    {
        _sut = new(_mockedUserDao.Object);
    }

    [Fact]
    public async Task TestThatFanceeUsersIdAsyncThrowsUserNotFoundExceptionOnInvalidUser()
    {
        var userId = Guid.NewGuid();

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.FanceeUsersIdAsync(userId));

        _mockedUserDao.Verify(ud => ud.GetAsync(userId), Times.Once);
    }

    [Fact]
    public async Task TestThatFanceeUsersIdAsyncCallsUserDaoGetAsync()
    {
        var userId = Guid.NewGuid();
        var fanceeUsersId = Guid.NewGuid();

        _mockedUserDao.Setup(ud => ud.GetAsync(userId))
            .ReturnsAsync(new FanceeData.Models.Ticketing.User { FanceeUsersId = fanceeUsersId });

        var actual = await _sut.FanceeUsersIdAsync(userId);

        Assert.Equal(fanceeUsersId, actual);

        _mockedUserDao.Verify(ud => ud.GetAsync(userId), Times.Once);
    }
}