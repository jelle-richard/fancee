using System;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AuthService.Persistence.Claims;
using AuthService.Persistence.User;
using AuthService.Services.Claims;
using FanceeData.Models.Ticketing;
using FanceeData.Permissions;
using WebApiCore.Exceptions.Claim;
using WebApiCore.Exceptions.User;
using WebApiCore.Persistence.AppTeam;
using WebApiCore.Utils.Reflection;

namespace AuthService.Tests.Services.Claims;

public class ClaimsServiceTests
{
    private static readonly Guid UserId = Guid.NewGuid();
    private readonly ClaimsService _sut;
    private readonly Mock<IClaimsDao> _mockedClaimsDao = new();
    private readonly Mock<IUserDao> _mockedUserDao = new();
    private readonly Mock<IAppTeamDao> _mockedAppTeamDao = new();

    public ClaimsServiceTests()
    {
        _sut = new(_mockedClaimsDao.Object, _mockedUserDao.Object, _mockedAppTeamDao.Object);
    }

    [Fact]
    public void TestThatListPlatformClaimsRetrievesAllClaimHierarchyCategoriesResponse()
    {
        var actual = _sut.ListPlatformClaims(null).ToList();

        Assert.Equal(35, actual.Count);
        Assert.Equal("Admin Agenda Iframes", actual.MinBy(c => c.Category)?.Category);
    }

    [Fact]
    public void TestThatListPlatformClaimsRetrievesOrganizationClaimHierarchyCategoriesResponse()
    {
        var actual = _sut.ListPlatformClaims(UserType.Organization).ToList();

        Assert.Equal(17, actual.Count);
        Assert.Equal("App teams", actual.MinBy(c => c.Category)?.Category);
    }

    [Fact]
    public async Task TestThatUserClaimsAsyncCallsUserDaoExistsAndThrowsUserNotFoundExceptionForInvalidGuid()
    {
        _mockedUserDao.Setup(ud => ud.ExistsAsync(UserId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.UserClaimsAsync(UserId));

        _mockedUserDao.Verify(ud => ud.ExistsAsync(UserId), Times.Once);
    }

    [Fact]
    public async Task TestThatUserClaimsAsyncWithValidUserCallsClaimsDaoUserClaimsASync()
    {
        _mockedUserDao.Setup(ud => ud.ExistsAsync(UserId))
            .ReturnsAsync(true);

        _mockedClaimsDao.Setup(cd => cd.UserClaimsAsync(UserId))
            .ReturnsAsync(new[] { "claim1", "claim2", "claim3" });

        var actual = await _sut.UserClaimsAsync(UserId);

        Assert.Equal(3, actual.Count());

        _mockedUserDao.Verify(ud => ud.ExistsAsync(UserId), Times.Once);
        _mockedClaimsDao.Verify(cd => cd.UserClaimsAsync(UserId), Times.Once);
    }

    [Fact]
    public async Task TestThatAlterUserClaimsAsyncThrowsUserNotFoundExceptionOnNonExistentUser()
    {
        _mockedUserDao.Setup(ud => ud.ExistsAsync(UserId))
            .ReturnsAsync(false);

        await Assert.ThrowsAsync<UserNotFoundException>(async () => await _sut.AlterUserClaimsAsync(UserId, new[] { "claim1" }, UserType.Organization));

        _mockedUserDao.Verify(ud => ud.ExistsAsync(UserId), Times.Once);
    }

    [Fact]
    public async Task TestThatAlterUserClaimsAsyncValidatesIfClaimsExists()
    {
        _mockedUserDao.Setup(ud => ud.ExistsAsync(UserId))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<ClaimNotFoundException>(async () => await _sut.AlterUserClaimsAsync(UserId, new[] { "nonexisting.claim" }, UserType.Organization));

        _mockedUserDao.Verify(ud => ud.ExistsAsync(UserId), Times.Once);
    }

    [Fact]
    public async Task TestThatAlterUserClaimsAsyncValidatesIfClaimsContainsTheDependedOnClaims()
    {
        _mockedUserDao.Setup(ud => ud.ExistsAsync(UserId))
            .ReturnsAsync(true);

        await Assert.ThrowsAsync<MismatchedClaimHierarchyException>(async () => await _sut.AlterUserClaimsAsync(UserId, new[] { "organization.invoice.details" }, null));

        _mockedUserDao.Verify(ud => ud.ExistsAsync(UserId), Times.Once);
    }

    [Fact]
    public async Task TestThatAlterUserClaimsAsyncCallsClaimsDaoAlterUserClaimsAsync()
    {
        var claims = new[] { "organization.invoice.list" };
        _mockedUserDao.Setup(ud => ud.ExistsAsync(UserId))
            .ReturnsAsync(true);

        _mockedClaimsDao.Setup(cd => cd.AlterUserClaimsAsync(UserId, claims));

        await _sut.AlterUserClaimsAsync(UserId, claims, null);

        _mockedClaimsDao.Verify(cd => cd.AlterUserClaimsAsync(UserId, claims), Times.Once);
        _mockedUserDao.Verify(ud => ud.ExistsAsync(UserId), Times.Once);
    }

    [Fact]
    public void TestThatAllClaimsHaveADescription()
    {
        var claimDescriptions = ReflectionUtils.GetImplementations<IPermissions>()
            .SelectMany(implementation => implementation.GetConstants()
                .Select(constant => constant.GetCustomAttribute<DescriptionAttribute>()?.Description))
            .ToArray();

        Assert.DoesNotContain(claimDescriptions, cd => cd == null);
    }

    [Fact]
    public void TestThatAllPermissionsHaveADescription()
    {
        var permissionDescriptions = ReflectionUtils.GetImplementations<IPermissions>()
            .Select(implementation => implementation.GetCustomAttribute<DescriptionAttribute>()?.Description)
            .ToArray();

        Assert.DoesNotContain(permissionDescriptions, cd => cd == null);
    }

    [Fact]
    public async Task TestThatAppTeamClaimsAsyncCallsAppTeamDaoOrganizationAppTeamMetadataAsyncAndParsesTeamSettingsToClaims()
    {
        var appTeamId = Guid.NewGuid();

        _mockedAppTeamDao.Setup(atd => atd.OrganizationAppTeamMetadataAsync(appTeamId))
            .ReturnsAsync(new AppTeam
            {
                Name = "Unit team",
                SalesEnabled = true,
                StatisticsEnabled = false,
                ScanningEnabled = true
            });

        var actual = await _sut.AppTeamClaimsAsync(appTeamId);

        Assert.Equal(new[] { "scan", "sales" }, actual);

        _mockedAppTeamDao.Verify(atd => atd.OrganizationAppTeamMetadataAsync(appTeamId), Times.Once);
    }
}