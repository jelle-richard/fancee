﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce;

public class ChamberOfCommerceDateConverter : JsonConverter<DateOnly?>
{
    private const string DefaultDateTimeFormat = "yyyyMMdd";
    private const string Year = "yyyy0000";
    private const string YearMonth = "yyyyMM00";
    private const string YearDay = "yyyy00dd";
    private const string MonthDay = "0000MMdd";
    private const string Month = "0000MM00";
    private const string Day = "000000dd";

    private static readonly string[] DateFormats =
    {
        DefaultDateTimeFormat,
        Year,
        YearMonth,
        YearDay,
        MonthDay,
        Month,
        Day
    };

    public override DateOnly? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType != JsonTokenType.String)
            throw new JsonException("The given value should be of type string");

        var value = reader.GetString();

        if (string.IsNullOrEmpty(value))
            throw new JsonException("The given value was not recognized as a valid boolean");

        if (value == "00000000")
            return null;

        foreach (var format in DateFormats)
            if (DateOnly.TryParseExact(value, format, out var date))
                return date;

        throw new JsonException("The given value was not recognized as a valid boolean");
    }

    public override void Write(Utf8JsonWriter writer, DateOnly? value, JsonSerializerOptions options)
    {
        if (value == null)
            writer.WriteNullValue();
        else
            writer.WriteStringValue(((DateOnly)value).ToString(DefaultDateTimeFormat));
    }
}