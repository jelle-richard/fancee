﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce;

public class DutchBooleanConverter : JsonConverter<bool>
{
    private static readonly Dictionary<string, bool> BooleanMappings = new()
    {
        { "ja", true },
        { "nee", false }
    };

    public override bool Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType != JsonTokenType.String)
            throw new JsonException("The given value should be of type string");

        var value = reader.GetString()?.ToLowerInvariant();

        if (value == null || !BooleanMappings.ContainsKey(value))
            throw new JsonException("The given value was not recognized as a valid boolean");

        return BooleanMappings[value];
    }

    public override void Write(Utf8JsonWriter writer, bool value, JsonSerializerOptions options)
    {
        writer.WriteStringValue(BooleanMappings.First(bm => bm.Value == value).Key);
    }
}