﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class SbiActivity
{
    [JsonPropertyName("sbiCode")]
    public string SbiCode { get; set; } = default!;

    [JsonPropertyName("sbiOmschrijving")]
    public string? SbiDescription { get; set; }

    [JsonPropertyName("indHoofdactiviteit")]
    [JsonConverter(typeof(DutchBooleanConverter))]
    public bool? IsMainActivity { get; set; }
}