﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class Result<TResultItem>
{
    [JsonPropertyName("pagina")]
    public int Page { get; set; }

    [JsonPropertyName("aantal")]
    public int Amount { get; set; }

    [JsonPropertyName("total")]
    public int Total { get; set; }

    [JsonPropertyName("vorige")]
    public string? Previous { get; set; }

    [JsonPropertyName("volgende")]
    public string? Next { get; set; }

    [JsonPropertyName("resultaten")]
    public IEnumerable<TResultItem> Results { get; set; } = new List<TResultItem>();

    [JsonPropertyName("links")]
    public IEnumerable<Link> Links { get; set; } = new List<Link>();
}