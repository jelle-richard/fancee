﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class Link
{
    [JsonPropertyName("rel")]
    public string? Rel { get; set; }

    [JsonPropertyName("href")]
    public string? Href { get; set; }

    [JsonPropertyName("hreflang")]
    public string? HrefLong { get; set; }

    [JsonPropertyName("media")]
    public string? Media { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("deprecation")]
    public string? Deprecation { get; set; }

    [JsonPropertyName("profile")]
    public string? Profile { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }
}