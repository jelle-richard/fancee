﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class Branch
{
    [JsonPropertyName("vestigingsnummer")]
    public string? BranchNumber { get; set; }

    [JsonPropertyName("kvkNummer")]
    public string KvKNumber { get; set; } = default!;

    [JsonPropertyName("rsin")]
    public string? Rsin { get; set; }

    [JsonPropertyName("indNonMailing")]
    [JsonConverter(typeof(DutchBooleanConverter))]
    public bool? IsNonMailing { get; set; }

    [JsonPropertyName("formeleRegistratiedatum")]
    [JsonConverter(typeof(ChamberOfCommerceDateConverter))]
    public DateOnly? FormalRegisterDate { get; set; }

    [JsonPropertyName("materieleRegistratie")]
    public MaterialRegistration? MaterialRegistration { get; set; }

    [JsonPropertyName("eersteHandelsnaam")]
    public string FirstTradeName { get; set; } = default!;

    [JsonPropertyName("indHoofdvestiging")]
    [JsonConverter(typeof(DutchBooleanConverter))]
    public bool IsMainBranch { get; set; } = default!;

    [JsonPropertyName("indCommercieleVestiging")]
    [JsonConverter(typeof(DutchBooleanConverter))]
    public bool IsCommercialBranch { get; set; } = default!;

    [JsonPropertyName("voltijdWerkzamePersonen")]
    public int? FullTimeEmployees { get; set; }

    [JsonPropertyName("totaalWerkzamePersonen")]
    public int? TotalEmployees { get; set; }

    [JsonPropertyName("deeltijdWerkzamePersonen")]
    public int? PartTimeEmployees { get; set; }

    [JsonPropertyName("handelsnamen")]
    public IEnumerable<TradeName> TradeNames { get; set; } = new List<TradeName>();

    [JsonPropertyName("adressen")]
    public IEnumerable<Address> Addresses { get; set; } = new List<Address>();

    [JsonPropertyName("websites")]
    public IEnumerable<string> Websites { get; set; } = new List<string>();

    public IEnumerable<SbiActivity> SbiActivities { get; set; } = new List<SbiActivity>();

    [JsonPropertyName("links")]
    public IEnumerable<Link> Links { get; set; } = new List<Link>();
}