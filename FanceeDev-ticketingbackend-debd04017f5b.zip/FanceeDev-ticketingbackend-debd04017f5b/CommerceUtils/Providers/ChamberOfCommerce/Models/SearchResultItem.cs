﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class SearchResultItem
{
    [JsonPropertyName("kvkNummer")]
    public string KvKNumber { get; set; } = default!;

    [JsonPropertyName("rsin")]
    public string? Rsin { get; set; }

    [JsonPropertyName("vestigingsnummer")]
    public string? BranchNumber { get; set; }

    [JsonPropertyName("handelsnaam")]
    public string TradeName { get; set; } = default!;

    [JsonPropertyName("straatnaam")]
    public string? StreetName { get; set; }

    [JsonPropertyName("huisnummer")]
    public int? HouseNumber { get; set; }

    [JsonPropertyName("huisnummerToevoeging")]
    public string? HouseNumberAddition { get; set; }

    [JsonPropertyName("postcode")]
    public string? PostalCode { get; set; }

    [JsonPropertyName("plaats")]
    public string? City { get; set; }

    [JsonPropertyName("type")]
    public string? Type { get; set; }

    [JsonPropertyName("actief")]
    public string? Active { get; set; }

    [JsonPropertyName("vervallenNaam")]
    public string? FormerName { get; set; }

    [JsonPropertyName("links")]
    public IEnumerable<Link> Links { get; set; } = new List<Link>();
}