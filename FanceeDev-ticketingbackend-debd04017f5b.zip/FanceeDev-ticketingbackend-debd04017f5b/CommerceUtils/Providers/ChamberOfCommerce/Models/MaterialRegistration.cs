﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class MaterialRegistration
{
    [JsonPropertyName("datumAanvang")]
    [JsonConverter(typeof(ChamberOfCommerceDateConverter))]
    public DateOnly? DateStart { get; set; }

    [JsonPropertyName("datumEinde")]
    [JsonConverter(typeof(ChamberOfCommerceDateConverter))]
    public DateOnly? DateEnd { get; set; }
}