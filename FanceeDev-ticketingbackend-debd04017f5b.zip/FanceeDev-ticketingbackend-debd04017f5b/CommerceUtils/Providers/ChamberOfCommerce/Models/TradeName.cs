﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class TradeName
{
    [JsonPropertyName("naam")]
    public string Name { get; set; } = default!;

    [JsonPropertyName("volgorde")]
    public int Order { get; set; }
}