﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class Address
{
    [JsonPropertyName("type")]
    public string Type { get; set; } = default!;

    [JsonPropertyName("indAfgeschermd")]
    [JsonConverter(typeof(DutchBooleanConverter))]
    public bool IsProtected { get; set; } = default!;

    [JsonPropertyName("volledigAdres")]
    public string FullAddress { get; set; } = default!;

    [JsonPropertyName("straatnaam")]
    public string? StreetName { get; set; }

    [JsonPropertyName("huisnummer")]
    public int? HouseNumber { get; set; }

    [JsonPropertyName("huisnummerToevoeging")]
    public string? HouseNumberAddition { get; set; }

    [JsonPropertyName("huisletter")]
    public string? HouseLetter { get; set; }

    [JsonPropertyName("toevoegingAdres")]
    public string? AddressAddition { get; set; }

    [JsonPropertyName("postcode")]
    public string PostalCode { get; set; } = default!;

    [JsonPropertyName("postbusnummer")]
    public int? PoBoxNumber { get; set; }

    [JsonPropertyName("plaats")]
    public string City { get; set; } = default!;

    [JsonPropertyName("straatHuisnummer")]
    public string? StreetHouseNumber { get; set; }

    [JsonPropertyName("postcodeWoonplaats")]
    public string? PostalCodeCity { get; set; }

    [JsonPropertyName("regio")]
    public string? Region { get; set; }

    [JsonPropertyName("land")]
    public string Country { get; set; } = default!;

    public GeoData? GeoData { get; set; }
}