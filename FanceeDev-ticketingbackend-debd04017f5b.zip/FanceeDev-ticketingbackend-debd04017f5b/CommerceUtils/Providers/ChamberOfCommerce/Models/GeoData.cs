﻿using System.Text.Json.Serialization;

namespace CommerceUtils.Providers.ChamberOfCommerce.Models;

public class GeoData
{
    [JsonPropertyName("addresseerbaarObjectId")]
    public string? AddressableObjectId { get; set; }

    [JsonPropertyName("nummerAanduidingId")]
    public string? NumberDesignationId { get; set; }

    [JsonPropertyName("gpsLatitude")]
    public decimal? GpsLatitude { get; set; }

    [JsonPropertyName("gpsLongitude")]
    public decimal? GpsLongitude { get; set; }

    [JsonPropertyName("rijksdriehoekX")]
    public decimal? StateTriangleX { get; set; }

    [JsonPropertyName("rijksdriehoekY")]
    public decimal? StateTriangleY { get; set; }

    [JsonPropertyName("rijksdriehoekZ")]
    public decimal? StateTriangleZ { get; set; }
}