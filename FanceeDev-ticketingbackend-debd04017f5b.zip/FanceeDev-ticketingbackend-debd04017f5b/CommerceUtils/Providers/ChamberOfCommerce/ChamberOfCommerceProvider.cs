﻿using CommerceUtils.Providers.ChamberOfCommerce.Models;
using CommerceUtils.Providers.Models;
using CommerceUtils.Utils;
using System.Text.Json;

namespace CommerceUtils.Providers.ChamberOfCommerce;

public class ChamberOfCommerceProvider : ICommerceProvider
{
    private const string CertificateFilename = "Staat_der_Nederlanden_Private_Root_CA_-_G1.cer";
    private const string SslTestEndpoint = "https://ssltest.kvk.nl";

    private readonly string _endpoint;
    private readonly HttpClient _httpClient;

    public ChamberOfCommerceProvider(ICustomCertificateHttpClient httpClientBuilder, string endpoint, string apiKey)
    {
        _endpoint = endpoint;

        _httpClient = httpClientBuilder.AddCertificate(CertificateFilename)
            .AddDefaultHeader("apikey", apiKey)
            .SetTimeout(TimeSpan.FromSeconds(10))
            .Build();
    }

    public CountryCode SupportedCountry() => CountryCode.NL;

    public async Task<bool> ServiceHealthyAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync(SslTestEndpoint);

            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }

    public async Task<bool> IsValidAsync(string identifier) =>
        (await SearchAsync(identifier, 1))?.Results.Any() ?? false;

    public async Task<CompanyInfo?> InfoAsync(string identifier)
    {
        var branch = await MainBranchAsync(identifier);

        if (branch == null)
            return null;

        var info = new CompanyInfo();

        if (!string.IsNullOrEmpty(branch.FirstTradeName))
            info.BusinessNames.Add(branch.FirstTradeName);

        info.BusinessNames.AddRange(branch.TradeNames.OrderBy(tn => tn.Order).Select(tn => tn.Name));
        info.BusinessNames = info.BusinessNames.Distinct().ToList();

        var address = branch.Addresses.FirstOrDefault(
            a => a?.Type.ToLowerInvariant() == "correspondentieadres",
            branch.Addresses.FirstOrDefault());

        if (address != null)
        {
            info.Address = new()
            {
                Country = CountryCode.NL,
                City = address.City,
                PostalCode = address.PostalCode,
                Street = address.StreetName,
                HouseNumber = $"{address.HouseNumber}{address.HouseNumberAddition}"
            };
        }

        return info;
    }

    /// <summary>
    /// Searches for the given identifier.
    /// </summary>
    /// <param name="identifier"></param>
    /// <param name="limit"></param>
    /// <returns></returns>
    private async Task<Result<SearchResultItem>?> SearchAsync(string identifier, int limit)
    {
        return await GetAsync<Result<SearchResultItem>>($"{_endpoint}/v1/zoeken?kvkNummer={identifier}&type=hoofdvestiging&pagina=1&aantal={limit}");
    }

    /// <summary>
    /// Gets the information of the main branch.
    /// </summary>
    /// <param name="identifier"></param>
    /// <returns></returns>
    private async Task<Branch?> MainBranchAsync(string identifier)
    {
        return await GetAsync<Branch?>($"{_endpoint}/v1/basisprofielen/{identifier}/hoofdvestiging");
    }

    /// <summary>
    /// Sends off a GET request to the given url.
    /// Tries to decode the response into the given model.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="url"></param>
    /// <returns></returns>
    private async Task<T?> GetAsync<T>(string url)
    {
        try
        {
            var response = await _httpClient.GetAsync(url);

            if (!response.IsSuccessStatusCode)
                return default;

            var json = await response.Content.ReadAsStringAsync();

            return JsonSerializer.Deserialize<T>(json);
        }
        catch
        {
            return default;
        }
    }
}