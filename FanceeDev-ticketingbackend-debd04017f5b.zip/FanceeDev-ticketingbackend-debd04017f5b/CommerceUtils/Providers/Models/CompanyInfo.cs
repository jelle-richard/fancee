﻿namespace CommerceUtils.Providers.Models;

public class CompanyInfo
{
    public Address? Address { get; set; }

    public List<string> BusinessNames { get; set; } = new();
}