using AccountingUtils.Providers.Bank.Models;
using AccountingUtils.Services.Bank.Ing.Exporters;
using ClosedXML.Excel;
using JetBrains.Annotations;

namespace AccountingUtils.Tests.Services.Bank.Ing.Exporters;

[TestSubject(typeof(IngPayoutExportService))]
public class IngPayoutExportServiceTests
{
    private readonly IngPayoutExportService _sut;
    private readonly Mock<IXLWorksheet> _mockedWorksheet = new();

    private readonly PayoutExportInfo _payoutExportInfo = new()
    {
        DebtorBankAccountHolderName = "Hans Test",
        DebtorIban = "NL01TEST1234567890",
        ExecuteOn = DateOnly.Parse("2022-12-31"),
        Rows = new PayoutRow[]
        {
            new()
            {
                Description = null,
                BankAccountHolderName = "Jan Test",
                ReceiverIban = "DE02TEST9876543210",
                Reference = "Internal-Reference",
                ValueEurCents = 24950
            },
            new()
            {
                Description = "Testing",
                BankAccountHolderName = "Barry Flash",
                ReceiverIban = "US01TEST4567893210",
                Reference = null,
                ValueEurCents = 1245
            }
        }
    };

    public IngPayoutExportServiceTests()
    {
        _mockedWorksheet.Setup(w => w.Cell(It.IsAny<string>()))
            .Returns(new Mock<IXLCell>().Object);

        _sut = new(_mockedWorksheet.Object, _payoutExportInfo);
    }

    [Fact]
    public void TestThatMaximumRowsPerDocumentIs1000()
    {
        Assert.Equal(1000, IngPayoutExportService.MaximumRowsPerDocument);
    }

    [Fact]
    public void TestThatCreateFillsDataOnWorksheet()
    {
        _sut.Create();

        // Note: I'm not sure why, but calling SetValue with a null value makes the mock invoke SetValue twice.

        _mockedWorksheet.Verify(w => w.Cell("C1").SetValue("Hans Test"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("C2").SetValue("NL01TEST1234567890"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("C4").SetValue(DateTime.Parse("2022-12-31 23:59:59")), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("B12").SetValue("Jan Test"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("C12").SetValue("DE02TEST9876543210"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("D12").SetValue(249.5m), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("E12").SetValue<string?>(null), Times.Exactly(2));
        _mockedWorksheet.Verify(w => w.Cell("F12").SetValue("Internal-Reference"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("B13").SetValue("Barry Flash"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("C13").SetValue("US01TEST4567893210"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("D13").SetValue(12.45m), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("E13").SetValue("Testing"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell("F13").SetValue<string?>(null), Times.Exactly(2));
        _mockedWorksheet.Verify(w => w.Cell("C8").SetValue<object?>(null), Times.Exactly(4));
        _mockedWorksheet.Verify(w => w.Cell("C9").SetValue<object?>(null), Times.Exactly(4));
        _mockedWorksheet.VerifySet(w => w.Cell("C8").FormulaA1 = "SUM(D12:D1011)", Times.Once);
        _mockedWorksheet.VerifySet(w => w.Cell("C9").FormulaA1 = "COUNT(D12:D1011)", Times.Once);
        _mockedWorksheet.VerifyGet(w => w.Cell("C8").Value, Times.Exactly(2));
        _mockedWorksheet.VerifyGet(w => w.Cell("C9").Value, Times.Exactly(2));
        _mockedWorksheet.VerifyNoOtherCalls();
    }
}