using AccountingUtils.Providers.Bank.Models;
using AccountingUtils.Services.Bank.Ing.Exporters;
using ClosedXML.Excel;
using JetBrains.Annotations;

namespace AccountingUtils.Tests.Services.Bank.Ing.Exporters;

[TestSubject(typeof(IngBankAccountExportService))]
public class IngBankAccountExportServiceTests
{
    private static readonly List<PayoutRow> Rows = new()
    {
        new()
        {
            Description = null,
            BankAccountHolderName = "Jan Test",
            ReceiverBankAccountNumber = "987654321",
            ReceiverBic = "RABONL2U",
            Reference = "Internal-Reference",
            ValueEurCents = 24950
        },
        new()
        {
            Description = "Testing",
            BankAccountHolderName = "Barry Flash",
            ReceiverBankAccountNumber = "4567891B23951",
            ReceiverBic = "INGBNL2A",
            Reference = null,
            ValueEurCents = 1245
        }
    };

    private readonly IngBankAccountExportService _sut;
    private readonly Mock<IXLWorksheet> _mockedWorksheet = new();

    public IngBankAccountExportServiceTests()
    {
        _mockedWorksheet.Setup(w => w.Row(1).Style.Font).Returns(new Mock<IXLFont>().Object);
        _mockedWorksheet.Setup(w => w.Columns(1, 6)).Returns(new Mock<IXLColumns>().Object);

        _mockedWorksheet.Setup(w => w.Cell(It.IsAny<int>(), It.IsAny<int>()))
            .Returns(() =>
            {
                var mockedCell = new Mock<IXLCell>();
                var mockedStyle = new Mock<IXLStyle>();
                mockedCell.Setup(c => c.SetDataType(It.IsAny<XLDataType>())).Returns(mockedCell.Object);
                mockedCell.Setup(c => c.SetValue(It.IsAny<It.IsAnyType>())).Returns(mockedCell.Object);
                mockedCell.Setup(c => c.Style).Returns(mockedStyle.Object);

                mockedStyle.Setup(s => s.Alignment).Returns(new Mock<IXLAlignment>().Object);
                mockedStyle.Setup(s => s.NumberFormat).Returns(new Mock<IXLNumberFormat>().Object);

                return mockedCell.Object;
            });

        _sut = new(_mockedWorksheet.Object, Rows);
    }

    [Fact]
    public void TestThatCreateFillsDataOnWorksheet()
    {
        _sut.Create();

        // Verify row 1 (header)
        _mockedWorksheet.Verify(w => w.Cell(1, 1).SetValue("Holder name"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(1, 2).SetValue("Bank account number"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(1, 3).SetValue("BIC"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(1, 4).SetValue("Payout"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(1, 5).SetValue("Reference"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(1, 6).SetValue("Description"), Times.Once);

        // Verify row 2 (content)
        _mockedWorksheet.Verify(w => w.Cell(2, 1).SetValue("Jan Test"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(2, 2).SetValue("987654321"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(2, 3).SetValue("RABONL2U"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(2, 4).SetValue(249.5m), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(2, 5).SetValue("Internal-Reference"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(2, 6).SetValue<string?>(null), Times.Once);

        // Verify row 3 (content)
        _mockedWorksheet.Verify(w => w.Cell(3, 1).SetValue("Barry Flash"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(3, 2).SetValue("4567891B23951"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(3, 3).SetValue("INGBNL2A"), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(3, 4).SetValue(12.45m), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(3, 5).SetValue<string?>(null), Times.Once);
        _mockedWorksheet.Verify(w => w.Cell(3, 6).SetValue("Testing"), Times.Once);
    }
}