using AccountingUtils.Utils.Http;

namespace AccountingUtils.Tests.Utils.Http;

public class JsonPostDataTests
{
    [Fact]
    public void TestThatGetHttpContentReturnsJsonString()
    {
        var sut = new JsonPostDataClass
        {
            Id = 42
        };

        var actual = sut.GetHttpContent();

        Assert.IsType<StringContent>(actual);
        Assert.Equal("{\"Id\":42}", actual.ReadAsStringAsync().Result);
    }

    #region Unit Test Classes

    private class JsonPostDataClass : JsonPostData
    {
        public int Id { get; set; }
    }

    #endregion
}