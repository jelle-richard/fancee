using System.Net;
using AccountingUtils.Utils.Exceptions;
using AccountingUtils.Utils.Http;

namespace AccountingUtils.Tests.Utils.Http;

public class HttpUtilsTests
{
    [Fact]
    public void TestThatSetBearerTokenAddsBearerTokenToRequest()
    {
        var httpClient = new HttpClient();

        var actual = httpClient.SetBearerToken("jj39tjg");

        Assert.NotNull(actual.DefaultRequestHeaders.Authorization);
        Assert.Equal("Bearer", actual.DefaultRequestHeaders.Authorization?.Scheme);
        Assert.Equal("jj39tjg", actual.DefaultRequestHeaders.Authorization?.Parameter);
    }

    [Fact]
    public async Task TestThatRunJsonAsyncThrowsInvalidHttpCallExceptionOnInvalidCall()
    {
        await Assert.ThrowsAsync<InvalidHttpCallException>(async () => await HttpUtils.RunJsonAsync<dynamic>(() =>
            throw new()
        ));
    }

    [Fact]
    public async Task TestThatRunJsonAsyncThrowsHttpRequestExceptionIfHttpCodeIsNotIn200Range()
    {
        await Assert.ThrowsAsync<HttpRequestException>(async () => await HttpUtils.RunJsonAsync<dynamic>(() =>
            Task.FromResult(new HttpResponseMessage(HttpStatusCode.BadRequest))
        ));
    }

    [Fact]
    public async Task TestThatRunJsonAsyncThrowsInvalidJsonResponseExceptionOnInvalidJsonResponse()
    {
        var actualException = await Assert.ThrowsAsync<InvalidJsonResponseException>(async () => await HttpUtils.RunJsonAsync<UnitTestDto?>(() =>
            Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("null") })
        ));

        Assert.Equal("The JSON is malformed or cannot be transformed to type 'UnitTestDto'", actualException.Message);
    }

    [Fact]
    public async Task TestThatRunJsonAsyncThrowsInvalidJsonResponseExceptionOnException()
    {
        var actualException = await Assert.ThrowsAsync<InvalidJsonResponseException>(async () => await HttpUtils.RunJsonAsync<dynamic>(() =>
            Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("") })
        ));

        Assert.Equal("The JSON is malformed", actualException.Message);
    }

    [Fact]
    public async Task TestThatRunJsonAsyncReturnsParsedObject()
    {
        var actual = await HttpUtils.RunJsonAsync<UnitTestDto>(() =>
            Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{\"id\": 42}") })
        );

        Assert.NotNull(actual);
        Assert.Equal(42, actual.Id);
    }

    #region Unit Test Classes

    public class UnitTestDto
    {
        public int Id { get; set; }
    }

    #endregion
}