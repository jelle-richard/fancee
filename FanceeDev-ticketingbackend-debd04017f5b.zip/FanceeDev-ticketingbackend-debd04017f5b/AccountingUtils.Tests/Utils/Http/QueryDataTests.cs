using AccountingUtils.Utils.Http;

namespace AccountingUtils.Tests.Utils.Http;

public class QueryDataTests
{
    [Fact]
    public void TestThatBuildUrlCreatesUrlFromObject()
    {
        var sut = new QueryDataClass
        {
            String = "my string",
            Int = 20,
            Bool = true
        };

        var actual = sut.BuildUrl("https://base");

        Assert.NotEmpty(actual);
        Assert.Equal("https://base?String=my%20string&Int=20&Bool=True", actual);
    }

    #region Unit Test Classes

    private class QueryDataClass : QueryData
    {
        public string String { get; set; } = default!;
        public int Int { get; set; }
        public bool Bool { get; set; }
    }

    #endregion
}