using AccountingUtils.Utils.Http;

namespace AccountingUtils.Tests.Utils.Http;

public class UrlEncodedPostDataTests
{
    [Fact]
    public void TestThatGetHttpContentReturnsFormUrlEncodedContent()
    {
        var sut = new UrlEncodedPostDataClass
        {
            Int = 42,
            String = "my string",
            Bool = true
        };

        var actual = sut.GetHttpContent();

        Assert.IsType<FormUrlEncodedContent>(actual);
        Assert.Equal("Int=42&String=my+string&Bool=True", actual.ReadAsStringAsync().Result);
    }

    #region Unit Test Classes

    private class UrlEncodedPostDataClass : UrlEncodedPostData
    {
        public int Int { get; set; }
        public string String { get; set; } = default!;
        public bool Bool { get; set; }
    }

    #endregion
}