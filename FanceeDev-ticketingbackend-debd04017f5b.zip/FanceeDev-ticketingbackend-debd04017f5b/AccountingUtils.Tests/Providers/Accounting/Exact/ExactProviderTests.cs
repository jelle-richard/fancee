using System.Net;
using System.Net.Mime;
using AccountingUtils.Config;
using AccountingUtils.Providers.Accounting.Exact;
using AccountingUtils.Providers.Accounting.Exact.Exceptions;
using AccountingUtils.Providers.Accounting.Exact.Requests;
using AccountingUtils.Providers.Accounting.Exact.Responses;
using Microsoft.Net.Http.Headers;
using TestCore.Mocks;

namespace AccountingUtils.Tests.Providers.Accounting.Exact;

public class ExactProviderTests
{
    private const int Division = 42;

    private readonly ExactProvider _sut;
    private readonly Mock<HttpMessageHandler> _mockedHandler;

    public ExactProviderTests()
    {
        var exactConfiguration = new ExactConfiguration
        {
            BaseUrl = "https://base",
            ClientId = "client-id",
            ClientSecret = "client-secret",
            OAuthRedirectDomain = "https://redirect"
        };
        _mockedHandler = new();
        var mockedHttpClientFactory = new Mock<IHttpClientFactory>();

        var httpClient = new HttpClient(_mockedHandler.Object)
        {
            BaseAddress = new($"{exactConfiguration.BaseUrl}/"),
            DefaultRequestHeaders = { { HeaderNames.Accept, MediaTypeNames.Application.Json } }
        };

        mockedHttpClientFactory.Setup(hcf => hcf.CreateClient("Exact"))
            .Returns(httpClient);

        _sut = new(exactConfiguration, mockedHttpClientFactory.Object);
    }

    [Fact]
    public void TestThatSetTokenSetsToken()
    {
        var actual = _sut.SetToken("my-token");

        Assert.NotNull(actual);
        Assert.Equal("my-token", _sut.Token);
    }

    [Fact]
    public void TestThatOAuthRedirectUrlReturnsRedirectUrl()
    {
        const string redirectUrl = "https://redirect";

        var actual = _sut.OAuthRedirectUrl(redirectUrl);

        Assert.Equal("https://base/oauth2/auth?client_id=client-id&redirect_uri=https%3A%2F%2Fredirect&response_type=code&force_login=0", actual);
    }

    [Fact]
    public async Task TestThatTokenAsyncCallsOAuth2TokenEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"access_token":"access","token_type":"type","expires_in":3600,"refresh_token":"refresh"}""")
            });

        var actual = await _sut.TokenAsync("code", "https://redirect");

        Assert.NotNull(actual);
        Assert.Equal("access", actual.AccessToken);
        Assert.Equal("type", actual.TokenType);
        Assert.Equal("refresh", actual.RefreshToken);
        Assert.Equal(3600, actual.ExpiresIn);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "oauth2/token"
        );
    }

    [Fact]
    public async Task TestThatRefreshTokenAsyncCallsTokenEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"access_token":"access","token_type":"type","expires_in":3600,"refresh_token":"refresh"}""")
            });

        var actual = await _sut.RefreshTokenAsync("refreshToken");

        Assert.NotNull(actual);
        Assert.Equal("access", actual.AccessToken);
        Assert.Equal("type", actual.TokenType);
        Assert.Equal("refresh", actual.RefreshToken);
        Assert.Equal(3600, actual.ExpiresIn);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "/oauth2/token"
        );
    }

    [Fact]
    public async Task TestThatCurrentDivisionAsyncThrowsExactMissingDataExceptionOnInvalidResult()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"results":[]}}""")
            });

        _sut.SetToken("my-token");

        var actualException = await Assert.ThrowsAsync<ExactMissingDataException>(async () => await _sut.CurrentDivisionAsync());

        Assert.Equal("Could not get property 'AccountingDivision' from the Exact response", actualException.Message);
    }

    [Fact]
    public async Task TestThatCurrentDivisionAsyncCallsMeEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"results":[{"AccountingDivision":42}]}}""")
            });
        _sut.SetToken("my-token");

        var actual = await _sut.CurrentDivisionAsync();

        Assert.Equal(Division, actual);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            "/v1/current/Me"
        );
    }

    [Fact]
    public async Task TestThatJournalsAsyncCallsJournalsEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"results":[{"ID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F","Code":"journal-code","AllowVariableCurrency":true,"Type":20,"IsBlocked":false}]}}""")
            });

        var actual = (await _sut.JournalsAsync(Division)).ToList();

        Assert.Single(actual);
        Assert.Equal(Guid.Parse("EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"), actual[0].Id);
        Assert.Equal("journal-code", actual[0].Code);
        Assert.True(actual[0].AllowVariableCurrency);
        Assert.False(actual[0].Blocked);
        Assert.Equal(JournalResponse.JournalType.Sales, actual[0].Type);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/financial/Journals"
        );
    }

    [Fact]
    public async Task TestThatAccountsAsyncCallsAccountsEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"results":[{"ID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F","Name":"Unit Tester","Status":"C"}]}}""")
            });

        var actual = (await _sut.AccountsAsync(Division, null)).ToList();

        Assert.Single(actual);
        Assert.Equal(Guid.Parse("EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"), actual[0].Id);
        Assert.Equal("Unit Tester", actual[0].Name);
        Assert.Equal("C", actual[0].Status);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/crm/Accounts?$filter=Status eq %27C%27"
        );
    }

    [Fact]
    public async Task TestThatAccountsAsyncFiltersOnName()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"results":[{"ID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F","Name":"Unit Tester","Status":"C"}]}}""")
            });

        var actual = (await _sut.AccountsAsync(Division, "Unit Tester")).ToList();

        Assert.Single(actual);
        Assert.Equal(Guid.Parse("EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"), actual[0].Id);
        Assert.Equal("Unit Tester", actual[0].Name);
        Assert.Equal("C", actual[0].Status);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/crm/Accounts?$filter=Status eq %27C%27 and Name eq %27Unit Tester%27"
        );
    }

    [Fact]
    public async Task TestThatItemsAsyncCallsItemsEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"results":[{"ID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F","Code":"ItemCode","UnitType":"T"}]}}""")
            });

        var actual = (await _sut.ItemsAsync(Division)).ToList();

        Assert.Single(actual);
        Assert.Equal(Guid.Parse("EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"), actual[0].Id);
        Assert.Equal("ItemCode", actual[0].Code);
        Assert.Equal("T", actual[0].UnitType);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/logistics/Items?$select="
        );
    }

    [Fact]
    public async Task TestThatCreateUserAsyncCallsAccountsEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"ID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"}}""")
            });

        var actual = await _sut.CreateUserAsync(Division, new());

        Assert.Equal(Guid.Parse("EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"), actual);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/crm/Accounts"
        );
    }

    [Fact]
    public async Task TestThatCreateSalesInvoiceAsyncCallsSalesInvoicesEndpoint()
    {
        _mockedHandler.SetupSendAsync()
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"InvoiceID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F","InvoiceNumber":123}}""")
            });

        var actual = await _sut.CreateSalesInvoiceAsync(Division, new());

        Assert.Equal(Guid.Parse("EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"), actual.InvoiceId);
        Assert.Equal(123, actual.InvoiceNumber);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/salesinvoice/SalesInvoices"
        );
    }

    [Fact]
    public async Task TestThatUploadDocumentAsyncCallsDocumentsAndDocumentAttachmentsEndpoints()
    {
        _mockedHandler.SetupSendAsync("/Documents")
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"ID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F","Subject":"invoice"}}""")
            });

        _mockedHandler.SetupSendAsync("/DocumentAttachments")
            .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("""{"d":{"ID":"EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F","FileName":"invoice.pdf","FileSize":40964096}}""")
            });

        var accountId = Guid.NewGuid();

        var actual = await _sut.UploadDocumentAsync(Division, "invoice", DocumentType.PurchaseEntry, "invoice.pdf", "base64content", accountId);

        Assert.Equal(Guid.Parse("EA8E1DE5-DD6D-47E1-9B75-4732D9F4509F"), actual);

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/documents/Documents"
        );

        _mockedHandler.VerifySendAsync(
            Times.Once(),
            $"/v1/{Division}/documents/DocumentAttachments"
        );
    }
}