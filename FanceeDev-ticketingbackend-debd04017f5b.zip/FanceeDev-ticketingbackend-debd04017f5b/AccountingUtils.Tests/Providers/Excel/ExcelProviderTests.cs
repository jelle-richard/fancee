using AccountingUtils.Providers.Excel;
using ClosedXML.Excel;

namespace AccountingUtils.Tests.Providers.Excel;

public class ExcelProviderTests
{
    private readonly ExcelProvider _sut;

    public ExcelProviderTests()
    {
        _sut = new();
    }

    [Fact]
    public void TestThatCreateWorkbookCreatesWorkbookFromStream()
    {
        var file = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Mocks", "Files", "Book1.xlsx");

        var actual = _sut.CreateWorkbook(new StreamReader(file).BaseStream);

        Assert.NotNull(actual);
        Assert.IsType<XLWorkbook>(actual);
    }
}