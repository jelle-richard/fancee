using AccountingUtils.Providers.Bank.Ing;
using AccountingUtils.Providers.Bank.Models;
using AccountingUtils.Providers.Excel;
using ClosedXML.Excel;

namespace AccountingUtils.Tests.Providers.Bank.Ing;

public class IngBankExportProviderTests
{
    private readonly IngBankExportProvider _sut;
    private readonly Mock<IExcelProvider> _mockedExcelProvider = new();
    private readonly Mock<IXLWorkbook> _mockedWorkbook = new();

    public IngBankExportProviderTests()
    {
        _mockedExcelProvider.Setup(ep => ep.CreateWorkbook(It.IsAny<Stream>()))
            .Returns(_mockedWorkbook.Object);

        _mockedExcelProvider.Setup(ep => ep.CreateWorkbook())
            .Returns(_mockedWorkbook.Object);

        _sut = new(_mockedExcelProvider.Object);
    }

    [Fact]
    public void TestThatCreatePayoutExportCreatesIbanExport()
    {
        var mockedWorksheet = new Mock<IXLWorksheet>();
        _mockedWorkbook.Setup(w => w.Worksheet(1)).Returns(mockedWorksheet.Object);
        mockedWorksheet.Setup(w => w.Cell(It.IsAny<string>())).Returns(new Mock<IXLCell>().Object);

        var actual = _sut.CreatePayoutExport(new()
        {
            DebtorBankAccountHolderName = "Unit Tester",
            DebtorIban = "NL99TEST1234562341",
            ExecuteOn = DateOnly.Parse("2022-12-12"),
            Rows = new PayoutRow[]
            {
                new()
                {
                    ReceiverIban = "NL88TEST12348904565",
                    BankAccountHolderName = "Unit Receiver",
                    ValueEurCents = 123123
                }
            }
        });

        Assert.Single(actual);

        _mockedWorkbook.Verify(w => w.Worksheet(1), Times.Once);
        _mockedWorkbook.Verify(w => w.SaveAs(It.IsAny<MemoryStream>()), Times.Once);
        _mockedWorkbook.Verify(w => w.AddWorksheet(), Times.Never);
    }

    [Fact]
    public void TestThatCreatePayoutExportCreatesBankAccountExport()
    {
        var mockedWorksheet = new Mock<IXLWorksheet>();
        _mockedWorkbook.Setup(w => w.AddWorksheet()).Returns(mockedWorksheet.Object);
        mockedWorksheet.Setup(w => w.Row(1).Style.Font).Returns(new Mock<IXLFont>().Object);
        mockedWorksheet.Setup(w => w.Columns(1, 6)).Returns(new Mock<IXLColumns>().Object);
        mockedWorksheet.Setup(w => w.Cell(It.IsAny<int>(), It.IsAny<int>())).Returns(() =>
        {
            var mockedCell = new Mock<IXLCell>();
            var mockedStyle = new Mock<IXLStyle>();
            mockedCell.Setup(c => c.SetDataType(It.IsAny<XLDataType>())).Returns(mockedCell.Object);
            mockedCell.Setup(c => c.SetValue(It.IsAny<It.IsAnyType>())).Returns(mockedCell.Object);
            mockedCell.Setup(c => c.Style).Returns(mockedStyle.Object);

            mockedStyle.Setup(s => s.Alignment).Returns(new Mock<IXLAlignment>().Object);
            mockedStyle.Setup(s => s.NumberFormat).Returns(new Mock<IXLNumberFormat>().Object);

            return mockedCell.Object;
        });

        var actual = _sut.CreatePayoutExport(new()
        {
            DebtorBankAccountHolderName = "Unit Tester",
            DebtorIban = "NL99TEST1234562341",
            ExecuteOn = DateOnly.Parse("2022-12-12"),
            Rows = new PayoutRow[]
            {
                new()
                {
                    ReceiverBankAccountNumber = "9876542",
                    ReceiverBic = "INGBNL2A",
                    BankAccountHolderName = "Unit Receiver",
                    ValueEurCents = 123123
                }
            }
        });

        Assert.Single(actual);

        _mockedWorkbook.Verify(w => w.AddWorksheet(), Times.Once);
        _mockedWorkbook.Verify(w => w.SaveAs(It.IsAny<MemoryStream>()), Times.Once);
    }

    [Fact]
    public void TestThatCreatePayoutExportCreatesMultipleFilesIfRowsAreOverBatchLimit()
    {
        var mockedWorksheet = new Mock<IXLWorksheet>();
        _mockedWorkbook.Setup(w => w.Worksheet(1)).Returns(mockedWorksheet.Object);
        mockedWorksheet.Setup(w => w.Cell(It.IsAny<string>())).Returns(new Mock<IXLCell>().Object);

        var actual = _sut.CreatePayoutExport(new()
        {
            DebtorBankAccountHolderName = "Unit Tester",
            DebtorIban = "NL99TEST1234562341",
            ExecuteOn = DateOnly.Parse("2022-12-12"),
            Rows = Enumerable.Range(0, 1100).Select(i => new PayoutRow
            {
                ReceiverIban = "NL88TEST12348904565",
                BankAccountHolderName = "Unit Receiver",
                ValueEurCents = 123123
            })
        });

        Assert.Equal(2, actual.Count);

        _mockedWorkbook.Verify(w => w.Worksheet(1), Times.Exactly(2));
        _mockedWorkbook.Verify(w => w.SaveAs(It.IsAny<MemoryStream>()), Times.Exactly(2));
    }
}