import type { IconNames } from '@fancee/flux';
import { ChannelType } from '@/data/enum/analytics/api';

export default function (channelType: ChannelType): IconNames {
    switch (channelType) {
        case ChannelType.Facebook:
        case ChannelType.FacebookAds:
        case ChannelType.FacebookPublicData:
            return 'facebook';

        case ChannelType.Instagram:
        case ChannelType.InstagramPublicData:
            return 'instagram';

        case ChannelType.GoogleAnalytics:
        case ChannelType.GoogleAnalytics4:
        case ChannelType.GoogleAds:
            return 'google';

        case ChannelType.Youtube:
        case ChannelType.YoutubeV2:
            return 'youtube';

        case ChannelType.LinkedIn:
            return 'linkedin';

        case ChannelType.TikTok:
            return 'tiktok';
    }
}
