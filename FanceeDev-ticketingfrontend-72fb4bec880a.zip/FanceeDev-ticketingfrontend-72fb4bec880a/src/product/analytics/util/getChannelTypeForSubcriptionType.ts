import { ChannelType, SubscriptionType } from '@/data/enum/analytics/api';

export default function (subscriptionType: SubscriptionType): ChannelType {
    switch (subscriptionType) {
        case SubscriptionType.FacebookPage:
        case SubscriptionType.FacebookPosts:
        case SubscriptionType.FacebookGeography:
        case SubscriptionType.FacebookAgeAndGender:
            return ChannelType.Facebook;

        case SubscriptionType.FacebookAdsCampaign:
        case SubscriptionType.FacebookAdsAds:
        case SubscriptionType.FacebookAdsVideo:
        case SubscriptionType.FacebookAdsConversion:
        case SubscriptionType.FacebookAdsGeo:
        case SubscriptionType.FacebookAdsAgeAndGender:
            return ChannelType.FacebookAds;

        case SubscriptionType.FacebookPublicDataPage:
        case SubscriptionType.FacebookPublicDataPosts:
        case SubscriptionType.FacebookPublicDataUrlShares:
            return ChannelType.FacebookPublicData;

        case SubscriptionType.InstagramFollowers:
        case SubscriptionType.InstagramProfile:
        case SubscriptionType.InstagramMedia:
        case SubscriptionType.InstagramGeography:
        case SubscriptionType.InstagramAgeAndGender:
            return ChannelType.Instagram;

        case SubscriptionType.InstagramPublicDataPosts:
        case SubscriptionType.InstagramPublicDataProfiles:
        case SubscriptionType.InstagramPublicDataHashtags:
            return ChannelType.InstagramPublicData;

        case SubscriptionType.GoogleAnalyticsTraffic:
        case SubscriptionType.GoogleAnalyticsPaidTraffic:
        case SubscriptionType.GoogleAnalyticsSearch:
        case SubscriptionType.GoogleAnalyticsUser:
        case SubscriptionType.GoogleAnalyticsTechnology:
        case SubscriptionType.GoogleAnalyticsContent:
        case SubscriptionType.GoogleAnalyticsECommerse:
        case SubscriptionType.GoogleAnalyticsSocial:
        case SubscriptionType.GoogleAnalyticsEvents:
            return ChannelType.GoogleAnalytics;

        case SubscriptionType.GoogleAnalytics4Device:
        case SubscriptionType.GoogleAnalytics4Publishing:
        case SubscriptionType.GoogleAnalytics4Engagement:
        case SubscriptionType.GoogleAnalytics4UserAcquisition:
        case SubscriptionType.GoogleAnalytics4TrafficAcquisition:
            return ChannelType.GoogleAnalytics4;

        case SubscriptionType.YoutubeVideo:
            return ChannelType.Youtube;

        case SubscriptionType.YoutubeV2AdPerformance:
        case SubscriptionType.YoutubeV2Demographic:
        case SubscriptionType.YoutubeV2Video:
        case SubscriptionType.YoutubeV2Channel:
        case SubscriptionType.YoutubeV2Geo:
        case SubscriptionType.YoutubeV2Device:
        case SubscriptionType.YoutubeV2TrafficSource:
            return ChannelType.YoutubeV2;

        case SubscriptionType.LinkedInPage:
        case SubscriptionType.LinkedInPost:
        case SubscriptionType.LinkedInCountry:
            return ChannelType.LinkedIn;

        case SubscriptionType.GoogleAdsCampaign:
        case SubscriptionType.GoogleAdsAd:
        case SubscriptionType.GoogleAdsKeyword:
        case SubscriptionType.GoogleAdsPlacement:
        case SubscriptionType.GoogleAdsConversion:
        case SubscriptionType.GoogleAdsSearchQuery:
        case SubscriptionType.GoogleAdsShopping:
        case SubscriptionType.GoogleAdsGeo:
        case SubscriptionType.GoogleAdsAge:
        case SubscriptionType.GoogleAdsGender:
            return ChannelType.GoogleAds;

        case SubscriptionType.TikTokProfile:
        case SubscriptionType.TikTokVideo:
        case SubscriptionType.TikTokCountry:
        case SubscriptionType.TikTokGender:
            return ChannelType.TikTok;
    }
}
