import { ChannelType } from '@/data/enum/analytics/api';

export default function (channelType: ChannelType): string {
    switch (channelType) {
        case ChannelType.Facebook:
        case ChannelType.FacebookAds:
        case ChannelType.FacebookPublicData:
            return '/assets/icons/facebook.svg';

        case ChannelType.Instagram:
        case ChannelType.InstagramPublicData:
            return '/assets/icons/instagram.svg';

        case ChannelType.GoogleAnalytics:
        case ChannelType.GoogleAnalytics4:
            return '/assets/icons/googleanalytics.svg';

        case ChannelType.GoogleAds:
            return '/assets/icons/googleads.svg';

        case ChannelType.Youtube:
        case ChannelType.YoutubeV2:
            return '/assets/icons/youtube.svg';

        case ChannelType.LinkedIn:
            return '/assets/icons/linkedin.svg';

        case ChannelType.TikTok:
            return '/assets/icons/tiktok.svg';
    }
}
