import type { IconNames } from '@fancee/flux';

export default function getFieldTypeIcon(fieldType?: string): IconNames {
    if (!fieldType) {
        return 'question';
    }

    if (fieldType.startsWith('string')) {
        return 'text';
    }

    if (fieldType.startsWith('int') || fieldType.startsWith('float')) {
        return 'hashtag';
    }

    return 'question';
}
