import type { SubscriptionType } from '@/data/enum/analytics/api';
import getChannelTypeForSubcriptionType from './getChannelTypeForSubcriptionType';
import getChannelTypeSVGPath from './getChannelTypeSVGPath';

export default function (subscriptionType: SubscriptionType): string {
    return getChannelTypeSVGPath(getChannelTypeForSubcriptionType(subscriptionType));
}
