import type { IconNames } from '@fancee/flux';
import type { SubscriptionType } from '@/data/enum/analytics/api';
import getChannelTypeForSubcriptionType from './getChannelTypeForSubcriptionType';
import getChannelTypeIcon from './getChannelTypeIcon';

export default function (subscriptionType: SubscriptionType): IconNames {
    return getChannelTypeIcon(getChannelTypeForSubcriptionType(subscriptionType));
}
