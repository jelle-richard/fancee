<template>
    <FluxGrid>
        <FluxGridColumn :sm="5">
            <MultiSumFollowersCard
                :channels="channels"
                :startDate="startDate"
                :endDate="endDate"/>
        </FluxGridColumn>

        <FluxGridColumn :sm="3">
            <MultiSumReachCard
                :channels="channels"
                :startDate="startDate"
                :endDate="endDate"/>
        </FluxGridColumn>

        <FluxGridColumn :sm="4">
            <MultiSumEngagementCard
                :channels="channels"
                :startDate="startDate"
                :endDate="endDate"/>
        </FluxGridColumn>

        <FluxGridColumn :sm="8">
            <MultiSumBestTimeToPostCard
                :title="t('analytics.bestPostTime.title')"
                :channels="channels"
                :startDate="startDate"
                :endDate="endDate"/>
        </FluxGridColumn>

        <FluxGridColumn :sm="4">
            <MultiSumLocationsCard
                :channels="channels"
                :startDate="startDate"
                :endDate="endDate"
                :max="7"/>
        </FluxGridColumn>

        <FluxGridColumn :sm="12">
            <MultiSumPostsCard
                :channels="channels"
                :startDate="startDate"
                :endDate="endDate"/>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    setup
    lang="ts">
    import type { DateTime } from 'luxon';
    import { useI18n } from 'vue-i18n';
    import type { Channel } from '@/data/dto/analytics/channels';
    import MultiSumFollowersCard from '@/components/analytics/dashboard/MultiSumFollowersCard.vue';
    import MultiSumEngagementCard from '@/components/analytics/dashboard/MultiSumEngagementCard.vue';
    import MultiSumPostsCard from '@/components/analytics/dashboard/MultiSumPostsCard.vue';
    import MultiSumReachCard from '@/components/analytics/dashboard/MultiSumReachCard.vue';
    import MultiSumLocationsCard from '@/components/analytics/dashboard/MultiSumLocationsCard.vue';
    import MultiSumBestTimeToPostCard from '@/components/analytics/dashboard/MultiSumBestTimeToPostCard.vue';

    export type Props = {
        channels: Channel[];
        startDate: DateTime;
        endDate: DateTime;
    };

    defineProps<Props>();

    const {t} = useI18n();
</script>
