<template>
    <FluxStack
        gap="15"
        axis="horizontal">
        <FluxStack
            v-if="isSelection"
            axis="horizontal">

            <FluxSecondaryButton
                icon-before="chevron-left"
                :label="t('global.back')"
                @click="emit('back')"/>
            <FluxSpacer/>
        </FluxStack>

        <h5 v-if="title && !isSelection">{{ title }}</h5>

        <slot name="header"/>

        <FluxSpacer/>

        <FluxFlyout ref="datepickerFlyoutRef">
            <template #opener="{open}">
                <FluxFormInputGroup>
                    <FluxFormInputAddition :text="t('global.date')"/>

                    <FluxSecondaryButton
                        icon-after="chevron-down"
                        :label="periodLabel"
                        @click="open"/>
                </FluxFormInputGroup>
            </template>

            <template #default>
                <FluxStack
                    axis="horizontal"
                    gap="0">
                    <FluxStack
                        axis="vertical"
                        gap="0"
                        class="date-options-container">
                        <FluxSecondaryButton
                            v-for="item in dateOptions"
                            :key="item.id"
                            :label="item.label"
                            @click="selectDateOption(item.id!)"/>
                    </FluxStack>

                    <FluxSeparator axis="vertical"/>

                    <FluxDatePicker
                        v-model="datesSelected"
                        class="calendar"
                        range-mode="range"/>
                </FluxStack>
            </template>
        </FluxFlyout>

        <FluxFlyout
            v-if="channels.length > 0"
            ref="channelsFlyoutRef">
            <template #opener="{open}">
                <FluxFormInputGroup>
                    <FluxFormInputAddition :text="t('analytics.channel.singular')"/>

                    <FluxSecondaryButton
                        icon-after="chevron-down"
                        :label="channelSelection.label"
                        @click="open"/>
                </FluxFormInputGroup>
            </template>

            <template #default>
                <FluxMenu>
                    <FluxMenuGroup>
                        <FluxMenuItem
                            v-for="item in channelOptions"
                            :key="item.id"
                            :icon-before="item.channelType === null ? 'calendar' : null"
                            :image-url="item.channelType !== null ? getChannelTypeSVGPath(item.channelType) : null"
                            :is-highlighted="channelSelection.id === item.id"
                            :label="item.label"
                            @click="selectChannelType(item)"/>
                    </FluxMenuGroup>
                </FluxMenu>
            </template>
        </FluxFlyout>

        <slot name="header-right"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { FluxFormSelectOption, IconNames } from '@fancee/flux';
    import { DateTime, DateTimeFormatOptions } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { getChannelTypeSVGPath } from '@/product/analytics/util';

    type ChannelSelectOption = {
        id: string,
        label: string,
        channelType: ChannelType | null,
        icon?: IconNames
    };

    export type Emits = {
        (e: 'back'): void;
        (e: 'update-channels', channels: Channel[]): void;
        (e: 'update-dates', startDate: DateTime, endDate: DateTime): void;
    };

    export type Props = {
        title?: string | null;
        channels: Channel[];
        startDate: DateTime;
        endDate: DateTime;
        isSelection?: boolean | false;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();

    const allTypesOption: ChannelSelectOption = {id: 'all', label: t('analytics.header.allChannels'), icon: 'home', channelType: null};
    const periodFormat: DateTimeFormatOptions = {month: 'short', day: '2-digit', year: 'numeric'};

    const dateOptions = computed((): FluxFormSelectOption[] => [
        {id: 'last_7_days', label: t('analytics.header.datePresets.lastSevenDays')},
        {id: 'last_month', label: t('analytics.header.datePresets.lastMonth')},
        {id: 'this_month', label: t('analytics.header.datePresets.thisMonth')},
        {id: 'this_year', label: t('analytics.header.datePresets.thisYear')}
    ]);

    const datesSelected = ref([unref(startDate), unref(endDate)]);
    const channelSelection = ref(allTypesOption);

    const datepickerFlyoutRef = ref();
    const channelsFlyoutRef = ref();

    const filteredChannels = computed((): Channel[] => {
        const currentChannelSelection = unref(channelSelection);
        return currentChannelSelection.id === allTypesOption.id ? unref(channels) : unref(channels).filter(channel => channel.type === currentChannelSelection.channelType);
    });

    const channelOptions = computed((): ChannelSelectOption[] => {
        const currentChannels = unref(channels);

        if (currentChannels.length === 0) {
            return [];
        }

        const typeOnlyList = [...new Set(currentChannels.map<ChannelType>(channel => channel?.type))];
        return [
            unref(allTypesOption),
            ...typeOnlyList
                .map<ChannelSelectOption>(entry => ({id: entry, label: t(`analytics.channel.type.${entry.toLowerCase()}`), channelType: entry}))
                .sort((a, b) => a.label.localeCompare(b.label))
        ];
    });

    const periodLabel = computed((): string => `${unref(startDate).toLocaleString(periodFormat)}  -  ${unref(endDate).toLocaleString(periodFormat)}`);

    function selectDateOption(id: string | number): void {
        switch (id) {
            case 'last_7_days':
                datesSelected.value = [DateTime.now().minus({days: 7}), DateTime.now()];
                break;

            case 'last_month':
                datesSelected.value = [DateTime.now().set({day: 1}).minus({month: 1}), DateTime.now().set({day: 1}).minus({day: 1})];
                break;

            case 'this_month':
                datesSelected.value = [DateTime.now().set({day: 1}), DateTime.now()];
                break;

            case 'this_year':
                datesSelected.value = [DateTime.now().set({day: 1, month: 1}), DateTime.now()];
                break;
        }
    }

    function selectChannelType(option: ChannelSelectOption): void {
        channelSelection.value = option;
        channelsFlyoutRef.value.close();
    }

    watch(channelSelection, () => {
        emit('update-channels', unref(filteredChannels));
    }, {immediate: true});

    watch(datesSelected, () => {
        emit('update-dates', datesSelected.value[0], datesSelected.value[1]);
        datepickerFlyoutRef.value.close();
    });
</script>

<style
    lang="scss"
    scoped>
    .date-options-container {
        padding: 1rem;

        .flux-button {
            justify-content: flex-start;
            border: none;
        }
    }

    .calendar {
        min-width: 300px;
    }

    h5 {
        align-items: flex-end;
        justify-content: center;
        display: inline-flex;
        color: var(--foreground-prominent);
    }

    ::v-deep(.flux-form-select) > .flux-menu-item {
        display: contents;
    }

    ::v-deep(.flux-form-input) {
        white-space: nowrap;
        max-width: none;
        width: auto;

        &.flux-form-select {
            flex: 0;
            padding: 0 12px;
        }

        &[is-disabled=true] {
            outline: none;
            cursor: auto;

            > .flux-form-input {
                background: var(--gray-4);
                cursor: auto;
            }
        }

        .flux-form-select-popup {
            width: auto;
        }
    }

    ::v-deep(.flux-menu-item-image) {
        margin-left: 0;
        height: 18px;
        width: 18px;
    }
</style>
