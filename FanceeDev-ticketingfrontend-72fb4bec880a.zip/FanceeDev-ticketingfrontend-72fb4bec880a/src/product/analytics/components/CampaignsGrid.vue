<template>
    <FluxGrid>
        <FluxGridColumn
            v-if="title"
            :sm="12">
            <h5>{{ title }}</h5>
        </FluxGridColumn>

        <FluxGridColumn :sm="3">
            <MultiSumStatusCard
                :title="t('analytics.totalCampaigns.title')"
                :header-link="headerLink"
                :items="statusItems"
                :is-loading="isLoading"/>
        </FluxGridColumn>

        <FluxGridColumn :sm="3">
            <MultiSumRadialBarCard
                :title="t('analytics.spent.title')"
                :header-link="headerLink"
                :items="spentItems"
                :budget="budget"
                :spent="spent"
                :is-loading="isLoading"/>
        </FluxGridColumn>

        <FluxGridColumn :sm="6">
            <MultiSumStatisticsCard
                :title="t('analytics.engagement.title')"
                :header-link="headerLink"
                :items="engagementItems"
                :is-loading="isLoading"/>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useCurrency, useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumCampaignItem } from '@/data/dto/analytics/dashboard';
    import { DashboardService } from '@/data/service';
    import { asCompactNumber, asMoney, decimalToCents } from '@/util';
    import MultiSumStatusCard from '@/components/analytics/campaigns/MultiSumStatusCard.vue';
    import MultiSumStatisticsCard from '@/components/analytics/campaigns/MultiSumStatisticsCard.vue';
    import MultiSumRadialBarCard from '@/components/analytics/campaigns/MultiSumRadialBarCard.vue';

    interface Props {
        title?: string | null;
        showHeaderLink?: boolean;
        channels: Channel[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = withDefaults(defineProps<Props>(), {
        showHeaderLink: true
    });
    const {channels, startDate, endDate, showHeaderLink} = toRefs(props);

    const {t} = useI18n();
    const {getSumCampaigns} = useService(DashboardService);
    const currency = useCurrency();

    const campaignsSummary = ref<SumCampaignItem | null>(null);
    const isLoading = ref(false);

    const headerLink = computed(() => {
        if (!unref(showHeaderLink)) {
            return null;
        }

        return {label: t('analytics.fullOverview'), value: {name: 'analytics-campaign'}};
    });

    const statusItems = computed(() => {
        const statusFromJson = JSON.parse(unref(campaignsSummary)?.status ?? '[]');
        return statusFromJson.map((status: any) => ({
            label: t(`analytics.totalCampaigns.${status.label}`),
            value: status.count,
            color: status.label === 'enabled' ? 'success' : 'warning'
        }));
    });

    const budget = computed((): number | null => unref(campaignsSummary)?.budget ?? null);
    const spent = computed((): number | null => unref(campaignsSummary)?.cost ?? null);

    const spentItems = computed(() => {
        const _currency = unref(currency);
        const currentCampaignsSummary = unref(campaignsSummary);

        return [
            {
                label: t('analytics.spent.total'),
                value: asMoney(decimalToCents(currentCampaignsSummary?.cost ?? 0, _currency), _currency)
            },
            {
                label: t('analytics.spent.budget'),
                value: asMoney(decimalToCents(currentCampaignsSummary?.budget ?? 0, _currency), _currency)
            }
        ];
    });

    const engagementItems = computed(() => {
        const _Currency = unref(currency);
        const _CampaignsSummary = unref(campaignsSummary);

        return [
            {
                label: t('analytics.engagement.impressions'),
                value: asCompactNumber(Math.floor(_CampaignsSummary?.impressions ?? 0))
            },
            {
                label: t('analytics.engagement.clicks'),
                value: asCompactNumber(Math.floor(_CampaignsSummary?.clicks ?? 0))
            },
            {
                label: t('analytics.engagement.cpc'),
                value: asMoney(decimalToCents(_CampaignsSummary?.cpc ?? 0, _Currency), _Currency)
            },
            {
                label: t('analytics.engagement.ctr'),
                value: `${Math.round((_CampaignsSummary?.ctr ?? 0.0) * 100) / 100}`
            },
            {
                label: t('analytics.engagement.conversion'),
                value: `${Math.round((_CampaignsSummary?.conversion ?? 0.0) * 100)}%`
            }
        ];
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumCampaigns(props.channels, props.startDate, props.endDate);
        campaignsSummary.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    h5 {
        align-items: flex-end;
        display: inline-flex;
        color: var(--foreground-prominent);
    }
</style>
