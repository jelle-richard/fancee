<template>
    <FluxStack>
        <FluxStack axis="horizontal">
            <FluxButtonGroup>
                <FluxSecondaryButton
                    icon-before="calendar"
                    :label="getPeriod"
                    @click="openDateSelector"/>

                <FluxSecondaryButton
                    v-for="item in channelOptions"
                    :key="item.id"
                    :class="item.id!.toString().toLowerCase()"
                    :is-active="channelSelection === item.id"
                    :label="item.label"
                    @click="selectChannel(item.id!.toString())"/>
            </FluxButtonGroup>
        </FluxStack>

        <FluxOverlay>
            <FluxPane v-if="selectingDates">
                <FluxDatePicker
                    v-model="datesSelected"
                    range-mode="range"/>

                <FluxPaneFooter>
                    <FluxSecondaryButton
                        :label="t('global.cancel')"
                        @click="closeDateSelector"/>

                    <FluxSpacer/>

                    <FluxPrimaryButton
                        :label="t('global.continue')"
                        icon-after="circle-arrow-right"
                        @click="onContinueClicked"/>
                </FluxPaneFooter>
            </FluxPane>
        </FluxOverlay>

        <slot
            :data="filteredChannels"
            :startDate="startDate"
            :endDate="endDate"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { FluxFormSelectOption } from '@fancee/flux';
    import { computed, ref, toRefs, unref } from 'vue';
    import { DateTime, DateTimeFormatOptions } from 'luxon';
    import { Channel } from '@/data/dto/analytics/channels';
    import { useI18n } from 'vue-i18n';

    export interface Props {
        readonly channels: Channel[];
    }

    const props = defineProps<Props>();
    const {channels} = toRefs(props);

    const {t} = useI18n();

    const preStart = DateTime.now().minus({days: 14});
    const preEnd = DateTime.now();
    const allTypesOption: FluxFormSelectOption = {id: 'all', label: t('global.all')};
    const periodFormat: DateTimeFormatOptions = {month: 'short', day: '2-digit'};

    const startDate = ref(preStart);
    const endDate = ref(preEnd);
    const selectingDates = ref(false);
    const datesSelected = ref([preStart, preEnd]);
    const channelSelection = ref(allTypesOption.id?.toString());

    const filteredChannels = computed((): Channel[] => {
        const currentChannelSelection = unref(channelSelection);
        return currentChannelSelection === allTypesOption.id ? unref(channels) : unref(channels).filter(channel => channel.type === currentChannelSelection);
    });

    const channelOptions = computed((): FluxFormSelectOption[] => {
        const typeOnlyList = [...new Set(unref(channels).map<string>(channel => channel.type))];
        return [allTypesOption, ...typeOnlyList.map<FluxFormSelectOption>(entry => ({id: entry, label: t(entry.toLowerCase())}))];
    });

    const getPeriod = computed((): string => `${unref(startDate).toLocaleString(periodFormat)}  -  ${unref(endDate).toLocaleString(periodFormat)}`);

    function selectChannel(id: string) {
        channelSelection.value = unref(channelSelection) === id ? allTypesOption.id?.toString() : id;
    }

    function openDateSelector(): void {
        selectingDates.value = true;
    }

    function closeDateSelector(): void {
        selectingDates.value = false;
    }

    function onContinueClicked(): void {
        const currentDates = unref(datesSelected);
        startDate.value = currentDates[0];
        endDate.value = currentDates[1];
        selectingDates.value = false;
    }
</script>

<style
    lang="scss"
    scoped>
    .gap-1 {
        gap: 1rem;
    }

    ::v-deep(.flux-button[is-active="true"]) {
        background-color: rgb(var(--primary-7));

        > * {
            color: white;
        }
    }

    ::v-deep(label.form-control) {
        width: auto;
    }
</style>
