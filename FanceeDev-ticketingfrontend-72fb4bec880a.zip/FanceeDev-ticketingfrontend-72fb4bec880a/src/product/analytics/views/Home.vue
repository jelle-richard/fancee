<template>
    <FluxContainer>
        <ChannelsContainer
            v-slot="channelsProps"
            :starting-page-length="25">
            <FluxSpinner
                v-if="channelsProps.isLoading"
                :class="$style.loader"/>

            <NoChannelsFound v-if="!channelsProps.isLoading && channelsProps.data.length === 0"/>

            <DashboardHeader
                v-if="channelsProps.data.length > 0"
                :title="headerTitle"
                :channels="channelsProps.data.filter(ch => socialChannelTypes.concat(campaignChannelTypes).includes(ch.type))"
                :start-date="startDate"
                :end-date="endDate"
                @update-channels="updateChannels"
                @update-dates="updateDates"/>

            <FluxStack gap="60">
                <SocialsGrid
                    v-if="someSocialChannels"
                    :channels="filteredSocialChannels"
                    :start-date="startDate"
                    :end-date="endDate"/>

                <CampaignsGrid
                    v-if="someCampaignChannels"
                    :title="campaignTitle"
                    :channels="filteredCampaignChannels"
                    :start-date="startDate"
                    :end-date="endDate"/>
            </FluxStack>
        </ChannelsContainer>
    </FluxContainer>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { computed, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { useRememberedValue } from '@/composable';
    import ChannelsContainer from '@/components/analytics/data/channel/ChannelsContainer.vue';
    import DashboardHeader from '@/product/analytics/components/DashboardHeader.vue';
    import SocialsGrid from '@/product/analytics/components/SocialsGrid.vue';
    import CampaignsGrid from '@/product/analytics/components/CampaignsGrid.vue';
    import NoChannelsFound from '@/components/analytics/channels/NoChannelsFound.vue';

    const {t} = useI18n();

    const startDate = useRememberedValue<DateTime>('start-date-analytics', DateTime.now().minus({days: 7}));
    const endDate = useRememberedValue<DateTime>('end-date-analytics', DateTime.now());
    const channels = ref<Channel[]>([]);

    const socialChannelTypes: ChannelType[] = [ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2, ChannelType.LinkedIn, ChannelType.TikTok];
    const campaignChannelTypes: ChannelType[] = [ChannelType.GoogleAds, ChannelType.FacebookAds];

    const someChannels = (types: ChannelType[]): boolean => unref(channels).some(ch => types.includes(ch.type));
    const filterChannels = (types: ChannelType[]): Channel[] => unref(channels).filter(ch => types.includes(ch.type));

    const someSocialChannels = computed((): boolean => someChannels(socialChannelTypes));
    const filteredSocialChannels = computed((): Channel[] => filterChannels(socialChannelTypes));

    const someCampaignChannels = computed((): boolean => someChannels(campaignChannelTypes));
    const filteredCampaignChannels = computed((): Channel[] => filterChannels(campaignChannelTypes));

    const headerTitle = computed((): string | null => {
        if (unref(someSocialChannels)) {
            return t('analytics.titles.social');
        }

        if (unref(someCampaignChannels)) {
            return t('analytics.titles.campaign');
        }

        return null;
    });

    const campaignTitle = computed((): string | null => {
        if (!unref(someSocialChannels)) {
            return null;
        }

        return t('analytics.titles.campaign');
    });

    function updateDates(eventStartDate: DateTime, eventEndDate: DateTime) {
        startDate.value = eventStartDate;
        endDate.value = eventEndDate;
    }

    function updateChannels(eventChannels: Channel[]) {
        channels.value = eventChannels;
    }
</script>

<style module>
    .loader {
        margin: 60px auto;
    }
</style>
