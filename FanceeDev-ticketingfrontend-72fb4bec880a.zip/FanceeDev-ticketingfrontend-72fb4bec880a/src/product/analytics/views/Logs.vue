<template>
    <FluxContainer>
        <LogsContainer v-slot="slotProps">
            <FluxPane :is-loading="slotProps.isLoading">
                <FluxPaneBody>
                    <LogTimeline
                        v-if="slotProps.data"
                        :logs="slotProps.data"
                        user-type="Admin"/>
                </FluxPaneBody>
                <FluxPaneFooter>
                    <FluxPaginationBar
                        :page="slotProps.page"
                        :per-page="slotProps.pageLength"
                        :total="slotProps.totalItems"
                        @limit="slotProps.onPageSizeUpdate"
                        @navigate="slotProps.onPageUpdate"/>
                </FluxPaneFooter>
            </FluxPane>
        </LogsContainer>
    </FluxContainer>
</template>

<script
    setup
    lang="ts">
    import LogsContainer from '@/components/analytics/data/logs/LogsContainer.vue';
    import LogTimeline from '@/components/analytics/timeline/LogTimeline.vue';
</script>
