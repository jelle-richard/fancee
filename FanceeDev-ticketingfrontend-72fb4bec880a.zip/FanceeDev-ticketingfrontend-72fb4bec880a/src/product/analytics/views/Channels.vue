<template>
    <Component
        :is="user?.type === UserType.Admin ? 'FluxStack': 'FluxContainer'"
        gap="0">
        <ChannelsContainer
            v-slot="slotProps"
            ref="channelsContainerRef"
            :startingPageLength="25">
            <FluxPane :is-loading="slotProps.isLoading">
                <FluxActionBar #primary>
                    <FluxPrimaryButton
                        icon-before="circle-plus"
                        :label="t('analytics.channel.singular')"
                        @click="createNewChannel"/>
                </FluxActionBar>

                <ChannelsTable
                    v-if="slotProps.data"
                    :rows="slotProps.data"
                    :key="slotProps.pageSize"
                    :page-size="slotProps.pageSize"
                    :page="slotProps.page"
                    :total-items="slotProps.totalItems"
                    :order-by="slotProps.orderBy"
                    :order-by-direction="slotProps.orderByDirection"
                    :interactive="false"
                    @on-order-update="onOrderUpdate"/>

                <FluxPaneFooter>
                    <FluxPaginationBar
                        :page="slotProps.page"
                        :per-page="slotProps.pageSize"
                        :total="slotProps.totalItems"
                        @limit="slotProps.onPageSizeUpdate"
                        @navigate="slotProps.onPageUpdate"/>
                </FluxPaneFooter>
            </FluxPane>
        </ChannelsContainer>

        <FluxOverlay is-closeable>
            <ChannelForm
                v-if="channelRequest !== null && !saving"
                class="channel-form-container"
                editable
                :channelRequest="channelRequest"
                @cancel="cancelChannel"
                @save="saveChannel"/>

            <FluxPane v-if="saving">
                <FluxPaneBody>
                    <FluxStack
                        :gap="15"
                        is-centered>
                        <FluxSpinner/>

                        <h3>{{ t(savingTitle) }}</h3>
                    </FluxStack>
                </FluxPaneBody>
            </FluxPane>
        </FluxOverlay>
    </Component>
</template>

<script
    lang="ts"
    setup>
    import { UserType } from '@fancee/data';
    import { ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { CreateChannelRequest } from '@/data/dto/analytics/channels/CreateChannelRequest';
    import { ChannelsService, SubscriptionsService } from '@/data/service';
    import { useAuthStore } from '@/data/store';
    import ChannelsTable from '@/components/analytics/channels/ChannelsTable.vue';
    import ChannelForm from '@/components/analytics/channels/ChannelForm.vue';
    import ChannelsContainer from '@/components/analytics/data/channel/ChannelsContainer.vue';

    const {user} = useAuthStore();
    const {t} = useI18n();
    const {create} = useService(ChannelsService);
    const {updateAll} = useService(SubscriptionsService);

    const channelRequest = ref<CreateChannelRequest | null>(null);
    const saving = ref(false);
    const savingTitle = ref('analytics.channel.saving');
    const channelsContainerRef = ref();

    function createNewChannel(): void {
        let request = CreateChannelRequest.empty();
        request.platformUserId = user?.id ?? '';
        request.owner.organizationId = user?.activeOrganizationId ?? null;
        channelRequest.value = request;
    }

    async function saveChannel(): Promise<void> {
        const currentRequest = unref(channelRequest);

        if (currentRequest === null) {
            return;
        }

        saving.value = true;
        let {data} = await create(currentRequest);

        savingTitle.value = 'analytics.channel.updating';

        await updateAll(data.channel.id!);

        channelRequest.value = null;
        saving.value = false;

        await unref(channelsContainerRef).updateData();
    }

    function onOrderUpdate(fieldName: string | null, direction: 'ascending' | 'descending' | null): void {
        unref(channelsContainerRef)?.onOrderUpdate(fieldName, direction);
    }

    function cancelChannel(): void {
        channelRequest.value = null;
        saving.value = false;
    }
</script>

<style
    lang="scss"
    scoped>
    .channel-form-container {
        min-width: 460px;
    }
</style>
