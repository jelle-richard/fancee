<template>
    <FluxContainer>
        <ChannelsContainer
            v-slot="channelsProps"
            v-if="!selectedCampaign">
            <FluxSpinner
                v-if="channelsProps.isLoading"
                :class="$style.loader"/>

            <NoChannelsFound v-if="!channelsProps.isLoading && someDefaultChannels === false"/>

            <DashboardHeader
                v-if="channelsProps.data.length > 0"
                :title="t('analytics.titles.overview')"
                :channels="channelsProps.data.filter(ch => defaultChannelTypes.includes(ch.type))"
                :start-date="startDate"
                :end-date="endDate"
                @update-channels="updateChannels"
                @update-dates="updateDates">
                <template #header-right>
                    <FluxPane>
                        <FluxStack
                            :class="$style.headerCompare"
                            axis="horizontal">
                            <span>{{ t('analytics.comparisonView') }}</span>

                            <FluxToggle
                                v-model="comparing"
                                @update:model-value="updateScreenState($event)"/>
                        </FluxStack>
                    </FluxPane>
                </template>
            </DashboardHeader>

            <CampaignsGrid
                v-if="someDefaultChannels"
                :channels="filteredDefaultChannels"
                :start-date="startDate"
                :end-date="endDate"
                :show-header-link="false"/>

            <MultiSumCampaignsCard
                v-if="someDefaultChannels && screenState === null"
                :channels="filteredDefaultChannels"
                :start-date="startDate"
                :end-date="endDate"
                @on-campaign-selected="selectCampaign"/>

            <CampaignsComparePane
                v-if="someDefaultChannels && screenState === 'compare'"
                :channels="channels"
                :start-date="startDate"
                :end-date="endDate"/>
        </ChannelsContainer>

        <ChannelsContainer v-else>
            <DashboardHeader
                :title="t('analytics.titles.overview')"
                :channels="[]"
                :start-date="startDate"
                :end-date="endDate"
                is-selection
                @update-channels="updateChannels"
                @update-dates="updateDates"
                @back="back">
            </DashboardHeader>

            <CampaignCard
                :campaign="selectedCampaign"
                :start-date="startDate"
                :end-date="endDate"/>
        </ChannelsContainer>
    </FluxContainer>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { computed, onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumCampaignItem } from '@/data/dto/analytics/dashboard';
    import { useRememberedValue } from '@/composable';
    import ChannelsContainer from '@/components/analytics/data/channel/ChannelsContainer.vue';
    import DashboardHeader from '@/product/analytics/components/DashboardHeader.vue';
    import MultiSumCampaignsCard from '@/components/analytics/campaigns/MultiSumCampaignsCard.vue';
    import CampaignsGrid from '@/product/analytics/components/CampaignsGrid.vue';
    import CampaignCard from '@/components/analytics/campaigns/CampaignCard.vue';
    import NoChannelsFound from '@/components/analytics/channels/NoChannelsFound.vue';
    import CampaignsComparePane from '@/components/analytics/dashboard/compare/CampaignsComparePane.vue';

    const {t} = useI18n();

    const channels = ref<Channel[]>([]);
    const selectedCampaign = ref<SumCampaignItem | null>(null);
    const screenState = ref<string | null>(null);
    const comparing = useRememberedValue<boolean>('compare-analytics-channels', false);
    const startDate = useRememberedValue<DateTime>('start-date-analytics', DateTime.now().minus({days: 7}));
    const endDate = useRememberedValue<DateTime>('end-date-analytics', DateTime.now());

    const someChannels = (types: ChannelType[]): boolean => unref(channels).some(ch => types.includes(ch.type));
    const filterChannels = (types: ChannelType[]): Channel[] => unref(channels).filter(ch => types.includes(ch.type));

    const defaultChannelTypes: ChannelType[] = [ChannelType.GoogleAds, ChannelType.FacebookAds];
    const someDefaultChannels = computed((): boolean => someChannels(defaultChannelTypes));
    const filteredDefaultChannels = computed((): Channel[] => filterChannels(defaultChannelTypes));

    onMounted(() => {
        updateScreenState(unref(comparing));
    });

    function updateDates(eventStartDate: DateTime, eventEndDate: DateTime): void {
        startDate.value = eventStartDate;
        endDate.value = eventEndDate;
    }

    function updateChannels(eventChannels: Channel[]): void {
        channels.value = eventChannels;
    }

    function selectCampaign(campaign: SumCampaignItem): void {
        selectedCampaign.value = campaign;
    }

    function back(): void {
        selectedCampaign.value = null;
    }

    function updateScreenState(compareBool: boolean) {
        screenState.value = compareBool ? 'compare' : null;
    }
</script>

<style module>
    .loader {
        margin: 60px auto;
    }

    .headerCompare {
        padding-left: 12px;
        padding-right: 12px;
        height: 100%;
        align-items: center;
    }
</style>
