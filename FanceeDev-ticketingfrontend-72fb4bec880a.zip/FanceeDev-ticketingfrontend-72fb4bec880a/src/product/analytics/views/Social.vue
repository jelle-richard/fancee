<template>
    <FluxContainer>
        <ChannelsContainer
            v-slot="channelsProps"
            :startingPageLength="25">
            <FluxSpinner
                v-if="channelsProps.isLoading"
                :class="$style.loader"/>

            <NoChannelsFound v-if="!channelsProps.isLoading && someDefaultChannels === false"/>

            <DashboardHeader
                v-if="channelsProps.data.length > 0"
                :title="t('analytics.titles.social')"
                :channels="channelsProps.data.filter(ch => socialChannelTypes.includes(ch.type))"
                :start-date="startDate"
                :end-date="endDate"
                @update-channels="updateChannels"
                @update-dates="updateDates">
                <template #header-right>
                    <FluxPane>
                        <FluxStack
                            :class="$style.headerCompare"
                            axis="horizontal">
                            <span>{{ t('analytics.comparisonView') }}</span>

                            <FluxToggle
                                v-model="comparing"
                                @update:model-value="updateScreenState($event)"/>
                        </FluxStack>
                    </FluxPane>
                </template>
            </DashboardHeader>

            <SocialsGrid
                v-if="screenState === null && someDefaultChannels"
                :channels="filteredDefaultChannels"
                :start-date="startDate"
                :end-date="endDate"/>

            <SocialsComparePane
                v-if="someDefaultChannels && screenState === 'compare'"
                :channels="filteredDefaultChannels"
                :start-date="startDate"
                :end-date="endDate"/>

            <FluxGrid v-if="channels.length > 0 && screenState === null">
                <FluxGridColumn
                    v-if="someChannels([ChannelType.Facebook])"
                    :sm="4">
                    <MultiSumEmotionsCard
                        :channels="filterChannels([ChannelType.Facebook])"
                        :startDate="startDate"
                        :endDate="endDate"/>
                </FluxGridColumn>

                <FluxGridColumn
                    v-if="someChannels([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2])"
                    :sm="4">
                    <MultiSumAgeCard
                        :channels="filterChannels([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2])"
                        :startDate="startDate"
                        :endDate="endDate"/>
                </FluxGridColumn>

                <FluxGridColumn
                    v-if="someChannels([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2, ChannelType.TikTok])"
                    :sm="4">
                    <MultiSumGenderCard
                        :channels="filterChannels([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2, ChannelType.TikTok])"
                        :startDate="startDate"
                        :endDate="endDate"/>
                </FluxGridColumn>

                <FluxGridColumn :sm="4">
                    <MultiSumKeywordsCard
                        :channels="filteredDefaultChannels"
                        :startDate="startDate"
                        :endDate="endDate"
                        :title="t('analytics.hashtags.title')"
                        :color="ANALYTICS_CHART_COLOR"
                        type="hashtags"/>
                </FluxGridColumn>

                <FluxGridColumn :sm="4">
                    <MultiSumKeywordsCard
                        :channels="filteredDefaultChannels"
                        :startDate="startDate"
                        :endDate="endDate"
                        :title="t('analytics.mentions.title')"
                        :color="ANALYTICS_CHART_COLOR"
                        type="mentions"/>
                </FluxGridColumn>

                <FluxGridColumn :sm="4">
                    <MultiSumKeywordsCard
                        :channels="filteredDefaultChannels"
                        :startDate="startDate"
                        :endDate="endDate"
                        :title="t('analytics.captions.title')"
                        :color="ANALYTICS_CHART_COLOR"
                        type="captions"/>
                </FluxGridColumn>
            </FluxGrid>
        </ChannelsContainer>
    </FluxContainer>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { computed, onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ANALYTICS_CHART_COLOR } from '@/data';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { useRememberedValue } from '@/composable';
    import ChannelsContainer from '@/components/analytics/data/channel/ChannelsContainer.vue';
    import DashboardHeader from '@/product/analytics/components/DashboardHeader.vue';
    import MultiSumAgeCard from '@/components/analytics/dashboard/MultiSumAgeCard.vue';
    import MultiSumGenderCard from '@/components/analytics/dashboard/MultiSumGenderCard.vue';
    import MultiSumKeywordsCard from '@/components/analytics/dashboard/MultiSumKeywordsCard.vue';
    import SocialsGrid from '@/product/analytics/components/SocialsGrid.vue';
    import NoChannelsFound from '@/components/analytics/channels/NoChannelsFound.vue';
    import MultiSumEmotionsCard from '@/components/analytics/dashboard/MultiSumEmotionsCard.vue';
    import SocialsComparePane from '@/components/analytics/dashboard/compare/SocialsComparePane.vue';

    const {t} = useI18n();

    const channels = ref<Channel[]>([]);
    const comparing = useRememberedValue<boolean>('compare-analytics-channels', false);
    const startDate = useRememberedValue<DateTime>('start-date-analytics', DateTime.now().minus({days: 7}));
    const endDate = useRememberedValue<DateTime>('end-date-analytics', DateTime.now());

    const screenState = ref<string | null>(null);

    const socialChannelTypes: ChannelType[] = [ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2, ChannelType.LinkedIn, ChannelType.TikTok];

    const someChannels = (types: ChannelType[]): boolean => unref(channels).some(ch => types.includes(ch.type));
    const filterChannels = (types: ChannelType[]): Channel[] => unref(channels).filter(ch => types.includes(ch.type));

    const someDefaultChannels = computed((): boolean => someChannels(socialChannelTypes));
    const filteredDefaultChannels = computed((): Channel[] => filterChannels(socialChannelTypes));

    onMounted(() => {
        updateScreenState(unref(comparing));
    });

    function updateDates(eventStartDate: DateTime, eventEndDate: DateTime) {
        startDate.value = eventStartDate;
        endDate.value = eventEndDate;
    }

    function updateChannels(eventChannels: Channel[]) {
        channels.value = eventChannels;
    }

    function updateScreenState(compareBool: boolean) {
        screenState.value = compareBool ? 'compare' : null;
    }
</script>

<style module>
    .loader {
        margin: 60px auto;
    }

    .headerCompare {
        padding-left: 12px;
        padding-right: 12px;
        height: 100%;
        align-items: center;
    }
</style>
