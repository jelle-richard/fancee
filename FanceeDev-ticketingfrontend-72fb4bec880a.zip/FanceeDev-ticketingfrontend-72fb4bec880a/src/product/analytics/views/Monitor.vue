<template>
    <ChannelsContainer
        v-slot="channelsProps"
        v-if="!!startDate && !!endDate">
        <ChannelSelectBlock
            :channels="channelsProps.data"
            :is-loading="channelsProps.isLoading"
            :startDate="startDate"
            :endDate="endDate"
            @channel-changed="setChannel"
            @start-date-changed="setStartDate"
            @end-date-changed="setEndDate"/>

        <ChannelReachBlock
            v-if="selectedChannel"
            :channel="selectedChannel"
            :start-date="startDate"
            :end-date="endDate"/>

        <FluxGrid v-if="selectedChannel">
            <AveragePerDayContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate"
                selection="REACH">
                <BarChartCard
                    :is-loading="slotProps.isLoading"
                    :title="slotProps.title"
                    :subtitle="t('analytics.monitor.averageDay')"
                    chart-color="#441289"
                    :chart-categories="slotProps.categories"
                    :chart-data="[{
                        name: t('analytics.monitor.bestDayToPost'),
                        data: slotProps.data
                    }]"/>
            </AveragePerDayContainer>

            <AveragePerHourContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate"
                selection="REACH">
                <BarChartCard
                    :is-loading="slotProps.isLoading"
                    :title="slotProps.title"
                    :subtitle="t('analytics.monitor.averageHour')"
                    chart-color="#f48000"
                    :chart-categories="slotProps.categories"
                    :chart-data="[{
                        name: t('analytics.monitor.bestHourToPost'),
                        data: slotProps.data
                    }]"/>
            </AveragePerHourContainer>

            <GenderContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate">
                <PieChartCard
                    :is-loading="slotProps.isLoading"
                    :title="t('analytics.monitor.gender.title')"
                    :subtitle="t('analytics.monitor.gender.subTitle')"
                    :chart-data="slotProps.data"
                    :chart-categories="slotProps.categories"/>
            </GenderContainer>

            <AgeContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate">
                <PieChartCard
                    :is-loading="slotProps.isLoading"
                    :title="t('analytics.monitor.age.title')"
                    :subtitle="t('analytics.monitor.age.subTitle')"
                    :chart-data="slotProps.data"
                    :chart-categories="slotProps.categories"/>
            </AgeContainer>

            <EmotionsContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate">
                <PieChartCard
                    :is-loading="slotProps.isLoading"
                    :title="t('analytics.monitor.emotion.title')"
                    :subtitle="t('analytics.monitor.emotion.subTitle')"
                    :chart-data="slotProps.data"
                    :chart-categories="slotProps.categories"/>
            </EmotionsContainer>

            <KeywordsContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate"
                category="HASH">
                <WordCloudCard
                    :is-loading="slotProps.isLoading"
                    :title="slotProps.title"
                    :subtitle="t('analytics.monitor.hashtags')"
                    :chart-data="slotProps.data"
                    color="#5076b9"/>
            </KeywordsContainer>

            <KeywordsContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate"
                category="TAG">
                <WordCloudCard
                    :is-loading="slotProps.isLoading"
                    :title="slotProps.title"
                    :subtitle="t('analytics.monitor.mentions')"
                    :chart-data="slotProps.data"
                    color="#a85632"/>
            </KeywordsContainer>

            <KeywordsContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate"
                category="CAPTION">
                <WordCloudCard
                    :is-loading="slotProps.isLoading"
                    :title="slotProps.title"
                    :subtitle="t('analytics.monitor.captions')"
                    :chart-data="slotProps.data"
                    color="#0e8218"/>
            </KeywordsContainer>

            <KeywordsContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate"
                category="EMOJI">
                <WordCloudCard
                    :is-loading="slotProps.isLoading"
                    :title="slotProps.title"
                    :subtitle="t('analytics.monitor.emojis')"
                    :chart-data="slotProps.data"/>
            </KeywordsContainer>

            <TopPostsContainer
                v-slot="slotProps"
                :channel="selectedChannel"
                :start-date="startDate"
                :end-date="endDate"
                :page-size="5"
                selection="REACH">
                <FluxPane>
                    <FluxPaneHeader :title="t('analytics.monitor.topPosts')"/>

                    <PostsTable
                        v-if="slotProps.data"
                        :rows="slotProps.data"
                        :key="slotProps.pageSize"
                        :page-size="slotProps.pageSize"
                        :page="slotProps.page"
                        :total-items="slotProps.totalItems"
                        :onPageUpdate="slotProps.onPageUpdate"
                        :onPageSizeUpdate="slotProps.onPageSizeUpdate"
                        :interactive="false"/>
                </FluxPane>
            </TopPostsContainer>
        </FluxGrid>

        <SubscriptionsContainer
            v-if="selectedChannel"
            v-slot="slotProps"
            :channel="selectedChannel">
            <MultiEntriesContainer
                v-slot="multiProps"
                :subscriptions="slotProps.data"
                :start-date="startDate"
                :end-date="endDate">
                <FluxPane :is-loading="slotProps.isLoading || multiProps.isLoading">
                    <FluxPaneHeader :title="t('analytics.subscription.plural')"/>

                    <FluxPaneBody>
                        <MultiLineChartCard
                            :subscriptions="multiProps.data"
                            :start-date="startDate"
                            :end-date="endDate"/>
                    </FluxPaneBody>
                </FluxPane>
            </MultiEntriesContainer>
        </SubscriptionsContainer>
    </ChannelsContainer>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { Channel } from '@/data/dto/analytics/channels';
    import ChannelReachBlock from '@/components/analytics/dashboard/ChannelReachBlock.vue';
    import ChannelSelectBlock from '@/components/analytics/dashboard/ChannelSelectBlock.vue';
    import GenderContainer from '@/components/analytics/data/likes/GenderContainer.vue';
    import AgeContainer from '@/components/analytics/data/likes/AgeContainer.vue';
    import KeywordsContainer from '@/components/analytics/data/posts/KeywordsContainer.vue';
    import WordCloudCard from '@/components/analytics/cards/WordCloudCard.vue';
    import AveragePerDayContainer from '@/components/analytics/data/posts/AveragePerDayContainer.vue';
    import BarChartCard from '@/components/analytics/cards/BarChartCard.vue';
    import SubscriptionsContainer from '@/components/analytics/data/channel/SubscriptionsContainer.vue';
    import AveragePerHourContainer from '@/components/analytics/data/posts/AveragePerHourContainer.vue';
    import TopPostsContainer from '@/components/analytics/data/posts/TopPostsContainer.vue';
    import PostsTable from '@/components/analytics/posts/PostsTable.vue';
    import EmotionsContainer from '@/components/analytics/data/likes/EmotionsContainer.vue';
    import ChannelsContainer from '@/components/analytics/data/channel/ChannelsContainer.vue';
    import PieChartCard from '@/components/analytics/cards/PieChartCard.vue';
    import MultiEntriesContainer from '@/components/analytics/data/generic/MultiEntriesContainer.vue';
    import MultiLineChartCard from '@/components/analytics/cards/MultiLineChartCard.vue';

    const {t} = useI18n();

    const selectedChannel = ref<Channel | null>(null);
    const startDate = ref(DateTime.now().minus({years: 1}));
    const endDate = ref(DateTime.now());

    const setChannel = (channel: Channel | undefined) => {
        selectedChannel.value = channel ?? null;
    };

    const setStartDate = (newDate: DateTime | null) => {
        if (newDate === null) {
            return;
        }

        startDate.value = newDate;
    };

    const setEndDate = (newDate: DateTime | null) => {
        if (newDate === null) {
            return;
        }

        endDate.value = newDate;
    };
</script>

<style
    lang="scss"
    scoped>
    .flux-grid-column {
        position: relative;
        overflow: hidden;
    }
</style>
