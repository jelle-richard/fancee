<template>
    <SubscriptionsContainer
        v-slot="slotProps"
        :channel="channel">
        <FluxStack>
            <FluxSpinner v-if="slotProps.isLoading"/>

            <SubscriptionInfoCard
                v-for="subscription in slotProps.data"
                :key="subscription.id"
                :subscription="subscription"/>
        </FluxStack>
    </SubscriptionsContainer>
</template>

<script
    lang="ts"
    setup>
    import { Channel } from '@/data/dto/analytics/channels';
    import SubscriptionInfoCard from '@/product/analytics/views/crm/channels/subscriptions/components/SubscriptionInfoCard.vue';
    import SubscriptionsContainer from '@/components/analytics/data/channel/SubscriptionsContainer.vue';

    export interface Props {
        readonly channel: Channel;
    }

    defineProps<Props>();
</script>
