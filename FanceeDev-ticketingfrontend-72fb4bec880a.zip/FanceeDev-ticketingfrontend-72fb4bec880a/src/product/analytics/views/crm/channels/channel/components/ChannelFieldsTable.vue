<template>
    <FluxTable v-if="fields">
        <template #header>
            <FluxTableRow>
                <FluxTableHeader> {{ t('analytics.crm.channel.fields.table.name') }}</FluxTableHeader>
                <FluxTableHeader> {{ t('analytics.crm.channel.fields.table.type') }}</FluxTableHeader>
                <FluxTableHeader> {{ t('analytics.crm.channel.fields.table.field') }}</FluxTableHeader>
                <FluxTableHeader> {{ t('analytics.crm.channel.fields.table.group') }}</FluxTableHeader>
                <FluxTableHeader> {{ t('analytics.crm.channel.fields.table.description') }}</FluxTableHeader>
            </FluxTableRow>
        </template>
        <template #rows>
            <FluxTableRow
                v-for="field in fields"
                :key="field.fieldId">
                <FluxTableCell>
                    <FluxInfo :icon="getFieldTypeIcon(field.dataType)">{{ field.fieldName }}</FluxInfo>
                </FluxTableCell>

                <FluxTableCell>
                    <i>{{ field.dataType }}</i>
                </FluxTableCell>

                <FluxTableCell>
                    <FluxTooltip :content="field.fieldId">
                        <i class="channel-field-id">{{ field.fieldId }}</i>
                    </FluxTooltip>
                </FluxTableCell>

                <FluxTableCell>
                    <FluxBadge :label="field.groupName"/>
                </FluxTableCell>

                <FluxTableCell>
                    <FluxTooltip
                        v-if="field.description"
                        :content="field.description">
                        <FluxSecondaryButton
                            icon-before="circle-info"
                            label="info"
                            size="small"/>
                    </FluxTooltip>
                </FluxTableCell>
            </FluxTableRow>
        </template>
    </FluxTable>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { ChannelField } from '@/data/dto/analytics/channels/ChannelField';
    import { getFieldTypeIcon } from '@/product/analytics/util';

    export interface Props {
        readonly fields: ChannelField[];
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>

<style
    lang="scss"
    scoped>
    .channel-field-id {
        text-overflow: ellipsis;
        overflow: hidden;
        width: 200px;
        white-space: nowrap;
    }
</style>
