<template>
    <FluxPane v-if="fields">
        <FluxExpandable :label="t('analytics.crm.channel.fields.title')">
            <ChannelFieldsTable :fields="fields"/>
        </FluxExpandable>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { ChannelsService } from '@/data/service';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelField } from '@/data/dto/analytics/channels/ChannelField';
    import ChannelFieldsTable from '@/product/analytics/views/crm/channels/channel/components/ChannelFieldsTable.vue';

    export interface Props {
        readonly channel: Channel;
    }

    const props = defineProps<Props>();
    const {channel} = toRefs(props);

    const {t} = useI18n();
    const {settings} = useService(ChannelsService);

    const fields = ref<ChannelField[]>([]);

    async function updateFields(): Promise<void> {
        let response = await settings(unref(channel).id);
        fields.value = response.data.fields ?? null;
    }

    watch(channel, updateFields, {deep: true, immediate: true});
</script>
