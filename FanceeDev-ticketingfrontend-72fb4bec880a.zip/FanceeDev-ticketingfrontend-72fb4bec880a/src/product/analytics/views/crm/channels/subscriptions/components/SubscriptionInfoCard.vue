<template>
    <FluxPane is-contained>
        <FluxPaneHeader :title="title"/>
        <FluxTabs>
            <FluxTab
                icon="coffee"
                :label="t('analytics.crm.subscription.info.title')">
                <FluxTable>
                    <template #rows>
                        <FluxTableRow>
                            <FluxTableCell>
                                <FluxInfo
                                    :class="`subscription-active-${subscription.active}`"
                                    :icon="subscription.active ? 'check' : 'x'">
                                    {{ t('analytics.crm.subscription.info.status') }}
                                </FluxInfo>
                            </FluxTableCell>

                            <FluxTableCell>
                                <FluxBadge
                                    dot
                                    :color="subscription.active ? 'success' : 'danger'"
                                    :label="t(subscription.active ? 'analytics.subscription.status.active' : 'analytics.subscription.status.inactive')"/>
                            </FluxTableCell>
                        </FluxTableRow>

                        <FluxTableRow>
                            <FluxTableCell>
                                <FluxInfo icon="clock">{{ t('analytics.crm.subscription.info.cron') }}</FluxInfo>
                            </FluxTableCell>

                            <FluxTableCell>
                                {{ subscription.cron }}
                            </FluxTableCell>
                        </FluxTableRow>

                        <FluxTableRow>
                            <FluxTableCell>
                                <FluxInfo icon="home">{{ t('analytics.crm.subscription.info.type') }}</FluxInfo>
                            </FluxTableCell>

                            <FluxTableCell>
                                {{ subscription.type }}
                            </FluxTableCell>
                        </FluxTableRow>

                        <FluxTableRow>
                            <FluxTableCell>
                                <FluxInfo icon="calendar">{{ t('analytics.crm.subscription.info.createdOn') }}</FluxInfo>
                            </FluxTableCell>
                            <FluxTableCell>
                                {{ formatDateTime(subscription.createdOn) }}
                            </FluxTableCell>
                        </FluxTableRow>

                        <FluxTableRow>
                            <FluxTableCell>
                                <FluxInfo icon="calendar">{{ t('analytics.crm.subscription.info.updatedOn') }}</FluxInfo>
                            </FluxTableCell>
                            <FluxTableCell>
                                {{ formatDateTime(subscription.updatedOn) }}
                            </FluxTableCell>
                        </FluxTableRow>

                        <FluxTableRow v-if="subscription.fields">
                            <FluxTableCell>
                                <FluxInfo icon="list">{{ t('analytics.crm.subscription.info.fields') }}</FluxInfo>
                            </FluxTableCell>

                            <FluxTableCell class="subscription-fields-table">
                                <FluxExpandable
                                    :label="t('analytics.crm.subscription.info.showFields')"
                                    #body>
                                    <SubscriptionFieldsTable :fields="subscription.fields"/>
                                </FluxExpandable>
                            </FluxTableCell>
                        </FluxTableRow>
                    </template>
                </FluxTable>

                <FluxPaneFooter>
                    <FluxSecondaryButton
                        icon-before="refresh"
                        @click="refreshSubscription"
                        :label="t('global.refresh')"/>
                </FluxPaneFooter>
            </FluxTab>

            <FluxTab
                icon="chart-mixed"
                :label="t('analytics.crm.subscription.chart.title')">
                <GenericEntriesContainer
                    v-slot="entrySlotProps"
                    :subscriptionId="subscription.id"
                    :start-date="startDate"
                    :end-date="endDate">
                    <FluxPaneBody v-if="!entrySlotProps.loading && entrySlotProps.data.length === 0">
                        <NoDashboardData variation="full"/>
                    </FluxPaneBody>

                    <FluxPaneBody v-else>
                        <LineChartCard
                            :entries="entrySlotProps.data"
                            :start-date="startDate"
                            :end-date="endDate"/>
                    </FluxPaneBody>
                </GenericEntriesContainer>
            </FluxTab>

            <FluxTab
                icon="book"
                :label="t('analytics.crm.subscription.history.title')">
                <ConnectionsContainer
                    v-slot="entrySlotProps"
                    :subscription="subscription">
                    <FluxPaneBody>
                        <NoDashboardData
                            v-if="!entrySlotProps.loading && entrySlotProps.data.length === 0"
                            variation="full"/>

                        <LogTimeline
                            v-else
                            user-type="Admin"
                            :logs="toLogs(entrySlotProps.data)"/>
                    </FluxPaneBody>
                </ConnectionsContainer>
            </FluxTab>
        </FluxTabs>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { showSnackbar } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { Subscription } from '@/data/dto/analytics/subscriptions';
    import { LogLevel } from '@/data/enum/analytics/logs';
    import { Log } from '@/data/dto/analytics/logs/Log';
    import { Connection } from '@/data/dto/analytics/logs/Connection';
    import { SubscriptionsService } from '@/data/service/SubscriptionsService';
    import { formatDateTime } from '@/util';
    import ConnectionsContainer from '@/components/analytics/data/generic/ConnectionsContainer.vue';
    import GenericEntriesContainer from '@/components/analytics/data/generic/GenericEntriesContainer.vue';
    import LineChartCard from '@/components/analytics/cards/LineChartCard.vue';
    import LogTimeline from '@/components/analytics/timeline/LogTimeline.vue';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';
    import SubscriptionFieldsTable from '@/product/analytics/views/crm/channels/subscriptions/components/SubscriptionFieldsTable.vue';

    export interface Props {
        readonly subscription: Subscription;
    }

    const props = defineProps<Props>();

    const {t} = useI18n();
    const {update} = useService(SubscriptionsService);

    const startDate = ref(DateTime.now().minus({months: 3}));
    const endDate = ref(DateTime.now());

    const title = computed((): string => t(`analytics.subscription.type.${props.subscription.type.toLowerCase()}`));

    const toLogs = (connections: Connection[]): Log[] => connections.map<Log>(conn => {
        let log = new Log(conn.id, null, conn.createdOn, conn.updatedOn, conn.error ? LogLevel.Error : LogLevel.Success, '', '', conn.error ?? conn.meta);
        if (conn.error) {
            log.message = 'Connection error';
        } else {
            log.message = `Connection ${conn.meta?.status_code}.
                Query from ${conn.meta?.query?.start_date} to ${conn.meta?.query?.end_date}.
                Received ${conn.meta?.result?.total_rows} rows and ${conn.meta?.result?.total_columns} columns.`;
        }
        return log;
    });

    async function refreshSubscription(): Promise<void> {
        await update(props.subscription.id);

        showSnackbar({
            color: 'success',
            icon: 'check',
            message: t('analytics.crm.subscription.refresh', [unref(title)])
        });
    }
</script>

<style
    lang="scss"
    scoped>
    .flux-table-row > *:first-child {
        max-width: 200px;
        width: 200px;
    }

    .subscription-field {
        margin-bottom: 0.5rem;

        .flux-info {
            min-width: 300px;
        }
    }

    ::v-deep(.subscription-fields-table) {
        > .flux-table-cell-content {
            padding: 0;
        }

        .flux-expandable {
            flex: 1;

            .flux-expandable-header {
                padding: 12px 15px;
                height: auto;
            }

            .flux-expandable-content {
                padding: 0 15px 12px 15px;
            }
        }
    }
</style>
