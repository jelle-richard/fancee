<template>
    <FluxPane>
        <FluxPaneHeader :title="channel.name"/>
        <FluxTable>
            <template #rows>
                <FluxTableRow>
                    <FluxTableCell>
                        <FluxInfo icon="check">{{ t('global.status') }}</FluxInfo>
                    </FluxTableCell>

                    <FluxTableCell>
                        <FluxBadge
                            dot
                            :color="channel.status === ChannelStatus.Active ? 'success' : 'danger'"
                            :label="t(channel.status === ChannelStatus.Active ? 'analytics.channel.status.active' : 'analytics.channel.status.inactive')"/>
                    </FluxTableCell>
                </FluxTableRow>

                <FluxTableRow>
                    <FluxTableCell>
                        <FluxInfo icon="star">{{ t('analytics.channel.info.request') }}</FluxInfo>
                    </FluxTableCell>

                    <FluxTableCell>
                        {{ channel.request }}
                    </FluxTableCell>
                </FluxTableRow>

                <FluxTableRow>
                    <FluxTableCell>
                        <FluxInfo icon="calendar">{{ t('analytics.channel.info.lastLogin') }}</FluxInfo>
                    </FluxTableCell>

                    <FluxTableCell>
                        {{ formatDateTime(channel.updatedOn) }}
                    </FluxTableCell>
                </FluxTableRow>

                <FluxTableRow>
                    <FluxTableCell>
                        <FluxInfo icon="calendar">{{ t('analytics.channel.info.createdOn') }}</FluxInfo>
                    </FluxTableCell>

                    <FluxTableCell>
                        {{ formatDateTime(channel.createdOn) }}
                    </FluxTableCell>
                </FluxTableRow>

                <FluxTableRow v-if="channel.userId !== user?.id && !!channel.owner">
                    <FluxTableCell>
                        <FluxInfo icon="user">{{ t('analytics.channel.info.owner') }}</FluxInfo>
                    </FluxTableCell>

                    <FluxTableCell>
                        {{ channel.owner.firstName }} {{ channel.owner.lastName }}
                    </FluxTableCell>
                </FluxTableRow>

                <FluxTableRow v-if="user?.type === UserType.Admin && !!channel.owner">
                    <FluxTableCell>
                        <FluxInfo icon="users-gear">{{ t('analytics.channel.info.organization') }}</FluxInfo>
                    </FluxTableCell>

                    <FluxTableCell>
                        {{ channel.owner.organizationName }}
                    </FluxTableCell>
                </FluxTableRow>

                <FluxTableRow v-if="user?.type === UserType.Admin && !!channel.owner">
                    <FluxTableCell>
                        <FluxInfo icon="envelope">{{ t('form.field.email') }}</FluxInfo>
                    </FluxTableCell>

                    <FluxTableCell>
                        {{ channel.owner.email }}
                    </FluxTableCell>
                </FluxTableRow>
            </template>
        </FluxTable>

        <FluxPaneFooter>
            <FluxSecondaryButton
                :label="t('global.refresh')"
                icon-before="refresh"
                @click="openRefreshModal"/>

            <FluxDestructiveButton
                :label="t('global.delete')"
                icon-before="trash"
                @click="openDeleteModal"/>
        </FluxPaneFooter>
    </FluxPane>

    <FluxOverlay
        is-closeable
        size="small"
        @close="close">
        <ModalFormOverlay
            v-if="isRefreshModalOpen"
            :title="t('analytics.crm.channel.refresh.title')"
            icon="refresh"
            :explanation="t('analytics.crm.channel.refresh.message')"
            @cancel="close"
            @ok="refreshChannel"/>

        <ModalFormOverlay
            v-if="isDeleteModalOpen"
            :title="t('analytics.crm.channel.delete.title')"
            icon="trash"
            :explanation="t('analytics.crm.channel.delete.message')"
            @cancel="close"
            @ok="deleteChannel"/>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { UserType } from '@fancee/data';
    import { ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ModalFormOverlay } from '@/components/ui';
    import { useUser } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelStatus } from '@/data/enum/analytics/api';
    import { formatDateTime } from '@/util';

    export type Emits = {
        (e: 'delete'): void;
        (e: 'refresh'): void;
    };

    export type Props = {
        readonly channel: Channel;
    };

    defineProps<Props>();
    const emit = defineEmits<Emits>();

    const {t} = useI18n();
    const user = useUser();

    const isRefreshModalOpen = ref(false);
    const isDeleteModalOpen = ref(false);

    function close(): void {
        isRefreshModalOpen.value = false;
        isDeleteModalOpen.value = false;
    }

    function openRefreshModal(): void {
        isRefreshModalOpen.value = true;
    }

    function openDeleteModal(): void {
        isDeleteModalOpen.value = true;
    }

    function deleteChannel(): void {
        close();
        emit('delete');
    }

    function refreshChannel(): void {
        close();
        emit('refresh');
    }
</script>
