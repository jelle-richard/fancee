<template>
    <FluxTable>
        <template #header>
            <FluxTableRow>
                <FluxTableHeader>{{ t('analytics.crm.subscription.fields.name') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('analytics.crm.subscription.fields.type') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('analytics.crm.subscription.fields.field') }}</FluxTableHeader>
            </FluxTableRow>
        </template>

        <template #rows>
            <FluxTableRow
                v-for="field in fields"
                :key="field.fieldId">
                <FluxTableCell>
                    <FluxInfo :icon="getFieldTypeIcon(field.fieldType)">{{ field.fieldName }}</FluxInfo>
                </FluxTableCell>

                <FluxTableCell>
                    <em>{{ field.fieldType }}</em>
                </FluxTableCell>

                <FluxTableCell>
                    <em>{{ field.fieldId }}</em>
                </FluxTableCell>
            </FluxTableRow>
        </template>
    </FluxTable>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { SubscriptionField } from '@/data/dto/analytics/subscriptions/SubscriptionField';
    import { getFieldTypeIcon } from '@/product/analytics/util';

    export interface Props {
        readonly fields: SubscriptionField[];
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>
