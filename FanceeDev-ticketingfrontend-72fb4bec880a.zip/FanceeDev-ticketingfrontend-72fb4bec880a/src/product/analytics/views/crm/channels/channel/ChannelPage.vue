<template>
    <Component
        :is="user?.type === UserType.Admin ? 'FluxStack': 'FluxContainer'"
        :is-loading="isLoading"
        gap="0">
        <FluxPersona
            v-if="channel"
            :avatar-size="40"
            :avatar-url="getChannelTypeSVGPath(channel.type)"
            :name="channel.name"
            :title="t(`analytics.channel.type.${channel.type.toLowerCase()}`)"/>

        <FluxTabs v-if="channel">
            <FluxTab
                icon="home"
                :label="t('analytics.channel.singular')">
                <FluxStack>
                    <ChannelInfoCard
                        :channel="channel"
                        @refresh="refreshChannel"
                        @delete="deleteChannel"/>

                    <ChannelFieldsCard :channel="channel"/>
                </FluxStack>
            </FluxTab>

            <FluxTab
                v-if="channel?.status"
                icon="monitor-waveform"
                :label="t('analytics.subscription.singular')">
                <SubscriptionsPane :channel="channel"/>
            </FluxTab>
        </FluxTabs>
    </Component>
</template>

<script
    lang="ts"
    setup>
    import { UserType } from '@fancee/data';
    import { useFluxStore } from '@fancee/flux';
    import { computed, onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRoute, useRouter, useService, useUser } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelsService, SubscriptionsService } from '@/data/service';
    import { getChannelTypeSVGPath } from '@/product/analytics/util';
    import ChannelInfoCard from '@/product/analytics/views/crm/channels/channel/components/ChannelInfoCard.vue';
    import ChannelFieldsCard from '@/product/analytics/views/crm/channels/channel/components/ChannelFieldsCard.vue';
    import SubscriptionsPane from '@/product/analytics/views/crm/channels/subscriptions/SubscriptionsPane.vue';

    const {showSnackbar} = useFluxStore();
    const {t} = useI18n();
    const {single: getChannel, delete: callDelete} = useService(ChannelsService);
    const {updateAll: callRefresh} = useService(SubscriptionsService);
    const route = useRoute();
    const router = useRouter();
    const user = useUser();

    const channel = ref<Channel | null>(null);
    const isLoading = ref(true);

    const currentChannelId = computed(() => unref(route).params.id as string);

    onMounted(async () => {
        isLoading.value = true;
        const {data} = await getChannel(unref(currentChannelId));
        channel.value = data;
        isLoading.value = false;
    });

    async function refreshChannel(): Promise<void> {
        const currentChannel = unref(channel);

        if (!currentChannel) {
            return;
        }

        await callRefresh(currentChannel.id);

        showSnackbar({
            color: 'success',
            icon: 'check',
            message: t('analytics.crm.channel.refresh.working', [unref(currentChannel).name])
        });
    }

    async function deleteChannel(): Promise<void> {
        const currentChannel = unref(channel);

        if (!currentChannel) {
            return;
        }

        await callDelete(currentChannel);

        showSnackbar({
            color: 'danger',
            icon: 'trash',
            message: t('analytics.crm.channel.delete.done')
        });

        await router.push({name: unref(user)?.type === UserType.Admin ? 'crm-channels' : 'my-channels'});
    }
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-avatar-image) {
        background: transparent;
        border-radius: unset;
    }
</style>
