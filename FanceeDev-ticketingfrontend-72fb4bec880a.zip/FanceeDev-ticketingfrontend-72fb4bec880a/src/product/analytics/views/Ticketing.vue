<template>
    <FluxContainer>
        <ChannelsContainer>
            <DashboardHeader
                :channels="channels"
                :start-date="startDate"
                :end-date="endDate"
                @update-dates="updateDates"
                #header>
                <FluxFormSelectAsync
                    :class="$style.eventSelector"
                    v-model="selectedEventIds"
                    is-multiple
                    :placeholder="t('event.addBarcodesOverlay.selectEvent')"
                    :fetch-options="fetchSelect(async (ids: string[]) => await getEventOptions(organizationId, ids))"
                    :fetch-relevant="fetchSelect(async () => await getEventOptions(organizationId))"
                    :fetch-search="fetchSelect(async (searchQuery: string) => await getEventOptions(organizationId, searchQuery))"/>
            </DashboardHeader>

            <FluxNotice
                icon="circle-info"
                is-small
                :message="t('analytics.ticketing.notice.message')"
                variant="info"/>

            <MultiSumAveragePriceCard
                :selected-event-ids="selectedEventIds"
                :startDate="startDate"
                :endDate="endDate"/>

            <MultiBarTicketsByAgeCard
                :selected-event-ids="selectedEventIds"
                :startDate="startDate"
                :endDate="endDate"/>

            <MultiBarAverageTimeCard
                :selected-event-ids="selectedEventIds"
                :startDate="startDate"
                :endDate="endDate"/>
        </ChannelsContainer>
    </FluxContainer>
</template>

<script
    setup
    lang="ts">
    import { SelectService } from '@fancee/api';
    import { useActiveOrganizationId, useRememberedValue, useService } from '@/composable';
    import { DateTime } from 'luxon';
    import { ref } from 'vue';
    import { Channel } from '@/data/dto/analytics/channels';
    import { useI18n } from 'vue-i18n';
    import { fetchSelect } from '@/util';
    import MultiSumAveragePriceCard from '@/components/analytics/dashboard/MultiSumAveragePriceCard.vue';
    import ChannelsContainer from '@/components/analytics/data/channel/ChannelsContainer.vue';
    import DashboardHeader from '@/product/analytics/components/DashboardHeader.vue';
    import MultiBarTicketsByAgeCard from '@/components/analytics/dashboard/MultiBarTicketsByAgeCard.vue';
    import MultiBarAverageTimeCard from '@/components/analytics/dashboard/MultiBarAverageTimeCard.vue';

    const {t} = useI18n();
    const {getEventOptions} = useService(SelectService);
    const organizationId = useActiveOrganizationId();

    const selectedEventIds = ref<string[]>([]);
    const channels = ref<Channel[]>([]);
    const startDate = useRememberedValue<DateTime>('start-date-analytics', DateTime.now().minus({days: 7}));
    const endDate = useRememberedValue<DateTime>('end-date-analytics', DateTime.now());

    function updateDates(eventStartDate: DateTime, eventEndDate: DateTime) {
        startDate.value = eventStartDate;
        endDate.value = eventEndDate;
    }
</script>

<style
    lang="scss"
    module>
    .eventSelector {
        width: 100% !important;
        flex: auto !important;
    }
</style>
