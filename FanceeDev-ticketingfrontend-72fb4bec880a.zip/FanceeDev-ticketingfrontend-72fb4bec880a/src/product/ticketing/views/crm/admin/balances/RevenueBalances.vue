<template>
    <FluxPane is-contained>
        <FluxPaneHeader :title="t('crm.balance.revenue')"/>
        <FluxDataTable
            :is-loading="isLoading"
            :data-set="revenue"
            :page="1"
            :total="13"
            is-hoverable
            class="revenue-table">
            <template #header>
                <FluxTableHeader>{{ t('crm.balance.month') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.ticketFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.seatedTicketFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.productFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.guestlistFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.paymentFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.tsp') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.chargebackFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.refundFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.additionalCosts') }}</FluxTableHeader>
            </template>

            <template #month="{row: {month}}">
                <FluxTableCell :class="$style.month">{{ month === 13 ? t('global.total') : formatMonthLocal(month, locale) }}</FluxTableCell>
            </template>

            <template #ticketFeeCents="{row: {ticketFeeCents}}">
                <FluxTableCell>{{ asMoney(ticketFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #seatedTicketFeeCents="{row: {seatedTicketFeeCents}}">
                <FluxTableCell>{{ asMoney(seatedTicketFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #productFeeCents="{row: {productFeeCents}}">
                <FluxTableCell>{{ asMoney(productFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #guestListFeeCents="{row: {guestListFeeCents}}">
                <FluxTableCell>{{ asMoney(guestListFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #paymentFeeCents="{row: {paymentFeeCents}}">
                <FluxTableCell>{{ asMoney(paymentFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #ticketServicePlusCostCents="{row: {ticketServicePlusCostCents}}">
                <FluxTableCell>{{ asMoney(ticketServicePlusCostCents, currency) }}</FluxTableCell>
            </template>

            <template #chargebackCostCents="{row: {chargebackCostCents}}">
                <FluxTableCell>{{ asMoney(chargebackCostCents, currency) }}</FluxTableCell>
            </template>

            <template #refundCostCents="{row: {refundCostCents}}">
                <FluxTableCell>{{ asMoney(refundCostCents, currency) }}</FluxTableCell>
            </template>

            <template #additionalCostCents="{row: {additionalCostCents}}">
                <FluxTableCell>{{ asMoney(additionalCostCents, currency) }}</FluxTableCell>
            </template>
        </FluxDataTable>
    </FluxPane>
</template>


<script
    setup
    lang="ts">
    import { Currency, RevenueBalance } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { asMoney, formatMonthLocal } from '@/util';

    export interface Props {
        readonly isLoading: boolean;
        readonly revenue: RevenueBalance[];
        readonly currency: Currency;
    }

    defineProps<Props>();

    const {locale, t} = useI18n();
</script>

<style lang="scss">
    .revenue-table tbody tr:last-child {
        font-weight: bold;
        background-color: rgb(var(--gray-2));
    }
</style>

<style
    lang="scss"
    module>
    .month {
        text-transform: capitalize;
    }
</style>
