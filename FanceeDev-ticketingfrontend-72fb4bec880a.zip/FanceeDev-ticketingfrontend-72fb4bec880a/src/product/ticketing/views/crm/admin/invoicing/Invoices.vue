<template>
    <InvoiceTable
        :invoices="invoices"
        :events="events"
        :download-in-progress="downloadInvoiceInProgress"
        :is-loading="isLoadingInvoices"
        :organizations="organizations"
        is-admin
        @fetch-invoices="getInvoices"
        @download-invoice="downloadInvoicePdf"
        @export-invoices="downloadInvoicesCsv"
        @filter-events="getOrganizationEvents"
        @filter-organizations="getOrganizations"/>
</template>

<script
    lang="ts"
    setup>
    import { EventService, InvoiceService, OrganizationService } from '@fancee/api';
    import { Paginated } from '@fancee/client';
    import { AdminInvoiceFilter, EventListFilter, InvoiceListItem, OrganizationListFilter } from '@fancee/data';
    import { FluxFilterOptionItem } from '@fancee/flux';
    import { onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { DEFAULT_PAGE_LENGTH, DEFAULT_PAGES_AMOUNT, DEFAULT_SEARCH_RESULTS, DEFAULT_STARTING_PAGE } from '@/data';
    import { storeToRefs, useUiStore } from '@/data/store';
    import { downloadBlob, guarded } from '@/util';
    import InvoiceTable from '@/product/ticketing/views/crm/admin/invoicing/InvoiceTable.vue';

    const uiStore = useUiStore();
    const {allowedCountries} = storeToRefs(uiStore);
    const {t} = useI18n();
    const {csvExport, download, list: listInvoices} = useService(InvoiceService);
    const {listOrganization} = useService(EventService);
    const {list: listOrganizations} = useService(OrganizationService);

    const _csvExport = guarded(csvExport, t('ui.somethingWentWrong.title'), t('crm.invoicing.downloadFailed'));
    const _download = guarded(download, t('ui.somethingWentWrong.title'), t('crm.invoicing.downloadFailed'));
    const _listInvoices = guarded(listInvoices, t('ui.somethingWentWrong.title'), t('crm.invoicing.loadingFailed'));
    const _listOrganization = guarded(listOrganization, t('ui.somethingWentWrong.title'), t('crm.invoicing.loadingEventsFailed'));
    const _listOrganizations = guarded(listOrganizations, t('ui.somethingWentWrong.title'), t('crm.invoicing.loadingOrganizationsFailed'));

    const eventFilter = ref(EventListFilter.default());
    const organizationFilter = ref(OrganizationListFilter.default());
    const invoices = ref(new Paginated<InvoiceListItem>([], 1, 1, 1, 0));
    const organizations = ref<FluxFilterOptionItem[]>([]);
    const events = ref<FluxFilterOptionItem[]>([]);
    const isLoadingInvoices = ref(true);
    const downloadInvoiceInProgress = ref(false);
    const downloadInvoicesInProgress = ref(false);

    onMounted(async () => {
        organizationFilter.value.dateSpan = null;
        eventFilter.value.dateSpan = null;

        await getInvoices(DEFAULT_STARTING_PAGE, DEFAULT_PAGE_LENGTH, AdminInvoiceFilter.default());
        await getOrganizations('');
    });

    async function getInvoices(page: number, length: number, filter: AdminInvoiceFilter): Promise<void> {
        isLoadingInvoices.value = true;

        try {
            const {data} = await _listInvoices(length, page, filter, unref(allowedCountries));
            invoices.value = data;
        } finally {
            isLoadingInvoices.value = false;
        }
    }

    async function downloadInvoicesCsv(filter: AdminInvoiceFilter): Promise<void> {
        downloadInvoicesInProgress.value = true;

        try {
            const {blob, name} = await _csvExport(filter, unref(allowedCountries));
            downloadBlob(blob, name);
        } finally {
            downloadInvoicesInProgress.value = false;
        }
    }

    async function downloadInvoicePdf(invoiceNumber: number): Promise<void> {
        downloadInvoiceInProgress.value = true;

        try {
            const {blob, name} = await _download(invoiceNumber);
            downloadBlob(blob, name);
        } finally {
            downloadInvoiceInProgress.value = false;
        }
    }

    async function getOrganizations(searchQuery: string): Promise<void> {
        organizationFilter.value.search = searchQuery;

        const {data} = await _listOrganizations(DEFAULT_SEARCH_RESULTS, DEFAULT_PAGES_AMOUNT, organizationFilter.value, unref(allowedCountries));

        organizations.value = data.items
            .filter(o => o.name.length > 0)
            .map(o => ({
                label: o.name,
                value: o.id
            }));
    }

    async function getOrganizationEvents(searchQuery: string, filter: AdminInvoiceFilter): Promise<void> {
        if (!filter.organizationId) {
            events.value = [];
            return;
        }

        eventFilter.value.searchQuery = searchQuery;

        const {data} = await _listOrganization(filter.organizationId, DEFAULT_SEARCH_RESULTS, DEFAULT_PAGES_AMOUNT, eventFilter.value, unref(allowedCountries));

        events.value = data.items.map(e => ({
            label: e.name,
            value: e.id
        }));
    }
</script>
