<template>
    <FluxGrid>
        <FluxGridColumn
            :lg="4"
            :md="5"
            :sm="6">
            <FluxStack :key="update">
                <FluxPane :is-loading="checkableClaimCategories.length === 0"/>

                <FluxButtonStack>
                    <FluxSpacer/>

                    <FluxPrimaryButton
                        icon-before="circle-check"
                        :label="t('global.save')"
                        :is-loading="isSaving"
                        @click="saveUserClaims"/>
                </FluxButtonStack>

                <template
                    v-for="checkableClaimCategory of checkableClaimCategories"
                    :key="checkableClaimCategory.category">
                    <ClaimCategory :claim-category="checkableClaimCategory"/>
                </template>
            </FluxStack>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { AuthService } from '@fancee/api';
    import { showSnackbar } from '@fancee/flux';
    import { computed, onMounted, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { ClaimCheckCategory } from '@/data/dto/claim/ClaimCheckCategory';
    import { guarded } from '@/util';
    import { ClaimAdapter } from '@/data/adapter/claim/ClaimAdapter';
    import ClaimCategory from '@/product/ticketing/views/dashboard/generic/claims/ClaimCategory.vue';

    export interface Props {
        readonly organizationId: string;
    }

    const props = defineProps<Props>();
    const {organizationId} = toRefs(props);

    const {t} = useI18n();
    const {updateUserClaims, getPlatformClaims, getUserClaims} = useService(AuthService);

    const _getPlatformClaims = guarded(getPlatformClaims, t('ui.somethingWentWrong.title'), t('crm.organization.single.permissions.loadingClaimsFailed'));
    const _getUserClaims = guarded(getUserClaims, t('ui.somethingWentWrong.title'), t('crm.organization.single.permissions.loadingUserClaimsFailed'));
    const _updateUserClaims = guarded(updateUserClaims, t('ui.somethingWentWrong.title'), t('crm.organization.single.permissions.savingUserClaimsFailed'));

    const checkableClaimCategories = ref<ClaimCheckCategory[]>([]);
    const claims = ref<string[]>([]);
    const isSaving = ref(false);
    const update = ref(0);

    const checkedClaims = computed(() => unref(checkableClaimCategories).map(ccc => ccc.selectedClaims).flat());

    onMounted(async () => {
        await loadUserClaims();
        await loadPlatformClaims();
    });

    async function loadPlatformClaims(): Promise<void> {
        const {data} = await _getPlatformClaims();
        checkableClaimCategories.value = ClaimAdapter.parseClaimHierarchyCategoryToCheckableClaims(data, unref(claims));
    }

    async function loadUserClaims(): Promise<void> {
        const {data} = await _getUserClaims(unref(organizationId));
        claims.value = data;
    }

    async function saveUserClaims(): Promise<void> {
        isSaving.value = true;

        try {
            await _updateUserClaims(unref(organizationId), unref(checkedClaims));

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('ui.changesSavedSuccessfully')
            });
        } finally {
            isSaving.value = false;
        }
    }

    watch(() => checkableClaimCategories, () => update.value++, {deep: true});
</script>
