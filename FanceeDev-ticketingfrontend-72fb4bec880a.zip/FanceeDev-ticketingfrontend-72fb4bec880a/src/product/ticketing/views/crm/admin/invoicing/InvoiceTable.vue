<template>
    <FluxPane>
        <FluxActionBar
            :is-resettable="filter.isResettable"
            @reset="reset">
            <template #search>
                <ToolbarSearch
                    v-model="filter.searchQuery"
                    :placeholder="t('crm.invoicing.search')"/>
            </template>

            <template #filter>
                <FluxFilter
                    v-model="filter"
                    :resettable="filter.resettable"
                    @reset="(field: string) => filter.reset(field)">
                    <FluxFilterOption
                        v-if="isAdmin && !!organizations"
                        :label="t('crm.invoicing.filter.organization')"
                        :options="organizations"
                        :search-placeholder="t('crm.invoicing.filter.organizationSearch')"
                        is-searchable
                        icon="users"
                        name="organizationId"
                        @update:search="onFilterOrganizations"/>

                    <FluxFilterOption
                        v-if="showEventFilter()"
                        :label="t('crm.invoicing.filter.event')"
                        :options="events"
                        :search-placeholder="t('crm.invoicing.filter.eventSearch')"
                        is-searchable
                        icon="calendar"
                        name="eventId"
                        @update:search="onFilterEvents"/>
                </FluxFilter>
            </template>

            <template #actions-before-search>
                <ClaimCheck claim="admin.invoice.export">
                    <ToolbarDownload
                        :is-loading="downloadInProgress"
                        @download="onDownloadInvoices"/>
                </ClaimCheck>
            </template>
        </FluxActionBar>

        <FluxDataTable
            :is-loading="isLoading"
            :data-set="invoices.items"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems">
            <template #header>
                <FluxTableHeader>{{ t('crm.invoicing.table.number') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.invoicing.table.organization') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.invoicing.table.createdOn') }}</FluxTableHeader>
                <FluxTableHeader is-shrinking/>
            </template>

            <template #invoice-number="{row: {invoiceNumber}}">
                <FluxTableCell>{{ invoiceNumber }}</FluxTableCell>
            </template>

            <template #organization="{row: {organization}}">
                <FluxTableCell>{{ organization }}</FluxTableCell>
            </template>

            <template #created-at="{row: {createdAt}}">
                <FluxTableCell>{{ createdAt.toFormat(LUXON_DATE_FORMAT) }}</FluxTableCell>
            </template>

            <template #actions="{row: {invoiceNumber, hasFile}}">
                <FluxTableCell>
                    <FluxTableActions v-if="hasFile && hasClaim">
                        <FluxTooltip :content="t('global.download')">
                            <FluxAction
                                icon="arrow-down-to-line"
                                @click="downloadInvoice(invoiceNumber)"/>
                        </FluxTooltip>
                    </FluxTableActions>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { Paginated } from '@fancee/client';
    import { AdminInvoiceFilter, InvoiceFilter, InvoiceListItem, OrganizationInvoiceFilter } from '@fancee/data';
    import { FluxFilterOptionItem } from '@fancee/flux';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ToolbarDownload, ToolbarSearch } from '@/components/filter';
    import { ClaimCheck } from '@/components/ui';
    import { usePagination } from '@/composable';
    import { LUXON_DATE_FORMAT } from '@/data';
    import { storeToRefs, useAuthStore, useUiStore } from '@/data/store';

    export type Emits = {
        (e: 'download-invoice', invoiceNumber: number): void;
        (e: 'export-invoices', filter: InvoiceFilter): void;
        (e: 'fetch-invoices', page: number, length: number, filter: InvoiceFilter): void;
        (e: 'filter-events', searchQuery: string, filter: InvoiceFilter): void;
        (e: 'filter-organizations', searchQuery: string): void;
    };

    export type Props = {
        readonly invoices: Paginated<InvoiceListItem>;
        readonly events: FluxFilterOptionItem[];
        readonly organizations?: FluxFilterOptionItem[];
        readonly downloadInProgress?: boolean;
        readonly isLoading?: boolean;
        readonly isAdmin?: boolean;
    };

    const emit = defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        downloadInProgress: false,
        isLoading: false,
        isAdmin: false
    });
    const {invoices} = toRefs(props);

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const {t} = useI18n();
    const authStore = useAuthStore();
    const {claims} = storeToRefs(authStore);
    const uiStore = useUiStore();
    const {allowedCountries} = storeToRefs(uiStore);

    const filter = ref<InvoiceFilter>(props.isAdmin ? AdminInvoiceFilter.default() : OrganizationInvoiceFilter.default());

    const hasClaim = computed(() => unref(claims).includes('organization.invoice.details') || unref(claims).includes('admin.invoice.details'));

    function showEventFilter(): boolean {
        return !props.isAdmin || !!(filter.value as AdminInvoiceFilter).organizationId;
    }

    function reset() {
        filter.value.reset();
        emit('fetch-invoices', unref(currentPage), unref(pageLength), unref(filter));
        emit('filter-organizations', '');
        emit('filter-events', '', unref(filter));
    }

    function downloadInvoice(invoiceNumber: number): void {
        emit('download-invoice', invoiceNumber);
    }

    function onFilterEvents(searchQuery: string) {
        emit('filter-events', searchQuery, unref(filter));
    }

    function onFilterOrganizations(searchQuery: string) {
        emit('filter-organizations', searchQuery);
    }

    function onDownloadInvoices() {
        emit('export-invoices', unref(filter));
    }

    watch(filter, (newFilter, oldFilter) => {
        if (props.isAdmin && !!(<AdminInvoiceFilter>newFilter).organizationId) {
            // Prevent infinite recursive loop
            if (newFilter.eventId !== oldFilter.eventId) {
                newFilter.eventId = null;
            }

            emit('filter-events', '', unref(filter));
        }

        emit('fetch-invoices', unref(currentPage), unref(pageLength), unref(filter));
    }, {deep: true});

    watch([currentPage, pageLength, allowedCountries], () => emit('fetch-invoices', unref(currentPage), unref(pageLength), unref(filter)));

    watch(invoices, () => {
        setTotalItems(unref(invoices).totalItems);
    });

    watch(filter, () => {
        currentPage.value = 1;
    }, {deep: true});
</script>
