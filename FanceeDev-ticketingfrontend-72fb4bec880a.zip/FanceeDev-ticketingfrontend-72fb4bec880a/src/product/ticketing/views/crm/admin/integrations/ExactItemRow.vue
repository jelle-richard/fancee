<template>
    <FluxStack
        :axis="isDesktop ? 'horizontal' : 'vertical'"
        is-fill
        :gap="9">
        <FluxFormSelect
            v-model="itemMapping.countries"
            auto-complete="off"
            is-searchable
            is-multiple
            :options="availableCountries"
            @update:model-value="onCountriesUpdated"/>

        <FluxFormSelect
            v-model="itemMapping.exactItemCode"
            is-searchable
            :placeholder="t('crm.integration.exact.mapping.notMapped')"
            :options="exactItems"/>

        <FluxTooltip :content="t('crm.integration.exact.mapping.country.add')">
            <FluxSecondaryButton
                v-if="!showDeleteButton"
                icon-before="plus"
                @click="$emit('add-country-mapping')"/>
        </FluxTooltip>

        <FluxTooltip :content="t('crm.integration.exact.mapping.country.remove')">
            <FluxDestructiveButton
                v-if="showDeleteButton"
                icon-before="trash"
                @click="$emit('remove-country-mapping')"/>
        </FluxTooltip>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { FluxFormSelectOption, useBreakpoints } from '@fancee/flux';
    import { toRefs } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ExactCountriesMapping } from '@/data/dto/accounting';

    export interface Props {
        readonly showDeleteButton: boolean;
        readonly availableCountries: FluxFormSelectOption[];
        readonly exactItems: FluxFormSelectOption[];
        readonly itemMapping: ExactCountriesMapping;
    }

    export interface Emits {
        (e: 'add-country-mapping'): void;

        (e: 'remove-country-mapping'): void;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {itemMapping} = toRefs(props);

    const {isDesktop} = useBreakpoints();
    const {t} = useI18n();

    function onCountriesUpdated(): void {
        // Makes sure that the user cannot enter NL, DE, All (other) countries
        if (itemMapping.value.countries.length > 1 && itemMapping.value.countries.includes(null)) {
            itemMapping.value.countries = itemMapping.value.countries.filter(c => c !== null);
        }
    }
</script>
