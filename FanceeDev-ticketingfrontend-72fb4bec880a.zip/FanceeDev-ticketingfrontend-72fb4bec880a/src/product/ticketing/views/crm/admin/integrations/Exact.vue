<template>
    <FluxPane :is-loading="isLoading">
        <IntegrationDetails
            :logo="logo"
            :title="t('crm.integration.exact.title')"
            :description="t('crm.integration.exact.description')"/>
        <FluxPaneBody>
            <FluxButtonStack axis="vertical">
                <FluxPrimaryButton
                    :label="integrationComplete ? t('crm.integration.configure') : t('crm.integration.connect')"
                    :icon-before="integrationComplete ? 'gear' : 'link-simple'"
                    @click="integrationComplete ? configureExact() : enableExact()"/>
            </FluxButtonStack>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ExactService } from '@fancee/api';
    import { showSnackbar } from '@fancee/flux';
    import { onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRoute, useRouter, useService } from '@/composable';
    import { guarded } from '@/util';
    import IntegrationDetails from '@/product/ticketing/views/crm/admin/integrations/IntegrationDetails.vue';
    import logo from '@/assets/images/logos/integrations/exact.svg';

    const {t} = useI18n();
    const {authenticate, getEnabled} = useService(ExactService);
    const route = useRoute();
    const router = useRouter();

    const _authenticate = guarded(authenticate, t('ui.somethingWentWrong.title'), t('crm.integration.exact.loadingFailed'));
    const _getEnabled = guarded(getEnabled, t('ui.somethingWentWrong.title'), t('crm.integration.exact.loadingStatusFailed'));

    const isLoading = ref(false);
    const integrationComplete = ref(false);

    onMounted(async () => {
        await exactEnabled();
        checkExactIntegrationResult();
    });

    function checkExactIntegrationResult(): void {
        if (!('exactIntegrationComplete' in unref(route).query)) {
            return;
        }

        if (unref(route).query.exactIntegrationComplete?.toString().toLowerCase() === 'true') {
            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('crm.integration.exact.completed')
            });
        } else {
            showSnackbar({
                color: 'danger',
                icon: 'circle-exclamation',
                message: t('ui.somethingWentWrong.message')
            });
        }
    }

    async function exactEnabled(): Promise<void> {
        isLoading.value = true;

        try {
            const {data} = await _getEnabled();
            integrationComplete.value = data;
        } finally {
            isLoading.value = false;
        }
    }

    async function configureExact(): Promise<void> {
        await router.push({name: 'configure-exact'});
    }

    async function enableExact(): Promise<void> {
        isLoading.value = true;

        try {
            const {data: url} = await _authenticate();
            window.open(url, '_self');
        } finally {
            isLoading.value = false;
        }
    }
</script>
