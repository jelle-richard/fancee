<template>
    <FluxGrid
        class="header"
        v-if="breakpoint === 'lg' || breakpoint === 'xl'">
        <FluxGridColumn :lg="2">
            <p><strong>{{ t('crm.integration.exact.mapping.platform') }}</strong></p>
        </FluxGridColumn>

        <FluxGridColumn :lg="10">
            <p><strong>{{ t('crm.integration.exact.mapping.exact') }}</strong></p>
        </FluxGridColumn>
    </FluxGrid>

    <FluxStack>
        <FluxGrid
            v-for="itemMapping in exactPlatformItems"
            class="item-grid"
            :key="itemMapping.platformCode">
            <FluxGridColumn :lg="2">
                {{ itemMapping.platformCode }}
            </FluxGridColumn>

            <FluxGridColumn :lg="10">
                <FluxStack
                    is-fill
                    :gap="9">
                    <FluxFormRow
                        v-for="(countryItem, index) in itemMapping.exactCountriesMappings"
                        :key="`country_item_${itemMapping.platformCode}_${index}`">
                        <FluxStack
                            axis="horizontal"
                            is-fill
                            :gap="9">
                            <ExactItemRow
                                :show-delete-button="index > 0"
                                :available-countries="getAvailableCountries(itemMapping, countryItem)"
                                :exact-items="exactItems"
                                :item-mapping="countryItem"
                                @add-country-mapping="onAddCountryMapping(itemMapping)"
                                @remove-country-mapping="onRemoveCountryMapping(itemMapping, index)"/>
                        </FluxStack>
                    </FluxFormRow>
                </FluxStack>
            </FluxGridColumn>
        </FluxGrid>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { FluxFormSelectOption, useBreakpoints } from '@fancee/flux';
    import { useI18n } from 'vue-i18n';
    import { SELECT_COUNTRY_OPTIONS } from '@/data';
    import { ExactCountriesMapping, ExactItemMapping } from '@/data/dto/accounting';
    import ExactItemRow from '@/product/ticketing/views/crm/admin/integrations/ExactItemRow.vue';

    export interface Props {
        readonly exactPlatformItems: ExactItemMapping[];
        readonly exactItems: FluxFormSelectOption[];
    }

    defineProps<Props>();

    const {breakpoint} = useBreakpoints();
    const {t} = useI18n();

    function getAvailableCountries(itemMapping: ExactItemMapping, countryMapping: ExactCountriesMapping): FluxFormSelectOption[] {
        const allCountries = [{id: null!, label: 'All (other) countries'}, ...SELECT_COUNTRY_OPTIONS];

        const currentCountries = itemMapping.exactCountriesMappings.flatMap(ecm => ecm.countries)
            .filter(c => !countryMapping.countries.includes(c));

        return allCountries.filter(ac => !currentCountries.includes(<string | null>ac.id));
    }

    function onAddCountryMapping(mapping: ExactItemMapping) {
        mapping.exactCountriesMappings.push(new ExactCountriesMapping([], null));
    }

    function onRemoveCountryMapping(mapping: ExactItemMapping, index: number) {
        mapping.exactCountriesMappings.splice(index, 1);
    }
</script>

<style
    lang="scss"
    scoped>
    .header {
        padding-left: 6px;
    }

    .item-grid {
        padding: 6px;

        &:hover {
            background-color: rgb(var(--gray-1));
        }
    }
</style>
