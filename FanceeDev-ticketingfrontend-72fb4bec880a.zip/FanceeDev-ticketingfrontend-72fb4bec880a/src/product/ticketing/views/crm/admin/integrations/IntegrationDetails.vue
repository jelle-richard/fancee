<template>
    <FluxPane>
        <FluxPaneHeader>
            <img
                class="integration-logo"
                :src="logo"
                :alt="`${title}`"/>
        </FluxPaneHeader>
        <FluxPaneBody>
            <h4>{{ title }}</h4>
            <p>{{ description }}</p>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    export interface Props {
        readonly logo: string;
        readonly title: string;
        readonly description: string;
    }

    defineProps<Props>();
</script>
