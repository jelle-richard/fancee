<template>
    <FluxStack>
        <FluxFormSelect
            v-model="selectedYear"
            :class="$style.dateSelector"
            :options="years"/>

        <ReceivedBalances
            :is-loading="isLoading"
            :received="received"
            :currency="currency"/>

        <RevenueBalances
            :is-loading="isLoading"
            :revenue="revenue"
            :currency="currency"/>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { ReportService } from '@fancee/api';
    import { ReceivedBalance, RevenueBalance } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useCurrency, useService } from '@/composable';
    import { SelectAdapter } from '@/data/adapter/components/select/SelectAdapter';
    import { useStore, useUiStore } from '@/data/store';
    import { guarded } from '@/util';
    import ReceivedBalances from './ReceivedBalances.vue';
    import RevenueBalances from './RevenueBalances.vue';

    const {allowedCountries} = useStore(useUiStore());

    const {t} = useI18n();
    const {getMonthlyBalancesForYear} = useService(ReportService);
    const currency = useCurrency();

    const _getMonthlyBalancesForYear = guarded(getMonthlyBalancesForYear, t('ui.somethingWentWrong.title'), t('crm.balance.loadingFailed'));

    const years = computed<FluxFormSelectOption[]>(() => SelectAdapter.platformYears());

    const received = ref<ReceivedBalance[]>([]);
    const revenue = ref<RevenueBalance[]>([]);
    const isLoading = ref(false);
    const selectedYear = ref(DateTime.now().year);

    async function getBalances(): Promise<void> {
        isLoading.value = true;

        try {
            const {data} = await _getMonthlyBalancesForYear(unref(selectedYear), unref(allowedCountries));

            received.value = data.receivedBalances;
            addTotalReceived();

            revenue.value = data.revenueBalances;
            addTotalRevenue();
        } finally {
            isLoading.value = false;
        }
    }

    function addTotalReceived(): void {
        received.value.push(
            unref(received).reduce((acc, curr) => {
                acc.issuedTickets = acc.issuedTickets.add(curr.issuedTickets);
                acc.fulfilledOrders += curr.fulfilledOrders;
                acc.productIncomeCents += curr.productIncomeCents;
                acc.ticketFeeCents += curr.ticketFeeCents;
                acc.seatedTicketFeeCents += curr.seatedTicketFeeCents;
                acc.productFeeCents += curr.productFeeCents;
                acc.paymentFeeCents += curr.paymentFeeCents;
                acc.ticketServicePlusCents += curr.ticketServicePlusCents;
                acc.smsCents += curr.smsCents;
                acc.refundedCents += curr.refundedCents;
                acc.chargedBackCents += curr.chargedBackCents;

                return acc;
            }, ReceivedBalance.emptyTotal())
        );
    }

    function addTotalRevenue(): void {
        revenue.value.push(
            unref(revenue).reduce((acc, curr) => {
                acc.ticketFeeCents += curr.ticketFeeCents;
                acc.seatedTicketFeeCents += curr.seatedTicketFeeCents;
                acc.productFeeCents += curr.productFeeCents;
                acc.guestListFeeCents += curr.guestListFeeCents;
                acc.paymentFeeCents += curr.paymentFeeCents;
                acc.ticketServicePlusCostCents += curr.ticketServicePlusCostCents;
                acc.smsCostCents += curr.smsCostCents;
                acc.chargebackCostCents += curr.chargebackCostCents;
                acc.refundCostCents += curr.refundCostCents;
                acc.additionalCostCents += curr.additionalCostCents;

                return acc;
            }, RevenueBalance.emptyTotal())
        );
    }

    watch([selectedYear, allowedCountries], async () => await getBalances(), {immediate: true});
</script>

<style
    lang="scss"
    module>
    .dateSelector {
        max-width: 200px;
    }
</style>
