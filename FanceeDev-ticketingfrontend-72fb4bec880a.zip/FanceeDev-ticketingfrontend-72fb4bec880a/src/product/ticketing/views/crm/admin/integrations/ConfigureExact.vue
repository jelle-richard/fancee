<template>
    <FluxPane :is-loading="isLoading || isSaving">
        <FluxPaneBody>
            <FluxStack>
                <FluxFormField :label="t('crm.integration.exact.configure.selectJournal')">
                    <FluxFormSelect
                        v-model="selectedJournal"
                        :options="journals"/>
                </FluxFormField>

                <FluxFormField :label="t('crm.integration.exact.configure.configureItems')">
                    <ExactConfigureItemsTable
                        :exact-items="exactItems"
                        :exact-platform-items="itemMappings"/>
                </FluxFormField>
            </FluxStack>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxSecondaryButton
                :label="t('global.cancel')"
                @click="router.push({name: 'integrations'})"/>

            <FluxPrimaryButton
                icon-before="circle-check"
                :label="t('global.save')"
                :disabled="isSaving"
                :is-loading="isSaving"
                @click="save"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { AccountingInvoiceService, ExactService } from '@fancee/api';
    import { ConfigurableCountryItem, ConfigurableItem, ConfigurableItems, ConfigurableJournal } from '@fancee/data';
    import { FluxFormSelectOption, showSnackbar } from '@fancee/flux';
    import { onMounted, ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRouter, useService } from '@/composable';
    import { ExactCountriesMapping, ExactItemMapping } from '@/data/dto/accounting';
    import { guarded } from '@/util';
    import ExactConfigureItemsTable from '@/product/ticketing/views/crm/admin/integrations/ExactConfigureItemsTable.vue';
    import groupBy from 'lodash/groupBy';
    import map from 'lodash/map';

    const {t} = useI18n();
    const {getSpecificationNames} = useService(AccountingInvoiceService);
    const {getEnabled, getItems, getJournals, configure, configureItems, configuration} = useService(ExactService);
    const router = useRouter();

    const _configuration = guarded(configuration, t('ui.somethingWentWrong.title'), t('crm.integration.exact.configure.loadingConfigurationFailed'));
    const _getItems = guarded(getItems, t('ui.somethingWentWrong.title'), t('crm.integration.exact.configure.loadingItemsFailed'));
    const _getJournals = guarded(getJournals, t('ui.somethingWentWrong.title'), t('crm.integration.exact.configure.loadingJournalsFailed'));
    const _getSpecificationNames = guarded(getSpecificationNames, t('ui.somethingWentWrong.title'), t('crm.integration.exact.configure.loadingSpecificationNamesFailed'));

    const isLoading = ref(true);
    const isSaving = ref(false);
    const journals = ref<FluxFormSelectOption[]>([]);
    const exactItems = ref<FluxFormSelectOption[]>([]);
    const selectedJournal = ref<string | null>(null);
    const itemMappings = ref<ExactItemMapping[]>([]);
    const platformItems = ref<string[]>([]);

    onMounted(async () => {
        if (await redirectIfNotEnabled()) {
            return;
        }

        await fetchPlatformItems();
        await fetchJournals();
        await fetchItems();
        await fetchConfiguration();

        isLoading.value = false;
    });

    async function save() {
        isSaving.value = true;

        if (await updateJournal() && await updateItems()) {
            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('ui.changesSavedSuccessfully')
            });
        } else {
            showSnackbar({
                color: 'danger',
                icon: 'circle-exclamation',
                message: t('ui.somethingWentWrong.message')
            });
        }

        isSaving.value = false;
    }

    async function updateJournal(): Promise<boolean> {
        if (selectedJournal.value === null) {
            showSnackbar({
                color: 'warning',
                icon: 'circle-exclamation',
                message: t('ui.somethingWentWrong.message')
            });

            return false;
        }

        try {
            await configure(new ConfigurableJournal(selectedJournal.value));

            return true;
        } catch (err) {
            return false;
        }
    }

    async function updateItems(): Promise<boolean> {
        try {
            await configureItems(exactItemMappingsToConfigurableItems());

            return true;
        } catch (err) {
            return false;
        }
    }

    function exactItemMappingsToConfigurableItems(): ConfigurableItems {
        const configurableItems = new ConfigurableItems([]);

        for (const item of itemMappings.value) {
            const countryMappings = item.exactCountriesMappings.flatMap(cm => cm.countries.map(c => new ConfigurableCountryItem(c, cm.exactItemCode!)));

            configurableItems.items.push(new ConfigurableItem(item.platformCode, countryMappings));
        }

        return configurableItems;
    }

    function configurableItemsToExactItemMappings(configurableItems: ConfigurableItem[]): ExactItemMapping[] {
        const mappings: ExactItemMapping[] = [];

        for (const item of configurableItems) {
            const countries = map(
                groupBy(item.countryItems, ci => ci.exactItemCode),
                (group, key) => new ExactCountriesMapping(group.map(g => g.countryCode), key)
            );

            mappings.push(new ExactItemMapping(item.platformItem, countries));
        }

        return mappings;
    }

    async function fetchPlatformItems(): Promise<void> {
        const {data: fetchedSpecificationNames} = await _getSpecificationNames();
        platformItems.value = fetchedSpecificationNames;
    }

    async function fetchJournals(): Promise<void> {
        const {data: fetchedJournals} = await _getJournals();

        journals.value = fetchedJournals.map<FluxFormSelectOption>(j => ({
            id: j.code,
            label: `${j.code} - ${j.description} (${j.currency})`
        }));
    }

    async function fetchItems(): Promise<void> {
        const {data: fetchedItems} = await _getItems();

        exactItems.value = fetchedItems.map<FluxFormSelectOption>(i => ({
            id: i.id,
            label: `${i.code} - ${i.description}`
        }));
    }

    async function fetchConfiguration(): Promise<void> {
        const {data: fetchedConfiguration} = await _configuration();

        if (fetchedConfiguration.journal !== '') {
            selectedJournal.value = fetchedConfiguration.journal;
        }

        if (fetchedConfiguration.items?.length > 0) {
            configureItemMappings(fetchedConfiguration.items);
        }
    }

    async function redirectIfNotEnabled(): Promise<boolean> {
        try {
            const {data: enabled} = await getEnabled();

            if (enabled) {
                return false;
            }
        } catch (_) {
            // note(Bas): Errors such as unauthorized are handled by the HoF guard on
            //  getEnabled, but because we want to return something we should catch
            //  all other errors here, but don't actually care that much :-).
        }

        showSnackbar({
            color: 'danger',
            icon: 'circle-exclamation',
            message: t('crm.integration.exact.configure.disconnected')
        });

        await router.push({name: 'integrations'});

        return true;
    }

    function configureItemMappings(fetchedItems: ConfigurableItem[]): void {
        const platformMappings = platformItems.value.map(pi => new ExactItemMapping(pi, [new ExactCountriesMapping([], null)]));
        const mappedItems = configurableItemsToExactItemMappings(fetchedItems);

        mappedItems.push(...platformMappings.filter(pm => mappedItems.find(mi => mi.platformCode === pm.platformCode) === undefined));

        for (const item of mappedItems) {
            const im = itemMappings.value.find(im => im.platformCode === item.platformCode);

            if (im !== undefined) {
                im.exactCountriesMappings = item.exactCountriesMappings;
            }
        }

        itemMappings.value = mappedItems;
    }
</script>
