<template>
    <FluxStack>
        <ResponseErrorsNotice
            v-if="hasErrors"
            :errors="errors"/>

        <FluxPane>
            <FluxActionBar
                :is-resettable="listFilter.isResettable"
                @reset="listFilter.reset()">
                <template #primary>
                    <FluxButtonGroup>
                        <FluxSecondaryButton
                            :disabled="viewMode === 'list'"
                            icon-before="list"
                            @click="viewMode = 'list'"/>

                        <FluxSecondaryButton
                            :disabled="viewMode === 'agenda'"
                            icon-before="calendar"
                            @click="viewMode = 'agenda'"/>
                    </FluxButtonGroup>
                </template>

                <template
                    v-if="viewMode === 'list'"
                    #search>
                    <ToolbarSearch
                        v-model="listFilter.searchQuery"
                        :placeholder="t('event.list.searchPlaceholder')"/>
                </template>

                <template
                    v-if="viewMode === 'list'"
                    #filter>
                    <FluxFilter
                        v-model="listFilter"
                        :resettable="listFilter.resettable"
                        @reset="(field: string) => listFilter.reset(field)">
                        <FluxFilterDateRange
                            icon="calendar"
                            :label="t('global.filter.date')"
                            name="dateSpan"/>

                        <FluxFilterOptions
                            icon="circle-dashed"
                            :label="t('global.filter.state')"
                            name="states"
                            :options="eventStateFilterOptions"/>
                    </FluxFilter>
                </template>
            </FluxActionBar>

            <template v-if="viewMode === 'list'">
                <EventDataTable
                    is-readonly
                    :current-page="currentPage"
                    :is-loading="isLoading"
                    :items="listEvents"
                    :page-length="pageLength"
                    :total-items="totalItems"/>

                <FluxPaneFooter>
                    <FluxPaginationBar
                        :page="currentPage"
                        :per-page="pageLength"
                        :total="totalItems"
                        @limit="setPageLength"
                        @navigate="setCurrentPage"/>
                </FluxPaneFooter>
            </template>

            <template v-else>
                <FluxCalendar
                    class="calendar"
                    :is-loading="isLoading"
                    @navigate="setAgendaDateTimeSpan">
                    <FluxCalendarEvent
                        v-for="event of agendaEvents"
                        :key="event.id"
                        :date="event.startDate"
                        :label="event.name"/>
                </FluxCalendar>

                <FluxPaneFooter/>
            </template>
        </FluxPane>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { EventService } from '@fancee/api';
    import { EventAgendaListing, EventListFilter, EventListing, EventStatus } from '@fancee/data';
    import { FluxFilterOptionItem } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ToolbarSearch } from '@/components/filter';
    import { ResponseErrorsNotice } from '@/components/ui';
    import { usePagination, useRememberedValue, useRequestErrorBoundary, useService } from '@/composable';
    import { EventDataTable } from '@/product/ticketing/components';
    import { storeToRefs, useUiStore } from '@/data/store';

    const uiStore = useUiStore();
    const {allowedCountries} = storeToRefs(uiStore);
    const {t} = useI18n();
    const {errors, hasErrors, reset: resetErrors} = useRequestErrorBoundary();
    const {getAgendaPlatform, listPlatform} = useService(EventService);
    const viewMode = useRememberedValue<'agenda' | 'list'>('crm-platform-events-view-mode', 'list');

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const agendaEvents = ref<EventAgendaListing[]>([]);
    const isLoading = ref(false);
    const listEvents = ref<EventListing[]>([]);
    const listFilter = ref(EventListFilter.default());
    const fromDate = ref<DateTime | null>(null);
    const toDate = ref<DateTime | null>(null);

    const eventStateFilterOptions = computed<FluxFilterOptionItem[]>(() => [
        {label: t('event.status.active'), value: EventStatus.Active},
        {label: t('event.status.canceled'), value: EventStatus.Cancelled},
        {label: t('event.status.unpublished'), value: EventStatus.Unpublished},
        {label: t('event.status.soldOut'), value: EventStatus.SoldOut},
        {label: t('event.status.concluded'), value: EventStatus.Concluded},
        {label: t('event.status.concept'), value: EventStatus.Concept}
    ]);

    function setAgendaDateTimeSpan(_: DateTime, from: DateTime, to: DateTime): void {
        fromDate.value = from;
        toDate.value = to;
    }

    async function loadAgenda(): Promise<void> {
        resetErrors();

        if (unref(fromDate) === null || unref(toDate) === null) {
            return;
        }

        isLoading.value = true;

        const {data: events} = await getAgendaPlatform(unref(fromDate)!, unref(toDate)!, unref(allowedCountries));

        agendaEvents.value = events;
        isLoading.value = false;
    }

    async function loadList(): Promise<void> {
        resetErrors();
        isLoading.value = true;

        const {data: {items, totalItems}} = await listPlatform(unref(pageLength), unref(currentPage), unref(listFilter), unref(allowedCountries));
        listEvents.value = items;
        setTotalItems(totalItems);

        isLoading.value = false;
    }

    watch(hasErrors, () => isLoading.value = false);

    watch([currentPage, pageLength, listFilter, allowedCountries, fromDate, toDate], async () => {
        if (unref(viewMode) === 'list') {
            await loadList();
        } else {
            await loadAgenda();
        }
    }, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .calendar {
        margin-top: -12px;

        ::v-deep(.flux-action-bar) {
            padding-top: 6px;
        }
    }
</style>
