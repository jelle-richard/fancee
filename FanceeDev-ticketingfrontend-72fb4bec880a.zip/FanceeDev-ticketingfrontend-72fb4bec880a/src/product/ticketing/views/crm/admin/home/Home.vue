<template>
    <FluxStack>
        <SelectorPane :title="t('crm.home.statisticsFor', [selectedYear])">
            <FluxFormSelect
                v-model="selectedYear"
                :options="years"/>
        </SelectorPane>

        <GlobalEventStatisticsCards :global-event-statistics="globalEventStatistics"/>

        <GeneralTargetProgression :platform-growth-target-progression="platformGrowthTargetProgression"/>

        <PlatformGrowthTargetsChart
            :currency="currency"
            :platform-growth-target-progression="platformGrowthTargetProgression"
            :ticket-revenue-indication="ticketRevenueIndication"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { EventService, ReportService } from '@fancee/api';
    import { GlobalEventStatistics, PlatformGrowthTargetProgression, TicketRevenueIndication } from '@fancee/data';
    import { FluxFormSelectOption } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { SelectorPane } from '@/components/ui';
    import { useCurrency, useService } from '@/composable';
    import { SelectAdapter } from '@/data/adapter/components/select/SelectAdapter';
    import { useStore, useUiStore } from '@/data/store';
    import { guarded } from '@/util';
    import GeneralTargetProgression from '@/product/ticketing/views/crm/admin/targets/GeneralTargetProgression.vue';
    import GlobalEventStatisticsCards from '@/product/ticketing/views/dashboard/organization/statistics/GlobalEventStatisticsCards.vue';
    import PlatformGrowthTargetsChart from '@/product/ticketing/views/crm/admin/targets/PlatformGrowthTargetsChart.vue';

    const {allowedCountries} = useStore(useUiStore());

    const {t} = useI18n();
    const {getGlobalStatisticsPlatform} = useService(EventService);
    const {getPlatformGrowthTargets, getTicketRevenueIndication} = useService(ReportService);

    const _getGlobalStatisticsPlatform = guarded(getGlobalStatisticsPlatform, t('ui.somethingWentWrong.title'), t('crm.home.failed.loadingGlobalPlatformStatistics'));
    const _getPlatformGrowthTargets = guarded(getPlatformGrowthTargets, t('ui.somethingWentWrong.title'), t('crm.home.failed.loadingGrowthTargets'));
    const _getTicketRevenueIndication = guarded(getTicketRevenueIndication, t('ui.somethingWentWrong.title'), t('crm.home.failed.loadingTicketRevenueIndication'));

    const platformGrowthTargetProgression = ref<PlatformGrowthTargetProgression[]>([]);
    const ticketRevenueIndication = ref<TicketRevenueIndication | null>(null);
    const globalEventStatistics = ref<GlobalEventStatistics | null>(null);
    const isLoadingPlatformStatistics = ref(true);
    const currency = useCurrency();
    const selectedYear = ref(DateTime.now().year);

    const years = computed<FluxFormSelectOption[]>(() => SelectAdapter.platformYears());

    async function loadGlobalPlatformStatistics(): Promise<void> {
        globalEventStatistics.value = null;

        let startDate = DateTime.local(unref(selectedYear), 1, 1, 0, 0, 0);
        let endDate = DateTime.local(unref(selectedYear), 12, 31, 23, 59, 59);

        try {
            const {data} = await _getGlobalStatisticsPlatform(startDate, endDate, unref(allowedCountries));
            globalEventStatistics.value = data;
        } finally {
            isLoadingPlatformStatistics.value = false;
        }
    }

    async function loadPlatformGrowthTargets(): Promise<void> {
        platformGrowthTargetProgression.value = [];

        const {data} = await _getPlatformGrowthTargets(unref(selectedYear), unref(allowedCountries));
        platformGrowthTargetProgression.value = data;
    }

    async function loadPlatformTicketRevenueIndication(): Promise<void> {
        ticketRevenueIndication.value = null;

        const {data} = await _getTicketRevenueIndication(unref(selectedYear), unref(allowedCountries));
        ticketRevenueIndication.value = data;
    }

    watch([allowedCountries, selectedYear], async () => {
        await loadPlatformGrowthTargets();
        await loadGlobalPlatformStatistics();
        await loadPlatformTicketRevenueIndication();
    }, {immediate: true});
</script>
