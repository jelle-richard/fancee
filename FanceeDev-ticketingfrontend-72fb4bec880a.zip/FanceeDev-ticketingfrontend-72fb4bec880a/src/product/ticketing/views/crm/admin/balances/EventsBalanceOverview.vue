<template>
    <FluxPane>
        <FluxActionBar
            :is-resettable="listFilter.isResettable"
            @reset="listFilter.reset()">
            <template #search>
                <ToolbarSearch
                    v-model="listFilter.searchQuery"
                    :placeholder="t('event.list.searchPlaceholder')"/>
            </template>

            <template #filter>
                <FluxFilter
                    v-model="listFilter"
                    :resettable="listFilter.resettable"
                    @reset="(field: string) => listFilter.reset(field)">
                    <FluxFilterDateRange
                        icon="calendar"
                        :label="t('global.date')"
                        name="dateSpan"/>
                </FluxFilter>
            </template>
        </FluxActionBar>

        <FluxDataTable
            :data-set="listEvents"
            :is-loading="isLoading"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems"
            is-hoverable>
            <template #header>
                <FluxTableHeader>{{ t('crm.eventBalance.table.event') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.eventBalance.table.organization') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.eventBalance.table.status') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.eventBalance.table.scannedTickets') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.eventBalance.table.fees') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.eventBalance.table.received') }}</FluxTableHeader>
            </template>

            <template #event="{row: {startDate, endDate, eventName}}">
                <FluxTableCell v-slot:content>
                    <div class="event-caption">
                        <FluxAvatar
                            class="event-caption-type"
                            fallback="neutral"
                            fallback-icon="ticket"
                            :size="42"/>

                        <div class="event-caption-info">
                            <FluxTooltip :content="eventName">
                                <strong>{{ truncateString(eventName, 30) }}</strong>
                            </FluxTooltip>
                            <small>{{ formatDateTimeLocal(startDate) }} - {{ formatDateTimeLocal(endDate) }}</small>
                        </div>
                    </div>
                </FluxTableCell>
            </template>

            <template #organization="{row: {userEmail, countryCode}}">
                <FluxTableCell>
                    <div class="organization-caption">
                        <FluxTooltip
                            v-if="countryCode !== null"
                            :content="AddressAdapter.parseCountryCodeToDisplay(countryCode)">
                            <img
                                class="country-flag"
                                :src="countryFlagImages[countryCode]"
                                alt=""/>
                        </FluxTooltip>
                        {{ userEmail }}
                    </div>
                </FluxTableCell>
            </template>

            <template #status="{row: {status}}">
                <FluxTableCell>
                    <FluxBadge
                        class="event-status"
                        dot
                        :color="EVENT_STATUSES[status.toLowerCase()]"
                        :label="t(`event.status.${status.toLowerCase()}`)"/>
                </FluxTableCell>
            </template>

            <template #scanned="{row: {totalAmountOfIssuedTickets, totalAmountOfScannedTickets}}">
                <FluxTableCell>
                    <div class="event-balance-amounts">
                        {{ totalAmountOfScannedTickets }} / {{ totalAmountOfIssuedTickets }}
                    </div>
                </FluxTableCell>
            </template>

            <template #fees="{row: {organizationCurrencyEventBalanceCentsReceivedResponse, platformCurrencyEventBalanceCentsReceivedResponse}}">
                <FluxTableCell>
                    <div class="event-balance-amounts">
                        <FluxTooltip v-if="organizationCurrencyEventBalanceCentsReceivedResponse.currency.shortCode !== platformCurrencyEventBalanceCentsReceivedResponse.currency.shortCode">
                            <template #content>
                                <span v-if="organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.ticketFee') }}:</strong> {{ asMoney(organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketFeeCentsReceived, organizationCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfSeatedTicketFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.seatedTicketFee') }}:</strong> {{ asMoney(organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfSeatedTicketFeeCentsReceived, organizationCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfPaymentFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.paymentFee') }}:</strong> {{ asMoney(organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfPaymentFeeCentsReceived, organizationCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfGuestListFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.guestlistFee') }}:</strong> {{ asMoney(organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfGuestListFeeCentsReceived, organizationCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketPlusCostsCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.tsp') }}:</strong> {{ asMoney(organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketPlusCostsCentsReceived, organizationCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>
                            </template>

                            <span>{{ asMoney(totalFees(organizationCurrencyEventBalanceCentsReceivedResponse), organizationCurrencyEventBalanceCentsReceivedResponse.currency) }}</span>
                        </FluxTooltip>

                        <FluxTooltip>
                            <template #content>
                                <span v-if="platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.ticketFee') }}:</strong> {{ asMoney(platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketFeeCentsReceived, platformCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfSeatedTicketFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.seatedTicketFee') }}:</strong> {{ asMoney(platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfSeatedTicketFeeCentsReceived, platformCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfPaymentFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.paymentFee') }}:</strong> {{ asMoney(platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfPaymentFeeCentsReceived, platformCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfGuestListFeeCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.guestlistFee') }}:</strong> {{ asMoney(platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfGuestListFeeCentsReceived, platformCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>

                                <span v-if="platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketPlusCostsCentsReceived > 0">
                                    <strong>{{ t('crm.eventBalance.tip.tsp') }}:</strong> {{ asMoney(platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfTicketPlusCostsCentsReceived, platformCurrencyEventBalanceCentsReceivedResponse.currency) }}
                                </span>
                            </template>

                            <span>{{ asMoney(totalFees(platformCurrencyEventBalanceCentsReceivedResponse), platformCurrencyEventBalanceCentsReceivedResponse.currency) }}</span>
                        </FluxTooltip>
                    </div>
                </FluxTableCell>
            </template>

            <template #received="{row: {organizationCurrencyEventBalanceCentsReceivedResponse, platformCurrencyEventBalanceCentsReceivedResponse}}">
                <FluxTableCell>
                    <div class="event-balance-amounts">
                        <span v-if="organizationCurrencyEventBalanceCentsReceivedResponse.currency.shortCode !== platformCurrencyEventBalanceCentsReceivedResponse.currency.shortCode">{{ asMoney(organizationCurrencyEventBalanceCentsReceivedResponse.totalAmountOfOrderTotalCostsCentsReceived, organizationCurrencyEventBalanceCentsReceivedResponse.currency) }}</span>
                        <span>{{ asMoney(platformCurrencyEventBalanceCentsReceivedResponse.totalAmountOfOrderTotalCostsCentsReceived, platformCurrencyEventBalanceCentsReceivedResponse.currency) }}</span>
                    </div>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { EventService } from '@fancee/api';
    import { AddressAdapter, EventBalance, EventBalanceListFilter, EventBalanceListing, truncateString } from '@fancee/data';
    import { ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ToolbarSearch } from '@/components/filter';
    import { usePagination, useService } from '@/composable';
    import { EVENT_STATUSES } from '@/data';
    import { storeToRefs, useUiStore } from '@/data/store';
    import { asMoney, formatDateTimeLocal, guarded } from '@/util';
    import countryFlagImages from '@/assets/language';

    const uiStore = useUiStore();
    const {allowedCountries} = storeToRefs(uiStore);

    const {t} = useI18n();
    const {getBalanceEvents} = useService(EventService);

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const _getBalanceEvents = guarded(getBalanceEvents, t('ui.somethingWentWrong.title'), t('crm.eventBalance.loadingFailed'));

    const isLoading = ref(false);
    const listEvents = ref<EventBalanceListing[]>([]);
    const listFilter = ref(EventBalanceListFilter.default());

    async function loadList(): Promise<void> {
        isLoading.value = true;

        try {
            const {data: {items, totalItems}} = await _getBalanceEvents(unref(pageLength), unref(currentPage), unref(listFilter), unref(allowedCountries));

            listEvents.value = items;
            setTotalItems(totalItems);
        } finally {
            isLoading.value = false;
        }
    }

    function totalFees(eventBalance: EventBalance): number {
        return eventBalance.totalAmountOfTicketFeeCentsReceived
            + eventBalance.totalAmountOfSeatedTicketFeeCentsReceived
            + eventBalance.totalAmountOfPaymentFeeCentsReceived
            + eventBalance.totalAmountOfGuestListFeeCentsReceived
            + eventBalance.totalAmountOfTicketPlusCostsCentsReceived;
    }

    watch([currentPage, pageLength, listFilter, allowedCountries], async () => await loadList(), {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .event-caption {
        display: flex;
        height: 100%;
        padding: 12px 9px 12px 12px;
        gap: 9px;

        &-type {
            border-radius: var(--radius);
        }

        &-type ::v-deep(.flux-avatar-fallback) {
            color: rgb(var(--primary-7));
        }

        &-info {
            display: flex;
            flex-flow: column;

            strong {
                color: var(--foreground-prominent);
            }
        }
    }

    .organization-caption {
        display: flex;
        height: 100%;
        gap: 9px
    }

    .country-flag {
        height: 21px;
        margin-top: 3px;
    }

    .event-balance-amounts {
        display: flex;
        height: 100%;
        align-items: flex-start;
        flex-flow: column;
        gap: 3px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
</style>
