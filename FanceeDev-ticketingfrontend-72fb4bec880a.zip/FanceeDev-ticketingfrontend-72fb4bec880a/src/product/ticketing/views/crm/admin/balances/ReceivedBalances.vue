<template>
    <FluxPane is-contained>
        <FluxPaneHeader :title="t('crm.balance.received')"/>

        <FluxDataTable
            :is-loading="isLoading"
            :data-set="received"
            :page="1"
            :total="13"
            is-hoverable
            class="received-table">
            <template #header>
                <FluxTableHeader>{{ t('crm.balance.month') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.tickets') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.orders') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.productIncome') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.ticketFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.seatedTicketFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.productFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.paymentFee') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.tsp') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.sms') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.refunded') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('crm.balance.chargebacked') }}</FluxTableHeader>
            </template>

            <template #month="{row: {month}}">
                <FluxTableCell :class="$style.month">{{ month === 13 ? t('global.total') : formatMonthLocal(month, locale) }}</FluxTableCell>
            </template>

            <template #issuedTickets="{row: {issuedTickets}}">
                <FluxTooltip>
                    <template #content>
                        <FluxStack :gap="3">
                            <FluxStack axis="horizontal">
                                <p :class="$style.revenueOrigin">{{ t('finance.report.revenue.obtained.shop') }}</p>
                                <FluxSpacer/>
                                <p :class="$style.revenueOrigin">{{ issuedTickets.issuedPlatformShopProducts }}</p>
                            </FluxStack>

                            <FluxStack axis="horizontal">
                                <p :class="$style.revenueOrigin">{{ t('finance.report.revenue.obtained.app') }}</p>
                                <FluxSpacer/>
                                <p :class="$style.revenueOrigin">{{ issuedTickets.issuedPlatformAppProducts }}</p>
                            </FluxStack>

                            <FluxStack axis="horizontal">
                                <p :class="$style.revenueOrigin">{{ t('finance.report.revenue.obtained.imported') }}</p>
                                <FluxSpacer/>
                                <p :class="$style.revenueOrigin">{{ issuedTickets.issuedPlatformImportedProducts }}</p>
                            </FluxStack>

                            <FluxStack axis="horizontal">
                                <p :class="$style.revenueOrigin">{{ t('finance.report.revenue.obtained.guestlist') }}</p>
                                <FluxSpacer/>
                                <p :class="$style.revenueOrigin">{{ issuedTickets.issuedPlatformGuestlistProducts }}</p>
                            </FluxStack>

                            <FluxStack axis="horizontal">
                                <p :class="$style.revenueOrigin">{{ t('finance.report.revenue.obtained.generated') }}</p>
                                <FluxSpacer/>
                                <p :class="$style.revenueOrigin">{{ issuedTickets.issuedPlatformGeneratedProducts }}</p>
                            </FluxStack>

                            <FluxStack axis="horizontal">
                                <p :class="$style.revenueOrigin">{{ t('finance.report.revenue.obtained.ticketswap') }}</p>
                                <FluxSpacer/>
                                <p :class="$style.revenueOrigin">{{ issuedTickets.issuedTicketSwapProducts }}</p>
                            </FluxStack>
                        </FluxStack>
                    </template>

                    <FluxTableCell>{{ asFormattedNumber(issuedTickets.total()) }}</FluxTableCell>
                </FluxTooltip>
            </template>

            <template #fulfilledOrders="{row: {fulfilledOrders}}">
                <FluxTableCell>{{ asFormattedNumber(fulfilledOrders) }}</FluxTableCell>
            </template>

            <template #productIncomeCents="{row: {productIncomeCents}}">
                <FluxTableCell>{{ asMoney(productIncomeCents, currency) }}</FluxTableCell>
            </template>

            <template #ticketFeeCents="{row: {ticketFeeCents}}">
                <FluxTableCell>{{ asMoney(ticketFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #seatedTicketFeeCents="{row: {seatedTicketFeeCents}}">
                <FluxTableCell>{{ asMoney(seatedTicketFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #productFeeCents="{row: {productFeeCents}}">
                <FluxTableCell>{{ asMoney(productFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #paymentFeeCents="{row: {paymentFeeCents}}">
                <FluxTableCell>{{ asMoney(paymentFeeCents, currency) }}</FluxTableCell>
            </template>

            <template #ticketServicePlusCents="{row: {ticketServicePlusCents}}">
                <FluxTableCell>{{ asMoney(ticketServicePlusCents, currency) }}</FluxTableCell>
            </template>

            <template #smsCents="{row: {smsCents}}">
                <FluxTableCell>{{ asMoney(smsCents, currency) }}</FluxTableCell>
            </template>

            <template #refunded="{row: {refundedCents}}">
                <FluxTableCell>{{ asMoney(refundedCents, currency) }}</FluxTableCell>
            </template>

            <template #chargeBacked="{row: {chargedBackCents}}">
                <FluxTableCell>{{ asMoney(chargedBackCents, currency) }}</FluxTableCell>
            </template>
        </FluxDataTable>
    </FluxPane>
</template>


<script
    setup
    lang="ts">
    import { Currency, ReceivedBalance } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { asFormattedNumber, asMoney, formatMonthLocal } from '@/util';

    export interface Props {
        readonly isLoading: boolean;
        readonly received: ReceivedBalance[];
        readonly currency: Currency;
    }

    defineProps<Props>();

    const {locale, t} = useI18n();
</script>

<style lang="scss">
    .received-table tbody tr:last-child {
        font-weight: bold;
        background-color: rgb(var(--gray-2));
    }
</style>

<style
    lang="scss"
    module>
    .month {
        text-transform: capitalize;
    }

    .revenueOrigin {
        font-size: 0.9rem;
        opacity: 0.75;
    }
</style>

