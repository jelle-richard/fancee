<template>
    <FluxGrid>
        <FluxGridColumn :md="3">
            <Exact/>
        </FluxGridColumn>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import Exact from '@/product/ticketing/views/crm/admin/integrations/Exact.vue';
</script>
