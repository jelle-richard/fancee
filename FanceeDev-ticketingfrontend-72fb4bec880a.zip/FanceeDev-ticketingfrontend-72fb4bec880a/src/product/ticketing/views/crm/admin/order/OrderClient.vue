<template>
    <FluxGrid :columns="2">
        <FluxFormField
            v-if="(selectedOrder.client.firstName !== null && selectedOrder.client.firstName.length > 0) || (selectedOrder.client.lastName !== null && selectedOrder.client.lastName.length > 0)"
            :label="t('form.field.name')">
            {{ selectedOrder.client.firstName }} {{ selectedOrder.client.lastName }}
        </FluxFormField>

        <FluxFormField :label="t('form.field.email')">
            <a :href="`mailto:${selectedOrder.client.email}`">{{ selectedOrder.client.email }}</a>
        </FluxFormField>

        <FluxFormField
            v-if="selectedOrder.client.phoneNumber !== null && selectedOrder.client.phoneNumber.length > 0"
            :label="t('form.field.phoneNumber')">
            <a :href="`tel:${selectedOrder.client.phoneNumber}`">{{ selectedOrder.client.phoneNumber }}</a>
        </FluxFormField>

        <FluxFormField
            v-if="selectedOrder.client.gender !== null"
            :label="t('form.field.gender')">
            {{ t(`global.gender.${selectedOrder.client.gender.toLowerCase()}`) }}
        </FluxFormField>

        <FluxFormField
            v-if="selectedOrder.client.birthdate !== null"
            :label="t('form.field.birthdate')">
            {{ formatDateLocal(selectedOrder.client.birthdate) }}
        </FluxFormField>

        <FluxFormField
            v-if="selectedOrder.client.address && !selectedOrder.client.address.isEmpty"
            :label="t('form.field.address')">
            <a
                :href="getGoogleMapsSearchUrl(selectedOrder.client.address)"
                target="_blank">
                <div v-if="selectedOrder.client.address.street !== null">
                    <span>{{ selectedOrder.client.address.street }}&nbsp;</span>
                    <span v-if="selectedOrder.client.address.houseNumber !== null">{{ selectedOrder.client.address.houseNumber }}</span>
                </div>

                <span v-if="selectedOrder.client.address.postalCode !== null">{{ selectedOrder.client.address.postalCode }}&nbsp;</span>

                <div v-if="selectedOrder.client.address.city !== null">
                    <span>{{ selectedOrder.client.address.city }}&nbsp;</span>
                    <span v-if="selectedOrder.client.address.countryCode !== null">({{ selectedOrder.client.address.countryCode }})</span>
                </div>
            </a>
        </FluxFormField>

        <FluxFormField :label="t('finance.order.single.client.optins.title')">
            <FluxBadgeStack v-if="selectedOrder.client.optInPromotionalEmail || selectedOrder.client.optInPromotionalSms">
                <FluxBadge
                    v-if="selectedOrder.client.optInPromotionalEmail"
                    :label="t('finance.order.single.client.optins.email')"/>

                <FluxBadge
                    v-if="selectedOrder.client.optInPromotionalSms"
                    :label="t('finance.order.single.client.optins.sms')"/>
            </FluxBadgeStack>

            <span v-else>
                &mdash;
            </span>
        </FluxFormField>
    </FluxGrid>
</template>

<script
    lang="ts"
    setup>
    import { Order } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { formatDateLocal, getGoogleMapsSearchUrl } from '@/util';

    export interface Props {
        readonly selectedOrder: Order;
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>
