export { default as EventDataTable } from './EventDataTable.vue';
