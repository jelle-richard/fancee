<template>
    <ShareOverlay #default="{share}">
        <FluxDataTable
            :data-set="items"
            :is-loading="isLoading"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems"
            is-hoverable>
            <template #header>
                <FluxTableHeader data-testid="my-events-header-event">
                    {{ t('event.list.table.event') }}
                </FluxTableHeader>

                <FluxTableHeader
                    is-shrinking
                    data-testid="my-events-header-organization">
                    {{ t('event.list.table.organization') }}
                </FluxTableHeader>

                <FluxTableHeader
                    class="table-cell-shops"
                    data-testid="my-events-header-shops">
                    {{ t('event.list.table.shops') }}
                </FluxTableHeader>

                <FluxTableHeader
                    is-shrinking
                    data-testid="my-events-header-status">
                    {{ t('event.list.table.status') }}
                </FluxTableHeader>

                <FluxTableHeader
                    v-if="!isReadonly"
                    is-shrinking/>
            </template>

            <template #event="{row: {date, name, type}}">
                <FluxTableCell v-slot:content>
                    <div class="event-caption">
                        <FluxAvatar
                            class="event-caption-type"
                            fallback="neutral"
                            :fallback-icon="type === EventType.Seating ? 'loveseat' : (type === EventType.Timeslotted ? 'clock' : 'ticket')"
                            :size="42"/>

                        <div class="event-caption-info">
                            <strong>{{ name }}</strong>
                            <small>{{ formatDateTimeLocal(date) }}</small>
                        </div>
                    </div>
                </FluxTableCell>
            </template>

            <template #organization="{row: {organization}}">
                <FluxTableCell>
                    <FluxPersona
                        class="event-organization"
                        :avatar-fallback-initials="fullNameToInitials(organization.name)"
                        :name="organization.name"/>
                </FluxTableCell>
            </template>

            <template #shops="{row: {shopLinkListItems, id}, index}">
                <FluxTableCell
                    class="table-cell-shops"
                    #content>
                    <div class="event-shops">
                        <template v-for="(shop, i) of shopLinkListItems">
                            <div class="shop-link">
                                <a
                                    v-if="shop.active"
                                    :href="getShopUrl(shop.code)"
                                    :data-testid="`my-events-shop-${index}-url-${i}`"
                                    rel="noopener"
                                    target="_blank">
                                    {{ shop.name }}
                                </a>

                                <FluxTooltip
                                    v-else
                                    :content="t('event.list.table.deactivated')">
                                    <span>
                                        {{ shop.name }}
                                    </span>
                                </FluxTooltip>

                                <FluxTableActions>
                                    <FluxFlyout>
                                        <template #opener="{open}">
                                            <fluxAction
                                                class="flyout-action"
                                                icon="gear"
                                                @click="open"/>
                                        </template>

                                        <template #default="{close}">
                                            <FluxMenu>
                                                <FluxMenuGroup>
                                                    <FluxMenuItem
                                                        icon-before="share-from-square"
                                                        :label="t('global.share')"
                                                        @click="share(getShopUrl(shop.code))"
                                                        @mouseup="close"/>

                                                    <FluxMenuItem
                                                        icon-before="lock"
                                                        :label="t('event.secureCode.plural')"
                                                        type="route"
                                                        :to="{
                                                            name: 'securecodes',
                                                            params: {eventId: id, shopCode: shop.code}
                                                        }"/>
                                                </FluxMenuGroup>
                                            </FluxMenu>
                                        </template>
                                    </FluxFlyout>
                                </FluxTableActions>
                            </div>
                        </template>
                    </div>
                </FluxTableCell>
            </template>

            <template #status="{row: {status}}">
                <FluxTableCell>
                    <FluxBadge
                        class="event-status"
                        dot
                        :color="EVENT_STATUSES[status.toLowerCase()]"
                        :label="t(`event.status.${status.toLowerCase()}`)"/>
                </FluxTableCell>
            </template>

            <template
                v-if="!isReadonly"
                #actions="{row: {deletable, id, name, type}, index}">
                <FluxTableCell>
                    <ClaimCheck claim="organization.event.configure">
                        <FluxTableActions class="event-actions">
                            <ClaimCheck claim="organization.event.details">
                                <FluxTooltip :content="t('global.edit')">
                                    <FluxAction
                                        icon="pen"
                                        :data-testid="`my-events-edit-${index}`"
                                        @click="onEditEventClicked(id)"/>
                                </FluxTooltip>
                            </ClaimCheck>

                            <FluxTooltip :content="t('global.copy')">
                                <FluxAction
                                    :disabled="type === EventType.Seating"
                                    icon="clone"
                                    :data-testid="`my-events-clone-${index}`"
                                    @click="onCopyEventClicked(id)"/>
                            </FluxTooltip>

                            <FluxTooltip :content="t('global.delete')">
                                <FluxAction
                                    destructive
                                    :disabled="!deletable"
                                    icon="trash"
                                    :data-testid="`my-events-delete-${index}`"
                                    @click="onDeleteEventClicked(id, name)"/>
                            </FluxTooltip>
                        </FluxTableActions>
                    </ClaimCheck>
                </FluxTableCell>
            </template>
        </FluxDataTable>
    </ShareOverlay>
</template>

<script
    setup
    lang="ts">
    import { EventListing, EventType } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { ClaimCheck, ShareOverlay } from '@/components/ui';
    import { EVENT_STATUSES } from '@/data';
    import { getShopUrl } from '@/product/ticketing/util';
    import { formatDateTimeLocal, fullNameToInitials } from '@/util';

    export interface Emits {
        (e: 'copy', eventId: string): void;

        (e: 'delete', eventId: string, name: string): void;

        (e: 'edit', eventId: string): void;
    }

    export interface Props {
        readonly currentPage: number;
        readonly isLoading: boolean;
        readonly isReadonly?: boolean;
        readonly items: EventListing[];
        readonly pageLength: number;
        readonly totalItems: number;
    }

    const emit = defineEmits<Emits>();
    defineProps<Props>();

    const {t} = useI18n();

    function onCopyEventClicked(eventId: string): void {
        emit('copy', eventId);
    }

    function onDeleteEventClicked(eventId: string, name: string): void {
        emit('delete', eventId, name);
    }

    function onEditEventClicked(eventId: string): void {
        emit('edit', eventId);
    }
</script>

<style
    lang="scss"
    scoped>
    .event-caption {
        display: flex;
        height: 100%;
        padding: 12px 15px 12px 21px;
        gap: 15px;

        &-type {
            border-radius: var(--radius);
        }

        &-type ::v-deep(.flux-avatar-fallback) {
            color: rgb(var(--primary-7));
        }

        &-info {
            display: flex;
            flex-flow: column;

            strong {
                color: var(--foreground-prominent);
            }
        }
    }

    .event-organization {
        margin: 0 -6px -6px;
        pointer-events: none;
    }

    .event-shops {
        display: flex;
        height: 100%;
        padding: 12px 15px;
        align-items: flex-start;
        flex-flow: column;
        justify-content: center;
        gap: 3px;
        font-size: 80%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .shop-link {
        display: flex;
        height: 20px;
        max-width: 100%;
        align-items: center;
        gap: 9px;

        a,
        span {
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }

    .event-actions {
        margin-top: 6px;
    }

    .event-status {
        margin-top: 8px;
    }

    .table-cell-shops {
        max-width: 300px;
    }

    .flyout-action {
        height: 21px;
        width: 21px;
        font-size: 15px;
    }
</style>
