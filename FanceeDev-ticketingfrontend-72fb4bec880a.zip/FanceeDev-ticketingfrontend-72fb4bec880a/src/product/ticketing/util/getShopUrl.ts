export default function (shopCode: string, campaignCode?: string): string {
    const campaignSegment = campaignCode ? `?campaignCode=${campaignCode}` : '';

    return `${import.meta.env.VITE_BASE_URL}/shop/${shopCode}${campaignSegment}`;
}
