import type { EventProduct } from '@fancee/data';

export default function (product: EventProduct, reference: EventProduct, products: EventProduct[]): boolean {
    if (!product.waveLinkedProductId) {
        return false;
    }

    if (product.waveLinkedProductId === reference.id) {
        return true;
    }

    let wavelinked: EventProduct | undefined;

    while (wavelinked = products.find(p => p.id === product.waveLinkedProductId)) {
        if (wavelinked.waveLinkedProductId === reference.id) {
            return true;
        }

        product = wavelinked;
    }

    return false;
}
