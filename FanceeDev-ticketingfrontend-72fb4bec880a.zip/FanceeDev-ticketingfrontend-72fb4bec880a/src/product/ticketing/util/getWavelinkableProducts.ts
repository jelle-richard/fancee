import type { EventProduct } from '@fancee/data';
import hasWavelinkReferenceWith from './hasWavelinkReferenceWith';

export default function (product: EventProduct, products: EventProduct[]): EventProduct[] {
    return products
        .filter(p => p.id !== product.id)
        .filter(p => !hasWavelinkReferenceWith(p, product, products));
}
