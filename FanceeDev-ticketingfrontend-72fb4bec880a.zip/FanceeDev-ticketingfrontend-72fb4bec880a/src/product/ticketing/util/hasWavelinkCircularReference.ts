import type { EventProduct } from '@fancee/data';

export default function (product: EventProduct, products: EventProduct[]): boolean {
    if (!product.waveLinkedProductId) {
        return false;
    }

    const productId = product.id;
    let wavelinked: EventProduct | undefined;

    while (wavelinked = products.find(p => p.id === product.waveLinkedProductId)) {
        if (wavelinked.waveLinkedProductId === productId) {
            return true;
        }

        product = wavelinked;
    }

    return false;
}
