import '@fancee/flux/style.css';
import '@/assets/css/flux.scss';
import '@/assets/css/apexcharts.scss';

import { createApp } from 'vue';
import { flux } from '@/components/flux';
import { globalErrorHandler } from '@/data';
import { i18n } from '@/data/i18n';
import { default as router } from '@/data/router/router';
import { store } from '@/data/store';
import App from './App.vue';

const app = createApp(App)
    .use(flux)
    .use(i18n)
    .use(router)
    .use(store);

app.config.errorHandler = globalErrorHandler;

app.mount('#app');
