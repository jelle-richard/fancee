<template>
    <FluxRoot>
        <RouterView/>
    </FluxRoot>
</template>

<script
    lang="ts"
    setup>
    import { computed, unref, watchEffect } from 'vue';
    import { useRequestErrorBoundaryProvider, useRollbar, useRouteName } from '@/composable';
    import { languages, switchLanguage } from '@/data/i18n';
    import { useStore, useUiStore } from '@/data/store';

    useRequestErrorBoundaryProvider();
    useRollbar();

    const {language, skin} = useStore(useUiStore());
    const routeName = useRouteName();

    const currentLanguage = computed(() => languages.find(l => l.code === (unref(language) ?? navigator.language)) ?? languages[0]);

    watchEffect(() => switchLanguage(unref(currentLanguage).code));

    watchEffect(() => {
        if (!unref(routeName).startsWith('auth') && unref(skin) === 'dark') {
            document.documentElement.setAttribute('dark', 'dark');
        } else {
            document.documentElement.removeAttribute('dark');
        }
    });
</script>
