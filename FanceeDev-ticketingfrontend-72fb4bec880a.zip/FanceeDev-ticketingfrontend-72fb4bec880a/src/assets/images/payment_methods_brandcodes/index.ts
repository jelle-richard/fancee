const images = import.meta.glob('./*.svg', {eager: true});

export default Object.fromEntries(
    Object.entries(images).map(([key, module]: [string, any]) => [
        key.substring(2, key.length - 4),
        module.default
    ])
);
