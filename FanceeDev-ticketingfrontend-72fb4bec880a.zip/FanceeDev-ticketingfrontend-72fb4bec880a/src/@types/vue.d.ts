import { Ref } from 'vue';

declare module 'vue' {
    declare type UnwrapRefSimple<T> = T;

    declare function ref<T extends object>(value: T): [T] extends [Ref] ? T : Ref<T>;

    declare function ref<T>(value: T): Ref<T>;
}
