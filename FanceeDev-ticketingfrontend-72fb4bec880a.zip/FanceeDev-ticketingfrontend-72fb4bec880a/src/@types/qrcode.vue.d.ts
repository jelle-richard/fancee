declare module 'qrcode.vue';
