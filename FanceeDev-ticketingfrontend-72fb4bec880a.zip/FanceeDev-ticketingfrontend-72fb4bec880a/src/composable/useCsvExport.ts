import { downloadString } from '@/util';

export default function ({delimiter, filename, onInvalid}: UseCsvExportOptions): UseCsvExport {
    function parseHeader(item: object): string {
        return Object.keys(item)
            .join(delimiter)
            .concat('\r\n');
    }

    function parseItem(item: object): string {
        return Object.values(item)
            .join(delimiter)
            .concat('\r\n');
    }

    return (items: object[]) => {
        if (items.length === 0) {
            onInvalid();
            return;
        }

        let csv = '';
        csv += parseHeader(items[0]);
        csv += items.map(parseItem).join('');

        downloadString(csv, filename, 'text/csv');
    };
}

interface UseCsvExport {
    (items: object[]): void;
}

interface UseCsvExportOptions {
    readonly delimiter: string;
    readonly filename: string;
    readonly onInvalid: () => void;
}
