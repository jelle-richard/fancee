import { HttpStatusCode, IResponseErrors, isRequestError, RequestError } from '@fancee/client';
import { computed, inject, InjectionKey, onErrorCaptured, provide, Ref, shallowRef, unref, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import { FanceeForbiddenError, FanceeUnauthorizedError, globalErrorHandler } from '@/data/error';
import useRoute from './useRoute';

const SYMBOL: InjectionKey<UseRequestErrorBoundary> = Symbol();

export default function (): UseRequestErrorBoundary {
    const injection = inject(SYMBOL, null);

    if (!injection) {
        throw new Error('No request boundary provider was found.');
    }

    return injection;
}

export function useRequestErrorBoundaryProvider(): void {
    const {t} = useI18n();
    const route = useRoute();

    const errors = shallowRef<IResponseErrors | null>(null);

    const hasErrors = computed(() => !!unref(errors) && Object.values(unref(errors)!).length > 0);

    onErrorCaptured((err: Error | RequestError): boolean => {
        if (!isRequestError(err)) {
            // note: This will let Vue continue to its own error handler.
            return true;
        }

        if (err.statusCode === HttpStatusCode.NotFound && Object.entries(err.errors).length === 0) {
            err = new RequestError(err.message, {
                'FAN-404': [
                    t('ui.notFound.record')
                ]
            }, err.statusCode);
        }

        errors.value = err.errors;

        return false;
    });

    function reset(): void {
        errors.value = null;
    }

    async function runSandboxed<T = unknown>(fn: () => Promise<T>, onError?: (err: Error | RequestError) => void): Promise<void> {
        try {
            await fn();
        } catch (err) {
            if (err instanceof FanceeForbiddenError || err instanceof FanceeUnauthorizedError) {
                globalErrorHandler(err);
                return;
            }

            if (err instanceof Error || isRequestError(err)) {
                onError?.(err);
                return;
            }

            throw new Error('Something was thrown, but it wasn\'t an instance of Error...?');
        }
    }

    provide(SYMBOL, {
        errors,
        hasErrors,
        reset,
        runSandboxed
    });

    watch(route, () => reset());
}

interface UseRequestErrorBoundary {
    readonly errors: Readonly<Ref<IResponseErrors | null>>;
    readonly hasErrors: Readonly<Ref<boolean>>;

    reset(): void;

    runSandboxed<T = unknown>(fn: () => Promise<T>, onError?: (err: Error | RequestError) => void): Promise<void>;
}
