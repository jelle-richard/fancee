import { computed, ComputedRef, unref } from 'vue';
import useUser from './useUser';

export default function (): ComputedRef<string> {
    const user = useUser();
    return computed(() => unref(user)?.activeOrganizationId as string);
}
