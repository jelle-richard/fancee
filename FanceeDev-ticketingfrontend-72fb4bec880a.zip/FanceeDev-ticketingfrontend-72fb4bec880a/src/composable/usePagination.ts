import { ref, Ref } from 'vue';
import { DEFAULT_PAGE_LENGTH, DEFAULT_STARTING_PAGE } from '@/data/constant';

export default function (initialPageLength?: number): UsePagination {
    const currentPage = ref(DEFAULT_STARTING_PAGE);
    const pageLength = ref(initialPageLength ?? DEFAULT_PAGE_LENGTH);
    const totalItems = ref(0);

    function setCurrentPage(page: number): void {
        currentPage.value = page;
    }

    function setPageLength(length: number): void {
        pageLength.value = length;

        setCurrentPage(DEFAULT_STARTING_PAGE);
    }

    function setTotalItems(total: number): void {
        totalItems.value = total;
    }

    return {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    };
}

interface UsePagination {
    readonly currentPage: Ref<number>;
    readonly pageLength: Ref<number>;
    readonly totalItems: Ref<number>;

    setCurrentPage(page: number): void;

    setPageLength(length: number): void;

    setTotalItems(total: number): void;
}
