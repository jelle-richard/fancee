import { BaseResponse, isRequestError, RequestError } from '@fancee/client';
import { generateUuidV4, Media } from '@fancee/data';
import { ref, Ref } from 'vue';
import { useI18n } from 'vue-i18n';

export default function ({remove: removeFile, upload: uploadFile, onRemove, onRemoveError, onUpload, onUploadError}: UseMultiFileUploadParams): UseMultiFileUpload {
    const {t} = useI18n();

    const currentFile = ref<File | null>(null);
    const errors = ref<string[]>([]);
    const isRemoving = ref(false);
    const isUploading = ref(false);
    const pendingMedia: Ref<Media[]> = ref([]);

    const remove = async (fileId: string): Promise<void> => {
        if (!removeFile) {
            return;
        }

        isRemoving.value = true;

        try {
            await removeFile(fileId);
            onRemove?.(fileId);
        } catch (err) {
            if (!isRequestError(err)) {
                throw err;
            }

            onRemoveError?.(fileId, err);
        }

        isRemoving.value = false;
    };

    const upload = async (files: File[]): Promise<Media[]> => {
        errors.value = [];
        isUploading.value = true;

        const medias: Media[] = [];
        const queue: [File, Media][] = [];

        for (const file of files) {
            const url = URL.createObjectURL(file);
            const media = new Media(generateUuidV4(), url, file.name, file.type);

            pendingMedia.value.push(media);
            queue.push([file, media]);
        }

        for (const [file, media] of queue) {
            currentFile.value = file;

            try {
                const {data: mediaId} = await uploadFile(file);
                media.id = mediaId;
                medias.push(media);
                onUpload?.(media);
            } catch (err) {
                if (!isRequestError(err)) {
                    throw err;
                }

                let message: string | null = null;

                switch (err.statusCode) {
                    case 413:
                        message = t('upload_failed_too_large', {fileName: file.name});
                        break;

                    default:
                        message = t('upload_failed_generic', {fileName: file.name});
                        break;
                }

                if (message) {
                    errors.value.push(message);
                }

                onUploadError?.(file, err, message);
            } finally {
                pendingMedia.value = pendingMedia.value.filter(m => m.id !== media.id);
            }
        }

        currentFile.value = null;
        isUploading.value = false;

        return medias;
    };

    return {
        currentFile,
        errors,
        isRemoving,
        isUploading,
        pendingMedia,
        remove,
        upload
    };
}

interface UseMultiFileUpload {
    readonly currentFile: Ref<File | null>;
    readonly errors: Ref<string[]>;
    readonly isRemoving: Ref<boolean>;
    readonly isUploading: Ref<boolean>;
    readonly pendingMedia: Ref<Media[]>;

    remove(fileId: string): Promise<void>;

    upload(files: File[]): Promise<Media[]>;
}

interface UseMultiFileUploadParams {
    onRemove?(fileId: string): void;

    onRemoveError?(fileId: string, err: RequestError): void;

    onUpload?(media: Media): void;

    onUploadError?(file: File, error: RequestError, message: string | null): void;

    remove?(fileId: string): Promise<BaseResponse<never>>;

    upload(file: File): Promise<BaseResponse<string>>;
}
