import { computed, Ref, unref } from 'vue';
import { Claim } from '@/data';
import { storeToRefs, useAuthStore } from '@/data/store';

export default function (claim: Claim): Ref<boolean> {
    const authStore = useAuthStore();
    const {claims} = storeToRefs(authStore);

    return computed(() => unref(claims).includes(claim));
}
