import { computed, Ref } from 'vue';
import { isRouteMeta, RouteMeta } from '@/data/router';
import useRoute from './useRoute';
import merge from 'lodash/merge';

export default function (): Ref<RouteMeta | null> {
    const route = useRoute();

    return computed(() => {
        let meta: RouteMeta = {};

        for (let i = route.matched.length - 1; i >= 0; --i) {
            const record = route.matched[i];

            if (!isRouteMeta(record.meta)) {
                continue;
            }

            let matchMeta = {...record.meta};

            if ('navigation' in meta) {
                const {navigation: _, ...matchMetaWithoutNavigation} = matchMeta;
                matchMeta = matchMetaWithoutNavigation;
            }

            meta = merge(meta, matchMeta);
        }

        return meta;
    });
}
