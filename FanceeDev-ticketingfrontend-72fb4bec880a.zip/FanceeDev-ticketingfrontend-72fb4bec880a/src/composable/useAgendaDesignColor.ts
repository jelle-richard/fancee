import { AgendaDesign } from '@fancee/data';
import { computed, Ref, unref } from 'vue';
import { hexToHSL } from '@/util';

type Adjustments = {
    saturation?: number;
    lightness?: number;
};

type ColorKey = 'backdropColor'
    | 'backgroundColor'
    | 'primaryColor'
    | 'textColor';

export default function useAgendaDesignColor(agendaDesignRef: Ref<AgendaDesign>, key: ColorKey, adjustments?: Adjustments, opacity?: number): Ref<string | null> {
    return computed(() => {
        const design = unref(agendaDesignRef);

        if (!design) {
            return null;
        }

        const color = design[key] ?? null;
        if (!color || !adjustments) {
            return color;
        }

        let [hue, saturation, lightness] = hexToHSL(color);

        if (adjustments.saturation) {
            saturation += saturation > 50 ? -adjustments.saturation : adjustments.saturation;
        }

        if (adjustments.lightness) {
            lightness += lightness > 25 ? -adjustments.lightness : adjustments.lightness;
        }

        if (opacity) {
            return `hsl(${hue}deg ${saturation}% ${lightness}% / ${opacity})`;
        }

        return `hsl(${hue}deg ${saturation}% ${lightness}%)`;
    });
}
