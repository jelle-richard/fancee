import { Router, useRouter as _useRouter } from 'vue-router';

export default function (): Router {
    return _useRouter();
}
