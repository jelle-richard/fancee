import { isDtoDirty } from '@fancee/client';
import { useFluxStore } from '@fancee/flux';
import { computed, Ref, unref } from 'vue';
import { useI18n } from 'vue-i18n';
import { onBeforeRouteLeave } from 'vue-router';

export default function (...dtos: Ref<object>[]): UseUnsavedChangesCheck {
    const {addConfirm, removeConfirm} = useFluxStore();
    const {t} = useI18n();

    const hasUnsavedChanges = computed(() => dtos
        .map(unref)
        .flat()
        .some(isDtoDirty));

    onBeforeRouteLeave((_, __, next): void => {
        if (!unref(hasUnsavedChanges)) {
            next();
            return;
        }

        const id = addConfirm({
            icon: 'circle-exclamation',
            message: t('ui.unsavedChanges.message'),
            title: t('ui.unsavedChanges.title'),
            onCancel(): void {
                removeConfirm(id);

                try {
                    next(false);
                } catch {
                    // note: We don't handle the exception that is thrown here, because that exception
                    //  says that the navigation has been aborted, which is exactly what we want.
                }
            },
            onConfirm(): void {
                removeConfirm(id);
                next();
            }
        });
    });

    return {
        hasUnsavedChanges
    };
}

interface UseUnsavedChangesCheck {
    readonly hasUnsavedChanges: Ref<boolean>;
}
