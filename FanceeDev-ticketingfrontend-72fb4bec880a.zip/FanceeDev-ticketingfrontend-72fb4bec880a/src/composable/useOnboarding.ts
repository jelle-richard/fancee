import { OrganizationOnboardingService, OrganizationService } from '@fancee/api';
import type { RequestError } from '@fancee/client';
import type { Address, LegalEntity, OrganizationProfile, OrganizationContact } from '@fancee/data';
import { ComputedRef, inject, InjectionKey, provide, Ref, ref, unref, watch } from 'vue';
import useActiveOrganizationId from './useActiveOrganizationId';
import useLoaded from './useLoaded';
import useRequestErrorBoundary from './useRequestErrorBoundary';
import useService from './useService';

const SYMBOL: InjectionKey<UseOnboarding> = Symbol();

export default function () {
    const injected = inject(SYMBOL, null);

    if (injected) {
        return injected;
    }

    const {isLoading, loaded} = useLoaded();
    const {reset, runSandboxed} = useRequestErrorBoundary();
    const {getProfile} = useService(OrganizationService);
    const {updateCompany, updateFinance, updateHolder} = useService(OrganizationOnboardingService);
    const organizationId = useActiveOrganizationId();

    const profile = ref<OrganizationProfile>();

    async function sandboxed(fn: () => Promise<void>, onError?: (err: Error | RequestError) => void): Promise<void> {
        await runSandboxed(
            loaded(fn),
            onError
        );
    }

    async function submit(fn: () => Promise<void>): Promise<void> {
        reset();

        await loaded(fn)();
        await updateProfile();
    }

    async function submitCompany(address: Address, legalEntity: LegalEntity): Promise<void> {
        await submit(async () => {
            await updateCompany(unref(organizationId), address, legalEntity);
        });
    }

    async function submitFinance(currencyShortCode: string, iban: string | null, bankAccountNumber: string | null, bic: string | null, vatCode: string | null, approximatedAnnualSalesAmount: number): Promise<void> {
        await submit(async () => {
            await updateFinance(unref(organizationId), currencyShortCode, iban, bankAccountNumber, bic, vatCode, approximatedAnnualSalesAmount);
        });
    }

    async function submitHolder(firstName: string, lastName: string, supportContact: OrganizationContact | null): Promise<void> {
        await submit(async () => {
            await updateHolder(unref(organizationId), firstName, lastName, supportContact);
        });
    }

    async function updateProfile(): Promise<void> {
        await loaded(async () => {
            const {data} = await getProfile(unref(organizationId));
            profile.value = data;
        })();
    }

    watch(organizationId, updateProfile, {immediate: true});

    provide(SYMBOL, {
        isLoading,
        organizationId,
        profile,
        loaded,
        sandboxed,
        submit,
        submitCompany,
        submitFinance,
        submitHolder
    });

    return {
        isLoading,
        organizationId,
        profile,
        loaded,
        sandboxed,
        submit,
        submitCompany,
        submitFinance,
        submitHolder
    };
}

type UseOnboarding = {
    readonly isLoading: ComputedRef<boolean>;
    readonly organizationId: ComputedRef<string>;
    readonly profile: Ref<OrganizationProfile | undefined>;

    loaded<T>(fn: () => Promise<T>): () => Promise<T>;
    sandboxed(fn: () => Promise<void>, onError: (err: Error | RequestError) => void): Promise<void>;
    submit(fn: () => Promise<void>): Promise<void>;
    submitCompany(address: Address, legalEntity: LegalEntity): Promise<void>;
    submitFinance(currencyShortCode: string, iban: string | null, bankAccountNumber: string | null, bic: string | null, vatCode: string | null, approximatedAnnualSalesAmount: number): Promise<void>;
    submitHolder(firstName: string, lastName: string, supportContact: OrganizationContact | null): Promise<void>;
}
