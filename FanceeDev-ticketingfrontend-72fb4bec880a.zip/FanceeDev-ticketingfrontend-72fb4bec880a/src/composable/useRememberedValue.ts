import { ref, Ref, watch } from 'vue';
import { getStorageValue, hasStorageValue, setStorageValue } from '@/data/browserStorage';
import { DateTime } from 'luxon';

export default function <T>(key: string, initialValue: T): Ref<T> {
    const realKey = `WAF[${key}]`;
    const value = ref<T>(get() ?? initialValue);

    function get(): T | null {
        if (hasStorageValue(realKey)) {
            let storageValue = JSON.parse(getStorageValue(realKey) ?? 'null');

            if (Array.isArray(storageValue) && storageValue[0] === 'DateTime') {
                storageValue = DateTime.fromISO(storageValue[1]);
            }

            return storageValue;
        }

        return null;
    }

    watch(value, value => {
        let _value = value;

        if (DateTime.isDateTime(value)) {
            _value = ['DateTime', value.toISO({
                includeOffset: true,
                extendedZone: true
            })] as unknown as T;
        }

        setStorageValue(realKey, JSON.stringify(_value));
    });

    return value;
}
