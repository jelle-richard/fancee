import { useVuelidate } from '@vuelidate/core';
import { computed, inject, provide, readonly, ref, unref } from 'vue';

const SYMBOL = Symbol();

export default function (isLive: boolean = true) {
    const injected = inject(SYMBOL, null);

    if (injected) {
        return injected;
    }

    const v$ = useVuelidate();

    const errors = computed(() => unref(v$).$errors);
    const invalid = computed(() => unref(v$).$errors.length > 0);
    const live = readonly(ref(isLive));

    function reset(): void {
        unref(v$).$reset();
    }

    async function validate(): Promise<boolean> {
        return await unref(v$).$validate();
    }

    async function validated(fn: () => void | Promise<void>): Promise<void> {
        if (!await validate()) {
            return;
        }

        await fn();
    }

    provide(SYMBOL, {
        errors,
        invalid,
        live,
        reset,
        validate,
        validated
    });

    return {
        errors,
        invalid,
        live,
        reset,
        validate,
        validated
    };
}
