import { BaseService } from '@fancee/client';
import { guarded } from '@/util';

type ServiceClass<T extends BaseService> = { new(): T; };

export default function <T extends BaseService>(serviceClass: ServiceClass<T>): T {
    const service = new serviceClass;
    const methods = Object.getOwnPropertyNames(serviceClass.prototype)
        .filter(m => m !== 'constructor');

    const functions = {};

    for (let method of methods) {
        functions[method] = guarded(service[method].bind(service));
    }

    return functions as T;
}
