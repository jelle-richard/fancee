import { isDto } from '@fancee/client';
import { dependencies } from '@/../package.json';
import { useAuthStore } from '@/data/store';
import Rollbar from 'rollbar';
import useUser from './useUser';

const rollbar = new Rollbar({
    accessToken: 'f14649d4ed0c4544b04253b6e18e2a6b',
    captureUncaught: true,
    captureUnhandledRejections: true,
    codeVersion: import.meta.env.VERSION,
    enabled: import.meta.env.VITE_ENVIRONMENT === 'production',
    environment: import.meta.env.VITE_ENVIRONMENT,
    payload: {
        client: {
            javascript: {
                code_version: import.meta.env.VERSION,
                guess_uncaught_frames: true,
                source_map_enabled: true
            }
        },
        '@fancee/api': dependencies['@fancee/api'],
        '@fancee/client': dependencies['@fancee/client'],
        '@fancee/data': dependencies['@fancee/data'],
        '@fancee/flux': dependencies['@fancee/flux']
    }
});

export default function (): Rollbar {
    const auth = useAuthStore();
    const user = useUser();

    if (rollbar.options.payload) {
        rollbar.options.payload.authToken = auth.token ?? null;
        rollbar.options.payload.user = isDto(user.value) ? user.value.toJSON() : null;
    }

    return rollbar;
}
