import { RouteLocationNormalizedLoaded, useRoute as _useRoute } from 'vue-router';
import type { RouteMeta } from '@/data/router';

type UseRoute = { meta: RouteMeta | null; } & Omit<RouteLocationNormalizedLoaded, 'meta'>;

export default function (): UseRoute {
    return _useRoute();
}
