import { AuthUser } from '@fancee/data';
import { Ref } from 'vue';
import { storeToRefs, useAuthStore } from '@/data/store';

export default function (): Ref<AuthUser | null> {
    const authStore = useAuthStore();
    const {user} = storeToRefs(authStore);

    return user;
}
