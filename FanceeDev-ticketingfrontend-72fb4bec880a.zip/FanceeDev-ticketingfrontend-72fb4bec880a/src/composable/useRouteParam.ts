import { Ref, ref, watch } from 'vue';
import useRoute from './useRoute';

export default function (name: string, defaultValue: string | null = null): Ref<string | null> {
    const route = useRoute();
    const param = ref(defaultValue);

    watch(() => route.params[name], (value) => {
        param.value = (value || null) as string | null;
    }, {immediate: true});

    return param;
}
