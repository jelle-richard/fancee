import { Ref, ref, watch } from 'vue';
import useRoute from './useRoute';

export default function (): Ref<string> {
    const route = useRoute();
    const name = ref('');

    watch(() => route.name, value => {
        name.value = value?.toString() ?? '';
    }, {immediate: true});

    return name;
}
