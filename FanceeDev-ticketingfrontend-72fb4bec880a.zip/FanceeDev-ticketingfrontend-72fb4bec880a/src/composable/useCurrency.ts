import { Currency } from '@fancee/data';
import { computed, Ref, unref } from 'vue';
import { storeToRefs, usePlatformStore } from '@/data/store';
import useUser from './useUser';

export default function (): Ref<Currency> {
    const platformStore = usePlatformStore();
    const user = useUser();
    const {standardCurrency} = storeToRefs(platformStore);

    return computed(() => unref(user)?.currency || unref(standardCurrency) || new Currency('Unknown', '?', 'EUR', 0));
}
