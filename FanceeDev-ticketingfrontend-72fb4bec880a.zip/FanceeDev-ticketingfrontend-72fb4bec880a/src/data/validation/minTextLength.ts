import type { ValidationRuleWithParams } from '@vuelidate/core';

const element = document.createElement('div');

export default function (min: number): ValidationRuleWithParams {
    return {
        $message: (): string => 'validations.minLength',
        $params: {min},
        $validator: (value: unknown) => {
            if (typeof value !== 'string') {
                return false;
            }

            element.innerHTML = value;

            return element.textContent!.length >= min;
        }
    };
}
