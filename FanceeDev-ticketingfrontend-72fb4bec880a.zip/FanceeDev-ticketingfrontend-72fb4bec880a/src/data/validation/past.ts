import type { ValidationRuleWithoutParams } from '@vuelidate/core';
import { DateTime } from 'luxon';
import { isDateTimeInPast } from '@/util';

export default {
    $message: (): string => 'validations.past',
    $validator: (value: unknown) => {
        if (!DateTime.isDateTime(value)) {
            return true;
        }

        return isDateTimeInPast(value);
    }
} satisfies ValidationRuleWithoutParams as ValidationRuleWithoutParams;
