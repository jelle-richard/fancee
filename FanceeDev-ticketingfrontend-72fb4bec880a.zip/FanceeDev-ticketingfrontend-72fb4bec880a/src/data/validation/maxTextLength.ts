import type { ValidationRuleWithParams } from '@vuelidate/core';

const element = document.createElement('div');

export default function (max: number): ValidationRuleWithParams {
    return {
        $message: (): string => 'validations.maxLength',
        $params: {max},
        $validator: (value: unknown) => {
            if (typeof value !== 'string') {
                return false;
            }

            element.innerHTML = value;

            return element.textContent!.length <= max;
        }
    };
}
