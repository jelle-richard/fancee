import type { ValidationRuleWithParams } from '@vuelidate/core';
import { DateTime } from 'luxon';
import { formatDateTimeLocal, isDateTimeAfter } from '@/util';

export default function (compareDate: DateTime | null): ValidationRuleWithParams {
    let formattedDateTime: string | null = null;

    if (compareDate !== null) {
        formattedDateTime = formatDateTimeLocal(compareDate);
    }

    return {
        $message: (): string => 'validations.afterDate',
        $params: {formattedDateTime},
        $validator: (value: unknown) => {
            if (!DateTime.isDateTime(value) || compareDate === null) {
                return true;
            }

            return isDateTimeAfter(value, compareDate);
        }
    };
}
