import type { ValidationRuleWithParams } from '@vuelidate/core';
import { DateTime } from 'luxon';
import { formatDateTimeLocal, isDateTimeAfter, isDateTimeBefore } from '@/util';

export default function (minDate: DateTime, maxDate: DateTime): ValidationRuleWithParams {
    const formattedMinDate: string = formatDateTimeLocal(minDate);
    const formattedMaxDate: string = formatDateTimeLocal(maxDate);

    return {
        $message: (): string => 'validations.betweenDates',
        $params: {formattedMinDate, formattedMaxDate},
        $validator: (value: unknown) => {
            if (!DateTime.isDateTime(value)) {
                return true;
            }

            return isDateTimeAfter(value, minDate) && isDateTimeBefore(value, maxDate);
        }
    };
}
