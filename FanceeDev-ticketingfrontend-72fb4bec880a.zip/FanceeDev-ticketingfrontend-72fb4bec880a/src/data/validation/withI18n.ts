import { createI18nMessage } from '@vuelidate/validators';
import { t } from '@/data/i18n';

export default createI18nMessage({
    messagePath: ({$validator}) => `validation.validator.${$validator}`,
    t
});
