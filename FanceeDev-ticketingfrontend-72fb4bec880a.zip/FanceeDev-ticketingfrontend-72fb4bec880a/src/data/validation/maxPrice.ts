import type { ValidationRuleWithParams } from '@vuelidate/core';

export default function (maxPriceCents: number, formattedMaxPrice: string): ValidationRuleWithParams {
    return {
        $message: (): string => 'validations.formattedMaxPrice',
        $params: {maxPriceCents, formattedMaxPrice},
        $validator: (value: unknown) => {
            if (typeof value !== 'number') {
                return false;
            }

            return value <= maxPriceCents;
        }
    };
}
