import { alpha as _alpha, alphaNum as _alphaNum, and as _and, between as _between, decimal as _decimal, email as _email, integer as _integer, ipAddress as _ipAddress, macAddress as _macAddress, maxLength as _maxLength, maxValue as _maxValue, minLength as _minLength, minValue as _minValue, not as _not, numeric as _numeric, or as _or, required as _required, requiredIf as _requiredIf, requiredUnless as _requiredUnless, sameAs as _sameAs, url as _url } from '@vuelidate/validators';

import withI18n from './withI18n';

import _future from './future';
import _past from './past';
import _betweenDates from './betweenDates';
import _afterDate from './afterDate';
import _beforeDate from './beforeDate';
import _phoneNumber from './phoneNumber';
import _maxPrice from './maxPrice';
import _maxTextLength from './maxTextLength';
import _minTextLength from './minTextLength';
import _requiredPrice from './requiredPrice';
import _secureCode from './secureCode';

export const required = withI18n(_required);
export const requiredIf = withI18n(_requiredIf, {withArguments: true});
export const requiredUnless = withI18n(_requiredUnless, {withArguments: true});
export const maxLength = withI18n(_maxLength, {withArguments: true});
export const minLength = withI18n(_minLength, {withArguments: true});
export const maxValue = withI18n(_maxValue, {withArguments: true});
export const minValue = withI18n(_minValue, {withArguments: true});
export const between = withI18n(_between, {withArguments: true});
export const alpha = withI18n(_alpha);
export const alphaNum = withI18n(_alphaNum);
export const decimal = withI18n(_decimal);
export const email = withI18n(_email);
export const integer = withI18n(_integer);
export const ipAddress = withI18n(_ipAddress);
export const numeric = withI18n(_numeric);
export const macAddress = withI18n(_macAddress, {withArguments: true});
export const sameAs = withI18n(_sameAs, {withArguments: true});
export const url = withI18n(_url);
export const and = withI18n(_and, {withArguments: true});
export const not = withI18n(_not, {withArguments: true});
export const or = withI18n(_or, {withArguments: true});

export const future = withI18n(_future);
export const past = withI18n(_past);
export const betweenDates = withI18n(_betweenDates, {withArguments: true});
export const afterDate = withI18n(_afterDate, {withArguments: true});
export const beforeDate = withI18n(_beforeDate, {withArguments: true});
export const phoneNumber = withI18n(_phoneNumber, {withArguments: true});
export const maxTextLength = withI18n(_maxTextLength, {withArguments: true});
export const minTextLength = withI18n(_minTextLength, {withArguments: true});
export const maxPrice = withI18n(_maxPrice, {withArguments: true});
export const requiredPrice = withI18n(_requiredPrice);
export const secureCode = withI18n(_secureCode);
