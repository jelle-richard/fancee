import type { ValidationRuleWithoutParams } from '@vuelidate/core';

export default {
    $message: (): string => 'validations.required',
    $validator: (value: unknown) => {
        return !(typeof value !== 'number' || value <= 0);
    }
} satisfies ValidationRuleWithoutParams as ValidationRuleWithoutParams;
