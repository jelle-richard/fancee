import type { ValidationRuleWithoutParams } from '@vuelidate/core';
import { VALID_SECURE_CODE_REGEX } from '@/data';

export default {
    $message: (): string => 'validations.secureCode',
    $validator: (value: unknown) => {
        if (typeof value !== 'string') {
            return true;
        }

        return VALID_SECURE_CODE_REGEX.test(value);
    }
} satisfies ValidationRuleWithoutParams as ValidationRuleWithoutParams;
