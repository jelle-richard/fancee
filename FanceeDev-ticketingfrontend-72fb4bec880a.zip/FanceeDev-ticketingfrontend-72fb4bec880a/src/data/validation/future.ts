import type { ValidationRuleWithoutParams } from '@vuelidate/core';
import { DateTime } from 'luxon';
import { isDateTimeInFuture } from '@/util';

export default {
    $message: (): string => 'validations.future',
    $validator: (value: unknown) => {
        if (!DateTime.isDateTime(value)) {
            return true;
        }

        return isDateTimeInFuture(value);
    }
} satisfies ValidationRuleWithoutParams as ValidationRuleWithoutParams;
