import { CountryCode } from '@fancee/data';
import type { ValidationRuleWithParams } from '@vuelidate/core';
import { type CountryCode as LPCountryCode, default as parse } from 'libphonenumber-js';

export default function (countryCode: CountryCode): ValidationRuleWithParams {
    return {
        $message: (): string => 'validations.phoneNumber',
        $params: {countryCode},
        $validator: (value: unknown) => {
            if (!value || typeof value !== 'string') {
                return true;
            }

            const result = parse(value, countryCode as LPCountryCode);

            if (!result) {
                return false;
            }

            return result.isValid();
        }
    };
}
