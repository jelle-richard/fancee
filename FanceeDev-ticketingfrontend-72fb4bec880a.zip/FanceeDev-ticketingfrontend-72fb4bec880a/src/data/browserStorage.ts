const backupStorage: Record<string, string> = {};
let storageMode: 'localStorage' | 'sessionStorage' | 'backupStorage';

try {
    localStorage.length;
    storageMode = 'localStorage';
} catch (err) {
    try {
        sessionStorage.length;
        storageMode = 'sessionStorage';
    } catch (err) {
        storageMode = 'backupStorage';
    }
}

export function getStorageValue(key: string): string | null {
    switch (storageMode) {
        case 'localStorage':
            return localStorage.getItem(key);

        case 'sessionStorage':
            return sessionStorage.getItem(key);

        case 'backupStorage':
            return backupStorage[key] ?? null;
    }
}

export function hasStorageValue(key: string): boolean {
    switch (storageMode) {
        case 'localStorage':
            return key in localStorage;

        case 'sessionStorage':
            return key in sessionStorage;

        case 'backupStorage':
            return key in backupStorage;
    }
}

export function removeStorageValue(key: string): void {
    switch (storageMode) {
        case 'localStorage':
            localStorage.removeItem(key);
            break;

        case 'sessionStorage':
            sessionStorage.removeItem(key);
            break;

        case 'backupStorage':
            delete backupStorage[key];
            break;
    }
}

export function setStorageValue(key: string, value: string): void {
    switch (storageMode) {
        case 'localStorage':
            localStorage.setItem(key, value);
            break;

        case 'sessionStorage':
            sessionStorage.setItem(key, value);
            break;

        case 'backupStorage':
            backupStorage[key] = value;
            break;
    }
}
