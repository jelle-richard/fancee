export enum LogLevel {
    Trace = 'trace',
    Information = 'information',
    Debug = 'debug',
    Success = 'success',
    Warning = 'warning',
    Error = 'error',
    Critical = 'critical',
    None = 'none',
}
