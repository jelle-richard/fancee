export enum ChannelType {
    Facebook = 'FACEBOOK',
    FacebookAds = 'FACEBOOKADS',
    FacebookPublicData = 'FACEBOOKPUBLICDATA',
    Instagram = 'INSTAGRAM',
    InstagramPublicData = 'INSTAGRAMPUBLICDATA',
    GoogleAnalytics = 'GOOGLEANALYTICS',
    GoogleAnalytics4 = 'GOOGLEANALYTICS4',
    GoogleAds = 'GOOGLEADS',
    Youtube = 'YOUTUBE',
    YoutubeV2 = 'YOUTUBEV2',
    LinkedIn = 'LINKEDIN',
    TikTok = 'TIKTOK'
}
