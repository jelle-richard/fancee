export enum ChannelStatus {
    Setup = 'Setup',
    Active = 'Active',
    Paused = 'Paused',
    Expired = 'Expired'
}
