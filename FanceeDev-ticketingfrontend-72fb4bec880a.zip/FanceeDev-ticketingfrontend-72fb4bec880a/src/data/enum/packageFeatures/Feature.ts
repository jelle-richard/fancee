export enum Feature {
    Support = 'accountSupport',
    ShopCustomization = 'shopCustomization',
    SalesGuides = 'salesGuides',
    SalesScanApp = 'salesScanApp',
    Guestlist = 'guestlist',
    CustomerAnalytics = 'customerAnalytics',
    MarketingCampaigns = 'marketingCampaigns',
    AmbassadorPrograms = 'ambassadorPrograms',
    Discounts = 'discounts',
    WebsiteIntegrations = 'websiteIntegrations',
    CustomFeatures = 'customFeatures',
    Seating = 'seating'
}
