export enum GuestFieldType {
    Email = 'email',
    FirstName = 'firstName',
    LastName = 'lastName',
    Quantity = 'quantity'
}
