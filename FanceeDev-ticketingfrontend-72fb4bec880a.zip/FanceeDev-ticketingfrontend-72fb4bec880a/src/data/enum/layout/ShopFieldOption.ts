export enum ShopFieldOption {
    Disabled = 'disabled',
    Optional = 'optional',
    Required = 'required',
    OptionalCountry = 'optional_country',
    OptionalCity = 'optional_city',
    OptionalFullAddress = 'optional_full_address',
    RequiredCountry = 'required_country',
    RequiredCity = 'required_city',
    RequiredFullAddress = 'required_full_address',
}
