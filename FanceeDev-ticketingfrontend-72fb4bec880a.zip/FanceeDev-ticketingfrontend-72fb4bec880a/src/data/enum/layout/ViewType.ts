export enum ViewType {
    List = 'list',
    Calendar = 'calendar'
}
