export enum BarcodeFieldType {
    Barcode = 'barcode',
    EmailAddress = 'emailAddress',
    FirstName = 'firstName',
    LastName = 'lastName'
}
