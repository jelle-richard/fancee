export enum RegisterAdminType {
    CountryManager = 'Country manager',
    CustomerServiceEmployee = 'Customer service employee'
}
