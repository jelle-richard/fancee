export enum SecureCodeFieldType {
    Code = 'code',
    MaxUses = 'maxUses'
}
