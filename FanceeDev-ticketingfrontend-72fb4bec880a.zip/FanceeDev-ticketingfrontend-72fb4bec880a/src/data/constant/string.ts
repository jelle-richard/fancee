export const VALID_SECURE_CODE_REGEX: RegExp = /^([a-zA-Z0-9.@_-]+)$/;
