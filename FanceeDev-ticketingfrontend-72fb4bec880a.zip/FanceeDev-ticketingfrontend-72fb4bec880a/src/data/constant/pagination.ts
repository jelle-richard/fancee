export const DEFAULT_STARTING_PAGE: number = 1;
export const DEFAULT_PAGE_LENGTH: number = 10;
export const MAXIMUM_PAGE_LENGTH: number = 100;
export const DEFAULT_WALLET_BALANCE_ENTRIES: number = 7;
