import { AddressAdapter, countries, CountryCode } from '@fancee/data';
import { FluxFormSelectOption } from '@fancee/flux';

export const DEFAULT_SEARCH_RESULTS: number = 8;
export const DEFAULT_PAGES_AMOUNT: number = 1;
// todo: This is a temp constant and should be removed when the following issue is fixed: https://fanceesoftware.atlassian.net/browse/FAN-1745
export const DEFAULT_SEARCH_RESULTS_JUMBO_SELECTOR: number = 40;

export const SELECT_COUNTRY_OPTIONS = Object.keys(countries).map<FluxFormSelectOption>(code => ({
    id: code,
    label: AddressAdapter.parseCountryCodeToDisplay(code as CountryCode)
}));
