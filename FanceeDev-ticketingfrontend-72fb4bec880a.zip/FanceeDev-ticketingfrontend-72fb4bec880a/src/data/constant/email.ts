export const SUPPORT_EMAIL: string = 'support@wearefancee.com';
export const SALES_EMAIL: string = 'sales@wearefancee.com';
export const MARKETING_EMAIL: string = 'marketing@wearefancee.com';
