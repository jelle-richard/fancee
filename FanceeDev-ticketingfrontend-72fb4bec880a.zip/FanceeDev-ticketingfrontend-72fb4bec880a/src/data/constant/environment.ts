export type EnvironmentType = 'development' | 'production' | 'staging';
export const ENVIRONMENT: EnvironmentType = import.meta.env.VITE_ENVIRONMENT as EnvironmentType;
