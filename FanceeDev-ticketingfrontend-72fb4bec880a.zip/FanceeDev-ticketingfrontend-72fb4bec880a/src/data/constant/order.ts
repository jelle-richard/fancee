import { PaymentStatus } from '@fancee/data';

export const SUCCESSFUL_PAYMENT_STATUSES: PaymentStatus[] = [PaymentStatus.Authorised, PaymentStatus.Chargeback, PaymentStatus.Refund, PaymentStatus.PartialRefund];
