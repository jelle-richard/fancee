export const MAX_FILE_SIZE_KB: number = 1000;
export const TSP_EXPLANATION_PDF_LINK: string = '/assets/documents/TicketServicePlus_EN.pdf';
export const TERMS_CONDITIONS_SHOP_PDF_LINK: string = '/assets/documents/TermsAndConditionsShop_EN.pdf';
export const SCANNING_INSTRUCTIONS_PDF_LINK_NL: string = '/assets/documents/ScanningInstructions_NL.pdf';
