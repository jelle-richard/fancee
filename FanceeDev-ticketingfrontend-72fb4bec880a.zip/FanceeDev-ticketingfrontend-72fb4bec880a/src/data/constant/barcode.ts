export const MAX_VALUE_BARCODE_IMPORT_ROWS: number = 25000;
export const MAX_VALUE_BARCODE_GENERATE: number = 5000;
export const MAX_VALUE_GUESTLIST_IMPORT: number = 100;
