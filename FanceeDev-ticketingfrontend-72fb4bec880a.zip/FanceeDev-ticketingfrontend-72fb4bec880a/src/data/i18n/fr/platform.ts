import type { Translations } from '../types';

export default {
    changelog: {
        noChanges: 'Aucun changement trouvé',
        noChangesDescription: `Aucun changement n'a été trouvé dans le système, veuillez vérifier {'à'} nouveau plus tard pour d'éventuelles mises {'à'} jour du système.`
    },
    faq: {
        title: 'Questions fréquemment posées',
        description: 'Des questions? ',
        email: {
            title: 'E-mail',
            description: 'Nous ferons de notre mieux pour vous contacter dans un délai de {0} jour(s) ouvrable(s) !',
            button: 'Envoyez-nous un email'
        },
        phone: {
            title: 'Téléphone',
            description: `Nous sommes toujours heureux d'aider.`
        },
        whatsapp: {
            title: 'WhatsApp',
            description: 'Nous ferons de notre mieux pour vous contacter dans les {0} heures les jours ouvrables !',
            button: 'Contactez-nous'
        },
        categories: [
            {
                icon: 'user',
                title: 'Gestion de compte',
                subTitle: 'Réponses sur la façon de configurer les configurations de compte',
                questions: [
                    ['Puis-je modifier mes frais ?', 'Les frais de votre plateforme sont basés sur le package de tableaux de bord comme indiqué dans le contrat. '],
                    [`Puis-je augmenter ou rétrograder mon forfait ?', 'Sauf indication expresse dans votre contrat, vous pouvez le faire {'à'} tout moment. `],
                    ['Comment activer 2-FA ?', `L'activation de 2-FA est un excellent moyen de sécuriser davantage votre compte. `],
                    ['Comment modifier mon code TVA, mon compte bancaire et/ou mes coordonnées de chambre de commerce ?', `Vous ne pouvez pas modifier ces informations {'à'} votre propre discrétion. `],
                    ['Certains éléments de menu sont verrouillés, comment puis-je y accéder ?', 'Selon le package de tableaux de bord pour lequel votre compte est configuré, certaines pages peuvent ne pas être incluses. ']
                ]
            },
            {
                icon: 'shopping-bag',
                title: 'Ventes',
                subTitle: 'Comment gérer vos ventes',
                questions: [
                    [`Le support m'aidera-t-il dans mes ventes ?`, `Le tableau de bord prend en charge un large éventail d'explications sous forme de didacticiels, de webinaires en ligne et de téléchargements, disponibles 24h/24 et 7j/7. `],
                    [`Comment puis-je offrir des réductions {'à'} mes clients ?`, 'Les remises sont un excellent moyen d’attirer des clients, de vendre le stock restant ou d’offrir une compensation. '],
                    [`J'ai des produits en attente, qu'est-ce que cela signifie ?`, `Lorsqu'un client achète des produits via votre boutique, notre plateforme conserve sa sélection de produits dans une réservation (par défaut de 8 minutes), cela permet {'à'} l'utilisateur de remplir les formulaires requis pour finaliser son achat. `],
                    ['Puis-je augmenter ou diminuer les prix des produits pendant les soldes ?', `Oui, vous pouvez modifier les prix de vos produits {'à'} tout moment en les ajustant {'à'} l'étape « Produits » de « Configurer l'événement ». `],
                    [`Puis-je augmenter ou diminuer le stock de produits pendant les soldes ?', 'Le stock de produits peut être modifié {'à'} tout moment, mais si le stock restant est mis {'à'} jour {'à'} 0, les réservations en attente peuvent toujours être complétées. `],
                    ['Puis-je répercuter les frais de plateforme sur le client ?', `Vous pouvez librement ajouter vos propres frais au prix du produit dans les options avancées de modification d'un produit {'à'} l'étape « Produits » de « Configurer l'événement ».`]
                ]
            },
            {
                icon: 'calendar',
                title: `Gestion d'événements`,
                subTitle: 'Comment configurer vos événements et vos boutiques',
                questions: [
                    [`Que font les types d'événements pour un événement ?`, `Lors de la création d'un événement, vous êtes confronté au choix entre un événement normal, assis ou programmé. `],
                    ['Quel lien utiliser pour partager ma boutique en ligne ?', `Une fois que vous avez créé un événement avec au moins une boutique, le lien de cette boutique sera visible dans l'aperçu de votre événement accessible via la page 'Mes événements'.`],
                    ['Comment puis-je utiliser mon propre guide de marque dans les boutiques en ligne ?', `Lors de la création de boutiques pour votre événement, vous pouvez choisir des couleurs via l'option « Appliquer les couleurs de la marque » dans l'étape « Boutiques » de « Configurer l'événement ». `]
                ]
            },
            {
                icon: 'mobile-notch',
                title: 'Des billets',
                subTitle: `Comment vérifier l'accès aux événements`,
                questions: [
                    ['Comment scanner les billets ?', `En utilisant l'application « WeAreFancee Scan » qui se trouve {'à'} la fois sur le Play Store Android et sur l'App Store d'Apple. `],
                    ['Comment puis-je me connecter au scanner ?', `Vous pouvez vous connecter avec votre compte d'organisation ou créer des équipes d'organisation via la page « Équipes d'organisation » sous l'élément de menu « Numérisation ».`],
                    [`Mon client déclare que le billet n'a pas été livré, que dois-je faire ?`, `Si le client n'a pas reçu son billet, vous pouvez choisir d'utiliser les étapes suivantes : 1. Vous pouvez guider le client vers la page « Billet perdu » trouvée sur https://www.WeAreFancee.com/lost-ticket\r `],
                    [`Que dois-je faire si un client se présente {'à'} l’événement sans billet ?`, `Lorsqu'un client a oublié d'apporter son billet mais est en mesure de fournir une preuve de paiement, vous pouvez retrouver le billet dans l'application via la fenêtre « Statistiques des billets » et effectuer une recherche avec l'e-mail et/ou la date de naissance.`]
                ]
            },
            {
                icon: 'coin',
                title: 'Finance',
                subTitle: 'Comment suivre vos revenus',
                questions: [
                    [`Puis-je avoir un paiement intermédiaire ?`, `Oui, en accédant {'à'} votre « Portefeuille » situé sous l'élément de menu « Finances », vous pouvez demander un paiement si votre solde actuel est positif. `],
                    ['Quand est-ce que je reçois un paiement ?', `Vous pouvez demander un paiement en naviguant vers votre « Portefeuille » situé sous l'élément de menu « Finances » si votre solde est positif.`],
                    ['Comment rembourser un client ?', `Vous pouvez rechercher le client ou sa transaction dans l'aperçu des transactions trouvé dans « Transactions » sous l'élément de menu « Finance ». `],
                    ['Où puis-je trouver mes factures ?', `Dans l'aperçu de la page « Factures » sous l'élément de menu « Finances ».`]
                ]
            },
            {
                icon: 'chart-simple',
                title: 'Statistiques',
                subTitle: 'Comment utiliser vos données clients',
                questions: [
                    ['Comment puis-je suivre les résultats de ma campagne ?', `Via la page « Campagnes » sous l'élément de menu « Marketing ».`],
                    ['Où puis-je trouver des statistiques de base sur les événements ?', `Sur l'écran d'accueil, vous verrez initialement des statistiques {'à'} l'échelle du compte. `],
                    ['Comment trouver des clients et des transactions ?', `Vous pouvez accéder aux pages Finance > Commande où vous pouvez effectuer une recherche sur les clients ou les détails de la commande, en cliquant sur une ligne, vous obtiendrez plus d'informations.`],
                    [`Comment savoir quels clients je suis autorisé {'à'} contacter ?`, `Lorsque vous souhaitez contacter un ou plusieurs utilisateurs, vous pouvez accéder {'à'} la page « Transactions » sous l'élément de menu « Finance » et filtrer les utilisateurs qui ont choisi de recevoir une promotion par e-mail ou par SMS.`],
                    ['Comment suivre les ventes ?', `Sur la page d'accueil, vous pouvez rechercher et sélectionner votre événement pour avoir un aperçu des ventes quotidiennes, du stock restant et de vos meilleures ventes.`]
                ]
            }
        ]
    },
    profile: {
        loadingFailed: 'Erreur lors de la récupération des informations de votre profil, veuillez réessayer plus tard.',
        contact: {
            title: 'Contact',
            add: '@:platform.profile.contact.title',
            added: '{0} {1} a été ajouté en tant que contact.',
            deleted: '{0} {1} a été supprimé en tant que contact.',
            createFailed: `Une erreur s'est produite lors de la création du contact. `,
            deleteFailed: `Une erreur s'est produite lors de la tentative de suppression du contact. `,
            editFailed: `Une erreur s'est produite lors de l'enregistrement du contact. `,
            emptyView: [
                'Chez @:global.platform.name, nous comprenons que lorsque votre entreprise se développe, vous devez déléguer certaines tâches. ',
                `Si aucun contact supplémentaire n'est configuré, toute notre correspondance arrivera {'à'} l'e-mail enregistré de ce compte.`,
                'Les contacts peuvent être définis par rôle, afin que nos demandes parviennent aux bons services.'
            ],
            role: {
                customerSupprt: 'Service client',
                finance: 'Finance',
                marketing: 'Commercialisation',
                organization: 'Organisation'
            }
        },
        organization: {
            title: '@:global.organisation',
            cannotMakeChanges: 'Votre contrat a été créé. ',
            downloadContract: 'Télécharger le contrat',
            finance: 'Finance',
            holder: 'Titulaire',
            legalEntity: 'Entité légale',
            loadCurrenciesFailed: 'Erreur rencontrée lors de la récupération des devises. '
        },
        packages: {
            title: 'Paquets',
            request: 'Demande',
            requestFailed: 'Impossible de demander un changement de forfait. ',
            requestSuccess: `Votre demande de modification du package vers {0} a été soumise {'à'} notre support.`,
            selfService: 'En libre service',
            supportBusinessHours: 'Assistance compte (heures ouvrables)',
            support247: 'Assistance compte (24h/24 et 7j/7)',
            ticketFee: '{0} Frais de billet',
            ticketFeeCustom: 'Frais de billet en accord avec les ventes.',
            unlimited: 'Illimité',
            feature: {
                accountSupport: 'Prise en charge du compte',
                ambassadorPrograms: `Programmes d'ambassadeurs`,
                customerAnalytics: 'Analyse client',
                customFeatures: 'Fonctionnalités sur mesure',
                discounts: 'Réductions',
                guestlist: 'Liste des invités',
                marketingCampaigns: 'Campagnes marketing',
                salesGuides: 'Guides de vente',
                salesScanApp: 'Ventes',
                seating: 'Sièges',
                shopCustomization: 'Personnalisation de la boutique',
                websiteIntegrations: 'Intégrations de sites Web'
            },
            light: {
                name: 'Lumière',
                description: `Petites organisations jusqu'{'à'} 2 500 billets par an.`
            },
            medium: {
                name: 'Moyen',
                description: 'Des organisations plus grandes pour 2 500 billets par an.'
            },
            custom: {
                name: 'Coutume',
                description: 'Pour les organisations ayant besoin d’une logique personnalisée.'
            }
        },
        security: {
            title: 'Sécurité',
            passwordChanged: 'Votre mot de passe a été changé. ',
            passwordChangeFailed: `Une erreur s'est produite lors de la tentative de modification de votre mot de passe. `
        },
        sessions: {
            title: 'Séances'
        },
        user: {
            title: 'Utilisateur',
            avatar: 'Image de profil'
        }
    },
    receipt: {
        title: 'Télécharger le reçu',
        description: 'Votre reçu contiendra un aperçu de vos achats.',
        downloading: 'Votre reçu PDF est en route. ',
        exceeded: 'Nous avons rencontré un léger problème lors du téléchargement de votre reçu. ',
        failed: `Nous n'avons pas pu récupérer votre reçu. `,
        success: 'Votre reçu PDF a été téléchargé ! '
    }
} satisfies Translations;
