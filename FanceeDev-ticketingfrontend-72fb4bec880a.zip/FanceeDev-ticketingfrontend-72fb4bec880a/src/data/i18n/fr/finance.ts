import type { Translations } from '../types';

export default {
    title: 'Finances',
    takings: 'Recettes',
    ticketFee: 'Frais de billet',
    paymentFee: 'Frais de paiement',
    discount: 'Réduction',
    invoice: {
        plural: 'Factures',
        singular: 'Facture',
        title: '@:finance.invoice.plural',
        downloadFailed: `Une erreur s'est produite lors du téléchargement du fichier des factures.`,
        downloadSingleFailed: `Une erreur s'est produite lors du téléchargement de la facture.`,
        loadingFailed: `Le système n'a pu récupérer aucune facture.`,
        loadingEventsFailed: `Une erreur s'est produite lors du chargement de vos événements. `
    },
    order: {
        title: 'Ordres',
        downloadFailed: `Une erreur s'est produite lors du téléchargement des commandes.`,
        loadingFailed: `Une erreur s'est produite lors du chargement de la commande.`,
        loadingSingleFailed: `Une erreur s'est produite lors du chargement des commandes.`,
        search: 'Ordres de Recherche...',
        cost: 'Coût',
        filter: {
            promotionalEmail: 'E-mail promotionnel',
            promotionalSms: 'SMS promotionnels',
            orderSms: 'Recevoir un SMS de commande'
        },
        table: {
            psp: 'Référence PSP',
            event: '@:event.singular',
            date: '@:global.date',
            amount: '@:global.montant',
            paymentStatus: '@:finance.paymentStatus.title'
        },
        single: {
            title: 'Historique des commandes',
            advanced: {
                title: 'Avancé',
                refund: {
                    title: 'Remboursement',
                    info: 'Vous avez la possibilité de rembourser le client.',
                    start: 'Commencer le remboursement'
                },
                resend: {
                    title: 'Renvoyer la confirmation de commande',
                    info: `Vous avez la possibilité de renvoyer les billets au client, ce sera une copie directe de l'e-mail envoyé lors de l'exécution de la commande.`,
                    disabled: `Le renvoi de la commande au client n'est possible que lorsque le paiement a été effectué.`,
                    submit: 'Renvoyer',
                    success: `Le PDF du ticket de cette commande a été renvoyé {'à'} l'acheteur d'origine.`
                }
            },
            client: {
                title: 'Informations clients',
                optins: {
                    title: 'Inscriptions promotionnelles',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            order: {
                title: 'Commande',
                breakdown: 'Panne',
                psp: 'Référence PSP',
                cost: 'Coût',
                paymentFee: 'Frais de paiement',
                paymentMethod: 'Mode de paiement',
                paymentStatus: 'Statut de paiement',
                placed: 'Commande passée',
                productFee: 'Frais de produit',
                seatedTicketFee: 'Frais de billet assis',
                ticketAndProductRevenue: 'Billet',
                ticketFee: 'Frais de billet',
                ticketServicePlusCost: 'Service de billetterie plus coût',
                totalOrderCost: 'Coût total de la commande'
            },
            purchase: {
                title: 'Achat',
                viewTickets: 'Voir les billets',
                productFee: '{0} frais de produit',
                seatedTicketFee: '{0} frais de billet assis',
                ticketFee: '{0} frais de billet',
                boughtTsp: 'Service de billets achetés Plus',
                receiveOrderSms: 'Recevoir un sms de commande',
                products: 'Des produits'
            }
        },
        refund: {
            title: 'Remboursement {0}',
            notice: `Gardez {'à'} l’esprit que le remboursement d’une commande n’est pas réversible, l’acheteur du billet sera informé de ce remboursement et nous visons {'à'} transférer les fonds dans les 3 jours ouvrables.`,
            returnToStock: 'Retour en stock',
            invalidateTickets: 'Invalider les billets',
            submit: 'Émettre un remboursement',
            totalRefundAmount: 'Montant total à rembourser :',
            failed: `Une erreur s'est produite lors de l'émission du remboursement.`,
            success: `Le remboursement a été effectué avec succès et l'acheteur en sera informé.`
        }
    },
    report: {
        title: `Rapports`,
        loadingFailed: `Une erreur s'est produite lors du chargement de vos statistiques de revenus. Veuillez contacter l'assistance si l'erreur persiste.`,
        loadingEventsFailed: `Une erreur s'est produite lors du chargement de vos événements. Veuillez réessayer plus tard.`,
        info: `Vous pouvez utiliser ces informations pour analyser les tendances de vos revenus. Sélectionnez un événement pour obtenir des informations spécifiques ou laissez-le vide pour un aperçu de l'ensemble du compte.`,
        searchEvent: `Rechercher un événement...`,
        organization: {
            statistics: {
                title: 'Statistiques de revenus',
                fulfilledOrders: 'Commandes exécutées',
                issuedProducts: 'Produits émis',
                obtained: {
                    app: 'Obtenu via l\'application @:global.platform.name.',
                    generated: 'Généré par la plateforme.',
                    guestlist: 'Envoyés via des listes d\'invités.',
                    imported: 'Importé d\'une source externe.',
                    shop: 'Obtenu via la boutique @:global.platform.name.',
                    ticketswap: 'Vendu via Ticketswap'
                }
            },
            revenue: {
                title: 'Revenu de l\'organisation'
            },
            cost: {
                title: 'Coût de l\'organisation',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Frais de paiement',
                ticketFeeCost: '@:finance.ticketFee',
                seatedTicketFeeCost: 'Frais de billets assis',
                guestlistCost: 'Listes d\'invités'
            }
        },
        platform: {
            revenue: {
                title: 'Revenu de la plateforme',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Frais de paiement'
            },
            cost: {
                title: 'Coût de la plateforme',
                ticketFee: '@:finance.ticketFee',
                productFee: 'Frais de produit',
                seatedTicketFee: 'Frais de billets assis',
                guestlist: 'Listes d\'invités',
                additional: 'Supplémentaire',
                paymentFeeCost: 'Frais de paiement'
            }
        },
        client: {
            cost: {
                title: 'Coût client',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Frais de paiement'
            }
        },
        product: {
            title: 'Revenu des produits',
            cash: 'Revenu en espèces',
            online: 'Revenu en ligne'
        },
        totals: {
            title: 'Total',
            totals: 'Total',
            OrganizationRevenue: 'Total des revenus de l\'organisation',
            PlatformRevenue: 'Total des revenus de la plateforme',
            organizationCost: 'Coût total de l\'organisation',
            clientCost: 'Coût total du client',
            revenue: 'Revenu total',
            cost: 'Coût total',
            profit: {
                title: 'Profit',
                wallet: 'Versé dans le portefeuille',
                profit: 'Profit',
                cash: 'La différence entre le profit et ce qui est versé dans votre portefeuille est due aux revenus en espèces'
            }
        }
    },
    wallet: {
        title: 'Portefeuille',
        currencyConversionInfo: 'Veuillez noter que même si tous les paiements sont traités en euros, des fluctuations des montants reçus peuvent survenir en raison des frais bancaires et des fluctuations de conversion des devises.',
        searchTransactions: 'Rechercher des opérations...',
        downloadInvoiceFailed: `Une erreur s'est produite lors du téléchargement de la facture.`,
        downloadOrdersFailed: `Une erreur s'est produite lors du téléchargement du fichier de commandes.`,
        downloadReceiptFailed: 'Erreur rencontrée lors du téléchargement du reçu du portefeuille.',
        loadingBalanceFailed: 'Erreur rencontrée lors de la récupération du solde du portefeuille.',
        loadingTransactionsFailed: 'Erreur rencontrée lors de la récupération des transactions du portefeuille.',
        balance: {
            title: 'Équilibre',
            subTitle: 'Solde du portefeuille au cours des {days} derniers jours.',
            pending: 'En attente',
            spendable: 'Dépensable'
        },
        payout: {
            request: 'Demande Paiement',
            requestFailed: 'Erreur rencontrée lors du traitement de la demande de paiement.',
            requestSuccess: 'Votre demande de paiement a été soumise avec succès.',
            acknowledge: `En soumettant cette demande, vous reconnaissez que vous demandez {'à'} être payé {montant}.`,
            info: 'Vous pouvez demander un montant de paiement personnalisé en cochant la case et en fournissant une valeur personnalisée.',
            custom: 'Demander une valeur personnalisée',
            amount: 'Montant'
        },
        structure: {
            pending: 'En attente',
            reserved: 'Réservé',
            requiredDeposit: 'Dépôt requis',
            spendable: {
                title: 'Dépensable',
                tip: `Vous avez demandé des paiements d'un montant total de {0} qui n'ont pas encore été traités.`
            }
        },
        transaction: {
            statement: 'Déclaration',
            table: {
                amount: 'Montant',
                processedOn: 'Traité',
                requestedOn: 'Demandé'
            }
        }
    },
    paymentStatus: {
        title: 'Statut de paiement',
        authenticationFinished: 'Authentification terminée',
        authenticationNotRequired: 'Authentification non requise',
        authorised: 'Autorisé',
        blocked: 'Bloqué',
        cancelled: 'Annulé',
        challengeShopper: `Défier l'acheteur`,
        chargeback: 'Rétrofacturation',
        error: 'Erreur',
        expired: 'Expiré',
        identifyShopper: `Identifier l'acheteur`,
        partiallyAuthorised: 'Partiellement autorisé',
        partialRefund: 'Remboursement partiel',
        pending: 'En attente',
        presentToShopper: 'Présenter au client',
        received: 'Reçu',
        redirectShopper: `Rediriger l'acheteur`,
        refund: 'Remboursement',
        pendingRefund: 'En attente remboursement',
        refused: 'Refusé',
        unknown: 'Inconnu'
    }
} satisfies Translations;
