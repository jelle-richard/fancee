import type { Translations } from '../types';

export default {
    title: 'Données',
    titles: {
        campaign: 'Campagne',
        channels: 'Canaux',
        home: 'Maison',
        monitor: 'Moniteur',
        overview: 'Aperçu',
        social: 'Sociale',
        ticketing: 'Billetterie'
    },
    navigation: {
        campaign: 'Campagne',
        channels: 'Canaux',
        home: 'Maison',
        settings: 'Paramètres',
        social: 'Sociale',
        ticketing: '@:analytics.titles.ticketing'
    },
    comparisonView: 'Comparer',
    disabled: 'Désactivé',
    enabled: 'Activé',
    fullOverview: 'Aperçu complet',
    paused: 'En pause',
    noData: `Aucune donnée n'a pu être trouvée`,
    openInBrowser: 'Ouvrir dans le navigateur',
    selectField: 'Sélectionnez le champ...',
    splitOn: 'Divisé sur...',
    noChannelsFound: {
        title: 'Aucune chaîne trouvée',
        message: `Aucune chaîne n'a été trouvée. `
    },
    channel: {
        plural: 'Canaux',
        singular: 'Canal',
        saving: 'Sauvegarde de la chaîne...',
        updating: `Mise {'à'} jour des abonnements...`,
        info: {
            createdOn: 'Créé sur',
            lastLogin: 'Dernière connexion',
            organization: 'Organisation',
            owner: 'Propriétaire',
            request: 'Demande'
        },
        new: {
            title: 'Nouvelle chaîne',
            user: 'Utilisateur',
            supermetrics: {
                account: 'SuperMetrics-ds_accounts',
                user: 'SuperMetrics-ds_user'
            }
        },
        status: {
            active: 'Actif',
            error: 'Erreur',
            expired: 'Expiré',
            inactive: 'Inactif',
            partiallyActive: 'Partiellement actif',
            paused: 'En pause',
            setup: 'Installation'
        },
        table: {
            name: '@:form.field.name',
            type: 'Taper',
            status: 'Statut',
            organization: 'Organisation',
            owner: 'Propriétaire',
            email: '@:form.field.email',
            createdOn: 'Créé sur'
        },
        type: {
            facebook: 'Facebook',
            facebookads: 'Publicités Facebook',
            facebookpublicdata: 'Données publiques Facebook',
            googleads: 'Annonces Google',
            googleanalytics: 'Google Analytics',
            googleanalytics4: 'GoogleAnalytics V4',
            instagram: 'Instagram',
            instagrampublicdata: 'Données publiques Instagram',
            linkedin: 'LinkedIn',
            tiktok: 'TIC Tac',
            youtube: 'Youtube',
            youtubev2: 'YouTubeV2'
        }
    },
    subscription: {
        plural: 'Abonnements',
        singular: 'Abonnement',
        status: {
            active: 'Actif',
            inactive: 'Inactif'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            aw_ad: 'Annonces Google – Annonce',
            aw_age: 'Annonces Google – Âge',
            aw_campaign: 'Annonces Google – Campagne',
            aw_conversion: 'Annonces Google – Conversions',
            aw_gender: 'Annonces Google – Sexe',
            aw_geo: 'Annonces Google – Géo',
            aw_keyword: 'Annonces Google – Mot clé',
            aw_placement: 'Annonces Google – Emplacement',
            aw_search_query: 'Google Ads – Requête de recherche',
            aw_shopping: 'Annonces Google – Shopping',
            fa_ads: 'Publicités Facebook - Publicité',
            fa_age_and_gender: 'Publicités Facebook – Âge et sexe',
            fa_campaign: 'Publicités Facebook - Campagne',
            fa_conversion: 'Publicités Facebook – Conversion',
            fa_geo: 'Publicités Facebook – Géo',
            fa_video: 'Publicités Facebook – Vidéo',
            fb: 'La page Facebook',
            fb_age_and_gender: 'Facebook – Âge et sexe',
            fb_geo_likes: 'Facebook – Géographique',
            fb_posts: 'Facebook - Publications',
            fbpd_page: 'Données publiques Facebook - Page',
            fbpd_posts: 'Données publiques Facebook - Publications',
            fbpd_url_shares: `Données publiques Facebook - Partages d'URL`,
            ga_content: 'Google Analytics – Contenu',
            ga_ecommerce: 'Google Analytics – Commerce électronique',
            ga_events: 'Google Analytics – Événements',
            ga_paid_traffic: 'Google Analytics – Trafic payant',
            ga_search: 'Google Analytics – Recherche',
            ga_social: 'Google Analytics – Réseaux sociaux',
            ga_technology: 'Google Analytics – Technologie',
            ga_traffic: 'Google Analytics – Trafic',
            ga_user: 'Google Analytics – Utilisateur',
            gawa_device: 'Google Analytics 4 – Appareils',
            gawa_ecom_items: 'Google Analytics 4 – Articles de commerce électronique',
            gawa_engagement: 'Google Analytics 4 – Engagement',
            gawa_publishing: 'Google Analytics 4 – Publication',
            gawa_traffic_acquisition: 'Google Analytics 4 – Acquisition de trafic',
            gawa_user_acquisition: `Google Analytics 4 - Acquisition d'utilisateurs`,
            igi: 'Instagram - Abonnés',
            igi_age_and_gender: 'Instagram – Âge et sexe',
            igi_country: 'Instagram - Pays',
            igi_media: 'Instagram - Médias',
            igi_profile_data: 'Instagram - Données de profil',
            igpd2_hashtags: 'Données publiques Instagram - Hashtags',
            igpd2_posts: 'Données publiques Instagram - Publications',
            igpd2_profiles: 'Données publiques Instagram - Profils',
            lip_country: 'LinkedIn - Pays',
            lip_page: 'LinkedIn - Page',
            lip_post: 'LinkedIn - Publications',
            tikba_country: 'TikTok - Pays',
            tikba_gender: 'TikTok - Genre',
            tikba_profile: 'TikTok - Profil',
            tikba_video: 'TikTok - Vidéo',
            yt2_ad_performance: 'Youtube v2 – Performances des annonces',
            yt2_channel: 'Youtube v2 - Chaîne',
            yt2_demographic: 'Youtube v2 – Données démographiques',
            yt2_device: 'Youtube v2 - Appareil',
            yt2_geo: 'Youtube v2 - Géo',
            yt2_traffic_source: 'Youtube v2 – Source de trafic',
            yt2_video: 'Youtube v2 - Vidéo',
            yt_video: 'Vidéo Youtube'
        }
    },
    header: {
        allChannels: 'Toutes les chaînes',
        comparisonView: 'Vue comparative',
        datePresets: {
            lastMonth: 'Le mois dernier',
            lastSevenDays: 'Les 7 derniers jours',
            thisMonth: 'Ce mois-ci',
            thisYear: 'Cette année'
        }
    },
    ads: {
        title: 'Les publicités',
        budget: 'Budget',
        campaign: 'Campagne',
        clicks: 'Clics',
        conversion: 'Conversion',
        cost: 'Coût',
        cpc: 'CPC',
        ctr: 'CTR',
        date: '@:global.date',
        engagement: 'Fiançailles',
        impressions: 'Impressions',
        status: 'Statut',
        totalCampaigns: 'Total des campagnes',
        totalSpent: 'Total dépensé'
    },
    bestPostTime: {
        title: 'Meilleur moment pour poster sur',
        comments: 'commentaires',
        likes: 'Aime',
        reach: 'Atteindre',
        basedOn: {
            comments: 'Basé sur le nombre moyen de commentaires',
            likes: 'Basé sur la moyenne des likes',
            reach: 'Basé sur la portée moyenne'
        },
        engagement: {
            highest: 'Engagement le plus élevé',
            lowest: 'Engagement le plus faible'
        }
    },
    campaignInfo: {
        title: 'informations générales',
        ageClicks: `Clics liés {'à'} l'âge`,
        budget: 'Budget',
        clicks: 'Clics',
        conversion: 'Conversion',
        cpc: 'CPC',
        ctr: 'CTR',
        genderClicks: 'Clics sur le sexe',
        impressions: 'Impressions',
        remaining: 'Restant',
        spent: 'Dépensé'
    },
    captions: {
        title: 'Légendes'
    },
    emotions: {
        title: 'Émotions',
        subTitle: 'Pour Facebook uniquement',
        like: 'Comme',
        likes: 'Aime',
        love: 'Amour',
        thankful: 'Reconnaissant',
        wow: 'Ouah',
        haha: 'Haha',
        pride: 'Fierté',
        anger: 'Colère',
        sorry: 'Désolé'
    },
    engagement: {
        title: 'Fiançailles',
        clicks: 'Clics',
        conversion: 'Conversion',
        cpc: 'CPC',
        ctr: 'CTR',
        comments: 'commentaires',
        impressions: 'Impressions',
        likes: 'Aime',
        shares: 'Actions'
    },
    field: {
        activeFollowers: 'Abonnés actifs',
        averageAge: 'Âge moyen',
        clicksOnPage: 'Clics',
        comments: 'commentaires',
        description: 'Description',
        increasedFollowers: `Augmentation du nombre d'abonnés`,
        likes: 'Aime',
        percentIncreaseFollowers: 'Les abonnés augmentent',
        percentMen: 'Hommes',
        percentWomen: 'Femmes',
        reach: 'Atteindre',
        shares: 'Actions',
        totalFollowers: `Nombre total d'abonnés`
    },
    followers: {
        title: 'Suiveurs',
        lost: 'Perdu',
        new: 'Nouveau',
        total: 'Total'
    },
    hashtags: {
        title: 'Hashtags'
    },
    locations: {
        title: 'Emplacements'
    },
    mentions: {
        title: 'Mentionné'
    },
    monitor: {
        title: 'Surveillez vos chaînes',
        placeholder: 'Sélectionnez une chaîne...',
        averageDay: 'Moyenne par jour',
        averageHour: 'Moyenne par heure',
        bestDayToPost: 'Meilleur jour pour publier',
        bestHourToPost: 'Meilleure heure pour publier',
        captions: 'Légendes',
        emojis: 'Émojis',
        hashtags: '',
        mentions: `{'@'}Mentions`,
        topPosts: 'Les 5 meilleurs articles',
        age: {
            title: 'Âge',
            subTitle: `J'aime en fonction de l'âge`
        },
        emotion: {
            title: 'Émotion',
            subTitle: `J'aime basé sur l'émotion`
        },
        gender: {
            title: 'Genre',
            subTitle: `J'aime en fonction du sexe`
        }
    },
    post: {
        title: 'Des postes',
        comments: 'commentaires',
        date: '@:global.date',
        likes: 'Aime',
        shares: 'Actions',
        clicks: 'Clics',
        message: 'Message',
        reach: 'Atteindre',
        reactions: 'Réactions',
        time: '@:global.time',
        views: 'Vues',
        table: {
            channel: '@:analytics.channel.singular',
            date: '@:global.date',
            type: 'Taper',
            engagement: 'Fiançailles',
            conversion: 'Conversion',
            paidYesNo: 'Payé O/N'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            video: 'Vidéo',
            video_inline: 'Vidéo',
            video_direct_response: 'Réponse vidéo',
            reels_video: 'Vidéo en bobines',
            story_video: `Vidéo d'histoire`,
            feed_carousel_album: 'Album de flux',
            photo: 'Photo',
            image: 'Image',
            album: 'Album',
            carousel_album: 'Album',
            share: 'Partager',
            cover_photo: 'Photo de couverture',
            image_share: `Partage d'images`,
            native_templates: 'Publicité',
            event: 'Événement'
        }
    },
    reach: {
        title: 'Atteindre',
        gained: 'Portée gagnée',
        gainedPercentage: '{0} gagnés',
        lost: 'Atteindre perdu',
        lostPercentage: '{0} perdu'
    },
    socialImpact: {
        title: 'Impact social',
        engagement: 'Fiançailles',
        followers: 'Suiveurs',
        growth: 'Croissance',
        posts: 'Des postes',
        reach: 'Atteindre',
        less: 'moins que la dernière période',
        more: 'plus que la dernière période'
    },
    spent: {
        title: 'Total dépensé',
        budget: 'Budget',
        cost: 'Coût',
        total: 'Total'
    },
    tags: {
        title: 'Titre',
        captions: 'Légendes',
        hashtags: 'Hashtags',
        mentions: 'Mentionné'
    },
    topLocations: {
        title: 'Meilleurs emplacements',
        country: 'Pays',
        visitors: 'Visiteurs'
    },
    totalCampaigns: {
        title: 'Total des campagnes',
        enabled: 'Activé',
        disabled: 'Désactivé',
        paused: '@:analytics.paused'
    },
    crm: {
        channel: {
            title: '@:analytics.channel.plural',
            delete: {
                title: 'Supprimer la chaîne',
                message: `Cela supprimera la chaîne, les abonnements et toutes les données appartenant {'à'} ceux-ci.`,
                done: 'La chaîne a été supprimée.'
            },
            refresh: {
                title: 'Actualiser la chaîne',
                message: `L'actualisation d'une chaîne tentera de récupérer jusqu'{'à'} 6 mois de données pour chaque abonnement actif.`,
                working: `L'actualisation de la chaîne {0} va bientôt commencer.`
            },
            fields: {
                title: 'Tous les champs',
                table: {
                    name: 'Nom',
                    type: 'Taper',
                    field: 'Champ',
                    group: 'Groupe',
                    description: 'Description'
                }
            }
        },
        subscription: {
            refresh: `L'actualisation de l'abonnement {0} va bientôt commencer.`,
            info: {
                title: 'Info',
                createdOn: 'Créé sur',
                cron: 'Calendrier Cron',
                fields: 'Des champs',
                showFields: 'Afficher les champs',
                status: 'Statut',
                type: 'Taper',
                updatedOn: `Mis {'à'} jour le`
            },
            chart: {
                title: 'Données'
            },
            fields: {
                name: 'Nom',
                type: 'Taper',
                field: 'Champ'
            },
            history: {
                title: 'Histoire'
            }
        },
        ticketing: {
            notice: {
                message: 'Les données seront synchronisées tous les jours à 11h00 UTC et à 23h00 UTC. Cela peut prendre jusqu\'à une heure.'
            },
            averageOrderPrice: {
                title: 'Prix moyen de la commande',
                average: 'Prix moyen pour toutes les commandes'
            },
            gendersByAge: {
                title: 'Sexes par tranche d\'âge'
            },
            averageOrderReservation: {
                title: 'Délai moyen des réservations et des commandes',
                orderTime: 'Délai moyen de commande',
                reservationTime: 'Durée moyenne de réservation'
            }
        }
    }
} satisfies Translations;
