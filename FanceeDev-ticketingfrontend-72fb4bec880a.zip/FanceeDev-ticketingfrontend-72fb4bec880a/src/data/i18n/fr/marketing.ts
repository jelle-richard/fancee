import type { Translations } from '../types';

export default {
    title: 'Commercialisation',
    agenda: {
        plural: 'Ordres du jour',
        singular: 'Ordre du jour',
        title: '@:marketing.agenda.plural',
        table: {
            all: 'Tous actifs @.lower:event.plural'
        },
        deleteFailed: `Erreur rencontrée lors de la suppression de l'agenda. `,
        deleteSuccessful: `L'ordre du jour a été supprimé avec succès.`,
        loadingFailed: 'Erreur rencontrée lors de la récupération des agendas. ',
        loadingEventsFailed: `Une erreur s'est produite lors du chargement de vos événements. `,
        loadingSingleFailed: `L'ordre du jour est introuvable. `,
        savingFailed: `Une erreur s'est produite lors de la sauvegarde de l'agenda. `,
        savingSuccessful: `L'agenda a été enregistré avec succès.`,
        configure: {
            title: {
                create: 'Créer @.lower:marketing.agenda.singular',
                edit: 'Modifier @.lower:marketing.agenda.singular'
            },
            allEvents: 'Utilisez tous @.lower:event.plural',
            showHeaders: `Afficher les en-têtes d'événements`
        }
    },
    campaign: {
        plural: 'Campagnes',
        singular: 'Campagne',
        title: '@:marketing.campaign.plural',
        search: `Recherchez @.lower:{'marketing.campaign.plural'}...`,
        deleteConfirm: `Êtes-vous sûr de vouloir supprimer le @.lower:{'marketing.campaign.singular'} {0} ?`,
        deleteFailed: `Erreur rencontrée lors de la suppression du @.lower:{'marketing.campaign.singular'}. `,
        deleteSuccessful: `Votre @.lower:{'marketing.campaign.singular'} a été supprimé avec succès.`,
        exportFailed: `Une erreur s'est produite lors de l'exportation de votre @.lower:{'marketing.campaign.plural'}. `,
        loadingFailed: `Une erreur s'est produite lors de la récupération de votre @.lower:{'marketing.campaign.plural'}. `,
        table: {
            name: '@:marketing.campaign.singular',
            event: '@:event.singular',
            clicks: 'Clics',
            revenue: 'Revenu',
            productsSold: 'Produits vendus',
            averageAge: 'Âge moyen',
            genderSplit: 'Répartition des sexes',
            salesSplitTip: 'Les billets {productAmount} ont été vendus sur les commandes de {orderAmount} provenant des réservations de {reservationAmount}.'
        },
        configure: {
            title: 'Configurer @.lower:marketing.campaign.singular',
            loadingEventsFailed: `Une erreur s'est produite lors du chargement de vos événements. `,
            savingFailed: `Une erreur s'est produite lors de l'enregistrement du @.lower:{'marketing.campaign.singular'}. `,
            savingSuccessful: `Votre @.lower:{'marketing.campaign.singular'} a été enregistré. `,
            info: `Une URL de suivi @.lower:{'marketing.campaign.singular'} peut être attribuée {'à'} plusieurs boutiques {'à'} condition qu'elles fassent partie du même événement.`,
            eventsHint: `Existant @.lower:{'marketing.campaign.plural'} ne peut pas voir son événement modifié en raison de la collecte de statistiques; `,
            shopDisabledHint: `Veuillez d'abord sélectionner un événement.`
        }
    },
    preRegister: {
        title: '@:marketing.preRegister.plural',
        plural: 'Pré-inscriptions',
        singular: 'Pré-inscrire',
        search: `Recherchez @.lower:{'marketing.preRegister.plural'}...`,
        table: {
            name: '@:form.field.name',
            registered: 'Inscriptions',
            downloadCsv: 'Télécharger CSV',
            exportSecureShop: 'Boutique sécurisée export',
            expiresOn: 'Expire le'
        },
        deleteConfirm: `La suppression de ce @.lower:{'marketing.preRegister.singular'} supprimera également les entrées de registre associées.`,
        deleteFailed: `Le @.lower:{'marketing.preRegister.singular'} n'a pas pu être supprimé. `,
        deleteSuccessful: `Le @.lower:{'marketing.preRegister.singular'} {name} a été supprimé avec succès.`,
        downloadFailed: `Une erreur s'est produite lors du téléchargement de l'export @.lower:{'marketing.preRegister.singular'}. `,
        exportFailed: `Une erreur s'est produite lors de la récupération des inscriptions pour ce @.lower:{'marketing.preRegister.singular'}. `,
        exportFailedNoEntries: 'Il semble qu’aucune inscription ne soit disponible pour l’exportation pour le moment.',
        loadingFailed: `Une erreur s'est produite lors de la tentative de récupération de vos @.lower:{'marketing.preRegister.singular'}. `,
        configure: {
            createdSuccessfully: `Le @.lower:{'marketing.preRegister.singular'} pour {name} a été créé avec succès.`,
            saveFailed: `Une erreur s'est produite lors de l'enregistrement de votre @.lower:{'marketing.preRegister.singular'}. `,
            create: `Créez @.lower:{'marketing.preRegister.singular'}`,
            edit: `Modifier @.lower:{'marketing.preRegister.singular'}`,
            header: {
                title: 'Entête',
                description: 'Image utilisée pour l’en-tête du pré-enregistrement.'
            }
        },
        signUp: {
            complete: {
                title: 'Inscription terminée',
                message: 'Inscription terminée. '
            },
            expired: {
                title: 'Expiré',
                message: `La période @.lower:{'marketing.preRegister.singular'} a expiré. `
            },
            failed: `Une erreur s'est produite lors du chargement de votre pré-enregistrement. Veuillez réessayer plus tard.`
        }
    }
} satisfies Translations;
