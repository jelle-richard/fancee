import type { Translations } from '../types';

export default {
    title: 'GRC',
    navigation: {
        home: 'Aperçu',
        adminRegister: 'Registre administrateur',
        balance: 'Équilibre',
        channels: 'Canaux',
        eventBalance: `Solde de l'événement`,
        eventPlanning: `Planification d'événements`,
        integrations: 'Intégrations',
        invoicing: 'Facturation',
        orders: 'Ordres',
        organizations: 'Organisations',
        paymentMethods: 'Méthodes de payement',
        payouts: 'Paiements'
    },
    home: {
        title: 'Aperçu',
        statisticsFor: 'Statistiques pour {0}',
        failed: {
            loadingGlobalPlatformStatistics: 'Erreur rencontrée lors de la récupération des statistiques globales de la plateforme.',
            loadingGrowthTargets: 'Erreur rencontrée lors de la récupération de vos objectifs de vente.',
            loadingTicketRevenueIndication: `Une erreur s'est produite lors du chargement de l'indication des revenus des frais de billet.`
        },
        targetProgression: {
            newEvents: 'Nouveaux événements',
            newOrganizations: 'Nouvelles organisations',
            newUniqueBuyers: 'Nouveaux acheteurs uniques',
            placedOrders: 'Commandes passées',
            placedOrdersTip: '{placed} commandes ont été passées, dont {fulfilled} ont été exécutées.'
        },
        targets: {
            title: 'Cibles de la plateforme',
            subTitle: 'Objectifs de la plateforme pour mesurer la croissance.',
            ticketFeeThisMonth: 'Ce mois-ci : {0} / {1}',
            ticketFeeLastMonth: 'Le mois dernier : {0} / {1}',
            revenueAccomplished: `Chiffre d'affaires réalisé`,
            revenueTarget: 'Objectif de revenus',
            revenueToday: `Chiffre d'affaires aujourd'hui`,
            revenueYesterday: `Chiffre d'affaires hier`,
            topDailySoldProducts: 'Produits les plus vendus quotidiennement',
            tooltip: {
                ticketFeeRevenue: 'Revenus des frais de billetterie {0} / {1}',
                seatedTicketFeeREvenue: 'Revenus des frais de billets assis {0} / {1}',
                tickets: 'Billets {0} / {1}',
                seatedTickets: 'Billets assis {0} / {1}',
                organizations: 'Organisations {0} / {1}',
                events: 'Événements {0} / {1}',
                placedOrders: 'Commandes passées {0} / {1}',
                fulfilledOrders: 'Commandes exécutées {0} / {1}',
                uniqueBuyers: 'Acheteurs uniques {0} / {1}'
            }
        }
    },
    adminRegister: {
        title: 'Registre administrateur',
        choose: `Choisissez le rôle d'administrateur`,
        terminatesOn: 'Se termine le',
        countryManager: {
            createFailed: `Une erreur s'est produite lors de la tentative de création du responsable national.`,
            createSuccess: 'Le responsable national a été ajouté avec succès.',
            hint: 'Notez que la définition de la date de résiliation sur le responsable pays verrouille le compte après cette date.'
        },
        customerServiceEmployee: {
            createFailed: `Une erreur s'est produite lors de la tentative de création de l'employé du service client.`,
            createSuccess: `L'employé du service client a été ajouté avec succès.`,
            countryManager: 'Responsable pays',
            hint: `Notez que vous ne pouvez sélectionner qu'un seul responsable pays pour l'employé du service client pour le moment.`,
            missingCountryManagers: `Il n'y a actuellement aucun responsable pays disponible.`
        }
    },
    balance: {
        title: 'Équilibre',
        loadingFailed: 'Le chargement des soldes a échoué.',
        received: 'Reçu',
        revenue: 'Revenu',
        additionalCosts: 'Coûts additionnels',
        chargebacked: 'Facturé',
        chargebackFee: 'Frais de rétrofacturation',
        guestlistFee: `Frais de liste d'invités`,
        month: 'Mois',
        orders: 'Ordres',
        paymentFee: 'Frais de paiement',
        productFee: 'Frais de produit',
        productIncome: 'Revenu du produit',
        refunded: 'Remboursé',
        refundFee: 'Frais de remboursement',
        seatedTicketFee: 'Frais de billet assis',
        sms: 'SMS',
        ticketFee: 'Frais de billet',
        tickets: '@:event.ticketPlural',
        tsp: 'TSP'
    },
    eventBalance: {
        title: `Solde de l'événement`,
        loadingFailed: `Une erreur s'est produite lors du chargement des événements.`,
        table: {
            event: '@:event.singular',
            organization: 'Organisation',
            status: '@:event.statut.titre',
            scannedTickets: 'Billets scannés',
            fees: 'Frais',
            received: 'Reçu'
        },
        tip: {
            guestlistFee: `Frais de liste d'invités`,
            paymentFee: 'Frais de paiement',
            seatedTicketFee: 'Frais de billet assis',
            ticketFee: 'Frais de billet',
            tsp: 'TSP'
        }
    },
    eventPlanning: {
        title: `Planification d'événements`
    },
    integration: {
        title: 'Intégrations',
        configure: 'Configurer',
        connect: 'Connecter',
        exact: {
            title: 'Exact',
            description: 'Connectez-vous sur Exact en appuyant sur le bouton ci-dessous, vous serez redirigé après la connexion.',
            completed: 'Intégration exacte terminée.',
            loadingFailed: `Erreur lors de la récupération de l'URL de connexion exacte.`,
            loadingStatusFailed: 'Erreur de récupération si Exact est activé.',
            configure: {
                configureItems: 'Configurer les éléments',
                selectJournal: 'Sélectionnez le journal',
                disconnected: 'Exact n’est pas connecté.',
                loadingConfigurationFailed: 'Impossible de récupérer la configuration.',
                loadingItemsFailed: 'Impossible de récupérer les éléments.',
                loadingJournalsFailed: 'Impossible de récupérer les journaux.',
                loadingSpecificationNamesFailed: 'Impossible de récupérer les noms des spécifications de facture.'
            },
            mapping: {
                platform: 'Article de plateforme',
                exact: 'Code article exact',
                notMapped: 'Non cartographié',
                country: {
                    add: 'Ajouter une cartographie de pays',
                    remove: 'Supprimer la cartographie des pays'
                }
            }
        }
    },
    invoicing: {
        title: 'Facturation',
        search: 'Rechercher des factures...',
        downloadFailed: `Une erreur s'est produite lors du téléchargement du fichier des factures.`,
        loadingFailed: `Le système n'a pu récupérer aucune facture.`,
        loadingEventsFailed: `Une erreur s'est produite lors du chargement des événements.`,
        loadingOrganizationsFailed: `Une erreur s'est produite lors du chargement des organisations.`,
        filter: {
            event: '@:event.singular',
            eventSearch: '@:event.list.searchPlaceholder',
            organization: 'Organisation',
            organizationSearch: 'Rechercher des organisations...'
        },
        table: {
            number: 'Nombre',
            organization: 'Organisation',
            createdOn: 'Créé sur'
        }
    },
    order: {
        title: 'Ordres'
    },
    organization: {
        singular: 'Organisation',
        plural: 'Organisations',
        title: '@:crm.organization.plural',
        search: 'Rechercher des organisations...',
        downloadFailed: `Une erreur s'est produite lors du téléchargement du fichier des organisations.`,
        loadingFailed: `Une erreur s'est produite lors du chargement des organisations.`,
        filter: {
            date: '@:global.date',
            contractSigned: 'Contrat signé',
            isBlocked: 'Bloqué',
            isImportant: 'Important'
        },
        table: {
            name: '@:form.field.name',
            email: '@:form.field.email',
            annualSales: `Chiffre d'affaires annuel`,
            important: 'Important',
            verified: 'Vérifié',
            blocked: 'Bloqué',
            profileComplete: 'Profil terminé',
            lastLogin: 'Dernière connexion',
            phoneNumber: '@:form.field.phoneNumber'
        },
        single: {
            navigation: {
                account: 'Compte',
                monitoring: 'Surveillance',
                permissions: 'Autorisations',
                planning: `Planification d'événements`,
                wallet: 'Portefeuille'
            },
            contact: {
                title: 'Contacts'
            },
            contract: {
                title: 'Contracter',
                currentPackage: 'Forfait actuel',
                addAddendum: 'Addenda',
                updateContract: `Mettre {'à'} jour le contrat`,
                expiresOn: 'Expire le {0}',
                guestlistFee: `Frais de liste d'invités de {0}`,
                productFee: 'Frais de produit de {0} {1} %',
                seatedTicketFee: 'Frais de billet assis de {0} {1} %',
                ticketFee: 'Frais de billet de {0} {1} %',
                downloadFailed: '@:onboarding.agreement.downloadFailed',
                updateFailed: `Une erreur inconnue s'est produite lors de la tentative de mise {'à'} jour du type de package d'une organisation.`
            },
            info: {
                approximateAnnualSales: 'Ventes annuelles approximatives',
                contractSigned: 'Contrat signé',
                createdOn: 'Créé sur',
                important: 'Important',
                lastLogin: 'Dernière connexion',
                profileComplete: 'Profil terminé',
                verified: 'Vérifié',
                block: 'Bloquer un utilisateur',
                unblock: `Débloquer l'utilisateur`,
                blockFailed: `Une erreur s'est produite lors du blocage de l'utilisateur.`,
                blockSuccess: `L'utilisateur a été bloqué avec succès.`,
                unblockFailed: `Une erreur s'est produite lors du déblocage de l'utilisateur.`,
                unblockSuccess: `L'utilisateur a été débloqué avec succès.`,
                importantChangeFailed: `Une erreur s'est produite lors de la modification du statut important de l'utilisateur.`,
                accountTakeover: {
                    button: 'Entrer le compte',
                    info: `Veuillez saisir {'à'} nouveau votre mot de passe ci-dessous pour vous connecter en tant que cette organisation.`
                },
                accountStatus: 'Statut du compte',
                accountStatusUnfinished: 'Cette organisation s\'est inscrite mais n\'a pas encore complété son profil ni signé son contrat'
            },
            note: {
                title: 'Remarques',
                attachFiles: 'Joindre des fichiers...',
                createSuccess: 'La note a été créée avec succès.',
                deleteSuccess: 'La note a été supprimée avec succès.'
            },
            permissions: {
                loadingClaimsFailed: `Une erreur s'est produite lors de la récupération des revendications de la plateforme.`,
                loadingUserClaimsFailed: `Une erreur s'est produite lors de la récupération des réclamations des utilisateurs.`,
                savingUserClaimsFailed: `Une erreur s'est produite lors de l'enregistrement des revendications de l'utilisateur.`
            },
            planning: {
                search: 'Rechercher des événements...'
            },
            wallet: {
                search: 'Rechercher des opérations...'
            },
            invoice: {
                regenerateTitle: 'Générer une facture',
                regenerateExplanation: 'Générer manuellement une facture pour lorganisation (fonctionnalité de développement uniquement)'
            }
        },
        addAddendumOverlay: {
            title: 'Créer un addenda',
            info: `L'avenant que vous êtes sur le point de créer sera annexé au contrat actuel de l'organisation.`,
            notation: 'Veuillez noter que tous les frais sont indiqués en centimes.',
            createSuccess: `L'avenant a été ajouté avec succès au contrat de l'organisation.`,
            guestlistFee: `Frais de liste d'invités`,
            productFee: {
                percentual: 'Frais de produit en pourcentage',
                static: 'Frais de produit'
            },
            seatedTicketFee: {
                percentual: 'Frais de billet assis en pourcentage',
                static: 'Frais de billet assis'
            },
            ticketFee: {
                percentual: 'Frais de billet en pourcentage',
                static: 'Frais de billet'
            }
        },
        alterContractOverlay: {
            title: `Mettre {'à'} jour le contrat`
        }
    },
    paymentMethod: {
        title: 'Méthodes de payement',
        search: 'Rechercher des modes de paiement...',
        downloadFailed: `Une erreur s'est produite lors du téléchargement du fichier des modes de paiement.`,
        loadingFailed: `Les méthodes de paiement n'ont pas pu être chargées.`,
        table: {
            id: 'Identifiant',
            name: 'Nom',
            provider: 'Fournisseur',
            cost: 'Coût',
            limitedTo: `Limité {'à'}`
        }
    },
    payout: {
        title: 'Paiements',
        search: 'Rechercher des paiements...',
        export: 'Exporter',
        resolve: `Résoudre l'exportation en cours`,
        resolved: `L'exportation du paiement a été marquée comme résolue et les demandes de paiement sous-jacentes ont été mises {'à'} jour en conséquence.`,
        exportFailed: `Il n'y a actuellement aucune demande de paiement en attente, donc aucun fichier d'exportation ne peut être généré pour le moment.`,
        exportSuccess: `Vous avez lancé une procédure d'exportation des paiements.`,
        outstandingNotice: 'Il y a actuellement un paiement en attente de traitement. | Il y a actuellement {n} paiements en attente de traitement.',
        status: {
            created: 'Créé',
            processed: 'Traité'
        },
        table: {
            id: 'Identifiant',
            createdOn: 'Créé sur',
            status: 'Statut',
            markProcessed: 'Marque traitée'
        }
    }
} satisfies Translations;
