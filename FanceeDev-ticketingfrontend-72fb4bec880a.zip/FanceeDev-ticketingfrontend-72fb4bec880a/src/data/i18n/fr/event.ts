import type { Translations } from '../types';

export default {
    plural: 'Événements',
    singular: 'Événement',
    discountPlural: 'Réductions',
    discountSingular: 'Rabais',
    productPlural: 'Des produits',
    productSingular: 'Produit',
    shopPlural: 'Magasins',
    shopSingular: 'Boutique',
    ticketPlural: 'Des billets',
    ticketSingular: 'Billet',
    createEvent: 'Créer un évènement',
    manageEvent: `Gérer l'événement`,
    myEvents: 'Mes événements',
    list: {
        deletionFailed: `Impossible de supprimer l'événement "{0}".`,
        searchPlaceholder: 'Rechercher des événements...',
        table: {
            deactivated: 'Cette boutique est désactivée.',
            event: '@:event.singular',
            organization: 'Organisation',
            shops: '@:event.shopPlural',
            status: 'Statut'
        },
        emptyView: {
            title: `Pas d'événements`,
            message: `Aucun événement n'a encore été créé dans votre compte.`,
            add: '@:event.singular'
        }
    },
    discount: {
        title: 'Réductions',
        searchPlaceholder: 'Rechercher des réductions...',
        loadingEventsFailed: `Une erreur s'est produite lors du chargement de vos événements.`,
        loadingProductsFailed: `Une erreur s'est produite lors du chargement de vos produits.`,
        filter: {
            includeExpired: 'Inclure expiré',
            shops: '@:event.shopPlural',
            shopsSearchPlaceholder: `Recherchez @.lower :{'event.shopPlural'}...`
        },
        table: {
            code: 'Code',
            used: 'Utilisé',
            amount: 'Montant',
            expires: 'Expire'
        },
        deleteFailed: `Une erreur inconnue s'est produite lors de la tentative de suppression de la remise.`,
        getFailed: `Une erreur inconnue s'est produite lors de la récupération de votre réduction.`,
        listFailed: `Une erreur inconnue s'est produite lors de la récupération de vos remises.`,
        deleted: 'Remise supprimée avec succès.',
        saved: 'Remise enregistrée avec succès.',
        configurator: {
            title: {
                create: 'Créer @.lower:event.discountSingular',
                edit: 'Modifier @.lower:event.discountSingular'
            },
            expires: 'Expire',
            stock: 'Action',
            assignTo: {
                label: `Affecter {'à'}`,
                placeholder: `La réduction s'applique {'à'}...`,
                description: {
                    products: [
                        `Lors de l'attribution d'une remise fixe {'à'} un produit, le montant est déduit par produit dans la commande.`,
                        'Sélectionnez des événements pour trouver vos produits'
                    ],
                    shops: `Lors de l'attribution d'une remise {'à'} un magasin, le montant est déduit du total de la commande.`
                }
            },
            code: {
                label: 'Code',
                placeholder: '@:form.eg PRINTEMPS13'
            },
            value: {
                labelFixed: 'Remise fixe',
                labelPercentage: 'Pourcentage de remise'
            },
            validate: {
                assignmentRequirement: `Au moins un magasin ou un produit doit être affecté {'à'} la remise.`,
                valueRequirement: 'Il manque une valeur de remise statique ou en pourcentage.'
            }
        }
    },
    guestlist: {
        singular: 'Liste des invités',
        plural: `Listes d'invités`,
        title: '@:event.guestlist.plural',
        selector: {
            title: `Gérer les listes d'invités`,
            search: '@:event.list.searchPlaceholder'
        },
        empty: `Vous ne pouvez gérer les listes d'invités que pour les événements actifs.`,
        manage: {
            title: 'Modifier la liste des invités',
            onlyActiveEvents: `Les listes d'invités ne peuvent être envoyées qu'{'à'} des événements actifs.`,
            deduct: 'Déduire le stock',
            guest: 'Invité',
            hasHeader: 'CSV a un en-tête',
            failed: `Une erreur s'est produite lors de l'envoi de la liste des invités.`,
            success: 'Votre (vos) billet(s) invité(s) ont été envoyés avec succès.',
            manual: {
                title: 'Inviter'
            },
            import: {
                title: 'Importer',
                info: `Pour télécharger des invités en masse, veuillez télécharger un fichier CSV contenant, au minimum, l'adresse e-mail et la quantité de billets {'à'} envoyer.`,
                choose: 'Choisir le fichier',
                maxRows: 'Vous pouvez télécharger un fichier CSV avec un maximum de {0} adresses e-mail.',
                maxRowsExceeded: `Le nombre maximal d'importations de {0} listes d'invités a été dépassé.`,
                missingEmailField: `Aucun champ n'a été attribué comme email.`,
                missingQuantityField: `Aucun champ n'a été affecté comme quantité.`,
                table: {
                    example: 'Exemples de données',
                    field: 'Type de champ'
                }
            }
        }
    },
    ticket: {
        title: '@:event.ticketPlural',
        addBarcodes: 'Codes-barres',
        searchPlaceholder: `Recherchez @.lower:{'event.ticketPlural'}...`,
        table: {
            event: '@:event.singular',
            shop: '@:event.shopSingular',
            ticket: '@:event.ticketSingular',
            code: 'Code',
            origin: 'Origine',
            scanStatus: `État de l'analyse`,
            scanTime: 'Temps de balayage',
            holder: 'Titulaire',
            state: 'Statut'
        },
        filter: {
            acquirerOrigin: `Origine de l'acquéreur`,
            promotionalEmail: 'E-mail promotionnel',
            promotionalSms: 'SMS promotionnels',
            receiveOrderSms: 'Recevoir un SMS de commande',
            scanState: `État de l'analyse`
        },
        origin: {
            app: `Acquis via l'application @:global.platform.name`,
            generated: 'Généré par @:global.platform.name',
            guestlist: `Liste d'invités @: global.platform.name`,
            imported: 'Importé vers @:global.platform.name',
            shop: 'Acquis via la boutique @:global.platform.name',
            ticketswap: 'Acquis via TicketSwap',
            filter: {
                app: '@: application global.platform.name',
                generated: 'Généré',
                guestlist: `Liste d'invités @:global.platform.name`,
                imported: 'Importé',
                shop: 'Boutique @:global.platform.name',
                ticketswap: 'Échange de billets'
            }
        },
        single: {
            title: '@:event.ticketInformation singulière',
            info: {
                name: '@:event.ticketNom singulier',
                code: 'Code',
                markScanned: 'Marque numérisée',
                markUnscanned: 'Marquer comme non analysé',
                scanStatus: `État de l'analyse`,
                seatLocation: 'Emplacement du siège',
                viewOrder: `Voir l'ordre`,
                scanStateConfirm: `Souhaitez-vous mettre {'à'} jour l'état d'analyse du ticket {code} en {state} ?`,
                scanStateUpdated: `État de l'analyse mis {'à'} jour`,
                advanced: {
                    title: 'Options avancées',
                    invalidate: {
                        title: 'Invalider',
                        explanation: `Vous pouvez invalider un ticket pour qu'il ne puisse plus être utilisé`,
                        returnToStock: 'Retour en stock',
                        giveReason: 'Veuillez indiquer la raison pour laquelle le ticket est invalidé, le client recevra une notification avec cette raison',
                        failed: `Impossible d'invalider le ticket. Si le problème persiste, veuillez contacter le support pour obtenir de l'aide.`,
                        success: 'Invalidé le ticket'
                    }
                },
                ticketState: 'Statut du billet'
            },
            client: {
                title: 'Informations clients',
                belongsTo: `Appartient {'à'}`,
                boughtBy: 'Acheté par',
                boughtInShop: 'Acheté en boutique',
                enabledSms: 'SMS activé',
                enabledTsp: `Activé cuillère {'à'} café`,
                optins: {
                    label: 'Inscriptions promotionnelles',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            holder: {
                title: 'Informations sur le titulaire'
            }
        }
    },
    scanState: {
        notScanned: 'Non analysé',
        scanned: 'Numérisé',
        unscanned: 'Non analysé'
    },
    status: {
        title: `Statut de l'événement`,
        active: 'Actif',
        canceled: 'Annulé',
        cancelled: '@:event.status.annulé',
        concept: 'Concept',
        concluded: 'Conclu',
        soldOut: 'Épuisé',
        unpublished: 'Inédit'
    },
    addBarcodesOverlay: {
        title: 'Codes-barres',
        generate: 'Générer',
        import: 'Importer',
        selectEvent: 'Sélectionnez un événement...',
        selectProduct: 'Sélectionner un produit...',
        submitGenerate: 'Générer',
        submitImport: 'Importer',
        generateError: 'Erreur lors de la génération des codes-barres.',
        importError: `Erreur lors de l'importation des codes-barres.`,
        productLoadingFailed: 'Erreur lors du chargement des produits',
        importDuplicateFound: 'Des champs en double ont été trouvés.',
        importMax: `Un maximum de {amount} codes-barres peuvent être importés {'à'} la fois.`,
        importMissingBarcode: 'Un type de champ de code-barres est requis.',
        success: {
            title: 'Badcodes ajoutés',
            message: '{amount} nouveaux codes-barres ont été ajoutés avec succès.'
        },
        fieldType: {
            barcode: `code {'à'} barre`,
            email: '@:form.field.email',
            firstName: '@:form.field.firstName',
            lastName: '@:form.field.lastName'
        }
    },
    copyEventOverlay: {
        title: 'Copier {0}',
        info: 'Vous êtes sur le point de copier {0}, veuillez sélectionner les informations supplémentaires que vous souhaitez copier.',
        categories: {
            title: 'Catégories',
            description: 'Copiez toutes les catégories.'
        },
        paymentMethods: {
            title: 'Méthodes de payement',
            description: 'Copiez tous les modes de paiement.'
        },
        products: {
            title: 'Des produits',
            description: 'Copiez tous les produits.'
        },
        shops: {
            title: '@:event.shopPlural',
            description: `Copiez tout @.lower:{'event.shopPlural'}.`
        }
    },
    cancelOverlay: {
        title: `Annuler l'événement`,
        explanation: 'Notez que l’annulation de l’événement est une action permanente et irréversible.',
        giveReason: `Donnez une raison détaillée pour laquelle vous annulez l'événement.`,
        failed: `Une erreur s'est produite lors de l'annulation de votre événement, veuillez réessayer plus tard.`,
        success: `L'événement a été annulé avec succès.`
    },
    cancelPane: {
        title: 'Annuler',
        explanation: `Si vous choisissez d'annuler votre événement, il sera désactivé et aucun produit ne pourra plus être vendu.`,
        notice: '@:event.cancelOverlay.explication',
        submit: `Annuler l'événement`
    },
    unpublishPane: {
        title: 'Annuler la publication',
        explanation: `Si vous choisissez de dépublier votre événement, il sera temporairement désactivé jusqu'{'à'} ce que vous choisissiez de le publier {'à'} nouveau.`,
        submit: 'Annuler la publication'
    },
    create: {
        step: {
            type: 'Taper',
            details: 'Détails',
            products: '@:event.productPlural',
            shops: '@:event.shopPlural',
            payment: 'Paiement',
            mailing: 'Envoi postal',
            design: 'Conception de billets',
            publish: 'Publier'
        },
        details: {
            seatingEventId: `ID d'événement de placement`,
            categories: {
                label: 'Catégories',
                placeholder: 'Choisissez quelques catégories facultatives pour votre événement...'
            },
            header: {
                label: 'Entête',
                description: 'Images utilisées comme en-tête de votre événement.'
            },
            minimalAge: {
                hint: `Les événements avec des restrictions d'âge doivent demander l'âge des invités.`,
                label: 'Âge minimal',
                placeholder: '@:form.eg 16'
            },
            timezone: {
                info: 'Votre événement aura lieu dans le fuseau horaire {timezone}.',
                change: 'Utilisez un fuseau horaire différent.'
            },
            sealed: {
                label: 'Événement scellé',
                hint: 'Une fois que vous avez activé et enregistré les ventes d\'événements scellés, elles ne peuvent plus être désactivées',
                enabled: 'La livraison de billets scellés est activée pour cet événement'
            }
        },
        mailing: {
            title: 'Envoi postal',
            content: 'Contenu',
            mailType: 'Type de courrier',
            mailTypes: {
                guestlist: `E-mail d'invitation {'à'} la liste d'invités`,
                purchase: 'Acheter du courrier',
                sealed: 'Courrier de livraison de billets scellés'
            },
            senderName: `Nom de l'expéditeur`,
            senderNamePlaceholder: '@:global.platform.name',
            subject: 'Sujet',
            subjectPlaceholder: `Votre confirmation d'achat pour l'événement`,
            variables: {
                title: 'Variables',
                info: `Les e-mails peuvent contenir du texte personnalisé basé sur les variables ci-dessous, qui sera remplacé par des valeurs appropriées une fois l'e-mail envoyé.`
            },
            sealed: {
                title: 'Livraison de billets scellés',
                message: 'Vous avez activé la livraison de billets scellés pour votre événement et vous pouvez donc également modifier le courrier de livraison ci-dessous'
            }
        },
        paymentMethods: {
            title: 'Méthodes de payement',
            defaults: 'Vos paramètres de paiement par défaut sont actuellement appliqués.',
            paidByCustomer: 'Activé, payé par le client',
            paidByOrganization: `Activé, payé par l'organisation`,
            loadingFailed: `Une erreur s'est produite lors de la tentative de récupération de vos modes de paiement par défaut.`,
            klarnaInfo: 'Pour ce mode de paiement, le champ « adresse » doit être défini sur « obligatoire » dans les paramètres de la boutique.',
            psd2: {
                title: `Attention, la DSP2 peut s'appliquer {'à'} vous !`,
                paragraphs: [
                    `Selon la loi PSD2, il n'est pas toujours permis de facturer des frais de paiement {'à'} vos clients.`,
                    `L'une des dispositions de la PSD2 est l'interdiction des frais supplémentaires, ce qui signifie que les commerçants ne sont pas autorisés {'à'} facturer des frais supplémentaires {'à'} leurs clients pour l'utilisation de méthodes de paiement spécifiques, telles que les cartes de crédit ou de débit.`,
                    `Il convient de noter que même si la PSD2 s'applique {'à'} tous les États membres de l'UE, certains pays peuvent avoir mis en œuvre la loi différemment, de sorte que les règles exactes en matière de surcharge peuvent varier.`,
                    'Il existe quelques exceptions par pays, mais veuillez faire preuve de diligence raisonnable.'
                ]
            }
        },
        products: {
            add: {
                ticket: '@:global.add @.lower:event.ticketSingular',
                product: '@:global.add @.lower:event.productSingular'
            },
            configurator: {
                access: {
                    title: 'Accéder',
                    partial: {
                        label: 'Accès partiel',
                        hint: `Lorsque l'accès partiel est activé, les clients ne peuvent accéder {'à'} l'événement que dans le laps de temps imparti.`,
                        end: 'Fin',
                        start: 'Commencer'
                    }
                },
                advanced: {
                    title: 'Avancé',
                    ticketSwap: {
                        label: 'Échange de billets',
                        hint: 'Active SecureSwap du ticket sur TicketSwap.',
                        sealedSwapUnfinishedTitle: 'Échange TicketSwap impossible',
                        sealedSwapUnfinishedDescription: 'En raison de la fin des travaux sur TicketSwaps, TicketSwap ne peut pas être utilisé pour des événements scellés pour le moment, revenez plus tard.'
                    }
                },
                details: {
                    title: 'Détails',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Réservation anticipée'
                    },
                    description: {
                        label: '@:form.field.description',
                        placeholder: '@:form.eg Vous offre le meilleur endroit sur notre site.'
                    }
                },
                images: {
                    title: 'Images'
                },
                salesFlow: {
                    title: 'Flux de vente',
                    administrationFee: {
                        label: `Frais d'administration`,
                        hint: 'Il s’agit des frais que vous ajoutez au prix du billet.'
                    },
                    maxOrderQuantity: {
                        label: 'Quantité maximale de commande'
                    },
                    packQuantity: {
                        labelProduct: 'Montant',
                        labelTicket: 'Nombre de codes-barres dans le ticket de groupe',
                        hint: 'Le produit est vendu selon la quantité indiquée.'
                    },
                    dateTime: {
                        title: 'Date et heure',
                        hint: 'Vendez votre produit pendant la plage de dates spécifiée.',
                        saleEnd: 'Fin de la vente',
                        saleStart: 'Début de la vente'
                    },
                    waveLink: {
                        title: 'Lien vague',
                        hint: 'Vendez votre produit une fois que le produit sélectionné a 10 % de stock restant.',
                        linkedTicket: 'Billet lié',
                        circular: `Cette combinaison de liens d'onde n'est pas possible.`,
                        disabled: `Vous devez disposer d'au moins deux produits pour que cette fonctionnalité fonctionne.`
                    }
                },
                scanning: {
                    title: 'Balayage',
                    notification: {
                        label: 'Notification',
                        placeholder: `@:form.eg Donnez 5 pièces {'à'} l'arrivée.`
                    },
                    preArrivalThreshold: {
                        label: 'Seuil de pré-arrivée',
                        hint: `Permet aux clients d'arriver le nombre de minutes donné avant le début de leur accès.`
                    }
                },
                hint: {
                    title: `Plus d'options de produits`,
                    description: `Il existe encore plus d'options pour vos produits, cliquez sur l'icône d'engrenage d'un produit pour les révéler.`
                }
            },
            empty: {
                title: '@:event.productPlural',
                description: [
                    `Commencez {'à'} constituer l’inventaire de votre boutique en ajoutant des billets et/ou des produits.`,
                    `Une fois que vous avez fini de créer tous vos billets et/ou produits, vous pourrez les attribuer et les concevoir {'à'} l'étape suivante.`
                ]
            },
            group: {
                products: '@:event.productPlural',
                seatedTickets: 'Assis @.lower:event.ticketPlural',
                tickets: '@:event.ticketPlural'
            },
            new: {
                product: 'Nouveau @.lower:event.productSingular',
                ticket: 'Nouveau @.lower:event.ticketSingular'
            },
            row: {
                name: {
                    label: '@:form.field.name',
                    placeholder: '@:event.create.products.configurator.details.name.placeholder'
                },
                price: {
                    label: '@:form.field.price',
                    changement: `Veuillez noter que vous êtes sur le point de modifier le prix d'un billet déj{'à'} vendu. Pensez {'à'} créer un nouveau billet pour les billets au nouveau tarif.`
                },
                seats: {
                    label: 'Des places'
                },
                stock: {
                    label: '@:form.field.stock',
                    placeholder: '@:form.eg 100'
                }
            }
        },
        publish: {
            notReady: {
                title: `Presque l{'à'}`,
                info: `Votre événement est presque prêt {'à'} être publié.`,
                missingPaymentMethods: {
                    action: 'Configurer les modes de paiement',
                    message: `Aucun mode de paiement n'est configuré pour votre événement.`
                },
                missingSellableProducts: {
                    action: 'Configurer les boutiques',
                    message: `Votre événement a besoin d'au moins une boutique proposant des produits vendables.`
                }
            },
            ready: {
                title: `Prêt {'à'} publier !`,
                info: `Tout est prêt {'à'} être publié.`,
                requestReview: 'Demander un examen',
                requestReviewPending: 'Avis demandé, un de nos collaborateurs vous contactera.'
            },
            scanning: {
                title: 'Balayage',
                paragraphs: [
                    `Besoin d'aide pour numériser ?`,
                    'Intéressé? '
                ],
                submit: 'Instructions de téléchargement',
                file: 'Instructions de numérisation'
            },
            status: {
                canceled: 'Cet événement a été annulé.',
                unpublished: 'Cet événement est inédit.',
                soldIn: `Vendu {'à'} : {0}`,
                soldNowhere: 'Non vendu nulle part'
            }
        },
        seatingSetup: {
            title: 'Configuration des sièges',
            explanation: `Notre équipe d'assistance effectuera la configuration initiale de cet événement pour vous.`,
            failed: {
                title: 'Validation échouée',
                message: `Nous avons eu du mal {'à'} contacter SeatsIO pour valider l'événement.`,
                notice: 'L’ID d’événement SeatsIO donné n’est pas valide.'
            },
            setupId: '@:event.create.details.seatingEventId'
        },
        shops: {
            designer: 'Designer',
            default: {
                buttonLabel: 'Nouveau bouton',
                noticeContent: `Ceci est un texte d'espace réservé pour l'avis, veuillez saisir votre message.`,
                shopName: 'Nouvelle boutique',
                textBlockText: `Un élément de texte peut être utilisé pour fournir {'à'} vos clients des informations supplémentaires sur vos produits, n'oubliez pas de remplacer cet exemple par votre propre saisie.`,
                textBlockTitle: 'Information'
            },
            element: {
                accordion: {
                    icon: 'Icône',
                    opened: 'Ouvert par défaut',
                    title: 'Titre',
                    titlePlaceholder: '@:form.eg Billets de bus'
                },
                divider: {
                    title: 'Titre',
                    titlePlaceholder: '@:form.eg Tickets de stationnement'
                },
                externalLink: {
                    text: 'Texte',
                    textPlaceholder: '@:form.eg Visitez notre site Web',
                    url: 'URL',
                    urlPlaceholder: '@:form.eg https://wearefancee.com'
                },
                notice: {
                    message: 'Message',
                    messagePlaceholder: `@:form.eg Gardez {'à'} l'esprit qu'il est obligatoire d'apporter votre pièce d'identité.`,
                    variant: 'Une variante',
                    variants: {
                        danger: 'Danger',
                        info: 'Information',
                        success: 'Succès',
                        warning: 'Avertissement'
                    }
                },
                textBlock: {
                    title: 'Titre',
                    titlePlaceholder: '@:form.eg Informations sur la santé',
                    text: 'Texte',
                    textPlaceholder: `@:form.eg L'eau potable est essentielle {'à'} une bonne santé.`
                }
            },
            insert: {
                accordion: 'Accordéon',
                divider: 'Diviseur',
                link: 'Lien',
                notice: 'Avis',
                product: 'Produit',
                seating: 'Plan de salle',
                text: 'Texte',
                ticket: 'Billet'
            },
            newShop: {
                title: 'Nouvelle boutique',
                message: 'Choisissez un nom pour votre boutique.',
                label: 'Nom',
                placeholder: '@:form.eg Boutique de prévente'
            },
            noElements: {
                title: 'Concevez votre boutique',
                message: `Ajoutez des éléments ci-dessous et donnez vie {'à'} votre vision.`
            },
            configurator: {
                defaultPalette: {
                    loadingFailed: `Une erreur s'est produite lors de la tentative de récupération de votre palette par défaut.`,
                    savingFailed: `Une erreur s'est produite lors de la tentative d'enregistrement de votre palette par défaut.`
                },
                colors: {
                    title: 'Couleurs',
                    background: 'Arrière-plan',
                    panel: 'Panneau',
                    primary: 'Primaire',
                    text: 'Texte'
                },
                details: {
                    title: 'Détails',
                    endDate: 'Date de fin',
                    active: 'Actif',
                    startDate: 'Date de début',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Pré-vente'
                    }
                },
                fields: {
                    title: 'Des champs',
                    info: 'Précisez les informations que vous souhaitez obtenir de vos invités.',
                    address: '@:form.field.adresse',
                    city: '@:form.field.addressCity',
                    birthdate: '@:form.field.birthdate',
                    birthdateRequired: 'La date de naissance est obligatoire car votre événement a un âge minimum.',
                    email: '@:form.field.email',
                    firstName: '@:form.field.firstName',
                    gender: '@:form.field.gender',
                    lastName: '@:form.field.lastName',
                    phoneNumber: '@:form.field.phoneNumber'
                },
                images: {
                    title: 'Images',
                    header: 'Entête'
                },
                marketing: {
                    title: 'Commercialisation',
                    googleAnalyticsId: {
                        label: 'Identifiant Google Analytics',
                        placeholder: '@:form.eg G-XXXXXXXXXX'
                    },
                    googleTagManagerId: {
                        label: 'Identifiant Google Tag Manager',
                        placeholder: '@:form.eg GTM-XXXXXX'
                    },
                    tiktokPixelId: {
                        label: 'Identifiant TikTok',
                        placeholder: '@:form.eg ABCDEFGHIJK123456789'
                    },
                    facebookPixelId: {
                        label: 'Identifiant Facebook Pixel',
                        placeholder: '@:form.eg 12345678912345678',
                        accessToken: `Jeton d'accès Facebook`,
                        required: 'Les deux entrées Facebook sont requises'
                    }
                }
            }
        },
        ticketDesign: {
            title: 'Concepteur de billets',
            info: 'Il s’agit du modèle utilisé dans le fichier PDF du ticket.',
            assigned: 'Billets attribués',
            hasDesign: 'A un design',
            unAssigned: `Certains tickets n'ont pas de design, ceux-ci utiliseront le design par défaut de la plateforme.`,
            uploadImage: `Télécharger l'image...`,
            designs: {
                title: 'Dessins',
                info: 'Cliquez pour modifier ou en ajouter un nouveau.',
                warning: 'Les designs qui ne sont pas attribués aux tickets seront supprimés.'
            },
            unattachedFound: {
                title: 'Modèles de tickets non attachés trouvés',
                message: 'Des modèles de billets sans billets attachés ont été trouvés. Lorsque vous appuyez sur Continuer, ces modèles seront supprimés.'
            },
            upcomingEvents: {
                title: `Évènements {'à'} venir`,
                anotherEvent: 'Un autre événement',
                nEvents: 'Afficher aucun événement | Afficher un événement | Afficher {n} événements'
            },
            useDefault: 'Aucun design détecté, appuyer sur Continuer fera que les tickets utiliseront la présentation par défaut de la plateforme.',
            empty: {
                title: '@:event.create.ticketDesign.title',
                description: [
                    `Commencez {'à'} concevoir vos billets et vos produits. Vos billets peuvent être conçus comme bon vous semble. Placez des images sur votre billet et/ou affichez les événements {'à'} venir.`,
                    `Une fois que vous avez terminé de créer tous vos modèles de tickets, vous pouvez sélectionner le ticket que vous souhaitez attribuer {'à'} quel modèle.`
                ]
            }
        },
        type: {
            normal: {
                title: 'Normale',
                description: 'Convient aux besoins standards de vente et/ou de fourniture de billets d’entrée.'
            },
            seated: {
                title: 'Assise',
                description: `Attribuez des tickets {'à'} rechercher {'à'} l’aide d’une carte interactive.`
            },
            timeslotted: {
                title: 'Plage horaire',
                description: 'Permet de planifier des billets sur certaines plages horaires.'
            }
        }
    },
    secureCode: {
        plural: 'Codes sécurisés',
        singular: 'Code de sécurité',
        secureShop: 'Sécurisé @.lower:event.shopSingular',
        alterShopSecure: `Modifier l'état sécurisé`,
        search: 'Rechercher des codes...',
        table: {
            code: 'Code',
            createdOn: 'Créé sur',
            uses: 'Les usages',
            deleteAllFailed: `Erreur rencontrée lors de la suppression de tous les @.lower:{'event.secureCode.plural'} inutilisés.`,
            deleteAllSuccess: `Suppression réussie de tous les @.lower:{'event.secureCode.plural'} inutilisés.`,
            deleteFailed: `Erreur rencontrée lors de la suppression du @.lower:{'event.secureCode.singular'}.`,
            deleteSuccess: `Le @.lower:{'event.secureCode.singular'} a été supprimé avec succès.`,
            downloadFailed: `Une erreur s'est produite lors du téléchargement de l'export @.lower:{'event.secureCode.plural'}.`,
            loadingFailed: `Une erreur s'est produite lors du chargement du @.lower:{'event.secureCode.plural'}.`,
            loadingShopFailed: `Une erreur s'est produite lors du chargement de la boutique.`,
            codeUsages: '{usedAmount}{slash}{maximumUses} ont été utilisés, dont {endingAmount} sont en attente de réservation'
        },
        add: {
            title: 'Ajouter @:event.secureCode.plural',
            pleaseFix: 'Veuillez corriger ce qui suit',
            manual: 'Manuel',
            maxUses: 'Utilisations maximales',
            maxUsesHint: 'Laissez vide pour des utilisations maximales illimitées.',
            noneSelected: `Aucun @:event.secureCode.plural n'a été sélectionné.`,
            noMaxUsesSelected: 'Aucune utilisation maximale sélectionnée.',
            duplicates: 'Des doublons ont été trouvés.',
            failed: 'Impossible de créer un nouveau @:event.secureCode.singular, contactez le support si le problème persiste.',
            success: `Le nouveau @:{'event.secureCode.singular'} a été ajouté avec succès.`,
            import: {
                title: 'Importer',
                failed: `Impossible d'importer @:{'event.secureCode.plural'}, contactez le support si le problème persiste.`,
                success: 'Nouveau @:event.secureCode.plural importé avec succès'
            }
        },
        set: {
            title: `Définir l'état sécurisé`,
            info: `Lorsque vous marquez une boutique comme boutique sécurisée, vous pouvez éventuellement définir une date d'expiration.`,
            state: 'État sécurisé',
            until: `Sécurisé jusqu'{'à'}`,
            failed: `Une erreur inconnue s'est produite lors de la sauvegarde de l'état sécurisé de la boutique.`,
            success: `L'état sécurisé a été enregistré avec succès.`
        },
        import: {
            title: 'Importer en tant que @.lower:event.secureCode.plural',
            info: `Veuillez sélectionner une boutique pour laquelle vous souhaitez importer les pré-enregistrements {0} avec {1} sous forme de codes sécurisés {'à'} usage unique.`,
            selectShop: 'Sélectionnez la boutique...',
            submit: 'Importer',
            failed: `L'importation de @.lower:event.secureCode.plural a échoué.`,
            success: `L'importation de @.lower:event.secureCode.plural a réussi.`
        }
    }
} satisfies Translations;
