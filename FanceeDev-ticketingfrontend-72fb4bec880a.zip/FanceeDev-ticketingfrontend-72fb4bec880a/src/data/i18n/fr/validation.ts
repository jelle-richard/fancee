import type { Translations } from '../types';

export default {
    errors: {
        message: `Veuillez corriger les erreurs dans le formulaire avant de procéder {'à'} la soumission.`,
        pleaseFix: 'Veuillez corriger les éléments suivants',
        pleaseFixErrors: `S'il vous plait, corrigez les erreurs suivantes`
    },
    validator: {
        afterDate: `La date doit être postérieure {'à'} {formattedDateTime}`,
        alpha: 'Veuillez saisir uniquement des caractères alphabétiques.',
        alphaNum: 'Veuillez saisir une valeur contenant uniquement des lettres et des chiffres.',
        beforeDate: `La date doit être antérieure {'à'} {formattedDateTime}`,
        between: 'Veuillez saisir un nombre compris entre {min} et {max} inclus.',
        betweenDates: 'La date doit être comprise entre {formattedMinDate} et {formattedMaxDate}',
        decimal: 'Veuillez saisir une valeur décimale valide.',
        email: `S'il vous plaît, mettez une adresse email valide.`,
        future: 'Veuillez entrer une date future.',
        integer: 'Veuillez saisir un nombre entier.',
        ipAddress: 'Veuillez saisir une adresse IP valide.',
        macAddress: 'Veuillez saisir une adresse MAC valide.',
        maxPrice: `Veuillez saisir un montant inférieur ou égal {'à'} {formattedMaxPrice}.`,
        maxLength: `Veuillez saisir une valeur d'une longueur maximale de {max} caractères.`,
        maxValue: `Veuillez saisir un nombre inférieur ou égal {'à'} {max}.`,
        minLength: `Veuillez saisir une valeur d'une longueur minimale de {min} caractères.`,
        minValue: `Veuillez saisir un nombre supérieur ou égal {'à'} {min}.`,
        numeric: 'Veuillez saisir une valeur numérique valide.',
        past: 'Veuillez entrer une date passée.',
        phoneNumber: `S'il vous plaît entrer un numéro de téléphone valide.`,
        price: 'Veuillez saisir un prix valide avec une valeur décimale.',
        required: 'Ce champ est obligatoire.',
        requiredIf: 'Ce champ est obligatoire.',
        requiredUnless: 'Ce champ est obligatoire.',
        sameAs: `Veuillez vous assurer que ce champ est le même que l'autre champ.`,
        url: 'Veuillez saisir une URL valide.',
        minTextLength: '@: validation.validator.minLength',
        secureCode: `Veuillez saisir une valeur contenant uniquement des lettres, des chiffres ou l\'un des caractères suivants: . {'@'} _-.`
    }
} satisfies Translations;
