import type { Translations } from '../types';

export default {
    title: 'Application',
    scanStatistics: {
        title: `Statistiques d'analyse`
    },
    team: {
        plural: `Équipes d'application`,
        singular: `Équipe d'application`,
        title: '@:app.team.plural',
        search: `Rechercher des équipes d'applications...`,
        emptyView: `Il semble que votre compte ne comporte aucune équipe d'application.`,
        createFailed: `L'équipe de l'application n'a pas pu être créée.`,
        createSuccess: `L'équipe de l'application a été créée avec succès.`,
        deleteFailed: `L'équipe de l'application n'a pas pu être supprimée.`,
        deleteSuccess: `L'équipe de l'application a été supprimée avec succès.`,
        updateFailed: `L'équipe de l'application n'a pas pu être modifiée.`,
        downloadFailed: `Une erreur s'est produite lors du téléchargement de vos équipes d'application.`,
        loadingFailed: `Une erreur s'est produite lors de la récupération de vos équipes d'application.`,
        loadingEventsFailed: `Une erreur s'est produite lors du chargement de vos événements.`,
        loadingProductsFailed: `Une erreur s'est produite lors du chargement de vos produits.`,
        loadingSingleFailed: `Une erreur s'est produite lors de la récupération de votre équipe d'application.`,
        table: {
            name: '@:form.field.name',
            rights: 'Droits',
            qr: 'QR Code'
        },
        right: {
            guestlists: '@:event.guestlist.plural',
            scanning: 'Analyse',
            sales: 'Ventes',
            statistics: 'Statistiques',
            cash: 'Espèces'
        },
        configure: {
            title: {
                edit: 'Modifier {0}',
                new: `Créer une équipe d'application`
            }
        },
        statistics: {
            title: `Afficher les statistiques d'analyse`,
            loadingFailed: `Une erreur s'est produite lors de la récupération des statistiques d'événement.`,
            loadingTeamFailed: `Une erreur s'est produite lors de la récupération des statistiques de l'équipe de l'application.`,
            selectAppTeam: `Sélectionnez une équipe d'application...`,
            selectEvent: 'Sélectionnez un événement...',
            event: {
                title: 'Statistiques des événements',
                subTitle: `Statistiques d'analyse par ticket`,
                remaining: 'Restant',
                scanned: 'Numérisé'
            },
            team: {
                title: `Temps d'analyse`,
                subTitle: `Temps d'analyse de l'équipe chargée de l'application`,
                scanned: 'Numérisé',
                unscanned: 'Non analysé',
                dateHint: `Modifiez la date ou l'heure pour afficher les statistiques d'analyse {'à'} partir de cette heure.`,
                empty: `Aucune donnée d'analyse n'a été trouvée pour l'équipe d'application sélectionnée ou pour la date choisie.`
            }
        }
    }
} satisfies Translations;
