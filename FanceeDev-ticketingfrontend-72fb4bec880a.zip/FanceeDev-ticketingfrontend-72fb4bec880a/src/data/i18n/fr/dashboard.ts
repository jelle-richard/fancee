import type { Translations } from '../types';

export default {
    emptyView: {
        title: 'Rien ici',
        message: `Il semble qu'aucun événement n'ait été trouvé pour votre compte et, par conséquent, aucune statistique n'est disponible.`
    },
    monitor: {
        title: 'Surveillez vos événements',
        subTitle: 'Veuillez choisir un événement pour avoir un aperçu de votre position sur le marché.',
        select: 'Sélectionnez un événement...'
    },
    statistics: {
        loadingFailed: `Aucune statistique n'a pu être récupérée.`,
        notEnoughData: `Il semble que l'événement n'ait pas encore généré de statistiques significatives.`,
        averageAge: {
            title: 'Âge moyen',
            tip: {
                female: 'Âge moyen des clientes féminines: {0} ans.',
                male: 'Âge moyen des clients masculins de {0} ans.',
                neutral: 'Âge moyen neutre des clients de {0} ans.',
                unknown: 'Âge moyen des clients inconnus de {0} ans.'
            }
        },
        fulfilledOrders: {
            title: 'Commandes exécutées',
            tip: '{0} commandes exécutées.'
        },
        pendingRefunds: {
            title: 'Remboursements en attente',
            tip: '{0} total des remboursements en attente.'
        },
        productsSold: {
            title: 'Produits vendus',
            tip: '{0} produits au total vendus.'
        },
        ticketsScanned: {
            title: 'Billets scannés',
            tip: '{0} billets au total analysés.'
        },
        uniqueCustomers: {
            title: 'Clients uniques',
            tip: {
                female: '{0} clientes féminines uniques.',
                male: '{0} clients masculins uniques.',
                neutral: '{0} clients neutres uniques.',
                unknown: '{0} client inconnu unique.'
            }
        },
        finance: {
            cashSalesRevenue: `Chiffre d'affaires des ventes au comptant`,
            onlineSalesRevenue: `Chiffre d'affaires des ventes en ligne`,
            platformExpenses: 'Dépenses de la plateforme',
            profit: 'Profit'
        },
        bestSellingProducts: {
            title: 'Produits phares',
            subTitle: 'Produits les plus vendus des {0} derniers jours.'
        },
        dailyOrders: {
            title: 'Revenus des commandes',
            subTitle: 'Aperçu des commandes terminées quotidiennement.',
            ordersOnDay: 'Commandes le jour même',
            cashRevenue: 'Recettes en espèces',
            onlineRevenue: 'Revenus en ligne',
            orders: 'Ordres',
            productsSold: 'Produits vendus',
            revenueFlow: 'Flux de revenus'
        },
        productRatio: {
            title: 'Rapport produit',
            subTitle: 'Flux de produits en fonction du montant.'
        },
        productStatistics: {
            guest: 'Invité',
            guestlistTip: `Veuillez garder {'à'} l’esprit que les billets invités ne sont pas toujours déduits du stock.`,
            name: '@:form.field.name',
            pending: 'En attente',
            pendingTip: '{0} réservations sont en attente et {1} est actuellement en cours de paiement.',
            price: '@:form.field.price',
            remaining: 'Restant',
            sold: '@: global.vendu',
            stock: '@:form.field.stock'
        }
    },
    wallet: {
        title: 'Solde du portefeuille',
        manage: 'Gérer'
    }
} satisfies Translations;
