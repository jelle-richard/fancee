import type { Translations } from '../types';

export default {
    navigation: {
        blockedEmails: 'E-mails bloqués',
        defaultPaymentMethods: 'Modes de paiement par défaut',
        defaultShopPalette: 'Conception de boutique par défaut',
        roleManagement: 'Gestion des rôles'
    },
    blockedEmails: {
        add: 'Ajouter un e-mail bloqué',
        addSuccess: '{0} a été bloqué avec succès.',
        deleteEverythingConfirm: 'Cette action supprimera tous les e-mails bloqués de votre compte.',
        deleteEverythingFailed: `Une erreur s'est produite lors de la tentative de suppression de tous les e-mails bloqués. `,
        deleteEverythingSuccess: 'Tous les e-mails bloqués ont été supprimés avec succès.',
        deleteFailed: `Une erreur s'est produite lors de la tentative de suppression d'un e-mail bloqué. `,
        deleteSuccess: 'E-mail bloqué supprimé avec succès.',
        loadingFailed: `Une erreur s'est produite lors du chargement des e-mails bloqués. `
    },
    defaultPaymentMethods: {
        loadingFailed: `Une erreur s'est produite lors de la tentative de récupération de vos modes de paiement par défaut. `,
        savingFailed: `Une erreur s'est produite lors de la tentative d'enregistrement de vos modes de paiement par défaut. `
    },
    defaultShopPalette: {
        title: 'Conception de boutique par défaut',
        description: 'Enregistrez les couleurs de votre marque comme palette par défaut pour une application facile dans vos magasins.',
        background: 'Arrière-plan',
        panel: 'Panneau',
        primary: 'Primaire',
        text: 'Texte'
    },
    roleManagement: {
        title: 'Gestion des rôles',
        notice: `L'attribution de rôles {'à'} des utilisateurs externes vous permet de donner accès {'à'} certaines parties du compte de votre organisation. `,
        addFailed: `Une erreur inconnue s'est produite lors de l'attribution de l'utilisateur. `,
        addSuccess: `L'utilisateur a été ajouté avec succès {'à'} l'organisation.`,
        deleteFailed: `Une erreur inconnue s'est produite lors de la suppression de l'utilisateur. `,
        deleteSuccess: `L'utilisateur a été supprimé avec succès de l'organisation.`,
        loadingFailed: `Une erreur inconnue s'est produite lors du chargement de vos utilisateurs. `,
        updateFailed: `Une erreur inconnue s'est produite lors de la mise {'à'} jour de l'utilisateur attribué. `,
        configure: {
            title: {
                add: 'Ajouter un nouvel utilisateur',
                edit: 'Modifier {0}'
            },
            rights: 'Droits',
            chargementFailed: `Une erreur inconnue s'est produite lors du chargement de vos réclamations. Veuillez contacter le support si ce problème persiste.`
        }
    }
} satisfies Translations;
