import type { Translations } from '../types';

export default {
    lastOrder: {
        title: 'Votre dernière commande',
        placedOn: 'Placé le {0}'
    },
    dashboard: {
        loadingFailed: `Nous n'avons pas pu charger vos commandes.`,
        emptyView: {
            title: 'Rien ici',
            message: `Aucune commande n'a pu être trouvée pour votre compte.`
        }
    },
    ticket: {
        eventName: 'Événement',
        startDate: 'Date',
        loadingFailed: 'Impossible de charger vos billets.',
        emptyView: {
            title: 'Rien ici',
            message: `Si vous êtes certain d'avoir droit {'à'} des billets pour un événement {'à'} venir, veuillez vérifier vos commandes.`,
            action: 'Afficher les commandes'
        },
        sealed: {
            message: 'Ces billets sont scellés et seront disponibles {0} heures avant le début de l\'événement.',
            saleButton: 'Vendre sur TicketSwap'
        }
    }
} satisfies Translations;
