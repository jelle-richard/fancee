import type { Translations } from '../types';

export default {
    agreement: {
        title: 'Finalisez votre accord',
        intro: `Dans cette étape finale, nous formaliserons notre engagement {'à'} travailler ensemble par le biais d'un contrat clair et concis. `,
        disclaimer: 'En signant ici, vous reconnaissez avoir lu le contrat dans son intégralité et en accepter le contenu.',
        negotiate: `Si votre organisation nous a déj{'à'} contacté et négocié des frais ou des conditions de douane, veuillez attendre cette étape pendant que nous mettons {'à'} jour le contrat pour refléter ces accords.`,
        sign: 'Signer le contrat',
        signOverlayTitle: 'Signe',
        alreadySigned: `Vous avez déj{'à'} terminé le processus de signature du contrat.`,
        contactSales: 'Contacter le service commercial',
        downloadFailed: 'Impossible de télécharger votre contrat. '
    },
    company: {
        title: 'Parlez-nous de votre organisation',
        intro: 'Plongeons maintenant au cœur de votre organisation. ',
        supportContact: 'Contact d assistance',
        optionalSupportContact: 'Contact d assistance facultatif',
        supportContactExplanation: `Les détails du support client sont utilisés par le système pour communiquer {'à'} vos clients comment vous contacter. Si laissé vide, les détails par défaut seront utilisés. Vous avez également la possibilité de modifier cela ultérieurement dans votre profil.`,
    },
    financial: {
        title: 'Configurez vos finances',
        intro: 'Dans cette étape, nous organiserons les aspects financiers pour garantir des transactions fluides. ',
        ibanInfo: 'Si vous avez un IBAN, utilisez-le. ',
        approximateAnnualSales: 'Ventes annuelles approximatives',
        approximateAnnualSalesPlaceholder: 'Combien de billets comptez-vous vendre ?'
    },
    personal: {
        title: 'Laissez-vous opérationnel !',
        intro: 'Nous sommes ravis de mieux vous connaître, vous et votre organisation. '
    },
    welcome: {
        title: `Let's get Fancee!`,
        intro: `Maintenant que nous avons réglé votre contrat, n'hésitez plus et commencez {'à'} vendre des billets quand vous en avez envie ! `,
        start: `Commencer {'à'} vendre`
    }
} satisfies Translations;
