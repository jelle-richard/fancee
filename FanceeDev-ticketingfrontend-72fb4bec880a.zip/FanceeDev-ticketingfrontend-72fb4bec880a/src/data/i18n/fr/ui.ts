import type { Translations } from '../types';

export default {
    changesSavedSuccessfully: 'Changements sauvegardés avec succès.',
    accountTakeoverNotice: {
        info: 'Actuellement connecté en tant que {0}, tout ce que vous faites affecte ce compte.',
        switchBack: `Revenez {'à'} {0}.`
    },
    confirmDeleteOverlay: {
        title: 'Supprimer {0} ?',
        titleAll: 'Tout supprimer ?',
        titleGeneric: 'Confirmation de la suppression',
        message: 'Êtes-vous vraiment sûr de vouloir supprimer "{0}" ?',
        messageGeneric: `Etes-vous vraiment sûr de vouloir supprimer l'entrée ?`
    },
    countrySelectOverlay: {
        title: 'Quels pays souhaitez-vous gérer ?',
        selection: '{0} sur {1}',
        checkAll: 'Gérer tous les pays'
    },
    focalPoint: {
        editor: {
            title: 'Éditeur de points focaux',
            subTitle: 'Faites glisser le cercle vers le point focal souhaité pour chacune de vos images.'
        },
        singular: 'Point focal',
        plural: 'Points focaux'
    },
    notAllowed: {
        title: 'Interdit',
        message: `Votre compte ne dispose pas des autorisations nécessaires pour effectuer l'action demandée.`
    },
    notFound: {
        record: `L'enregistrement demandé est introuvable.`,
        page: {
            title: 'Page non trouvée',
            content: `L'URL demandée n'a pas été trouvée sur ce serveur.`,
            goHome: `De retour {'à'} la maison`
        }
    },
    shareOverlay: {
        copied: 'Copié avec succès dans le presse-papier !',
        copyFrameCode: 'Copier le code iframe',
        copyUrl: 'Copier le lien',
        newTab: 'Nouvel onglet'
    },
    somethingWentWrong: {
        title: 'Oops... ;(',
        message: 'Nous avons eu un contretemps de notre côté. ',
        downloadFailed: 'Il y a un problème avec le téléchargement du fichier. '
    },
    unsavedChanges: {
        title: 'Avertissement! ',
        message: 'Il y a des modifications non enregistrées. '
    },
    navigation: {
        ticketing: {
            home: 'Aperçu',
            finance: {
                group: 'Finance',
                invoices: 'Factures',
                orders: 'Ordres',
                reports: 'Rapports',
                wallet: 'Portefeuille'
            },
            marketing: {
                group: 'Commercialisation',
                agendas: 'Ordres du jour',
                campaignTracking: 'Suivi de campagne',
                preRegisters: 'Pré-inscriptions'
            }
        }
    },
    pageTitle: {
        faq: 'FAQ',
        home: 'Aperçu',
        profile: 'Profil',
        settings: 'Paramètres',
        whatsNew: 'Quoi de neuf',
        secureCodes: 'Secure codes'
    },
    profileMenu: {
        appearance: 'Apparence',
        faq: 'FAQ',
        language: 'Langue',
        managing: 'Gestion : {0}',
        profile: 'Profil',
        settings: 'Paramètres',
        signOff: 'Se déconnecter',
        switchOrganization: `Changer d'organisation`,
        whatsNew: 'Quoi de neuf',
        theme: {
            dark: 'Sombre',
            light: 'Lumière'
        }
    },
    countdown: {
        expiresIn: 'Expire dans {0} :{1}',
        expiresInWithHours: 'Expire dans {0} :{1} :{2}',
        expiresInDays: 'Expiré | Expire dans un jour | Expire dans {n} jours',
        expiresInHours: 'Expiré | Expire dans une heure | Expire dans {n} heures'
    },
    csvUpload: {
        message: 'Téléchargez ou faites glisser un fichier CSV ici...',
        button: 'Choisir le dossier',
        hasHeader: 'A un en-tête',
        exampleData: 'Exemples de données',
        fieldType: 'Type de champ'
    },
    emptyView: {
        title: 'Rien ici',
        message: `Il n'y a actuellement rien {'à'} voir ici.`
    },
    googlePlacesAutocomplete: {
        invalid: 'Adresse invalide, veuillez en sélectionner une dans la liste déroulante des adresses.',
        unavailable: `Il n'est pas possible de sélectionner une adresse pour le moment.`
    }
} satisfies Translations;
