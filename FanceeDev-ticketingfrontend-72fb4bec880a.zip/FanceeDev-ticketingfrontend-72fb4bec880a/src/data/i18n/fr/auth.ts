import type { Translations } from '../types';

export default {
    logout: 'Se déconnecter',
    useClient: 'Afficher le compte personnel',
    login: {
        title: 'Se connecter',
        description: `Pour vous connecter, veuillez fournir vos informations d'identification et accéder {'à'} votre compte.`,
        submit: 'Se connecter',
        or: 'Ou',
        createAccount: 'Créer un compte',
        forgotPassword: 'Mot de passe oublié?'
    },
    register: {
        title: `S'inscrire`,
        description: 'Bienvenue sur WeAreFancee !',
        clientTitle: 'Client',
        clientDescription: 'Je veux voir mes propres billets.',
        organizationTitle: 'Organisation',
        organizationDescription: `J'ai besoin d'une billetterie pour mon (mes) événement(s).`,
        complete: 'Votre compte a été créé!',
        submit: 'Registre',
        client: {
            title: `S'inscrire - Client`,
            description: 'Commençons par créer votre compte personnel WeAreFancee. '
        },
        organization: {
            title: `S'inscrire - Organisation`,
            description: 'Commençons par créer votre compte WeAreFancee. '
        }
    },
    select: {
        title: 'Bonjour {nom},',
        description: 'Votre compte peut gérer différentes organisations. '
    },
    verify: {
        title: 'Vérification de compte',
        description: 'Attendez un instant pendant que nous validons les détails de votre compte.',
        busy: 'Vérification...',
        done: 'Votre compte a été vérifié! '
    },
    forgotPassword: {
        title: 'réinitialisez votre mot de passe',
        description: 'Pas de soucis!',
        feedback: 'Si vous avez un compte sur @:global.platform.name, vous recevrez un e-mail contenant des instructions sur la façon de réinitialiser votre mot de passe.'
    },
    forgotPasswordReset: {
        title: '@:auth.forgotPassword.title',
        description: `Pour retrouver l'accès {'à'} votre compte, veuillez saisir votre nouveau mot de passe ci-dessous.`,
        success: 'Votre mot de passe a été réinitialisé. '
    },
    reauthenticate: {
        title: 'Vous avez été déconnecté.',
        body: `Pour continuer {'à'} utiliser votre compte, veuillez vous reconnecter en utilisant votre mot de passe.`,
        submit: '@:auth.login.submit'
    },
    sessions: {
        singular: 'Session',
        plural: 'Séances',
        search: 'Sessions de recherche...',
        device: 'Appareil',
        ipAddress: 'Adresse IP',
        issuedOn: 'Publié le',
        expires: 'Expire',
        deleteFailed: 'Impossible de supprimer la session.',
        loadingFailed: 'Impossible de récupérer les sessions.',
        deleted: 'La session a été supprimée avec succès.'
    }
} satisfies Translations;
