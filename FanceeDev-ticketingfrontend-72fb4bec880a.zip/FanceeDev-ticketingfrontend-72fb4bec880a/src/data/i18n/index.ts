import { createI18n } from 'vue-i18n';

import { languages, messages } from './locales';

const i18n = createI18n<false, {}, typeof messages>({
    legacy: false,
    locale: 'en',
    fallbackLocale: false,
    fallbackWarn: false,
    silentFallbackWarn: true,
    silentTranslationWarn: true,

    messages: messages
});

export async function switchLanguage(locale: string): Promise<void> {
    i18n.global.locale.value = locale;
}

export function t(key: Parameters<typeof i18n.global.t>[0], params?: Record<string, unknown>): string {
    return i18n.global.t(key, params ?? {});
}

export { i18n, languages };
