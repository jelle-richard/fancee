import type { Translations } from '../types';

export default {
    errors: {
        message: 'Los de fouten in het formulier op voordat u verder gaat met de indiening.',
        pleaseFix: 'Gelieve de volgende items te corrigeren',
        pleaseFixErrors: 'Gelieve de volgende fouten te corrigeren'
    },
    validator: {
        afterDate: 'Voer een datum na {formattedDateTime} in.',
        alpha: 'Voer alleen alfabetische tekens in.',
        alphaNum: 'Voer een waarde in die alleen letters en cijfers bevat.',
        beforeDate: 'Voer een datum voor {formattedDateTime} in.',
        between: 'Voer een getal in tussen {min} en {max}, inclusief.',
        betweenDates: 'Voer een datum tussen {formattedMinDate} en {formattedMaxDate} in.',
        decimal: 'Voer een geldige decimale waarde in.',
        email: 'Voer een geldig e-mailadres in.',
        future: 'Voer een toekomstige datum in.',
        integer: 'Voer een geheel getal in.',
        ipAddress: 'Voer een geldig IP-adres in.',
        macAddress: 'Voer een geldig MAC-adres in.',
        maxPrice: 'Voer een bedrag in dat kleiner is dan of gelijk is aan {formattedMaxPrice}.',
        maxLength: 'Voer een waarde in met een maximale lengte van {max} tekens.',
        maxValue: 'Voer een getal in dat kleiner is dan of gelijk is aan {max}.',
        minLength: 'Voer een waarde in met een minimale lengte van {min} tekens.',
        minValue: 'Voer een getal in dat groter is dan of gelijk is aan {min}.',
        numeric: 'Voer een geldige numerieke waarde in.',
        past: 'Voer een datum in het verleden in.',
        phoneNumber: 'Voer een geldig telefoonnummer in.',
        price: 'Voer een geldige prijs in met een decimale waarde.',
        required: 'Dit veld is verplicht.',
        requiredIf: 'Dit veld is verplicht.',
        requiredUnless: 'Dit veld is verplicht.',
        sameAs: 'Zorg ervoor dat dit veld overeenkomt met het andere veld.',
        url: 'Voer een geldige URL in.',
        minTextLength: '@:validation.validator.minLength',
        secureCode: `Voer een waarde in die alleen letters, cijfers of een van de volgende tekens bevat: . {'@'} _-.`
    }
} satisfies Translations;
