import type { Translations } from '../types';

export default {
    title: 'App',
    scanStatistics: {
        title: 'Scanstatistieken'
    },
    team: {
        plural: 'App-teams',
        singular: 'App-team',
        title: '@:app.team.plural',
        search: 'Zoek in app-teams...',
        emptyView: 'Het lijkt erop dat uw account geen app-teams heeft.',
        createFailed: 'Het app-team kon niet worden gemaakt. Neem contact op met support als het probleem zich blijft voordoen.',
        createSuccess: 'Het app-team is succesvol aangemaakt.',
        deleteFailed: 'Het app-team kon niet worden verwijderd. Neem contact op met support als het probleem zich blijft voordoen.',
        deleteSuccess: 'Het app-team is succesvol verwijderd.',
        updateFailed: 'Het app-team kon niet worden gewijzigd. Neem contact op met support als het probleem zich blijft voordoen.',
        downloadFailed: 'Er is een fout opgetreden tijdens het downloaden van uw app-teams. Neem contact op met support voor hulp.',
        loadingFailed: 'Er is een fout opgetreden tijdens het ophalen van uw app-teams. Probeer het later opnieuw of neem contact op met support voor hulp.',
        loadingEventsFailed: 'Er is een fout opgetreden tijdens het laden van uw evenementen. Probeer het later opnieuw of neem contact op met support voor hulp.',
        loadingProductsFailed: 'Er is een fout opgetreden tijdens het laden van uw producten. Probeer het later opnieuw of neem contact op met support voor hulp.',
        loadingSingleFailed: 'Er is een fout opgetreden tijdens het ophalen van uw app-team. Probeer het later opnieuw of neem contact op met support voor hulp.',
        table: {
            name: '@:form.field.name',
            rights: 'Rechten',
            qr: 'QR-Code'
        },
        right: {
            guestlists: '@:event.guestlist.plural',
            scanning: 'Scannen',
            sales: 'Verkopen',
            statistics: 'Statistieken',
            cash: 'Contant'
        },
        configure: {
            title: {
                edit: '{0} wijzigen',
                new: 'Nieuw app-team maken'
            }
        },
        statistics: {
            title: 'Scanstatistieken bekijken',
            loadingFailed: 'Er is een fout opgetreden tijdens het ophalen van de evenementstatistieken. Probeer het later opnieuw of neem contact op met support voor hulp.',
            loadingTeamFailed: 'Er is een fout opgetreden tijdens het ophalen van de app-teamstatistieken. Probeer het later opnieuw of neem contact op met support voor hulp.',
            selectAppTeam: 'Selecteer een app-team...',
            selectEvent: 'Selecteer een evenement...',
            event: {
                title: 'Evenementstatistieken',
                subTitle: 'Scanstatistieken per ticket',
                remaining: 'Resterend',
                scanned: 'Gescand'
            },
            team: {
                title: 'Scantijden',
                subTitle: 'Scantijden van het app-team',
                scanned: 'Gescand',
                unscanned: 'Niet gescand',
                dateHint: 'Wijzig de datum of tijd om de scanstatistieken vanaf dat moment te bekijken.',
                empty: 'Er zijn geen scangegevens gevonden voor het geselecteerde app-team of de gekozen datum.'
            }
        }
    }
} satisfies Translations;
