import type { Translations } from '../types';

export default {
    changesSavedSuccessfully: 'Wijzigingen succesvol opgeslagen.',
    accountTakeoverNotice: {
        info: 'Momenteel ingelogd als {0}, alles wat u doet heeft invloed op dit account.',
        switchBack: 'Terug naar {0}.'
    },
    confirmDeleteOverlay: {
        title: '{0} verwijderen?',
        titleAll: 'Alles verwijderen?',
        titleGeneric: 'Verwijdering bevestigen',
        message: 'Weet u zeker dat u "{0}" wilt verwijderen?',
        messageGeneric: 'Weet u zeker dat u de entry wilt verwijderen?'
    },
    countrySelectOverlay: {
        title: 'Welke landen wilt u beheren?',
        selection: '{0} van {1}',
        checkAll: 'Alle landen beheren'
    },
    focalPoint: {
        editor: {
            title: 'Brandpunt editor',
            subTitle: 'Sleep de cirkel naar het gewenste brandpunt voor elk van uw afbeeldingen.'
        },
        singular: 'Brandpunt',
        plural: 'Brandpunten'
    },
    notAllowed: {
        title: 'Niet toegestaan',
        message: 'Uw account heeft niet de benodigde rechten om de gevraagde actie uit te voeren.'
    },
    notFound: {
        record: 'Het gevraagde record kon niet worden gevonden.',
        page: {
            title: 'Pagina niet gevonden',
            content: 'De gevraagde URL is niet gevonden op deze server.',
            goHome: 'Terug naar Home'
        }
    },
    shareOverlay: {
        copied: 'Succesvol gekopieerd naar klembord!',
        copyFrameCode: 'Iframe code kopiëren',
        copyUrl: 'URL kopiëren',
        newTab: 'Nieuw tabblad'
    },
    somethingWentWrong: {
        title: 'Oeps... ;(',
        message: 'Er is iets fout gegaan. Probeer het later opnieuw. Als het probleem zich blijft voordoen, neem contact op met onze support team.',
        downloadFailed: 'Er is een probleem met het downloaden van het bestand. Neem contact op met onze support voor hulp.'
    },
    unsavedChanges: {
        title: 'Waarschuwing! Niet-opgeslagen wijzigingen.',
        message: 'Er zijn niet-opgeslagen wijzigingen. Als u doorgaat, gaan deze wijzigingen verloren. Weet u zeker dat u wilt doorgaan?'
    },
    navigation: {
        ticketing: {
            home: 'Overzicht',
            finance: {
                group: 'Financiën',
                invoices: 'Facturen',
                orders: 'Bestellingen',
                reports: 'Rapporten',
                wallet: 'Portemonnee'
            },
            marketing: {
                group: 'Marketing',
                agendas: 'Agenda\'s',
                campaignTracking: 'Campagne tracking',
                preRegisters: 'Voorafgaange registraties'
            }
        }
    },
    pageTitle: {
        faq: 'FAQ',
        home: 'Overzicht',
        profile: 'Profiel',
        settings: 'Instellingen',
        whatsNew: 'Wat is nieuw',
        secureCodes: 'Secure codes'
    },
    profileMenu: {
        appearance: 'Weergave',
        faq: 'FAQ',
        language: 'Taal',
        managing: 'Beheer: {0}',
        profile: 'Profiel',
        settings: 'Instellingen',
        signOff: 'Afmelden',
        switchOrganization: 'Organisatie wijzigen',
        whatsNew: 'Wat is nieuw',
        theme: {
            dark: 'Donker',
            light: 'Licht'
        }
    },
    countdown: {
        expiresIn: 'Verloopt over {0}:{1}',
        expiresInWithHours: 'Verloopt over {0}:{1}:{2}',
        expiresInDays: 'Verlopen | Verloopt over één dag | Verloopt over {n} dagen',
        expiresInHours: 'Verlopen | Verloopt over één uur | Verloopt over {n} uren'
    },
    csvUpload: {
        message: 'Upload of sleep hier een CSV-bestand...',
        button: 'Bestand selecteren',
        hasHeader: 'Bevat header',
        exampleData: 'Voorbeeld data',
        fieldType: 'Veldtype'
    },
    emptyView: {
        title: 'Niets hier',
        message: 'Er is momenteel niets te zien hier.'
    },
    googlePlacesAutocomplete: {
        invalid: 'Ongeldig adres, selecteer er één uit de adreslijst.',
        unavailable: 'Het is momenteel niet mogelijk om een adres te selecteren.'
    }
} satisfies Translations;
