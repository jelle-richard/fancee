import type { Translations } from '../types';

export default {
    title: 'Financien',
    takings: 'Inkomsten',
    ticketFee: 'Ticketkosten',
    paymentFee: 'Betaal kosten',
    discount: 'Korting',
    invoice: {
        plural: 'Facturen',
        singular: 'Factuur',
        title: '@:finance.invoice.plural',
        downloadFailed: 'Er is een fout opgetreden tijdens het downloaden van het facturenbestand. Neem contact op met support voor hulp.',
        downloadSingleFailed: 'Er is een fout opgetreden tijdens het downloaden van de factuur. Neem contact op met support voor hulp.',
        loadingFailed: 'Het systeem kon geen facturen ophalen. Probeer het later opnieuw of neem contact op met support voor hulp.',
        loadingEventsFailed: 'Er is een fout opgetreden tijdens het laden van uw evenementen. Probeer het later opnieuw.'
    },
    order: {
        title: 'Bestellingen',
        downloadFailed: 'Er is een fout opgetreden tijdens het downloaden van bestellingen. Neem contact op met support voor hulp.',
        loadingFailed: 'Er is een fout opgetreden tijdens het laden van de bestelling. Neem contact op met support voor hulp.',
        loadingSingleFailed: 'Er is een fout opgetreden tijdens het laden van bestellingen. Neem contact op met support voor hulp.',
        search: 'Zoek bestellingen...',
        cost: 'Kosten',
        filter: {
            promotionalEmail: 'Promotie-e-mail',
            promotionalSms: 'Promotie-sms',
            orderSms: 'Bestel-sms ontvangen'
        },
        table: {
            psp: 'PSP referentie',
            event: '@:event.singular',
            date: '@:global.date',
            amount: '@:global.amount',
            paymentStatus: '@:finance.paymentStatus.title'
        },
        single: {
            title: 'Bestelhistorie',
            advanced: {
                title: 'Geavanceerd',
                refund: {
                    title: 'Terugbetalen',
                    info: 'U kunt de klant terugbetalen. U kunt er dan voor kiezen om de terugbetaalde producten terug te nemen in de voorraad van uw winkel.',
                    start: 'Start met terugbetalen'
                },
                resend: {
                    title: 'Bestelbevestiging opnieuw verzenden',
                    info: 'U kunt de tickets opnieuw naar de klant sturen, dit is een directe kopie van de e-mail die werd verzonden bij de uitvoering van de bestelling.',
                    disabled: 'Het opnieuw verzenden van de bestelling naar de klant is alleen mogelijk als de betaling is uitgevoerd.',
                    submit: 'Opnieuw verzenden',
                    success: 'De ticket-PDF van deze bestelling is opnieuw verzonden naar de oorspronkelijke koper.'
                }
            },
            client: {
                title: 'Klantgegevens',
                optins: {
                    title: 'Aanmeldingen voor promoties',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            order: {
                title: 'Bestelling',
                breakdown: 'Overzicht',
                psp: 'PSP referentie',
                cost: 'Kosten',
                paymentFee: 'Betalingstoeslag',
                paymentMethod: 'Betaalmethode',
                paymentStatus: 'Betalingsstatus',
                placed: 'Bestelling geplaatst',
                productFee: 'Productkosten',
                seatedTicketFee: 'Kosten seated tickets',
                ticketAndProductRevenue: 'Ticket- & Productinkomsten',
                ticketFee: '@:finance.ticketFee',
                ticketServicePlusCost: 'Ticket Service Plus kosten',
                totalOrderCost: 'Totale bestelkosten'
            },
            purchase: {
                title: 'Aankoop',
                viewTickets: 'Tickets bekijken',
                productFee: '{0} productkosten',
                seatedTicketFee: '{0} kosten seated tickets',
                ticketFee: '{0} ticketkosten',
                boughtTsp: 'Ticket Service Plus gekocht',
                receiveOrderSms: 'Bestel-sms ontvangen',
                products: 'Producten'
            }
        },
        refund: {
            title: 'Terugbetaling {0}',
            notice: 'Houd er rekening mee dat het terugbetalen van een bestelling niet omkeerbaar is, de ticketkoper wordt op de hoogte gesteld van deze terugbetaling en wij streven ernaar het geld binnen 3 werkdagen over te maken.',
            returnToStock: 'Terug naar voorraad',
            invalidateTickets: 'Tickets ongeldig maken',
            submit: 'Terugbetaling uitvoeren',
            totalRefundAmount: 'Totaal terug te betalen bedrag:',
            failed: 'Er is een fout opgetreden tijdens het uitvoeren van de terugbetaling. Neem contact op met support voor hulp.',
            success: 'De terugbetaling is succesvol uitgevoerd en de koper is op de hoogte gesteld.'
        }
    },
    report: {
        title: 'Rapporten',
        loadingFailed: 'Er is een fout opgetreden bij het laden van uw omzetstatistieken. Neem contact op met de ondersteuning als de fout zich blijft voordoen.',
        loadingEventsFailed: 'Er is een fout opgetreden tijdens het laden van uw evenementen. Probeer het later opnieuw.',
        info: 'Deze informatie kun je gebruiken om je omzettrends te analyseren. Selecteer een evenement om specifieke inzichten te krijgen of laat het leeg voor een accountbreed overzicht.',
        searchEvent: 'Zoek gebeurtenis...',
        organization: {
            statistics: {
                title: 'Omzetstatistieken',
                fulfilledOrders: 'Uitgevoerde bestellingen',
                issuedProducts: 'Uitgeleverde producten',
                obtained: {
                    app: 'Verkregen via @:global.platform.name app.',
                    generated: 'Gegenereerd door platform.',
                    guestlist: 'Verstuurd via gastenlijsten.',
                    imported: 'Geïmporteerd uit externe bron.',
                    shop: 'Verkregen via @:global.platform.name shop.',
                    ticketswap: 'Verkocht via ticketswap'
                }
            },
            revenue: {
                title: 'Organisatie omzet'
            },
            cost: {
                title: 'Organisatie kosten',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Transactiekosten',
                ticketFeeCost: '@:finance.ticketFee',
                seatedTicketFeeCost: 'Geplaceerde ticketkosten',
                guestlistCost: 'Gastenlijsten'
            }
        },
        platform: {
            revenue: {
                title: 'Platform omzet',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Transactiekosten'
            },
            cost: {
                title: 'Platform kosten',
                ticketFee: '@:finance.ticketFee',
                productFee: 'Productkosten',
                seatedTicketFee: 'Geplaceerde ticketkosten',
                guestlist: 'Gastenlijsten',
                additional: 'Overige',
                paymentFeeCost: 'Transactiekosten'
            }
        },
        client: {
            cost: {
                title: 'Klant kosten',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Transactiekosten'
            }
        },
        product: {
            title: 'Product omzet',
            cash: 'Contant',
            online: 'Online'
        },
        totals: {
            title: 'Totaal',
            totals: 'Totalen',
            OrganizationRevenue: 'Totale organisatie omzet',
            PlatformRevenue: 'Totale platform omzet',
            organizationCost: 'Totale organisatie kosten',
            clientCost: 'Totale klant kosten',
            revenue: 'Totale omzet',
            cost: 'Totale kosten',
            profit: {
                title: 'Winst',
                wallet: 'In wallet geplaatst',
                profit: 'Winst',
                cash: 'Het verschil tussen winst en wat er in de wallet geplaatst is komt door de contante omzet'
            }
        }
    },
    wallet: {
        title: 'Portemonnee',
        currencyConversionInfo: 'Houd er rekening mee dat hoewel alle uitbetalingen in euro worden verwerkt, schommelingen in ontvangen bedragen kunnen optreden als gevolg van bankkosten en wisselkoersfluctuaties. We waarderen uw begrip.',
        searchTransactions: 'Zoek transacties...',
        downloadInvoiceFailed: 'Er is een fout opgetreden tijdens het downloaden van de factuur. Neem contact op met support voor hulp.',
        downloadOrdersFailed: 'Er is een fout opgetreden tijdens het downloaden van het bestand met bestellingen. Neem contact op met support voor hulp.',
        downloadReceiptFailed: 'Er is een fout opgetreden tijdens het downloaden van het wallet-ontvangstbewijs. Neem contact op met support voor hulp.',
        loadingBalanceFailed: 'Er is een fout opgetreden tijdens het ophalen van het saldo van de wallet. Neem contact op met support voor hulp.',
        loadingTransactionsFailed: 'Er is een fout opgetreden tijdens het ophalen van wallet-transacties. Neem contact op met support voor hulp.',
        balance: {
            title: 'Saldo',
            subTitle: 'Saldo van de wallet in de afgelopen {days} dagen.',
            pending: 'In behandeling',
            spendable: 'Uit te geven'
        },
        payout: {
            request: 'Uitbetaling aanvragen',
            requestFailed: 'Er is een fout opgetreden tijdens het verwerken van uw aanvraag voor uitbetaling. Neem contact op met support voor hulp.',
            requestSuccess: 'Uw aanvraag voor uitbetaling is succesvol ingediend.',
            acknowledge: 'Door dit verzoek in te dienen, erkent u dat u een uitbetaling van {amount} aanvraagt.',
            info: 'U kunt een aangepast uitbetalingsbedrag aanvragen door het selectievakje aan te vinken en een aangepaste waarde op te geven.',
            custom: 'Aangepast bedrag aanvragen',
            amount: 'Bedrag'
        },
        structure: {
            pending: 'In behandeling',
            reserved: 'Gereserveerd',
            requiredDeposit: 'Verplichte storting',
            spendable: {
                title: 'Uit te geven',
                tip: 'U hebt uitbetaling(en) aangevraagd ter waarde van {0} die nog niet zijn verwerkt.'
            }
        },
        transaction: {
            statement: 'Overzicht',
            table: {
                amount: 'Bedrag',
                processedOn: 'Verwerkt op',
                requestedOn: 'Aangevraagd op'
            }
        }
    },
    paymentStatus: {
        title: 'Betalingsstatus',
        authenticationFinished: 'Authenticatie voltooid',
        authenticationNotRequired: 'Authenticatie niet vereist',
        authorised: 'Geautoriseerd',
        blocked: 'Geblokkeerd',
        cancelled: 'Geannuleerd',
        challengeShopper: 'Fraudeverificatie vereist',
        chargeback: 'Storno',
        error: 'Fout',
        expired: 'Verlopen',
        identifyShopper: 'Identificatie koper vereist',
        partiallyAuthorised: 'Gedeeltelijk geautoriseerd',
        partialRefund: 'Gedeeltelijke terugbetaling',
        pending: 'In behandeling',
        presentToShopper: 'Aanbieden aan koper',
        received: 'Ontvangen',
        redirectShopper: 'Doorverwijzen koper',
        refund: 'Terugbetaling',
        pendingRefund: 'Terugbetaling in behandeling',
        refused: 'Geweigerd',
        unknown: 'Onbekend'
    }
} satisfies Translations;
