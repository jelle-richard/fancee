import type { Translations } from '../types';

export default {
    changelog: {
        noChanges: 'Geen wijzigingen gevonden',
        noChangesDescription: 'Er zijn geen wijzigingen in het systeem gevonden. Kijk later nog eens naar updates van het systeem.'
    },
    faq: {
        title: 'Veelgestelde vragen',
        description: 'Heeft u vragen? Hier vindt u de antwoorden.',
        email: {
            title: 'E-mail',
            description: 'We zullen ons best doen om binnen {0} werkdag(en) contact met u op te nemen!',
            button: 'Stuur ons een e-mail'
        },
        phone: {
            title: 'Telefoon',
            description: 'We helpen u graag verder.'
        },
        whatsapp: {
            title: 'WhatsApp',
            description: 'We zullen ons best doen om binnen {0} uur op werkdagen contact met u op te nemen!',
            button: 'Stuur ons een bericht'
        },
        categories: [
            {
                icon: 'user',
                title: 'Accountbeheer',
                subTitle: 'Antwoorden op hoe u accountconfiguraties kunt instellen',
                questions: [
                    ['Kan ik mijn kosten wijzigen?', 'Uw platformkosten zijn gebaseerd op het dashboardpakket zoals vermeld in het contract. Om uw platformkosten te wijzigen, moet u contact opnemen met de ondersteuning om uw pakket te wijzigen.'],
                    ['Kan ik mijn pakket upgraden of downgraden?', 'Tenzij expliciet vermeld in uw contract, kunt u dit op elk gewenst moment doen. Neem contact op met de ondersteuning met uw gewenste dashboardpakket. We zullen een nieuw contract voor u opstellen.'],
                    ['Hoe activeer ik 2-FA?', 'Het inschakelen van 2-FA is een geweldige manier om uw account verder te beveiligen. U kunt dit doen door naar uw profiel te navigeren en het gevraagde formulier in te vullen op het tabblad \'Beveiliging\'.'],
                    ['Hoe wijzig ik mijn btw-code, bankrekeningnummer en/of Kamer van Koophandel-gegevens?', 'U mag deze informatie niet naar eigen goeddunken wijzigen. Neem contact op met de ondersteuning en geef de vereiste wijzigingen door. Zodra deze zijn geverifieerd, zullen ze uw account dienovereenkomstig bijwerken.'],
                    ['Er zijn menu-items die vergrendeld zijn, hoe krijg ik toegang tot deze items?', 'Afhankelijk van het dashboardpakket waarvoor uw account is geconfigureerd, zijn er bepaalde pagina\'s die mogelijk niet zijn opgenomen. U kunt de details van uw dashboardpakket vinden in uw contract of op de pagina \'Mijn profiel\'. Zie \'Kan ik mijn pakket upgraden of downgraden?\' om uw dashboardpakket te wijzigen.']
                ]
            },
            {
                icon: 'shopping-bag',
                title: 'Verkoop',
                subTitle: 'Hoe u uw verkoop kunt afhandelen',
                questions: [
                    ['Zal de ondersteuning mij helpen met de verkoop?', 'Het dashboard ondersteunt een breed scala aan uitleg in de vorm van tutorials, online webinars en downloads, die 24/7 beschikbaar zijn. Mocht u verdere hulp nodig hebben, dan helpt onze verkoopafdeling u graag uw verkoopopportuniteiten te vergroten.'],
                    ['Hoe bied ik kortingen aan mijn klanten aan?', 'Kortingen zijn een geweldige manier om klanten aan te trekken, resterende voorraad te verkopen of een compensatie aan te bieden. U kunt kortingen toevoegen via de pagina \'Kortingen\' onder het menu \'Evenementen\'. Hier kunt u kortingen maken voor specifieke evenementen, winkels en zelfs producten. Kortingen kunnen worden geconfigureerd met zowel een statische als een procentuele prijsverlaging en kunnen worden ingesteld om te vervallen.'],
                    ['Ik heb producten in een toestand in behandeling, wat betekent dit?', 'Wanneer een klant producten via uw winkel koopt, houdt ons platform hun productselectie in een reservering (standaard 8 minuten). Dit stelt de gebruiker in staat de vereiste formulieren in te vullen om zijn/haar aankoop te voltooien. Zodra een aankoop is gestart, krijgt de klant nog eens 15 minuten van de back-/betalingsprovider. Zodra de reservering verloopt zonder een voltooide aankoop, zal de gereserveerde voorraad worden vrijgegeven.'],
                    ['Kan ik de productprijzen tijdens de verkoop verhogen of verlagen?', 'Ja, u kunt de prijzen van uw product(en) op elk gewenst moment wijzigen door deze aan te passen in de stap \'Producten\' van \'Configureer evenement\'. Houd er rekening mee dat deze wijzigingen onmiddellijk van kracht worden in alle winkels die gebruikmaken van genoemde product(en).'],
                    ['Kan ik de productvoorraad tijdens de verkoop verhogen of verlagen?', 'De productvoorraad kan op elk gewenst moment worden gewijzigd, hoewel als de resterende voorraad wordt bijgewerkt naar 0, de lopende reserveringen nog steeds kunnen worden voltooid. Dit kan leiden tot een oververkoop van producthoeveelheden. U kunt de voorraad van uw product(en) op elk gewenst moment wijzigen door deze aan te passen in de stap \'Producten\' van \'Configureer evenement\'. Houd er rekening mee dat deze wijzigingen onmiddellijk van kracht worden in alle winkels die gebruikmaken van genoemde product(en).'],
                    ['Kan ik de platformkosten doorberekenen aan de klant?', 'U kunt een eigen toeslag toevoegen aan de productprijs onder de geavanceerde opties van het bewerken van een product in de stap \'Producten\' van \'Configureer evenement\'.']
                ]
            },
            {
                icon: 'calendar',
                title: 'Evenementbeheer',
                subTitle: 'Hoe u uw evenementen en winkels instelt',
                questions: [
                    ['Wat doen de type evenementen voor een evenement?', 'Bij het maken van een evenement word je geconfronteerd met de keuze tussen een normaal, seated en timeslotted evenement. Een normaal evenement maakt de verkoop van tickets en producten voor een gewenste datum mogelijk. Geplande evenementen bieden de mogelijkheid om tickets en producten over een reeks datums te verkopen, waarbij deze tickets en producten kunnen worden toegewezen aan een tijdslot waarin ze geldig zijn. Genummerde evenementen lijken op een normaal evenement, maar verkochte tickets tijdens een genummerd evenement moeten worden toegewezen aan een stoel die de klant kan kiezen.'],
                    ['Welke link gebruik ik om mijn online winkel te delen?', 'Wanneer je een evenement hebt aangemaakt met minstens één winkel, is de link van deze winkel zichtbaar in je evenementsoverzicht, die je kunt vinden via de pagina \'Mijn evenementen\'.'],
                    ['Hoe kan ik mijn eigen huisstijl gebruiken in de online winkels?', 'Bij het maken van winkels voor je evenement kun je kleuren kiezen via de optie \'Huisstijlkleuren toepassen\' in de stap \'Winkels\' van \'Evenement configureren\'. Je kunt je kleuren ook opslaan als een sjabloon en deze sjabloon (of een van de vooraf gedefinieerde sjablonen) kiezen bij het maken van een nieuwe winkel.']
                ]
            },
            {
                icon: 'mobile-notch',
                title: 'Tickets & Scannen',
                subTitle: 'Hoe u toegang tot evenementen verifieert',
                questions: [
                    ['Hoe scan ik tickets?', 'Door gebruik te maken van de \'WeAreFancee Scan app\' die je zowel in de Android Play Store als de Apple App Store kunt vinden. Je kunt inloggen met je organisatieaccount of organisatieteams aanmaken via de pagina \'organisatieteams\' onder het menu-item \'Scannen\'.'],
                    ['Hoe log ik in bij de scanner?', 'Je kunt inloggen met je organisatieaccount of organisatieteams aanmaken via de pagina \'organisatieteams\' onder het menu-item \'Scannen\'.'],
                    ['Mijn klant zegt dat het ticket niet is bezorgd, wat moet ik doen?', 'Als de klant zijn/haar ticket niet heeft ontvangen, kun je de volgende stappen uitvoeren: 1. Je kunt de klant naar de pagina \'Ticket verloren\' leiden, te vinden op https://www.WeAreFancee.com/lost-ticket \r 2. Je kunt proberen de klant te vinden via het transactieoverzicht in \'Transacties\' onder het menu-item \'Financiën\' en de ticket-e-mail opnieuw te verzenden. \r 3. Als de klant oorspronkelijk het verkeerde e-mailadres heeft ingevoerd, kun je hem/haar het verkeerde e-mailadres + transactie-ID verstrekken zodat hij/zij de tickets kan ophalen via https://www.WeAreFancee.com/ticket-lost.'],
                    ['Wat doe ik als een klant zonder ticket naar het evenement komt?', 'Wanneer een klant zijn/haar ticket is vergeten mee te nemen, maar wel een betalingsbewijs kan overleggen, kun je het ticket in de app vinden via het venster \'Ticketstatistieken\' en zoeken met de e-mail en/of geboortedatum.']
                ]
            },
            {
                icon: 'coin',
                title: 'Financiën',
                subTitle: 'Hoe uw inkomsten bij te houden',
                questions: [
                    ['Kan ik een tussentijdse uitbetaling krijgen?', 'Ja, door naar uw \'Portemonnee\' te navigeren onder het menu-item \'Financiën\' kunt u een uitbetaling aanvragen als uw huidige saldo positief is. Voor de kosten van deze uitbetalingen verwijzen wij u naar uw organisatiecontract.'],
                    ['Wanneer krijg ik een uitbetaling?', 'U kunt een uitbetaling aanvragen door naar uw \'Portemonnee\' te navigeren onder het menu-item \'Financiën\' als uw saldo positief is.'],
                    ['Hoe vergoed ik een klant?', 'U kunt naar de klant of zijn/haar transactie zoeken in het transactieoverzicht onder \'Transacties\' onder het menu-item \'Financiën\'. Hier vindt u een restitutiemogelijkheid onder het tabblad \'Geavanceerde opties\'.'],
                    ['Waar kan ik mijn facturen vinden?', 'In het overzicht van de pagina \'Facturen\' onder het menu-item \'Financiën\'.']
                ]
            },
            {
                icon: 'chart-simple',
                title: 'Statistieken & marketing',
                subTitle: 'Hoe u uw klantgegevens gebruikt',
                questions: [
                    ['Hoe volg ik de resultaten van mijn campagnes?', 'Via de pagina \'Campagnes\' onder het menu-item \'Marketing\'.'],
                    ['Waar kan ik basisstatistieken van evenementen vinden?', 'Op het startscherm ziet u aanvankelijk accountbrede statistieken. In de navigatiebalk is er een optie om naar evenementspecifieke statistieken te kijken.'],
                    ['Hoe vind ik klanten en transacties?', 'U kunt navigeren naar de pagina\'s Financiën > Bestellingen waar u kunt zoeken op klanten of orderdetails. Door op een rij te klikken, krijgt u meer informatie.'],
                    ['Hoe weet ik met welke klanten ik contact mag opnemen?', 'Wanneer u contact wilt opnemen met één of meerdere gebruikers, kunt u naar de pagina \'Transacties\' onder het menu-item \'Financiën\' navigeren en filteren op gebruikers die zich hebben aangemeld voor e-mail- of sms-promoties.'],
                    ['Hoe houd ik mijn verkoop bij?', 'Op de startpagina kunt u uw evenement zoeken en selecteren om inzicht te krijgen in de dagelijkse verkoop, de resterende voorraad en uw bestsellers.']
                ]
            }
        ]
    },
    profile: {
        loadingFailed: 'Fout bij het ophalen van uw profielgegevens, probeer het later opnieuw.',
        contact: {
            title: 'Contact',
            add: '@:platform.profile.contact.title',
            added: '{0} {1} is toegevoegd als contactpersoon.',
            deleted: '{0} {1} is verwijderd als contactpersoon.',
            createFailed: 'Er is een fout opgetreden bij het toevoegen van het contactpersoon. Probeer het later opnieuw.',
            deleteFailed: 'Er is een fout opgetreden bij het verwijderen van het contactpersoon. Neem contact op met support voor hulp.',
            editFailed: 'Er is een fout opgetreden bij het opslaan van het contactpersoon. Probeer het later opnieuw.',
            emptyView: [
                'Bij @:global.platform.name begrijpen we dat wanneer uw bedrijf groeit, u taken moet delegeren. Daarom kunt u extra contactmogelijkheden toevoegen.',
                'Als er geen extra contactpersonen zijn geconfigureerd, komt al onze correspondentie op de geregistreerde e-mail van dit account terecht.',
                'Contactpersonen kunnen per rol worden gedefinieerd, zodat onze vragen bij de juiste afdelingen terechtkomen.'
            ],
            role: {
                customerSupprt: 'Klantondersteuning',
                finance: 'Financiën',
                marketing: 'Marketing',
                organization: 'Organisatie'
            }
        },
        organization: {
            title: '@:global.organization',
            cannotMakeChanges: 'Uw contract is aangemaakt. Neem contact op met support als er wijzigingen in uw profiel moeten worden aangebracht.',
            downloadContract: 'Contract downloaden',
            finance: 'Financiën',
            holder: 'Account houder',
            legalEntity: 'Rechtspersoon',
            loadCurrenciesFailed: 'Er is een fout opgetreden bij het ophalen van valuta\'s. Neem contact op met support voor hulp.'
        },
        packages: {
            title: 'Pakketten',
            request: 'Aanvraag',
            requestFailed: 'Aanvraag voor pakketwijziging kon niet worden ingediend. Probeer het later opnieuw.',
            requestSuccess: 'Uw aanvraag voor pakketwijziging naar {0} is ingediend bij onze support.',
            selfService: 'Zelfservice',
            supportBusinessHours: 'Accountondersteuning (kantooruren)',
            support247: 'Accountondersteuning (24/7)',
            ticketFee: '{0} Ticketkosten',
            ticketFeeCustom: 'Ticketkosten in overleg met sales.',
            unlimited: 'Onbeperkt',
            feature: {
                accountSupport: 'Accountondersteuning',
                ambassadorPrograms: 'Ambassadeursprogramma\'s',
                customerAnalytics: 'Klantenanalyses',
                customFeatures: 'Op maat gemaakte functies',
                discounts: 'Kortingen',
                guestlist: 'Gastenlijst',
                marketingCampaigns: 'Marketingcampagnes',
                salesGuides: 'Verkoopgidsen',
                salesScanApp: 'Verkoop- & scan-app',
                seating: 'Plaatsbepaling',
                shopCustomization: 'Winkel aanpassing',
                websiteIntegrations: 'Website integraties'
            },
            light: {
                name: 'Light',
                description: 'Kleine organisaties tot 2500 tickets per jaar.'
            },
            medium: {
                name: 'Medium',
                description: 'Grotere organisaties voor 2500+ tickets per jaar.'
            },
            custom: {
                name: 'Custom',
                description: 'Voor organisaties met behoefte aan aangepaste logica.'
            }
        },
        security: {
            title: 'Beveiliging',
            passwordChanged: 'Uw wachtwoord is gewijzigd. U wordt nu doorgestuurd naar de inlogpagina.',
            passwordChangeFailed: 'Er is een fout opgetreden bij het wijzigen van uw wachtwoord. Probeer het later opnieuw.'
        },
        sessions: {
            title: 'Sessies'
        },
        user: {
            title: 'Gebruiker',
            avatar: 'Profielfoto'
        }
    },
    receipt: {
        title: 'Factuur downloaden',
        description: 'Uw factuur bevat een overzicht van uw aankopen.',
        downloading: 'Uw factuur-pdf is onderweg. Even geduld!',
        exceeded: 'We zijn een klein probleem tegengekomen bij het downloaden van uw factuur. Probeer het later opnieuw.',
        failed: 'We konden uw factuur niet ophalen. Controleer de link in uw e-mail of probeer het later opnieuw.',
        success: 'Uw factuur-pdf is gedownload! Kijk in uw downloadmap om uw factuur te bekijken.'
    }
} satisfies Translations;
