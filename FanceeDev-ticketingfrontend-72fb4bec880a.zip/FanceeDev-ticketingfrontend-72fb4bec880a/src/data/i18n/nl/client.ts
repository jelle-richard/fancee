import type { Translations } from '../types';

export default {
    lastOrder: {
        title: 'Uw laatste bestelling',
        placedOn: 'Geplaatst op {0}'
    },
    dashboard: {
        loadingFailed: 'We konden uw bestellingen niet laden. Probeer het later opnieuw.',
        emptyView: {
            title: 'Niets te zien',
            message: 'Er konden geen bestellingen gevonden worden voor uw account. Daarom kunnen we hier geen tickets weergeven.'
        }
    },
    ticket: {
        eventName: 'Evenement',
        startDate: 'Datum',
        loadingFailed: 'Kan uw tickets niet laden.',
        emptyView: {
            title: 'Niets te zien',
            message: 'Als u zeker weet dat u recht hebt op tickets voor een aankomend evenement, controleer dan uw bestellingen.',
            action: 'Bestellingen bekijken'
        },
        sealed: {
            message: 'Deze tickets zijn verzegeld en worden {0} uur van tevoren vrijgegeven.',
            saleButton: 'Verkoop op TicketSwap'
        }
    }
} satisfies Translations;
