import type { Translations } from '../types';

export default {
    title: 'CRM',
    navigation: {
        home: 'Overzicht',
        adminRegister: 'Admin register',
        balance: 'Saldo',
        channels: 'Kanalen',
        eventBalance: 'Evenementsaldo',
        eventPlanning: 'Evenementplanning',
        integrations: 'Integraties',
        invoicing: 'Facturatie',
        orders: 'Bestellingen',
        organizations: 'Organisaties',
        paymentMethods: 'Betaalmethoden',
        payouts: 'Uitbetalingen'
    },
    home: {
        title: 'Overzicht',
        statisticsFor: 'Statistieken voor {0}',
        failed: {
            loadingGlobalPlatformStatistics: 'Er is een fout opgetreden tijdens het ophalen van de algemene platformstatistieken. Neem contact op met de support als dit probleem zich blijft voordoen.',
            loadingGrowthTargets: 'Er is een fout opgetreden tijdens het ophalen van uw verkooptargets. Neem contact op met de support als dit probleem zich blijft voordoen.',
            loadingTicketRevenueIndication: 'Er is een fout opgetreden tijdens het laden van de ticketinkomstenindicatie. Neem contact op met de support als dit probleem zich blijft voordoen.'
        },
        targetProgression: {
            newEvents: 'Nieuwe evenementen',
            newOrganizations: 'Nieuwe organisaties',
            newUniqueBuyers: 'Nieuwe unieke kopers',
            placedOrders: 'Geplaatst bestellingen',
            placedOrdersTip: '{placed} bestellingen geplaatst, waarvan {fulfilled} gepland.'
        },
        targets: {
            title: 'Platform targets',
            subTitle: 'Platform targets om groei te meten.',
            ticketFeeThisMonth: 'Deze maand: {0} / {1}',
            ticketFeeLastMonth: 'Vorige maand: {0} / {1}',
            revenueAccomplished: 'Gerealiseerde omzet',
            revenueTarget: 'Omzetdoelstelling',
            revenueToday: 'Omzet vandaag',
            revenueYesterday: 'Omzet gisteren',
            topDailySoldProducts: 'Top meest verkochte producten per dag',
            tooltip: {
                ticketFeeRevenue: 'Ticketinkomsten {0} / {1}',
                seatedTicketFeeREvenue: 'Inkomen seated tickets {0} / {1}',
                tickets: 'Tickets {0} / {1}',
                seatedTickets: 'Seated tickets {0} / {1}',
                organizations: 'Organisaties {0} / {1}',
                events: 'Evenementen {0} / {1}',
                placedOrders: 'Geplaatst bestellingen {0} / {1}',
                fulfilledOrders: 'Geplande bestellingen {0} / {1}',
                uniqueBuyers: 'Unieke kopers {0} / {1}'
            }
        }
    },
    adminRegister: {
        title: 'Admin registratie',
        choose: 'Kies admin rol',
        terminatesOn: 'Eindigt op',
        countryManager: {
            createFailed: 'Er is een fout opgetreden bij het aanmaken van de country manager. Kijk voor meer informatie in de logs.',
            createSuccess: 'De country manager is succesvol toegevoegd.',
            hint: 'Let op dat het instellen van de einddatum op de country manager het account na die datum blokkeert. Dit veld is niet verplicht.'
        },
        customerServiceEmployee: {
            createFailed: 'Er is een fout opgetreden bij het aanmaken van de klantenservicemedewerker. Kijk voor meer informatie in de logs.',
            createSuccess: 'De klantenservicemedewerker is succesvol toegevoegd.',
            countryManager: 'Country manager',
            hint: 'Op dit moment kunt u slechts één country manager selecteren voor de klantenservicemedewerker.',
            missingCountryManagers: 'Er zijn momenteel geen country managers beschikbaar.'
        }
    },
    balance: {
        title: 'Saldo',
        loadingFailed: 'Saldo\'s laden is mislukt. Neem contact op met de support als dit probleem zich blijft voordoen.',
        received: 'Ontvangen',
        revenue: 'Omzet',
        additionalCosts: 'Extra kosten',
        chargebacked: 'Teruggeboekt',
        chargebackFee: 'Terugboekingskosten',
        guestlistFee: 'Gastlijst kosten',
        month: 'Maand',
        orders: 'Bestellingen',
        paymentFee: 'Betalingstoeslag',
        productFee: 'Productkosten',
        productIncome: 'Productinkomsten',
        refunded: 'Terugbetaald',
        refundFee: 'Terugbetalingstoeslag',
        seatedTicketFee: 'Kosten seated tickets',
        sms: 'SMS',
        ticketFee: 'Ticketkosten',
        tickets: '@:event.ticketPlural',
        tsp: 'TSP'
    },
    eventBalance: {
        title: 'Evenementsaldo',
        loadingFailed: 'Er is een fout opgetreden tijdens het laden van evenementen. Probeer het later opnieuw.',
        table: {
            event: '@:event.singular',
            organization: 'Organisatie',
            status: '@:event.status.title',
            scannedTickets: 'Gescande tickets',
            fees: 'Kosten',
            received: 'Ontvangen'
        },
        tip: {
            guestlistFee: 'Gastlijst kosten',
            paymentFee: 'Betalingstoeslag',
            seatedTicketFee: 'Kosten seated tickets',
            ticketFee: 'Ticketkosten',
            tsp: 'TSP'
        }
    },
    eventPlanning: {
        title: 'Evenementplanning'
    },
    integration: {
        title: 'Integraties',
        configure: 'Configureren',
        connect: 'Verbinden',
        exact: {
            title: 'Exact',
            description: 'Login op Exact door op de knop hieronder te drukken. U wordt na de login teruggestuurd.',
            completed: 'Exact integratie voltooid.',
            loadingFailed: 'Fout bij het ophalen van Exact-login-URL.',
            loadingStatusFailed: 'Fout bij het ophalen van de vraag of Exact is ingeschakeld.',
            configure: {
                configureItems: 'Items configureren',
                selectJournal: 'Selecteer dagboek',
                disconnected: 'Exact is niet verbonden. Verbind het eerst voordat u het configureert.',
                loadingConfigurationFailed: 'Kan de configuratie niet ophalen. Probeer het later opnieuw.',
                loadingItemsFailed: 'Kan items niet ophalen. Probeer het later opnieuw.',
                loadingJournalsFailed: 'Kan dagboeken niet ophalen. Probeer het later opnieuw.',
                loadingSpecificationNamesFailed: 'Kan namen van factuurspecificaties niet ophalen. Probeer het later opnieuw.'
            },
            mapping: {
                platform: 'Platform item',
                exact: 'Exact itemcode',
                notMapped: 'Niet toegewezen',
                country: {
                    add: 'Land mapping toevoegen',
                    remove: 'Land mapping verwijderen'
                }
            }
        }
    },
    invoicing: {
        title: 'Facturatie',
        search: 'Zoek facturen...',
        downloadFailed: 'Er is een fout opgetreden tijdens het downloaden van het facturenbestand. Neem contact op met support voor hulp.',
        loadingFailed: 'Het systeem kon geen facturen ophalen. Probeer het opnieuw of neem contact op met support voor hulp.',
        loadingEventsFailed: 'Er is een fout opgetreden tijdens het laden van evenementen. Probeer het later opnieuw.',
        loadingOrganizationsFailed: 'Er is een fout opgetreden tijdens het laden van organisaties. Probeer het later opnieuw.',
        filter: {
            event: '@:event.singular',
            eventSearch: '@:event.list.searchPlaceholder',
            organization: 'Organisatie',
            organizationSearch: 'Zoek organisaties...'
        },
        table: {
            number: 'Nummer',
            organization: 'Organisatie',
            createdOn: 'Aangemaakt op'
        }
    },
    order: {
        title: 'Bestellingen'
    },
    organization: {
        singular: 'Organisatie',
        plural: 'Organisaties',
        title: '@:crm.organization.plural',
        search: 'Zoek organisaties...',
        downloadFailed: 'Er is een fout opgetreden tijdens het downloaden van het organisatiesbestand. Neem contact op met support voor hulp.',
        loadingFailed: 'Er is een fout opgetreden tijdens het laden van organisaties. Neem contact op met support voor hulp.',
        filter: {
            date: '@:global.date',
            contractSigned: 'Contract getekend',
            isBlocked: 'Geblokkeerd',
            isImportant: 'Belangrijk'
        },
        table: {
            name: '@:form.field.name',
            email: '@:form.field.email',
            annualSales: 'Jaarlijkse omzet',
            important: 'Belangrijk',
            verified: 'Geverifieerd',
            blocked: 'Geblokkeerd',
            profileComplete: 'Profiel compleet',
            lastLogin: 'Laatste aanmelding',
            phoneNumber: '@:form.field.phoneNumber'
        },
        single: {
            navigation: {
                account: 'Account',
                monitoring: 'Monitoring',
                permissions: 'Machtigingen',
                planning: 'Evenementplanning',
                wallet: 'Portemonnee'
            },
            contact: {
                title: 'Contactpersonen'
            },
            contract: {
                title: 'Contract',
                currentPackage: 'Huidig pakket',
                addAddendum: 'Aanvulling',
                updateContract: 'Contract bijwerken',
                expiresOn: 'Vervalt op {0}',
                guestlistFee: 'Gastlijst toeslag van {0}',
                productFee: 'Productkosten van {0} + {1}%',
                seatedTicketFee: 'Kosten seated tickets van {0} + {1}%',
                ticketFee: 'Ticketkosten van {0} + {1}%',
                downloadFailed: '@:onboarding.agreement.downloadFailed',
                updateFailed: 'Er is een onbekende fout opgetreden tijdens het proberen bijwerken van het pakkettype van een organisatie. Neem contact op met support voor hulp.'
            },
            info: {
                approximateAnnualSales: 'Geschatte jaarlijkse omzet',
                contractSigned: 'Contract getekend',
                createdOn: 'Aangemaakt op',
                important: 'Belangrijk',
                lastLogin: 'Laatste aanmelding',
                profileComplete: 'Profiel compleet',
                verified: 'Geverifieerd',
                block: 'Gebruiker blokkeren',
                unblock: 'Gebruiker deblokkeren',
                blockFailed: 'Er is een fout opgetreden tijdens het blokkeren van de gebruiker.',
                blockSuccess: 'Gebruiker succesvol geblokkeerd.',
                unblockFailed: 'Er is een fout opgetreden tijdens het deblokkeren van de gebruiker.',
                unblockSuccess: 'Gebruiker succesvol gedeblokkeerd.',
                importantChangeFailed: 'Er is een fout opgetreden tijdens het wijzigen van de belangrijke status van de gebruiker.',
                accountTakeover: {
                    button: 'Inloggen in account',
                    info: 'Voer hieronder opnieuw uw wachtwoord in om in te loggen als deze organisatie.'
                },
                accountStatus: 'Account status',
                accountStatusUnfinished: 'De organisatie is geregistreed maar heeft nog niet zijn profieel compleet ingevuld noch zijn contract getekend'
            },
            note: {
                title: 'Notities',
                attachFiles: 'Bestanden toevoegen...',
                createSuccess: 'De notitie is succesvol aangemaakt.',
                deleteSuccess: 'De notitie is succesvol verwijderd.'
            },
            permissions: {
                loadingClaimsFailed: 'Er is een fout opgetreden tijdens het ophalen van de platformclaims. Neem contact op met support voor hulp.',
                loadingUserClaimsFailed: 'Er is een fout opgetreden tijdens het ophalen van de gebruikersclaims. Neem contact op met support voor hulp.',
                savingUserClaimsFailed: 'Er is een fout opgetreden tijdens het opslaan van de gebruikersclaims. Neem contact op met support voor hulp.'
            },
            planning: {
                search: 'Zoek evenementen...'
            },
            wallet: {
                search: 'Zoek transacties...'
            },
            invoice: {
                regenerateTitle: 'Genereer factuur',
                regenerateExplanation: 'Genereer handmatig een factuur voor de organisatie (Enkel beschikbaar op dev)'
            }
        },
        addAddendumOverlay: {
            title: 'Aanvulling aanmaken',
            info: 'De aanvulling die u gaat aanmaken, wordt toegevoegd aan het huidige contract van de organisatie.',
            notation: 'Let op dat alle kosten in eurocent worden weergegeven. Bijvoorbeeld, een ticketkosten van €1,50 zou 150 eurocent zijn.',
            createSuccess: 'De aanvulling is succesvol toegevoegd aan het contract van de organisatie.',
            guestlistFee: 'Gastlijst toeslag',
            productFee: {
                percentual: 'Percentage productkosten',
                static: 'Productkosten'
            },
            seatedTicketFee: {
                percentual: 'Percentage kosten seated tickets',
                static: 'Kosten seated tickets'
            },
            ticketFee: {
                percentual: 'Percentage ticketkosten',
                static: 'Ticketkosten'
            }
        },
        alterContractOverlay: {
            title: 'Contract bijwerken'
        }
    },
    paymentMethod: {
        title: 'Betaalmethoden',
        search: 'Zoek betaalmethoden...',
        downloadFailed: 'Er is een fout opgetreden tijdens het downloaden van het bestand met betaalmethoden. Neem contact op met support voor hulp.',
        loadingFailed: 'Betaalmethoden konden niet worden geladen. Neem contact op met support voor hulp.',
        table: {
            id: 'Id',
            name: 'Naam',
            provider: 'Aanbieder',
            cost: 'Kosten',
            limitedTo: 'Beperkt tot'
        }
    },
    payout: {
        title: 'Uitbetalingen',
        search: 'Zoek uitbetalingen...',
        export: 'Exporteren',
        resolve: 'Huidige export oplossen',
        resolved: 'De uitbetalingsexport is als opgelost gemarkeerd en de onderliggende uitbetalingsverzoeken zijn dienovereenkomstig bijgewerkt.',
        exportFailed: 'Er zijn momenteel geen openstaande uitbetalingsverzoeken, dus er kan op dit moment geen exportbestand worden gegenereerd.',
        exportSuccess: 'U hebt een procedure voor het exporteren van uitbetalingen gestart. Het bestand wordt automatisch gedownload. Markeer de export als opgelost zodra deze is voltooid.',
        outstandingNotice: 'Er is momenteel één openstaande uitbetaling die moet worden verwerkt. | Er zijn momenteel {n} openstaande uitbetalingen die moeten worden verwerkt.',
        status: {
            created: 'Aangemaakt',
            processed: 'Verwerkt'
        },
        table: {
            id: 'Id',
            createdOn: 'Aangemaakt op',
            status: 'Status',
            markProcessed: 'Markeren als verwerkt'
        }
    }
} satisfies Translations;
