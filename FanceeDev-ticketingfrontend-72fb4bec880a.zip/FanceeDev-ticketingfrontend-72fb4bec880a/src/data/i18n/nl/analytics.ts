import type { Translations } from '../types';

export default {
    title: 'Data',
    titles: {
        campaign: 'Campagne',
        channels: 'Kanalen',
        home: 'Startscherm',
        monitor: 'Monitor',
        overview: 'Overzicht',
        social: 'Social',
        ticketing: 'Kaartverkoop'
    },
    navigation: {
        campaign: 'Campagne',
        channels: 'Kanalen',
        home: 'Startscherm',
        settings: 'Instellingen',
        social: 'Social',
        ticketing: '@:analytics.titles.ticketing'
    },
    comparisonView: 'Vergelijken',
    disabled: 'Uitgeschakeld',
    enabled: 'Ingeschakeld',
    paused: 'Gepauzeerd',
    fullOverview: 'Volledig overzicht',
    noData: 'Geen gegevens gevonden',
    openInBrowser: 'Openen in browser',
    selectField: 'Selecteer veld...',
    splitOn: 'Splitsen op...',
    noChannelsFound: {
        title: 'Geen kanalen gevonden',
        message: 'Er zijn geen kanalen gevonden. Gebruik de pagina \'Kanalen\' om er een toe te voegen.'
    },
    channel: {
        plural: 'Kanalen',
        singular: 'Kanaal',
        saving: 'Kanaal opslaan...',
        updating: 'Abonnementen bijwerken...',
        info: {
            createdOn: 'Aangemaakt op',
            lastLogin: 'Laatste aanmelding',
            organization: 'Organisatie',
            owner: 'Eigenaar',
            request: 'Aanvraag'
        },
        new: {
            title: 'Nieuw kanaal',
            user: 'Gebruiker',
            supermetrics: {
                account: 'SuperMetrics - ds_accounts',
                user: 'SuperMetrics - ds_user'
            }
        },
        status: {
            active: 'Actief',
            error: 'Fout',
            expired: 'Verlopen',
            inactive: 'Inactief',
            partiallyActive: 'Gedeeltelijk actief',
            paused: 'Gepauzeerd',
            setup: 'Instellen'
        },
        table: {
            name: '@:form.field.name',
            type: 'Type',
            status: 'Status',
            organization: 'Organisatie',
            owner: 'Eigenaar',
            email: '@:form.field.email',
            createdOn: 'Aangemaakt op'
        },
        type: {
            facebook: 'Facebook',
            facebookads: 'Facebook Ads',
            facebookpublicdata: 'Facebook Public Data',
            googleads: 'Google Ads',
            googleanalytics: 'Google Analytics',
            googleanalytics4: 'Google Analytics V4',
            instagram: 'Instagram',
            instagrampublicdata: 'Instagram Public Data',
            linkedin: 'LinkedIn',
            tiktok: 'TikTok',
            youtube: 'YouTube',
            youtubev2: 'YouTube V2'
        }
    },
    subscription: {
        plural: 'Abonnementen',
        singular: 'Abonnement',
        status: {
            active: 'Actief',
            inactive: 'Inactief'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            aw_ad: 'Google Ads - Ad',
            aw_age: 'Google Ads - Age',
            aw_campaign: 'Google Ads - Campaign',
            aw_conversion: 'Google Ads - Conversion',
            aw_gender: 'Google Ads - Gender',
            aw_geo: 'Google Ads - Geo',
            aw_keyword: 'Google Ads - Keyword',
            aw_placement: 'Google Ads - Placement',
            aw_search_query: 'Google Ads - Seaarch Query',
            aw_shopping: 'Google Ads - Shopping',
            fa_ads: 'Facebook Ads - Ad',
            fa_age_and_gender: 'Facebook Ads - Age and Gender',
            fa_campaign: 'Facebook Ads - Campaign',
            fa_conversion: 'Facebook Ads - Conversion',
            fa_geo: 'Facebook Ads - Geo',
            fa_video: 'Facebook Ads - Video',
            fb: 'Facebook - Page',
            fb_age_and_gender: 'Facebook - Age and Gender',
            fb_geo_likes: 'Facebook - Geographic',
            fb_posts: 'Facebook - Posts',
            fbpd_page: 'Facebook Public Data - Page',
            fbpd_posts: 'Facebook Public Data - Posts',
            fbpd_url_shares: 'Facebook Public Data - Url Shares',
            ga_content: 'Google Analytics - Content',
            ga_ecommerce: 'Google Analytics - Ecommerce',
            ga_events: 'Google Analytics - Events',
            ga_paid_traffic: 'Google Analytics - Paid traffic',
            ga_search: 'Google Analytics - Search',
            ga_social: 'Google Analytics - Social',
            ga_technology: 'Google Analytics - Technology',
            ga_traffic: 'Google Analytics - Traffic',
            ga_user: 'Google Analytics - User',
            gawa_device: 'Google Analytics 4 - Devices',
            gawa_ecom_items: 'Google Analytics 4 - E-Commerce items',
            gawa_engagement: 'Google Analytics 4 - Engagement',
            gawa_publishing: 'Google Analytics 4 - Publishing',
            gawa_traffic_acquisition: 'Google Analytics 4 - Traffic Acquisition',
            gawa_user_acquisition: 'Google Analytics 4 - User Acquisition',
            igi: 'Instagram - Followers',
            igi_age_and_gender: 'Instagram - Age and Gender',
            igi_country: 'Instagram - Country',
            igi_media: 'Instagram - Media',
            igi_profile_data: 'Instagram - Profile data',
            igpd2_hashtags: 'Instagram Public Data - Hashtags',
            igpd2_posts: 'Instagram Public Data - Posts',
            igpd2_profiles: 'Instagram Public Data - Profiles',
            lip_country: 'LinkedIn - Country',
            lip_page: 'LinkedIn - Page',
            lip_post: 'LinkedIn - Posts',
            tikba_country: 'TikTok - Country',
            tikba_gender: 'TikTok - Gender',
            tikba_profile: 'TikTok - Profile',
            tikba_video: 'TikTok - Video',
            yt2_ad_performance: 'Youtube v2 - Ad Performance',
            yt2_channel: 'Youtube v2 - Channel',
            yt2_demographic: 'Youtube v2 - Demographic',
            yt2_device: 'Youtube v2 - Device',
            yt2_geo: 'Youtube v2 - Geo',
            yt2_traffic_source: 'Youtube v2 - Traffic Source',
            yt2_video: 'Youtube v2 - Video',
            yt_video: 'YouTube - Video'
        }
    },
    header: {
        allChannels: 'Alle kanalen',
        comparisonView: 'Vergelijking',
        datePresets: {
            lastMonth: 'Vorige maand',
            lastSevenDays: 'Afgelopen 7 dagen',
            thisMonth: 'Deze maand',
            thisYear: 'Dit jaar'
        }
    },
    ads: {
        title: 'Advertenties',
        budget: 'Budget',
        campaign: 'Campagne',
        clicks: 'Klikken',
        conversion: 'Conversie',
        cost: 'Kosten',
        cpc: 'CPC',
        ctr: 'CTR',
        date: '@:global.date',
        engagement: 'Betrokkenheid',
        impressions: 'Weergaven',
        status: 'Status',
        totalCampaigns: 'Totaal aantal campagnes',
        totalSpent: 'Totaal uitgegeven'
    },
    bestPostTime: {
        title: 'Beste tijd om te posten op',
        comments: 'Reacties',
        likes: 'Likes',
        reach: 'Bereik',
        basedOn: {
            comments: 'Gebaseerd op gemiddelde hoeveelheid reacties',
            likes: 'Gebaseerd op gemiddelde aantal likes',
            reach: 'Gebaseerd op gemiddelde bereik'
        },
        engagement: {
            highest: 'Hoogste betrokkenheid',
            lowest: 'Laagste betrokkenheid'
        }
    },
    campaignInfo: {
        title: 'Algemene informatie',
        ageClicks: 'Klikken per leeftijd',
        budget: 'Budget',
        clicks: 'Klikken',
        conversion: 'Conversie',
        cpc: 'CPC',
        ctr: 'CTR',
        genderClicks: 'Klikken per geslacht',
        impressions: 'Weergaven',
        remaining: 'Overgebleven',
        spent: 'Uitgegeven'
    },
    captions: {
        title: 'Bijschriften'
    },
    emotions: {
        title: 'Emoties',
        subTitle: 'Alleen voor Facebook',
        like: 'Like',
        likes: 'Likes',
        love: 'Liefde',
        thankful: 'Dankbaar',
        wow: 'Wow',
        haha: 'Haha',
        pride: 'Trots',
        anger: 'Boosheid',
        sorry: 'Sorry'
    },
    engagement: {
        title: 'Betrokkenheid',
        clicks: 'Klikken',
        conversion: 'Conversie',
        cpc: 'CPC',
        ctr: 'CTR',
        comments: 'Reacties',
        impressions: 'Weergaven',
        likes: 'Likes',
        shares: 'Delen'
    },
    field: {
        activeFollowers: 'Actieve volgers',
        averageAge: 'Gemiddelde leeftijd',
        clicksOnPage: 'Klikken',
        comments: 'Reacties',
        description: 'Beschrijving',
        increasedFollowers: 'Gestegen volgers',
        likes: 'Likes',
        percentIncreaseFollowers: 'Toename volgers',
        percentMen: 'Mannen',
        percentWomen: 'Vrouwen',
        reach: 'Bereik',
        shares: 'Delen',
        totalFollowers: 'Totaal aantal volgers'
    },
    followers: {
        title: 'Volgers',
        lost: 'Verloren',
        new: 'Nieuw',
        total: 'Totaal'
    },
    hashtags: {
        title: 'Hashtags'
    },
    locations: {
        title: 'Locaties'
    },
    mentions: {
        title: 'Vermeldingen'
    },
    monitor: {
        title: 'Monitor je kanalen',
        placeholder: 'Selecteer een kanaal...',
        averageDay: 'Gemiddeld per dag',
        averageHour: 'Gemiddeld per uur',
        bestDayToPost: 'Beste dag om te posten',
        bestHourToPost: 'Beste tijd om te posten',
        captions: 'Bijschriften',
        emojis: 'Emojis',
        hashtags: '#Hashtags',
        mentions: `{'@'}Vermeldingen`,
        topPosts: 'Top 5 berichten',
        age: {
            title: 'Leeftijd',
            subTitle: 'Likes gebaseerd op leeftijd'
        },
        emotion: {
            title: 'Emotie',
            subTitle: 'Likes gebaseerd op emotie'
        },
        gender: {
            title: 'Geslacht',
            subTitle: 'Likes gebaseerd op geslacht'
        }
    },
    post: {
        title: 'Berichten',
        comments: 'Reacties',
        date: '@:global.date',
        likes: 'Likes',
        shares: 'Delen',
        clicks: 'Klikken',
        message: 'Bericht',
        reach: 'Bereik',
        reactions: 'Reacties',
        time: '@:global.time',
        views: 'Weergaven',
        table: {
            channel: '@:analytics.channel.singular',
            date: '@:global.date',
            type: 'Type',
            engagement: 'Betrokkenheid',
            conversion: 'Conversie',
            paidYesNo: 'Betaald J/N'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            video: 'Video',
            video_inline: 'Video',
            video_direct_response: 'Video Reactie',
            reels_video: 'Reels Video',
            story_video: 'Story Video',
            feed_carousel_album: 'Feed Album',
            photo: 'Foto',
            image: 'Afbeelding',
            album: 'Album',
            carousel_album: 'Album',
            share: 'Delen',
            cover_photo: 'Hoofdfoto',
            image_share: 'Afbeelding Delen',
            native_templates: 'Advertentie',
            event: 'Evenement'
        }
    },
    reach: {
        title: 'Bereik',
        gained: 'Bereik gewonnen',
        gainedPercentage: '{0} gewonnen',
        lost: 'Bereik verloren',
        lostPercentage: '{0} verloren'
    },
    socialImpact: {
        title: 'Sociale impact',
        engagement: 'Betrokkenheid',
        followers: 'Volgers',
        growth: 'Groei',
        posts: 'Berichten',
        reach: 'Bereik',
        less: 'minder dan vorige periode',
        more: 'meer dan vorige periode'
    },
    spent: {
        title: 'Totaal uitgegeven',
        budget: 'Budget',
        cost: 'Kosten',
        total: 'Totaal'
    },
    tags: {
        title: 'Titel',
        captions: 'Bijschriften',
        hashtags: 'Hashtags',
        mentions: 'Vermeldingen'
    },
    topLocations: {
        title: 'Toplocaties',
        country: 'Land',
        visitors: 'Bezoekers'
    },
    totalCampaigns: {
        title: 'Totaal aantal campagnes',
        enabled: 'Ingeschakeld',
        disabled: 'Uitgeschakeld',
        paused: '@:analytics.paused'
    },
    crm: {
        channel: {
            title: '@:analytics.channel.plural',
            delete: {
                title: 'Kanaal verwijderen',
                message: 'Dit verwijdert het kanaal, abonnementen en alle bijbehorende gegevens. Weet u het zeker?',
                done: 'Het kanaal is verwijderd.'
            },
            refresh: {
                title: 'Kanaal vernieuwen',
                message: 'Het vernieuwen van een kanaal zal proberen maximaal 6 maanden gegevens op te halen voor elk actief abonnement. Deze actie kan tot 10 minuten duren.',
                working: 'Vernieuwing voor kanaal {0} start binnenkort. Het kan tot 5 minuten duren tot de vernieuwing is voltooid.'
            },
            fields: {
                title: 'Alle velden',
                table: {
                    name: 'Naam',
                    type: 'Type',
                    field: 'Veld',
                    group: 'Groep',
                    description: 'Beschrijving'
                }
            }
        },
        subscription: {
            refresh: 'Vernieuwing voor abonnement {0} start binnenkort. Het kan tot 5 minuten duren tot de vernieuwing is voltooid.',
            info: {
                title: 'Info',
                createdOn: 'Aangemaakt op',
                cron: 'Cron schema',
                fields: 'Velden',
                showFields: 'Toon velden',
                status: 'Status',
                type: 'Type',
                updatedOn: 'Bijgewerkt op'
            },
            chart: {
                title: 'Data'
            },
            fields: {
                name: 'Naam',
                type: 'Type',
                field: 'Veld'
            },
            history: {
                title: 'Geschiedenis'
            }
        },
        ticketing: {
            notice: {
                message: 'Gegevens worden elke dag om 11:00 uur UTC en 23:00 uur UTC gesynchroniseerd. Dit kan tot een uur duren.'
            },
            averageOrderPrice: {
                title: 'Gemiddelde bestelprijs',
                average: 'Gemiddelde prijs voor alle bestellingen'
            },
            gendersByAge: {
                title: 'Geslachten per leeftijdsgroep'
            },
            averageOrderReservation: {
                title: 'Gemiddelde tijd voor reserveringen en bestellingen',
                orderTime: 'Gemiddelde besteltijd',
                reservationTime: 'Gemiddelde reserveringstijd'
            }
        }
    }
} satisfies Translations;
