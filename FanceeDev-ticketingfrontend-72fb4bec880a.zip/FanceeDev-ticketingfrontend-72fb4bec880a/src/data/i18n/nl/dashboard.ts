import type { Translations } from '../types';

export default {
    emptyView: {
        title: 'Niets gevonden',
        message: 'Het lijkt erop dat er geen evenementen voor uw account zijn gevonden, waardoor er geen statistieken beschikbaar zijn.'
    },
    monitor: {
        title: 'Volg uw evenementen',
        subTitle: 'Kies een evenement om inzichten te krijgen in uw marktpositie.',
        select: 'Evenement selecteren...'
    },
    statistics: {
        loadingFailed: 'Er konden geen statistieken worden opgehaald. Neem contact op met support als dit probleem zich blijft voordoen.',
        notEnoughData: 'Het lijkt erop dat het evenement nog geen zinvolle statistieken heeft gegenereerd. Kom aub later terug wanneer producten zijn uitgegeven.',
        averageAge: {
            title: 'Gemiddelde leeftijd',
            tip: {
                female: 'Gemiddelde leeftijd van vrouwelijke klanten: {0} jaar.',
                male: 'Gemiddelde leeftijd van mannelijke klanten: {0} jaar.',
                neutral: 'Gemiddelde leeftijd van neutrale klanten: {0} jaar.',
                unknown: 'Gemiddelde leeftijd van onbekende klanten: {0} jaar.'
            }
        },
        fulfilledOrders: {
            title: 'Verwerkte bestellingen',
            tip: '{0} bestellingen verwerkt.'
        },
        pendingRefunds: {
            title: 'In afwachting van terugbetaling',
            tip: '{0} terugbetalingen in behandeling.'
        },
        productsSold: {
            title: 'Verkochte producten',
            tip: '{0} producten in totaal verkocht.'
        },
        ticketsScanned: {
            title: 'Tickets gescand',
            tip: '{0} tickets in totaal gescand.'
        },
        uniqueCustomers: {
            title: 'Unieke klanten',
            tip: {
                female: '{0} unieke vrouwelijke klanten.',
                male: '{0} unieke mannelijke klanten.',
                neutral: '{0} unieke neutrale klanten.',
                unknown: '{0} unieke onbekende klanten.'
            }
        },
        finance: {
            cashSalesRevenue: 'Kassabonverkoop',
            onlineSalesRevenue: 'Online verkoop',
            platformExpenses: 'Platformkosten',
            profit: 'Winst'
        },
        bestSellingProducts: {
            title: 'Top-producten',
            subTitle: 'Best verkochte producten van de afgelopen {0} dagen.'
        },
        dailyOrders: {
            title: 'Bestelomzet',
            subTitle: 'Overzicht van dagelijks voltooide bestellingen.',
            ordersOnDay: 'Bestellingen op dag',
            cashRevenue: 'Kassabonverkoop',
            onlineRevenue: 'Online verkoop',
            orders: 'Bestellingen',
            productsSold: 'Verkochte producten',
            revenueFlow: 'Omzetstroom'
        },
        productRatio: {
            title: 'Product ratio',
            subTitle: 'Productstroom op basis van het bedrag.'
        },
        productStatistics: {
            guest: 'Gast',
            guestlistTip: 'Houd er rekening mee dat gastelijsttickets mogelijk niet altijd van de voorraad worden afgetrokken.',
            name: '@:form.field.name',
            pending: 'In afwachting',
            pendingTip: '{0} reserveringen zijn in afwachting, waarvan {1} momenteel in het betalingsproces zitten.',
            price: '@:form.field.price',
            remaining: 'Resterend',
            sold: '@:global.sold',
            stock: '@:form.field.stock'
        }
    },
    wallet: {
        title: 'Portemonnee saldo',
        manage: 'Beheer'
    }
} satisfies Translations;
