import type { Translations } from '../types';

export default {
    navigation: {
        blockedEmails: 'Geblokkeerde e-mails',
        defaultPaymentMethods: 'Standaard betaalmethoden',
        defaultShopPalette: 'Standaard winkelpalet',
        roleManagement: 'Rollenbeheer'
    },
    blockedEmails: {
        add: 'Geblokkeerde e-mail toevoegen',
        addSuccess: '{0} is succesvol geblokkeerd.',
        deleteEverythingConfirm: 'Deze actie verwijdert alle geblokkeerde e-mails uit uw account.',
        deleteEverythingFailed: 'Er is een fout opgetreden bij het verwijderen van alle geblokkeerde e-mails. Probeer het later opnieuw of neem contact op met support voor hulp.',
        deleteEverythingSuccess: 'Alle geblokkeerde e-mails zijn succesvol verwijderd.',
        deleteFailed: 'Er is een fout opgetreden bij het verwijderen van een geblokkeerde e-mail. Probeer het later opnieuw of neem contact op met support voor hulp.',
        deleteSuccess: 'Geblokkeerde e-mail succesvol verwijderd.',
        loadingFailed: 'Er is een fout opgetreden bij het laden van geblokkeerde e-mails. Probeer het later opnieuw. Als het probleem zich blijft voordoen, neem dan contact op met support voor hulp.'
    },
    defaultPaymentMethods: {
        loadingFailed: 'Er is een fout opgetreden bij het ophalen van uw standaard betaalmethoden. Neem contact op met support als dit probleem zich blijft voordoen.',
        savingFailed: 'Er is een fout opgetreden bij het opslaan van uw standaard betaalmethoden. Neem contact op met support als dit probleem zich blijft voordoen.'
    },
    defaultShopPalette: {
        title: 'Standaard winkelpalet',
        description: 'Bewaar uw huisstijlkleuren als een standaardpalet voor eenvoudige toepassing in uw winkels.',
        background: 'Achtergrond',
        panel: 'Paneel',
        primary: 'Primair',
        text: 'Tekst'
    },
    roleManagement: {
        title: 'Rollenbeheer',
        notice: 'Door rollen toe te wijzen aan externe gebruikers, kunt u toegang verlenen tot delen van het account van uw organisatie. Dit maakt het mogelijk om het beheer van dagelijkse taken te delen of inzichten te bieden in specifieke gebieden van uw organisatie.',
        addFailed: 'Er is een onbekende fout opgetreden tijdens het toewijzen van de gebruiker. Neem contact op met support als dit probleem zich blijft voordoen.',
        addSuccess: 'De gebruiker is succesvol toegevoegd aan de organisatie.',
        deleteFailed: 'Er is een onbekende fout opgetreden tijdens het verwijderen van de gebruiker. Neem contact op met support als dit probleem zich blijft voordoen.',
        deleteSuccess: 'De gebruiker is succesvol verwijderd uit de organisatie.',
        loadingFailed: 'Er is een onbekende fout opgetreden tijdens het laden van uw gebruikers. Neem contact op met support als dit probleem zich blijft voordoen.',
        updateFailed: 'Er is een onbekende fout opgetreden tijdens het bijwerken van de toegewezen gebruiker. Neem contact op met support als dit probleem zich blijft voordoen.',
        configure: {
            title: {
                add: 'Nieuwe gebruiker toevoegen',
                edit: '{0} bewerken'
            },
            rights: 'Rechten',
            loadingFailed: 'Er is een onbekende fout opgetreden tijdens het laden van uw claims. Neem contact op met de ondersteuning als dit probleem zich blijft voordoen.'
        }
    }
} satisfies Translations;
