import type { Translations } from '../types';

export default {
    title: 'Marketing',
    agenda: {
        plural: 'Agenda\'s',
        singular: 'Agenda',
        title: '@:marketing.agenda.plural',
        table: {
            all: 'Alle actieve @.lower:event.plural'
        },
        deleteFailed: 'Er is een fout opgetreden tijdens het verwijderen van de agenda. Neem contact op met support als dit probleem zich blijft voordoen.',
        deleteSuccessful: 'De agenda is succesvol verwijderd.',
        loadingFailed: 'Er is een fout opgetreden tijdens het ophalen van agenda\'s. Neem contact op met support als dit probleem zich blijft voordoen.',
        loadingEventsFailed: 'Er is een fout opgetreden tijdens het laden van uw evenementen. Probeer het later opnieuw.',
        loadingSingleFailed: 'De agenda kon niet worden gevonden. Doorverwijzing naar overzicht.',
        savingFailed: 'Er is een fout opgetreden tijdens het opslaan van de agenda. Neem contact op met support als dit probleem zich blijft voordoen.',
        savingSuccessful: 'De agenda is succesvol opgeslagen.',
        configure: {
            title: {
                create: 'Maak @.lower:marketing.agenda.singular',
                edit: 'Bewerk @.lower:marketing.agenda.singular'
            },
            allEvents: 'Gebruik alle @.lower:event.plural',
            showHeaders: 'Laat evenementkoppen zien'
        }
    },
    campaign: {
        plural: 'Campagnes',
        singular: 'Campagne',
        title: '@:marketing.campaign.plural',
        search: `Zoek @.lower:{'marketing.campaign.plural'}...`,
        deleteConfirm: `Weet u zeker dat u de @.lower:{'marketing.campaign.singular'} {0} wilt verwijderen?`,
        deleteFailed: `Er is een fout opgetreden tijdens het verwijderen van de @.lower:{'marketing.campaign.singular'}. Neem contact op met support voor hulp.`,
        deleteSuccessful: `Uw @.lower:{'marketing.campaign.singular'} is succesvol verwijderd.`,
        exportFailed: `Er is een fout opgetreden tijdens het exporteren van uw @.lower:{'marketing.campaign.plural'}. Neem contact op met support als dit probleem zich blijft voordoen.`,
        loadingFailed: `Er is een fout opgetreden tijdens het ophalen van uw @.lower:{'marketing.campaign.plural'}. Neem contact op met support als dit probleem zich blijft voordoen.`,
        table: {
            name: '@:marketing.campaign.singular',
            event: '@:event.singular',
            clicks: 'Klikken',
            revenue: 'Omzet',
            productsSold: 'Verkochte producten',
            averageAge: 'Gemiddelde leeftijd',
            genderSplit: 'Geslachtsverdeling',
            salesSplitTip: '{productAmount} tickets zijn verkocht over {orderAmount} bestellingen van {reservationAmount} reserveringen.'
        },
        configure: {
            title: 'Configureer @.lower:marketing.campaign.singular',
            loadingEventsFailed: 'Er is een fout opgetreden tijdens het laden van uw evenementen. Probeer het later opnieuw.',
            savingFailed: `Er is een fout opgetreden tijdens het opslaan van de @.lower:{'marketing.campaign.singular'}. Neem contact op met support als het probleem zich blijft voordoen.`,
            savingSuccessful: `Uw @.lower:{'marketing.campaign.singular'} is opgeslagen. U kunt de tracking-URL vinden via de deelknop in het overzicht.`,
            info: `Een @.lower:{'marketing.campaign.singular'} tracking-URL kan aan meerdere winkels worden toegewezen, zolang ze deel uitmaken van hetzelfde evenement.`,
            eventsHint: `Bestaande @.lower:{'marketing.campaign.plural'} kunnen hun evenement vanwege statistieken niet wijzigen; u kunt echter wel winkels toevoegen of verwijderen.`,
            shopDisabledHint: 'Selecteer eerst een evenement.'
        }
    },
    preRegister: {
        title: '@:marketing.preRegister.plural',
        plural: 'Pre-registraties',
        singular: 'Pre-registratie',
        search: `Zoek @.lower:{'marketing.preRegister.plural'}...`,
        table: {
            name: '@:form.field.name',
            registered: 'Registraties',
            downloadCsv: 'Download CSV',
            exportSecureShop: 'Export beveiligde winkel',
            expiresOn: 'Verloopt op'
        },
        deleteConfirm: `Door het verwijderen van deze @.lower:{'marketing.preRegister.singular'} worden ook de bijbehorende registratie-items verwijderd.`,
        deleteFailed: `De @.lower:{'marketing.preRegister.singular'} kon niet worden verwijderd. Neem contact op met support voor verdere hulp.`,
        deleteSuccessful: `De @.lower:{'marketing.preRegister.singular'} {name} is succesvol verwijderd.`,
        downloadFailed: `Er is een fout opgetreden tijdens het downloaden van de @.lower:{'marketing.preRegister.singular'} export. Neem contact op met support voor verdere hulp.`,
        exportFailed: `Er is een fout opgetreden tijdens het ophalen van de aanmeldingen voor deze @.lower:{'marketing.preRegister.singular'}. Probeer het later opnieuw.`,
        exportFailedNoEntries: 'Momenteel zijn er geen aanmeldingen beschikbaar voor export.',
        loadingFailed: `Er is een fout opgetreden bij het ophalen van uw @.lower:{'marketing.preRegister.singular'}s. Neem contact op met support voor hulp.`,
        configure: {
            createdSuccessfully: `De @.lower:{'marketing.preRegister.singular'} voor {name} is succesvol gemaakt.`,
            saveFailed: `Er is een fout opgetreden tijdens het opslaan van uw @.lower:{'marketing.preRegister.singular'}. Neem contact op met support voor hulp.`,
            create: `Maak @.lower:{'marketing.preRegister.singular'}`,
            edit: `Bewerk @.lower:{'marketing.preRegister.singular'}`,
            header: {
                title: 'Header',
                description: 'Afbeelding die wordt gebruikt voor de header van de pre-registratie.'
            }
        },
        signUp: {
            complete: {
                title: 'Aanmelding voltooid',
                message: 'Aanmelding voltooid. Uw registratie voor {name} is succesvol geregistreerd. U kunt dit venster nu sluiten. Houd er rekening mee dat het meerdere keren invullen van dit formulier niet nodig is, aangezien alleen unieke inzendingen worden verwerkt.'
            },
            expired: {
                title: 'Verlopen',
                message: `De @.lower:{'marketing.preRegister.singular'} periode is verlopen. Het is niet langer mogelijk om te registreren.`
            },
            failed: 'Er is een fout opgetreden tijdens het laden van uw preregister. Probeer het later opnieuw.'
        }
    }
} satisfies Translations;
