import type { Translations } from '../types';

export default {
    logout: 'Afmelden',
    useClient: 'Bekijk mijn persoonlijke account',
    login: {
        title: 'Inloggen',
        description: 'Voer uw inloggegevens in om toegang te krijgen tot uw account.',
        submit: 'Aanmelden',
        or: 'Of',
        createAccount: 'Account aanmaken',
        forgotPassword: 'Wachtwoord vergeten?'
    },
    register: {
        title: 'Registreren',
        description: 'Welkom bij WeAreFancee! Voordat u een account aanmaakt, geef aub aan welk type account u wilt creëren.',
        clientTitle: 'Klant',
        clientDescription: 'Ik wil mijn eigen tickets zien.',
        organizationTitle: 'Organisatie',
        organizationDescription: 'Ik heb ticketing nodig voor mijn evenement(en).',
        complete: 'Uw account is aangemaakt! Controleer uw e-mailinbox op een verificatiebericht.',
        submit: 'Registreren',
        client: {
            title: 'Registreren - Klant',
            description: `Laten we beginnen met het aanmaken van uw persoonlijke WeAreFancee-account. Vul het onderstaande formulier in om verder te gaan.`
        },
        organization: {
            title: 'Registreren - Organisatie',
            description: `Laten we beginnen met het aanmaken van uw WeAreFancee-account. Zodra uw account is aangemaakt, wordt er een contract opgesteld. U zou meteen kunnen beginnen. Vul het onderstaande formulier in om verder te gaan.`
        }
    },
    select: {
        title: 'Hallo {name},',
        description: 'Met uw account kunt u verschillende organisaties beheren. In welke organisatie wilt u duiken?'
    },
    verify: {
        title: 'Accountverificatie',
        description: 'Even geduld, we controleren uw accountgegevens.',
        busy: 'Verifiëren...',
        done: 'Uw account is geverifieerd! U kunt nu inloggen.'
    },
    forgotPassword: {
        title: 'Wachtwoord opnieuw instellen',
        description: `Geen zorgen! Als u uw wachtwoord bent vergeten, vult u hieronder uw e-mailadres in. Wij sturen vervolgens instructies over hoe u het wachtwoord kunt resetten.`,
        feedback: `Als u een account hebt bij @:global.platform.name ontvangt u een e-mail met instructies over hoe u uw wachtwoord kunt resetten.`
    },
    forgotPasswordReset: {
        title: '@:auth.forgotPassword.title',
        description: `Voer uw nieuwe wachtwoord hieronder in om weer toegang te krijgen tot uw account. Zorg ervoor dat het voldoet aan onze beveiligingseisen. Zodra uw nieuwe wachtwoord is ingesteld, kunt u uw account veilig gebruiken.`,
        success: `Uw wachtwoord is gereset. U wordt binnenkort doorgestuurd naar de inlogpagina.`
    },
    reauthenticate: {
        title: `U bent uitgelogd.`,
        body: 'Om uw account te blijven gebruiken, meldt u zich opnieuw aan met uw wachtwoord.',
        submit: '@:auth.login.submit'
    },
    sessions: {
        singular: 'Sessie',
        plural: 'Sessies',
        search: 'Zoek sessies...',
        device: 'Apparaat',
        ipAddress: 'IP-adres',
        issuedOn: 'Aangemaakt op',
        expires: 'Verloopt',
        deleteFailed: 'De sessie kon niet worden verwijderd. Probeer het later opnieuw.',
        loadingFailed: 'Kon geen sessies ophalen. Probeer het later opnieuw.',
        deleted: 'De sessie is succesvol verwijderd.'
    }
} satisfies Translations;
