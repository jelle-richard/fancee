import type { Translations } from '../types';

export default {
    plural: 'Evenementen',
    singular: 'Evenement',
    discountPlural: 'Kortingen',
    discountSingular: 'Kortingscode',
    productPlural: 'Producten',
    productSingular: 'Product',
    shopPlural: 'Winkels',
    shopSingular: 'Winkel',
    ticketPlural: 'Tickets',
    ticketSingular: 'Ticket',
    createEvent: 'Evenement aanmaken',
    manageEvent: 'Evenement beheren',
    myEvents: 'Mijn evenementen',
    list: {
        deletionFailed: 'Kan evenement "{0}" niet verwijderen.',
        searchPlaceholder: 'Zoek evenementen...',
        table: {
            deactivated: 'Deze winkel is gedeactiveerd.',
            event: '@:event.singular',
            organization: 'Organisatie',
            shops: '@:event.shopPlural',
            status: 'Status'
        },
        emptyView: {
            title: 'Geen evenementen',
            message: 'Er zijn nog geen evenementen aangemaakt in uw account.',
            add: '@:event.singular toevoegen'
        }
    },
    discount: {
        title: 'Kortingen',
        searchPlaceholder: 'Zoek kortingscodes...',
        loadingEventsFailed: 'Er is een fout opgetreden tijdens het laden van uw evenementen. Probeer het later opnieuw.',
        loadingProductsFailed: 'Er is een fout opgetreden tijdens het laden van uw producten. Probeer het later opnieuw.',
        filter: {
            includeExpired: 'Inclusief verlopen kortingscodes',
            shops: '@:event.shopPlural',
            shopsSearchPlaceholder: `Zoek in @.lower:{'event.shopPlural'}...`
        },
        table: {
            code: 'Code',
            used: 'Gebruikt',
            amount: 'Bedrag',
            expires: 'Vervalt op'
        },
        deleteFailed: 'Er is een onbekende fout opgetreden tijdens het verwijderen van de kortingscode. Neem contact op met support voor hulp.',
        getFailed: 'Er is een onbekende fout opgetreden tijdens het ophalen van uw kortingscode. Neem contact op met support voor hulp.',
        listFailed: 'Er is een onbekende fout opgetreden tijdens het ophalen van uw kortingscodes. Neem contact op met support voor hulp.',
        deleted: 'Kortingscode succesvol verwijderd.',
        saved: 'Kortingscode succesvol opgeslagen.',
        configurator: {
            title: {
                create: '@.lower:event.discountSingular} aanmaken',
                edit: '@.lower:event.discountSingular} bewerken'
            },
            expires: 'Vervalt op',
            stock: 'Voorraad',
            assignTo: {
                label: 'Toewijzen aan',
                placeholder: 'Kortingscode geldt voor...',
                description: {
                    products: [
                        'Bij het toewijzen van een vaste korting aan een product wordt het bedrag per product in de bestelling afgehaald. Percentagekortingen worden afgetrokken van het totale bedrag van de producten.',
                        'Selecteer evenementen om uw producten te vinden'
                    ],
                    shops: 'Bij het toewijzen van een korting aan een winkel wordt het bedrag afgetrokken van het totaalbedrag van de bestelling.'
                }
            },
            code: {
                label: 'Code',
                placeholder: '@:form.eg LENTE15'
            },
            value: {
                labelFixed: 'Vaste korting',
                labelPercentage: 'Percentagekorting'
            },
            validate: {
                assignmentRequirement: 'Er moet minstens één winkel of product aan de kortingscode worden toegewezen.',
                valueRequirement: 'Er ontbreekt een vaste of percentagekortingswaarde.'
            }
        }
    },
    guestlist: {
        singular: 'Gastenlijst',
        plural: 'Gastenlijsten',
        title: '@:event.guestlist.plural',
        selector: {
            title: 'Beheer gastenlijsten',
            search: '@:event.list.searchPlaceholder'
        },
        empty: 'U kunt alleen gastenlijsten beheren voor actieve evenementen. Verfijn uw zoekopdracht of controleer of u actieve evenementen heeft.',
        manage: {
            title: 'Gastenlijst bewerken',
            onlyActiveEvents: 'Gastenlijsten kunnen alleen naar actieve evenementen worden verstuurd.',
            deduct: 'Voorraad aftrekken',
            guest: 'Gast',
            hasHeader: 'CSV heeft een header',
            failed: 'Er is een fout opgetreden tijdens het versturen van de gastenlijst. Neem contact op met support voor hulp.',
            success: 'Uw gasttickets zijn succesvol verstuurd.',
            manual: {
                title: 'Uitnodigen'
            },
            import: {
                title: 'Importeren',
                info: 'Om meerdere gasten tegelijk te uploaden, uploadt u een CSV-bestand met minimaal het e-mailadres en de hoeveelheid tickets die u wilt versturen. Wanneer u veldtypen toewijst aan de waarden in uw bestand, is het belangrijk om te controleren of uw bestand een header heeft en dit dienovereenkomstig aan te vinken.',
                choose: 'Bestand kiezen',
                maxRows: 'U kunt een CSV-bestand uploaden met maximaal {0} e-mailadressen.',
                maxRowsExceeded: 'Het maximum aantal van {0} gastenlijst-imports is overschreden.',
                missingEmailField: 'Er is geen veld als e-mail toegewezen.',
                missingQuantityField: 'Er is geen veld als aantal toegewezen.',
                table: {
                    example: 'Voorbeelddocumentatie',
                    field: 'Veldtype'
                }
            }
        }
    },
    ticket: {
        title: '@:event.ticketPlural',
        addBarcodes: 'Barcodes',
        searchPlaceholder: `Zoek @.lower:{'event.ticketPlural'}...`,
        table: {
            event: '@:event.singular',
            shop: '@:event.shopSingular',
            ticket: '@:event.ticketSingular',
            code: 'Code',
            origin: 'Herkomst',
            scanStatus: 'Scanstatus',
            scanTime: 'Scantijd',
            holder: 'Houder',
            state: 'Status'
        },
        filter: {
            acquirerOrigin: 'Herkomstverwerver',
            promotionalEmail: 'Promotie-e-mail',
            promotionalSms: 'Promotie-sms',
            receiveOrderSms: 'Bestelling ontvangen SMS',
            scanState: 'Scanstatus'
        },
        origin: {
            app: 'Verkregen via @:global.platform.name app',
            generated: 'Gegenereerd door @:global.platform.name',
            guestlist: '@:global.platform.name gastenlijst',
            imported: 'Geïmporteerd naar @:global.platform.name',
            shop: 'Verkregen via @:global.platform.name shop',
            ticketswap: 'Verkregen via TicketSwap',
            filter: {
                app: '@:global.platform.name app',
                generated: 'Gegenereerd',
                guestlist: '@:global.platform.name gastenlijst',
                imported: 'Geïmporteerd',
                shop: '@:global.platform.name shop',
                ticketswap: 'TicketSwap'
            }
        },
        single: {
            title: '@:event.ticketSingular informatie',
            info: {
                name: '@:event.ticketSingular naam',
                code: 'Code',
                markScanned: 'Markeer als gescand',
                markUnscanned: 'Markeer als niet gescand',
                scanStatus: 'Scanstatus',
                seatLocation: 'Stoellocatie',
                viewOrder: 'Bekijk bestelling',
                scanStateConfirm: 'Wilt u de scanstatus van ticket {code} bijwerken naar {state}?',
                scanStateUpdated: 'Scanstatus bijgewerkt',
                advanced: {
                    title: 'Geavanceerde mogelijkheden',
                    invalidate: {
                        title: 'Ongeldig maken',
                        explanation: 'Je kunt een ticket ongeldig maken, zodat het ticket niet meer gebruikt kan worden',
                        returnToStock: 'Terug naar voorraad',
                        giveReason: 'Geef een reden op waarom het ticket ongeldig is gemaakt, de klant krijgt hierover een melding',
                        failed: 'Kan het ticket niet ongeldig maken. Als het probleem zich blijft voordoen, neem dan contact op met de ondersteuning voor hulp.',
                        success: 'Het ticket is ongeldig gemaakt'
                    }
                },
                ticketState: 'Ticket status'
            },
            client: {
                title: 'Klantinformatie',
                belongsTo: 'Behoort tot',
                boughtBy: 'Gekocht door',
                boughtInShop: 'Gekocht in de winkel',
                enabledSms: 'SMS ingeschakeld',
                enabledTsp: 'TSP ingeschakeld',
                optins: {
                    label: 'Promotie opt-ins',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            holder: {
                title: 'Houderinformatie'
            }
        }
    },
    scanState: {
        notScanned: 'Niet gescand',
        scanned: 'Gescand',
        unscanned: 'Niet gescand'
    },
    status: {
        title: 'Evenement status',
        active: 'Actief',
        canceled: 'Geannuleerd',
        cancelled: '@:event.status.canceled',
        concept: 'Concept',
        concluded: 'Afgerond',
        soldOut: 'Uitverkocht',
        unpublished: 'Niet gepubliceerd'
    },
    addBarcodesOverlay: {
        title: 'Barcodes',
        generate: 'Genereer',
        import: 'Importeren',
        selectEvent: 'Selecteer evenement...',
        selectProduct: 'Selecteer product...',
        submitGenerate: 'Genereer',
        submitImport: 'Importeren',
        generateError: 'Er is een fout opgetreden bij het genereren van barcodes.',
        importError: 'Er is een fout opgetreden bij het importeren van barcodes.',
        productLoadingFailed: 'Er is een fout opgetreden tijdens het laden van producten.',
        importDuplicateFound: 'Er zijn dubbele velden gevonden. Zorg ervoor dat een veldtype slechts één keer wordt geselecteerd.',
        importMax: 'U kunt maximaal {amount} barcodes tegelijk importeren.',
        importMissingBarcode: 'Een barcode-veldtype is vereist. Zorg ervoor dat er één is geselecteerd.',
        success: {
            title: 'Barcodes toegevoegd',
            message: 'Succesvol {amount} nieuwe barcodes toegevoegd.'
        },
        fieldType: {
            barcode: 'Barcode',
            email: '@:form.field.email',
            firstName: '@:form.field.firstName',
            lastName: '@:form.field.lastName'
        }
    },
    copyEventOverlay: {
        title: '{0} kopiëren',
        info: 'U staat op het punt om {0} te kopiëren, selecteer de gewenste aanvullende informatie die u wilt meekopiëren.',
        categories: {
            title: 'Categorieën',
            description: 'Alle categorieën kopiëren.'
        },
        paymentMethods: {
            title: 'Betaalmethoden',
            description: 'Alle betaalmethoden kopiëren.'
        },
        products: {
            title: 'Producten',
            description: 'Alle producten kopiëren.'
        },
        shops: {
            title: '@:event.shopPlural',
            description: `Alle @.lower:{'event.shopPlural'} kopiëren.`
        }
    },
    cancelOverlay: {
        title: 'Evenement annuleren',
        explanation: 'Let op: het annuleren van het evenement is een permanente actie die niet ongedaan kan worden gemaakt. Eenmaal geannuleerd, kan het evenement niet worden hersteld.',
        giveReason: 'Geef een gedetailleerde reden waarom u het evenement annuleert.',
        failed: 'Er is een fout opgetreden tijdens het annuleren van uw evenement. Probeer het later opnieuw.',
        success: 'Het evenement is succesvol geannuleerd.'
    },
    cancelPane: {
        title: 'Annuleren',
        explanation: 'Als u ervoor kiest om uw evenement te annuleren, wordt het uitgeschakeld en kunnen er geen producten meer worden verkocht.',
        notice: '@:event.cancelOverlay.explanation',
        submit: 'Evenement annuleren'
    },
    unpublishPane: {
        title: 'Niet-publiceren',
        explanation: 'Als u ervoor kiest om uw evenement niet te publiceren, wordt het tijdelijk uitgeschakeld totdat u besluit het opnieuw te publiceren.',
        submit: 'Niet publiceren'
    },
    create: {
        step: {
            type: 'Type',
            details: 'Details',
            products: '@:event.productPlural',
            shops: '@:event.shopPlural',
            payment: 'Betaling',
            mailing: 'Mailing',
            design: 'Ticket design',
            publish: 'Publiceren'
        },
        details: {
            seatingEventId: 'Zaal evenement ID',
            categories: {
                label: 'Categorieën',
                placeholder: 'Kies een paar optionele categorieën voor je evenement...'
            },
            header: {
                label: 'Header',
                description: 'Afbeeldingen die worden gebruikt als header voor je evenement.'
            },
            minimalAge: {
                hint: 'Bij evenementen met leeftijdsbeperkingen moet de leeftijd van de gasten worden gevraagd. Laat het veld leeg als er geen beperking is.',
                label: 'Minimumleeftijd',
                placeholder: '@:form.eg 16'
            },
            timezone: {
                info: 'Je evenement vindt plaats in de {timezone} tijdzone.',
                change: 'Gebruik een andere tijdzone.'
            },
            sealed: {
                label: 'Verzegeld event',
                hint: 'Als je eenmaal verzegelde verkoop hebt aangezet en opslagen kan dit later niet ongedaan gemaakt worden',
                enabled: 'Verzegelde ticket verkoop staat aan voor dit evenement'
            }
        },
        mailing: {
            title: 'Mailing',
            content: 'Inhoud',
            mailType: 'Mail type',
            mailTypes: {
                guestlist: 'Gastenlijst uitnodigingsmail',
                purchase: 'Aankoopmail',
                sealed: 'Verzegelde ticket bezorgings mail'
            },
            senderName: 'Afzendernaam',
            senderNamePlaceholder: '@:global.platform.name',
            subject: 'Onderwerp',
            subjectPlaceholder: 'Uw aankoopbevestiging voor Evenement',
            variables: {
                title: 'Variabelen',
                info: 'E-mails kunnen aangepaste tekst bevatten op basis van de onderstaande variabelen, die worden vervangen door de juiste waarden wanneer de e-mail wordt verzonden.'
            },
            sealed: {
                title: 'Verzegelde tickets aflevering',
                message: 'Je hebt verzegelde ticketbezorging voor je evenement ingeschakeld en daarom kun je hieronder ook de bezorgmail wijzigen'
            }
        },
        paymentMethods: {
            title: 'Betaalmethoden',
            defaults: 'Uw standaard betaalinstellingen worden momenteel toegepast. Wijzig een van deze instellingen om deze te overschrijven.',
            paidByCustomer: 'Ingeschakeld, betaald door klant',
            paidByOrganization: 'Ingeschakeld, betaald door organisatie',
            loadingFailed: 'Er is een fout opgetreden tijdens het ophalen van uw standaard betaalmethoden. Neem contact op met support als dit probleem zich blijft voordoen.',
            klarnaInfo: 'Voor deze betaalmethode moet het veld \'adres\' in de shop-instellingen worden ingesteld op \'verplicht\'.',
            psd2: {
                title: 'Opgelet, PSD2 is mogelijk op u van toepassing!',
                paragraphs: [
                    'Volgens de PSD2-wetgeving is het niet altijd toegestaan om uw klanten extra kosten te rekenen voor betaalmethoden.',
                    'Een van de bepalingen van PSD2 is het verbod op toeslagen, wat betekent dat verkopers klanten geen extra kosten mogen rekenen voor het gebruik van specifieke betaalmethoden, zoals creditcards of bankpassen. Dit is bedoeld om consumenten te beschermen tegen verborgen of buitensporige kosten, transparantie te bevorderen en ervoor te zorgen dat de door verkopers geadverteerde prijzen voor alle betaalmethoden hetzelfde zijn.',
                    'Het is belangrijk op te merken dat hoewel PSD2 van toepassing is op alle EU-lidstaten, sommige landen de wet mogelijk anders hebben geïmplementeerd, dus de exacte regels over toeslagen kunnen verschillen. Over het algemeen is de wet echter bedoeld om te voorkomen dat verkopers de kosten van het accepteren van kaartbetalingen doorberekenen aan consumenten. Dit betekent dat verkopers verplicht zijn de kosten van de betaling zelf te dragen, in plaats van klanten extra kosten te rekenen voor het gebruik van bepaalde betaalmethoden.',
                    'Er zijn enkele uitzonderingen per land, maar doe uw eigen due diligence. Zo mogen iDeal, PayPal en AMEX in Nederland worden toeslagen.'
                ]
            }
        },
        products: {
            add: {
                ticket: '@:event.ticketSingular @.lower:global.add',
                product: '@:event.productSingular @.lower:global.add'
            },
            configurator: {
                access: {
                    title: 'Toegang',
                    partial: {
                        label: 'Gedeeltelijke toegang',
                        hint: 'Wanneer \'Gedeeltelijke toegang\' ingeschakeld is, kunnen klanten het evenement alleen betreden binnen de opgegeven tijdsperiode.',
                        end: 'Einde',
                        start: 'Start'
                    }
                },
                advanced: {
                    title: 'Geavanceerd',
                    ticketSwap: {
                        label: 'TicketSwap',
                        hint: 'Maakt veilige doorverkoop van het ticket op TicketSwap mogelijk. Houd er rekening mee dat het raadzaam is om contact op te nemen met TicketSwap als je dit voor het hele evenement uitschakelt.',
                        sealedSwapUnfinishedTitle: 'Ticketswap niet mogelijk',
                        sealedSwapUnfinishedDescription: 'Vanwege werkzaamheden aan het einde van TicketSwaps kan TicketSwap op dit moment niet worden gebruikt voor verzegelde evenementen. Kom later terug'
                    }
                },
                details: {
                    title: 'Details',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Early Bird'
                    },
                    description: {
                        label: '@:form.field.description',
                        placeholder: '@:form.eg Geeft u de beste plek op onze locatie.'
                    }
                },
                images: {
                    title: 'Afbeeldingen'
                },
                salesFlow: {
                    title: 'Verkoopstroom',
                    administrationFee: {
                        label: 'Administratiekosten',
                        hint: 'Dit zijn de kosten die u bovenop de ticketprijs plaatst. Wanneer leeg, worden de kosten in uw contract gebruikt.'
                    },
                    maxOrderQuantity: {
                        label: 'Maximaal aantal bestellingen'
                    },
                    packQuantity: {
                        labelProduct: 'Aantal',
                        labelTicket: 'Aantal barcodes in groepsticket',
                        hint: 'Het product wordt verkocht per opgegeven hoeveelheid. Bijvoorbeeld: Het product wordt in sets van twee verkocht als er twee wordt ingevoerd.'
                    },
                    dateTime: {
                        title: 'Datum tijd',
                        hint: 'Verkoop uw product gedurende de opgegeven datumbereik.',
                        saleEnd: 'Einde verkoop',
                        saleStart: 'Start verkoop'
                    },
                    waveLink: {
                        title: 'Golf link',
                        hint: 'Verkoop uw product zodra het geselecteerde product nog 10% voorraad heeft.',
                        linkedTicket: 'Gekoppeld ticket',
                        circular: 'Deze combinatie van golf links is niet mogelijk. Beide producten creëren een circulaire keten.',
                        disabled: 'U moet minimaal twee producten hebben voor deze functie om te werken.'
                    }
                },
                scanning: {
                    title: 'Scannen',
                    notification: {
                        label: 'Melding',
                        placeholder: '@:form.eg Geef 5 munten bij aankomst.'
                    },
                    preArrivalThreshold: {
                        label: 'Drempelwaarde voor aankomst',
                        hint: 'Laat klanten de gegeven hoeveelheid minuten aankomen voordat hun toegang begint.'
                    }
                },
                hint: {
                    title: 'Meer product opties',
                    description: 'Er zijn nog meer opties voor uw producten, klik op het tandwielpictogram van een product om ze te bekijken.'
                }
            },
            empty: {
                title: '@:event.productPlural',
                description: [
                    'Begin met het opbouwen van je shopvoorraad door tickets en/of producten toe te voegen. Je tickets en producten kunnen worden geconfigureerd naar de behoeften van je marketingstrategie, voorraadbeheer, scanpersoneel en nog veel meer.',
                    'Nadat je al je tickets en/of producten hebt aangemaakt, kun je ze in de volgende stap toewijzen en ontwerpen.'
                ]
            },
            group: {
                products: '@:event.productPlural',
                seatedTickets: 'Geplaceerde @.lower:event.ticketPlural',
                tickets: '@:event.ticketPlural'
            },
            new: {
                product: 'Nieuw @.lower:event.productSingular',
                ticket: 'Nieuw @.lower:event.ticketSingular'
            },
            row: {
                name: {
                    label: '@:form.field.name',
                    placeholder: '@:event.create.products.configurator.details.name.placeholder'
                },
                price: {
                    label: '@:form.field.price',
                    change: `Houd er rekening mee dat u op het punt staat de prijs te wijzigen van een ticket waarvoor al verkoop is. Overweeg een nieuwe ticket te maken voor de nieuw geprijsde tickets.`
                },
                seats: {
                    label: 'Plaatsen'
                },
                stock: {
                    label: '@:form.field.stock',
                    placeholder: '@:form.eg 100'
                }
            }
        },
        publish: {
            notReady: {
                title: 'Bijna klaar',
                info: 'Je evenement is bijna klaar om gepubliceerd te worden. Voltooi de onderstaande stappen voordat je je evenement publiceert.',
                missingPaymentMethods: {
                    action: 'Betaalmethoden configureren',
                    message: 'Er zijn geen betaalmethoden geconfigureerd voor je evenement.'
                },
                missingSellableProducts: {
                    action: 'Shops configureren',
                    message: 'Je evenement heeft minimaal één shop met verkoopbare producten nodig.'
                }
            },
            ready: {
                title: 'Klaar om te publiceren!',
                info: 'Alles is klaar om te worden gepubliceerd. Je kunt je evenement ook opslaan zonder te publiceren als je er nog niet helemaal klaar voor bent.',
                requestReview: 'Beoordeling aanvragen',
                requestReviewPending: 'Beoordeling aangevraagd, een van onze medewerkers zal contact met u opnemen.'
            },
            scanning: {
                title: 'Scannen',
                paragraphs: [
                    'Hulp nodig met scannen? WeAreFancee biedt de mogelijkheid om de benodigde hardware en/of personeel uit te besteden.',
                    'Geïnteresseerd? Neem contact op met onze support afdeling. We helpen je graag!'
                ],
                submit: 'Instructies downloaden',
                file: 'Scaninstructies'
            },
            status: {
                canceled: 'Dit evenement is geannuleerd.',
                unpublished: 'Dit evenement is niet gepubliceerd. Het is momenteel niet mogelijk om producten via de shops te kopen.',
                soldIn: 'Verkocht in: {0}',
                soldNowhere: 'Nergens verkocht'
            }
        },
        seatingSetup: {
            title: 'Zitplaatsindeling',
            explanation: 'Ons support team verzorgt de initiële setup van dit evenement voor u. Neem contact met hen op om te beginnen.',
            failed: {
                title: 'Validatie mislukt',
                message: 'We hebben geprobeerd contact op te nemen met SeatsIO voor het valideren van het evenement. Probeer het later opnieuw.',
                notice: 'De opgegeven SeatsIO Event ID is ongeldig.'
            },
            setupId: '@:event.create.details.seatingEventId'
        },
        shops: {
            designer: 'Ontwerper',
            default: {
                buttonLabel: 'Nieuwe knop',
                noticeContent: 'Dit is een voorbeeldtekst voor een notitie, voer uw bericht in.',
                shopName: 'Nieuwe shop',
                textBlockText: 'Een tekstelement kan worden gebruikt om uw klanten extra informatie te geven over uw producten. Vergeet niet dit voorbeeld te vervangen door uw eigen tekst.',
                textBlockTitle: 'Informatie'
            },
            element: {
                accordion: {
                    icon: 'Pictogram',
                    opened: 'Standaard geopend',
                    title: 'Titel',
                    titlePlaceholder: '@:form.eg Bustickets'
                },
                divider: {
                    title: 'Titel',
                    titlePlaceholder: '@:form.eg Parkeertickets'
                },
                externalLink: {
                    text: 'Tekst',
                    textPlaceholder: '@:form.eg Bezoek onze website',
                    url: 'URL',
                    urlPlaceholder: '@:form.eg https://wearefancee.com'
                },
                notice: {
                    message: 'Bericht',
                    messagePlaceholder: '@:form.eg Vergeet niet je ID mee te nemen, dit is verplicht.',
                    variant: 'Variant',
                    variants: {
                        danger: 'Gevaar',
                        info: 'Informatie',
                        success: 'Succes',
                        warning: 'Waarschuwing'
                    }
                },
                textBlock: {
                    title: 'Titel',
                    titlePlaceholder: '@:form.eg Gezonderheidsinformatie',
                    text: 'Tekst',
                    textPlaceholder: '@:form.eg Water drinken is essentieel voor een goede gezondheid. Het helpt ons lichaam gehydrateerd te houden, spoelt gifstoffen weg en helpt bij de spijsvertering. Water helpt ook de lichaamstemperatuur te reguleren en ondersteunt een gezonde huid. Experts raden aan om minstens acht glazen water per dag te drinken om een optimale gezondheid te behouden.'
                }
            },
            insert: {
                accordion: 'Accordeon',
                divider: 'Scheidingslijn',
                link: 'Link',
                notice: 'Melding',
                product: 'Product',
                seating: 'Zaalplattegrond',
                text: 'Tekst',
                ticket: 'Ticket'
            },
            newShop: {
                title: 'Nieuwe shop',
                message: 'Kies een naam voor je shop.',
                label: 'Naam',
                placeholder: '@:form.eg Voorverkoop shop'
            },
            noElements: {
                title: 'Ontwerp je shop',
                message: 'Voeg elementen hieronder toe en breng je visie tot leven.'
            },
            configurator: {
                defaultPalette: {
                    loadingFailed: 'Er is een fout opgetreden tijdens het ophalen van je standaard kleurenpalet. Neem contact op met support als dit probleem zich blijft voordoen.',
                    savingFailed: 'Er is een fout opgetreden tijdens het opslaan van je standaard kleurenpalet. Neem contact op met support als dit probleem zich blijft voordoen.'
                },
                colors: {
                    title: 'Kleuren',
                    background: 'Achtergrond',
                    panel: 'Paneel',
                    primary: 'Primair',
                    text: 'Tekst'
                },
                details: {
                    title: 'Details',
                    endDate: 'Einddatum',
                    active: 'Actief',
                    startDate: 'Startdatum',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Voorverkoop'
                    }
                },
                fields: {
                    title: 'Velden',
                    info: 'Geef aan welke informatie je van je gasten wilt weten. Optionele velden worden getoond, maar zijn niet verplicht.',
                    address: '@:form.field.address',
                    city: '@:form.field.addressCity',
                    birthdate: '@:form.field.birthdate',
                    birthdateRequired: 'Geboortedatum is verplicht, omdat je evenement een minimumleeftijd heeft.',
                    email: '@:form.field.email',
                    firstName: '@:form.field.firstName',
                    gender: '@:form.field.gender',
                    lastName: '@:form.field.lastName',
                    phoneNumber: '@:form.field.phoneNumber'
                },
                images: {
                    title: 'Afbeeldingen',
                    header: 'Header'
                },
                marketing: {
                    title: 'Marketing',
                    googleAnalyticsId: {
                        label: 'Google Analytics ID',
                        placeholder: '@:form.eg G-XXXXXXXXXX'
                    },
                    googleTagManagerId: {
                        label: 'Google Tag Manager ID',
                        placeholder: '@:form.eg GTM-XXXXXX'
                    },
                    tiktokPixelId: {
                        label: 'TikTok ID',
                        placeholder: '@:form.eg ABCDEFGHIJK123456789'
                    },
                    facebookPixelId: {
                        label: 'Facebook Pixel id',
                        placeholder: '@:form.eg 12345678912345678',
                        accessToken: 'Facebook Toegangstoken',
                        required: 'Beide Facebook-invoeren zijn vereist'
                    }
                }
            }
        },
        ticketDesign: {
            title: 'Ticket ontwerper',
            info: 'Dit is het ontwerp dat wordt gebruikt in het PDF-bestand van het ticket.',
            assigned: 'Toegewezen tickets',
            unAssigned: 'Sommige tickets hebben geen ontwerp, deze gebruiken het standaardontwerp van het platform.',
            hasDesign: 'Heeft ontwerp',
            uploadImage: 'Afbeelding uploaden...',
            designs: {
                title: 'Ontwerpen',
                info: 'Klik om te bewerken of een nieuwe toe te voegen.',
                warning: 'Ontwerpen die niet aan tickets zijn gekoppeld, worden verwijderd.'
            },
            unattachedFound: {
                title: 'Niet-gekoppelde ticketontwerpen gevonden',
                message: 'Er zijn ticketontwerpen gevonden zonder gekoppelde tickets. Wanneer u op Doorgaan drukt, worden deze ontwerpen verwijderd.'
            },
            upcomingEvents: {
                title: 'Aankomende evenementen',
                anotherEvent: 'Een ander evenement',
                nEvents: 'Geen evenementen laten zien | Toon één evenement | Toon {n} evenementen'
            },
            useDefault: 'Er zijn geen ontwerpen gedetecteerd. Als u op Doorgaan drukt, gebruiken de tickets de standaardlay-out van het platform.',
            empty: {
                title: '@:event.create.ticketDesign.title',
                description: [
                    'Begin met het ontwerpen van je tickets en producten. Uw tickets kunnen naar eigen inzicht worden ontworpen. Plaats afbeeldingen op uw ticket en/of laat aankomende evenementen zien.',
                    `Nadat u klaar bent met het maken van al uw ticketontwerpen, kunt u selecteren welk ticket u aan welk ontwerp wilt toewijzen.`
                ]
            }
        },
        type: {
            normal: {
                title: 'Normaal',
                description: 'Geschikt voor de standaardbehoeften van het verkopen en/of aanbieden van toegangstickets.'
            },
            seated: {
                title: 'Gezeten',
                description: 'Toewijzen van tickets aan zoekopdrachten met behulp van een interactieve kaart.'
            },
            timeslotted: {
                title: 'Tijdslot',
                description: 'Maakt het mogelijk om tickets in bepaalde tijdsintervallen te plannen.'
            }
        }
    },
    secureCode: {
        plural: 'Veilige codes',
        singular: 'Beveiligings code',
        secureShop: 'Beveilig @.lower:event.shopSingular',
        alterShopSecure: 'Verander de veilige status',
        search: 'Zoekcodes...',
        table: {
            code: 'Code',
            createdOn: 'Gemaakt op',
            uses: 'Toepassingen',
            deleteAllFailed: `Er is een fout opgetreden bij het verwijderen van alle ongebruikte @.lower:{'event.secureCode.plural'}. `,
            deleteAllSuccess: `Alle ongebruikte @.lower:{'event.secureCode.plural'} zijn succesvol verwijderd.`,
            deleteFailed: `Er is een fout opgetreden bij het verwijderen van @.lower:{'event.secureCode.singular'}. `,
            deleteSuccess: `@.lower:{'event.secureCode.singular'} is succesvol verwijderd.`,
            downloadFailed: `Er is een fout opgetreden tijdens het downloaden van de @.lower:{'event.secureCode.plural'} export. `,
            loadingFailed: `Er is een fout opgetreden tijdens het laden van @.lower:{'event.secureCode.plural'}. `,
            loadingShopFailed: 'Er is een fout opgetreden tijdens het laden van de winkel. ',
            codeUsages: '{usedAmount}{slash}{maximumUses} codez ijn gebruikt, waarvan {pendingAmount} in pending reservaties'
        },
        add: {
            title: 'Voeg @:event.secureCode.plural toe',
            pleaseFix: 'Los het volgende op',
            manual: 'Handmatig',
            maxUses: 'Maximaal gebruik',
            maxUsesHint: 'Laat leeg voor onbeperkt maximaal gebruik.',
            noneSelected: 'Er zijn geen @:event.secureCode.plural geselecteerd.',
            noMaxUsesSelected: 'Geen maximaal gebruik geselecteerd.',
            duplicates: 'Er zijn duplicaten gevonden.',
            failed: 'Kan geen nieuwe @:event.secureCode.singular maken. Neem contact op met de ondersteuning als het probleem zich blijft voordoen.',
            success: `De nieuwe @:{'event.secureCode.singular'} is succesvol toegevoegd.`,
            import: {
                title: 'Importeren',
                failed: `Kan @:{'event.secureCode.plural'} niet importeren. Neem contact op met de ondersteuning als het probleem zich blijft voordoen.`,
                success: 'Nieuwe @:event.secureCode.plural geïmporteerd'
            }
        },
        set: {
            title: 'Veilige status instellen',
            info: 'Bij het markeren van een winkel als beveiligde winkel kunt u optioneel een vervaldatum instellen.',
            state: 'Veilige staat',
            until: 'Beveiligd tot',
            failed: 'Er is een onbekende fout opgetreden bij het opslaan van de beveiligde status van de winkel.',
            success: 'De veilige status is succesvol opgeslagen.'
        },
        import: {
            title: 'Importeer als @.lower:event.secureCode.plural',
            info: 'Selecteer een winkel waarvoor u de {0} met {1} pre-registraties wilt importeren als beveiligingscodes voor eenmalig gebruik.',
            selectShop: 'Selecteer winkel...',
            submit: 'Importeren',
            failed: 'Het importeren van @.lower:event.secureCode.plural is mislukt.',
            success: 'Het importeren van @.lower:event.secureCode.plural is gelukt.'
        }
    }
} satisfies Translations;
