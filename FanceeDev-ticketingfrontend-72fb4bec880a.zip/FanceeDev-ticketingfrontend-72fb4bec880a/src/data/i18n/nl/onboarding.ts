import type { Translations } from '../types';

export default {
    agreement: {
        title: 'Finaliseer uw overeenkomst',
        intro: `In deze laatste stap formaliseren we onze samenwerking door middel van een helder en beknopt contract. Door hier te ondertekenen bekrachtigt u onze samenwerking en zorgt u ervoor dat beide partijen zich aan de algemene voorwaarden houden. We zijn enthousiast om u aan boord te hebben en deze stap is de laatste om het officieel te maken.`,
        disclaimer: "Door hier te ondertekenen bevestigt u dat u het contract volledig hebt gelezen en akkoord gaat met de inhoud.",
        negotiate: 'Als uw organisatie eerder contact met ons heeft opgenomen en aangepaste tarieven of voorwaarden heeft onderhandeld, wacht dan in deze stap terwijl wij het contract bijwerken om deze overeenkomsten te reflecteren.',
        sign: 'Onderteken contract',
        signOverlayTitle: 'Ondertekenen',
        alreadySigned: `U heeft het ondertekeningsproces van het contract al voltooid. Indien u wijzigingen wenst of vragen heeft, neem dan contact op met ons support team.`,
        contactSales: 'Contact Sales',
        downloadFailed: 'Het contract kon niet worden gedownload. Probeer het later opnieuw of neem contact op met onze support.'
    },
    company: {
        title: 'Vertel ons over uw organisatie',
        intro: `Laten we nu over uw organisatie duiken. Geef ons alstublieft belangrijke details over uw bedrijf. We hebben de naam, het adres en meer van de organisatie nodig.`,
        supportContact: 'Support contact',
        optionalSupportContact: 'Optionele support contact',
        supportContactExplanation: 'Een customer support contact wordt door het systeem gebruikt om aan uw klanten te communiceren hoe ze contact met u kunnen opnemen. Als u dit leeg laat, worden de standaardgegevens gebruikt. Je hebt ook de mogelijkheid om dit later in je profiel aan te passen',
    },
    financial: {
        title: 'Stel uw financiën in',
        intro: `In deze stap zullen we de financiële aspecten regelen om naadloze transacties te garanderen. Geef alstublieft de essentiële details op over waar we uw uitbetalingen naartoe moeten sturen en andere financiële voorkeuren. Uw financiële veiligheid en gemak hebben onze hoogste prioriteit, en het voltooien van deze stap zal ons helpen u beter van dienst te zijn.`,
        ibanInfo: `Als u een IBAN hebt, kunt u deze gebruiken. Anders vult u uw bankrekeningnummer en de BIC van uw bank in.`,
        approximateAnnualSales: 'Geschatte jaarlijkse omzet',
        approximateAnnualSalesPlaceholder: 'Hoeveel tickets verwacht u te verkopen?',
    },
    personal: {
        title: `Laten we beginnen!`,
        intro: `We maken graag kennis met u en uw organisatie. Om uw onboarding te starten, vragen we u vriendelijk om enkele gegevens over de eigenaar.`,
    },
    welcome: {
        title: `Let's get Fancee!`,
        intro: `Nu we uw contract hebben geregeld, kunt u op elk moment tickets gaan verkopen! Als u hulp nodig hebt, aarzel dan niet om contact met ons op te nemen.`,
        start: 'Begin met verkopen'
    }
} satisfies Translations;
