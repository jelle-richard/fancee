import type { Locale, LocaleImport, Messages } from './types';
import * as en from './en';
import * as nl from './nl';
import * as de from './de';
import * as fr from './fr';

const locales: LocaleImport[] = [en, nl, de, fr];

export const languages: Locale[] = locales.map(l => l.options);

export const messages: Messages = Object.fromEntries(
    locales.map(l => [
        l.options.code,
        l.messages
    ])
);
