import type { Translations } from '../types';

export default {
    title: 'Finanzen',
    takings: 'Einnahmen',
    ticketFee: 'Ticketgebühr',
    paymentFee: 'Zahlungsgebühr',
    discount: 'Rabatt',
    invoice: {
        plural: 'Rechnungen',
        singular: 'Rechnung',
        title: '@:finance.invoice.plural',
        downloadFailed: 'Beim Herunterladen der Rechnungsdatei ist ein Fehler aufgetreten.',
        downloadSingleFailed: 'Beim Herunterladen der Rechnung ist ein Fehler aufgetreten.',
        loadingFailed: 'Das System konnte keine Rechnungen abrufen.',
        loadingEventsFailed: 'Beim Laden Ihrer Ereignisse ist ein Fehler aufgetreten. '
    },
    order: {
        title: 'Aufträge',
        downloadFailed: 'Beim Herunterladen der Bestellungen ist ein Fehler aufgetreten.',
        loadingFailed: 'Beim Laden der Bestellung ist ein Fehler aufgetreten.',
        loadingSingleFailed: 'Beim Laden der Bestellungen ist ein Fehler aufgetreten.',
        search: 'Aufträge durchsuchen...',
        cost: 'Kosten',
        filter: {
            promotionalEmail: 'Werbe-E-Mail',
            promotionalSms: 'Werbe-SMS',
            orderSms: 'Bestell-SMS erhalten'
        },
        table: {
            psp: 'PSP-Referenz',
            event: '@:event.singular',
            date: '@:global.date',
            amount: '@:global.amount',
            paymentStatus: '@:finance.zahlungStatus.title'
        },
        single: {
            title: 'Bestellverlauf',
            advanced: {
                title: 'Fortschrittlich',
                refund: {
                    title: 'Erstattung',
                    info: 'Sie haben die Möglichkeit, dem Kunden eine Rückerstattung zu gewähren.',
                    start: 'Beginnen Sie mit der Rückerstattung'
                },
                resend: {
                    title: 'Bestellbestätigung erneut senden',
                    info: 'Sie haben die Möglichkeit, die Tickets erneut an den Kunden zu senden. Dabei handelt es sich um eine direkte Kopie der E-Mail, die bei der Ausführung der Bestellung gesendet wurde.',
                    disabled: 'Eine erneute Bestellung an den Kunden ist erst nach erfolgter Zahlung möglich.',
                    submit: 'Erneut senden',
                    success: 'Das Ticket-PDF dieser Bestellung wurde erneut an den ursprünglichen Käufer gesendet.'
                }
            },
            client: {
                title: 'Kundeninformation',
                optins: {
                    title: 'Werbe-Opt-Ins',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            order: {
                title: 'Befehl',
                breakdown: 'Abbauen',
                psp: 'PSP-Referenz',
                cost: 'Kosten',
                paymentFee: 'Gebühr',
                paymentMethod: 'Bezahlverfahren',
                paymentStatus: 'Zahlungsstatus',
                placed: 'Bestellung aufgegeben',
                productFee: 'Produktgebühr',
                seatedTicketFee: 'Sitzplatzgebühr',
                ticketAndProductRevenue: 'Fahrkarte',
                ticketFee: 'Ticketgebühr',
                ticketServicePlusCost: 'Ticketservice zzgl. Kosten',
                totalOrderCost: 'Gesamtkosten der Bestellung'
            },
            purchase: {
                title: 'Kaufen',
                viewTickets: 'Tickets ansehen',
                productFee: '{0} Produktgebühr',
                seatedTicketFee: '{0} Sitzplatzgebühr',
                ticketFee: '{0} Ticketgebühr',
                boughtTsp: 'Ticket Service Plus gekauft',
                receiveOrderSms: 'Bestell-SMS erhalten',
                products: 'Produkte'
            }
        },
        refund: {
            title: 'Rückerstattung {0}',
            notice: 'Beachten Sie, dass die Rückerstattung einer Bestellung nicht rückgängig gemacht werden kann. Der Ticketkäufer wird über diese Rückerstattung benachrichtigt und wir sind bestrebt, den Betrag innerhalb von 3 Werktagen zu überweisen.',
            returnToStock: 'Zurück zum Lagerbestand',
            invalidateTickets: 'Tickets ungültig machen',
            submit: 'Rückerstattung ausstellen',
            totalRefundAmount: 'Gesamtbetrag der Rückerstattung:',
            failed: 'Bei der Erstattung ist ein Fehler aufgetreten.',
            success: 'Die Rückerstattung wurde erfolgreich durchgeführt und der Käufer wird benachrichtigt.'
        }
    },
    report: {
        title: 'Berichte',
        loadingFailed: 'Beim Laden Ihrer Umsatzstatistik ist ein Fehler aufgetreten. Bitte wenden Sie sich an den Support, wenn der Fehler weiterhin besteht.',
        loadingEventsFailed: 'Beim Laden Ihrer Ereignisse ist ein Fehler aufgetreten. Bitte versuchen Sie es später noch einmal.',
        info: 'Mithilfe dieser Informationen können Sie Ihre Umsatztrends analysieren. Wählen Sie entweder ein Ereignis aus, um spezifische Erkenntnisse zu gewinnen, oder lassen Sie es leer, um einen kontoweiten Überblick zu erhalten.',
        searchEvent: 'Suchereignis...',
        organization: {
            statistics: {
                title: 'Umsatzstatistik',
                fulfilledOrders: 'Erfüllte Bestellungen',
                issuedProducts: 'Ausgestellte Produkte',
                obtained: {
                    app: 'Erhalten über die @:global.platform.name App.',
                    generated: 'Von Plattform generiert.',
                    guestlist: 'Über Gästelisten versendet.',
                    imported: 'Aus externer Quelle importiert.',
                    shop: 'Erhalten über den @:global.platform.name Shop.',
                    ticketswap: 'Über Ticketswap verkauft'
                }
            },
            revenue: {
                title: 'Organisationsumsatz'
            },
            cost: {
                title: 'Organisationskosten',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Zahlungsgebühren',
                ticketFeeCost: '@:finance.ticketFee',
                seatedTicketFeeCost: 'Platzticketgebühren',
                guestlistCost: 'Gästelisten'
            }
        },
        platform: {
            revenue: {
                title: 'Plattformumsatz',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Zahlungsgebühren'
            },
            cost: {
                title: 'Plattformkosten',
                ticketFee: '@:finance.ticketFee',
                productFee: 'Produktgebühren',
                seatedTicketFee: 'Platzticketgebühren',
                guestlist: 'Gästelisten',
                additional: 'Zusätzlich',
                paymentFeeCost: 'Zahlungsgebühren'
            }
        },
        client: {
            cost: {
                title: 'Kundenkosten',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Zahlungsgebühren'
            }
        },
        product: {
            title: 'Produktumsatz',
            cash: 'Barumsatz',
            online: 'Online-Umsatz'
        },
        totals: {
            title: 'Gesamt',
            totals: 'Gesamt',
            OrganizationRevenue: 'Gesamter Organisationsumsatz',
            PlatformRevenue: 'Gesamter Plattformumsatz',
            organizationCost: 'Gesamte Organisationskosten',
            clientCost: 'Gesamte Kundenkosten',
            revenue: 'Gesamtumsatz',
            cost: 'Gesamtkosten',
            profit: {
                title: 'Gewinn',
                wallet: 'Ins Wallet gelegt',
                profit: 'Gewinn',
                cash: 'Der Unterschied zwischen Gewinn und dem, was in Ihrem Portemonnaie steckt, ist auf die Bareinnahmen zurückzuführen.'
            }
        }
    },
    wallet: {
        title: 'Geldbörse',
        currencyConversionInfo: 'Bitte beachten Sie, dass zwar alle Auszahlungen in Euro abgewickelt werden, es jedoch aufgrund von Bankgebühren und Währungsumrechnungsschwankungen zu Schwankungen bei den erhaltenen Beträgen kommen kann.',
        searchTransactions: 'Transaktionen suchen...',
        downloadInvoiceFailed: 'Beim Herunterladen der Rechnung ist ein Fehler aufgetreten.',
        downloadOrdersFailed: 'Beim Herunterladen der Bestelldatei ist ein Fehler aufgetreten.',
        downloadReceiptFailed: 'Beim Herunterladen der Wallet-Quittung ist ein Fehler aufgetreten.',
        loadingBalanceFailed: 'Beim Abrufen des Wallet-Guthabens ist ein Fehler aufgetreten.',
        loadingTransactionsFailed: 'Beim Abrufen der Wallet-Transaktionen ist ein Fehler aufgetreten.',
        balance: {
            title: 'Gleichgewicht',
            subTitle: 'Wallet-Guthaben der letzten {days} Tage.',
            pending: 'Ausstehend',
            spendable: 'Ausgebbar'
        },
        payout: {
            request: 'Auszahlung beantragen',
            requestFailed: 'Beim Verarbeiten der Auszahlungsanforderung ist ein Fehler aufgetreten.',
            requestSuccess: 'Ihre Auszahlungsanfrage wurde erfolgreich übermittelt.',
            acknowledge: 'Mit dem Absenden dieser Anfrage bestätigen Sie, dass Sie die Zahlung von {amount} beantragen.',
            info: 'Sie können einen benutzerdefinierten Auszahlungsbetrag anfordern, indem Sie das Kontrollkästchen aktivieren und einen benutzerdefinierten Wert angeben.',
            custom: 'Fordern Sie einen benutzerdefinierten Wert an',
            amount: 'Menge'
        },
        structure: {
            pending: 'Ausstehend',
            reserved: 'Reserviert',
            requiredDeposit: 'Erforderliche Anzahlung',
            spendable: {
                title: 'Ausgebbar',
                tip: 'Sie haben Auszahlung(en) im Gesamtwert von {0} beantragt, die noch nicht verarbeitet wurden.'
            }
        },
        transaction: {
            statement: 'Stellungnahme',
            table: {
                amount: 'Menge',
                processedOn: 'Verarbeitet',
                requestedOn: 'Angefordert'
            }
        }
    },
    paymentStatus: {
        title: 'Zahlungsstatus',
        authenticationFinished: 'Authentifizierung abgeschlossen',
        authenticationNotRequired: 'Authentifizierung nicht erforderlich',
        authorised: 'Autorisiert',
        blocked: 'verstopft',
        cancelled: 'Abgesagt',
        challengeShopper: 'Fordern Sie den Käufer heraus',
        chargeback: 'Rückbuchung',
        error: 'Fehler',
        expired: 'Abgelaufen',
        identifyShopper: 'Identifizieren Sie den Käufer',
        partiallyAuthorised: 'Teilweise autorisiert',
        partialRefund: 'Teilerstattung',
        pending: 'Ausstehend',
        presentToShopper: 'Dem Käufer präsentieren',
        received: 'Erhalten',
        redirectShopper: 'Käufer umleiten',
        refund: 'Erstattung',
        pendingRefund: 'Ausstehend erstattung',
        refused: 'Abgelehnt',
        unknown: 'Unbekannt'
    }
} satisfies Translations;
