import type { Translations } from '../types';

export default {
    title: 'App',
    scanStatistics: {
        title: 'Scanstatistiken'
    },
    team: {
        plural: 'App-Teams',
        singular: 'App-Team',
        title: '@:app.team.plural',
        search: 'App-Teams suchen...',
        emptyView: 'Anscheinend verfügt Ihr Konto über keine App-Teams.',
        createFailed: 'Das App-Team konnte nicht erstellt werden.',
        createSuccess: 'Das App-Team wurde erfolgreich erstellt.',
        deleteFailed: 'Das App-Team konnte nicht gelöscht werden.',
        deleteSuccess: 'Das App-Team wurde erfolgreich gelöscht.',
        updateFailed: 'Das App-Team konnte nicht bearbeitet werden.',
        downloadFailed: 'Beim Herunterladen Ihrer App-Teams ist ein Fehler aufgetreten.',
        loadingFailed: 'Beim Abrufen Ihrer App-Teams ist ein Fehler aufgetreten.',
        loadingEventsFailed: 'Beim Laden Ihrer Ereignisse ist ein Fehler aufgetreten.',
        loadingProductsFailed: 'Beim Laden Ihrer Produkte ist ein Fehler aufgetreten.',
        loadingSingleFailed: 'Beim Abrufen Ihres App-Teams ist ein Fehler aufgetreten.',
        table: {
            name: '@:form.field.name',
            rights: 'Rechte',
            qr: 'QR-Code'
        },
        right: {
            guestlists: '@:event.guestlist.plural',
            scanning: 'Scan',
            sales: 'Verkäufe',
            statistics: 'Statistiken',
            cash: 'Kasse'
        },
        configure: {
            title: {
                edit: 'Bearbeiten Sie {0}',
                new: 'Erstellen Sie ein App-Team'
            }
        },
        statistics: {
            title: 'Scanstatistiken anzeigen',
            loadingFailed: 'Beim Abrufen der Ereignisstatistiken ist ein Fehler aufgetreten.',
            loadingTeamFailed: 'Beim Abrufen der App-Teamstatistiken ist ein Fehler aufgetreten.',
            selectAppTeam: 'Wählen Sie ein App-Team aus...',
            selectEvent: 'Wählen Sie eine Veranstaltung aus...',
            event: {
                title: 'Ereignisstatistiken',
                subTitle: 'Scan-Statistiken pro Ticket',
                remaining: 'Übrig',
                scanned: 'Gescannt'
            },
            team: {
                title: 'Scanzeiten',
                subTitle: 'Scanzeiten des App-Teams',
                scanned: 'Gescannt',
                unscanned: 'Nicht gescannt',
                dateHint: 'Ändern Sie das Datum oder die Stunde, um die Scanstatistiken ab diesem Zeitpunkt anzuzeigen.',
                empty: 'Für das ausgewählte App-Team oder das ausgewählte Datum wurden keine Scandaten gefunden.'
            }
        }
    }
} satisfies Translations;
