import type { Translations } from '../types';

export default {
    title: 'CRM',
    navigation: {
        home: 'Überblick',
        adminRegister: 'Admin-Register',
        balance: 'Gleichgewicht',
        channels: 'Kanäle',
        eventBalance: 'Ereignisbilanz',
        eventPlanning: 'Eventplanung',
        integrations: 'Integrationen',
        invoicing: 'Fakturierung',
        orders: 'Aufträge',
        organizations: 'Organisationen',
        paymentMethods: 'Zahlungsarten',
        payouts: 'Auszahlungen'
    },
    home: {
        title: 'Überblick',
        statisticsFor: 'Statistiken für {0}',
        failed: {
            loadingGlobalPlatformStatistics: 'Beim Abrufen globaler Plattformstatistiken ist ein Fehler aufgetreten.',
            loadingGrowthTargets: 'Beim Abrufen Ihrer Verkaufsziele ist ein Fehler aufgetreten.',
            loadingTicketRevenueIndication: 'Beim Laden der Anzeige der Ticketgebühren ist ein Fehler aufgetreten. '
        },
        targetProgression: {
            newEvents: 'Neue Veranstaltungen',
            newOrganizations: 'Neue Organisationen',
            newUniqueBuyers: 'Neue einzigartige Käufer',
            placedOrders: 'Bestellungen aufgegeben',
            placedOrdersTip: 'Es wurden {placed} Bestellungen aufgegeben, von denen {fulfilled} ausgeführt wurden.'
        },
        targets: {
            title: 'Plattformziele',
            subTitle: 'Plattformziele zur Messung des Wachstums.',
            ticketFeeThisMonth: 'Diesen Monat: {0} / {1}',
            ticketFeeLastMonth: 'Letzter Monat: {0} / {1}',
            revenueAccomplished: 'Erzielter Umsatz',
            revenueTarget: 'Umsatzziel',
            revenueToday: 'Umsatz heute',
            revenueYesterday: 'Umsatz gestern',
            topDailySoldProducts: 'Top täglich verkaufte Produkte',
            tooltip: {
                ticketFeeRevenue: 'Einnahmen aus Ticketgebühren {0} / {1}',
                seatedTicketFeeREvenue: 'Einnahmen aus Sitzplatztickets {0} / {1}',
                tickets: 'Tickets {0} / {1}',
                seatedTickets: 'Sitzplatzkarten {0} / {1}',
                organizations: 'Organisationen {0} / {1}',
                events: 'Ereignisse {0} / {1}',
                placedOrders: 'Bestellungen aufgegeben {0} / {1}',
                fulfilledOrders: 'Ausgeführte Bestellungen {0} / {1}',
                uniqueBuyers: 'Einzelkäufer {0} / {1}'
            }
        }
    },
    adminRegister: {
        title: 'Admin-Register',
        choose: 'Wählen Sie die Administratorrolle',
        terminatesOn: 'Endet am',
        countryManager: {
            createFailed: 'Beim Versuch, den Ländermanager zu erstellen, ist ein Fehler aufgetreten.',
            createSuccess: 'Der Ländermanager wurde erfolgreich hinzugefügt.',
            hint: 'Beachten Sie, dass durch die Festlegung des Kündigungsdatums im Ländermanager das Konto nach diesem Datum gesperrt wird. '
        },
        customerServiceEmployee: {
            createFailed: 'Beim Versuch, den Kundendienstmitarbeiter zu erstellen, ist ein Fehler aufgetreten.',
            createSuccess: 'Der Kundendienstmitarbeiter wurde erfolgreich hinzugefügt.',
            countryManager: 'Land-Manager',
            hint: 'Beachten Sie, dass Sie derzeit nur einen Ländermanager für den Kundendienstmitarbeiter auswählen können.',
            missingCountryManagers: 'Derzeit sind keine Ländermanager verfügbar.'
        }
    },
    balance: {
        title: 'Gleichgewicht',
        loadingFailed: 'Das Laden des Guthabens ist fehlgeschlagen.',
        received: 'Erhalten',
        revenue: 'Einnahmen',
        additionalCosts: 'Zusätzliche Kosten',
        chargebacked: 'Rückbuchung',
        chargebackFee: 'Rückbuchungsgebühr',
        guestlistFee: 'Gästelistengebühr',
        month: 'Monat',
        orders: 'Aufträge',
        paymentFee: 'Gebühr',
        productFee: 'Produktgebühr',
        productIncome: 'Produkteinkommen',
        refunded: 'Erstattet',
        refundFee: 'Erstattungsgebühr',
        seatedTicketFee: 'Sitzplatzgebühr',
        sms: 'SMS',
        ticketFee: 'Ticketgebühr',
        tickets: '@:event.ticketPlural',
        tsp: 'TSP'
    },
    eventBalance: {
        title: 'Ereignisbilanz',
        loadingFailed: 'Beim Laden von Ereignissen ist ein Fehler aufgetreten.',
        table: {
            event: '@:event.singular',
            organization: 'Organisation',
            status: '@:event.status.title',
            scannedTickets: 'Gescannte Tickets',
            fees: 'Gebühren',
            received: 'Erhalten'
        },
        tip: {
            guestlistFee: 'Gästelistengebühr',
            paymentFee: 'Gebühr',
            seatedTicketFee: 'Sitzplatzgebühr',
            ticketFee: 'Ticketgebühr',
            tsp: 'TSP'
        }
    },
    eventPlanning: {
        title: 'Eventplanung'
    },
    integration: {
        title: 'Integrationen',
        configure: 'Konfigurieren',
        connect: 'Verbinden',
        exact: {
            title: 'Genau',
            description: 'Melden Sie sich bei Exact an, indem Sie auf die Schaltfläche unten klicken. Nach der Anmeldung werden Sie zurückgeleitet.',
            completed: 'Exakte Integration abgeschlossen.',
            loadingFailed: 'Fehler beim Abrufen der genauen Anmelde-URL.',
            loadingStatusFailed: 'Fehler beim Abrufen, wenn Exact aktiviert ist.',
            configure: {
                configureItems: 'Artikel konfigurieren',
                selectJournal: 'Journal auswählen',
                disconnected: 'Genau ist nicht verbunden.',
                loadingConfigurationFailed: 'Die Konfiguration konnte nicht abgerufen werden.',
                loadingItemsFailed: 'Elemente können nicht abgerufen werden.',
                loadingJournalsFailed: 'Journale können nicht abgerufen werden.',
                loadingSpecificationNamesFailed: 'Rechnungsspezifikationsnamen konnten nicht abgerufen werden. '
            },
            mapping: {
                platform: 'Plattformartikel',
                exact: 'Genauer Artikelcode',
                notMapped: 'Nicht kartiert',
                country: {
                    add: 'Länderzuordnung hinzufügen',
                    remove: 'Länderzuordnung entfernen'
                }
            }
        }
    },
    invoicing: {
        title: 'Fakturierung',
        search: 'Rechnungen suchen...',
        downloadFailed: 'Beim Herunterladen der Rechnungsdatei ist ein Fehler aufgetreten.',
        loadingFailed: 'Das System konnte keine Rechnungen abrufen.',
        loadingEventsFailed: 'Beim Laden von Ereignissen ist ein Fehler aufgetreten.',
        loadingOrganizationsFailed: 'Beim Laden von Organisationen ist ein Fehler aufgetreten.',
        filter: {
            event: '@:event.singular',
            eventSearch: '@:event.list.searchPlaceholder',
            organization: 'Organisation',
            organizationSearch: 'Organisationen suchen...'
        },
        table: {
            number: 'Nummer',
            organization: 'Organisation',
            createdOn: 'Erstellt am'
        }
    },
    order: {
        title: 'Aufträge'
    },
    organization: {
        singular: 'Organisation',
        plural: 'Organisationen',
        title: '@:crm.organization.plural',
        search: 'Organisationen suchen...',
        downloadFailed: 'Beim Herunterladen der Organisationsdatei ist ein Fehler aufgetreten.',
        loadingFailed: 'Beim Laden von Organisationen ist ein Fehler aufgetreten.',
        filter: {
            date: '@:global.date',
            contractSigned: 'Vertrag unterzeichnet',
            isBlocked: 'verstopft',
            isImportant: 'Wichtig'
        },
        table: {
            name: '@:form.field.name',
            email: '@:form.field.email',
            annualSales: 'Jahresumsatz',
            important: 'Wichtig',
            verified: 'Verifiziert',
            blocked: 'verstopft',
            profileComplete: 'Profil vollständig',
            lastLogin: 'Letzte Anmeldung',
            phoneNumber: '@:form.field.phoneNumber'
        },
        single: {
            navigation: {
                account: 'Konto',
                monitoring: 'Überwachung',
                permissions: 'Berechtigungen',
                planning: 'Eventplanung',
                wallet: 'Geldbörse'
            },
            contact: {
                title: 'Kontakte'
            },
            contract: {
                title: 'Vertrag',
                currentPackage: 'Aktuelles Paket',
                addAddendum: 'Nachtrag',
                updateContract: 'Vertrag aktualisieren',
                expiresOn: 'Läuft am {0} ab',
                guestlistFee: 'Gästelistengebühr von {0}',
                productFee: 'Produktgebühr von {0} {1} %',
                seatedTicketFee: 'Sitzplatzgebühr von {0} {1} %',
                ticketFee: 'Ticketgebühr von {0} {1} %',
                downloadFailed: '@:onboarding.agreement.downloadFailed',
                updateFailed: 'Beim Versuch, den Pakettyp einer Organisation zu aktualisieren, ist ein unbekannter Fehler aufgetreten. '
            },
            info: {
                approximateAnnualSales: 'Ungefährer Jahresumsatz',
                contractSigned: 'Vertrag unterzeichnet',
                createdOn: 'Erstellt am',
                important: 'Wichtig',
                lastLogin: 'Letzte Anmeldung',
                profileComplete: 'Profil vollständig',
                verified: 'Verifiziert',
                block: 'Benutzer blockieren',
                unblock: 'Nutzer entblockieren',
                blockFailed: 'Beim Blockieren des Benutzers ist ein Fehler aufgetreten.',
                blockSuccess: 'Der Benutzer wurde erfolgreich blockiert.',
                unblockFailed: 'Beim Entsperren des Benutzers ist ein Fehler aufgetreten.',
                unblockSuccess: 'Der Benutzer wurde erfolgreich entsperrt.',
                importantChangeFailed: 'Beim Ändern des wichtigen Status des Benutzers ist ein Fehler aufgetreten.',
                accountTakeover: {
                    button: 'Konto eingeben',
                    info: 'Bitte geben Sie unten Ihr Passwort erneut ein, um sich als diese Organisation anzumelden.'
                },
                accountStatus: 'Kontostatus',
                accountStatusUnfinished: 'Diese Organisation hat sich registriert, muss aber noch ihr Profil vervollständigen oder ihren Vertrag unterzeichnen'
            },
            note: {
                title: 'Anmerkungen',
                attachFiles: 'Dateien anhängen...',
                createSuccess: 'Die Notiz wurde erfolgreich erstellt.',
                deleteSuccess: 'Die Notiz wurde erfolgreich gelöscht.'
            },
            permissions: {
                loadingClaimsFailed: 'Beim Abrufen der Plattformansprüche ist ein Fehler aufgetreten.',
                loadingUserClaimsFailed: 'Beim Abrufen der Ansprüche der Benutzer ist ein Fehler aufgetreten.',
                savingUserClaimsFailed: 'Beim Speichern der Benutzeransprüche ist ein Fehler aufgetreten. '
            },
            planning: {
                search: 'Veranstaltungen suchen...'
            },
            wallet: {
                search: 'Transaktionen suchen...'
            },
            invoice: {
                regenerateTitle: 'Rechnung erstellen',
                regenerateExplanation: 'Erstellen Sie manuell eine Rechnung für die Organisation (nur Entwicklungsfunktion)'
            }
        },
        addAddendumOverlay: {
            title: 'Nachtrag erstellen',
            info: 'Der Nachtrag, den Sie gerade erstellen, wird dem aktuellen Vertrag der Organisation beigefügt.',
            notation: 'Bitte beachten Sie, dass alle Gebühren in Cent angegeben sind.',
            createSuccess: 'Der Nachtrag wurde erfolgreich zum Vertrag der Organisation hinzugefügt.',
            guestlistFee: 'Gästelistengebühr',
            productFee: {
                percentual: 'Prozentuale Produktgebühr',
                static: 'Produktgebühr'
            },
            seatedTicketFee: {
                percentual: 'Prozentuale Sitzplatzgebühr',
                static: 'Sitzplatzgebühr'
            },
            ticketFee: {
                percentual: 'Prozentuale Ticketgebühr',
                static: 'Ticketgebühr'
            }
        },
        alterContractOverlay: {
            title: 'Vertrag aktualisieren'
        }
    },
    paymentMethod: {
        title: 'Zahlungsarten',
        search: 'Zahlungsmethoden suchen...',
        downloadFailed: 'Beim Herunterladen der Zahlungsmethodendatei ist ein Fehler aufgetreten.',
        loadingFailed: 'Zahlungsmethoden konnten nicht geladen werden.',
        table: {
            id: 'Ausweis',
            name: 'Name',
            provider: 'Anbieter',
            cost: 'Kosten',
            limitedTo: 'Begrenzt auf'
        }
    },
    payout: {
        title: 'Auszahlungen',
        search: 'Auszahlungen suchen...',
        export: 'Export',
        resolve: 'Aktuellen Export auflösen',
        resolved: 'Der Auszahlungsexport wurde als gelöst markiert und die zugrunde liegenden Auszahlungsanfragen wurden entsprechend aktualisiert.',
        exportFailed: 'Da derzeit keine Auszahlungsanträge ausstehen, kann derzeit keine Exportdatei erstellt werden.',
        exportSuccess: 'Sie haben einen Auszahlungsexportvorgang eingeleitet.',
        outstandingNotice: 'Derzeit steht eine Auszahlung zur Bearbeitung aus.',
        status: {
            created: 'Erstellt',
            processed: 'Verarbeitet'
        },
        table: {
            id: 'Ausweis',
            createdOn: 'Erstellt am',
            status: 'Status',
            markProcessed: 'Mark verarbeitet'
        }
    }
} satisfies Translations;
