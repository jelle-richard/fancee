import type { Translations } from '../types';

export default {
    navigation: {
        blockedEmails: 'Blockierte E-Mails',
        defaultPaymentMethods: 'Standardzahlungsmethoden',
        defaultShopPalette: 'Standard-Shopdesign',
        roleManagement: 'Rollenmanagement'
    },
    blockedEmails: {
        add: 'Blockierte E-Mail hinzufügen',
        addSuccess: '{0} erfolgreich blockiert.',
        deleteEverythingConfirm: 'Durch diese Aktion werden alle blockierten E-Mails aus Ihrem Konto entfernt.',
        deleteEverythingFailed: 'Beim Versuch, alle blockierten E-Mails zu löschen, ist ein Fehler aufgetreten.',
        deleteEverythingSuccess: 'Alle blockierten E-Mails wurden erfolgreich gelöscht.',
        deleteFailed: 'Beim Versuch, eine blockierte E-Mail zu löschen, ist ein Fehler aufgetreten.',
        deleteSuccess: 'Blockierte E-Mail erfolgreich gelöscht.',
        loadingFailed: 'Beim Laden blockierter E-Mails ist ein Fehler aufgetreten.'
    },
    defaultPaymentMethods: {
        loadingFailed: 'Beim Versuch, Ihre Standardzahlungsmethoden abzurufen, ist ein Fehler aufgetreten.',
        savingFailed: 'Beim Versuch, Ihre Standardzahlungsmethoden zu speichern, ist ein Fehler aufgetreten.'
    },
    defaultShopPalette: {
        title: 'Standard-Shopdesign',
        description: 'Speichern Sie Ihre Markenfarben als Standardpalette für eine einfache Anwendung in Ihren Geschäften.',
        background: 'Hintergrund',
        panel: 'Panel',
        primary: 'Primär',
        text: 'Text'
    },
    roleManagement: {
        title: 'Rollenmanagement',
        notice: 'Durch die Gewährung von Rollen an externe Benutzer können Sie Zugriff auf Teile des Kontos Ihrer Organisation gewähren.',
        addFailed: 'Beim Zuweisen des Benutzers ist ein unbekannter Fehler aufgetreten.',
        addSuccess: 'Der Benutzer wurde erfolgreich zur Organisation hinzugefügt.',
        deleteFailed: 'Beim Löschen des Benutzers ist ein unbekannter Fehler aufgetreten.',
        deleteSuccess: 'Der Benutzer wurde erfolgreich aus der Organisation entfernt.',
        loadingFailed: 'Beim Laden Ihrer Benutzer ist ein unbekannter Fehler aufgetreten.',
        updateFailed: 'Beim Aktualisieren des zugewiesenen Benutzers ist ein unbekannter Fehler aufgetreten.',
        configure: {
            title: {
                add: 'Neuen Benutzer hinzufügen',
                edit: 'Bearbeiten Sie {0}'
            },
            rights: 'Rechte',
            LoadingFailed: 'Beim Laden Ihrer Ansprüche ist ein unbekannter Fehler aufgetreten. Bitte wenden Sie sich an den Support, wenn das Problem weiterhin besteht.'
        }
    }
} satisfies Translations;
