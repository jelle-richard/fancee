import type { Translations } from '../types';

export default {
    agreement: {
        title: 'Schließen Sie Ihre Vereinbarung ab',
        intro: 'In diesem abschließenden Schritt formalisieren wir unsere Verpflichtung zur Zusammenarbeit durch einen klaren und prägnanten Vertrag.',
        disclaimer: 'Mit Ihrer Unterschrift bestätigen Sie, dass Sie den Vertrag vollständig gelesen haben und mit dem Inhalt einverstanden sind.',
        negotiate: 'Wenn Ihre Organisation uns zuvor kontaktiert und kundenspezifische Gebühren oder Bedingungen ausgehandelt hat, warten Sie bitte in diesem Schritt, während wir den Vertrag aktualisieren, um diese Vereinbarungen widerzuspiegeln.',
        sign: 'Unterschreibe den Vertrag',
        signOverlayTitle: 'Zeichen',
        alreadySigned: 'Sie haben den Vertragsunterzeichnungsprozess bereits abgeschlossen.',
        contactSales: 'Kontaktieren Sie den Vertrieb',
        downloadFailed: 'Ihr Vertrag konnte nicht heruntergeladen werden. '
    },
    company: {
        title: 'Erzählen Sie uns etwas über Ihre Organisation',
        intro: 'Lassen Sie uns nun in das Herz Ihrer Organisation eintauchen. ',
        supportContact: 'Support-Kontakt',
        optionalSupportContact: 'Optionaler Support-Kontakt',
        supportContactExplanation: 'Die Kundensupportdetails werden vom System verwendet, um Ihren Kunden mitzuteilen, wie sie Sie kontaktieren können. Wenn es leer bleibt, werden die Standarddetails verwendet. Sie haben auch die Möglichkeit, dies später in Ihrem Profil anzupassen.',
    },
    financial: {
        title: 'Richten Sie Ihre Finanzen ein',
        intro: 'In diesem Schritt regeln wir die finanziellen Aspekte, um reibungslose Transaktionen zu gewährleisten.',
        ibanInfo: 'Wenn Sie eine IBAN haben, verwenden Sie diese.',
        approximateAnnualSales: 'Ungefährer Jahresumsatz',
        approximateAnnualSalesPlaceholder: 'Wie viele Tickets werden voraussichtlich verkauft?'
    },
    personal: {
        title: 'Wir bringen Sie zum Laufen!',
        intro: 'Wir freuen uns darauf, Sie und Ihre Organisation besser kennenzulernen. '
    },
    welcome: {
        title: `Let's get Fancee!`,
        intro: 'Nachdem wir nun Ihren Vertrag geklärt haben, können Sie mit dem Verkauf von Tickets beginnen, wann immer Ihnen danach ist!',
        start: 'Beginnen Sie mit dem Verkauf'
    }
} satisfies Translations;
