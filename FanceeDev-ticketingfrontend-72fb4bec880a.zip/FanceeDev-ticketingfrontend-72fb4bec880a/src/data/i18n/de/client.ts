import type { Translations } from '../types';

export default {
    lastOrder: {
        title: 'Ihre letzte Bestellung',
        placedOn: 'Platziert am {0}'
    },
    dashboard: {
        loadingFailed: 'Wir konnten Ihre Bestellungen nicht laden.',
        emptyView: {
            title: 'Nichts hier',
            message: 'Für Ihr Konto konnte keine Bestellung gefunden werden. '
        }
    },
    ticket: {
        eventName: 'Ereignis',
        startDate: 'Datum',
        loadingFailed: 'Ihre Tickets konnten nicht geladen werden.',
        emptyView: {
            title: 'Nichts hier',
            message: 'Wenn Sie sicher sind, dass Sie Anspruch auf Tickets für eine bevorstehende Veranstaltung haben, überprüfen Sie bitte Ihre Bestellungen.',
            action: 'Bestellungen ansehen'
        },
        sealed: {
            message: 'Diese Tickets sind versiegelt und werden {0} Stunden vor Beginn der Veranstaltung verfügbar sein',
            saleButton: 'Verkaufen Sie auf TicketSwap'
        }
    }
} satisfies Translations;
