import type { Translations } from '../types';

export default {
    plural: 'Veranstaltungen',
    singular: 'Ereignis',
    discountPlural: 'Rabatte',
    discountSingular: 'Rabatt',
    productPlural: 'Produkte',
    productSingular: 'Produkt',
    shopPlural: 'Geschäfte',
    shopSingular: 'Geschäft',
    ticketPlural: 'Tickets',
    ticketSingular: 'Fahrkarte',
    createEvent: 'Veranstaltung erstellen',
    manageEvent: 'Veranstaltung verwalten',
    myEvents: 'Meine Veranstaltungen',
    list: {
        deletionFailed: 'Ereignis „{0}“ konnte nicht gelöscht werden.',
        searchPlaceholder: 'Veranstaltungen suchen...',
        table: {
            deactivated: 'Dieser Shop ist deaktiviert.',
            event: '@:event.singular',
            organization: 'Organisation',
            shops: '@:event.shopPlural',
            status: 'Status'
        },
        emptyView: {
            title: 'Keine Ereignisse',
            message: 'In Ihrem Konto wurden noch keine Veranstaltungen erstellt.',
            add: '@:event.singular'
        }
    },
    discount: {
        title: 'Rabatte',
        searchPlaceholder: 'Rabatte suchen...',
        loadingEventsFailed: 'Beim Laden Ihrer Ereignisse ist ein Fehler aufgetreten.',
        loadingProductsFailed: 'Beim Laden Ihrer Produkte ist ein Fehler aufgetreten.',
        filter: {
            includeExpired: 'Abgelaufen einbeziehen',
            shops: '@:event.shopPlural',
            shopsSearchPlaceholder: `Suche @.lower:{'event.shopPlural'}...`
        },
        table: {
            code: 'Code',
            used: 'Gebraucht',
            amount: 'Menge',
            expires: 'Läuft ab'
        },
        deleteFailed: 'Beim Versuch, den Rabatt zu entfernen, ist ein unbekannter Fehler aufgetreten.',
        getFailed: 'Beim Abrufen Ihres Rabatts ist ein unbekannter Fehler aufgetreten.',
        listFailed: 'Beim Abrufen Ihrer Rabatte ist ein unbekannter Fehler aufgetreten.',
        deleted: 'Rabatt erfolgreich gelöscht.',
        saved: 'Rabatt erfolgreich gespeichert.',
        configurator: {
            title: {
                create: 'Erstellen Sie @.lower:event.discountSingular',
                edit: 'Bearbeiten Sie @.lower:event.discountSingular'
            },
            expires: 'Läuft ab',
            stock: 'Aktie',
            assignTo: {
                label: 'Zuweisen',
                placeholder: 'Der Rabatt gilt für...',
                description: {
                    products: [
                        'Wenn Sie einem Produkt einen festen Rabatt zuweisen, wird der Betrag pro Produkt in der Bestellung abgezogen.',
                        'Wählen Sie Veranstaltungen aus, um Ihre Produkte zu finden'
                    ],
                    shops: 'Wenn Sie einem Shop einen Rabatt zuweisen, wird der Betrag von der Bestellsumme abgezogen.'
                }
            },
            code: {
                label: 'Code',
                placeholder: '@:form.eg SPRING13'
            },
            value: {
                labelFixed: 'Fester Rabatt',
                labelPercentage: 'Prozentualer Rabatt'
            },
            validate: {
                assignmentRequirement: 'Dem Rabatt muss mindestens ein Shop oder Produkt zugeordnet sein.',
                valueRequirement: 'Es fehlt ein statischer oder prozentualer Rabattwert.'
            }
        }
    },
    guestlist: {
        singular: 'Gästeliste',
        plural: 'Gästelisten',
        title: '@:event.guestlist.plural',
        selector: {
            title: 'Gästelisten verwalten',
            search: '@:event.list.searchPlaceholder'
        },
        empty: 'Sie können Gästelisten nur für aktive Veranstaltungen verwalten.',
        manage: {
            title: 'Gästeliste bearbeiten',
            onlyActiveEvents: 'Gästelisten können nur an aktive Veranstaltungen gesendet werden.',
            deduct: 'Lagerbestand abziehen',
            guest: 'Gast',
            hasHeader: 'CSV hat einen Header',
            failed: 'Beim Senden der Gästeliste ist ein Fehler aufgetreten.',
            success: 'Ihre Gastkarte(n) wurden erfolgreich versendet.',
            manual: {
                title: 'Einladen'
            },
            import: {
                title: 'Importieren',
                info: 'Um Gäste in großen Mengen hochzuladen, laden Sie bitte eine CSV-Datei hoch, die mindestens die E-Mail-Adresse und die Anzahl der zu versendenden Tickets enthält.',
                choose: 'Datei wählen',
                maxRows: 'Sie können eine CSV-Datei mit maximal {0} E-Mail-Adressen hochladen.',
                maxRowsExceeded: 'Die maximale Anzahl von {0} Gästelistenimporten wurde überschritten.',
                missingEmailField: 'Es wurde kein Feld als E-Mail zugewiesen.',
                missingQuantityField: 'Es wurde kein Feld als Menge zugewiesen.',
                table: {
                    example: 'Beispieldaten',
                    field: 'Feldtyp'
                }
            }
        }
    },
    ticket: {
        title: '@:event.ticketPlural',
        addBarcodes: 'Barcodes',
        searchPlaceholder: `Suche @.lower:{'event.ticketPlural'}...`,
        table: {
            event: '@:event.singular',
            shop: '@:event.shopSingular',
            ticket: '@:event.ticketSingular',
            code: 'Code',
            origin: 'Herkunft',
            scanStatus: 'Scanstatus',
            scanTime: 'Scan Zeit',
            holder: 'Halter',
            state: 'Status'
        },
        filter: {
            acquirerOrigin: 'Herkunft des Erwerbers',
            promotionalEmail: 'Werbe-E-Mail',
            promotionalSms: 'Werbe-SMS',
            receiveOrderSms: 'Bestell-SMS erhalten',
            scanState: 'Scanstatus'
        },
        origin: {
            app: 'Erworben über die @:global.platform.name-App',
            generated: 'Generiert von @:global.platform.name',
            guestlist: '@:global.platform.name Gästeliste',
            imported: 'Importiert nach @:global.platform.name',
            shop: 'Erworben über den Shop @:global.platform.name',
            ticketswap: 'Über TicketSwap erworben',
            filter: {
                app: '@:global.platform.name-App',
                generated: 'Generiert',
                guestlist: '@:global.platform.name Gästeliste',
                imported: 'Importiert',
                shop: '@:global.platform.name Shop',
                ticketswap: 'TicketSwap'
            }
        },
        single: {
            title: '@:event.ticketSinguläre Informationen',
            info: {
                name: '@:event.ticketEinzelname',
                code: 'Code',
                markScanned: 'Mark gescannt',
                markUnscanned: 'Als nicht gescannt markieren',
                scanStatus: 'Scanstatus',
                seatLocation: 'Sitzplatz',
                viewOrder: 'Bestellung ansehen',
                scanStateConfirm: 'Möchten Sie den Scanstatus des Tickets {code} auf {state} aktualisieren?',
                scanStateUpdated: 'Scanstatus aktualisiert',
                advanced: {
                    title: 'Erweiterte Optionen',
                    invalidate: {
                        title: 'Ungültig machen',
                        explanation: 'Sie können ein Ticket ungültig machen, sodass das Ticket nicht mehr verwendet werden kann',
                        returnToStock: 'Zurück zum Lager',
                        giveReason: 'Bitte geben Sie einen Grund an, warum das Ticket ungültig wird. Der Kunde erhält eine Benachrichtigung mit diesem Grund',
                        failed: 'Das Ticket konnte nicht ungültig gemacht werden.“ Wenn das Problem weiterhin besteht, wenden Sie sich bitte an den Support.',
                        success: 'Das Ticket wurde ungültig gemacht'
                    }
                },
                ticketState: 'Ticketstatus'
            },
            client: {
                title: 'Kundeninformation',
                belongsTo: 'Gehört',
                boughtBy: 'Gekauft von',
                boughtInShop: 'Im Laden gekauft',
                enabledSms: 'SMS aktiviert',
                enabledTsp: 'Aktivierte Tsp',
                optins: {
                    label: 'Werbe-Opt-Ins',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            holder: {
                title: 'Inhaberinformationen'
            }
        }
    },
    scanState: {
        notScanned: 'Nicht gescannt',
        scanned: 'Gescannt',
        unscanned: 'Nicht gescannt'
    },
    status: {
        title: 'Ereignisstatus',
        active: 'Aktiv',
        canceled: 'Abgesagt',
        cancelled: '@:event.status.canceled',
        concept: 'Konzept',
        concluded: 'Abgeschlossen',
        soldOut: 'Ausverkauft',
        unpublished: 'Unveröffentlicht'
    },
    addBarcodesOverlay: {
        title: 'Barcodes',
        generate: 'Generieren',
        import: 'Importieren',
        selectEvent: 'Veranstaltung auswählen...',
        selectProduct: 'Ausgewähltes Produkt...',
        submitGenerate: 'Generieren',
        submitImport: 'Importieren',
        generateError: 'Fehler beim Generieren der Barcodes.',
        importError: 'Fehler beim Importieren von Barcodes.',
        productLoadingFailed: 'Fehler beim Laden der Produkte',
        importDuplicateFound: 'Es wurden doppelte Felder gefunden.',
        importMax: 'Es können maximal {amount} Barcodes auf einmal importiert werden.',
        importMissingBarcode: 'Ein Barcode-Feldtyp ist erforderlich.',
        success: {
            title: 'Badcodes hinzugefügt',
            message: '{Anzahl} neue Barcodes erfolgreich hinzugefügt.'
        },
        fieldType: {
            barcode: 'Barcode',
            email: '@:form.field.email',
            firstName: '@:form.field.firstName',
            lastName: '@:form.field.lastName'
        }
    },
    copyEventOverlay: {
        title: 'Kopieren Sie {0}',
        info: 'Sie sind dabei, {0} zu kopieren. Bitte wählen Sie die gewünschten zusätzlichen Informationen aus, die Sie mitkopieren möchten.',
        categories: {
            title: 'Kategorien',
            description: 'Alle Kategorien kopieren.'
        },
        paymentMethods: {
            title: 'Zahlungsarten',
            description: 'Kopieren Sie alle Zahlungsmethoden.'
        },
        products: {
            title: 'Produkte',
            description: 'Alle Produkte kopieren.'
        },
        shops: {
            title: '@:event.shopPlural',
            description: `Kopiere alles @.lower:{'event.shopPlural'}.`
        }
    },
    cancelOverlay: {
        title: 'Veranstaltung absagen',
        explanation: 'Beachten Sie, dass das Absagen der Veranstaltung eine dauerhafte Aktion ist und nicht rückgängig gemacht werden kann.',
        giveReason: 'Geben Sie einen detaillierten Grund an, warum Sie die Veranstaltung absagen.',
        failed: 'Beim Absagen Ihrer Veranstaltung ist ein Fehler aufgetreten. Bitte versuchen Sie es später noch einmal.',
        success: 'Die Veranstaltung wurde erfolgreich abgesagt.'
    },
    cancelPane: {
        title: 'Stornieren',
        explanation: 'Wenn Sie Ihre Veranstaltung absagen, wird sie deaktiviert und es können keine Produkte mehr verkauft werden.',
        notice: '@:event.cancelOverlay.explanation',
        submit: 'Veranstaltung absagen'
    },
    unpublishPane: {
        title: 'Veröffentlichung aufheben',
        explanation: 'Wenn Sie die Veröffentlichung Ihrer Veranstaltung rückgängig machen, wird sie vorübergehend deaktiviert, bis Sie sie erneut veröffentlichen.',
        submit: 'Veröffentlichung aufheben'
    },
    create: {
        step: {
            type: 'Typ',
            details: 'Einzelheiten',
            products: '@:event.productPlural',
            shops: '@:event.shopPlural',
            payment: 'Zahlung',
            mailing: 'Mailing',
            design: 'Ticketdesign',
            publish: 'Veröffentlichen'
        },
        details: {
            seatingEventId: 'Sitzplatz-Ereignis-ID',
            categories: {
                label: 'Kategorien',
                placeholder: 'Wählen Sie einige optionale Kategorien für Ihre Veranstaltung aus ...'
            },
            header: {
                label: 'Header',
                description: 'Bilder, die als Header für Ihre Veranstaltung verwendet werden.'
            },
            minimalAge: {
                hint: 'Bei Veranstaltungen mit Altersbeschränkungen muss das Alter der Gäste angegeben werden.',
                label: 'Mindestalter',
                placeholder: '@:form.eg 16'
            },
            timezone: {
                info: 'Ihre Veranstaltung findet in der Zeitzone {timezone} statt.',
                change: 'Verwenden Sie eine andere Zeitzone.'
            },
            sealed: {
                label: 'Besiegelte Veranstaltung',
                hint: 'Sobald Sie den versiegelten Eventverkauf aktiviert und gespeichert haben, kann er nicht mehr deaktiviert werden',
                enabled: 'Für diese Veranstaltung ist der versiegelte Ticketversand aktiviert'
            }
        },
        mailing: {
            title: 'Mailing',
            content: 'Inhalt',
            mailType: 'E-Mail-Typ',
            mailTypes: {
                guestlist: 'Einladungsmail zur Gästeliste',
                purchase: 'Post kaufen',
                sealed: 'Versiegelte Ticketzustellungspost'
            },
            senderName: 'Absender',
            senderNamePlaceholder: '@:global.platform.name',
            subject: 'Thema',
            subjectPlaceholder: 'Ihre Kaufbestätigung für Event',
            variables: {
                title: 'Variablen',
                info: 'E-Mails können benutzerdefinierten Text enthalten, der auf den folgenden Variablen basiert und beim Senden der E-Mail durch entsprechende Werte ersetzt wird.'
            },
            sealed: {
                title: 'Versiegelte Ticketlieferung',
                message: 'Sie haben die versiegelte Ticketzustellung für Ihre Veranstaltung aktiviert und können daher unten auch die Zustellungsmail ändern'
            }
        },
        paymentMethods: {
            title: 'Zahlungsarten',
            defaults: 'Derzeit werden Ihre Standardzahlungseinstellungen angewendet.',
            paidByCustomer: 'Aktiviert, vom Kunden bezahlt',
            paidByOrganization: 'Aktiviert, bezahlt von der Organisation',
            loadingFailed: 'Beim Versuch, Ihre Standardzahlungsmethoden abzurufen, ist ein Fehler aufgetreten.',
            klarnaInfo: 'Für diese Zahlungsart muss in den Shop-Einstellungen das Feld „Adresse“ auf „erforderlich“ gesetzt werden.',
            psd2: {
                title: 'Achtung, PSD2 könnte auf Sie zutreffen!',
                paragraphs: [
                    'Nach dem PSD2-Gesetz ist es nicht immer zulässig, Ihren Kunden Zahlungsgebühren in Rechnung zu stellen.',
                    'Eine der Bestimmungen der PSD2 ist das Verbot von Zuschlägen, was bedeutet, dass Händler ihren Kunden keine zusätzlichen Gebühren für die Nutzung bestimmter Zahlungsmethoden wie Kredit- oder Debitkarten in Rechnung stellen dürfen.',
                    'Es ist erwähnenswert, dass PSD2 zwar für alle EU-Mitgliedstaaten gilt, einige Länder das Gesetz jedoch möglicherweise unterschiedlich umgesetzt haben, sodass die genauen Regeln für die Zuschlagserhebung variieren können.',
                    'Es gibt einige Ausnahmen pro Land, aber bitte gehen Sie sorgfältig vor. '
                ]
            }
        },
        products: {
            add: {
                ticket: '@:global.add @.lower:event.ticketSingular',
                product: '@:global.add @.lower:event.productSingular'
            },
            configurator: {
                access: {
                    title: 'Zugang',
                    partial: {
                        label: 'Teilweiser Zugriff',
                        hint: 'Wenn der Teilzugriff aktiviert ist, können Kunden die Veranstaltung nur innerhalb der angegebenen Zeitspanne betreten.',
                        end: 'Ende',
                        start: 'Start'
                    }
                },
                advanced: {
                    title: 'Fortschrittlich',
                    ticketSwap: {
                        label: 'TicketSwap',
                        hint: 'Aktiviert SecureSwap des Tickets auf TicketSwap. ',
                        sealedSwapUnfinishedTitle: 'TicketSwap nicht möglich',
                        sealedSwapUnfinishedDescription: 'Aufgrund der Arbeiten am Ende von TicketSwaps kann TicketSwap derzeit nicht für versiegelte Veranstaltungen verwendet werden. Schauen Sie später noch einmal vorbei'
                    }
                },
                details: {
                    title: 'Einzelheiten',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Early Bird'
                    },
                    description: {
                        label: '@:form.field.description',
                        placeholder: '@:form.eg Bietet Ihnen den besten Platz an unserem Veranstaltungsort.'
                    }
                },
                images: {
                    title: 'Bilder'
                },
                salesFlow: {
                    title: 'Verkaufsfluss',
                    administrationFee: {
                        label: 'Verwaltungsgebühr',
                        hint: 'Dies ist die Gebühr, die Sie zusätzlich zum Ticketpreis erheben. '
                    },
                    maxOrderQuantity: {
                        label: 'Maximale Bestellmenge'
                    },
                    packQuantity: {
                        labelProduct: 'Menge',
                        labelTicket: 'Anzahl der Barcodes im Gruppenticket',
                        hint: 'Das Produkt wird pro angegebener Menge verkauft. '
                    },
                    dateTime: {
                        title: 'Terminzeit',
                        hint: 'Verkaufen Sie Ihr Produkt innerhalb des angegebenen Zeitraums.',
                        saleEnd: 'Verkaufsende',
                        saleStart: 'Verkaufsstart'
                    },
                    waveLink: {
                        title: 'Wave-Link',
                        hint: 'Verkaufen Sie Ihr Produkt, sobald der Restbestand des ausgewählten Produkts 10 % beträgt.',
                        linkedTicket: 'Verknüpftes Ticket',
                        circular: 'Diese Wave-Link-Kombination ist nicht möglich.',
                        disabled: 'Damit diese Funktion funktioniert, sollten Sie mindestens zwei Produkte haben.'
                    }
                },
                scanning: {
                    title: 'Scannen',
                    notification: {
                        label: 'Benachrichtigung',
                        placeholder: '@:form.eg Geben Sie bei der Ankunft 5 Münzen ab.'
                    },
                    preArrivalThreshold: {
                        label: 'Schwelle vor der Ankunft',
                        hint: 'Ermöglicht es Kunden, die angegebene Anzahl von Minuten vor Beginn ihres Zugriffs einzutreffen.'
                    }
                },
                hint: {
                    title: 'Weitere Produktoptionen',
                    description: 'Es gibt noch mehr Optionen für Ihre Produkte. Klicken Sie auf das Zahnradsymbol eines Produkts, um sie anzuzeigen.'
                }
            },
            empty: {
                title: '@:event.productPlural',
                description: [
                    'Beginnen Sie mit dem Aufbau Ihres Shop-Bestands, indem Sie Tickets und/oder Produkte hinzufügen.',
                    'Nachdem Sie alle Ihre Tickets und/oder Produkte erstellt haben, können Sie diese im nächsten Schritt zuweisen und gestalten.'
                ]
            },
            group: {
                products: '@:event.productPlural',
                seatedTickets: 'Sitzend @.lower:event.ticketPlural',
                tickets: '@:event.ticketPlural'
            },
            new: {
                product: 'Neues @.lower:event.productSingular',
                ticket: 'Neues @.lower:event.ticketSingular'
            },
            row: {
                name: {
                    label: '@:form.field.name',
                    placeholder: '@:event.create.products.configurator.details.name.placeholder'
                },
                price: {
                    label: '@:form.field.price',
                    change: `Bitte beachten Sie, dass Sie dabei sind, den Preis eines Tickets zu ändern, für das es bereits Verkäufe gibt.“ Erwägen Sie die Erstellung eines neuen Tickets für die neu berechneten Tickets.`
                },
                seats: {
                    label: 'Sitze'
                },
                stock: {
                    label: '@:form.field.stock',
                    placeholder: '@:form.eg 100'
                }
            }
        },
        publish: {
            notReady: {
                title: 'Fast dort',
                info: 'Ihre Veranstaltung ist fast bereit zur Veröffentlichung.',
                missingPaymentMethods: {
                    action: 'Zahlungsmethoden konfigurieren',
                    message: 'Für Ihre Veranstaltung sind keine Zahlungsmethoden konfiguriert.'
                },
                missingSellableProducts: {
                    action: 'Shops konfigurieren',
                    message: 'Ihre Veranstaltung benötigt mindestens einen Shop mit verkaufsfähigen Produkten.'
                }
            },
            ready: {
                title: 'Bereit zur Veröffentlichung!',
                info: 'Alles ist bereit zur Veröffentlichung.',
                requestReview: 'Überprüfung anfordern',
                requestReviewPending: 'Bewertung erbeten, einer unserer Mitarbeiter wird sich mit Ihnen in Verbindung setzen.'
            },
            scanning: {
                title: 'Scannen',
                paragraphs: [
                    'Benötigen Sie Hilfe beim Scannen?',
                    'Interessiert? '
                ],
                submit: 'Anleitung herunterladen',
                file: 'Scananweisungen'
            },
            status: {
                canceled: 'Diese Veranstaltung wurde abgesagt.',
                unpublished: 'Diese Veranstaltung ist unveröffentlicht.',
                soldIn: 'Verkauft in: {0}',
                soldNowhere: 'Nirgendwo verkauft'
            }
        },
        seatingSetup: {
            title: 'Sitzaufbau',
            explanation: 'Unser Support-Team übernimmt für Sie die Ersteinrichtung dieser Veranstaltung.',
            failed: {
                title: 'Überprüfung fehlgeschlagen',
                message: 'Wir hatten Probleme, SeatsIO zur Validierung der Veranstaltung zu kontaktieren.',
                notice: 'Die angegebene SeatsIO-Ereignis-ID ist ungültig.'
            },
            setupId: '@:event.create.details.seatingEventId'
        },
        shops: {
            designer: 'Designer',
            default: {
                buttonLabel: 'Neuer Knopf',
                noticeContent: 'Dies ist ein Platzhaltertext für eine Mitteilung. Bitte geben Sie Ihre Nachricht ein.',
                shopName: 'Neuer Shop',
                textBlockText: 'Ein Textelement kann verwendet werden, um Ihren Kunden zusätzliche Informationen zu Ihren Produkten bereitzustellen. Vergessen Sie nicht, dieses Beispiel durch Ihre eigene Eingabe zu ersetzen.',
                textBlockTitle: 'Information'
            },
            element: {
                accordion: {
                    icon: 'Symbol',
                    opened: 'Standardmäßig geöffnet',
                    title: 'Titel',
                    titlePlaceholder: '@:form.eg Bustickets'
                },
                divider: {
                    title: 'Titel',
                    titlePlaceholder: '@:form.eg Parkscheine'
                },
                externalLink: {
                    text: 'Text',
                    textPlaceholder: '@:form.eg Besuchen Sie unsere Website',
                    url: 'URL',
                    urlPlaceholder: '@:form.eg https://wearefrance.com'
                },
                notice: {
                    message: 'Nachricht',
                    messagePlaceholder: '@:form.eg Bitte beachten Sie, dass die Mitnahme Ihres Ausweises obligatorisch ist.',
                    variant: 'Variante',
                    variants: {
                        danger: 'Gefahr',
                        info: 'Information',
                        success: 'Erfolg',
                        warning: 'Warnung'
                    }
                },
                textBlock: {
                    title: 'Titel',
                    titlePlaceholder: '@:form.eg Gesundheitsinformationen',
                    text: 'Text',
                    textPlaceholder: '@:form.eg Trinkwasser ist für eine gute Gesundheit unerlässlich. '
                }
            },
            insert: {
                accordion: 'Akkordeon',
                divider: 'Teiler',
                link: 'Verknüpfung',
                notice: 'Beachten',
                product: 'Produkt',
                seating: 'Sitzplan',
                text: 'Text',
                ticket: 'Fahrkarte'
            },
            newShop: {
                title: 'Neuer Shop',
                message: 'Wählen Sie einen Namen für Ihren Shop.',
                label: 'Name',
                placeholder: '@:form.eg Vorverkaufsshop'
            },
            noElements: {
                title: 'Gestalten Sie Ihren Shop',
                message: 'Fügen Sie Elemente von unten hinzu und erwecken Sie Ihre Vision zum Leben.'
            },
            configurator: {
                defaultPalette: {
                    loadingFailed: 'Beim Versuch, Ihre Standardpalette abzurufen, ist ein Fehler aufgetreten.',
                    savingFailed: 'Beim Versuch, Ihre Standardpalette zu speichern, ist ein Fehler aufgetreten. '
                },
                colors: {
                    title: 'Farben',
                    background: 'Hintergrund',
                    panel: 'Panel',
                    primary: 'Primär',
                    text: 'Text'
                },
                details: {
                    title: 'Einzelheiten',
                    endDate: 'Endtermin',
                    active: 'Aktiv',
                    startDate: 'Startdatum',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Vorverkauf'
                    }
                },
                fields: {
                    title: 'Felder',
                    info: 'Geben Sie an, welche Informationen Sie von Ihren Gästen wünschen.',
                    address: '@:form.field.address',
                    city: '@:form.field.addressCity',
                    birthdate: '@:form.field.birthdate',
                    birthdateRequired: 'Das Geburtsdatum ist erforderlich, da Ihre Veranstaltung ein Mindestalter hat.',
                    email: '@:form.field.email',
                    firstName: '@:form.field.firstName',
                    gender: '@:form.field.gender',
                    lastName: '@:form.field.lastName',
                    phoneNumber: '@:form.field.phoneNumber'
                },
                images: {
                    title: 'Bilder',
                    header: 'Header'
                },
                marketing: {
                    title: 'Marketing',
                    googleAnalyticsId: {
                        label: 'Google Analytics ID',
                        placeholder: '@:form.eg G-XXXXXXXXXX'
                    },
                    googleTagManagerId: {
                        label: 'Google Tag Manager-ID',
                        placeholder: '@:form.eg GTM-XXXXXX'
                    },
                    tiktokPixelId: {
                        label: 'TikTok-ID',
                        placeholder: '@:form.eg ABCDEFGHIJK123456789'
                    },
                    facebookPixelId: {
                        label: 'Facebook-Pixel-ID',
                        placeholder: '@:form.eg 12345678912345678',
                        accessToken: 'Facebook-Zugriffstoken',
                        required: 'Beide Facebook-Eingaben sind erforderlich'
                    }
                }
            }
        },
        ticketDesign: {
            title: 'Ticketdesigner',
            info: 'Dies ist das Design, das in der Ticket-PDF-Datei verwendet wird.',
            assigned: 'Zugewiesene tickets',
            unAssigned: 'Einige Tickets haben kein Design, diese verwenden das Standarddesign der Plattform.',
            hasDesign: 'Hat Design',
            uploadImage: 'Bild hochladen...',
            designs: {
                title: 'Designs',
                info: 'Klicken Sie, um eine neue zu bearbeiten oder hinzuzufügen.',
                warning: 'Designs, die keinen Tickets zugeordnet sind, werden gelöscht.'
            },
            unattachedFound: {
                title: 'Nicht angehängte Ticketdesigns gefunden',
                message: 'Es wurden Ticketdesigns ohne angehängte Tickets gefunden. Wenn Sie auf „Weiter“ klicken, werden diese Designs gelöscht.'
            },
            upcomingEvents: {
                title: 'Kommende Veranstaltungen',
                anotherEvent: 'Ein weiteres Ereignis',
                nEvents: 'Keine Veranstaltungen anzeigen | Ein Ereignis anzeigen | {n} Ereignisse anzeigen'
            },
            useDefault: 'Keine Designs erkannt. Wenn Sie auf Weiter klicken, verwenden die Tickets das Standardlayout der Plattform.',
            leer: {
                Titel: '@:event.create.ticketDesign.title',
                Beschreibung: [
                    'Beginnen Sie mit der Gestaltung Ihrer Tickets und Produkte.“ Ihre Tickets können nach Ihren Wünschen gestaltet werden. Platzieren Sie Bilder auf Ihrem Ticket und/oder zeigen Sie bevorstehende Veranstaltungen.',
                    'Nachdem Sie alle Ihre Ticketdesigns erstellt haben, können Sie auswählen, welches Ticket Sie welchem Design zuweisen möchten.'
                ]
            }
        },
        type: {
            normal: {
                title: 'Normal',
                description: 'Entspricht den Standardanforderungen des Verkaufs und/oder der Bereitstellung von Eintrittskarten.'
            },
            seated: {
                title: 'Sitzend',
                description: 'Weisen Sie Tickets der Suche mithilfe einer interaktiven Karte zu.'
            },
            timeslotted: {
                title: 'Zeitfenster',
                description: 'Ermöglicht die Planung von Tickets in bestimmte Zeitspannen.'
            }
        }
    },
    secureCode: {
        plural: 'Sichere Codes',
        singular: 'Sicherheitscode',
        secureShop: 'Sichern Sie @.lower:event.shopSingular',
        alterShopSecure: 'Sicheren Zustand ändern',
        search: 'Suchcodes...',
        table: {
            code: 'Code',
            createdOn: 'Erstellt am',
            uses: 'Verwendet',
            deleteAllFailed: `Beim Entfernen aller nicht verwendeten @.lower:{'event.secureCode.plural'} ist ein Fehler aufgetreten. `,
            deleteAllSuccess: `Alle nicht verwendeten @.lower:{'event.secureCode.plural'} wurden erfolgreich gelöscht.`,
            deleteFailed: `Beim Entfernen von @.lower:{'event.secureCode.singular'} ist ein Fehler aufgetreten. `,
            deleteSuccess: `@.lower:{'event.secureCode.singular'} erfolgreich gelöscht.`,
            downloadFailed: `Beim Herunterladen des Exports @.lower:{'event.secureCode.plural'} ist ein Fehler aufgetreten. `,
            loadingFailed: `Beim Laden von @.lower:{'event.secureCode.plural'} ist ein Fehler aufgetreten. `,
            loadingShopFailed: 'Beim Laden des Shops ist ein Fehler aufgetreten. ',
            codeUsages: '{usedAmount}{slash}{maximumUses} wurden verwendet, davon sind {pendingAmount} in ausstehenden Reservierungen'
        },
        add: {
            title: 'Fügen Sie @:event.secureCode.plural hinzu',
            pleaseFix: 'Bitte beheben Sie Folgendes',
            manual: 'Handbuch',
            maxUses: 'Max nutzt',
            maxUsesHint: 'Für eine unbegrenzte maximale Nutzung leer lassen.',
            noneSelected: 'Es wurden keine @:event.secureCode.plural ausgewählt.',
            noMaxUsesSelected: 'Keine maximale Verwendung ausgewählt.',
            duplicates: 'Es wurden Duplikate gefunden.',
            failed: 'Es konnte kein neues @:event.secureCode.singular erstellt werden. Wenden Sie sich an den Support, wenn das Problem weiterhin besteht.',
            success: `Das neue @:{'event.secureCode.singular'} wurde erfolgreich hinzugefügt.`,
            import: {
                title: 'Importieren',
                failed: `@:{'event.secureCode.plural'} konnte nicht importiert werden. Wenden Sie sich an den Support, wenn das Problem weiterhin besteht.`,
                success: 'Neues @:event.secureCode.plural erfolgreich importiert'
            }
        },
        set: {
            title: 'Sicheren Zustand festlegen',
            info: 'Wenn Sie einen Shop als gesicherten Shop markieren, können Sie optional ein Ablaufdatum festlegen.',
            state: 'Sicherer Staat',
            until: 'Gesichert bis',
            failed: 'Beim Speichern des sicheren Status des Shops ist ein unbekannter Fehler aufgetreten.',
            success: 'Der sichere Zustand wurde erfolgreich gespeichert.'
        },
        import: {
            title: 'Importieren als @.lower:event.secureCode.plural',
            info: 'Bitte wählen Sie einen Shop aus, für den Sie die Vorregistrierungen {0} mit {1} als sichere Einmalcodes importieren möchten.',
            selectShop: 'Shop auswählen...',
            submit: 'Importieren',
            failed: 'Der Import von @.lower:event.secureCode.plural ist fehlgeschlagen.',
            success: 'Der Import von @.lower:event.secureCode.plural war erfolgreich.'
        }
    }
} satisfies Translations;
