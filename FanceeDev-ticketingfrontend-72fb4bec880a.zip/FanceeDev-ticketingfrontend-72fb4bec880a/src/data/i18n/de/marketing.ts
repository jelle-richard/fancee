import type { Translations } from '../types';

export default {
    title: 'Marketing',
    agenda: {
        plural: 'Tagesordnungen',
        singular: 'Agenda',
        title: '@:marketing.agenda.plural',
        table: {
            all: 'Alle aktiven @.lower:event.plural'
        },
        deleteFailed: 'Beim Löschen der Agenda ist ein Fehler aufgetreten.',
        deleteSuccessful: 'Die Tagesordnung wurde erfolgreich gelöscht.',
        loadingFailed: 'Beim Abrufen der Tagesordnungen ist ein Fehler aufgetreten.',
        loadingEventsFailed: 'Beim Laden Ihrer Ereignisse ist ein Fehler aufgetreten.',
        loadingSingleFailed: 'Die Tagesordnung konnte nicht gefunden werden.',
        savingFailed: 'Beim Speichern der Agenda ist ein Fehler aufgetreten.',
        savingSuccessful: 'Die Agenda wurde erfolgreich gespeichert.',
        configure: {
            title: {
                create: 'Erstellen Sie @.lower:marketing.agenda.singular',
                edit: 'Bearbeiten Sie @.lower:marketing.agenda.singular'
            },
            allEvents: 'Verwenden Sie alle @.lower:event.plural',
            showHeaders: 'Ereigniskopfzeilen anzeigen'
        }
    },
    campaign: {
        plural: 'Kampagnen',
        singular: 'Kampagne',
        title: '@:marketing.campaign.plural',
        search: 'Suche @.lower:{\'marketing.campaign.plural\'}...',
        deleteConfirm: 'Sind Sie sicher, dass Sie @.lower:{\'marketing.campaign.singular\'} {0} löschen möchten?',
        deleteFailed: 'Beim Löschen von @.lower:{\'marketing.campaign.singular\'} ist ein Fehler aufgetreten.',
        deleteSuccessful: 'Ihr @.lower:{\'marketing.campaign.singular\'} wurde erfolgreich gelöscht.',
        exportFailed: 'Beim Exportieren Ihres @.lower:{\'marketing.campaign.plural\'} ist ein Fehler aufgetreten.',
        loadingFailed: 'Beim Abrufen Ihres @.lower:{\'marketing.campaign.plural\'} ist ein Fehler aufgetreten.',
        table: {
            name: '@:marketing.campaign.singular',
            event: '@:event.singular',
            clicks: 'Klicks',
            revenue: 'Einnahmen',
            productsSold: 'Verkaufte Produkte',
            averageAge: 'Durchschnittsalter',
            genderSplit: 'Geschlechterspaltung',
            salesSplitTip: '{productAmount} Tickets wurden über {orderAmount} Bestellungen aus {reservationAmount} Reservierungen verkauft.'
        },
        configure: {
            title: 'Konfigurieren Sie @.lower:marketing.campaign.singular',
            loadingEventsFailed: 'Beim Laden Ihrer Ereignisse ist ein Fehler aufgetreten.',
            savingFailed: 'Beim Speichern von @.lower:{\'marketing.campaign.singular\'} ist ein Fehler aufgetreten.',
            savingSuccessful: 'Ihr @.lower:{\'marketing.campaign.singular\'} wurde gespeichert.',
            info: 'Eine @.lower:{\'marketing.campaign.singular\'}-Tracking-URL kann mehreren Shops zugewiesen werden, sofern diese Teil derselben Veranstaltung sind.',
            eventsHint: 'Das Ereignis des vorhandenen @.lower:{\'marketing.campaign.plural\'} kann aufgrund der Erfassung von Statistiken nicht geändert werden.',
            shopDisabledHint: 'Bitte wählen Sie zunächst eine Veranstaltung aus.'
        }
    },
    preRegister: {
        title: '@:marketing.preRegister.plural',
        plural: 'Voranmeldungen',
        singular: 'Vorab anmelden',
        search: 'Durchsuchen Sie @.lower:{\'marketing.preRegister.plural\'}...',
        table: {
            name: '@:form.field.name',
            registered: 'Anmeldungen',
            downloadCsv: 'CSV herunterladen',
            exportSecureShop: 'Sicheren Shop exportieren',
            expiresOn: 'Läuft aus am'
        },
        deleteConfirm: 'Durch das Löschen dieses @.lower:{\'marketing.preRegister.singular\'} werden auch die zugehörigen Registereinträge entfernt.',
        deleteFailed: 'Das @.lower:{\'marketing.preRegister.singular\'} konnte nicht gelöscht werden.',
        deleteSuccessful: 'Der @.lower:{\'marketing.preRegister.singular\'} {name} wurde erfolgreich gelöscht.',
        downloadFailed: 'Beim Herunterladen des Exports @.lower:{\'marketing.preRegister.singular\'} ist ein Fehler aufgetreten.',
        exportFailed: 'Beim Abrufen der Anmeldungen für dieses @.lower:{\'marketing.preRegister.singular\'} ist ein Fehler aufgetreten.',
        exportFailedNoEntries: 'Es scheint, dass derzeit keine Anmeldungen für den Export verfügbar sind.',
        loadingFailed: 'Beim Versuch, Ihre @.lower:{\'marketing.preRegister.singular\'}s abzurufen, ist ein Fehler aufgetreten.',
        configure: {
            createdSuccessfully: 'Das @.lower:{\'marketing.preRegister.singular\'} für {name} wurde erfolgreich erstellt.',
            saveFailed: 'Beim Speichern Ihres @.lower:{\'marketing.preRegister.singular\'} ist ein Fehler aufgetreten.',
            create: 'Erstellen Sie @.lower:{\'marketing.preRegister.singular\'}',
            edit: 'Bearbeiten Sie @.lower:{\'marketing.preRegister.singular\'}',
            header: {
                title: 'Header',
                description: 'Bild, das für den Header des Vorregisters verwendet wird.'
            }
        },
        signUp: {
            complete: {
                title: 'Anmeldung abgeschlossen',
                message: 'Anmeldung abgeschlossen. '
            },
            expired: {
                title: 'Abgelaufen',
                message: 'Der @.lower:{\'marketing.preRegister.singular\'}-Zeitraum ist abgelaufen. '
            },
            failed: `Beim Laden Ihres Vorregisters ist ein Fehler aufgetreten. Bitte versuchen Sie es später noch einmal.`
        }
    }
} satisfies Translations;
