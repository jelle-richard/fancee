import type { Translations } from '../types';

export default {
    changelog: {
        noChanges: 'Keine Änderungen gefunden',
        noChangesDescription: 'Es wurden keine Änderungen im System gefunden. Bitte überprüfen Sie es später noch einmal, ob Aktualisierungen des Systems vorliegen.'
    },
    faq: {
        title: 'Häufig gestellte Fragen',
        description: 'Irgendwelche Fragen?',
        email: {
            title: 'Email',
            description: 'Wir werden unser Bestes tun, um Sie innerhalb von {0} Werktagen zu kontaktieren!',
            button: 'Schreiben Sie uns eine E-Mail'
        },
        phone: {
            title: 'Telefon',
            description: 'Wir helfen Ihnen jederzeit gerne weiter.'
        },
        whatsapp: {
            title: 'WhatsApp',
            description: 'Wir werden unser Bestes tun, um uns an Werktagen innerhalb von {0} Stunden mit Ihnen in Verbindung zu setzen!',
            button: 'Nachricht an uns'
        },
        categories: [
            {
                icon: 'user',
                title: 'Kontoverwaltung',
                subTitle: 'Antworten zum Einrichten von Kontokonfigurationen',
                questions: [
                    ['Kann ich meine Gebühren ändern?', 'Ihre Plattformgebühren basieren auf dem im Vertrag genannten Dashboard-Paket. '],
                    ['Kann ich mein Paket up- oder downgraden?', 'Sofern in Ihrem Vertrag nicht ausdrücklich anders angegeben, können Sie dies jederzeit tun. '],
                    ['Wie aktiviere ich 2-FA?', 'Die Aktivierung von 2-FA ist eine großartige Möglichkeit, Ihr Konto weiter zu schützen. '],
                    ['Wie ändere ich meine Umsatzsteuer-Identifikationsnummer, mein Bankkonto und/oder meine Handelskammerdaten?', 'Sie dürfen diese Informationen nicht nach eigenem Ermessen ändern. '],
                    ['Es gibt Menüpunkte, die gesperrt sind. Wie kann ich darauf zugreifen?', 'Abhängig vom Dashboard-Paket, für das Ihr Konto konfiguriert ist, gibt es bestimmte Seiten, die möglicherweise nicht enthalten sind. ']
                ]
            },
            {
                icon: 'shopping-bag',
                title: 'Verkäufe',
                subTitle: 'So wickeln Sie Ihre Verkäufe ab',
                questions: [
                    ['Hilft mir der Support beim Verkauf?', 'Das Dashboard unterstützt eine breite Palette an Erklärungen in Form von Tutorials, Online-Webinaren und Downloads, die rund um die Uhr verfügbar sind. '],
                    ['Wie kann ich meinen Kunden Rabatte gewähren?', 'Rabatte sind eine tolle Möglichkeit, Kunden anzulocken, Restbestände zu verkaufen oder eine Entschädigung anzubieten. '],
                    ['Ich habe Produkte im Status „Ausstehend“. Was bedeutet das?', 'Wenn ein Kunde Produkte über Ihren Shop kauft, speichert unsere Plattform seine Produktauswahl in einer Reservierung (Standard: 8 Minuten), die es dem Benutzer ermöglicht, die erforderlichen Formulare auszufüllen, um seinen Kauf abzuschließen. '],
                    ['Kann ich die Produktpreise während des Verkaufs erhöhen oder senken?', 'Ja, Sie können die Preise Ihrer Produkte jederzeit ändern, indem Sie sie im Schritt „Produkte“ unter „Ereignis konfigurieren“ anpassen. '],
                    ['Kann ich den Produktbestand während des Verkaufs erhöhen oder verringern?', 'Der Produktbestand kann jederzeit geändert werden. Wenn der Restbestand jedoch auf 0 aktualisiert wird, können ausstehende Reservierungen möglicherweise noch abgeschlossen werden. '],
                    ['Kann ich die Plattformgebühren an den Kunden weitergeben?', 'Sie können unter den erweiterten Optionen zum Bearbeiten eines Produkts im Schritt „Produkte“ von „Ereignis konfigurieren“ frei Ihre eigene Gebühr zum Produktpreis hinzufügen.']
                ]
            },
            {
                icon: 'calendar',
                title: 'Veranstaltungsmanagement',
                subTitle: 'So richten Sie Ihre Veranstaltungen und Shops ein',
                questions: [
                    ['Was bewirken die Event-Event-Typen für ein Event?', 'Beim Erstellen einer Veranstaltung stehen Sie vor der Wahl zwischen einer normalen, einer Sitzplatz- und einer Zeitfensterveranstaltung. '],
                    ['Über welchen Link teile ich meinen Online-Shop?', 'Sobald Sie eine Veranstaltung mit mindestens einem Shop erstellt haben, wird der Link dieses Shops in Ihrer Veranstaltungsübersicht angezeigt, die Sie über die Seite „Meine Veranstaltungen“ finden.'],
                    ['Wie kann ich meinen eigenen Markenführer in den Online-Shops nutzen?', 'Beim Erstellen von Shops für Ihre Veranstaltung können Sie über die Option „Branding-Farben anwenden“ im Schritt „Shops“ von „Event konfigurieren“ Farben auswählen. ']
                ]
            },
            {
                icon: 'mobile-notch',
                title: 'Tickets',
                subTitle: 'So überprüfen Sie den Ereigniszugriff',
                questions: [
                    ['Wie scanne ich Tickets?', 'Mithilfe der „WeAreFancee Scan-App“, die sowohl im Android Play Store als auch im Apple App Store verfügbar ist. '],
                    ['Wie melde ich mich am Scanner an?', 'Sie können sich mit Ihrem Organisationskonto anmelden oder alternativ über die Seite „Organisationsteams“ unter dem Menüpunkt „Scannen“ Organisationsteams erstellen.'],
                    ['Mein Kunde gibt an, dass das Ticket nicht zugestellt wurde. Was kann ich tun?', 'Wenn der Kunde sein Ticket nicht erhalten hat, können Sie die folgenden Schritte ausführen: 1. Sie können den Kunden zur Seite „Verlorenes Ticket“ auf https://www.WeAreFancee.com/lost-ticket führen\r '],
                    ['Was mache ich, wenn ein Kunde ohne Ticket zur Veranstaltung kommt?', 'Wenn ein Kunde vergessen hat, sein Ticket mitzubringen, aber einen Zahlungsnachweis vorlegen kann, können Sie das Ticket in der App über das Fenster „Ticketstatistik“ finden und nach E-Mail und/oder Geburtsdatum suchen']
                ]
            },
            {
                icon: 'coin',
                title: 'Finanzen',
                subTitle: 'So verfolgen Sie Ihre Einnahmen',
                questions: [
                    ['Kann ich eine Zwischenzahlung erhalten?', 'Ja, indem Sie zu Ihrem „Wallet“ navigieren, das Sie unter dem Menüpunkt „Finanzen“ finden, können Sie eine Auszahlung beantragen, wenn Ihr aktueller Kontostand positiv ist. '],
                    ['Wann erhalte ich eine Auszahlung?', 'Wenn Ihr Kontostand positiv ist, können Sie eine Auszahlung beantragen, indem Sie zu Ihrem „Wallet“ navigieren, das Sie unter dem Menüpunkt „Finanzen“ finden.'],
                    ['Wie erstatte ich einem Kunden eine Rückerstattung?', 'Sie können in der Transaktionsübersicht unter „Transaktionen“ unter dem Menüpunkt „Finanzen“ nach dem Kunden oder seiner Transaktion suchen. '],
                    ['Wo finde ich meine Rechnungen?', 'In der Übersicht der Seite „Rechnungen“ unter dem Menüpunkt „Finanzen“.']
                ]
            },
            {
                icon: 'chart-simple',
                title: 'Statistiken',
                subTitle: 'So nutzen Sie Ihre Kundendaten',
                questions: [
                    ['Wie verfolge ich die Ergebnisse meiner Kampagne?', 'Über die Seite „Kampagnen“ unter dem Menüpunkt „Marketing“.'],
                    ['Wo finde ich grundlegende Ereignisstatistiken?', 'Auf dem Startbildschirm sehen Sie zunächst kontoweite Statistiken. '],
                    ['Wie finde ich Kunden und Transaktionen?', 'Sie können zu den Seiten „Finanzen“ > „Bestellung“ navigieren, wo Sie nach Kunden oder Bestelldetails suchen können. Wenn Sie auf eine Zeile klicken, erhalten Sie weitere Informationen.'],
                    ['Woher weiß ich, welche Kunden ich kontaktieren darf?', 'Wenn Sie einen oder mehrere Benutzer kontaktieren möchten, können Sie zur Seite „Transaktionen“ unter dem Menüpunkt „Finanzen“ navigieren und nach Benutzern filtern, die sich entweder für eine E-Mail- oder SMS-Werbung angemeldet haben.'],
                    ['Wie behalte ich den Überblick über die Verkäufe?', 'Auf der Startseite können Sie Ihre Veranstaltung suchen und auswählen, um einen Einblick in die täglichen Verkäufe, den Restbestand und Ihre Bestseller zu erhalten']
                ]
            }
        ]
    },
    profile: {
        loadingFailed: 'Beim Abrufen Ihrer Profilinformationen ist ein Fehler aufgetreten. Bitte versuchen Sie es später noch einmal.',
        contact: {
            title: 'Kontakt',
            add: '@:platform.profile.contact.title',
            added: '{0} {1} wurde als Kontakt hinzugefügt.',
            deleted: '{0} {1} wurde als Kontakt gelöscht.',
            createFailed: 'Beim Erstellen des Kontakts ist ein Fehler aufgetreten.',
            deleteFailed: 'Beim Versuch, den Kontakt zu entfernen, ist ein Fehler aufgetreten.',
            editFailed: 'Beim Speichern des Kontakts ist ein Fehler aufgetreten.',
            emptyView: [
                'Bei @:global.platform.name verstehen wir, dass Sie Angelegenheiten delegieren müssen, wenn Ihr Unternehmen wächst.',
                'Wenn keine zusätzlichen Kontakte konfiguriert sind, wird unsere gesamte Korrespondenz an die registrierte E-Mail-Adresse dieses Kontos gesendet.',
                'Pro Rolle können Kontakte definiert werden, sodass unsere Anfragen bei den richtigen Abteilungen ankommen.'
            ],
            role: {
                customerSupprt: 'Kundendienst',
                finance: 'Finanzen',
                marketing: 'Marketing',
                organization: 'Organisation'
            }
        },
        organization: {
            title: '@:global.organization',
            cannotMakeChanges: 'Ihr Vertrag wurde erstellt.',
            downloadContract: 'Vertrag herunterladen',
            finance: 'Finanzen',
            holder: 'Halter',
            legalEntity: 'Juristische Person',
            loadCurrenciesFailed: 'Beim Abrufen der Währungen ist ein Fehler aufgetreten. '
        },
        packages: {
            title: 'Pakete',
            request: 'Anfrage',
            requestFailed: 'Es konnte keine Paketänderung angefordert werden.',
            requestSuccess: 'Ihre Anfrage für eine Paketänderung zu {0} wurde an unseren Support übermittelt.',
            selfService: 'Selbstbedienung',
            supportBusinessHours: 'Kontobetreuung (Geschäftszeiten)',
            support247: 'Kontounterstützung (24/7)',
            ticketFee: '{0} Ticketgebühr',
            ticketFeeCustom: 'Ticketgebühr in Absprache mit dem Verkauf.',
            unlimited: 'Unbegrenzt',
            feature: {
                accountSupport: 'Kontounterstützung',
                ambassadorPrograms: 'Botschafterprogramme',
                customerAnalytics: 'Kundenanalyse',
                customFeatures: 'Maßgeschneiderte Funktionen',
                discounts: 'Rabatte',
                guestlist: 'Gästeliste',
                marketingCampaigns: 'Marketing-Kampagnen',
                salesGuides: 'Verkaufsleitfäden',
                salesScanApp: 'Verkäufe',
                seating: 'Sitzplätze',
                shopCustomization: 'Shop-Anpassung',
                websiteIntegrations: 'Website-Integrationen'
            },
            light: {
                name: 'Licht',
                description: 'Kleine Organisationen bis zu 2500 Tickets pro Jahr.'
            },
            medium: {
                name: 'Mittel',
                description: 'Größere Organisationen für 2500 Tickets pro Jahr.'
            },
            custom: {
                name: 'Brauch',
                description: 'Für Organisationen mit Bedarf an benutzerdefinierter Logik.'
            }
        },
        security: {
            title: 'Sicherheit',
            passwordChanged: 'Ihr Passwort wurde geändert.',
            passwordChangeFailed: 'Beim Versuch, Ihr Passwort zu ändern, ist ein Fehler aufgetreten. '
        },
        sessions: {
            title: 'Sitzungen'
        },
        user: {
            title: 'Benutzer',
            avatar: 'Profilbild'
        }
    },
    receipt: {
        title: 'Quittung herunterladen',
        description: 'Ihre Quittung enthält eine Übersicht Ihrer Einkäufe.',
        downloading: 'Ihre Quittungs-PDF ist unterwegs.',
        exceeded: 'Beim Herunterladen Ihrer Quittung ist ein kleines Problem aufgetreten.',
        failed: 'Wir konnten Ihre Quittung nicht abrufen.',
        success: 'Ihr Beleg-PDF wurde heruntergeladen! '
    }
} satisfies Translations;
