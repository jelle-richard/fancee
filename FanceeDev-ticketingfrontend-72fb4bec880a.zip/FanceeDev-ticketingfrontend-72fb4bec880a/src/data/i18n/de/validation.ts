import type { Translations } from '../types';

export default {
    errors: {
        message: 'Bitte beheben Sie die Fehler im Formular, bevor Sie mit der Übermittlung fortfahren.',
        pleaseFix: 'Bitte beheben Sie die folgenden Punkte',
        pleaseFixErrors: 'Bitte behebe die folgenden Fehler'
    },
    validator: {
        afterDate: 'Das Datum muss nach {formattedDateTime} liegen.',
        alpha: 'Bitte geben Sie nur alphabetische Zeichen ein.',
        alphaNum: 'Bitte geben Sie einen Wert ein, der nur Buchstaben und Zahlen enthält.',
        beforeDate: 'Das Datum muss vor {formattedDateTime} liegen.',
        between: 'Bitte geben Sie eine Zahl zwischen {min} und {max} (einschließlich) ein.',
        betweenDates: 'Das Datum muss zwischen {formattedMinDate} und {formattedMaxDate} liegen.',
        decimal: 'Bitte geben Sie einen gültigen Dezimalwert ein.',
        email: 'Bitte geben Sie eine gültige E-Mail-Adresse ein.',
        future: 'Bitte geben Sie ein zukünftiges Datum ein.',
        integer: 'Bitte geben Sie eine ganze Zahl ein.',
        ipAddress: 'Bitte geben Sie eine gültige IP-Adresse ein.',
        macAddress: 'Bitte geben Sie eine gültige MAC-Adresse ein.',
        maxPrice: 'Bitte geben Sie einen Betrag ein, der kleiner oder gleich {formattedMaxPrice} ist.',
        maxLength: 'Bitte geben Sie einen Wert mit einer maximalen Länge von {max} Zeichen ein.',
        maxValue: 'Bitte geben Sie eine Zahl kleiner oder gleich {max} ein.',
        minLength: 'Bitte geben Sie einen Wert mit einer Mindestlänge von {min} Zeichen ein.',
        minValue: 'Bitte geben Sie eine Zahl größer oder gleich {min} ein.',
        numeric: 'Bitte geben Sie einen gültigen numerischen Wert ein.',
        past: 'Bitte geben Sie ein vergangenes Datum ein.',
        phoneNumber: 'Bitte geben Sie eine gültige Telefonnummer ein.',
        price: 'Bitte geben Sie einen gültigen Preis mit einem Dezimalwert ein.',
        required: 'Dieses Feld ist erforderlich.',
        requiredIf: 'Dieses Feld ist erforderlich.',
        requiredUnless: 'Dieses Feld ist erforderlich.',
        sameAs: 'Bitte stellen Sie sicher, dass dieses Feld mit dem anderen Feld übereinstimmt.',
        url: 'Bitte geben Sie eine gültige URL ein.',
        minTextLength: '@:validation.validator.minLength',
        secureCode: `Bitte geben Sie einen Wert ein, der nur Buchstaben, Zahlen oder eines der folgenden Zeichen enthält: . {'@'} _ -.`
    }
} satisfies Translations;
