import type { Translations } from '../types';

export default {
    emptyView: {
        title: 'Nichts hier',
        message: 'Es scheint, dass für Ihr Konto keine Ereignisse gefunden wurden und daher keine Statistiken verfügbar sind.'
    },
    monitor: {
        title: 'Überwachen Sie Ihre Veranstaltungen',
        subTitle: 'Bitte wählen Sie eine Veranstaltung aus, um Einblicke in Ihre Marktposition zu gewinnen.',
        select: 'Veranstaltung auswählen...'
    },
    statistics: {
        loadingFailed: 'Es konnten keine Statistiken abgerufen werden.',
        notEnoughData: 'Es scheint, dass das Ereignis noch keine aussagekräftigen Statistiken generiert hat.',
        averageAge: {
            title: 'Durchschnittsalter',
            tip: {
                female: 'Durchschnittliches Alter weiblicher Kunden: {0} Jahre.',
                male: 'Durchschnittliches Alter männlicher Kunden: {0} Jahre.',
                neutral: 'Durchschnittliches Alter neutraler Kunden von {0} Jahren.',
                unknown: 'Durchschnittliches unbekanntes Kundenalter von {0} Jahren.'
            }
        },
        fulfilledOrders: {
            title: 'Erfüllte Bestellungen',
            tip: '{0} Bestellungen erfüllt.'
        },
        pendingRefunds: {
            title: 'Ausstehende Rückerstattungen',
            tip: '{0} insgesamt ausstehende Rückerstattungen.'
        },
        productsSold: {
            title: 'Verkaufte Produkte',
            tip: '{0} insgesamt verkaufte Produkte.'
        },
        ticketsScanned: {
            title: 'Tickets gescannt',
            tip: '{0} insgesamt gescannte Tickets.'
        },
        uniqueCustomers: {
            title: 'Einzigartige Kunden',
            tip: {
                female: '{0} einzigartige weibliche Kunden.',
                male: '{0} einzigartige männliche Kunden.',
                neutral: '{0} einzigartige neutrale Kunden.',
                unknown: '{0} einzigartiger unbekannter Kunde.'
            }
        },
        finance: {
            cashSalesRevenue: 'Einnahmen aus Barverkäufen',
            onlineSalesRevenue: 'Online-Verkaufserlöse',
            platformExpenses: 'Plattformkosten',
            profit: 'Profitieren'
        },
        bestSellingProducts: {
            title: 'Top-Produkte',
            subTitle: 'Die meistverkauften Produkte der letzten {0} Tage.'
        },
        dailyOrders: {
            title: 'Auftragserlös',
            subTitle: 'Tägliche Übersicht über abgeschlossene Bestellungen.',
            ordersOnDay: 'Bestellungen am Tag',
            cashRevenue: 'Bareinnahmen',
            onlineRevenue: 'Online-Einnahmen',
            orders: 'Aufträge',
            productsSold: 'Verkaufte Produkte',
            revenueFlow: 'Einnahmenfluss'
        },
        productRatio: {
            title: 'Produktverhältnis',
            subTitle: 'Produktfluss basierend auf der Menge.'
        },
        productStatistics: {
            guest: 'Gast',
            guestlistTip: 'Bitte beachten Sie, dass Gästelistenkarten möglicherweise nicht immer vom Bestand abgezogen werden.',
            name: '@:form.field.name',
            pending: 'Ausstehend',
            pendingTip: '{0} Reservierungen stehen aus, {1} befindet sich derzeit im Zahlungsvorgang.',
            price: '@:form.field.price',
            remaining: 'Übrig',
            sold: '@:global.sold',
            stock: '@:form.field.stock'
        }
    },
    wallet: {
        title: 'Wallet-Guthaben',
        manage: 'Verwalten'
    }
} satisfies Translations;
