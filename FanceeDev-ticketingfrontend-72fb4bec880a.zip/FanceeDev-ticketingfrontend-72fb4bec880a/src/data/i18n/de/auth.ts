import type { Translations } from '../types';

export default {
    logout: 'Abmelden',
    useClient: 'Persönliches Konto anzeigen',
    login: {
        title: 'Anmeldung',
        description: 'Um sich anzumelden, geben Sie bitte Ihre Zugangsdaten ein und greifen Sie auf Ihr Konto zu.',
        submit: 'Anmelden',
        or: 'Oder',
        createAccount: 'Ein Konto erstellen',
        forgotPassword: 'Passwort vergessen?'
    },
    register: {
        title: 'Melden Sie sich an',
        description: 'Willkommen bei WeAreFancee!',
        clientTitle: 'Kunde',
        clientDescription: 'Ich möchte meine eigenen Tickets sehen.',
        organizationTitle: 'Organisation',
        organizationDescription: 'Ich benötige Tickets für meine Veranstaltung(en).',
        complete: 'Ihr Konto wurde erstellt!',
        submit: 'Registrieren',
        client: {
            title: 'Registrieren – Kunde',
            description: 'Beginnen wir mit der Erstellung Ihres persönlichen WeAreFancee-Kontos. '
        },
        organization: {
            title: 'Anmelden – Organisation',
            description: 'Beginnen wir mit der Erstellung Ihres WeAreFancee-Kontos. '
        }
    },
    select: {
        title: 'Hallo {Name},',
        description: 'Ihr Konto kann verschiedene Organisationen verwalten. '
    },
    verify: {
        title: 'Bestätigung des Kontos',
        description: 'Warten Sie einen Moment, während wir Ihre Kontodaten überprüfen.',
        busy: 'Überprüfung...',
        done: 'Dein Account wurde verifiziert! '
    },
    forgotPassword: {
        title: 'Setze dein Passwort zurück',
        description: 'Keine Sorge!',
        feedback: 'Wenn Sie ein Konto bei @:global.platform.name haben, erhalten Sie eine E-Mail mit Anweisungen zum Zurücksetzen Ihres Passworts.'
    },
    forgotPasswordReset: {
        title: '@:auth.forgotPassword.title',
        description: 'Um wieder Zugriff auf Ihr Konto zu erhalten, geben Sie bitte unten Ihr neues Passwort ein.',
        success: 'Dein Passwort wurde zurück gesetzt. '
    },
    reauthenticate: {
        title: 'Sie wurden abgemeldet.',
        body: 'Um Ihr Konto weiterhin zu nutzen, melden Sie sich bitte erneut mit Ihrem Passwort an.',
        submit: '@:auth.login.submit'
    },
    sessions: {
        singular: 'Sitzung',
        plural: 'Sitzungen',
        search: 'Suchsitzungen...',
        device: 'Gerät',
        ipAddress: 'IP Adresse',
        issuedOn: 'Ausgegeben am',
        expires: 'Läuft ab',
        deleteFailed: 'Die Sitzung konnte nicht gelöscht werden.',
        loadingFailed: 'Sitzungen konnten nicht abgerufen werden.',
        deleted: 'Die Sitzung wurde erfolgreich gelöscht.'
    }
} satisfies Translations;
