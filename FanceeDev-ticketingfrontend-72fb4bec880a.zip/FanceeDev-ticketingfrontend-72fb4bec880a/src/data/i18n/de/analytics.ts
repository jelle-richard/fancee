import type { Translations } from '../types';

export default {
    title: 'Daten',
    titles: {
        campaign: 'Kampagne',
        channels: 'Kanäle',
        home: 'Heim',
        monitor: 'Monitor',
        overview: 'Überblick',
        social: 'Sozial',
        ticketing: 'Buchung'
    },
    navigation: {
        campaign: 'Kampagne',
        channels: 'Kanäle',
        home: 'Heim',
        settings: 'Einstellungen',
        social: 'Sozial',
        ticketing: '@:analytics.titles.ticketing'
    },
    comparisonView: 'Vergleichen',
    disabled: 'Deaktiviert',
    enabled: 'Ermöglicht',
    paused: 'Angehalten',
    fullOverview: 'Vollständiger Überblick',
    noData: 'Es konnten keine Daten gefunden werden',
    openInBrowser: 'Im Browser öffnen',
    selectField: 'Feld auswählen...',
    splitOn: 'Aufgeteilt auf...',
    noChannelsFound: {
        title: 'Keine Kanäle gefunden',
        message: 'Es wurden keine Kanäle gefunden. '
    },
    channel: {
        plural: 'Kanäle',
        singular: 'Kanal',
        saving: 'Kanal wird gespeichert...',
        updating: 'Abonnements werden aktualisiert...',
        info: {
            createdOn: 'Erstellt am',
            lastLogin: 'Letzte Anmeldung',
            organization: 'Organisation',
            owner: 'Eigentümer',
            request: 'Anfrage'
        },
        new: {
            title: 'Neuer Kanal',
            user: 'Benutzer',
            supermetrics: {
                account: 'SuperMetrics – ds_accounts',
                user: 'SuperMetrics – ds_user'
            }
        },
        status: {
            active: 'Aktiv',
            error: 'Fehler',
            expired: 'Abgelaufen',
            inactive: 'Inaktiv',
            partiallyActive: 'Teilweise aktiv',
            paused: 'Angehalten',
            setup: 'Aufstellen'
        },
        table: {
            name: '@:form.field.name',
            type: 'Typ',
            status: 'Status',
            organization: 'Organisation',
            owner: 'Eigentümer',
            email: '@:form.field.email',
            createdOn: 'Erstellt am'
        },
        type: {
            facebook: 'Facebook',
            facebookads: 'Facebook-Anzeigen',
            facebookpublicdata: 'Öffentliche Facebook-Daten',
            googleads: 'Google-Anzeigen',
            googleanalytics: 'Google Analytics',
            googleanalytics4: 'Google Analytics V4',
            instagram: 'Instagram',
            instagrampublicdata: 'Öffentliche Instagram-Daten',
            linkedin: 'LinkedIn',
            tiktok: 'TikTok',
            youtube: 'Youtube',
            youtubev2: 'YouTube V2'
        }
    },
    subscription: {
        plural: 'Abonnements',
        singular: 'Abonnement',
        status: {
            active: 'Aktiv',
            inactive: 'Inaktiv'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            aw_ad: 'Google Ads – Anzeige',
            aw_age: 'Google Ads – Alter',
            aw_campaign: 'Google Ads – Kampagne',
            aw_conversion: 'Google Ads – Konvertierung',
            aw_gender: 'Google Ads – Geschlecht',
            aw_geo: 'Google Ads – Geo',
            aw_keyword: 'Google Ads – Schlüsselwort',
            aw_placement: 'Google Ads – Platzierung',
            aw_search_query: 'Google Ads – Suchabfrage',
            aw_shopping: 'Google Ads – Einkaufen',
            fa_ads: 'Facebook-Anzeigen – Anzeige',
            fa_age_and_gender: 'Facebook-Anzeigen – Alter und Geschlecht',
            fa_campaign: 'Facebook-Anzeigen – Kampagne',
            fa_conversion: 'Facebook-Anzeigen – Konvertierung',
            fa_geo: 'Facebook-Anzeigen – Geo',
            fa_video: 'Facebook-Anzeigen – Video',
            fb: 'Facebook Seite',
            fb_age_and_gender: 'Facebook – Alter und Geschlecht',
            fb_geo_likes: 'Facebook – Geografisch',
            fb_posts: 'Facebook – Beiträge',
            fbpd_page: 'Öffentliche Facebook-Daten – Seite',
            fbpd_posts: 'Öffentliche Facebook-Daten – Beiträge',
            fbpd_url_shares: 'Öffentliche Facebook-Daten – URL-Freigaben',
            ga_content: 'Google Analytics – Inhalt',
            ga_ecommerce: 'Google Analytics – E-Commerce',
            ga_events: 'Google Analytics – Ereignisse',
            ga_paid_traffic: 'Google Analytics – Bezahlter Traffic',
            ga_search: 'Google Analytics – Suche',
            ga_social: 'Google Analytics – Sozial',
            ga_technology: 'Google Analytics – Technologie',
            ga_traffic: 'Google Analytics – Verkehr',
            ga_user: 'Google Analytics – Benutzer',
            gawa_device: 'Google Analytics 4 – Geräte',
            gawa_ecom_items: 'Google Analytics 4 – E-Commerce-Artikel',
            gawa_engagement: 'Google Analytics 4 – Engagement',
            gawa_publishing: 'Google Analytics 4 – Veröffentlichung',
            gawa_traffic_acquisition: 'Google Analytics 4 – Traffic-Erfassung',
            gawa_user_acquisition: 'Google Analytics 4 – Nutzerakquise',
            igi: 'Instagram – Follower',
            igi_age_and_gender: 'Instagram – Alter und Geschlecht',
            igi_country: 'Instagram - Land',
            igi_media: 'Instagram – Medien',
            igi_profile_data: 'Instagram – Profildaten',
            igpd2_hashtags: 'Öffentliche Instagram-Daten – Hashtags',
            igpd2_posts: 'Öffentliche Instagram-Daten – Beiträge',
            igpd2_profiles: 'Öffentliche Instagram-Daten – Profile',
            lip_country: 'LinkedIn – Land',
            lip_page: 'LinkedIn - Seite',
            lip_post: 'LinkedIn – Beiträge',
            tikba_country: 'TikTok – Land',
            tikba_gender: 'TikTok – Geschlecht',
            tikba_profile: 'TikTok – Profil',
            tikba_video: 'TikTok – Video',
            yt2_ad_performance: 'YouTube v2 – Anzeigenleistung',
            yt2_channel: 'Youtube v2 – Kanal',
            yt2_demographic: 'YouTube v2 – Demographisch',
            yt2_device: 'Youtube v2 – Gerät',
            yt2_geo: 'Youtube v2 – Geo',
            yt2_traffic_source: 'Youtube v2 – Traffic-Quelle',
            yt2_video: 'Youtube v2 – Video',
            yt_video: 'YouTube - Video'
        }
    },
    header: {
        allChannels: 'Alle Kanäle',
        comparisonView: 'Vergleichsansicht',
        datePresets: {
            lastMonth: 'Im vergangenen Monat',
            lastSevenDays: 'Letzten 7 Tage',
            thisMonth: 'Diesen Monat',
            thisYear: 'Dieses Jahr'
        }
    },
    ads: {
        title: 'Anzeigen',
        budget: 'Budget',
        campaign: 'Kampagne',
        clicks: 'Klicks',
        conversion: 'Konvertierung',
        cost: 'Kosten',
        cpc: 'CPC',
        ctr: 'CTR',
        date: '@:global.date',
        engagement: 'Engagement',
        impressions: 'Eindrücke',
        status: 'Status',
        totalCampaigns: 'Gesamtzahl der Kampagnen',
        totalSpent: 'Gesamtausgaben'
    },
    bestPostTime: {
        title: 'Beste Zeit zum Posten',
        comments: 'Kommentare',
        likes: 'Likes',
        reach: 'Erreichen',
        basedOn: {
            comments: 'Basierend auf der durchschnittlichen Anzahl an Kommentaren',
            likes: 'Basierend auf durchschnittlichen Likes',
            reach: 'Basierend auf der durchschnittlichen Reichweite'
        },
        engagement: {
            highest: 'Höchstes Engagement',
            lowest: 'Geringstes Engagement'
        }
    },
    campaignInfo: {
        title: 'allgemeine Informationen',
        ageClicks: 'Altersklicks',
        budget: 'Budget',
        clicks: 'Klicks',
        conversion: 'Konvertierung',
        cpc: 'CPC',
        ctr: 'CTR',
        genderClicks: 'Geschlechterklicks',
        impressions: 'Eindrücke',
        remaining: 'Übrig',
        spent: 'Ausgegeben'
    },
    captions: {
        title: 'Bildunterschriften'
    },
    emotions: {
        title: 'Emotionen',
        subTitle: 'Nur für Facebook',
        like: 'Wie',
        likes: 'Likes',
        love: 'Liebe',
        thankful: 'Dankbar',
        wow: 'Wow',
        haha: 'Haha',
        pride: 'Stolz',
        anger: 'Wut',
        sorry: 'Entschuldigung'
    },
    engagement: {
        title: 'Engagement',
        clicks: 'Klicks',
        conversion: 'Konvertierung',
        cpc: 'CPC',
        ctr: 'CTR',
        comments: 'Kommentare',
        impressions: 'Eindrücke',
        likes: 'Likes',
        shares: 'Anteile'
    },
    field: {
        activeFollowers: 'Aktive Follower',
        averageAge: 'Durchschnittsalter',
        clicksOnPage: 'Klicks',
        comments: 'Kommentare',
        description: 'Beschreibung',
        increasedFollowers: 'Mehr Follower',
        likes: 'Likes',
        percentIncreaseFollowers: 'Follower nehmen zu',
        percentMen: 'Männer',
        percentWomen: 'Frauen',
        reach: 'Erreichen',
        shares: 'Anteile',
        totalFollowers: 'Gesamtzahl der Follower'
    },
    followers: {
        title: 'Anhänger',
        lost: 'Verloren',
        new: 'Neu',
        total: 'Gesamt'
    },
    hashtags: {
        title: 'Hashtags'
    },
    locations: {
        title: 'Standorte'
    },
    mentions: {
        title: 'Erwähnungen'
    },
    monitor: {
        title: 'Überwachen Sie Ihre Kanäle',
        placeholder: 'Wählen Sie einen Kanal...',
        averageDay: 'Durchschnitt pro Tag',
        averageHour: 'Durchschnitt pro Stunde',
        bestDayToPost: 'Der beste Tag zum Posten',
        bestHourToPost: 'Beste Stunde zum Posten',
        captions: 'Bildunterschriften',
        emojis: 'Emojis',
        hashtags: '#Hashtags',
        mentions: '{\'@\'}Erwähnungen',
        topPosts: 'Top 5 Beiträge',
        age: {
            title: 'Alter',
            subTitle: 'Likes basierend auf dem Alter'
        },
        emotion: {
            title: 'Emotion',
            subTitle: 'Likes basieren auf Emotionen'
        },
        gender: {
            title: 'Geschlecht',
            subTitle: 'Likes basierend auf dem Geschlecht'
        }
    },
    post: {
        title: 'Beiträge',
        comments: 'Kommentare',
        date: '@:global.date',
        likes: 'Likes',
        shares: 'Anteile',
        clicks: 'Klicks',
        message: 'Nachricht',
        reach: 'Erreichen',
        reactions: 'Reaktionen',
        time: '@:global.time',
        views: 'Ansichten',
        table: {
            channel: '@:analytics.channel.singular',
            date: '@:global.date',
            type: 'Typ',
            engagement: 'Engagement',
            conversion: 'Konvertierung',
            paidYesNo: 'Bezahlt J/N'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            video: 'Video',
            video_inline: 'Video',
            video_direct_response: 'Videoantwort',
            reels_video: 'Rollenvideo',
            story_video: 'Story-Video',
            feed_carousel_album: 'Feed-Album',
            photo: 'Foto',
            image: 'Bild',
            album: 'Album',
            carousel_album: 'Album',
            share: 'Aktie',
            cover_photo: 'Titelbild',
            image_share: 'Bildfreigabe',
            native_templates: 'Werbung',
            event: 'Ereignis'
        }
    },
    reach: {
        title: 'Erreichen',
        gained: 'Reichweite gewonnen',
        gainedPercentage: '{0} gewonnen',
        lost: 'Reichweite verloren',
        lostPercentage: '{0} verloren'
    },
    socialImpact: {
        title: 'Sozialer Einfluss',
        engagement: 'Engagement',
        followers: 'Anhänger',
        growth: 'Wachstum',
        posts: 'Beiträge',
        reach: 'Erreichen',
        less: 'weniger als in der letzten Periode',
        more: 'mehr als in der letzten Periode'
    },
    spent: {
        title: 'Gesamtausgaben',
        budget: 'Budget',
        cost: 'Kosten',
        total: 'Gesamt'
    },
    tags: {
        title: 'Titel',
        captions: 'Bildunterschriften',
        hashtags: 'Hashtags',
        mentions: 'Erwähnungen'
    },
    topLocations: {
        title: 'Top-Standorte',
        country: 'Land',
        visitors: 'Besucher'
    },
    totalCampaigns: {
        title: 'Gesamtzahl der Kampagnen',
        enabled: 'Ermöglicht',
        disabled: 'Deaktiviert',
        paused: '@:analytics.paused'
    },
    crm: {
        channel: {
            title: '@:analytics.channel.plural',
            delete: {
                title: 'Kanal löschen',
                message: 'Dadurch werden der Kanal, die Abonnements und alle dazugehörigen Daten gelöscht.',
                done: 'Der Kanal wurde gelöscht.'
            },
            refresh: {
                title: 'Kanal aktualisieren',
                message: 'Beim Aktualisieren eines Kanals wird versucht, für jedes aktive Abonnement Daten von bis zu 6 Monaten abzurufen.',
                working: 'Die Aktualisierung für Kanal {0} beginnt in Kürze. '
            },
            fields: {
                title: 'Alle Felder',
                table: {
                    name: 'Name',
                    type: 'Typ',
                    field: 'Feld',
                    group: 'Gruppe',
                    description: 'Beschreibung'
                }
            }
        },
        subscription: {
            refresh: 'Die Aktualisierung für das Abonnement {0} beginnt bald.',
            info: {
                title: 'Die Info',
                createdOn: 'Erstellt am',
                cron: 'Cron-Zeitplan',
                fields: 'Felder',
                showFields: 'Felder anzeigen',
                status: 'Status',
                type: 'Typ',
                updatedOn: 'Aktualisiert am'
            },
            chart: {
                title: 'Daten'
            },
            fields: {
                name: 'Name',
                type: 'Typ',
                field: 'Feld'
            },
            history: {
                title: 'Geschichte'
            }
        },
        ticketing: {
            notice: {
                message: 'Die Daten werden täglich um 11:00 Uhr UTC und 23:00 Uhr UTC synchronisiert. Dies kann bis zu einer Stunde dauern.'
            },
            averageOrderPrice: {
                title: 'Durchschnittlicher Bestellpreis',
                average: 'Durchschnittspreis für alle Bestellungen'
            },
            gendersByAge: {
                title: 'Geschlechter nach Altersgruppe'
            },
            averageOrderReservation: {
                title: 'Durchschnittliche Zeit für Reservierungen und Bestellungen',
                orderTime: 'Durchschnittliche Bestellzeit',
                reservationTime: 'Durchschnittliche Reservierungszeit'
            }
        }
    }
} satisfies Translations;
