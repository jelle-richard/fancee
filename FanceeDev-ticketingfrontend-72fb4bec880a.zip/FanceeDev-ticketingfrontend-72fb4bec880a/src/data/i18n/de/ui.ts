import type { Translations } from '../types';

export default {
    changesSavedSuccessfully: 'Änderungen erfolgreich gespeichert.',
    accountTakeoverNotice: {
        info: 'Derzeit als {0} angemeldet, wirkt sich alles, was Sie tun, auf dieses Konto aus.',
        switchBack: 'Wechseln Sie zurück zu {0}.'
    },
    confirmDeleteOverlay: {
        title: '{0} löschen?',
        titleAll: 'Alles löschen?',
        titleGeneric: 'Löschen bestätigen',
        message: 'Sind Sie wirklich sicher, dass Sie „{0}“ löschen möchten?',
        messageGeneric: 'Sind Sie wirklich sicher, dass Sie den Eintrag löschen möchten?'
    },
    countrySelectOverlay: {
        title: 'Welche Länder möchten Sie verwalten?',
        selection: '{0} von {1}',
        checkAll: 'Verwalten Sie alle Länder'
    },
    focalPoint: {
        editor: {
            title: 'Schwerpunkteditor',
            subTitle: 'Ziehen Sie den Kreis für jedes Ihrer Bilder auf den gewünschten Fokuspunkt.'
        },
        singular: 'Mittelpunkt',
        plural: 'Schwerpunkte'
    },
    notAllowed: {
        title: 'Nicht erlaubt',
        message: 'Ihr Konto verfügt nicht über die Berechtigungen, die angeforderte Aktion auszuführen.'
    },
    notFound: {
        record: 'Der angeforderte Datensatz konnte nicht gefunden werden.',
        page: {
            title: 'Seite nicht gefunden',
            content: 'Die angeforderte URL wurde auf diesem Server nicht gefunden.',
            goHome: 'Zurück nach Hause'
        }
    },
    shareOverlay: {
        copied: 'Erfolgreich in die Zwischenablage kopiert!',
        copyFrameCode: 'Iframe-Code kopieren',
        copyUrl: 'URL kopieren',
        newTab: 'Neue Registerkarte'
    },
    somethingWentWrong: {
        title: 'Hoppla... ;(',
        message: 'Am Ende hatten wir einen Schluckauf.',
        downloadFailed: 'Beim Herunterladen der Datei ist ein Problem aufgetreten.'
    },
    unsavedChanges: {
        title: 'Warnung!',
        message: 'Es gibt nicht gespeicherte Änderungen. '
    },
    navigation: {
        ticketing: {
            home: 'Überblick',
            finance: {
                group: 'Finanzen',
                invoices: 'Rechnungen',
                orders: 'Aufträge',
                reports: 'Berichte',
                wallet: 'Geldbörse'
            },
            marketing: {
                group: 'Marketing',
                agendas: 'Tagesordnungen',
                campaignTracking: 'Kampagnenverfolgung',
                preRegisters: 'Voranmeldungen'
            }
        }
    },
    pageTitle: {
        faq: 'FAQ',
        home: 'Überblick',
        profile: 'Profil',
        settings: 'Einstellungen',
        whatsNew: 'Was ist neu',
        secureCodes: 'Secure codes'
    },
    profileMenu: {
        appearance: 'Aussehen',
        faq: 'FAQ',
        language: 'Sprache',
        managing: 'Verwalten: {0}',
        profile: 'Profil',
        settings: 'Einstellungen',
        signOff: 'abmelden',
        switchOrganization: 'Organisation wechseln',
        whatsNew: 'Was ist neu',
        theme: {
            dark: 'Dunkel',
            light: 'Licht'
        }
    },
    countdown: {
        expiresIn: 'Läuft in {0} ab:{1}',
        expiresInWithHours: 'Läuft ab in {0}:{1}:{2}',
        expiresInDays: 'Abgelaufen |',
        expiresInHours: 'Abgelaufen | '
    },
    csvUpload: {
        message: 'Laden Sie eine CSV-Datei hier hoch oder ziehen Sie sie hierher...',
        button: 'Datei aussuchen',
        hasHeader: 'Hat einen Header',
        exampleData: 'Beispieldaten',
        fieldType: 'Feldtyp'
    },
    emptyView: {
        title: 'Nichts hier',
        message: 'Hier gibt es derzeit nichts zu sehen.'
    },
    googlePlacesAutocomplete: {
        invalid: 'Ungültige Adresse, bitte wählen Sie eine aus der Adress-Dropdown-Liste aus.',
        unavailable: 'Es ist derzeit nicht möglich, eine Adresse auszuwählen.'
    }
} satisfies Translations;
