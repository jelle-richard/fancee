import type { Translations } from '../types';

export default {
    title: 'CRM',
    navigation: {
        home: 'Overview',
        adminRegister: 'Admin register',
        balance: 'Balance',
        channels: 'Channels',
        eventBalance: 'Event balance',
        eventPlanning: 'Event planning',
        integrations: 'Integrations',
        invoicing: 'Invoicing',
        orders: 'Orders',
        organizations: 'Organizations',
        paymentMethods: 'Payment methods',
        payouts: 'Payouts'
    },
    home: {
        title: 'Overview',
        statisticsFor: 'Statistics for {0}',
        failed: {
            loadingGlobalPlatformStatistics: 'Error encountered while fetching global platform statistics. Please contact support if this issue persists.',
            loadingGrowthTargets: 'Error encountered while fetching your sales targets. Please contact support if this issue persists.',
            loadingTicketRevenueIndication: 'Error occurred while loading the ticket fee revenue indication. Please contact support if this issue persists.'
        },
        targetProgression: {
            newEvents: 'New events',
            newOrganizations: 'New organizations',
            newUniqueBuyers: 'New unique buyers',
            placedOrders: 'Placed orders',
            placedOrdersTip: '{placed} orders were placed, of which {fulfilled} were fulfilled.'
        },
        targets: {
            title: 'Platform targets',
            subTitle: 'Platform targets for measuring growth.',
            ticketFeeThisMonth: 'This month: {0} / {1}',
            ticketFeeLastMonth: 'Last month: {0} / {1}',
            revenueAccomplished: 'Accomplished revenue',
            revenueTarget: 'Revenue target',
            revenueToday: 'Revenue today',
            revenueYesterday: 'Revenue yesterday',
            topDailySoldProducts: 'Top daily sold products',
            tooltip: {
                ticketFeeRevenue: 'Ticket fee revenue {0} / {1}',
                seatedTicketFeeREvenue: 'Seated ticket fee revenue {0} / {1}',
                tickets: 'Tickets {0} / {1}',
                seatedTickets: 'Seated tickets {0} / {1}',
                organizations: 'Organizations {0} / {1}',
                events: 'Events {0} / {1}',
                placedOrders: 'Placed orders {0} / {1}',
                fulfilledOrders: 'Fulfilled orders {0} / {1}',
                uniqueBuyers: 'Unique buyers {0} / {1}'
            }
        }
    },
    adminRegister: {
        title: 'Admin register',
        choose: 'Choose admin role',
        terminatesOn: 'Terminates on',
        countryManager: {
            createFailed: 'An error occurred while trying to create the country manager. Please check the logs for more details.',
            createSuccess: 'The country manager has been successfully added.',
            hint: 'Note that setting the termination date on the country manager locks the account after that date. This field is not required.'
        },
        customerServiceEmployee: {
            createFailed: 'An error occurred while trying to create the customer service employee. Please check the logs for more details.',
            createSuccess: 'The customer service employee has been successfully added.',
            countryManager: 'Country manager',
            hint: 'Note that you may only select one country manager for the customer service employee at this time.',
            missingCountryManagers: 'There are currently no country managers availalbe.'
        }
    },
    balance: {
        title: 'Balance',
        loadingFailed: 'Loading balances failed. Please contact support if this issue persists.',
        received: 'Received',
        revenue: 'Revenue',
        additionalCosts: 'Additional costs',
        chargebacked: 'Chargebacked',
        chargebackFee: 'Chargeback fee',
        guestlistFee: 'Guestlist fee',
        month: 'Month',
        orders: 'Orders',
        paymentFee: 'Payment fee',
        productFee: 'Product fee',
        productIncome: 'Product income',
        refunded: 'Refunded',
        refundFee: 'Refund fee',
        seatedTicketFee: 'Seated ticket fee',
        sms: 'SMS',
        ticketFee: 'Ticket fee',
        tickets: '@:event.ticketPlural',
        tsp: 'TSP'
    },
    eventBalance: {
        title: 'Event balance',
        loadingFailed: 'An error occurred while loading events. Please try again later.',
        table: {
            event: '@:event.singular',
            organization: 'Organization',
            status: '@:event.status.title',
            scannedTickets: 'Scanned tickets',
            fees: 'Fees',
            received: 'Received'
        },
        tip: {
            guestlistFee: 'Guestlist fee',
            paymentFee: 'Payment fee',
            seatedTicketFee: 'Seated ticket fee',
            ticketFee: 'Ticket fee',
            tsp: 'TSP'
        }
    },
    eventPlanning: {
        title: 'Event planning'
    },
    integration: {
        title: 'Integrations',
        configure: 'Configure',
        connect: 'Connect',
        exact: {
            title: 'Exact',
            description: 'Login on Exact by pressing the button below, you\'ll be redirected back after the login.',
            completed: 'Exact integration completed.',
            loadingFailed: 'Error retrieving Exact login url.',
            loadingStatusFailed: 'Error retrieving if Exact is enabled.',
            configure: {
                configureItems: 'Configure items',
                selectJournal: 'Select journal',
                disconnected: 'Exact is not connected. Please connect it before configuring.',
                loadingConfigurationFailed: 'Unable to fetch the configuration. Please try again later.',
                loadingItemsFailed: 'Unable to fetch items. Please try again later.',
                loadingJournalsFailed: 'Unable to fetch journals. Please try again later.',
                loadingSpecificationNamesFailed: 'Unable to fetch invoice specification names. Please try again later.'
            },
            mapping: {
                platform: 'Platform item',
                exact: 'Exact item code',
                notMapped: 'Not mapped',
                country: {
                    add: 'Add country mapping',
                    remove: 'Remove country mapping'
                }
            }
        }
    },
    invoicing: {
        title: 'Invoicing',
        search: 'Search invoices...',
        downloadFailed: 'An error occurred while downloading the invoices file. Please contact support for assistance.',
        loadingFailed: 'The system could not fetch any invoices. Please try again or contact support for assistance.',
        loadingEventsFailed: 'An error occurred while loading events. Please try again later.',
        loadingOrganizationsFailed: 'An error occurred while loading organizations. Please try again later.',
        filter: {
            event: '@:event.singular',
            eventSearch: '@:event.list.searchPlaceholder',
            organization: 'Organization',
            organizationSearch: 'Search organizations...'
        },
        table: {
            number: 'Number',
            organization: 'Organization',
            createdOn: 'Created on'
        }
    },
    order: {
        title: 'Orders'
    },
    organization: {
        singular: 'Organization',
        plural: 'Organizations',
        title: '@:crm.organization.plural',
        search: 'Search organizations...',
        downloadFailed: 'An error occurred while downloading the organizations file. Please contact support for assistance.',
        loadingFailed: 'An error occurred while loading organizations. Please contact support for assistance.',
        filter: {
            date: '@:global.date',
            contractSigned: 'Contract signed',
            isBlocked: 'Blocked',
            isImportant: 'Important'
        },
        table: {
            name: '@:form.field.name',
            email: '@:form.field.email',
            annualSales: 'Annual sales',
            important: 'Important',
            verified: 'Verified',
            blocked: 'Blocked',
            profileComplete: 'Profile complete',
            lastLogin: 'Last login',
            phoneNumber: '@:form.field.phoneNumber'
        },
        single: {
            navigation: {
                account: 'Account',
                monitoring: 'Monitoring',
                permissions: 'Permissions',
                planning: 'Event planning',
                wallet: 'Wallet'
            },
            contact: {
                title: 'Contacts'
            },
            contract: {
                title: 'Contract',
                currentPackage: 'Current package',
                addAddendum: 'Addendum',
                updateContract: 'Update contract',
                expiresOn: 'Expires on {0}',
                guestlistFee: 'Guestlist fee of {0}',
                productFee: 'Product fee of {0} + {1}%',
                seatedTicketFee: 'Seated ticket fee of {0} + {1}%',
                ticketFee: 'Ticket fee of {0} + {1}%',
                downloadFailed: '@:onboarding.agreement.downloadFailed',
                updateFailed: 'An unknown error occurred while trying to update the package type of an organization. Please contact support for assistance.'
            },
            info: {
                approximateAnnualSales: 'Approximate annual sales',
                contractSigned: 'Contract signed',
                createdOn: 'Created on',
                important: 'Important',
                lastLogin: 'Last login',
                profileComplete: 'Profile complete',
                verified: 'Verified',
                block: 'Block user',
                unblock: 'Unblock user',
                blockFailed: 'An error occurred while blocking the user.',
                blockSuccess: 'Successfully blocked the user.',
                unblockFailed: 'An error occurred while unblocking the user.',
                unblockSuccess: 'Successfully unblocked the user.',
                importantChangeFailed: 'An error occurred while changing the important status of the user.',
                accountTakeover: {
                    button: 'Enter account',
                    info: 'Please re-enter your password below to login as this organization.'
                },
                accountStatus: 'Account status',
                accountStatusUnfinished: 'This organization has registered but has yet to complete his profile or sign his contract'
            },
            note: {
                title: 'Notes',
                attachFiles: 'Attach files...',
                createSuccess: 'The note has been created successfully.',
                deleteSuccess: 'The note has been deleted successfully.'
            },
            permissions: {
                loadingClaimsFailed: 'An error occurred while retrieving the platform claims. Please contact support for assistance.',
                loadingUserClaimsFailed: 'An error occurred while retrieving the users\' claims. Please contact support for assistance.',
                savingUserClaimsFailed: 'An error occurred while saving the user claims. Please contact support for assistance.'
            },
            planning: {
                search: 'Search events...'
            },
            wallet: {
                search: 'Search transactions...'
            },
            invoice: {
                regenerateTitle: 'Generate invoice',
                regenerateExplanation: 'Manually generate an invoice for the organization (dev feature only)'
            }
        },
        addAddendumOverlay: {
            title: 'Create addendum',
            info: 'The addendum you\'re about to create will be appended to the current contract of the organization.',
            notation: 'Please note that all fees are noted in cents. For example, a ticket fee of 1.50 would be 150 cents.',
            createSuccess: 'The addendum has been successfully added to the organization\'s contract.',
            guestlistFee: 'Guestlist fee',
            productFee: {
                percentual: 'Percentual product fee',
                static: 'Product fee'
            },
            seatedTicketFee: {
                percentual: 'Percentual seated ticket fee',
                static: 'Seated ticket fee'
            },
            ticketFee: {
                percentual: 'Percentual ticket fee',
                static: 'Ticket fee'
            }
        },
        alterContractOverlay: {
            title: 'Update contract'
        }
    },
    paymentMethod: {
        title: 'Payment methods',
        search: 'Search payment methods...',
        downloadFailed: 'An error occurred while downloading the payment methods file. Please contact support for assistance.',
        loadingFailed: 'Payment methods could not be loaded. Please contact support for assistance.',
        table: {
            id: 'Id',
            name: 'Name',
            provider: 'Provider',
            cost: 'Cost',
            limitedTo: 'Limited to'
        }
    },
    payout: {
        title: 'Payouts',
        search: 'Search payouts...',
        export: 'Export',
        resolve: 'Resolve current export',
        resolved: 'The payout export has been marked as resolved, and the underlying payout requests have been updated accordingly.',
        exportFailed: 'There are currently no pending payout requests, so no export file can be generated at this time.',
        exportSuccess: 'You\'ve initiated a payout export procedure. The file will download automatically. Please mark the export as resolved once it\'s finished.',
        outstandingNotice: 'There is currently one pending payout to process. | There are currently {n} pending payouts to process.',
        status: {
            created: 'Created',
            processed: 'Processed'
        },
        table: {
            id: 'Id',
            createdOn: 'Created on',
            status: 'Status',
            markProcessed: 'Mark processed'
        }
    }
} satisfies Translations;
