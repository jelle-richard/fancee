import type { Translations } from '../types';

export default {
    emptyView: {
        title: 'Nothing here',
        message: 'It appears that no events were found for your account, and as a result, no statistics are available.'
    },
    monitor: {
        title: 'Monitor your events',
        subTitle: 'Please choose an event to gain insights into your market position.',
        select: 'Select event...'
    },
    statistics: {
        loadingFailed: 'No statistics could be retrieved. Please contact support if this issue persists.',
        notEnoughData: 'It appears that the event hasn\'t generated meaningful statistics yet. Please revisit once products have been issued.',
        averageAge: {
            title: 'Average age',
            tip: {
                female: 'Average female customer age of {0} years.',
                male: 'Average male customer age of {0} years.',
                neutral: 'Average neutral customer age of {0} years.',
                unknown: 'Average unknown customer age of {0} years.'
            }
        },
        fulfilledOrders: {
            title: 'Fulfilled orders',
            tip: '{0} orders fulfilled.'
        },
        pendingRefunds: {
            title: 'Pending refunds',
            tip: '{0} total pending refunds.'
        },
        productsSold: {
            title: 'Products sold',
            tip: '{0} total products sold.'
        },
        ticketsScanned: {
            title: 'Tickets scanned',
            tip: '{0} total tickets scanned.'
        },
        uniqueCustomers: {
            title: 'Unique customers',
            tip: {
                female: '{0} unique female customers.',
                male: '{0} unique male customers.',
                neutral: '{0} unique neutral customers.',
                unknown: '{0} unique unknown customer.'
            }
        },
        finance: {
            cashSalesRevenue: 'Cash sales revenue',
            onlineSalesRevenue: 'Online sales revenue',
            platformExpenses: 'Platform expenses',
            profit: 'Profit'
        },
        bestSellingProducts: {
            title: 'Top products',
            subTitle: 'Best selling products of the last {0} days.'
        },
        dailyOrders: {
            title: 'Order revenue',
            subTitle: 'Daily completed orders overview.',
            ordersOnDay: 'Orders on day',
            cashRevenue: 'Cash revenue',
            onlineRevenue: 'Online revenue',
            orders: 'Orders',
            productsSold: 'Products sold',
            revenueFlow: 'Revenue flow'
        },
        productRatio: {
            title: 'Product ratio',
            subTitle: 'Product flow based on the amount.'
        },
        productStatistics: {
            guest: 'Guest',
            guestlistTip: 'Please keep in mind that guestlist tickets may not always be deducted from stock.',
            name: '@:form.field.name',
            pending: 'Pending',
            pendingTip: '{0} reservations are pending, with {1} currently in the process of payment.',
            price: '@:form.field.price',
            remaining: 'Remaining',
            sold: '@:global.sold',
            stock: '@:form.field.stock'
        }
    },
    wallet: {
        title: 'Wallet balance',
        manage: 'Manage'
    }
} satisfies Translations;
