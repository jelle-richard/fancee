import type { Translations } from '../types';

export default {
    title: 'Marketing',
    agenda: {
        plural: 'Agendas',
        singular: 'Agenda',
        title: '@:marketing.agenda.plural',
        table: {
            all: 'All active @.lower:event.plural'
        },
        deleteFailed: 'Error encountered while deleting agenda. Please contact support if this issue persists.',
        deleteSuccessful: 'The agenda was successfully deleted.',
        loadingFailed: 'Error encountered while fetching agendas. Please contact support if this issue persists.',
        loadingEventsFailed: 'An error occurred while loading your events. Please try again later.',
        loadingSingleFailed: 'The agenda could not be found. Redirecting to overview.',
        savingFailed: 'There was an error while saving the agenda. Please contact support if this issue persists.',
        savingSuccessful: 'The agenda was saved successfully.',
        configure: {
            title: {
                create: 'Create @.lower:marketing.agenda.singular',
                edit: 'Edit @.lower:marketing.agenda.singular'
            },
            allEvents: 'Use all @.lower:event.plural',
            showHeaders: 'Show event headers'
        }
    },
    campaign: {
        plural: 'Campaigns',
        singular: 'Campaign',
        title: '@:marketing.campaign.plural',
        search: `Search @.lower:{'marketing.campaign.plural'}...`,
        deleteConfirm: `Are you sure you want to delete the @.lower:{'marketing.campaign.singular'} {0}?`,
        deleteFailed: `Error encountered while deleting the @.lower:{'marketing.campaign.singular'}. Please contact support for assistance.`,
        deleteSuccessful: `Your @.lower:{'marketing.campaign.singular'} has been deleted successfully.`,
        exportFailed: `An error occurred while exporting your @.lower:{'marketing.campaign.plural'}. Please contact support if this issue persists.`,
        loadingFailed: `An error occurred while retrieving your @.lower:{'marketing.campaign.plural'}. Please contact support if this issue persists.`,
        table: {
            name: '@:marketing.campaign.singular',
            event: '@:event.singular',
            clicks: 'Clicks',
            revenue: 'Revenue',
            productsSold: 'Products sold',
            averageAge: 'Average age',
            genderSplit: 'Gender split',
            salesSplitTip: '{productAmount} tickets have been sold across {orderAmount} orders from {reservationAmount} reservations.'
        },
        configure: {
            title: 'Configure @.lower:marketing.campaign.singular',
            loadingEventsFailed: 'An error occurred while loading your events. Please try again later.',
            savingFailed: `An error occurred while saving the @.lower:{'marketing.campaign.singular'}. Please contact support if the issue persists.`,
            savingSuccessful: `Your @.lower:{'marketing.campaign.singular'} has been saved. You can find the tracking URL via the share button in the overview.`,
            info: `A @.lower:{'marketing.campaign.singular'} tracking URL can be assigned to multiple shops as long as they're part of the same event.`,
            eventsHint: `Existing @.lower:{'marketing.campaign.plural'} cannot have their event altered due to the gathering of statistics; however, you may add or remove shops from the equation.`,
            shopDisabledHint: 'Please select an event first.'
        }
    },
    preRegister: {
        title: '@:marketing.preRegister.plural',
        plural: 'Pre-registers',
        singular: 'Pre-register',
        search: `Search @.lower:{'marketing.preRegister.plural'}...`,
        table: {
            name: '@:form.field.name',
            registered: 'Registrations',
            downloadCsv: 'Download CSV',
            exportSecureShop: 'Export secure shop',
            expiresOn: 'Expires on'
        },
        deleteConfirm: `Deleting this @.lower:{'marketing.preRegister.singular'} will also remove the associated register entries.`,
        deleteFailed: `The @.lower:{'marketing.preRegister.singular'} could not be deleted. Please contact support for further assistance.`,
        deleteSuccessful: `The @.lower:{'marketing.preRegister.singular'} {name} has been successfully deleted.`,
        downloadFailed: `An error occurred while downloading the @.lower:{'marketing.preRegister.singular'} export. Please contact support for further assistance.`,
        exportFailed: `An error occurred while retrieving the sign-ups for this @.lower:{'marketing.preRegister.singular'}. Please try again later.`,
        exportFailedNoEntries: 'It appears that there are no sign-ups available for export at this time.',
        loadingFailed: `There was an error while attempting to retrieve your @.lower:{'marketing.preRegister.singular'}s. Please contact support for assistance.`,
        configure: {
            createdSuccessfully: `The @.lower:{'marketing.preRegister.singular'} for {name} has been successfully created.`,
            saveFailed: `An error occurred while saving your @.lower:{'marketing.preRegister.singular'}. Please contact support for assistance.`,
            create: `Create @.lower:{'marketing.preRegister.singular'}`,
            edit: `Edit @.lower:{'marketing.preRegister.singular'}`,
            header: {
                title: 'Header',
                description: 'Image that is used for the header of the preregister.'
            }
        },
        signUp: {
            complete: {
                title: 'Signup complete',
                message: 'Sign-up completed. Your registration for {name} has been successfully recorded. You may now close this window. Please note that entering this form multiple times is unnecessary, as only unique entries will be processed.'
            },
            expired: {
                title: 'Expired',
                message: `The @.lower:{'marketing.preRegister.singular'} period has expired. It is no longer possible to register.`
            },
            failed: 'An error occurred while loading your preregister. Please try again later.'
        }
    }
} satisfies Translations;
