import type { Translations } from '../types';

export default {
    title: 'Data',
    titles: {
        campaign: 'Campaign',
        channels: 'Channels',
        home: 'Home',
        monitor: 'Monitor',
        overview: 'Overview',
        social: 'Social',
        ticketing: 'Ticketing'
    },
    navigation: {
        campaign: 'Campaign',
        channels: 'Channels',
        home: 'Home',
        settings: 'Settings',
        social: 'Social',
        ticketing: '@:analytics.titles.ticketing'
    },
    comparisonView: 'Compare',
    disabled: 'Disabled',
    enabled: 'Enabled',
    paused: 'Paused',
    fullOverview: 'Full overview',
    noData: 'No data could be found',
    openInBrowser: 'Open in browser',
    selectField: 'Select field...',
    splitOn: 'Split on...',
    noChannelsFound: {
        title: 'No channels found',
        message: 'No channels have been found. Please use the \'Channels\' page to add one.'
    },
    channel: {
        plural: 'Channels',
        singular: 'Channel',
        saving: 'Saving channel...',
        updating: 'Updating subscriptions...',
        info: {
            createdOn: 'Created on',
            lastLogin: 'Last login',
            organization: 'Organization',
            owner: 'Owner',
            request: 'Request'
        },
        new: {
            title: 'New channel',
            user: 'User',
            supermetrics: {
                account: 'SuperMetrics - ds_accounts',
                user: 'SuperMetrics - ds_user'
            }
        },
        status: {
            active: 'Active',
            error: 'Error',
            expired: 'Expired',
            inactive: 'Inactive',
            partiallyActive: 'Partially active',
            paused: 'Paused',
            setup: 'Setup'
        },
        table: {
            name: '@:form.field.name',
            type: 'Type',
            status: 'Status',
            organization: 'Organization',
            owner: 'Owner',
            email: '@:form.field.email',
            createdOn: 'Created on'
        },
        type: {
            facebook: 'Facebook',
            facebookads: 'Facebook Ads',
            facebookpublicdata: 'Facebook Public Data',
            googleads: 'Google Ads',
            googleanalytics: 'Google Analytics',
            googleanalytics4: 'Google Analytics V4',
            instagram: 'Instagram',
            instagrampublicdata: 'Instagram Public Data',
            linkedin: 'LinkedIn',
            tiktok: 'TikTok',
            youtube: 'YouTube',
            youtubev2: 'YouTube V2'
        }
    },
    subscription: {
        plural: 'Subscriptions',
        singular: 'Subscription',
        status: {
            active: 'Active',
            inactive: 'Inactive'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            aw_ad: 'Google Ads - Ad',
            aw_age: 'Google Ads - Age',
            aw_campaign: 'Google Ads - Campaign',
            aw_conversion: 'Google Ads - Conversion',
            aw_gender: 'Google Ads - Gender',
            aw_geo: 'Google Ads - Geo',
            aw_keyword: 'Google Ads - Keyword',
            aw_placement: 'Google Ads - Placement',
            aw_search_query: 'Google Ads - Seaarch Query',
            aw_shopping: 'Google Ads - Shopping',
            fa_ads: 'Facebook Ads - Ad',
            fa_age_and_gender: 'Facebook Ads - Age and Gender',
            fa_campaign: 'Facebook Ads - Campaign',
            fa_conversion: 'Facebook Ads - Conversion',
            fa_geo: 'Facebook Ads - Geo',
            fa_video: 'Facebook Ads - Video',
            fb: 'Facebook - Page',
            fb_age_and_gender: 'Facebook - Age and Gender',
            fb_geo_likes: 'Facebook - Geographic',
            fb_posts: 'Facebook - Posts',
            fbpd_page: 'Facebook Public Data - Page',
            fbpd_posts: 'Facebook Public Data - Posts',
            fbpd_url_shares: 'Facebook Public Data - Url Shares',
            ga_content: 'Google Analytics - Content',
            ga_ecommerce: 'Google Analytics - Ecommerce',
            ga_events: 'Google Analytics - Events',
            ga_paid_traffic: 'Google Analytics - Paid traffic',
            ga_search: 'Google Analytics - Search',
            ga_social: 'Google Analytics - Social',
            ga_technology: 'Google Analytics - Technology',
            ga_traffic: 'Google Analytics - Traffic',
            ga_user: 'Google Analytics - User',
            gawa_device: 'Google Analytics 4 - Devices',
            gawa_ecom_items: 'Google Analytics 4 - E-Commerce items',
            gawa_engagement: 'Google Analytics 4 - Engagement',
            gawa_publishing: 'Google Analytics 4 - Publishing',
            gawa_traffic_acquisition: 'Google Analytics 4 - Traffic Acquisition',
            gawa_user_acquisition: 'Google Analytics 4 - User Acquisition',
            igi: 'Instagram - Followers',
            igi_age_and_gender: 'Instagram - Age and Gender',
            igi_country: 'Instagram - Country',
            igi_media: 'Instagram - Media',
            igi_profile_data: 'Instagram - Profile data',
            igpd2_hashtags: 'Instagram Public Data - Hashtags',
            igpd2_posts: 'Instagram Public Data - Posts',
            igpd2_profiles: 'Instagram Public Data - Profiles',
            lip_country: 'LinkedIn - Country',
            lip_page: 'LinkedIn - Page',
            lip_post: 'LinkedIn - Posts',
            tikba_country: 'TikTok - Country',
            tikba_gender: 'TikTok - Gender',
            tikba_profile: 'TikTok - Profile',
            tikba_video: 'TikTok - Video',
            yt2_ad_performance: 'Youtube v2 - Ad Performance',
            yt2_channel: 'Youtube v2 - Channel',
            yt2_demographic: 'Youtube v2 - Demographic',
            yt2_device: 'Youtube v2 - Device',
            yt2_geo: 'Youtube v2 - Geo',
            yt2_traffic_source: 'Youtube v2 - Traffic Source',
            yt2_video: 'Youtube v2 - Video',
            yt_video: 'YouTube - Video'
        }
    },
    header: {
        allChannels: 'All channels',
        comparisonView: 'Comparison view',
        datePresets: {
            lastMonth: 'Last month',
            lastSevenDays: 'Last 7 days',
            thisMonth: 'This month',
            thisYear: 'This year'
        }
    },
    ads: {
        title: 'Ads',
        budget: 'Budget',
        campaign: 'Campaign',
        clicks: 'Clicks',
        conversion: 'Conversion',
        cost: 'Cost',
        cpc: 'CPC',
        ctr: 'CTR',
        date: '@:global.date',
        engagement: 'Engagement',
        impressions: 'Impressions',
        status: 'Status',
        totalCampaigns: 'Total campaigns',
        totalSpent: 'Total spent'
    },
    bestPostTime: {
        title: 'Best time to post on',
        comments: 'Comments',
        likes: 'Likes',
        reach: 'Reach',
        basedOn: {
            comments: 'Based on avarage amount of comments',
            likes: 'Based on avarage likes',
            reach: 'Based on average reach'
        },
        engagement: {
            highest: 'Highest engagement',
            lowest: 'Lowest engagement'
        }
    },
    campaignInfo: {
        title: 'General information',
        ageClicks: 'Age clicks',
        budget: 'Budget',
        clicks: 'Clicks',
        conversion: 'Conversion',
        cpc: 'CPC',
        ctr: 'CTR',
        genderClicks: 'Gender clicks',
        impressions: 'Impressions',
        remaining: 'Remaining',
        spent: 'Spent'
    },
    captions: {
        title: 'Captions'
    },
    emotions: {
        title: 'Emotions',
        subTitle: 'For facebook only',
        like: 'Like',
        likes: 'Likes',
        love: 'Love',
        thankful: 'Thankful',
        wow: 'Wow',
        haha: 'Haha',
        pride: 'Pride',
        anger: 'Anger',
        sorry: 'Sorry'
    },
    engagement: {
        title: 'Engagement',
        clicks: 'Clicks',
        conversion: 'Conversion',
        cpc: 'CPC',
        ctr: 'CTR',
        comments: 'Comments',
        impressions: 'Impressions',
        likes: 'Likes',
        shares: 'Shares'
    },
    field: {
        activeFollowers: 'Active followers',
        averageAge: 'Average age',
        clicksOnPage: 'Clicks',
        comments: 'Comments',
        description: 'Description',
        increasedFollowers: 'Increased followers',
        likes: 'Likes',
        percentIncreaseFollowers: 'Followers increase',
        percentMen: 'Men',
        percentWomen: 'Women',
        reach: 'Reach',
        shares: 'Shares',
        totalFollowers: 'Total followers'
    },
    followers: {
        title: 'Followers',
        lost: 'Lost',
        new: 'New',
        total: 'Total'
    },
    hashtags: {
        title: 'Hashtags'
    },
    locations: {
        title: 'Locations'
    },
    mentions: {
        title: 'Mentions'
    },
    monitor: {
        title: 'Monitor your channels',
        placeholder: 'Select a channel...',
        averageDay: 'Average by day',
        averageHour: 'Average by hour',
        bestDayToPost: 'Best day to post on',
        bestHourToPost: 'Best hour to post on',
        captions: 'Captions',
        emojis: 'Emojis',
        hashtags: '#Hashtags',
        mentions: `{'@'}Mentions`,
        topPosts: 'Top 5 posts',
        age: {
            title: 'Age',
            subTitle: 'Likes based on age'
        },
        emotion: {
            title: 'Emotion',
            subTitle: 'Likes based on emotion'
        },
        gender: {
            title: 'Gender',
            subTitle: 'Likes based on gender'
        }
    },
    post: {
        title: 'Posts',
        comments: 'Comments',
        date: '@:global.date',
        likes: 'Likes',
        shares: 'Shares',
        clicks: 'Clicks',
        message: 'Message',
        reach: 'Reach',
        reactions: 'Reactions',
        time: '@:global.time',
        views: 'Views',
        table: {
            channel: '@:analytics.channel.singular',
            date: '@:global.date',
            type: 'Type',
            engagement: 'Engagement',
            conversion: 'Conversion',
            paidYesNo: 'Paid Y/N'
        },
        // note(Bas): these are in snake_case, because these are keys.
        type: {
            video: 'Video',
            video_inline: 'Video',
            video_direct_response: 'Video Response',
            reels_video: 'Reels Video',
            story_video: 'Story Video',
            feed_carousel_album: 'Feed Album',
            photo: 'Photo',
            image: 'Image',
            album: 'Album',
            carousel_album: 'Album',
            share: 'Share',
            cover_photo: 'Cover Photo',
            image_share: 'Image Share',
            native_templates: 'Advertisement',
            event: 'Event'
        }
    },
    reach: {
        title: 'Reach',
        gained: 'Reach gained',
        gainedPercentage: '{0} gained',
        lost: 'Reach lost',
        lostPercentage: '{0} lost'
    },
    socialImpact: {
        title: 'Social impact',
        engagement: 'Engagement',
        followers: 'Followers',
        growth: 'Growth',
        posts: 'Posts',
        reach: 'Reach',
        less: 'less than last period',
        more: 'more than last period'
    },
    spent: {
        title: 'Total spent',
        budget: 'Budget',
        cost: 'Cost',
        total: 'Total'
    },
    tags: {
        title: 'Title',
        captions: 'Captions',
        hashtags: 'Hashtags',
        mentions: 'Mentions'
    },
    topLocations: {
        title: 'Top locations',
        country: 'Country',
        visitors: 'Visitors'
    },
    totalCampaigns: {
        title: 'Total campaigns',
        enabled: 'Enabled',
        disabled: 'Disabled',
        paused: '@:analytics.paused'
    },
    crm: {
        channel: {
            title: '@:analytics.channel.plural',
            delete: {
                title: 'Delete channel',
                message: 'This will delete the channel, subscriptions and all data belonging to those. Are you sure?',
                done: 'The channel has been deleted.'
            },
            refresh: {
                title: 'Refresh channel',
                message: 'Refreshing a channel will try to fetch up to 6 months of data for every active subscription. This action can take up to 10 minutes.',
                working: 'Refresh for channel {0} will start soon. In can take up to 5 minutes until refreshing is finished.'
            },
            fields: {
                title: 'All fields',
                table: {
                    name: 'Name',
                    type: 'Type',
                    field: 'Field',
                    group: 'Group',
                    description: 'Description'
                }
            }
        },
        subscription: {
            refresh: 'Refresh for subscription {0} will start soon. In can take up to 5 minutes until refreshing is finished.',
            info: {
                title: 'Info',
                createdOn: 'Created on',
                cron: 'Cron schedule',
                fields: 'Fields',
                showFields: 'Show fields',
                status: 'Status',
                type: 'Type',
                updatedOn: 'Updated on'
            },
            chart: {
                title: 'Data'
            },
            fields: {
                name: 'Name',
                type: 'Type',
                field: 'Field'
            },
            history: {
                title: 'History'
            }
        }
    },
    ticketing: {
        notice: {
            message: 'Data will be synced every day at 11:00 AM UTC and 11:00 PM UTC. This can take up to an hour.'
        },
        averageOrderPrice: {
            title: 'Average order price',
            average: 'Average price for all orders'
        },
        gendersByAge: {
            title: 'Genders by age group'
        },
        averageOrderReservation: {
            title: 'Average time for reservations and orders',
            orderTime: 'Average order time',
            reservationTime: 'Average reservation time'
        }
    }
} satisfies Translations;
