import type { Translations } from '../types';

export default {
    lastOrder: {
        title: 'Your last order',
        placedOn: 'Placed on {0}'
    },
    dashboard: {
        loadingFailed: 'We couldn\'t load your orders. Please try again later.',
        emptyView: {
            title: 'Nothing here',
            message: 'No order could be found for your account. Therefore, we are unable to display any tickets here.'
        }
    },
    ticket: {
        eventName: 'Event',
        startDate: 'Date',
        loadingFailed: 'Could not load your tickets.',
        emptyView: {
            title: 'Nothing here',
            message: 'If you are certain that you are entitled to tickets for an upcoming event please check your orders.',
            action: 'View orders'
        },
        sealed: {
            message: 'These tickets are sealed and will become available {0} hours before the event starts',
            saleButton: 'Sell on TicketSwap'
        }
    }
} satisfies Translations;
