import type { Translations } from '../types';

export default {
    agreement: {
        title: 'Finalize your agreement',
        intro: `In this concluding step, we'll formalize our commitment to work together through a clear and concise contract. Your signature here will solidify our partnership and ensure both parties are aligned on the terms and conditions. We're excited to have you on board, and this step is the final touch to make it official.`,
        disclaimer: "By signing here you acknowledge you've read the contract in its entirety and agree with the content.",
        negotiate: 'If your organization has previously contacted us and negotiated custom fees or terms, please wait in this step while we update the contract to reflect those agreements.',
        sign: 'Sign contract',
        signOverlayTitle: 'Sign',
        alreadySigned: `You've already completed the contract signing process. Should you desire any modifications or have inquiries, please reach out to our support team.`,
        contactSales: 'Contact sales',
        downloadFailed: 'Could not download your contract. Please try again later or contact our support.'
    },
    company: {
        title: 'Tell us about your organization',
        intro: `Now, let's dive into the heart of your organization. Please provide us with key details about your company. We'll need the organization's name, address and more.`,
        supportContact: 'Support contact',
        optionalSupportContact: 'Optional support contact',
        supportContactExplanation: 'Customer support details are used by the system to communicate to your clients how to contact you. If left empty, the defaults details will be used. You also have the option to adjust this later in your profile.',
    },
    financial: {
        title: 'Set up your financials',
        intro: `In this step, we'll arrange the financial aspects to ensure seamless transactions. Please provide the essential details about where we should send your payouts and any other financial preferences. Your financial security and convenience are our top priorities, and completing this step will help us serve you better.`,
        ibanInfo: `If you've got an IBAN, go ahead and use it. Otherwise, fill in your bank account number and the BIC for your bank.`,
        approximateAnnualSales: 'Approximate annual sales',
        approximateAnnualSalesPlaceholder: 'How many tickets do you expect to sell?',
    },
    personal: {
        title: `Let's get you up and running!`,
        intro: `We're excited to get to know you and your organization better. To kick off your onboarding journey, we kindly ask for a few details about the owner.`
    },
    welcome: {
        title: `Let's get Fancee!`,
        intro: `Now that we've sorted out your contract, go ahead and start selling tickets whenever you feel like it! If you need any assistance, don't hesitate to reach out to us.`,
        start: 'Start selling'
    }
} satisfies Translations;
