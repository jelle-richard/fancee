import type { Translations } from '../types';

export default {
    changelog: {
        noChanges: 'No changes found',
        noChangesDescription: 'No changes have been found in the system, please check again later for any updates of the system.'
    },
    faq: {
        title: 'Frequently asked questions',
        description: 'Any questions? Here you\'ll find the answers.',
        email: {
            title: 'Email',
            description: 'We will do our best to get in touch within {0} business day(s)!',
            button: 'Email us'
        },
        phone: {
            title: 'Phone',
            description: 'We are always happy to help.'
        },
        whatsapp: {
            title: 'WhatsApp',
            description: 'We will do our best to get in touch within {0} hours on business days!',
            button: 'Message us'
        },
        categories: [
            {
                icon: 'user',
                title: 'Account management',
                subTitle: 'Answers on how to setup account configurations',
                questions: [
                    ['Can I change my fees?', 'Your platform fees are based on the dashboard package as stated in the contract. In order to change your platform fees you\'ll have to contact support to change your package.'],
                    ['Can I up or downgrade my package?', 'Unless explicitly stated in your contract, you may do so at any time. Contact support with your desired dashboard package. We will draft a new contract for you.'],
                    ['How do I enable 2-FA?', 'Enabling 2-FA is a great way to further secure your account. You can do so by navigation to your profile and filing in the requested form under the \'Security\' tab.'],
                    ['How do I change my VAT code, bank account and/or Chamber of commerce details?', 'You may not change this information at your own discretion. Contact support and provide the required changes, once verified they\'ll update your account accordingly.'],
                    ['There are menu items which are locked, how do I access these?', 'Depending on the dashboard package your account is configured for, there are certain pages that may not be included. You can find the details of your dashboard package in your contract or alternatively in the \'My profile\' page. To change your dashboard package please see \'Can I up or downgrade my package?\'']
                ]
            },
            {
                icon: 'shopping-bag',
                title: 'Sales',
                subTitle: 'How to handle your sales',
                questions: [
                    ['Will support help me with sales?', 'The dashboard supports a wide assortment of explanation in the form of tutorials, online webinars and downloads, which are available 24/7. In case you require further help our sales department is happy to help you expand your sales opportunities.'],
                    ['How do I provide discounts to my customers?', 'Discounts are a great way to attract customers, sell remaining stock or to offer some compensation. You can add discounts via the \'Discounts\' page found under the \'Events\' menu. Here you are able to create discounts for specific events, shops and even products. Discounts can be configured with both a static or percentage price reduction and can set to expire.'],
                    ['I have products in a pending state, what does this mean?', 'When a customer is purchasing products through your shop our platform holds their selection of products in a reservation (default of 8 minutes), this allows the user to fill in the required forms to complete his/her purchase. Once a purchase is started the customer is granted another 15 minutes from the back/payment provider. Once the reservation is expired without a completed purchase the reserved stock will be released.'],
                    ['Can I increase or decrease product prices during sale?', 'Yes, you may change the prices of your product(s) at any time by adjusting them in the \'Products\' step of \'Configure event\'. Do note that these changes will take in effect immediately in all of the shops that use said product(s).'],
                    ['Can I increase or decrease product stock during sale?', 'Product stock can be changed at any time, although if remaining stock is updated to 0 the pending reservations may still be completed. This can result in a oversale of product quantities. You may change the stock of your product(s) at any time by adjusting them in the \'Products\' step of \'Configure event\'. Do note that these changes will take in effect immediately in all of the shops that use said product(s).'],
                    ['Can I pass the platform fees on to the customer?', 'You may freely add your own fee to the product price under the advanced options of editing a product in the \'Products\' step of \'Configure event\'.']
                ]
            },
            {
                icon: 'calendar',
                title: 'Event management',
                subTitle: 'How to setup your events and shops',
                questions: [
                    ['What do the event event types do for an event?', 'When creating an event you are confronted with the choice between a normal, seated and timeslotted event. A normal event allows the sales of tickets and products for a desired date. Timeslotted events offer the possibility to sell tickets and products over a range of dates where said tickets and products can be allocated to a timeslot in which they are valid. Seated events are similar to a normal event but tickets sold throughout a seated event must be allocated to a seat which the customer can decide.'],
                    ['What link do I use to share my online shop?', 'Once you\'ve created an event with at least one shop, the link of this shop will be visible in your event overview which can be found via the \'My events\' page.'],
                    ['How can I use my own brand guide in the online shops?', 'When creating shops for your event you may choose colors via the \'Apply branding colors\' in the \'Shops\' step of \'Configure event\'. Alternatively you can save your colors as a template and pick this template (or any of the pre defined templates) when creating a new shop.']
                ]
            },
            {
                icon: 'mobile-notch',
                title: 'Tickets & scanning',
                subTitle: 'How to verify event access',
                questions: [
                    ['How do I scan tickets?', 'By using the \'WeAreFancee Scan app\' which can be found in both the Android play store and Apple app store. You may login with your organization account or alternatively create organization teams via the \'organization teams\' page under the \'Scanning\' menu item.'],
                    ['How do I log-in in the scanner?', 'You may login with your organization account or alternatively create organization teams via the \'organization teams\' page under the \'Scanning\' menu item.'],
                    ['My customer states that the ticket have not been delivered, what do I do?', 'If the customer has not received his/her ticket you may opt to use the following steps: 1. You may guide the customer to the \'Lost ticket\' page found on https://www.WeAreFancee.com/lost-ticket \r 2. You may try to find the customer via the transactions overview in \'Transactions\' under the \'Finance\' menu item and resend the tickets email. \r 3. If the customer originally entered the wrong email address you may provide them with the incorrect email-address + transaction ID so they may collect the tickets via https://www.WeAreFancee.com/ticket-lost.'],
                    ['What do I do if a customer comes to the event without a ticket?', 'When a customer has forgot to bring his/her ticket but is able to supply proof of payment you may find the ticket in the app via the \'Ticket statistics\' window and search with the email and/or birthdate']
                ]
            },
            {
                icon: 'coin',
                title: 'Finance',
                subTitle: 'How to track your revenue',
                questions: [
                    ['Can I have interim payment?', 'Yes, by navigation to your \'Wallet\' found under the \'Finance\' menu item you may request a payout if your current balance is positive. For the cost of these payouts please refer to your organization contract.'],
                    ['When do I get a payout?', 'You may request a payout by navigation to your \'Wallet\' found under the \'Finance\' menu item if your balance is positive.'],
                    ['How do I refund a customer?', 'You may search for the customer or his/her transaction in the transactions overview found in \'Transactions\' under the \'Finance\' menu item. Here you may find a refund option under the \'Advanced options\' tab.'],
                    ['Where can I find my invoices?', 'In the overview of the \'Invoices\' page found under the \'Finance\' menu item.']
                ]
            },
            {
                icon: 'chart-simple',
                title: 'Statistics & marketing',
                subTitle: 'How to use your customer data',
                questions: [
                    ['How do I track my campaign results?', 'Via the \'Campaings\' page under the \'Marketing\' menu item.'],
                    ['Where can I find basic event statistics?', 'On the home screen you\'ll initially see account wide statistics. In the navbar there is an option to look at event specific statistics.'],
                    ['How do I find customers and transactions?', 'You may navigate to the Finance > Order pages where you can search on customers or order details, by clicking a row you will get more information.'],
                    ['How do I know which customers I\'m authorised to contact?', 'When you wish to contact one or more users you may navigate to the \'Transactions\' page under the \'Finance\' menu item and filter for users that opted in to either an email or SMS promotion.'],
                    ['How do I keep track of sales?', 'On the home page you can search and select your event to get an insight in daily sales, remaining stock and your best sellers']
                ]
            }
        ]
    },
    profile: {
        loadingFailed: 'Error retrieving your profile information, please try again later.',
        contact: {
            title: 'Contact',
            add: '@:platform.profile.contact.title',
            added: '{0} {1} has been added as a contact.',
            deleted: '{0} {1} has been deleted as a contact.',
            createFailed: 'An error occurred while creating the contact. Please try again later.',
            deleteFailed: 'An error occurred while attempting to remove the contact. Please contact support for assistance.',
            editFailed: 'An error occurred while saving the contact. Please try again later.',
            emptyView: [
                'At @:global.platform.name we understand that when your business is growing you have to delegate matters. For this reason you may add extra contact options.',
                'If no extra contacts are configured all of our correspondence will arrive at the registered email of this account.',
                'Contacts can be defined per role, so that our inquiries arrive at the correct departments.'
            ],
            role: {
                customerSupprt: 'Customer support',
                finance: 'Finance',
                marketing: 'Marketing',
                organization: 'Organization'
            }
        },
        organization: {
            title: '@:global.organization',
            cannotMakeChanges: 'Your contract has been created. Please contact support if there is a need to make changes to your profile.',
            downloadContract: 'Download contract',
            finance: 'Finance',
            holder: 'Holder',
            legalEntity: 'Legal entity',
            loadCurrenciesFailed: 'Error encountered while retrieving currencies. Please reach out to support for assistance.'
        },
        packages: {
            title: 'Packages',
            request: 'Request',
            requestFailed: 'Could not request a package change. Please try again later.',
            requestSuccess: 'Your request for a package change to {0} has been submitted to our support.',
            selfService: 'Self service',
            supportBusinessHours: 'Account support (business hours)',
            support247: 'Account support (24 / 7 )',
            ticketFee: '{0} Ticket fee',
            ticketFeeCustom: 'Ticket fee in consultation with sales.',
            unlimited: 'Unlimited',
            feature: {
                accountSupport: 'Account support',
                ambassadorPrograms: 'Ambassador programs',
                customerAnalytics: 'Customer analytics',
                customFeatures: 'Custom made features',
                discounts: 'Discounts',
                guestlist: 'Guestlist',
                marketingCampaigns: 'Marketing campaigns',
                salesGuides: 'Sales guides',
                salesScanApp: 'Sales & scan-app',
                seating: 'Seating',
                shopCustomization: 'Shop customization',
                websiteIntegrations: 'Website integrations'
            },
            light: {
                name: 'Light',
                description: 'Small organizations up to 2500 tickets annually.'
            },
            medium: {
                name: 'Medium',
                description: 'Bigger organizations for 2500+ tickets annually.'
            },
            custom: {
                name: 'Custom',
                description: 'For organizations with the need of custom logic.'
            }
        },
        security: {
            title: 'Security',
            passwordChanged: 'Your password has been changed. You will now be redirected to the login page.',
            passwordChangeFailed: 'An error occurred while attempting to change your password. Please try again later.'
        },
        sessions: {
            title: 'Sessions'
        },
        user: {
            title: 'User',
            avatar: 'Profile picture'
        }
    },
    receipt: {
        title: 'Download receipt',
        description: 'Your receipt will contain an overview of your purchases.',
        downloading: 'Your receipt PDF is on its way. Please wait a moment!',
        exceeded: 'We encountered a slight issue while downloading your receipt. Please try again later.',
        failed: 'We couldn\'t retrieve your receipt. Please check the link in your email or try again later.',
        success: 'Your receipt PDF has been downloaded! Please check your download folder to view your receipt.'
    }
} satisfies Translations;
