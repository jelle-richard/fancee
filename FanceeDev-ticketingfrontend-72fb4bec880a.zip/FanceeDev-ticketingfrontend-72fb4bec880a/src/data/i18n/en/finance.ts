import type { Translations } from '../types';

export default {
    title: 'Finance',
    takings: 'Takings',
    ticketFee: 'Ticket fee',
    paymentFee: 'Payment fee',
    discount: 'Discount',
    invoice: {
        plural: 'Invoices',
        singular: 'Invoice',
        title: '@:finance.invoice.plural',
        downloadFailed: 'An error occurred while downloading the invoices file. Please contact support for assistance.',
        downloadSingleFailed: 'An error occurred while downloading the invoice. Please contact support for assistance.',
        loadingFailed: 'The system could not fetch any invoices. Please try again or contact support for assistance.',
        loadingEventsFailed: 'An error occurred while loading your events. Please try again later.'
    },
    order: {
        title: 'Orders',
        downloadFailed: 'An error occurred while downloading orders. Please contact support for assistance.',
        loadingFailed: 'An error occurred while loading the order. Please contact support for assistance.',
        loadingSingleFailed: 'An error occurred while loading orders. Please contact support for assistance.',
        search: 'Search orders...',
        cost: 'Cost',
        filter: {
            promotionalEmail: 'Promotional Email',
            promotionalSms: 'Promotional SMS',
            orderSms: 'Receive order SMS'
        },
        table: {
            psp: 'PSP reference',
            event: '@:event.singular',
            date: '@:global.date',
            amount: '@:global.amount',
            paymentStatus: '@:finance.paymentStatus.title'
        },
        single: {
            title: 'Order history',
            advanced: {
                title: 'Advanced',
                refund: {
                    title: 'Refund',
                    info: 'You have the option to refund the customer. When doing so you may choose to take the refunded products back in the stock of your shop.',
                    start: 'Start refunding'
                },
                resend: {
                    title: 'Resend order confirmation',
                    info: 'You have the option to resend the tickets to the customer, this will be a direct copy of the email sent when the order was fulfilled.',
                    disabled: 'Resending the order to the customer is only possible when the payment has been fulfilled.',
                    submit: 'Resend',
                    success: 'The ticket PDF of this order has been resent to the original buyer.'
                }
            },
            client: {
                title: 'Client information',
                optins: {
                    title: 'Promotional opt-ins',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            order: {
                title: 'Order',
                breakdown: 'Breakdown',
                psp: 'PSP reference',
                cost: 'Cost',
                paymentFee: 'Payment fee',
                paymentMethod: 'Payment method',
                paymentStatus: 'Payment status',
                placed: 'Order placed',
                productFee: 'Product fee',
                seatedTicketFee: 'Seated ticket fee',
                ticketAndProductRevenue: 'Ticket & Product revenue',
                ticketFee: '@:finance.ticketFee',
                ticketServicePlusCost: 'Ticket service plus cost',
                totalOrderCost: 'Total order cost'
            },
            purchase: {
                title: 'Purchase',
                viewTickets: 'View tickets',
                productFee: '{0} product fee',
                seatedTicketFee: '{0} seated ticket fee',
                ticketFee: '{0} ticket fee',
                boughtTsp: 'Bought Ticket Service Plus',
                receiveOrderSms: 'Receive order sms',
                products: 'Products'
            }
        },
        refund: {
            title: 'Refund {0}',
            notice: 'Keep in mind that refunding an order is not reversible, the ticket buyer will be notified of this refund and we aim to transfer the funds within 3 working days.',
            returnToStock: 'Return to stock',
            invalidateTickets: 'Invalidate tickets',
            submit: 'Issue refund',
            totalRefundAmount: 'Total amount to be refunded:',
            failed: 'An error occurred while issuing the refund. Please contact support for assistance.',
            success: 'The refund was issued successfully and the buyer will be notified.'
        }
    },
    report: {
        title: 'Reports',
        loadingFailed: 'An error occurred while loading your revenue statistics. Please contact support if the error persists.',
        loadingEventsFailed: 'An error occurred while loading your events. Please try again later.',
        info: 'You can use this information to analyze your revenue trends. Either select an event to gain specific insights or leave it empty for an account-wide overview.',
        searchEvent: 'Search event...',
        organization: {
            statistics: {
                title: 'Revenue statistics',
                fulfilledOrders: 'Fulfilled orders',
                issuedProducts: 'Issued products',
                obtained: {
                    app: 'Obtained through @:global.platform.name app.',
                    generated: 'Generated by platform.',
                    guestlist: 'Sent out through guestlists.',
                    imported: 'Imported from external source.',
                    shop: 'Obtained through @:global.platform.name shop.',
                    ticketswap: 'Sold via ticketswap'
                }
            },
            revenue: {
                title: 'Organization revenue'
            },
            cost: {
                title: 'Organization cost',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Payment fee',
                ticketFeeCost: '@:finance.ticketFee',
                seatedTicketFeeCost: 'Seated ticket fee',
                guestlistCost: 'Guestlists'
            }
        },
        platform: {
            revenue: {
                title: 'Platform revenue',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Payment fee'
            },
            cost: {
                title: 'Platform cost',
                ticketFee: '@:finance.ticketFee',
                productFee: 'Product fee',
                seatedTicketFee: 'Seated ticket fee',
                guestlist: 'Guestlists',
                additional: 'Additional',
                paymentFeeCost: 'Payment fee'
            }
        },
        client: {
            cost: {
                title: 'Client cost',
                smsCost: 'SMS',
                tspCost: 'Ticket Service Plus',
                paymentFeeCost: 'Payment fee'
            }
        },
        product: {
            title: 'Product revenue',
            cash: 'Cash revenue',
            online: 'Online revenue'
        },
        totals: {
            title: 'Total',
            totals: 'Totals',
            OrganizationRevenue: 'Total organization revenue',
            PlatformRevenue: 'Total platform revenue',
            organizationCost: 'Total organization cost',
            clientCost: 'Total client cost',
            revenue: 'Total revenue',
            cost: 'Total cost',
            profit: {
                title: 'Profit',
                wallet: 'Placed into wallet',
                profit: 'Profit',
                cash: `The difference of profit and what's placed in your wallet, is because of the cash revenue`
            }
        }
    },
    wallet: {
        title: 'Wallet',
        currencyConversionInfo: 'Please be aware that while all payouts are processed in Euro, fluctuations in received amounts may occur due to banking costs and currency conversion fluctuations. We appreciate your understanding.',
        searchTransactions: 'Search transactions...',
        downloadInvoiceFailed: 'An error occurred while downloading the invoice. Please contact support for assistance.',
        downloadOrdersFailed: 'An error occurred while downloading the orders file. Please contact support for assistance.',
        downloadReceiptFailed: 'Error encountered while downloading wallet receipt. Please reach out to support for assistance.',
        loadingBalanceFailed: 'Error encountered while retrieving wallet balance. Please contact support for assistance.',
        loadingTransactionsFailed: 'Error encountered while fetching wallet transactions. Please contact support for assistance.',
        balance: {
            title: 'Balance',
            subTitle: 'Wallet balance over the past {days} days.',
            pending: 'Pending',
            spendable: 'Spendable'
        },
        payout: {
            request: 'Request payout',
            requestFailed: 'Error encountered while processing payout request. Please contact support for assistance.',
            requestSuccess: 'Your payout request has been successfully submitted.',
            acknowledge: 'By submitting this request, you acknowledge that you are requesting to be paid {amount}.',
            info: 'You can request a custom payout amount by selecting the checkbox and providing a custom value.',
            custom: 'Request custom value',
            amount: 'Amount'
        },
        structure: {
            pending: 'Pending',
            reserved: 'Reserved',
            requiredDeposit: 'Required deposit',
            spendable: {
                title: 'Spendable',
                tip: 'You have requested payout(s) totaling {0} that have not yet been processed.'
            }
        },
        transaction: {
            statement: 'Statement',
            table: {
                amount: 'Amount',
                processedOn: 'Processed',
                requestedOn: 'Requested'
            }
        }
    },
    paymentStatus: {
        title: 'Payment status',
        authenticationFinished: 'Authentication finished',
        authenticationNotRequired: 'Authentication not required',
        authorised: 'Authorized',
        blocked: 'Blocked',
        cancelled: 'Canceled',
        challengeShopper: 'Challenge shopper',
        chargeback: 'Chargeback',
        error: 'Error',
        expired: 'Expired',
        identifyShopper: 'Identify shopper',
        partiallyAuthorised: 'Partially authorised',
        partialRefund: 'Partial refund',
        pending: 'Pending',
        presentToShopper: 'Present to shopper',
        received: 'Received',
        redirectShopper: 'Redirect shopper',
        refund: 'Refund',
        pendingRefund: 'Pending refund',
        refused: 'Refused',
        unknown: 'Unknown'
    }
} satisfies Translations;
