import type { Translations } from '../types';

export default {
    logout: 'Sign off',
    useClient: 'View personal account',
    login: {
        title: 'Login',
        description: 'To log in, kindly provide your credentials and access your account.',
        submit: 'Sign in',
        or: 'Or',
        createAccount: 'Create an account',
        forgotPassword: 'Forgot password?'
    },
    register: {
        title: 'Sign up',
        description: 'Welcome to WeAreFancee! Before you create your account, kindly specify the type of account you wish to create.',
        clientTitle: 'Customer',
        clientDescription: 'I want to see my own tickets.',
        organizationTitle: 'Organization',
        organizationDescription: 'I need ticketing for my event(s).',
        complete: 'Your account has been created! Please check your email inbox for a verification.',
        submit: 'Register',
        client: {
            title: 'Sign up - Customer',
            description: `Let's get started on creating your personal WeAreFancee account. Please fill in the form below to continue.`
        },
        organization: {
            title: 'Sign up - Organization',
            description: `Let's get started on creating your WeAreFancee account. A contract will be created once your account is created. You should be able to start right away. Please fill in the form below to continue.`
        }
    },
    select: {
        title: 'Hi {name},',
        description: 'Your account can manage different organizations. Which one do you want to dive into?'
    },
    verify: {
        title: 'Account verification',
        description: 'Hold on for a moment as we validate your account details.',
        busy: 'Verifying...',
        done: 'Your account has been verified! You may now login.'
    },
    forgotPassword: {
        title: 'Reset your password',
        description: `No worries! If you've forgotten your password, just enter your email address below. We'll send you detailed instructions on how to reset it.`,
        feedback: `If you have an account at @:global.platform.name you'll be receiving an email with instructions on how to reset your password.`
    },
    forgotPasswordReset: {
        title: '@:auth.forgotPassword.title',
        description: `To regain access to your account, please enter your new password below. Make sure it meets our security requirements. Once your new password is set, you'll be able to use your account securely.`,
        success: `Your password has been reset. You'll be redirected to the login page shortly.`
    },
    reauthenticate: {
        title: `You've been signed out.`,
        body: 'To continue using your account, please sign in again using your password.',
        submit: '@:auth.login.submit'
    },
    sessions: {
        singular: 'Session',
        plural: 'Sessions',
        search: 'Search sessions...',
        device: 'Device',
        ipAddress: 'IP Address',
        issuedOn: 'Issued on',
        expires: 'Expires',
        deleteFailed: 'Could not delete the session. Please try again later.',
        loadingFailed: 'Could not retrieve sessions. Please try again later.',
        deleted: 'The session was successfully deleted.'
    }
} satisfies Translations;
