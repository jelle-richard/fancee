import type { Translations } from '../types';

export default {
    errors: {
        message: 'Please address the errors in the form before proceeding with the submission.',
        pleaseFix: 'Please fix the following items',
        pleaseFixErrors: 'Please fix the following errors'
    },
    validator: {
        afterDate: 'Date must be after {formattedDateTime}',
        alpha: 'Please enter only alphabetical characters.',
        alphaNum: 'Please enter a value containing only letters and numbers.',
        beforeDate: 'Date must be before {formattedDateTime}',
        between: 'Please enter a number between {min} and {max}, inclusive.',
        betweenDates: 'Date must be between {formattedMinDate} and {formattedMaxDate}',
        decimal: 'Please enter a valid decimal value.',
        email: 'Please enter a valid email address.',
        future: 'Please enter a future date.',
        integer: 'Please enter a whole number.',
        ipAddress: 'Please enter a valid IP address.',
        macAddress: 'Please enter a valid MAC address.',
        maxPrice: 'Please enter an amount less than or equal to {formattedMaxPrice}.',
        maxLength: 'Please enter a value with a maximum length of {max} characters.',
        maxValue: 'Please enter a number less than or equal to {max}.',
        minLength: 'Please enter a value with a minimum length of {min} characters.',
        minValue: 'Please enter a number greater than or equal to {min}.',
        numeric: 'Please enter a valid numeric value.',
        past: 'Please enter a past date.',
        phoneNumber: 'Please enter a valid phone number.',
        price: 'Please enter a valid price with a decimal value.',
        required: 'This field is required.',
        requiredIf: 'This field is required.',
        requiredUnless: 'This field is required.',
        sameAs: 'Please ensure this field is the same as the other field.',
        url: 'Please enter a valid URL.',
        minTextLength: '@:validation.validator.minLength',
        secureCode: `Please enter a value that contains only letters, numbers or one of the following characters: . {'@'} _ -.`
    }
} satisfies Translations;
