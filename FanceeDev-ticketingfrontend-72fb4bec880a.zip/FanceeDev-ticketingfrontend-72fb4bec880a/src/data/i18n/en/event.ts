import type { Translations } from '../types';

export default {
    plural: 'Events',
    singular: 'Event',
    discountPlural: 'Discounts',
    discountSingular: 'Discount',
    productPlural: 'Products',
    productSingular: 'Product',
    shopPlural: 'Shops',
    shopSingular: 'Shop',
    ticketPlural: 'Tickets',
    ticketSingular: 'Ticket',
    createEvent: 'Create event',
    manageEvent: 'Manage event',
    myEvents: 'My events',
    list: {
        deletionFailed: 'Could not delete event "{0}".',
        searchPlaceholder: 'Search events...',
        table: {
            deactivated: 'This shop is deactivated.',
            event: '@:event.singular',
            organization: 'Organization',
            shops: '@:event.shopPlural',
            status: 'Status'
        },
        emptyView: {
            title: 'No events',
            message: 'No events have been created in your account yet.',
            add: '@:event.singular'
        }
    },
    discount: {
        title: 'Discounts',
        searchPlaceholder: 'Search discounts...',
        loadingEventsFailed: 'An error occurred while loading your events. Please try again later.',
        loadingProductsFailed: 'There was an error loading your products. Please try again later.',
        filter: {
            includeExpired: 'Include expired',
            shops: '@:event.shopPlural',
            shopsSearchPlaceholder: `Search @.lower:{'event.shopPlural'}...`
        },
        table: {
            code: 'Code',
            used: 'Used',
            amount: 'Amount',
            expires: 'Expires'
        },
        deleteFailed: 'An unknown error occurred while attempting to remove the discount. Please contact support for assistance.',
        getFailed: 'An unknown error occurred while retrieving your discount. Please contact support for assistance.',
        listFailed: 'An unknown error occurred while retrieving your discounts. Please contact support for assistance.',
        deleted: 'Discount deleted successfully.',
        saved: 'Discount saved successfully.',
        configurator: {
            title: {
                create: 'Create @.lower:event.discountSingular',
                edit: 'Edit @.lower:event.discountSingular'
            },
            expires: 'Expires',
            stock: 'Stock',
            assignTo: {
                label: 'Assign to',
                placeholder: 'Discount applies to...',
                description: {
                    products: [
                        'When assigning a fixed discount to a product the amount is deducted per product in the order. Percentage discounts are deducted over the total amount of products.',
                        'Select events to find your products'
                    ],
                    shops: 'When assigning a discount to a shop the amount is deducted from the order total.'
                }
            },
            code: {
                label: 'Code',
                placeholder: '@:form.eg SPRING13'
            },
            value: {
                labelFixed: 'Fixed discount',
                labelPercentage: 'Percentage discount'
            },
            validate: {
                assignmentRequirement: 'At least one shop or product needs to be assigned to the discount.',
                valueRequirement: 'A static or percentage discount value is missing.'
            }
        }
    },
    guestlist: {
        singular: 'Guestlist',
        plural: 'Guestlists',
        title: '@:event.guestlist.plural',
        selector: {
            title: 'Manage guestlists',
            search: '@:event.list.searchPlaceholder'
        },
        empty: 'You can only manage guest lists for active events. Please specify your search further or check if you have any active events.',
        manage: {
            title: 'Edit guestlist',
            onlyActiveEvents: 'Guestlists can only be sent to active events.',
            deduct: 'Deduct stock',
            guest: 'Guest',
            hasHeader: 'CSV has a header',
            failed: 'An error occurred while sending the guest list. Please contact support for assistance.',
            success: 'Your guest ticket(s) have been successfully sent.',
            manual: {
                title: 'Invite'
            },
            import: {
                title: 'Import',
                info: 'To bulk upload guests, please upload a CSV file containing, at minimum, the email address and quantity of tickets to send. When assigning field types to the values of your file, it is important to check if your file has a header and mark it accordingly.',
                choose: 'Choose file',
                maxRows: 'You can upload a CSV file with a maximum of {0} email addresses.',
                maxRowsExceeded: 'The maximum amount of {0} guest list imports has been exceeded.',
                missingEmailField: 'No field has been assigned as an email.',
                missingQuantityField: 'No field has been assigned as a quantity.',
                table: {
                    example: 'Example data',
                    field: 'Field type'
                }
            }
        }
    },
    ticket: {
        title: '@:event.ticketPlural',
        addBarcodes: 'Barcodes',
        searchPlaceholder: `Search @.lower:{'event.ticketPlural'}...`,
        table: {
            event: '@:event.singular',
            shop: '@:event.shopSingular',
            ticket: '@:event.ticketSingular',
            code: 'Code',
            origin: 'Origin',
            scanStatus: 'Scan status',
            scanTime: 'Scan time',
            holder: 'Holder',
            state: 'Status'
        },
        filter: {
            acquirerOrigin: 'Acquirer origin',
            promotionalEmail: 'Promotional Email',
            promotionalSms: 'Promotional SMS',
            receiveOrderSms: 'Receive order SMS',
            scanState: 'Scan status'
        },
        origin: {
            app: 'Acquired via @:global.platform.name app',
            generated: 'Generated by @:global.platform.name',
            guestlist: '@:global.platform.name guestlist',
            imported: 'Imported to @:global.platform.name',
            shop: 'Acquired via @:global.platform.name shop',
            ticketswap: 'Acquired via TicketSwap',
            filter: {
                app: '@:global.platform.name app',
                generated: 'Generated',
                guestlist: '@:global.platform.name guestlist',
                imported: 'Imported',
                shop: '@:global.platform.name shop',
                ticketswap: 'TicketSwap'
            }
        },
        single: {
            title: '@:event.ticketSingular information',
            info: {
                name: '@:event.ticketSingular name',
                code: 'Code',
                markScanned: 'Mark scanned',
                markUnscanned: 'Mark unscanned',
                scanStatus: 'Scan status',
                seatLocation: 'Seat location',
                viewOrder: 'View order',
                scanStateConfirm: 'Would you like to update the scanning status of ticket {code} to {state}?',
                scanStateUpdated: 'Scan status updated',
                advanced: {
                    title: 'Advanced options',
                    invalidate: {
                        title: 'Invalidate',
                        explanation: `You can invalidate a ticket so the ticket can't be used anymore`,
                        returnToStock: 'Return to stock',
                        giveReason: 'Please give a reason why the ticket is invalidated, the client will get a notification with this reason',
                        failed: 'Could not invalidate the ticket. If the problem persists, please contact support for assistance.',
                        success: 'Invalidated the ticket'
                    }
                },
                ticketState: 'Ticket status'
            },
            client: {
                title: 'Client information',
                belongsTo: 'Belongs to',
                boughtBy: 'Bought by',
                boughtInShop: 'Bought in shop',
                enabledSms: 'Enabled Sms',
                enabledTsp: 'Enabled Tsp',
                optins: {
                    label: 'Promotional opt-ins',
                    email: '@:form.field.email',
                    sms: 'SMS'
                }
            },
            holder: {
                title: 'Holder information'
            }
        }
    },
    scanState: {
        notScanned: 'Not scanned',
        scanned: 'Scanned',
        unscanned: 'Unscanned'
    },
    status: {
        title: 'Event status',
        active: 'Active',
        canceled: 'Canceled',
        cancelled: '@:event.status.canceled',
        concept: 'Concept',
        concluded: 'Concluded',
        soldOut: 'Sold out',
        unpublished: 'Unpublished'
    },
    addBarcodesOverlay: {
        title: 'Barcodes',
        generate: 'Generate',
        import: 'Import',
        selectEvent: 'Select event...',
        selectProduct: 'Select product...',
        submitGenerate: 'Generate',
        submitImport: 'Import',
        generateError: 'Error generating barcodes.',
        importError: 'Error importing barcodes.',
        productLoadingFailed: 'Error loading products',
        importDuplicateFound: 'Duplicate fields were found. Ensure that a field type is selected once.',
        importMax: 'A maximum of {amount} barcodes can be imported at once.',
        importMissingBarcode: 'A barcode field type is required. Ensure that one is selected.',
        success: {
            title: 'Badcodes added',
            message: 'Successfully added {amount} new barcodes.'
        },
        fieldType: {
            barcode: 'Barcode',
            email: '@:form.field.email',
            firstName: '@:form.field.firstName',
            lastName: '@:form.field.lastName'
        }
    },
    copyEventOverlay: {
        title: 'Copy {0}',
        info: 'You\'re about to copy {0}, please select the desired additional information to copy along.',
        categories: {
            title: 'Categories',
            description: 'Copy all categories.'
        },
        paymentMethods: {
            title: 'Payment methods',
            description: 'Copy all payment methods.'
        },
        products: {
            title: 'Products',
            description: 'Copy all products.'
        },
        shops: {
            title: '@:event.shopPlural',
            description: `Copy all @.lower:{'event.shopPlural'}.`
        }
    },
    cancelOverlay: {
        title: 'Cancel event',
        explanation: 'Note that canceling the event is a permanent action, and cannot be undone. Once the event is canceled, it cannot be restored.',
        giveReason: 'Give a detailed reason why you\'re cancelling the event.',
        failed: 'There was an error with cancelling your event, please try again later.',
        success: 'The event was successfully canceled.'
    },
    cancelPane: {
        title: 'Cancel',
        explanation: 'If you choose to cancel your event, it will be disabled and no products can be sold anymore.',
        notice: '@:event.cancelOverlay.explanation',
        submit: 'Cancel event'
    },
    unpublishPane: {
        title: 'Unpublish',
        explanation: 'If you choose to unpublish your event, it will be temporarily disabled until you choose to publish it again.',
        submit: 'Unpublish'
    },
    create: {
        step: {
            type: 'Type',
            details: 'Details',
            products: '@:event.productPlural',
            shops: '@:event.shopPlural',
            payment: 'Payment',
            mailing: 'Mailing',
            design: 'Ticket design',
            publish: 'Publish'
        },
        details: {
            seatingEventId: 'Seating Event ID',
            categories: {
                label: 'Categories',
                placeholder: 'Pick a few optional categories for your event...'
            },
            header: {
                label: 'Header',
                description: 'Images that are used as a header for your event.'
            },
            minimalAge: {
                hint: 'Events with age restrictions must request guests\' ages. Leave the field blank if no restriction applies.',
                label: 'Minimal age',
                placeholder: '@:form.eg 16'
            },
            timezone: {
                info: 'Your event will be held in the {timezone} timezone.',
                change: 'Use a different timezone.'
            },
            sealed: {
                label: 'Sealed event',
                hint: 'Once you\'ve enabled and saved sealed event sales it can no longer be turned off',
                enabled: 'Sealed ticket delivery is enabled for this event'
            }
        },
        mailing: {
            title: 'Mailing',
            content: 'Content',
            mailType: 'Mail type',
            mailTypes: {
                guestlist: 'Guestlist invite mail',
                purchase: 'Purchase mail',
                sealed: 'Sealed ticket delivery mail'
            },
            senderName: 'Sender name',
            senderNamePlaceholder: '@:global.platform.name',
            subject: 'Subject',
            subjectPlaceholder: 'Your purchase confirmation for Event',
            variables: {
                title: 'Variables',
                info: 'Emails can contain customized text based on the variables below, which will be replaced with appropriate values once the email is sent.'
            },
            sealed: {
                title: 'Sealed ticket delivery',
                message: 'You\'ve enabled sealed ticket delivery for your event and thus you can also change the delivery mail below'
            }
        },
        paymentMethods: {
            title: 'Payment methods',
            defaults: 'Your default payment settings are currently applied. Change any of these settings to override.',
            paidByCustomer: 'Enabled, paid by customer',
            paidByOrganization: 'Enabled, paid by organization',
            loadingFailed: 'An error occurred while attempting to retrieve your default payment methods. Please reach out to support if this issue persists.',
            klarnaInfo: 'For this payment method, the \'address\' field needs to be set to \'required\' in the shop settings.',
            psd2: {
                title: 'Attention, PSD2 may apply to you!',
                paragraphs: [
                    'According to the PSD2 law, it is not always allowed to surcharge your customers for payment fees.',
                    'One of the provisions of PSD2 is the prohibition of surcharging, which means that merchants are not allowed to charge customers extra fees for using specific payment methods, such as credit or debit cards. This is meant to protect consumers from hidden or excessive fees, promote transparency, and ensure that the prices advertised by merchants are the same for all payment methods.',
                    'It\'s worth noting that while PSD2 applies to all EU member states, some countries may have implemented the law differently, so the exact rules on surcharging may vary. However, in general, the law aims to prevent merchants from passing on the costs of accepting card payments to consumers. This means that merchants are required to absorb the costs of payment processing themselves, rather than charging customers extra fees for using certain payment methods.',
                    'There are some exceptions per country, but please do your due diligence. For instance, iDeal, PayPal, and AMEX are allowed to be surcharged in the Netherlands.'
                ]
            }
        },
        products: {
            add: {
                ticket: '@:global.add @.lower:event.ticketSingular',
                product: '@:global.add @.lower:event.productSingular'
            },
            configurator: {
                access: {
                    title: 'Access',
                    partial: {
                        label: 'Partial Access',
                        hint: 'When Partial Access is enabled, customers can only enter the event within the given time span.',
                        end: 'End',
                        start: 'Start'
                    }
                },
                advanced: {
                    title: 'Advanced',
                    ticketSwap: {
                        label: 'TicketSwap',
                        hint: 'Enables SecureSwap of the ticket on TicketSwap. When turned of, it\'s no longer possible to sell this ticket via TicketSwap. Note that it is advisable to contact TicketSwap in case you\'re turning this off for the entire event.',
                        sealedSwapUnfinishedTitle: 'TicketSwap not possible',
                        sealedSwapUnfinishedDescription: 'Due to work on TicketSwaps end, TicketSwap cannot be used for sealed events at this moment, check back later'
                    }
                },
                details: {
                    title: 'Details',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Early Bird'
                    },
                    description: {
                        label: '@:form.field.description',
                        placeholder: '@:form.eg Gives you the best spot at our venue.'
                    }
                },
                images: {
                    title: 'Images'
                },
                salesFlow: {
                    title: 'Sales flow',
                    administrationFee: {
                        label: 'Administration fee',
                        hint: 'This is the fee you place on top of the ticket price. When empty, the fee in your contract will be used.'
                    },
                    maxOrderQuantity: {
                        label: 'Maximum order quantity'
                    },
                    packQuantity: {
                        labelProduct: 'Amount',
                        labelTicket: 'Amount of barcodes in groupticket',
                        hint: 'The product is sold per the given quantity. For example: The product is sold in sets of two when two is entered.'
                    },
                    dateTime: {
                        title: 'Date time',
                        hint: 'Sell your product during the specified date range.',
                        saleEnd: 'Sale end',
                        saleStart: 'Sale start'
                    },
                    waveLink: {
                        title: 'Wave link',
                        hint: 'Sell your product once the selected product has 10% remaining stock.',
                        linkedTicket: 'Linked ticket',
                        circular: 'This wave link combination is not possible. Both products create a circular chain.',
                        disabled: 'You should have at least two products for this feature to work.'
                    }
                },
                scanning: {
                    title: 'Scanning',
                    notification: {
                        label: 'Notification',
                        placeholder: '@:form.eg Give 5 coins at arrival.'
                    },
                    preArrivalThreshold: {
                        label: 'Pre arrival threshold',
                        hint: 'Allows customers to arrive the given amount of minutes before their access starts.'
                    }
                },
                hint: {
                    title: 'More product options',
                    description: 'There are even more options for your products, click the gear icon of a product to reveal them.'
                }
            },
            empty: {
                title: '@:event.productPlural',
                description: [
                    'Start building your shops inventory by adding tickets and or products. Your tickets and products can be configured according to the needs of your marketing strategy, stock management, scanner personnel and much more.',
                    'After you\'re done creating all your tickets and or products you will be able to assign and design them in the next step.'
                ]
            },
            group: {
                products: '@:event.productPlural',
                seatedTickets: 'Seated @.lower:event.ticketPlural',
                tickets: '@:event.ticketPlural'
            },
            new: {
                product: 'New @.lower:event.productSingular',
                ticket: 'New @.lower:event.ticketSingular'
            },
            row: {
                name: {
                    label: '@:form.field.name',
                    placeholder: '@:event.create.products.configurator.details.name.placeholder'
                },
                price: {
                    label: '@:form.field.price',
                    change: `Please be aware that you're about to change the price of a ticket that already has sales. Consider creating a new ticket for the newly priced tickets.`
                },
                seats: {
                    label: 'Seats'
                },
                stock: {
                    label: '@:form.field.stock',
                    placeholder: '@:form.eg 100'
                }
            }
        },
        publish: {
            notReady: {
                title: 'Almost there',
                info: 'Your event is almost ready to be published. Complete the steps below before publishing your event.',
                missingPaymentMethods: {
                    action: 'Configure payment methods',
                    message: 'There are no payment methods configured for your event.'
                },
                missingSellableProducts: {
                    action: 'Configure shops',
                    message: 'Your event needs at least one shop with sellable products.'
                }
            },
            ready: {
                title: 'Ready to publish!',
                info: 'Everything is ready to be published. You may also save your event without publishing if you\'re not quite ready yet.',
                requestReview: 'Request review',
                requestReviewPending: 'Review requested, one of our employees will contact you.'
            },
            scanning: {
                title: 'Scanning',
                paragraphs: [
                    'Need help with scanning? WeAreFancee offers the possibility to outsource the required hardware and/or personnel required for the job.',
                    'Interested? Get in touch with our support department. We\'re always happy to help!'
                ],
                submit: 'Download instructions',
                file: 'Scanning Instructions'
            },
            status: {
                canceled: 'This event has been canceled.',
                unpublished: 'This event is unpublished. It is currently not possible to buy products through its shops.',
                soldIn: 'Sold in: {0}',
                soldNowhere: 'Not sold anywhere'
            }
        },
        seatingSetup: {
            title: 'Seating setup',
            explanation: 'Our support team will do the initial setup of this event for you. Please reach out to them to get started.',
            failed: {
                title: 'Validation failed',
                message: 'We had trouble contacting SeatsIO for validating the event. Please try again later.',
                notice: 'The given SeatsIO Event ID is invalid.'
            },
            setupId: '@:event.create.details.seatingEventId'
        },
        shops: {
            designer: 'Designer',
            default: {
                buttonLabel: 'New Button',
                noticeContent: 'This is a notice placeholder text, please input your message.',
                shopName: 'New shop',
                textBlockText: 'A text element may be used to provide your customers with some extra information about your products, dont\'t forget to replace this example with your own input.',
                textBlockTitle: 'Information'
            },
            element: {
                accordion: {
                    icon: 'Icon',
                    opened: 'Opened by default',
                    title: 'Title',
                    titlePlaceholder: '@:form.eg Bus tickets'
                },
                divider: {
                    title: 'Title',
                    titlePlaceholder: '@:form.eg Parking tickets'
                },
                externalLink: {
                    text: 'Text',
                    textPlaceholder: '@:form.eg Visit our website',
                    url: 'URL',
                    urlPlaceholder: '@:form.eg https://wearefancee.com'
                },
                notice: {
                    message: 'Message',
                    messagePlaceholder: '@:form.eg Keep in mind that bringing your ID is mandatory.',
                    variant: 'Variant',
                    variants: {
                        danger: 'Danger',
                        info: 'Information',
                        success: 'Success',
                        warning: 'Warning'
                    }
                },
                textBlock: {
                    title: 'Title',
                    titlePlaceholder: '@:form.eg Health information',
                    text: 'Text',
                    textPlaceholder: '@:form.eg Drinking water is essential for good health. It helps keep our bodies hydrated, flushes out toxins, and aids in digestion. Water also helps regulate body temperature and supports healthy skin. Experts recommend drinking at least eight glasses of water a day to maintain optimal health.'
                }
            },
            insert: {
                accordion: 'Accordion',
                divider: 'Divider',
                link: 'Link',
                notice: 'Notice',
                product: 'Product',
                seating: 'Seating map',
                text: 'Text',
                ticket: 'Ticket'
            },
            newShop: {
                title: 'New shop',
                message: 'Choose a name for your shop.',
                label: 'Name',
                placeholder: '@:form.eg Pre-sale shop'
            },
            noElements: {
                title: 'Design your shop',
                message: 'Add elements from below and bring your vision to life.'
            },
            configurator: {
                defaultPalette: {
                    loadingFailed: 'An error occurred while attempting to retrieve your default palette. Please contact support if this issue persists.',
                    savingFailed: 'An error occurred while attempting to save your default palette. Please contact support if this issue persists.'
                },
                colors: {
                    title: 'Colors',
                    background: 'Background',
                    panel: 'Panel',
                    primary: 'Primary',
                    text: 'Text'
                },
                details: {
                    title: 'Details',
                    endDate: 'End date',
                    active: 'Active',
                    startDate: 'Start date',
                    name: {
                        label: '@:form.field.name',
                        placeholder: '@:form.eg Pre-sale'
                    }
                },
                fields: {
                    title: 'Fields',
                    info: 'Specify which information you want from your guests. Optional fields are shown, but not required.',
                    address: '@:form.field.address',
                    city: '@:form.field.addressCity',
                    birthdate: '@:form.field.birthdate',
                    birthdateRequired: 'Birthdate is required, because your event has a minimal age.',
                    email: '@:form.field.email',
                    firstName: '@:form.field.firstName',
                    gender: '@:form.field.gender',
                    lastName: '@:form.field.lastName',
                    phoneNumber: '@:form.field.phoneNumber'
                },
                images: {
                    title: 'Images',
                    header: 'Header'
                },
                marketing: {
                    title: 'Marketing',
                    googleAnalyticsId: {
                        label: 'Google Analytics ID',
                        placeholder: '@:form.eg G-XXXXXXXXXX'
                    },
                    googleTagManagerId: {
                        label: 'Google Tag Manager ID',
                        placeholder: '@:form.eg GTM-XXXXXX'
                    },
                    tiktokPixelId: {
                        label: 'TikTok ID',
                        placeholder: '@:form.eg ABCDEFGHIJK123456789'
                    },
                    facebookPixelId: {
                        label: 'Facebook Pixel id',
                        placeholder: '@:form.eg 12345678912345678',
                        accessToken: 'Facebook Access Token',
                        required: 'Both Facebook inputs are required'
                    }
                }
            }
        },
        ticketDesign: {
            title: 'Ticket designer',
            info: 'This is the design that is used in the ticket PDF file.',
            assigned: 'Assigned tickets',
            unAssigned: 'Some tickets do not have a design, these will use the platform default design.',
            hasDesign: 'Has design',
            uploadImage: 'Upload image...',
            designs: {
                title: 'Designs',
                info: 'Click to edit or add a new one.',
                warning: 'Designs that are not assigned to tickets will be deleted.'
            },
            unattachedFound: {
                title: 'Unattached ticket designs found',
                message: 'Ticket designs without attached tickets have been found, when pressing continue, these designs will be deleted.'
            },
            upcomingEvents: {
                title: 'Upcoming events',
                anotherEvent: 'Another Event',
                nEvents: 'Show no events | Show one event | Show {n} events'
            },
            useDefault: 'No designs detected, pressing continue will make the tickets use the platform default layout.',
            empty: {
                title: '@:event.create.ticketDesign.title',
                description: [
                    'Start designing your tickets and products. Your tickets can be designed as you see fit. Place images on your ticket and/or show upcoming events.',
                    `After you're done creating all your ticket designs you can select which ticket you want to assign to which design.`
                ]
            }
        },
        type: {
            normal: {
                title: 'Normal',
                description: 'Suits the standard needs of selling and/or providing entry tickets.'
            },
            seated: {
                title: 'Seated',
                description: 'Assign tickets to search using an interactive map.'
            },
            timeslotted: {
                title: 'Timeslotted',
                description: 'Allows scheduling tickets into certain timespans.'
            }
        }
    },
    secureCode: {
        plural: 'Secure codes',
        singular: 'Secure code',
        secureShop: 'Secure @.lower:event.shopSingular',
        alterShopSecure: 'Alter secure state',
        search: 'Search codes...',
        table: {
            code: 'Code',
            createdOn: 'Created on',
            uses: 'Uses',
            deleteAllFailed: `Error encountered while removing all unused @.lower:{'event.secureCode.plural'}. Please try again or contact support for assistance.`,
            deleteAllSuccess: `Successfully deleted all unused @.lower:{'event.secureCode.plural'}.`,
            deleteFailed: `Error encountered while removing the @.lower:{'event.secureCode.singular'}. Please try again or contact support for assistance.`,
            deleteSuccess: `Successfully deleted the @.lower:{'event.secureCode.singular'}.`,
            downloadFailed: `An error occurred while downloading the @.lower:{'event.secureCode.plural'} export. Please contact support for further assistance.`,
            loadingFailed: `An error occurred while loading the @.lower:{'event.secureCode.plural'}. Please contact support if this issue persists.`,
            loadingShopFailed: 'An error occurred while loading the shop. Please contact support if this issue persists.',
            codeUsages: '{usedAmount}{slash}{maximumUses} have been used of which {pendingAmount} are in pending reservations'
        },
        add: {
            title: 'Add @:event.secureCode.plural',
            pleaseFix: 'Please fix the following',
            manual: 'Manual',
            maxUses: 'Max uses',
            maxUsesHint: 'Leave empty for unlimited max uses.',
            noneSelected: 'No @:event.secureCode.plural have been selected.',
            noMaxUsesSelected: 'No max uses selected.',
            duplicates: 'Duplicates have been found.',
            failed: 'Could not create a new @:event.secureCode.singular, contact support if the problem persists.',
            success: `The new @:{'event.secureCode.singular'} has been added successfully.`,
            import: {
                title: 'Import',
                failed: `Could not import @:{'event.secureCode.plural'}, contact support if the problem persists.`,
                success: 'Successfully imported new @:event.secureCode.plural'
            }
        },
        set: {
            title: 'Set secure state',
            info: 'When marking a shop as a secured shop, you may optionally set an expiration date. Once passed, the shop will operate as a normal shop, and secure codes will not be required.',
            state: 'Secure state',
            until: 'Secured until',
            failed: 'An unknown error occurred while saving the shop\'s secure state.',
            success: 'Secure state has been saved successfully.'
        },
        import: {
            title: 'Import as @.lower:event.secureCode.plural',
            info: 'Please select a shop for which you want to import the {0} with {1} pre-registers as single-use secure codes.',
            selectShop: 'Select shop...',
            submit: 'Import',
            failed: `The import of @.lower:event.secureCode.plural has failed.`,
            success: `The import of @.lower:event.secureCode.plural has succeeded.`
        }
    }
} satisfies Translations;
