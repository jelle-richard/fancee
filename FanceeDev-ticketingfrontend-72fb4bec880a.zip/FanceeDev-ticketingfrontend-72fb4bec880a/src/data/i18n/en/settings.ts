import type { Translations } from '../types';

export default {
    navigation: {
        blockedEmails: 'Blocked emails',
        defaultPaymentMethods: 'Default payment methods',
        defaultShopPalette: 'Default shop design',
        roleManagement: 'Role management'
    },
    blockedEmails: {
        add: 'Add blocked email',
        addSuccess: 'Successfully blocked {0}.',
        deleteEverythingConfirm: 'This action will remove all blocked emails from your account.',
        deleteEverythingFailed: 'An error occurred while attempting to delete all blocked emails. Please try again later or contact support for assistance.',
        deleteEverythingSuccess: 'All blocked emails have been successfully deleted.',
        deleteFailed: 'An error occurred while attempting to delete a blocked email. Please try again later or contact support for assistance.',
        deleteSuccess: 'Blocked email successfully deleted.',
        loadingFailed: 'There was an error while loading blocked emails. Please try again later. If the issue persists, contact support for assistance.'
    },
    defaultPaymentMethods: {
        loadingFailed: 'An error occurred while attempting to retrieve your default payment methods. Please contact support if this issue persists.',
        savingFailed: 'An error occurred while attempting to save your default payment methods. Please contact support if this issue persists.'
    },
    defaultShopPalette: {
        title: 'Default shop design',
        description: 'Save your branding colors as a default palette for easy application in your shops.',
        background: 'Background',
        panel: 'Panel',
        primary: 'Primary',
        text: 'Text'
    },
    roleManagement: {
        title: 'Role management',
        notice: 'Granting roles to external users allows you to provide access to parts of your organization\'s account. This enables sharing the management of daily tasks or offering insights into specific areas of your organization.',
        addFailed: 'An unknown error occurred while assigning the user. Please contact support if this issue persists.',
        addSuccess: 'The user has been successfully added to the organization.',
        deleteFailed: 'An unknown error occurred while deleting the user. Please contact support if this issue persists.',
        deleteSuccess: 'The user has been successfully removed from the organization.',
        loadingFailed: 'An unknown error occurred while loading your users. Please contact support if this issue persists.',
        updateFailed: 'An unknown error occurred while updating the assigned user. Please contact support if this issue persists.',
        configure: {
            title: {
                add: 'Add new user',
                edit: 'Edit {0}'
            },
            rights: 'Rights',
            loadingFailed: 'An unknown error occurred while loading your claims. Please contact support if this issue persists.'
        }
    }
} satisfies Translations;
