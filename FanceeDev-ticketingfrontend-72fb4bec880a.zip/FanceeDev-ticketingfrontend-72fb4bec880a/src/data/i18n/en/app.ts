import type { Translations } from '../types';

export default {
    title: 'App',
    scanStatistics: {
        title: 'Scan statistics'
    },
    team: {
        plural: 'App teams',
        singular: 'App team',
        title: '@:app.team.plural',
        search: 'Search app teams...',
        emptyView: 'It seems your account has no app-teams.',
        createFailed: 'The app team could not be created. If the problem persists, please contact support for assistance.',
        createSuccess: 'The app team has been successfully created.',
        deleteFailed: 'The app team could not be deleted. If the problem persists, please contact support for assistance.',
        deleteSuccess: 'The app team has been successfully deleted.',
        updateFailed: 'The app team could not be edited. If the issue persists, please contact support for assistance.',
        downloadFailed: 'An error occurred while downloading your app teams. Please contact support for assistance.',
        loadingFailed: 'An error occurred while fetching your app teams. Please try again or contact support for assistance.',
        loadingEventsFailed: 'An error occurred while loading your events. Please try again later.',
        loadingProductsFailed: 'An error occurred while loading your products. Please try again or contact support for assistance.',
        loadingSingleFailed: 'An error occurred while fetching your app team. Please try again or contact support for assistance.',
        table: {
            name: '@:form.field.name',
            rights: 'Rights',
            qr: 'QR-Code'
        },
        right: {
            guestlists: '@:event.guestlist.plural',
            scanning: 'Scan',
            sales: 'Sales',
            statistics: 'Statistics',
            cash: 'Cash'
        },
        configure: {
            title: {
                edit: 'Edit {0}',
                new: 'Create app team'
            }
        },
        statistics: {
            title: 'View scan statistics',
            loadingFailed: 'An error occurred while fetching the event statistics. Please try again or contact support for assistance.',
            loadingTeamFailed: 'An error occurred while fetching the app team statistics. Please try again or contact support for assistance.',
            selectAppTeam: 'Select an app team...',
            selectEvent: 'Select an event...',
            event: {
                title: 'Event statistics',
                subTitle: 'Scan statistics per ticket',
                remaining: 'Remaining',
                scanned: 'Scanned'
            },
            team: {
                title: 'Scan times',
                subTitle: 'App team scan times',
                scanned: 'Scanned',
                unscanned: 'Unscanned',
                dateHint: 'Modify the date or hour to view the scan statistics from that time onward.',
                empty: 'No scan data was found for the selected app team or the chosen date.'
            }
        }
    }
} satisfies Translations;
