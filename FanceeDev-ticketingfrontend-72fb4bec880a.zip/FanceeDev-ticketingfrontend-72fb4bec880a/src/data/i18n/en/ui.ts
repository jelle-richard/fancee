import type { Translations } from '../types';

export default {
    changesSavedSuccessfully: 'Changes saved successfully.',
    accountTakeoverNotice: {
        info: 'Currently logged in as {0}, everything you do affects this account.',
        switchBack: 'Switch back to {0}.'
    },
    confirmDeleteOverlay: {
        title: 'Delete {0}?',
        titleAll: 'Delete everything?',
        titleGeneric: 'Confirm delete',
        message: 'Are you really sure you want to delete "{0}"?',
        messageGeneric: 'Are you really sure you want to delete the entry?'
    },
    countrySelectOverlay: {
        title: 'Which countries do you want to manage?',
        selection: '{0} of {1}',
        checkAll: 'Manage all countries'
    },
    focalPoint: {
        editor: {
            title: 'Focal point editor',
            subTitle: 'Drag the circle to the desired focal point for each of your images.'
        },
        singular: 'Focal point',
        plural: 'Focal points'
    },
    notAllowed: {
        title: 'Not allowed',
        message: 'Your account doesn\'t have the permissions to perform the requested action.'
    },
    notFound: {
        record: 'The requested record could not be found.',
        page: {
            title: 'Page not found',
            content: 'The requested URL was not found on this server.',
            goHome: 'Back to Home'
        }
    },
    shareOverlay: {
        copied: 'Successfully copied to clipboard!',
        copyFrameCode: 'Copy iframe code',
        copyUrl: 'Copy URL',
        newTab: 'New tab'
    },
    somethingWentWrong: {
        title: 'Oops... ;(',
        message: 'We ran into a hiccup on our end. Please give it another shot later, and if the issue persists, reach out to our support team.',
        downloadFailed: 'There\'s an issue with the file download. Please contact our support for assistance.'
    },
    unsavedChanges: {
        title: 'Warning! Unsaved changes.',
        message: 'There are unsaved changes. If you continue, these changes will be lost. Are you sure you want to proceed?'
    },
    navigation: {
        ticketing: {
            home: 'Overview',
            finance: {
                group: 'Finance',
                invoices: 'Invoices',
                orders: 'Orders',
                reports: 'Reports',
                wallet: 'Wallet'
            },
            marketing: {
                group: 'Marketing',
                agendas: 'Agendas',
                campaignTracking: 'Campaign tracking',
                preRegisters: 'Pre registers'
            }
        }
    },
    pageTitle: {
        faq: 'FAQ',
        home: 'Overview',
        profile: 'Profile',
        settings: 'Settings',
        whatsNew: `What's new`,
        secureCodes: 'Secure codes'
    },
    profileMenu: {
        appearance: 'Appearance',
        faq: 'FAQ',
        language: 'Language',
        managing: 'Managing: {0}',
        profile: 'Profile',
        settings: 'Settings',
        signOff: 'Sign off',
        switchOrganization: 'Switch organization',
        whatsNew: `What's new`,
        theme: {
            dark: 'Dark',
            light: 'Light'
        }
    },
    countdown: {
        expiresIn: 'Expires in {0}:{1}',
        expiresInWithHours: 'Expires in {0}:{1}:{2}',
        expiresInDays: 'Expired | Expires in one day | Expires in {n} days',
        expiresInHours: 'Expired | Expires in one hour | Expires in {n} hours'
    },
    csvUpload: {
        message: 'Upload or drag a CSV file here...',
        button: 'Select file',
        hasHeader: 'Has header',
        exampleData: 'Example data',
        fieldType: 'Field type'
    },
    emptyView: {
        title: 'Nothing here',
        message: 'There is currently nothing to see here.'
    },
    googlePlacesAutocomplete: {
        invalid: 'Invalid address, please select one from the address dropdown.',
        unavailable: 'It is not possible to select an address right now.'
    }
} satisfies Translations;
