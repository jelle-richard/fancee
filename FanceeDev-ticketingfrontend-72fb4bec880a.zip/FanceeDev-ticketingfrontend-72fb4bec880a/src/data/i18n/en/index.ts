import type { Locale } from '../types';
import imageUrl from '@/assets/language/gb.svg?url';
import analytics from './analytics';
import app from './app';
import auth from './auth';
import client from './client';
import crm from './crm';
import dashboard from './dashboard';
import event from './event';
import finance from './finance';
import flux from './flux';
import form from './form';
import global from './global';
import marketing from './marketing';
import onboarding from './onboarding';
import platform from './platform';
import settings from './settings';
import validation from './validation';
import ui from './ui';

export const messages = {
    analytics,
    app,
    auth,
    client,
    crm,
    dashboard,
    event,
    finance,
    flux,
    form,
    global,
    marketing,
    onboarding,
    platform,
    settings,
    validation,
    ui
};

export const options: Locale = {
    code: 'en',
    flag: imageUrl,
    label: 'English'
};
