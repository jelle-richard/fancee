import type { messages as en } from './en';

export type Locale = {
    readonly code: string;
    readonly flag: string;
    readonly label: string;
};

export type Translations = { [key: string]: Translation; };
export type Translation = string | PluralTranslation | Translation[] | Translations;
export type PluralTranslation = `${string} | ${string}` | `${string} | ${string} | ${string}`;

export type Schema = typeof en;
export type Messages = { [key: string]: Schema; };

export type LocaleImport = {
    readonly messages: Schema;
    readonly options: Locale;
};
