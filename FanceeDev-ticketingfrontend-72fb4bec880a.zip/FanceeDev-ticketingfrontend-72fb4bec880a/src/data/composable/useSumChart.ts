import { computed, Ref, ref, unref } from 'vue';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
import { ChartGrowth, ChartSeriesItem } from '@/data/interface/charts';
import { Channel } from '../dto/analytics/channels';
import { DateTime } from 'luxon';

export function useSumChart<TSumItem>(channels: Ref<Channel[]>, fieldNameForX: string, fieldNameForY: string): UseSumChart<TSumItem> {
    const sumCharts = ref<SumChart<TSumItem>[]>([]);
    const fieldX = ref(fieldNameForX);
    const fieldSelection = ref(fieldNameForY);

    const chartSeries = computed((): ChartSeriesItem[] => {
        const _sumCharts = unref(sumCharts);
        const _fieldX = unref(fieldX);
        const _fieldY = unref(fieldSelection);
        const _channels = unref(channels);

        return _sumCharts.map(group => {

            const mappedData = mapSumItems(group.items, _fieldX);

            return {
                name: _channels?.find(c => c.id === group.channelId)?.name ?? '',
                data: mappedData.map(item => ({x: DateTime.fromISO(<string>item.key), y: item.values.reduce((acc, curr) => curr[_fieldY], 0)}))
            };
        });
    });

    interface KeyValueMap<TSumItem> {
        key: string | number | DateTime;
        values: TSumItem[];
    }

    const mapSumItems = (entries: TSumItem[], fieldX: string): KeyValueMap<TSumItem>[] => entries.reduce(function (responseArray: KeyValueMap<TSumItem>[], entry: TSumItem) {
        let itemInArray = responseArray.find(i => i.key === entry[fieldX]);

        if (!itemInArray) {
            itemInArray = {key: entry[fieldX], values: []};
            responseArray.push(itemInArray);
        }

        itemInArray.values.push(entry);

        return responseArray;
    }, []);

    const chartGrowth = computed((): ChartGrowth => {
        const _sumCharts = unref(sumCharts);
        const _fieldName = unref(fieldSelection);

        let chartGrowth: ChartGrowth = {
            growth: 0,
            total: 0,
            percentage: 0,
            previousGrowth: 0,
            previousTotal: 0,
            previousPercentage: 0
        };

        _sumCharts.filter(s => s.items?.length > 0).forEach(s => {
            const startOfThisPeriod = s.items[0][_fieldName];

            chartGrowth.growth += (s.items[s.items.length - 1][_fieldName]) - startOfThisPeriod;
            chartGrowth.total += s.items[0][_fieldName];

            if (s.startOfPreviousPeriod) {
                const startOfPreviousPeriod = s.startOfPreviousPeriod[_fieldName];

                chartGrowth.previousGrowth += startOfThisPeriod - startOfPreviousPeriod;
                chartGrowth.previousTotal += startOfPreviousPeriod;
            }
        });

        if (chartGrowth.growth !== 0 && chartGrowth.total !== 0) {
            chartGrowth.percentage = Math.round(chartGrowth.growth / chartGrowth.total * 10000) / 100;
        }

        if (chartGrowth.previousGrowth !== 0 && chartGrowth.previousTotal !== 0) {
            chartGrowth.previousPercentage = Math.round(chartGrowth.previousGrowth / chartGrowth.previousTotal * 10000) / 100;
        }

        return chartGrowth;
    });

    function setSumCharts(newSumCharts: SumChart<TSumItem>[]) {
        sumCharts.value = newSumCharts;
    }

    return {
        chartSeries,
        fieldSelection,
        chartGrowth,
        setSumCharts
    };
}

interface UseSumChart<TSumItem> {
    readonly chartSeries: Ref<ChartSeriesItem[]>;
    readonly fieldSelection: Ref<string>;
    readonly chartGrowth: Ref<ChartGrowth>;

    setSumCharts(newSumCharts: SumChart<TSumItem>[]): void;
}
