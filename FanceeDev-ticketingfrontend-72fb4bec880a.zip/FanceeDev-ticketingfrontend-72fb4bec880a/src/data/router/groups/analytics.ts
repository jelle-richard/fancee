import { UserType } from '@fancee/data';
import { Route } from '..';
import Proxy from '../proxy';
import analyticsLogo from '@/assets/brand/logo-analytics.svg';

export default (): Route => ({
    path: '/analytics',
    component: () => import('@/components/ui/Dashboard.vue'),
    meta: {
        accessibleBy: [UserType.Organization],
        authorized: true,
        product: {
            logo: analyticsLogo,
            name: 'analytics.title'
        },
        navigation: [
            {
                icon: 'home',
                title: 'analytics.navigation.home',
                route: 'analytics-home'
            },
            {
                icon: 'star',
                title: 'analytics.navigation.social',
                route: 'analytics-social'
            },
            {
                icon: 'bullhorn',
                title: 'analytics.navigation.campaign',
                route: 'analytics-campaign'
            },
            {
                header: 'analytics.navigation.settings'
            },
            {
                icon: 'calendar',
                title: 'analytics.navigation.channels',
                route: 'my-channels'
            }
        ]
    },
    children: [
        {
            name: 'analytics-home',
            path: '',
            component: () => import('@/product/analytics/views/Home.vue'),
            meta: {title: 'analytics.titles.home'}
        },
        {
            name: 'analytics-monitor',
            path: 'monitor',
            component: () => import('@/product/analytics/views/Monitor.vue'),
            meta: {title: 'analytics.titles.monitor'}
        },
        {
            name: 'analytics-social',
            path: 'social',
            component: () => import('@/product/analytics/views/Social.vue'),
            meta: {title: 'analytics.titles.social'}
        },
        {
            name: 'analytics-campaign',
            path: 'campaign',
            component: () => import('@/product/analytics/views/Campaign.vue'),
            meta: {title: 'analytics.titles.campaign'}
        },
        {
            name: 'analytics-ticketing',
            path: 'ticketing',
            component: () => import('@/product/analytics/views/Ticketing.vue'),
            meta: {title: 'analytics.titles.ticketing'}
        },
        {
            path: 'channels',
            component: Proxy,
            children: [
                {
                    name: 'my-channels',
                    path: '',
                    component: () => import('@/product/analytics/views/Channels.vue'),
                    meta: {title: 'analytics.titles.channels'}
                },
                {
                    name: 'channel',
                    path: ':id',
                    component: () => import('@/product/analytics/views/crm/channels/channel/ChannelPage.vue'),
                    meta: {title: 'analytics.titles.channel'}
                }
            ]
        },
        {
            name: 'analytics-logs',
            path: 'logs',
            component: () => import('@/product/analytics/views/Logs.vue'),
            meta: {title: 'analytics.titles.logs'}
        }
    ]
});
