import { UserType } from '@fancee/data';
import { useAuthStore } from '@/data/store';
import type { Route } from '..';
import Proxy from '../proxy';

export default (): Route => ({
    path: '/',
    component: Proxy,
    children: [
        {
            path: '/',
            name: 'home',
            redirect: () => {
                const {isAuthenticated, user} = useAuthStore();

                if (isAuthenticated && user) {
                    switch (user.type) {
                        case UserType.Admin:
                            return {name: 'crm-home'};

                        case UserType.Client:
                            return {name: 'client-home'};

                        case UserType.Organization:
                            if (user.activeOrganizationId) {
                                return {name: 'organization-home'};
                            } else {
                                return {name: 'auth-select'};
                            }
                    }
                }

                return {name: 'auth-login'};
            }
        },
        {
            name: 'pre-register',
            path: '/pre-register/:code',
            component: () => import('@/product/ticketing/views/preRegister/SignUp.vue')
        },
        {
            name: 'receipt',
            path: 'order/:id',
            component: () => import('@/route/order/Receipt.vue')
        },
        {
            name: 're',
            path: 'reactivity',
            component: () => import('@/product/ticketing/views/dashboard/generic/development/Reactivity.vue')
        }
    ]
});
