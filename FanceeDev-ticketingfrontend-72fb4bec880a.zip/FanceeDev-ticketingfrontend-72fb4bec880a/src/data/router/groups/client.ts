import { UserType } from '@fancee/data';
import { Route } from '..';
import ticketingLogo from '@/assets/brand/logo-ticketing.svg';

export default (): Route => ({
    path: '/client',
    component: () => import('@/components/ui/Dashboard.vue'),
    meta: {
        accessibleBy: [UserType.Client],
        authorized: true,
        product: {
            logo: ticketingLogo,
            name: 'global.platform.ticketing'
        },
        navigation: [
            {
                icon: 'home',
                title: 'ui.navigation.ticketing.home',
                route: 'client-home'
            },
            {
                icon: 'list',
                title: 'finance.order.title',
                route: 'client-orders'
            },
            {
                icon: 'ticket',
                title: 'event.ticket.title',
                route: 'client-tickets'
            }
        ]
    },
    children: [
        {
            name: 'client-home',
            path: '',
            component: () => import('@/product/ticketing/views/dashboard/client/home/Home.vue'),
            meta: {title: 'ui.navigation.ticketing.home'}
        },
        {
            name: 'client-orders',
            path: 'orders',
            component: () => import('@/product/ticketing/views/dashboard/client/order/Orders.vue'),
            meta: {title: 'finance.order.title'}
        },
        {
            name: 'client-tickets',
            path: 'tickets',
            component: () => import('@/product/ticketing/views/dashboard/client/products/Tickets.vue'),
            meta: {title: 'event.ticket.title'}
        }
    ]
});
