import type { Route } from '..';
import Proxy from '../proxy';

export default (): Route => ({
    path: '/auth',
    component: Proxy,
    children: [
        {
            name: 'auth-login',
            path: 'login',
            component: () => import('@/route/auth/Login.vue'),
            meta: {authorized: false}
        },
        {
            name: 'auth-select',
            path: 'select',
            component: () => import('@/route/auth/SelectOrganization.vue'),
            meta: {authorized: true}
        },
        {
            name: 'auth-register',
            path: 'register',
            component: () => import('@/route/auth/Register.vue'),
            meta: {authorized: false}
        },
        {
            name: 'auth-register-type',
            path: 'register/:type(client|organization)',
            component: () => import('@/route/auth/RegisterType.vue'),
            meta: {authorized: false}
        },
        {
            name: 'auth-forgot-password',
            path: 'forgot-password',
            component: () => import('@/route/auth/ForgotPassword.vue'),
            meta: {authorized: false}
        },
        {
            name: 'auth-forgot-password-reset',
            path: 'password-reset',
            alias: '/forgot-password-reset',
            component: () => import('@/route/auth/ForgotPasswordReset.vue'),
            meta: {authorized: false}
        },
        {
            name: 'auth-verify',
            path: 'verify/:code',
            alias: '/verify-email/:code',
            component: () => import('@/route/auth/VerifyEmail.vue')
        },
        {
            name: 'auth-sign-up',
            path: 'sign-up/:code',
            alias: '/create-account/:code',
            component: () => import('@/route/auth/SignUp.vue')
        },
        {
            path: 'onboarding',
            component: () => import('@/route/onboarding/Onboarding.vue'),
            children: [
                {
                    name: 'onboarding',
                    path: '',
                    component: () => import('@/route/onboarding/OnboardingRedirect.vue')
                },
                {
                    name: 'onboarding-personal',
                    path: 'personal',
                    component: () => import('@/route/onboarding/OnboardingPersonal.vue')
                },
                {
                    name: 'onboarding-company',
                    path: 'company',
                    component: () => import('@/route/onboarding/OnboardingCompany.vue')
                },
                {
                    name: 'onboarding-financial',
                    path: 'financial',
                    component: () => import('@/route/onboarding/OnboardingFinancial.vue')
                },
                {
                    name: 'onboarding-agreement',
                    path: 'agreement',
                    component: () => import('@/route/onboarding/OnboardingAgreement.vue')
                },
                {
                    name: 'onboarding-welcome',
                    path: 'welcome',
                    component: () => import('@/route/onboarding/OnboardingWelcome.vue')
                }
            ]
        }
    ]
});
