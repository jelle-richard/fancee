import { UserType } from '@fancee/data';
import { Route } from '..';
import Proxy from '../proxy';
import ticketingLogo from '@/assets/brand/logo-ticketing.svg';

export default (): Route => ({
    path: '/crm',
    component: () => import('@/components/ui/Dashboard.vue'),
    meta: {
        accessibleBy: [UserType.Admin],
        authorized: true,
        product: {
            logo: ticketingLogo,
            name: 'crm.title'
        },
        navigation: [
            {
                icon: 'home',
                title: 'crm.navigation.home',
                route: 'crm-home'
            },
            {
                icon: 'users',
                title: 'crm.navigation.organizations',
                route: 'organizations',
                userClaim: 'admin.organizationmanagement.list'
            },
            {
                icon: 'credit-card',
                title: 'crm.navigation.paymentMethods',
                route: 'payment-methods',
                userClaim: 'admin.paymentmethod.list'
            },
            {
                icon: 'cart-shopping',
                title: 'crm.navigation.orders',
                route: 'platform-orders',
                userClaim: 'admin.order.list'
            },
            {
                icon: 'calendar-range',
                title: 'crm.navigation.eventPlanning',
                route: 'event-planning',
                userClaim: 'admin.event.list'
            },
            {
                icon: 'receipt',
                title: 'crm.navigation.invoicing',
                route: 'invoicing',
                userClaim: 'admin.invoice.list'
            },
            {
                icon: 'link',
                title: 'crm.navigation.integrations',
                route: 'integrations',
                userClaim: 'admin.crm.integratesoftware'
            },
            {
                icon: 'money-bill-trend-up',
                title: 'crm.navigation.payouts',
                route: 'payouts',
                userClaim: 'admin.crm.payout.export'
            },
            {
                icon: 'user-crown',
                title: 'crm.navigation.adminRegister',
                route: 'admin-register',
                userClaim: 'admin.crm.create.user'
            },
            {
                icon: 'scale-balanced',
                title: 'crm.navigation.balance',
                route: 'balance',
                userClaim: 'admin.crm.balance'
            },
            {
                icon: 'money-bill-transfer',
                title: 'crm.navigation.eventBalance',
                route: 'event-balance',
                userClaim: 'admin.crm.events.balances.list'
            },
            {
                header: 'global.platform.analytics'
            },
            {
                icon: 'calendar',
                title: 'crm.navigation.channels',
                route: 'crm-channels'
            }
        ]
    },
    children: [
        {
            name: 'crm-home',
            path: '',
            component: () => import('@/product/ticketing/views/crm/admin/home/Home.vue'),
            meta: {title: 'crm.home.title'}
        },
        {
            name: 'event-planning',
            path: 'event-planning',
            component: () => import('@/product/ticketing/views/crm/admin/events/PlatformEvents.vue'),
            meta: {title: 'crm.eventPlanning.title'}
        },
        {
            name: 'integrations',
            path: 'integrations',
            component: () => import('@/product/ticketing/views/crm/admin/integrations/IntegrationCards.vue'),
            meta: {title: 'crm.integration.title'}
        },
        {
            name: 'configure-exact',
            path: 'integrations/exact',
            component: () => import('@/product/ticketing/views/crm/admin/integrations/ConfigureExact.vue'),
            meta: {title: 'crm.integration.configureExact'}
        },
        {
            name: 'payouts',
            path: 'payouts',
            component: () => import('@/product/ticketing/views/crm/admin/payouts/PayOutOverview.vue'),
            meta: {title: 'crm.payout.title'}
        },
        {
            name: 'invoicing',
            path: 'invoicing',
            component: () => import('@/product/ticketing/views/crm/admin/invoicing/Invoices.vue'),
            meta: {title: 'crm.invoicing.title'}
        },
        {
            path: 'organizations',
            component: Proxy,
            children: [
                {
                    name: 'organizations',
                    path: '',
                    component: () => import('@/product/ticketing/views/crm/admin/organization/Organizations.vue'),
                    meta: {title: 'crm.organization.title'}
                },
                {
                    path: ':id',
                    component: () => import('@/product/ticketing/views/crm/admin/organization/Organization.vue'),
                    meta: {title: 'crm.organization.title'},
                    children: [
                        {
                            name: 'organization',
                            path: '',
                            component: () => import('@/product/ticketing/views/crm/admin/organization/route/OrganizationAccount.vue')
                        },
                        {
                            name: 'organization-monitoring',
                            path: 'monitoring',
                            component: () => import('@/product/ticketing/views/crm/admin/organization/route/OrganizationMonitoring.vue')
                        },
                        {
                            name: 'organization-permissions',
                            path: 'permissions',
                            component: () => import('@/product/ticketing/views/crm/admin/organization/route/OrganizationPermissions.vue')
                        },
                        {
                            name: 'organization-planning',
                            path: 'planning',
                            component: () => import('@/product/ticketing/views/crm/admin/organization/route/OrganizationEvents.vue')
                        },
                        {
                            name: 'organization-wallet',
                            path: 'wallet',
                            component: () => import('@/product/ticketing/views/crm/admin/organization/route/OrganizationWallet.vue')
                        }
                    ]
                }
            ]
        },
        {
            name: 'platform-orders',
            path: 'orders',
            component: () => import('@/product/ticketing/views/crm/admin/order/Orders.vue'),
            meta: {title: 'crm.order.title'}
        },
        {
            name: 'payment-methods',
            path: 'payment-methods',
            component: () => import('@/product/ticketing/views/crm/admin/payments/PaymentMethods.vue'),
            meta: {title: 'crm.paymentMethod.title'}
        },
        {
            name: 'admin-register',
            path: 'admin-register',
            component: () => import('@/product/ticketing/views/crm/admin/register/RegisterAdmin.vue'),
            meta: {title: 'crm.adminRegister.title'}
        },
        {
            name: 'balance',
            path: 'balance',
            component: () => import('@/product/ticketing/views/crm/admin/balances/BalanceOverview.vue'),
            meta: {title: 'crm.balance.title'}
        },
        {
            name: 'event-balance',
            path: 'event-balance',
            component: () => import('@/product/ticketing/views/crm/admin/balances/EventsBalanceOverview.vue'),
            meta: {title: 'crm.eventBalance.title'}
        },
        {
            path: 'channels',
            component: Proxy,
            children: [
                {
                    name: 'crm-channels',
                    path: '',
                    component: () => import('@/product/analytics/views/Channels.vue'),
                    meta: {title: 'analytics.crm.channel.title'}
                },
                {
                    name: 'crm-channel',
                    path: ':id',
                    component: () => import('@/product/analytics/views/crm/channels/channel/ChannelPage.vue'),
                    meta: {title: 'analytics.crm.channel.title'}
                }
            ]
        }
    ]
});
