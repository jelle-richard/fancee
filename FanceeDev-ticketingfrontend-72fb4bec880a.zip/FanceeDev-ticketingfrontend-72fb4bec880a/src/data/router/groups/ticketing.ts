import { UserType } from '@fancee/data';
import { Route } from '..';
import Proxy from '../proxy';
import ticketingLogo from '@/assets/brand/logo-ticketing.svg';

export default (): Route => ({
    path: '/ticketing',
    component: () => import('@/components/ui/Dashboard.vue'),
    meta: {
        accessibleBy: [UserType.Organization],
        authorized: true,
        product: {
            logo: ticketingLogo,
            name: 'global.platform.ticketing'
        },
        navigation: [
            {
                icon: 'home',
                title: 'ui.navigation.ticketing.home',
                route: 'organization-home'
            },
            {
                icon: 'calendar',
                title: 'event.plural',
                children: [
                    {
                        title: 'event.createEvent',
                        route: 'create-event',
                        userClaim: 'organization.event.configure'
                    },
                    {
                        title: 'event.myEvents',
                        route: 'my-events',
                        userClaim: 'organization.event.list'
                    },
                    {
                        title: 'event.ticket.title',
                        route: 'tickets',
                        userClaim: 'organization.customerinsight.view'
                    },
                    {
                        title: 'event.guestlist.title',
                        route: 'guestlists',
                        userClaim: 'organization.guestlist.details'
                    },
                    {
                        title: 'event.discount.title',
                        route: 'discounts',
                        userClaim: 'organization.discount.list'
                    }
                ]
            },
            {
                icon: 'mobile-notch',
                title: 'app.title',
                children: [
                    {
                        title: 'app.team.title',
                        route: 'app-teams',
                        userClaim: 'organization.appteam.list'
                    },
                    {
                        title: 'app.scanStatistics.title',
                        route: 'scan-statistics',
                        userClaim: 'organization.appteam.list'
                    }
                ]
            },
            {
                icon: 'coin',
                title: 'finance.title',
                children: [
                    {
                        title: 'finance.order.title',
                        route: 'orders',
                        userClaim: 'organization.customerinsight.view'
                    },
                    {
                        title: 'finance.invoice.title',
                        route: 'invoices',
                        userClaim: 'organization.invoice.list'
                    },
                    {
                        title: 'finance.wallet.title',
                        route: 'wallet',
                        userClaim: 'organization.wallet.insights'
                    },
                    {
                        title: 'finance.report.title',
                        route: 'report',
                        userClaim: 'organization.event.details'
                    }
                ]
            },
            {
                icon: 'bullhorn',
                title: 'marketing.title',
                children: [
                    {
                        title: 'marketing.preRegister.title',
                        route: 'pre-registers',
                        userClaim: 'organization.preregister.list'
                    },
                    {
                        title: 'marketing.campaign.title',
                        route: 'campaign-tracking',
                        userClaim: 'organization.campaigns.list'
                    },
                    {
                        title: 'marketing.agenda.title',
                        route: 'agendas'
                    }
                ]
            }
        ]
    },
    children: [
        {
            name: 'organization-home',
            path: '',
            component: () => import('@/product/ticketing/views/dashboard/organization/home/Home.vue'),
            meta: {title: 'ui.pageTitle.home'}
        },
        {
            name: 'sandbox',
            path: 'sandbox',
            component: () => import('@/product/ticketing/views/dashboard/generic/development/Sandbox.vue'),
            meta: {title: 'Sandbox'}
        },
        {
            name: 'documentation',
            path: 'documentation',
            component: () => import('@/product/ticketing/views/dashboard/generic/development/Documentation.vue'),
            meta: {title: 'Documentation'}
        },
        {
            name: 'profile',
            path: 'profile',
            component: () => import('@/product/ticketing/views/dashboard/organization/profile/Profile.vue'),
            meta: {
                title: 'ui.pageTitle.profile',
                accessibleBy: [UserType.Organization]
            }
        },
        {
            path: 'settings',
            component: () => import('@/product/ticketing/views/dashboard/organization/settings/Settings.vue'),
            meta: {
                title: 'ui.pageTitle.settings',
                accessibleBy: [UserType.Organization]
            },
            children: [
                {
                    name: 'default-shop-settings',
                    path: 'default-shop-settings',
                    component: () => import('@/product/ticketing/views/dashboard/organization/settings/DefaultShopSettings.vue')
                },
                {
                    name: 'default-payment-methods',
                    path: 'default-payment-methods',
                    component: () => import('@/product/ticketing/views/dashboard/organization/settings/DefaultPaymentMethodSettings.vue')
                },
                {
                    name: 'blocked-emails',
                    path: 'blocked-emails',
                    component: () => import('@/product/ticketing/views/dashboard/organization/settings/BlockedEmails.vue')
                },
                {
                    name: 'role-assigner',
                    path: 'role-assigner',
                    component: () => import('@/product/ticketing/views/dashboard/organization/settings/RoleAssigner.vue')
                }
            ]
        },
        {
            name: 'faq',
            path: 'faq',
            component: () => import('@/product/ticketing/views/dashboard/generic/explanation/Faq.vue'),
            meta: {title: 'ui.pageTitle.faq'}
        },
        {
            name: 'changelog',
            path: 'changelog',
            component: () => import('@/product/ticketing/views/dashboard/generic/explanation/Changelog.vue'),
            meta: {title: 'ui.pageTitle.whatsNew'}
        },
        {
            name: 'securecodes',
            path: 'securecodes/:eventId/:shopCode',
            component: () => import('@/product/ticketing/views/dashboard/organization/events/securecode/SecureCodes.vue'),
            meta: {
                title: 'ui.pageTitle.secureCodes',
                activeAlias: 'my-events',
                accessibleBy: [UserType.Organization]
            },
        },
        {
            path: 'app',
            component: Proxy,
            meta: {
                accessibleBy: [UserType.Organization]
            },
            children: [
                {
                    name: 'app-teams',
                    path: 'teams',
                    component: () => import('@/product/ticketing/views/dashboard/organization/app/teams/AppTeams.vue'),
                    meta: {title: 'app.team.title'}
                },
                {
                    name: 'scan-statistics',
                    path: 'statistics',
                    component: () => import('@/product/ticketing/views/dashboard/organization/app/teams/Statistics.vue'),
                    meta: {title: 'app.scanStatistics.title'}
                }
            ]
        },
        {
            path: 'events',
            component: Proxy,
            meta: {
                accessibleBy: [UserType.Organization]
            },
            children: [
                {
                    name: 'my-events',
                    path: '',
                    component: () => import('@/product/ticketing/views/dashboard/organization/events/MyEvents.vue'),
                    meta: {title: 'event.myEvents'}
                },
                {
                    path: 'create-event',
                    component: () => import('@/product/ticketing/views/dashboard/organization/events/create/CreateEvent.vue'),
                    meta: {
                        activeAlias: 'create-event',
                        title: 'event.createEvent'
                    },
                    children: [
                        {
                            name: 'create-event',
                            path: '',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventType.vue')
                        },
                        {
                            name: 'create-event-setup-seating',
                            path: 'setup-seating',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventSetupSeating.vue')
                        },
                        {
                            name: 'create-event-details',
                            path: ':eventId/details',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventDetails.vue')
                        }
                    ]
                },
                {
                    path: 'create-event/:eventId',
                    component: () => import('@/product/ticketing/views/dashboard/organization/events/create/CreateEvent.vue'),
                    meta: {
                        activeAlias: 'create-event',
                        title: 'event.manageEvent'
                    },
                    children: [
                        {
                            name: 'create-event-products',
                            path: 'products',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventProducts.vue')
                        },
                        {
                            name: 'create-event-shops',
                            path: 'shops',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventShops.vue')
                        },
                        {
                            name: 'create-event-payment',
                            path: 'payment',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventPayment.vue')
                        },
                        {
                            name: 'create-event-mailing',
                            path: 'mailing',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventMailing.vue')
                        },
                        {
                            name: 'create-event-design',
                            path: 'design',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventDesign.vue')
                        },
                        {
                            name: 'create-event-publish',
                            path: 'publish',
                            component: () => import('@/product/ticketing/views/dashboard/organization/events/create/route/CreateEventPublish.vue')
                        }
                    ]
                },
                {
                    name: 'discounts',
                    path: 'discounts',
                    component: () => import('@/product/ticketing/views/dashboard/organization/events/discount/Discounts.vue'),
                    meta: {title: 'event.discount.title'}
                },
                {
                    name: 'guestlists',
                    path: 'guestlists',
                    component: () => import('@/product/ticketing/views/dashboard/organization/events/guestlist/Guestlist.vue'),
                    meta: {title: 'event.guestlist.title'}
                },
                {
                    name: 'manage-guestlist',
                    path: 'guestlists/manage/:id',
                    component: () => import('@/product/ticketing/views/dashboard/organization/events/guestlist/route/ManageEventGuestlist.vue'),
                    meta: {
                        activeAlias: 'guestlists',
                        title: 'event.guestlist.manage.title'
                    }
                },
                {
                    name: 'tickets',
                    path: 'tickets',
                    component: () => import('@/product/ticketing/views/dashboard/organization/events/tickets/Tickets.vue'),
                    meta: {title: 'event.ticket.title'}
                }
            ]
        },
        {
            path: 'finance',
            component: Proxy,
            meta: {
                accessibleBy: [UserType.Organization]
            },
            children: [
                {
                    name: 'invoices',
                    path: 'invoices',
                    component: () => import('@/product/ticketing/views/dashboard/organization/finance/invoice/Invoices.vue'),
                    meta: {title: 'finance.invoice.title'}
                },
                {
                    name: 'orders',
                    path: 'orders',
                    component: () => import('@/product/ticketing/views/dashboard/organization/finance/order/Orders.vue'),
                    meta: {title: 'finance.order.title'}
                },
                {
                    name: 'wallet',
                    path: 'wallet',
                    component: () => import('@/product/ticketing/views/dashboard/organization/finance/wallet/Wallet.vue'),
                    meta: {title: 'finance.wallet.title'}
                },
                {
                    name: 'report',
                    path: 'report',
                    component: () => import('@/product/ticketing/views/dashboard/organization/finance/report/RevenueReport.vue'),
                    meta: {title: 'finance.report.title'}
                }
            ]
        },
        {
            path: 'marketing',
            component: Proxy,
            meta: {
                accessibleBy: [UserType.Organization]
            },
            children: [
                {
                    path: 'pre-registers',
                    component: Proxy,
                    children: [
                        {
                            name: 'pre-registers',
                            path: '',
                            component: () => import('@/product/ticketing/views/dashboard/organization/marketing/preRegister/PreRegisters.vue'),
                            meta: {title: 'marketing.preRegister.title'}
                        },
                        {
                            name: 'create-pre-register',
                            path: 'create',
                            component: () => import('@/product/ticketing/views/dashboard/organization/marketing/preRegister/ConfigurePreRegister.vue'),
                            meta: {title: 'marketing.preRegister.title'}
                        },
                        {
                            name: 'configure-pre-register',
                            path: 'configure/:code',
                            component: () => import('@/product/ticketing/views/dashboard/organization/marketing/preRegister/ConfigurePreRegister.vue'),
                            meta: {title: 'marketing.preRegister.title'}
                        }
                    ]
                },
                {
                    name: 'campaign-tracking',
                    path: 'campaings',
                    component: () => import('@/product/ticketing/views/dashboard/organization/marketing/campaignTracking/Campaigns.vue'),
                    meta: {title: 'marketing.campaign.title'}
                },
                {
                    path: 'agendas',
                    component: Proxy,
                    children: [
                        {
                            name: 'agendas',
                            path: '',
                            component: () => import('@/product/ticketing/views/dashboard/organization/marketing/agenda/Agendas.vue'),
                            meta: {title: 'marketing.agenda.title'}
                        },
                        {
                            name: 'create-agenda',
                            path: 'create',
                            component: () => import('@/product/ticketing/views/dashboard/organization/marketing/agenda/AgendaConfigurator.vue'),
                            meta: {title: 'marketing.agenda.title'}
                        },
                        {
                            name: 'configure-agenda',
                            path: 'configure/:id',
                            component: () => import('@/product/ticketing/views/dashboard/organization/marketing/agenda/AgendaConfigurator.vue'),
                            meta: {title: 'marketing.agenda.title'}
                        }
                    ]
                }
            ]
        }
    ]
});
