import type { UserType } from '@fancee/data';
import type { IconNames } from '@fancee/flux';
import type { NavigationGuard, RouteComponent, RouteRecordRedirectOption } from 'vue-router';
import type { Claim } from '@/data';

export interface BasicRoute {
    readonly component: RouteComponent | (() => Promise<RouteComponent>);
    readonly meta?: Omit<RouteMeta, 'navigation' | 'product'>;
    readonly path: string;
    readonly alias?: string;
    readonly beforeEnter?: NavigationGuard;
}

export interface GroupRoute extends BasicRoute {
    readonly children: Route[];
}

export interface MasterRoute extends GroupRoute {
    readonly meta?: RouteMeta;
}

export interface NamedRoute extends BasicRoute {
    readonly name: string;
}

export interface RedirectRoute {
    readonly path: string;
    readonly redirect: RouteRecordRedirectOption;
}

export interface RouteMeta extends Record<string | number | symbol, unknown> {
    readonly accessibleBy?: UserType[];
    readonly activeAlias?: string | string[];
    readonly authorized?: boolean;
    readonly navigation?: NavEntry[];
    readonly product?: {
        readonly logo: string;
        readonly name: string;
    };
    readonly title?: string;
}

export interface NavElement {
    readonly userClaim?: Claim;
    readonly userType?: UserType;
}

export interface NavHeader extends NavElement {
    readonly header: string;
}

export interface NavLink extends NavElement {
    readonly icon?: IconNames;
    readonly title: string;
}

export interface NavItem extends NavLink {
    readonly route?: string;
    readonly routeParams?: Record<string, string | number | null>;
}

export interface NavParent extends NavLink {
    readonly children?: NavItem[];
}

export interface NavSeparator extends NavElement {
    readonly separator: true;
}

export type NavEntry = NavHeader | NavItem | NavParent | NavSeparator;
export type Route = GroupRoute | MasterRoute | NamedRoute | RedirectRoute;
