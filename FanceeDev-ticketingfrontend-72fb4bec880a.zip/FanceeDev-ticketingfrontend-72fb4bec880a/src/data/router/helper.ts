import type { GroupRoute, NamedRoute, NavEntry, NavHeader, NavItem, NavParent, NavSeparator, Route, RouteMeta } from './types';

export function isGroupRoute(route: Route): route is GroupRoute {
    return 'children' in route;
}

export function isNamedRoute(route: Route): route is NamedRoute {
    return 'name' in route;
}

export function isRouteMeta(meta: unknown): meta is RouteMeta {
    return !!meta && typeof meta === 'object' && Object.entries(meta).length > 0;
}

export function isNavHeader(navEntry: NavEntry): navEntry is NavHeader {
    return 'header' in navEntry;
}

export function isNavItem(navEntry: NavEntry): navEntry is NavItem {
    return 'route' in navEntry;
}

export function isNavParent(navEntry: NavEntry): navEntry is NavParent {
    return 'children' in navEntry;
}

export function isNavSeparator(navEntry: NavEntry): navEntry is NavSeparator {
    return 'separator' in navEntry && navEntry.separator;
}
