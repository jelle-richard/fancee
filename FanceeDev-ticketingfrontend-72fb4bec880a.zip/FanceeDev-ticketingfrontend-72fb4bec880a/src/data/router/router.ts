import { createRouter, createWebHistory } from 'vue-router';
import { accessibleByGuard, authenticatedGuard, combinationGuard, ticketingContractGuard } from './guards';
import * as groups from './groups';

const router = createRouter({
    history: createWebHistory(),
    scrollBehavior: () => ({top: 0, left: 0}) as const,
    routes: [
        groups.root(),
        groups.auth(),
        groups.analytics(),
        groups.client(),
        groups.crm(),
        groups.ticketing(),
        {
            path: '/not-found',
            component: () => import('@/product/ticketing/views/error/Error404.vue'),
            name: 'error-404'
        },
        {
            path: '/:pathMatch(.*)*',
            component: () => import('@/product/ticketing/views/error/Error404.vue')
        }
    ]
});

router.onError((err) => {
    if (!err.message.includes('Failed to fetch dynamically imported module')) {
        return;
    }

    window.location.reload();
});

router.beforeEach(combinationGuard(authenticatedGuard, accessibleByGuard, ticketingContractGuard));

export default router;
