import { DateTimeAdapter, UserType } from '@fancee/data';
import { showSnackbar } from '@fancee/flux';
import type { NavigationGuard, NavigationGuardNext, RouteLocationNormalizedLoaded } from 'vue-router';
import { t } from '@/data/i18n';
import { useAuthStore, usePlatformStore } from '@/data/store';
import { isRouteMeta } from './helper';
import { ERROR_SNACKBAR_DURATION_MS } from '@/data';

export function combinationGuard(...guards: NavigationGuard[]): NavigationGuard {
    let current = 0;

    return (to, from, next) => {
        const _next: NavigationGuardNext = (args?: unknown) => {
            if (args) {
                next(args);
                return;
            }

            const guard = guards[current];
            current++;

            if (guard) {
                guard(to, from, _next);
            } else {
                next();
            }
        };

        current = 0;
        _next();
    };
}

export function accessibleByGuard(to: RouteLocationNormalizedLoaded, _: RouteLocationNormalizedLoaded, next: NavigationGuardNext): void {
    const {manageableOrganizations, userType, claims} = useAuthStore();

    for (const match of to.matched) {
        if (!isRouteMeta(match.meta)) {
            continue;
        }

        if (!match.meta.accessibleBy || match.meta.accessibleBy.length === 0) {
            continue;
        }

        if (!userType) {
            next({name: 'auth-login'});
            return;
        }

        if (manageableOrganizations && manageableOrganizations.length > 0 && userType === UserType.Client) {
            next();
            return;
        }

        if (!match.meta.accessibleBy.includes(userType)) {
            showSnackbar({
                color: 'danger',
                duration: ERROR_SNACKBAR_DURATION_MS,
                icon: 'lock',
                title: t('ui.notAllowed.title'),
                message: t('ui.notAllowed.message')
            });

            next({name: 'home'});
            return;
        }
    }

    next();
}

export function authenticatedGuard(to: RouteLocationNormalizedLoaded, _: RouteLocationNormalizedLoaded, next: NavigationGuardNext): void {
    const {token, user, validUntil, logout} = useAuthStore();

    for (const match of to.matched) {
        if (!isRouteMeta(match.meta)) {
            continue;
        }

        if (match.meta.authorized === true && !user) {
            next({name: 'auth-login', query: {to: to.fullPath}});
            return;
        }

        if (match.meta.authorized === false && user) {
            next({name: 'home'});
            return;
        }

        if (!user) {
            continue;
        }

        const duration = validUntil ? DateTimeAdapter.parseDateTimeStringToLocal(validUntil).diff(DateTimeAdapter.now()).as('seconds') : 0;

        if (!token || token.length === 0 || duration <= 0) {
            logout();
            next({name: 'auth-login', query: {to: to.fullPath}});
            return;
        }
    }

    next();
}

export function ticketingContractGuard(to: RouteLocationNormalizedLoaded, _: RouteLocationNormalizedLoaded, next: NavigationGuardNext): void {
    const {user, userType} = useAuthStore();

    if (!user) {
        next();
        return;
    }

    if (userType !== UserType.Organization) {
        next();
        return;
    }

    if (!user.activeOrganizationId && to.name !== 'auth-select') {
        next({name: 'auth-select'});
        return;
    }

    const {organizationContract} = usePlatformStore();

    for (const match of to.matched) {
        if (match.name === undefined) {
            continue;
        }

        if (match.name && typeof match.name === 'string') {
            if (match.name.startsWith('auth')) {
                continue;
            }

            if (match.name.startsWith('onboarding')) {
                continue;
            }
        }

        if (userType === UserType.Organization && !organizationContract?.signed) {
            next({name: 'onboarding'});
            return;
        }
    }

    next();
}
