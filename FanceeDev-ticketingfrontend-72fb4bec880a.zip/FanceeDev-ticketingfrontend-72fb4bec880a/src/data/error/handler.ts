import { isRequestError } from '@fancee/client';
import { showSnackbar } from '@fancee/flux';
import { isNavigationFailure } from 'vue-router';
import { useRollbar } from '@/composable';
import { FanceeForbiddenError, FanceeHandledError, FanceeUnauthorizedError } from '@/data/error';
import { t } from '@/data/i18n';
import { useAuthStore } from '@/data/store';
import { ERROR_SNACKBAR_DURATION_MS } from '@/data';

export function globalErrorHandler(err: unknown): void {
    // note(Bas): This error is already handled by an onError callback function.
    if (err instanceof FanceeHandledError) {
        return;
    }

    if (err instanceof FanceeForbiddenError) {
        showSnackbar({
            color: 'danger',
            duration: ERROR_SNACKBAR_DURATION_MS,
            icon: 'lock',
            message: t('ui.notAllowed.message'),
            title: t('ui.notAllowed.title')
        });

        return;
    }

    if (err instanceof FanceeUnauthorizedError) {
        const {user, logout, showReauthenticateOverlay} = useAuthStore();

        if (!user) {
            logout();
            requestAnimationFrame(() => window.location.href ='/auth/login');
            return;
        }

        showReauthenticateOverlay();
        return;
    }

    // note(Bas): Navigation failures are not relevant.
    if (isNavigationFailure(err)) {
        return;
    }

    // note(Bas): It's probably alright.
    if (isRequestError(err) && err.message === 'Request failed without errors.') {
        return;
    }

    const rollbar = useRollbar();
    rollbar.error(err as Error);

    console.error(err);
}
