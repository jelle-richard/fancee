export class FanceeHandledError extends Error {
}
