export class FanceeUnauthorizedError extends Error {
}
