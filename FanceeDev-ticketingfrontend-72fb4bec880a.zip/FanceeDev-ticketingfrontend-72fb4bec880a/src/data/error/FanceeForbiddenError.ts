export class FanceeForbiddenError extends Error {
}
