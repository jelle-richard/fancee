import { BaseResponse, BaseService, Paginated, QueryString } from '@fancee/client';
import { DateTime } from 'luxon';
import { BestDayToPost, BestHourToPost, Keyword, Post } from '@/data/dto/analytics/posts';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';
import { BestDayToPostAdapter } from '@/data/adapter/analytics/posts/BestDayToPostAdapter';
import { BestHourToPostAdapter } from '@/data/adapter/analytics/posts/BestHourToPostAdapter';
import { KeywordAdapter } from '@/data/adapter/analytics/posts/KeywordAdapter';
import { PostAdapter } from '@/data/adapter/analytics/posts/PostAdapter';
import { LUXON_DATE_FORMAT } from '@/data';

export class PostsService extends BaseService {
    async getBestDayToPostOn(channelId: string, category: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<BestDayToPost[]>> {
        return await this
            .request('/posts/best-day-of-week', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('category', category)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(BestDayToPostAdapter.parseFromObject);
    }

    async getBestHourToPostOn(channelId: string, category: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<BestHourToPost[]>> {
        return await this
            .request('/posts/best-time-hour', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('category', category)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(BestHourToPostAdapter.parseFromObject);
    }

    async getTopKeywords(channelId: string, category: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<Keyword[]>> {
        return await this
            .request('/posts/top-keywords', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('category', category)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(KeywordAdapter.parseFromObject);
    }

    async getTopPostsPaginated(channelId: string, category: string, pageSize: number, page: number, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<Paginated<Post>>> {
        return await this
            .request('/posts/top', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('page', page)
                .append('pageSize', pageSize)
                .append('category', category)
                .append('options.channelId', channelId)
                .append('options.startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('options.endDate', endDate.toFormat(LUXON_DATE_FORMAT)))
            .runPaginatedAdapter(PostAdapter.parseFromObject);
    }
}
