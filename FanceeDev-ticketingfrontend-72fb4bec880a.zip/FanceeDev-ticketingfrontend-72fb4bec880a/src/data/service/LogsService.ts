import { BaseResponse, BaseService, Paginated, QueryString } from '@fancee/client';
import { Log } from '@/data/dto/analytics/logs/Log';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';
import { LogAdapter } from '@/data/adapter/analytics/logs/LogAdapter';

export class LogsService extends BaseService {
    async getPaginatedList(pageSize: number, page: number): Promise<BaseResponse<Paginated<Log>>> {
        return await this
            .request('/logs', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('pageSize', pageSize)
                .append('page', page))
            .runPaginatedAdapter(LogAdapter.parseFromObject);
    }
}
