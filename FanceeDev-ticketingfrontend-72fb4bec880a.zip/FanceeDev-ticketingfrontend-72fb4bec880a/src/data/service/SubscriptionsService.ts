import { BaseResponse, BaseService, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { Channel } from '@/data/dto/analytics/channels';
import { GenericEntry, Subscription } from '@/data/dto/analytics/subscriptions';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';
import { GenericEntryAdapter } from '@/data/adapter/analytics/subscriptions/GenericEntryAdapter';
import { SubscriptionAdapter } from '@/data/adapter/analytics/subscriptions/SubscriptionAdapter';
import { ConnectionAdapter } from '@/data/adapter/analytics/logs/ConnectionAdapter';
import { Connection } from '@/data/dto/analytics/logs/Connection';
import { DateTime } from 'luxon';
import { LUXON_DATE_FORMAT } from '@/data';

export class SubscriptionsService extends BaseService {
    async subscriptions(channel: Channel): Promise<BaseResponse<Subscription[]>> {
        return await this
            .request(`/subscriptions`, AnalyticsClient.instance)
            .queryString(QueryString.builder()
                .append('channelId', channel.id)
            )
            .bearerToken()
            .runArrayAdapter(SubscriptionAdapter.parseFromObject);
    }

    async update(id: string): Promise<HttpStatusCode> {
        return await this
            .request(`/subscriptions/${id}/update`, AnalyticsClient.instance)
            .method(HttpMethod.Put)
            .bearerToken()
            .runStatusCode();
    }

    async updateAll(channelId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/subscriptions/update`, AnalyticsClient.instance)
            .queryString(QueryString.builder()
                .append('channelId', channelId)
            )
            .bearerToken()
            .method(HttpMethod.Put)
            .runStatusCode();
    }

    async entries(subscriptionId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<GenericEntry[]>> {
        return await this
            .request(`/subscriptions/${subscriptionId}/entries`, AnalyticsClient.instance)
            .queryString(QueryString.builder()
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .bearerToken()
            .runArrayAdapter(GenericEntryAdapter.parseFromObject);
    }

    async connections(subscription: Subscription, page: number, pageSize: number): Promise<BaseResponse<Paginated<Connection>>> {
        return await this
            .request(`/subscriptions/${subscription.id}/connections`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('page', page)
                .append('pageSize', pageSize))
            .runPaginatedAdapter(ConnectionAdapter.parseFromObject);
    }
}
