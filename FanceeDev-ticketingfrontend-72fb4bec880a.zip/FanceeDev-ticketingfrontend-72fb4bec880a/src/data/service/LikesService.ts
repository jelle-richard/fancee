import { BaseResponse, BaseService, QueryString } from '@fancee/client';
import { DateTime } from 'luxon';
import { AgeLike, EmotionLike, GenderLike, GeoLike } from '@/data/dto/analytics/likes';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';
import { GeoLikeAdapter } from '@/data/adapter/analytics/likes/GeoLikeAdapter';
import { EmotionLikeAdapter } from '@/data/adapter/analytics/likes/EmotionLikeAdapter';
import { GenderLikeAdapter } from '@/data/adapter/analytics/likes/GenderLikeAdapter';
import { AgeLikeAdapter } from '@/data/adapter/analytics/likes/AgeLikeAdapter';
import { LUXON_DATE_FORMAT } from '@/data';


export class LikesService extends BaseService {
    async getGeoLikes(channelId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<GeoLike[]>> {
        return await this
            .request('/likes/geo', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(GeoLikeAdapter.parseFromObject);
    }

    async getEmotionLikes(channelId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<EmotionLike[]>> {
        return await this
            .request('/likes/emotion', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(EmotionLikeAdapter.parseFromObject);
    }

    async getGenderLikes(channelId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<GenderLike[]>> {
        return await this
            .request('/likes/gender', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(GenderLikeAdapter.parseFromObject);
    }

    async getAgeLikes(channelId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<AgeLike[]>> {
        return await this
            .request('/likes/age', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(AgeLikeAdapter.parseFromObject);
    }
}
