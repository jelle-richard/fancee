import { DateTime } from 'luxon';
import { BaseResponse, BaseService, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { Channel, ChannelReach, ChannelSettings, CreateChannelRequest, CreateChannelResponse } from '@/data/dto/analytics/channels';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';
import { ChannelReachAdapter } from '@/data/adapter/analytics/channels/ChannelReachAdapter';
import { CreateChannelResponseAdapter } from '@/data/adapter/analytics/channels/CreateChannelResponseAdapter';
import { ChannelAdapter } from '@/data/adapter/analytics/channels/ChannelAdapter';
import { ChannelSettingsAdapter } from '@/data/adapter/analytics/channels/ChannelSettingsAdapter';
import { LUXON_DATE_FORMAT } from '@/data';

export class ChannelsService extends BaseService {
    async getPaginatedList(pageSize: number, page: number): Promise<BaseResponse<Paginated<Channel>>> {
        return await this
            .request('/channels', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('pageSize', pageSize)
                .append('page', page))
            .runPaginatedAdapter(ChannelAdapter.parseFromObject);
    }

    async getPaginatedTable(pageSize: number, page: number, orderBy: string | null, orderByAscending: boolean): Promise<BaseResponse<Paginated<Channel>>> {
        return await this
            .request('/channels/table', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('page', page)
                .append('pageSize', pageSize)
                .append('options.orderBy', orderBy ?? 'CreatedOn')
                .append('options.orderByAscending', orderByAscending))
            .runPaginatedAdapter(ChannelAdapter.parseFromObject);
    }

    async single(channelId: string): Promise<BaseResponse<Channel>> {
        return await this
            .request(`/channels/${channelId}`, AnalyticsClient.instance)
            .bearerToken()
            .runAdapter(ChannelAdapter.parseFromObject);
    }

    async settings(channelId: string): Promise<BaseResponse<ChannelSettings>> {
        return await this
            .request(`/channelsettings/${channelId}`, AnalyticsClient.instance)
            .bearerToken()
            .runAdapter(ChannelSettingsAdapter.parseFromObject);
    }

    async create(channelRequest: CreateChannelRequest): Promise<BaseResponse<CreateChannelResponse>> {
        return await this
            .request('/channels', AnalyticsClient.instance)
            .bearerToken()
            .body(channelRequest, 'application/json-patch+json')
            .method(HttpMethod.Post)
            .runAdapter(CreateChannelResponseAdapter.parseFromObject);
    }

    async delete(channel: Channel): Promise<HttpStatusCode> {
        return await this
            .request(`/channels/${channel.id}`, AnalyticsClient.instance)
            .bearerToken()
            .method(HttpMethod.Delete)
            .runStatusCode();
    }

    async refresh(channel: Channel): Promise<HttpStatusCode> {
        return await this
            .request(`/channels/${channel.id}/update`, AnalyticsClient.instance)
            .bearerToken()
            .method(HttpMethod.Put)
            .runStatusCode();
    }

    async getReach(channelId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<ChannelReach>> {
        return await this
            .request('/channelinfo/reach', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT)))
            .runAdapter(ChannelReachAdapter.parseFromObject);
    }
}
