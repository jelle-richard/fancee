import { BaseResponse, BaseService, type BlobResponse, Paginated, QueryString } from '@fancee/client';
import { DateTime } from 'luxon';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';
import { Channel } from '@/data/dto/analytics/channels';
import { Keyword } from '@/data/dto/analytics/posts';
import { AgeByGenderItem, AverageCompletionTimes, AveragePriceItem, SumAgeAndGenderItem, SumCampaignAgeGenderItem, SumCampaignItem, SumCommentsGroup, SumCommentsItem, SumCountryItem, SumEmotionsGroup, SumEngagementGroup, SumEngagementItem, SumLostAndGainedGroup, SumLostAndGainedItem, SumPostItem, SumResponse } from '@/data/dto/analytics/dashboard';
import { SumAgeAndGenderResponseAdapter, SumCampaignAdapter, SumCampaignAgeAndGenderAdapter, SumCommentsResponseAdapter, SumCountryAdapter, SumEmotionsResponseAdapter, SumEngagementResponseAdapter, SumLostAndGainedResponseAdapter, SumPostAdapter, AverageAdapter } from '@/data/adapter/analytics/dashboard';
import { KeywordAdapter } from '@/data/adapter/analytics/posts/KeywordAdapter';
import { LUXON_DATE_FORMAT } from '@/data';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class DashboardService extends BaseService {
    async getSumFollowers(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumResponse<SumLostAndGainedGroup>>> {
        return await this
            .request(`/dashboard/followers`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runAdapter(SumLostAndGainedResponseAdapter.parseFromObject);
    }

    async getSumFollowersChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumLostAndGainedItem>[]>> {
        return await this
            .request(`/dashboard/followers/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumLostAndGainedResponseAdapter.parseFromChart);
    }

    async getSumReach(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumResponse<SumLostAndGainedGroup>>> {
        return await this
            .request(`/dashboard/reach`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runAdapter(SumLostAndGainedResponseAdapter.parseFromObject);
    }

    async getSumReachChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumLostAndGainedItem>[]>> {
        return await this
            .request(`/dashboard/reach/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumLostAndGainedResponseAdapter.parseFromChart);
    }

    async getSumEngagement(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumResponse<SumEngagementGroup>>> {
        return await this
            .request(`/dashboard/engagement`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runAdapter(SumEngagementResponseAdapter.parseFromObject);
    }

    async getSumEngagementChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumEngagementItem>[]>> {
        return await this
            .request(`/dashboard/engagement/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumEngagementResponseAdapter.parseFromChart);
    }

    async getSumComments(channels: Channel[], startDate: DateTime, endDate: DateTime, by: 'by_day' | 'by_hour'): Promise<BaseResponse<SumResponse<SumCommentsGroup>>> {
        return await this
            .request(`/dashboard/comments_${by}`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runAdapter(SumCommentsResponseAdapter.parseFromObject);
    }

    async getSumCommentsChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumCommentsItem>[]>> {
        return await this
            .request(`/dashboard/comments/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumCommentsResponseAdapter.parseFromChart);
    }

    async getSumEmotions(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumResponse<SumEmotionsGroup>>> {
        return await this
            .request(`/dashboard/emotions`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runAdapter(SumEmotionsResponseAdapter.parseFromObject);
    }

    async getSumGender(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumAgeAndGenderItem[]>> {
        return await this
            .request(`/dashboard/gender/sum`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumAgeAndGenderResponseAdapter.parseFromObject);
    }

    async getSumGenderChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumAgeAndGenderItem>[]>> {
        return await this
            .request(`/dashboard/gender/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumAgeAndGenderResponseAdapter.parseFromChart);
    }

    async getSumAge(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumAgeAndGenderItem[]>> {
        return await this
            .request(`/dashboard/age`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumAgeAndGenderResponseAdapter.parseFromObject);
    }

    async getSumAgeChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumAgeAndGenderItem>[]>> {
        return await this
            .request(`/dashboard/age/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumAgeAndGenderResponseAdapter.parseFromChart);
    }

    async getSumCountries(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumCountryItem[]>> {
        return await this
            .request(`/dashboard/countries`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumCountryAdapter.parseFromObject);
    }

    async getSumCountriesChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumCountryItem>[]>> {
        return await this
            .request(`/dashboard/countries/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumCountryAdapter.parseFromChart);
    }

    async getSumKeywords(keywordType: 'hashtags' | 'mentions' | 'captions', channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<Keyword[]>> {
        return await this
            .request(`/dashboard/${keywordType}`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(KeywordAdapter.parseFromObject);
    }

    async getSumKeywordsChart(keywordType: 'hashtags' | 'mentions' | 'captions', channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<Keyword>[]>> {
        return await this
            .request(`/dashboard/${keywordType}/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(KeywordAdapter.parseFromChart);
    }

    async getSumCampaigns(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumCampaignItem>> {
        return await this
            .request('/dashboard/campaigns', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT)))
            .runAdapter(SumCampaignAdapter.parseFromObject);
    }

    async getSumPostsPaginated(channels: Channel[], startDate: DateTime, endDate: DateTime, orderBy: string | null, orderByAscending: boolean, pageSize: number, page: number): Promise<BaseResponse<Paginated<SumPostItem>>> {
        return await this
            .request('/dashboard/posts', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('page', page)
                .append('pageSize', pageSize)
                .appendArray('options.channelIds', channels.map(s => s.id))
                .append('options.orderBy', orderBy ?? 'Date')
                .append('options.orderByAscending', orderByAscending)
                .append('options.startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('options.endDate', endDate.toFormat(LUXON_DATE_FORMAT)))
            .runPaginatedAdapter(SumPostAdapter.parseFromObject);
    }

    async getSumPostsChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumPostItem>[]>> {
        return await this
            .request(`/dashboard/posts/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumPostAdapter.parseFromChart);
    }

    async getSumCampaignsPaginated(channels: Channel[], startDate: DateTime, endDate: DateTime, orderBy: string | null, orderByAscending: boolean, pageSize: number, page: number): Promise<BaseResponse<Paginated<SumCampaignItem>>> {
        return await this
            .request('/dashboard/campaigns/list', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('page', page)
                .append('pageSize', pageSize)
                .appendArray('options.channelIds', channels.map(s => s.id))
                .append('options.orderBy', orderBy ?? 'Date')
                .append('options.orderByAscending', orderByAscending)
                .append('options.startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('options.endDate', endDate.toFormat(LUXON_DATE_FORMAT)))
            .runPaginatedAdapter(SumCampaignAdapter.parseFromObject);
    }

    async getSumCampaignsChart(channels: Channel[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumChart<SumCampaignItem>[]>> {
        return await this
            .request(`/dashboard/campaigns/chart`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('channelIds', channels.map(s => s.id))
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT))
            )
            .runArrayAdapter(SumCampaignAdapter.parseFromChart);
    }

    async getSingleSumCampaign(channelId: string, campaignId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumCampaignItem[]>> {
        return await this
            .request(`/dashboard/campaigns/${campaignId}/`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat(LUXON_DATE_FORMAT))
                .append('endDate', endDate.toFormat(LUXON_DATE_FORMAT)))
            .runArrayAdapter(SumCampaignAdapter.parseFromObject);
    }

    async getSumCampaignAge(channelId: string, campaignId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumCampaignAgeGenderItem[]>> {
        return await this
            .request(`/dashboard/campaigns/${campaignId}/age`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat('yyyy-MM-dd'))
                .append('endDate', endDate.toFormat('yyyy-MM-dd')))
            .runArrayAdapter(SumCampaignAgeAndGenderAdapter.parseFromObject);
    }

    async getSumCampaignGender(channelId: string, campaignId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumCampaignAgeGenderItem[]>> {
        return await this
            .request(`/dashboard/campaigns/${campaignId}/gender`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat('yyyy-MM-dd'))
                .append('endDate', endDate.toFormat('yyyy-MM-dd')))
            .runArrayAdapter(SumCampaignAgeAndGenderAdapter.parseFromObject);
    }

    async getSumCampaignAgeAndGender(channelId: string, campaignId: string, startDate: DateTime, endDate: DateTime): Promise<BaseResponse<SumCampaignAgeGenderItem[]>> {
        return await this
            .request(`/dashboard/campaigns/${campaignId}/age-and-gender`, AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .append('channelId', channelId)
                .append('startDate', startDate.toFormat('yyyy-MM-dd'))
                .append('endDate', endDate.toFormat('yyyy-MM-dd')))
            .runArrayAdapter(SumCampaignAgeAndGenderAdapter.parseFromObject);
    }

    async getAveragePrices(organizationId: string, eventIds: string[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<AveragePriceItem[]>> {
        return await this
            .request('/eventanalytics/average/price/event', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('EventIds', eventIds)
                .append('OrganizationId', organizationId)
                .append('StartDate', startDate.toFormat('yyyy-MM-dd'))
                .append('EndDate', endDate.toFormat('yyyy-MM-dd')))
            .runArrayAdapter(AverageAdapter.parseAveragePriceItemFromObject);
    }

    async getGendersByAgeGroup(organizationId: string, eventIds: string[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<AgeByGenderItem[]>> {
        return await this
            .request('/clientanalytics/buyer/profiles', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('EventIds', eventIds)
                .append('OrganizationId', organizationId)
                .append('StartDate', startDate.toFormat('yyyy-MM-dd'))
                .append('EndDate', endDate.toFormat('yyyy-MM-dd')))
            .runArrayAdapter(SumAgeAndGenderResponseAdapter.parseAgeGroupAndGenderFromObject);
    }

    async getAverageTimes(organizationId: string, eventIds: string[], startDate: DateTime, endDate: DateTime): Promise<BaseResponse<AverageCompletionTimes[]>> {
        return await this
            .request('/eventanalytics/average/times/event', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('EventIds', eventIds)
                .append('OrganizationId', organizationId)
                .append('StartDate', startDate.toFormat('yyyy-MM-dd'))
                .append('EndDate', endDate.toFormat('yyyy-MM-dd')))
            .runArrayAdapter(AverageAdapter.parseAverageCompletionTimesFromObject);
    }

    async buyerProfilesExport(organizationId: string, eventIds: string[], startDate: DateTime, endDate: DateTime): Promise<BlobResponse> {
        return await this
            .request('/clientanalytics/buyer/profiles/export', AnalyticsClient.instance)
            .bearerToken()
            .queryString(QueryString.builder()
                .appendArray('EventIds', eventIds)
                .append('OrganizationId', organizationId)
                .append('StartDate', startDate.toFormat('yyyy-MM-dd'))
                .append('EndDate', endDate.toFormat('yyyy-MM-dd')))
            .fetchBlob();
    }
}
