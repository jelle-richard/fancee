import { createPinia, setActivePinia } from 'pinia';
import { initializeApi } from '@/data/api';
import useAuthStore from './auth';
import useCreateEventStore from './createEvent';
import usePlatformStore from './platform';
import useUiStore from './ui';

export {
    defineStore,
    storeToRefs,
    useStore
} from './helper';

export {
    useAuthStore,
    useCreateEventStore,
    usePlatformStore,
    useUiStore
};

function initializeStores(): void {
    const {initialize: initializeAuth} = useAuthStore();
    const {initialize: initializePlatform} = usePlatformStore();
    const {initialize: initializeUi} = useUiStore();

    initializeAuth();
    initializePlatform();
    initializeUi();
}

const store = createPinia();
setActivePinia(store);

initializeApi();
initializeStores();

export { store };
