import { CreateEventShop, CreateEventShopListing, EventDetails, EventProduct, EventType } from '@fancee/data';
import { defineStore } from './helper';

export default defineStore('create-event', {
    state: (): CreateEventState => ({
        allProducts: [],
        details: EventDetails.default(),
        eventId: null,
        selectedShopCode: null,
        shops: []
    }),
    getters: {
        eventType: state => state.details.type,
        products: state => state.allProducts.filter(EventProduct.isProduct) as EventProduct[],
        tickets: state => state.allProducts.filter(EventProduct.isTicket) as EventProduct[],
        seatedTickets: state => state.allProducts.filter(EventProduct.isSeatedTicket) as EventProduct[],
        shop(state): CreateEventShop | null {
            const result = state.shops.find(s => s.code === state.selectedShopCode);

            if (result instanceof CreateEventShop) {
                return result;
            }

            return null;
        }
    },
    actions: {
        reset(): void {
            this.allProducts = [];
            this.details = EventDetails.default();
            this.eventId = null;
            this.selectedShopCode = null;
            this.shops = [];
        },

        setAllProducts(allProducts: EventProduct[]): void {
            this.allProducts = allProducts;
        },

        setDetails(details: EventDetails): void {
            this.details = details;
        },

        setEventId(eventId: string): void {
            this.eventId = eventId;
        },

        setEventType(eventType: EventType): void {
            this.details.type = eventType;
        },

        setSelectedShopCode(selectedShopCode: string | null): void {
            this.selectedShopCode = selectedShopCode;
        },

        setShops(shops: (CreateEventShop | CreateEventShopListing)[]): void {
            this.shops = shops;
        }
    }
});

interface CreateEventState {
    allProducts: EventProduct[];
    details: EventDetails;
    eventId: string | null;
    selectedShopCode: string | null;
    shops: (CreateEventShop | CreateEventShopListing)[];
}
