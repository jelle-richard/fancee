import { AuthService, TokenResponse } from '@fancee/api';
import { FanceeClient } from '@fancee/client';
import { AuthAdapter, AuthUser, DateTimeAdapter, ManageableOrganization, UserType } from '@fancee/data';
import { getStorageValue, removeStorageValue, setStorageValue } from '@/data/browserStorage';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';
import { defineStore } from './helper';

export default defineStore('auth', {
    state: (): AuthState => ({
        adminTokenResponse: null,
        isReauthenticateVisible: false,
        manageableOrganizations: null,
        token: null,
        user: null,
        validUntil: null,
        organizationClaims: [],
        userClaims: []
    }),
    getters: {
        claims: state => state.user && state.user.activeOrganizationId ? state.organizationClaims : state.userClaims,
        isAccountTakeover: state => !!state.adminTokenResponse && state.user?.type !== UserType.Admin,
        isAuthenticated: state => !!state.token,
        userType: state => state.user?.type ?? null
    },
    actions: {
        initialize(): void {
            const localAuth = getStorageValue('FT-auth');
            const localUser = getStorageValue('FT-user');
            const localOrganizationClaims = getStorageValue('FT-organization-claims');
            const localUserClaims = getStorageValue('FT-user-claims');

            if (!!localAuth && !!localUser) {
                const {claims, token, validUntil, adminTokenResponse, manageableOrganizations} = JSON.parse(localAuth);
                const user = AuthAdapter.parseAuthUserFromObject(JSON.parse(localUser).user);

                this.login(claims, token, user, manageableOrganizations, validUntil, adminTokenResponse);
            }

            if (!!localOrganizationClaims && !!localUserClaims) {
                this.setClaims(JSON.parse(localOrganizationClaims), JSON.parse(localUserClaims));
            }
        },

        login(claims: string[], token: string, user: AuthUser, manageableOrganizations: ManageableOrganization[], validUntil: string, adminTokenResponse: TokenResponse | null): void {
            this.token = token;
            this.user = user;
            this.manageableOrganizations = manageableOrganizations;
            this.validUntil = validUntil;
            this.adminTokenResponse = adminTokenResponse;

            //todo: Check why 2x the same claims are being passed https://fanceesoftware.atlassian.net/browse/FAN-2948
            this.setClaims(claims, claims);

            setStorageValue('FT-auth', JSON.stringify({claims, token, validUntil, adminTokenResponse, manageableOrganizations}));
            setStorageValue('FT-user', JSON.stringify({user}));

            FanceeClient.instance.authToken = token;
            AnalyticsClient.instance.authToken = token;
        },

        logout(): void {
            const authService = new AuthService();

            if (this.validUntil) {
                const seconds = Math.max(0, DateTimeAdapter.parseDateTimeStringToLocal(this.validUntil).diff(DateTimeAdapter.now()).as('seconds'));

                if (seconds === 0) {
                    authService.deleteSession(this.token!)
                        .catch();
                }
            }

            this.token = null;
            this.user = null;
            this.manageableOrganizations = null;
            this.validUntil = null;
            this.adminTokenResponse = null;

            this.setClaims([], []);

            removeStorageValue('FT-auth');
            removeStorageValue('FT-user');

            FanceeClient.instance.authToken = null;
            AnalyticsClient.instance.authToken = null;
        },

        setAdminTokenResponse(token: TokenResponse): void {
            this.adminTokenResponse = token;
        },

        setClaims(organizationClaims: string[], userClaims: string[]): void {
            this.organizationClaims = organizationClaims;
            this.userClaims = userClaims;
            setStorageValue('FT-organization-claims', JSON.stringify(organizationClaims));
            setStorageValue('FT-user-claims', JSON.stringify(userClaims));
        },

        setManagingOrganization(organizationId: string, claims: string[]): void {
            if (!this.user) {
                return;
            }

            this.setUser(new AuthUser(
                this.user.id,
                this.user.email,
                this.user.firstName,
                this.user.lastName,
                this.user.type,
                this.user.avatarFile,
                this.user.lastLogin,
                this.user.currency,
                [],
                this.user.isProfileComplete,
                this.user.changelogsSinceLastLogin,
                organizationId
            ));

            this.setClaims(claims, this.userClaims);
        },

        setUser(user: AuthUser): void {
            this.user = user;
            setStorageValue('FT-user', JSON.stringify({user}));
        },

        hideReauthenticateOverlay(): void {
            this.isReauthenticateVisible = false;
        },

        showReauthenticateOverlay(): void {
            this.isReauthenticateVisible = true;
        }
    }
});

type AuthState = {
    adminTokenResponse: TokenResponse | null;
    isReauthenticateVisible: boolean;
    manageableOrganizations: ManageableOrganization[] | null;
    token: string | null;
    user: AuthUser | null;
    validUntil: string | null;
    organizationClaims: string[];
    userClaims: string[];
};
