import type { DefineStoreOptions, Pinia, StateTree, Store, StoreGeneric } from 'pinia';
import { defineStore as _defineStore, storeToRefs as _storeToRefs } from 'pinia';
import type { ToRefs } from 'vue';

export function defineStore<Id extends string, S extends StateTree, G, A>(id: Id, options: { getters?: _DefineGetters<S, G>; } & Omit<DefineStoreOptions<Id, S, G, A>, 'id' | 'getters'>): _UseStore<Id, S, G, A> {
    return _defineStore(id, options as any) as _UseStore<Id, S, G, A>;
}

interface _UseStore<Id extends string, S extends StateTree, G, A> {
    $id: Id;

    (pinia?: Pinia | null, hot?: StoreGeneric): _Store<Id, S, _Getters<G>, A>;
}

type _DefineGetters<S, T> = {
    [Key in keyof T]: (state: S) => T[Key];
};

type _Getter<T> = T;

type _Getters<T> = {
    [K in keyof T]: _Getter<T[K]>;
}

type _Store<Id extends string, S, G, A> = S & G & A & Store<Id, {}, G, A>;

export function storeToRefs<Id extends string, S extends StateTree, G, A>(store: _Store<Id, S, G, A>): ToRefs<S & G> {
    return _storeToRefs(store as StoreGeneric);
}

export function useStore<Id extends string, S extends StateTree, G, A>(store: _Store<Id, S, G, A>): ToRefs<S & G> & A {
    const keys = Object.getOwnPropertyNames(store);
    const refs = _storeToRefs(store as StoreGeneric);
    const result: Record<string, unknown> = {};

    for (const key of keys) {
        if (key.startsWith('$') || key.startsWith('_')) {
            continue;
        }

        if (key in refs) {
            result[key] = refs[key];
            continue;
        }

        result[key] = store[key];
    }

    return result as ToRefs<S> & G & A;
}
