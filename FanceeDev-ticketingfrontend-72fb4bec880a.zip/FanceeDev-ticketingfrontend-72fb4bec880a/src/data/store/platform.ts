import { FanceeClient } from '@fancee/client';
import { Currency, OrganizationContract } from '@fancee/data';
import { getStorageValue, removeStorageValue, setStorageValue } from '@/data/browserStorage';
import { defineStore } from './helper';

export default defineStore('platform', {
    state: (): PlatformState => ({
        standardCurrency: null,
        organizationContract: null
    }),
    actions: {
        initialize(): void {
            const localOrganizationContract = getStorageValue('FT-organizationContract');
            const localStandardCurrency = getStorageValue('FT-standardCurrency');

            if (!!localStandardCurrency) {
                this.standardCurrency = JSON.parse(localStandardCurrency);
            }

            if (!!localOrganizationContract) {
                this.organizationContract = JSON.parse(localOrganizationContract);
                this.setTimezoneFromContract(this.organizationContract as OrganizationContract);
            }
        },

        async setOrganizationContract(organizationContract: OrganizationContract | null): Promise<void> {
            this.organizationContract = organizationContract;
            this.setTimezoneFromContract(organizationContract);

            if (organizationContract) {
                setStorageValue('FT-organizationContract', JSON.stringify(organizationContract));
            } else {
                removeStorageValue('FT-organizationContract');
            }
        },

        setStandardCurrency(standardCurrency: Currency | null): void {
            this.standardCurrency = standardCurrency;

            if (standardCurrency) {
                setStorageValue('FT-standardCurrency', JSON.stringify(standardCurrency));
            } else {
                removeStorageValue('FT-standardCurrency');
            }
        },

        setTimezoneFromContract(organizationContract: OrganizationContract | null): void {
            FanceeClient.instance.timezone = organizationContract?.timezone ?? Intl.DateTimeFormat().resolvedOptions().timeZone;
        }
    }
});

interface PlatformState {
    standardCurrency: Currency | null;
    organizationContract: OrganizationContract | null;
}
