import { CountryCode } from '@fancee/data';
import type { NavEntry } from '@/data/router';
import { getStorageValue, removeStorageValue, setStorageValue } from '@/data/browserStorage';
import { defineStore } from './helper';

export default defineStore('ui', {
    state: (): UiState => ({
        language: null,
        navigation: null,
        skin: getStorageValue('FT-skin') || 'light',
        allowedCountries: []
    }),
    actions: {
        initialize(): void {
            const localLanguage = getStorageValue('FT-language');
            const localSkin = getStorageValue('FT-skin');
            const localAllowedCountries = [...new Set(getStorageValue('FT-allowedCountries')?.split(',') ?? [])] as CountryCode[];

            if (!!localLanguage) {
                this.language = localLanguage;
            }

            if (!!localSkin) {
                this.skin = localSkin;
            }

            if (!!localAllowedCountries) {
                this.allowedCountries = localAllowedCountries;
            }
        },

        setLanguage(language: string | null): void {
            this.language = language;

            if (language) {
                setStorageValue('FT-language', language);
            } else {
                removeStorageValue('FT-language');
            }
        },

        setCountry(allowedCountries: CountryCode[]): void {
            this.allowedCountries = allowedCountries;

            if (allowedCountries.length > 0) {
                setStorageValue('FT-allowedCountries', allowedCountries.join());
            } else {
                removeStorageValue('FT-allowedCountries');
            }
        },

        setNavigation(navigation: NavEntry[] | null): void {
            this.navigation = navigation;
        },

        setSkin(skin: string): void {
            this.skin = skin;

            setStorageValue('FT-skin', skin);
        }
    }
});

interface UiState {
    language: string | null;
    navigation: NavEntry[] | null;
    skin: string;
    allowedCountries: CountryCode[];
}
