import { CsvDelimiter } from '@fancee/data';

export class CsvAdapter {
    public static delimiterValueByName(delimiterName: CsvDelimiter): string {
        switch (delimiterName) {
            case CsvDelimiter.Comma:
                return ',';
            case CsvDelimiter.Semicolon:
                return ';';
            default:
                return ',';
        }
    }

    public static detectDelimiter(input: string): CsvDelimiter {
        let commaCount = (input.match(/,/g) || []).length;
        let semicolonCount = (input.match(/;/g) || []).length;

        return commaCount > semicolonCount
            ? CsvDelimiter.Comma
            : CsvDelimiter.Semicolon;
    }

    public static csvStringToRowColumns(input: string, delimiterName: CsvDelimiter, rowsToRead: number): string[][] {
        return input.replace(/(^\n|\n$)/g, '')
            .split('\n')
            .splice(0, rowsToRead)
            .map(row => row.split(CsvAdapter.delimiterValueByName(delimiterName))
                .map(value => value.replace('\r', '')));
    }

    public static fieldMappingIndexByFieldType(fieldType: string, fieldMappings: { id: string | null, label: string }[]): number | null {
        for (let i = 0; i < fieldMappings.length; i++) {
            if (fieldMappings[i]['id'] === fieldType) {
                return i;
            }
        }

        return null;
    }
}
