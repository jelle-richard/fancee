import { FanceeClient } from '@fancee/client';

export class AnalyticsClient {
    static get instance(): FanceeClient {
        return this.#client;
    }

    static register(client: FanceeClient): void {
        this.#client = client;
    }

    static #client: FanceeClient;
}
