import { ClaimHierarchyCategory } from '@fancee/data';
import { ClaimCheckCategory } from '@/data/dto/claim/ClaimCheckCategory';
import { ClaimCheck } from '@/data/dto/claim/ClaimCheck';

export class ClaimAdapter {
    public static parseClaimHierarchyCategoryToCheckableClaims(claimCategories: ClaimHierarchyCategory[], claims: string[]): ClaimCheckCategory[] {
        return claimCategories.map(cc => new ClaimCheckCategory(
            cc.category,
            ClaimAdapter.getClaimsWithParent(cc, null, claims)
        ));
    }

    public static getClaimsWithParent(claimCategory: ClaimHierarchyCategory, claim: string | null = null, claims: string[]): ClaimCheck[] {
        return claimCategory.claims
            .filter(c => c.dependsOnClaim === claim)
            .map(c => {
                const claim = new ClaimCheck(
                    c.description,
                    c.claim,
                    claims.filter(uc => uc == c.claim).length > 0,
                    ClaimAdapter.getClaimsWithParent(claimCategory, c.claim, claims)
                );

                claim.dependingClaims.forEach(dc => dc.parentClaim = claim);

                return claim;
            });
    }
}
