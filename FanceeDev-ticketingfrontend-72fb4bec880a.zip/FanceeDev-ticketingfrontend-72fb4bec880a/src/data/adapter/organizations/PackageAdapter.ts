import { PackageType } from '@fancee/data';

export class PackageAdapter {
    public static parseContractTypeToPackageType(contractPackageType: string): PackageType {
        switch (contractPackageType.toLowerCase()) {
            case 'light':
                return PackageType.Light;

            case 'medium':
                return PackageType.Medium;

            default:
                return PackageType.Custom;
        }
    }
}
