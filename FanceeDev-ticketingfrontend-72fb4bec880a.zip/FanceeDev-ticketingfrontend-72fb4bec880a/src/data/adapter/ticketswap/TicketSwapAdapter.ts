export class TicketSwapAdapter {
    public static sealedTicketsSaleURL(orderId: string): string {
        return `https://www.ticketswap.com/sell/tickets/Fancee/${orderId}`;
    }
}
