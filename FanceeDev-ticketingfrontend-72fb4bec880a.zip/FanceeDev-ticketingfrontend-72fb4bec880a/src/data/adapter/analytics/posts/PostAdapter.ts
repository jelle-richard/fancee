import { Post } from '@/data/dto/analytics/posts';
import { DateTime } from 'luxon';

export class PostAdapter {
    public static parseFromObject(entry: object): Post {
        return new Post(
            entry['thumbnail'],
            entry['message'],
            entry['totalReach'],
            entry['totalLikes'],
            entry['totalReactions'],
            DateTime.fromISO(entry['date']),
            entry['time']
        );
    }
}
