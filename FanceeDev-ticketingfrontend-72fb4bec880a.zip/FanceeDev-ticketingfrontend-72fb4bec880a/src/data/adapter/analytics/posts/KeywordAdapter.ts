import { CHART_FONT_FAMILY } from '@/data';
import { Keyword } from '@/data/dto/analytics/posts';
import { KeywordChartItem } from '@/data/interface/charts';
import { mixColors, takeRandom } from '@/util';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class KeywordAdapter {
    public static parseFromObject(entry: object): Keyword {
        return new Keyword(
            entry['word'],
            entry['amount']
        );
    }

    public static parseFromChart(response: object): SumChart<Keyword> {
        return new SumChart<Keyword>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            response['values']
        );
    }

    public static toChartItems(keywords: Keyword[], color: string | null, rotation: boolean, defaultColor: string = '#9aa6d1'): KeywordChartItem[] {
        if (keywords.length === 0) {
            return [];
        }

        const min = Math.min(...keywords.map(keyword => keyword.amount));
        const max = Math.max(...keywords.map(keyword => keyword.amount));

        const startColor = defaultColor;
        const endColor = color ?? defaultColor;

        return keywords.map(keyword => ({
            text: keyword.word,
            weight: keyword.amount,
            rotation: rotation ? takeRandom([0, 0, 90, -90]) : 0,
            rotationUnit: 'deg',
            fontFamily: CHART_FONT_FAMILY,
            fontStyle: '',
            fontVariant: '',
            fontWeight: 600,
            color: min === max ? endColor : mixColors(startColor, endColor, (keyword.amount - min + 1) / (max - min))
        }));
    };
}
