import { BestHourToPost } from '@/data/dto/analytics/posts';

export class BestHourToPostAdapter {
    public static parseFromObject(entry: object): BestHourToPost {
        return new BestHourToPost(
            entry['hour'],
            entry['average']
        );
    }
}
