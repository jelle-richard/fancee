import { BestDayToPost } from '@/data/dto/analytics/posts';

export class BestDayToPostAdapter {
    public static parseFromObject(entry: object): BestDayToPost {
        return new BestDayToPost(
            entry['dayOfWeek'],
            entry['average']
        );
    }
}
