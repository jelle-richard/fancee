import { Connection } from '@/data/dto/analytics/logs/Connection';
import { DateTime } from 'luxon';

export class ConnectionAdapter {
    public static parseFromObject(conn: object): Connection {
        return new Connection(
            conn['id'],
            conn['userId'],
            DateTime.fromISO(conn['createdOn']),
            DateTime.fromISO(conn['updatedOn']),
            conn['subscriptionId'],
            conn['subscriptionType'],
            conn['meta'],
            conn['data'],
            conn['error'],
            conn['input']
        );
    }
}
