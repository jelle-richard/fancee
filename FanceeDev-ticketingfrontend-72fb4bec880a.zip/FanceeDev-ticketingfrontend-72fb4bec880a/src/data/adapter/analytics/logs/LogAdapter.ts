import { Log } from '@/data/dto/analytics/logs/Log';
import { DateTime } from 'luxon';

export class LogAdapter {
    public static parseFromObject(log: object): Log {
        return new Log(
            log['id'],
            log['userId'],
            DateTime.fromISO(log['createdOn']),
            DateTime.fromISO(log['updatedOn']),
            log['level'],
            log['message'],
            log['exception'],
            log['data']
        );
    }
}
