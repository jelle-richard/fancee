import { AgeLike } from '@/data/dto/analytics/likes';

export class AgeLikeAdapter {
    public static parseFromObject(like: object): AgeLike {
        return new AgeLike(
            like['age'],
            like['likesAmount']
        );
    }
}
