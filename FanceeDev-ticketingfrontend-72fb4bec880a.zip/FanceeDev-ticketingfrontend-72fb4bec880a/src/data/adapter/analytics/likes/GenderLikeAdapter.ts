import { GenderLike } from '@/data/dto/analytics/likes';

export class GenderLikeAdapter {
    public static parseFromObject(like: object): GenderLike {
        return new GenderLike(
            like['gender'],
            like['likesAmount']
        );
    }
}
