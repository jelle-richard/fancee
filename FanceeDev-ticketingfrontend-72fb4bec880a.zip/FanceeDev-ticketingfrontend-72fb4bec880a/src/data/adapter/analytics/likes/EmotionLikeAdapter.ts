import { EmotionLike } from '@/data/dto/analytics/likes';

export class EmotionLikeAdapter {
    public static parseFromObject(like: object): EmotionLike {
        return new EmotionLike(
            like['emotion'],
            like['amount']
        );
    }
}
