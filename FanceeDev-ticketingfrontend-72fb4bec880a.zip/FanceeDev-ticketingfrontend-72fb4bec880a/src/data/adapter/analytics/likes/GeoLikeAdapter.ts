import { GeoLike } from '@/data/dto/analytics/likes';

export class GeoLikeAdapter {
    public static parseFromObject(like: object): GeoLike {
        return new GeoLike(
            like['countryCode'],
            like['likesAmount'],
            like['likesGained'],
            like['previousLikesGained'],
            like['improvementPercentage']
        );
    }
}
