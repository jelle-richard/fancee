import { Subscription } from '@/data/dto/analytics/subscriptions';
import { DateTime } from 'luxon';
import { SubscriptionFieldAdapter } from '@/data/adapter/analytics/subscriptions/SubscriptionFieldAdapter';

export class SubscriptionAdapter {
    public static parseFromObject(subscription: object): Subscription {
        return new Subscription(
            subscription['id'],
            subscription['userId'],
            subscription['type'],
            subscription['name'],
            subscription['cron'],
            subscription['active'],
            DateTime.fromISO(subscription['createdOn']),
            DateTime.fromISO(subscription['updatedOn']),
            SubscriptionFieldAdapter.parseFromArray(subscription['fields'])
        );
    }
}
