import { GenericEntry } from '@/data/dto/analytics/subscriptions';
import { DateTime } from 'luxon';

export class GenericEntryAdapter {
    public static parseFromObject(entry: object): GenericEntry {
        return new GenericEntry(
            entry['id'],
            entry['inputType'],
            entry['subscriptionId'],
            entry['data'],
            entry['query'],
            DateTime.fromISO(entry['createdOn']),
            DateTime.fromISO(entry['updatedOn'])
        );
    }
}
