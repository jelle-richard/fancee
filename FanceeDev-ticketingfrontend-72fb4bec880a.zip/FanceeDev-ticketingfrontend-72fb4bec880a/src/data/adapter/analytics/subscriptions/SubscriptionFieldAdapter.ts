import { SubscriptionField } from '@/data/dto/analytics/subscriptions/SubscriptionField';

export class SubscriptionFieldAdapter {
    public static parseFromObject(field: object): SubscriptionField {
        return new SubscriptionField(
            field['field_id'],
            field['field_name'],
            field['field_type']
        );
    }

    public static parseFromArray(fields: object[] | undefined): SubscriptionField[] {
        if (!fields) {
            return [];
        }
        return fields.map(field => SubscriptionFieldAdapter.parseFromObject(field));
    }
}
