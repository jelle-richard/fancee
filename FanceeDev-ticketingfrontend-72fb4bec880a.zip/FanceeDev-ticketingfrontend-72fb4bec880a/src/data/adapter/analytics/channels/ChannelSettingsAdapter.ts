import { DateTime } from 'luxon';
import { ChannelSettings } from '@/data/dto/analytics/channels/ChannelSettings';
import { ChannelFieldAdapter } from '@/data/adapter/analytics/channels/ChannelFieldAdapter';

export class ChannelSettingsAdapter {
    public static parseFromObject(channel: object): ChannelSettings {
        return new ChannelSettings(
            channel['id'],
            channel['channelId'],
            DateTime.fromISO(channel['createdOn']),
            DateTime.fromISO(channel['updatedOn']),
            ChannelFieldAdapter.parseFromArray(channel['fields'])
        );
    }
}
