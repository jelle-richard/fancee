import { CreateChannelResponse } from '@/data/dto/analytics/channels';

export class CreateChannelResponseAdapter {
    public static parseFromObject(response: object): CreateChannelResponse {
        return new CreateChannelResponse(
            response['channel'],
            response['subscriptions']
        );
    }
}
