import { DateTime } from 'luxon';
import { Channel } from '@/data/dto/analytics/channels';

export class ChannelAdapter {
    public static parseFromObject(channel: object): Channel {
        return new Channel(
            channel['id'],
            channel['userId'],
            DateTime.fromISO(channel['createdOn']),
            DateTime.fromISO(channel['updatedOn']),
            channel['type'],
            channel['status'],
            channel['name'],
            channel['request'],
            channel['requestDisplayName'],
            channel['owner'],
            channel['user'],
            channel['subscriptions']
        );
    }

    public static parseChannelStatusToStatusColor(ChannelStatus: string) {
        switch (ChannelStatus.toLowerCase()) {
            case 'active':
                return 'success';

            case 'paused':
            case 'partiallyactive':
                return 'warning';

            case 'setup':
                return 'info';

            default:
                return 'danger';
        }
    }
}
