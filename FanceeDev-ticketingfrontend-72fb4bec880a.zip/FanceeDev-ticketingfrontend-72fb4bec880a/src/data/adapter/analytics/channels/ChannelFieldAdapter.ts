import { ChannelField } from '@/data/dto/analytics/channels';

export class ChannelFieldAdapter {
    public static parseFromObject(field: object): ChannelField {
        return new ChannelField(
            field['type'],
            field['field_id'],
            field['field_name'],
            field['field_type'],
            field['data_type'],
            field['description'],
            field['group_name'],
            field['is_filterable']
        );
    }

    public static parseFromArray(fields: object[]): ChannelField[] {
        return fields.map(field => ChannelFieldAdapter.parseFromObject(field));
    }
}
