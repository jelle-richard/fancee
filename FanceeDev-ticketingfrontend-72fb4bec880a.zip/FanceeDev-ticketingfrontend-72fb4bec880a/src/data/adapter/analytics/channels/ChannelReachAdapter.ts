import { ChannelReach } from '@/data/dto/analytics/channels';

export class ChannelReachAdapter {
    public static parseFromObject(channelReach: object): ChannelReach {
        return new ChannelReach(
            channelReach['totalFollowers'],
            channelReach['increasedFollowers'],
            channelReach['percentIncreaseFollowers'],
            channelReach['reach'],
            channelReach['activeFollowers'],
            channelReach['averageAge'],
            channelReach['percentMen'],
            channelReach['percentWomen'],
            channelReach['shares'],
            channelReach['likes'],
            channelReach['comments'],
            channelReach['clicksOnPage'],
            channelReach['description']
        );
    }
}
