import { SumEmotionsGroup, SumResponse } from '@/data/dto/analytics/dashboard';

export class SumEmotionsResponseAdapter {
    public static parseFromObject(response: object): SumResponse<SumEmotionsGroup> {
        return new SumResponse<SumEmotionsGroup>(
            response['first'],
            response['last'],
            response['items']
        );
    }
}
