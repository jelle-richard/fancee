import { AveragePriceItem, AverageCompletionTimes } from '@/data/dto/analytics/dashboard';

export class AverageAdapter {
    public static parseAveragePriceItemFromObject(item: object): AveragePriceItem {
        return new AveragePriceItem(
            item['name'],
            item['averageOrderPriceCents'],
            item['amountOfOrders']
        );
    }

    public static parseAverageCompletionTimesFromObject(response: object): AverageCompletionTimes {
        return new AverageCompletionTimes(
            response['name'],
            response['averageOrderCompletionTimeSeconds'],
            response['averageReservationCompletionTimeSeconds']
        );
    }
}
