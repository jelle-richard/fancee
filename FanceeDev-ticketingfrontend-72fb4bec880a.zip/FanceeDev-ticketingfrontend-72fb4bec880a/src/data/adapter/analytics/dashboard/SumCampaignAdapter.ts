import { DateTime } from 'luxon';
import { SumCampaignItem } from '@/data/dto/analytics/dashboard';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class SumCampaignAdapter {
    public static parseFromObject(entry: object): SumCampaignItem {
        return new SumCampaignItem(
            entry['subscriptionId'],
            entry['source'],
            DateTime.fromISO(entry['date']),
            entry['channelId'],
            DateTime.fromISO(entry['startDate']),
            entry['campaignId'],
            entry['name'],
            entry['status'],
            entry['cost'],
            entry['budget'],
            entry['impressions'],
            entry['clicks'],
            entry['cpc'],
            entry['ctr'],
            entry['conversion']
        );
    }

    public static parseFromChart(response: object): SumChart<SumCampaignItem> {
        return new SumChart<SumCampaignItem>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            response['values']
        );
    }
}
