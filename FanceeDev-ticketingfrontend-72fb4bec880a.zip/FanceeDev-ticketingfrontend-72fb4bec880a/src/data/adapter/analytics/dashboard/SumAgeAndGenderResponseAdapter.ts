import { SumAgeAndGenderItem, AgeByGenderItem } from '@/data/dto/analytics/dashboard';
import { DateTime } from 'luxon';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class SumAgeAndGenderResponseAdapter {
    public static parseFromObject(entry: object): SumAgeAndGenderItem {
        return new SumAgeAndGenderItem(
            entry['subscriptionId'],
            entry['source'],
            DateTime.fromISO(entry['date']),
            entry['age'],
            entry['gender'],
            entry['followers'],
            entry['percentage']
        );
    }

    public static parseFromChart(response: object): SumChart<SumAgeAndGenderItem> {
        return new SumChart<SumAgeAndGenderItem>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            response['values']
        );
    }

    public static parseAgeGroupAndGenderFromObject(ageGroup: object): AgeByGenderItem {
        return new AgeByGenderItem(
            ageGroup['ageGroup'],
            ageGroup['totalTickets'],
            ageGroup['maleTickets'],
            ageGroup['femaleTickets'],
            ageGroup['neutralTickets'],
            ageGroup['unknownTickets']
        );
    }
}
