import { SumEngagementGroup, SumEngagementItem, SumResponse } from '@/data/dto/analytics/dashboard';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class SumEngagementResponseAdapter {
    public static parseFromObject(response: object): SumResponse<SumEngagementGroup> {
        return new SumResponse<SumEngagementGroup>(
            response['first'],
            response['last'],
            response['items']
        );
    }

    public static parseFromChart(response: object): SumChart<SumEngagementItem> {
        return new SumChart<SumEngagementItem>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            response['values']
        );
    }
}
