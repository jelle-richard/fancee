import { SumCommentsGroup, SumCommentsItem, SumResponse } from '@/data/dto/analytics/dashboard';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
import { DateTime } from 'luxon';

export class SumCommentsResponseAdapter {
    public static parseFromObject(response: object): SumResponse<SumCommentsGroup> {
        return new SumResponse<SumCommentsGroup>(
            response['first'],
            response['last'],
            response['items']
        );
    }

    public static parseFromChart(response: object): SumChart<SumCommentsItem> {
        return new SumChart<SumCommentsItem>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            SumCommentsResponseAdapter.parseFromArray(response['values'])
        );
    }

    public static parseItemFromObject(response: object): SumCommentsItem {
        return new SumCommentsItem(
            response['subscriptionId'],
            response['source'],
            DateTime.fromISO(response['date']),
            response['hour'],
            response['dayOfWeek'],
            response['comments'],
            response['likes'],
            response['reach']
        );
    }

    public static parseFromArray(fields: object[]): SumCommentsItem[] {
        return fields.map(field => SumCommentsResponseAdapter.parseItemFromObject(field));
    }
}
