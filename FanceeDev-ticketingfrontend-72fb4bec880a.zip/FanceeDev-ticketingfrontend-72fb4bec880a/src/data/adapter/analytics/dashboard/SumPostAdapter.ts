import { DateTime } from 'luxon';
import { SumPostItem } from '@/data/dto/analytics/dashboard/posts/SumPostItem';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class SumPostAdapter {
    public static parseFromObject(entry: object): SumPostItem {
        return new SumPostItem(
            entry['subscriptionId'],
            entry['source'],
            DateTime.fromISO(entry['date']),
            entry['name'],
            entry['url'],
            entry['time'],
            entry['thumbnail'],
            entry['message'],
            entry['postType'],
            entry['likes'],
            entry['comments'],
            entry['shares'],
            entry['clicks'],
            entry['views'],
            entry['paid']
        );
    }

    public static parseFromChart(response: object): SumChart<SumPostItem> {
        return new SumChart<SumPostItem>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            response['values']
        );
    }
}
