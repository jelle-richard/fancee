import { SumCountryItem } from '@/data/dto/analytics/dashboard';
import { DateTime } from 'luxon';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class SumCountryAdapter {
    public static parseFromObject(entry: object): SumCountryItem {
        return new SumCountryItem(
            entry['subscriptionId'],
            entry['source'],
            DateTime.fromISO(entry['date']),
            entry['countryCode'],
            entry['followers'],
            entry['percentage'],
            entry['gainedPercentage']
        );
    }

    public static parseFromChart(response: object): SumChart<SumCountryItem> {
        return new SumChart<SumCountryItem>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            response['values']
        );
    }
}
