import { DateTime } from 'luxon';
import { SumCampaignAgeGenderItem } from '@/data/dto/analytics/dashboard/campaigns/SumCampaignAgeGenderItem';

export class SumCampaignAgeAndGenderAdapter {
    public static parseFromObject(entry: object): SumCampaignAgeGenderItem {
        return new SumCampaignAgeGenderItem(
            entry['subscriptionId'],
            entry['source'],
            DateTime.fromISO(entry['date']),
            entry['campaignId'],
            SumCampaignAgeAndGenderAdapter.notUndetermined(entry['age']),
            SumCampaignAgeAndGenderAdapter.notUndetermined(entry['gender']),
            entry['clicks'],
            entry['conversions'],
            entry['cost'],
            entry['impressions'],
            entry['views']
        );
    }

    private static notUndetermined = (value?: string | null): string | null => value === 'Undetermined' ? 'Other' : value ?? null;
}
