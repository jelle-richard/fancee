import { SumLostAndGainedGroup, SumLostAndGainedItem, SumResponse } from '@/data/dto/analytics/dashboard';
import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';

export class SumLostAndGainedResponseAdapter {
    public static parseFromObject(response: object): SumResponse<SumLostAndGainedGroup> {
        return new SumResponse<SumLostAndGainedGroup>(
            response['first'],
            response['last'],
            response['items']
        );
    }

    public static parseFromChart(response: object): SumChart<SumLostAndGainedItem> {
        return new SumChart<SumLostAndGainedItem>(
            response['channelId'],
            response['subscriptionId'],
            response['subscriptionType'],
            response['startOfPreviousPeriod'],
            response['values']
        );
    }
}
