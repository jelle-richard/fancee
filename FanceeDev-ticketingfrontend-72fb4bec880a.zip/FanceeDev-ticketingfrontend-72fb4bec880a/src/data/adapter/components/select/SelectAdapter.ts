import { AddressAdapter, CountryCode, CountryGroupedCountryManagers, DateTimeAdapter } from '@fancee/data';
import { FluxFormSelectGroup, FluxFormSelectOption } from '@fancee/flux';
import { PLATFORM_STARTING_YEAR } from '@/data';

export class SelectAdapter {
    public static parseCountryGroupedCountryManagersToFluxFormSelectOption(countryGroupedCountryManagers: CountryGroupedCountryManagers[]): (FluxFormSelectOption | FluxFormSelectGroup)[] {
        let options: (FluxFormSelectOption | FluxFormSelectGroup)[] = [];

        countryGroupedCountryManagers.forEach(cgcm => {
            options.push({
                icon: null,
                label: AddressAdapter.parseCountryCodeToEnglish(cgcm.countryCode as CountryCode)
            });
            options.push(...cgcm.countryManagers.map(cm => ({
                id: cm.id,
                label: `${cm.firstName} ${cm.lastName}`
            })));
        });

        return options;
    }

    public static platformYears(): FluxFormSelectOption[] {
        let years: FluxFormSelectOption[] = [];
        let currentYear: number = DateTimeAdapter.now().year;

        for (let year = PLATFORM_STARTING_YEAR; year <= currentYear; year++) {
            years.push({
                id: year,
                label: year.toString()
            });
        }

        return years.reverse();
    }
}
