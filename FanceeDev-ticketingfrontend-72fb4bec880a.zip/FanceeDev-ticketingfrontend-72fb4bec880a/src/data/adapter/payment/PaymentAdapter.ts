import { PaymentStatus } from '@fancee/data';

export class PaymentAdapter {
    public static parsePaymentStatusToClass(status: PaymentStatus): string {
        switch (status) {
            case PaymentStatus.Pending:
            case PaymentStatus.PresentToShopper:
            case PaymentStatus.ChallengeShopper:
            case PaymentStatus.AuthenticationFinished:
            case PaymentStatus.AuthenticationNotRequired:
            case PaymentStatus.IdentifyShopper:
            case PaymentStatus.Received:
            case PaymentStatus.RedirectShopper:
                return 'primary';

            case PaymentStatus.Authorised:
            case PaymentStatus.PartiallyAuthorised:
                return 'success';

            case PaymentStatus.Chargeback:
            case PaymentStatus.Refused:
            case PaymentStatus.Blocked:
                return 'danger';

            case PaymentStatus.Refund:
            case PaymentStatus.PendingRefund:
            case PaymentStatus.PartialRefund:
                return 'info';

            case PaymentStatus.Cancelled:
            case PaymentStatus.Expired:
            case PaymentStatus.Error:
            case PaymentStatus.Unknown:
            default:
                return 'error';
        }
    }
}
