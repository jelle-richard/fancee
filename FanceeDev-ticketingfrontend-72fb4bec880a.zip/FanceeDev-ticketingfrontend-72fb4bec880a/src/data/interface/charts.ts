import { GenericEntry } from '@/data/dto/analytics/subscriptions';
import { SubscriptionType } from '@/data/enum/analytics/api';
import { DateTime } from 'luxon';

export interface ChartDataItem {
    x: number | string | DateTime;
    y?: number | number[] | null;
    text?: string;
}

export interface ChartSeriesItem {
    name: string;
    min?: number;
    max?: number;
    data: ChartDataItem[];
}

export interface ChartGrowth {
    total: number;
    growth: number;
    percentage: number;
    previousTotal: number;
    previousGrowth: number;
    previousPercentage: number;
}

export type RotatedText = {
    text: string,
    offset: string,
    inside?: boolean
}

export type CustomApexAxisChartSeries = CustomApexAxisChart[];

export type CustomApexAxisChart = {
    name?: string
    type?: string
    color?: string
    group?: string
    data: {
        x: any;
        y: any;
        fill?: ApexFill;
        fillColor?: string;
        strokeColor?: string;
        meta?: any;
        goals?: any;
        barHeightOffset?: number;
        columnWidthOffset?: number;
    }[]
}

export interface ChartLegend {
    id: string;
    name: string;
    enabled: boolean;
    color: string;
}

export interface GenericChartSeries {
    name: string,
    data: object[]
}

export interface ChartCategory {
    id: string;
    label: string;
}

export interface Option {
    id: string | null;
    label: string;
}

export interface SplitItem {
    id: string;
    label: string;
    options: Option[];
    subscriptionId: string;
    subscriptionType: SubscriptionType;
    selected: string | null;
}

export interface DateAndEntries {
    date: string;
    entries: GenericEntry[];
}

export interface KeywordChartItem {
    text: string;
    weight?: number;
    rotation: number;
    rotationUnit: string;
    fontFamily: string;
    fontStyle: string;
    fontVariant: string;
    fontWeight: number;
    color: string;
}
