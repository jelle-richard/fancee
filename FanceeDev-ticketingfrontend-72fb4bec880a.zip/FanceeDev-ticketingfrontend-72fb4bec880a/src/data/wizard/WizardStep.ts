import { Dto } from '@fancee/client';
import type { IconNames } from '@fancee/flux';

@Dto
export default class WizardStep {
    get icon(): IconNames {
        return this.#icon;
    }

    get label(): string {
        return this.#label;
    }

    get routeName(): string {
        return this.#routeName;
    }

    get routeParams(): object {
        return this.#routeParams;
    }

    readonly #icon: IconNames;
    readonly #label: string;
    readonly #routeName: string;
    readonly #routeParams: object;

    constructor(icon: IconNames, label: string, routeName: string, routeParams: object = {}) {
        this.#icon = icon;
        this.#label = label;
        this.#routeName = routeName;
        this.#routeParams = routeParams;
    }
}
