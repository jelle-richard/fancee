import { Dto } from '@fancee/client';
import { ExactCountriesMapping } from '@/data/dto/accounting';

@Dto
export class ExactItemMapping {
    get platformCode(): string {
        return this.#platformCode;
    }

    set platformCode(value: string) {
        this.#platformCode = value;
    }

    get exactCountriesMappings(): ExactCountriesMapping[] {
        return this.#exactCountriesMappings;
    }

    set exactCountriesMappings(value: ExactCountriesMapping[]) {
        this.#exactCountriesMappings = value;
    }

    #platformCode: string;
    #exactCountriesMappings: ExactCountriesMapping[];

    constructor(platformCode: string, exactCountriesMappings: ExactCountriesMapping[]) {
        this.#platformCode = platformCode;
        this.#exactCountriesMappings = exactCountriesMappings;
    }
}
