import { Dto } from '@fancee/client';

@Dto
export class ExactCountriesMapping {
    get countries(): (string | null)[] {
        return this.#countries;
    }

    set countries(value: (string | null)[]) {
        this.#countries = value;
    }

    get exactItemCode(): string | null {
        return this.#exactItemCode;
    }

    set exactItemCode(value: string | null) {
        this.#exactItemCode = value;
    }

    #countries: (string | null)[];
    #exactItemCode: string | null;

    constructor(countries: (string | null)[], exactItemCode: string | null) {
        this.#countries = countries;
        this.#exactItemCode = exactItemCode;
    }
}
