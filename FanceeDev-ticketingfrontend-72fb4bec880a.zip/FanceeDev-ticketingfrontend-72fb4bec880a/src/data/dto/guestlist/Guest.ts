import { Dto } from '@fancee/client';

@Dto
export class Guest {
    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    get quantity(): number {
        return this.#quantity;
    }

    set quantity(value: number) {
        this.#quantity = value;
    }

    #email: string;
    #firstName: string;
    #lastName: string;
    #quantity: number;

    constructor(email: string, firstName: string, lastName: string, quantity: number) {
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#quantity = quantity;
    }

    public static empty(): Guest {
        return new Guest('', '', '', 1);
    }
}
