import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumCommentsItem extends SumItem {
    get hour(): string {
        return this.#hour;
    }

    get dayOfWeek(): string {
        return this.#dayOfWeek;
    }

    get comments(): number {
        return this.#comments;
    }

    get likes(): number {
        return this.#likes;
    }

    get reach(): number {
        return this.#reach;
    }

    readonly #hour: string;
    readonly #dayOfWeek: string;
    readonly #comments: number;
    readonly #likes: number;
    readonly #reach: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, hour: string, dayOfWeek: string, comments: number, likes: number, reach: number) {
        super(subscriptionId, source, date);
        this.#hour = hour;
        this.#dayOfWeek = dayOfWeek;
        this.#comments = comments;
        this.#likes = likes;
        this.#reach = reach;
    }
}
