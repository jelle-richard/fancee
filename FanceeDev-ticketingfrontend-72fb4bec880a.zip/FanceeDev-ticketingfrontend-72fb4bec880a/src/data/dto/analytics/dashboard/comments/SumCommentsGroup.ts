import { Dto } from '@fancee/client';
import { SumCommentsItem, SumGroup } from '@/data/dto/analytics/dashboard';

@Dto
export class SumCommentsGroup extends SumGroup<SumCommentsItem> {
    get averageComments(): number {
        return this.#averageComments;
    }

    get averageLikes(): number {
        return this.#averageLikes;
    }

    get averageReach(): number {
        return this.#averageReach;
    }

    readonly #averageComments: number;
    readonly #averageLikes: number;
    readonly #averageReach: number;

    constructor(date: string, values: SumCommentsItem[], averageComments: number, averageLikes: number, averageReach: number) {
        super(date, values);
        this.#averageComments = averageComments;
        this.#averageLikes = averageLikes;
        this.#averageReach = averageReach;
    }
}
