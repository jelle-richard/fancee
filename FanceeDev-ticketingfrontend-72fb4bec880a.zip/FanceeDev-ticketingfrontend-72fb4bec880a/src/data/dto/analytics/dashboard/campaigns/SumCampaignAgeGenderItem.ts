import { Dto } from '@fancee/client';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { DateTime } from 'luxon';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumCampaignAgeGenderItem extends SumItem {
    get campaignId(): string {
        return this.#campaignId;
    }

    get age(): string | null {
        return this.#age;
    }

    get gender(): string | null {
        return this.#gender;
    }

    get clicks(): number {
        return this.#clicks;
    }

    get conversions(): number {
        return this.#conversions;
    }

    get cost(): number {
        return this.#cost;
    }

    get impressions(): number {
        return this.#impressions;
    }

    get views(): number {
        return this.#views;
    }

    readonly #campaignId: string;
    readonly #age: string | null;
    readonly #gender: string | null;
    readonly #clicks: number;
    readonly #conversions: number;
    readonly #cost: number;
    readonly #impressions: number;
    readonly #views: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, campaignId: string, age: string | null, gender: string | null, clicks: number, conversions: number, cost: number, impressions: number, views: number) {
        super(subscriptionId, source, date);
        this.#campaignId = campaignId;
        this.#age = age;
        this.#gender = gender;
        this.#clicks = clicks;
        this.#conversions = conversions;
        this.#cost = cost;
        this.#impressions = impressions;
        this.#views = views;
    }
}
