import { Dto } from '@fancee/client';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { DateTime } from 'luxon';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumCampaignItem extends SumItem {
    get channelId(): string {
        return this.#channelId;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    get campaignId(): string {
        return this.#campaignId;
    }

    get name(): string {
        return this.#name;
    }

    get cost(): number {
        return this.#cost;
    }

    get budget(): number {
        return this.#budget;
    }

    get status(): string {
        return this.#status;
    }

    get impressions(): number {
        return this.#impressions;
    }

    get clicks(): number {
        return this.#clicks;
    }

    get cpc(): number {
        return this.#cpc;
    }

    get ctr(): number {
        return this.#ctr;
    }

    get conversion(): number {
        return this.#conversion;
    }

    readonly #channelId: string;
    readonly #startDate: DateTime;
    readonly #campaignId: string;
    readonly #name: string;
    readonly #status: string;
    readonly #cost: number;
    readonly #budget: number;
    readonly #impressions: number;
    readonly #clicks: number;
    readonly #cpc: number;
    readonly #ctr: number;
    readonly #conversion: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, channelId: string, startDate: DateTime, campaignId: string, name: string, status: string, cost: number, budget: number, impressions: number, clicks: number, cpc: number, ctr: number, conversion: number) {
        super(subscriptionId, source, date);
        this.#channelId = channelId;
        this.#startDate = startDate;
        this.#campaignId = campaignId;
        this.#name = name;
        this.#status = status;
        this.#cost = cost;
        this.#budget = budget;
        this.#impressions = impressions;
        this.#clicks = clicks;
        this.#cpc = cpc;
        this.#ctr = ctr;
        this.#conversion = conversion;
    }
}
