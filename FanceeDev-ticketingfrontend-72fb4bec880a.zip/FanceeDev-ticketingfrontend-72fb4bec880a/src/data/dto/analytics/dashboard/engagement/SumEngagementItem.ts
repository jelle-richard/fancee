import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumEngagementItem extends SumItem {
    get shares(): number {
        return this.#shares;
    }

    get comments(): number {
        return this.#comments;
    }

    get likes(): number {
        return this.#likes;
    }

    readonly #shares: number;
    readonly #comments: number;
    readonly #likes: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, shares: number, comments: number, likes: number) {
        super(subscriptionId, source, date);
        this.#shares = shares;
        this.#comments = comments;
        this.#likes = likes;
    }
}
