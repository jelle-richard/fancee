import { Dto } from '@fancee/client';
import { SumEngagementItem, SumGroup } from '@/data/dto/analytics/dashboard';

@Dto
export class SumEngagementGroup extends SumGroup<SumEngagementItem> {
    get totalShares(): number {
        return this.#totalShares;
    }

    get totalComments(): number {
        return this.#totalComments;
    }

    get totalLikes(): number {
        return this.#totalLikes;
    }

    readonly #totalShares: number;
    readonly #totalComments: number;
    readonly #totalLikes: number;

    constructor(date: string, values: SumEngagementItem[], totalShares: number, totalComments: number, totalLikes: number) {
        super(date, values);
        this.#totalShares = totalShares;
        this.#totalComments = totalComments;
        this.#totalLikes = totalLikes;
    }
}
