import { Dto } from '@fancee/client';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { DateTime } from 'luxon';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumPostItem extends SumItem {
    get url(): string {
        return this.#url;
    }

    get name(): string {
        return this.#name;
    }

    get time(): string {
        return this.#time;
    }

    get thumbnail(): string {
        return this.#thumbnail;
    }

    get message(): string {
        return this.#message;
    }

    get postType(): string {
        return this.#postType;
    }

    get likes(): number {
        return this.#likes;
    }

    get comments(): number {
        return this.#comments;
    }

    get shares(): number {
        return this.#shares;
    }

    get clicks(): number {
        return this.#clicks;
    }

    get views(): number {
        return this.#views;
    }

    get paid(): boolean {
        return this.#paid;
    }

    readonly #name: string;
    readonly #url: string;
    readonly #time: string;
    readonly #thumbnail: string;
    readonly #message: string;
    readonly #postType: string;
    readonly #likes: number;
    readonly #comments: number;
    readonly #shares: number;
    readonly #clicks: number;
    readonly #views: number;
    readonly #paid: boolean;


    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, name: string, url: string, time: string, thumbnail: string, message: string, postType: string, likes: number, comments: number, shares: number, clicks: number, views: number, paid: boolean) {
        super(subscriptionId, source, date);
        this.#name = name;
        this.#url = url;
        this.#time = time;
        this.#thumbnail = thumbnail;
        this.#message = message;
        this.#postType = postType;
        this.#likes = likes;
        this.#comments = comments;
        this.#shares = shares;
        this.#clicks = clicks;
        this.#views = views;
        this.#paid = paid;
    }
}
