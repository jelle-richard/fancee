import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumEmotionsItem extends SumItem {
    get wow(): number {
        return this.#wow;
    }

    get thankful(): number {
        return this.#thankful;
    }

    get sorry(): number {
        return this.#sorry;
    }

    get pride(): number {
        return this.#pride;
    }

    get love(): number {
        return this.#love;
    }

    get haha(): number {
        return this.#haha;
    }

    get anger(): number {
        return this.#anger;
    }

    get like(): number {
        return this.#like;
    }

    readonly #wow: number;
    readonly #thankful: number;
    readonly #sorry: number;
    readonly #pride: number;
    readonly #love: number;
    readonly #haha: number;
    readonly #anger: number;
    readonly #like: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, wow: number, thankful: number, sorry: number, pride: number, love: number, haha: number, anger: number, like: number) {
        super(subscriptionId, source, date);
        this.#wow = wow;
        this.#thankful = thankful;
        this.#sorry = sorry;
        this.#pride = pride;
        this.#love = love;
        this.#haha = haha;
        this.#anger = anger;
        this.#like = like;
    }
}
