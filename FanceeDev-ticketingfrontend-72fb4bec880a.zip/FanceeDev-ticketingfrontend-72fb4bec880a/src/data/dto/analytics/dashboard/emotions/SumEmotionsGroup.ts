import { Dto } from '@fancee/client';
import { SumEmotionsItem, SumGroup } from '@/data/dto/analytics/dashboard';

@Dto
export class SumEmotionsGroup extends SumGroup<SumEmotionsItem> {
    get totalWow(): number {
        return this.#totalWow;
    }

    get totalThankful(): number {
        return this.#totalThankful;
    }

    get totalSorry(): number {
        return this.#totalSorry;
    }

    get totalPride(): number {
        return this.#totalPride;
    }

    get totalLove(): number {
        return this.#totalLove;
    }

    get totalHaha(): number {
        return this.#totalHaha;
    }

    get totalAnger(): number {
        return this.#totalAnger;
    }

    get totalLike(): number {
        return this.#totalLike;
    }

    readonly #totalWow: number;
    readonly #totalThankful: number;
    readonly #totalSorry: number;
    readonly #totalPride: number;
    readonly #totalLove: number;
    readonly #totalHaha: number;
    readonly #totalAnger: number;
    readonly #totalLike: number;

    constructor(date: string, values: SumEmotionsItem[], totalWow: number, totalThankful: number, totalSorry: number, totalPride: number, totalLove: number, totalHaha: number, totalAnger: number, totalLike: number) {
        super(date, values);
        this.#totalWow = totalWow;
        this.#totalThankful = totalThankful;
        this.#totalSorry = totalSorry;
        this.#totalPride = totalPride;
        this.#totalLove = totalLove;
        this.#totalHaha = totalHaha;
        this.#totalAnger = totalAnger;
        this.#totalLike = totalLike;
    }
}
