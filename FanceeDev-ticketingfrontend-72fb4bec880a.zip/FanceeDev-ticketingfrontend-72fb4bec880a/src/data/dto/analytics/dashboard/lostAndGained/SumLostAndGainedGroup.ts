import { Dto } from '@fancee/client';
import { SumGroup, SumLostAndGainedItem } from '@/data/dto/analytics/dashboard';

@Dto
export class SumLostAndGainedGroup extends SumGroup<SumLostAndGainedItem> {
    get total(): number {
        return this.#total;
    }

    get totalLost(): number {
        return this.#totalLost;
    }

    get totalGained(): number {
        return this.#totalGained;
    }

    readonly #total: number;
    readonly #totalLost: number;
    readonly #totalGained: number;

    constructor(date: string, values: SumLostAndGainedItem[], total: number, totalLost: number, totalGained: number) {
        super(date, values);
        this.#total = total;
        this.#totalLost = totalLost;
        this.#totalGained = totalGained;
    }
}
