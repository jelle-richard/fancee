import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumLostAndGainedItem extends SumItem {
    get value(): number {
        return this.#value;
    }

    get gained(): number {
        return this.#gained;
    }

    get lost(): number {
        return this.#lost;
    }

    readonly #value: number;
    readonly #gained: number;
    readonly #lost: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, value: number, gained: number, lost: number) {
        super(subscriptionId, source, date);
        this.#value = value;
        this.#gained = gained;
        this.#lost = lost;
    }
}
