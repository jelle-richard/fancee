export class SumGroup<TSumItem> {
    get date(): string {
        return this.#date;
    }

    get values(): TSumItem[] {
        return this.#values;
    }

    readonly #date: string;
    readonly #values: TSumItem[];

    constructor(date: string, values: TSumItem[]) {
        this.#date = date;
        this.#values = values;
    }
}
