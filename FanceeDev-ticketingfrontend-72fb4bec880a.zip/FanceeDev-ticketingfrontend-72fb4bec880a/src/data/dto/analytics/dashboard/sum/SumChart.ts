import { Dto } from '@fancee/client';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumChart<TSumItem> {
    get channelId(): string {
        return this.#channelId;
    }

    get subscriptionId(): string {
        return this.#subscriptionId;
    }

    get subscriptionType(): SubscriptionType {
        return this.#subscriptionType;
    }

    get startOfPreviousPeriod(): TSumItem[] {
        return this.#startOfPreviousPeriod;
    }

    get items(): TSumItem[] {
        return this.#items;
    }

    readonly #channelId: string;
    readonly #subscriptionId: string;
    readonly #subscriptionType: SubscriptionType;
    readonly #startOfPreviousPeriod: TSumItem[];
    readonly #items: TSumItem[];

    constructor(channelId: string, subscriptionId: string, subscriptionType: SubscriptionType, startOfPreviousPeriod: TSumItem[], items: TSumItem[]) {
        this.#channelId = channelId;
        this.#subscriptionId = subscriptionId;
        this.#subscriptionType = subscriptionType;
        this.#startOfPreviousPeriod = startOfPreviousPeriod;
        this.#items = items;
    }
}
