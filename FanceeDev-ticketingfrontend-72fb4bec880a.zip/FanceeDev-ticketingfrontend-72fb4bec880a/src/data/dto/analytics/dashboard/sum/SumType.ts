export enum SumType {
    Followers = 'Followers',
    Reach = 'Reach',
    Engagement = 'Engagement',
    Comments = 'Comments'
}
