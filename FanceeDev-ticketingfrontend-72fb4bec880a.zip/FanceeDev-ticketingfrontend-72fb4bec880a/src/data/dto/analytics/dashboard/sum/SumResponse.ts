import { Dto } from '@fancee/client';

@Dto
export class SumResponse<TSumGroup> {
    get first(): TSumGroup {
        return this.#first;
    }

    get last(): TSumGroup {
        return this.#last;
    }

    get items(): TSumGroup[] {
        return this.#items;
    }

    readonly #first: TSumGroup;
    readonly #last: TSumGroup;
    readonly #items: TSumGroup[];

    constructor(first: TSumGroup, last: TSumGroup, items: TSumGroup[]) {
        this.#first = first;
        this.#last = last;
        this.#items = items;
    }
}
