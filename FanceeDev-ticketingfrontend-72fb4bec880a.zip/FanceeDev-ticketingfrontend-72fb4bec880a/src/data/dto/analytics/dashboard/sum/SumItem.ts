import { SubscriptionType } from '@/data/enum/analytics/api';
import { DateTime } from 'luxon';

export class SumItem {
    get subscriptionId(): string {
        return this.#subscriptionId;
    }

    get source(): SubscriptionType {
        return this.#source;
    }

    get date(): DateTime {
        return this.#date;
    }

    readonly #subscriptionId: string;
    readonly #source: SubscriptionType;
    readonly #date: DateTime;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime) {
        this.#subscriptionId = subscriptionId;
        this.#source = source;
        this.#date = date;
    }
}
