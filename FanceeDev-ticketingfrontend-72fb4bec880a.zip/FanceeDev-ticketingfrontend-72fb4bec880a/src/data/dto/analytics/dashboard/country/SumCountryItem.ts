import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumCountryItem extends SumItem {
    get countryCode(): string {
        return this.#countryCode;
    }

    get followers(): number {
        return this.#followers;
    }

    get percentage(): number {
        return this.#percentage;
    }

    get gainedPercentage(): number {
        return this.#gainedPercentage;
    }

    readonly #countryCode: string;
    readonly #followers: number;
    readonly #percentage: number;
    readonly #gainedPercentage: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, countryCode: string, followers: number, percentage: number, gainedPercentage: number) {
        super(subscriptionId, source, date);
        this.#countryCode = countryCode;
        this.#followers = followers;
        this.#percentage = percentage;
        this.#gainedPercentage = gainedPercentage;
    }
}
