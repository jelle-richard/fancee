import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { SumItem } from '@/data/dto/analytics/dashboard';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class SumAgeAndGenderItem extends SumItem {
    get age(): string {
        return this.#age;
    }

    get gender(): string {
        return this.#gender;
    }

    get followers(): number {
        return this.#followers;
    }

    get percentage(): number {
        return this.#percentage;
    }

    readonly #age: string;
    readonly #gender: string;
    readonly #followers: number;
    readonly #percentage: number;

    constructor(subscriptionId: string, source: SubscriptionType, date: DateTime, age: string, gender: string, followers: number, percentage: number) {
        super(subscriptionId, source, date);
        this.#age = age;
        this.#gender = gender;
        this.#followers = followers;
        this.#percentage = percentage;
    }
}
