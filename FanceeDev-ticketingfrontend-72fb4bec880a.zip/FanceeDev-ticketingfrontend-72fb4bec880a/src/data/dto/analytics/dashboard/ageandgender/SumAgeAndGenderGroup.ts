import { Dto } from '@fancee/client';
import { SumAgeAndGenderItem, SumGroup } from '@/data/dto/analytics/dashboard';

@Dto
export class SumAgeAndGenderGroup extends SumGroup<SumAgeAndGenderItem> {
    constructor(date: string, values: SumAgeAndGenderItem[]) {
        super(date, values);
    }
}
