import { Dto } from '@fancee/client';

@Dto
export class AverageCompletionTimes {
    get name(): string {
        return this.#name;
    }

    get averageOrderCompletionTimeSeconds(): number {
        return this.#averageOrderCompletionTimeSeconds;
    }

    get averageReservationCompletionTimeSeconds(): number {
        return this.#averageReservationCompletionTimeSeconds;
    }

    readonly #name: string;
    readonly #averageOrderCompletionTimeSeconds: number;
    readonly #averageReservationCompletionTimeSeconds: number;

    constructor(name: string, averageOrderCompletionTimeSeconds: number, averageReservationCompletionTimeSeconds: number) {
        this.#name = name;
        this.#averageOrderCompletionTimeSeconds = averageOrderCompletionTimeSeconds;
        this.#averageReservationCompletionTimeSeconds = averageReservationCompletionTimeSeconds;
    }
}
