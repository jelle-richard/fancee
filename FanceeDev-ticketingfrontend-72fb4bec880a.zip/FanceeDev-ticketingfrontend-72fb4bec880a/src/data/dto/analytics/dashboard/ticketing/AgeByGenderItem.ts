import { Dto } from '@fancee/client';

@Dto
export class AgeByGenderItem {
    get ageGroup(): string {
        return this.#ageGroup;
    }

    get totalTickets(): number {
        return this.#totalTickets;
    }

    get maleTickets(): number {
        return this.#maleTickets;
    }

    get femaleTickets(): number {
        return this.#femaleTickets;
    }

    get neutralTickets(): number {
        return this.#neutralTickets;
    }

    get unknownTickets(): number {
        return this.#unknownTickets;
    }

    readonly #ageGroup: string;
    readonly #totalTickets: number;
    readonly #maleTickets: number;
    readonly #femaleTickets: number;
    readonly #neutralTickets: number;
    readonly #unknownTickets: number;

    constructor(ageGroup: string, totalTickets: number, maleTickets: number, femaleTickets: number, neutralTickets: number, unknownTickets: number) {
        this.#ageGroup = ageGroup;
        this.#totalTickets = totalTickets;
        this.#maleTickets = maleTickets;
        this.#femaleTickets = femaleTickets;
        this.#neutralTickets = neutralTickets;
        this.#unknownTickets = unknownTickets;
    }
}
