import { Dto } from '@fancee/client';

@Dto
export class AveragePriceItem {
    get name(): string {
        return this.#name;
    }

    get averageOrderPriceCents(): number {
        return this.#averageOrderPriceCents;
    }

    get amountOfOrders(): number {
        return this.#amountOfOrders;
    }

    readonly #name: string;
    readonly #averageOrderPriceCents: number;
    readonly #amountOfOrders: number;

    constructor(name: string, averageOrderPriceCents: number, amountOfOrders: number) {
        this.#name = name;
        this.#averageOrderPriceCents = averageOrderPriceCents;
        this.#amountOfOrders = amountOfOrders;
    }
}
