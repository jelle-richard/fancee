import { Dto } from '@fancee/client';
import { ChannelType } from '@/data/enum/analytics/api';
import { ChannelOwner } from '@/data/dto/analytics/channels/ChannelOwner';

@Dto
export class CreateChannelRequest {
    get platformUserId(): string {
        return this.#platformUserId;
    }

    set platformUserId(value: string) {
        this.#platformUserId = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get type(): ChannelType | null {
        return this.#type;
    }

    set type(value: ChannelType | null) {
        this.#type = value;
    }

    get userId(): string {
        return this.#userId;
    }

    set userId(value: string) {
        this.#userId = value;
    }

    get accountsId(): string {
        return this.#accountsId;
    }

    set accountsId(value: string) {
        this.#accountsId = value;
    }

    get owner(): ChannelOwner {
        return this.#owner;
    }

    set owner(value: ChannelOwner) {
        this.#owner = value;
    }

    #platformUserId: string;
    #name: string;
    #type: ChannelType | null;
    #userId: string;
    #accountsId: string;
    #owner: ChannelOwner;

    constructor(platformUserId: string, name: string, type: ChannelType | null, userId: string, accountsId: string, owner: ChannelOwner) {
        this.#platformUserId = platformUserId;
        this.#name = name;
        this.#type = type;
        this.#userId = userId;
        this.#accountsId = accountsId;
        this.#owner = owner;
    }

    public static empty(): CreateChannelRequest {
        return new CreateChannelRequest('', '', null, '', '', new ChannelOwner('', '', '', '', ''));
    }
}
