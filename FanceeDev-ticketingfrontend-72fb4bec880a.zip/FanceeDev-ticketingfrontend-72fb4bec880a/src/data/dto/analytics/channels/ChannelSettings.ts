import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { ChannelField } from '@/data/dto/analytics/channels/ChannelField';

@Dto
export class ChannelSettings {
    get id(): string {
        return this.#id;
    }

    get channelId(): string {
        return this.#channelId;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    get updatedOn(): DateTime {
        return this.#updatedOn;
    }

    get fields(): ChannelField[] {
        return this.#fields;
    }

    readonly #id: string;
    readonly #channelId: string;
    readonly #createdOn: DateTime;
    readonly #updatedOn: DateTime;
    readonly #fields: ChannelField[];

    constructor(id: string, channelId: string, createdOn: DateTime, updatedOn: DateTime, fields?: ChannelField[]) {
        this.#id = id;
        this.#channelId = channelId;
        this.#createdOn = createdOn;
        this.#updatedOn = updatedOn;
        this.#fields = fields ?? [];
    }

    static empty(): ChannelSettings {
        return new ChannelSettings('', '', DateTime.utc(), DateTime.utc(), []);
    }
}
