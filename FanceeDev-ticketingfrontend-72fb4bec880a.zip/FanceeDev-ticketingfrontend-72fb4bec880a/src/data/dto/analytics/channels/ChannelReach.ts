import { Dto } from '@fancee/client';

@Dto
export class ChannelReach {
    get totalFollowers(): number {
        return this.#totalFollowers;
    }

    get increasedFollowers(): number {
        return this.#increasedFollowers;
    }

    get percentIncreaseFollowers(): number | null {
        return this.#percentIncreaseFollowers;
    }

    get reach(): number | null {
        return this.#reach;
    }

    get activeFollowers(): number {
        return this.#activeFollowers;
    }

    get averageAge(): number | null {
        return this.#averageAge;
    }

    get percentMen(): number | null {
        return this.#percentMen;
    }

    get percentWomen(): number | null {
        return this.#percentWomen;
    }

    get shares(): number {
        return this.#shares;
    }

    get likes(): number {
        return this.#likes;
    }

    get comments(): number {
        return this.#comments;
    }

    get clicksOnPage(): number | null {
        return this.#clicksOnPage;
    }

    get description(): string | null {
        return this.#description;
    }

    readonly #totalFollowers: number;
    readonly #increasedFollowers: number;
    readonly #percentIncreaseFollowers: number | null;
    readonly #reach: number | null;
    readonly #activeFollowers: number;
    readonly #averageAge: number | null;
    readonly #percentMen: number | null;
    readonly #percentWomen: number | null;
    readonly #shares: number;
    readonly #likes: number;
    readonly #comments: number;
    readonly #clicksOnPage: number | null;
    readonly #description: string | null;

    constructor(totalFollowers: number, increasedFollowers: number, percentIncreaseFollowers: number | null, reach: number | null, activeFollowers: number, averageAge: number | null, percentMen: number | null, percentWomen: number | null, shares: number, likes: number, comments: number, clicksOnPage: number | null, description: string | null) {
        this.#totalFollowers = totalFollowers;
        this.#increasedFollowers = increasedFollowers;
        this.#percentIncreaseFollowers = percentIncreaseFollowers;
        this.#reach = reach;
        this.#activeFollowers = activeFollowers;
        this.#averageAge = averageAge;
        this.#percentMen = percentMen;
        this.#percentWomen = percentWomen;
        this.#shares = shares;
        this.#likes = likes;
        this.#comments = comments;
        this.#clicksOnPage = clicksOnPage;
        this.#description = description;
    }

    static empty(): ChannelReach {
        return new ChannelReach(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null);
    }
}
