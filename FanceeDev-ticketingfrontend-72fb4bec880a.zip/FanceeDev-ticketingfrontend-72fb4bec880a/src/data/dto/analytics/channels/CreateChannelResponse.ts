import { Dto } from '@fancee/client';
import { Subscription } from '@/data/dto/analytics/subscriptions';
import { Channel } from '@/data/dto/analytics/channels/Channel';

@Dto
export class CreateChannelResponse {
    get channel(): Channel {
        return this.#channel;
    }

    get subscriptions(): Subscription[] {
        return this.#subscriptions;
    }

    readonly #channel: Channel;
    readonly #subscriptions: Subscription[];

    constructor(channel: Channel, subscriptions: Subscription[]) {
        this.#channel = channel;
        this.#subscriptions = subscriptions;
    }
}
