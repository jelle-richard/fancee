import { Dto } from '@fancee/client';

@Dto
export class ChannelField {
    get type(): string {
        return this.#type;
    }

    get fieldId(): string {
        return this.#fieldId;
    }

    get fieldName(): string {
        return this.#fieldName;
    }

    get fieldType(): string {
        return this.#fieldType;
    }

    get dataType(): string {
        return this.#dataType;
    }

    get description(): string {
        return this.#description;
    }

    get groupName(): string {
        return this.#groupName;
    }

    get isFilterable(): boolean {
        return this.#isFilterable;
    }

    readonly #type: string;
    readonly #fieldId: string;
    readonly #fieldName: string;
    readonly #fieldType: string;
    readonly #dataType: string;
    readonly #description: string;
    readonly #groupName: string;
    readonly #isFilterable: boolean;

    constructor(type: string, fieldId: string, fieldName: string, fieldType: string, dataType: string, description: string, groupName: string, isFilterable: boolean) {
        this.#type = type;
        this.#fieldId = fieldId;
        this.#fieldName = fieldName;
        this.#fieldType = fieldType;
        this.#dataType = dataType;
        this.#description = description;
        this.#groupName = groupName;
        this.#isFilterable = isFilterable;
    }
}
