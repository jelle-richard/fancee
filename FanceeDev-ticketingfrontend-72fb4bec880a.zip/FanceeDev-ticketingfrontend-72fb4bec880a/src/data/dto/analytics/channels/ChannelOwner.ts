import { Dto } from '@fancee/client';

@Dto
export class ChannelOwner {
    get organizationId(): string | null {
        return this.#organizationId;
    }

    set organizationId(value: string | null) {
        this.#organizationId = value;
    }

    get organizationName(): string | null {
        return this.#organizationName;
    }

    set organizationName(value: string | null) {
        this.#organizationName = value;
    }

    get firstName(): string | null {
        return this.#firstName;
    }

    set firstName(value: string | null) {
        this.#firstName = value;
    }

    get lastName(): string | null {
        return this.#lastName;
    }

    set lastName(value: string | null) {
        this.#lastName = value;
    }

    get email(): string | null {
        return this.#email;
    }

    set email(value: string | null) {
        this.#email = value;
    }

    #organizationId: string | null;
    #organizationName: string | null;
    #firstName: string | null;
    #lastName: string | null;
    #email: string | null;

    constructor(organizationId: string | null, organizationName: string | null, firstName: string | null, lastName: string | null, email: string | null) {
        this.#organizationId = organizationId;
        this.#organizationName = organizationName;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#email = email;
    }
}
