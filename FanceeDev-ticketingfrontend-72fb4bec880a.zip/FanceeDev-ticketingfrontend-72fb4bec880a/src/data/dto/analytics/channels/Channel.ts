import { Dto } from '@fancee/client';
import { AuthUser } from '@fancee/data';
import { DateTime } from 'luxon';
import { Subscription } from '@/data/dto/analytics/subscriptions';
import { ChannelStatus, ChannelType } from '@/data/enum/analytics/api';
import { ChannelOwner } from '@/data/dto/analytics/channels/ChannelOwner';

@Dto
export class Channel {
    get id(): string {
        return this.#id;
    }

    get userId(): string | null {
        return this.#userId;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    get updatedOn(): DateTime {
        return this.#updatedOn;
    }

    get type(): ChannelType {
        return this.#type;
    }

    get status(): ChannelStatus {
        return this.#status;
    }

    get name(): string {
        return this.#name;
    }

    get request(): string {
        return this.#request;
    }

    get requestDisplayName(): string {
        return this.#requestDisplayName;
    }

    get user(): AuthUser | null {
        return this.#user;
    }

    get owner(): ChannelOwner | null {
        return this.#channelOwner;
    }

    get subscriptions(): Subscription[] {
        return this.#subscriptions;
    }

    set subscriptions(value: Subscription[]) {
        this.#subscriptions = value;
    }

    readonly #id: string;
    readonly #userId: string | null;
    readonly #createdOn: DateTime;
    readonly #updatedOn: DateTime;
    readonly #type: ChannelType;
    readonly #status: ChannelStatus;
    readonly #name: string;
    readonly #request: string;
    readonly #requestDisplayName: string;
    readonly #channelOwner: ChannelOwner | null = null;
    readonly #user: AuthUser | null = null;
    #subscriptions: Subscription[];

    constructor(id: string, userId: string | null, createdOn: DateTime, updatedOn: DateTime, type: ChannelType, status: ChannelStatus, name: string, request: string, requestDisplayName: string, channelOwner: ChannelOwner, user: AuthUser | null, subscriptions?: Subscription[]) {
        this.#id = id;
        this.#userId = userId;
        this.#createdOn = createdOn;
        this.#updatedOn = updatedOn;
        this.#type = type;
        this.#status = status;
        this.#name = name;
        this.#request = request;
        this.#requestDisplayName = requestDisplayName;
        this.#channelOwner = channelOwner;
        this.#user = user;
        this.#subscriptions = subscriptions ?? [];
    }
}
