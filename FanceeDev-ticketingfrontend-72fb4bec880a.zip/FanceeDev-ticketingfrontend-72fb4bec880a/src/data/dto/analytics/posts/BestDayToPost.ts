import { Dto } from '@fancee/client';

@Dto
export class BestDayToPost {
    get dayOfWeek(): string {
        return this.#dayOfWeek;
    }

    get average(): number {
        return this.#average;
    }

    readonly #dayOfWeek: string;
    readonly #average: number;

    constructor(dayOfWeek: string, average: number) {
        this.#dayOfWeek = dayOfWeek;
        this.#average = average;
    }
}
