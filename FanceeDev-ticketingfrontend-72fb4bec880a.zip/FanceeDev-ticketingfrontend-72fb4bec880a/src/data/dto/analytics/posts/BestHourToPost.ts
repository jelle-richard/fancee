import { Dto } from '@fancee/client';

@Dto
export class BestHourToPost {
    get hour(): string {
        return this.#hour;
    }

    get average(): number {
        return this.#average;
    }

    readonly #hour: string;
    readonly #average: number;

    constructor(hour: string, average: number) {
        this.#hour = hour;
        this.#average = average;
    }
}
