import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class Post {
    get thumbnail(): string {
        return this.#thumbnail;
    }

    get message(): string {
        return this.#message;
    }

    get totalReach(): number {
        return this.#totalReach;
    }

    get totalLikes(): number {
        return this.#totalLikes;
    }

    get totalReactions(): number {
        return this.#totalReactions;
    }

    get date(): DateTime {
        return this.#date;
    }

    get time(): string {
        return this.#time;
    }

    readonly #thumbnail: string;
    readonly #message: string;
    readonly #totalReach: number;
    readonly #totalLikes: number;
    readonly #totalReactions: number;
    readonly #date: DateTime;
    readonly #time: string;

    constructor(thumbnail: string, message: string, totalReach: number, totalLikes: number, totalReactions: number, date: DateTime, time: string) {
        this.#thumbnail = thumbnail;
        this.#message = message;
        this.#totalReach = totalReach;
        this.#totalLikes = totalLikes;
        this.#totalReactions = totalReactions;
        this.#date = date;
        this.#time = time;
    }
}
