import { Dto } from '@fancee/client';

@Dto
export class Keyword {
    get word(): string {
        return this.#word;
    }

    get amount(): number {
        return this.#amount;
    }

    public set amount(value: number) {
        this.#amount = value;
    }

    readonly #word: string;
    #amount: number;

    constructor(word: string, amount: number) {
        this.#word = word;
        this.#amount = amount;
    }
}
