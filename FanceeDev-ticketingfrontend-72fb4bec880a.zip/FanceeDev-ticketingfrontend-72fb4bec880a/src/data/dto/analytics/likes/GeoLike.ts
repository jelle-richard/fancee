import { Dto } from '@fancee/client';
import { CountryCode } from '@fancee/data';

@Dto
export class GeoLike {
    get countryCode(): CountryCode {
        return this.#countryCode;
    }

    get likesAmount(): number {
        return this.#likesAmount;
    }

    get likesGained(): number {
        return this.#likesGained;
    }

    get previousLikesGained(): number {
        return this.#previousLikesGained;
    }

    get improvementPercentage(): number {
        return this.#improvementPercentage;
    }

    readonly #countryCode: CountryCode;
    readonly #likesAmount: number;
    readonly #likesGained: number;
    readonly #previousLikesGained: number;
    readonly #improvementPercentage: number;

    constructor(countryCode: CountryCode, likesAmount: number, likesGained: number, previousLikesGained: number, improvementPercentage: number) {
        this.#countryCode = countryCode;
        this.#likesAmount = likesAmount;
        this.#likesGained = likesGained;
        this.#previousLikesGained = previousLikesGained;
        this.#improvementPercentage = improvementPercentage;
    }
}
