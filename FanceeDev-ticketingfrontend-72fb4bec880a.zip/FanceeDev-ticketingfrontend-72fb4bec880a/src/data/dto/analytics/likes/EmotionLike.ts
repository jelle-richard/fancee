import { Dto } from '@fancee/client';

@Dto
export class EmotionLike {
    get emotion(): string {
        return this.#emotion;
    }

    get amount(): number {
        return this.#amount;
    }

    readonly #emotion: string;
    readonly #amount: number;

    constructor(emotion: string, amount: number) {
        this.#emotion = emotion;
        this.#amount = amount;
    }
}
