import { Dto } from '@fancee/client';

@Dto
export class AgeLike {
    get age(): string {
        return this.#age;
    }

    get likesAmount(): number {
        return this.#likesAmount;
    }

    readonly #age: string;
    readonly #likesAmount: number;

    constructor(age: string, amount: number) {
        this.#age = age;
        this.#likesAmount = amount;
    }
}
