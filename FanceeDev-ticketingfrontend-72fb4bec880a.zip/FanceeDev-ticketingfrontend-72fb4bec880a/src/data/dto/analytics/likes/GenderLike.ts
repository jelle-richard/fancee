import { Dto } from '@fancee/client';

@Dto
export class GenderLike {
    get gender(): string {
        return this.#gender;
    }

    get likesAmount(): number {
        return this.#likesAmount;
    }

    readonly #gender: string;
    readonly #likesAmount: number;

    constructor(gender: string, amount: number) {
        this.#gender = gender;
        this.#likesAmount = amount;
    }
}

