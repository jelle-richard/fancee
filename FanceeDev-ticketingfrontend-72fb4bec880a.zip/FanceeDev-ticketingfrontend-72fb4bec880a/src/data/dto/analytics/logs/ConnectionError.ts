import { Dto } from '@fancee/client';

@Dto
export class ConnectionError {
    get code(): string {
        return this.#code;
    }

    get message(): string {
        return this.#message;
    }

    get description(): string {
        return this.#description;
    }

    readonly #code: string;
    readonly #message: string;
    readonly #description: string;

    constructor(code: string, message: string, description: string) {
        this.#code = code;
        this.#message = message;
        this.#description = description;
    }
}
