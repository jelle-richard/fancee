import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { ConnectionError } from './ConnectionError';
import { SubscriptionType } from '@/data/enum/analytics/api';

@Dto
export class Connection {
    get id(): string | null {
        return this.#id;
    }

    get userId(): string | null {
        return this.#userId;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    get updatedOn(): DateTime {
        return this.#updatedOn;
    }

    get subscriptionId(): string {
        return this.#subscriptionId;
    }

    get subscriptionType(): SubscriptionType {
        return this.#subscriptionType;
    }

    get meta(): any {
        return this.#meta;
    }

    get data(): any {
        return this.#data;
    }

    get error(): ConnectionError | null {
        return this.#error;
    }

    get input(): any {
        return this.#input;
    }

    readonly #id: string | null;
    readonly #userId: string | null;
    readonly #createdOn: DateTime;
    readonly #updatedOn: DateTime;
    readonly #subscriptionId: string;
    readonly #subscriptionType: SubscriptionType;
    readonly #meta: any;
    readonly #data: any;
    readonly #error: ConnectionError | null;
    readonly #input: any;

    constructor(id: string | null, userId: string | null, createdOn: DateTime, updatedOn: DateTime, subscriptionId: string, subscriptionType: SubscriptionType, meta: any, data: any, error: ConnectionError, input: any) {
        this.#id = id;
        this.#userId = userId;
        this.#createdOn = createdOn;
        this.#updatedOn = updatedOn;
        this.#subscriptionId = subscriptionId;
        this.#subscriptionType = subscriptionType;
        this.#meta = meta;
        this.#data = data;
        this.#error = error;
        this.#input = input;
    }
}
