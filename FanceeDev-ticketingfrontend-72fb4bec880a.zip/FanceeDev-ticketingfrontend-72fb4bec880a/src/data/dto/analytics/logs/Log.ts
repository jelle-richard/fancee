import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { LogLevel } from '@/data/enum/analytics/logs/LogLevel';

@Dto
export class Log {
    get id(): string | null {
        return this.#id;
    }

    get userId(): string | null {
        return this.#userId;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    get updatedOn(): DateTime {
        return this.#updatedOn;
    }

    get level(): LogLevel {
        return this.#level;
    }

    get message(): string {
        return this.#message;
    }

    set message(value: string) {
        this.#message = value;
    }

    get exception(): string {
        return this.#exception;
    }

    get data(): any {
        return this.#data;
    }

    readonly #id: string | null;
    readonly #userId: string | null;
    readonly #createdOn: DateTime;
    readonly #updatedOn: DateTime;
    readonly #level: LogLevel;
    readonly #exception: string;
    readonly #data: any;
    #message: string;

    constructor(id: string | null, userId: string | null, createdOn: DateTime, updatedOn: DateTime, level: LogLevel, message: string, exception: string, data: any) {
        this.#id = id;
        this.#userId = userId;
        this.#createdOn = createdOn;
        this.#updatedOn = updatedOn;
        this.#level = level;
        this.#message = message;
        this.#exception = exception;
        this.#data = data;
    }
}
