import { Dto } from '@fancee/client';

@Dto
export class SubscriptionField {
    get fieldId(): string {
        return this.#fieldId;
    }

    get fieldName(): string {
        return this.#fieldName;
    }

    get fieldType(): string {
        return this.#fieldType;
    }

    readonly #fieldId: string;
    readonly #fieldName: string;
    readonly #fieldType: string;

    constructor(fieldId: string, fieldName: string, fieldType: string) {
        this.#fieldId = fieldId;
        this.#fieldName = fieldName;
        this.#fieldType = fieldType;
    }
}
