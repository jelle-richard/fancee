import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { GenericEntry } from '@/data/dto/analytics/subscriptions/GenericEntry';
import { SubscriptionField } from '@/data/dto/analytics/subscriptions/SubscriptionField';
import { SubscriptionType } from '@/data/enum/analytics/api/SubscriptionType';

@Dto
export class Subscription {
    get id(): string {
        return this.#id;
    }

    get userId(): string | null {
        return this.#userId;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    get updatedOn(): DateTime {
        return this.#updatedOn;
    }

    get type(): SubscriptionType {
        return this.#type;
    }

    get cron(): string {
        return this.#cron;
    }

    get active(): boolean {
        return this.#active;
    }

    get name(): string | null {
        return this.#name;
    }

    set name(value: string | null) {
        this.#name = value;
    }

    get entries(): GenericEntry[] {
        return this.#entries;
    }

    set entries(value: GenericEntry[]) {
        this.#entries = value;
    }

    get fields(): SubscriptionField[] {
        return this.#fields;
    }

    readonly #id: string;
    readonly #userId: string | null;
    readonly #type: SubscriptionType;
    readonly #cron: string;
    readonly #active: boolean;
    readonly #createdOn: DateTime;
    readonly #updatedOn: DateTime;
    readonly #fields: SubscriptionField[];
    #name: string | null;
    #entries: GenericEntry[] = [];

    constructor(id: string, userId: string | null, type: SubscriptionType, name: string | null, cron: string, active: boolean, createdOn: DateTime, updatedOn: DateTime, fields: SubscriptionField[] | undefined) {
        this.#id = id;
        this.#userId = userId;
        this.#type = type;
        this.#name = name ?? null;
        this.#cron = cron;
        this.#active = active;
        this.#createdOn = createdOn;
        this.#updatedOn = updatedOn;
        this.#fields = fields ?? [];
    }

    public static copyWithEntries(subscription: Subscription, entries: GenericEntry[]): Subscription {
        let newSubscription = new Subscription(subscription.id, subscription.userId, subscription.type, subscription.name, subscription.cron, subscription.active, subscription.createdOn, subscription.updatedOn, subscription.fields);
        newSubscription.entries = entries;
        return newSubscription;
    }
}
