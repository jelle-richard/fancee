import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class GenericEntry {
    get id(): string {
        return this.#id;
    }

    get inputType(): string {
        return this.#inputType;
    }

    get subscriptionId(): string {
        return this.#subscriptionId;
    }

    get data(): any {
        return this.#data;
    }

    get query(): any {
        return this.#query;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    get updatedOn(): DateTime {
        return this.#updatedOn;
    }

    readonly #id: string;
    readonly #inputType: string;
    readonly #subscriptionId: string;
    readonly #data: any;
    readonly #query: any;
    readonly #createdOn: DateTime;
    readonly #updatedOn: DateTime;

    constructor(id: string, inputType: string, subscriptionId: string, data: any, query: any, createdOn: DateTime, updatedOn: DateTime) {
        this.#id = id;
        this.#inputType = inputType;
        this.#subscriptionId = subscriptionId;
        this.#data = data;
        this.#query = query;
        this.#createdOn = createdOn;
        this.#updatedOn = updatedOn;
    }
}
