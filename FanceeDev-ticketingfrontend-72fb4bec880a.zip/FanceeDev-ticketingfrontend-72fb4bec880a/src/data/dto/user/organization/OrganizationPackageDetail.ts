import { Dto } from '@fancee/client';
import { PackageType } from '@fancee/data';
import { VisualSource } from '@/components/ui/Visual';

@Dto
export class OrganizationPackageDetail {
    get name(): PackageType {
        return this.#name;
    }

    get audience(): string {
        return this.#audience;
    }

    get ticketFeeCents(): number | null {
        return this.#ticketFeeCents;
    }

    get visual(): VisualSource {
        return this.#visual;
    }

    get features(): (string | number | boolean)[] {
        return this.#features;
    }

    readonly #name: PackageType;
    readonly #audience: string;
    readonly #ticketFeeCents: number | null;
    readonly #visual: VisualSource;
    readonly #features: (string | number | boolean)[];

    constructor(name: PackageType, audience: string, ticketFeeCents: number | null, visual: VisualSource, features: (string | number | boolean)[]) {
        this.#name = name;
        this.#audience = audience;
        this.#ticketFeeCents = ticketFeeCents;
        this.#visual = visual;
        this.#features = features;
    }
}
