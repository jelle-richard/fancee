import { Dto } from '@fancee/client';
import { Feature } from '@/data';
import { OrganizationPackageDetail } from '@/data/dto/user/organization/OrganizationPackageDetail';

@Dto
export class OrganizationPackage {
    get features(): Feature[] {
        return this.#features;
    }

    get packages(): OrganizationPackageDetail[] | null {
        return this.#packages;
    }

    readonly #features: Feature[];
    readonly #packages: OrganizationPackageDetail[] | null;

    constructor(features: Feature[], packages: OrganizationPackageDetail[] | null) {
        this.#features = features;
        this.#packages = packages;
    }
}
