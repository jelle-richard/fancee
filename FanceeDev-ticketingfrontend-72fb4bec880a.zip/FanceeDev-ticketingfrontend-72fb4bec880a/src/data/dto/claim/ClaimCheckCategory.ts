import { Dto } from '@fancee/client';
import { ClaimCheck } from '@/data/dto/claim/ClaimCheck';

@Dto
export class ClaimCheckCategory {
    get category(): string {
        return this.#category;
    }

    get claims(): ClaimCheck[] {
        return this.#claims;
    }

    get isChecked(): boolean | null {
        if (this.#claims.every(c => c.isFullyChecked)) {
            return true;
        }

        if (this.#claims.some(c => c.isFullyChecked)) {
            return null;
        }

        return false;
    }

    set isChecked(value: boolean | null) {
        if (value === null) {
            value = false;
        }

        this.#claims.forEach(c => c.isFullyChecked = value!);
    }

    get selectedClaims(): string[] {
        return this.#claims.map(c => c.selectedClaims).flat();
    }

    get selection(): string {
        return `${this.totalCheckedClaims} / ${this.totalClaims}`;
    }

    get totalCheckedClaims(): number {
        return this.#claims.map(dc => dc.totalCheckedClaims).reduce((acc, curr) => acc + curr, 0);
    }

    get totalClaims(): number {
        return this.#claims.map(dc => dc.totalClaims).reduce((acc, curr) => acc + curr, 0);
    }

    readonly #category: string;
    readonly #claims: ClaimCheck[];

    constructor(category: string, claims: ClaimCheck[]) {
        this.#category = category;
        this.#claims = claims;
    }
}
