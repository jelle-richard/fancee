import { Dto } from '@fancee/client';

@Dto
export class ClaimCheck {
    get name(): string {
        return this.#name;
    }

    get claim(): string {
        return this.#claim;
    }

    get dependingClaims(): ClaimCheck[] {
        return this.#dependingClaims;
    }

    set dependingClaims(value: ClaimCheck[]) {
        this.#dependingClaims = value;
    }

    get isChecked(): boolean | null {
        return this.#isChecked;
    }

    set isChecked(value: boolean | null) {
        if (value === null) {
            value = false;
        }

        this.#isChecked = value;

        if (value && this.#parentClaim) {
            this.#parentClaim.isChecked = true;
        }

        if (!value) {
            this.#dependingClaims.forEach(dc => dc.isChecked = false);
        }
    }

    get isFullyChecked(): boolean {
        return this.#isChecked && this.#dependingClaims.every(dc => dc.isFullyChecked);
    }

    set isFullyChecked(value: boolean) {
        this.isChecked = value;
        this.#dependingClaims.forEach(dc => dc.isFullyChecked = value);
    }

    set parentClaim(value: ClaimCheck) {
        this.#parentClaim = value;
    }

    get selectedClaims(): string[] {
        if (!this.#isChecked) {
            return [];
        }

        return [this.#claim, ...this.#dependingClaims.map(dc => dc.selectedClaims).flat()];
    }

    get totalCheckedClaims(): number {
        return (this.#isChecked ? 1 : 0) + this.#dependingClaims.map(dc => dc.totalCheckedClaims).reduce((acc, curr) => acc + curr, 0);
    }

    get totalClaims(): number {
        return 1 + this.#dependingClaims.map(dc => dc.totalClaims).reduce((acc, curr) => acc + curr, 0);
    }

    set name(value: string) {
        this.#name = value;
    }

    set claim(value: string) {
        this.#claim = value;
    }

    get parentClaim(): ClaimCheck | null {
        return this.#parentClaim;
    }

    #name: string;
    #claim: string;
    #dependingClaims: ClaimCheck[];
    #isChecked: boolean;
    #parentClaim: ClaimCheck | null = null;

    constructor(name: string, claim: string, isChecked: boolean, dependingClaims: ClaimCheck[]) {
        this.#name = name;
        this.#claim = claim;
        this.#isChecked = isChecked;
        this.#dependingClaims = dependingClaims;
    }
}
