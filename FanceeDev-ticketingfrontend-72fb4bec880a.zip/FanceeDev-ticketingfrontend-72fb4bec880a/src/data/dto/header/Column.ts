import { Dto } from '@fancee/client';

@Dto
export class Column {
    get label(): string {
        return this.#label;
    }

    set label(value: string) {
        this.#label = value;
    }

    get field(): string {
        return this.#field;
    }

    set field(value: string) {
        this.#field = value;
    }

    #label: string;
    #field: string;

    constructor(label: string, field: string) {
        this.#label = label;
        this.#field = field;
    }
}
