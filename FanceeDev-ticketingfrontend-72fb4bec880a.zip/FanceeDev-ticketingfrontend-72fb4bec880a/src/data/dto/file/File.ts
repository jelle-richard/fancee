import { Dto } from '@fancee/client';

@Dto
export class File {
    get file(): object | null {
        return this.#file;
    }

    set file(value: object | null) {
        this.#file = value;
    }

    get url(): string {
        return this.#url;
    }

    set url(value: string) {
        this.#url = value;
    }

    #file: object | null;
    #url: string;

    constructor(file: object | null, url: string) {
        this.#file = file;
        this.#url = url;
    }

    reset(file: File): File {
        file.file = null;
        file.url = '';

        return file;
    }
}
