import { Dto } from '@fancee/client';
import type { IconNames } from '@fancee/flux';

@Dto
export class EventCategory {
    get children(): EventCategory[] | null {
        return this.#children;
    }

    get icon(): IconNames | null {
        return this.#icon;
    }

    get name(): string {
        return this.#name;
    }

    readonly #children: EventCategory[] | null;
    readonly #icon: IconNames | null;
    readonly #name: string;

    constructor(name: string, icon: IconNames | null = null, children: EventCategory[] | null = null) {
        this.#children = children;
        this.#icon = icon;
        this.#name = name;
    }
}
