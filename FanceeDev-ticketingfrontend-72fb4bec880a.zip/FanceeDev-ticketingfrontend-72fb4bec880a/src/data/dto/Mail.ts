import { Dto } from '@fancee/client';
import { Address, DateTimeSpan } from '@fancee/data';
import { Template } from '@/data/dto/editor/Template';
import { formatDateTimeLocal } from '@/util';

@Dto
export class Mail {
    get senderName(): string {
        return this.#senderName;
    }

    set senderName(value: string) {
        this.#senderName = value;
    }

    get subject(): string {
        return this.#subject;
    }

    set subject(value: string) {
        this.#subject = value;
    }

    get content(): string {
        return this.#content;
    }

    set content(value: string) {
        this.#content = value;
    }

    get templateOptions(): Template[] {
        return this.#templateOptions;
    }

    set templateOptions(value: Template[]) {
        this.#templateOptions = value;
    }

    #senderName: string;
    #subject: string;
    #content: string;
    #templateOptions: Template[];

    constructor(senderName: string, subject: string, content: string, templateOptions: Template[]) {
        this.#senderName = senderName;
        this.#subject = subject;
        this.#content = content;
        this.#templateOptions = templateOptions;
    }

    static defaultConfigureEventMail(organizationName: string, eventName: string, minimalAge: number | null, address: Address, eventSpan: DateTimeSpan): Mail {
        let addressRepresentation = '<p>';

        if (address.venue !== null && address.venue.length > 0)
            addressRepresentation += `📌${address.venue}<br>`;

        if (address.street !== null && address.houseNumber !== null && address.street.length > 0 && address.houseNumber.length > 0)
            addressRepresentation += `${address.street} ${address.houseNumber}<br>`;

        if (address.postalCode !== null && address.city !== null && address.postalCode.length > 0 && address.city.length > 0)
            addressRepresentation += `${address.postalCode} ${address.city}<br>`;

        addressRepresentation += '</p>';

        let subject = `Your purchase confirmation for ${eventName}`;
        return new Mail(`On behalf of ${organizationName}`, subject.slice(0, 100),
            `<h2>Hey {firstname} {lastname}!</h2><p><br></p><p>Thank you for your purchase for {event-name}🤘</p><p>Thank you very much and see you on <u>{event-start-date}</u>!</p><p><br></p><p>With kind regards,</p><p>WeAreFancee on behalve of {event-name}</p>`,
            [
                new Template('{firstname}', 'John'),
                new Template('{lastname}', 'Doe'),
                new Template('{event-name}', eventName),
                new Template('{age}', minimalAge === null ? 'none' : minimalAge.toString()),
                new Template('{location}', addressRepresentation),
                new Template('{event-start-date}', formatDateTimeLocal(eventSpan.start)),
                new Template('{event-end-date}', formatDateTimeLocal(eventSpan.end))
            ]);
    }
}
