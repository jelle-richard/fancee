import { Dto } from '@fancee/client';

@Dto
export class Template {
    get key(): string {
        return this.#key;
    }

    set key(value: string) {
        this.#key = value;
    }

    get contents(): string {
        return this.#contents;
    }

    set contents(value: string) {
        this.#contents = value;
    }

    #key: string;
    #contents: string;

    constructor(key: string, contents: string) {
        this.#key = key;
        this.#contents = contents;
    }
}
