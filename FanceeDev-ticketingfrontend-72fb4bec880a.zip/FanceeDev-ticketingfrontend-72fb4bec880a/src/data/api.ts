import { BaseResponse, FanceeClient, HttpStatusCode } from '@fancee/client';
import { useRollbar } from '@/composable';
import { ENVIRONMENT } from '@/data/constant';
import { AnalyticsClient } from '@/data/adapter/AnalyticsClient';

const SKIP_STATUS_CODES = [
    HttpStatusCode.Ok,
    HttpStatusCode.Created,
    HttpStatusCode.Accepted,
    HttpStatusCode.NoContent,
    HttpStatusCode.BadRequest,
    HttpStatusCode.Unauthorized,
    HttpStatusCode.Forbidden
];

const SKIP_URLS = [
    '/api/auth/'
];

export function initializeApi(): void {
    if (ENVIRONMENT === 'production') {
        FanceeClient.register(new class Client extends FanceeClient {
            constructor() {
                super(null, import.meta.env.VITE_API_URL);
            }

            public onResponse(response: BaseResponse<unknown>) {
                if (SKIP_STATUS_CODES.includes(response.statusCode)) {
                    return;
                }

                for (const url of SKIP_URLS) {
                    if (response.response.url.includes(url)) {
                        return;
                    }
                }

                const url = response.response.url.replace(window.origin, '');
                const headers: Record<string, string> = {};
                response.headers.forEach((value, key) => headers[key] = value);

                const data = JSON.parse(JSON.stringify({
                    data: response.data,
                    errors: response.errors,
                    headers: headers,
                    statusCode: response.statusCode
                }));

                const rollbar = useRollbar();
                rollbar.warn(`Failed request response from API. (${url})`, data);
            }
        });
    } else {
        FanceeClient.register(new FanceeClient(null, import.meta.env.VITE_API_URL));
    }

    AnalyticsClient.register(new FanceeClient(null, import.meta.env.VITE_ANALYTICS_URL));
}
