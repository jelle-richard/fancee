<template>
    <FluxStack>
        <slot
            :data="items"
            :is-loading="isLoading"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { DashboardService } from '@/data/service';
    import { SumCampaignItem } from '@/data/dto/analytics/dashboard';

    export interface Props {
        readonly channelId: string;
        readonly campaignId: string;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channelId, campaignId, startDate, endDate} = toRefs(props);

    const isLoading = ref(false);
    const items = ref<SumCampaignItem[]>([]);
    const {getSingleSumCampaign} = useService(DashboardService);

    async function updateData(): Promise<void> {
        isLoading.value = true;

        const result = await getSingleSumCampaign(unref(channelId), unref(campaignId), unref(startDate), unref(endDate));

        items.value = result.data;
        isLoading.value = false;
    }

    watch([channelId, campaignId, startDate, endDate], updateData, {deep: true, immediate: true});
</script>
