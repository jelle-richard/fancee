<template>
    <FluxStack>
        <slot
            :data="channels"
            :page="currentPage"
            :pageSize="pageLength"
            :totalItems="totalItems"
            :orderBy="orderBy"
            :orderByDirection="orderByDirection"
            :is-loading="isLoading"
            :onPageUpdate="setCurrentPage"
            :onPageSizeUpdate="setPageLength"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref, watch } from 'vue';
    import { usePagination, useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelsService, SubscriptionsService } from '@/data/service';

    export interface Props {
        readonly includeSubscriptions?: boolean;
        readonly startingPageLength?: number;
    }

    const props = withDefaults(defineProps<Props>(), {
        includeSubscriptions: false,
        startingPageLength: 10
    });
    const {includeSubscriptions, startingPageLength} = toRefs(props);

    const channels = ref<Channel[]>([]);

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination(unref(startingPageLength));

    const isLoading = ref(false);
    const {getPaginatedTable} = useService(ChannelsService);
    const {subscriptions: getSubscriptions} = useService(SubscriptionsService);

    const orderBy = ref<string | null>('CreatedOn');
    const orderByDirection = ref<'ascending' | 'descending' | null>('ascending');

    function onOrderUpdate(fieldName: string | null, direction: 'ascending' | 'descending' | null): void {
        orderBy.value = fieldName;
        orderByDirection.value = direction;
        setCurrentPage(1);
    }

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getPaginatedTable(unref(pageLength), unref(currentPage), unref(orderBy), unref(orderByDirection) === 'ascending');

        if (unref(includeSubscriptions)) {
            for await (const channel of response.data.items) {
                const subResponse = await getSubscriptions(channel);
                channel.subscriptions = subResponse.data;
            }
        }

        channels.value = response.data.items;
        setTotalItems(response.data.totalItems);

        isLoading.value = false;
    }

    defineExpose({updateData, onOrderUpdate});

    watch([currentPage, pageLength, orderBy, orderByDirection], updateData, {deep: true, immediate: true});
</script>
