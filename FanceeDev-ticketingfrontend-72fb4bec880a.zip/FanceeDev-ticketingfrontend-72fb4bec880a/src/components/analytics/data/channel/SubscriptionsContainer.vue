<template>
    <FluxStack v-if="channel">
        <slot
            :data="subscriptions"
            :is-loading="isLoading"
            :type="channel.type"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { Subscription } from '@/data/dto/analytics/subscriptions';
    import { SubscriptionsService } from '@/data/service/SubscriptionsService';

    export interface Props {
        readonly channel: Channel;
    }

    const props = defineProps<Props>();
    const {channel} = toRefs(props);

    const isLoading = ref(false);
    const subscriptions = ref<Subscription[]>([]);
    const {subscriptions: getList} = useService(SubscriptionsService);

    async function updateData(): Promise<void> {
        isLoading.value = true;

        const response = await getList(unref(channel));
        subscriptions.value = response.data;

        isLoading.value = false;
    }

    watch(channel, updateData, {deep: true, immediate: true});
</script>
