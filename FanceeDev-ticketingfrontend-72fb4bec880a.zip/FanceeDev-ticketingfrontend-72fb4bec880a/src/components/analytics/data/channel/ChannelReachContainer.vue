<template>
    <FluxStack v-if="channel && supportedChannelTypes.includes(channel.type)">
        <slot
            :data="channelReach"
            :is-loading="isLoading"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { ChannelsService } from '@/data/service';
    import { Channel, ChannelReach } from '@/data/dto/analytics/channels';

    export interface Props {
        readonly channel: Channel;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channel, startDate, endDate} = toRefs(props);

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook,
        ChannelType.Instagram
    ];
    const channelReach = ref<ChannelReach>(ChannelReach.empty());
    const isLoading = ref(false);
    const {getReach} = useService(ChannelsService);

    async function updateData(): Promise<void> {
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        isLoading.value = true;
        const response = await getReach(currentChannel.id, unref(startDate), unref(endDate));
        channelReach.value = response.data;

        isLoading.value = false;
    }

    function clear(): void {
        channelReach.value = ChannelReach.empty();
        isLoading.value = false;
    }

    watch([channel, startDate, endDate], updateData, {deep: true, immediate: true});
</script>
