<template>
    <FluxStack>
        <slot
            :data="logs"
            :page="currentPage"
            :pageLength="pageLength"
            :totalItems="totalItems"
            :is-loading="isLoading"
            :onPageUpdate="setCurrentPage"
            :onPageSizeUpdate="setPageLength"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { ref, unref, watch } from 'vue';
    import { usePagination, useService } from '@/composable';
    import { Log } from '@/data/dto/analytics/logs/Log';
    import { LogsService } from '@/data/service/LogsService';

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination(5);

    const isLoading = ref(false);
    const logs = ref<Log[]>([]);
    const {getPaginatedList} = useService(LogsService);

    async function updateData(): Promise<void> {
        isLoading.value = true;

        try {
            const response = await getPaginatedList(unref(pageLength), unref(currentPage));
            logs.value = response.data.items;
            setTotalItems(response.data.totalItems);
        } catch {
            logs.value = [];
            setTotalItems(0);
        }

        isLoading.value = false;
    }

    watch([currentPage, pageLength], updateData, {deep: true, immediate: true});
</script>
