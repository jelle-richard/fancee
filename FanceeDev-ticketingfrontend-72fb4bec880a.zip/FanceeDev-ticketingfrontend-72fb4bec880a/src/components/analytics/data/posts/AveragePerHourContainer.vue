<template>
    <FluxGridColumn
        v-if="supportedChannelTypes.includes(props.channel.type)"
        :xl="6"
        :md="8"
        :sm="12">
        <slot
            :data="averages"
            :categories="chartCategories"
            :title="title"
            :is-loading="isLoading"/>
    </FluxGridColumn>
</template>

<script
    lang="ts"
    setup>
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { DateTime } from 'luxon';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { PostsService } from '@/data/service/PostsService';

    export interface Props {
        channel: Channel;
        startDate: DateTime;
        endDate: DateTime;
        selection: string;
    }

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook,
        ChannelType.Instagram
    ];
    const props = defineProps<Props>();
    const {channel, startDate, endDate, selection} = toRefs(props);

    const isLoading = ref(false);
    const averages = ref<number[]>([]);
    const chartCategories = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'];
    const {getBestHourToPostOn} = useService(PostsService);

    const title = computed((): string => {
        const currentAverages = unref(averages);

        if (currentAverages.length === 0) {
            return '';
        }

        return Math.max(...currentAverages.map(o => o)).toString();
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        const response = await getBestHourToPostOn(currentChannel.id, unref(selection), unref(startDate), unref(endDate));
        let newHoursArray = new Array(24).fill(0);
        response.data.forEach(item => {
            newHoursArray[parseInt(item.hour)] = item.average;
        });
        averages.value = newHoursArray;
        isLoading.value = false;
    }

    function clear(): void {
        averages.value = [];
        isLoading.value = false;
    }

    watch([channel, startDate, endDate, selection], updateData, {deep: true, immediate: true});
</script>
