<template>
    <FluxGridColumn
        v-if="supportedChannelTypes.includes(channel.type)"
        :sm="12">
        <slot
            :data="posts"
            :page="currentPage"
            :pageSize="pageLength"
            :totalItems="totalItems"
            :is-loading="isLoading"
            :onPageUpdate="setCurrentPage"
            :onPageSizeUpdate="setPageLength"/>
    </FluxGridColumn>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { usePagination, useService } from '@/composable';
    import { Post } from '@/data/dto/analytics/posts';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { PostsService } from '@/data/service/PostsService';

    export interface Props {
        readonly channel: Channel;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
        readonly selection: string;
        readonly pageSize?: number;
    }

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook,
        ChannelType.Instagram
    ];

    const props = defineProps<Props>();
    const {channel, startDate, endDate, selection} = toRefs(props);

    const posts = ref<Post[]>([]);

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination(props.pageSize);

    const isLoading = ref(false);
    const {getTopPostsPaginated} = useService(PostsService);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        const response = await getTopPostsPaginated(currentChannel.id, unref(selection), unref(pageLength), unref(currentPage), unref(startDate), unref(endDate));
        posts.value = response.data.items;
        setTotalItems(response.data.totalItems);

        isLoading.value = false;
    }

    function clear(): void {
        posts.value = [];
        isLoading.value = false;
    }

    watch([channel, startDate, endDate, selection, pageLength, currentPage], updateData, {deep: true, immediate: true});
</script>
