<template>
    <FluxGridColumn
        v-if="supportedChannelTypes.includes(channel.type)"
        :xl="3"
        :md="4"
        :sm="6">
        <slot
            :data="keywords"
            :title="title"
            :is-loading="isLoading"/>
    </FluxGridColumn>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { Keyword } from '@/data/dto/analytics/posts';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { PostsService } from '@/data/service/PostsService';

    export interface Props {
        channel: Channel;
        startDate: DateTime;
        endDate: DateTime;
        category: string;
    }

    const props = defineProps<Props>();
    const {channel, startDate, endDate, category} = toRefs(props);

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook,
        ChannelType.Instagram
    ];

    const isLoading = ref(false);
    const keywords = ref<Keyword[]>([]);
    const {getTopKeywords} = useService(PostsService);

    const title = computed((): string => {
        const currentKeywords = unref(keywords);

        if (currentKeywords.length === 0) {
            return '';
        }

        return currentKeywords.reduce((a, b) => a.amount > b.amount ? a : b).word;
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        const response = await getTopKeywords(currentChannel.id, unref(category), unref(startDate), unref(endDate));
        keywords.value = response.data;
        isLoading.value = false;
    }

    function clear(): void {
        keywords.value = [];
        isLoading.value = false;
    }

    watch([channel, startDate, endDate, category], updateData, {deep: true, immediate: true});
</script>
