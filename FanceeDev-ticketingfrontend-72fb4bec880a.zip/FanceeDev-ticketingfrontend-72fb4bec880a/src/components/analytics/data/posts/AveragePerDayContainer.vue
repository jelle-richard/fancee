<template>
    <FluxGridColumn
        v-if="channel && supportedChannelTypes.includes(channel.type)"
        :xl="3"
        :md="4"
        :sm="6">
        <slot
            :data="averages"
            :categories="chartCategories"
            :title="title"
            :is-loading="isLoading"/>
    </FluxGridColumn>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { PostsService } from '@/data/service/PostsService';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';

    export interface Props {
        channel: Channel;
        selection: string;
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channel, selection, startDate, endDate} = toRefs(props);

    const {t} = useI18n();

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook,
        ChannelType.Instagram
    ];
    const isLoading = ref(false);
    const averages = ref<number[]>([]);
    const chartCategories = [
        t('global.dayStr.monday'),
        t('global.dayStr.tuesday'),
        t('global.dayStr.wednesday'),
        t('global.dayStr.thursday'),
        t('global.dayStr.friday'),
        t('global.dayStr.saturday'),
        t('global.dayStr.sunday')
    ];

    const {getBestDayToPostOn} = useService(PostsService);

    const title = computed((): string => {
        const currentAverages = unref(averages);

        if (currentAverages.length === 0) {
            return '';
        }

        return Math.max(...currentAverages.map(o => o)).toString();
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        const response = await getBestDayToPostOn(currentChannel.id, unref(selection), unref(startDate), unref(endDate));
        averages.value = [
            response.data.find(e => e.dayOfWeek === 'Monday')?.average ?? 0,
            response.data.find(e => e.dayOfWeek === 'Tuesday')?.average ?? 0,
            response.data.find(e => e.dayOfWeek === 'Wednesday')?.average ?? 0,
            response.data.find(e => e.dayOfWeek === 'Thursday')?.average ?? 0,
            response.data.find(e => e.dayOfWeek === 'Friday')?.average ?? 0,
            response.data.find(e => e.dayOfWeek === 'Saturday')?.average ?? 0,
            response.data.find(e => e.dayOfWeek === 'Sunday')?.average ?? 0
        ];
        isLoading.value = false;
    }

    function clear(): void {
        averages.value = [];
        isLoading.value = false;
    }

    watch([channel, startDate, endDate, selection], updateData, {deep: true, immediate: true});
</script>
