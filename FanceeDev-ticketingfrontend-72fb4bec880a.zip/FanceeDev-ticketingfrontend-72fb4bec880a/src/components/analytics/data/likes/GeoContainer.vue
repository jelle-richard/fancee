<template>
    <FluxGridColumn
        v-if="supportedChannelTypes.includes(channel.type)"
        :md="6"
        :xl="12">
        <slot
            :data="locations"
            :is-loading="isLoading"/>
    </FluxGridColumn>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { GeoLike } from '@/data/dto/analytics/likes';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { LikesService } from '@/data/service/LikesService';

    export interface Props {
        readonly channel: Channel;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channel, startDate, endDate} = toRefs(props);

    const isLoading = ref(false);
    const locations = ref<GeoLike[]>([]);

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook,
        ChannelType.Instagram
    ];

    const {getGeoLikes} = useService(LikesService);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        const response = await getGeoLikes(currentChannel.id, unref(startDate), unref(endDate));
        locations.value = response.data;

        isLoading.value = false;
    }

    function clear(): void {
        locations.value = [];
        isLoading.value = false;
    }

    watch([channel, startDate, endDate], updateData, {deep: true, immediate: true});
</script>
