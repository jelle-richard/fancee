export { default as AgeContainer } from './AgeContainer.vue';
export { default as EmotionsContainer } from './EmotionsContainer.vue';
export { default as GenderContainer } from './GenderContainer.vue';
export { default as GeoContainer } from './GeoContainer.vue';
