<template>
    <FluxGridColumn
        v-if="supportedChannelTypes.includes(channel.type)"
        :xl="3"
        :md="4"
        :sm="6">
        <slot
            :data="genders"
            :categories="chartCategories"
            :is-loading="isLoading"/>
    </FluxGridColumn>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { Channel } from '@/data/dto/analytics/channels';
    import { LikesService } from '@/data/service/LikesService';

    export interface Props {
        readonly channel: Channel;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channel, startDate, endDate} = toRefs(props);

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook,
        ChannelType.Instagram
    ];
    const isLoading = ref(false);
    const genders = ref<number[]>([]);
    const chartCategories = ref<string[]>([]);
    const {getGenderLikes} = useService(LikesService);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        const response = await getGenderLikes(currentChannel.id, unref(startDate), unref(endDate));
        genders.value = response.data.map(item => item.likesAmount);
        chartCategories.value = response.data.map(item => item.gender);

        isLoading.value = false;
    }

    function clear(): void {
        genders.value = [];
        isLoading.value = false;
    }

    watch([channel, startDate, endDate], updateData, {deep: true, immediate: true});
</script>
