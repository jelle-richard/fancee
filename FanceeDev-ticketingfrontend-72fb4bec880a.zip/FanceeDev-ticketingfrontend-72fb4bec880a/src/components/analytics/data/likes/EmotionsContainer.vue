<template>
    <FluxGridColumn
        v-if="supportedChannelTypes.includes(channel.type)"
        :xl="3"
        :md="4"
        :sm="6">
        <slot
            :data="emotions"
            :categories="chartCategories"
            :is-loading="isLoading"/>
    </FluxGridColumn>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { LikesService } from '@/data/service/LikesService';

    export interface Props {
        readonly channel: Channel;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channel, startDate, endDate} = toRefs(props);

    const supportedChannelTypes: ChannelType[] = [
        ChannelType.Facebook
    ];
    const isLoading = ref(false);
    const emotions = ref<number[]>([]);
    const chartCategories = ref<string[]>([]);
    const {getEmotionLikes} = useService(LikesService);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentChannel = unref(channel);

        if (!supportedChannelTypes.includes(currentChannel.type)) {
            clear();
            return;
        }

        const response = await getEmotionLikes(currentChannel.id, unref(startDate), unref(endDate));
        const usefulList = response.data.filter(item => item.amount > 0);

        emotions.value = usefulList.map(item => item.amount);
        chartCategories.value = usefulList.map(item => item.emotion);

        isLoading.value = false;
    }

    function clear(): void {
        emotions.value = [];
        chartCategories.value = [];
        isLoading.value = false;
    }

    watch([channel, startDate, endDate], updateData, {deep: true, immediate: true});
</script>
