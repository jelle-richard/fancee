<template>
    <FluxStack>
        <slot
            :data="subscriptionsWithEntries"
            :is-loading="isLoading"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { Subscription } from '@/data/dto/analytics/subscriptions';
    import { SubscriptionType } from '@/data/enum/analytics/api';
    import { SubscriptionsService } from '@/data/service/SubscriptionsService';

    export interface Props {
        readonly subscriptions: Subscription[];
        readonly types?: SubscriptionType[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {subscriptions, types, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {entries: getEntries} = useService(SubscriptionsService);

    const isLoading = ref(false);
    const subscriptionsWithEntries = ref<Subscription[]>([]);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        let newListOfSubscriptions: Subscription[] = [];
        const typesFilter = unref(types);
        const currentSubscriptions = unref(subscriptions);
        const filteredSubscriptionList = !!typesFilter ? currentSubscriptions.filter(sub => typesFilter.includes(sub.type)) : currentSubscriptions;

        for (let subscription of filteredSubscriptionList) {
            const response = await getEntries(subscription.id, unref(startDate), unref(endDate));

            let subscriptionWithEntries = Subscription.copyWithEntries(subscription, response.data);
            subscriptionWithEntries.name = t(subscriptionWithEntries.type.toLowerCase());
            newListOfSubscriptions.push(subscriptionWithEntries);
        }

        subscriptionsWithEntries.value = newListOfSubscriptions;
        isLoading.value = false;
    }

    watch([subscriptions, startDate, endDate], updateData, {deep: true, immediate: true});
</script>
