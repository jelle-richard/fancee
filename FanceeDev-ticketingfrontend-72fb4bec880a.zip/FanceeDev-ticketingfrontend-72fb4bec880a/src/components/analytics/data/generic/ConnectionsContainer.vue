<template>
    <FluxStack>
        <slot
            :data="connections"
            :page="currentPage"
            :pageLength="pageLength"
            :totalItems="totalItems"
            :is-loading="isLoading"
            :setCurrentPage="setCurrentPage"
            :setPageLength="setPageLength"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref, watch } from 'vue';
    import { usePagination, useService } from '@/composable';
    import { Connection } from '@/data/dto/analytics/logs/Connection';
    import { SubscriptionsService } from '@/data/service/SubscriptionsService';
    import { Subscription } from '@/data/dto/analytics/subscriptions';

    export interface Props {
        readonly subscription: Subscription;
    }

    const props = defineProps<Props>();
    const {subscription} = toRefs(props);

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination(5);

    const isLoading = ref(false);
    const connections = ref<Connection[]>([]);
    const {connections: getList} = useService(SubscriptionsService);

    async function updateData(): Promise<void> {
        isLoading.value = true;

        const result = await getList(unref(subscription), unref(currentPage), unref(pageLength));
        connections.value = result.data.items;
        setTotalItems(result.data.totalItems);

        isLoading.value = false;
    }

    watch([subscription, currentPage, pageLength], updateData, {immediate: true});
</script>
