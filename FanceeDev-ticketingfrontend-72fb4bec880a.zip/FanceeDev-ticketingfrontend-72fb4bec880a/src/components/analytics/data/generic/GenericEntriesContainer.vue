<template>
    <FluxStack>
        <slot
            :data="entries"
            :is-loading="isLoading"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { SubscriptionsService } from '@/data/service/SubscriptionsService';
    import { GenericEntry } from '@/data/dto/analytics/subscriptions';

    export interface Props {
        readonly subscriptionId: string;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {subscriptionId, startDate, endDate} = toRefs(props);

    const isLoading = ref(false);
    const entries = ref<GenericEntry[]>([]);
    const {entries: getEntries} = useService(SubscriptionsService);

    async function updateData(): Promise<void> {
        isLoading.value = true;

        const result = await getEntries(unref(subscriptionId), unref(startDate), unref(endDate));

        entries.value = result.data;
        isLoading.value = false;
    }

    watch([subscriptionId, startDate, endDate], updateData, {deep: true, immediate: true});
</script>
