<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="t('analytics.reach.title')"/>

        <FluxPaneBody>
            <FluxStatistic
                axis="vertical"
                icon="plus"
                :change-color="sumGained - sumLost  > 0 ? 'danger' : 'danger'"
                :color="sumGained - sumLost  > 0 ? 'danger' : 'danger'"
                :value="asCompactNumber(Math.abs(sumGained - sumLost))"
                :label="sumGained - sumLost > 0 ? t('analytics.reach.gained') : t('analytics.reach.lost')"/>

            <FluxBadge
                v-if="sumGained !== 0 && sumTotal !== 0"
                :label="sumPercentageLabel"
                :icon="sumPercentage >= 0 ? 'arrow-up' : 'arrow-down'"
                :color="sumPercentage >= 0 ? 'success' : 'danger'"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { DashboardService } from '@/data/service/DashboardService';
    import { SumLostAndGainedGroup, SumResponse } from '@/data/dto/analytics/dashboard';
    import { asCompactNumber, asFormattedPercentage } from '@/util';

    interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumReach} = useService(DashboardService);

    const sumReach = ref<SumResponse<SumLostAndGainedGroup> | null>(null);
    const isLoading = ref(false);

    const sumGained = computed(() => unref(sumReach)?.items.reduce((acc, curr) => acc + curr.totalGained, 0) ?? 0);
    const sumLost = computed(() => unref(sumReach)?.items.reduce((acc, curr) => acc + curr.totalLost, 0) ?? 0);
    const sumTotal = computed(() => unref(sumReach)?.last?.total ?? 0);

    const sumPercentage = computed((): number => {
        const startTotal = unref(sumReach)?.first?.total ?? 0;
        const diffTotal = unref(sumTotal) - startTotal;

        if (diffTotal === 0 || startTotal === 0) {
            return 0;
        }

        return ((diffTotal / startTotal) * 100);
    });

    const sumPercentageLabel = computed(() => t(unref(sumPercentage) >= 0 ? 'analytics.reach.gainedPercentage' : 'analytics.reach.lostPercentage', [asFormattedPercentage(unref(sumPercentage) / 100)]));

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumReach(unref(channels), unref(startDate), unref(endDate));
        sumReach.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .flux-pane-body {
        align-items: flex-start;
    }

    .flux-statistic {
        flex: 1;
        border: 0;
        box-shadow: none;
        padding: 0 0 0.5rem;
        align-items: flex-start;
    }

    .flux-stack {
        flex: 1;
        width: 100%;
    }

    ::v-deep(.flux-badge) {
        margin-top: 9px;

        &.is-success {
            background: rgb(var(--success-2));
            border-color: rgb(var(--success-3) / .5);
            color: rgb(var(--success-10));
        }

        &.is-danger {
            background: rgb(var(--danger-2));
            border-color: rgb(var(--danger-3) / .5);
            color: rgb(var(--danger-10));
        }
    }

    ::v-deep(.flux-statistic-icon) {
        display: none;
    }

    ::v-deep(.flux-statistic).is-vertical .flux-statistic-data {
        align-items: flex-start;
    }
</style>
