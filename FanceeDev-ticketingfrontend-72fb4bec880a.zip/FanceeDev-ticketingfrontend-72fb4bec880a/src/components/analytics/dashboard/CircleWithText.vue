<template>
    <svg
        class="border-with-text"
        preserveAspectRatio="xMidYMid meet"
        viewBox="0 0 100 100"
        xmlns="http://www.w3.org/2000/svg">
        <path
            id="circle"
            fill="none"
            stroke-width="6"
            stroke="rgb(95, 114, 181)"
            :d="svgPath(100, 47, false)"/>
        <path
            id="circlePath"
            fill="none"
            stroke-width="1"
            stroke="none"
            :d="svgPath(100, 46, false)"/>
        <path
            id="circlePathReverse"
            fill="none"
            stroke-width="1"
            stroke="none"
            :d="svgPath(100, 48, true)"/>

        <text v-if="titles">
            <textPath
                v-for="title in titles"
                :href="`${toHref(title.inside)}`"
                :startOffset="title.offset">
                {{ title.text }}
            </textPath>
        </text>
    </svg>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { RotatedText } from '@/data/interface/charts';

    export interface Props {
        readonly titles: RotatedText[] | null;
    }

    defineProps<Props>();

    const {t} = useI18n();

    function toHref(inside?: boolean): string {
        return inside === true ? '#circlePathReverse' : '#circlePath';
    }

    const svgPath = (viewBox: number, radius: number, inside: boolean) => `
        M ${viewBox * 0.5 - radius}, ${viewBox * 0.5}
        a ${radius},${radius} 0 1,${inside ? 0 : 1} ${radius * 2},0
        ${radius},${radius} 0 1,${inside ? 0 : 1} -${radius * 2},0`;
</script>

<style
    lang="scss"
    scoped>
    span,
    svg {
        pointer-events: none;
    }

    .border-with-text {
        width: 330px;
    }

    text {
        font-size: 4px;
        font-weight: normal;
        fill: white;
        font-family: manrope-variable, sans-serif !important;
    }
</style>x
