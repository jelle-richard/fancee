<template>
    <FluxStack>
        <JumboSelector
            :options="channelOptions"
            :title="`${t('analytics.monitor.title')}`"
            :subtitle="''"
            :select-placeholder="`${t('analytics.monitor.placeholder')}...`"
            :is-loading-options="isLoading"
            @selected-row-changed="setChannel"/>

        <FluxStack
            v-if="channelId"
            axis="horizontal">
            <FluxFormField :label="t('form.field.startDate')">
                <FluxFormDateInput v-model="startDateSelect"/>
            </FluxFormField>

            <FluxFormField :label="t('form.field.endDate')">
                <FluxFormDateInput v-model="endDateSelect"/>
            </FluxFormField>
        </FluxStack>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { FluxFormSelectOption } from '@fancee/flux';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { Channel } from '@/data/dto/analytics/channels';
    import { getChannelTypeIcon } from '@/product/analytics/util';
    import JumboSelector from '@/product/ticketing/views/dashboard/generic/components/JumboSelector.vue';

    export type Emits = {
        (e: 'channel-changed', selectedChannel?: Channel): void;
        (e: 'start-date-changed', newDate?: DateTime): void;
        (e: 'end-date-changed', newDate?: DateTime): void;
        (e: 'select-input-changed', search?: string): void;
    };

    export type Props = {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
        readonly isLoading: boolean;
    };

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();

    const channelId = ref<string | null>(null);
    const startDateSelect = ref(unref(startDate));
    const endDateSelect = ref(unref(endDate));

    const channelOptions = computed((): FluxFormSelectOption[] => unref(channels).map(ch => ({
        icon: getChannelTypeIcon(ch.type),
        label: ch.name,
        id: ch.id ?? ''
    })));

    const setChannel = (newChannelId: string | null): void => {
        channelId.value = newChannelId;
        emit('channel-changed', unref(channels).find(c => c.id === newChannelId));
    };

    watch(startDateSelect, newDate => emit('start-date-changed', newDate));
    watch(endDateSelect, newDate => emit('end-date-changed', newDate));
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-form-select) {
        flex: 1;

        > .flux-menu-item {
            display: contents;

            .flux-button-label {
                padding-right: 2rem;
            }
        }
    }

    ::v-deep(.flux-grid-column).text-center {
        display: flex;
        flex-direction: Column;

        .flux-form-input-group {
            align-self: center;
        }
    }
</style>
