<template>
    <ColumnChartCard
        :key="Math.random()"
        :is-loading="isLoading"
        :title="t('analytics.ticketing.averageOrderReservation.title')"
        :height="chartHeight"
        :chart-data="chartSeries"
        :chart-options="chartOptions"/>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { DashboardService } from '@/data/service/DashboardService';
    import { CHART_BAR_AMOUNT, CHART_BAR_HEIGHT, CHART_BAR_MANY_HEIGHT, CHART_COLOR_ARRAY, CHART_COLORS, CHART_MIN_HEIGHT, LUXON_MINUTES_WITH_SECONDS_DECLARATION } from '@/data';
    import { AverageCompletionTimes } from '@/data/dto/analytics/dashboard';
    import { formatDuration } from '@/util';
    import ColumnChartCard from '@/components/analytics/cards/ColumnChartCard.vue';

    export type Props = {
        selectedEventIds: string[];
        startDate: DateTime;
        endDate: DateTime;
    };

    const props = defineProps<Props>();

    const {selectedEventIds, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getAverageTimes} = useService(DashboardService);
    const organizationId = useActiveOrganizationId();

    const chartHeight = computed(() => {
        const _entries = unref(entries)?.length ?? 0;

        return CHART_MIN_HEIGHT + ((_entries < CHART_BAR_AMOUNT ? CHART_BAR_HEIGHT : CHART_BAR_MANY_HEIGHT * 2) * _entries);
    });

    const entries = ref<AverageCompletionTimes[] | null>(null);
    const isLoading = ref(false);
    const chartSeries = ref<ApexAxisChartSeries[]>([]);
    const chartOptions = ref<ApexOptions>({
        chart: {
            type: 'bar',
            stacked: false,
            toolbar: {
                show: false
            }
        },
        legend: {
            position: 'bottom'
        },
        plotOptions: {
            bar: {
                horizontal: true,
                dataLabels: {
                    position: 'bottom'
                }
            }
        },
        tooltip: {
            enabled: false
        },
        colors: CHART_COLOR_ARRAY,
        dataLabels: {
            enabled: true,
            textAnchor: 'start',
            formatter: (value: number) => formatDuration({seconds: value}, LUXON_MINUTES_WITH_SECONDS_DECLARATION),
            offsetX: 0,
            offsetY: -2,
            background: {
                enabled: true,
                foreColor: CHART_COLORS[0],
                padding: 4,
                borderRadius: 2,
                borderWidth: 1,
                borderColor: CHART_COLORS[0],
                opacity: 1
            }
        },
        stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
        },
        xaxis: {
            labels: {
                formatter: (value: string) => formatDuration({seconds: Number(value)}, LUXON_MINUTES_WITH_SECONDS_DECLARATION)
            }
        },
        fill: {
            opacity: 1
        }
    });

    function fillChart(): void {
        chartSeries.value = [];
        chartOptions.value.labels = [];

        if (!unref(entries)) {
            return;
        }

        const reservationTimes: number[] = [];
        const orderTimes: number[] = [];

        unref(entries)!.forEach(e => {
            reservationTimes.push(e.averageReservationCompletionTimeSeconds);
            orderTimes.push(e.averageOrderCompletionTimeSeconds);
            chartOptions.value.labels!.push(e.name);
        });

        chartSeries.value.push(
            {data: reservationTimes, name: t('analytics.ticketing.averageOrderReservation.reservationTime')} as unknown as ApexAxisChartSeries,
            {data: orderTimes, name: t('analytics.ticketing.averageOrderReservation.orderTime')} as unknown as ApexAxisChartSeries
        );
    }

    async function updateData() {
        isLoading.value = true;
        const response = await getAverageTimes(unref(organizationId), unref(selectedEventIds), unref(startDate), unref(endDate));
        entries.value = response.data;
        fillChart();
        isLoading.value = false;
    }

    watch([startDate, endDate, selectedEventIds], updateData, {deep: true, immediate: true});
</script>
