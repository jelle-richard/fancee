<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="t('analytics.post.title')"/>

        <FluxDataTable
            :data-set="posts"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems"
            is-hoverable>
            <template #header>
                <FluxTableHeader>
                    {{ t('analytics.post.table.channel') }}
                    <MultiSortMenu
                        :options="['Name']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.post.table.date') }}
                    <MultiSortMenu
                        :options="['Date']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.post.table.type') }}
                    <MultiSortMenu
                        :options="['Type']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader class="justify-content-center">
                    {{ t('analytics.post.table.engagement') }}
                    <MultiSortMenu
                        :options="['Comments', 'Likes', 'Shares']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader class="justify-content-center">
                    {{ t('analytics.post.table.conversion') }}
                    <MultiSortMenu
                        :options="['Clicks', 'Views']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader class="justify-content-center">
                    {{ t('analytics.post.table.paidYesNo') }}
                    <MultiSortMenu
                        :options="['Paid']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader is-shrinking/>
            </template>

            <template #channel="{row: {source, name, url, message }}">
                <FluxTableCell class="align-items-center">
                    <img
                        class="channel-icon"
                        :src="getSubscriptionTypeSVGPath(source)"
                        alt=""/>

                    <FluxStack gap="0">
                        <label><strong>{{ name }}</strong></label>
                        <label>{{ truncateString(message, 20) }}</label>
                    </FluxStack>
                </FluxTableCell>
            </template>

            <template #date="{row: {date, time}}">
                <FluxTableCell
                    class="justify-content-center"
                    contentDirection="column">
                    <label class="cell-title">{{ formatDate(date) }}</label>
                    <label>{{ time?.substring(0, 5) }}</label>
                </FluxTableCell>
            </template>

            <template #type="{row: {postType}}">
                <FluxTableCell class="align-items-center">
                    <label v-if="postType !== ''">{{ t(`analytics.post.type.${postType.toLowerCase()}`) }}</label>
                </FluxTableCell>
            </template>

            <template #engagement="{row: {comments, likes, shares}}">
                <FluxTableCell class="align-items-center justify-content-center">
                    <FluxStack
                        class="post-inner-stack"
                        axis="horizontal">
                        <FluxStack
                            class="align-items-center"
                            gap="0">
                            <label>{{ comments }}</label>
                            <label class="cell-title">{{ t('analytics.post.comments') }}</label>
                        </FluxStack>

                        <FluxStack
                            class="align-items-center"
                            gap="0">
                            <label>{{ likes }}</label>
                            <label class="cell-title">{{ t('analytics.post.likes') }}</label>
                        </FluxStack>

                        <FluxStack
                            class="align-items-center"
                            gap="0">
                            <label>{{ shares }}</label>
                            <label class="cell-title">{{ t('analytics.post.shares') }}</label>
                        </FluxStack>
                    </FluxStack>
                </FluxTableCell>
            </template>

            <template #conversion="{row: {clicks, views}}">
                <FluxTableCell class="align-items-center justify-content-center">
                    <FluxStack
                        class="post-inner-stack"
                        axis="horizontal">
                        <FluxStack
                            class="align-items-center"
                            gap="0">
                            <label>{{ clicks }}</label>
                            <label class="cell-title">{{ t('analytics.post.clicks') }}</label>
                        </FluxStack>

                        <FluxStack
                            class="align-items-center"
                            gap="0">
                            <label>{{ views }}</label>
                            <label class="cell-title">{{ t('analytics.post.views') }}</label>
                        </FluxStack>
                    </FluxStack>
                </FluxTableCell>
            </template>

            <template #paid="{row: {paid}}">
                <FluxTableCell class="align-items-center justify-content-center">
                    <label>{{ paid === true ? t('global.yesSmall') : t('global.noSmall') }}</label>
                </FluxTableCell>
            </template>

            <template #actions="{row: { url }}">
                <FluxTableCell class="align-items-center justify-content-center">
                    <FluxTableActions>
                        <FluxAction
                            icon="arrow-up-right-from-square"
                            @click="openPostInNewTab(url)"/>
                    </FluxTableActions>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneBody v-if="!isLoading && posts.length === 0">
            <NoDashboardData variation="full"/>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="(limit: number) => {
                    setCurrentPage(1);
                    setPageLength(limit);
                }"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { truncateString } from '@fancee/data';
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { usePagination, useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumPostItem } from '@/data/dto/analytics/dashboard';
    import { DashboardService } from '@/data/service/DashboardService';
    import { getSubscriptionTypeSVGPath } from '@/product/analytics/util';
    import { formatDate } from '@/util';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';
    import MultiSortMenu from '@/components/analytics/posts/MultiSortMenu.vue';

    interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination(5);

    const {t} = useI18n();
    const {getSumPostsPaginated} = useService(DashboardService);

    const posts = ref<SumPostItem[]>([]);
    const isLoading = ref(false);
    const orderBy = ref<string | null>('Date');
    const orderByDirection = ref<'ascending' | 'descending' | null>('descending');
    const orderByAscending = ref(false);

    function openPostInNewTab(url: string | null) {
        if (!url) {
            return;
        }

        window?.open(url, '_blank');
    }

    function onSort(fieldName: string | null, direction: 'ascending' | 'descending' | null): void {
        orderBy.value = fieldName;
        orderByDirection.value = direction;
        orderByAscending.value = direction === 'ascending';
        setCurrentPage(1);
    }

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumPostsPaginated(unref(channels), unref(startDate), unref(endDate), unref(orderBy), unref(orderByAscending), unref(pageLength), unref(currentPage));
        posts.value = response.data.items;
        setTotalItems(response.data.totalItems);
        isLoading.value = false;
    }

    watch([channels, startDate, endDate, orderBy, orderByAscending, pageLength, currentPage], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .channel-icon {
        width: 51px;
        min-width: 51px;
        height: 51px;
        margin-right: 1rem;
    }

    .post-inner-stack {
        width: 100%;
        justify-content: space-evenly;
    }

    label {
        font-size: 14px;

        &.cell-title {
            white-space: nowrap;
        }
    }

    .align-items-center {
        align-items: center;
    }

    ::v-deep(.flux-table-cell).justify-content-center .flux-table-cell-content {
        justify-content: center;
    }

    ::v-deep(.flux-table-cell).align-items-center .flux-table-cell-content {
        align-items: center;
    }
</style>
