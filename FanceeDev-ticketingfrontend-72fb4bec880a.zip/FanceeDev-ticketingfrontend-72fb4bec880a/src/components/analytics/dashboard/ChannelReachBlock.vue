<template>
    <ChannelReachContainer
        v-slot="reachProps"
        :channel="channel"
        :start-date="startDate"
        :end-date="endDate">
        <FluxGrid v-if="reachProps && reachProps.data">
            <template v-for="(field, index) in fields">
                <FluxGridColumn
                    v-if="reachProps.data[field]"
                    :key="field + index"
                    :xl="2"
                    :md="4"
                    :sm="6">
                    <FluxStatistic
                        axis="vertical"
                        icon="analytics"
                        color="primary"
                        :label="t(`analytics.field.${field}`)"
                        :value="reachProps.data[field] ?? ''"/>
                </FluxGridColumn>
            </template>
        </FluxGrid>
    </ChannelReachContainer>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { useI18n } from 'vue-i18n';
    import { Channel } from '@/data/dto/analytics/channels';
    import ChannelReachContainer from '@/components/analytics/data/channel/ChannelReachContainer.vue';

    export interface Props {
        readonly channel: Channel;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineProps<Props>();

    const {t} = useI18n();

    const fields: string[] = [
        'totalFollowers',
        'increasedFollowers',
        'percentIncreaseFollowers',
        'reach',
        'activeFollowers',
        'averageAge',
        'percentMen',
        'percentWomen',
        'shares',
        'likes',
        'comments',
        'clicksOnPage',
        'description'
    ];
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-statistic-vertical) {
        display: flex;
        flex-direction: column;
        align-items: center;

        .flux-statistic-data {
            text-align: center;
        }
    }
</style>
