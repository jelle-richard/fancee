<template>
    <BarChartCard
        :is-loading="isLoading"
        :title="t('form.field.age')"
        :chart-data="chartSeries"
        :chart-options="chartOptions"/>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { DashboardService } from '@/data/service/DashboardService';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumAgeAndGenderItem } from '@/data/dto/analytics/dashboard';
    import BarChartCard from '@/components/analytics/cards/BarChartCard.vue';

    interface Props {
        channels: Channel[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumAge} = useService(DashboardService);

    const entries = ref<SumAgeAndGenderItem[] | null>(null);
    const isLoading = ref(false);

    const mappedEntries = computed(() => {
        let mappedItems: {} = {};
        const _entries = unref(entries) ?? [];
        const subscriptionsSize = new Set(_entries.map(entry => entry.subscriptionId)).size;

        _entries.forEach(item => {
            let age = item.age.toLowerCase();

            if (!mappedItems[age]) {
                mappedItems[age] = {x: age, y: 0};
            }

            mappedItems[age].y += item.percentage / subscriptionsSize;
        });

        return mappedItems;
    });

    const chartOptions: ApexOptions = {
        yaxis: {
            forceNiceScale: true,
            decimalsInFloat: 2,
            labels: {
                formatter: (val: number): string => `${val.toFixed(0)}%`
            }
        },
        tooltip: {
            y: {
                formatter: (val: number): string => `${val.toFixed(2)}%`
            }
        }
    };

    const chartSeries = computed((): ApexAxisChartSeries => {
        const currentEntries = unref(mappedEntries);
        const keys = Object.keys(currentEntries).sort();

        return [{
            name: t('analytics.followers.title'),
            data: keys.map(key => currentEntries[key])
        }];
    });

    async function updateData() {
        isLoading.value = true;
        const response = await getSumAge(unref(channels), unref(startDate), unref(endDate));
        entries.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .chart-container {
        height: 300px;
        min-height: 300px;
        max-height: 300px;
    }
</style>
