<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="t('analytics.engagement.title')"/>

        <FluxPaneBody>
            <FluxStack
                gap="0"
                axis="horizontal">
                <FluxStatistic
                    class="centered-vertical-statistics"
                    axis="vertical"
                    icon="diagram-project"
                    color="primary"
                    :value="asCompactNumber(sumShares)"
                    :label="t('analytics.engagement.shares')"/>

                <FluxStatistic
                    class="centered-vertical-statistics"
                    axis="vertical"
                    icon="comment"
                    color="primary"
                    :value="asCompactNumber(sumComments)"
                    :label="t('analytics.engagement.comments')"/>

                <FluxStatistic
                    class="centered-vertical-statistics"
                    axis="vertical"
                    icon="thumbs-up"
                    color="primary"
                    :value="asCompactNumber(sumLikes)"
                    :label="t('analytics.engagement.likes')"/>
            </FluxStack>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { DashboardService } from '@/data/service/DashboardService';
    import { SumEngagementGroup } from '@/data/dto/analytics/dashboard';
    import { asCompactNumber } from '@/util';

    export interface Emits {
        (e: 'open'): void;
    }

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineEmits<Emits>();
    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumEngagement} = useService(DashboardService);

    const entries = ref<SumEngagementGroup[]>([]);
    const isLoading = ref(false);

    const sumShares = computed(() => unref(entries).reduce((acc, curr) => acc + curr.totalShares, 0));
    const sumComments = computed(() => unref(entries).reduce((acc, curr) => acc + curr.totalComments, 0));
    const sumLikes = computed(() => unref(entries).reduce((acc, curr) => acc + curr.totalLikes, 0));

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumEngagement(unref(channels), unref(startDate), unref(endDate));
        entries.value = response.data.items;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .flux-pane {
        display: flex;
        flex-direction: column;

        .flux-pane-body {
            flex: 1;
        }
    }

    .centered-vertical-statistics {
        flex: 1;
        border: 0;
        box-shadow: none;
        padding: 0;
    }

    .flux-stack {
        justify-content: center;
    }

    ::v-deep(.flux-statistic-icon) {
        display: none;
    }

    ::v-deep(.flux-statistic-data) {
        justify-content: center;
    }
</style>
