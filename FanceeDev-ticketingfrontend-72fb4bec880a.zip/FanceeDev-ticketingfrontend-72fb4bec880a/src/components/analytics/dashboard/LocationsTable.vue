<template>
    <FluxDataTable
        :is-bordered="false"
        :data-set="locations"
        :page="1"
        :per-page="10"
        :total="totalItems">
        <template #header>
            <FluxTableHeader
                colspan="2"
                is-shrinking>
                {{ t('analytics.topLocations.country') }}
            </FluxTableHeader>

            <FluxTableHeader class="visitors">
                {{ t('analytics.topLocations.visitors') }}
            </FluxTableHeader>
        </template>

        <template #flag="{row: {countryCode}}">
            <FluxTableCell class="country-flag-cell">
                <img
                    class="country-flag"
                    :src="countryFlagImages[countryCode]"
                    :alt="countryCode"/>
            </FluxTableCell>
        </template>

        <template #name="{index, row: {countryCode}}">
            <FluxTableCell>{{ index + 1 }}. {{ AddressAdapter.parseCountryCodeToEnglish(countryCode) }}</FluxTableCell>
        </template>

        <template #visitors="{row: { percentage, gainedPercentage }}">
            <FluxTableCell
                class="visitors"
                contentDirection="column">
                <label class="visitors">{{ percentage?.toFixed(2) }}%</label>
                <label :class="`visitors percentage ${positiveClass(gainedPercentage)}`">{{ getGainString(gainedPercentage) }}</label>
            </FluxTableCell>
        </template>
    </FluxDataTable>
</template>

<script
    lang="ts"
    setup>
    import { AddressAdapter } from '@fancee/data';
    import { useI18n } from 'vue-i18n';
    import { SumCountryItem } from '@/data/dto/analytics/dashboard';
    import countryFlagImages from '@/assets/language';

    export interface Props {
        readonly locations: SumCountryItem[];
        readonly totalItems: number;
    }

    defineProps<Props>();

    const {t} = useI18n();

    const getGainString = (gainedPercentage: number | null): string => {
        if (!gainedPercentage || Number.isNaN(gainedPercentage) || Number.isNaN(gainedPercentage)) {
            return '-';
        }

        return `${gainedPercentage >= 0.00 ? '+' : ''}${gainedPercentage.toFixed(2)}`;
    };

    const positiveClass = (gainedPercentage: number | null): string => `positive-${gainedPercentage != null && gainedPercentage >= 0.00 ? 'true' : 'false'}`;
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-table-cell.visitors) .flux-table-cell-content {
        align-items: flex-end;
        justify-content: flex-end;
    }

    ::v-deep(.flux-table-cell-content:not(.flux-table-header-content)) {
        padding-top: 0.25rem;
        padding-bottom: 0.25rem;
        align-items: center;
    }

    .country-flag-cell {
        width: 30px;
    }

    .country-flag {
        width: 24px;
        height: 24px;
    }

    .positive-false {
        color: rgb(var(--danger-7));
    }

    .positive-true {
        color: rgb(var(--success-7));
    }
</style>
