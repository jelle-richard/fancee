<template>
    <BarChartCard
        :key="Math.random()"
        :is-loading="isLoading"
        :title="t('analytics.ticketing.averageOrderPrice.title')"
        :height="chartHeight"
        :chart-data="chartSeries"
        :chart-options="chartOptions"/>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useCurrency, useService } from '@/composable';
    import { DashboardService } from '@/data/service/DashboardService';
    import { AveragePriceItem } from '@/data/dto/analytics/dashboard';
    import { CHART_BAR_AMOUNT, CHART_BAR_HEIGHT, CHART_BAR_MANY_HEIGHT, CHART_COLORS, CHART_MIN_HEIGHT } from '@/data';
    import { asMoney } from '@/util';
    import BarChartCard from '@/components/analytics/cards/BarChartCard.vue';

    interface Props {
        selectedEventIds: string[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {selectedEventIds, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getAveragePrices} = useService(DashboardService);
    const organizationId = useActiveOrganizationId();
    const currency = useCurrency();

    const chartHeight = computed(() => {
        const _entries = unref(entries)?.length ?? 0;

        return CHART_MIN_HEIGHT + ((_entries < CHART_BAR_AMOUNT ? CHART_BAR_HEIGHT : CHART_BAR_MANY_HEIGHT) * _entries);
    });

    const entries = ref<AveragePriceItem[] | null>(null);
    const isLoading = ref(false);
    const chartSeries = ref<ApexAxisChartSeries>([]);
    const chartOptions = ref<ApexOptions>({
        xaxis: {
            tickAmount: 15,
            labels: {
                formatter: (value) => asMoney(Number(value), unref(currency))
            }
        },
        chart: {
            type: 'bar',
            stacked: true,
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        colors: CHART_COLORS,
        labels: [] as string[],
        dataLabels: {
            enabled: true,
            textAnchor: 'start',
            formatter: (value) => asMoney(Number(value), unref(currency)),
            offsetX: 0,
            offsetY: -1,
            background: {
                enabled: true,
                foreColor: CHART_COLORS[0],
                padding: 4,
                borderRadius: 2,
                borderWidth: 1,
                borderColor: CHART_COLORS[0],
                opacity: 1
            }
        },
        plotOptions: {
            bar: {
                horizontal: true,
                dataLabels: {
                    position: 'bottom'
                }
            }
        },
        tooltip: {
            enabled: false
        }
    });

    function fillChart(): void {
        const _entries = unref(entries);

        chartSeries.value = [];
        chartOptions.value.labels = [];

        if (!_entries) {
            return;
        }

        const averageOrderPrice: number[] = [];

        let sumAverageOrderCents: number = 0;
        let totalAmountOfOrders: number = 0;

        _entries.forEach(e => {
            averageOrderPrice.push(e.averageOrderPriceCents);

            sumAverageOrderCents += e.averageOrderPriceCents;
            totalAmountOfOrders += e.amountOfOrders;

            chartOptions.value.labels!.push(e.name);
        });

        if (_entries.length > 1) {
            averageOrderPrice.push(Math.ceil(sumAverageOrderCents / totalAmountOfOrders));
            chartOptions.value.labels!.push(t('analytics.ticketing.averageOrderPrice.average'));
        }

        chartSeries.value.push({
            data: averageOrderPrice
        });
    }

    async function updateData() {
        isLoading.value = true;
        const response = await getAveragePrices(unref(organizationId), unref(selectedEventIds), unref(startDate), unref(endDate));
        entries.value = response.data;
        fillChart();
        isLoading.value = false;
    }

    watch([startDate, endDate, selectedEventIds], updateData, {deep: true, immediate: true});
</script>
