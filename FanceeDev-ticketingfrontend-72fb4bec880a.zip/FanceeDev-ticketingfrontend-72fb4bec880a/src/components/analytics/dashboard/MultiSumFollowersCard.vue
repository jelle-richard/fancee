<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="t('analytics.followers.title')"/>

        <FluxPaneBody>
            <FluxStack
                v-if="props"
                gap="0"
                axis="horizontal">
                <FluxStatistic
                    axis="vertical"
                    icon="plus"
                    :change-color="sumGained - sumLost  > 0 ? 'danger' : 'danger'"
                    :color="sumGained - sumLost  > 0 ? 'danger' : 'danger'"
                    :value="asCompactNumber(Math.abs(sumGained - sumLost))"
                    :label="sumGained - sumLost  > 0 ? t('analytics.followers.new') : t('analytics.followers.lost')"/>

                <FluxStatistic
                    axis="vertical"
                    icon="user"
                    color="primary"
                    :value="asCompactNumber(sumTotal)"
                    :label="t('analytics.followers.total')"/>
            </FluxStack>

            <FluxBadge
                v-if="sumTotal > 0"
                :label="`${(sumGained > sumLost ? (100 / sumTotal) * sumGained : (100 / sumTotal) * sumLost).toFixed(2)}% ${ sumGained > sumLost ? t('analytics.followers.new') : t('analytics.followers.lost')}`"
                :icon="icon"
                :color="color"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { DashboardService } from '@/data/service/DashboardService';
    import { SumLostAndGainedGroup, SumResponse } from '@/data/dto/analytics/dashboard';
    import { asCompactNumber } from '@/util';

    interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumFollowers} = useService(DashboardService);

    const sumFollowers = ref<SumResponse<SumLostAndGainedGroup> | null>(null);
    const isLoading = ref(false);

    const sumGained = computed(() => unref(sumFollowers)?.items.reduce((acc, curr) => acc + curr.totalGained, 0) ?? 0);
    const sumLost = computed(() => unref(sumFollowers)?.items.reduce((acc, curr) => acc + curr.totalLost, 0) ?? 0);
    const sumTotal = computed(() => unref(sumFollowers)?.last?.total ?? 0);

    const icon = computed(() => {
        if (unref(sumGained) > unref(sumLost)) {
            return 'arrow-up';
        }

        if (unref(sumGained) < unref(sumLost)) {
            return 'arrow-down';
        }
    });

    const color = computed(() => {
        if (unref(sumGained) > unref(sumLost)) {
            return 'success';
        }

        if (unref(sumGained) < unref(sumLost)) {
            return 'danger';
        }
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumFollowers(unref(channels), unref(startDate), unref(endDate));
        sumFollowers.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .flux-pane-body {
        align-items: flex-start;
    }

    .flux-statistic {
        flex: 1;
        border: 0;
        box-shadow: none;
        padding: 0 0 0.5rem;
        align-items: flex-start;
    }

    .flux-stack {
        flex: 1;
        width: 100%;
    }

    ::v-deep(.flux-badge) {
        margin-top: 9px;

        &.is-success {
            background: rgb(var(--success-2));
            border-color: rgb(var(--success-3) / .5);
            color: rgb(var(--success-10));
        }

        &.is-danger {
            background: rgb(var(--danger-2));
            border-color: rgb(var(--danger-3) / .5);
            color: rgb(var(--danger-10));
        }
    }

    ::v-deep(.flux-statistic-icon) {
        display: none;
    }

    ::v-deep(.flux-statistic).is-vertical .flux-statistic-data {
        align-items: flex-start;
    }
</style>
