<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="title"
            :subTitle="subtitle">
            <FluxFormInputGroup>
                <FluxFormInputAddition :text="t('flux.sort')"/>

                <FluxFormSelect
                    v-model="sortSelection"
                    :options="sortOptions"/>
            </FluxFormInputGroup>
        </FluxPaneHeader>

        <FluxPaneBody>
            <NoDashboardData
                v-if="!isLoading && chartSeries.length === 0"
                variation="full"/>

            <HeatmapChart
                v-else-if="chartSeries.length > 0"
                :series="chartSeries"
                :options="chartOptions"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, nextTick, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { ANALYTICS_CHART_GRADIENT_COLORS } from '@/data';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumCommentsGroup } from '@/data/dto/analytics/dashboard';
    import { DashboardService } from '@/data/service/DashboardService';
    import { CustomApexAxisChartSeries, Option } from '@/data/interface/charts';
    import HeatmapChart from '@/components/analytics/cards/charts/HeatmapChart.vue';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export type Props = {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
        readonly title: string;
    };

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumComments} = useService(DashboardService);

    const commentGroups = ref<SumCommentsGroup[]>([]);
    const commentsMinValue = ref(0);
    const commentsMaxValue = ref(100);
    const isLoading = ref(false);
    const sortSelection = ref('REACTION');

    const chartSeries = ref<CustomApexAxisChartSeries>([]);
    const chartOptions = ref<ApexOptions>({});

    const sortOptions = computed((): Option[] => [
        {id: 'REACTION', label: t('analytics.bestPostTime.comments')},
        {id: 'LIKES', label: t('analytics.bestPostTime.likes')},
        {id: 'REACH', label: t('analytics.bestPostTime.reach')}
    ]);

    const chartCategories = computed((): Option[] => [
        {id: 'Sunday', label: t('global.dayStr.short.sunday')},
        {id: 'Saturday', label: t('global.dayStr.short.saturday')},
        {id: 'Friday', label: t('global.dayStr.short.friday')},
        {id: 'Thursday', label: t('global.dayStr.short.thursday')},
        {id: 'Wednesday', label: t('global.dayStr.short.wednesday')},
        {id: 'Tuesday', label: t('global.dayStr.short.tuesday')},
        {id: 'Monday', label: t('global.dayStr.short.monday')}
    ]);

    async function updateChartSeries(): Promise<void> {
        const _commentGroups = unref(commentGroups);
        const _categories = unref(chartCategories);
        const _hours = [...Array(24).keys()].map(i => `${i}`.padStart(2, '0'));
        const _sortSelection = unref(sortSelection);

        switch (_sortSelection) {
            case 'REACTION':
                let rangeReactions: number[] = [];
                chartSeries.value = _categories.map(category => {
                    const _values = _commentGroups.find(c => c.date == category.id)?.values.filter(v => v.comments > 0) ?? [];

                    rangeReactions.push(..._values.map(o => o.comments));

                    commentsMinValue.value = Math.min(...rangeReactions);
                    commentsMaxValue.value = Math.max(...rangeReactions);

                    return {
                        name: category.label,
                        data: _hours.map(hour => {
                            return {
                                x: hour,
                                y: _values.filter(v => v.hour === hour).reduce((acc, value) => acc + value.comments, 0)
                            };
                        })
                    };
                });

                await updateOptions();
                break;

            case 'LIKES':
                let rangeLikes: number[] = [];
                chartSeries.value = _categories.map(category => {
                    const _values = _commentGroups.find(c => c.date == category.id)?.values?.filter(v => v.likes > 0) ?? [];

                    rangeLikes.push(..._values.map(o => o.likes));

                    commentsMinValue.value = Math.min(...rangeLikes);
                    commentsMaxValue.value = Math.max(...rangeLikes);

                    return {
                        name: category.label,
                        data: _hours.map(hour => {
                            return {
                                x: hour,
                                y: _values.filter(v => v.hour === hour).reduce((acc, value) => acc + value.likes, 0)
                            };
                        })
                    };
                });

                await updateOptions();
                break;

            case 'REACH':
                let rangeReach: number[] = [];
                chartSeries.value = _categories.map(category => {
                    const _values = _commentGroups.find(c => c.date == category.id)?.values.filter(v => v.reach > 0) ?? [];

                    rangeReach.push(..._values.map(o => o.reach));

                    commentsMinValue.value = Math.min(...rangeReach);
                    commentsMaxValue.value = Math.max(...rangeReach);

                    return {
                        name: category.label,
                        data: _hours.map(hour => {
                            return {
                                x: hour,
                                y: _values.filter(v => v.hour === hour).reduce((acc, value) => acc + value.reach, 0)
                            };
                        })
                    };
                });

                await updateOptions();
                break;

            default:
                chartSeries.value = [];
                break;
        }
    }

    async function updateOptions(): Promise<void> {
        let _min = Math.floor(unref(commentsMinValue) ?? 0);
        const _max = Math.ceil(unref(commentsMaxValue) ?? 100);

        const diff = _max - _min;
        const stepSize = Math.ceil(diff / 10);

        chartOptions.value = {
            plotOptions: {
                heatmap: {
                    radius: 3,
                    enableShades: false,
                    distributed: true,
                    colorScale: {
                        ranges: [
                            {
                                from: 0,
                                to: 0.002,
                                color: '#e9ebf1'
                            },
                            {
                                from: 0.003,
                                to: (_min + stepSize),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[0]
                            },
                            {
                                from: _min + stepSize,
                                to: (_min + (stepSize * 2)),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[1]
                            },
                            {
                                from: _min + (stepSize * 2),
                                to: (_min + (stepSize * 3)),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[2]
                            },
                            {
                                from: _min + (stepSize * 3),
                                to: (_min + (stepSize * 4)),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[3]
                            },
                            {
                                from: _min + (stepSize * 4),
                                to: (_min + (stepSize * 5)),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[4]
                            },
                            {
                                from: _min + (stepSize * 5),
                                to: (_min + (stepSize * 6)),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[5]
                            },
                            {
                                from: _min + (stepSize * 6),
                                to: (_min + (stepSize * 7)),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[6]
                            },
                            {
                                from: _min + (stepSize * 7),
                                to: (_min + (stepSize * 8)),
                                color: ANALYTICS_CHART_GRADIENT_COLORS[7]
                            },
                            {
                                from: _min + (stepSize * 8),
                                to: _max,
                                color: ANALYTICS_CHART_GRADIENT_COLORS[8]
                            }
                        ]
                    }
                }
            }
        };
    }

    const subtitle = computed((): string => {
        switch (unref(sortSelection)) {
            case 'REACTION':
                return t('analytics.bestPostTime.basedOn.comments');

            case 'LIKES':
                return t('analytics.bestPostTime.basedOn.likes');

            case 'REACH':
                return t('analytics.bestPostTime.basedOn.reach');

            default:
                return '';
        }
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumComments(unref(channels), unref(startDate), unref(endDate), 'by_day');
        commentGroups.value = response.data.items;
        await updateChartSeries();
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], async () => {
        await updateData();
    }, {deep: true, immediate: true});

    watch(sortSelection, () => nextTick(async () => {
        await updateChartSeries();
    }));
</script>

<style
    lang="scss"
    scoped>
    .bar-chart-container {
        margin-bottom: -2rem;
    }

    .flux-form-input-addition {
        white-space: nowrap;
    }

    .flux-stack.is-horizontal {
        align-items: flex-end;
        justify-content: flex-end;
    }

    .flux-form-input {
        width: auto;
    }

    ::v-deep(.apexcharts-yaxis) {
        transform: translate(18px, 0);
    }

    ::v-deep(.flux-form-select-selected) {
        position: initial;
    }

    ::v-deep(.flux-form-input) .flux-form-select a *,
    ::v-deep(.bar-chart-controls) * {
        color: var(--foreground-prominent);
    }
</style>
