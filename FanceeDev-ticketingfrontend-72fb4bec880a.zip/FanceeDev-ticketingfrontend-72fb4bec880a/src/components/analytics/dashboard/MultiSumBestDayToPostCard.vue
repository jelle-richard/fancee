<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="title"
            :subTitle="subtitle"/>

        <FluxGrid columns="8">
            <FluxGridColumn :sm="5">
                <ApexChart
                    class="bar-chart-container"
                    width="100%"
                    height="270"
                    :series="chartSeries"
                    :options="chartOptions"/>
            </FluxGridColumn>

            <FluxGridColumn :sm="3">
                <FluxStack gap="1">
                    <FluxFormInputGroup>
                        <FluxFormInputAddition :text="t('flux.sort')"/>
                        <FluxFormSelect
                            v-model="sortSelection"
                            :options="sortOptions"/>
                    </FluxFormInputGroup>

                    <FluxStack
                        v-if="!isLoading && (bestGroup === null || bestGroup.values.length === 0)"
                        class="bar-chart-controls"
                        gap="0">
                        <b>{{ t('best_' + (hourly ? 'hour' : 'day')) }}</b>
                        <NoDashboardData/>
                    </FluxStack>

                    <FluxStack
                        v-else
                        class="bar-chart-controls"
                        gap="0">
                        <b>{{ t('best_' + (hourly ? 'hour' : 'day')) }}</b>
                        <span class="pb-1">{{ bestGroupDate }}</span>
                        <span><b>{{ bestGroupTotal }}</b> {{ selectedSortString }}</span>
                        <span><b>~{{ bestGroupAverage }}</b> per post</span>
                    </FluxStack>
                </FluxStack>
            </FluxGridColumn>
        </FluxGrid>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ApexOptions } from 'apexcharts';
    import { useService } from '@/composable';
    import { ANALYTICS_CHART_COLOR, CHART_FONT_FAMILY } from '@/data';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumCommentsGroup } from '@/data/dto/analytics/dashboard';
    import { DashboardService } from '@/data/service/DashboardService';
    import { Option } from '@/data/interface/charts';
    import ApexChart from 'vue3-apexcharts';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export type Props = {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
        readonly title: string;
        readonly hourly?: boolean;
    };

    const props = defineProps<Props>();
    const {channels, startDate, endDate, hourly} = toRefs(props);

    const {t} = useI18n();
    const {getSumComments} = useService(DashboardService);

    const entries = ref<SumCommentsGroup[]>([]);
    const isLoading = ref(false);
    const sortSelection = ref<string>('REACTION');

    const chartOptions = ref<ApexOptions>({
        grid: {
            show: false,
            padding: {
                left: 0,
                right: 0
            }
        },
        chart: {
            type: 'bar',
            toolbar: {
                show: false
            },
            sparkline: {
                enabled: false
            },
            animations: {
                enabled: false
            },
            fontFamily: CHART_FONT_FAMILY
        },
        colors: [ANALYTICS_CHART_COLOR],
        dataLabels: {
            enabled: false
        },
        legend: {
            show: false
        },
        tooltip: {
            intersect: false,
            style: {
                fontFamily: CHART_FONT_FAMILY
            }
        },
        xaxis: {
            tickAmount: unref(hourly) ? 9 : undefined,
            labels: {
                show: true,
                rotate: -45,
                rotateAlways: true,
                minHeight: 88,
                maxHeight: 88,
                style: {
                    colors: '#000000'
                },
                formatter: unref(hourly) ? function (value) {
                    return value + ':00';
                } : undefined
            }
        },
        yaxis: {
            axisBorder: {
                show: false
            },
            labels: {
                show: true,
                align: 'left',
                minWidth: 50
            }
        }
    });

    const sortOptions = computed((): Option[] => [
        {id: 'REACTION', label: t('analytics.bestPostTime.comments')},
        {id: 'LIKES', label: t('analytics.bestPostTime.likes')},
        {id: 'REACH', label: t('analytics.bestPostTime.reach')}
    ]);

    const chartSeries = computed((): ApexAxisChartSeries => {
        const currentHourly = unref(hourly);

        switch (unref(sortSelection)) {
            case 'REACTION':
                return [{
                    name: t('analytics.bestPostTime.comments'),
                    data: unref(entries).map(item => ({x: (currentHourly ? item.date : t(item.date?.toLowerCase()) ?? ''), y: item.averageComments})) ?? []
                }];

            case 'LIKES':
                return [{
                    name: t('analytics.bestPostTime.likes'),
                    data: unref(entries).map(item => ({x: (currentHourly ? item.date : t(item.date?.toLowerCase()) ?? ''), y: item.averageLikes})) ?? []
                }];

            case 'REACH':
                return [{
                    name: t('analytics.bestPostTime.reach'),
                    data: unref(entries).map(item => ({x: (currentHourly ? item.date : t(item.date?.toLowerCase()) ?? ''), y: item.averageReach})) ?? []
                }];

            default:
                return [];
        }
    });

    const bestGroup = computed((): SumCommentsGroup | null => {
        const currentEntries = unref(entries);

        if (currentEntries.length === 0) {
            return null;
        }

        switch (unref(sortSelection)) {
            case 'REACTION':
                return currentEntries.reduce((prev, current) => prev.averageComments > current.averageComments ? prev : current, currentEntries[0]);

            case 'LIKES':
                return currentEntries.reduce((prev, current) => prev.averageLikes > current.averageLikes ? prev : current, currentEntries[0]);

            case 'REACH':
                return currentEntries.reduce((prev, current) => prev.averageReach > current.averageReach ? prev : current, currentEntries[0]);

            default:
                return null;

        }
    });

    const bestGroupDate = computed((): string => {
        if (unref(hourly)) {
            return unref(bestGroup)?.date + ':00';
        }

        return t(unref(bestGroup)?.date?.toLowerCase() ?? 'error');
    });

    const bestGroupAverage = computed((): string | undefined => {
        switch (unref(sortSelection)) {
            case 'REACTION':
                return unref(bestGroup)?.averageComments?.toString();

            case 'LIKES':
                return unref(bestGroup)?.averageLikes?.toString();

            case 'REACH':
                return unref(bestGroup)?.averageReach?.toString();

            default:
                return '';
        }
    });

    const bestGroupTotal = computed((): string | undefined => {
        switch (unref(sortSelection)) {
            case 'REACTION':
                return unref(bestGroup)?.values?.reduce((sum, curr) => sum + curr.comments, 0).toString();

            case 'LIKES':
                return unref(bestGroup)?.values?.reduce((sum, curr) => sum + curr.likes, 0).toString();

            case 'REACH':
                return unref(bestGroup)?.values?.reduce((sum, curr) => sum + curr.reach, 0).toString();

            default:
                return '';
        }
    });

    const selectedSortString = computed((): string => {
        switch (unref(sortSelection)) {
            case 'REACTION':
                return t('analytics.bestPostTime.comments');

            case 'LIKES':
                return t('analytics.bestPostTime.likes');

            case 'REACH':
                return t('analytics.bestPostTime.reach');

            default:
                return '';
        }
    });

    const subtitle = computed((): string => {
        switch (unref(sortSelection)) {
            case 'REACTION':
                return t('analytics.bestPostTime.basedOn.comments');

            case 'LIKES':
                return t('analytics.bestPostTime.basedOn.likes');

            case 'REACH':
                return t('analytics.bestPostTime.basedOn.reach');

            default:
                return '';
        }
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumComments(unref(channels), unref(startDate), unref(endDate), unref(hourly) ? 'by_hour' : 'by_day');
        entries.value = response.data.items;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .bar-chart-container {
        margin-bottom: -2rem;
    }

    .flux-form-input-addition {
        white-space: nowrap;
    }

    ::v-deep(.apexcharts-yaxis) {
        transform: translate(18px, 0);
    }

    ::v-deep(.flux-form-select-selected) {
        position: initial;
    }

    ::v-deep(.flux-form-input) .flux-form-select a *,
    ::v-deep(.bar-chart-controls) * {
        color: var(--foreground-prominent);
    }
</style>
