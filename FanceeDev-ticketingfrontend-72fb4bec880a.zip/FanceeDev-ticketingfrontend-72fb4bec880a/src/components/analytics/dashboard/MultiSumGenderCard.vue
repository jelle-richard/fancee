<template>
    <PieChartCard
        :is-loading="isLoading"
        :title="t('form.field.gender')"
        :chart-data="chartData"
        :chart-options="chartOptions"
        :chart-categories="chartCategories"/>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { DashboardService } from '@/data/service/DashboardService';
    import { SumAgeAndGenderItem } from '@/data/dto/analytics/dashboard';
    import { ChartDataItem } from '@/data/interface/charts';
    import PieChartCard from '@/components/analytics/cards/PieChartCard.vue';

    interface Props {
        channels: Channel[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumGender} = useService(DashboardService);

    const entries = ref<SumAgeAndGenderItem[] | null>(null);
    const isLoading = ref(false);

    const mappedEntries = computed((): ChartDataItem[] => {
        let mappedItems: {} = {};
        let totalMappedPercentage = 0;
        const _entries = unref(entries) ?? [];

        _entries.forEach(item => {
            let gender = parseGenders(item.gender);

            if (!mappedItems[gender]) {
                mappedItems[gender] = 0;
            }

            mappedItems[gender] += item.percentage;
            totalMappedPercentage += item.percentage;
        });

        return Object.keys(mappedItems).map(key => ({
            x: key,
            y: mappedItems[key]
        })).sort((a, b) => b.y - a.y);
    });

    const chartOptions: ApexOptions = {
        yaxis: {
            forceNiceScale: true,
            decimalsInFloat: 2,
            labels: {
                formatter: (val: number): string => `${val.toFixed(0)}%`
            }
        },
        tooltip: {
            y: {
                formatter: (val: number): string => `${val.toFixed(2)}%`
            }
        }
    };

    const chartData = computed((): number[] => unref(mappedEntries).map(item => item.y ?? 0));
    const chartCategories = computed((): string[] => unref(mappedEntries).map(item => t(`global.gender.${item.x}`)));

    async function updateData() {
        isLoading.value = true;
        const response = await getSumGender(unref(channels), unref(startDate), unref(endDate));
        entries.value = response.data;
        isLoading.value = false;
    }

    function parseGenders(gender: string) {
        gender = gender.toLowerCase();

        switch (gender) {
            case 'male':
            case 'female':
            case 'neutral':
                return gender;

            case 'other':
                return 'neutral';

            default:
                return 'unknown';
        }
    }

    watch([channels, startDate, endDate], updateData, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .chart-container {
        height: 300px;
        min-height: 300px;
        max-height: 300px;
    }
</style>
