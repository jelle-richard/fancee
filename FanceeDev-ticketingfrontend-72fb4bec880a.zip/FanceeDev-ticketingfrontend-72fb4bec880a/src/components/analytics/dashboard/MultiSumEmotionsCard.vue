<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="t('analytics.emotions.title')"
            :sub-title="t('analytics.emotions.subTitle')"/>

        <FluxPaneBody class="chart-container">
            <NoDashboardData
                v-if="!isLoading && !containsData"
                variation="full"/>

            <ApexChart
                v-else
                width="100%"
                height="320"
                :series="chartSeries"
                :options="chartOptions"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { ANALYTICS_CHART_COLOR } from '@/data';
    import { Channel } from '@/data/dto/analytics/channels';
    import { DashboardService } from '@/data/service/DashboardService';
    import { SumEmotionsGroup } from '@/data/dto/analytics/dashboard';
    import ApexChart from 'vue3-apexcharts';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    interface Props {
        channels: Channel[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumEmotions} = useService(DashboardService);

    const entries = ref<SumEmotionsGroup[]>([]);
    const isLoading = ref(false);
    const showAllCategories = ref(true);

    const emotionFieldNames = ['totalLike', 'totalLove', 'totalThankful', 'totalWow', 'totalHaha', 'totalPride', 'totalAnger', 'totalSorry'];

    const chartCategories = computed(() => emotionFieldNames.map(field => t(field.toLowerCase().replace('total', 'analytics.emotions.'))));
    const chartData = computed((): number[] => {
        const currentEntries = unref(entries);
        const currentShowAllCategories = unref(showAllCategories);
        let newValues: number[] = [];

        emotionFieldNames.forEach(varName => {
            const val = currentEntries.reduce((sum, current) => sum + current[varName], 0) ?? 0;
            if (currentShowAllCategories || val !== 0) {
                newValues.push(val);
            }
        });

        return newValues;
    });

    const containsData = computed((): boolean => unref(chartData).reduce((total, item) => total + item, 0) > 0);

    const chartSeries = computed((): ApexAxisChartSeries => ([{
        name: t('analytics.emotions.likes'),
        data: unref(chartData)
    }]));

    const chartOptions = computed((): ApexOptions => ({
        chart: {
            type: 'radar',
            toolbar: {
                show: false
            },
            sparkline: {
                enabled: false
            },
            animations: {
                enabled: false
            }
        },
        plotOptions: {
            bar: {
                distributed: true
            }
        },
        stroke: {
            show: true,
            width: 2,
            colors: [ANALYTICS_CHART_COLOR]
        },
        markers: {
            size: 4,
            hover: {
                size: 10
            },
            colors: [ANALYTICS_CHART_COLOR]
        },
        xaxis: {
            categories: unref(chartCategories),
            labels: {
                show: true,
                minHeight: 0,
                maxHeight: 0,
                style: {
                    colors: ['#1f2024', '#1f2024', '#1f2024', '#1f2024', '#1f2024', '#1f2024', '#1f2024', '#1f2024']
                }
            }
        },
        yaxis: {
            show: false,
            labels: {
                show: false,
                minWidth: 0,
                maxWidth: 0
            }
        }
    }));

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumEmotions(unref(channels), unref(startDate), unref(endDate));
        entries.value = response.data.items;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .category-button {
        position: absolute;
        right: 1rem;
        top: 1rem;
    }

    .chart-container {
        height: 330px;
        min-height: 330px;
    }
</style>
