<template>
    <FluxPane :is-loading="isLoading">
        <slot name="header"/>
        <FluxTabs v-model="tabIndex">
            <FluxTab
                v-for="category in categories"
                :key="category.id"
                :label="category.label"/>
        </FluxTabs>
        <LineChart
            :series="series"
            :options="options"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { computed, ref, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { ChartCategory, ChartSeriesItem, GenericChartSeries } from '@/data/interface/charts';
    import LineChart from '@/components/analytics/cards/charts/LineChart.vue';

    interface Props {
        readonly chartSeries: GenericChartSeries[];
        readonly sortBy?: string;
        readonly categories: ChartCategory[];
        readonly isLoading: boolean;
    }

    const props = withDefaults(defineProps<Props>(), {
        sortBy: 'date'
    });

    const {chartSeries, sortBy, categories} = toRefs(props);

    const tabIndex = ref(0);

    const options: ApexOptions = {
        stroke: {
            show: true,
            width: 2
        },
        legend: {
            show: true,
            position: 'bottom'
        }
    };

    const series = computed((): ChartSeriesItem[] => {
        const _category = unref(categories)[unref(tabIndex)];
        const _sortBy = unref(sortBy);
        const _chartData = unref(chartSeries);

        return _chartData.map(chart => ({
            name: chart.name,
            data: chart.data?.map(item => ({x: item[_sortBy], y: item[_category.id]}))
        }));
    });
</script>
