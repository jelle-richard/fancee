<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="t('analytics.topLocations.title')"/>

        <FluxPaneBody v-if="!isLoading && locations.length === 0">
            <NoDashboardData/>
        </FluxPaneBody>

        <LocationsTable
            v-else
            :locations="locations"
            :total-items="totalItems"/>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { DashboardService } from '@/data/service/DashboardService';
    import { SumCountryItem } from '@/data/dto/analytics/dashboard';
    import LocationsTable from '@/components/analytics/dashboard/LocationsTable.vue';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export type Props = {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
        readonly max?: number;
    };

    const props = withDefaults(defineProps<Props>(), {
        max: 10
    });
    const {channels, startDate, endDate, max} = toRefs(props);

    const {t} = useI18n();
    const {getSumCountries} = useService(DashboardService);

    const locations = ref<SumCountryItem[]>([]);
    const totalItems = ref(0);
    const isLoading = ref(false);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const _max = unref(max);
        const response = await getSumCountries(props.channels, props.startDate, props.endDate);

        locations.value = response.data.slice(0, _max);
        totalItems.value = response.data.slice(0, _max).length;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>
