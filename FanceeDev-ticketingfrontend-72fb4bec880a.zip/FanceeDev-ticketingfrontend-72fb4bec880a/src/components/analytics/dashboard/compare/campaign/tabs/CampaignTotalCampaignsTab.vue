<template>
    <FluxPane
        class="container"
        :is-loading="isLoading">
        <FluxStack v-if="channels">
            <MultiLineChart
                v-if="chartSeries"
                :series="chartSeries"
                :start-date="startDate"
                :end-date="endDate"
                :is-loading="isLoading"/>
        </FluxStack>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { DateTime } from 'luxon';
    import { useService } from '@/composable';
    import { DashboardService } from '@/data/service';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumCampaignItem } from '@/data/dto/analytics/dashboard';
    import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
    import { ChartGrowth, ChartSeriesItem } from '@/data/interface/charts';
    import MultiLineChart from '@/components/analytics/cards/charts/MultiLineChart.vue';

    export interface Emits {
        (e: 'update-growth', growth: ChartGrowth): void;
    }

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumCampaignsChart} = useService(DashboardService);

    const sumCharts = ref<SumChart<SumCampaignItem>[]>([]);
    const isLoading = ref(false);

    const chartSeries = computed((): ChartSeriesItem[] => {
        const _sumCharts = unref(sumCharts);
        const _channels = unref(channels);

        let returnList: ChartSeriesItem[] = [];
        _sumCharts.forEach(group => {
            const _name = _channels?.find(c => c.id === group.channelId)?.name ?? '';
            returnList.push({
                name: `${_name} - ${t('analytics.ads.totalCampaigns')}`,
                data: group.items.map(item => ({x: item.date, y: item.campaignId?.split(',').length}))
            });
        });

        return returnList;
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumCampaignsChart(unref(channels), unref(startDate), unref(endDate));
        sumCharts.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 315px;
        background: none;
        border: none;
        box-shadow: none;
    }
</style>
