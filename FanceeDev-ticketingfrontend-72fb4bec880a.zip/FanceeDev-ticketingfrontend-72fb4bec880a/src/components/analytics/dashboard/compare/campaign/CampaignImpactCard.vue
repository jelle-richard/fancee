<template>
    <FluxPane v-if="channels">
        <FluxPaneHeader :title="t('analytics.ads.title')"/>
        <FluxTabs>
            <FluxTab :label="t('analytics.ads.totalCampaigns')">
                <CampaignTotalCampaignsTab
                    :channels="channels"
                    :start-date="startDate"
                    :end-date="endDate"
                    @update-growth="updateGrowth"/>
            </FluxTab>

            <FluxTab :label="t('analytics.ads.totalSpent')">
                <CampaignTotalSpentTab
                    :channels="channels"
                    :start-date="startDate"
                    :end-date="endDate"
                    @update-growth="updateGrowth"/>
            </FluxTab>

            <FluxTab :label="t('analytics.ads.engagement')">
                <CampaignEngagementTab
                    :channels="channels"
                    :start-date="startDate"
                    :end-date="endDate"
                    @update-growth="updateGrowth"/>
            </FluxTab>
        </FluxTabs>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { ref } from 'vue';
    import { DateTime } from 'luxon';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChartGrowth } from '@/data/interface/charts';
    import CampaignEngagementTab from '@/components/analytics/dashboard/compare/campaign/tabs/CampaignEngagementTab.vue';
    import CampaignTotalSpentTab from '@/components/analytics/dashboard/compare/campaign/tabs/CampaignTotalSpentTab.vue';
    import CampaignTotalCampaignsTab from '@/components/analytics/dashboard/compare/campaign/tabs/CampaignTotalCampaignsTab.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineProps<Props>();

    const {t} = useI18n();
    const chartGrowth = ref<ChartGrowth | null>(null);

    function updateGrowth(newChartGrowth: ChartGrowth): void {
        chartGrowth.value = newChartGrowth;
    }
</script>

