<template>
    <FluxStack
        gap="0"
        axis="horizontal">
         <span
             :class="`social-impact-subtitle ${growthClass}`"
             :title="growthTitle">
            {{ growthString }}
        </span>

        <span
            :class="`social-impact-subtitle`"
            :title="previousGrowthTitle">
            {{ previousGrowthString }}
        </span>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { computed, toRefs, unref } from 'vue';
    import { ChartGrowth } from '@/data/interface/charts';
    import { useI18n } from 'vue-i18n';

    export interface Props {
        readonly chartGrowth: ChartGrowth | null;
    }

    const props = defineProps<Props>();
    const {chartGrowth} = toRefs(props);

    const {t} = useI18n();

    const growthTitle = computed((): string => {
        const _chartGrowth = unref(chartGrowth);
        return _chartGrowth?.growth ? titleString(_chartGrowth.growth, _chartGrowth.total) : '';
    });

    const previousGrowthTitle = computed((): string => {
        const _chartGrowth = unref(chartGrowth);
        return _chartGrowth?.previousGrowth ? titleString(_chartGrowth.previousGrowth, _chartGrowth.previousTotal) : '';
    });

    const growthClass = computed((): string => (unref(chartGrowth)?.growth ?? 0.000) >= 0.000 ? 'growth-positive' : 'growth-negative');

    const growthString = computed((): string => {
        const _growth = unref(chartGrowth);

        if (!_growth || !_growth.percentage || Number.isNaN(_growth.percentage)) {
            return '-';
        }

        return `${_growth.percentage.toFixed(2)}% ${t('analytics.socialImpact.growth')}`;
    });

    const previousGrowthString = computed((): string => {
        const _growth = unref(chartGrowth);

        if (!_growth || !_growth.previousPercentage || Number.isNaN(_growth.previousPercentage)) {
            return '';
        }

        return `${Math.abs(_growth.percentage - _growth.previousPercentage).toFixed(2)}% ${_growth.percentage > _growth.previousPercentage ? t('analytics.socialImpact.more') : t('analytics.socialImpact.less')}`;
    });

    const titleString = (growth: number, total: number): string => `${total} -> ${total + growth}(${growth > 0.00 ? '+' : ''}${growth})`;
</script>

<style
    lang="scss"
    scoped>
    .social-impact-subtitle {
        padding-left: 21px;
    }

    .growth-positive {
        color: #1a5623;
    }

    .growth-negative {
        color: #b3261e;
    }
</style>

