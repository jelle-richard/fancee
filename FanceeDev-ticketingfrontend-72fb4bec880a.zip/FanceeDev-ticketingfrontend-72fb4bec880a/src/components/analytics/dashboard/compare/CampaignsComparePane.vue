<template>
    <FluxStack v-if="channels">
        <CampaignImpactCard
            :channels="channels"
            :start-date="startDate"
            :end-date="endDate"/>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { Channel } from '@/data/dto/analytics/channels';
    import CampaignImpactCard from '@/components/analytics/dashboard/compare/campaign/CampaignImpactCard.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
</script>
