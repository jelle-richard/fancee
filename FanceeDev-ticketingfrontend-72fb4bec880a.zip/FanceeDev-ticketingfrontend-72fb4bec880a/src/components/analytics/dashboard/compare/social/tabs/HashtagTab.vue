c
<template>
    <FluxPane
        class="container"
        :is-loading="isLoading">
        <NoDashboardData
            v-if="!isLoading && !containsData"
            variation="full"/>

        <StackedBarChart
            v-else-if="chartSeries"
            :series="chartSeries"
            :start-date="startDate"
            :end-date="endDate"
            :is-loading="isLoading"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { DateTime } from 'luxon';
    import { useService } from '@/composable';
    import { DashboardService } from '@/data/service';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
    import { Keyword } from '@/data/dto/analytics/posts';
    import { ChartSeriesItem } from '@/data/interface/charts';
    import StackedBarChart from '@/components/analytics/cards/charts/StackedBarChart.vue';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
        readonly wordType: 'hashtags' | 'mentions' | 'captions';
    }

    const props = defineProps<Props>();

    const {channels, startDate, endDate, wordType} = toRefs(props);

    const {getSumKeywordsChart} = useService(DashboardService);

    const sumCharts = ref<SumChart<Keyword>[]>([]);
    const isLoading = ref(false);

    const containsData = computed((): boolean => unref(chartSeries).reduce((total, item) => total + item.data.length, 0) > 0);

    const leaderboard = computed((): Keyword[] => {
        let totalListOfWords = unref(sumCharts).reduce((acc: Keyword[], item) => acc.concat(item.items), []);

        return totalListOfWords.reduce((acc: Keyword[], item) => {
            let keyword = acc.find(e => e.word === item.word);

            if (!keyword) {
                acc.push(new Keyword(item.word, item.amount));
            } else {
                keyword.amount += item.amount;
            }

            return acc;
        }, []).sort((a, b) => b.amount - a.amount);
    });

    const chartSeries = ref<ChartSeriesItem[]>([]);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumKeywordsChart(unref(wordType), unref(channels), unref(startDate), unref(endDate));
        sumCharts.value = response.data;

        chartSeries.value = unref(sumCharts).map(group => ({
            name: unref(channels)?.find(c => c.id === group.channelId)?.name ?? '',
            data: unref(leaderboard).slice(0, 7).map(item => {
                const itemInGroup = group.items.find(gi => gi.word === item.word);
                return {x: item.word, y: itemInGroup?.amount ?? null};
            })
        }));

        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 400px;
        background: none;
        border: none;
        box-shadow: none;
    }
</style>
