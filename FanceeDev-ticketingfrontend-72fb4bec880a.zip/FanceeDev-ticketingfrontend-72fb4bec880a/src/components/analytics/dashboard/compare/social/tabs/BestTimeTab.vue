<template>
    <FluxPane
        class="container"
        :is-loading="isLoading">
        <NoDashboardData
            v-if="!isLoading && chartSeries.length === 0"
            variation="full"/>

        <TimelineChart
            v-else-if="chartSeries"
            :series="chartSeries"
            :options="chartOptions"
            :start-date="startDate"
            :end-date="endDate"
            :is-loading="isLoading"/>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { DateTime } from 'luxon';
    import { ApexOptions } from 'apexcharts';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
    import { SumCommentsItem } from '@/data/dto/analytics/dashboard';
    import { DashboardService } from '@/data/service/DashboardService';
    import { ChartDataItem, ChartSeriesItem, Option } from '@/data/interface/charts';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';
    import TimelineChart from '@/components/analytics/cards/charts/TimelineChart.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumCommentsChart} = useService(DashboardService);

    const sumCharts = ref<SumChart<SumCommentsItem>[]>([]);
    const isLoading = ref(false);

    const chartCategories = computed((): Option[] => ([
        {id: 'Monday', label: t('global.dayStr.monday')},
        {id: 'Tuesday', label: t('global.dayStr.tuesday')},
        {id: 'Wednesday', label: t('global.dayStr.wednesday')},
        {id: 'Thursday', label: t('global.dayStr.thursday')},
        {id: 'Friday', label: t('global.dayStr.friday')},
        {id: 'Saturday', label: t('global.dayStr.saturday')},
        {id: 'Sunday', label: t('global.dayStr.sunday')}
    ]));

    const chartOptions = computed((): ApexOptions => ({
        xaxis: {
            categories: unref(chartCategories).map(cat => cat.label)
        },
        tooltip: {
            shared: false,
            custom: apexChartsBestTimeTooltip
        },
        yaxis: {
            max: 24,
            tickAmount: 7,
            labels: {}
        },
        grid: {
            padding: {
                left: 24,
                right: 24
            }
        }
    }));

    const chartSeries = computed((): ChartSeriesItem[] => {
        const _sumCharts = unref(sumCharts);
        const _channels = unref(channels);
        const _categories = unref(chartCategories);

        return _sumCharts.map(sumChart => ({
            name: (_channels?.find(c => c.id === sumChart.channelId)?.name ?? ''),
            data: sumChart.items.map(item => ({
                x: _categories.find(c => c.id === item.dayOfWeek)?.label,
                y: [parseInt(item.hour), (parseInt(item.hour) + 1)],
                comments: item.comments,
                likes: item.likes,
                reach: item.reach
            }) as ChartDataItem)
        } as ChartSeriesItem));
    });

    function apexChartsBestTimeTooltip({series, seriesIndex, dataPointIndex, w}) {
        const seriesArray = w.globals.initialSeries[seriesIndex];
        const item = seriesArray.data[dataPointIndex];

        const timeString = item.y.map(y => `${('00' + y).slice(-2)}:00`).join(' - ');

        return '<div>' + seriesArray.name + '</div><br/>' +
            '<div><b>' + item.x + '</b>' + '  ' + timeString + '</div>' +
            '<div><b>Comments</b>: ' + item.comments + '</div>' +
            '<div><b>Likes</b>: ' + item.likes + '</div>' +
            '<div><b>Shares</b>: ' + item.reach + '</div>';
    }

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumCommentsChart(unref(channels), unref(startDate), unref(endDate));
        sumCharts.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 500px;
        background: none;
        border: none;
        box-shadow: none;
    }
</style>
