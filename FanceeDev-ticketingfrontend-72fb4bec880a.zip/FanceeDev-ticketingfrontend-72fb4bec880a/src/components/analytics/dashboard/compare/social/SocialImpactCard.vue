<template>
    <FluxPane v-if="channels">
        <FluxPaneHeader :title="t('analytics.socialImpact.title')"/>

        <ChartGrowthHeader :chartGrowth="chartGrowth"/>

        <FluxPaneBody>
            <FluxTabs>
                <FluxTab :label="t('analytics.socialImpact.followers')">
                    <FollowersTab
                        :channels="channels"
                        :start-date="startDate"
                        :end-date="endDate"
                        @update-growth="updateGrowth"/>
                </FluxTab>

                <FluxTab :label="t('analytics.socialImpact.reach')">
                    <ReachTab
                        :channels="channels"
                        :start-date="startDate"
                        :end-date="endDate"
                        @update-growth="updateGrowth"/>
                </FluxTab>

                <FluxTab :label="t('analytics.socialImpact.engagement')">
                    <EngagementTab
                        :channels="channels"
                        :start-date="startDate"
                        :end-date="endDate"
                        @update-growth="updateGrowth"/>
                </FluxTab>

                <FluxTab :label="t('analytics.socialImpact.posts')">
                    <PostsTab
                        :channels="channels"
                        :start-date="startDate"
                        :end-date="endDate"
                        @update-growth="updateGrowth"/>
                </FluxTab>
            </FluxTabs>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { ref } from 'vue';
    import { DateTime } from 'luxon';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChartGrowth } from '@/data/interface/charts';
    import FollowersTab from '@/components/analytics/dashboard/compare/social/tabs/FollowersTab.vue';
    import ReachTab from '@/components/analytics/dashboard/compare/social/tabs/ReachTab.vue';
    import EngagementTab from '@/components/analytics/dashboard/compare/social/tabs/EngagementTab.vue';
    import PostsTab from '@/components/analytics/dashboard/compare/social/tabs/PostsTab.vue';
    import ChartGrowthHeader from '@/components/analytics/dashboard/compare/ChartGrowthHeader.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineProps<Props>();

    const {t} = useI18n();
    const chartGrowth = ref<ChartGrowth | null>(null);

    function updateGrowth(newChartGrowth: ChartGrowth): void {
        chartGrowth.value = newChartGrowth;
    }
</script>

<style
    lang="scss"
    scoped>
    .social-impact-subtitle {
        padding-left: 21px;
    }

    .growth-positive {
        color: rgb(var(--success-7));
    }

    .growth-negative {
        color: rgb(var(--danger-7));
    }
</style>

