<template>
    <FluxPane
        v-if="channels"
        class="container"
        :is-loading="isLoading">
        <NoDashboardData
            v-if="!isLoading && !containsData"
            variation="full"/>

        <span
            v-if="chartSeries"
            class="chartSync">
            <PolarAreaChart
                ref="apexChartRef"
                :series="chartSeries"
                :start-date="startDate"
                :end-date="endDate"
                :is-loading="isLoading"/>
        </span>

        <span
            v-if="chartSeries"
            class="chartSync absolute">
            <CircleWithText :titles="titles"/>
        </span>

        <div class="apexcharts-legend apexcharts-align-center apx-legend-position-bottom">
            <div
                v-for="(category, index) in legend"
                class="apexcharts-legend-series"
                :rel="index+1"
                @click="category.enabled = !category.enabled">
                <span
                    class="apexcharts-legend-marker"
                    :rel="index+1"
                    :style="`background: ${CHART_COMPARE_COLOR_ARRAY[index % 6]}`"/>
                <span
                    class="apexcharts-legend-text"
                    :rel="index+1">
                    {{ category.name }}
                </span>
            </div>
        </div>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { DateTime } from 'luxon';
    import { useService } from '@/composable';
    import { CHART_COMPARE_COLOR_ARRAY } from '@/data';
    import { DashboardService } from '@/data/service';
    import { ChartLegend, ChartSeriesItem, RotatedText } from '@/data/interface/charts';
    import { SumAgeAndGenderItem } from '@/data/dto/analytics/dashboard';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';
    import PolarAreaChart from '@/components/analytics/cards/charts/PolarAreaChart.vue';
    import CircleWithText from '@/components/analytics/dashboard/CircleWithText.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const apexChartRef = ref();

    const props = defineProps<Props>();

    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumGenderChart} = useService(DashboardService);

    const sumCharts = ref<SumChart<SumAgeAndGenderItem>[]>([]);
    const isLoading = ref(false);

    const titles = computed((): RotatedText[] => [
        {text: t('global.gender.male'), offset: '39%'},
        {text: t('global.gender.unknown'), offset: '22%', inside: true},
        {text: t('global.gender.female'), offset: '7%'}
    ]);

    const containsData = computed((): boolean => unref(sumCharts).reduce((total, item) => total + item.items.length, 0) > 0);

    const legend = ref<ChartLegend[]>([]);

    const filteredSumCharts = computed((): SumChart<SumAgeAndGenderItem>[] => {
        const _sumCharts = unref(sumCharts);
        const _legend = unref(legend);
        const filteredIds = _legend.filter(legend => legend.enabled).map(legend => legend.id);

        return _sumCharts.filter(chart => filteredIds.includes(chart.channelId));
    });

    const genderGroups = [
        {id: 'male', keys: ['male']},
        {id: 'unknown', keys: ['other', 'unknown', 'none', 'undefined']},
        {id: 'female', keys: ['female']}
    ];

    const chartSeries = computed((): ChartSeriesItem => {
        const _sumCharts = unref(filteredSumCharts);
        const _channels = unref(channels);
        const _legend = unref(legend);

        let newSeries: ChartSeriesItem = {
            name: 'Chart',
            data: []
        };

        genderGroups.forEach((group) => {
            _sumCharts.forEach((chart) => {
                const newVal = chart.items.find(item => group.keys.includes(item.gender))?.percentage ?? null;

                if (newVal === null) {
                    return;
                }

                const name = _channels?.find(channel => channel.id === chart.channelId)?.name ?? '';
                const seriesName = name + ' - ' + t(`global.gender.${group.id}`);
                const color = _legend.find(l => l.id === chart.channelId)?.color;

                newSeries.data.push({
                    x: seriesName,
                    y: newVal,
                    text: color
                });
            });
        });

        return newSeries;
    });

    function updateLegend(newChannels: Channel[]): void {
        legend.value = newChannels.map((group, index) => ({
            id: group.id,
            name: group.name,
            enabled: true,
            color: CHART_COMPARE_COLOR_ARRAY[index % newChannels.length]
        }));
    }

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumGenderChart(unref(channels), unref(startDate), unref(endDate));
        sumCharts.value = response.data;
        isLoading.value = false;
    }

    watch(channels, updateLegend, {immediate: true, deep: true});
    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 400px;
        background: none;
        border: none;
        box-shadow: none;
    }

    span.chartSync {
        display: flex;
        width: 100%;
        height: 400px;
        align-items: center;
        justify-content: center;

        &.absolute {
            position: absolute;
            left: 0;
            right: 0;
            top: -3px;
            bottom: 0;
            pointer-events: none;
        }
    }

    .apexcharts-legend {
        padding-bottom: 12px;
    }

    .apexcharts-legend-series {
        margin-top: 0 !important;
    }

    .apexcharts-legend-marker {
        height: 12px;
        width: 12px;
        left: 0;
        top: 0;
        border-width: 0;
        border-color: rgb(255, 255, 255);
        border-radius: 2px;
        margin: 2px 5px;
    }

    .apexcharts-legend-text {
        font-size: 12px !important;
        font-weight: 400;
    }

    #app .apexcharts-legend-series[collapsed=true] {
        opacity: 0.45;
    }

</style>
