<template>
    <FluxPane v-if="channels">
        <FluxPaneHeader :title="t('analytics.tags.title')"/>
        <FluxTabs>
            <FluxTab :label="t('analytics.tags.hashtags')">
                <HashtagTab
                    :channels="channels"
                    :end-date="endDate"
                    :start-date="startDate"
                    word-type="hashtags"/>
            </FluxTab>

            <FluxTab :label="t('analytics.tags.mentions')">
                <HashtagTab
                    :channels="channels"
                    :end-date="endDate"
                    :start-date="startDate"
                    word-type="mentions"/>
            </FluxTab>

            <FluxTab :label="t('analytics.tags.captions')">
                <HashtagTab
                    :channels="channels"
                    :end-date="endDate"
                    :start-date="startDate"
                    word-type="captions"/>
            </FluxTab>
        </FluxTabs>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { DateTime } from 'luxon';
    import { Channel } from '@/data/dto/analytics/channels';
    import HashtagTab from '@/components/analytics/dashboard/compare/social/tabs/HashtagTab.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>

