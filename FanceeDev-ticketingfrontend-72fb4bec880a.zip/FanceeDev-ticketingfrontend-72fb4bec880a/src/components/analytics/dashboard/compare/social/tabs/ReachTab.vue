<template>
    <FluxPane
        class="container"
        :is-loading="isLoading">
        <FluxStack v-if="channels">
            <MultiLineChart
                v-if="chartSeries"
                :series="chartSeries"
                :start-date="startDate"
                :end-date="endDate"
                :is-loading="isLoading"/>
        </FluxStack>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { ref, toRefs, unref, watch } from 'vue';
    import { DateTime } from 'luxon';
    import { useService } from '@/composable';
    import { useSumChart } from '@/data/composable/useSumChart';
    import { DashboardService } from '@/data/service';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChartGrowth } from '@/data/interface/charts';
    import MultiLineChart from '@/components/analytics/cards/charts/MultiLineChart.vue';

    export interface Emits {
        (e: 'update-growth', growth: ChartGrowth): void;
    }

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumReachChart} = useService(DashboardService);

    const isLoading = ref(false);

    const {
        chartSeries,
        chartGrowth,
        setSumCharts
    } = useSumChart(channels, 'date', 'value');

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumReachChart(unref(channels), unref(startDate), unref(endDate));
        setSumCharts(response.data);
        isLoading.value = false;
    }

    async function updateGrowth(): Promise<void> {
        emit('update-growth', unref(chartGrowth));
    }

    watch([chartGrowth], updateGrowth, {immediate: true, deep: true});
    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 315px;
        background: none;
        border: none;
        box-shadow: none;
    }
</style>
