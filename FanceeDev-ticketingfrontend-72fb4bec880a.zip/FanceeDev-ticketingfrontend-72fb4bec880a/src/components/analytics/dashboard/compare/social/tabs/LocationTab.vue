c
<template>
    <FluxPane
        v-if="channels"
        class="container"
        :is-loading="isLoading">
        <NoDashboardData
            v-if="!isLoading && !containsData"
            variation="full"/>

        <StackedBarChart
            v-else-if="chartSeries"
            :series="chartSeries"
            :options="chartOptions"
            :is-loading="isLoading"
            :start-date="startDate"
            :end-date="endDate"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { AddressAdapter, CountryCode } from '@fancee/data';
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { DashboardService } from '@/data/service';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChartSeriesItem } from '@/data/interface/charts';
    import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
    import { SumCountryItem } from '@/data/dto/analytics/dashboard';
    import StackedBarChart from '@/components/analytics/cards/charts/StackedBarChart.vue';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();

    const {channels, startDate, endDate} = toRefs(props);

    const {getSumCountriesChart} = useService(DashboardService);

    const sumCharts = ref<SumChart<SumCountryItem>[]>([]);
    const isLoading = ref(false);

    const containsData = computed((): boolean => unref(chartSeries).reduce((total, item) => total + item.data.length, 0) > 0);

    const chartOptions = computed((): ApexOptions => ({
        chart: {
            type: 'bar',
            stacked: true,
            stackType: '100%',
            animations: {
                enabled: false
            }
        },
        plotOptions: {
            bar: {
                horizontal: true
            }
        },
        legend: {
            showForSingleSeries: true,
            showForNullSeries: true,
            showForZeroSeries: true
        },
        dataLabels: {
            enabled: true
        }
    }) as ApexOptions);

    const chartSeries = computed((): ChartSeriesItem[] => {
        const _sumCharts = unref(sumCharts);
        const _channels = unref(channels);

        return _channels.map(channel => {
            const group = _sumCharts.find(c => c.channelId == channel.id);
            return {
                name: channel.name,
                data: group?.items.slice(0, 7).map(item => ({x: AddressAdapter.parseCountryCodeToEnglish(item.countryCode as CountryCode), y: item.followers})) ?? []
            };
        });
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumCountriesChart(unref(channels), unref(startDate), unref(endDate));
        sumCharts.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 400px;
        background: none;
        border: none;
        box-shadow: none;
    }
</style>
