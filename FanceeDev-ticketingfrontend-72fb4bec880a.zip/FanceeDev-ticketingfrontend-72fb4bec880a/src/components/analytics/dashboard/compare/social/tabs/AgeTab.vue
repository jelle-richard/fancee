<template>
    <FluxPane
        class="container"
        :is-loading="isLoading">
        <FluxStack v-if="channels">
            <NoDashboardData
                v-if="!isLoading && !containsData"
                variation="full"/>

            <StackedBarChart
                v-else-if="chartSeries"
                :height="height ?? 430"
                :series="chartSeries"
                :options="chartOptions"
                :start-date="startDate"
                :end-date="endDate"
                :is-loading="isLoading"/>
        </FluxStack>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { DateTime } from 'luxon';
    import { ApexOptions } from 'apexcharts';
    import { useService } from '@/composable';
    import { DashboardService } from '@/data/service';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumAgeAndGenderItem } from '@/data/dto/analytics/dashboard';
    import { ChartSeriesItem } from '@/data/interface/charts';
    import { SumChart } from '@/data/dto/analytics/dashboard/sum/SumChart';
    import StackedBarChart from '@/components/analytics/cards/charts/StackedBarChart.vue';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export interface Props {
        readonly height?: number;
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();

    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumAgeChart} = useService(DashboardService);

    const sumCharts = ref<SumChart<SumAgeAndGenderItem>[]>([]);
    const isLoading = ref(false);

    const chartOptions: ApexOptions = {
        plotOptions: {
            bar: {
                horizontal: false,
                borderRadius: 10,
                borderRadiusApplication: 'end',
                borderRadiusWhenStacked: 'last'
            }
        },
        legend: {
            position: 'bottom',
            showForSingleSeries: true,
            showForNullSeries: true,
            showForZeroSeries: true
        }
    };

    const containsData = computed((): boolean => unref(chartSeries).reduce((total, item) => total + item.data.length, 0) > 0);

    const categories = ['13-17', '18-24', '25-34', '35-44', '45-54', '55-64', '65+'];
    const chartSeries = computed((): ChartSeriesItem[] => {
        const _sumCharts = unref(sumCharts);
        const _channels = unref(channels);

        return _channels.map(channel => {
            const group = _sumCharts.find(c => c.channelId == channel.id);
            return {
                name: channel.name,
                data: categories.map(item => {
                    const itemInGroup = group?.items.find(gi => gi.age === item);
                    return {x: item, y: itemInGroup?.followers};
                })
            }
        });
    });

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumAgeChart(unref(channels), unref(startDate), unref(endDate));
        sumCharts.value = response.data;
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 400px;
        background: none;
        border: none;
        box-shadow: none;
    }
</style>
