<template>
    <FluxPane
        class="container"
        :is-loading="isLoading">
        <FluxStack v-if="channels">
            <FluxFormInputGroup class="floating-select">
                <FluxFormInputAddition :text="t('flux.sort')"/>
                <FluxFormSelect
                    v-model="fieldSelection"
                    :options="sortOptions"/>
            </FluxFormInputGroup>
            <MultiLineChart
                v-if="chartSeries"
                :series="chartSeries"
                :start-date="startDate"
                :end-date="endDate"
                :is-loading="isLoading"/>
        </FluxStack>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { DateTime } from 'luxon';
    import { useService } from '@/composable';
    import { useSumChart } from '@/data/composable/useSumChart';
    import { DashboardService } from '@/data/service';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChartGrowth, Option } from '@/data/interface/charts';
    import MultiLineChart from '@/components/analytics/cards/charts/MultiLineChart.vue';

    export interface Emits {
        (e: 'update-growth', growth: ChartGrowth): void;
    }

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getSumEngagementChart} = useService(DashboardService);

    const isLoading = ref(false);

    const {
        chartSeries,
        fieldSelection,
        chartGrowth,
        setSumCharts
    } = useSumChart(channels, 'date', 'shares');

    const sortOptions = computed((): Option[] => [
        {id: 'shares', label: t('analytics.engagement.shares')},
        {id: 'comments', label: t('analytics.engagement.comments')},
        {id: 'likes', label: t('analytics.engagement.likes')}
    ]);

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumEngagementChart(unref(channels), unref(startDate), unref(endDate));
        setSumCharts(response.data);
        isLoading.value = false;
    }

    async function updateGrowth(): Promise<void> {
        emit('update-growth', unref(chartGrowth));
    }

    watch([chartGrowth], updateGrowth, {immediate: true, deep: true});
    watch([channels, startDate, endDate], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .container {
        min-height: 315px;
        background: none;
        border: none;
        box-shadow: none;
    }

    .floating-select {
        position: absolute;
        right: 15px;
        top: -66px;
        width: auto;
    }

    ::v-deep {
        .flux-form-select > .flux-menu-item {
            display: contents;
        }

        .flux-form-input {
            white-space: nowrap;
            max-width: none;

            &.flux-form-select {
                flex: 0;
            }

            &[is-disabled=true] {
                outline: none;
                cursor: auto;

                > .flux-form-input {
                    background: var(--gray-4);
                    cursor: auto;
                }
            }

            .flux-button span {
                font-weight: inherit;
            }

            .flux-form-select-popup {
                width: auto;
            }
        }
    }
</style>
