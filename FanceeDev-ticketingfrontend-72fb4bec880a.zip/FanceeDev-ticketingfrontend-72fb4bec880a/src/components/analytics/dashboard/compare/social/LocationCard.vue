<template>
    <FluxPane v-if="channels">
        <FluxPaneHeader :title="t('analytics.locations.title')"/>

        <LocationTab
            :channels="channels"
            :end-date="endDate"
            :start-date="startDate"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { useI18n } from 'vue-i18n';
    import { DateTime } from 'luxon';
    import { Channel } from '@/data/dto/analytics/channels';
    import LocationTab from '@/components/analytics/dashboard/compare/social/tabs/LocationTab.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>

