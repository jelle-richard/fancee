<template>
    <FluxStack v-if="channels">
        <FluxGrid>
            <FluxGridColumn :sm="5">
                <MultiSumFollowersCard
                    :channels="channels"
                    :startDate="startDate"
                    :endDate="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn :sm="3">
                <MultiSumReachCard
                    :channels="channels"
                    :startDate="startDate"
                    :endDate="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn :sm="4">
                <MultiSumEngagementCard
                    :channels="channels"
                    :startDate="startDate"
                    :endDate="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn>
                <SocialImpactCard
                    :channels="channels"
                    :start-date="startDate"
                    :end-date="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn>
                <BestTimeCard
                    :channels="channels"
                    :start-date="startDate"
                    :end-date="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn>
                <LocationCard
                    :channels="channels"
                    :start-date="startDate"
                    :end-date="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn>
                <TagsCard
                    :channels="channels"
                    :start-date="startDate"
                    :end-date="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn
                v-if="channels.some(ch => ([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2] as ChannelType[]).includes(ch.type))"
                :sm="8">
                <AgeCard
                    :channels="channels.filter(ch => ([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2] as ChannelType[]).includes(ch.type))"
                    :start-date="startDate"
                    :end-date="endDate"/>
            </FluxGridColumn>

            <FluxGridColumn
                v-if="channels.some(ch => ([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2, ChannelType.TikTok] as ChannelType[]).includes(ch.type))"
                :sm="4">
                <GenderCard
                    :channels="channels.filter(ch => ([ChannelType.Facebook, ChannelType.Instagram, ChannelType.YoutubeV2, ChannelType.TikTok] as ChannelType[]).includes(ch.type))"
                    :start-date="startDate"
                    :end-date="endDate"/>
            </FluxGridColumn>
        </FluxGrid>
    </FluxStack>
</template>

<script
    setup
    lang="ts">
    import { DateTime } from 'luxon';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { Channel } from '@/data/dto/analytics/channels';
    import MultiSumEngagementCard from '@/components/analytics/dashboard/MultiSumEngagementCard.vue';
    import MultiSumReachCard from '@/components/analytics/dashboard/MultiSumReachCard.vue';
    import MultiSumFollowersCard from '@/components/analytics/dashboard/MultiSumFollowersCard.vue';
    import SocialImpactCard from '@/components/analytics/dashboard/compare/social/SocialImpactCard.vue';
    import TagsCard from '@/components/analytics/dashboard/compare/social/TagsCard.vue';
    import AgeCard from '@/components/analytics/dashboard/compare/social/AgeCard.vue';
    import GenderCard from '@/components/analytics/dashboard/compare/social/GenderCard.vue';
    import BestTimeCard from '@/components/analytics/dashboard/compare/social/BestTimeCard.vue';
    import LocationCard from '@/components/analytics/dashboard/compare/social/LocationCard.vue';

    export interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineProps<Props>();
</script>
