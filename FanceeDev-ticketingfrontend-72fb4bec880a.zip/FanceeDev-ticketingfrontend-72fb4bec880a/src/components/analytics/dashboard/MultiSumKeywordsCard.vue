<template>
    <WordCloudCard
        :is-loading="isLoading"
        :title="title"
        :subtitle="subtitle"
        :chart-data="keywords"
        :color="color"/>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { Keyword } from '@/data/dto/analytics/posts';
    import { DashboardService } from '@/data/service/DashboardService';
    import WordCloudCard from '@/components/analytics/cards/WordCloudCard.vue';

    interface Props {
        channels: Channel[];
        startDate: DateTime;
        endDate: DateTime;
        title?: string;
        subtitle?: string;
        color?: string;
        type: 'hashtags' | 'mentions' | 'captions';
    }

    const props = defineProps<Props>();
    const {channels, startDate, endDate, type} = toRefs(props);

    const keywords = ref<Keyword[]>([]);
    const isLoading = ref(false);
    const {getSumKeywords} = useService(DashboardService);

    async function updateData() {
        isLoading.value = true;
        const response = await getSumKeywords(unref(type), unref(channels), unref(startDate), unref(endDate));
        keywords.value = response.data.slice(0, 20);
        isLoading.value = false;
    }

    watch([channels, startDate, endDate], updateData, {immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .chart-container {
        height: 300px;
        min-height: 300px;
        max-height: 300px;
    }
</style>
