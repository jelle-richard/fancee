<template>
    <label :class="variation">{{ getTitle }}</label>
</template>

<script
    lang="ts"
    setup>
    import { computed, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';

    export interface Props {
        readonly title?: string;
        readonly variation?: 'default' | 'full';
    }

    const props = withDefaults(defineProps<Props>(), {
        variation: 'default'
    });
    const {title} = toRefs(props);

    const {t} = useI18n();

    const getTitle = computed((): string => unref(title) ?? t('analytics.noData'));
</script>

<style
    lang="scss"
    scoped>
    label.full {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100%;
    }
</style>
