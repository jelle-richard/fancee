<template>
    <ColumnChartCard
        :key="Math.random()"
        :is-loading="isLoading"
        :is-downloading="downloadInProgress"
        :title="t('analytics.ticketing.gendersByAge.title')"
        :chart-data="chartSeries"
        :chart-options="chartOptions"
        @download="downloadBuyerProfiles()"/>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useActiveOrganizationId, useService } from '@/composable';
    import { DashboardService } from '@/data/service/DashboardService';
    import { AgeByGenderItem } from '@/data/dto/analytics/dashboard/ticketing/AgeByGenderItem';
    import { CHART_COLOR_ARRAY, CHART_COLORS } from '@/data';
    import { downloadBlob } from '@/util';
    import ColumnChartCard from '@/components/analytics/cards/ColumnChartCard.vue';

    interface Props {
        selectedEventIds: string[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {selectedEventIds, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const {getGendersByAgeGroup, buyerProfilesExport} = useService(DashboardService);
    const organizationId = useActiveOrganizationId();

    const entries = ref<AgeByGenderItem[] | null>(null);
    const downloadInProgress = ref(false);
    const isLoading = ref(false);
    const chartSeries = ref<ApexAxisChartSeries[]>([]);
    const chartOptions = ref<ApexOptions>({
        chart: {
            type: 'bar',
            stacked: false,
            toolbar: {
                show: false
            }
        },
        legend: {
            position: 'bottom'
        },
        plotOptions: {
            bar: {
                horizontal: false,
                dataLabels: {
                    position: 'top'
                }
            }
        },
        tooltip: {
            enabled: true,
            intersect: true,
            x: {
                show: false
            }
        },
        colors: CHART_COLOR_ARRAY,
        dataLabels: {
            enabled: true,
            offsetY: -22,
            background: {
                enabled: true,
                foreColor: CHART_COLORS[0],
                padding: 4,
                borderRadius: 2,
                borderWidth: 0,
                opacity: 1
            }
        },
        stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
        },
        xaxis: {
            categories: [] as string[]
        },
        fill: {
            opacity: 1
        }
    });

    function fillChart(): void {
        chartSeries.value = [];
        chartOptions.value.xaxis!.categories = [];

        const maleTickets: number[] = [];
        const femaleTickets: number[] = [];
        const neutralTickets: number[] = [];
        const unknownTickets: number[] = [];

        let totalMaleTickets: number = 0;
        let totalFemaleTickets: number = 0;
        let totalNeutralTickets: number = 0;
        let totalUnknownTickets: number = 0;

        if (!unref(entries)) {
            return;
        }

        unref(entries)!.forEach(e => {
            chartOptions.value.xaxis!.categories.push(e.ageGroup);

            totalMaleTickets += e.maleTickets;
            totalFemaleTickets += e.femaleTickets;
            totalNeutralTickets += e.neutralTickets;
            totalUnknownTickets += e.unknownTickets;

            maleTickets.push(e.maleTickets);
            femaleTickets.push(e.femaleTickets);
            neutralTickets.push(e.neutralTickets);
            unknownTickets.push(e.unknownTickets);
        });

        maleTickets.push(totalMaleTickets);
        femaleTickets.push(totalFemaleTickets);
        neutralTickets.push(totalNeutralTickets);
        unknownTickets.push(totalUnknownTickets);

        chartOptions.value.xaxis!.categories.push(t('global.total'));

        chartSeries.value.push(
            {data: maleTickets, name: t('global.gender.male')} as unknown as ApexAxisChartSeries,
            {data: femaleTickets, name: t('global.gender.female')} as unknown as ApexAxisChartSeries,
            {data: neutralTickets, name: t('global.gender.neutral')} as unknown as ApexAxisChartSeries,
            {data: unknownTickets, name: t('global.gender.unknown')} as unknown as ApexAxisChartSeries
        );
    }

    async function updateData() {
        isLoading.value = true;
        const response = await getGendersByAgeGroup(unref(organizationId), unref(selectedEventIds), unref(startDate), unref(endDate));
        entries.value = response.data;
        fillChart();
        isLoading.value = false;
    }

    async function downloadBuyerProfiles(): Promise<void> {
        downloadInProgress.value = true;

        try {
            const {blob, name} = await buyerProfilesExport(unref(organizationId), unref(selectedEventIds), unref(startDate), unref(endDate));
            downloadBlob(blob, name);
        } finally {
            downloadInProgress.value = false;
        }
    }

    watch([startDate, endDate, selectedEventIds], updateData, {deep: true, immediate: true});
</script>
