<template>
    <FluxTimeline>
        <FluxTimelineItem
            v-for="log in props.logs"
            :key="log.id"
            :icon="levelToIcon(log.level)"
            :title="log.message"
            :when="formatDateTime(log.createdOn)"
            :color="levelToVariant(log.level)">
            <FluxExpandable v-if="log.data">
                <template #header="{isOpen, close, open, toggle}">
                    <FluxSecondaryButton
                        class="align-self-start"
                        label="Data"
                        @click="toggle"/>
                </template>

                <template #body>
                    <FluxNotice>
                        <pre>{{ JSON.stringify(log.data, null, 4) }}</pre>
                    </FluxNotice>
                </template>
            </FluxExpandable>

            <FluxExpandable v-if="log.exception">
                <template #header="{isOpen, close, open, toggle}">
                    <FluxSecondaryButton
                        class="align-self-start"
                        label="Exception"
                        @click="toggle"/>
                </template>

                <template #body>
                    <FluxNotice>
                        <pre>{{ JSON.stringify(log.exception, null, 4) }}</pre>
                    </FluxNotice>
                </template>
            </FluxExpandable>
        </FluxTimelineItem>
    </FluxTimeline>
</template>

<script
    lang="ts"
    setup>
    import { IconNames } from '@fancee/flux';
    import { useI18n } from 'vue-i18n';
    import { Log } from '@/data/dto/analytics/logs/Log';
    import { formatDateTime } from '@/util';

    export interface Props {
        logs: Log[];
        userType: string;
    }

    const props = defineProps<Props>();

    const {t} = useI18n();

    function levelToVariant(level: string): string {
        switch (level) {
            case 'Warning':
                return 'warning';

            case 'Error':
                return 'danger';

            case 'Success':
                return 'success';

            default:
                return 'primary';
        }
    }

    function levelToIcon(level: string): IconNames {
        switch (level) {
            case 'Warning':
                return 'star';

            case 'Error':
                return 'circle-exclamation';

            case 'Success':
                return 'check';

            default:
                return 'circle-info';
        }
    }
</script>

