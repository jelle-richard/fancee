<template>
    <FluxPane v-if="channelRequest">
        <FluxPaneHeader :title="t('analytics.channel.new.title')"/>
        <ValidationNotice pane-body/>

        <FluxPaneBody>
            <FluxFormColumn>
                <ValidationField
                    :label="t('form.field.name')"
                    :rules="{required}"
                    :value="channelRequest.name">
                    <FluxFormInputGroup>
                        <FluxFormInput v-model="channelRequest.name"/>
                    </FluxFormInputGroup>
                </ValidationField>

                <ValidationField
                    :label="t('form.field.type')"
                    :rules="{required}"
                    :value="channelRequest.type">
                    <FluxFormSelect
                        v-model="channelRequest.type"
                        :options="channelTypeOptions"/>
                </ValidationField>

                <ValidationField
                    v-if="user?.type === UserType.Admin"
                    :label="t('form.field.organization')"
                    :rules="{required}"
                    :value="selectedOrganization">
                    <FluxFormInputGroup>
                        <FluxFlyout
                            ref="organizationFlyoutRef"
                            :is-auto-width="true">
                            <template #opener="{open}">
                                <FluxSecondaryButton
                                    :label="selectedOrganization?.name ?? t('flux.search')"
                                    icon-after="chevron-down"
                                    @click="open"/>
                            </template>

                            <template #default="{close}">
                                <FluxMenu>
                                    <FluxFormInput
                                        :placeholder="`${t('flux.search')}`"
                                        v-model="filter.search"
                                        icon-before="search"/>
                                    <FluxMenuGroup>
                                        <FluxSpinner v-if="isLoading"/>
                                        <NoDashboardData v-if="!isLoading && organizations.length === 0"/>
                                        <FluxMenuItem
                                            v-if="!isLoading"
                                            v-for="item in organizations"
                                            :key="item.id"
                                            :is-highlighted="selectedOrganization?.id === item.id"
                                            :label="item.name"
                                            icon-before="users"
                                            @click="selectOrganization(item)"/>
                                    </FluxMenuGroup>
                                </FluxMenu>
                            </template>
                        </FluxFlyout>
                    </FluxFormInputGroup>
                </ValidationField>

                <FluxSpinner v-if="isLoadingManagedBy"/>

                <ValidationField
                    v-if="!!selectedManagedBy"
                    :label="t('analytics.channel.new.user')"
                    :rules="{required}"
                    :value="managedByName">
                    <FluxFormInputGroup>
                        <FluxFormInput
                            v-model="managedByName"
                            is-disabled/>
                    </FluxFormInputGroup>
                </ValidationField>

                <ValidationField
                    :label="t('analytics.channel.new.supermetrics.user')"
                    :rules="{required}"
                    :value="channelRequest.userId">
                    <FluxFormInputGroup>
                        <FluxFormInput v-model="channelRequest.userId"/>
                    </FluxFormInputGroup>
                </ValidationField>

                <ValidationField
                    :label="t('analytics.channel.new.supermetrics.account')"
                    :rules="{required}"
                    :value="channelRequest.accountsId">
                    <FluxFormInputGroup>
                        <FluxFormInput v-model="channelRequest.accountsId"/>
                    </FluxFormInputGroup>
                </ValidationField>
            </FluxFormColumn>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxSecondaryButton
                :label="t('global.cancel')"
                @click="$emit('cancel')"/>

            <FluxPrimaryButton
                :disabled="invalid"
                :is-loading="isLoading || isLoadingManagedBy"
                :label="t('global.save')"
                @click="validated(saveOrganization)"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { FluxFormSelectOption } from '@fancee/flux';
    import { OrganizationService } from '@fancee/api';
    import { ManagedBy, OrganizationListFilter, OrganizationListing, UserType } from '@fancee/data';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useService, useUser, useValidationScope } from '@/composable';
    import { ValidationNotice } from '@/components/form';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { required } from '@/data/validation';
    import { storeToRefs, useAuthStore, useUiStore } from '@/data/store';
    import { CreateChannelRequest } from '@/data/dto/analytics/channels/CreateChannelRequest';
    import { DEFAULT_PAGES_AMOUNT } from '@/data';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';
    import ValidationField from '@/components/form/ValidationField.vue';

    export type Emits = {
        (e: 'save'): void;
        (e: 'cancel'): void;
    };

    export type Props = {
        readonly channelRequest: CreateChannelRequest;
    };

    const props = defineProps<Props>();
    const {channelRequest} = toRefs(props);

    const emits = defineEmits<Emits>();

    const organizationFlyoutRef = ref();

    const uiStore = useUiStore();
    const user = useUser();
    const {t} = useI18n();
    const {allowedCountries} = storeToRefs(uiStore);
    const {manageableOrganizations} = storeToRefs(useAuthStore());
    const {invalid, validated} = useValidationScope();

    const {list, getAccount} = useService(OrganizationService);

    const channelTypeOptions = computed((): FluxFormSelectOption[] => [...Object.keys(ChannelType).map<FluxFormSelectOption>(entry => ({id: entry, label: t(`analytics.channel.type.${entry.toLowerCase()}`)}))]);

    const organizations = ref<OrganizationListing[]>([]);
    const selectedOrganization = ref<OrganizationListing | null>(null);
    const isLoading = ref(false);
    const selectedManagedBy = ref<ManagedBy | null>(null);
    const isLoadingManagedBy = ref(false);
    const initialLoadSucceeded = ref(false);
    const filter = ref(OrganizationListFilter.default());

    const managedByName = computed((): string => {
        const _managedBy = unref(selectedManagedBy);
        return !_managedBy ? '' : `${_managedBy.firstName} ${_managedBy.lastName}`;
    });

    function saveOrganization(): void {
        const _user = unref(user);
        const _manageableOrganizations = unref(manageableOrganizations);
        const _managedBy = unref(selectedManagedBy);
        const _selectedOrganization = unref(selectedOrganization);

        if (!!_managedBy) {
            channelRequest.value.platformUserId = _managedBy.id;
            channelRequest.value.owner.firstName = _managedBy.firstName;
            channelRequest.value.owner.lastName = _managedBy.lastName;
            channelRequest.value.owner.email = _managedBy.email;
        } else if (!!_user) {
            channelRequest.value.owner.firstName = _user.firstName;
            channelRequest.value.owner.lastName = _user.lastName;
            channelRequest.value.owner.email = _user.email;
        }

        if (!!_selectedOrganization) {
            channelRequest.value.owner.organizationId = _selectedOrganization.id;
            channelRequest.value.owner.organizationName = _selectedOrganization.name;
        } else if (!!user && !!_manageableOrganizations) {
            const activeOrganization = _manageableOrganizations.find(organization => organization.id === _user?.activeOrganizationId);

            channelRequest.value.owner.organizationId = activeOrganization?.id ?? null;
            channelRequest.value.owner.organizationName = activeOrganization?.name ?? null;
        }

        emits('save');
    }

    function selectOrganization(selection: OrganizationListing): void {
        selectedOrganization.value = selection;
        filter.value.search = '';

        unref(organizationFlyoutRef.value)?.close();
    }

    async function getOrganizations(): Promise<void> {
        if (unref(user)?.type !== UserType.Admin) {
            return;
        }

        isLoading.value = true;

        try {
            const {data: {items}} = await list(15, DEFAULT_PAGES_AMOUNT, unref(filter), unref(allowedCountries));

            organizations.value = items.filter(item => item.isVerified).slice(0, 5);

            initialLoadSucceeded.value = true;
        } catch (err) {
            initialLoadSucceeded.value = false;
        }

        isLoading.value = false;
    }

    async function updateManagedUserId(): Promise<void> {
        const _organization = unref(selectedOrganization);

        if (!_organization) {
            return;
        }

        isLoadingManagedBy.value = true;

        try {
            const {data} = await getAccount(_organization?.id ?? '');
            selectedManagedBy.value = data.managedBy[0];
        } catch (err) {
            filter.value.search = '';
            selectedOrganization.value = null;
            selectedManagedBy.value = null;
        }

        isLoadingManagedBy.value = false;
    }

    watch(selectedOrganization, updateManagedUserId, {immediate: true, deep: true});
    watch(filter, () => getOrganizations(), {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-button) span {
        font-weight: inherit;
    }

    ::v-deep(.flux-flyout) .flux-button {
        justify-content: space-between;
        flex: 1;
    }
</style>
