<template>
    <FluxNotice
        icon="empty-set"
        :title="t('analytics.noChannelsFound.title')"
        :message="t('analytics.noChannelsFound.message')"
        variant="info"/>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';

    const {t} = useI18n();
</script>
