<template>
    <FluxInfo
        :class="channelTypeClass"
        :icon="channelTypeIcon">
        {{ channelTypeText }}
    </FluxInfo>
</template>

<script
    lang="ts"
    setup>
    import { IconNames } from '@fancee/flux';
    import { computed, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ChannelType } from '@/data/enum/analytics/api';
    import { getChannelTypeIcon } from '@/product/analytics/util';

    export interface Props {
        readonly channelType: ChannelType;
    }

    const props = defineProps<Props>();
    const {channelType} = toRefs(props);

    const {t} = useI18n();

    const channelTypeClass = computed((): string => `channel-type-${unref(channelType).toLowerCase()}`);
    const channelTypeIcon = computed((): IconNames => getChannelTypeIcon(unref(channelType)));
    const channelTypeText = computed((): string => t(unref(channelType).toLowerCase()));
</script>

<style lang="scss">
    .flux-info.channel-type-instagram svg {
        color: #d62976;
    }

    .flux-info.channel-type-googleanalytics svg,
    .flux-info.channel-type-googleanalytics4 svg {
        color: orange;
    }

    .flux-info.channel-type-youtube svg,
    .flux-info.channel-type-youtubev2 svg {
        color: red;
    }
</style>
