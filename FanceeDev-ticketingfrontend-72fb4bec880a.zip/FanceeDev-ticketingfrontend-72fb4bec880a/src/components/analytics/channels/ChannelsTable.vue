<template>
    <FluxDataTable
        v-if="user"
        :data-set="rows"
        :page="page"
        :per-page="pageSize"
        :total="totalItems"
        is-hoverable>
        <template #header>
            <FluxTableHeader>
                {{ t('analytics.channel.table.name') }}
                <MultiSortMenu
                    :options="['Name']"
                    :orderBy="orderBy"
                    :order-by-direction="orderByDirection"
                    @sort="(option, sortBy) => $emit('on-order-update', option, sortBy)"/>
            </FluxTableHeader>

            <FluxTableHeader>
                {{ t('analytics.channel.table.type') }}
                <MultiSortMenu
                    :options="['Type']"
                    :orderBy="orderBy"
                    :order-by-direction="orderByDirection"
                    @sort="(option,sortBy) => $emit('on-order-update', option, sortBy)"/>
            </FluxTableHeader>

            <FluxTableHeader>
                {{ t('analytics.channel.table.status') }}
                <MultiSortMenu
                    :options="['Status']"
                    :orderBy="orderBy"
                    :order-by-direction="orderByDirection"
                    @sort="(option,sortBy) => $emit('on-order-update', option, sortBy)"/>
            </FluxTableHeader>

            <FluxTableHeader v-if="user.type === UserType.Admin">
                {{ t('analytics.channel.table.organization') }}
                <MultiSortMenu
                    :options="['Organization']"
                    :orderBy="orderBy"
                    :order-by-direction="orderByDirection"
                    @sort="(option,sortBy) => $emit('on-order-update', option, sortBy)"/>
            </FluxTableHeader>

            <FluxTableHeader v-if="user.type === UserType.Admin">
                {{ t('analytics.channel.table.owner') }}
                <MultiSortMenu
                    :options="['Owner']"
                    :orderBy="orderBy"
                    :order-by-direction="orderByDirection"
                    @sort="(option,sortBy) => $emit('on-order-update', option, sortBy)"/>
            </FluxTableHeader>

            <FluxTableHeader v-if="user.type === UserType.Admin">
                {{ t('analytics.channel.table.email') }}
                <MultiSortMenu
                    :options="['Email']"
                    :orderBy="orderBy"
                    :order-by-direction="orderByDirection"
                    @sort="(option,sortBy) => $emit('on-order-update', option, sortBy)"/>
            </FluxTableHeader>

            <FluxTableHeader>
                {{ t('analytics.channel.table.createdOn') }}
                <MultiSortMenu
                    :options="['CreatedOn']"
                    :orderBy="orderBy"
                    :order-by-direction="orderByDirection"
                    @sort="(option,sortBy) => $emit('on-order-update', option, sortBy)"/>
            </FluxTableHeader>

            <FluxTableHeader is-shrinking/>
        </template>

        <template #name="{row: {name}}">
            <FluxTableCell>{{ name }}</FluxTableCell>
        </template>

        <template #type="{row: {type}}">
            <FluxTableCell>
                <img
                    class="channel-icon"
                    :src="getChannelTypeSVGPath(type)"
                    alt=""/>
                {{ t(`analytics.channel.type.${type.toLowerCase()}`) }}
            </FluxTableCell>
        </template>

        <template #status="{row: {status}}">
            <FluxTableCell>
                <FluxBadge
                    dot
                    :color="ChannelAdapter.parseChannelStatusToStatusColor(status)"
                    :label="t(`analytics.channel.status.${toCamelCase(status)}`)"/>
            </FluxTableCell>
        </template>

        <template
            v-if="user.type === UserType.Admin"
            #organization="{row: {owner}}">
            <FluxTableCell>
                {{ owner?.organizationName }}
            </FluxTableCell>
        </template>

        <template
            v-if="user.type === UserType.Admin"
            #owner="{row: {owner}}">
            <FluxTableCell>
                <span v-if="!!owner">{{ owner?.firstName + ' ' + owner?.lastName }}</span>
            </FluxTableCell>
        </template>

        <template
            v-if="user.type === UserType.Admin"
            #email="{row: {owner}}">
            <FluxTableCell>
                {{ owner?.email }}
            </FluxTableCell>
        </template>

        <template
            v-if="true"
            #createdOn="{row: {createdOn}}">
            <FluxTableCell>{{ formatDateTime(createdOn) }}</FluxTableCell>
        </template>

        <template
            v-if="true"
            #id="{row: {id}}">
            <FluxTableCell>
                <FluxTableActions>
                    <FluxTooltip :content="t('global.edit')">
                        <FluxAction
                            icon="pen"
                            @click="onRowClick(id)"/>
                    </FluxTooltip>
                </FluxTableActions>
            </FluxTableCell>
        </template>
    </FluxDataTable>
</template>

<script
    lang="ts"
    setup>
    import { UserType } from '@fancee/data';
    import { unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRouter, useUser } from '@/composable';
    import { formatDateTime, toCamelCase } from '@/util';
    import { getChannelTypeSVGPath } from '@/product/analytics/util';
    import { Channel } from '@/data/dto/analytics/channels';
    import { ChannelAdapter } from '@/data/adapter/analytics/channels/ChannelAdapter';
    import MultiSortMenu from '@/components/analytics/posts/MultiSortMenu.vue';

    export interface Emits {
        (e: 'on-order-update', option: string | null, sort: 'ascending' | 'descending' | null): void;
    }

    export interface Props {
        readonly rows: Channel[];
        readonly page: number;
        readonly pageSize: number;
        readonly totalItems: number;
        readonly orderBy: string | null;
        readonly orderByDirection: 'ascending' | 'descending' | null;
    }

    defineEmits<Emits>();
    defineProps<Props>();

    const {t} = useI18n();
    const router = useRouter();
    const user = useUser();

    const onRowClick = async (id: string | null) => {
        const _user = unref(user);
        await router.push({name: _user?.type === UserType.Admin ? 'crm-channel' : 'channel', params: {id: id ?? 'error'}});
    };

</script>

<style lang="scss">
    .channel-icon {
        width: 19px;
        height: 19px;
        margin-right: 1rem;
        margin-top: 2px;
    }
</style>
