<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="t('analytics.ads.title')"/>

        <FluxDataTable
            :data-set="campaigns"
            :page="currentPage"
            :per-page="pageLength"
            :total="totalItems"
            :is-separated="false"
            is-hoverable>
            <template #header>
                <FluxTableHeader>
                    {{ t('analytics.ads.campaign') }}
                    <MultiSortMenu
                        :options="['Name']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.date') }}
                    <MultiSortMenu
                        :options="['StartDate']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.cost') }}
                    <MultiSortMenu
                        :options="['Cost']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.budget') }}
                    <MultiSortMenu
                        :options="['Budget']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.status') }}
                    <MultiSortMenu
                        :options="['Status']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.impressions') }}
                    <MultiSortMenu
                        :options="['Impressions']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.clicks') }}
                    <MultiSortMenu
                        :options="['Clicks']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.cpc') }}
                    <MultiSortMenu
                        :options="['CPC']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.ctr') }}
                    <MultiSortMenu
                        :options="['CTR']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader>
                    {{ t('analytics.ads.conversion') }}
                    <MultiSortMenu
                        :options="['Conversion']"
                        :orderBy="orderBy"
                        :order-by-direction="orderByDirection"
                        @sort="onSort"/>
                </FluxTableHeader>

                <FluxTableHeader is-shrinking/>
            </template>

            <template #campaign="{row: {source, name}}">
                <FluxTableCell>
                    <img
                        class="channel-icon"
                        :src="getSubscriptionTypeSVGPath(source)"
                        alt=""/>

                    <FluxStack gap="0">
                        <label><strong>{{ t(`analytics.channel.type.${getChannelTypeForSubcriptionType(source).toString().toLowerCase()}`) }}</strong></label>
                        <label>{{ name }}</label>
                    </FluxStack>
                </FluxTableCell>
            </template>

            <template #startDate="{row: {startDate}}">
                <FluxTableCell contentDirection="column">
                    <label class="cell-title">{{ formatDate(startDate) }}</label>
                </FluxTableCell>
            </template>

            <template #cost="{row: {cost}}">
                <FluxTableCell>
                    {{ toCurrency(cost) }}
                </FluxTableCell>
            </template>

            <template #budget="{row: {budget}}">
                <FluxTableCell>
                    {{ toCurrency(budget) }}
                </FluxTableCell>
            </template>

            <template #status="{row: {status}}">
                <FluxTableCell>
                    <FluxBadge
                        :icon="status === 'enabled' ? 'circle-check' : 'circle-xmark'"
                        :color="status === 'enabled' ? 'success' : 'danger'"
                        :label="t(`analytics.${status}`)"/>
                </FluxTableCell>
            </template>

            <template #impressions="{row: {impressions}}">
                <FluxTableCell>
                    {{ asCompactNumber(impressions) }}
                </FluxTableCell>
            </template>

            <template #clicks="{row: {clicks}}">
                <FluxTableCell>
                    {{ asCompactNumber(clicks) }}
                </FluxTableCell>
            </template>

            <template #cpc="{row: {cpc}}">
                <FluxTableCell>
                    {{ asMoney(decimalToCents(cpc, currency), currency) }}
                </FluxTableCell>
            </template>

            <template #ctr="{row: {ctr}}">
                <FluxTableCell>
                    {{ ctr.toFixed(2) }}
                </FluxTableCell>
            </template>

            <template #conversion="{row: {conversion}}">
                <FluxTableCell>
                    {{ (conversion * 100).toFixed(0) }}%
                </FluxTableCell>
            </template>

            <template #actions="{row}">
                <FluxTableCell>
                    <FluxTableActions>
                        <FluxAction
                            class="open-overlay-button"
                            icon="clone"
                            @click="$emit('on-campaign-selected', row)"/>
                    </FluxTableActions>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneBody v-if="!isLoading && campaigns.length === 0">
            <NoDashboardData variation="full"/>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="totalItems"
                @limit="limit => { setCurrentPage(1); setPageLength(limit); }"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useCurrency, usePagination, useService } from '@/composable';
    import { Channel } from '@/data/dto/analytics/channels';
    import { SumCampaignItem } from '@/data/dto/analytics/dashboard';
    import { DashboardService } from '@/data/service/DashboardService';
    import { getChannelTypeForSubcriptionType, getSubscriptionTypeSVGPath } from '@/product/analytics/util';
    import { asCompactNumber, asMoney, decimalToCents, formatDate } from '@/util';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';
    import MultiSortMenu from '@/components/analytics/posts/MultiSortMenu.vue';

    export interface Emits {
        (e: 'on-campaign-selected', selectedCampaign: SumCampaignItem): void;
    }

    interface Props {
        readonly channels: Channel[];
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    defineEmits<Emits>();
    const props = defineProps<Props>();
    const {channels, startDate, endDate} = toRefs(props);

    const {t} = useI18n();

    const {
        currentPage,
        pageLength,
        totalItems,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination(5);

    const campaigns = ref<SumCampaignItem[]>([]);
    const isLoading = ref(false);
    const orderBy = ref<string | null>('Date');
    const orderByDirection = ref<'ascending' | 'descending' | null>('descending');
    const orderByAscending = ref(false);

    const {getSumCampaignsPaginated} = useService(DashboardService);
    const currency = useCurrency();

    const toCurrency = (amount: number): string => {
        const currentCurrency = unref(currency);
        return asMoney(decimalToCents(amount, currentCurrency), currentCurrency);
    };

    function onSort(fieldName: string | null, direction: 'ascending' | 'descending' | null): void {
        orderBy.value = fieldName;
        orderByDirection.value = direction;
        orderByAscending.value = direction === 'ascending';
        setCurrentPage(1);
    }

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const response = await getSumCampaignsPaginated(unref(channels), unref(startDate), unref(endDate), unref(orderBy), unref(orderByAscending), unref(pageLength), unref(currentPage));
        campaigns.value = response.data.items;
        setTotalItems(response.data.totalItems);
        isLoading.value = false;
    }

    watch([channels, startDate, endDate, orderBy, orderByAscending, pageLength, currentPage], updateData, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .channel-icon {
        width: 51px;
        min-width: 51px;
        height: 51px;
        margin-right: 1rem;
    }

    .post-inner-stack {
        width: 100%;
        justify-content: space-evenly;
    }

    label {
        font-size: 14px;

        &.cell-title {
            white-space: nowrap;
        }
    }

    .flux-overlay .flux-pane.is-x-large {
        max-width: 1280px;
    }

    ::v-deep(.flux-table-cell).justify-content-center .flux-table-cell-content {
        justify-content: center;
    }

    ::v-deep(.flux-table-cell).align-items-center .flux-table-cell-content {
        align-items: center;
    }

    .open-overlay-button {
        transform: rotateY(180deg);
    }
</style>
