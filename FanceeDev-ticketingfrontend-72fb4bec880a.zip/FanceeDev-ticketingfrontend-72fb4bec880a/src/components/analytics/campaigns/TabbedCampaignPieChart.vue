<template>
    <FluxPane>
        <FluxTabs v-model="tabIndex">
            <FluxTab
                v-for="category in categories"
                :key="category.id"
                :label="category.label"/>
        </FluxTabs>

        <PieChart
            :series="series"
            :options="options"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { ApexOptions } from 'apexcharts';
    import { computed, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ChartCategory, ChartSeriesItem } from '@/data/interface/charts';
    import { SumCampaignAgeGenderItem } from '@/data/dto/analytics/dashboard/campaigns/SumCampaignAgeGenderItem';
    import PieChart from '@/components/analytics/cards/charts/PieChart.vue';

    interface Props {
        readonly items: SumCampaignAgeGenderItem[];
        readonly categories: ChartCategory[];
    }

    const props = defineProps<Props>();
    const {items, categories} = toRefs(props);

    const {t} = useI18n();

    const tabIndex = ref<number>(0);
    const options: ApexOptions = {
        legend: {
            position: 'right'
        }
    };

    const series = computed((): ChartSeriesItem => {
        const _categories = unref(categories)[unref(tabIndex)];

        return {
            name: _categories.label,
            data: unref(items).map(item => {
                let gender = item.gender ?? 'unknown';

                if (gender === 'undefined' || gender === 'other' || gender === 'undetermined') {
                    gender = 'unknown';
                }

                return {
                    x: t(`global.gender.${gender}`),
                    y: item[_categories.id]
                };
            }).sort((a, b) => b.y - a.y)
        };
    });
</script>
