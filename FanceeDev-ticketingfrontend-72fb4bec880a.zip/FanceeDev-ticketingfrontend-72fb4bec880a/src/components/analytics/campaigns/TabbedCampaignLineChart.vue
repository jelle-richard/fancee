<template>
    <FluxPane>
        <FluxTabs v-model="tabIndex">
            <FluxTab
                v-for="category in categories"
                :key="category.id"
                :label="category.label"/>
        </FluxTabs>
        <LineChart
            :series="series"
            :options="options"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { computed, ref, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { ChartCategory, ChartSeriesItem } from '@/data/interface/charts';
    import { SumCampaignItem } from '@/data/dto/analytics/dashboard';
    import LineChart from '@/components/analytics/cards/charts/LineChart.vue';

    interface Props {
        readonly items: SumCampaignItem[];
        readonly categories: ChartCategory[];
    }

    const props = defineProps<Props>();
    const {items, categories} = toRefs(props);

    const tabIndex = ref(0);

    const options: ApexOptions = {
        stroke: {
            show: true,
            width: 2
        }
    };

    const series = computed((): ChartSeriesItem[] => {
        const currentCategory = unref(categories)[unref(tabIndex)];
        return [{
            name: currentCategory.label,
            data: unref(items).map(item => ({x: item.date, y: item[currentCategory.id]}))
        }];
    });
</script>
