<template>
    <FluxPane v-if="campaign">
        <FluxPaneHeader>
            <FluxGrid>
                <FluxGridColumn :sm="3">
                    <img
                        class="campaign-icon"
                        :src="getSubscriptionTypeSVGPath(campaign.source)"
                        alt=""/>
                </FluxGridColumn>

                <FluxGridColumn :sm="3">
                    <FluxStack gap="0">
                        <b>{{ t('analytics.campaignInfo.title') }}</b>
                        <label>{{ campaign.name }}</label>
                    </FluxStack>

                    <FluxStack gap="0">
                        <b>{{ t('global.date') }}</b>
                        <label>{{ formatDate(campaign.startDate) }}</label>
                    </FluxStack>

                    <FluxBadge
                        class="justify-self-start"
                        :icon="campaign.status === 'enabled' ? 'circle-check' : 'circle-xmark'"
                        :color="campaign.status === 'enabled' ? 'success' : 'danger'"
                        :label="t(`analytics.${campaign.status}`)"/>
                </FluxGridColumn>

                <FluxGridColumn :sm="6">
                    <FluxStack :gap="3">
                        <b>{{ t('analytics.campaignInfo.budget') }}</b>
                        <label>{{ toCurrency(campaign.budget) }}</label>
                    </FluxStack>

                    <FluxStack :gap="3">
                        <b>{{ t('analytics.campaignInfo.spent') }}</b>
                        <label>{{ toCurrency(campaign.cost) }} ({{ (campaign.cost / campaign.budget * 100).toFixed(0) }}%)</label>
                    </FluxStack>

                    <FluxStack>
                        <FluxPercentageBar
                            is-legend-visible
                            :items="[
                            {color: 'rgb(var(--primary-7))', label: t('analytics.campaignInfo.spent'), value: campaign.cost / campaign.budget},
                            {color: 'rgb(var(--gray-4))', label: t('analytics.campaignInfo.remaining'), value: 1 - campaign.cost / campaign.budget}
                        ]"/>
                    </FluxStack>
                </FluxGridColumn>
            </FluxGrid>
        </FluxPaneHeader>

        <FluxPaneBody>
            <FluxStack>
                <SumCampaignContainer
                    v-if="campaign"
                    v-slot="campaignSlot"
                    :campaign-id="campaign.campaignId"
                    :channel-id="campaign.channelId"
                    :start-date="startDate"
                    :end-date="endDate">
                    <FluxGrid>
                        <FluxGridColumn :sm="6">
                            <TabbedCampaignLineChart
                                :items="campaignSlot.data"
                                :categories="[
                               {id: 'impressions', label:  t('analytics.campaignInfo.impressions')},
                               {id: 'clicks', label: t('analytics.campaignInfo.clicks')}
                            ]"/>
                        </FluxGridColumn>

                        <FluxGridColumn :sm="6">
                            <TabbedCampaignLineChart
                                :items="campaignSlot.data"
                                :categories="[
                               {id: 'conversion', label: t('analytics.campaignInfo.conversion')},
                               {id: 'cpc', label: t('analytics.campaignInfo.cpc')},
                               {id: 'ctr', label: t('analytics.campaignInfo.ctr')}
                            ]"/>
                        </FluxGridColumn>
                    </FluxGrid>
                </SumCampaignContainer>

                <FluxGrid>
                    <FluxGridColumn :sm="6">
                        <CampaignGenderContainer
                            v-if="campaign"
                            v-slot="campaignGenderSlot"
                            :campaign-id="campaign.campaignId"
                            :channel-id="campaign.channelId"
                            :start-date="startDate"
                            :end-date="endDate">
                            <TabbedCampaignPieChart
                                :items="campaignGenderSlot.data"
                                :categories="[
                                   {id: 'clicks', label: t('analytics.campaignInfo.genderClicks')}
                                ]"/>
                        </CampaignGenderContainer>
                    </FluxGridColumn>

                    <FluxGridColumn :sm="6">
                        <CampaignAgeContainer
                            v-if="campaign"
                            v-slot="campaignAgeSlot"
                            :campaign-id="campaign.campaignId"
                            :channel-id="campaign.channelId"
                            :start-date="startDate"
                            :end-date="endDate">
                            <TabbedCampaignBarChart
                                :items="campaignAgeSlot.data"
                                :categories="[
                                   {id: 'clicks', label: t('analytics.campaignInfo.ageClicks')}
                                ]"/>
                        </CampaignAgeContainer>
                    </FluxGridColumn>
                </FluxGrid>
            </FluxStack>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useCurrency, useService } from '@/composable';
    import { SumCampaignItem } from '@/data/dto/analytics/dashboard';
    import { DashboardService } from '@/data/service';
    import { getSubscriptionTypeSVGPath } from '@/product/analytics/util';
    import { asMoney, decimalToCents, formatDate } from '@/util';
    import CampaignAgeContainer from '@/components/analytics/data/campaigns/CampaignAgeContainer.vue';
    import CampaignGenderContainer from '@/components/analytics/data/campaigns/CampaignGenderContainer.vue';
    import SumCampaignContainer from '@/components/analytics/data/campaigns/SumCampaignContainer.vue';
    import TabbedCampaignBarChart from '@/components/analytics/campaigns/TabbedCampaignBarChart.vue';
    import TabbedCampaignLineChart from '@/components/analytics/campaigns/TabbedCampaignLineChart.vue';
    import TabbedCampaignPieChart from '@/components/analytics/campaigns/TabbedCampaignPieChart.vue';

    interface Props {
        readonly campaign: SumCampaignItem;
        readonly startDate: DateTime;
        readonly endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {campaign, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const currency = useCurrency();

    const isLoading = ref(false);
    const entries = ref<SumCampaignItem[]>([]);

    const {getSingleSumCampaign} = useService(DashboardService);

    const toCurrency = (amount: number): string => {
        const currentCurrency = unref(currency);
        return asMoney(decimalToCents(amount, currentCurrency), currentCurrency);
    };

    async function updateData(): Promise<void> {
        isLoading.value = true;
        const currentCampaign = unref(campaign);

        const result = await getSingleSumCampaign(currentCampaign.channelId, currentCampaign.campaignId, unref(startDate), unref(endDate));

        entries.value = result.data;
        isLoading.value = false;
    }

    watch([campaign, startDate, endDate], updateData, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .campaign-icon {
        height: 180px;
        justify-self: center;
    }

    .flux-grid {
        width: 100%;
    }

    .justify-self-start {
        justify-self: flex-start;
    }
</style>
