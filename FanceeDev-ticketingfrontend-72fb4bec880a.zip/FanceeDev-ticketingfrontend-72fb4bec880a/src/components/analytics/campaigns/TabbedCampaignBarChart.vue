<template>
    <FluxPane>
        <FluxTabs v-model="tabIndex">
            <FluxTab
                v-for="category in categories"
                :key="category.id"
                :label="category.label"/>
        </FluxTabs>
        <BarChart
            :series="series"
            :options="options"/>
    </FluxPane>
</template>

<script
    setup
    lang="ts">
    import { computed, ref, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { ANALYTICS_CHART_COLOR, CHART_FONT_FAMILY } from '@/data';
    import { ChartCategory } from '@/data/interface/charts';
    import { SumCampaignAgeGenderItem } from '@/data/dto/analytics/dashboard/campaigns/SumCampaignAgeGenderItem';
    import BarChart from '@/components/analytics/cards/charts/BarChart.vue';

    interface Props {
        readonly items: SumCampaignAgeGenderItem[];
        readonly categories: ChartCategory[];
    }

    const props = defineProps<Props>();
    const {items, categories} = toRefs(props);

    const tabIndex = ref(0);

    const options: ApexOptions = {
        legend: {
            position: 'right',
            fontFamily: CHART_FONT_FAMILY,
            fontSize: '20px'
        },
        fill: {
            opacity: 1
        }
    };

    const series = computed((): ApexAxisChartSeries => {
        const currentCategory = unref(categories)[unref(tabIndex)];
        const currentItems = unref(items);
        return [{
            name: currentCategory.label,
            data: currentItems.map(item => ({x: item.age ?? '', y: item[currentCategory.id]})),
            color: ANALYTICS_CHART_COLOR
        }];
    });
</script>
