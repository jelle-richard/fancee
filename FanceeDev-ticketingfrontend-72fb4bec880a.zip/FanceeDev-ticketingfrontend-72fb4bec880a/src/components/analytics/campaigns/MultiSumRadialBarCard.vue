<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="title">
            <FluxLink
                v-if="headerLink"
                class="full-overview-link"
                :label="headerLink.label"
                :to="headerLink.value"
                type="route"/>
        </FluxPaneHeader>
        <span class="chart-info">
            <span class="chart-info-title">
               {{ t('analytics.spent.budget') }}
            </span>

            <span class="chart-info-value">
                 {{ asMoney(decimalToCents(budget ?? 0, currency), currency) }}
            </span>
        </span>
        <ApexChart
            v-if="chartSeries"
            type="radialBar"
            width="100%"
            :series="chartSeries"
            :options="chartOptions"/>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { computed, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { RouteLocationRaw } from 'vue-router';
    import { useCurrency } from '@/composable';
    import { asMoney, decimalToCents } from '@/util';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        readonly title: string;
        readonly isLoading: boolean;
        readonly headerLink?: { label: string, value?: RouteLocationRaw | string | number } | null;
        readonly budget: number | null;
        readonly spent: number | null;
    }

    const props = defineProps<Props>();
    const {budget, spent} = toRefs(props);

    const {t} = useI18n();

    const chartOptions = computed((): ApexOptions => ({
        chart: {
            type: 'radialBar',
            height: '230px',
        },
        offsetY: -20,
        colors: ['#9fa0a6'],
        fill: {
            colors: [unref(activeColor)]
        },
        tooltip: {
            enabled: true,
            shared: false,
            fillSeriesColor: false,
            y: {
                formatter: tooltipFormatter
            }
        },
        plotOptions: {
            radialBar: {
                offsetY: -20,
                startAngle: -105,
                endAngle: 105,
                hollow: {
                    margin: 20,
                    size: '70%'
                },
                track: {
                    show: true,
                    background: '#9fa0a6',
                    strokeWidth: '100%',
                    opacity: 1
                },
                dataLabels: {
                    show: false
                }
            }
        },
        stroke: {
            lineCap: 'round'
        },
        labels: [t('analytics.spent.cost')]
    }) as ApexOptions);

    const currency = useCurrency();

    const chartSeries = computed((): number[] => {
        const _spent = unref(spent) ?? 0;
        const _budget = unref(budget) ?? 0;

        if (_spent > 0 && _budget > 0) {
            return [(_spent / _budget) * 100];
        }

        return [0];
    });

    const activeColor = computed((): string => (unref(spent) ?? 0) > (unref(budget) ?? 0) ? '#b3261e' : '#5f72b5');

    function tooltipFormatter(val: number, opts?: any): string {
        const _currency = unref(currency);
        return asMoney(decimalToCents(unref(spent) ?? 0, _currency), _currency);
    }
</script>

<style
    lang="scss"
    scoped>
    .chart-info {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;

        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        margin-top: 10px;
        min-height: 210px;
        pointer-events: none;

        .chart-info-title {
            color: #9fa0a6;
            font-family: manrope-variable, sans-serif;
            font-weight: 700;
        }

        .chart-info-value {
            color: #1f2024;
            font-family: manrope-variable, sans-serif;
            font-weight: 700;
            font-size: 20px;
        }
    }

    ::v-deep(.full-overview-link) {
        font-size: 12px;
        gap: 0.25rem;
        text-decoration: none;

        svg {
            font-size: 12px;
        }
    }
</style>
