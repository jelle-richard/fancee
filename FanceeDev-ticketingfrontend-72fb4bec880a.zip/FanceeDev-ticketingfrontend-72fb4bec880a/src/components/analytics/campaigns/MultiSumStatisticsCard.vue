<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="title">
            <FluxLink
                v-if="headerLink"
                class="full-overview-link"
                :label="headerLink.label"
                :to="headerLink.value"
                type="route"/>
        </FluxPaneHeader>
        <FluxPaneBody>
            <FluxStack
                gap="0"
                axis="horizontal">
                <FluxStatistic
                    v-for="item in items"
                    :key="item.label"
                    :class="`items-${alignItems} text-${alignText}`"
                    axis="vertical"
                    icon="diagram-project"
                    color="primary"
                    :label="item.label"
                    :value="item.value"/>
            </FluxStack>
            <slot/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import type { RouteLocationRaw } from 'vue-router';

    export interface Props {
        readonly title: string;
        readonly isLoading: boolean;
        readonly headerLink?: { label: string, value?: RouteLocationRaw | string | number } | null;
        readonly items: { label: string, value?: string | number }[];
        readonly alignItems?: 'left' | 'center' | 'right';
        readonly alignText?: 'left' | 'center' | 'right';
    }

    withDefaults(defineProps<Props>(), {
        alignItems: 'center',
        alignText: 'center'
    });
</script>

<style
    lang="scss"
    scoped>
    .flux-pane {
        display: flex;
        flex-direction: column;

        .flux-pane-body {
            flex: 1;
        }
    }

    .flux-statistic {
        flex: 1;
        border: 0;
        box-shadow: none;
        padding: 0;
    }

    .flux-stack {
        justify-content: center;
    }

    ::v-deep(.full-overview-link) {
        font-size: 12px;
        gap: 0.25rem;
        text-decoration: none;

        svg {
            font-size: 12px;
        }
    }

    ::v-deep(.flux-statistic-icon) {
        display: none;
    }

    ::v-deep(.flux-statistic-data) {
        justify-content: center;
    }

    ::v-deep(.flux-statistic).items-left {
        align-items: flex-start;
    }

    ::v-deep(.flux-statistic).items-center {
        align-items: center;
    }

    ::v-deep(.flux-statistic).items-right {
        align-items: flex-end;
    }

    ::v-deep(.text-left) .flux-statistic-data {
        align-items: flex-start;
    }

    ::v-deep(.text-center) .flux-statistic-data {
        align-items: center;
    }

    ::v-deep(.text-right) .flux-statistic-data {
        align-items: flex-end;
    }
</style>
