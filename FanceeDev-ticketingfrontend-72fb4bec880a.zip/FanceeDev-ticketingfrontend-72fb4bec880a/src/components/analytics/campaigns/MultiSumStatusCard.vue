<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader :title="title">
            <FluxLink
                v-if="headerLink"
                class="full-overview-link"
                :label="headerLink.label"
                :to="headerLink.value"
                type="route"/>
        </FluxPaneHeader>

        <FluxPaneBody>
            <FluxDataTable
                v-if="items"
                :data-set="items"
                :total="items.length"
                :is-bordered="false"
                :is-separated="false">
                <template #name="{row: {color, label}}">
                    <FluxTableCell>
                        <FluxStack
                            class="status-label"
                            axis="horizontal"
                            gap="3">
                            <div :class="`circle is-${color}`"/>
                            <span>{{ label }}</span>
                        </FluxStack>
                    </FluxTableCell>
                </template>

                <template #value="{row: {value}}">
                    <FluxTableCell class="status-value">
                        <strong>{{ value }}</strong>
                    </FluxTableCell>
                </template>
            </FluxDataTable>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import type { RouteLocationRaw } from 'vue-router';

    export interface Props {
        readonly title: string | null;
        readonly isLoading: boolean;
        readonly headerLink?: {
            readonly label: string;
            readonly value?: RouteLocationRaw | string | number
        } | null;
        readonly items: {
            readonly label: string;
            readonly value?: string | number;
            readonly color?: 'primary' | 'danger' | 'info' | 'success' | 'warning';
        }[];
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .circle {
        width: 15px;
        height: 15px;
        border-radius: 50%;
        margin-right: 1rem;

        &.is-primary {
            background-color: rgb(var(--primary-7));
        }

        &.is-danger {
            background-color: rgb(var(--danger-7));
        }

        &.is-info {
            background-color: rgb(var(--info-7));
        }

        &.is-success {
            background-color: rgb(var(--success-7));
        }

        &.is-warning {
            background-color: rgb(var(--warning-7));
        }
    }

    .status-label {
        --color: var(--foreground-secondary);
        height: 100%;
        flex: 1;
        align-items: center;
    }

    .status-value {
        --color: var(--foreground-prominent);

        font-size: 24px;
        font-weight: 700;

        strong {
            color: var(--color);
        }
    }

    .flux-pane {
        display: inline-flex;
        flex-direction: column;

        .flux-pane-body {
            flex: 1;
            justify-content: center;
        }
    }

    ::v-deep(.full-overview-link) {
        font-size: 12px;
        gap: 0.25rem;
        text-decoration: none;

        svg {
            font-size: 12px;
        }
    }

    ::v-deep(.flux-table-cell-content) {
        padding-top: 0;
        padding-bottom: 0;
    }
</style>
