<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="title"
            :sub-title="subtitle"/>

        <FluxPaneBody class="chart-container">
            <NoDashboardData
                v-if="!isLoading && chartData.length === 0"
                variation="full"/>

            <ApexChart
                v-else
                width="100%"
                height="330"
                :series="chartData"
                :options="options"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref, watch } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { CHART_COLOR_ARRAY } from '@/data';
    import ApexChart from 'vue3-apexcharts';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export interface Props {
        isLoading: boolean;
        title?: string;
        subtitle?: string;
        chartData: number[];
        chartOptions?: ApexOptions;
        chartCategories: string[];
    }

    const props = defineProps<Props>();
    const {chartCategories, chartOptions} = toRefs(props);

    const options = ref<ApexOptions>({
        chart: {
            type: 'pie',
            animations: {
                enabled: false
            },
            selection: {
                enabled: false
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            show: false
        },
        colors: CHART_COLOR_ARRAY,
        legend: {
            show: true,
            position: 'bottom'
        }
    });

    async function updateOptions(): Promise<void> {
        options.value = {
            ...unref(options),
            ...unref(chartOptions),
            ...{
                labels: unref(chartCategories)
            }
        };
    }

    watch([chartOptions, chartCategories], updateOptions, {immediate: true, deep: true});
</script>

<style
    lang="scss"
    scoped>
    .chart-container {
        height: 330px;
        min-height: 330px;
    }
</style>
