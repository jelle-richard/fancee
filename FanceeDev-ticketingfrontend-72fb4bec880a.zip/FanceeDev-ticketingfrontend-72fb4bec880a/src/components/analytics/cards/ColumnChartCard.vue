<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="title"
            :sub-title="subtitle">
            <FluxSecondaryButton
                :label="t('global.download')"
                icon-before="arrow-down-to-line"
                :is-loading="isDownloading"
                @click="onClick()"/>
        </FluxPaneHeader>

        <FluxPaneBody class="bar-chart-container">
            <NoDashboardData
                v-if="!isLoading && chartData.length === 0"
                variation="full"/>

            <ApexChart
                :height="height"
                :series="chartData"
                :options="chartOptions"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { toRefs } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { useI18n } from 'vue-i18n';
    import ApexChart from 'vue3-apexcharts';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    const {t} = useI18n();

    export interface Emits {
        (e: 'download'): void;
    }

    export interface Props {
        readonly isLoading: boolean;
        readonly isDownloading?: boolean;
        readonly title?: string;
        readonly subtitle?: string;
        readonly chartData: ApexAxisChartSeries[];
        readonly chartOptions?: ApexOptions;
        readonly height?: number;
    }

    const emit = defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        isLoading: false,
        height: 290
    });
    const {chartData, chartOptions} = toRefs(props);

    function onClick(): void {
        emit('download');
    }
</script>

<style
    lang="scss"
    scoped>
    .bar-chart-container {
        min-height: 330px;

        * {
            transition: none !important;
        }
    }
</style>
