<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="title"
            :sub-title="subtitle"/>

        <FluxPaneBody>
            <NoDashboardData
                v-if="!isLoading && (chartData.length === 0 || chartData[0].data.length === 0)"
                variation="full"/>

            <BarChart
                v-else
                :key="Math.random()"
                :height="height"
                :series="series"
                :options="options"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { computed, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { CHART_COLOR_ARRAY } from '@/data';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';
    import BarChart from '@/components/analytics/cards/charts/BarChart.vue';

    export interface Props {
        readonly isLoading: boolean;
        readonly title?: string;
        readonly subtitle?: string;
        readonly chartData: ApexAxisChartSeries;
        readonly chartOptions?: ApexOptions;
        readonly chartCategories?: string[];
        readonly height?: number;
    }

    const props = withDefaults(defineProps<Props>(), {
        isLoading: false,
        height: 290
    });
    const {chartData, chartOptions, chartCategories} = toRefs(props);

    const options: ApexOptions = {
        ...{
            colors: CHART_COLOR_ARRAY,
            toolbar: {
                show: true
            }
        },
        ...unref(chartOptions)
    };

    const series = computed((): ApexAxisChartSeries => {
        const _chartData = unref(chartData);
        const _chartCategories = unref(chartCategories);

        if (_chartData.length === 0) {
            return [];
        }

        if (!!_chartCategories && _chartData[0].data.length === _chartCategories.length) {
            return [{
                name: _chartData[0].name,
                data: _chartCategories.map((category, index) => ({x: category, y: _chartData[0].data[index]}))
            }];
        }

        return _chartData;
    });
</script>
