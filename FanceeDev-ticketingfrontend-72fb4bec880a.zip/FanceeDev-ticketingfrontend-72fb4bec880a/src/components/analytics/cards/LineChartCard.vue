<template>
    <FluxStack>
        <FluxActionBar>
            <template #search>
                <FluxFormSelect
                    v-model="splitSelection"
                    is-multiple
                    :options="splitOptions"
                    :placeholder="t('analytics.splitOn')"/>

                <FluxFormSelect
                    v-model="fieldSelection"
                    :options="fieldOptions"
                    :placeholder="t('analytics.selectField')"/>
            </template>
        </FluxActionBar>

        <ApexChart
            type="line"
            height="300"
            width="100%"
            :options="chartOptions"
            :series="chartSeries"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ApexOptions } from 'apexcharts';
    import { GenericEntry } from '@/data/dto/analytics/subscriptions';
    import { ChartDataItem, ChartSeriesItem, DateAndEntries, Option } from '@/data/interface/charts';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        entries: GenericEntry[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {entries, startDate, endDate} = toRefs(props);

    const {t} = useI18n();

    const splitSelection = ref<string[]>([]);
    const fieldSelection = ref<string | null>(null);
    const isLoading = ref(false);
    const chartOptions = ref<ApexOptions>({
        chart: {
            type: 'line',
            stacked: false,
            animations: {
                enabled: true
            },
            events: {}
        },
        xaxis: {
            type: 'datetime'
        },
        colors: ['#2e93fa', '#66da26', '#ec620e', '#6f1ee9', '#ff9800', '#e91e63', '#1ee9ba'],
        legend: {
            show: true,
            position: 'bottom',
            showForSingleSeries: true,
            showForNullSeries: true,
            showForZeroSeries: true
        },
        tooltip: {
            enabled: true,
            shared: true,
            y: {
                formatter: function (val) {
                    return val?.toString() ?? '-';
                }
            }
        },
        stroke: {
            curve: 'smooth'
        },
        markers: {
            showNullDataPoints: false
        }
    });

    const fieldOptions = computed((): Option[] => {
        const currentEntries = unref(entries);

        if (currentEntries.length === 0) {
            return [];
        }

        const entryData = currentEntries[0].data;
        const listOfNumberFields = Object.keys(entryData).filter(p => typeof (entryData[p]) !== 'string');
        const newFieldsList = listOfNumberFields.map((e) => ({
            id: e,
            label: e
        }));
        const currentFieldSelection = unref(fieldSelection);

        if (!!currentFieldSelection && !listOfNumberFields.includes(currentFieldSelection)) {
            fieldSelection.value = newFieldsList[0].id;
        }

        return newFieldsList;
    });

    const splitOptions = computed((): Option[] => {
        const currentEntries = unref(entries);

        if (currentEntries.length === 0) {
            return [];
        }

        const entryData = currentEntries[0].data;
        const listOfStringFields = Object.keys(entryData).filter(p => typeof (entryData[p]) !== 'number');

        return listOfStringFields.map((e) => ({
            id: e,
            label: e
        }));
    });

    // Gets the group name, used to group entries together as a separate line.
    const groupName = (entry: GenericEntry): string => {
        const itemsToSplit = unref(splitSelection);

        if (itemsToSplit.length === 0) {
            return unref(fieldSelection) ?? '';
        }

        return itemsToSplit.map(item => entry.data[item]).join(' - ');
    };

    const filteredEntriesByDate = computed((): GenericEntry[] => unref(entries).filter(entry => typeof (entry.data[unref(fieldSelection)!]) === 'number'));

    const chartSeries = computed((): ChartSeriesItem[] => {
        let newChartSeries: ChartSeriesItem[] = [];
        const filteredEntries: GenericEntry[] = unref(filteredEntriesByDate);
        const entriesByDate: DateAndEntries[] = dateAndEntriesArray(filteredEntries);

        getGroupNames(filteredEntries).forEach(columnGroupName => {
            newChartSeries.push(buildSingleChartSeries(columnGroupName, entriesByDate));
        });

        return newChartSeries;
    });

    const getGroupNames = (entries: GenericEntry[]): string[] => [...new Set(entries.map(entry => groupName(entry)))];

    const dateAndEntriesArray = (entries: GenericEntry[]): DateAndEntries[] => entries.reduce(function (responseArray: DateAndEntries[], entry: GenericEntry) {
        let itemInArray = responseArray.find(i => i.date === entry.query.date);

        if (!itemInArray) {
            itemInArray = {date: entry.query.date, entries: []};
            responseArray.push(itemInArray);
        }

        itemInArray.entries.push(entry);

        return responseArray;
    }, []);

    const buildSingleChartSeries = (columnGroupName: string, entriesByDate: DateAndEntries[]): ChartSeriesItem => {
        let newChartSeries: ChartSeriesItem = {
            name: columnGroupName,
            data: []
        };

        for (const dateAndEntries of entriesByDate) {
            const newX = new Date(dateAndEntries.date).setUTCHours(0, 0, 0, 0);
            const groupEntries: GenericEntry[] = dateAndEntries.entries.filter(entry => groupName(entry) === columnGroupName);

            let seriesData: ChartDataItem = {
                x: newX,
                y: undefined
            };

            if (!!unref(fieldSelection)) {
                groupEntries.forEach(entryValue => {
                    if (!seriesData.y) {
                        seriesData.y = entryValue.data[unref(fieldSelection)!];
                    } else {
                        seriesData.y += entryValue.data[unref(fieldSelection)!];
                    }
                });
            }

            newChartSeries.data.push(seriesData);
        }

        addStartAndEndDate(newChartSeries.data);

        return newChartSeries;
    };

    // Adds startDate and endDate to array of a chart series.
    const addStartAndEndDate = (chartSeriesData: ChartDataItem[]) => {
        chartSeriesData.push({
            x: unref(startDate)?.toJSDate().setUTCHours(0, 0, 0, 0) ?? 0,
            y: undefined
        });
        chartSeriesData.push({
            x: unref(endDate)?.toJSDate().setUTCHours(0, 0, 0, 0) ?? 0,
            y: undefined
        });
    };
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-form-select) > .flux-menu-item {
        display: contents;
    }
</style>
