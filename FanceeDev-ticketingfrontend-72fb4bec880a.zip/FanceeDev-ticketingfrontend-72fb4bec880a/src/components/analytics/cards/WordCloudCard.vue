<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneHeader
            :title="title"
            :sub-title="subtitle"/>
        <FluxPaneBody class="word-cloud-container">
            <NoDashboardData
                v-if="!isLoading && chartData.length === 0"
                variation="full"/>
            <VueWordCloud
                v-else-if="chartData.length > 0"
                :words="KeywordAdapter.toChartItems(chartData, color ?? null, false)"
                :font-size-ratio="0.5"
                :animation-duration="2"
                :spacing="1"
                :animation-overlap="1"
                enter-animation="animated flipY"
                leave-animation="animated flipX"/>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { Keyword } from '@/data/dto/analytics/posts';
    import { KeywordAdapter } from '@/data/adapter/analytics/posts/KeywordAdapter';
    import VueWordCloud from 'vuewordcloud';
    import NoDashboardData from '@/components/analytics/dashboard/NoDashboardData.vue';

    export interface Props {
        isLoading: boolean;
        title?: string;
        subtitle?: string;
        chartData: Keyword[];
        color?: string;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .word-cloud-container {
        height: 330px;
        min-height: 330px;

        span {
            font-family: manrope-variable, sans-serif !important;
        }
    }
</style>
