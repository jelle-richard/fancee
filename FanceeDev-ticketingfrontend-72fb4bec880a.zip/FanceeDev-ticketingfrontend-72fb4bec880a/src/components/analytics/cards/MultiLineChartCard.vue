<template>
    <FluxStack>
        <FluxActionBar>
            <template #search>
                <FluxFormField
                    v-for="item of fieldOptions"
                    :key="item.id"
                    :label="item.label">
                    <FluxFormInputGroup :is-disabled="item.options.length === 0">
                        <FluxFormInputAddition
                            :class="`subscription-type-${item.subscriptionType.split('_')[0].toLowerCase()}`"
                            :icon="getSubscriptionTypeIcon(item.subscriptionType)"/>

                        <FluxFormSelect
                            v-model="item.selected"
                            :options="item.options"
                            :placeholder="t('analytics.selectField')"/>
                    </FluxFormInputGroup>
                </FluxFormField>
            </template>
        </FluxActionBar>

        <ApexChart
            type="line"
            height="600"
            width="100%"
            :options="chartOptions"
            :series="chartSeries"/>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { DateTime } from 'luxon';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CHART_COLOR_ARRAY } from '@/data';
    import { GenericEntry, Subscription } from '@/data/dto/analytics/subscriptions';
    import { SubscriptionField } from '@/data/dto/analytics/subscriptions/SubscriptionField';
    import { ChartDataItem, ChartSeriesItem, DateAndEntries, Option, SplitItem } from '@/data/interface/charts';
    import { getSubscriptionTypeIcon } from '@/product/analytics/util';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        subscriptions: Subscription[];
        startDate: DateTime;
        endDate: DateTime;
    }

    const props = defineProps<Props>();
    const {subscriptions, startDate, endDate} = toRefs(props);

    const {t} = useI18n();
    const colors = CHART_COLOR_ARRAY;

    const fieldOptions = ref<SplitItem[]>([]);
    const chartOptions = computed((): ApexOptions => ({
        chart: {
            type: 'line',
            stacked: false,
            animations: {
                enabled: false
            },
            events: {}
        },
        xaxis: {
            type: 'datetime'
        },
        yaxis: unref(chartYAxis),
        colors: colors,
        legend: {
            show: true,
            position: 'bottom',
            showForSingleSeries: true,
            showForNullSeries: true,
            showForZeroSeries: true
        },
        tooltip: {
            enabled: true,
            shared: true,
            y: {
                formatter: function (val) {
                    return val?.toString() ?? '-';
                }
            }
        },
        stroke: {
            curve: 'smooth'
        },
        markers: {
            showNullDataPoints: false
        }
    }));

    const setupFieldOption = (subscription: Subscription): SplitItem => {
        let listOfNumberFields: SubscriptionField[];

        if (!!subscription.fields) {
            listOfNumberFields = subscription.fields.filter(field => !field.fieldType?.startsWith('string'));
        } else {
            const entryData = subscription.entries.length > 0 ? subscription.entries[0].data : {};
            listOfNumberFields = Object.keys(entryData).filter(p => typeof (entryData[p]) !== 'string').map<SubscriptionField>(e => new SubscriptionField(e, e, 'number'));
        }

        return {
            id: `${subscription.id}_options`,
            label: subscription.name ?? subscription.id,
            options: listOfNumberFields.length === 0 ? [] : [
                {
                    id: null,
                    label: t('analytics.selectField')
                },
                ...listOfNumberFields.map<Option>(field => ({
                    id: field.fieldId,
                    label: field.fieldName
                }))
            ],
            subscriptionId: subscription.id,
            subscriptionType: subscription.type,
            selected: null
        };
    };

    const buildFieldOptions = () => {
        fieldOptions.value = unref(subscriptions).map(subscription => setupFieldOption(subscription));
    };

    const chartSeries = computed((): ChartSeriesItem[] => {
        let newChartSeries: ChartSeriesItem[] = [];
        const currentSubscriptions = unref(subscriptions);
        const currentFieldOptions = unref(fieldOptions);

        currentFieldOptions.forEach(item => {
            const subscription = currentSubscriptions.find(subscription => subscription.id === item.subscriptionId) ?? null;
            const selectedItem = item.selected;

            if (!subscription || !selectedItem) {
                return;
            }

            const filteredEntries: GenericEntry[] = subscription.entries.filter(entry => typeof (entry.data[selectedItem]) === 'number');
            const entriesByDate: DateAndEntries[] = dateAndEntriesArray(filteredEntries);

            const fieldName = subscription.fields ? subscription.fields.find(e => e.fieldId === selectedItem)?.fieldName : item.selected;
            const chartName = `${subscription.name} - ${fieldName}`;

            newChartSeries.push(buildSingleChartSeries(chartName, entriesByDate, selectedItem));
        });

        return newChartSeries;
    });

    const chartYAxis = computed((): ApexYAxis[] => {
        let newChartYAxis: ApexYAxis[] = [];
        let oppositeRender: boolean = false;

        unref(chartSeries).forEach((series, index) => {
            const chartYMin: number = Math.min(...series.data.map(o => o.y ?? 0) as number[]);
            const chartYMax: number = Math.max(...series.data.map(o => o.y ?? 0) as number[]);
            const chartDiff = Math.abs(chartYMax - chartYMin) * 0.10;

            newChartYAxis.push({
                seriesName: series.name,
                opposite: oppositeRender,
                forceNiceScale: true,
                min: Math.round(Math.max(0, chartYMin - chartDiff)),
                max: Math.round(chartYMax + chartDiff),
                axisBorder: {
                    show: true,
                    color: colors[index]
                },
                labels: {
                    style: {
                        colors: colors[index]
                    }
                },
                title: {
                    text: series.name,
                    style: {
                        color: colors[index]
                    }
                }
            });
            oppositeRender = !oppositeRender;
        });

        return newChartYAxis;
    });

    const dateAndEntriesArray = (entries: GenericEntry[]): DateAndEntries[] => entries.reduce((responseArray: DateAndEntries[], entry: GenericEntry) => {
        let itemInArray = responseArray.find(i => i.date === entry.query.date);

        if (!itemInArray) {
            itemInArray = {date: entry.query.date, entries: []};
            responseArray.push(itemInArray);
        }

        itemInArray.entries.push(entry);

        return responseArray;
    }, []);

    const createDateSlots = (start: DateTime, end: DateTime): ChartDataItem[] => {
        let newArr: ChartDataItem[] = [];
        let dt = start.set({hour: 0, minute: 0, second: 0, millisecond: 0});
        for (; dt <= end; dt = dt.plus({days: 1})) {
            newArr.push({
                x: dt.toUnixInteger(),
                y: null,
                text: dt.toString()
            });
        }
        return newArr;
    };

    const buildSingleChartSeries = (columnGroupName: string, entriesByDate: DateAndEntries[], fieldSelection: string): ChartSeriesItem => {
        let newChartSeries: ChartSeriesItem = {
            name: columnGroupName,
            data: createDateSlots(unref(startDate), unref(endDate))
        };

        for (const dateAndEntries of entriesByDate) {
            const newX = DateTime.fromISO(dateAndEntries.date).set({hour: 0, minute: 0, second: 0, millisecond: 0}).toUnixInteger();
            const groupEntries: GenericEntry[] = dateAndEntries.entries;

            let seriesData: ChartDataItem | null = newChartSeries.data.find((c) => c.x === newX) ?? null;

            if (!seriesData) {
                seriesData = {
                    x: newX,
                    y: null,
                    text: dateAndEntries.date
                };
                newChartSeries.data.push(seriesData);
            }

            groupEntries.forEach(entryValue => {
                if (!seriesData!.y) {
                    seriesData!.y = entryValue.data[fieldSelection];
                } else {
                    seriesData!.y += entryValue.data[fieldSelection];
                }
            });
        }

        return newChartSeries;
    };

    watch(subscriptions, buildFieldOptions, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    ::v-deep(.flux-form-select) > .flux-menu-item {
        display: contents;
    }

    ::v-deep(.flux-action-bar) > .flux-form-field {
        flex-grow: 0;

        .flux-form-input {
            white-space: nowrap;
            max-width: none;

            &.flux-form-select {
                flex: 0;
            }

            &[is-disabled=true] {
                outline: none;
                cursor: auto;

                > .flux-form-input {
                    background: var(--gray-4);
                    cursor: auto;
                }
            }

            .flux-form-select-popup {
                width: auto;
            }
        }

        .flux-form-field-label {
            white-space: nowrap;
            padding-right: 2rem;
        }

        .subscription-type-fb {
            color: #4267b2;
        }

        .subscription-type-igi {
            color: #d62976;
        }

        .subscription-type-ga,
        .subscription-type-gawa {
            color: orange;
        }

        .subscription-type-yt {
            color: red;
        }
    }
</style>
