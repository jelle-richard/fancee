<template>
    <ApexChart
        v-if="series"
        height="500"
        width="100%"
        :options="chartOptions"
        :series="series"/>
</template>

<script
    lang="ts"
    setup>
    import { computed, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { ChartSeriesItem } from '@/data/interface/charts';
    import ApexChart from 'vue3-apexcharts';
    import { CHART_COMPARE_COLOR_ARRAY } from '@/data';
    import deepMerge from '@/util/deepMerge';

    export interface Props {
        series: ChartSeriesItem[];
        options?: ApexOptions;
    }

    const props = defineProps<Props>();
    const {series, options, categories} = toRefs(props);

    const chartOptions = computed((): ApexOptions => deepMerge(
        {
            chart: {
                type: 'rangeBar',
                animations: {
                    enabled: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: true
                }
            },

            tooltip: {
                enabled: true,
                shared: false,
                followCursor: false,
                intersect: false,
                x: {
                    formatter(val: number, opts?: any): string {
                        return `${val}`;
                    }
                },
                y: {
                    formatter: function (val) {
                        return `${('00' + val).slice(-2)}:00`;
                    }
                }
            },
            xaxis: {
                type: 'category',
                min: 0,
                max: 24,
                labels: {
                    showDuplicates: false
                    // formatter(value: string, timestamp?: number, opts?: any): string | string[] {
                    // }
                }
            },
            yaxis: {
                min: 0,
                max: 24
            },
            colors: CHART_COMPARE_COLOR_ARRAY,
            legend: {
                show: true,
                position: 'bottom',
                showForSingleSeries: true,
                showForNullSeries: true,
                showForZeroSeries: true
            }
        } as ApexOptions,
        unref(options)
    ));
</script>
