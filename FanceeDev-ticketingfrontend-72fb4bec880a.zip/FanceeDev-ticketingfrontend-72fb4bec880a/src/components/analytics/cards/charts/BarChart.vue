<template>
    <ApexChart
        width="100%"
        height="300"
        :series="series"
        :options="chartOptions"/>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { CHART_FONT_FAMILY } from '@/data';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        series: ApexAxisChartSeries;
        options?: ApexOptions | null;
    }

    const props = withDefaults(defineProps<Props>(), {
        options: null
    });

    const {series, options} = toRefs(props);

    const chartOptions = ref<ApexOptions>({
        ...{
            grid: {
                show: true,
                padding: {
                    left: 0,
                    right: 0
                }
            },
            chart: {
                type: 'bar',
                toolbar: {
                    show: false
                },
                selection: {
                    enabled: false,
                    fill: {
                        opacity: 1
                    }
                },
                sparkline: {
                    enabled: false
                },
                animations: {
                    enabled: false
                },
                fontFamily: CHART_FONT_FAMILY
            },
            plotOptions: {
                bar: {
                    borderRadius: 5,
                    borderRadiusApplication: 'end',
                    colors: {
                        backgroundBarOpacity: 1
                    }
                }
            },
            dataLabels: {
                enabled: false,
                formatter: function (val) {
                    if (Array.isArray(val) || val === 0 || val === '0') {
                        return '';
                    }

                    return val;
                },
                style: {
                    fontFamily: CHART_FONT_FAMILY,
                    colors: ['#ffffff']
                },
                dropShadow: {
                    enabled: true,
                    top: 1,
                    left: 1,
                    color: '#000',
                    opacity: 0.5
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                intersect: false,
                style: {
                    fontFamily: CHART_FONT_FAMILY
                }
            }
        },
        ...unref(options)
    });
</script>
