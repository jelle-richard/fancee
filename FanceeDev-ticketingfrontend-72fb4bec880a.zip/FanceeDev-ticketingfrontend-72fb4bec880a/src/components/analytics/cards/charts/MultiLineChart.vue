<template>
    <ApexChart
        v-if="!isLoading"
        :type="isScatter ? 'scatter' : 'line'"
        height="300"
        width="100%"
        :options="chartOptions"
        :series="chartSeries"/>
</template>

<script
    lang="ts"
    setup>
    import ApexChart from 'vue3-apexcharts';
    import { computed, ref, toRefs, unref } from 'vue';
    import { DateTime } from 'luxon';
    import { ChartDataItem, ChartSeriesItem } from '@/data/interface/charts';
    import { CHART_TICK_DAY_LIMIT, CHART_TICK_DEFAULT_START, CHART_TICK_MONTH_LIMIT, CHART_TICK_WEEK_LIMIT, LUXON_DATE_FORMAT, RAINBOW_COLORS } from '@/data';
    import { ApexOptions } from 'apexcharts';
    import apexChartsSharedTooltip from '@/util/apexChartsSharedTooltip';
    import apexTimestamp from '@/util/apexTimestamp';

    export interface Props {
        series: ChartSeriesItem[];
        startDate: DateTime;
        endDate: DateTime;
        isLoading: boolean;
        isScatter?: boolean;
    }

    const props = withDefaults(defineProps<Props>(), {
        isScatter: false
    });
    const {series, startDate, endDate, isScatter} = toRefs(props);

    const chartOptions = ref<ApexOptions | null>(null);

    const tickAmount = computed(() => {
        const amountOfDays = unref(endDate).diff(unref(startDate), ['days']).days;

        if (amountOfDays > CHART_TICK_WEEK_LIMIT) {
            return CHART_TICK_WEEK_LIMIT - CHART_TICK_DEFAULT_START;
        }

        if (amountOfDays > CHART_TICK_DAY_LIMIT) {
            return CHART_TICK_MONTH_LIMIT - CHART_TICK_DEFAULT_START;
        }

        return unref(series)[0].data.length - CHART_TICK_DEFAULT_START;
    });

    const chartSeries = computed((): ChartSeriesItem[] => {
        let newChartSeries: ChartSeriesItem[] = [];
        const _propSeries = unref(series);

        if (_propSeries.length === 0) {
            return [];
        }

        _propSeries.forEach(propSeriesItem => {
            let newChart: ChartSeriesItem = {
                name: propSeriesItem.name,
                data: []
            };

            newChart.data = propSeriesItem.data.filter(item => typeof item.y === 'number').map(item => ({x: apexTimestamp(item.x), y: item.y ?? null})).reduce((acc: ChartDataItem[], item) => {
                const itemInAcc = acc.find(i => i.x === item.x);

                if (!itemInAcc) {
                    acc.push({x: item.x, y: item.y});
                } else if (item.y) {
                    itemInAcc.y = typeof itemInAcc.y === 'number' ? itemInAcc.y + item.y : item.y;
                }

                return acc;
            }, []);

            newChartSeries.push(newChart);
        });

        updateChartOptions();

        return newChartSeries;
    });

    function updateChartOptions(): void {
        chartOptions.value = {
            chart: {
                zoom: {
                    enabled: false
                },
                stacked: false,
                toolbar: {
                    show: false
                },
                animations: {
                    enabled: false
                }
            },
            xaxis: {
                tickAmount: unref(tickAmount),
                labels: {
                    formatter(value) {
                        return DateTime.fromMillis(Number(value)).toFormat(LUXON_DATE_FORMAT);
                    }
                }
            },
            yaxis: {
                forceNiceScale: true,
                decimalsInFloat: 2
            },
            colors: RAINBOW_COLORS,
            dataLabels: {
                enabled: false
            },
            legend: {
                show: true,
                position: 'bottom',
                showForSingleSeries: true,
                showForNullSeries: true,
                showForZeroSeries: true
            },
            tooltip: {
                custom: apexChartsSharedTooltip,
                y: {
                    formatter: function (val) {
                        return val?.toString() ?? '-';
                    }
                }
            },
            stroke: {
                curve: 'straight',
                width: unref(isScatter) ? 0 : 2
            },
            markers: {
                size: unref(isScatter) ? 6 : 3,
                hover: {
                    size: unref(isScatter) ? 6 : 3
                }
            }
        };
    }
</script>
