<template>
    <ApexChart
        type="line"
        height="300"
        width="100%"
        :options="chartOptions"
        :series="series"/>
</template>

<script
    lang="ts"
    setup>
    import { computed, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        series: GenericChartSeries[];
        options?: ApexOptions;
    }

    const props = defineProps<Props>();
    const {options} = toRefs(props);

    const chartOptions = computed((): ApexOptions => ({
        ...{
            chart: {
                type: 'line',
                zoom: {
                    enabled: false
                },
                stacked: true,
                animations: {
                    enabled: false
                },
                events: {},
                toolbar: {
                    show: false
                }
            },
            xaxis: {
                type: 'datetime'
            },
            colors: ['#2e93fa', '#66da26', '#ec620e', '#6f1ee9', '#ff9800', '#e91e63', '#1ee9ba'],
            legend: {
                show: false
            },
            tooltip: {
                enabled: true,
                shared: false
            },
            stroke: {
                curve: 'smooth'
            },
            markers: {
                showNullDataPoints: true
            }
        },
        ...unref(options)
    }));
</script>
