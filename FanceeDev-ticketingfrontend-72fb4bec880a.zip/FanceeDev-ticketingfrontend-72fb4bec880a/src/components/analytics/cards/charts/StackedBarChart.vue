<template>
    <ApexChart
        v-if="series && !isLoading"
        :height="height ?? 400"
        width="100%"
        :options="chartOptions"
        :series="series"/>
</template>

<script
    lang="ts"
    setup>
    import { computed, toRefs, unref } from 'vue';
    import ApexChart from 'vue3-apexcharts';
    import { ApexOptions } from 'apexcharts';
    import deepMerge from '@/util/deepMerge';
    import { CHART_FONT_FAMILY } from '@/data';
    import { ChartSeriesItem } from '@/data/interface/charts';

    export interface Props {
        height?: number;
        series: ChartSeriesItem[];
        options?: ApexOptions;
        isLoading?: boolean;
    }

    const props = defineProps<Props>();
    const {series, options} = toRefs(props);

    const colors = ['#5f72b5', '#9aa6d1', '#f59f3f', '#f8bd7c', '#3b4771'];

    const chartOptions = computed(() => deepMerge(
        {
            chart: {
                type: 'bar',
                selection: {
                    enabled: false
                },
                stacked: true,
                animations: {
                    enabled: false
                },
                toolbar: {
                    show: false
                },
                events: {},
                fontFamily: CHART_FONT_FAMILY
            },
            dataLabels: {
                enabled: false
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    dataLabels: {
                        total: {
                            enabled: true,
                            offsetX: 0,
                            style: {
                                fontSize: '13px',
                                fontWeight: 900,
                                fontFamily: CHART_FONT_FAMILY
                            }
                        }
                    }
                }
            },
            states: {
                active: {
                    filter: {
                        type: 'none'
                    }
                }
            },
            colors: colors,
            fill: {
                opacity: 1
            },
            legend: {
                show: true,
                position: 'bottom',
                showForSingleSeries: true,
                showForNullSeries: true,
                showForZeroSeries: true
            },
            tooltip: {
                enabled: true,
                shared: true,
                followCursor: false,
                intersect: false,
                y: {
                    formatter: function (val) {
                        return val?.toString() ?? '-';
                    }
                }
            },
            stroke: {
                width: 2,
                colors: ['#fff']
            },
            markers: {
                size: 0,
                showNullDataPoints: false,
                hover: {
                    size: 0
                }
            },
            grid: {
                padding: {
                    left: 24,
                    right: 24
                }
            }
        },
        unref(options)
    ));
</script>
