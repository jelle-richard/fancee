<template>
    <FluxStack :gap="0">
        <ApexChart
            v-if="series && chartOptions"
            class="chart"
            width="100%"
            height="330"
            :series="series"
            :options="chartOptions"/>

        <FluxStack
            class="chart-engagement-bar"
            axis="horizontal">
            <span>{{ t('analytics.bestPostTime.engagement.lowest') }}</span>
            <span>{{ t('analytics.bestPostTime.engagement.highest') }}</span>
        </FluxStack>
    </FluxStack>
</template>

<script
    lang="ts"
    setup>
    import { ApexOptions } from 'apexcharts';
    import { ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ANALYTICS_CHART_GRADIENT_COLORS, CHART_FONT_FAMILY } from '@/data';
    import { deepMerge } from '@/util';
    import ApexChart from 'vue3-apexcharts';

    export type Props = {
        options?: ApexOptions;
        series: ApexAxisChartSeries;
    };

    const props = defineProps<Props>();
    const {series, options} = toRefs(props);

    const {t} = useI18n();

    const chartOptions = ref<ApexOptions>({
        chart: {
            type: 'heatmap',
            toolbar: {
                show: false
            },
            animations: {
                enabled: false
            }
        },
        legend: {
            position: 'bottom',
            height: 15,

            formatter: () => ''
        },
        plotOptions: {
            heatmap: {
                shadeIntensity: 0,
                radius: 5,
                useFillColorAsStroke: false
            }
        },
        grid: {
            padding: {
                top: 0,
                bottom: 30,
                right: -7,
                left: 0
            },
            yaxis: {
                lines: {
                    show: false
                }
            }
        },
        colors: ANALYTICS_CHART_GRADIENT_COLORS,
        xaxis: {
            categories: [...Array(24).keys()].map(i => `${i}`.padStart(2, '0')),
            type: 'category',
            labels: {
                style: {
                    fontSize: '12px',
                    fontFamily: CHART_FONT_FAMILY
                }
            }
        },
        yaxis: {
            showForNullSeries: false,
            labels: {
                show: true,
                minWidth: 40,
                maxWidth: 40,
                offsetX: -10,
                style: {
                    fontSize: '11px',
                    fontFamily: CHART_FONT_FAMILY
                }
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            width: 2
        },
        fill: {
            opacity: 1
        }
    });

    async function updateData() {
        chartOptions.value = deepMerge(
            unref(chartOptions),
            unref(options)
        )!;
    }

    watch([options], updateData, {deep: true, immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .chart {
        flex: 1
    }

    .chart-engagement-bar {
        margin-left: 40px;
        justify-content: space-between;
        font-size: 12px;
    }

    ::v-deep(.apexcharts-yaxis) {
        transform: translate(3px, 0) !important;
    }

    ::v-deep(.apexcharts-legend) {
        justify-content: space-evenly;
        overflow: hidden;
        padding: 0;
        margin-left: 40px;
        border-radius: 3px !important;
    }

    ::v-deep(.apexcharts-legend-series) {
        flex: 1;
        margin: 0 !important;

        &[seriesname="hidden"] {
            display: none !important;
        }
    }

    ::v-deep(.apexcharts-legend-marker) {
        margin: 0;
        height: 15px !important;
        top: auto !important;
        width: 100% !important;
        border-radius: 0 !important;
    }
</style>

