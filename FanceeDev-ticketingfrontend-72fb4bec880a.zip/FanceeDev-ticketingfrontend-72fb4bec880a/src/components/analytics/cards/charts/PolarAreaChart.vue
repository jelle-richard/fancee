<template>
    <ApexChart
        v-if="chartSeries.length > 0"
        ref="apexChartRef"
        width="100%"
        height="300"
        :options="chartOptions"
        :series="chartSeries"/>
</template>

<script
    lang="ts"
    setup>
    import ApexChart from 'vue3-apexcharts';
    import { computed, ref, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { ChartSeriesItem } from '@/data/interface/charts';

    export interface Props {
        series: ChartSeriesItem;
        options?: ApexOptions;
        isLoading: boolean;
    }

    const props = defineProps<Props>();
    const {series} = toRefs(props);

    const apexChartRef = ref();

    const chartSeries = computed((): number[] => unref(series).data.map(item => item.y ?? 0));
    const chartColors = computed((): string[] => unref(series).data.map(item => item.text ?? '#000000'));
    const chartCategories = computed((): string[] => unref(series).data.map(item => item.x?.toString() ?? ''));

    const chartOptions = computed((): ApexOptions => ({
        chart: {
            type: 'polarArea',
            animations: {
                enabled: false
            },
            selection: {
                enabled: false
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            show: false
        },
        fill: {
            opacity: 0.9
        },
        labels: unref(chartCategories),
        colors: unref(chartColors),
        legend: {
            show: false,
            position: 'bottom'
        },
        tooltip: {
            fillSeriesColor: false,
            y: {
                formatter: (val: number): string => `${val.toFixed(2)}%`
            }
        }
    }));
</script>
