<template>
    <ApexChart
        height="300"
        width="100%"
        :options="chartOptions"
        :series="chartSeries"/>
</template>

<script
    lang="ts"
    setup>
    import { computed, toRefs, unref } from 'vue';
    import { ApexOptions } from 'apexcharts';
    import { CHART_COLOR_ARRAY } from '@/data';
    import { ChartSeriesItem } from '@/data/interface/charts';
    import ApexChart from 'vue3-apexcharts';

    export interface Props {
        series: ChartSeriesItem;
        options?: ApexOptions;
    }

    const props = defineProps<Props>();
    const {series, options} = toRefs(props);

    const chartSeries = computed((): number[] => unref(series).data.map(item => item.y ?? 0) as number[]);

    const chartCategories = computed((): string[] => {
        const currentSeries = unref(series);
        return currentSeries.data.map(item => item.x?.toString() ?? '');
    });

    const chartOptions = computed((): ApexOptions => ({
        ...{
            chart: {
                type: 'pie',
                animations: {
                    enabled: false
                },
                selection: {
                    enabled: false
                }
            },
            dataLabels: {
                enabled: true
            },
            stroke: {
                show: false
            },
            labels: unref(chartCategories),
            colors: CHART_COLOR_ARRAY,
            legend: {
                show: true,
                position: 'bottom'
            },
            tooltip: {
                fillSeriesColor: false
            }
        },
        ...unref(options)
    } as ApexOptions));
</script>
