<template>
    <FluxDataTable
        :data-set="rows"
        :page="page"
        :per-page="pageSize"
        :total="totalItems"
        is-hoverable>
        <template #header>
            <FluxTableHeader>{{ t('analytics.post.message') }}</FluxTableHeader>
            <FluxTableHeader>{{ t('analytics.post.reach') }}</FluxTableHeader>
            <FluxTableHeader>{{ t('analytics.post.likes') }}</FluxTableHeader>
            <FluxTableHeader>{{ t('analytics.post.reactions') }}</FluxTableHeader>
            <FluxTableHeader>{{ t('analytics.post.date') }}</FluxTableHeader>
            <FluxTableHeader>{{ t('analytics.post.time') }}</FluxTableHeader>
        </template>

        <template #message="{row: {message}}">
            <FluxTableCell>{{ message }}</FluxTableCell>
        </template>

        <template #reach="{row: {totalReach}}">
            <FluxTableCell>{{ totalReach }}</FluxTableCell>
        </template>

        <template #likes="{row: {totalLikes}}">
            <FluxTableCell>{{ totalLikes }}</FluxTableCell>
        </template>

        <template #reactions="{row: {totalReactions}}">
            <FluxTableCell>{{ totalReactions }}</FluxTableCell>
        </template>

        <template #date="{row: {date}}">
            <FluxTableCell>{{ formatDate(date) }}</FluxTableCell>
        </template>

        <template #time="{row: {time}}">
            <FluxTableCell>{{ time }}</FluxTableCell>
        </template>
    </FluxDataTable>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { Post } from '@/data/dto/analytics/posts';
    import { formatDate } from '@/util';

    export type Props = {
        readonly rows: Post[];
        readonly page: number;
        readonly pageSize: number;
        readonly totalItems: number;
        readonly onPageUpdate?: void;
        readonly onPageSizeUpdate?: void;
    };

    defineProps<Props>();

    const {t} = useI18n();
</script>
