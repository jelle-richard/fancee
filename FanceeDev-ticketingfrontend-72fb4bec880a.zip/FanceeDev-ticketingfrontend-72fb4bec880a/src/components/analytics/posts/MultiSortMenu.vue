<template>
    <FluxFlyout>
        <template #opener="{open}">
            <button
                :class="`flux-table-header-sort sort-active-${isActive}`"
                :aria-label="t('flux.sort')"
                tabindex="-1"
                @click="open">
                <FluxIcon
                    :size="15"
                    :variant="sortingIconEngagement"/>
                <label
                    v-if="isActive && options.length > 1"
                    class="active-sort-label">
                    {{ t(orderBy!.toLowerCase()) }}
                </label>
                <label
                    v-if="filter !== null && filter.length > 0"
                    class="active-sort-label">
                    {{ filter }}
                </label>
            </button>
        </template>

        <template #default="{close}">
            <FluxMenu>
                <FluxMenuGroup>
                    <template v-for="option in options">
                        <FluxMenuItem
                            :is-highlighted="orderBy === option && orderByDirection === 'ascending'"
                            icon-before="arrow-down-a-z"
                            :label="optionLabel(option, 'Ascending')"
                            @click="() => { $emit('sort', option, 'ascending',filter); close(); }"/>

                        <FluxMenuItem
                            :is-highlighted="orderBy === option && orderByDirection === 'descending'"
                            icon-before="arrow-up-a-z"
                            :label="optionLabel(option, 'Descending')"
                            @click="() => {$emit('sort', option, 'descending', filter); close(); }"/>
                    </template>
                </FluxMenuGroup>

                <template v-if="isActive">
                    <FluxSeparator/>

                    <FluxMenuGroup>
                        <FluxMenuItem
                            icon-before="circle-xmark"
                            is-destructive
                            :label="t('flux.sortRemove')"
                            @click="() => { $emit('sort', null, null, null); close(); }"/>
                    </FluxMenuGroup>
                </template>
            </FluxMenu>
        </template>
    </FluxFlyout>
</template>


<script
    lang="ts"
    setup>
    import type { IconNames } from '@fancee/flux';
    import { computed, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';

    export interface Emits {
        (e: 'sort', option: string | null, sort: 'ascending' | 'descending' | null, filter: string | null): void;
    }

    export interface Props {
        readonly options: string[];
        readonly orderBy: string | null;
        readonly orderByDirection: 'ascending' | 'descending' | null;
    }

    defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        orderByDirection: null
    });
    const {options, orderBy, orderByDirection} = toRefs(props);

    const {t} = useI18n();

    const filter = ref<string | null>(null);

    const optionLabel = (option: string, direction: 'Ascending' | 'Descending'): string => {
        const directionString = t(`flux.sort${direction}`);

        if (unref(options).length <= 1) {
            return directionString;
        }

        return `${t(option.toLowerCase())}, ${directionString}`;
    };

    const isActive = computed((): boolean => {
        const _orderBy: string | null = unref(orderBy);
        return _orderBy !== null && unref(options).includes(_orderBy);
    });

    const sortingIconEngagement = computed((): IconNames => {
        if (unref(isActive)) {
            switch (unref(orderByDirection)) {
                case 'ascending':
                    return 'arrow-down-a-z';

                case 'descending':
                    return 'arrow-up-a-z';
            }
        }

        return 'arrow-up-arrow-down';
    });
</script>

<style
    lang="scss"
    scoped>
    .active-sort-label {
        padding-left: 0.25rem;
        cursor: inherit;
        color: inherit;
        line-height: 1rem;
    }

    .flux-table-header-sort {
        width: auto;
        min-width: 24px;
    }

    .sort-active-true {
        color: rgb(var(--primary-7));
    }
</style>
