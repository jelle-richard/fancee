<template>
    <SideVisualLayout>
        <div :class="$style.onboardingLayoutBody">
            <FluxStepperSteps
                :class="$style.onboardingLayoutStepper"
                :amount="steps"
                :current="step"/>

            <div :class="$style.onboardingLayoutContent">
                <slot/>
            </div>

            <FluxFadeTransition>
                <div
                    v-if="isLoading"
                    :class="$style.onboardingLayoutSpinner">
                    <FluxSpinner :size="30"/>
                </div>
            </FluxFadeTransition>
        </div>
    </SideVisualLayout>
</template>

<script
    lang="ts"
    setup>
    import SideVisualLayout from './SideVisualLayout.vue';

    export interface Props {
        readonly isLoading?: boolean;
        readonly step: number;
        readonly steps: number;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    @use '@/assets/css/breakpoints' as *;

    .onboardingLayoutBody {
        position: relative;
        display: grid;
        padding: 30px 0;
        gap: 48px;
        grid-template-columns: 1fr [content-start] minmax(0, 660px) [content-end] 1fr;
        grid-template-rows: auto 1fr;
    }

    .onboardingLayoutContent {
        position: relative;
        display: flex;
        flex-flow: column;
        gap: 21px;
        grid-column: content;
    }

    .onboardingLayoutSpinner {
        position: absolute;
        display: flex;
        inset: 0;
        align-items: center;
        justify-content: center;
        background: rgb(var(--gray-2) / .75);
        backdrop-filter: blur(5px) saturate(180%);
    }

    .onboardingLayoutStepper {
        grid-column: content;
    }

    @include breakpoint-up(lg) {
        .onboardingLayoutBody {
            padding: 84px 42px;
            margin-top: 0;
        }
    }
</style>
