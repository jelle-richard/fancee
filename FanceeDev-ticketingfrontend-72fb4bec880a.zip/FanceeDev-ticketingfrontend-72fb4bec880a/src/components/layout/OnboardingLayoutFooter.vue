<template>
    <footer :class="$style.onboardingLayoutFooter">
        <slot/>
    </footer>
</template>

<style
    lang="scss"
    module>
    .onboardingLayoutFooter {
        display: flex;
        margin-top: 30px;
        align-items: center;
        flex-flow: row;
        gap: 6px;
    }
</style>
