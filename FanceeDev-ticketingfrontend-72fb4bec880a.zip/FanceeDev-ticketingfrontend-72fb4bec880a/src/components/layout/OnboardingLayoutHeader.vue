<template>
    <header :class="$style.onboardingLayoutHeader">
        <slot/>
    </header>
</template>

<style
    lang="scss"
    module>
    .onboardingLayoutHeader {
        display: flex;
        flex-flow: column;
        gap: 6px;

        :is(h1, p) {
            margin: 0;
        }

        :is(h1) {
            font-size: 21px;
        }

        :is(p) {
            font-size: 16px;
        }
    }
</style>
