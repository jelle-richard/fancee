<template>
    <SideVisualLayout>
        <div :class="$style.authLayoutBody">
            <div :class="$style.authLayoutContent">
                <div :class="$style.authLayoutHeader">
                    <h1>{{ title }}</h1>
                    <p v-if="description">{{ description }}</p>
                </div>

                <slot/>
            </div>

            <FluxFadeTransition>
                <div
                    v-if="isLoading"
                    :class="$style.authLayoutSpinner">
                    <FluxSpinner :size="30"/>
                </div>
            </FluxFadeTransition>
        </div>
    </SideVisualLayout>
</template>

<script
    lang="ts"
    setup>
    import SideVisualLayout from './SideVisualLayout.vue';

    export interface Props {
        readonly description?: string;
        readonly isLoading?: boolean;
        readonly title: string;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    @use '@/assets/css/breakpoints' as *;

    .authLayoutBody {
        position: relative;
        display: grid;
        padding: 30px;
        align-items: center;
        grid-template-columns: 1fr [content-start] minmax(0, 510px) [content-end] 1fr;
    }

    .authLayoutContent {
        position: relative;
        display: flex;
        flex-flow: column;
        gap: 21px;
        grid-column: content;
    }

    .authLayoutHeader {
        display: flex;
        flex-flow: column;
        gap: 6px;

        :is(h1, p) {
            margin: 0;
        }

        :is(h1) {
            font-size: 21px;
        }

        :is(p) {
            font-size: 16px;
        }
    }

    .authLayoutSpinner {
        position: absolute;
        display: flex;
        inset: 0;
        align-items: center;
        justify-content: center;
        background: rgb(var(--gray-2) / .75);
        backdrop-filter: blur(5px) saturate(180%);
    }

    @include breakpoint-up(lg) {
        .authLayoutBody {
            padding: 84px 42px;
        }
    }
</style>
