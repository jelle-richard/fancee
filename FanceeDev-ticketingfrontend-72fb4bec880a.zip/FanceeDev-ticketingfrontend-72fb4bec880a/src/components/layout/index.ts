export { default as AuthLayout } from './AuthLayout.vue';
export { default as OnboardingLayout } from './OnboardingLayout.vue';
export { default as OnboardingLayoutFooter } from './OnboardingLayoutFooter.vue';
export { default as OnboardingLayoutHeader } from './OnboardingLayoutHeader.vue';
export { default as SideVisualLayout } from './SideVisualLayout.vue';
