<template>
    <main :class="$style.sideVisualLayout">
        <div :class="$style.sideVisualLayoutVisual">
            <div :class="$style.sideVisualLayoutVisualImage"/>

            <img
                :class="$style.sideVisualLayoutVisualLogo"
                :src="wearefanceeLogo"
                :alt="t('global.platform.name')">
        </div>

        <slot/>
    </main>

    <FluxButtonStack
        axis="horizontal"
        :class="$style.sideVisualLanguageFlyout">
        <FluxSecondaryButton
            v-if="user !== null"
            :label="t('auth.logout')"
            @click="handleUserLogout(router)"/>
        <LanguageFlyout/>
    </FluxButtonStack>
</template>

<script
    lang="ts"
    setup>
    import { LanguageFlyout } from '@/components/ui';
    import { handleUserLogout } from '@/util';
    import { useRouter } from '@/composable';
    import { useI18n } from 'vue-i18n';
    import { useAuthStore } from '@/data/store';
    import wearefanceeLogo from '@/assets/brand/logo-wearefancee.svg';

    const {t} = useI18n();
    const {user} = useAuthStore();
    const router = useRouter();
</script>

<style
    lang="scss"
    module>
    @use '@/assets/css/breakpoints' as *;

    .sideVisualLanguageFlyout {
        width: min-content;
        margin: 30px auto;
        display: flex;
        right: 30px;
        bottom: 0;
    }

    .sideVisualLayout {
        display: grid;
        grid-template-columns: 1fr;
        grid-template-rows: 150px 1fr;
        background: rgb(var(--gray-2));

        :global(.flux-notice.is-gray) {
            --notice-background: rgb(var(--gray-3));
        }
    }

    .sideVisualLayoutVisual {
        position: relative;
        display: flex;
        align-items: center;
        flex-flow: column;
        justify-content: center;
        background: rgb(var(--primary-9));
        overflow: hidden;
    }

    .sideVisualLayoutVisualImage {
        position: absolute;
        display: block;
        inset: 0;
        background: url(@/assets/images/backgrounds/nightlife.jpg) no-repeat center left / cover;
        filter: blur(10px) saturate(135%);
        opacity: .25;
    }

    .sideVisualLayoutVisualLogo {
        position: relative;
        height: 24px;
        filter: invert(1);
    }

    @include breakpoint-up(lg) {
        .sideVisualLanguageFlyout {
            margin: 0;
            position: absolute;
            top: 30px;
        }

        .sideVisualLayout {
            min-height: 100dvh;
            grid-template-columns: 300px 1fr;
            grid-template-rows: 1fr;
        }

        .sideVisualLayoutVisual {
            position: sticky;
            max-height: 100dvh;
            padding-top: 84px;
            top: 0;
            justify-content: flex-start;
        }
    }
</style>
