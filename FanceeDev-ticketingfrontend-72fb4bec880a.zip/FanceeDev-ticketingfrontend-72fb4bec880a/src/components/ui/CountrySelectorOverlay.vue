<template>
    <FluxPane>
        <FluxPaneHeader>
            <FluxStack is-fill>
                <FluxStack axis="horizontal">
                    <h4>{{ t('ui.countrySelectOverlay.title') }}</h4>

                    <FluxSpacer/>

                    <FluxBadge
                        v-if="user"
                        :label="t('ui.countrySelectOverlay.selection', [selectedCountryOptions.length, user.countryCodes.length])"/>
                </FluxStack>

                <FluxFormInputGroup>
                    <FluxFormInputAddition icon="magnifying-glass"/>

                    <FluxFormInput
                        v-model="countrySearch"
                        auto-complete="off"
                        type="search"/>

                    <FluxSecondaryButton
                        v-if="countrySearch.length > 0"
                        icon-before="xmark"
                        @click="countrySearch = ''"/>
                </FluxFormInputGroup>

                <FluxButtonStack class="justify-content">
                    <input
                        type="checkbox"
                        class="display-none"
                        id="check_all"/>

                    <label for="check_all">
                        <FluxStack is-fill>
                            <div
                                class="faux-button"
                                :class="areAllChecked ? 'primary' : ''"
                                @click="selectAllToggle">
                                <span>{{ t('ui.countrySelectOverlay.checkAll') }}</span>
                                <FluxIcon
                                    size="15"
                                    variant="circle-check"/>
                            </div>
                        </FluxStack>
                    </label>
                </FluxButtonStack>
            </FluxStack>
        </FluxPaneHeader>

        <FluxDivider/>

        <FluxPaneBody
            v-if="user"
            class="overflow-y-auto">
            <FluxStack>
                <FluxGrid :gap="15">
                    <template v-for="countryCode of user.countryCodes">
                        <FluxGridColumn
                            v-if="showCountry(countryCode)"
                            :key="countryCode"
                            :md="6">
                            <input
                                v-model="selectedCountryOptions"
                                :value="countryCode"
                                type="checkbox"
                                class="display-none"
                                :id="countryCode"/>
                            <label :for="countryCode">
                                <FluxStack is-fill>
                                    <div
                                        class="faux-button"
                                        :class="selectedCountryOptions.includes(countryCode) ? 'primary' : ''">
                                        <img
                                            class="country-flag"
                                            :src="countryFlagImages[countryCode]"
                                            alt=""/>
                                        {{ `${countryCode} (${AddressAdapter.parseCountryCodeToEnglish(countryCode)})` }}
                                    </div>
                                </FluxStack>
                            </label>
                        </FluxGridColumn>
                    </template>
                </FluxGrid>
            </FluxStack>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSpacer/>

            <FluxSecondaryButton
                :label="t('global.close')"
                @click="revertSelectedCountries"/>

            <FluxPrimaryButton
                :disabled="selectedCountryOptions.length === 0"
                :label="t('global.save')"
                icon-before="circle-check"
                @click="addSelectedCountries(selectedCountryOptions)"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { AddressAdapter, CountryCode } from '@fancee/data';
    import { computed, onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { storeToRefs, useAuthStore, useUiStore } from '@/data/store';
    import countryFlagImages from '@/assets/language';

    export interface Emits {
        (e: 'close'): void;

        (e: 'selected-countries', selectedCountries: CountryCode[]): void;
    }

    const emit = defineEmits<Emits>();

    const {t} = useI18n();
    const authStore = useAuthStore();
    const uiStore = useUiStore();
    const {user} = storeToRefs(authStore);
    const {allowedCountries} = storeToRefs(uiStore);

    const selectedCountryOptions = ref<CountryCode[]>([]);
    const selectedCountries = ref<CountryCode[]>([]);
    const countrySearch = ref('');

    const areAllChecked = computed(() => unref(selectedCountryOptions).length === unref(user)!.countryCodes.length);

    onMounted(() => {
        //todo: Selecting all countries may result in a timeout until https://fanceesoftware.atlassian.net/browse/FAN-1631 is fixed

        selectedCountries.value = unref(allowedCountries);
        selectedCountryOptions.value = unref(allowedCountries);
    });

    function selectAllToggle(): void {
        selectedCountryOptions.value = unref(areAllChecked) ? [] : unref(user)!.countryCodes;
    }

    function showCountry(country: CountryCode): boolean {
        const search = unref(countrySearch).toUpperCase();

        return search.length === 0
            || country.includes(search)
            || AddressAdapter.parseCountryCodeToEnglish(country).toUpperCase().includes(search);
    }

    function addSelectedCountries(countries: CountryCode[]): void {
        selectedCountries.value = countries;

        uiStore.setCountry(unref(selectedCountries));

        emit('selected-countries', unref(selectedCountries));
        emit('close');
    }

    function revertSelectedCountries(): void {
        selectedCountryOptions.value = unref(selectedCountries);

        emit('close');
    }
</script>

<style
    lang="scss"
    scoped>
    .display-none {
        display: none;
    }

    .overflow-y-auto {
        overflow-y: auto;
    }

    .country-flag {
        height: 21px;
        margin-right: 6px;
    }

    .faux-button {
        --button-background: rgb(var(--gray-0));
        --button-background-hover: rgb(var(--gray-2));
        --button-background-active: rgb(var(--gray-3));
        --button-foreground: var(--foreground);
        --button-icon: var(--foreground-prominent);
        --button-stroke: rgb(var(--gray-4) / .75);
        display: inline-flex;
        height: 42px;
        padding: 0 12px;
        align-items: center;
        flex-shrink: 0;
        gap: 12px;
        background: var(--button-background);
        border: 1px solid var(--button-stroke);
        border-radius: var(--radius);
        box-shadow: var(--shadow-px);
        cursor: pointer;
        font: inherit;
        text-decoration: none;
        transition: 180ms var(--swift-out);
        transition-property: background, box-shadow, color, outline-color, outline-offset;
        -webkit-user-select: none;
        user-select: none;
        outline: 2px solid rgb(var(--primary-7)/0);
        outline-offset: 0;

        &.primary {
            --button-background: rgb(var(--primary-7));
            --button-background-hover: rgb(var(--primary-8));
            --button-background-active: rgb(var(--primary-9));
            --button-foreground: rgb(var(--primary-0));
            --button-icon: rgb(var(--primary-0));
            --button-stroke: transparent;
            --spinner-track: rgb(var(--primary-8));
            --spinner-value: rgb(var(--primary-0));
            color: var(--button-foreground);
        }
    }

    .justify-content {
        justify-content: center;
    }
</style>
