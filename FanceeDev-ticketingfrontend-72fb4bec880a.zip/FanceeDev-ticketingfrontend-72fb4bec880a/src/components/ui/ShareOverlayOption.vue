<template>
    <button
        class="share-option"
        :data-option="name"
        @click="$emit('click', $event)">
        <FluxIcon
            :size="27"
            :variant="icon"/>

        <span>{{ name }}</span>
    </button>
</template>

<script
    lang="ts"
    setup>
    import type { IconNames } from '@fancee/flux';

    export interface Emits {
        (e: 'click', evt: MouseEvent): void;
    }

    export interface Props {
        readonly icon: IconNames;
        readonly name: string;
    }

    defineProps<Props>();
</script>

<style
    lang="scss"
    scoped>
    .share-option {
        --color: var(--foreground-prominent);

        display: flex;
        padding: 0;
        aspect-ratio: 1;
        align-items: center;
        flex-flow: column;
        gap: 12px;
        justify-content: center;
        background: transparent;
        border: 1px solid transparent;
        border-radius: var(--radius);
        color: var(--foreground);
        cursor: pointer;
        outline: 0;
        transition: 210ms var(--swift-out);
        user-select: none;

        &:focus-visible,
        &:hover {
            background: rgb(var(--gray-1));
            border-color: rgb(var(--gray-3));
            box-shadow: var(--shadow-sm);
        }

        &:focus-visible {
            outline: 2px solid rgb(var(--primary-6));
        }

        ::v-deep(.flux-icon) {
            color: var(--color);
        }

        &[data-option="Facebook"] {
            --color: #1877f2;
        }

        &[data-option="linkedIn"] {
            --color: #0a66c2;
        }

        &[data-option="Telegram"] {
            --color: #0088cc;
        }

        &[data-option="WhatsApp"] {
            --color: #25d366;
        }

        &[data-option="X (Twitter)"] {
            --color: var(--foreground-prominent);
        }
    }
</style>
