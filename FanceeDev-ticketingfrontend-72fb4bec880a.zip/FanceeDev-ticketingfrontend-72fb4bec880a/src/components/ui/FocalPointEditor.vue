<template>
    <FluxSecondaryButton
        icon-before="arrows-to-circle"
        :label="label"
        @click="isOpen = true">
        <template #after>
            <FluxOverlay
                is-closeable
                size="large"
                @close="close">
                <FluxPane v-if="isOpen">
                    <FluxPaneHeader
                        icon="arrows-to-circle"
                        :title="t('ui.focalPoint.editor.title')"
                        :sub-title="t('ui.focalPoint.editor.subTitle')">
                        <FluxSecondaryButton
                            icon-before="xmark"
                            @click="close"/>
                    </FluxPaneHeader>

                    <FluxPaneBody
                        v-if="images.length > 1"
                        class="focal-point-editor-images">
                        <template
                            v-for="image of images"
                            :key="image.url">
                            <button
                                class="focal-point-editor-image"
                                :class="{'is-selected': image.url === selectedImage?.url}"
                                @click="selectedImage = image">
                                <FluxFocalPointImage
                                    :focal-point="image.focalPoint"
                                    :src="image.url"
                                    alt=""/>
                            </button>
                        </template>
                    </FluxPaneBody>

                    <FluxFocalPointEditor
                        v-if="selectedImage"
                        v-model="focalPoint"
                        class="focal-point-editor"
                        :url="selectedImage.url">
                        <template #footer>
                            <FluxSecondaryButton
                                :label="t('global.done')"
                                @click="close"/>
                        </template>
                    </FluxFocalPointEditor>
                </FluxPane>
            </FluxOverlay>
        </template>
    </FluxSecondaryButton>
</template>

<script
    lang="ts"
    setup>
    import { FocalPoint, Media } from '@fancee/data';
    import { ref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';

    export interface Emits {
        (e: 'close'): void;
    }

    export interface Props {
        readonly images: Media[];
        readonly label?: string;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {t} = useI18n();

    const isOpen = ref(false);
    const selectedImage = ref<Media | null>(props.images[0] ?? null);

    const focalPoint = ref([50, 50]);

    function close(): void {
        emit('close');
        isOpen.value = false;
    }

    watch(focalPoint, focalPoint => {
        if (!selectedImage.value) {
            return;
        }

        selectedImage.value.focalPoint = new FocalPoint(
            Math.round(focalPoint[0]),
            Math.round(focalPoint[1])
        );
    });

    watch(selectedImage, selectedImage => {
        focalPoint.value = [
            selectedImage?.focalPoint?.x ?? 50,
            selectedImage?.focalPoint?.y ?? 50
        ];
    }, {immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .focal-point-editor {
        width: unset;
        background: transparent;

        ::v-deep(.flux-focal-point-editor) {
            max-height: 540px;
        }

        ::v-deep(.flux-focal-point-preview) {
            height: 450px;
        }

        ::v-deep(.flux-focal-point-preview-image) {
            max-height: 450px;
        }

        &-image {
            display: flex;
            height: 72px;
            width: 72px;
            align-items: center;
            justify-content: center;
            border: 0;
            border-radius: var(--radius);
            cursor: pointer;
            opacity: .5;
            outline: 2px solid rgb(var(--gray-0));
            outline-offset: -2px;
            transition: 210ms var(--swift-out);
            transition-property: opacity, outline;

            ::v-deep(.flux-focal-point-image) {
                height: inherit;
                width: inherit;
                border-radius: inherit;
            }

            &:hover,
            &.is-selected {
                opacity: 1;
            }

            &.is-selected {
                outline: 3px solid rgb(var(--primary-7));
                outline-offset: 2px;
            }
        }

        &-images {
            flex-flow: row;
            padding-bottom: 0;
            gap: 12px;
        }
    }
</style>
