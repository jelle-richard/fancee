<template>
    <main class="auth-view">
        <div class="auth-view-background"/>

        <FluxPane>
            <FluxPaneBody>
                <img
                    class="auth-view-logo"
                    :src="wearefanceeLogo"
                    alt="WeAreFancee"/>
            </FluxPaneBody>
            <slot/>
        </FluxPane>
    </main>
</template>

<script
    lang="ts"
    setup>
    import wearefanceeLogo from '@/assets/brand/logo-wearefancee.svg?url';
</script>

<style
    lang="scss"
    scoped>
    .auth-view {
        position: fixed;
        display: flex;
        inset: 0;
        height: 100dvh;
        width: 100dvw;
        background: rgb(var(--primary-9));

        &-background {
            position: absolute;
            display: block;
            inset: 0;
            background: url(@/assets/images/backgrounds/nightlife.jpg) no-repeat center center / cover fixed;
            filter: blur(10px) saturate(135%);
            opacity: .25;
        }

        &-logo {
            height: 15px;
            align-self: flex-start;
        }

        ::v-deep(.flux-pane:not(.flux-form-select-popup)) {
            position: relative;
            margin: auto;
            max-width: 420px;
            width: calc(100% - 90px);
            border: 0;
            box-shadow: var(--shadow-large);
        }

        ::v-deep(.flux-pane-body),
        ::v-deep(.flux-pane-footer) {
            padding: 30px;
        }

        ::v-deep(.flux-pane-body + .flux-pane-body) {
            padding-top: 0;
        }

        ::v-deep(.flux-separator) {
            margin: 6px 15px;
        }
    }
</style>
