<template>
    <Suspense timeout="0">
        <template #fallback>
            <slot name="fallback"/>
        </template>

        <slot
            v-bind="{error}"
            v-if="error"
            name="error">
            <template v-if="error instanceof FanceeForbiddenError">
                <FluxNotice
                    icon="circle-exclamation"
                    is-small
                    :message="t('ui.notAllowed.message')"
                    variant="danger"/>
            </template>

            <template>
                {{ {error} }}
            </template>
        </slot>

        <slot v-else/>
    </Suspense>
</template>

<script
    lang="ts"
    setup>
    import { onErrorCaptured, ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { FanceeForbiddenError } from '@/data';

    const {t} = useI18n();

    const error = ref<Error>();

    onErrorCaptured(err => {
        error.value = err;
        return false;
    });
</script>
