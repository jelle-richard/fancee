import addEventImage from '@/assets/visual/addEvent.svg?url';
import addEventDarkImage from '@/assets/visual/addEventDark.svg?url';
import analyticsImage from '@/assets/visual/analytics.svg?url';
import analyticsDarkImage from '@/assets/visual/analyticsDark.svg?url';
import commentsImage from '@/assets/visual/comments.svg?url';
import commentsDarkImage from '@/assets/visual/commentsDark.svg?url';
import confirmedImage from '@/assets/visual/confirmed.svg?url';
import confirmedDarkImage from '@/assets/visual/confirmedDark.svg?url';
import countdownImage from '@/assets/visual/countdown.svg?url';
import countdownDarkImage from '@/assets/visual/countdownDark.svg?url';
import ghostImage from '@/assets/visual/ghost.svg?url';
import ghostDarkImage from '@/assets/visual/ghostDark.svg?url';
import navigationImage from '@/assets/visual/navigation.svg?url';
import navigationDarkImage from '@/assets/visual/navigationDark.svg?url';
import notFoundImage from '@/assets/visual/notFound.svg?url';
import notFoundDarkImage from '@/assets/visual/notFoundDark.svg?url';
import retroMacErrorImage from '@/assets/visual/retroMacError.svg?url';
import retroMacErrorDarkImage from '@/assets/visual/retroMacErrorDark.svg?url';
import searchUserImage from '@/assets/visual/searchUser.svg?url';
import searchUserDarkImage from '@/assets/visual/searchUserDark.svg?url';
import settingsImage from '@/assets/visual/settings.svg?url';
import settingsDarkImage from '@/assets/visual/settingsDark.svg?url';
import ticketsImage from '@/assets/visual/tickets.svg?url';
import ticketsDarkImage from '@/assets/visual/ticketsDark.svg?url';
import timeslottedImage from '@/assets/visual/timeslotted.svg?url';
import timeslottedDarkImage from '@/assets/visual/timeslottedDark.svg?url';

export const visualSources = {
    addEvent: [addEventImage, addEventDarkImage],
    analytics: [analyticsImage, analyticsDarkImage],
    comments: [commentsImage, commentsDarkImage],
    confirmed: [confirmedImage, confirmedDarkImage],
    countdown: [countdownImage, countdownDarkImage],
    ghost: [ghostImage, ghostDarkImage],
    navigation: [navigationImage, navigationDarkImage],
    notFound: [notFoundImage, notFoundDarkImage],
    retroMacError: [retroMacErrorImage, retroMacErrorDarkImage],
    searchUser: [searchUserImage, searchUserDarkImage],
    settings: [settingsImage, settingsDarkImage],
    tickets: [ticketsImage, ticketsDarkImage],
    timeslotted: [timeslottedImage, timeslottedDarkImage]
} as const;

export type VisualSource = keyof typeof visualSources;
