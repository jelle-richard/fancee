<template>
    <FluxDashboardNavigation
        :application-name="t(productName)"
        :logo-url="productLogo"
        :navigation-key="navigation.length">
        <template
            v-if="userType === UserType.Organization"
            #apps="{closeAppSwitcher}">
            <FluxMenu is-large>
                <FluxMenuGroup>
                    <FluxMenuItem
                        :image-url="ticketingLogo"
                        :label="t('global.platform.ticketing')"
                        :to="{name: 'organization-home'}"
                        type="route"
                        @click="closeAppSwitcher"/>

                    <FluxMenuItem
                        :image-url="analyticsLogo"
                        :label="t('global.platform.analytics')"
                        :to="{name: 'analytics-home'}"
                        type="route"
                        @click="closeAppSwitcher"/>
                </FluxMenuGroup>
            </FluxMenu>
        </template>

        <template #footer>
            &copy; {{ t('global.platform.name') }}
        </template>

        <FluxExpandableGroup is-controlled>
            <FluxMenu is-large>
                <template v-for="(item, index) of navigation">
                    <FluxMenuGroup v-if="isNavParent(item)">
                        <FluxExpandable :is-opened="isActive(item)">
                            <template #header="{open}">
                                <FluxMenuItem
                                    :disabled="isLocked(item)"
                                    :icon-after="isLocked(item) ? 'lock' : null"
                                    :icon-before="item.icon"
                                    :is-active="isActive(item)"
                                    :label="t(item.title)"
                                    @click="open"/>
                            </template>

                            <template #body>
                                <FluxMenuGroup>
                                    <template v-for="child of (item.children ?? [])">
                                        <FluxMenuItem
                                            :disabled="isLocked(child)"
                                            :icon-after="isLocked(child) ? 'lock' : null"
                                            :is-active="isActive(child)"
                                            is-indented
                                            :label="t(child.title)"
                                            :to="{name: child.route}"
                                            type="route"/>
                                    </template>
                                </FluxMenuGroup>
                            </template>
                        </FluxExpandable>
                    </FluxMenuGroup>

                    <template v-else-if="isNavItem(item)">
                        <FluxMenuItem
                            :key="index"
                            :disabled="isLocked(item)"
                            :icon-after="isLocked(item) ? 'lock' : null"
                            :icon-before="item.icon"
                            :is-active="isActive(item)"
                            :label="t(item.title)"
                            :to="{
                                name: item.route,
                                params: item.routeParams
                            }"
                            type="route"/>
                    </template>

                    <template v-else-if="isNavHeader(item)">
                        <FluxMenuSubHeader :label="t(item.header)"/>
                    </template>

                    <template v-else-if="isNavSeparator(item)">
                        <FluxSeparator/>
                    </template>
                </template>
            </FluxMenu>
        </FluxExpandableGroup>
    </FluxDashboardNavigation>
</template>

<script
    setup
    lang="ts">
    import { UserType } from '@fancee/data';
    import { useDashboardInjection, useDebouncedRef } from '@fancee/flux';
    import { computed, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRoute, useRouteMeta } from '@/composable';
    import { isNavHeader, isNavItem, isNavParent, isNavSeparator, isRouteMeta, NavEntry, NavItem } from '@/data/router';
    import { storeToRefs, useAuthStore, usePlatformStore, useUiStore } from '@/data/store';
    import analyticsLogo from '@/assets/brand/logo-analytics.svg';
    import ticketingLogo from '@/assets/brand/logo-ticketing.svg';

    const {isNavigationOpen} = useDashboardInjection();
    const {t} = useI18n();
    const route = useRoute();
    const routeMeta = useRouteMeta();
    const uiStore = useUiStore();
    const authStore = useAuthStore();
    const platformStore = usePlatformStore();
    const {claims, user} = storeToRefs(authStore);
    const {organizationContract} = storeToRefs(platformStore);

    const activeRouteNames = computed(() => {
        const {matched} = unref(route);
        return matched
            .map(m => m.meta && isRouteMeta(m.meta) && m.meta.activeAlias ? [m.name, m.meta.activeAlias] : m.name)
            .flat()
            .filter(m => !!m);
    });
    const productLogo = computed(() => unref(routeMeta)?.product?.logo ?? ticketingLogo);
    const productName = computed(() => unref(routeMeta)?.product?.name ?? 'unknown');
    const userType = computed(() => unref(user)?.type ?? null)

    const navigationLive = computed(() => uiStore.navigation ?? unref(routeMeta)?.navigation ?? []);
    const navigation = useDebouncedRef<NavEntry[]>([], 1);

    function isActive(entry: NavEntry): boolean {
        if (isNavHeader(entry) || isNavSeparator(entry)) {
            return false;
        }

        if (isNavItem(entry)) {
            return unref(activeRouteNames).includes(entry.route);
        }

        if (!entry.children) {
            return false;
        }

        for (const child of entry.children) {
            if (unref(activeRouteNames).includes(child.route)) {
                return true;
            }
        }

        return false;
    }

    function isLocked(item: NavItem): boolean {
        if (item.userClaim && !unref(claims).includes(item.userClaim)) {
            return true;
        }

        return unref(userType) === UserType.Organization && !unref(organizationContract)?.signed;
    }

    watch(navigationLive, navigationLive => navigation.value = navigationLive, {immediate: true});
    watch(route, () => isNavigationOpen.value = false);
</script>
