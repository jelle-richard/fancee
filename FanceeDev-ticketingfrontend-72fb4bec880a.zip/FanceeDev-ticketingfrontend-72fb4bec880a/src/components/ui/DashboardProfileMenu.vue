<template>
    <FluxFlyout :width="270">
        <template #opener="{open}">
            <FluxPersona
                v-if="user"
                :avatar-fallback-initials="user.firstName && user.lastName ? fullNameToInitials(`${user.firstName} ${user.lastName}`) : 'F'"
                :avatar-size="42"
                :avatar-url="user.avatarFile?.url"
                :name="user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : user.email"
                :title="activeOrganization ? t('ui.profileMenu.managing', [activeOrganization.name]) : null"
                @click="open()"/>
        </template>

        <template #default="{close}">
            <FluxWindow>
                <template #default="{navigate}">
                    <FluxMenu>
                        <template v-if="user && user.type === UserType.Organization">
                            <FluxMenuGroup>
                                <FluxMenuItem
                                    icon-before="user"
                                    :label="t('ui.profileMenu.profile')"
                                    :to="{name: 'profile'}"
                                    type="route"
                                    @click="close()"/>

                                <FluxMenuItem
                                    v-if="user && user.type === UserType.Organization"
                                    icon-before="cog"
                                    :label="t('ui.profileMenu.settings')"
                                    :to="{name: 'default-shop-settings'}"
                                    type="route"
                                    @click="close()"/>

                                <FluxMenuItem
                                    v-if="user && manageableOrganizations && manageableOrganizations.length > 1"
                                    command-icon="angle-right"
                                    icon-before="users-gear"
                                    :label="t('ui.profileMenu.switchOrganization')"
                                    @click="navigate('organizations')"/>
                            </FluxMenuGroup>

                            <FluxSeparator/>
                        </template>

                        <FluxMenuGroup>
                            <FluxMenuItem
                                command-icon="angle-right"
                                icon-before="language"
                                :label="t('ui.profileMenu.language')"
                                @click="navigate('language')"/>

                            <FluxMenuItem
                                :command="t(`ui.profileMenu.theme.${skin}`)"
                                command-icon="angle-right"
                                icon-before="eclipse"
                                :label="t('ui.profileMenu.appearance')"
                                @click="navigate('appearance')"/>
                        </FluxMenuGroup>

                        <FluxSeparator/>

                        <template v-if="user && user.type === UserType.Organization">
                            <FluxMenuGroup>
                                <FluxMenuItem
                                    icon-before="circle-question"
                                    :label="t('ui.profileMenu.faq')"
                                    :to="{name: 'faq'}"
                                    type="route"
                                    @click="close()"/>

                                <FluxMenuItem
                                    icon-before="sparkles"
                                    :label="t('ui.profileMenu.whatsNew')"
                                    :to="{name: 'changelog'}"
                                    type="route"
                                    @click="close()"/>
                            </FluxMenuGroup>

                            <FluxSeparator/>
                        </template>

                        <template v-if="ENVIRONMENT === 'development'">
                            <FluxMenuGroup>
                                <FluxMenuItem
                                    icon-before="file-code"
                                    label="Documentation"
                                    type="route"
                                    :to="{name: 'documentation'}"
                                    @click="close()"/>

                                <FluxMenuItem
                                    icon-before="screwdriver-wrench"
                                    label="Sandbox"
                                    type="route"
                                    :to="{name: 'sandbox'}"
                                    @click="close()"/>
                            </FluxMenuGroup>

                            <FluxSeparator/>
                        </template>

                        <FluxMenuGroup>
                            <FluxMenuItem
                                icon-before="arrow-right-from-line"
                                is-destructive
                                :label="t('ui.profileMenu.signOff')"
                                @click="handleUserLogout(router)"/>
                        </FluxMenuGroup>
                    </FluxMenu>
                </template>

                <template #organizations="{back}">
                    <FluxMenu>
                        <FluxMenuGroup>
                            <FluxMenuItem
                                icon-before="angle-left"
                                :label="t('global.back')"
                                @click="back()"/>
                        </FluxMenuGroup>

                        <FluxSeparator/>

                        <FluxMenuGroup>
                            <template
                                v-for="organization of manageableOrganizations"
                                :key="organization.id">
                                <FluxMenuItem
                                    :is-active="organization.id === activeOrganization?.id"
                                    :label="organization.name"
                                    @click="setOrganization(organization.id)"/>
                            </template>
                        </FluxMenuGroup>
                    </FluxMenu>
                </template>

                <template #language="{back}">
                    <FluxMenu>
                        <FluxMenuGroup>
                            <FluxMenuItem
                                icon-before="angle-left"
                                :label="t('global.back')"
                                @click="back()"/>
                        </FluxMenuGroup>

                        <FluxSeparator/>

                        <FluxMenuGroup>
                            <template
                                v-for="language of languages"
                                :key="language.code">
                                <FluxMenuItem
                                    :image-url="language.flag"
                                    :is-active="currentLanguage.code === language.code"
                                    :label="language.label"
                                    @click="setLanguage(language.code)"/>
                            </template>
                        </FluxMenuGroup>
                    </FluxMenu>
                </template>

                <template #appearance="{back}">
                    <FluxMenu>
                        <FluxMenuGroup>
                            <FluxMenuItem
                                icon-before="angle-left"
                                :label="t('global.back')"
                                @click="back()"/>
                        </FluxMenuGroup>

                        <FluxSeparator/>

                        <FluxMenuGroup>
                            <FluxMenuItem
                                :is-active="skin === 'light'"
                                icon-before="sun-alt"
                                :label="t('ui.profileMenu.theme.light')"
                                @click="uiStore.setSkin('light')"/>

                            <FluxMenuItem
                                :is-active="skin === 'dark'"
                                icon-before="moon"
                                :label="t('ui.profileMenu.theme.dark')"
                                @click="uiStore.setSkin('dark')"/>
                        </FluxMenuGroup>
                    </FluxMenu>
                </template>
            </FluxWindow>
        </template>
    </FluxFlyout>
</template>

<script
    lang="ts"
    setup>
    import { OrganizationService } from '@fancee/api';
    import { AuthUser, UserType } from '@fancee/data';
    import { computed, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRouter, useService } from '@/composable';
    import { ENVIRONMENT } from '@/data';
    import { languages } from '@/data/i18n';
    import { storeToRefs, useAuthStore, usePlatformStore, useUiStore } from '@/data/store';
    import { fullNameToInitials, handleUserLogout } from '@/util';

    const {t} = useI18n();
    const {getContract: getOrganizationContract} = useService(OrganizationService);
    const authStore = useAuthStore();
    const platformStore = usePlatformStore();
    const router = useRouter();
    const uiStore = useUiStore();
    const {user, manageableOrganizations} = storeToRefs(authStore);
    const {skin} = storeToRefs(uiStore);

    const activeOrganization = computed(() => {
        const _organizations = unref(manageableOrganizations) ?? [];
        const _user = unref(user);

        if (!_user || !_user.activeOrganizationId) {
            return null;
        }

        return _organizations.find(o => o.id === _user.activeOrganizationId) ?? null;
    });

    const currentLanguage = computed(() => languages.find(l => l.code === uiStore.language) ?? languages[0]);

    function setLanguage(language: string): void {
        uiStore.setLanguage(language);
    }

    async function setOrganization(organizationId: string): Promise<void> {
        const _user = unref(user);

        if (_user === null || organizationId === _user.activeOrganizationId) {
            return;
        }

        const newStoreUser = new AuthUser(
            _user.id,
            _user.email,
            _user.firstName,
            _user.lastName,
            _user.type,
            _user?.avatarFile,
            _user.lastLogin,
            _user.currency,
            [],
            _user.isProfileComplete,
            _user.changelogsSinceLastLogin,
            organizationId
        );

        const {data} = await getOrganizationContract(organizationId);
        await platformStore.setOrganizationContract(data);

        authStore.setUser(newStoreUser);

        router.go(0);
    }
</script>
