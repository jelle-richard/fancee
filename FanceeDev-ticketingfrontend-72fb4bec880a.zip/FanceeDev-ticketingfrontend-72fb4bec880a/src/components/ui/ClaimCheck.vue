<script lang="ts">
    import { computed, defineComponent, PropType, unref } from 'vue';
    import { Claim } from '@/data';
    import { storeToRefs, useAuthStore } from '@/data/store';

    export default defineComponent({
        props: {
            claim: {required: true, type: String as PropType<Claim>}
        },
        setup(props, {slots}) {
            const authStore = useAuthStore();
            const {claims} = storeToRefs(authStore);

            const hasClaim = computed(() => unref(claims).includes(props.claim));

            return () => unref(hasClaim) ? slots.default?.()[0] : null;
        }
    });
</script>
