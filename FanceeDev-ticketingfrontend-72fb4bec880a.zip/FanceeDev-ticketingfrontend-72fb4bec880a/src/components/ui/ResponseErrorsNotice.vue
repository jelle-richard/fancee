<template>
    <FluxNotice
        icon="circle-exclamation"
        :title="title ?? t('validation.errors.pleaseFixErrors')"
        variant="danger">
        <ul>
            <template v-for="(messages, code) of errors">
                <li
                    :key="`${code}/${index}`"
                    v-for="(message, index) of messages">
                    <strong>{{ code }}</strong>: {{ message }}
                </li>
            </template>
        </ul>
    </FluxNotice>
</template>

<script
    lang="ts"
    setup>
    import type { IResponseErrors } from '@fancee/client';
    import type { IconNames } from '@fancee/flux';
    import { useI18n } from 'vue-i18n';

    export interface Props {
        readonly errors: IResponseErrors | null;
        readonly icon?: IconNames;
        readonly title?: string;
    }

    withDefaults(defineProps<Props>(), {
        icon: 'circle-exclamation'
    });

    const {t} = useI18n();
</script>
