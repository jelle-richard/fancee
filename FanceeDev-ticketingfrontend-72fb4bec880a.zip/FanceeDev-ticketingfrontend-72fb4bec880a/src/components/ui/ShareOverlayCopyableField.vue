<template>
    <FluxFormField :label="label">
        <FluxFormInputGroup>
            <FluxFormInput
                class="share-field"
                is-readonly
                :model-value="text"/>

            <FluxSecondaryButton
                icon-before="clone"
                :label="t('global.copy')"
                tabindex="-1"
                @click="copy"/>
        </FluxFormInputGroup>
    </FluxFormField>
</template>

<script
    lang="ts"
    setup>
    import { showSnackbar } from '@fancee/flux';
    import { useI18n } from 'vue-i18n';

    export interface Emits {
        (e: 'copied'): void;
    }

    export interface Props {
        readonly label: string;
        readonly text: string;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {t} = useI18n();

    async function copy(): Promise<void> {
        await navigator.clipboard.writeText(props.text);

        emit('copied');

        showSnackbar({
            color: 'success',
            icon: 'clone',
            message: t('ui.shareOverlay.copied')
        });
    }
</script>

<style
    lang="scss"
    scoped>
    .share-field {
        font-family: monospace;
        font-size: 13px;
    }
</style>
