<template>
    <slot v-bind="{close, share}"/>

    <FluxOverlay
        is-closeable
        size="medium"
        @close="close">
        <FluxPane v-if="currentShareUrl">
            <FluxPaneHeader
                icon="share-from-square"
                :title="t('global.share')">
                <FluxSecondaryButton
                    icon-before="xmark"
                    @click="close"/>
            </FluxPaneHeader>

            <FluxVerticalWindowTransition>
                <FluxPaneBody
                    v-if="qrCodeVisible"
                    class="qrcode"
                    is-content-centered>
                    <div class="qr-contract-container">
                        <QRCode
                            level="H"
                            :size="180"
                            :value="currentShareUrl"/>
                    </div>
                </FluxPaneBody>

                <FluxPane v-else>
                    <FluxPaneBody class="share-channels">
                        <ShareOverlayChannel
                            icon="link-simple"
                            :name="t('ui.shareOverlay.newTab')"
                            :url="currentShareUrl"
                            @shared="close"/>

                        <ShareOverlayChannel
                            base-url="https://telegram.me/share/url?url="
                            icon="telegram"
                            name="Telegram"
                            :url="currentShareUrl"
                            @shared="close"/>

                        <ShareOverlayChannel
                            base-url="https://api.whatsapp.com/send?text="
                            icon="whatsapp"
                            name="WhatsApp"
                            :url="currentShareUrl"
                            @shared="close"/>

                        <ShareOverlayChannel
                            base-url="https://www.linkedin.com/shareArticle?url="
                            icon="linkedin"
                            name="LinkedIn"
                            :url="currentShareUrl"
                            @shared="close"/>

                        <ShareOverlayChannel
                            base-url="https://www.facebook.com/sharer/sharer.php?u="
                            icon="facebook"
                            name="Facebook"
                            :url="currentShareUrl"
                            @shared="close"/>

                        <ShareOverlayChannel
                            base-url="https://twitter.com/intent/tweet?text="
                            icon="x-twitter"
                            name="X (Twitter)"
                            :url="currentShareUrl"
                            @shared="close"/>

                        <ShareOverlayChannel
                            base-url="mailto:?body="
                            icon="envelope"
                            name="Email"
                            :url="currentShareUrl"
                            @shared="close"/>

                        <ShareOverlayOption
                            icon="qrcode"
                            :name="t('global.qrcode')"
                            @click="qrCodeVisible = true"/>
                    </FluxPaneBody>

                    <FluxPaneBody class="share-fields">
                        <ShareOverlayCopyableField
                            :label="t('ui.shareOverlay.copyUrl')"
                            :text="currentShareUrl"
                            @copied="close"/>

                        <ShareOverlayCopyableField
                            :label="t('ui.shareOverlay.copyFrameCode')"
                            :text="iframeCode"
                            @copied="close"/>
                    </FluxPaneBody>
                </FluxPane>
            </FluxVerticalWindowTransition>
        </FluxPane>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { computed, ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import QRCode from 'qrcode.vue';
    import ShareOverlayChannel from './ShareOverlayChannel.vue';
    import ShareOverlayCopyableField from './ShareOverlayCopyableField.vue';
    import ShareOverlayOption from './ShareOverlayOption.vue';

    export interface Props {
        readonly disableIframe?: boolean;
    }

    defineProps<Props>();

    const {t} = useI18n();

    const currentShareUrl = ref<string | null>(null);
    const qrCodeVisible = ref(false);

    const iframeCode = computed(() => `<iframe src="${currentShareUrl.value}" width="100%" height="100%" frameborder="0" scrolling="yes"/>`);

    function close(): void {
        currentShareUrl.value = null;
        qrCodeVisible.value = false;
    }

    function share(url: string): void {
        currentShareUrl.value = url;
        qrCodeVisible.value = false;
    }
</script>

<style
    lang="scss"
    scoped>
    .share-channels {
        display: grid;
        gap: 9px;
        grid-template-columns: repeat(4, 1fr);
    }

    .share-fields {
        display: flex;
        flex-flow: column;
        gap: 15px;
    }

    .qrcode {
        padding-top: 60px;
        padding-bottom: 60px;
    }

    .qr-contract-container {
        background-color: #fff;
        border-radius: var(--radius);
        //QRCode plugin automagically includes 6 dead pixels in the otherwise square, hence the padding shift.
        padding: 18px 18px 12px 18px;
    }
</style>
