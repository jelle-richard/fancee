<template>
    <FluxSecondaryButton
        v-bind="$props"
        :class="$style.featureButton"
        #label>
        <FluxIcon
            :class="$style.featureButtonIcon"
            :variant="icon"/>

        <div :class="$style.featureButtonLabel">
            <strong>{{ title }}</strong>
            <span>{{ description }}</span>
        </div>

        <FluxIcon
            :class="$style.featureButtonArrow"
            variant="right"/>
    </FluxSecondaryButton>
</template>

<script
    lang="ts"
    setup>
    import type { FluxRoutingLocation, IconNames } from '@fancee/flux';

    export interface Emits {
        (e: 'click', evt: MouseEvent): void;

        (e: 'mouseenter', evt: MouseEvent): void;

        (e: 'mouseleave', evt: MouseEvent): void;
    }

    export interface Props {
        readonly type?: 'button' | 'link' | 'route';
        readonly disabled?: boolean;
        readonly description: string;
        readonly icon?: IconNames | null;
        readonly title: string;
        readonly href?: string;
        readonly rel?: string;
        readonly target?: string;
        readonly to?: FluxRoutingLocation;
    }

    defineEmits<Emits>();
    defineProps<Props>();
</script>

<style module>
    .featureButton {
        height: unset;
        padding-left: 21px;
        padding-right: 21px;
    }

    .featureButtonArrow {
        color: var(--foreground-secondary);
    }

    .featureButtonIcon {
        color: rgb(var(--primary-7));
    }

    .featureButtonLabel {
        display: flex;
        padding: 12px 9px;
        flex-flow: column;
        flex-grow: 1;
        text-align: left;
    }
</style>
