<template>
    <FluxPaneHeader :title="title"/>

    <FluxPaneBody>
        <DetailList :class="$style.list">
            <slot/>
        </DetailList>
    </FluxPaneBody>
</template>

<script
    lang="ts"
    setup>
    import DetailList from './DetailList.vue';

    export type Props = {
        readonly title: string;
    };

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    .list {
        margin-top: -12px;
        margin-bottom: -12px;
    }
</style>
