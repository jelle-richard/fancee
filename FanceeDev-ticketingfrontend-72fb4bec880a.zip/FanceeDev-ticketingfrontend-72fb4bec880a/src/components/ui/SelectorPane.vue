<template>
    <FluxPane :class="$style.selector">
        <FluxPaneIllustration
            :class="$style.selectorIllustration"
            :animated-colors="ILLUSTRATION_ANIMATION_COLORS"
            :animated-seed="13"
            :animated-opacity="1"
            is-masked/>

        <FluxPaneBody :class="$style.selectorBody">
            <FluxFormColumn>
                <h2>{{ title }}</h2>

                <slot/>
            </FluxFormColumn>
        </FluxPaneBody>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { ILLUSTRATION_ANIMATION_COLORS } from '@/data';

    export type Props = {
        readonly title: string;
    };

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    .selector {
        position: relative;
        padding: 60px;
        text-align: center;
    }

    .selectorBody {
        margin: 0 auto;
        max-width: 540px;
    }

    .selectorIllustration {
        position: absolute;
        inset: 0;
        aspect-ratio: unset !important;
    }
</style>
