<template>
    <div :class="isSmall ? $style.listSmall : $style.listLarge">
        <slot/>
    </div>
</template>

<script
    lang="ts"
    setup>
    export type Props = {
        readonly isSmall?: boolean;
    };

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    .list {
        display: flex;
        flex-flow: column;
    }

    .listSmall {
        --height: 24px;
        --fontSize: 12px;

        composes: list;

        color: var(--foreground);
    }

    .listLarge {
        composes: list;

        color: var(--foreground-prominent);
    }

    .list > .list {
        margin-left: 9px;
        padding-top: 3px;

        &:not(:last-child) {
            padding-bottom: 3px;
        }
    }
</style>
