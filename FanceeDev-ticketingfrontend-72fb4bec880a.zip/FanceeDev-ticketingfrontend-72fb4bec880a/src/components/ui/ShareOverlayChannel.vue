<template>
    <ShareOverlayOption
        :icon="icon"
        :name="name"
        @click="onClick"/>
</template>

<script
    lang="ts"
    setup>
    import type { IconNames } from '@fancee/flux';
    import ShareOverlayOption from './ShareOverlayOption.vue';

    export interface Emits {
        (e: 'shared'): void;
    }

    export interface Props {
        readonly baseUrl?: string;
        readonly icon: IconNames;
        readonly name: string;
        readonly url: string;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    function onClick(): void {
        emit('shared');

        const baseUrl = props.baseUrl;
        let url = props.url;

        if (baseUrl) {
            url = `${baseUrl}${encodeURIComponent(url)}`;
        }

        window.open(url, '_blank');
    }
</script>
