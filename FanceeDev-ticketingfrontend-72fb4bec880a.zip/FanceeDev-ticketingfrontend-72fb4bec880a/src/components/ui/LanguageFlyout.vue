<template>
    <FluxFlyout>
        <template #opener="{open}">
            <FluxSecondaryButton
                :label="currentLanguage.label"
                @click="open()"
                #before>
                <img
                    :class="$style.flag"
                    :src="currentLanguage.flag"
                    :alt="currentLanguage.label">
            </FluxSecondaryButton>
        </template>

        <template #default="{close}">
            <FluxMenu>
                <FluxMenuGroup>
                    <FluxMenuItem
                        v-for="language of languages"
                        :image-url="language.flag"
                        :is-highlighted="locale === language.code"
                        :label="language.label"
                        @click="onLanguageClick(language.code, close)"/>
                </FluxMenuGroup>
            </FluxMenu>
        </template>
    </FluxFlyout>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { languages } from '@/data/i18n';
    import { useStore, useUiStore } from '@/data/store';
    import { computed, unref } from 'vue';

    const {locale} = useI18n();
    const {setLanguage} = useStore(useUiStore());

    const currentLanguage = computed(() => languages.find(l => l.code === unref(locale)) ?? languages[0]);

    function onLanguageClick(language: string, close: Function): void {
        close();
        setLanguage(language);
    }
</script>

<style
    lang="scss"
    module>
    .flag {
        height: 20px;
        width: 20px;
    }
</style>
