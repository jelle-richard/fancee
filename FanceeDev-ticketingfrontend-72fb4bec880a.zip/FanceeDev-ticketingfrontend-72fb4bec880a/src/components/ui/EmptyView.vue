<template>
    <div :class="$style.emptyView">
        <Visual
            :class="$style.emptyViewImage"
            :variant="variant"/>

        <div :class="$style.emptyViewContent">
            <h2>{{ title ?? t('ui.emptyView.title') }}</h2>
            <p>{{ message ?? t('ui.emptyView.message') }}</p>
        </div>

        <slot/>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { VisualSource } from './Visual';
    import Visual from './Visual.vue';

    export interface Props {
        readonly message?: string;
        readonly title?: string;
        readonly variant?: VisualSource;
    }

    withDefaults(defineProps<Props>(), {
        variant: 'retroMacError'
    });

    const {t} = useI18n();
</script>

<style module>
    .emptyView {
        display: flex;
        align-items: center;
        flex-flow: column;
        flex-grow: 1;
        gap: 30px;
        justify-content: center;
    }

    .emptyViewImage {
        max-height: 240px;
        max-width: 240px;
        width: calc(100dvw - 90px);
    }

    .emptyViewContent {
        display: flex;
        max-width: 720px;
        align-items: center;
        flex-flow: column;
        text-align: center;
        text-wrap: balance;

        :is(p) {
            font-size: 16px;
        }
    }

    @media (min-height: 840px) {
        .emptyViewImage {
            margin-top: -240px;
        }
    }
</style>
