<template>
    <slot v-bind="{close, showQr, title}"/>

    <FluxOverlay
        is-closeable
        size="small"
        @close="close">
        <FluxPane v-if="qrcode">
            <FluxPaneHeader
                icon="qrcode"
                :title="qrTitle === null ? t('global.qrcode') : qrTitle">
                <FluxSecondaryButton
                    icon-before="xmark"
                    @click="close"/>
            </FluxPaneHeader>

            <FluxPaneBody is-content-centered>
                <div class="qr-contract-container">
                    <QRCode
                        level="H"
                        :size="256"
                        :value="qrcode"/>
                </div>
            </FluxPaneBody>
        </FluxPane>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { ref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import QRCode from 'qrcode.vue';

    const {t} = useI18n();

    const qrcode = ref<string | null>(null);
    const qrTitle = ref<string | null>(null);

    function close(): void {
        qrcode.value = null;
    }

    function showQr(qr: string): void {
        qrcode.value = qr;
    }

    function title(title: string): void {
        qrTitle.value = title;
    }
</script>

<style
    lang="scss"
    scoped>
    .qr-contract-container {
        background-color: #fff;
        border-radius: var(--radius);
        //QRCode plugin automagically includes 6 dead pixels in the otherwise square, hence the padding shift.
        padding: 18px 18px 12px 18px;
    }
</style>
