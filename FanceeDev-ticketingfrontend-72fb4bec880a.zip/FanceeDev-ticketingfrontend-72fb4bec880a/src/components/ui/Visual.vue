<template>
    <img
        v-if="source"
        :src="source"
        alt="">
</template>

<script
    lang="ts"
    setup>
    import { computed } from 'vue';
    import { useUiStore } from '@/data/store';
    import { VisualSource, visualSources } from './Visual';

    export interface Props {
        readonly variant: VisualSource;
    }

    const props = defineProps<Props>();

    const source = computed(() => {
        const {skin} = useUiStore();
        const source = visualSources[props.variant];

        if (!source) {
            return null;
        }

        return source[skin === 'dark' ? 1 : 0];
    });
</script>
