<template>
    <FluxPane
        is-contained
        :is-loading="isLoading">
        <FluxPaneBody
            :gap="27"
            is-content-centered
            is-larger-padded>
            <FluxIcon
                :size="30"
                :variant="icon"
                style="color: rgb(var(--danger-7))"/>

            <div>
                <h2>{{ title }}</h2>
                <p>{{ explanation }}</p>
            </div>
        </FluxPaneBody>

        <form @submit.prevent="$emit('ok')">
            <slot/>
        </form>

        <FluxPaneFooter>
            <FluxButtonStack is-fill>
                <FluxSpacer/>

                <FluxPrimaryButton
                    :disabled="okDisabled"
                    icon-before="circle-check"
                    :label="okLabel ?? t('global.ok')"
                    @click="$emit('ok')"/>

                <FluxSecondaryButton
                    :label="t('global.cancel')"
                    @click="$emit('cancel')"/>
            </FluxButtonStack>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import type { IconNames } from '@fancee/flux';
    import { useI18n } from 'vue-i18n';

    export interface Emits {
        (e: 'ok'): void;

        (e: 'cancel'): void;
    }

    export interface Props {
        readonly explanation: string;
        readonly icon?: IconNames;
        readonly isLoading?: boolean;
        readonly okDisabled?: boolean;
        readonly okLabel?: string;
        readonly title: string;
    }

    defineEmits<Emits>();
    defineProps<Props>();

    const {t} = useI18n();
</script>
