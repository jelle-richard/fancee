<template>
    <FluxDropZone
        is-multiple
        @select="onFilesSelected"
        v-slot:default="{showPicker}">
        <FluxStack :gap="15">
            <FluxAspectRatio :aspect-ratio="21 / 8">
                <FluxPlaceholder
                    v-if="!hasImages"
                    :icon="icon"
                    :title="title"
                    :message="description">
                    <FluxSecondaryButton
                        :label="t('global.upload')"
                        @click="showPicker"/>
                </FluxPlaceholder>

                <FluxFader
                    v-else
                    :key="`header_editor_fader_${allImages.length}`"
                    :interval="FADER_INTERVAL_MS">
                    <template v-for="image of allImages">
                        <FluxFaderItem>
                            <FluxFocalPointImage
                                :focal-point="image.focalPoint"
                                :src="image.url"
                                alt=""/>
                        </FluxFaderItem>
                    </template>
                </FluxFader>

                <FluxButtonStack
                    v-if="hasImages"
                    class="header-images-editor-tools"
                    is-fill>
                    <template v-if="isEditing">
                        <FocalPointEditor
                            :label="t('ui.focalPoint.plural')"
                            :images="images"
                            @close="onFocalPointEditorClose"/>

                        <FluxSpacer/>

                        <FluxSecondaryButton
                            icon-before="arrow-up-from-line"
                            @click="showPicker"/>

                        <FluxSecondaryButton
                            icon-before="xmark"
                            @click="isEditing = false"/>
                    </template>

                    <template v-else>
                        <FluxSpacer/>

                        <FluxSecondaryButton
                            icon-before="pen"
                            @click="isEditing = true"/>
                    </template>
                </FluxButtonStack>
            </FluxAspectRatio>

            <FluxGallery
                v-if="isEditing"
                :key="`header_editor_gallery_${images.length}`"
                :pending-items="pendingImages.map(i => i.url)">
                <template
                    v-for="(image, index) of images"
                    :key="index">
                    <FluxGalleryItem
                        is-deletable
                        :focal-point="image.focalPoint"
                        :url="image.url"
                        @delete="$emit('delete', image)"/>
                </template>
            </FluxGallery>
        </FluxStack>
    </FluxDropZone>
</template>

<script
    lang="ts"
    setup>
    import { isDtoDirty, markDtoClean } from '@fancee/client';
    import { Media } from '@fancee/data';
    import { IconNames } from '@fancee/flux';
    import { computed, ref, toRefs, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { FocalPointEditor } from '@/components/ui';
    import { FADER_INTERVAL_MS } from '@/data';

    export interface Emits {
        (e: 'delete', media: Media): void;

        (e: 'upload', files: File[]): void;

        (e: 'focal-point', media: Media): void;
    }

    export interface Props {
        readonly icon: IconNames;
        readonly title: string;
        readonly description: string;
        readonly images: Media[];
        readonly pendingImages?: Media[];
        readonly isFocalPointsEnabled?: boolean;
    }

    const emit = defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        pendingImages: () => []
    });
    const {images, pendingImages} = toRefs(props);

    const {t} = useI18n();

    const isEditing = ref(false);

    const allImages = computed(() => [...unref(images), ...unref(pendingImages)]);
    const hasImages = computed(() => unref(images).length > 0 || unref(pendingImages).length > 0);

    function onFilesSelected(files: FileList): void {
        const images: File[] = [];

        for (let i = 0; i < files.length; ++i) {
            const file = files.item(i);

            if (!file || !file.type.startsWith('image/')) {
                continue;
            }

            images.push(file);
        }

        emit('upload', images);
    }

    function onFocalPointEditorClose(): void {
        for (const image of images.value) {
            if (!isDtoDirty(image)) {
                continue;
            }

            emit('focal-point', image);
            markDtoClean(image);
        }
    }

    watch(hasImages, hasImages => !hasImages && (isEditing.value = false));
</script>

<style lang="scss">
    .header-images-editor-tools {
        position: absolute;
        height: unset;
        max-width: calc(100% - 30px);
        left: 15px;
        right: 15px;
        bottom: 15px;
    }
</style>
