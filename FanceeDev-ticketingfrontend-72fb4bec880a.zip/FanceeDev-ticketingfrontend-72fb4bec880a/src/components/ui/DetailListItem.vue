<template>
    <div :class="$style.item">
        <span>{{ label }}</span>

        <span :class="$style.value">
            {{ typeof value === 'number' ? asFormattedNumber(value) : value }}
        </span>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { asFormattedNumber } from '@/util';

    export type Props = {
        readonly label: string;
        readonly value: string | number;
    };

    defineProps<Props>();
</script>

<style
    lang="scss"
    module>
    .item {
        display: flex;
        height: var(--height, 33px);
        margin-left: -12px;
        margin-right: -12px;
        padding-left: 12px;
        padding-right: 12px;
        align-items: center;
        gap: 15px;
        justify-content: space-between;
        border-radius: calc(var(--radius) / 2);
        font-size: var(--fontSize, 1rem);

        &:hover {
            background: rgb(var(--gray-2));
        }
    }

    .value {
        color: var(--foreground);
    }
</style>
