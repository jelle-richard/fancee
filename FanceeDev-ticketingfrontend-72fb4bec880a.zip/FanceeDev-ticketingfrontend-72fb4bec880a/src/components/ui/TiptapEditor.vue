<template>
    <div
        v-if="editor"
        class="flux-form-input"
        :class="$style.editor">
        <FluxToolbar :class="$style.editorToolbar">
            <FluxToolbarGroup>
                <FluxAction
                    :class="{[$style.actionIsActive]: editor.isActive('bold')}"
                    :disabled="!editor.can().chain().focus().toggleBold().run()"
                    icon="bold"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleBold().run()"/>

                <FluxAction
                    :class="{[$style.actionIsActive]: editor.isActive('italic')}"
                    :disabled="!editor.can().chain().focus().toggleItalic().run()"
                    icon="italic"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleItalic().run()"/>

                <FluxAction
                    :class="{[$style.actionIsActive]: editor.isActive('underline')}"
                    :disabled="!editor.can().chain().focus().toggleUnderline().run()"
                    icon="underline"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleUnderline().run()"/>

                <FluxAction
                    :class="{[$style.actionIsActive]: editor.isActive('strike')}"
                    :disabled="!editor.can().chain().focus().toggleStrike().run()"
                    icon="strikethrough"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleStrike().run()"/>
            </FluxToolbarGroup>

            <FluxSeparator axis="vertical"/>

            <FluxToolbarGroup>
                <FluxAction
                    :class="{[$style.actionIsActive]: editor.isActive('heading', {level: 1})}"
                    :disabled="!editor.can().chain().focus().toggleHeading({level: 1}).run()"
                    icon="h1"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleHeading({level: 1}).run()"/>

                <FluxAction
                    :class="{[$style.actionIsActive]: editor.isActive('heading', {level: 2})}"
                    :disabled="!editor.can().chain().focus().toggleHeading({level: 2}).run()"
                    icon="h2"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleHeading({level: 2}).run()"/>

                <FluxAction
                    :class="{[$style.actionIsActive]: editor.isActive('heading', {level: 3})}"
                    :disabled="!editor.can().chain().focus().toggleHeading({level: 3}).run()"
                    icon="h3"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleHeading({level: 3}).run()"/>
            </FluxToolbarGroup>

            <FluxSeparator axis="vertical"/>

            <FluxToolbarGroup>
                <FluxAction
                    icon="image"
                    tabindex="-1"
                    @click="onUploadImageClick()"/>

                <FluxAction
                    icon="code"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleCodeBlock().run()"/>
            </FluxToolbarGroup>

            <FluxSeparator axis="vertical"/>

            <FluxToolbarGroup>
                <FluxAction
                    icon="list-dots"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleBulletList().run()"/>

                <FluxAction
                    icon="list-numeric"
                    tabindex="-1"
                    @click="editor.chain().focus().toggleOrderedList().run()"/>
            </FluxToolbarGroup>

            <FluxSpacer/>

            <FluxToolbarGroup>
                <FluxAction
                    :disabled="!editor.can().chain().focus().undo().run()"
                    icon="undo"
                    tabindex="-1"
                    @click="editor.chain().focus().undo().run()"/>

                <FluxAction
                    :disabled="!editor.can().chain().focus().redo().run()"
                    icon="redo"
                    tabindex="-1"
                    @click="editor.chain().focus().redo().run()"/>
            </FluxToolbarGroup>
        </FluxToolbar>

        <EditorContent
            :class="$style.editorContent"
            :editor="editor"/>
    </div>
</template>

<script lang="ts">
    export default {
        model: {
            prop: 'model-value',
            event: 'update:model-value'
        }
    };
</script>

<script
    lang="ts"
    setup>
    import { default as ImageExtension } from '@tiptap/extension-image';
    import { default as UnderlineExtension } from '@tiptap/extension-underline';
    import { default as StarterKit } from '@tiptap/starter-kit';
    import { EditorContent, useEditor } from '@tiptap/vue-3';
    import { toRefs, unref, useCssModule, watch } from 'vue';

    export interface Emits {
        (e: 'update:model-value', value: string): void;
    }

    export interface Props {
        readonly modelValue: string;
    }

    const $style = useCssModule();

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {modelValue} = toRefs(props);

    const editor = useEditor({
        content: unref(modelValue),
        extensions: [
            StarterKit,
            ImageExtension.configure({
                allowBase64: true,
                HTMLAttributes: {
                    class: $style.editorContentImage
                }
            }),
            UnderlineExtension
        ],
        onUpdate: () => {
            const tiptap = unref(editor);

            if (!tiptap) {
                return;
            }

            emit('update:model-value', tiptap.getHTML());
        }
    });

    async function onUploadImageClick(): Promise<void> {
        const tiptap = unref(editor);

        if (!tiptap) {
            return;
        }

        const imageHandle = await new Promise<File | null>(resolve => {
            const input = document.createElement('input');
            input.accept = 'image/*';
            input.type = 'file';
            input.oncancel = () => resolve(null);
            input.onchange = () => resolve(input.files?.[0] ?? null);
            input.click();
        });

        if (!imageHandle) {
            return;
        }

        const src = await new Promise<string | null>(resolve => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result?.toString() ?? null);
            reader.readAsDataURL(imageHandle);
        });

        if (!src) {
            return;
        }

        tiptap.commands.setImage({src});
        tiptap.commands.focus('end');
    }

    watch(modelValue, () => {
        const tiptap = unref(editor);
        const value = unref(modelValue);

        if (!tiptap || value === tiptap.getHTML()) {
            return;
        }

        tiptap.commands.setContent(value, false);
    });
</script>

<style module>
    :global(.flux-button).actionIsActive {
        --button-background: rgb(var(--gray-10));
        --button-background-hover: rgb(var(--gray-9));
        --button-background-active: rgb(var(--gray-8));
        --button-foreground: rgb(var(--gray-0));
        --button-icon: rgb(var(--gray-0));
    }

    .editor {
        display: flex;
        height: unset;
        padding: 0;
        flex-flow: column;
        flex-grow: 1;
        contain: paint;
    }

    .editorContent {
        min-height: 126px;
        flex-grow: 1;
        word-break: break-word;

        :global(.tiptap) {
            height: 100%;
            min-height: inherit;
            padding: 15px;
            outline: 0;
        }
    }

    .editorContentImage {
        max-width: 100%;
        border-radius: calc(var(--radius) / 2);
        outline: 1px solid rgba(0, 0, 0, .025);
        outline-offset: -1px;

        &:global(.ProseMirror-selectednode) {
            outline: 2px solid rgb(var(--primary-6));
            outline-offset: 2px;
        }
    }

    .editorToolbar {
        padding: 9px 12px;
        background: rgb(var(--gray-1));
        border-bottom: 1px solid rgb(var(--gray-3));
        flex-wrap: wrap;
    }
</style>
