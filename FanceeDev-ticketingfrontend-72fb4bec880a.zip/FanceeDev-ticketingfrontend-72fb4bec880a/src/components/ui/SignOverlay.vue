<template>
    <FluxPane>
        <FluxPaneHeader
            icon="signature"
            :title="t('onboarding.agreement.signOverlayTitle')"/>

        <FluxPaneBody :class="$style.signatureContainer">
            <VueSignature
                ref="signpadRef"
                :class="$style.signature"
                @mousedown="validateSignature"
                @mouseup="validateSignature"
                @mousemove="validateSignature"
                @touchstart="validateSignature"
                @touchend="validateSignature"
                @touchmove="validateSignature"/>
        </FluxPaneBody>

        <FluxPaneBody>
            <FluxNotice
                icon="circle-info"
                is-small
                :message="t('onboarding.agreement.disclaimer')"/>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxSecondaryButton
                :label="t('global.clear')"
                @click="onClearClick()"/>

            <FluxSpacer/>

            <FluxSecondaryButton
                :label="t('global.cancel')"
                @click="onCancelClick()"/>

            <FluxPrimaryButton
                :disabled="isSignpadEmpty"
                icon-before="circle-check"
                :label="t('onboarding.agreement.sign')"
                @click="onSignClick()"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { defineAsyncComponent, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { convertBase64ToBlob } from '@/util';

    const VueSignature = defineAsyncComponent(() => import('vue3-signature'));

    const emit = defineEmits<{
        (e: 'close'): void;

        (e: 'save', signatureBlob: Blob): void;
    }>();

    const {t} = useI18n();

    const signpadRef = ref<SignpadRef>();
    const isSignpadEmpty = ref(true);

    function validateSignature(): void {
        isSignpadEmpty.value = unref(signpadRef)?.isEmpty() ?? true;
    }

    function onCancelClick(): void {
        emit('close');
    }

    function onClearClick(): void {
        isSignpadEmpty.value = true;
        unref(signpadRef)?.clear();
    }

    function onSignClick(): void {
        const signpad = unref(signpadRef);

        if (!signpad || signpad.isEmpty()) {
            return;
        }

        const dataUri = signpad.save('image/png');

        if (!dataUri) {
            return;
        }

        const [, base64] = dataUri.split(',');

        if (!base64) {
            return;
        }

        emit('save', convertBase64ToBlob(base64, 'image/png'));
    }

    type SignpadRef = {
        clear: () => void;
        save: (format?: 'image/png' | 'image/svg+xml') => string;
        isEmpty: () => boolean;
    };
</script>

<style module>
    .signature {
        border: 2px solid rgb(var(--gray-3));
        border-radius: var(--radius);
        contain: paint;
    }

    .signatureContainer {
        aspect-ratio: 3 / 2;
        max-width: 100%;
    }
</style>
