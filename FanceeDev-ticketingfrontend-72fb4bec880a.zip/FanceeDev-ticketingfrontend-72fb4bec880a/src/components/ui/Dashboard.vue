<template>
    <FluxDashboard>
        <template #header>
            <FluxDashboardHeader :title="t(routeMeta?.title ?? '...')">
                <template #end>
                    <FluxSecondaryButton
                        v-if="userType === UserType.Admin"
                        icon-before="earth-europe"
                        @click="isOverlayVisible = true">
                        <template #after>
                            <FluxBadge :label="selectedCountries.length === 1 ? selectedCountries[0] : selectedCountries.length"/>
                        </template>
                    </FluxSecondaryButton>

                    <DashboardProfileMenu/>
                </template>
            </FluxDashboardHeader>
        </template>

        <template #navigation>
            <DashboardNavigation/>
        </template>

        <template #notice>
            <FluxNotice
                v-if="isAccountTakeover"
                is-center
                is-fluid
                is-small
                icon="circle-exclamation"
                variant="warning">
                <p>
                    {{ t('ui.accountTakeoverNotice.info', [accountTakeoverEmail]) }}
                    <a
                        v-if="user"
                        href="#"
                        @click.prevent="switchBackToAdmin(router, user)">
                        {{ t('ui.accountTakeoverNotice.switchBack', [accountTakeoverAdminEmail]) }}
                    </a>
                </p>
            </FluxNotice>
        </template>

        <RouterView #default="{Component}">
            <Component :is="Component"/>
        </RouterView>
    </FluxDashboard>

    <FluxOverlay size="small">
        <ReauthenticateOverlay v-if="isReauthenticateVisible"/>
    </FluxOverlay>

    <FluxOverlay
        v-if="userType === UserType.Admin"
        is-closeable
        size="large"
        @close="isOverlayVisible = false">
        <CountrySelectorOverlay
            v-if="isOverlayVisible"
            @selected-countries="setSelectedCountries"
            @close="isOverlayVisible = false"/>
    </FluxOverlay>
</template>

<script
    lang="ts"
    setup>
    import { CountryCode, UserType } from '@fancee/data';
    import { computed, onMounted, ref, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { CountrySelectorOverlay, ReauthenticateOverlay } from '@/components/ui';
    import { useRouteMeta, useRouter } from '@/composable';
    import { useAuthStore, useStore, useUiStore } from '@/data/store';
    import { switchBackToAdmin } from '@/util';
    import DashboardNavigation from './DashboardNavigation.vue';
    import DashboardProfileMenu from './DashboardProfileMenu.vue';

    const routeMeta = useRouteMeta();
    const router = useRouter();
    const {t} = useI18n();
    const {adminTokenResponse, isAccountTakeover, isReauthenticateVisible, user, userType} = useStore(useAuthStore());
    const {allowedCountries} = useStore(useUiStore());

    const isOverlayVisible = ref(false);
    const selectedCountries = ref<CountryCode[]>([]);

    const accountTakeoverEmail = computed(() => unref(user)?.email ?? '');
    const accountTakeoverAdminEmail = computed(() => unref(adminTokenResponse)?.user.email ?? '');

    onMounted(() => selectedCountries.value = unref(allowedCountries));

    function setSelectedCountries(countries: CountryCode[]): void {
        selectedCountries.value = countries;
    }
</script>
