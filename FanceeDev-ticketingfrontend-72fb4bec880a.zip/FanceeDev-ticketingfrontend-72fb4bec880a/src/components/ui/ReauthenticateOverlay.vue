<template>
    <FluxPane :is-loading="isLoading">
        <FluxPaneBody
            :gap="27"
            is-content-centered
            is-larger-padded>
            <FluxIcon
                :size="30"
                variant="lock"
                style="color: rgb(var(--danger-7))"/>

            <div>
                <h2>{{ t('auth.reauthenticate.title') }}</h2>
                <p>{{ t('auth.reauthenticate.body') }}</p>
            </div>
        </FluxPaneBody>

        <FluxPaneBody>
            <FluxFormColumn>
                <CombinedFormNotice/>

                <FluxFormField :label="t('form.field.email')">
                    <FluxFormInput
                        is-disabled
                        :model-value="user?.email"/>
                </FluxFormField>

                <ValidationField
                    :label="t('form.field.password')"
                    :rules="{required}"
                    :value="state.password">
                    <FluxFormInput
                        v-model="state.password"
                        auto-focus
                        type="password"/>
                </ValidationField>
            </FluxFormColumn>
        </FluxPaneBody>

        <FluxPaneFooter>
            <FluxButtonStack
                axis="vertical"
                is-fill>
                <FluxPrimaryButton
                    :disabled="invalid"
                    icon-after="circle-arrow-right"
                    :label="t('auth.reauthenticate.submit')"
                    @click="validated(onSignInClick)"/>

                <FluxSecondaryButton
                    :label="t('global.cancel')"
                    @click="onCancelClick()"/>
            </FluxButtonStack>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { AuthService } from '@fancee/api';
    import { useI18n } from 'vue-i18n';
    import { reactive, unref } from 'vue';
    import { CombinedFormNotice, ValidationField } from '@/components/form';
    import { useActiveOrganizationId, useLoaded, useRequestErrorBoundary, useRouter, useService, useValidationScope } from '@/composable';
    import { useAuthStore, useStore } from '@/data/store';
    import { required } from '@/data/validation';
    import { AuthUser } from '@fancee/data';

    const {t} = useI18n();
    const {isLoading, loaded} = useLoaded();
    const {reset: resetErrors} = useRequestErrorBoundary();
    const {login} = useService(AuthService);
    const {hideReauthenticateOverlay, login: storeLogin, logout, user} = useStore(useAuthStore());
    const {invalid, validated} = useValidationScope();
    const organizationId = useActiveOrganizationId();
    const router = useRouter();

    const _login = loaded(login);

    const state = reactive({
        password: ''
    });

    async function onCancelClick(): Promise<void> {
        hideReauthenticateOverlay();
        logout();

        await router.push({
            name: 'auth-login'
        });
    }

    async function onSignInClick(): Promise<void> {
        resetErrors();

        const _user = unref(user);

        if (!_user) {
            return await onCancelClick();
        }

        const {data} = await _login(_user.email, state.password);

        const newStoreUser = new AuthUser(
            data.user.id,
            data.user.email,
            data.user.firstName,
            data.user.lastName,
            data.user.type,
            data.user.avatarFile,
            data.user.lastLogin,
            data.user.currency,
            [],
            data.user.isProfileComplete,
            data.user.changelogsSinceLastLogin,
            unref(organizationId)
        );

        storeLogin(
            data.claims,
            data.token,
            newStoreUser,
            data.manageableOrganizations,
            data.validUntil,
            null
        );

        hideReauthenticateOverlay();
        router.go(0);
    }
</script>
