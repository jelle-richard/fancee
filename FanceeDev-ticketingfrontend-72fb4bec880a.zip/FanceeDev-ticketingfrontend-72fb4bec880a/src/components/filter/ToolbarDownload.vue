<template>
    <FluxSecondaryButton
        :label="t('global.download')"
        icon-before="arrow-down-to-line"
        :is-loading="isLoading"
        @click="onClick()"/>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';

    export interface Emits {
        (e: 'download'): void;
    }

    export interface Props {
        readonly isLoading?: boolean;
    }

    const emit = defineEmits<Emits>();
    withDefaults(defineProps<Props>(), {
        isLoading: false
    });

    const {t} = useI18n();

    function onClick(): void {
        emit('download');
    }
</script>
