<template>
    <FluxFormInput
        v-model="localValue"
        auto-complete="off"
        :placeholder="placeholder"
        type="search"
        icon-before="magnifying-glass"/>
</template>

<script lang="ts">
    export default {
        model: {
            prop: 'model-value',
            event: 'update:model-value'
        }
    };
</script>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref, watch } from 'vue';

    export interface Emits {
        (e: 'update:model-value', value: string): void;
    }

    export interface Props {
        readonly modelValue: string;
        readonly placeholder: string;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();

    const {modelValue} = toRefs(props);

    const localValue = ref<string>(unref(modelValue));

    watch(modelValue, modelValue => {
        localValue.value = modelValue;
    });

    watch(localValue, localValue => {
        emit('update:model-value', localValue);
    });
</script>
