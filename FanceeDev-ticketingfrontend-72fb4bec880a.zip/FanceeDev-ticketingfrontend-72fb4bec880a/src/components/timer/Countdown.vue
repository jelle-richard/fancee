<template>
    <time v-if="!isFinished">
        {{ remainingTime }}
    </time>
    <span v-else>
        <slot name="expired">
            {{ t('global.expired') }}
        </slot>
    </span>
</template>

<script
    lang="ts"
    setup>
    import { DateTime } from 'luxon';
    import { computed, onMounted, ref, toRefs, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { padNumberStart } from '@/util';

    export interface Emits {
        (e: 'finished'): void;
    }

    export interface Props {
        readonly endDate: DateTime;
        readonly description?: string | null;
    }

    const emit = defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        description: null
    });
    const {endDate} = toRefs(props);

    const {t} = useI18n();

    const now = ref(DateTime.utc());

    const isFinished = computed(() => unref(now) >= unref(endDate));
    const remainingTime = computed(() => {
        let milliseconds = unref(endDate).diff(unref(now)).milliseconds;

        let seconds = Math.floor(milliseconds / 1000);
        let minutes = Math.floor(seconds / 60);
        let hours = Math.floor(minutes / 60);
        let days = Math.floor(hours / 24);

        seconds = seconds % 60;
        minutes = minutes % 60;
        hours = hours % 24;

        if (days < 1 && hours < 2) {
            return t('ui.countdown.expiresInWithHours', [padNumberStart(hours, 2), padNumberStart(minutes, 2), padNumberStart(seconds, 2)]);
        } else if (days < 1 && hours < 1) {
            return t('ui.countdown.expiresIn', [padNumberStart(minutes, 2), padNumberStart(seconds, 2)]);
        } else if (days < 1) {
            return t('ui.countdown.expiresInHours', hours);
        }

        return t('ui.countdown.expiresInDays', days);
    });

    onMounted(() => schedule());

    function schedule(): void {
        window.setTimeout(() => requestAnimationFrame(() => {
            now.value = DateTime.utc();

            if (unref(isFinished)) {
                emit('finished');
                return;
            }

            schedule();
        }), 1000);
    }
</script>
