<template>
    <FluxNoticeStack v-if="invalid || hasErrors || $slots.default">
        <ValidationNotice/>

        <template v-for="requestError of requestErrors">
            <FluxNotice
                icon="circle-exclamation"
                is-small
                :message="requestError"
                variant="danger"/>
        </template>

        <slot/>
    </FluxNoticeStack>
</template>

<script
    lang="ts"
    setup>
    import { computed, unref } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useRequestErrorBoundary, useValidationScope } from '@/composable';
    import ValidationNotice from './ValidationNotice.vue';

    const {t, te} = useI18n();
    const {errors, hasErrors} = useRequestErrorBoundary();
    const {invalid} = useValidationScope();

    const requestErrors = computed(() => {
        const errs = unref(errors);

        if (!errs) {
            return;
        }

        return Object.entries(errs).map(([code, messages]) => {
            const key = `errors_${code.toLowerCase().replaceAll('-', '_')}`;

            if (te(key)) {
                return t(key);
            }

            return `${messages.join(' ')} (${code})`;
        });
    });
</script>
