<template>
    <div class="flux-expandable">
        <button
            class="flux-expandable-header"
            @click="toggle">
            <span>{{ label }}</span>

            <FluxFadeTransition>
                <FluxIcon
                    v-if="invalid"
                    :class="$style.invalid"
                    :size="16"
                    variant="circle-exclamation"/>
            </FluxFadeTransition>

            <FluxSpacing :size="4"/>

            <FluxFadeTransition>
                <FluxIcon
                    :key="isOpen"
                    :size="16"
                    :variant="isOpen ? 'minus' : 'plus'"/>
            </FluxFadeTransition>
        </button>

        <FluxAutoHeightTransition>
            <div
                v-show="isOpen"
                class="flux-expandable-body">
                <div class="flux-expandable-content">
                    <slot/>
                </div>
            </div>
        </FluxAutoHeightTransition>
    </div>
</template>

<script
    lang="ts"
    setup>
    import { useComponentId, useExpandableGroupInjection } from '@fancee/flux';
    import { useVuelidate } from '@vuelidate/core';
    import { getCurrentInstance, onBeforeMount, onUnmounted, ref, unref, watchEffect } from 'vue';

    export interface Emits {
        (e: 'toggle', isOpen: boolean): void;
    }

    export interface Props {
        readonly label: string;
    }

    const emit = defineEmits<Emits>();
    defineProps<Props>();

    const {closeAll, register, unregister} = useExpandableGroupInjection();
    const id = useComponentId();
    const instance = getCurrentInstance()!;
    const v$ = useVuelidate();

    onBeforeMount(() => register?.(unref(id), instance));
    onUnmounted(() => unregister?.(unref(id)));

    const invalid = ref(false);
    const isOpen = ref(false);

    function close(): void {
        isOpen.value = false;
        emit('toggle', isOpen.value);
    }

    function open(): void {
        closeAll?.();
        isOpen.value = true;
        emit('toggle', isOpen.value);
    }

    function toggle(): void {
        if (isOpen.value) {
            close();
        } else {
            open();
        }
    }

    watchEffect(() => {
        invalid.value = Object.values(unref(v$).$silentErrors).length > 0;
    });

    defineExpose({
        isOpen,
        close,
        open,
        toggle
    });
</script>

<style module>
    .invalid {
        color: rgb(var(--danger-7));
    }
</style>
