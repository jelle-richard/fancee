<template>
    <FluxFormInput
        v-model="localValue"
        :placeholder="t('form.egValue', [asMoney(500, currency)])"
        @blur="onBlur()"/>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, unref, watchEffect } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { useCurrency } from '@/composable';
    import { asMoney, decimalToCents } from '@/util';

    export interface Emits {
        (e: 'update:modelValue', modelValue: number | null): void;
    }

    export interface Props {
        readonly modelValue: number | null;
    }

    const emit = defineEmits<Emits>();
    const props = defineProps<Props>();
    const {modelValue} = toRefs(props);

    const {t} = useI18n();
    const currency = useCurrency();

    const localValue = ref('');

    function onBlur(): void {
        const value = unref(localValue);

        if (!value) {
            return;
        }

        const matches = value.match(/[\d,.]+/);

        if (!matches || !matches[0]) {
            emit('update:modelValue', null);
            return;
        }

        const parts = new Intl.NumberFormat(navigator.language, {
            currency: unref(currency).shortCode,
            style: 'currency'
        }).formatToParts(1000000.5); // note(Bas): just a random number containing both a thousand and decimal separator.

        let decimalSeparator = parts.find(p => p.type === 'decimal')?.value ?? null;
        let thousandSeparator = parts.find(p => p.type === 'group')?.value ?? null;

        const decimalIsMoreFrequent = decimalSeparator && thousandSeparator && matches[0].split(decimalSeparator).length > matches[0].split(thousandSeparator).length;
        const decimalOccursFirst = decimalSeparator && thousandSeparator && matches[0].indexOf(thousandSeparator) > matches[0].indexOf(decimalSeparator);

        if (decimalIsMoreFrequent && decimalOccursFirst) {
            [decimalSeparator, thousandSeparator] = [thousandSeparator, decimalSeparator];
        }

        let userValue = matches[0];
        thousandSeparator && (userValue = userValue.replaceAll(thousandSeparator, ''));
        decimalSeparator && (userValue = userValue.replaceAll(decimalSeparator, '.'));

        const decimalValue = Number(userValue);
        const centsValue = decimalToCents(decimalValue, unref(currency));

        setLocalValue(centsValue);

        emit('update:modelValue', centsValue);
    }

    function setLocalValue(value: number | null): void {
        if (value || value === 0) {
            localValue.value = asMoney(value, unref(currency));
        } else {
            localValue.value = '';
        }
    }

    watchEffect(() => {
        setLocalValue(unref(modelValue));
    });
</script>
