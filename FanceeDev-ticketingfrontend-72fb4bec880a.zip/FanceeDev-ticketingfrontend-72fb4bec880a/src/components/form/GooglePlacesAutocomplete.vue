<template>
    <FluxNotice
        v-if="didMountFail"
        icon="circle-exclamation"
        is-small
        :message="t('ui.googlePlacesAutocomplete.failed')"
        variant="danger"/>

    <FluxFormInput
        v-else
        v-model="autocompleteText"
        ref="inputRef"
        :="$attrs"
        auto-complete="off"
        icon-before="magnifying-glass"
        :is-disabled="isDisabled"
        :placeholder="placeholder"
        @blur="onPlaceChanged"/>

    <FluxFormFieldAddition
        v-if="hasInvalidLocation"
        icon="circle-exclamation"
        mode="error"
        :message="t('ui.googlePlacesAutocomplete.invalid')"/>
</template>

<script
    lang="ts"
    setup>
    import { Address, CountryCode } from '@fancee/data';
    import { ComponentPublicInstance, computed, onMounted, ref, unref, watch } from 'vue';
    import { useI18n } from 'vue-i18n';

    export interface Emits {
        (e: 'address-changed', address: Address): void;

        (e: 'change', value: string): void;

        (e: 'place-changed', place: google.maps.places.PlaceResult, address: Address): void;
    }

    export interface Props {
        readonly isDisabled?: boolean;
        readonly placeholder?: string;
        readonly types?: string[];
        readonly value?: string;
    }

    defineOptions({inheritAttrs: false});

    const emit = defineEmits<Emits>();
    const props = withDefaults(defineProps<Props>(), {
        types: () => ['address']
    });

    const {t} = useI18n();

    const autocomplete = ref<google.maps.places.Autocomplete>();
    const autocompleteText = ref('');
    const didMountFail = ref(false);
    const hasInvalidLocation = ref(false);
    const inputRef = ref<ComponentPublicInstance>();

    const inputElement = computed(() => unref(inputRef)!.$el.querySelector('input') as HTMLInputElement);

    onMounted(() => {
        if (typeof google === 'undefined') {
            didMountFail.value = true;
            return;
        }

        const googleMapsAutocomplete = new google.maps.places.Autocomplete(unref(inputElement), {
            types: props.types
        });

        googleMapsAutocomplete.setFields(['address_components', 'adr_address', 'alt_id', 'formatted_address', 'geometry', 'icon', 'id', 'name', 'business_status', 'photo', 'place_id', 'scope', 'type', 'url', 'utc_offset_minutes', 'vicinity']);
        googleMapsAutocomplete.addListener('place_changed', onPlaceChanged);

        autocomplete.value = googleMapsAutocomplete;
        autocompleteText.value = props.value ?? '';
    });

    function onPlaceChanged(): void {
        if (unref(autocompleteText).trim().length === 0) {
            emit('address-changed', Address.empty());
            hasInvalidLocation.value = false;
            return;
        }

        const place: google.maps.places.PlaceResult = autocomplete.value!.getPlace();

        if (!place || !place.geometry || !place.address_components) {
            emit('address-changed', Address.empty());
            hasInvalidLocation.value = true;
            return;
        }

        const address = convertPlaceToAddress(place);

        if (isInvalidAddress(address)) {
            emit('address-changed', Address.empty());
            hasInvalidLocation.value = true;
            return;
        }

        hasInvalidLocation.value = false;

        emit('address-changed', address);
        emit('place-changed', place, address);

        autocompleteText.value = unref(unref(inputElement)).value;
    }

    function convertPlaceToAddress(place: google.maps.places.PlaceResult): Address {
        const value = (type: string, variant: 'long_name' | 'short_name'): string | null => {
            const index = place.address_components!.findIndex(ac => ac.types.includes(type));

            if (index === -1) {
                return null;
            }

            return place.address_components![index][variant];
        };

        const result = Address.empty();
        result.latitude = place.geometry?.location?.lat() || null;
        result.longitude = place.geometry?.location?.lng() || null;
        result.street = value('route', 'long_name');
        result.houseNumber = value('street_number', 'long_name');
        result.city = value('locality', 'long_name');
        result.postalCode = value('postal_code', 'long_name');

        const countryCode = value('country', 'short_name');
        if (countryCode) {
            result.countryCode = countryCode as CountryCode;
        }

        return result;
    }

    function isInvalidAddress(address: Address): boolean {
        return address.street === null
            || address.countryCode === null
            || address.city === null;
    }

    watch(autocompleteText, autocompleteText => emit('change', autocompleteText));

    watch(() => props.value, value => value && (autocompleteText.value = value), {immediate: true});
</script>
