<template>
    <FluxPaneBody v-if="paneBody && invalid">
        <FluxNotice
            icon="circle-exclamation"
            is-small
            :message="message ?? t('validation.errors.message')"
            variant="danger">
        </FluxNotice>
    </FluxPaneBody>

    <FluxNotice
        v-else-if="invalid"
        icon="circle-exclamation"
        is-small
        :message="message ?? t('validation.errors.message')"
        variant="danger">
    </FluxNotice>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { useValidationScope } from '@/composable';

    export interface Props {
        readonly message?: string;
        readonly paneBody?: boolean;
    }

    defineProps<Props>();

    const {t} = useI18n();
    const {invalid} = useValidationScope();
</script>
