<template>
    <FluxFormField
        :current-length="currentLength"
        :error="error"
        :hint="hint"
        :is-optional="isOptional"
        :label="label"
        :max-length="maxLength">
        <slot/>
    </FluxFormField>
</template>

<script
    lang="ts"
    setup>
    import { useVuelidate, type ValidationRuleCollection } from '@vuelidate/core';
    import { computed, onMounted, toRefs, unref, watch } from 'vue';
    import { useValidationScope } from '@/composable';

    export interface Props {
        readonly currentLength?: number;
        readonly hint?: string;
        readonly isOptional?: boolean;
        readonly label: string;
        readonly maxLength?: number;
        readonly rules: ValidationRuleCollection;
        readonly value?: unknown;
    }

    const props = defineProps<Props>();
    const {rules, value} = toRefs(props);

    const {live} = useValidationScope();
    const v$ = useVuelidate(
        {localValue: rules},
        {localValue: value}
    );

    onMounted(() => {
        if (Object.entries(unref(rules)).length > 0) {
            return;
        }

        throw new Error('Validation field used without any validation rules.');
    });

    const error = computed(() => {
        const value = unref(v$).localValue;

        if (value.$errors.length === 0) {
            return undefined;
        }

        return value.$errors.map(e => e.$message).join(' ');
    });

    watch(value, () => unref(live) && unref(v$).$validate());
</script>
