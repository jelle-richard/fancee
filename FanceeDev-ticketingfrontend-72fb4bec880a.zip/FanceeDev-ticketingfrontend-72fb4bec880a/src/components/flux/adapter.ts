import { FluxFormSelectGroup, FluxFormSelectOption } from '@fancee/flux';
import { EventCategory } from '@/data/dto/event';

export class FluxAdapter {
    public static parseEventCategoriesToSelectOption(categories: EventCategory[]): (FluxFormSelectGroup | FluxFormSelectOption)[] {
        const selectRows: (FluxFormSelectGroup | FluxFormSelectOption)[] = [];

        categories
            .filter(category => category.children !== null)
            .forEach(category => {
                selectRows.push({
                    icon: category.icon || null,
                    label: category.name
                });

                for (const child of category.children!) {
                    selectRows.push({
                        id: child.name,
                        label: child.name
                    });
                }
            });

        return selectRows;
    }
}
