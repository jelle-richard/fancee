<template>
    <FluxContainer class="wizard-view">
        <WizardStepper v-if="steps.length > 0">
            <WizardStepperItem
                v-for="step of steps"
                :key="step.routeName"
                :active="isActive(step)"
                :done="isDone(step)"
                :step="step"
                :visited="isEdit || isVisited(step)"/>
        </WizardStepper>

        <FluxSpinner v-if="isLoading"/>

        <slot v-else/>
    </FluxContainer>
</template>

<script
    lang="ts"
    setup>
    import { ref, toRefs, watch } from 'vue';
    import { useRouteName } from '@/composable';
    import { WizardStep } from '@/data/wizard';
    import WizardStepper from './WizardStepper.vue';
    import WizardStepperItem from './WizardStepperItem.vue';

    interface Props {
        readonly isEdit?: boolean;
        readonly isLoading?: boolean;
        readonly steps: WizardStep[];
    }

    const props = defineProps<Props>();

    const {steps} = toRefs(props);

    const routeName = useRouteName();

    const visitedRouteNames = ref(new Set<string>());

    function isActive(step: WizardStep): boolean {
        return step.routeName === routeName.value;
    }

    function isDone(step: WizardStep): boolean {
        if (isActive(step)) {
            return false;
        }

        for (const s of steps.value) {
            if (s.routeName === step.routeName) {
                return true;
            }

            if (isActive(s)) {
                break;
            }
        }

        return false;
    }

    function isVisited(step: WizardStep): boolean {
        return visitedRouteNames.value.has(step.routeName);
    }

    watch(routeName, routeName => {
        if (!routeName) {
            return;
        }

        visitedRouteNames.value.add(routeName);
    });

    watch(steps, steps => {
        visitedRouteNames.value.clear();

        for (const step of steps) {
            visitedRouteNames.value.add(step.routeName);

            if (isActive(step)) {
                break;
            }
        }
    }, {immediate: true});
</script>

<style
    lang="scss"
    scoped>
    .wizard-view {
        display: flex;
        flex-flow: column;
        gap: 30px;
    }

    html:not([md]) .wizard-view {
        padding-left: 0;
        padding-right: 0;
    }
</style>
