<template>
    <RouterLink
        :to="{name: step.routeName, params: step.routeParams}"
        class="wizard-stepper-item"
        :class="{
            'wizard-stepper-item-active': active,
            'wizard-stepper-item-done': done,
            'wizard-stepper-item-visited': visited
        }">
        <div class="wizard-stepper-item-icon">
            <FluxIcon
                :size="18"
                :variant="step.icon"/>

            <div
                v-if="done"
                class="wizard-stepper-item-check">
                <FluxIcon
                    :size="10"
                    variant="circle-check"/>
            </div>
        </div>

        <FluxAutoWidthTransition>
            <div
                v-if="active"
                class="wizard-stepper-item-label">
                <span>{{ t(step.label) }}</span>
            </div>
        </FluxAutoWidthTransition>
    </RouterLink>
</template>

<script
    lang="ts"
    setup>
    import { useI18n } from 'vue-i18n';
    import { WizardStep } from '@/data/wizard';

    interface Props {
        readonly active?: boolean;
        readonly done?: boolean;
        readonly visited?: boolean;
        readonly step: WizardStep;
    }

    defineProps<Props>();

    const {t} = useI18n();
</script>

<style
    lang="scss"
    scoped>
    .wizard-stepper-item {
        position: relative;
        display: flex;
        padding: 0;
        align-items: center;
        background: unset;
        border: 0;
        color: var(--foreground);
        cursor: pointer;
        text-decoration: unset;

        --color: rgb(var(--gray-4));
        --color-hover: rgb(var(--gray-5));
        --icon: var(--foreground);

        &-check {
            position: absolute;
            display: flex;
            height: 18px;
            width: 18px;
            right: -3px;
            bottom: -3px;
            align-items: center;
            justify-content: center;
            background: #16b364;
            border: 2px solid var(--background);
            border-radius: 9px;
            color: white;
        }

        &-icon {
            position: relative;
            display: flex;
            height: 42px;
            width: 42px;
            align-items: center;
            justify-content: center;
            background: var(--color);
            border-radius: var(--radius);
            color: var(--icon);
        }

        &-label {
            font-weight: 700;
            transition: width 300ms var(--swift-out), opacity 300ms var(--swift-out) 150ms;

            &.v-enter,
            &.v-leave-to {
                opacity: 0;
            }

            &.v-enter-to,
            &.v-leave {
                opacity: 1;
            }

            &.v-leave-active {
                transition-delay: 0s;
            }

            span {
                display: inline-block;
                margin-left: 15px;
            }
        }

        &:hover &-icon {
            background: var(--color-hover);
        }

        &:not(&-visited) {
            pointer-events: none;
        }

        &-active,
        &-done {
            --color: rgb(var(--primary-7));
            --color-hover: rgb(var(--primary-8));
            --icon: rgb(var(--primary-0));
        }
    }
</style>
