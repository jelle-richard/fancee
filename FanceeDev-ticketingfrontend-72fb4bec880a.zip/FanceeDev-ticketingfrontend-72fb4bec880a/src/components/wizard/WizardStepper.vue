<template>
    <nav class="wizard-stepper">
        <slot/>
    </nav>
</template>

<style
    lang="scss"
    scoped>
    .wizard-stepper {
        display: flex;
        gap: 21px;
    }
</style>
