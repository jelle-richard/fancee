export { default as SessionsDataTable } from './SessionsDataTable.vue';
