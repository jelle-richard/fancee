<template>
    <FluxPane is-contained>
        <FluxActionBar
            v-if="false"
            #search>
            <ToolbarSearch
                v-model="search"
                :placeholder="t('auth.sessions.search')"/>
        </FluxActionBar>

        <FluxDataTable
            :is-loading="isLoading"
            :data-set="sessions"
            :page="currentPage"
            :per-page="pageLength"
            :total="sessions.length"
            is-hoverable>
            <template #header>
                <FluxTableHeader>{{ t('auth.sessions.device') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('auth.sessions.ipAddress') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('auth.sessions.issuedOn') }}</FluxTableHeader>
                <FluxTableHeader>{{ t('auth.sessions.expires') }}</FluxTableHeader>
                <FluxTableHeader/>
            </template>

            <template #device="{row: {device, token}}">
                <FluxTableCell>
                    <FluxStack
                        axis="horizontal"
                        :gap="12">
                        <span>{{ device }}</span>

                        <FluxBadge
                            v-if="currentToken === token"
                            :label="t('global.current')"/>
                    </FluxStack>
                </FluxTableCell>
            </template>

            <template #ipAddress="{row: {ipAddress}}">
                <FluxTableCell><code>{{ ipAddress }}</code></FluxTableCell>
            </template>

            <template #issuedOn="{row: {issuedOn}}">
                <FluxTableCell>{{ formatDateTime(issuedOn) }}</FluxTableCell>
            </template>

            <template #validUntil="{row: {validUntil}}">
                <FluxTableCell>{{ formatDateTime(validUntil) }}</FluxTableCell>
            </template>

            <template #action="{row: {token, ipAddress}}">
                <FluxTableCell>
                    <FluxTableActions>
                        <FluxTooltip
                            v-if="currentToken !== token"
                            :content="t('global.delete')">
                            <FluxAction
                                destructive
                                icon="trash"
                                data-testid="sessions-delete-session"
                                @click="deleteSession(token, ipAddress)"/>
                        </FluxTooltip>
                    </FluxTableActions>
                </FluxTableCell>
            </template>
        </FluxDataTable>

        <FluxPaneFooter v-if="false">
            <FluxPaginationBar
                :page="currentPage"
                :per-page="pageLength"
                :total="sessions.length"
                @limit="setPageLength"
                @navigate="setCurrentPage"/>
        </FluxPaneFooter>
    </FluxPane>
</template>

<script
    lang="ts"
    setup>
    import { AuthService } from '@fancee/api';
    import type { Session } from '@fancee/data';
    import { showConfirm, showSnackbar } from '@fancee/flux';
    import { ref, toRefs, watch } from 'vue';
    import { useI18n } from 'vue-i18n';
    import { ToolbarSearch } from '@/components/filter';
    import { useLoaded, usePagination, useService } from '@/composable';
    import { useAuthStore, useStore } from '@/data/store';
    import { formatDateTime, guarded } from '@/util';

    export interface Props {
        readonly userId?: string;
    }

    const props = defineProps<Props>();
    const {userId} = toRefs(props);

    const {t} = useI18n();
    const {isLoading, loaded} = useLoaded();
    const {getSessions: getCurrentUserSessions, getSessionsForUser, deleteSession: deleteCurrentUserSession, deleteSessionForUser} = useService(AuthService);
    const {token: currentToken} = useStore(useAuthStore());

    const {
        currentPage,
        pageLength,
        setCurrentPage,
        setPageLength,
        setTotalItems
    } = usePagination();

    const _deleteCurrentUserSession = guarded(loaded(deleteCurrentUserSession), t('ui.somethingWentWrong.title'), t('auth.sessions.deleteFailed'));
    const _deleteSessionForUser = guarded(loaded(deleteSessionForUser), t('ui.somethingWentWrong.title'), t('auth.sessions.deleteFailed'));
    const _getCurrentUserSessions = guarded(loaded(getCurrentUserSessions), t('ui.somethingWentWrong.title'), t('auth.sessions.loadingFailed'));
    const _getSessionsForUser = guarded(loaded(getSessionsForUser), t('ui.somethingWentWrong.title'), t('auth.sessions.loadingFailed'));

    const sessions = ref<Session[]>([]);
    const search = ref('');

    async function loadSessions(): Promise<void> {
        const {data: items} = !userId?.value ?
            await _getCurrentUserSessions() :
            await _getSessionsForUser(userId.value);

        sessions.value = items;
        setTotalItems(items.length);
    }

    async function deleteSession(token: string, ipAddress: string): Promise<void> {
        const confirmed = await showConfirm({
            icon: 'trash',
            title: t('ui.confirmDeleteOverlay.title', [t('auth.sessions.singular')]),
            message: t('ui.confirmDeleteOverlay.messageGeneric')
        });

        if (!confirmed) {
            return;
        }

        try {
            !userId.value
                ? await _deleteCurrentUserSession(token)
                : await _deleteSessionForUser(userId.value, token);

            showSnackbar({
                color: 'success',
                icon: 'circle-check',
                message: t('auth.sessions.deleted')
            });
        } finally {
            await loadSessions();
        }
    }

    watch([userId, currentPage, pageLength], () => loadSessions(), {immediate: true});
</script>
