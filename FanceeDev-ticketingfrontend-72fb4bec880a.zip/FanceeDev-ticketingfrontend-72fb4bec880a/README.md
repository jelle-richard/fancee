# WeAreFancee ticketing dashboard

This repository contains the WeAreFancee ticketing dashboard and online shop meant for organizations, ambassadors and 
clients. Please read the following instructions and checks in order to proceed.

## Installation requirements & guide

- Install NodeJs ^16.
- Install pnpm using `npm i -g pnpm`.
- Configure an environment variable `FANCEE_NPM_AUTH_TOKEN`. The value can be found in lastpass.
- Configure an environment variable `FONTAWESOME_NPM_AUTH_TOKEN`. The value can be found in lastpass.
- Use `pnpm install` to install the required packages.
- Use `pnpm dev` to serve a local build.
- When needed use `pnpm build` to create a production build.

## Git usage

Commit messages and branches will be in English.

### Branches

The repository works via the following structure:

###### Main branch

Contains the latest stable release and is the exact code that is running on the live environment.

###### Develop branch

This branch contains the latest stable release marked for the next deployment and is the exact code that is running on
the staging environment.

###### Feature branches

Any new feature should have its own feature branch. Once complete, the feature branch should be merged to the develop
branch and the feature branch should be deleted.

###### Bugfix branches

If a bug is found, it should be fixed within a bugfix branch. Once complete, the bugfix branch should be merged to the
branch it originated from and the bugfix branch should be deleted.

### Commit messages

All commit messages should follow the following template: `<type>{(<jira-issue>)}: <subject>`
Parts between `{ }` are optional.

The following types are allowed:

| Type     | Description                                                  |
| -------- | ------------------------------------------------------------ |
| feat     | for when a new feature has been added                        |
| fix      | for when a bugfix has been made                              |
| docs     | for when documentation has changed                           |
| style    | for when formatting has been changed (for example: missing semicolon, removed/added brackets etc. - no actual code functionality has been changed) |
| refactor | for when the changed code is a refactor of some kind         |
| test     | for when adding (unit) tests                                 |
| chore    | for all other type of commits                                |

## Coding style

Everything related to code, HTML, styling classes etc. will be in English.

## Icons

This project uses Font Awesome icons. The icons can be found at https://fontawesome.com/. We have a license for
Font Awesome Pro, which means that we can use all icons. To use an icon do the following:

- Find the icon you want to use at https://fontawesome.com/.
- Copy the icon name (for example: `fa-user`).
- Add the icon to one of the exports in `src/data/ui/icons.ts` by using the camelCase name of the icon (for
  example: `faUser`).
- Use the icon in your component by using the `<Icon/>` component and removing `fa` from its name. For example:
  `<Icon variant="user" />`.

### Typescript / javascript

- Do **NOT** use `myVar.constructor.name === MyClass.name` for type checking; this will break in production builds.<br/>
  Use `myVar instanceof MyClass` instead.
- Use `camelCase` for variable and function names.
- Use `PascalCase` for class names.
- Use `camelCase` of class members and methods.
- Use `PascalCase` for interface names.
- Use `camelCase` for interface members.
- Use `PascalCase` for type names.
- Use `camelCase` for type members.
- Use `PascalCase` for namespace names.
- Use `PascalCase` for enums.
- Use `PascalCase` for enum members.
- Use `camelCase` for file names.
- Use types wheresoever possible to denote the structure.
- Don’t ever use the types `Number`, `String`, `Boolean`, `Symbol`, or `Object` These types refer to non-primitive boxed
  objects that are almost never used appropriately in JavaScript code.
- Do use the types `number`, `string`, `boolean`, and `symbol`.
- Prefer using union types over overload implementations that only differ in argument position.
- Don’t ever have a generic type which doesn't use its type parameter.
- Prefer using single quotes ``'`` for string unless escaping.
- Try not to use the `any` type, this often just begs for its content to be extracted to a Dto.
- Sort overloads by putting the more specified signatures on top.
- Use single quotes ``'`` for imports and requires.
- Use 4 spaces, not tabs.
- Notate arrays as `Foo[]` instead of `Array<Foo>`.
- Define typed variables as ``const/let myVar: MyType = ...;`` and prevent casting.
- Use the standard code indentation present in Webstorm when pressing ``ctrl + alt + l``.
- Classes should adhere to the following structure: getters & setters > properties > constructor.
- Classes should adhere to the following access modifier order: public > protected > private.
- Methods with nullable parameters should prioritise to have said parameter at the end of the method signature.
- Functionality for uploading files (e.g. product images, profile pictures or shop content) should not be uploaded to a
  public folder.
- Code and or assets for development should be removed from production builds.
- Always place named exports above default exports.
- Always put TicketingApi import at the top of the imports @api > @client > @data
- All Dto's should have the `@Dto` decorator applied, imported from `@fancee/client`.
- The order of members in component classes should be: props, getters/setters, lifecycle methods, other methods, watchers.

### Data fetching
Please use the following format for data fetching, this will ensure that some errors are handled globally.

```typescript
const {list: listEvents} = useService(EventService);
const _listEvents = guarded(listEvents, 'error title', 'error message');

const {data: {items, totalItems}} = await _listEvents();
```

### HTML

- Use empty lines for better readability on your own account, but be consistent.
- Start on a new line for every attribute after the first one.
- Don't use inline style unless explicitly needed in a certain situation.
- All HTML entities should use the `kebab-case` naming scheme.
- HTML properties and attribute values like: id, name, label should use the `kebab-case` naming scheme.

### Vue components

- Try to extract business logic from the components.
- Always use `:key` attribute with `v-for` directives.
- Always use unique values for the `:key` attribute.
- Don't use `v-if` and `v-for` in the same context as `v-for` has a higher priority.
- Always use the `required` property in Prop options to specify if a Prop is required.
- Use `Vue.set` with arrays and objects to bypass the limitation of Vue to detect internal changes.
- Both shorthands or fully written directives ar accepted, but should not be mixed and remain consistent.
- Use `kebab-case` when emitting events.
- Declare props with `camelCase` and use `kebab-case` in templates.
- Don’t call a method on created AND watch but use the built-in solution of `Vue watcher`.
- Template expressions should only have basic javascript expressions, otherwise they should be extracted to a method.
- Use snake-case for emits.
- Use unref() for reading and .value for setting when working with Vue Ref

### SCSS and other styling methods

- All styling should be done via SCSS.
- All classes should use the `kebab-case`.
- All styles regarding colors should consider the switch between light and dark mode and thus use the appropriate color
  variables.

### Editor settings

Settings → Editor → Inspections
- JavaScript and TypeScript
  - Code style issues
    - Unterminated statement [✓]
      - Options
        - Allow absence of semicolon at end of block [✘]
      - Severity: Warning (of error)

## Definition of Done

- The deliverable adheres to all the requirements of the Coding style.
- The deliverable follows the provided GIT branching structure.
- The deliverable branch is up-to-date with its origin/parent branch.
- The deliverable should be production ready and not contain: (console logs, todo comments and/or other development
  related code).
- The deliverable branch should be attached to a corresponding Jira issue and only contain the needed changes as stated
  in said issue.
- The deliverable has no type errors in the build.
- The deliverable has a PR in BitBucket which is connected to a Jira issue.
- The deliverable PR has at least 1 approve of either 'Martijn Woolschot (martijn@tibbaa.com)', 'Jorden Willemsen
  (jorden@tibbaa.com)' or 'Bas Milius (bas@tibbaa.com)'.
- The deliverable PR passed all merge checks.
- The deliverable branch should be deleted after the PR is merged.
- All new text has been translated in every language the dashboard offers.
