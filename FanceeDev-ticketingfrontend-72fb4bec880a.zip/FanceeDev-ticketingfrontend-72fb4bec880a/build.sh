#!/usr/bin/env sh
set -e

if [[ -z "$1" ]]; then
  echo "No tag provided"
  exit 1
fi

if [[ -z "$2" ]]; then
  echo "No VITE target provided"
  exit 1
fi

docker build \
  --build-arg vite_target="$2" \
  --build-arg npm_auth_token="$FANCEE_NPM_AUTH_TOKEN" \
  --build-arg fontawesome_auth_token="$FONTAWESOME_NPM_AUTH_TOKEN" \
  -t packages.fanc.ee/p/main/docker/frontend:"$1" \
  .

docker image push packages.fanc.ee/p/main/docker/frontend:"$1"
docker rmi packages.fanc.ee/p/main/docker/frontend:"$1"
