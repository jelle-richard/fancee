import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, Paginated, QueryString } from '@fancee/client';
import { AdminInvoiceFilter, CountryCode, InvoiceAdapter, InvoiceFilter, InvoiceListItem } from '@fancee/data';
import { IInvoiceService } from '@';

export class InvoiceService extends BaseService implements IInvoiceService {
    @Debounce(500)
    async list(pageSize: number, page: number, filter: AdminInvoiceFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<InvoiceListItem>>> {
        return await this
            .request('/invoices/list')
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .append('Options.OrganizationId', filter.organizationId)
                .appendArray('Options.CountryCodes', countryCodes)
                .append('Options.EventId', filter.eventId))
            .bearerToken()
            .runPaginatedAdapter(InvoiceAdapter.parseInvoiceListItemFromObject);
    }

    async csvExport(filter: AdminInvoiceFilter, countryCodes: CountryCode[]): Promise<BlobResponse> {
        return await this
            .request('/invoices/export/csv')
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.searchQuery)
                .append('OrganizationId', filter.organizationId)
                .appendArray('CountryCodes', countryCodes)
                .append('EventId', filter.eventId))
            .bearerToken()
            .fetchBlob();
    }

    @Debounce(500)
    async listOrganization(organizationId: string, pageSize: number, page: number, filter: InvoiceFilter): Promise<BaseResponse<Paginated<InvoiceListItem>>> {
        return await this
            .request('/invoices/organization/list')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .append('Options.EventId', filter.eventId))
            .bearerToken()
            .runPaginatedAdapter(InvoiceAdapter.parseInvoiceListItemFromObject);
    }

    async csvExportOrganization(organizationId: string, filter: InvoiceFilter): Promise<BlobResponse> {
        return await this
            .request('/invoices/organization/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.searchQuery)
                .append('EventId', filter.eventId))
            .bearerToken()
            .fetchBlob();
    }

    async download(invoiceNumber: number): Promise<BlobResponse> {
        return await this
            .request(`/invoice/${invoiceNumber}`)
            .bearerToken()
            .fetchBlob();
    }

    async generateInvoice(organizationId: string, month: number, year: number): Promise<BaseResponse<number>> {
        return await this
            .request(`/invoice/organization/${organizationId}/generate`)
            .method(HttpMethod.Post)
            .body({
                month: month,
                year: year
            })
            .bearerToken()
            .runData();
    }
}
