import type { BaseResponse, BlobResponse, Paginated } from '@fancee/client';
import { AdminInvoiceFilter, CountryCode, InvoiceFilter, InvoiceListItem } from '@fancee/data';

export interface IInvoiceService {
    list(pageSize: number, page: number, filter: AdminInvoiceFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<InvoiceListItem>>>;

    csvExport(filter: AdminInvoiceFilter, countryCodes: CountryCode[]): Promise<BlobResponse>;

    listOrganization(organizationId: string, pageSize: number, page: number, filter: InvoiceFilter): Promise<BaseResponse<Paginated<InvoiceListItem>>>;

    csvExportOrganization(organizationId: string, filter: InvoiceFilter): Promise<BlobResponse>;

    download(invoiceNumber: number): Promise<BlobResponse>;

    generateInvoice(organizationId: string, month: number, year: number): Promise<BaseResponse<number>>;
}
