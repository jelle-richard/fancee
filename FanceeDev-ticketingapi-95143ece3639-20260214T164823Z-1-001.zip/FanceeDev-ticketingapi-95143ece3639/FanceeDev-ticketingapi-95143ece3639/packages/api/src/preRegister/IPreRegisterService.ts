import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { PreRegister, PreRegisterListing, PreRegisterSignUp } from '@fancee/data';

export interface IPreRegisterService {
    get(code: string): Promise<BaseResponse<PreRegister>>;

    list(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<PreRegisterListing>>>;

    csvExport(organizationId: string, searchQuery: string): Promise<BlobResponse>;

    create(organizationId: string, preRegister: PreRegister): Promise<BaseResponse<string>>;

    delete(organizationId: string, code: string): Promise<HttpStatusCode>;

    update(organizationId: string, preRegister: PreRegister): Promise<HttpStatusCode>;

    assignHeaderMedia(organizationId: string, code: string, headerMedia: File): Promise<HttpStatusCode>;

    deleteHeaderMedia(organizationId: string, code: string): Promise<HttpStatusCode>;

    signUp(code: string, signUp: PreRegisterSignUp): Promise<HttpStatusCode>;

    csvExportSignUps(organizationId: string, code: string): Promise<BaseResponse<PreRegisterSignUp[]>>;
}
