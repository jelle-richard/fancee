import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { PreRegister, PreRegisterAdapter, PreRegisterListing, PreRegisterSignUp } from '@fancee/data';
import { IPreRegisterService } from '@';

export class PreRegisterService extends BaseService implements IPreRegisterService {
    async get(code: string): Promise<BaseResponse<PreRegister>> {
        return await this
            .request(`/pre-register/${code}`)
            .runAdapter(PreRegisterAdapter.parsePreRegister);
    }

    @Debounce(500)
    async list(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<PreRegisterListing>>> {
        return await this
            .request('/pre-registers/list')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery))
            .bearerToken()
            .runPaginatedAdapter(PreRegisterAdapter.parsePreRegisterListFromObject);
    }

    async csvExport(organizationId: string, searchQuery: string): Promise<BlobResponse> {
        return await this
            .request('/pre-registers/organization/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    async create(organizationId: string, preRegister: PreRegister): Promise<BaseResponse<string>> {
        return await this
            .request('/pre-register')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(PreRegisterAdapter.parsePreRegisterToApiScheme(preRegister))
            .runDataKey<{ code: string; }>('code');
    }

    async delete(organizationId: string, code: string): Promise<HttpStatusCode> {
        return await this
            .request(`/pre-register/${code}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async assignHeaderMedia(organizationId: string, code: string, headerMedia: File): Promise<HttpStatusCode> {
        const body = new FormData();
        body.append('media', headerMedia);

        return await this
            .request(`/pre-register/${code}/media/header`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runStatusCode();
    }

    async deleteHeaderMedia(organizationId: string, code: string): Promise<HttpStatusCode> {
        return await this
            .request(`/pre-register/${code}/media/header`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async update(organizationId: string, preRegister: PreRegister): Promise<HttpStatusCode> {
        return await this
            .request(`/pre-register/${preRegister.code}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(PreRegisterAdapter.parsePreRegisterToApiScheme(preRegister))
            .runStatusCode();
    }

    async signUp(code: string, signUp: PreRegisterSignUp): Promise<HttpStatusCode> {
        return await this
            .request('/pre-register/sign-up')
            .method(HttpMethod.Post)
            .body(PreRegisterAdapter.parseSignUpToApiScheme(code, signUp))
            .runStatusCode();
    }

    async csvExportSignUps(organizationId: string, code: string): Promise<BaseResponse<PreRegisterSignUp[]>> {
        return await this
            .request(`/pre-register/${code}/sign-ups`)
            .asOrganization(organizationId)
            .bearerToken()
            .runData();
    }
}
