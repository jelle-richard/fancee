import { BaseResponse, BaseService, HttpMethod } from '@fancee/client';
import { CreateEventAdapter, CreateEventShop, CreateEventShopElement, CreateEventShopListing, EventDetails, EventValidationResponse, Media, MediaAdapter } from '@fancee/data';
import { ICreateEventService } from '@';

export class CreateEventService extends BaseService implements ICreateEventService {
    async createEvent(organizationId: string, details: EventDetails): Promise<BaseResponse<string>> {
        return await this
            .request('/event')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(CreateEventAdapter.parseDetailsToApi(details))
            .runDataKey<{ id: string; }>('id');
    }

    async createShop(organizationId: string, eventId: string, shop: CreateEventShop): Promise<BaseResponse<string>> {
        return await this
            .request(`/event/${eventId}/shop`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(CreateEventAdapter.parseShopToApi(shop))
            .runEmpty();
    }

    async getEvent(organizationId: string, eventId: string): Promise<BaseResponse<EventDetails>> {
        return await this
            .request(`/event/${eventId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(CreateEventAdapter.parseDetailsFromObject);
    }

    async getShop(organizationId: string, eventId: string, shopCode: string): Promise<BaseResponse<CreateEventShop>> {
        return await this
            .request(`/event/${eventId}/shop/${shopCode}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(CreateEventAdapter.parseShopFromObject);
    }

    async getShops(organizationId: string, eventId: string): Promise<BaseResponse<CreateEventShopListing[]>> {
        return await this
            .request(`/event/${eventId}/shops/list`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(CreateEventAdapter.parseShopListingFromObject);
    }

    async updateEvent(organizationId: string, eventId: string, details: EventDetails): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(CreateEventAdapter.parseDetailsToApi(details))
            .runEmpty();
    }

    async updateShop(organizationId: string, eventId: string, shopCode: string, shop: CreateEventShop): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/shop/${shopCode}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(CreateEventAdapter.parseShopToApi(shop))
            .runEmpty();
    }

    async updateShopElements(organizationId: string, eventId: string, shopCode: string, elements: CreateEventShopElement[]): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/shop/${shopCode}/elements`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(CreateEventAdapter.parseShopElementsToApi(elements))
            .runEmpty();
    }

    async deleteShop(organizationId: string, eventId: string, shopCode: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/shop/${shopCode}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    async deleteEventHeader(organizationId: string, eventId: string, fileId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/media/${fileId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    async updateEventHeaderFocalPoint(organizationId: string, eventId: string, media: Media): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/media/${media.id}/focal-point`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(media.focalPoint ? MediaAdapter.parseFocalPointToApi(media.focalPoint) : null)
            .runEmpty();
    }

    async uploadEventHeader(organizationId: string, eventId: string, file: File): Promise<BaseResponse<string>> {
        const body = new FormData();
        body.append('media', file);

        return await this
            .request(`/event/${eventId}/media`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runData();
    }

    async deleteShopHeader(organizationId: string, eventId: string, shopCode: string, fileId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/shop/${shopCode}/media/header/${fileId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    async updateShopHeaderFocalPoint(organizationId: string, eventId: string, shopCode: string, media: Media): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/shop/${shopCode}/media/header/${media.id}/focal-point`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(media.focalPoint ? MediaAdapter.parseFocalPointToApi(media.focalPoint) : null)
            .runEmpty();
    }

    async uploadShopHeader(organizationId: string, eventId: string, shopCode: string, file: File): Promise<BaseResponse<string>> {
        const body = new FormData();
        body.append('media', file);

        return await this
            .request(`/event/${eventId}/shop/${shopCode}/media/header`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runData();
    }

    async validateEvent(organizationId: string, eventId: string): Promise<BaseResponse<EventValidationResponse>> {
        return await this
            .request(`/event/${eventId}/validate`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .runAdapter(CreateEventAdapter.parseValidationFromObject);
    }

    async syncSeatsIoEvent(organizationId: string, eventId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/seats/sync`)
            .method(HttpMethod.Get)
            .bearerToken()
            .asOrganization(organizationId)
            .runEmpty();
    }

    async validateSeatsIoEventId(organizationId: string, seatsIoEventId: string): Promise<BaseResponse<boolean>> {
        return await this
            .request(`/event/seats/${seatsIoEventId}/validate`)
            .method(HttpMethod.Get)
            .bearerToken()
            .asOrganization(organizationId)
            .runData();
    }
}
