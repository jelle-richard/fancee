import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { AssignedPaymentMethod, ChangeableEventStatus, CountryCode, CreateEventAdapter, DateTimeAdapter, EventAdapter, EventAgendaListing, EventBalanceListFilter, EventBalanceListing, EventCancellationRefundOption, EventDetails, EventListFilter, EventListing, EventMail, EventMailType, EventPaymentMethod, EventProductsIdentification, EventRevenueStatistics, GlobalEventStatistics, IssuedProductStatistics, PaymentAdapter, ProductAdapter } from '@fancee/data';
import type { DateTime } from 'luxon';
import { IEventService } from '@';

export class EventService extends BaseService implements IEventService {
    async get(organizationId: string, eventId: string): Promise<BaseResponse<EventDetails>> {
        return await this
            .request(`/event/${eventId}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(CreateEventAdapter.parseDetailsFromObject);
    }

    @Debounce(500)
    async list(organizationId: string, pageSize: number, page: number, filter: EventListFilter): Promise<BaseResponse<Paginated<EventListing>>> {
        return await this
            .request('/events/list')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .appendArray('Options.CountryCodes', [])
                .appendArray('Options.EventStates', filter.states ? EventAdapter.parseEventStates(filter.states) : null)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null))
            .bearerToken()
            .runPaginatedAdapter(EventAdapter.parseEventListingFromObject);
    }

    async csvExport(organizationId: string, filter: EventListFilter): Promise<BlobResponse> {
        return await this
            .request('/events/organization/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.searchQuery)
                .appendArray('EventStates', filter.states ? EventAdapter.parseEventStates(filter.states) : null)
                .appendArray('Options.CountryCodes', [])
                .append('DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null))
            .bearerToken()
            .fetchBlob();
    }

    @Debounce(500)
    async listOrganization(organizationId: string, pageSize: number, page: number, filter: EventListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<EventListing>>> {
        return await this
            .request(`/events/admin/list/${organizationId}`)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .appendArray('Options.EventStates', filter.states ? EventAdapter.parseEventStates(filter.states) : null)
                .appendArray('Options.CountryCodes', countryCodes)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null))
            .bearerToken()
            .runPaginatedAdapter(EventAdapter.parseEventListingFromObject);
    }

    async csvExportOrganization(organizationId: string, filter: EventListFilter, countryCodes: CountryCode[]): Promise<BlobResponse> {
        return await this
            .request(`/events/admin/export/csv/${organizationId}`)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.searchQuery)
                .appendArray('EventStates', filter.states ? EventAdapter.parseEventStates(filter.states) : null)
                .appendArray('CountryCodes', countryCodes)
                .append('DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null))
            .bearerToken()
            .fetchBlob();
    }

    @Debounce(500)
    async listPlatform(pageSize: number, page: number, filter: EventListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<EventListing>>> {
        return await this
            .request('/events/admin/list')
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .appendArray('Options.EventStates', filter.states ? EventAdapter.parseEventStates(filter.states) : null)
                .appendArray('Options.CountryCodes', countryCodes)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null))
            .bearerToken()
            .runPaginatedAdapter(EventAdapter.parseEventListingFromObject);
    }

    async csvExportPlatform(filter: EventListFilter, countryCodes: CountryCode[]): Promise<BlobResponse> {
        return await this
            .request('/events/admin/export/csv')
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.searchQuery)
                .appendArray('EventStates', filter.states ? EventAdapter.parseEventStates(filter.states) : null)
                .appendArray('CountryCodes', countryCodes)
                .append('DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null))
            .bearerToken()
            .fetchBlob();
    }

    async getAgendaPlatform(startDate: DateTime, endDate: DateTime, countryCodes: CountryCode[]): Promise<BaseResponse<EventAgendaListing[]>> {
        return await this
            .request('/events/crm/agenda')
            .queryString(QueryString.builder()
                .append('startDate', DateTimeAdapter.parseDateTimeToApi(startDate))
                .append('endDate', DateTimeAdapter.parseDateTimeToApi(endDate))
                .appendArray('countryCodes', countryCodes))
            .bearerToken()
            .runArrayAdapter(EventAdapter.parseEventToAgendaListingFromObject);
    }

    async copy(organizationId: string, eventId: string, copyShops: boolean, copyProducts: boolean, copyPaymentMethods: boolean, copyCategories: boolean, copyTags: boolean): Promise<BaseResponse<string>> {
        return await this
            .request(`/event/${eventId}/copy`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body({
                copyShops,
                copyProducts,
                copyPaymentMethods,
                copyCategories,
                copyTags
            })
            .runDataKey<{ id: string; }>('id');
    }

    async delete(organizationId: string, eventId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/event/${eventId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async cancel(organizationId: string, eventId: string, reason: string | null, preferredRefundOption: EventCancellationRefundOption): Promise<HttpStatusCode> {
        return await this
            .request(`/event/${eventId}/cancel`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body({
                reason,
                preferredRefundOption
            })
            .bearerToken()
            .runStatusCode();
    }

    async requestReview(organizationId: string, eventId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/review`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .runEmpty();
    }

    async getPaymentMethods(organizationId: string, eventId: string): Promise<BaseResponse<EventPaymentMethod[]>> {
        return await this
            .request(`/event/${eventId}/payment-methods`)
            .asOrganization(organizationId)
            .bearerToken()
            .runArrayAdapter(PaymentAdapter.parseEventPaymentMethodFromObject);
    }

    async updatePaymentMethods(organizationId: string, eventId: string, paymentMethods: AssignedPaymentMethod[]): Promise<HttpStatusCode> {
        return await this
            .request(`/event/${eventId}/payment-methods`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({
                paymentMethods: paymentMethods
                    .filter(paymentMethod => paymentMethod.paidBy !== null)
                    .map(PaymentAdapter.parseAssignedPaymentMethodToApi)
            })
            .runStatusCode();
    }

    async updateStatus(organizationId: string, eventId: string, status: ChangeableEventStatus): Promise<HttpStatusCode> {
        return await this
            .request(`/event/${eventId}/status`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({
                status
            })
            .runStatusCode();
    }

    async getGlobalStatisticsEvents(organizationId: string): Promise<BaseResponse<GlobalEventStatistics>> {
        return await this
            .request(`/events/statistics`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(EventAdapter.parseGlobalStatisticsFromObject);
    }

    async getGlobalStatistics(organizationId: string, eventId: string): Promise<BaseResponse<GlobalEventStatistics>> {
        return await this
            .request(`/event/${eventId}/statistics`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(EventAdapter.parseGlobalStatisticsFromObject);
    }

    async getGlobalStatisticsPlatform(startDate: DateTime, endDate: DateTime, countryCodes: CountryCode[]): Promise<BaseResponse<GlobalEventStatistics>> {
        return await this
            .request('/events/platform/statistics')
            .queryString(QueryString
                .builder()
                .append('startDate', DateTimeAdapter.parseDateTimeToApi(startDate))
                .append('endDate', DateTimeAdapter.parseDateTimeToApi(endDate))
                .appendArray('countryCodes', countryCodes))
            .bearerToken()
            .runAdapter(EventAdapter.parseGlobalStatisticsFromObject);
    }

    async getStatisticsRevenueEvents(organizationId: string): Promise<BaseResponse<EventRevenueStatistics>> {
        return await this
            .request(`/events/revenues`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(EventAdapter.parseRevenueStatisticsFromObject);
    }

    async getStatisticsRevenue(organizationId: string, eventId: string): Promise<BaseResponse<EventRevenueStatistics>> {
        return await this
            .request(`/event/${eventId}/revenues`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(EventAdapter.parseRevenueStatisticsFromObject);
    }

    async getUpcomingProducts(organizationId: string): Promise<BaseResponse<EventProductsIdentification[]>> {
        return await this
            .request(`/events/upcoming/products`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(EventAdapter.parseUpcomingEventsWithProductsFromObject);
    }

    async getIssuedProducts(organizationId: string, eventId: string): Promise<BaseResponse<IssuedProductStatistics[]>> {
        return await this
            .request(`/event/${eventId}/products/issued`)
            .asOrganization(organizationId)
            .bearerToken()
            .runArrayAdapter(ProductAdapter.parseIssuedProductStatisticsFromObject);
    }

    async getEventMail(organizationId: string, eventId: string, mailType: EventMailType): Promise<BaseResponse<EventMail>> {
        return await this
            .request(`/event/${eventId}/mail`)
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('Type', mailType))
            .bearerToken()
            .runAdapter(EventAdapter.parseEventMailFromObject);
    }

    async updateEventMail(organizationId: string, eventId: string, request: EventMail): Promise<HttpStatusCode> {
        return await this
            .request(`/event/${eventId}/mail`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({
                content: request.content,
                senderName: request.senderName,
                subject: request.subject,
                type: request.type
            })
            .runStatusCode();
    }

    async getBalanceEvents(pageSize: number, page: number, filter: EventBalanceListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<EventBalanceListing>>> {
        return await this
            .request('/events/crm/balance')
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .append('Options.DateRange.Minimum', DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]))
                .append('Options.DateRange.Maximum', DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]))
                .appendArray('CountryCodes', countryCodes))
            .bearerToken()
            .runPaginatedAdapter(EventAdapter.parseEventsBalanceFromObject);
    }

    async updateSecuredState(organizationId: string, eventId: string, shopCode: string, isSecured: boolean, secureStateExpiresOn: DateTime | null): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/shop/${shopCode}/secure`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .body({
                isSecured: isSecured,
                secureStateExpiresOn: secureStateExpiresOn === null
                    ? null
                    : DateTimeAdapter.parseDateTimeToApi(secureStateExpiresOn)
            })
            .bearerToken()
            .runEmpty();
    }
}
