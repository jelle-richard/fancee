import type { BaseResponse } from '@fancee/client';
import type { EventProduct, EventProductSummary, TicketDesign } from '@fancee/data';

export interface IEventProductService {
    create(organizationId: string, eventId: string, product: EventProduct): Promise<BaseResponse<string>>;

    delete(organizationId: string, eventId: string, productId: string): Promise<BaseResponse<never>>;

    list(organizationId: string, eventId: string): Promise<BaseResponse<EventProduct[]>>;

    getShops(organizationId: string, eventId: string): Promise<BaseResponse<EventProductSummary[]>>;

    update(organizationId: string, eventId: string, productId: string, product: EventProduct): Promise<BaseResponse<never>>;

    updateAll(organizationId: string, eventId: string, products: EventProduct[]): Promise<BaseResponse<never>>;

    deleteProductMedia(organizationId: string, eventId: string, productId: string, fileId: string): Promise<BaseResponse<never>>;

    uploadProductMedia(organizationId: string, eventId: string, productId: string, file: File): Promise<BaseResponse<string>>;

    createOrUpdateTicketDesign(organizationId: string, eventId: string, design: TicketDesign): Promise<BaseResponse<never>>;

    getTicketDesigns(organizationId: string, eventId: string): Promise<BaseResponse<TicketDesign[]>>;

    uploadTicketDesignMedia(organizationId: string, eventId: string, file: File): Promise<BaseResponse<string>>;
}
