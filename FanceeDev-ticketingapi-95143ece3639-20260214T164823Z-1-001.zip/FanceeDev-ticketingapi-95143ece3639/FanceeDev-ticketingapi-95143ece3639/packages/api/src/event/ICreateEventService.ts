import type { BaseResponse } from '@fancee/client';
import type { CreateEventShop, CreateEventShopElement, CreateEventShopListing, EventDetails, EventValidationResponse, Media } from '@fancee/data';

export interface ICreateEventService {
    createEvent(organizationId: string, details: EventDetails): Promise<BaseResponse<string>>;

    createShop(organizationId: string, eventId: string, shop: CreateEventShop): Promise<BaseResponse<string>>;

    getEvent(organizationId: string, eventId: string): Promise<BaseResponse<EventDetails>>;

    getShop(organizationId: string, eventId: string, shopCode: string): Promise<BaseResponse<CreateEventShop>>;

    getShops(organizationId: string, eventId: string): Promise<BaseResponse<CreateEventShopListing[]>>;

    updateEvent(organizationId: string, eventId: string, details: EventDetails): Promise<BaseResponse<never>>;

    updateShop(organizationId: string, eventId: string, shopCode: string, shop: CreateEventShop): Promise<BaseResponse<never>>;

    updateShopElements(organizationId: string, eventId: string, shopCode: string, elements: CreateEventShopElement[]): Promise<BaseResponse<never>>;

    deleteShop(organizationId: string, eventId: string, shopCode: string): Promise<BaseResponse<never>>;

    deleteEventHeader(organizationId: string, eventId: string, fileId: string): Promise<BaseResponse<never>>;

    updateEventHeaderFocalPoint(organizationId: string, eventId: string, media: Media): Promise<BaseResponse<never>>;

    uploadEventHeader(organizationId: string, eventId: string, file: File): Promise<BaseResponse<string>>;

    deleteShopHeader(organizationId: string, eventId: string, shopCode: string, fileId: string): Promise<BaseResponse<never>>;

    updateShopHeaderFocalPoint(organizationId: string, eventId: string, shopCode: string, media: Media): Promise<BaseResponse<never>>;

    uploadShopHeader(organizationId: string, eventId: string, shopCode: string, file: File): Promise<BaseResponse<string>>;

    validateEvent(organizationId: string, eventId: string): Promise<BaseResponse<EventValidationResponse>>;

    syncSeatsIoEvent(organizationId: string, eventId: string): Promise<BaseResponse<never>>;

    validateSeatsIoEventId(organizationId: string, seatsIoEventId: string): Promise<BaseResponse<boolean>>;
}
