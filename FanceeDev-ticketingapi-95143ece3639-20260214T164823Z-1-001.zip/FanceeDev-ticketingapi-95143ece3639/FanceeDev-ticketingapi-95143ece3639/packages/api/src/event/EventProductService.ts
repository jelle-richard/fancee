import { BaseResponse, BaseService, Debounce, HttpMethod } from '@fancee/client';
import { EventProduct, EventProductAdapter, EventProductSummary, TicketDesign } from '@fancee/data';
import { IEventProductService } from '@';

export class EventProductService extends BaseService implements IEventProductService {
    async create(organizationId: string, eventId: string, product: EventProduct): Promise<BaseResponse<string>> {
        return await this
            .request(`/event/${eventId}/product`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(EventProductAdapter.parseEventProductToApi(product))
            .runDataKey<{ id: string; }>('id');
    }

    async delete(organizationId: string, eventId: string, productId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/product/${productId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    @Debounce(500)
    async list(organizationId: string, eventId: string): Promise<BaseResponse<EventProduct[]>> {
        return await this
            .request(`/event/${eventId}/product`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(EventProductAdapter.parseEventProductFromObject);
    }

    async getShops(organizationId: string, eventId: string): Promise<BaseResponse<EventProductSummary[]>> {
        return await this
            .request(`/event/${eventId}/products/shops`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(EventProductAdapter.parseEventProductSummaryFromObject);
    }

    async update(organizationId: string, eventId: string, productId: string, product: EventProduct): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/product/${productId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(EventProductAdapter.parseEventProductToApi(product))
            .runEmpty();
    }

    async updateAll(organizationId: string, eventId: string, products: EventProduct[]): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/product`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(products.map(EventProductAdapter.parseEventProductToApi))
            .runEmpty();
    }

    async deleteProductMedia(organizationId: string, eventId: string, productId: string, fileId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/product/${productId}/media/${fileId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    async uploadProductMedia(organizationId: string, eventId: string, productId: string, file: File): Promise<BaseResponse<string>> {
        const body = new FormData();
        body.append('media', file);

        return await this
            .request(`/event/${eventId}/product/${productId}/media`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runData();
    }

    async createOrUpdateTicketDesign(organizationId: string, eventId: string, design: TicketDesign): Promise<BaseResponse<never>> {
        return await this
            .request(`/event/${eventId}/product/ticket/design/elements`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(EventProductAdapter.parseTicketDesignToApi(design))
            .runEmpty();
    }

    async getTicketDesigns(organizationId: string, eventId: string): Promise<BaseResponse<TicketDesign[]>> {
        return await this
            .request(`/event/${eventId}/product/ticket/design/elements`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(EventProductAdapter.parseTicketDesignFromObject);
    }

    async uploadTicketDesignMedia(organizationId: string, eventId: string, file: File): Promise<BaseResponse<string>> {
        const body = new FormData();
        body.append('media', file);

        return await this
            .request(`/event/${eventId}/product/ticket/design/media`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runData();
    }
}
