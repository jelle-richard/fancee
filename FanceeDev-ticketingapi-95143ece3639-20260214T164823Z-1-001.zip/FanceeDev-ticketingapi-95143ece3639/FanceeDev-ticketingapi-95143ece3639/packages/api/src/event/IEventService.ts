import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { AssignedPaymentMethod, ChangeableEventStatus, CountryCode, EventAgendaListing, EventBalanceListFilter, EventBalanceListing, EventCancellationRefundOption, EventDetails, EventListFilter, EventListing, EventMail, EventMailType, EventPaymentMethod, EventProductsIdentification, EventRevenueStatistics, GlobalEventStatistics, IssuedProductStatistics } from '@fancee/data';
import type { DateTime } from 'luxon';

export interface IEventService {
    get(organizationId: string, eventId: string): Promise<BaseResponse<EventDetails>>;

    list(organizationId: string, pageSize: number, page: number, filter: EventListFilter): Promise<BaseResponse<Paginated<EventListing>>>;

    csvExport(organizationId: string, filter: EventListFilter): Promise<BlobResponse>;

    listOrganization(organizationId: string, pageSize: number, page: number, filter: EventListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<EventListing>>>;

    csvExportOrganization(organizationId: string, filter: EventListFilter, countryCodes: CountryCode[]): Promise<BlobResponse>;

    listPlatform(pageSize: number, page: number, filter: EventListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<EventListing>>>;

    csvExportPlatform(filter: EventListFilter, countryCodes: CountryCode[]): Promise<BlobResponse>;

    getAgendaPlatform(startDate: DateTime, endDate: DateTime, countryCodes: CountryCode[]): Promise<BaseResponse<EventAgendaListing[]>>;

    copy(organizationId: string, eventId: string, copyShops: boolean, copyProducts: boolean, copyPaymentMethods: boolean, copyCategories: boolean, copyTags: boolean): Promise<BaseResponse<string>>;

    delete(organizationId: string, eventId: string): Promise<HttpStatusCode>;

    cancel(organizationId: string, eventId: string, reason: string | null, preferredRefundOption: EventCancellationRefundOption): Promise<HttpStatusCode>;

    requestReview(organizationId: string, eventId: string): Promise<BaseResponse<never>>;

    getPaymentMethods(organizationId: string, eventId: string): Promise<BaseResponse<EventPaymentMethod[]>>;

    updatePaymentMethods(organizationId: string, eventId: string, paymentMethods: AssignedPaymentMethod[]): Promise<HttpStatusCode>;

    updateStatus(organizationId: string, eventId: string, status: ChangeableEventStatus): Promise<HttpStatusCode>;

    getGlobalStatisticsEvents(organizationId: string): Promise<BaseResponse<GlobalEventStatistics>>;

    getGlobalStatistics(organizationId: string, eventId: string): Promise<BaseResponse<GlobalEventStatistics>>;

    getGlobalStatisticsPlatform(startDate: DateTime, endDate: DateTime, countryCodes: CountryCode[]): Promise<BaseResponse<GlobalEventStatistics>>;

    getStatisticsRevenueEvents(organizationId: string): Promise<BaseResponse<EventRevenueStatistics>>;

    getStatisticsRevenue(organizationId: string, eventId: string): Promise<BaseResponse<EventRevenueStatistics>>;

    getUpcomingProducts(organizationId: string): Promise<BaseResponse<EventProductsIdentification[]>>;

    getIssuedProducts(organizationId: string, eventId: string): Promise<BaseResponse<IssuedProductStatistics[]>>;

    getEventMail(organizationId: string, eventId: string, mailType: EventMailType): Promise<BaseResponse<EventMail>>;

    updateEventMail(organizationId: string, eventId: string, request: EventMail): Promise<HttpStatusCode>;

    getBalanceEvents(pageSize: number, page: number, filter: EventBalanceListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<EventBalanceListing>>>;

    updateSecuredState(organizationId: string, eventId: string, shopCode: string, isSecured: boolean, secureStateExpiresOn: DateTime | null): Promise<BaseResponse<never>>;
}
