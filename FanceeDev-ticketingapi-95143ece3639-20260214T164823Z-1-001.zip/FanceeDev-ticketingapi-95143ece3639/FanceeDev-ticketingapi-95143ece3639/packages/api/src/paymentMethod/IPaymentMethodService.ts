import type { BaseResponse, BlobResponse, Paginated } from '@fancee/client';
import type { EventPaymentMethod } from '@fancee/data';

export interface IPaymentMethodService {
    list(pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<EventPaymentMethod>>>;

    csvExport(searchQuery: string): Promise<BlobResponse>;
}
