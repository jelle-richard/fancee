import { BaseResponse, BaseService, BlobResponse, Debounce, Paginated, QueryString } from '@fancee/client';
import { EventPaymentMethod, PaymentAdapter } from '@fancee/data';
import { IPaymentMethodService } from '@';

export class PaymentMethodService extends BaseService implements IPaymentMethodService {
    @Debounce(500)
    async list(pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<EventPaymentMethod>>> {
        return await this
            .request('/payment-methods/list')
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery))
            .bearerToken()
            .runPaginatedAdapter(PaymentAdapter.parseEventPaymentMethodFromObject);
    }

    async csvExport(searchQuery: string): Promise<BlobResponse> {
        return await this
            .request('/payment-methods/export/csv')
            .queryString(QueryString
                .builder()
                .append('SearchQuery', searchQuery))
            .bearerToken()
            .fetchBlob();
    }
}
