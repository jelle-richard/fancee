import type { BaseResponse, Paginated } from '@fancee/client';
import type { Agenda, AgendaOverview, AgendaListing, AgendaOverviewLinkedEvent } from '@fancee/data';

export interface IAgendaService {
    list(organizationId: string, pageSize: number, page: number): Promise<BaseResponse<Paginated<AgendaListing>>>;

    getPublic(id: string): Promise<BaseResponse<AgendaOverview>>;

    get(organizationId: string, id: string): Promise<BaseResponse<Agenda>>;

    create(organizationId: string, agenda: Agenda): Promise<BaseResponse<string>>;

    update(organizationId: string, id: string, agenda: Agenda): Promise<BaseResponse<never>>;

    delete(organizationId: string, id: string): Promise<BaseResponse<never>>;

    events(organizationId: string, events: string[]): Promise<BaseResponse<AgendaOverviewLinkedEvent[]>>;
}
