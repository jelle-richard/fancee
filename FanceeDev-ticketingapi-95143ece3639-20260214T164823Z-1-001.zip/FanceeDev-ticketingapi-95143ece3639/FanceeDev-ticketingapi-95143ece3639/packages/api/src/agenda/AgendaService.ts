import { BaseResponse, BaseService, HttpMethod, Paginated, QueryString } from '@fancee/client';
import { Agenda, AgendaOverview, AgendaAdapter, AgendaListing, AgendaOverviewLinkedEvent } from '@fancee/data';

export class AgendaService extends BaseService implements AgendaService {
    async list(organizationId: string, pageSize: number, page: number): Promise<BaseResponse<Paginated<AgendaListing>>> {
        return await this
            .request('/agenda-iframes/organization/list')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page))
            .bearerToken()
            .runPaginatedAdapter(AgendaAdapter.parseAgendaListingFromObject);
    }

    async getPublic(id: string): Promise<BaseResponse<AgendaOverview>> {
        return await this
            .request(`/agenda-iframe/public/${id}`)
            .method(HttpMethod.Get)
            .runAdapter(AgendaAdapter.parseAgendaOverviewFromObject);
    }

    async get(organizationId: string, id: string): Promise<BaseResponse<Agenda>> {
        return await this
            .request(`/agenda-iframe/${id}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(AgendaAdapter.parseAgendaFromObject);
    }

    async create(organizationId: string, agenda: Agenda): Promise<BaseResponse<string>> {
        return await this
            .request('/agenda-iframe/create')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body(AgendaAdapter.parseAgendaToApi(agenda))
            .bearerToken()
            .runData();
    }

    async update(organizationId: string, id: string, agenda: Agenda): Promise<BaseResponse<never>> {
        return await this
            .request(`/agenda-iframe/update/${id}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .body(AgendaAdapter.parseAgendaToApi(agenda))
            .bearerToken()
            .runEmpty();
    }

    async delete(organizationId: string, id: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/agenda-iframe/delete/${id}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    async events(organizationId: string, eventIds: string[]): Promise<BaseResponse<AgendaOverviewLinkedEvent[]>> {
        return await this
            .request('/agenda-iframe/events')
            .method(HttpMethod.Get)
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .appendArray('ids', eventIds))
            .bearerToken()
            .runArrayAdapter(AgendaAdapter.parseAgendaOverviewLinkedEventFromObject);
    }
}
