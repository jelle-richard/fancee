import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { BarcodeImport, BestSellingProduct, DateTimeAdapter, EventProducts, ProductAdapter, TicketAdapter, TicketFilter, TicketInformation, TicketListing } from '@fancee/data';
import { IProductService } from '@';

export class ProductService extends BaseService implements IProductService {
    async getTicket(organizationId: string, code: string): Promise<BaseResponse<TicketInformation>> {
        return await this
            .request(`/product/ticket/${code}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(TicketAdapter.parseTicketInformationFromObject);
    }

    @Debounce(500)
    async listTicket(organizationId: string, pageSize: number, page: number, filter: TicketFilter): Promise<BaseResponse<Paginated<TicketListing>>> {
        return await this
            .request('/products/ticket/list')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .appendArray('Options.EventIds', filter.eventIds)
                .appendArray('Options.ShopCodes', filter.shopCodes)
                .appendArray('Options.ProductOrigins', filter.origins)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('Options.ScanState', filter.scanState)
                .append('Options.OptInSms', filter.optInPromotionalSms)
                .append('Options.OptInEmail', filter.optInPromotionalEmail)
                .append('Options.ReceiveViaSms', filter.receiveViaSms))
            .bearerToken()
            .runPaginatedAdapter(TicketAdapter.parseTicketListingFromObject);
    }

    async csvExportTicket(organizationId: string, filter: TicketFilter): Promise<BlobResponse> {
        return await this
            .request('/products/ticket/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.searchQuery)
                .appendArray('EventIds', filter.eventIds)
                .appendArray('ShopCodes', filter.shopCodes)
                .appendArray('ProductOrigins', filter.origins)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('ScanState', filter.scanState)
                .append('OptInSms', filter.optInPromotionalSms)
                .append('OptInEmail', filter.optInPromotionalEmail)
                .append('ReceiveViaSms', filter.receiveViaSms))
            .bearerToken()
            .fetchBlob();
    }

    async getBestSelling(organizationId: string, limit: number, startDate: string, endDate: string): Promise<BaseResponse<BestSellingProduct[]>> {
        return await this
            .request(`/products/best-selling?limit=${limit}&startDate=${startDate}&endDate=${endDate}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(ProductAdapter.parseBestSellingProductsFromObjects);
    }

    async getBestSellingEvent(organizationId: string, eventId: string, limit: number, startDate: string, endDate: string): Promise<BaseResponse<BestSellingProduct[]>> {
        return await this
            .request(`/products/${eventId}/best-selling?limit=${limit}&startDate=${startDate}&endDate=${endDate}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(ProductAdapter.parseBestSellingProductsFromObjects);
    }

    async importGuests(organizationId: string, productId: string, media: Blob, emailIndex: number, quantityIndex: number, firstNameIndex: number | null, lastNameIndex: number | null, deductStock: boolean, delimiter: string, hasHeader: boolean): Promise<BaseResponse<never>> {
        const body = new FormData();
        body.append('media', media);
        body.append('emailFieldIndex', emailIndex.toString());
        body.append('ticketAmountFieldIndex', quantityIndex.toString());
        body.append('deductStock', deductStock.toString());
        body.append('delimiter', delimiter);
        body.append('hasHeader', hasHeader.toString());

        if (firstNameIndex !== null) {
            body.append('firstNameFieldIndex', firstNameIndex.toString());
        }

        if (lastNameIndex !== null) {
            body.append('lastNameFieldIndex', lastNameIndex.toString());
        }

        return await this
            .request(`/tickets/${productId}/guest-list/import`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runEmpty();
    }

    async eventProducts(organizationId: string, eventIds: string[]): Promise<BaseResponse<EventProducts[]>> {
        return await this
            .request('/products')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .appendArray('EventIds', eventIds))
            .bearerToken()
            .runArrayAdapter(ProductAdapter.parseEventProductsFromObject);
    }

    async generateBarcodes(organizationId: string, productId: string, amount: number): Promise<HttpStatusCode> {
        return await this
            .request(`/tickets/${productId}/generate-barcode`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .queryString(QueryString
                .builder()
                .append('amount', amount))
            .bearerToken()
            .runStatusCode();
    }

    async importBarcodes(organizationId: string, productId: string, barcodes: BarcodeImport): Promise<HttpStatusCode> {
        const body = new FormData();
        body.append('media', barcodes.file);
        body.append('codeFieldIndex', barcodes.codeFieldIndex.toString());

        if (barcodes.emailFieldIndex !== null) {
            body.append('emailFieldIndex', barcodes.emailFieldIndex.toString());
        }

        if (barcodes.firstnameFieldIndex !== null) {
            body.append('firstnameFieldIndex', barcodes.firstnameFieldIndex.toString());
        }

        if (barcodes.lastnameFieldIndex !== null) {
            body.append('lastnameFieldIndex', barcodes.lastnameFieldIndex.toString());
        }

        body.append('delimiter', barcodes.delimiter.toString());
        body.append('hasHeader', barcodes.hasHeader.toString());

        return await this
            .request(`/tickets/${productId}/import`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runStatusCode();
    }

    async invalidate(organizationId: string, code: string, reason: string | null, returnToStock: boolean): Promise<BaseResponse<never>> {
        return await this
            .request(`/product/ticket/${code}/state/invalidate`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({
                reason,
                returnToStock
            })
            .runEmpty();
    }
}
