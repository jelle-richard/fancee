import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { BarcodeImport, BestSellingProduct, EventProducts, TicketFilter, TicketInformation, TicketListing } from '@fancee/data';

export interface IProductService {
    getTicket(organizationId: string, code: string): Promise<BaseResponse<TicketInformation>>;

    listTicket(organizationId: string, pageSize: number, page: number, filter: TicketFilter): Promise<BaseResponse<Paginated<TicketListing>>>;

    csvExportTicket(organizationId: string, filter: TicketFilter): Promise<BlobResponse>;

    getBestSelling(organizationId: string, limit: number, startDate: string, endDate: string): Promise<BaseResponse<BestSellingProduct[]>>;

    getBestSellingEvent(organizationId: string, eventId: string, limit: number, startDate: string, endDate: string): Promise<BaseResponse<BestSellingProduct[]>>;

    importGuests(organizationId: string, productId: string, media: Blob, emailIndex: number, quantityIndex: number, firstNameIndex: number | null, lastNameIndex: number | null, deductStock: boolean, delimiter: string, hasHeader: boolean): Promise<BaseResponse<never>>;

    eventProducts(organizationId: string, eventIds: string[]): Promise<BaseResponse<EventProducts[]>>;

    generateBarcodes(organizationId: string, productId: string, amount: number): Promise<HttpStatusCode>;

    importBarcodes(organizationId: string, productId: string, barcodes: BarcodeImport): Promise<HttpStatusCode>;

    invalidate(organizationId: string, code: string, reason: string | null, returnToStock: boolean): Promise<BaseResponse<never>>;
}
