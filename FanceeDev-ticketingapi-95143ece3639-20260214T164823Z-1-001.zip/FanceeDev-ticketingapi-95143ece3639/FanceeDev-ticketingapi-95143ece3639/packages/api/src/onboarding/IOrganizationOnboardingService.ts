import type { BaseResponse } from '@fancee/client';
import { Address, LegalEntity, OrganizationContact } from '@fancee/data';

export interface IOrganizationOnboardingService {
    updateCompany(organizationId: string, address: Address, legalEntity: LegalEntity): Promise<BaseResponse<never>>;

    updateFinance(organizationId: string, currencyShortCode: string, iban: string | null, bankAccountNumber: string | null, bic: string | null, vatCode: string | null, approximatedAnnualSalesAmount: number): Promise<BaseResponse<never>>;

    updateHolder(organizationId: string, firstName: string, lastName: string, supportContact: OrganizationContact | null): Promise<BaseResponse<never>>;
}
