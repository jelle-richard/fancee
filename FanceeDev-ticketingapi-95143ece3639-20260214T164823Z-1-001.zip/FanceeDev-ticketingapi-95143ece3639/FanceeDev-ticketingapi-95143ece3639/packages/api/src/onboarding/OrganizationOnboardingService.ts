import { BaseResponse, BaseService, HttpMethod } from '@fancee/client';
import { Address, LegalEntity, OrganizationContact } from '@fancee/data';
import type { IOrganizationOnboardingService } from '@';

export class OrganizationOnboardingService extends BaseService implements IOrganizationOnboardingService {
    async updateCompany(organizationId: string, address: Address, legalEntity: LegalEntity): Promise<BaseResponse<never>> {
        return await this
            .request('/user/organization/profile/company-info')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({address, legalEntity})
            .runEmpty();
    }

    async updateFinance(organizationId: string, currencyShortCode: string, iban: string | null, bankAccountNumber: string | null, bic: string | null, vatCode: string | null, approximatedAnnualSalesAmount: number): Promise<BaseResponse<never>> {
        return await this
            .request('/user/organization/profile/finance')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({currencyShortCode, iban, bankAccountNumber, bic, vatCode, approximatedAnnualSalesAmount})
            .runEmpty();
    }

    async updateHolder(organizationId: string, firstName: string, lastName: string, supportContact: OrganizationContact | null): Promise<BaseResponse<never>> {
        return await this
            .request('/user/organization/profile/holder')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({
                firstName, lastName, customerSupportContact: supportContact === null
                    ? null
                    : {
                        email: supportContact.email,
                        firstName: supportContact.firstName,
                        lastName: supportContact.lastName,
                        phoneNumber: supportContact.phoneNumber
                    }
            })
            .runEmpty();
    }
}
