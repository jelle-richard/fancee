import { BaseResponse, BaseService, BlobResponse, HttpMethod, HttpStatusCode } from '@fancee/client';
import { AdminRegisterAdapter, CountryCode, CountryGroupedCountryManagers, CountryManagerAdapter, OrganizationAdapter, OrganizationContractAddendum, OrganizationContractAlter, PackageType, RegisterCountryManager, RegisterCustomerServiceEmployee, UserType } from '@fancee/data';
import { IUserService } from '@';

export class UserService extends BaseService implements IUserService {
    async verified(verifyId: string): Promise<BaseResponse<boolean>> {
        return await this
            .request(`/user/verified/${verifyId}`)
            .method(HttpMethod.Get)
            .runData();
    }

    async createAccount(verifyId: string, password: string): Promise<HttpStatusCode> {
        return await this
            .request('/user/create')
            .method(HttpMethod.Post)
            .body({password, verifyId})
            .runStatusCode();
    }

    async updatePassword(currentPassword: string, newPassword: string): Promise<HttpStatusCode> {
        // note: backend should probably accept currentPassword.
        const oldPassword = currentPassword;

        return await this
            .request(`/user/change-password`)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({oldPassword, newPassword})
            .runStatusCode();
    }

    async forgotPassword(email: string): Promise<BaseResponse<string>> {
        return await this
            .request(`/user/forgot-password?email=${email}`)
            .runData();
    }

    async register(email: string, password: string, type: UserType | null, countryCode: CountryCode | null, organizationName: string | null, phoneNumber: string | null): Promise<HttpStatusCode> {
        return await this
            .request('/user')
            .method(HttpMethod.Post)
            .body({email, password, type, countryCode, organizationName, phoneNumber})
            .runStatusCode();
    }

    async resetPassword(resetToken: string, newPassword: string): Promise<HttpStatusCode> {
        return await this
            .request('/user/reset-password')
            .method(HttpMethod.Put)
            .body({resetToken, newPassword})
            .runStatusCode();
    }

    async assignCustomerServiceEmployeeToCountryManager(customerServiceEmployeeId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/admin/country-manager/assign/${customerServiceEmployeeId}`)
            .method(HttpMethod.Post)
            .bearerToken()
            .runStatusCode();
    }

    async registerCountryManager(countryManager: RegisterCountryManager): Promise<BaseResponse<string>> {
        return await this
            .request('/user/admin/country-manager')
            .method(HttpMethod.Post)
            .bearerToken()
            .body(AdminRegisterAdapter.parseRegisterCountryManagerToApiScheme(countryManager))
            .runData();
    }

    async registerCustomerServiceEmployee(customerServiceEmployee: RegisterCustomerServiceEmployee): Promise<BaseResponse<string>> {
        return await this
            .request('/user/admin/customer-service-employee')
            .method(HttpMethod.Post)
            .bearerToken()
            .body(AdminRegisterAdapter.parseRegisterCustomerServiceEmployeeToApiScheme(customerServiceEmployee))
            .runData();
    }

    async getActiveCountryManagers(): Promise<BaseResponse<CountryGroupedCountryManagers[]>> {
        return await this
            .request('/user/admin/country-manager/active')
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(CountryManagerAdapter.parseCountryGroupedCountryManagersFromObject);
    }

    async downloadContract(organizationId: string): Promise<BlobResponse> {
        return await this
            .request('/user/organization/contract/download/contract')
            .asOrganization(organizationId)
            .bearerToken()
            .fetchBlob();
    }

    async downloadContractAsZip(organizationId: string): Promise<BlobResponse> {
        return await this
            .request('/user/organization/contract/download/contract/zip')
            .asOrganization(organizationId)
            .bearerToken()
            .fetchBlob();
    }

    async signContract(organizationId: string, signature: Blob): Promise<HttpStatusCode> {
        const body = new FormData();
        body.append('media', signature);

        return await this
            .request('/user/organization/contract/sign')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runStatusCode();
    }

    async verify(verifyId: string): Promise<HttpStatusCode> {
        return await this
            .request('/user/verify')
            .method(HttpMethod.Post)
            .body({VerifyId: verifyId})
            .runStatusCode();
    }

    async getOrganizationHasCreatedEvents(organizationId: string): Promise<BaseResponse<boolean>> {
        return await this
            .request('/user/organization/events/any')
            .asOrganization(organizationId)
            .bearerToken()
            .runData();
    }

    async uploadAvatar(organizationId: string, file: File): Promise<BaseResponse<string>> {
        const body = new FormData();
        body.append('media', file);

        return await this
            .request('/user/avatar')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runData();
    }

    async deleteAvatar(organizationId: string): Promise<HttpStatusCode> {
        return await this
            .request('/user/avatar')
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async updatePackageRequest(organizationId: string, packageType: PackageType): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/request/package')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body({packageType: packageType})
            .bearerToken()
            .runStatusCode();
    }

    async blockEmail(organizationId: string, email: string): Promise<BaseResponse<string>> {
        return await this
            .request('/user/organization/blocked-email')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body({email})
            .bearerToken()
            .runData();
    }

    async updateBlockedEmail(organizationId: string, currentEmail: string, newEmail: string): Promise<BaseResponse<string>> {
        return await this
            .request('/user/organization/blocked-email')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .body({currentEmail, newEmail})
            .bearerToken()
            .runData();
    }

    async deleteBlockedEmail(organizationId: string, email: string): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/blocked-email')
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .body({email})
            .bearerToken()
            .runStatusCode();
    }

    async getBlockedEmails(organizationId: string): Promise<BaseResponse<string[]>> {
        return await this
            .request('/user/organization/blocked-emails/list')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runDataKey<{ blockedEmails: string[]; }>('blockedEmails');
    }

    async deleteBlockedEmails(organizationId: string): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/blocked-emails/list')
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async block(userId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/admin/block-user/${userId}`)
            .method(HttpMethod.Post)
            .bearerToken()
            .runStatusCode();
    }

    async unblock(userId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/admin/unblock-user/${userId}`)
            .method(HttpMethod.Post)
            .bearerToken()
            .runStatusCode();
    }

    async changeOrganizationPackageType(organizationId: string, packageType: PackageType): Promise<HttpStatusCode> {
        return await this
            .request(`/user/organization/contract/${organizationId}/package/${packageType}`)
            .method(HttpMethod.Put)
            .bearerToken()
            .runStatusCode();
    }

    async downloadContractAsAdmin(organizationId: string): Promise<BlobResponse> {
        return await this
            .request(`/user/organization/contract/${organizationId}/download`)
            .bearerToken()
            .fetchBlob();
    }

    async alterContract(organizationId: string, contract: OrganizationContractAlter): Promise<BaseResponse<never>> {
        return await this
            .request(`/user/organization/contract/${organizationId}/alter`)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(OrganizationAdapter.parseOrganizationContractAlterToApi(contract))
            .runEmpty();
    }

    async createContractAddendum(organizationId: string, addendum: OrganizationContractAddendum): Promise<BaseResponse<never>> {
        return await this
            .request(`/user/organization/contract/addendum/${organizationId}`)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(OrganizationAdapter.parseOrganizationContractAddendumToApi(addendum))
            .runEmpty();
    }

    async updateOrganizationImportantStatus(organizationId: string, important: boolean): Promise<BaseResponse<never>> {
        return await this
            .request(`/user/organization/${organizationId}/important/${important}`)
            .method(HttpMethod.Put)
            .bearerToken()
            .runEmpty();
    }
}
