import type { BaseResponse, BlobResponse, HttpStatusCode } from '@fancee/client';
import type { CountryCode, CountryGroupedCountryManagers, OrganizationContractAddendum, OrganizationContractAlter, PackageType, RegisterCountryManager, RegisterCustomerServiceEmployee, UserType } from '@fancee/data';

export interface IUserService {
    verified(verifyId: string): Promise<BaseResponse<boolean>>;

    createAccount(verifyId: string, password: string): Promise<HttpStatusCode>;

    updatePassword(currentPassword: string, newPassword: string): Promise<HttpStatusCode>;

    forgotPassword(email: string): Promise<BaseResponse<string>>;

    register(email: string, password: string, type: UserType | null, countryCode: CountryCode | null, organizationName: string | null, phoneNumber: string | null): Promise<HttpStatusCode>;

    resetPassword(resetToken: string, newPassword: string): Promise<HttpStatusCode>;

    registerCountryManager(countryManager: RegisterCountryManager): Promise<BaseResponse<string>>;

    registerCustomerServiceEmployee(customerServiceEmployee: RegisterCustomerServiceEmployee): Promise<BaseResponse<string>>;

    assignCustomerServiceEmployeeToCountryManager(customerServiceEmployeeId: string): Promise<HttpStatusCode>;

    getActiveCountryManagers(): Promise<BaseResponse<CountryGroupedCountryManagers[]>>;

    downloadContract(organizationId: string): Promise<BlobResponse>;

    downloadContractAsZip(organizationId: string): Promise<BlobResponse>;

    signContract(organizationId: string, signature: Blob): Promise<HttpStatusCode>;

    verify(verifyId: string): Promise<HttpStatusCode>;

    getOrganizationHasCreatedEvents(organizationId: string): Promise<BaseResponse<boolean>>;

    uploadAvatar(organizationId: string, file: File): Promise<BaseResponse<string>>;

    deleteAvatar(organizationId: string): Promise<HttpStatusCode>;

    updatePackageRequest(organizationId: string, packageType: PackageType): Promise<HttpStatusCode>;

    blockEmail(organizationId: string, email: string): Promise<BaseResponse<string>>;

    updateBlockedEmail(organizationId: string, currentEmail: string, newEmail: string): Promise<BaseResponse<string>>;

    deleteBlockedEmail(organizationId: string, email: string): Promise<HttpStatusCode>;

    getBlockedEmails(organizationId: string): Promise<BaseResponse<string[]>>;

    deleteBlockedEmails(organizationId: string): Promise<HttpStatusCode>;

    block(userId: string): Promise<HttpStatusCode>;

    unblock(userId: string): Promise<HttpStatusCode>;

    changeOrganizationPackageType(organizationId: string, packageType: PackageType): Promise<HttpStatusCode>;

    downloadContractAsAdmin(organizationId: string): Promise<BlobResponse>;

    alterContract(organizationId: string, contract: OrganizationContractAlter): Promise<BaseResponse<never>>;

    createContractAddendum(organizationId: string, addendum: OrganizationContractAddendum): Promise<BaseResponse<never>>;

    updateOrganizationImportantStatus(organizationId: string, isImportant: boolean): Promise<BaseResponse<never>>;
}
