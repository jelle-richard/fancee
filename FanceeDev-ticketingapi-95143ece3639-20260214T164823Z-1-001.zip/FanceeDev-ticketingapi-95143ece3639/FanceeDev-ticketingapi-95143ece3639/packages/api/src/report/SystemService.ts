import { BaseResponse, BaseService, HttpMethod, QueryString } from '@fancee/client';
import { Changelog, SystemAdapter } from '@fancee/data';
import { ISystemService } from '@';

export class SystemService extends BaseService implements ISystemService {
    async getChangelogs(countryCode: string): Promise<BaseResponse<Changelog[]>> {
        return await this
            .request(`/system/changelog`)
            .queryString(QueryString
                .builder()
                .append('countryCode', countryCode))
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(SystemAdapter.parseChangelogFromObject);
    }
}
