import type { BaseResponse } from '@fancee/client';
import type { Changelog } from '@fancee/data';

export interface ISystemService {
    getChangelogs(countryCode: string): Promise<BaseResponse<Changelog[]>>;
}
