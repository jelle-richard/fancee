import type { BaseResponse } from '@fancee/client';
import type { RevenueReportStatistics } from '@fancee/data';

export interface IRevenueService {
    accountRevenueReport(organizationId: string): Promise<BaseResponse<RevenueReportStatistics>>;

    eventRevenueReport(organizationId: string, eventId: string): Promise<BaseResponse<RevenueReportStatistics>>;
}
