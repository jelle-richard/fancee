import type { BaseResponse } from '@fancee/client';
import type { CountryCode, PlatformBalances, PlatformGrowthTargetProgression, TicketRevenueIndication } from '@fancee/data';

export interface IReportService {
    getPlatformGrowthTargets(year: number, countryCodes: CountryCode[]): Promise<BaseResponse<PlatformGrowthTargetProgression[]>>;

    getTicketRevenueIndication(year: number, countryCodes: CountryCode[]): Promise<BaseResponse<TicketRevenueIndication>>;

    getMonthlyBalancesForYear(year: number, countryCodes: CountryCode[]): Promise<BaseResponse<PlatformBalances>>;
}
