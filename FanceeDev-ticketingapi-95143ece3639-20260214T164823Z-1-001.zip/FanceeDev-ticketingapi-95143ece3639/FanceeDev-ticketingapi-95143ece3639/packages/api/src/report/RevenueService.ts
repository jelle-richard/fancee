import { BaseResponse, BaseService, HttpMethod } from '@fancee/client';
import { RevenueAdapter, RevenueReportStatistics } from '@fancee/data';
import { IRevenueService } from '@';

export class RevenueService extends BaseService implements IRevenueService {
    async accountRevenueReport(organizationId: string): Promise<BaseResponse<RevenueReportStatistics>> {
        return await this.request('/revenue')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(RevenueAdapter.parseRevenueReportFromObject);
    }

    async eventRevenueReport(organizationId: string, eventId: string): Promise<BaseResponse<RevenueReportStatistics>> {
        return await this.request(`/revenue/event/${eventId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(RevenueAdapter.parseRevenueReportFromObject);
    }
}
