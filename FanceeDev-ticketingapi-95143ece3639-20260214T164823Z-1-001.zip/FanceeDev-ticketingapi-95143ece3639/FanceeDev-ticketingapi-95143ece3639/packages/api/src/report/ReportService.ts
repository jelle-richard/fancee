import { BaseResponse, BaseService, HttpMethod, QueryString } from '@fancee/client';
import { CountryCode, PlatformBalances, PlatformGrowthTargetProgression, ReportAdapter, TicketRevenueIndication } from '@fancee/data';
import { IReportService } from '@';

export class ReportService extends BaseService implements IReportService {
    async getPlatformGrowthTargets(year: number, countryCodes: CountryCode[]): Promise<BaseResponse<PlatformGrowthTargetProgression[]>> {
        return await this
            .request(`/report/platform/growth/targets/${year}`)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .appendArray('countryCodes', countryCodes))
            .bearerToken()
            .runArrayAdapter(ReportAdapter.parsePlatformGrowthTargetProgression);
    }

    async getTicketRevenueIndication(year: number, countryCodes: CountryCode[]): Promise<BaseResponse<TicketRevenueIndication>> {
        return await this
            .request(`/report/platform/tickets/revenue/${year}`)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .appendArray('countryCodes', countryCodes))
            .bearerToken()
            .runAdapter(ReportAdapter.parseTicketRevenueIndicationFromObject);
    }

    async getMonthlyBalancesForYear(year: number, countryCodes: CountryCode[]): Promise<BaseResponse<PlatformBalances>> {
        return await this
            .request(`/report/platform/balance/${year}`)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .appendArray('countryCodes', countryCodes))
            .bearerToken()
            .runAdapter(ReportAdapter.parseMonthlyBalancesForYearFromObject);
    }
}
