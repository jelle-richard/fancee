import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { AppTeam, AppTeamListItem } from '@fancee/data';

export interface IAppTeamService {
    list(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<AppTeamListItem>>>;

    csvExport(organizationId: string, searchQuery: string): Promise<BlobResponse>;

    get(organizationId: string, appTeamId: string): Promise<BaseResponse<AppTeam>>;

    delete(organizationId: string, appTeamId: string): Promise<HttpStatusCode>;

    create(organizationId: string, appTeam: AppTeam): Promise<BaseResponse<string>>;

    update(organizationId: string, appTeamId: string, appTeam: AppTeam): Promise<HttpStatusCode>;
}
