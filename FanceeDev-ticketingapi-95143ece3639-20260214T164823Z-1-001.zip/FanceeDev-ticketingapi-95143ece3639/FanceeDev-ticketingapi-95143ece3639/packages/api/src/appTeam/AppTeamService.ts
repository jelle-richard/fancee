import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { AppTeam, AppTeamAdapter, AppTeamListItem } from '@fancee/data';
import { IAppTeamService } from '@';

export class AppTeamService extends BaseService implements IAppTeamService {
    @Debounce(500)
    async list(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<AppTeamListItem>>> {
        return await this
            .request('/user/app-teams/list')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery))
            .bearerToken()
            .runPaginatedAdapter(AppTeamAdapter.parseAppTeamListItemFromObject);
    }

    async csvExport(organizationId: string, searchQuery: string): Promise<BlobResponse> {
        return await this
            .request('/user/app-teams/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    async get(organizationId: string, appTeamId: string): Promise<BaseResponse<AppTeam>> {
        return await this
            .request(`/user/app-team/${appTeamId}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(appTeam => AppTeamAdapter.parseAppTeamFromObject(appTeam, appTeamId));
    }

    async delete(organizationId: string, appTeamId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/app-team/${appTeamId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async create(organizationId: string, appTeam: AppTeam): Promise<BaseResponse<string>> {
        return await this
            .request('/user/app-team')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(AppTeamAdapter.parseAppTeamToApi(appTeam))
            .runDataKey<{ id: string; }>('id');
    }

    async update(organizationId: string, appTeamId: string, appTeam: AppTeam): Promise<HttpStatusCode> {
        return await this
            .request(`/user/app-team/${appTeamId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(AppTeamAdapter.parseAppTeamToApi(appTeam))
            .runStatusCode();
    }
}
