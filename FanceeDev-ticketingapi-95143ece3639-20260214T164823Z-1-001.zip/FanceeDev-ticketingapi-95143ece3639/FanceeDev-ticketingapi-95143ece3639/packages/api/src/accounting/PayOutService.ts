import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, Paginated, QueryString } from '@fancee/client';
import { PayOutAdapter, PayOutExportListing, PayOutListFilter } from '@fancee/data';
import { IPayOutService } from '@';

export class PayOutService extends BaseService implements IPayOutService {
    async createExport(): Promise<BaseResponse<string>> {
        return await this
            .request('/accounting/pay-out/create-export')
            .method(HttpMethod.Post)
            .bearerToken()
            .runDataKey<{ id: string; }>('id');
    }

    async downloadExport(exportId: string): Promise<BlobResponse> {
        return await this
            .request(`/accounting/pay-out/download-export/${exportId}`)
            .method(HttpMethod.Get)
            .bearerToken()
            .fetchBlob();
    }

    @Debounce(500)
    async list(pageSize: number, page: number, filter: PayOutListFilter): Promise<BaseResponse<Paginated<PayOutExportListing>>> {
        return await this
            .request('/accounting/pay-out/export/list')
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery)
                .append('Options.Status', filter.status)
            )
            .method(HttpMethod.Get)
            .bearerToken()
            .runPaginatedAdapter(PayOutAdapter.parsePayOutExportListItemFromObject);
    }

    async markAsProcessed(exportId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/accounting/pay-out/export/${exportId}/status/processed`)
            .method(HttpMethod.Put)
            .bearerToken()
            .runEmpty();
    }

    async pendingPayouts(): Promise<BaseResponse<number>> {
        return await this
            .request('/accounting/pay-out/pending')
            .method(HttpMethod.Get)
            .bearerToken()
            .runData();
    }
}
