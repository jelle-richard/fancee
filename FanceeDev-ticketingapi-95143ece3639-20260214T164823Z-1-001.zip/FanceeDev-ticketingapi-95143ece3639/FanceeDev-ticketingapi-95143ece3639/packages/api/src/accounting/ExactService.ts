import { BaseResponse, BaseService, HttpMethod, HttpStatusCode } from '@fancee/client';
import { ConfigurableItems, ConfigurableJournal, Configuration, ConfigurationAdapter, Item, ItemAdapter, Journal, JournalAdapter } from '@fancee/data';
import { IExactService } from '@';

export class ExactService extends BaseService implements IExactService {
    async authenticate(): Promise<BaseResponse<string>> {
        return await this
            .request('/accounting/integrations/exact/authenticate')
            .bearerToken()
            .runData();
    }

    async getEnabled(): Promise<BaseResponse<boolean>> {
        return await this
            .request('/accounting/integrations/exact/enabled')
            .bearerToken()
            .runData();
    }

    async getJournals(): Promise<BaseResponse<Journal[]>> {
        return await this
            .request('/accounting/integrations/exact/journals')
            .bearerToken()
            .runArrayAdapter(JournalAdapter.parseJournalFromObject);
    }

    async getItems(): Promise<BaseResponse<Item[]>> {
        return await this
            .request('/accounting/integrations/exact/items')
            .bearerToken()
            .runArrayAdapter(ItemAdapter.parseItemFromObject);
    }

    async configure(request: ConfigurableJournal): Promise<HttpStatusCode> {
        return await this
            .request('/accounting/integrations/exact/configure')
            .method(HttpMethod.Post)
            .bearerToken()
            .body(request)
            .runStatusCode();
    }

    async configureItems(request: ConfigurableItems): Promise<HttpStatusCode> {
        return await this
            .request('/accounting/integrations/exact/configure/items')
            .method(HttpMethod.Post)
            .bearerToken()
            .body(request)
            .runStatusCode();
    }

    async configuration(): Promise<BaseResponse<Configuration>> {
        return await this
            .request('/accounting/integrations/exact/configuration')
            .bearerToken()
            .runAdapter(ConfigurationAdapter.parseConfigurationFromObject);
    }
}
