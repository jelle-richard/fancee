import type { BaseResponse, HttpStatusCode } from '@fancee/client';
import type { ConfigurableItems, ConfigurableJournal, Item, Journal } from '@fancee/data';

export interface IExactService {
    authenticate(): Promise<BaseResponse<string>>;

    getEnabled(): Promise<BaseResponse<boolean>>;

    getJournals(): Promise<BaseResponse<Journal[]>>;

    getItems(): Promise<BaseResponse<Item[]>>;

    configure(request: ConfigurableJournal): Promise<HttpStatusCode>;

    configureItems(request: ConfigurableItems): Promise<HttpStatusCode>;
}
