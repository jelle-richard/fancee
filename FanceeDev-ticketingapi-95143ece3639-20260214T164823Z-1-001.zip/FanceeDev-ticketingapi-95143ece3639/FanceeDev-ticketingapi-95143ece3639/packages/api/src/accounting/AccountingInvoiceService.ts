import { BaseResponse, BaseService } from '@fancee/client';
import { IAccountingInvoiceService } from '@';

export class AccountingInvoiceService extends BaseService implements IAccountingInvoiceService {
    async getSpecificationNames(): Promise<BaseResponse<string[]>> {
        return await this
            .request('/accounting/invoice/specification-names')
            .bearerToken()
            .runData();
    }
}
