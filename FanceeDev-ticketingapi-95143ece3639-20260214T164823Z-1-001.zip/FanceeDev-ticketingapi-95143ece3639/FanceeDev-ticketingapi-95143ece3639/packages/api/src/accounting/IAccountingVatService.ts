import type { BaseResponse } from '@fancee/client';
import type { CountryCode } from '@fancee/data';

export interface IAccountingVatService {
    getCountries(): Promise<BaseResponse<Partial<Record<CountryCode, boolean>>>>;
}
