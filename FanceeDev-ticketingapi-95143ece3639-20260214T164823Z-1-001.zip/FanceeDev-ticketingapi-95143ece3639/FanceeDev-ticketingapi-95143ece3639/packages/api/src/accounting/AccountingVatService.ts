import { type BaseResponse, BaseService } from '@fancee/client';
import type { IAccountingVatService } from '@';
import type { CountryCode } from '@fancee/data';

export class AccountingVatService extends BaseService implements IAccountingVatService {
    async getCountries(): Promise<BaseResponse<Partial<Record<CountryCode, boolean>>>> {
        return await this
            .request('/accounting/vat/countries')
            .bearerToken()
            .runData();
    }
}
