import type { BaseResponse, BlobResponse, Paginated } from '@fancee/client';
import type { PayOutExportListing, PayOutListFilter } from '@fancee/data';

export interface IPayOutService {
    list(pageSize: number, page: number, filter: PayOutListFilter): Promise<BaseResponse<Paginated<PayOutExportListing>>>;

    markAsProcessed(exportId: string): Promise<BaseResponse<never>>;

    downloadExport(exportId: string): Promise<BlobResponse>;

    createExport(): Promise<BaseResponse<string>>;

    pendingPayouts(): Promise<BaseResponse<number>>;
}
