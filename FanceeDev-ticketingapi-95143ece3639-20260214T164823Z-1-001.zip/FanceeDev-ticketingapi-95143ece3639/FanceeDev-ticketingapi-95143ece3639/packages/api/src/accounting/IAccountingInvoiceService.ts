import type { BaseResponse } from '@fancee/client';

export interface IAccountingInvoiceService {
    getSpecificationNames(): Promise<BaseResponse<string[]>>;
}
