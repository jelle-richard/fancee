import { BaseResponse, BlobResponse, Paginated } from '@fancee/client';
import { AssignedPaymentMethod, CombinedShop, CombinedShopListing, EventPaymentMethod, Media, SharedShopListing, ShopsSharedWithMeListing } from '@fancee/data';

export interface ICombinedShopService {
    createShop(organizationId: string, combinedShop: CombinedShop): Promise<BaseResponse<string>>;

    getShop(organizationId: string, combinedShopCode: string): Promise<BaseResponse<CombinedShop>>;

    updateShop(organizationId: string, combinedShopCode: string, combinedShop: CombinedShop): Promise<BaseResponse<never>>;

    deleteShop(organizationId: string, combinedShopCode: string): Promise<BaseResponse<never>>;

    getShopPaymentMethods(organizationId: string, combinedShopCode: string): Promise<BaseResponse<EventPaymentMethod[]>>;

    updateShopPaymentMethods(organizationId: string, combinedShopCode: string, paymentMethod: AssignedPaymentMethod[]): Promise<BaseResponse<never>>;

    list(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<CombinedShopListing>>>;

    csvExport(organizationId: string, searchQuery: string): Promise<BlobResponse>;

    uploadMedia(organizationId: string, combinedShopCode: string, file: File): Promise<BaseResponse<string>>;

    mediaReposition(organizationId: string, combinedShopCode: string, positions: string[]): Promise<BaseResponse<never>>;

    mediaRemove(organizationId: string, fileId: string, combinedShopCode: string): Promise<BaseResponse<never>>;

    mediaFocalPoint(organizationId: string, fileId: string, combinedShopCode: string, media: Media): Promise<BaseResponse<never>>;

    sharedShop(organizationId: string, publicCode: string, shopCodes: string[]): Promise<BaseResponse<never>>;

    sharedShopList(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<SharedShopListing>>>;

    csvExportSharedShopList(organizationId: string, searchQuery: string): Promise<BlobResponse>;

    shopSharedWithMeList(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<ShopsSharedWithMeListing>>>;
}
