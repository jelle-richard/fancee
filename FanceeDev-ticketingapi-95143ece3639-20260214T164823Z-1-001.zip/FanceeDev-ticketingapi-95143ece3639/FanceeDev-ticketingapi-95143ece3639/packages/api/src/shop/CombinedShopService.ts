import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, Paginated, QueryString } from '@fancee/client';
import { AssignedPaymentMethod, CombinedShop, CombinedShopAdapter, CombinedShopListing, EventPaymentMethod, Media, MediaAdapter, PaymentAdapter, SharedShopListing, ShopsSharedWithMeListing } from '@fancee/data';
import { ICombinedShopService } from '@';

export class CombinedShopService extends BaseService implements ICombinedShopService {
    async createShop(organizationId: string, combinedShop: CombinedShop): Promise<BaseResponse<string>> {
        return await this
            .request('/shop/combined')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body(CombinedShopAdapter.parseCombinedShopToApi(combinedShop))
            .bearerToken()
            .runData();
    }

    async getShop(organizationId: string, combinedShopCode: string): Promise<BaseResponse<CombinedShop>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(CombinedShopAdapter.parseCombinedShopFromObject);
    }

    async updateShop(organizationId: string, combinedShopCode: string, combinedShop: CombinedShop): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .body(CombinedShopAdapter.parseCombinedShopToApi(combinedShop))
            .bearerToken()
            .runEmpty();
    }

    async deleteShop(organizationId: string, combinedShopCode: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    async getShopPaymentMethods(organizationId: string, combinedShopCode: string): Promise<BaseResponse<EventPaymentMethod[]>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}/payment-methods`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(PaymentAdapter.parseEventPaymentMethodFromObject);
    }

    async updateShopPaymentMethods(organizationId: string, combinedShopCode: string, paymentMethods: AssignedPaymentMethod[]): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}/payment-methods`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .body({
                paymentMethods: paymentMethods
                    .filter(paymentMethod => paymentMethod.paidBy !== null)
                    .map(PaymentAdapter.parseAssignedPaymentMethodToApi)
            })
            .bearerToken()
            .runEmpty();
    }

    @Debounce(500)
    async list(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<CombinedShopListing>>> {
        return await this
            .request('/shop/combined/list')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery))
            .bearerToken()
            .runPaginatedAdapter(CombinedShopAdapter.parseCombinedShopListingFromObject);
    }

    async csvExport(organizationId: string, searchQuery: string): Promise<BlobResponse> {
        return await this
            .request('/shop/combined/export/csv')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    async uploadMedia(organizationId: string, combinedShopCode: string, file: File): Promise<BaseResponse<string>> {
        const body = new FormData();
        body.append('media', file);

        return await this
            .request(`/shop/combined/${combinedShopCode}/media`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body(body)
            .bearerToken()
            .runData();
    }

    async mediaReposition(organizationId: string, combinedShopCode: string, positions: string[]): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}/media/reposition`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .body(positions)
            .bearerToken()
            .runEmpty();
    }

    async mediaRemove(organizationId: string, fileId: string, combinedShopCode: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}/media/${fileId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runEmpty();
    }

    async mediaFocalPoint(organizationId: string, fileId: string, combinedShopCode: string, media: Media): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop/combined/${combinedShopCode}/media/${fileId}/focal-point`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(media.focalPoint ? MediaAdapter.parseFocalPointToApi(media.focalPoint) : null)
            .runEmpty();
    }

    async sharedShop(organizationId: string, publicCode: string, shopCodes: string[]): Promise<BaseResponse<never>> {
        return await this
            .request('/shared/shop')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body({
                publicCode,
                shopCodes
            })
            .bearerToken()
            .runEmpty();
    }

    async sharedShopList(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<SharedShopListing>>> {
        return await this
            .request('/shared/shop/list')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery))
            .bearerToken()
            .runPaginatedAdapter(CombinedShopAdapter.parseSharedShopListingFromObject);
    }

    async csvExportSharedShopList(organizationId: string, searchQuery: string): Promise<BlobResponse> {
        return await this
            .request('/shared/shop/export')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    async shopSharedWithMeList(organizationId: string, pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<Paginated<ShopsSharedWithMeListing>>> {
        return await this
            .request('/shared/shop/with-me/list')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery))
            .bearerToken()
            .runPaginatedAdapter(CombinedShopAdapter.parseSharedWithMeListingFromObject);
    }
}
