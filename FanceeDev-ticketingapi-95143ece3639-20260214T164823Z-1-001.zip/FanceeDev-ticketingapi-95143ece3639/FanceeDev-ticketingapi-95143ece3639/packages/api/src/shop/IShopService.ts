import type { BaseResponse } from '@fancee/client';
import type { OrderComplete, Reservation, ReservedProduct, ShopDetails, ShopOrder } from '@fancee/data';

export interface IShopService {
    get(shopCode: string, campaignCode: string | null): Promise<BaseResponse<ShopDetails>>;

    order(shopCode: string, order: ShopOrder): Promise<BaseResponse<OrderComplete>>;

    reserve(shopCode: string, products: ReservedProduct[], campaignCode: string | null, secureCode: string | null): Promise<BaseResponse<Reservation>>;
}
