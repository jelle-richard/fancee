import { BaseResponse, BlobResponse, Paginated } from '@fancee/client';
import { SecureCode, SecureCodeImportCsv, SecureCodeListFilter, SecureCodeListing } from '@fancee/data';

export interface ISecureCodeService {
    create(organizationId: string, shopCode: string, secureCode: SecureCode): Promise<BaseResponse<never>>;

    update(organizationId: string, shopCode: string, code: string, secureCode: SecureCode): Promise<BaseResponse<never>>;

    delete(organizationId: string, shopCode: string, code: string): Promise<BaseResponse<never>>;

    isApplicable(shopCode: string, code: string): Promise<BaseResponse<never>>;

    list(organizationId: string, shopCode: string, pageSize: number, page: number, filter: SecureCodeListFilter): Promise<BaseResponse<Paginated<SecureCodeListing>>>;

    csvExport(organizationId: string, shopCode: string, filter: SecureCodeListFilter): Promise<BlobResponse>;

    import(organizationId: string, shopCode: string, csvImportFile: SecureCodeImportCsv): Promise<BaseResponse<never>>;

    importPreRegister(organizationId: string, shopCode: string, preRegisterCode: string): Promise<BaseResponse<never>>;

    deleteUnused(organizationId: string, shopCode: string): Promise<BaseResponse<never>>;
}
