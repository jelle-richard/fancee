import { BaseResponse, BaseService, HttpMethod, QueryString } from '@fancee/client';
import { OrderAdapter, OrderComplete, Reservation, ReservationAdapter, ReservedProduct, ShopAdapter, ShopDetails, ShopOrder } from '@fancee/data';
import { IShopService } from '@';

export class ShopService extends BaseService implements IShopService {
    async get(shopCode: string, campaignCode: string | null): Promise<BaseResponse<ShopDetails>> {
        return await this
            .request(`/shop/${shopCode}`)
            .queryString(QueryString.builder()
                .append('campaignCode', campaignCode))
            .runAdapter(ShopAdapter.parseFromObject);
    }

    async order(shopCode: string, order: ShopOrder): Promise<BaseResponse<OrderComplete>> {
        return await this
            .request(`/order/${shopCode}`)
            .method(HttpMethod.Post)
            .body(OrderAdapter.parseShopOrderToApi(order))
            .runAdapter(OrderAdapter.parseOrderCompleteFromObject);
    }

    async reserve(shopCode: string, products: ReservedProduct[], campaignCode: string | null, secureCode: string | null): Promise<BaseResponse<Reservation>> {
        return await this
            .request(`/reserve/${shopCode}`)
            .method(HttpMethod.Post)
            .queryString(QueryString.builder()
                .append('campaignCode', campaignCode)
                .append('secureCode', secureCode))
            .body({
                products: products.map(ShopAdapter.parseReservedProductToApi)
            })
            .runAdapter(ReservationAdapter.parseReservationFromObject);
    }
}
