import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, Paginated, QueryString } from '@fancee/client';
import { SecureCode, SecureCodeAdapter, SecureCodeImportCsv, SecureCodeListFilter, SecureCodeListing } from '@fancee/data';
import { ISecureCodeService } from '@';

export class SecureCodeService extends BaseService implements ISecureCodeService {
    async create(organizationId: string, shopCode: string, secureCode: SecureCode): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop-secure-code/${shopCode}`)
            .method(HttpMethod.Post)
            .body(SecureCodeAdapter.parseSecureCodeToObject(secureCode))
            .asOrganization(organizationId)
            .bearerToken()
            .runEmpty();
    }

    async update(organizationId: string, shopCode: string, code: string, secureCode: SecureCode): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop-secure-code/${shopCode}/${code}`)
            .method(HttpMethod.Put)
            .body(SecureCodeAdapter.parseSecureCodeToObject(secureCode))
            .asOrganization(organizationId)
            .bearerToken()
            .runEmpty();
    }

    async delete(organizationId: string, shopCode: string, code: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop-secure-code/${shopCode}/${code}`)
            .method(HttpMethod.Delete)
            .asOrganization(organizationId)
            .bearerToken()
            .runEmpty();
    }

    @Debounce(2000)
    async isApplicable(shopCode: string, code: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop-secure-code/${shopCode}/${code}/applicable`)
            .runEmpty();
    }

    @Debounce(500)
    async list(organizationId: string, shopCode: string, pageSize: number, page: number, filter: SecureCodeListFilter): Promise<BaseResponse<Paginated<SecureCodeListing>>> {
        return await this
            .request(`/shop-secure-codes/${shopCode}/list`)
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.searchQuery))
            .bearerToken()
            .runPaginatedAdapter(SecureCodeAdapter.parseSecureCodeListingFromObject);
    }

    async csvExport(organizationId: string, shopCode: string, filter: SecureCodeListFilter): Promise<BlobResponse> {
        return await this
            .request(`/shop-secure-codes/${shopCode}/export/csv`)
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('Options.SearchQuery', filter.searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    async import(organizationId: string, shopCode: string, csvImportFile: SecureCodeImportCsv): Promise<BaseResponse<never>> {
        const body = new FormData();
        body.append('media', csvImportFile.media);
        body.append('codeFieldIndex', csvImportFile.codeIndex.toString());
        body.append('usesFieldIndex', csvImportFile.usesIndex.toString());
        body.append('delimiter', csvImportFile.delimiter);
        body.append('hasHeader', csvImportFile.hasHeader.toString());

        return await this
            .request(`/shop-secure-codes/${shopCode}/import`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(body)
            .runEmpty();
    }

    async importPreRegister(organizationId: string, shopCode: string, preRegisterCode: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop-secure-codes/${shopCode}/preRegister/import/${preRegisterCode}`)
            .method(HttpMethod.Post)
            .asOrganization(organizationId)
            .bearerToken()
            .runEmpty();
    }

    async deleteUnused(organizationId: string, shopCode: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/shop-secure-codes/${shopCode}`)
            .method(HttpMethod.Delete)
            .asOrganization(organizationId)
            .bearerToken()
            .runEmpty();
    }
}
