import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { ApplicableDiscount, Discount, DiscountAdapter, DiscountFilter, DiscountListItem } from '@fancee/data';
import { IDiscountService } from '@';

export class DiscountService extends BaseService implements IDiscountService {
    async create(organizationId: string, discount: Discount): Promise<BaseResponse<string>> {
        return await this
            .request('/discount')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(DiscountAdapter.toDiscountRequest(discount))
            .runData();
    }

    async csvExport(organizationId: string, filter: DiscountFilter): Promise<BlobResponse> {
        return await this
            .request('/discounts/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.search)
                .appendArray('ShopCodes', filter.shopCodes)
                .appendArray('ProductIds', filter.productIds)
                .append('IncludeExpired', filter.includeExpired)
            )
            .bearerToken()
            .fetchBlob();
    }

    async get(organizationId: string, id: string): Promise<BaseResponse<Discount>> {
        return await this
            .request(`/discount/${id}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(DiscountAdapter.parseDiscountFromObject);
    }

    @Debounce(500)
    async list(organizationId: string, pageSize: number, page: number, filter: DiscountFilter): Promise<BaseResponse<Paginated<DiscountListItem>>> {
        return await this
            .request('/discounts/list')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', filter.search)
                .appendArray('Options.ShopCodes', filter.shopCodes)
                .appendArray('Options.ProductIds', filter.productIds)
                .append('Options.IncludeExpired', filter.includeExpired))
            .bearerToken()
            .runPaginatedAdapter(DiscountAdapter.parseDiscountListItemFromObject);
    }

    async delete(organizationId: string, id: string): Promise<HttpStatusCode> {
        return await this
            .request(`/discount/${id}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async update(organizationId: string, id: string, discount: Discount): Promise<HttpStatusCode> {
        return await this
            .request(`/discount/${id}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(DiscountAdapter.toDiscountRequest(discount))
            .runStatusCode();
    }

    @Debounce(1000)
    async apply(reservationReference: string, discountCode: string): Promise<BaseResponse<ApplicableDiscount>> {
        return await this
            .request(`/reserve/${reservationReference}/discount`)
            .method(HttpMethod.Put)
            .queryString(QueryString
                .builder()
                .append('discountCode', discountCode))
            .runAdapter(DiscountAdapter.applicableDiscountFromObject);
    }

    async remove(reservationReference: string): Promise<HttpStatusCode> {
        return await this
            .request(`/reserve/${reservationReference}/discount`)
            .method(HttpMethod.Delete)
            .runStatusCode();
    }
}
