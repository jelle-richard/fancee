import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { ApplicableDiscount, Discount, DiscountFilter, DiscountListItem } from '@fancee/data';

export interface IDiscountService {
    get(organizationId: string, id: string): Promise<BaseResponse<Discount>>;

    create(organizationId: string, discount: Discount): Promise<BaseResponse<string>>;

    update(organizationId: string, id: string, discount: Discount): Promise<HttpStatusCode>;

    delete(organizationId: string, id: string): Promise<HttpStatusCode>;

    list(organizationId: string, pageSize: number, page: number, filter: DiscountFilter): Promise<BaseResponse<Paginated<DiscountListItem>>>;

    csvExport(organizationId: string, filter: DiscountFilter): Promise<BlobResponse>;

    apply(reservationReference: string, discountCode: string): Promise<BaseResponse<ApplicableDiscount>>;

    remove(reservationReference: string): Promise<HttpStatusCode>;
}
