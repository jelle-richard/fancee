export type { ICampaignService } from './ICampaignService';
export { CampaignService } from './CampaignService';
