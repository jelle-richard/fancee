import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { Campaign, CampaignFilter, ConfigurableCampaign } from '@fancee/data';

export interface ICampaignService {
    get(organizationId: string, code: string): Promise<BaseResponse<Campaign>>;

    update(organizationId: string, code: string, campaign: ConfigurableCampaign): Promise<HttpStatusCode>;

    delete(organizationId: string, code: string): Promise<HttpStatusCode>;

    list(organizationId: string, filter: CampaignFilter, pageSize: number, page: number): Promise<BaseResponse<Paginated<Campaign>>>;

    export(organizationId: string, search: string): Promise<BlobResponse>;

    create(organizationId: string, campaign: ConfigurableCampaign): Promise<HttpStatusCode>;
}
