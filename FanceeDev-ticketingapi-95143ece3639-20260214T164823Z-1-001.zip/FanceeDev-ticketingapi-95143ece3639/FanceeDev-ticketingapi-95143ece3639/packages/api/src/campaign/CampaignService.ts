import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { Campaign, CampaignAdapter, CampaignFilter, ConfigurableCampaign } from '@fancee/data';
import { ICampaignService } from '@';

export class CampaignService extends BaseService implements ICampaignService {
    async create(organizationId: string, campaign: ConfigurableCampaign): Promise<HttpStatusCode> {
        return await this
            .request('/campaign')
            .method(HttpMethod.Post)
            .body(CampaignAdapter.parseConfigurableCampaignToObject(campaign))
            .asOrganization(organizationId)
            .bearerToken()
            .runStatusCode();
    }

    async delete(organizationId: string, code: string): Promise<HttpStatusCode> {
        return await this
            .request(`/campaign/${code}`)
            .method(HttpMethod.Delete)
            .asOrganization(organizationId)
            .bearerToken()
            .runStatusCode();
    }

    async export(organizationId: string, search: string): Promise<BlobResponse> {
        return await this
            .request('/campaign/export/csv')
            .queryString(QueryString
                .builder()
                .append('SearchQuery', search))
            .asOrganization(organizationId)
            .bearerToken()
            .fetchBlob();
    }

    async get(organizationId: string, code: string): Promise<BaseResponse<Campaign>> {
        return await this
            .request(`/campaign/${code}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(CampaignAdapter.parseCampaignFromObject);
    }

    @Debounce(500)
    async list(organizationId: string, filter: CampaignFilter, pageSize: number, page: number): Promise<BaseResponse<Paginated<Campaign>>> {
        return await this
            .request('/campaign/list')
            .queryString(QueryString
                .builder()
                .append('Options.SearchQuery', filter.searchQuery)
                .append('PageSize', pageSize)
                .append('Page', page))
            .asOrganization(organizationId)
            .bearerToken()
            .runPaginatedAdapter(CampaignAdapter.parseCampaignFromObject);
    }

    async update(organizationId: string, code: string, campaign: ConfigurableCampaign): Promise<HttpStatusCode> {
        return await this
            .request(`/campaign/${code}`)
            .method(HttpMethod.Put)
            .body(CampaignAdapter.parseConfigurableCampaignToObject(campaign))
            .asOrganization(organizationId)
            .bearerToken()
            .runStatusCode();
    }
}
