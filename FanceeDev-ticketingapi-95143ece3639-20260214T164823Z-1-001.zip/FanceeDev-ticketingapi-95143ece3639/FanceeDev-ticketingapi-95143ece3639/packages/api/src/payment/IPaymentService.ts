import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { TimedWalletBalanceSetting, WalletBalanceSetting, WalletPaymentType, WalletTransaction } from '@fancee/data';

export interface IPaymentService {
    createSession(reservationReference: string): Promise<BaseResponse<object>>;

    getBalance(organizationId: string): Promise<BaseResponse<WalletBalanceSetting>>;

    getBalanceHistory(organizationId: string, startDate: string, endDate: string): Promise<BaseResponse<TimedWalletBalanceSetting[]>>;

    getWalletTransactions(organizationId: string, pageSize: number, page: number, searchQuery: string | null, type: WalletPaymentType | null): Promise<BaseResponse<Paginated<WalletTransaction>>>;

    csvExportWalletTransactions(organizationId: string, searchQuery: string, type: WalletPaymentType | null): Promise<BlobResponse>;

    requestWalletPayout(organizationId: string, cents: number): Promise<HttpStatusCode>;

    downloadWalletReceipt(organizationId: string, fileId: string): Promise<BlobResponse>;

    getOrganizationBalance(organizationId: string): Promise<BaseResponse<WalletBalanceSetting>>;

    getOrganizationBalanceHistory(organizationId: string, startDate: string, endDate: string): Promise<BaseResponse<TimedWalletBalanceSetting[]>>;

    getOrganizationWalletTransactions(organizationId: string, pageSize: number, page: number, searchQuery: string | null, type: WalletPaymentType | null): Promise<BaseResponse<Paginated<WalletTransaction>>>;

    csvExportOrganizationWalletTransactions(organizationId: string, searchQuery: string, type: WalletPaymentType | null): Promise<BlobResponse>;

    downloadOrganizationWalletReceipt(organizationId: string, fileId: string): Promise<BlobResponse>;
}
