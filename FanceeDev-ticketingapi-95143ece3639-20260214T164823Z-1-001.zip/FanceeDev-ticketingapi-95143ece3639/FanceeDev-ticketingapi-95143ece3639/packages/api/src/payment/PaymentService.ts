import { BaseResponse, BaseService, BlobResponse, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { PaymentAdapter, TimedWalletBalanceSetting, WalletBalanceSetting, WalletPaymentType, WalletTransaction } from '@fancee/data';
import { IPaymentService } from '@';

export class PaymentService extends BaseService implements IPaymentService {
    async createSession(reservationReference: string): Promise<BaseResponse<object>> {
        return await this
            .request('/payment/session')
            .method(HttpMethod.Post)
            .body({
                ReservationReference: reservationReference
            })
            .runData();
    }

    async getBalance(organizationId: string): Promise<BaseResponse<WalletBalanceSetting>> {
        return await this
            .request('/payment/wallet/balance')
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(PaymentAdapter.parseWalletBalanceSettingFromObject);
    }

    async getBalanceHistory(organizationId: string, startDate: string, endDate: string): Promise<BaseResponse<TimedWalletBalanceSetting[]>> {
        //Todo: @Bas make a url builder to negate issue where Nginx cant parse space in DateTime
        return await this
            .request(`/payment/wallet/balance/${startDate}/${endDate}`.replaceAll(' ', 'T'))
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(PaymentAdapter.parseTimedWalletBalanceSettingFromObject);
    }

    async getWalletTransactions(organizationId: string, pageSize: number, page: number, searchQuery: string | null, type: WalletPaymentType | null): Promise<BaseResponse<Paginated<WalletTransaction>>> {
        return await this
            .request(`/payment/wallet/transaction/list`)
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery)
                .append('Options.Type', type)
            )
            .method(HttpMethod.Get)
            .bearerToken()
            .runPaginatedAdapter(PaymentAdapter.parseWalletTransactionFromObject);
    }

    async csvExportWalletTransactions(organizationId: string, searchQuery: string, type: WalletPaymentType | null): Promise<BlobResponse> {
        return await this
            .request('/payment/wallet/transaction/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', searchQuery)
                .append('Type', type)
            )
            .method(HttpMethod.Get)
            .bearerToken()
            .fetchBlob();
    }

    async downloadWalletReceipt(organizationId: string, fileId: string): Promise<BlobResponse> {
        return await this
            .request(`/payment/wallet/payout/download-receipt/${fileId}`)
            .asOrganization(organizationId)
            .bearerToken()
            .fetchBlob();
    }

    async requestWalletPayout(organizationId: string, cents: number): Promise<HttpStatusCode> {
        return await this
            .request('/payment/wallet/payout/request')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body({
                cents: cents
            })
            .bearerToken()
            .runStatusCode();
    }

    async getOrganizationBalance(organizationId: string): Promise<BaseResponse<WalletBalanceSetting>> {
        return await this
            .request(`/payment/wallet/organization/${organizationId}/balance`)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(PaymentAdapter.parseWalletBalanceSettingFromObject);
    }

    async getOrganizationBalanceHistory(organizationId: string, startDate: string, endDate: string): Promise<BaseResponse<TimedWalletBalanceSetting[]>> {
        return await this
            .request(`/payment/wallet/organization/${organizationId}/balance/${startDate}/${endDate}`.replaceAll(' ', 'T'))
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(PaymentAdapter.parseTimedWalletBalanceSettingFromObject);
    }

    async getOrganizationWalletTransactions(organizationId: string, pageSize: number, page: number, searchQuery: string | null, type: WalletPaymentType | null): Promise<BaseResponse<Paginated<WalletTransaction>>> {
        return await this
            .request(`/payment/wallet/organization/${organizationId}/transaction/list`)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.SearchQuery', searchQuery)
                .append('Options.Type', type)
            )
            .method(HttpMethod.Get)
            .bearerToken()
            .runPaginatedAdapter(PaymentAdapter.parseWalletTransactionFromObject);
    }

    async csvExportOrganizationWalletTransactions(organizationId: string, searchQuery: string, type: WalletPaymentType | null): Promise<BlobResponse> {
        return await this
            .request(`/payment/wallet/organization/${organizationId}/transaction/export/csv`)
            .queryString(QueryString
                .builder()
                .append('SearchQuery', searchQuery)
                .append('Type', type)
            )
            .method(HttpMethod.Get)
            .bearerToken()
            .fetchBlob();
    }

    async downloadOrganizationWalletReceipt(organizationId: string, fileId: string): Promise<BlobResponse> {
        return await this
            .request(`/payment/wallet/organization/${organizationId}/payout/download-receipt/${fileId}`)
            .bearerToken()
            .fetchBlob();
    }
}
