import type { BaseResponse, BlobResponse, HttpStatusCode } from '@fancee/client';
import type { OrganizationNote, OrganizationNoteRequest } from '@fancee/data';

export interface IOrganizationNoteService {
    list(organizationId: string): Promise<BaseResponse<OrganizationNote[]>>;

    create(organizationId: string, request: OrganizationNoteRequest): Promise<BaseResponse<string>>;

    update(organizationId: string, noteId: string, request: OrganizationNoteRequest): Promise<HttpStatusCode>;

    delete(organizationId: string, noteId: string): Promise<HttpStatusCode>;

    deleteFile(organizationId: string, noteId: string, fileId: string): Promise<HttpStatusCode>;

    downloadFile(organizationId: string, noteId: string, fileId: string): Promise<BlobResponse>;
}
