import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode } from '@fancee/client';
import { OrganizationNote, OrganizationNoteAdapter, OrganizationNoteRequest } from '@fancee/data';
import { IOrganizationNoteService } from '@';

export class OrganizationNoteService extends BaseService implements IOrganizationNoteService {
    async create(organizationId: string, request: OrganizationNoteRequest): Promise<BaseResponse<string>> {
        return await this
            .request(`/user/organization/${organizationId}/note`)
            .method(HttpMethod.Post)
            .body(OrganizationNoteAdapter.parseFormDataFromNoteRequest(request))
            .bearerToken()
            .runData();
    }

    async delete(organizationId: string, noteId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/organization/${organizationId}/note/${noteId}`)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async deleteFile(organizationId: string, noteId: string, fileId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/organization/${organizationId}/note/${noteId}/file/${fileId}`)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    @Debounce(500)
    async list(organizationId: string): Promise<BaseResponse<OrganizationNote[]>> {
        return await this
            .request(`/user/organization/notes/${organizationId}`)
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(OrganizationNoteAdapter.parseOrganizationNoteFromObject);
    }

    async update(organizationId: string, noteId: string, request: OrganizationNoteRequest): Promise<HttpStatusCode> {
        return await this
            .request(`/user/organization/${organizationId}/note/${noteId}`)
            .method(HttpMethod.Put)
            .body(OrganizationNoteAdapter.parseFormDataFromNoteRequest(request))
            .bearerToken()
            .runStatusCode();
    }

    async downloadFile(organizationId: string, noteId: string, fileId: string): Promise<BlobResponse> {
        return await this
            .request(`/user/organization/${organizationId}/note/${noteId}/file/${fileId}`)
            .method(HttpMethod.Get)
            .bearerToken()
            .fetchBlob();
    }
}
