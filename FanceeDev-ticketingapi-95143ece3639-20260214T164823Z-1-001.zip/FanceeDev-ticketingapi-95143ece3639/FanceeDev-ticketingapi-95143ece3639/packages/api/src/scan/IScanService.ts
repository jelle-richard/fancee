import type { BaseResponse } from '@fancee/client';
import type { AppTeamScanStatistics, Scan, ScanState, TicketScanStatistics } from '@fancee/data';
import type { DateTime } from 'luxon';

export interface IScanService {
    updateState(organizationId: string, code: string, state: ScanState): Promise<BaseResponse<Scan>>;

    eventStatistics(organizationId: string, eventId: string): Promise<BaseResponse<TicketScanStatistics[]>>;

    eventAppTeamStatistics(organizationId: string, eventId: string, appTeamId: string, dateTime: DateTime | null): Promise<BaseResponse<AppTeamScanStatistics[]>>;
}
