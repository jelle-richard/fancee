export type { IScanService } from './IScanService';
export { ScanService } from './ScanService';
