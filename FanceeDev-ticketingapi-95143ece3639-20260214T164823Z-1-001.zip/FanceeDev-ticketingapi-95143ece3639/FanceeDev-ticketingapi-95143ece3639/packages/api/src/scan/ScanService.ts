import { BaseResponse, BaseService, HttpMethod, QueryString } from '@fancee/client';
import { AppTeamScanStatistics, DateTimeAdapter, Scan, ScanAdapter, ScanState, TicketScanStatistics } from '@fancee/data';
import type { DateTime } from 'luxon';
import { IScanService } from '@';

export class ScanService extends BaseService implements IScanService {
    async updateState(organizationId: string, code: string, state: ScanState): Promise<BaseResponse<Scan>> {
        return await this
            .request(`/scan/${code}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body({state})
            .runData();
    }

    async eventStatistics(organizationId: string, eventId: string): Promise<BaseResponse<TicketScanStatistics[]>> {
        return await this
            .request(`/scan/statistics/${eventId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(ScanAdapter.parseTicketsStatisticsFromObject);
    }

    async eventAppTeamStatistics(organizationId: string, eventId: string, appTeamId: string, dateTime: DateTime | null): Promise<BaseResponse<AppTeamScanStatistics[]>> {
        return await this
            .request(`/scan/statistics/${eventId}/app-team/${appTeamId}`)
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('date', dateTime === null ? null : DateTimeAdapter.parseDateTimeToApi(dateTime))
            )
            .method(HttpMethod.Get)
            .bearerToken()
            .runAdapter(ScanAdapter.parseAppTeamStatisticsFromObject);
    }
}
