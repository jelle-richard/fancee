import { type BaseResponse, BaseService, HttpMethod, QueryString } from '@fancee/client';
import { SelectAdapter, type SelectOption } from '@fancee/data';
import type { ISelectService } from '@';

export class SelectService extends BaseService implements ISelectService {
    async crmGetEventOptions(): Promise<BaseResponse<SelectOption[]>>;
    async crmGetEventOptions(ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    async crmGetEventOptions(searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    async crmGetEventOptions(idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>> {
        const query = this.setupQuery(idsOrSearchQuery);

        return await this
            .request('/events/admin/list/select-options')
            .method(HttpMethod.Get)
            .queryString(query)
            .bearerToken()
            .runArrayAdapter(SelectAdapter.parseSelectOptionFromApi);
    }

    async getEventOptions(organizationId: string): Promise<BaseResponse<SelectOption[]>>;
    async getEventOptions(organizationId: string, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    async getEventOptions(organizationId: string, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    async getEventOptions(organizationId: string, idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>> {
        const query = this.setupQuery(idsOrSearchQuery);

        return await this
            .request('/events/list/select-options')
            .method(HttpMethod.Get)
            .queryString(query)
            .bearerToken()
            .asOrganization(organizationId)
            .runArrayAdapter(SelectAdapter.parseSelectOptionFromApi);
    }

    async getEventProductOptions(organizationId: string, eventIds: string[] | null, onlyUpcoming: boolean | null): Promise<BaseResponse<SelectOption[]>>;
    async getEventProductOptions(organizationId: string, eventIds: string[] | null, onlyUpcoming: boolean | null, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    async getEventProductOptions(organizationId: string, eventIds: string[] | null, onlyUpcoming: boolean | null, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    async getEventProductOptions(organizationId: string, eventIds: string[] | null, onlyUpcoming: boolean | null, idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>> {
        const query = this.setupQuery(idsOrSearchQuery);

        if (eventIds && eventIds.length > 0) {
            eventIds.forEach(eventId => query.append('EventIds', eventId));
        }

        if (onlyUpcoming !== null) {
            query.append('OnlyUpcoming', onlyUpcoming);
        }

        return await this
            .request('/events/products/list/select-options')
            .method(HttpMethod.Get)
            .queryString(query)
            .bearerToken()
            .asOrganization(organizationId)
            .runArrayAdapter(SelectAdapter.parseSelectOptionFromApi);
    }

    async getShopOptions(organizationId: string, eventIds: string[] | null): Promise<BaseResponse<SelectOption[]>>;
    async getShopOptions(organizationId: string, eventIds: string[] | null, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    async getShopOptions(organizationId: string, eventIds: string[] | null, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    async getShopOptions(organizationId: string, eventIds: string[] | null, idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>> {
        const query = this.setupQuery(idsOrSearchQuery);

        if (eventIds && eventIds.length > 0) {
            eventIds.forEach(eventId => query.append('EventIds', eventId));
        }

        return await this
            .request('/events/shops/list/select-options')
            .method(HttpMethod.Get)
            .queryString(query)
            .bearerToken()
            .asOrganization(organizationId)
            .runArrayAdapter(SelectAdapter.parseSelectOptionFromApi);
    }

    async getAppTeamsOptions(organizationId: string, eventIds: string[] | null): Promise<BaseResponse<SelectOption[]>>;
    async getAppTeamsOptions(organizationId: string, eventIds: string[] | null, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    async getAppTeamsOptions(organizationId: string, eventIds: string[] | null, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    async getAppTeamsOptions(organizationId: string, eventIds: string[] | null, idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>> {
        const query = this.setupQuery(idsOrSearchQuery);

        if (eventIds && eventIds.length > 0) {
            eventIds.forEach(eventId => query.append('EventIds', eventId));
        }

        return await this
            .request('/user/app-teams/list/select-options')
            .method(HttpMethod.Get)
            .queryString(query)
            .bearerToken()
            .asOrganization(organizationId)
            .runArrayAdapter(SelectAdapter.parseSelectOptionFromApi);
    }

    setupQuery(idsOrSearchQuery?: string | string[]): QueryString {
        const query = QueryString.builder();

        if (!idsOrSearchQuery) {
            return query;
        }

        if (typeof idsOrSearchQuery === 'string') {
            query.append('SearchQuery', idsOrSearchQuery);
        } else {
            idsOrSearchQuery.forEach(id => query.append('Ids', id));
        }

        return query;
    }

    async getSharedShopOptions(organizationId: string): Promise<BaseResponse<SelectOption[]>>;
    async getSharedShopOptions(organizationId: string, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    async getSharedShopOptions(organizationId: string, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    async getSharedShopOptions(organizationId: string, idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>> {
        const query = this.setupQuery(idsOrSearchQuery);

        return await this
            .request('/shared/shop/with-me/list/select-options')
            .method(HttpMethod.Get)
            .queryString(query)
            .bearerToken()
            .asOrganization(organizationId)
            .runArrayAdapter(SelectAdapter.parseSelectOptionFromApi);
    }
}
