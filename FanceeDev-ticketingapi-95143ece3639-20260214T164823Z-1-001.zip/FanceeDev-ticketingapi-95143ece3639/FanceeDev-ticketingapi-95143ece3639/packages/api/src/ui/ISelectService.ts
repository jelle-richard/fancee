import type { BaseResponse } from '@fancee/client';
import type { SelectOption } from '@fancee/data';

export interface ISelectService {
    crmGetEventOptions(): Promise<BaseResponse<SelectOption[]>>;
    crmGetEventOptions(ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    crmGetEventOptions(searchQuery: string): Promise<BaseResponse<SelectOption[]>>;

    getEventOptions(organizationId: string): Promise<BaseResponse<SelectOption[]>>;
    getEventOptions(organizationId: string, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    getEventOptions(organizationId: string, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;

    getEventProductOptions(organizationId: string, eventIds: string[] | null, onlyUpcoming: boolean | null): Promise<BaseResponse<SelectOption[]>>;
    getEventProductOptions(organizationId: string, eventIds: string[] | null, onlyUpcoming: boolean | null, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    getEventProductOptions(organizationId: string, eventIds: string[] | null, onlyUpcoming: boolean | null, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;

    getShopOptions(organizationId: string, eventIds: string[] | null): Promise<BaseResponse<SelectOption[]>>;
    getShopOptions(organizationId: string, eventIds: string[] | null, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    getShopOptions(organizationId: string, eventIds: string[] | null, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;

    getAppTeamsOptions(organizationId: string, eventIds: string[] | null): Promise<BaseResponse<SelectOption[]>>;
    getAppTeamsOptions(organizationId: string, eventIds: string[] | null, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    getAppTeamsOptions(organizationId: string, eventIds: string[] | null, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    getAppTeamsOptions(organizationId: string, eventIds: string[] | null, idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>>

    getSharedShopOptions(organizationId: string): Promise<BaseResponse<SelectOption[]>>;
    getSharedShopOptions(organizationId: string, ids: string[]): Promise<BaseResponse<SelectOption[]>>;
    getSharedShopOptions(organizationId: string, searchQuery: string): Promise<BaseResponse<SelectOption[]>>;
    getSharedShopOptions(organizationId: string, idsOrSearchQuery?: string | string[]): Promise<BaseResponse<SelectOption[]>>;
}
