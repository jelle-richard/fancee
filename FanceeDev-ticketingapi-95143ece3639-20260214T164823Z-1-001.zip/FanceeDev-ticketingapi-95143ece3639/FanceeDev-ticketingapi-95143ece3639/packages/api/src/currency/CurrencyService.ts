import { BaseResponse, BaseService } from '@fancee/client';
import { ICurrencyService } from '@';
import { Currency, CurrencyAdapter } from '@fancee/data';

export class CurrencyService extends BaseService implements ICurrencyService {
    async getPlatformStandard(): Promise<BaseResponse<Currency>> {
        return await this
            .request('/currency/platform-standard')
            .runAdapter(CurrencyAdapter.parseFromObject);
    }

    async getActive(): Promise<BaseResponse<Currency[]>> {
        return await this
            .request('/currencies/active')
            .runArrayAdapter(CurrencyAdapter.parseFromObject);
    }
}
