import type { BaseResponse } from '@fancee/client';
import type { Currency } from '@fancee/data';

export interface ICurrencyService {
    getPlatformStandard(): Promise<BaseResponse<Currency>>;

    getActive(): Promise<BaseResponse<Currency[]>>;
}
