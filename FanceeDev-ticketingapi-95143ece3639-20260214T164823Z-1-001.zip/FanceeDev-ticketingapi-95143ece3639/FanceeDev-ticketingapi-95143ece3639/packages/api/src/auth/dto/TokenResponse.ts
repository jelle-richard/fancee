import { Dto } from '@fancee/client';
import { AuthAdapter, AuthUser, ManageableOrganization } from '@fancee/data';

@Dto
export class TokenResponse {
    get claims(): string[] {
        return this.#claims;
    }

    get token(): string {
        return this.#token;
    }

    get user(): AuthUser {
        return this.#user;
    }

    get manageableOrganizations(): ManageableOrganization[] {
        return this.#manageableOrganizations;
    }

    get validUntil(): string {
        return this.#validUntil;
    }

    readonly #claims: string[];
    readonly #token: string;
    readonly #user: AuthUser;
    readonly #manageableOrganizations: ManageableOrganization[];
    readonly #validUntil: string;

    constructor(claims: string[], token: string, user: AuthUser, manageableOrganizations: ManageableOrganization[], validUntil: string) {
        this.#claims = claims;
        this.#token = token;
        this.#user = AuthAdapter.parseAuthUserFromObject(user);
        this.#manageableOrganizations = manageableOrganizations;
        this.#validUntil = validUntil;
    }
}
