import type { BaseResponse, HttpStatusCode } from '@fancee/client';
import type { ClaimHierarchyCategory, Session } from '@fancee/data';
import type { TokenResponse } from './dto';

export interface IAuthService {
    login(email: string, password: string): Promise<BaseResponse<TokenResponse>>;

    getSessions(): Promise<BaseResponse<Session[]>>;

    getSessionsForUser(userId: string): Promise<BaseResponse<Session[]>>;

    deleteSession(token: string): Promise<HttpStatusCode>;

    deleteSessionForUser(userId: string, token: string): Promise<HttpStatusCode>;

    getPlatformClaims(): Promise<BaseResponse<ClaimHierarchyCategory[]>>;

    getPlatformOrganizationClaims(): Promise<BaseResponse<ClaimHierarchyCategory[]>>;

    getUserClaims(userId: string): Promise<BaseResponse<string[]>>;

    updateUserClaims(userId: string, claims: string[]): Promise<HttpStatusCode>;

    accountTakeover(accountId: string, adminPassword: string): Promise<BaseResponse<TokenResponse>>;
}
