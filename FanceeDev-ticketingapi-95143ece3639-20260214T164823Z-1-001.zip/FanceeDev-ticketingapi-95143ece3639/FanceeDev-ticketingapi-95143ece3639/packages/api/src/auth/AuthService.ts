import { BaseResponse, BaseService, HttpMethod, HttpStatusCode } from '@fancee/client';
import { AuthAdapter, ClaimAdapter, Session, ClaimHierarchyCategory } from '@fancee/data';
import { IAuthService } from '@';
import { TokenResponseAdapter } from './adapter';
import { TokenResponse } from './dto';

export class AuthService extends BaseService implements IAuthService {
    async login(email: string, password: string): Promise<BaseResponse<TokenResponse>> {
        return await this
            .request('/auth/token')
            .method(HttpMethod.Post)
            .body({
                email: email,
                password: password
            })
            .runAdapter(TokenResponseAdapter.parseFromObject);
    }

    async getSessions(): Promise<BaseResponse<Session[]>> {
        return await this
            .request('/auth/sessions')
            .bearerToken()
            .runArrayAdapter(AuthAdapter.parseSessionFromObject);
    }

    async getSessionsForUser(userId: string): Promise<BaseResponse<Session[]>> {
        return await this
            .request(`/auth/sessions/user/${userId}`)
            .bearerToken()
            .runArrayAdapter(AuthAdapter.parseSessionFromObject);
    }

    async deleteSession(token: string): Promise<HttpStatusCode> {
        return await this
            .request(`/auth/session/${token}`)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async deleteSessionForUser(userId: string, token: string): Promise<HttpStatusCode> {
        return await this
            .request(`/auth/session/user/${userId}/${token}`)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async updateUserClaims(userId: string, claims: string[]): Promise<HttpStatusCode> {
        return await this
            .request(`/auth/claims/${userId}`)
            .method(HttpMethod.Post)
            .body({
                claims: claims
            })
            .bearerToken()
            .runStatusCode();
    }

    async getPlatformClaims(): Promise<BaseResponse<ClaimHierarchyCategory[]>> {
        return await this
            .request('/auth/claims/platform')
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(ClaimAdapter.parseClaimHierarchyCategoryFromObject);
    }

    async getPlatformOrganizationClaims(): Promise<BaseResponse<ClaimHierarchyCategory[]>> {
        return await this
            .request('/auth/claims/organization')
            .method(HttpMethod.Get)
            .bearerToken()
            .runArrayAdapter(ClaimAdapter.parseClaimHierarchyCategoryFromObject);
    }

    async getUserClaims(userId: string): Promise<BaseResponse<string[]>> {
        return await this
            .request(`/auth/claims/${userId}`)
            .method(HttpMethod.Get)
            .bearerToken()
            .runData<string[]>();
    }

    async accountTakeover(accountId: string, adminPassword: string): Promise<BaseResponse<TokenResponse>> {
        return await this
            .request('/auth/admin/auth/takeover')
            .method(HttpMethod.Post)
            .body({
                accountId: accountId,
                adminPassword: adminPassword
            })
            .bearerToken()
            .runAdapter(TokenResponseAdapter.parseFromObject);
    }
}
