import { Adapter } from '@fancee/client';
import { AuthAdapter } from '@fancee/data';
import { TokenResponse } from '../dto';

@Adapter
export class TokenResponseAdapter {
    public static parseFromObject(response: object): TokenResponse {
        return new TokenResponse(
            response['claims'],
            response['token'],
            response['user'],
            response['manageableOrganizations'].map(AuthAdapter.parseManageableOrganizationFromObject),
            response['validUntil']
        );
    }
}
