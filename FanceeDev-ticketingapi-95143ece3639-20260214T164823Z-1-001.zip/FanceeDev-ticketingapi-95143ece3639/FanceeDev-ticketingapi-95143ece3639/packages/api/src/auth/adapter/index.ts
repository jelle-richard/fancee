export { TokenResponseAdapter } from './TokenResponseAdapter';
