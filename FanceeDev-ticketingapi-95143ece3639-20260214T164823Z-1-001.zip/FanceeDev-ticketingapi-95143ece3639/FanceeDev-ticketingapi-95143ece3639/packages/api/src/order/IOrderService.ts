import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import { ClientOrderItem, CountryCode, DailyOrder, Order, OrderCost, OrdersFilter, OrganizationOrderItem, PlatformOrderItem, Refund, TicketOrder } from '@fancee/data';

export interface IOrderService {
    getClient(pageSize: number, page: number, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<ClientOrderItem>>>;

    csvExportClient(filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BlobResponse>;

    getTicket(pageSize: number, page: number, searchQuery: string): Promise<BaseResponse<TicketOrder[]>>;

    getOrganization(organizationId: string, pageSize: number, page: number, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<OrganizationOrderItem>>>;

    csvExportOrganization(organizationId: string, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BlobResponse>;

    getPlatform(pageSize: number, page: number, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<PlatformOrderItem>>>;

    csvExportPlatform(filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BlobResponse>;

    get(organizationId: string, orderId: string): Promise<BaseResponse<Order>>;

    getCrm(orderId: string): Promise<BaseResponse<Order>>;

    getClientOrder(orderId: string): Promise<BaseResponse<Order>>;

    getDaily(organizationId: string, startDate: string, endDate: string): Promise<BaseResponse<DailyOrder[]>>;

    getDailyEvent(organizationId: string, eventId: string, startDate: string, endDate: string): Promise<BaseResponse<DailyOrder[]>>;

    downloadTicketsPdf(orderId: string, clientId: string): Promise<BlobResponse>;

    resend(organizationId: string, orderId: string): Promise<HttpStatusCode>;

    resendCrm(orderId: string, emailAddress: string): Promise<HttpStatusCode>;

    getCost(reservationReference: string, paymentMethodId: string | null, receiveViaSms: boolean, enabledTicketServicePlus: boolean): Promise<BaseResponse<OrderCost>>;

    generateReceipt(orderId: string): Promise<BaseResponse<never>>;

    getReceipt(orderId: string): Promise<BlobResponse>;

    issueRefund(organizationId: string, orderId: string, refund: Refund): Promise<HttpStatusCode>;
}
