import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { ClientOrderItem, type CountryCode, DailyOrder, DateTimeAdapter, Order, OrderAdapter, OrderCost, OrdersFilter, OrganizationOrderItem, PlatformOrderItem, TicketOrder, Refund } from '@fancee/data';
import { IOrderService } from '@';

export class OrderService extends BaseService implements IOrderService {
    @Debounce(500)
    async getClient(pageSize: number, page: number, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<ClientOrderItem>>> {
        return await this
            .request('/orders/client/list')
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('Options.CostCentsRange.Minimum', filter.costCentsRange ? filter.costCentsRange[0] : null)
                .append('Options.CostCentsRange.Maximum', filter.costCentsRange ? filter.costCentsRange[1] : null)
                .appendArray('Options.CountryCodes', countryCodes)
                .appendArray('Options.PaymentMethods', filter.paymentMethods)
                .appendArray('Options.EventStates', filter.states)
                .appendArray('Options.PaymentStates', filter.paymentStates)
                .append('Options.OptInSms', filter.optInSms)
                .append('Options.OptInEmail', filter.optInEmail)
                .append('Options.ReceiveViaSms', filter.receiveViaSms)
                .appendArray('Options.EventIds', filter.eventIds)
                .append('Options.SearchQuery', filter.searchQuery))
            .bearerToken()
            .runPaginatedAdapter(OrderAdapter.parseClientOrderListingFromObject);
    }

    async csvExportClient(filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BlobResponse> {
        return await this
            .request('/orders/client/export/csv')
            .queryString(QueryString
                .builder()
                .append('DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('CostCentsRange.Minimum', filter.costCentsRange ? filter.costCentsRange[0] : null)
                .append('CostCentsRange.Maximum', filter.costCentsRange ? filter.costCentsRange[1] : null)
                .appendArray('CountryCodes', countryCodes)
                .appendArray('PaymentMethods', filter.paymentMethods)
                .appendArray('EventStates', filter.states)
                .appendArray('PaymentStates', filter.paymentStates)
                .append('OptInSms', filter.optInSms)
                .append('OptInEmail', filter.optInEmail)
                .append('ReceiveViaSms', filter.receiveViaSms)
                .appendArray('EventIds', filter.eventIds)
                .append('SearchQuery', filter.searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    async getTicket(): Promise<BaseResponse<TicketOrder[]>> {
        return await this
            .request('/order/tickets')
            .bearerToken()
            .runArrayAdapter(OrderAdapter.parseTicketOrderFromObject);
    }

    @Debounce(500)
    async getOrganization(organizationId: string, pageSize: number, page: number, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<OrganizationOrderItem>>> {
        return await this
            .request('/orders/organization/list')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('Options.CostCentsRange.Minimum', filter.costCentsRange ? filter.costCentsRange[0] : null)
                .append('Options.CostCentsRange.Maximum', filter.costCentsRange ? filter.costCentsRange[1] : null)
                .appendArray('Options.CountryCodes', countryCodes)
                .appendArray('Options.PaymentMethods', filter.paymentMethods)
                .appendArray('Options.EventStates', filter.states)
                .appendArray('Options.PaymentStates', filter.paymentStates)
                .append('Options.OptInSms', filter.optInSms)
                .append('Options.OptInEmail', filter.optInEmail)
                .append('Options.ReceiveViaSms', filter.receiveViaSms)
                .appendArray('Options.EventIds', filter.eventIds)
                .append('Options.SearchQuery', filter.searchQuery))
            .bearerToken()
            .runPaginatedAdapter(OrderAdapter.parseOrganizationListingFromObject);
    }

    async csvExportOrganization(organizationId: string, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BlobResponse> {
        return await this
            .request('/orders/organization/export/csv')
            .asOrganization(organizationId)
            .queryString(QueryString
                .builder()
                .append('DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('CostCentsRange.Minimum', filter.costCentsRange ? filter.costCentsRange[0] : null)
                .append('CostCentsRange.Maximum', filter.costCentsRange ? filter.costCentsRange[1] : null)
                .appendArray('CountryCodes', countryCodes)
                .appendArray('PaymentMethods', filter.paymentMethods)
                .appendArray('EventStates', filter.states)
                .appendArray('PaymentStates', filter.paymentStates)
                .append('OptInSms', filter.optInSms)
                .append('OptInEmail', filter.optInEmail)
                .append('ReceiveViaSms', filter.receiveViaSms)
                .appendArray('EventIds', filter.eventIds)
                .append('SearchQuery', filter.searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    @Debounce(500)
    async getPlatform(pageSize: number, page: number, filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<PlatformOrderItem>>> {
        return await this
            .request('/orders/platform/list')
            .queryString(QueryString
                .builder()
                .append('PageSize', pageSize)
                .append('Page', page)
                .append('Options.DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('Options.CostCentsRange.Minimum', filter.costCentsRange ? filter.costCentsRange[0] : null)
                .append('Options.CostCentsRange.Maximum', filter.costCentsRange ? filter.costCentsRange[1] : null)
                .appendArray('Options.CountryCodes', countryCodes)
                .appendArray('Options.PaymentMethods', filter.paymentMethods)
                .appendArray('Options.EventStates', filter.states)
                .appendArray('Options.PaymentStates', filter.paymentStates)
                .append('Options.OptInSms', filter.optInSms)
                .append('Options.OptInEmail', filter.optInEmail)
                .append('Options.ReceiveViaSms', filter.receiveViaSms)
                .appendArray('Options.EventIds', filter.eventIds)
                .append('Options.SearchQuery', filter.searchQuery))
            .bearerToken()
            .runPaginatedAdapter(OrderAdapter.parsePlatFormOrderListingFromObject);
    }

    async csvExportPlatform(filter: OrdersFilter, countryCodes: CountryCode[]): Promise<BlobResponse> {
        return await this
            .request('/orders/platform/export/csv')
            .queryString(QueryString
                .builder()
                .append('DateRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('DateRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('CostCentsRange.Minimum', filter.costCentsRange ? filter.costCentsRange[0] : null)
                .append('CostCentsRange.Maximum', filter.costCentsRange ? filter.costCentsRange[1] : null)
                .appendArray('CountryCodes', countryCodes)
                .appendArray('PaymentMethods', filter.paymentMethods)
                .appendArray('EventStates', filter.states)
                .appendArray('PaymentStates', filter.paymentStates)
                .append('OptInSms', filter.optInSms)
                .append('OptInEmail', filter.optInEmail)
                .append('ReceiveViaSms', filter.receiveViaSms)
                .appendArray('EventIds', filter.eventIds)
                .append('SearchQuery', filter.searchQuery))
            .bearerToken()
            .fetchBlob();
    }

    async get(organizationId: string, orderId: string): Promise<BaseResponse<Order>> {
        return await this
            .request(`/order/${orderId}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(OrderAdapter.parseOrderFromObject);
    }

    async getCrm(orderId: string): Promise<BaseResponse<Order>> {
        return await this
            .request(`/order/${orderId}`)
            .bearerToken()
            .runAdapter(OrderAdapter.parseOrderFromObject);
    }

    async getClientOrder(orderId: string): Promise<BaseResponse<Order>> {
        return await this
            .request(`/order/${orderId}`)
            .bearerToken()
            .runAdapter(OrderAdapter.parseOrderFromObject);
    }

    async getDaily(organizationId: string, startDate: string, endDate: string): Promise<BaseResponse<DailyOrder[]>> {
        return await this
            .request(`/orders/daily?startDate=${startDate}&endDate=${endDate}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(OrderAdapter.parseDailyOrdersFromObjects);
    }

    async getDailyEvent(organizationId: string, eventId: string, startDate: string, endDate: string): Promise<BaseResponse<DailyOrder[]>> {
        return await this
            .request(`/orders/event/${eventId}/daily?startDate=${startDate}&endDate=${endDate}`)
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(OrderAdapter.parseDailyOrdersFromObjects);
    }

    async downloadTicketsPdf(orderId: string, clientId: string): Promise<BlobResponse> {
        return await this
            .request(`/order/file/${orderId}`)
            .queryString(QueryString
                .builder()
                .append('c', clientId)
            )
            .fetchBlob();
    }

    async resend(organizationId: string, orderId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/order/resend/${orderId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .runStatusCode();
    }

    async resendCrm(orderId: string, emailAddress: string): Promise<HttpStatusCode> {
        return await this
            .request(`/order/resend/${orderId}/explicit`)
            .method(HttpMethod.Post)
            .body({emailAddress})
            .bearerToken()
            .runStatusCode();
    }

    async getCost(reservationReference: string, paymentMethodId: string | null, receiveViaSms: boolean, enabledTicketServicePlus: boolean): Promise<BaseResponse<OrderCost>> {
        return await this
            .request('/order/cost')
            .queryString(QueryString
                .builder()
                .append('reservationReference', reservationReference)
                .append('paymentMethodId', paymentMethodId)
                .append('receiveViaSms', receiveViaSms)
                .append('enabledTicketServicePlus', enabledTicketServicePlus))
            .runAdapter(OrderAdapter.parseOrderCostFromObject);
    }

    async generateReceipt(orderId: string): Promise<BaseResponse<never>> {
        return await this
            .request(`/order/${orderId}/receipt/generate`)
            .method(HttpMethod.Get)
            .runEmpty();
    }

    async getReceipt(orderId: string): Promise<BlobResponse> {
        return await this
            .request(`/order/${orderId}/receipt`)
            .method(HttpMethod.Get)
            .fetchBlob();
    }

    async issueRefund(organizationId: string, orderId: string, refund: Refund): Promise<HttpStatusCode> {
        return await this
            .request(`/refund/${orderId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body(OrderAdapter.parseRefundToObject(refund))
            .bearerToken()
            .runStatusCode();
    }
}
