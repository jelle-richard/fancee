import type { BaseResponse, HttpStatusCode } from '@fancee/client';
import type { AssignedPaymentMethod, EventPaymentMethod, ShopColorPalette } from '@fancee/data';

export interface IOrganizationDefaultsService {
    getPalette(organizationId: string): Promise<BaseResponse<ShopColorPalette>>;

    updatePalette(organizationId: string, palette: ShopColorPalette): Promise<HttpStatusCode>;

    getPaymentMethods(organizationId: string): Promise<BaseResponse<EventPaymentMethod[]>>;

    updatePaymentMethods(organizationId: string, paymentMethods: AssignedPaymentMethod[]): Promise<HttpStatusCode>;
}
