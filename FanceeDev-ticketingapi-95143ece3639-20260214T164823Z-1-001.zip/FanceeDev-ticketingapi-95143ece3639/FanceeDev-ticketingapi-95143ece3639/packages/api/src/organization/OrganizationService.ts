import { BaseResponse, BaseService, BlobResponse, Debounce, HttpMethod, HttpStatusCode, Paginated, QueryString } from '@fancee/client';
import { CountryCode, DateTimeAdapter, OrganizationAccount, OrganizationAdapter, OrganizationContact, OrganizationContract, OrganizationListFilter, OrganizationListing, OrganizationProfile } from '@fancee/data';
import { IOrganizationService } from '@';

export class OrganizationService extends BaseService implements IOrganizationService {
    async addContact(organizationId: string, contact: OrganizationContact): Promise<BaseResponse<string>> {
        return await this
            .request('/user/organization/profile/contacts')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .bearerToken()
            .body(OrganizationAdapter.parseOrganizationContactToApi(contact))
            .runData();
    }

    async deleteContact(organizationId: string, contactId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/organization/profile/contacts/${contactId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async getContract(organizationId: string): Promise<BaseResponse<OrganizationContract>> {
        return await this
            .request('/user/organization/contract')
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(OrganizationAdapter.parseOrganizationContractFromObject);
    }

    @Debounce(500)
    async list(pageSize: number, page: number, filter: OrganizationListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<OrganizationListing>>> {
        return await this
            .request('/user/organizations/list')
            .queryString(QueryString
                .builder()
                .append('Page', page)
                .append('PageSize', pageSize)
                .append('Options.SearchQuery', filter.search)
                .append('Options.IsImportant', filter.isImportant)
                .append('Options.ContractSigned', filter.contractSigned)
                .appendArray('Options.CountryCodes', countryCodes)
                .append('Options.ApproximatedAnnualSalesRange.Minimum', filter.salesRange ? filter.salesRange[0] : null)
                .append('Options.ApproximatedAnnualSalesRange.Maximum', filter.salesRange ? filter.salesRange[1] : null)
                .append('Options.DateCreatedRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('Options.DateCreatedRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('Options.IsBlocked', filter.isBlocked))
            .bearerToken()
            .runPaginatedAdapter(OrganizationAdapter.parseOrganizationListingFromObject);
    }

    async csvExport(filter: OrganizationListFilter, countryCodes: CountryCode[]): Promise<BlobResponse> {
        return await this
            .request('/user/organizations/export/csv')
            .queryString(QueryString
                .builder()
                .append('SearchQuery', filter.search)
                .append('IsImportant', filter.isImportant)
                .appendArray('CountryCodes', countryCodes)
                .append('ApproximatedAnnualSalesRange.Minimum', filter.salesRange ? filter.salesRange[0] : null)
                .append('ApproximatedAnnualSalesRange.Maximum', filter.salesRange ? filter.salesRange[1] : null)
                .append('DateCreatedRange.Minimum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[0]) : null)
                .append('DateCreatedRange.Maximum', filter.dateSpan ? DateTimeAdapter.parseDateTimeToApi(filter.dateSpan[1]) : null)
                .append('IsBlocked', filter.isImportant))
            .bearerToken()
            .fetchBlob();
    }

    async getProfile(organizationId: string): Promise<BaseResponse<OrganizationProfile>> {
        return await this
            .request('/user/organization/profile')
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(OrganizationAdapter.parseOrganizationProfileFromObject);
    }

    async updateContact(organizationId: string, contact: OrganizationContact): Promise<HttpStatusCode> {
        return await this
            .request(`/user/organization/profile/contacts/${contact.id}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(OrganizationAdapter.parseOrganizationContactToApi(contact))
            .runStatusCode();
    }

    async updateProfile(organizationId: string, profile: OrganizationProfile): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/profile')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(OrganizationAdapter.parseOrganizationProfileToApi(profile))
            .runStatusCode();
    }

    async getAccount(organizationId: string): Promise<BaseResponse<OrganizationAccount>> {
        return await this
            .request(`/user/organization/${organizationId}/account`)
            .bearerToken()
            .runAdapter(OrganizationAdapter.parseOrganizationAccountFromObject);
    }
}
