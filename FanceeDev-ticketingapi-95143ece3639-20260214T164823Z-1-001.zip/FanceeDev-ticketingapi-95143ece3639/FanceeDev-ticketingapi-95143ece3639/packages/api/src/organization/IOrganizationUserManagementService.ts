import type { BaseResponse, HttpStatusCode } from '@fancee/client';
import type { OrganizationUser, OrganizationUserAssignment, OrganizationUserAssignmentUpdate } from '@fancee/data';

export interface IOrganizationUserManagementService {
    get(organizationId: string): Promise<BaseResponse<OrganizationUser[]>>;

    add(organizationId: string, user: OrganizationUserAssignment): Promise<HttpStatusCode>;

    update(organizationId: string, user: OrganizationUserAssignmentUpdate): Promise<HttpStatusCode>;

    delete(organizationId: string, userId: string): Promise<HttpStatusCode>;
}
