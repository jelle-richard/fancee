import { BaseResponse, BaseService, HttpMethod, HttpStatusCode } from '@fancee/client';
import { OrganizationUser, OrganizationUserAdapter, OrganizationUserAssignment, OrganizationUserAssignmentUpdate } from '@fancee/data';
import { IOrganizationUserManagementService } from '@';

export class OrganizationUserManagementService extends BaseService implements IOrganizationUserManagementService {
    async add(organizationId: string, user: OrganizationUserAssignment): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/users')
            .asOrganization(organizationId)
            .method(HttpMethod.Post)
            .body(OrganizationUserAdapter.parseOrganizationUserAssignmentToObject(user))
            .bearerToken()
            .runStatusCode();
    }

    async delete(organizationId: string, userId: string): Promise<HttpStatusCode> {
        return await this
            .request(`/user/organization/users/${userId}`)
            .asOrganization(organizationId)
            .method(HttpMethod.Delete)
            .bearerToken()
            .runStatusCode();
    }

    async get(organizationId: string): Promise<BaseResponse<OrganizationUser[]>> {
        return await this
            .request('/user/organization/users')
            .asOrganization(organizationId)
            .bearerToken()
            .runArrayAdapter(OrganizationUserAdapter.parseOrganizationUserFromObject);
    }

    async update(organizationId: string, user: OrganizationUserAssignmentUpdate): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/users')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .body(OrganizationUserAdapter.parseOrganizationUserAssignmentUpdateToObject(user))
            .bearerToken()
            .runStatusCode();
    }

}
