import type { BaseResponse, BlobResponse, HttpStatusCode, Paginated } from '@fancee/client';
import type { OrganizationAccount, OrganizationContact, OrganizationContract, OrganizationListing, OrganizationListFilter, OrganizationProfile, CountryCode } from '@fancee/data';

export interface IOrganizationService {
    addContact(organizationId: string, contact: OrganizationContact): Promise<BaseResponse<string>>;

    deleteContact(organizationId: string, contactId: string): Promise<HttpStatusCode>;

    getContract(organizationId: string): Promise<BaseResponse<OrganizationContract>>;

    list(pageSize: number, page: number, filter: OrganizationListFilter, countryCodes: CountryCode[]): Promise<BaseResponse<Paginated<OrganizationListing>>>;

    csvExport(filter: OrganizationListFilter, countryCodes: CountryCode[]): Promise<BlobResponse>;

    getProfile(organizationId: string): Promise<BaseResponse<OrganizationProfile>>;

    updateContact(organizationId: string, contact: OrganizationContact): Promise<HttpStatusCode>;

    updateProfile(organizationId: string, profile: OrganizationProfile): Promise<HttpStatusCode>;

    getAccount(organizationId: string): Promise<BaseResponse<OrganizationAccount>>;
}
