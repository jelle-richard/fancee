import { BaseResponse, BaseService, HttpMethod, HttpStatusCode } from '@fancee/client';
import { AssignedPaymentMethod, EventPaymentMethod, OrganizationDefaultsAdapter, PaymentAdapter, ShopColorPalette } from '@fancee/data';
import { IOrganizationDefaultsService } from '@';

export class OrganizationDefaultsService extends BaseService implements IOrganizationDefaultsService {
    async getPalette(organizationId: string): Promise<BaseResponse<ShopColorPalette>> {
        return await this
            .request('/user/organization/shop-palette/default')
            .asOrganization(organizationId)
            .bearerToken()
            .runAdapter(OrganizationDefaultsAdapter.parseShopColorPalletFromObject);
    }

    async updatePalette(organizationId: string, palette: ShopColorPalette): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/shop-palette/default')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body(OrganizationDefaultsAdapter.parseShopColorPaletteToApi(palette))
            .runStatusCode();
    }

    async getPaymentMethods(organizationId: string): Promise<BaseResponse<EventPaymentMethod[]>> {
        return await this
            .request('/user/organization/payment-methods/default')
            .asOrganization(organizationId)
            .bearerToken()
            .runArrayAdapter(PaymentAdapter.parseEventPaymentMethodFromObject);
    }

    async updatePaymentMethods(organizationId: string, paymentMethods: AssignedPaymentMethod[]): Promise<HttpStatusCode> {
        return await this
            .request('/user/organization/payment-methods/default')
            .asOrganization(organizationId)
            .method(HttpMethod.Put)
            .bearerToken()
            .body({
                paymentMethods: paymentMethods
                    .filter(paymentMethod => paymentMethod.paidBy !== null)
                    .map(PaymentAdapter.parseAssignedPaymentMethodToApi)
            })
            .runStatusCode();
    }
}
