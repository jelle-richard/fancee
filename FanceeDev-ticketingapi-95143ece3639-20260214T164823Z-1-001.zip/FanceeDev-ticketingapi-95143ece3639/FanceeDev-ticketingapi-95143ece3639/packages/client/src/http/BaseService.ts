import { FanceeClient } from '@/client';
import { RequestBuilder } from '@/http';

export class BaseService {
    protected request(path: string, client?: FanceeClient): RequestBuilder {
        return new RequestBuilder(path, client);
    }
}
