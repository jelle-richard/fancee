// note(Bas): Usage of "any" is a requirement here.
//  See: https://www.typescriptlang.org/docs/handbook/mixins.html

const isStrict = true;

export function Adapter<T extends Constructor>(Parent: T): T {
    return class extends Parent {
        constructor(...args: any[]) {
            if (isStrict) {
                throw new Error('Adapters cannot be instantiated.');
            }

            super(...args);
        }
    } as T;
}

type Constructor<T = {}> = new (...args: any[]) => T;
