export const LUXON_DATE_TIME_FILE_FORMAT: string = 'yyyy-MM-dd HH-mm-ss';
