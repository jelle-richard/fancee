import { DateTime } from 'luxon';
import { LUXON_DATE_TIME_FILE_FORMAT } from '@/constant';

export function formatFileDateTime(dateTime?: DateTime): string {
    dateTime = dateTime || DateTime.now();

    return dateTime.toFormat(LUXON_DATE_TIME_FILE_FORMAT);
}
