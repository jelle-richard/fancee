import { Dto } from '@fancee/client';
import { ProductType } from '@/enum';

@Dto
export class TypedProductIdentification {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get type(): ProductType {
        return this.#type;
    }

    set type(value: ProductType) {
        this.#type = value;
    }

    #id: string;
    #name: string;
    #type: ProductType;

    constructor(id: string, name: string, type: ProductType) {
        this.#id = id;
        this.#name = name;
        this.#type = type;
    }
}
