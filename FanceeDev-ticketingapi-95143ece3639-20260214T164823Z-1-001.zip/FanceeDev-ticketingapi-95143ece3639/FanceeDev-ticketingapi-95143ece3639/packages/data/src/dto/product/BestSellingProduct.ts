import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class BestSellingProduct {
    get productId(): string {
        return this.#productId;
    }

    set productId(value: string) {
        this.#productId = value;
    }

    get productName(): string {
        return this.#productName;
    }

    set productName(value: string) {
        this.#productName = value;
    }

    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get media(): Media[] {
        return this.#media;
    }

    set media(value: Media[]) {
        this.#media = value;
    }

    get amountSold(): number {
        return this.#amountSold;
    }

    set amountSold(value: number) {
        this.#amountSold = value;
    }

    public get amountStock(): number {
        return this.#amountStock;
    }

    public set amountStock(value: number) {
        this.#amountStock = value;
    }

    #productId: string;
    #productName: string;
    #eventName: string;
    #media: Media[];
    #amountSold: number;
    #amountStock: number;

    constructor(productId: string, productName: string, eventName: string, media: Media[], amountSold: number, amountStock: number) {
        this.#productId = productId;
        this.#productName = productName;
        this.#eventName = eventName;
        this.#media = media;
        this.#amountSold = amountSold;
        this.#amountStock = amountStock;
    }
}
