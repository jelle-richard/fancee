import { Dto } from '@fancee/client';

@Dto
export class IssuedProductStatistics {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get priceCents(): number {
        return this.#priceCents;
    }

    set priceCents(value: number) {
        this.#priceCents = value;
    }

    get stock(): number {
        return this.#stock;
    }

    set stock(value: number) {
        this.#stock = value;
    }

    get pendingReservationsAmount(): number {
        return this.#pendingReservationsAmount;
    }

    set pendingReservationsAmount(value: number) {
        this.#pendingReservationsAmount = value;
    }

    get pendingPaymentsAmount(): number {
        return this.#pendingPaymentsAmount;
    }

    set pendingPaymentsAmount(value: number) {
        this.#pendingPaymentsAmount = value;
    }

    get refundAmount(): number {
        return this.#refundAmount;
    }

    set refundAmount(value: number) {
        this.#refundAmount = value;
    }

    get notDeductedGuestAmount(): number {
        return this.#notDeductedGuestAmount;
    }

    set notDeductedGuestAmount(value: number) {
        this.#notDeductedGuestAmount = value;
    }

    get deductedGuestAmount(): number {
        return this.#deductedGuestAmount;
    }

    set deductedGuestAmount(value: number) {
        this.#deductedGuestAmount = value;
    }

    get soldAmount(): number {
        return this.#soldAmount;
    }

    set soldAmount(value: number) {
        this.#soldAmount = value;
    }

    get packQuantity(): number {
        return this.#packQuantity;
    }

    set packQuantity(value: number) {
        this.#packQuantity = value;
    }

    get selected(): boolean {
        return this.#selected;
    }

    set selected(value: boolean) {
        this.#selected = value;
    }

    #id: string;
    #name: string;
    #priceCents: number;
    #stock: number;
    #pendingReservationsAmount: number;
    #pendingPaymentsAmount: number;
    #refundAmount: number;
    #notDeductedGuestAmount: number;
    #deductedGuestAmount: number;
    #soldAmount: number;
    #packQuantity: number;
    #selected: boolean;

    constructor(id: string, name: string, priceCents: number, stock: number, pendingReservationsAmount: number, pendingPaymentsAmount: number, refundAmount: number, notDeductedGuestAmount: number, deductedGuestAmount: number, soldAmount: number, packQuantity: number, selected: boolean) {
        this.#id = id;
        this.#name = name;
        this.#priceCents = priceCents;
        this.#stock = stock;
        this.#pendingReservationsAmount = pendingReservationsAmount;
        this.#pendingPaymentsAmount = pendingPaymentsAmount;
        this.#refundAmount = refundAmount;
        this.#notDeductedGuestAmount = notDeductedGuestAmount;
        this.#deductedGuestAmount = deductedGuestAmount;
        this.#soldAmount = soldAmount;
        this.#packQuantity = packQuantity;
        this.#selected = selected;
    }
}
