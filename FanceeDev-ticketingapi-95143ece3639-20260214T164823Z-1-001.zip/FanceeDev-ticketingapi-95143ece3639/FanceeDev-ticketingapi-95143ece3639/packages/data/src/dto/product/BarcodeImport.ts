import { Dto } from '@fancee/client';
import { CsvDelimiter } from '@/enum';

@Dto
export class BarcodeImport {
    get file(): File {
        return this.#file;
    }

    set file(value: File) {
        this.#file = value;
    }

    get codeFieldIndex(): number {
        return this.#codeFieldIndex;
    }

    set codeFieldIndex(value: number) {
        this.#codeFieldIndex = value;
    }

    get emailFieldIndex(): number | null {
        return this.#emailFieldIndex;
    }

    set emailFieldIndex(value: number | null) {
        this.#emailFieldIndex = value;
    }

    get firstnameFieldIndex(): number | null {
        return this.#firstnameFieldIndex;
    }

    set firstnameFieldIndex(value: number | null) {
        this.#firstnameFieldIndex = value;
    }

    get lastnameFieldIndex(): number | null {
        return this.#lastnameFieldIndex;
    }

    set lastnameFieldIndex(value: number | null) {
        this.#lastnameFieldIndex = value;
    }

    get delimiter(): CsvDelimiter {
        return this.#delimiter;
    }

    set delimiter(value: CsvDelimiter) {
        this.#delimiter = value;
    }

    get hasHeader(): boolean {
        return this.#hasHeader;
    }

    set hasHeader(value: boolean) {
        this.#hasHeader = value;
    }

    #file: File;
    #codeFieldIndex: number;
    #emailFieldIndex: number | null;
    #firstnameFieldIndex: number | null;
    #lastnameFieldIndex: number | null;
    #delimiter: CsvDelimiter;
    #hasHeader: boolean;

    constructor(file: File, codeFieldIndex: number, emailFieldIndex: number | null, firstnameFieldIndex: number | null, lastnameFieldIndex: number | null, delimiter: CsvDelimiter, hasHeader: boolean) {
        this.#file = file;
        this.#codeFieldIndex = codeFieldIndex;
        this.#emailFieldIndex = emailFieldIndex;
        this.#firstnameFieldIndex = firstnameFieldIndex;
        this.#lastnameFieldIndex = lastnameFieldIndex;
        this.#delimiter = delimiter;
        this.#hasHeader = hasHeader;
    }
}
