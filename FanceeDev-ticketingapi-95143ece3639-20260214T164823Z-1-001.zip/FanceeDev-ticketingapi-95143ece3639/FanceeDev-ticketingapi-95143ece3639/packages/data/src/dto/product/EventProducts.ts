import { Dto } from '@fancee/client';
import { ProductIdentification } from '@/dto';

@Dto
export class EventProducts {
    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get products(): ProductIdentification[] {
        return this.#products;
    }

    set products(value: ProductIdentification[]) {
        this.#products = value;
    }

    #eventName: string;
    #products: ProductIdentification[];

    constructor(eventName: string, products: ProductIdentification[]) {
        this.#eventName = eventName;
        this.#products = products;
    }
}
