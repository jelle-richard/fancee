import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { Filter } from '@/dto';
import { ProductOrigin, ScanState } from '@/enum';

@Dto
export class TicketFilter extends Filter<TicketFilter> {
    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    get eventIds(): string[] {
        return this.#eventIds;
    }

    set eventIds(value: string[]) {
        this.#eventIds = value;
    }

    get shopCodes(): string[] {
        return this.#shopCodes;
    }

    set shopCodes(value: string[]) {
        this.#shopCodes = value;
    }

    get origins(): ProductOrigin[] {
        return this.#origins;
    }

    set origins(value: ProductOrigin[]) {
        this.#origins = value;
    }

    get dateSpan(): [DateTime, DateTime] | null {
        return this.#dateSpan;
    }

    set dateSpan(value: [DateTime, DateTime] | null) {
        this.#dateSpan = value;
    }

    get scanState(): ScanState | null {
        return this.#scanState;
    }

    set scanState(value: ScanState | null) {
        this.#scanState = value;
    }

    get optInPromotionalSms(): boolean | null {
        return this.#optInPromotionalSms;
    }

    set optInPromotionalSms(value: boolean | null) {
        this.#optInPromotionalSms = value;
    }

    get optInPromotionalEmail(): boolean | null {
        return this.#optInPromotionalEmail;
    }

    set optInPromotionalEmail(value: boolean | null) {
        this.#optInPromotionalEmail = value;
    }

    get receiveViaSms(): boolean | null {
        return this.#receiveViaSms;
    }

    set receiveViaSms(value: boolean | null) {
        this.#receiveViaSms = value;
    }

    #searchQuery: string;
    #eventIds: string[];
    #shopCodes: string[];
    #origins: ProductOrigin[];
    #dateSpan: [DateTime, DateTime] | null;
    #scanState: ScanState | null;
    #optInPromotionalSms: boolean | null;
    #optInPromotionalEmail: boolean | null;
    #receiveViaSms: boolean | null;

    constructor(searchQuery: string, eventIds: string[], shopCodes: string[], origins: ProductOrigin[], dateSpan: [DateTime, DateTime] | null, scanState: ScanState | null, optInPromotionalSms: boolean | null, optInPromotionalEmail: boolean | null, receiveViaSms: boolean | null) {
        super();
        this.#searchQuery = searchQuery;
        this.#eventIds = eventIds;
        this.#shopCodes = shopCodes;
        this.#origins = origins;
        this.#dateSpan = dateSpan;
        this.#scanState = scanState;
        this.#optInPromotionalSms = optInPromotionalSms;
        this.#optInPromotionalEmail = optInPromotionalEmail;
        this.#receiveViaSms = receiveViaSms;
    }

    public static default(): TicketFilter {
        return new TicketFilter(
            '',
            [],
            [],
            [],
            [
                DateTime.now().plus({months: -3}),
                DateTime.now()
            ],
            null,
            null,
            null,
            null
        );
    }
}
