import { Dto } from '@fancee/client';
import { AddressAdapter } from '@/adapter';
import { CountryCode } from '@/constant';

@Dto
export class Address {
    get venue(): string | null {
        return this.#venue;
    }

    set venue(value: string | null) {
        this.#venue = value;
    }

    get countryCode(): CountryCode | null {
        return this.#countryCode;
    }

    set countryCode(value: CountryCode | null) {
        this.#countryCode = value;
    }

    get city(): string | null {
        return this.#city;
    }

    set city(value: string | null) {
        this.#city = value;
    }

    get postalCode(): string | null {
        return this.#postalCode;
    }

    set postalCode(value: string | null) {
        this.#postalCode = value;
    }

    get street(): string | null {
        return this.#street;
    }

    set street(value: string | null) {
        this.#street = value;
    }

    get houseNumber(): string | null {
        return this.#houseNumber;
    }

    set houseNumber(value: string | null) {
        this.#houseNumber = value;
    }

    get latitude(): number | null {
        return this.#latitude;
    }

    set latitude(value: number | null) {
        this.#latitude = value;
    }

    get longitude(): number | null {
        return this.#longitude;
    }

    set longitude(value: number | null) {
        this.#longitude = value;
    }

    get formatted(): string {
        if (this.#street === null || this.#street.trim().length === 0) {
            return '';
        }

        if (this.#city === null || this.#city.trim().length === 0) {
            return '';
        }

        const parts = [];

        parts.push(`${this.#street ?? ''} ${this.#houseNumber ?? ''}`.trim());
        parts.push(`${this.#postalCode ?? ''} ${this.#city ?? ''}`.trim());

        if (this.#countryCode !== null) {
            parts.push(AddressAdapter.parseCountryCodeToEnglish(this.#countryCode));
        }

        return parts.join(', ');
    }

    get formattedCity(): string {
        if (this.#countryCode === null || this.#countryCode.trim().length === 0) {
            return '';
        }

        if (this.#city === null || this.#city.trim().length === 0) {
            return '';
        }

        const parts = [];
        parts.push(this.#city.trim());
        parts.push(AddressAdapter.parseCountryCodeToEnglish(this.#countryCode));

        return parts.join(', ');
    }

    get isEmpty(): boolean {
        return this.#venue === null
            && this.#countryCode === null
            && this.#city === null
            && this.#postalCode === null
            && this.#street === null
            && this.#houseNumber === null
            && this.#latitude === null
            && this.#longitude === null;
    }

    #venue: string | null;
    #countryCode: CountryCode | null;
    #city: string | null;
    #postalCode: string | null;
    #street: string | null;
    #houseNumber: string | null;
    #latitude: number | null;
    #longitude: number | null;

    constructor(venue: string | null, countryCode: CountryCode | null, city: string | null, postalCode: string | null, street: string | null, houseNumber: string | null, latitude: number | null, longitude: number | null) {
        this.#venue = venue;
        this.#countryCode = countryCode;
        this.#city = city;
        this.#postalCode = postalCode;
        this.#street = street;
        this.#houseNumber = houseNumber;
        this.#latitude = latitude;
        this.#longitude = longitude;
    }

    public static empty(): Address {
        return new Address(null, null, null, null, null, null, null, null);
    }
}
