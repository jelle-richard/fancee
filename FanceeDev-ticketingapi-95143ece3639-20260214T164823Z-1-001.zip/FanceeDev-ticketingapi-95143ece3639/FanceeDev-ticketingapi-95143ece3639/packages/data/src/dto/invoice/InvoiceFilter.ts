import { Filter, OrganizationInvoiceFilter } from '@/dto';

export abstract class InvoiceFilter extends Filter<InvoiceFilter> {
    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    get eventId(): string | null {
        return this.#eventId;
    }

    set eventId(value: string | null) {
        this.#eventId = value;
    }

    #searchQuery: string;
    #eventId: string | null;

    protected constructor(searchQuery: string, eventId: string | null) {
        super();
        this.#searchQuery = searchQuery;
        this.#eventId = eventId;
    }

    public static default(): OrganizationInvoiceFilter {
        return new OrganizationInvoiceFilter('', null);
    }
}
