import { Dto } from '@fancee/client';
import { InvoiceFilter } from '@/dto';

@Dto
export class OrganizationInvoiceFilter extends InvoiceFilter {
    constructor(searchQuery: string, eventId: string | null) {
        super(searchQuery, eventId);
    }
}
