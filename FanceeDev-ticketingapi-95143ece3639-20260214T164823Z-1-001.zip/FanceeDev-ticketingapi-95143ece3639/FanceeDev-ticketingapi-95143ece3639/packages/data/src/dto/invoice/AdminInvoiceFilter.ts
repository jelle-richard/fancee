import { Dto } from '@fancee/client';
import { InvoiceFilter } from '@/dto';

@Dto
export class AdminInvoiceFilter extends InvoiceFilter {
    get organizationId(): string | null {
        return this.#organizationId;
    }

    set organizationId(value: string | null) {
        this.#organizationId = value;
    }

    #organizationId: string | null;

    constructor(searchQuery: string, eventId: string | null, organizationId: string | null) {
        super(searchQuery, eventId);
        this.#organizationId = organizationId;
    }

    public static default(): AdminInvoiceFilter {
        return new AdminInvoiceFilter('', null, null);
    }
}
