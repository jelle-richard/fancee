import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class InvoiceListItem {
    get invoiceNumber(): number {
        return this.#invoiceNumber;
    }

    set invoiceNumber(value: number) {
        this.#invoiceNumber = value;
    }

    get organization(): string {
        return this.#organization;
    }

    set organization(value: string) {
        this.#organization = value;
    }

    get createdAt(): DateTime {
        return this.#createdAt;
    }

    set createdAt(value: DateTime) {
        this.#createdAt = value;
    }

    get hasFile(): boolean {
        return this.#hasFile;
    }

    set hasFile(value: boolean) {
        this.#hasFile = value;
    }

    #invoiceNumber: number;
    #organization: string;
    #createdAt: DateTime;
    #hasFile: boolean;

    constructor(invoiceNumber: number, organization: string, createdAt: DateTime, hasFile: boolean) {
        this.#invoiceNumber = invoiceNumber;
        this.#organization = organization;
        this.#createdAt = createdAt;
        this.#hasFile = hasFile;
    }
}
