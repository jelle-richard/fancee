import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class DateTimeSpan {
    get end(): DateTime | null {
        return this.#end;
    }

    set end(value: DateTime | null) {
        this.#end = value;
    }

    get start(): DateTime | null {
        return this.#start;
    }

    set start(value: DateTime | null) {
        this.#start = value;
    }

    get isEmpty(): boolean {
        return !this.start && !this.end;
    }

    #end: DateTime | null;
    #start: DateTime | null;

    constructor(start: DateTime | null, end: DateTime | null) {
        this.#start = start;
        this.#end = end;
    }

    public static default(): DateTimeSpan {
        return new DateTimeSpan(null, null);
    }
}
