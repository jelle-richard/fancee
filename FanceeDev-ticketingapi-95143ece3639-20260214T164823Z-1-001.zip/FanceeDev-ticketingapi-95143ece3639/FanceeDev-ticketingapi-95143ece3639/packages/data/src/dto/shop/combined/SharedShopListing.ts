import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class SharedShopListing {
    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get eventStartDate(): DateTime {
        return this.#eventStartDate;
    }

    set eventStartDate(value: DateTime) {
        this.#eventStartDate = value;
    }

    get shopName(): string {
        return this.#shopName;
    }

    set shopName(value: string) {
        this.#shopName = value;
    }

    get organizationName(): string {
        return this.#organizationName;
    }

    set organizationName(value: string) {
        this.#organizationName = value;
    }

    get sharedOn(): DateTime {
        return this.#sharedOn;
    }

    set sharedOn(value: DateTime) {
        this.#sharedOn = value;
    }

    #eventName: string;
    #eventStartDate: DateTime;
    #shopName: string;
    #organizationName: string;
    #sharedOn: DateTime;

    constructor(eventName: string, eventStartDate: DateTime, shopName: string, organizationName: string, sharedOn: DateTime) {
        this.#eventName = eventName;
        this.#eventStartDate = eventStartDate;
        this.#shopName = shopName;
        this.#organizationName = organizationName;
        this.#sharedOn = sharedOn;
    }
}
