import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class SecureCodeListing {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get active(): boolean {
        return this.#active;
    }

    set active(value: boolean) {
        this.#active = value;
    }

    get maximumUses(): number | null {
        return this.#maximumUses;
    }

    set maximumUses(value: number | null) {
        this.#maximumUses = value;
    }

    get usedAmount(): number {
        return this.#usedAmount;
    }

    set usedAmount(value: number) {
        this.#usedAmount = value;
    }

    get pendingAmount(): number {
        return this.#pendingAmount;
    }

    set pendingAmount(value: number) {
        this.#pendingAmount = value;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    set createdOn(value: DateTime) {
        this.#createdOn = value;
    }

    #code: string;
    #active: boolean;
    #maximumUses: number | null;
    #usedAmount: number;
    #pendingAmount: number;
    #createdOn: DateTime;

    constructor(code: string, active: boolean, maximumUses: number | null, usedAmount: number, pendingAmount: number, createdOn: DateTime) {
        this.#code = code;
        this.#active = active;
        this.#maximumUses = maximumUses;
        this.#usedAmount = usedAmount;
        this.#pendingAmount = pendingAmount;
        this.#createdOn = createdOn;
    }
}
