import { Dto } from '@fancee/client';
import { ShopField } from '@/enum';

@Dto
export class ShopFieldRequirement {
    get field(): ShopField {
        return this.#field;
    }

    set field(value: ShopField) {
        this.#field = value;
    }

    get enabled(): boolean {
        return this.#enabled;
    }

    set enabled(value: boolean) {
        this.#enabled = value;
    }

    get required(): boolean {
        return this.#required;
    }

    set required(value: boolean) {
        this.#required = value;
    }

    #field: ShopField;
    #enabled: boolean;
    #required: boolean;

    constructor(field: ShopField, enabled: boolean, required: boolean) {
        this.#field = field;
        this.#enabled = enabled;
        this.#required = required;
    }
}
