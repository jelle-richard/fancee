import { Dto } from '@fancee/client';

@Dto
export class CombinedShopListing {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get isActive(): boolean {
        return this.#isActive;
    }

    set isActive(value: boolean) {
        this.#isActive = value;
    }

    get shopsAmount(): number {
        return this.#shopsAmount;
    }

    set shopsAmount(value: number) {
        this.#shopsAmount = value;
    }

    #code: string;
    #name: string;
    #isActive: boolean;
    #shopsAmount: number;

    constructor(code: string, name: string, isActive: boolean, shopsAmount: number) {
        this.#code = code;
        this.#name = name;
        this.#isActive = isActive;
        this.#shopsAmount = shopsAmount;
    }
}
