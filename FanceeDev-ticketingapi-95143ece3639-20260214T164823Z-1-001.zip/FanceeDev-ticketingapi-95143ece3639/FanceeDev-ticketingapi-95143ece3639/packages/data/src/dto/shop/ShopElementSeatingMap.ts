import { Dto } from '@fancee/client';
import { ShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class ShopElementSeatingMap extends ShopElement {
    constructor() {
        super(ShopElementKind.SeatingMap);
    }
}
