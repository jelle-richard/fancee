import { Dto } from '@fancee/client';
import { Media } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class EventShopLinkListItem {
    get active(): boolean {
        return this.#active;
    }

    set active(value: boolean) {
        this.#active = value;
    }

    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get headerMedia(): Media[] {
        return this.#headerMedia;
    }

    set headerMedia(value: Media[]) {
        this.#headerMedia = value;
    }

    get isSecuredUntil(): DateTime | null {
        return this.#isSecuredUntil;
    }

    set isSecuredUntil(value: DateTime | null) {
        this.#isSecuredUntil = value;
    }

    get securable(): boolean {
        return this.#securable;
    }

    set securable(value: boolean) {
        this.#securable = value;
    }

    #active: boolean;
    #code: string;
    #name: string;
    #headerMedia: Media[] = [];
    #isSecuredUntil: DateTime | null;
    #securable: boolean;

    constructor(active: boolean, code: string, name: string, headerMedia: Media[], isSecuredUntil: DateTime | null, securable: boolean) {
        this.#active = active;
        this.#code = code;
        this.#name = name;
        this.#headerMedia = headerMedia;
        this.#isSecuredUntil = isSecuredUntil;
        this.#securable = securable;
    }
}
