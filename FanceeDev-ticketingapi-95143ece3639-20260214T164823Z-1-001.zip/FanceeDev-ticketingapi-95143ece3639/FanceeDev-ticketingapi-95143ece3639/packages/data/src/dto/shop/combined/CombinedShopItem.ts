import { Dto } from '@fancee/client';

@Dto
export class CombinedShopItem {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get active(): boolean {
        return this.#active;
    }

    set active(value: boolean) {
        this.#active = value;
    }

    #code: string;
    #name: string;
    #active: boolean;

    constructor(code: string, name: string, active: boolean) {
        this.#code = code;
        this.#name = name;
        this.#active = active;
    }
}
