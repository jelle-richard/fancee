import { Dto } from '@fancee/client';
import { Filter } from '@/dto';

@Dto
export class SecureCodeListFilter extends Filter<SecureCodeListFilter> {
    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    #searchQuery: string;

    constructor(searchQuery: string) {
        super();
        this.#searchQuery = searchQuery;
    }

    public static default(): SecureCodeListFilter {
        return new SecureCodeListFilter('');
    }
}
