import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class ShopDesign {
    get backdropColor(): string | null {
        return this.#backdropColor;
    }

    set backdropColor(value: string | null) {
        this.#backdropColor = value;
    }

    get backgroundColor(): string | null {
        return this.#backgroundColor;
    }

    set backgroundColor(value: string | null) {
        this.#backgroundColor = value;
    }

    get headerMedia(): Media[] {
        return this.#headerMedia;
    }

    set headerMedia(value: Media[]) {
        this.#headerMedia = value;
    }

    get primaryColor(): string | null {
        return this.#primaryColor;
    }

    set primaryColor(value: string | null) {
        this.#primaryColor = value;
    }

    get textColor(): string | null {
        return this.#textColor;
    }

    set textColor(value: string | null) {
        this.#textColor = value;
    }

    #backdropColor: string | null;
    #backgroundColor: string | null;
    #headerMedia: Media[] = [];
    #primaryColor: string | null;
    #textColor: string | null;

    constructor(headerMedia: Media[], primaryColor: string | null, textColor: string | null, backdropColor: string | null, backgroundColor: string | null) {
        this.#headerMedia = headerMedia;
        this.#primaryColor = primaryColor;
        this.#textColor = textColor;
        this.#backdropColor = backdropColor;
        this.#backgroundColor = backgroundColor;
    }

    addHeaderMedia(media: Media): void {
        this.#headerMedia.push(media);
    }

    removeHeaderMedia(id: string): void {
        const mediaIndex = this.#headerMedia.findIndex(m => m.id === id);

        if (mediaIndex === -1) {
            return;
        }

        this.#headerMedia.splice(mediaIndex, 1);
    }

    static default(): ShopDesign {
        return new ShopDesign([], null, null, null, null);
    }
}
