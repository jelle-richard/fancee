import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { SeatedProduct, ShopAnalytics, ShopDesign, ShopElement, ShopEvent, ShopFieldRequirement } from '@/dto';

@Dto
export class ShopDetails {
    get event(): ShopEvent {
        return this.#event;
    }

    set event(value: ShopEvent) {
        this.#event = value;
    }

    get elements(): ShopElement[] {
        return this.#elements;
    }

    set elements(value: ShopElement[]) {
        this.#elements = value;
    }

    get design(): ShopDesign {
        return this.#design;
    }

    set design(value: ShopDesign) {
        this.#design = value;
    }

    get secured(): boolean {
        return this.#secured;
    }

    set secured(value: boolean) {
        this.#secured = value;
    }

    get platformSmsCostCents(): number {
        return this.#platformSmsCostCents;
    }

    set platformSmsCostCents(value: number) {
        this.#platformSmsCostCents = value;
    }

    get platformTicketServicePlusCostCents(): number {
        return this.#platformTicketServicePlusCostCents;
    }

    set platformTicketServicePlusCostCents(value: number) {
        this.#platformTicketServicePlusCostCents = value;
    }

    get shopFields(): ShopFieldRequirement[] {
        return this.#shopFields;
    }

    set shopFields(value: ShopFieldRequirement[]) {
        this.#shopFields = value;
    }

    get analytics(): ShopAnalytics {
        return this.#analytics;
    }

    set analytics(value: ShopAnalytics) {
        this.#analytics = value;
    }

    get seatedProducts(): SeatedProduct[] | null {
        return this.#seatedProducts;
    }

    set seatedProducts(value: SeatedProduct[] | null) {
        this.#seatedProducts = value;
    }

    #event: ShopEvent;
    #elements: ShopElement[];
    #design: ShopDesign;
    #secured: boolean;
    #platformSmsCostCents: number;
    #platformTicketServicePlusCostCents: number;
    #shopFields: ShopFieldRequirement[];
    #analytics: ShopAnalytics;
    #seatedProducts: SeatedProduct[] | null;

    constructor(event: ShopEvent, elements: ShopElement[], design: ShopDesign, secured: boolean, platformSmsCostCents: number, platformTicketServicePlusCostCents: number, shopFields: ShopFieldRequirement[], analytics: ShopAnalytics, seatedProcuts: SeatedProduct[] | null) {
        this.#event = event;
        this.#elements = elements;
        this.#design = design;
        this.#secured = secured;
        this.#platformSmsCostCents = platformSmsCostCents;
        this.#platformTicketServicePlusCostCents = platformTicketServicePlusCostCents;
        this.#shopFields = shopFields;
        this.#analytics = analytics;
        this.#seatedProducts = seatedProcuts;
    }
}
