import { Dto } from '@fancee/client';
import { DateTimeSpan, Media, ShopElement } from '@/dto';
import { ProductType, ShopElementKind } from '@/enum';

@Dto
export class ShopElementProduct extends ShopElement {
    get id(): string {
        return this.#id;
    }

    get description(): string {
        return this.#description;
    }

    get media(): Media[] {
        return this.#media;
    }

    get name(): string {
        return this.#name;
    }

    get packQuantity(): number {
        return this.#packQuantity;
    }

    get priceCents(): number {
        return this.#priceCents;
    }

    get feeCents(): number {
        return this.#feeCents;
    }

    get reservableQuantity(): number {
        return this.#reservableQuantity;
    }

    get type(): ProductType {
        return this.#type;
    }

    get saleSpan(): DateTimeSpan {
        return this.#saleSpan;
    }

    get hasPendingReservations(): boolean {
        return this.#hasPendingReservations;
    }

    get selectedQuantity(): number {
        return this.#selectedQuantity;
    }

    set selectedQuantity(value: number) {
        this.#selectedQuantity = value;
    }

    readonly #id: string;
    readonly #description: string;
    readonly #media: Media[];
    readonly #name: string;
    readonly #packQuantity: number;
    readonly #priceCents: number;
    readonly #feeCents: number;
    readonly #reservableQuantity: number;
    readonly #type: ProductType;
    readonly #saleSpan: DateTimeSpan;
    readonly #hasPendingReservations: boolean;
    #selectedQuantity: number;

    constructor(id: string, description: string, media: Media[], name: string, packQuantity: number, priceCents: number, feeCents: number, reservableQuantity: number, type: ProductType, saleSpan: DateTimeSpan, hasPendingReservations: boolean) {
        super(ShopElementKind.Product);
        this.#id = id;
        this.#description = description;
        this.#media = media;
        this.#name = name;
        this.#packQuantity = packQuantity;
        this.#priceCents = priceCents;
        this.#feeCents = feeCents;
        this.#reservableQuantity = reservableQuantity;
        this.#type = type;
        this.#saleSpan = saleSpan;
        this.#hasPendingReservations = hasPendingReservations;
        this.#selectedQuantity = 0;
    }
}
