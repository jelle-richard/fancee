import { Dto } from '@fancee/client';

@Dto
export class SeatedProduct {
    get productId(): string {
        return this.#productId;
    }

    set productId(value: string) {
        this.#productId = value;
    }

    get seatsIoCategoryId(): string {
        return this.#seatsIoCategoryId;
    }

    set seatsIoCategoryId(value: string) {
        this.#seatsIoCategoryId = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get reservableQuantity(): number {
        return this.#reservableQuantity;
    }

    set reservableQuantity(value: number) {
        this.#reservableQuantity = value;
    }

    get feeCents(): number {
        return this.#feeCents;
    }

    set feeCents(value: number) {
        this.#feeCents = value;
    }

    get priceCents(): number {
        return this.#priceCents;
    }

    set priceCents(value: number) {
        this.#priceCents = value;
    }

    #productId: string;
    #seatsIoCategoryId: string;
    #name: string;
    #description: string;
    #reservableQuantity: number;
    #feeCents: number;
    #priceCents: number;

    constructor(productId: string, seatsIoCategoryId: string, name: string, description: string, reservableQuantity: number, feeCents: number, priceCents: number) {
        this.#productId = productId;
        this.#seatsIoCategoryId = seatsIoCategoryId;
        this.#name = name;
        this.#description = description;
        this.#reservableQuantity = reservableQuantity;
        this.#feeCents = feeCents;
        this.#priceCents = priceCents;
    }
}
