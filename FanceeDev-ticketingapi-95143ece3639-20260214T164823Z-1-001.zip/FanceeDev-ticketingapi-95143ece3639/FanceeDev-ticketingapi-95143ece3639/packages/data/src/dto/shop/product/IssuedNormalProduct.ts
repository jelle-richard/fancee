import { Dto } from '@fancee/client';
import { IssuedProduct, Media } from '@/dto';
import { ProductType } from '@/enum';

@Dto
export class IssuedNormalProduct extends IssuedProduct {
    constructor(id: string, productId: string, orderId: string, type: ProductType, quantity: number, name: string, media: Media | null, productFeeCents: number, costCents: number) {
        super(id, productId, orderId, type, quantity, name, media, productFeeCents, costCents);
    }
}
