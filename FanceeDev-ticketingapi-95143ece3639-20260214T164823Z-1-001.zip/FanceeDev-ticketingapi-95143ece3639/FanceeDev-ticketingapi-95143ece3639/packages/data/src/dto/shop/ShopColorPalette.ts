import { Dto } from '@fancee/client';

@Dto
export class ShopColorPalette {
    get primaryColor(): string {
        return this.#primaryColor;
    }

    set primaryColor(value: string) {
        this.#primaryColor = value;
    }

    get textColor(): string {
        return this.#textColor;
    }

    set textColor(value: string) {
        this.#textColor = value;
    }

    get backdropColor(): string {
        return this.#backdropColor;
    }

    set backdropColor(value: string) {
        this.#backdropColor = value;
    }

    get backgroundColor(): string {
        return this.#backgroundColor;
    }

    set backgroundColor(value: string) {
        this.#backgroundColor = value;
    }

    #primaryColor: string;
    #textColor: string;
    #backdropColor: string;
    #backgroundColor: string;

    constructor(primaryColor: string, textColor: string, backdropColor: string, backgroundColor: string) {
        this.#primaryColor = primaryColor;
        this.#textColor = textColor;
        this.#backdropColor = backdropColor;
        this.#backgroundColor = backgroundColor;
    }
}
