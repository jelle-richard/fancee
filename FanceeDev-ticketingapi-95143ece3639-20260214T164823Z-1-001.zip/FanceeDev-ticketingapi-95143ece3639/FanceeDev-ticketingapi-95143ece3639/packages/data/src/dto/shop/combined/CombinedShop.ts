import { Dto } from '@fancee/client';
import { Media, ShopAnalytics } from '@/dto';

@Dto
export class CombinedShop {
    get title(): string {
        return this.#title;
    }

    set title(value: string) {
        this.#title = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get active(): boolean {
        return this.#active;
    }

    set active(value: boolean) {
        this.#active = value;
    }

    get analytics(): ShopAnalytics {
        return this.#analytics;
    }

    set analytics(value: ShopAnalytics) {
        this.#analytics = value;
    }

    get shopCodes(): string[] {
        return this.#shopCodes;
    }

    set shopCodes(value: string[]) {
        this.#shopCodes = value;
    }

    get headerMedia(): Media[] {
        return this.#headerMedia;
    }

    set headerMedia(value: Media[]) {
        this.#headerMedia = value;
    }

    get primaryColor(): string {
        return this.#primaryColor;
    }

    set primaryColor(value: string) {
        this.#primaryColor = value;
    }

    get textColor(): string {
        return this.#textColor;
    }

    set textColor(value: string) {
        this.#textColor = value;
    }

    get backdropColor(): string {
        return this.#backdropColor;
    }

    set backdropColor(value: string) {
        this.#backdropColor = value;
    }

    get backgroundColor(): string {
        return this.#backgroundColor;
    }

    set backgroundColor(value: string) {
        this.#backgroundColor = value;
    }

    #title: string;
    #description: string;
    #active: boolean;
    #analytics: ShopAnalytics;
    #shopCodes: string[];
    #headerMedia: Media[];
    #primaryColor: string | null;
    #textColor: string | null;
    #backdropColor: string | null;
    #backgroundColor: string | null;

    constructor(title: string, description: string, active: boolean, analytics: ShopAnalytics, shopCodes: string[], headerMedia: Media[], primaryColor: string | null, textColor: string | null, backdropColor: string | null, backgroundColor: string | null) {
        this.#title = title;
        this.#description = description;
        this.#active = active;
        this.#analytics = analytics;
        this.#shopCodes = shopCodes;
        this.#headerMedia = headerMedia;
        this.#primaryColor = primaryColor;
        this.#textColor = textColor;
        this.#backdropColor = backdropColor;
        this.#backgroundColor = backgroundColor;
    }

    public static default(): CombinedShop {
        return new CombinedShop('', '', false, ShopAnalytics.default(), [], [], null, null, null, null);
    }
}
