import { Dto } from '@fancee/client';
import { IssuedProduct, Media } from '@/dto';
import { ProductType } from '@/enum';

@Dto
export class IssuedTicket extends IssuedProduct {
    get maxAttendees(): number {
        return this.#maxAttendees;
    }

    set maxAttendees(value: number) {
        this.#maxAttendees = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    #maxAttendees: number;
    #ticketFeeCents: number;

    constructor(id: string, productId: string, orderId: string, type: ProductType, quantity: number, name: string, media: Media | null, productFeeCents: number, costCents: number, maxAttendees: number, ticketFeeCents: number) {
        super(id, productId, orderId, type, quantity, name, media, productFeeCents, costCents);

        this.#maxAttendees = maxAttendees;
        this.#ticketFeeCents = ticketFeeCents;
    }
}
