import { Dto } from '@fancee/client';

@Dto
export class SecureCode {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get maximumUses(): number | null {
        return this.#maximumUses;
    }

    set maximumUses(value: number | null) {
        this.#maximumUses = value;
    }

    get active(): boolean {
        return this.#active;
    }

    set active(value: boolean) {
        this.#active = value;
    }

    #code: string;
    #maximumUses: number | null;
    #active: boolean;

    constructor(code: string, maximumUses: number | null, active: boolean) {
        this.#code = code;
        this.#maximumUses = maximumUses;
        this.#active = active;
    }
}
