import { Dto } from '@fancee/client';
import { ShopElement } from '@/dto';
import { ColorType } from '@/type';
import { ShopElementKind } from '@/enum';

@Dto
export class ShopElementNotice extends ShopElement {
    get content(): string {
        return this.#content;
    }

    get variant(): ColorType {
        return this.#variant;
    }

    readonly #content: string;
    readonly #variant: ColorType;

    constructor(content: string, variant: ColorType) {
        super(ShopElementKind.Notice);
        this.#content = content;
        this.#variant = variant;
    }
}
