import { Dto } from '@fancee/client';
import { ShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class ShopElementDivider extends ShopElement {
    get name(): string {
        return this.#name;
    }

    readonly #name: string;

    constructor(name: string) {
        super(ShopElementKind.Divider);
        this.#name = name;
    }
}
