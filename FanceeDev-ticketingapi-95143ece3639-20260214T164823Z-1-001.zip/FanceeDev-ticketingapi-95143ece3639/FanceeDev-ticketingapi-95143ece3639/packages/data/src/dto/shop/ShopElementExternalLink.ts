import { Dto } from '@fancee/client';
import { ShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class ShopElementExternalLink extends ShopElement {
    get link(): string {
        return this.#link;
    }

    get name(): string {
        return this.#name;
    }

    readonly #link: string;
    readonly #name: string;

    constructor(link: string, name: string) {
        super(ShopElementKind.ExternalLink);
        this.#link = link;
        this.#name = name;
    }
}
