import { Dto } from '@fancee/client';
import { ShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class ShopElementTextBlock extends ShopElement {
    get text(): string {
        return this.#text;
    }

    get title(): string {
        return this.#title;
    }

    readonly #text: string;
    readonly #title: string;

    constructor(text: string, title: string) {
        super(ShopElementKind.TextBlock);
        this.#text = text;
        this.#title = title;
    }
}
