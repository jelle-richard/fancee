import { Dto } from '@fancee/client';
import { ShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class ShopElementAccordion extends ShopElement {
    get elements(): ShopElement[] {
        return this.#elements;
    }

    get icon(): string {
        return this.#icon;
    }

    get opened(): boolean {
        return this.#opened;
    }

    get title(): string {
        return this.#title;
    }

    readonly #elements: ShopElement[];
    readonly #icon: string;
    readonly #opened: boolean;
    readonly #title: string;

    constructor(elements: ShopElement[], icon: string, opened: boolean, title: string) {
        super(ShopElementKind.Accordion);
        this.#elements = elements;
        this.#icon = icon;
        this.#opened = opened;
        this.#title = title;
    }
}
