import { Dto } from '@fancee/client';

@Dto
export class ShopAnalytics {
    get googleAnalyticsId(): string | null {
        return this.#googleAnalyticsId;
    }

    set googleAnalyticsId(value: string | null) {
        this.#googleAnalyticsId = value;
    }

    get googleTagManagerId(): string | null {
        return this.#googleTagManagerId;
    }

    set googleTagManagerId(value: string | null) {
        this.#googleTagManagerId = value;
    }

    get tiktokPixelId(): string | null {
        return this.#tiktokPixelId;
    }

    set tiktokPixelId(value: string | null) {
        this.#tiktokPixelId = value;
    }

    get facebookPixelId(): string | null {
        return this.#facebookPixelId;
    }

    set facebookPixelId(value: string | null) {
        this.#facebookPixelId = value;
    }

    get facebookAccessCode(): string | null {
        return this.#facebookAccessCode;
    }

    set facebookAccessCode(value: string | null) {
        this.#facebookAccessCode = value;
    }

    #googleAnalyticsId: string | null;
    #googleTagManagerId: string | null;
    #tiktokPixelId: string | null;
    #facebookPixelId: string | null;
    #facebookAccessCode: string | null;

    constructor(googleAnalyticsId: string | null, googleTagManagerId: string | null, tiktokPixelId: string | null, facebookPixelId: string | null, facebookAccessCode: string | null) {
        this.#googleAnalyticsId = googleAnalyticsId;
        this.#googleTagManagerId = googleTagManagerId;
        this.#tiktokPixelId = tiktokPixelId;
        this.#facebookPixelId = facebookPixelId;
        this.#facebookAccessCode = facebookAccessCode;
    }

    public static default(): ShopAnalytics {
        return new ShopAnalytics(null, null, null, null, null);
    }
}
