import { Dto } from '@fancee/client';
import { CombinedShopItem } from '@/dto';

@Dto
export class ShopsSharedWithMeListing {
    get shopName(): string {
        return this.#shopName;
    }

    set shopName(value: string) {
        this.#shopName = value;
    }

    get organizationId(): string {
        return this.#organizationId;
    }

    set organizationId(value: string) {
        this.#organizationId = value;
    }

    get organizationName(): string {
        return this.#organizationName;
    }

    set organizationName(value: string) {
        this.#organizationName = value;
    }

    get combinedShops(): CombinedShopItem[] {
        return this.#combinedShops;
    }

    set combinedShops(value: CombinedShopItem[]) {
        this.#combinedShops = value;
    }

    #shopName: string;
    #organizationId: string;
    #organizationName: string;
    #combinedShops: CombinedShopItem[];

    constructor(shopName: string, organizationId: string, organizationName: string, combinedShops: CombinedShopItem[]) {
        this.#shopName = shopName;
        this.#organizationId = organizationId;
        this.#organizationName = organizationName;
        this.#combinedShops = combinedShops;
    }
}
