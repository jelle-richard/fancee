import { Dto } from '@fancee/client';
import { CsvDelimiter } from '@/enum';

@Dto
export class SecureCodeImportCsv {
    get media(): Blob {
        return this.#media;
    }

    set media(value: Blob) {
        this.#media = value;
    }

    get codeIndex(): number {
        return this.#codeIndex;
    }

    set codeIndex(value: number) {
        this.#codeIndex = value;
    }

    get usesIndex(): number {
        return this.#usesIndex;
    }

    set usesIndex(value: number) {
        this.#usesIndex = value;
    }

    get delimiter(): string {
        return this.#delimiter;
    }

    set delimiter(value: string) {
        this.#delimiter = value;
    }

    get hasHeader(): boolean {
        return this.#hasHeader;
    }

    set hasHeader(value: boolean) {
        this.#hasHeader = value;
    }

    #media: Blob;
    #codeIndex: number;
    #usesIndex: number;
    #delimiter: string;
    #hasHeader: boolean;

    constructor(media: Blob, codeIndex: number, usesIndex: number, delimiter: string, hasHeader: boolean) {
        this.#media = media;
        this.#codeIndex = codeIndex;
        this.#usesIndex = usesIndex;
        this.#delimiter = delimiter;
        this.#hasHeader = hasHeader;
    }
}
