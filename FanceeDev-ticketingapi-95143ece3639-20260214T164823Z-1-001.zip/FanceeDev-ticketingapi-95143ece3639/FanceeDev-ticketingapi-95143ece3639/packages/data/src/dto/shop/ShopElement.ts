import { ShopElementAccordion, ShopElementDivider, ShopElementExternalLink, ShopElementNotice, ShopElementProduct, ShopElementTextBlock } from '@/dto';
import { ShopElementKind } from '@/enum';

export abstract class ShopElement {
    get kind(): ShopElementKind {
        return this.#kind;
    }

    readonly #kind: ShopElementKind;

    protected constructor(kind: ShopElementKind) {
        this.#kind = kind;
    }

    public static isAccordion(element: ShopElement): element is ShopElementAccordion {
        return element && element.kind === ShopElementKind.Accordion;
    }

    public static isDivider(element: ShopElement): element is ShopElementDivider {
        return element && element.kind === ShopElementKind.Divider;
    }

    public static isExternalLink(element: ShopElement): element is ShopElementExternalLink {
        return element && element.kind === ShopElementKind.ExternalLink;
    }

    public static isNotice(element: ShopElement): element is ShopElementNotice {
        return element && element.kind === ShopElementKind.Notice;
    }

    public static isProduct(element: ShopElement): element is ShopElementProduct {
        return element && element.kind === ShopElementKind.Product;
    }

    public static isSeatingMap(element: ShopElement): element is ShopElementTextBlock {
        return element && element.kind === ShopElementKind.SeatingMap;
    }

    public static isTextBlock(element: ShopElement): element is ShopElementTextBlock {
        return element && element.kind === ShopElementKind.TextBlock;
    }
}
