import { Dto } from '@fancee/client';
import { FocalPoint } from '@/dto';

@Dto
export class Media {
    get id(): string | null {
        return this.#id;
    }

    set id(value: string | null) {
        this.#id = value;
    }

    get url(): string {
        return this.#url;
    }

    set url(value: string) {
        this.#url = value;
    }

    get originalFileName(): string | null {
        return this.#originalFileName;
    }

    set originalFileName(value: string | null) {
        this.#originalFileName = value;
    }

    get mimeType(): string | null {
        return this.#mimeType;
    }

    set mimeType(value: string | null) {
        this.#mimeType = value;
    }

    get focalPoint(): FocalPoint | null {
        return this.#focalPoint;
    }

    set focalPoint(value: FocalPoint | null) {
        this.#focalPoint = value;
    }

    #url: string;
    #id: string | null;
    #originalFileName: string | null;
    #mimeType: string | null;
    #focalPoint: FocalPoint | null;

    constructor(id: string | null, url: string, originalFileName: string | null, mimeType: string | null, focalPoint: FocalPoint | null = null) {
        this.#url = url;
        this.#id = id;
        this.#originalFileName = originalFileName;
        this.#mimeType = mimeType;
        this.#focalPoint = focalPoint;
    }
}
