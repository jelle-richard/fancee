import { Dto } from '@fancee/client';

@Dto
export class FocalPoint {
    get x(): number {
        return this.#x;
    }

    set x(value: number) {
        this.#x = value;
    }

    get y(): number {
        return this.#y;
    }

    set y(value: number) {
        this.#y = value;
    }

    #x: number;
    #y: number;

    constructor(x: number, y: number) {
        this.#x = x;
        this.#y = y;
    }

    public static default(): FocalPoint {
        return new FocalPoint(50, 50);
    }
}
