import { Dto } from '@fancee/client';

@Dto
export class ClientOptions {
    get receiveSms(): boolean {
        return this.#receiveSms;
    }

    set receiveSms(value: boolean) {
        this.#receiveSms = value;
    }

    get upgradeTsp(): boolean {
        return this.#upgradeTsp;
    }

    set upgradeTsp(value: boolean) {
        this.#upgradeTsp = value;
    }

    get acceptedTerms(): boolean {
        return this.#acceptedTerms;
    }

    set acceptedTerms(value: boolean) {
        this.#acceptedTerms = value;
    }

    get acceptedSummary(): boolean {
        return this.#acceptedSummary;
    }

    set acceptedSummary(value: boolean) {
        this.#acceptedSummary = value;
    }

    get optInPromotionalEmail(): boolean {
        return this.#optInPromotionalEmail;
    }

    set optInPromotionalEmail(value: boolean) {
        this.#optInPromotionalEmail = value;
    }

    get optInPromotionalSms(): boolean {
        return this.#optInPromotionalSms;
    }

    set optInPromotionalSms(value: boolean) {
        this.#optInPromotionalSms = value;
    }

    #receiveSms: boolean;
    #upgradeTsp: boolean;
    #acceptedTerms: boolean;
    #acceptedSummary: boolean;
    #optInPromotionalEmail: boolean;
    #optInPromotionalSms: boolean;

    constructor(receiveSms: boolean, upgradeTsp: boolean, acceptedTerms: boolean, acceptedSummary: boolean, optInPromotionalEmail: boolean, optInPromotionalSms: boolean) {
        this.#receiveSms = receiveSms;
        this.#upgradeTsp = upgradeTsp;
        this.#acceptedTerms = acceptedTerms;
        this.#acceptedSummary = acceptedSummary;
        this.#optInPromotionalEmail = optInPromotionalEmail;
        this.#optInPromotionalSms = optInPromotionalSms;
    }

    public static empty(): ClientOptions {
        return new ClientOptions(false, false, false, false, false, false);
    }
}
