import { Dto } from '@fancee/client';
import { OrderCostDiscount } from '@/dto';

@Dto
export class OrderCost {
    get discount(): OrderCostDiscount | null {
        return this.#discount;
    }

    set discount(value: OrderCostDiscount | null) {
        this.#discount = value;
    }

    get paymentFeeCents(): number {
        return this.#paymentFeeCents;
    }

    set paymentFeeCents(value: number) {
        this.#paymentFeeCents = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    get seatedTicketFeeCents(): number {
        return this.#seatedTicketFeeCents;
    }

    set seatedTicketFeeCents(value: number) {
        this.#seatedTicketFeeCents = value;
    }

    get ticketServicePlusCents(): number {
        return this.#ticketServicePlusCents;
    }

    set ticketServicePlusCents(value: number) {
        this.#ticketServicePlusCents = value;
    }

    get totalOrderCostCents(): number {
        return this.#totalOrderCostCents;
    }

    set totalOrderCostCents(value: number) {
        this.#totalOrderCostCents = value;
    }

    #discount: OrderCostDiscount | null;
    #paymentFeeCents: number;
    #productFeeCents: number;
    #ticketFeeCents: number;
    #seatedTicketFeeCents: number;
    #ticketServicePlusCents: number;
    #totalOrderCostCents: number;

    constructor(discount: OrderCostDiscount | null, paymentFeeCents: number, productFeeCents: number, ticketFeeCents: number, seatedTicketFeeCents: number, ticketServicePlusCents: number, totalOrderCostCents: number) {
        this.#discount = discount;
        this.#paymentFeeCents = paymentFeeCents;
        this.#productFeeCents = productFeeCents;
        this.#ticketFeeCents = ticketFeeCents;
        this.#seatedTicketFeeCents = seatedTicketFeeCents;
        this.#ticketServicePlusCents = ticketServicePlusCents;
        this.#totalOrderCostCents = totalOrderCostCents;
    }
}
