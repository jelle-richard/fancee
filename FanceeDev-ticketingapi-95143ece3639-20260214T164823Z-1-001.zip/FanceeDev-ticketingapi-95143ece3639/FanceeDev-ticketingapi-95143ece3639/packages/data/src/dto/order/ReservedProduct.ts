import { Dto } from '@fancee/client';

@Dto
export class ReservedProduct {
    get productId(): string {
        return this.#productId;
    }

    set productId(value: string) {
        this.#productId = value;
    }

    get quantity(): number {
        return this.#quantity;
    }

    set quantity(value: number) {
        this.#quantity = value;
    }

    get seatLabels(): string[] {
        return this.#seatLabels;
    }

    set seatLabels(value: string[]) {
        this.#seatLabels = value;
    }

    #productId: string;
    #quantity: number;
    #seatLabels: string[];

    constructor(productId: string, quantity: number, seatLabels: string[]) {
        this.#productId = productId;
        this.#quantity = quantity;
        this.#seatLabels = seatLabels;
    }
}
