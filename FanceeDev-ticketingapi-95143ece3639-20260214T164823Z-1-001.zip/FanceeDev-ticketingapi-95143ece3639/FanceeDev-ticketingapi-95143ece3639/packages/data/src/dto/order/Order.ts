import { Dto } from '@fancee/client';
import { ClientOrder, Currency, OrderEvent, OrderPaymentHistory, OrderProduct } from '@/dto';
import { PaymentStatus } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class Order {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get costCents(): number | null {
        return this.#costCents;
    }

    set costCents(value: number | null) {
        this.#costCents = value;
    }

    get transactionStatus(): PaymentStatus {
        return this.#transactionStatus;
    }

    set transactionStatus(value: PaymentStatus) {
        this.#transactionStatus = value;
    }

    get paymentMethod(): string {
        return this.#paymentMethod;
    }

    set paymentMethod(value: string) {
        this.#paymentMethod = value;
    }

    get placedOn(): DateTime {
        return this.#placedOn;
    }

    set placedOn(value: DateTime) {
        this.#placedOn = value;
    }

    get lastAlteration(): DateTime {
        return this.#lastAlteration;
    }

    set lastAlteration(value: DateTime) {
        this.#lastAlteration = value;
    }

    get pspReference(): string {
        return this.#pspReference;
    }

    set pspReference(value: string) {
        this.#pspReference = value;
    }

    get reservationReference(): string {
        return this.#reservationReference;
    }

    set reservationReference(value: string) {
        this.#reservationReference = value;
    }

    get paymentMethodId(): string {
        return this.#paymentMethodId;
    }

    set paymentMethodId(value: string) {
        this.#paymentMethodId = value;
    }

    get client(): ClientOrder {
        return this.#client;
    }

    set client(value: ClientOrder) {
        this.#client = value;
    }

    get event(): OrderEvent {
        return this.#event;
    }

    set event(value: OrderEvent) {
        this.#event = value;
    }

    get products(): OrderProduct[] {
        return this.#products;
    }

    set products(value: OrderProduct[]) {
        this.#products = value;
    }

    get currency(): Currency | null {
        return this.#currency;
    }

    set currency(value: Currency | null) {
        this.#currency = value;
    }

    get paymentHistory(): OrderPaymentHistory[] {
        return this.#paymentHistory;
    }

    set paymentHistory(value: OrderPaymentHistory[]) {
        this.#paymentHistory = value;
    }

    #id: string;
    #costCents: number | null;
    #transactionStatus: PaymentStatus;
    #paymentMethod: string;
    #placedOn: DateTime;
    #lastAlteration: DateTime;
    #pspReference: string;
    #reservationReference: string;
    #paymentMethodId: string;
    #client: ClientOrder;
    #event: OrderEvent;
    #products: OrderProduct[];
    #currency: Currency | null;
    #paymentHistory: OrderPaymentHistory[];

    constructor(id: string, costCents: number | null, transactionStatus: PaymentStatus, paymentMethod: string, placedOn: DateTime, lastAlteration: DateTime, pspReference: string, reservationReference: string, paymentMethodId: string, client: ClientOrder, event: OrderEvent, products: OrderProduct[], currency: Currency | null, paymentHistory: OrderPaymentHistory[]) {
        this.#id = id;
        this.#costCents = costCents;
        this.#transactionStatus = transactionStatus;
        this.#paymentMethod = paymentMethod;
        this.#placedOn = placedOn;
        this.#lastAlteration = lastAlteration;
        this.#pspReference = pspReference;
        this.#reservationReference = reservationReference;
        this.#paymentMethodId = paymentMethodId;
        this.#client = client;
        this.#event = event;
        this.#products = products;
        this.#currency = currency;
        this.#paymentHistory = paymentHistory;
    }
}
