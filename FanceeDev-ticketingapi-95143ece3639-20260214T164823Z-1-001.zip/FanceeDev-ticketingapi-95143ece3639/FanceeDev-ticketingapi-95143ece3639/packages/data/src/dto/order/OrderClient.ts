import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { Address } from '@/dto';
import { Gender } from '@/enum';

@Dto
export class OrderClient {
    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    get phoneNumber(): string {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string) {
        this.#phoneNumber = value;
    }

    get gender(): Gender | null {
        return this.#gender;
    }

    set gender(value: Gender | null) {
        this.#gender = value;
    }

    get birthDate(): DateTime | null {
        return this.#birthDate;
    }

    set birthDate(value: DateTime | null) {
        this.#birthDate = value;
    }

    get address(): Address {
        return this.#address;
    }

    set address(value: Address) {
        this.#address = value;
    }

    #email: string;
    #firstName: string;
    #lastName: string;
    #phoneNumber: string;
    #gender: Gender | null;
    #birthDate: DateTime | null;
    #address: Address;

    constructor(email: string, firstName: string, lastName: string, phoneNumber: string, gender: Gender | null, birthDate: DateTime | null, address: Address) {
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#phoneNumber = phoneNumber;
        this.#gender = gender;
        this.#birthDate = birthDate;
        this.#address = address;
    }

    public static default(): OrderClient {
        return new OrderClient('', '', '', '', null, null, Address.empty());
    }
}
