import { Dto } from '@fancee/client';
import { RefundableProduct } from '@/dto/order/RefundableProduct';

@Dto
export class Refund {
    get returnToStock(): boolean {
        return this.#returnToStock;
    }

    set returnToStock(value: boolean) {
        this.#returnToStock = value;
    }

    get invalidateTickets(): boolean {
        return this.#invalidateTickets;
    }

    set invalidateTickets(value: boolean) {
        this.#invalidateTickets = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get products(): RefundableProduct[] {
        return this.#products;
    }

    set products(value: RefundableProduct[]) {
        this.#products = value;
    }

    #returnToStock: boolean;
    #invalidateTickets: boolean;
    #description: string;
    #products: RefundableProduct[];

    constructor(returnToStock: boolean, invalidateTickets: boolean, description: string, products: RefundableProduct[]) {
        this.#returnToStock = returnToStock;
        this.#invalidateTickets = invalidateTickets;
        this.#description = description;
        this.#products = products;
    }
}
