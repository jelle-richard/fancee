import { Dto } from '@fancee/client';
import { TicketHolder } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class OrderedTicket {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get label(): string {
        return this.#label;
    }

    set label(value: string) {
        this.#label = value;
    }

    get eventStartDate(): DateTime {
        return this.#eventStartDate;
    }

    set eventStartDate(value: DateTime) {
        this.#eventStartDate = value;
    }

    get maximumPreArrivalTimeMinutes(): number {
        return this.#maximumPreArrivalTimeMinutes;
    }

    set maximumPreArrivalTimeMinutes(value: number) {
        this.#maximumPreArrivalTimeMinutes = value;
    }

    get partialAccessStart(): DateTime | null {
        return this.#partialAccessStart;
    }

    set partialAccessStart(value: DateTime | null) {
        this.#partialAccessStart = value;
    }

    get partialAccessEnd(): DateTime | null {
        return this.#partialAccessEnd;
    }

    set partialAccessEnd(value: DateTime | null) {
        this.#partialAccessEnd = value;
    }

    get holder(): TicketHolder {
        return this.#holder;
    }

    set holder(value: TicketHolder) {
        this.#holder = value;
    }

    get isSwappable(): boolean {
        return this.#isSwappable;
    }

    set isSwappable(value: boolean) {
        this.#isSwappable = value;
    }

    #code: string;
    #name: string;
    #label: string;
    #eventStartDate: DateTime;
    #maximumPreArrivalTimeMinutes: number;
    #partialAccessStart: DateTime | null;
    #partialAccessEnd: DateTime | null;
    #holder: TicketHolder;
    #isSwappable: boolean;

    constructor(code: string, name: string, label: string, eventStartDate: DateTime, maximumPreArrivalTimeMinutes: number, partialAccessStart: DateTime | null, partialAccessEnd: DateTime | null, holder: TicketHolder, isSwappable: boolean) {
        this.#code = code;
        this.#name = name;
        this.#label = label;
        this.#eventStartDate = eventStartDate;
        this.#maximumPreArrivalTimeMinutes = maximumPreArrivalTimeMinutes;
        this.#partialAccessStart = partialAccessStart;
        this.#partialAccessEnd = partialAccessEnd;
        this.#holder = holder;
        this.#isSwappable = isSwappable;
    }
}
