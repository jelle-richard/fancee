import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { PaymentStatus } from '@/enum';

@Dto
export class OrderPaymentHistory {
    get createdOn(): DateTime {
        return this.#createdOn;
    }

    set createdOn(value: DateTime) {
        this.#createdOn = value;
    }

    get amountCents(): number {
        return this.#amountCents;
    }

    set amountCents(value: number) {
        this.#amountCents = value;
    }

    get pspReference(): string {
        return this.#pspReference;
    }

    set pspReference(value: string) {
        this.#pspReference = value;
    }

    get paymentStatus(): PaymentStatus {
        return this.#paymentStatus;
    }

    set paymentStatus(value: PaymentStatus) {
        this.#paymentStatus = value;
    }

    #createdOn: DateTime;
    #amountCents: number;
    #pspReference: string;
    #paymentStatus: PaymentStatus;

    constructor(createdOn: DateTime, amountCents: number, pspReference: string, paymentStatus: PaymentStatus) {
        this.#createdOn = createdOn;
        this.#amountCents = amountCents;
        this.#pspReference = pspReference;
        this.#paymentStatus = paymentStatus;
    }
}
