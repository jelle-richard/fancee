import { Dto } from '@fancee/client';
import { OrderCostProductDiscount } from '@/dto';

@Dto
export class OrderCostDiscount {
    get productDiscounts(): OrderCostProductDiscount[] {
        return this.#productDiscounts;
    }

    set productDiscounts(value: OrderCostProductDiscount[]) {
        this.#productDiscounts = value;
    }

    get shopDiscountCents(): number {
        return this.#shopDiscountCents;
    }

    set shopDiscountCents(value: number) {
        this.#shopDiscountCents = value;
    }

    get totalDiscountCents(): number {
        return this.#totalDiscountCents;
    }

    set totalDiscountCents(value: number) {
        this.#totalDiscountCents = value;
    }

    #productDiscounts: OrderCostProductDiscount[];
    #shopDiscountCents: number;
    #totalDiscountCents: number;

    constructor(productDiscounts: OrderCostProductDiscount[], shopDiscountCents: number, totalDiscountCents: number) {
        this.#productDiscounts = productDiscounts;
        this.#shopDiscountCents = shopDiscountCents;
        this.#totalDiscountCents = totalDiscountCents;
    }
}
