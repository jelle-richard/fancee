import { Dto } from '@fancee/client';
import { Address } from '@/dto';
import { Gender } from '@/enum';

@Dto
export class ClientProductOrder {
    get address(): Address | null {
        return this.#address;
    }

    set address(value: Address | null) {
        this.#address = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    get phoneNumber(): string {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string) {
        this.#phoneNumber = value;
    }

    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get gender(): Gender | null {
        return this.#gender;
    }

    set gender(value: Gender | null) {
        this.#gender = value;
    }

    get age(): string | null {
        return this.#age;
    }

    set age(value: string | null) {
        this.#age = value;
    }

    get receiveViaSms(): boolean {
        return this.#receiveViaSms;
    }

    set receiveViaSms(value: boolean) {
        this.#receiveViaSms = value;
    }

    get optInPromotionalSms(): boolean {
        return this.#optInPromotionalSms;
    }

    set optInPromotionalSms(value: boolean) {
        this.#optInPromotionalSms = value;
    }

    get optInPromotionalEmail(): boolean {
        return this.#optInPromotionalEmail;
    }

    set optInPromotionalEmail(value: boolean) {
        this.#optInPromotionalEmail = value;
    }

    get enabledTicketServicePlus(): boolean {
        return this.#enabledTicketServicePlus;
    }

    set enabledTicketServicePlus(value: boolean) {
        this.#enabledTicketServicePlus = value;
    }

    #address: Address | null;
    #firstName: string | null;
    #lastName: string | null;
    #phoneNumber: string | null;
    #email: string;
    #gender: Gender | null;
    #age: string | null;
    #receiveViaSms: boolean;
    #optInPromotionalSms: boolean;
    #optInPromotionalEmail: boolean;
    #enabledTicketServicePlus: boolean;

    constructor(address: Address | null, firstName: string, lastName: string, phoneNumber: string, email: string, gender: Gender | null, age: string | null, receiveViaSms: boolean, optInPromotionalSms: boolean, optInPromotionalEmail: boolean, enabledTicketServicePlus: boolean) {
        this.#address = address;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#phoneNumber = phoneNumber;
        this.#email = email;
        this.#gender = gender;
        this.#age = age;
        this.#receiveViaSms = receiveViaSms;
        this.#optInPromotionalSms = optInPromotionalSms;
        this.#optInPromotionalEmail = optInPromotionalEmail;
        this.#enabledTicketServicePlus = enabledTicketServicePlus;
    }
}
