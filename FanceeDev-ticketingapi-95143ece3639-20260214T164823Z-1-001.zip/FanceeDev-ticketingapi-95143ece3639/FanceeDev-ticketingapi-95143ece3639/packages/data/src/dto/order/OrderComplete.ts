import { Dto } from '@fancee/client';

@Dto
export class OrderComplete {
    get orderId(): string {
        return this.#orderId;
    }

    set orderId(value: string) {
        this.#orderId = value;
    }

    get clientId(): string {
        return this.#clientId;
    }

    set clientId(value: string) {
        this.#clientId = value;
    }

    get redirectUrl(): string {
        return this.#redirectUrl;
    }

    set redirectUrl(value: string) {
        this.#redirectUrl = value;
    }

    #orderId: string;
    #clientId: string;
    #redirectUrl: string;

    constructor(orderId: string, clientId: string, redirectUrl: string) {
        this.#orderId = orderId;
        this.#clientId = clientId;
        this.#redirectUrl = redirectUrl;
    }
}
