import { Dto } from '@fancee/client';
import { PaymentStatus } from '@/enum';
import { Currency } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class PlatformOrderItem {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get creationDate(): DateTime {
        return this.#creationDate;
    }

    set creationDate(value: DateTime) {
        this.#creationDate = value;
    }

    get costCents(): number | null {
        return this.#costCents;
    }

    set costCents(value: number | null) {
        this.#costCents = value;
    }

    get status(): PaymentStatus {
        return this.#status;
    }

    set status(value: PaymentStatus) {
        this.#status = value;
    }

    get currency(): Currency | null {
        return this.#currency;
    }

    set currency(value: Currency | null) {
        this.#currency = value;
    }

    get pspReference(): string | null {
        return this.#pspReference;
    }

    set pspReference(value: string | null) {
        this.#pspReference = value;
    }

    #id: string;
    #eventName: string;
    #creationDate: DateTime;
    #costCents: number | null;
    #status: PaymentStatus;
    #currency: Currency | null;
    #pspReference: string | null;

    constructor(id: string, eventName: string, creationDate: DateTime, costCents: number | null, status: PaymentStatus, currency: Currency | null, pspReference: string | null) {
        this.#id = id;
        this.#eventName = eventName;
        this.#creationDate = creationDate;
        this.#costCents = costCents;
        this.#status = status;
        this.#currency = currency;
        this.#pspReference = pspReference;
    }
}
