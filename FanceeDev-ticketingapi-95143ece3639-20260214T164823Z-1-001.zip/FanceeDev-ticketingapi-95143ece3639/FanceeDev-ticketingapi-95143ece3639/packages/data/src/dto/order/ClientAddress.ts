import { Dto } from '@fancee/client';
import { CountryCode } from '@/constant';

@Dto
export class ClientAddress {
    get province(): string | null {
        return this.#province;
    }

    set province(value: string | null) {
        this.#province = value;
    }

    get street(): string | null {
        return this.#street;
    }

    set street(value: string | null) {
        this.#street = value;
    }

    get houseNumber(): string | null {
        return this.#houseNumber;
    }

    set houseNumber(value: string | null) {
        this.#houseNumber = value;
    }

    get zipcode(): string | null {
        return this.#zipcode;
    }

    set zipcode(value: string | null) {
        this.#zipcode = value;
    }

    get countryCode(): CountryCode | null {
        return this.#countryCode;
    }

    set countryCode(value: CountryCode | null) {
        this.#countryCode = value;
    }

    #province: string | null;
    #street: string | null;
    #houseNumber: string | null;
    #zipcode: string | null;
    #countryCode: CountryCode | null;

    constructor(province: string | null, street: string | null, houseNumber: string | null, zipcode: string | null, countryCode: CountryCode | null) {
        this.#province = province;
        this.#street = street;
        this.#houseNumber = houseNumber;
        this.#zipcode = zipcode;
        this.#countryCode = countryCode;
    }

    isEmpty(): boolean {
        return this.#province === null
            && this.#street === null
            && this.#houseNumber === null
            && this.#zipcode === null
            && this.#countryCode === null;
    }

    static empty(): ClientAddress {
        return new ClientAddress(null, null, null, null, null);
    }
}
