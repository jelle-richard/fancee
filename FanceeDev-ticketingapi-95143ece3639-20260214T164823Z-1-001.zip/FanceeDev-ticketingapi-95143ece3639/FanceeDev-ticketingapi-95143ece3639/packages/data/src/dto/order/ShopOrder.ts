import { Dto } from '@fancee/client';
import { OrderClient } from '@/dto';

@Dto
export class ShopOrder {
    get reservationReference(): string {
        return this.#reservationReference;
    }

    set reservationReference(value: string) {
        this.#reservationReference = value;
    }

    get orderClient(): OrderClient {
        return this.#orderClient;
    }

    set orderClient(value: OrderClient) {
        this.#orderClient = value;
    }

    get paymentMethodId(): string | null {
        return this.#paymentMethodId;
    }

    set paymentMethodId(value: string | null) {
        this.#paymentMethodId = value;
    }

    get receiveViaSms(): boolean {
        return this.#receiveViaSms;
    }

    set receiveViaSms(value: boolean) {
        this.#receiveViaSms = value;
    }

    get optInPromotionalSms(): boolean {
        return this.#optInPromotionalSms;
    }

    set optInPromotionalSms(value: boolean) {
        this.#optInPromotionalSms = value;
    }

    get optInPromotionalEmail(): boolean {
        return this.#optInPromotionalEmail;
    }

    set optInPromotionalEmail(value: boolean) {
        this.#optInPromotionalEmail = value;
    }

    get enabledTicketServicePlus(): boolean {
        return this.#enabledTicketServicePlus;
    }

    set enabledTicketServicePlus(value: boolean) {
        this.#enabledTicketServicePlus = value;
    }

    get discountCode(): string | null {
        return this.#discountCode;
    }

    set discountCode(value: string | null) {
        this.#discountCode = value;
    }

    #reservationReference: string;
    #orderClient: OrderClient;
    #paymentMethodId: string | null;
    #receiveViaSms: boolean;
    #optInPromotionalSms: boolean;
    #optInPromotionalEmail: boolean;
    #enabledTicketServicePlus: boolean;
    #discountCode: string | null;

    constructor(reservationReference: string, orderClient: OrderClient, paymentMethodId: string | null, receiveViaSms: boolean, optInPromotionalSms: boolean, optInPromotionalEmail: boolean, enabledTicketServicePlus: boolean, discountCode: string | null) {
        this.#reservationReference = reservationReference;
        this.#orderClient = orderClient;
        this.#paymentMethodId = paymentMethodId;
        this.#receiveViaSms = receiveViaSms;
        this.#optInPromotionalSms = optInPromotionalSms;
        this.#optInPromotionalEmail = optInPromotionalEmail;
        this.#enabledTicketServicePlus = enabledTicketServicePlus;
        this.#discountCode = discountCode;
    }

    public static default(reservationReference: string): ShopOrder {
        return new ShopOrder(reservationReference, OrderClient.default(), null, false, false, false, false, null);
    }
}
