import { Dto } from '@fancee/client';
import { Filter } from '@/dto';
import { DateTime } from 'luxon';
import { EventStatus, PaymentStatus } from '@/enum';

@Dto
export class OrdersFilter extends Filter<OrdersFilter> {
    get dateSpan(): [DateTime, DateTime] | null {
        return this.#dateSpan;
    }

    set dateSpan(value: [DateTime, DateTime] | null) {
        this.#dateSpan = value;
    }

    get costCentsRange(): [number, number] | null {
        return this.#costCentsRange;
    }

    set costCentsRange(value: [number, number] | null) {
        this.#costCentsRange = value;
    }

    get states(): EventStatus[] | null {
        return this.#states;
    }

    set states(value: EventStatus[] | null) {
        this.#states = value;
    }

    get paymentMethods(): string[] | null {
        return this.#paymentMethods;
    }

    set paymentMethods(value: string[] | null) {
        this.#paymentMethods = value;
    }

    get paymentStates(): PaymentStatus[] | null {
        return this.#paymentStates;
    }

    set paymentStates(value: PaymentStatus[] | null) {
        this.#paymentStates = value;
    }

    get optInSms(): boolean | null {
        return this.#optInSms;
    }

    set optInSms(value: boolean | null) {
        this.#optInSms = value;
    }

    get optInEmail(): boolean | null {
        return this.#optInEmail;
    }

    set optInEmail(value: boolean | null) {
        this.#optInEmail = value;
    }

    get receiveViaSms(): boolean | null {
        return this.#receiveViaSms;
    }

    set receiveViaSms(value: boolean | null) {
        this.#receiveViaSms = value;
    }

    get eventIds(): string[] | null {
        return this.#eventIds;
    }

    set eventIds(value: string[] | null) {
        this.#eventIds = value;
    }

    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    #dateSpan: [DateTime, DateTime] | null;
    #costCentsRange: [number, number] | null;
    #states: EventStatus[] | null;
    #paymentMethods: string[] | null;
    #paymentStates: PaymentStatus[] | null;
    #optInSms: boolean | null;
    #optInEmail: boolean | null;
    #receiveViaSms: boolean | null;
    #eventIds: string[] | null;
    #searchQuery: string;

    constructor(dateSpan: [DateTime, DateTime] | null, costCentsRange: [number, number] | null, states: EventStatus[] | null, paymentMethods: string[] | null, paymentStates: PaymentStatus[] | null, optInSms: boolean | null, optInEmail: boolean | null, receiveViaSms: boolean | null, eventIds: string[] | null, searchQuery: string) {
        super();
        this.#dateSpan = dateSpan;
        this.#costCentsRange = costCentsRange;
        this.#states = states;
        this.#paymentMethods = paymentMethods;
        this.#paymentStates = paymentStates;
        this.#optInSms = optInSms;
        this.#optInEmail = optInEmail;
        this.#receiveViaSms = receiveViaSms;
        this.#eventIds = eventIds;
        this.#searchQuery = searchQuery;
    }

    public static default(): OrdersFilter {
        return new OrdersFilter(
            [DateTime.now().plus({weeks: -52}), DateTime.now()],
            null,
            [],
            [],
            [],
            null,
            null,
            null,
            [],
            ''
        );
    }
}
