import { Dto } from '@fancee/client';

@Dto
export class RefundableProduct {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get quantity(): number {
        return this.#quantity;
    }

    set quantity(value: number) {
        this.#quantity = value;
    }

    #id: string;
    #quantity: number;

    constructor(id: string, quantity: number) {
        this.#id = id;
        this.#quantity = quantity;
    }
}
