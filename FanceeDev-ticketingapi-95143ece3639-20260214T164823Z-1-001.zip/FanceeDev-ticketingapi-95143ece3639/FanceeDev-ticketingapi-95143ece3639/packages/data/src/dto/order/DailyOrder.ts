import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class DailyOrder {
    get date(): DateTime {
        return this.#date;
    }

    set date(value: DateTime) {
        this.#date = value;
    }

    get totalOrders(): number {
        return this.#totalOrders;
    }

    set totalOrders(value: number) {
        this.#totalOrders = value;
    }

    get totalProductsSold(): number {
        return this.#totalProductsSold;
    }

    set totalProductsSold(value: number) {
        this.#totalProductsSold = value;
    }

    get cashSalesRevenueCents(): number {
        return this.#cashSalesRevenueCents;
    }

    set cashSalesRevenueCents(value: number) {
        this.#cashSalesRevenueCents = value;
    }

    get onlineSalesRevenueCents(): number {
        return this.#onlineSalesRevenueCents;
    }

    set onlineSalesRevenueCents(value: number) {
        this.#onlineSalesRevenueCents = value;
    }

    #date: DateTime;
    #totalOrders: number;
    #totalProductsSold: number;
    #cashSalesRevenueCents: number;
    #onlineSalesRevenueCents: number;

    constructor(date: DateTime, totalOrders: number, totalProductsSold: number, cashSalesRevenueCents: number, onlineSalesRevenueCents: number) {
        this.#date = date;
        this.#totalOrders = totalOrders;
        this.#totalProductsSold = totalProductsSold;
        this.#cashSalesRevenueCents = cashSalesRevenueCents;
        this.#onlineSalesRevenueCents = onlineSalesRevenueCents;
    }
}
