import { Dto } from '@fancee/client';

@Dto
export class OrderCostProductDiscount {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get discountCents(): number {
        return this.#discountCents;
    }

    set discountCents(value: number) {
        this.#discountCents = value;
    }

    get discountCentsTotal(): number {
        return this.#discountCentsTotal;
    }

    set discountCentsTotal(value: number) {
        this.#discountCentsTotal = value;
    }

    get discountedPriceCents(): number {
        return this.#discountedPriceCents;
    }

    set discountedPriceCents(value: number) {
        this.#discountedPriceCents = value;
    }

    get discountedPriceCentsTotal(): number {
        return this.#discountedPriceCentsTotal;
    }

    set discountedPriceCentsTotal(value: number) {
        this.#discountedPriceCentsTotal = value;
    }

    get quantity(): number {
        return this.#quantity;
    }

    set quantity(value: number) {
        this.#quantity = value;
    }

    #id: string;
    #discountCents: number;
    #discountCentsTotal: number;
    #discountedPriceCents: number;
    #discountedPriceCentsTotal: number;
    #quantity: number;

    constructor(id: string, discountCents: number, discountCentsTotal: number, discountedPriceCents: number, discountedPriceCentsTotal: number, quantity: number) {
        this.#id = id;
        this.#discountCentsTotal = discountCentsTotal;
        this.#discountCents = discountCents;
        this.#discountedPriceCents = discountedPriceCents;
        this.#discountedPriceCentsTotal = discountedPriceCentsTotal;
        this.#quantity = quantity;
    }
}
