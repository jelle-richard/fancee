import { Dto } from '@fancee/client';
import { OrderedTicket } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class TicketOrder {
    get orderId(): string {
        return this.#orderId;
    }

    set orderId(value: string) {
        this.#orderId = value;
    }

    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get eventStartDate(): DateTime {
        return this.#eventStartDate;
    }

    set eventStartDate(value: DateTime) {
        this.#eventStartDate = value;
    }

    get tickets(): OrderedTicket[] {
        return this.#tickets;
    }

    set tickets(value: OrderedTicket[]) {
        this.#tickets = value;
    }

    #orderId: string;
    #eventName: string;
    #eventStartDate: DateTime;
    #tickets: OrderedTicket[];

    constructor(orderId: string, eventName: string, eventStartDate: DateTime, tickets: OrderedTicket[]) {
        this.#orderId = orderId;
        this.#eventName = eventName;
        this.#eventStartDate = eventStartDate;
        this.#tickets = tickets;
    }
}
