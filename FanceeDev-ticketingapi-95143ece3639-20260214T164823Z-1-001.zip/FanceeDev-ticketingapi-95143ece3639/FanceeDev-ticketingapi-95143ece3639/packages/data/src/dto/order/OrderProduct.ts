import { Dto } from '@fancee/client';
import { IssuedOrderTicket, Media } from '@/dto';
import { ProductType } from '@/enum';

@Dto
export class OrderProduct {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get priceCents(): number | null {
        return this.#priceCents;
    }

    set priceCents(value: number | null) {
        this.#priceCents = value;
    }

    get feeCents(): number | null {
        return this.#feeCents;
    }

    set feeCents(value: number | null) {
        this.#feeCents = value;
    }

    get media(): Media[] {
        return this.#media;
    }

    set media(value: Media[]) {
        this.#media = value;
    }

    get type(): ProductType {
        return this.#type;
    }

    set type(value: ProductType) {
        this.#type = value;
    }

    get issuedTickets(): IssuedOrderTicket[] {
        return this.#issuedTickets;
    }

    set issuedTickets(value: IssuedOrderTicket[]) {
        this.#issuedTickets = value;
    }

    get quantity(): number {
        return this.#quantity;
    }

    set quantity(value: number) {
        this.#quantity = value;
    }

    #id: string;
    #name: string;
    #priceCents: number | null;
    #feeCents: number | null;
    #media: Media[];
    #type: ProductType;
    #issuedTickets: IssuedOrderTicket[];
    #quantity: number;

    constructor(id: string, name: string, priceCents: number | null, feeCents: number | null, media: Media[], type: ProductType, issuedTickets: IssuedOrderTicket[], quantity: number) {
        this.#id = id;
        this.#name = name;
        this.#priceCents = priceCents;
        this.#feeCents = feeCents;
        this.#media = media;
        this.#type = type;
        this.#issuedTickets = issuedTickets;
        this.#quantity = quantity;
    }
}
