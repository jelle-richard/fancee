import { Dto } from '@fancee/client';
import { PaymentMethod } from '@/dto';

@Dto
export class ClientPayment {
    get selectedMethod(): PaymentMethod | null {
        return this.#selectedMethod;
    }

    set selectedMethod(value: PaymentMethod | null) {
        this.#selectedMethod = value;
    }

    get usedDiscountCode(): string {
        return this.#usedDiscountCode;
    }

    set usedDiscountCode(value: string) {
        this.#usedDiscountCode = value;
    }

    #selectedMethod: PaymentMethod | null;
    #usedDiscountCode: string;

    constructor(selectedMethod: PaymentMethod | null, usedDiscountCode: string) {
        this.#selectedMethod = selectedMethod;
        this.#usedDiscountCode = usedDiscountCode;
    }

    public static empty(): ClientPayment {
        return new ClientPayment(null, '');
    }
}
