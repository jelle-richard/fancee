import { Dto } from '@fancee/client';
import { OrderEventOrganization } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class OrderEvent {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    set startDate(value: DateTime) {
        this.#startDate = value;
    }

    get organization(): OrderEventOrganization {
        return this.#organization;
    }

    set organization(value: OrderEventOrganization) {
        this.#organization = value;
    }

    #name: string;
    #startDate: DateTime;
    #organization: OrderEventOrganization;

    constructor(name: string, startDate: DateTime, organization: OrderEventOrganization) {
        this.#name = name;
        this.#startDate = startDate;
        this.#organization = organization;
    }
}
