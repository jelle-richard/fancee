import { Dto } from '@fancee/client';

@Dto
export class OrderEventOrganization {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    #name: string;
    #ticketFeeCents: number;
    #productFeeCents: number;

    constructor(name: string, ticketFeeCents: number, productFeeCents: number) {
        this.#name = name;
        this.#ticketFeeCents = ticketFeeCents;
        this.#productFeeCents = productFeeCents;
    }
}
