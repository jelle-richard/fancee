import { Dto } from '@fancee/client';
import { Address } from '@/dto';
import { Gender } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class ClientOrder {
    get address(): Address | null {
        return this.#address;
    }

    set address(value: Address | null) {
        this.#address = value;
    }

    get firstName(): string | null {
        return this.#firstName;
    }

    set firstName(value: string | null) {
        this.#firstName = value;
    }

    get lastName(): string | null {
        return this.#lastName;
    }

    set lastName(value: string | null) {
        this.#lastName = value;
    }

    get phoneNumber(): string | null {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string | null) {
        this.#phoneNumber = value;
    }

    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get gender(): Gender | null {
        return this.#gender;
    }

    set gender(value: Gender | null) {
        this.#gender = value;
    }

    get birthdate(): DateTime | null {
        return this.#birthdate;
    }

    set birthdate(value: DateTime | null) {
        this.#birthdate = value;
    }

    get receiveViaSmsCostCents(): number {
        return this.#receiveViaSmsCostCents;
    }

    set receiveViaSmsCostCents(value: number) {
        this.#receiveViaSmsCostCents = value;
    }

    get ticketServicePlusCostCents(): number {
        return this.#ticketServicePlusCostCents;
    }

    set ticketServicePlusCostCents(value: number) {
        this.#ticketServicePlusCostCents = value;
    }

    get optInPromotionalEmail(): boolean {
        return this.#optInPromotionalEmail;
    }

    set optInPromotionalEmail(value: boolean) {
        this.#optInPromotionalEmail = value;
    }

    get optInPromotionalSms(): boolean {
        return this.#optInPromotionalSms;
    }

    set optInPromotionalSms(value: boolean) {
        this.#optInPromotionalSms = value;
    }

    #address: Address | null;
    #firstName: string | null;
    #lastName: string | null;
    #phoneNumber: string | null;
    #email: string;
    #gender: Gender | null;
    #birthdate: DateTime | null;
    #receiveViaSmsCostCents: number;
    #ticketServicePlusCostCents: number;
    #optInPromotionalEmail: boolean;
    #optInPromotionalSms: boolean;

    constructor(address: Address | null, firstName: string | null, lastName: string | null, phoneNumber: string | null, email: string, gender: Gender | null, birthdate: DateTime | null, receiveViaSmsCostCents: number, ticketServicePlusCostCents: number, optInPromotionalEmail: boolean, optInPromotionalSms: boolean) {
        this.#address = address;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#phoneNumber = phoneNumber;
        this.#email = email;
        this.#gender = gender;
        this.#birthdate = birthdate;
        this.#receiveViaSmsCostCents = receiveViaSmsCostCents;
        this.#ticketServicePlusCostCents = ticketServicePlusCostCents;
        this.#optInPromotionalEmail = optInPromotionalEmail;
        this.#optInPromotionalSms = optInPromotionalSms;
    }
}
