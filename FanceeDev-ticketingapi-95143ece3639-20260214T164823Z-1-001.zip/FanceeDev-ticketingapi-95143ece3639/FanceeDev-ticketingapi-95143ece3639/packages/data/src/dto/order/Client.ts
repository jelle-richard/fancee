import { Dto } from '@fancee/client';
import { ClientAddress, ClientOptions, ClientPayment } from '@/dto';
import { Gender } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class Client {
    get firstname(): string {
        return this.#firstname;
    }

    set firstname(value: string) {
        this.#firstname = value;
    }

    get lastname(): string {
        return this.#lastname;
    }

    set lastname(value: string) {
        this.#lastname = value;
    }

    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get phoneNumber(): string {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string) {
        this.#phoneNumber = value;
    }

    get gender(): Gender | null {
        return this.#gender;
    }

    set gender(value: Gender | null) {
        this.#gender = value;
    }

    get birthdate(): DateTime | null {
        return this.#birthdate;
    }

    set birthdate(value: DateTime | null) {
        this.#birthdate = value;
    }

    get address(): ClientAddress {
        return this.#address;
    }

    set address(value: ClientAddress) {
        this.#address = value;
    }

    get options(): ClientOptions {
        return this.#options;
    }

    set options(value: ClientOptions) {
        this.#options = value;
    }

    get payment(): ClientPayment {
        return this.#payment;
    }

    set payment(value: ClientPayment) {
        this.#payment = value;
    }

    #firstname: string;
    #lastname: string;
    #email: string;
    #phoneNumber: string;
    #gender: Gender | null;
    #birthdate: DateTime | null;
    #address: ClientAddress;
    #options: ClientOptions;
    #payment: ClientPayment;

    constructor(firstname: string, lastname: string, email: string, phoneNumber: string, gender: Gender | null, birthdate: DateTime | null, address: ClientAddress, options: ClientOptions, payment: ClientPayment) {
        this.#firstname = firstname;
        this.#lastname = lastname;
        this.#email = email;
        this.#phoneNumber = phoneNumber;
        this.#gender = gender;
        this.#birthdate = birthdate;
        this.#address = address;
        this.#options = options;
        this.#payment = payment;
    }

    public static empty(): Client {
        return new Client(null, null, '', null, null, null, ClientAddress.empty(), ClientOptions.empty(), ClientPayment.empty());
    }
}
