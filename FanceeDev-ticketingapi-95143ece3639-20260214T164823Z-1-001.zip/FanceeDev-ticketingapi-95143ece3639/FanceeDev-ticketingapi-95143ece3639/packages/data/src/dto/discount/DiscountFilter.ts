import { Dto } from '@fancee/client';
import { Filter } from '@/dto';

@Dto
export class DiscountFilter extends Filter<DiscountFilter> {
    get search(): string {
        return this.#search;
    }

    set search(value: string) {
        this.#search = value;
    }

    get shopCodes(): string[] {
        return this.#shopCodes;
    }

    set shopCodes(value: string[]) {
        this.#shopCodes = value;
    }

    get productIds(): string[] {
        return this.#productIds;
    }

    set productIds(value: string[]) {
        this.#productIds = value;
    }

    get includeExpired(): boolean {
        return this.#includeExpired;
    }

    set includeExpired(value: boolean) {
        this.#includeExpired = value;
    }

    #search: string;
    #shopCodes: string[];
    #productIds: string[];
    #includeExpired: boolean;

    constructor(search: string, shopCodes: string[], productIds: string[], includeExpired: boolean) {
        super();
        this.#search = search;
        this.#shopCodes = shopCodes;
        this.#productIds = productIds;
        this.#includeExpired = includeExpired;
    }

    public static default(): DiscountFilter {
        return new DiscountFilter('', [], [], true);
    }
}
