import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class DiscountListItem {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get stock(): number {
        return this.#stock;
    }

    set stock(value: number) {
        this.#stock = value;
    }

    get used(): number {
        return this.#used;
    }

    set used(value: number) {
        this.#used = value;
    }

    get amountPercentual(): number | null {
        return this.#amountPercentual;
    }

    set amountPercentual(value: number | null) {
        this.#amountPercentual = value;
    }

    get amountStaticCents(): number {
        return this.#amountStaticCents;
    }

    set amountStaticCents(value: number) {
        this.#amountStaticCents = value;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    set createdOn(value: DateTime) {
        this.#createdOn = value;
    }

    get expiresOn(): DateTime {
        return this.#expiresOn;
    }

    set expiresOn(value: DateTime) {
        this.#expiresOn = value;
    }

    #id: string;
    #code: string;
    #stock: number;
    #used: number;
    #amountPercentual: number | null;
    #amountStaticCents: number;
    #createdOn: DateTime;
    #expiresOn: DateTime;

    constructor(id: string, code: string, stock: number, used: number, amountPercentual: number | null, amountStaticCents: number, createdOn: DateTime, expiresOn: DateTime) {
        this.#id = id;
        this.#code = code;
        this.#stock = stock;
        this.#used = used;
        this.#amountPercentual = amountPercentual;
        this.#amountStaticCents = amountStaticCents;
        this.#createdOn = createdOn;
        this.#expiresOn = expiresOn;
    }
}
