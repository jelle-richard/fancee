import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class Discount {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get stock(): number {
        return this.#stock;
    }

    set stock(value: number) {
        this.#stock = value;
    }

    get used(): number {
        return this.#used;
    }

    set used(value: number) {
        this.#used = value;
    }

    get amountPercentual(): number | null {
        return this.#amountPercentual;
    }

    set amountPercentual(value: number | null) {
        this.#amountPercentual = value;
    }

    get amountStaticCents(): number | null {
        return this.#amountStaticCents;
    }

    set amountStaticCents(value: number | null) {
        this.#amountStaticCents = value;
    }

    get assignedShopCodes(): string[] {
        return this.#assignedShopCodes;
    }

    set assignedShopCodes(value: string[]) {
        this.#assignedShopCodes = value;
    }

    get assignedProductIds(): string[] {
        return this.#assignedProductIds;
    }

    set assignedProductIds(value: string[]) {
        this.#assignedProductIds = value;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    set createdOn(value: DateTime) {
        this.#createdOn = value;
    }

    get expiresOn(): DateTime {
        return this.#expiresOn;
    }

    set expiresOn(value: DateTime) {
        this.#expiresOn = value;
    }

    #code: string;
    #stock: number;
    #used: number;
    #amountPercentual: number | null;
    #amountStaticCents: number;
    #assignedShopCodes: string[];
    #assignedProductIds: string[];
    #createdOn: DateTime;
    #expiresOn: DateTime;

    constructor(code: string, stock: number, used: number, amountPercentual: number | null, amountStaticCents: number | null, assignedShopCodes: string[], assignedProductIds: string[], createdOn: DateTime, expiresOn: DateTime) {
        this.#code = code;
        this.#stock = stock;
        this.#used = used;
        this.#amountPercentual = amountPercentual;
        this.#amountStaticCents = amountStaticCents;
        this.#assignedShopCodes = assignedShopCodes;
        this.#assignedProductIds = assignedProductIds;
        this.#createdOn = createdOn;
        this.#expiresOn = expiresOn;
    }

    public static empty(): Discount {
        return new Discount('', 10, 0, null, 0, [], [], DateTime.now(), DateTime.now());
    }
}
