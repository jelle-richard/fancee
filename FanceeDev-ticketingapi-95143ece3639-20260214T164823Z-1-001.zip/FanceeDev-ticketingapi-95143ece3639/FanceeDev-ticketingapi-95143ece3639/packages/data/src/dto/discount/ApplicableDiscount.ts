import { Dto } from '@fancee/client';

@Dto
export class ApplicableDiscount {
    get discountCode(): string {
        return this.#discountCode;
    }

    set discountCode(value: string) {
        this.#discountCode = value;
    }

    get amountPercentual(): number {
        return this.#amountPercentual;
    }

    set amountPercentual(value: number) {
        this.#amountPercentual = value;
    }

    get amountStaticCents(): number {
        return this.#amountStaticCents;
    }

    set amountStaticCents(value: number) {
        this.#amountStaticCents = value;
    }

    get isApplicableToShop(): boolean {
        return this.#isApplicableToShop;
    }

    set isApplicableToShop(value: boolean) {
        this.#isApplicableToShop = value;
    }

    get matchingProductIds(): string[] {
        return this.#matchingProductIds;
    }

    set matchingProductIds(value: string[]) {
        this.#matchingProductIds = value;
    }

    #discountCode: string;
    #amountPercentual: number;
    #amountStaticCents: number;
    #isApplicableToShop: boolean;
    #matchingProductIds: string[];

    constructor(discountCode: string, amountPercentual: number, amountStaticCents: number, isApplicableToShop: boolean, matchingProductIds: string[]) {
        this.#discountCode = discountCode;
        this.#amountPercentual = amountPercentual;
        this.#amountStaticCents = amountStaticCents;
        this.#isApplicableToShop = isApplicableToShop;
        this.#matchingProductIds = matchingProductIds;
    }
}
