import { Dto } from '@fancee/client';
import { Media } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class OrganizationNote {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get adminEmail(): string {
        return this.#adminEmail;
    }

    set adminEmail(value: string) {
        this.#adminEmail = value;
    }

    get adminFirstName(): string {
        return this.#adminFirstName;
    }

    set adminFirstName(value: string) {
        this.#adminFirstName = value;
    }

    get adminLastName(): string {
        return this.#adminLastName;
    }

    set adminLastName(value: string) {
        this.#adminLastName = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get placedOn(): DateTime {
        return this.#placedOn;
    }

    set placedOn(value: DateTime) {
        this.#placedOn = value;
    }

    get files(): Media[] {
        return this.#files;
    }

    set files(value: Media[]) {
        this.#files = value;
    }

    #id: string;
    #adminEmail: string;
    #adminFirstName: string;
    #adminLastName: string;
    #description: string;
    #placedOn: DateTime;
    #files: Media[];

    constructor(id: string, adminEmail: string, adminFirstName: string, adminLastName: string, description: string, placedOn: DateTime, files: Media[]) {
        this.#id = id;
        this.#adminEmail = adminEmail;
        this.#adminFirstName = adminFirstName;
        this.#adminLastName = adminLastName;
        this.#description = description;
        this.#placedOn = placedOn;
        this.#files = files;
    }
}
