import { Dto } from '@fancee/client';

@Dto
export class OrganizationNoteRequest {
    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get media(): File[] {
        return this.#media;
    }

    set media(value: File[]) {
        this.#media = value;
    }

    #description: string;
    #media: File[];

    constructor(description: string, media: File[]) {
        this.#description = description;
        this.#media = media;
    }

    public static empty(): OrganizationNoteRequest {
        return new OrganizationNoteRequest('', []);
    }

    public reset(): void {
        this.description = '';
        this.media = [];
    }
}
