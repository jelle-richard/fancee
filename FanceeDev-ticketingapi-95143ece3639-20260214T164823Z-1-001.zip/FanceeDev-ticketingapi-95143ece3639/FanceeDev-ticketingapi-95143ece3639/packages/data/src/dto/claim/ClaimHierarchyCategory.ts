import { Dto } from '@fancee/client';
import { ClaimHierarchy } from '@/dto';

@Dto
export class ClaimHierarchyCategory {
    get category(): string {
        return this.#category;
    }

    set category(value: string) {
        this.#category = value;
    }

    get claims(): ClaimHierarchy[] {
        return this.#claims;
    }

    set claims(value: ClaimHierarchy[]) {
        this.#claims = value;
    }

    #category: string;
    #claims: ClaimHierarchy[];

    constructor(category: string, claims: ClaimHierarchy[]) {
        this.#category = category;
        this.#claims = claims;
    }
}
