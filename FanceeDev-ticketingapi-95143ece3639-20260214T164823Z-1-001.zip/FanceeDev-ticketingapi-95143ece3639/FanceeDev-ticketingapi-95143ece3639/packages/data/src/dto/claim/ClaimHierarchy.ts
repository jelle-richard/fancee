import { Dto } from '@fancee/client';

@Dto
export class ClaimHierarchy {
    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get claim(): string {
        return this.#claim;
    }

    set claim(value: string) {
        this.#claim = value;
    }

    get dependsOnClaim(): string | null {
        return this.#dependsOnClaim;
    }

    set dependsOnClaim(value: string | null) {
        this.#dependsOnClaim = value;
    }

    #description: string;
    #claim: string;
    #dependsOnClaim: string | null;

    constructor(description: string, claim: string, dependsOnClaim: string | null) {
        this.#description = description;
        this.#claim = claim;
        this.#dependsOnClaim = dependsOnClaim;
    }
}
