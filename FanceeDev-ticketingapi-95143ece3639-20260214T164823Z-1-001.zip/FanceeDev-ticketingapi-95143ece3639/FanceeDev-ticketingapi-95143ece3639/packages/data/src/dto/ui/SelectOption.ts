import { Dto } from '@fancee/client';

@Dto
export class SelectOption {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get label(): string {
        return this.#label;
    }

    set label(value: string) {
        this.#label = value;
    }

    get header(): string | null {
        return this.#header;
    }

    set header(value: string | null) {
        this.#header = value;
    }

    get note(): string | null {
        return this.#note;
    }

    set note(value: string | null) {
        this.#note = value;
    }

    #id: string;
    #label: string;
    #header: string | null;
    #note: string | null;

    constructor(id: string, label: string, header: string | null, note: string | null) {
        this.#id = id;
        this.#label = label;
        this.#header = header;
        this.#note = note;
    }
}
