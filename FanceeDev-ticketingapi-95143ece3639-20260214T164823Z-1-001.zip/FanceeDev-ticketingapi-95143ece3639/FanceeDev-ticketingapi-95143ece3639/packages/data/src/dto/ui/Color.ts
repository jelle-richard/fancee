import { Dto } from '@fancee/client';
import { hexToRgb, rgbToHex, rgbToHsl } from '@/util';

@Dto
export class Color {
    get [Symbol.toStringTag]() {
        return this.hex;
    }

    get alpha(): number {
        return this.#alpha;
    }

    set alpha(value: number) {
        this.#alpha = value;
    }

    get red(): number {
        return this.#red;
    }

    set red(value: number) {
        this.#red = value;
    }

    get green(): number {
        return this.#green;
    }

    set green(value: number) {
        this.#green = value;
    }

    get blue(): number {
        return this.#blue;
    }

    set blue(value: number) {
        this.#blue = value;
    }

    get hex(): string {
        return rgbToHex(this.#red, this.#green, this.#blue);
    }

    set hex(value: string) {
        [this.#red, this.#green, this.#blue] = hexToRgb(value);
    }

    get luminance(): number {
        const [r, g, b] = [this.#red, this.#green, this.#blue].map(x => {
            x /= 255;

            if (x < .03928) {
                x = x / 12.92;
            } else {
                x = Math.pow((x + .055) / 1.055, 2.4);
            }

            return x;
        });

        return r * .2126 + g * .7152 + b * .0722;
    }

    get hsl(): [number, number, number] {
        return rgbToHsl(this.#red, this.#green, this.#blue);
    }

    get yiq(): number {
        return (this.#red * 299 + this.#green * 587 + this.#blue * 114) / 1000;
    }

    get r(): number {
        return this.#red;
    }

    get g(): number {
        return this.#green;
    }

    get b(): number {
        return this.#blue;
    }

    #alpha: number;
    #red: number;
    #green: number;
    #blue: number;

    constructor(red: number, green: number, blue: number, alpha: number = 1) {
        this.#red = red;
        this.#green = green;
        this.#blue = blue;
        this.#alpha = alpha;
    }

    public blend(other: Color, weight: number = 0): Color {
        weight = Math.max(0, Math.min(100, weight));

        const percentage = weight / 100;
        const scaledWeight = percentage * 2 - 1;
        const alphaDiff = this.#alpha - other.#alpha;

        const weight1 = ((scaledWeight * alphaDiff === -1 ? scaledWeight : (scaledWeight + alphaDiff) / (1 + scaledWeight * alphaDiff)) + 1) / 2;
        const weight2 = 1 - weight;

        return new Color(
            Math.round(this.#red * weight1 + other.#red * weight2),
            Math.round(this.#green * weight1 + other.#green * weight2),
            Math.round(this.#blue * weight1 + other.#blue * weight2),
            this.#alpha
        );
    }

    public shade(weight: number): Color {
        return this.blend(new Color(0, 0, 0), weight);
    }

    public tint(weight: number): Color {
        return this.blend(new Color(255, 255, 255), weight);
    }

    public static fromHex(hex: string): Color {
        const [red, green, blue] = hexToRgb(hex);

        return new Color(red, green, blue);
    }

    public static fromRgb(red: number, green: number, blue: number): Color {
        return new Color(red, green, blue);
    }

    public static fromRgba(red: number, green: number, blue: number, alpha: number): Color {
        return new Color(red, green, blue, alpha);
    }
}
