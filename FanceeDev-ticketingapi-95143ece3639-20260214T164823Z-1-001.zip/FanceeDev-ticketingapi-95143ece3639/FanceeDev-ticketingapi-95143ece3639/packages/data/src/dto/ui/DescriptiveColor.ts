import { Dto } from '@fancee/client';
import { Color } from '@/dto';
import { UIColor } from '@/enum';

type _ForeignColorObject = {
    readonly rgba: {
        readonly r: number;
        readonly g: number;
        readonly b: number;
        readonly a: number;
    };
};

@Dto
export class DescriptiveColor {
    get name(): UIColor {
        return this.#name;
    }

    set name(value: UIColor) {
        this.#name = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get color(): Color {
        return this.#color;
    }

    set color(value: Color | _ForeignColorObject | string) {
        if (typeof value === 'string') {
            this.#color = Color.fromHex(value);
        } else if (value instanceof Color) {
            this.#color.red = value.red;
            this.#color.green = value.green;
            this.#color.blue = value.blue;
        } else {
            this.#color.red = value.rgba.r;
            this.#color.green = value.rgba.g;
            this.#color.blue = value.rgba.b;
        }
    }

    #color: Color;
    #name: UIColor;
    #description: string;

    constructor(color: Color, name: UIColor, description: string) {
        this.#color = color;
        this.#name = name;
        this.#description = description;
    }
}
