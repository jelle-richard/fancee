import { Dto } from '@fancee/client';
import { ClientProductOrder, TicketHolder } from '@/dto';
import { ProductOrigin, ScanState, TicketState } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class TicketInformation {
    get shopName(): string | null {
        return this.#shopName;
    }

    set shopName(value: string | null) {
        this.#shopName = value;
    }

    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get eventStartDate(): DateTime {
        return this.#eventStartDate;
    }

    set eventStartDate(value: DateTime) {
        this.#eventStartDate = value;
    }

    get ticketName(): string {
        return this.#ticketName;
    }

    set ticketName(value: string) {
        this.#ticketName = value;
    }

    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get label(): string {
        return this.#label;
    }

    set label(value: string) {
        this.#label = value;
    }

    get scanState(): ScanState | null {
        return this.#scanState;
    }

    set scanState(value: ScanState | null) {
        this.#scanState = value;
    }

    get scanTime(): DateTime | null {
        return this.#scanTime;
    }

    set scanTime(value: DateTime | null) {
        this.#scanTime = value;
    }

    get origin(): ProductOrigin {
        return this.#origin;
    }

    set origin(value: ProductOrigin) {
        this.#origin = value;
    }

    get holder(): TicketHolder | null {
        return this.#holder;
    }

    set holder(value: TicketHolder | null) {
        this.#holder = value;
    }

    get client(): ClientProductOrder | null {
        return this.#client;
    }

    set client(value: ClientProductOrder | null) {
        this.#client = value;
    }

    get orderId(): string | null {
        return this.#orderId;
    }

    set orderId(value: string | null) {
        this.#orderId = value;
    }

    get ticketState(): TicketState {
        return this.#ticketState;
    }

    set ticketState(value: TicketState) {
        this.#ticketState = value;
    }

    #shopName: string | null;
    #eventName: string;
    #eventStartDate: DateTime;
    #ticketName: string;
    #code: string;
    #label: string;
    #scanState: ScanState | null;
    #scanTime: DateTime | null;
    #origin: ProductOrigin;
    #holder: TicketHolder | null;
    #client: ClientProductOrder | null;
    #orderId: string | null;
    #ticketState: TicketState;

    constructor(shopName: string | null, eventName: string, eventStartDate: DateTime, ticketName: string, code: string, label: string, scanState: ScanState | null, scanTime: DateTime | null, origin: ProductOrigin, holder: TicketHolder | null, client: ClientProductOrder | null, orderId: string | null, ticketState: TicketState) {
        this.#shopName = shopName;
        this.#eventName = eventName;
        this.#eventStartDate = eventStartDate;
        this.#ticketName = ticketName;
        this.#code = code;
        this.#label = label;
        this.#scanState = scanState;
        this.#scanTime = scanTime;
        this.#origin = origin;
        this.#holder = holder;
        this.#client = client;
        this.#orderId = orderId;
        this.#ticketState = ticketState;
    }
}
