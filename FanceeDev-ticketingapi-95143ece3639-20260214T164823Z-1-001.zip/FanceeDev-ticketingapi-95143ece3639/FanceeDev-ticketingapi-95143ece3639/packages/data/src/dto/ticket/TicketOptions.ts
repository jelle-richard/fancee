import { Dto } from '@fancee/client';
import { DateTimeSpan } from '@/dto';

@Dto
export class TicketOptions {
    get isUsableForGuestList(): boolean {
        return this.#isUsableForGuestList;
    }

    set isUsableForGuestList(value: boolean) {
        this.#isUsableForGuestList = value;
    }

    get swappable(): boolean {
        return this.#swappable;
    }

    set swappable(value: boolean) {
        this.#swappable = value;
    }

    get partialAccess(): DateTimeSpan {
        return this.#partialAccess;
    }

    set partialAccess(value: DateTimeSpan) {
        this.#partialAccess = value;
    }

    get scanNotification(): string | null {
        return this.#scanNotification;
    }

    set scanNotification(value: string | null) {
        this.#scanNotification = value;
    }

    get maximumPreArrivalMinutes(): number {
        return this.#maximumPreArrivalMinutes;
    }

    set maximumPreArrivalMinutes(value: number) {
        this.#maximumPreArrivalMinutes = value;
    }

    #isUsableForGuestList: boolean;
    #swappable: boolean;
    #partialAccess: DateTimeSpan;
    #scanNotification: string | null;
    #maximumPreArrivalMinutes: number;

    constructor(isUsableForGuestList: boolean, swappable: boolean, partialAccess: DateTimeSpan, scanNotification: string | null, maximumPreArrivalMinutes: number) {
        this.#isUsableForGuestList = isUsableForGuestList;
        this.#swappable = swappable;
        this.#partialAccess = partialAccess;
        this.#scanNotification = scanNotification;
        this.#maximumPreArrivalMinutes = maximumPreArrivalMinutes;
    }

    public static default(): TicketOptions {
        return new TicketOptions(false, true, DateTimeSpan.default(), null, 60);
    }
}
