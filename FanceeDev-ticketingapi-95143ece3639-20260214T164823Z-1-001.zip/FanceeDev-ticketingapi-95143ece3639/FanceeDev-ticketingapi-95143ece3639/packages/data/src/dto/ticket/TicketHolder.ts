import { Dto } from '@fancee/client';
import { Gender } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class TicketHolder {
    get firstname(): string | null {
        return this.#firstname;
    }

    set firstname(value: string | null) {
        this.#firstname = value;
    }

    get lastname(): string | null {
        return this.#lastname;
    }

    set lastname(value: string | null) {
        this.#lastname = value;
    }

    get email(): string | null {
        return this.#email;
    }

    set email(value: string | null) {
        this.#email = value;
    }

    get gender(): Gender | null {
        return this.#gender;
    }

    set gender(value: Gender | null) {
        this.#gender = value;
    }

    get phoneNumber(): string | null {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string | null) {
        this.#phoneNumber = value;
    }

    get birthdate(): DateTime | null {
        return this.#birthdate;
    }

    set birthdate(value: DateTime | null) {
        this.#birthdate = value;
    }

    get personalizedOn(): DateTime | null {
        return this.#personalizedOn;
    }

    set personalizedOn(value: DateTime | null) {
        this.#personalizedOn = value;
    }

    #firstname: string | null;
    #lastname: string | null;
    #email: string | null;
    #gender: Gender | null;
    #phoneNumber: string | null;
    #birthdate: DateTime | null;
    #personalizedOn: DateTime | null;

    constructor(firstname: string | null, lastname: string | null, email: string | null, gender: Gender | null, phoneNumber: string | null, birthdate: DateTime | null, personalizedOn: DateTime | null) {
        this.#firstname = firstname;
        this.#lastname = lastname;
        this.#email = email;
        this.#gender = gender;
        this.#phoneNumber = phoneNumber;
        this.#birthdate = birthdate;
        this.#personalizedOn = personalizedOn;
    }
}
