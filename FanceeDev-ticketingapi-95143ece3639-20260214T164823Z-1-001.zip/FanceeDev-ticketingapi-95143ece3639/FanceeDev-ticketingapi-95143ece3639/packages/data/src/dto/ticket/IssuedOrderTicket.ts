import { Dto } from '@fancee/client';
import { TicketHolder } from '@/dto';

@Dto
export class IssuedOrderTicket {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get holder(): TicketHolder {
        return this.#holder;
    }

    set holder(value: TicketHolder) {
        this.#holder = value;
    }

    #code: string;
    #holder: TicketHolder;

    constructor(code: string, holder: TicketHolder) {
        this.#code = code;
        this.#holder = holder;
    }
}
