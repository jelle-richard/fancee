import { Dto } from '@fancee/client';
import { ProductOrigin, ScanState, TicketState } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class TicketListing {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get label(): string {
        return this.#label;
    }

    set label(value: string) {
        this.#label = value;
    }

    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get origin(): ProductOrigin {
        return this.#origin;
    }

    set origin(value: ProductOrigin) {
        this.#origin = value;
    }

    get scanTime(): DateTime | null {
        return this.#scanTime;
    }

    set scanTime(value: DateTime | null) {
        this.#scanTime = value;
    }

    get scanState(): ScanState | null {
        return this.#scanState;
    }

    set scanState(value: ScanState | null) {
        this.#scanState = value;
    }

    get shopName(): string {
        return this.#shopName;
    }

    set shopName(value: string) {
        this.#shopName = value;
    }

    get productName(): string {
        return this.#productName;
    }

    set productName(value: string) {
        this.#productName = value;
    }

    get email(): string | null {
        return this.#email;
    }

    set email(value: string | null) {
        this.#email = value;
    }

    get name(): string | null {
        return this.#name;
    }

    set name(value: string | null) {
        this.#name = value;
    }

    get ticketState(): TicketState {
        return this.#ticketState;
    }

    set ticketState(value: TicketState) {
        this.#ticketState = value;
    }

    #code: string;
    #label: string;
    #eventName: string;
    #origin: ProductOrigin;
    #scanTime: DateTime | null;
    #scanState: ScanState | null;
    #shopName: string;
    #productName: string;
    #email: string | null;
    #name: string | null;
    #ticketState: TicketState;

    constructor(code: string, label: string, eventName: string, origin: ProductOrigin, scanTime: DateTime | null, scanState: ScanState | null, shopName: string, productName: string, email: string | null, name: string | null, ticketState: TicketState) {
        this.#code = code;
        this.#label = label;
        this.#eventName = eventName;
        this.#origin = origin;
        this.#scanTime = scanTime;
        this.#scanState = scanState;
        this.#shopName = shopName;
        this.#productName = productName;
        this.#email = email;
        this.#name = name;
        this.#ticketState = ticketState;
    }
}
