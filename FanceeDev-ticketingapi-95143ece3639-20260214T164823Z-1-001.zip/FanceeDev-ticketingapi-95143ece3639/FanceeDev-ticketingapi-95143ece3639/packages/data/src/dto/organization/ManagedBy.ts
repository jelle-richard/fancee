import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class ManagedBy {
    get id(): string {
        return this.#id;
    }

    get email(): string {
        return this.#email;
    }

    get firstName(): string {
        return this.#firstName;
    }

    get lastName(): string {
        return this.#lastName;
    }

    get avatar(): Media | null {
        return this.#avatar;
    }

    readonly #id: string;
    readonly #email: string;
    readonly #firstName: string;
    readonly #lastName: string;
    readonly #avatar: Media | null;

    constructor(id: string, email: string, firstName: string, lastName: string, avatar: Media | null) {
        this.#id = id;
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#avatar = avatar;
    }
}
