import { Dto } from '@fancee/client';

@Dto
export class OrganizationHolder {
    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    #email: string;
    #firstName: string;
    #lastName: string;

    constructor(email: string, firstName: string, lastName: string) {
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
    }

    public static empty(): OrganizationHolder {
        return new OrganizationHolder('', '', '');
    }
}
