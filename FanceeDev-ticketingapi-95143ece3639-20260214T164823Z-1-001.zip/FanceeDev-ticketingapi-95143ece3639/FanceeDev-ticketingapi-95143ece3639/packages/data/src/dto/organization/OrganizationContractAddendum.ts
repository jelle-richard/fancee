import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class OrganizationContractAddendum {
    get content(): string {
        return this.#content;
    }

    set content(value: string) {
        this.#content = value;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    set startDate(value: DateTime) {
        this.#startDate = value;
    }

    get endDate(): DateTime {
        return this.#endDate;
    }

    set endDate(value: DateTime) {
        this.#endDate = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    get ticketFeePercentage(): number {
        return this.#ticketFeePercentage;
    }

    set ticketFeePercentage(value: number) {
        this.#ticketFeePercentage = value;
    }

    get seatedTicketFeeCents(): number {
        return this.#seatedTicketFeeCents;
    }

    set seatedTicketFeeCents(value: number) {
        this.#seatedTicketFeeCents = value;
    }

    get seatedTicketFeePercentage(): number {
        return this.#seatedTicketFeePercentage;
    }

    set seatedTicketFeePercentage(value: number) {
        this.#seatedTicketFeePercentage = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    get productFeePercentage(): number {
        return this.#productFeePercentage;
    }

    set productFeePercentage(value: number) {
        this.#productFeePercentage = value;
    }

    get guestListFeeCents(): number {
        return this.#guestListFeeCents;
    }

    set guestListFeeCents(value: number) {
        this.#guestListFeeCents = value;
    }

    #content: string;
    #startDate: DateTime;
    #endDate: DateTime;
    #ticketFeeCents: number;
    #ticketFeePercentage: number;
    #seatedTicketFeeCents: number;
    #seatedTicketFeePercentage: number;
    #productFeeCents: number;
    #productFeePercentage: number;
    #guestListFeeCents: number;

    constructor(content: string, startDate: DateTime, endDate: DateTime, ticketFeeCents: number, ticketFeePercentage: number, seatedTicketFeeCents: number, seatedTicketFeePercentage: number, productFeeCents: number, productFeePercentage: number, guestListFeeCents: number) {
        this.#content = content;
        this.#startDate = startDate;
        this.#endDate = endDate;
        this.#ticketFeeCents = ticketFeeCents;
        this.#ticketFeePercentage = ticketFeePercentage;
        this.#seatedTicketFeeCents = seatedTicketFeeCents;
        this.#seatedTicketFeePercentage = seatedTicketFeePercentage;
        this.#productFeeCents = productFeeCents;
        this.#productFeePercentage = productFeePercentage;
        this.#guestListFeeCents = guestListFeeCents;
    }
}
