import { Dto } from '@fancee/client';
import { ContactType } from '@/enum';

@Dto
export class OrganizationContact {
    get id(): string | null {
        return this.#id;
    }

    set id(value: string | null) {
        this.#id = value;
    }

    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    get phoneNumber(): string {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string) {
        this.#phoneNumber = value;
    }

    get contactRoleType(): ContactType {
        return this.#contactRoleType;
    }

    set contactRoleType(value: ContactType) {
        this.#contactRoleType = value;
    }

    #id: string | null;
    #email: string;
    #firstName: string;
    #lastName: string;
    #phoneNumber: string;
    #contactRoleType: ContactType;

    constructor(id: string | null, email: string, firstName: string, lastName: string, phoneNumber: string, contactRoleType: ContactType) {
        this.#id = id;
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#phoneNumber = phoneNumber;
        this.#contactRoleType = contactRoleType;
    }

    public static empty(): OrganizationContact {
        return new OrganizationContact(null, '', '', '', '', ContactType.CustomerSupport);
    }
}
