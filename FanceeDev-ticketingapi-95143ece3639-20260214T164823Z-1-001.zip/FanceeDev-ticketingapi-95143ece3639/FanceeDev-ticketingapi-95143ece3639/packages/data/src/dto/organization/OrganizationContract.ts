import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class OrganizationContract {
    get start(): DateTime {
        return this.#start;
    }

    set start(value: DateTime) {
        this.#start = value;
    }

    get end(): DateTime {
        return this.#end;
    }

    set end(value: DateTime) {
        this.#end = value;
    }

    get packageType(): string {
        return this.#packageType;
    }

    set packageType(value: string) {
        this.#packageType = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    get productFeePercentage(): number {
        return this.#productFeePercentage;
    }

    set productFeePercentage(value: number) {
        this.#productFeePercentage = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    get ticketFeePercentage(): number {
        return this.#ticketFeePercentage;
    }

    set ticketFeePercentage(value: number) {
        this.#ticketFeePercentage = value;
    }

    get seatedTicketFeeCents(): number {
        return this.#seatedTicketFeeCents;
    }

    set seatedTicketFeeCents(value: number) {
        this.#seatedTicketFeeCents = value;
    }

    get seatedTicketFeePercentage(): number {
        return this.#seatedTicketFeePercentage;
    }

    set seatedTicketFeePercentage(value: number) {
        this.#seatedTicketFeePercentage = value;
    }

    get guestListFeeCents(): number {
        return this.#guestListFeeCents;
    }

    set guestListFeeCents(value: number) {
        this.#guestListFeeCents = value;
    }

    get signed(): boolean {
        return this.#signed;
    }

    set signed(value: boolean) {
        this.#signed = value;
    }

    get timezone(): string {
        return this.#timezone;
    }

    set timezone(value: string) {
        this.#timezone = value;
    }

    #start: DateTime;
    #end: DateTime;
    #packageType: string;
    #productFeeCents: number;
    #productFeePercentage: number;
    #ticketFeeCents: number;
    #ticketFeePercentage: number;
    #seatedTicketFeeCents: number;
    #seatedTicketFeePercentage: number;
    #guestListFeeCents: number;
    #signed: boolean;
    #timezone: string;

    constructor(start: DateTime, end: DateTime, packageType: string, productFeeCents: number, productFeePercentage: number, ticketFeeCents: number, ticketFeePercentage: number, seatedTicketFeeCents: number, seatedTicketFeePercentage: number, guestListFeeCents: number, signed: boolean, timezone: string) {
        this.#start = start;
        this.#end = end;
        this.#packageType = packageType;
        this.#productFeeCents = productFeeCents;
        this.#productFeePercentage = productFeePercentage;
        this.#ticketFeeCents = ticketFeeCents;
        this.#ticketFeePercentage = ticketFeePercentage;
        this.#seatedTicketFeeCents = seatedTicketFeeCents;
        this.#seatedTicketFeePercentage = seatedTicketFeePercentage;
        this.#guestListFeeCents = guestListFeeCents;
        this.#signed = signed;
        this.#timezone = timezone;
    }
}
