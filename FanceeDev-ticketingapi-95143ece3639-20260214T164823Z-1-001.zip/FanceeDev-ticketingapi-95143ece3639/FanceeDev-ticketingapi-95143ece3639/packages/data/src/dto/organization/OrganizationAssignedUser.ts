import { Dto } from '@fancee/client';

@Dto
export class OrganizationAssignedUser {
    get userId(): string {
        return this.#userId;
    }

    set userId(value: string) {
        this.#userId = value;
    }

    get claims(): string[] {
        return this.#claims;
    }

    set claims(value: string[]) {
        this.#claims = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    #userId: string;
    #claims: string[];
    #description: string;

    constructor(userId: string, claims: string[], description: string) {
        this.#userId = userId;
        this.#claims = claims;
        this.#description = description;
    }
}
