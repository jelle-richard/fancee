import { Dto } from '@fancee/client';
import { Address, Currency, ManagedBy, Media, OrganizationContact, OrganizationContract } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class OrganizationAccount {
    get avatar(): Media | null {
        return this.#avatar;
    }

    get email(): string {
        return this.#email;
    }

    get firstName(): string | null {
        return this.#firstName;
    }

    get lastName(): string | null {
        return this.#lastName;
    }

    get phoneNumber(): string | null {
        return this.#phoneNumber;
    }

    get organization(): string | null {
        return this.#organization;
    }

    get isVerified(): boolean {
        return this.#isVerified;
    }

    get isProfileComplete(): boolean {
        return this.#isProfileComplete;
    }

    set isImportant(value: boolean) {
        this.#isImportant = value;
    }

    get isImportant(): boolean {
        return this.#isImportant;
    }

    get address(): Address | null {
        return this.#address;
    }

    get lastLogin(): DateTime | null {
        return this.#lastLogin;
    }

    get createdOn(): DateTime {
        return this.#createdOn;
    }

    get approximatedAnnualSalesAmount(): number {
        return this.#approximatedAnnualSalesAmount;
    }

    get contract(): OrganizationContract | null {
        return this.#contract;
    }

    get currency(): Currency | null {
        return this.#currency;
    }

    get chamberOfCommerceIdentifier(): string | null {
        return this.#chamberOfCommerceIdentifier;
    }

    get contacts(): OrganizationContact[] {
        return this.#contacts;
    }

    get managedBy(): ManagedBy[] {
        return this.#managedBy;
    }

    get isBlocked(): boolean {
        return this.#isBlocked;
    }

    set isBlocked(value: boolean) {
        this.#isBlocked = value;
    }

    readonly #avatar: Media | null;
    readonly #email: string;
    readonly #firstName: string | null;
    readonly #lastName: string | null;
    readonly #phoneNumber: string | null;
    readonly #organization: string | null;
    readonly #isVerified: boolean;
    readonly #isProfileComplete: boolean;
    #isImportant: boolean;
    readonly #address: Address | null;
    readonly #lastLogin: DateTime | null;
    readonly #createdOn: DateTime;
    readonly #approximatedAnnualSalesAmount: number;
    readonly #contract: OrganizationContract | null;
    readonly #currency: Currency | null;
    readonly #chamberOfCommerceIdentifier: string | null;
    readonly #contacts: OrganizationContact[];
    readonly #managedBy: ManagedBy[];
    #isBlocked: boolean;

    constructor(avatar: Media | null, email: string, firstName: string | null, lastName: string | null, phoneNumber: string | null, organization: string | null, isVerified: boolean, isProfileComplete: boolean, isImportant: boolean, address: Address | null, lastLogin: DateTime | null, createdOn: DateTime, approximatedAnnualSalesAmount: number, contract: OrganizationContract | null, currency: Currency | null, chamberOfCommerceIdentifier: string | null, contacts: OrganizationContact[], managedBy: ManagedBy[], isBlocked: boolean) {
        this.#avatar = avatar;
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#phoneNumber = phoneNumber;
        this.#organization = organization;
        this.#isVerified = isVerified;
        this.#isProfileComplete = isProfileComplete;
        this.#isImportant = isImportant;
        this.#address = address;
        this.#lastLogin = lastLogin;
        this.#createdOn = createdOn;
        this.#approximatedAnnualSalesAmount = approximatedAnnualSalesAmount;
        this.#contract = contract;
        this.#currency = currency;
        this.#chamberOfCommerceIdentifier = chamberOfCommerceIdentifier;
        this.#contacts = contacts;
        this.#managedBy = managedBy;
        this.#isBlocked = isBlocked;
    }
}
