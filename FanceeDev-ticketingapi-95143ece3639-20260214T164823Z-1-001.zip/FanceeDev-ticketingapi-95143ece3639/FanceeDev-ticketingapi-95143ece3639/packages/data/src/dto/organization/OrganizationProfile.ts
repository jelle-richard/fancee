import { Dto } from '@fancee/client';
import { Address, LegalEntity, OrganizationHolder, OrganizationContact, OrganizationFinanceDetails } from '@/dto';

@Dto
export class OrganizationProfile {
    get address(): Address {
        return this.#address;
    }

    set address(value: Address) {
        this.#address = value;
    }

    get contacts(): OrganizationContact[] {
        return this.#contacts;
    }

    set contacts(value: OrganizationContact[]) {
        this.#contacts = value;
    }

    get finance(): OrganizationFinanceDetails {
        return this.#finance;
    }

    set finance(value: OrganizationFinanceDetails) {
        this.#finance = value;
    }

    get holder(): OrganizationHolder {
        return this.#holder;
    }

    set holder(value: OrganizationHolder) {
        this.#holder = value;
    }

    get legalEntity(): LegalEntity {
        return this.#legalEntity;
    }

    set legalEntity(value: LegalEntity) {
        this.#legalEntity = value;
    }

    get twoFactorEnabled(): boolean {
        return this.#twoFactorEnabled;
    }

    set twoFactorEnabled(value: boolean) {
        this.#twoFactorEnabled = value;
    }

    #address: Address;
    #contacts: OrganizationContact[];
    #finance: OrganizationFinanceDetails;
    #holder: OrganizationHolder;
    #legalEntity: LegalEntity;
    #twoFactorEnabled: boolean;

    constructor(holder: OrganizationHolder, legalEntity: LegalEntity, finance: OrganizationFinanceDetails, address: Address, contacts: OrganizationContact[], twoFactorEnabled: boolean) {
        this.#holder = holder;
        this.#legalEntity = legalEntity;
        this.#finance = finance;
        this.#address = address;
        this.#contacts = contacts;
        this.#twoFactorEnabled = twoFactorEnabled;
    }

    public static empty(): OrganizationProfile {
        return new OrganizationProfile(
            OrganizationHolder.empty(),
            LegalEntity.empty(),
            OrganizationFinanceDetails.empty(),
            Address.empty(),
            [],
            false
        );
    }
}
