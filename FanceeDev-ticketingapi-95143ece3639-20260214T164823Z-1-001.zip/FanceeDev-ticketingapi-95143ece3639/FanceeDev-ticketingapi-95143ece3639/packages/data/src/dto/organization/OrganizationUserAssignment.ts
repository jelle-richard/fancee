import { Dto } from '@fancee/client';

@Dto
export class OrganizationUserAssignment {
    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get claims(): string[] {
        return this.#claims;
    }

    set claims(value: string[]) {
        this.#claims = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    #email: string;
    #claims: string[];
    #description: string;

    constructor(email: string, claims: string[], description: string) {
        this.#email = email;
        this.#claims = claims;
        this.#description = description;
    }
}
