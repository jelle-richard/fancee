import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class OrganizationUser {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    get avatar(): Media | null {
        return this.#avatar;
    }

    set avatar(value: Media | null) {
        this.#avatar = value;
    }

    get claims(): string[] {
        return this.#claims;
    }

    set claims(value: string[]) {
        this.#claims = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    #id: string;
    #email: string;
    #firstName: string;
    #lastName: string;
    #avatar: Media | null;
    #claims: string[];
    #description: string;

    constructor(id: string, email: string, firstName: string, lastName: string, avatar: Media | null, claims: string[], description: string) {
        this.#id = id;
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#avatar = avatar;
        this.#claims = claims;
        this.#description = description;
    }
}
