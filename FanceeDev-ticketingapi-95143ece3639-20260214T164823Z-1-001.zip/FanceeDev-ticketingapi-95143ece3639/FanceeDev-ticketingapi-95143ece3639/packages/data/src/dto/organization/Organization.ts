import { Dto } from '@fancee/client';

@Dto
export class Organization {
    get avatar(): string {
        return this.#avatar;
    }

    set avatar(value: string) {
        this.#avatar = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    #avatar: string;
    #name: string;

    constructor(name: string, avatar: string) {
        this.#avatar = avatar;
        this.#name = name;
    }
}
