import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class OrganizationContractAlter {
    get guestListFeeCents(): number {
        return this.#guestListFeeCents;
    }

    set guestListFeeCents(value: number) {
        this.#guestListFeeCents = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    get productFeePercentage(): number {
        return this.#productFeePercentage;
    }

    set productFeePercentage(value: number) {
        this.#productFeePercentage = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    get ticketFeePercentage(): number {
        return this.#ticketFeePercentage;
    }

    set ticketFeePercentage(value: number) {
        this.#ticketFeePercentage = value;
    }

    get seatedTicketFeeCents(): number {
        return this.#seatedTicketFeeCents;
    }

    set seatedTicketFeeCents(value: number) {
        this.#seatedTicketFeeCents = value;
    }

    get seatedTicketFeePercentage(): number {
        return this.#seatedTicketFeePercentage;
    }

    set seatedTicketFeePercentage(value: number) {
        this.#seatedTicketFeePercentage = value;
    }

    get endDate(): DateTime | null {
        return this.#endDate;
    }

    set endDate(value: DateTime | null) {
        this.#endDate = value;
    }

    #guestListFeeCents: number;
    #productFeeCents: number;
    #productFeePercentage: number;
    #ticketFeeCents: number;
    #ticketFeePercentage: number;
    #seatedTicketFeeCents: number;
    #seatedTicketFeePercentage: number;
    #endDate: DateTime | null;

    constructor(guestListFeeCents: number, productFeeCents: number, productFeePercentage: number, ticketFeeCents: number, ticketFeePercentage: number, seatedTicketFeeCents: number, seatedTicketFeePercentage: number, endDate: DateTime | null) {
        this.#guestListFeeCents = guestListFeeCents;
        this.#productFeeCents = productFeeCents;
        this.#productFeePercentage = productFeePercentage;
        this.#ticketFeeCents = ticketFeeCents;
        this.#ticketFeePercentage = ticketFeePercentage;
        this.#seatedTicketFeeCents = seatedTicketFeeCents;
        this.#seatedTicketFeePercentage = seatedTicketFeePercentage;
        this.#endDate = endDate;
    }
}
