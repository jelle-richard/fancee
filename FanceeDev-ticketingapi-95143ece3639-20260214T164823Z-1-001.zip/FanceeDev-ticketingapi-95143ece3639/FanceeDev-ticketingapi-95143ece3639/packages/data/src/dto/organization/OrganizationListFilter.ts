import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { Filter } from '@/dto';

@Dto
export class OrganizationListFilter extends Filter<OrganizationListFilter> {
    get search(): string {
        return this.#search;
    }

    set search(value: string) {
        this.#search = value;
    }

    get contractSigned(): boolean | null {
        return this.#contractSigned;
    }

    set contractSigned(value: boolean | null) {
        this.#contractSigned = value;
    }

    get isImportant(): boolean | null {
        return this.#isImportant;
    }

    set isImportant(value: boolean | null) {
        this.#isImportant = value;
    }

    get salesRange(): [number, number] | null {
        return this.#salesRange;
    }

    set salesRange(value: [number, number] | null) {
        this.#salesRange = value;
    }

    get dateSpan(): [DateTime, DateTime] | null {
        return this.#dateSpan;
    }

    set dateSpan(value: [DateTime, DateTime] | null) {
        this.#dateSpan = value;
    }

    get isBlocked(): boolean | null {
        return this.#isBlocked;
    }

    set isBlocked(value: boolean | null) {
        this.#isBlocked = value;
    }

    #search: string;
    #contractSigned: boolean | null;
    #isImportant: boolean | null;
    #salesRange: [number, number] | null;
    #dateSpan: [DateTime, DateTime] | null;
    #isBlocked: boolean | null;

    constructor(search: string, contractSigned: boolean | null, isImportant: boolean | null, salesRange: [number, number] | null, dateSpan: [DateTime, DateTime] | null, isBlocked: boolean | null) {
        super();
        this.#search = search;
        this.#contractSigned = contractSigned;
        this.#isImportant = isImportant;
        this.#salesRange = salesRange;
        this.#dateSpan = dateSpan;
        this.#isBlocked = isBlocked;
    }

    public static default(): OrganizationListFilter {
        return new OrganizationListFilter(
            '',
            null,
            null,
            null,
            null,
            null
        );
    }
}
