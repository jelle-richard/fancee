import { Dto } from '@fancee/client';
import { CountryCode } from '@/constant';
import { DateTime } from 'luxon';

@Dto
export class OrganizationListing {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get countryCode(): CountryCode {
        return this.#countryCode;
    }

    set countryCode(value: CountryCode) {
        this.#countryCode = value;
    }

    get approximatedAnnualSalesAmount(): number {
        return this.#approximatedAnnualSalesAmount;
    }

    set approximatedAnnualSalesAmount(value: number) {
        this.#approximatedAnnualSalesAmount = value;
    }

    get isImportant(): boolean {
        return this.#isImportant;
    }

    set isImportant(value: boolean) {
        this.#isImportant = value;
    }

    get isVerified(): boolean {
        return this.#isVerified;
    }

    set isVerified(value: boolean) {
        this.#isVerified = value;
    }

    get isProfileComplete(): boolean {
        return this.#isProfileComplete;
    }

    set isProfileComplete(value: boolean) {
        this.#isProfileComplete = value;
    }

    get lastLogin(): DateTime {
        return this.#lastLogin;
    }

    set lastLogin(value: DateTime) {
        this.#lastLogin = value;
    }

    get isBlocked(): boolean {
        return this.#isBlocked;
    }

    set isBlocked(value: boolean) {
        this.#isBlocked = value;
    }

    get phoneNumber(): string | null {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string | null) {
        this.#phoneNumber = value;
    }

    #id: string;
    #name: string;
    #email: string;
    #countryCode: CountryCode;
    #approximatedAnnualSalesAmount: number;
    #isImportant: boolean;
    #isVerified: boolean;
    #isProfileComplete: boolean;
    #lastLogin: DateTime;
    #isBlocked: boolean;
    #phoneNumber: string | null;

    constructor(id: string, name: string, email: string, countryCode: CountryCode, approximatedAnnualSalesAmount: number, isImportant: boolean, isVerified: boolean, isProfileComplete: boolean, lastLogin: DateTime, isBlocked: boolean, phoneNumber: string | null) {
        this.#id = id;
        this.#name = name;
        this.#email = email;
        this.#countryCode = countryCode;
        this.#approximatedAnnualSalesAmount = approximatedAnnualSalesAmount;
        this.#isImportant = isImportant;
        this.#isVerified = isVerified;
        this.#isProfileComplete = isProfileComplete;
        this.#lastLogin = lastLogin;
        this.#isBlocked = isBlocked;
        this.#phoneNumber = phoneNumber;
    }
}
