import { Dto } from '@fancee/client';
import { Currency } from '@/dto';

@Dto
export class OrganizationFinanceDetails {
    get bankAccountIban(): string | null {
        return this.#bankAccountIban;
    }

    set bankAccountIban(value: string | null) {
        this.#bankAccountIban = value;
    }

    get bankAccountNumber(): string | null {
        return this.#bankAccountNumber;
    }

    set bankAccountNumber(value: string | null) {
        this.#bankAccountNumber = value;
    }

    get bankAccountBic(): string | null {
        return this.#bankAccountBic;
    }

    set bankAccountBic(value: string | null) {
        this.#bankAccountBic = value;
    }

    get vatIdentifier(): string | null {
        return this.#vatIdentifier;
    }

    set vatIdentifier(value: string | null) {
        this.#vatIdentifier = value;
    }

    get approximatedAnnualSalesAmount(): number {
        return this.#approximatedAnnualSalesAmount;
    }

    set approximatedAnnualSalesAmount(value: number) {
        this.#approximatedAnnualSalesAmount = value;
    }

    get currency(): Currency | null {
        return this.#currency;
    }

    set currency(value: Currency | null) {
        this.#currency = value;
    }

    #bankAccountIban: string | null;
    #bankAccountNumber: string | null;
    #bankAccountBic: string | null;
    #vatIdentifier: string | null;
    #approximatedAnnualSalesAmount: number;
    #currency: Currency | null;

    constructor(bankAccountIban: string | null, bankAccountNumber: string | null, bankAccountBic: string | null, vatIdentifier: string | null, approximatedAnnualSalesAmount: number, currency: Currency | null) {
        this.#bankAccountIban = bankAccountIban;
        this.#bankAccountNumber = bankAccountNumber;
        this.#bankAccountBic = bankAccountBic;
        this.#vatIdentifier = vatIdentifier;
        this.#approximatedAnnualSalesAmount = approximatedAnnualSalesAmount;
        this.#currency = currency;
    }

    static empty(): OrganizationFinanceDetails {
        return new OrganizationFinanceDetails(null, null, null, null, 0, null);
    }
}
