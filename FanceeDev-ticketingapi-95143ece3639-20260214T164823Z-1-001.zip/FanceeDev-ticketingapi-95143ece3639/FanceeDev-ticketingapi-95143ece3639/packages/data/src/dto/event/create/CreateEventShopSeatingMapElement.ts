import { Dto } from '@fancee/client';
import { CreateEventShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class CreateEventShopSeatingMapElement extends CreateEventShopElement {
    constructor() {
        super(ShopElementKind.SeatingMap);
    }
}
