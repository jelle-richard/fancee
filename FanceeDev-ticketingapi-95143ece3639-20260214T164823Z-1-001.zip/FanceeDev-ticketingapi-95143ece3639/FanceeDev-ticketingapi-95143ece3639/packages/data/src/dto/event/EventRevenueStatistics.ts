import { Dto } from '@fancee/client';

@Dto
export class EventRevenueStatistics {
    get onlineSalesRevenueCents(): number {
        return this.#onlineSalesRevenueCents;
    }

    set onlineSalesRevenueCents(value: number) {
        this.#onlineSalesRevenueCents = value;
    }

    get cashSalesRevenueCents(): number {
        return this.#cashSalesRevenueCents;
    }

    set cashSalesRevenueCents(value: number) {
        this.#cashSalesRevenueCents = value;
    }

    get platformExpensesCents(): number {
        return this.#platformExpensesCents;
    }

    set platformExpensesCents(value: number) {
        this.#platformExpensesCents = value;
    }

    get profitCents(): number {
        return this.#profitCents;
    }

    set profitCents(value: number) {
        this.#profitCents = value;
    }

    #onlineSalesRevenueCents: number;
    #cashSalesRevenueCents: number;
    #platformExpensesCents: number;
    #profitCents: number;

    constructor(onlineSalesRevenueCents: number, cashSalesRevenueCents: number, platformExpensesCents: number, profitCents: number) {
        this.#onlineSalesRevenueCents = onlineSalesRevenueCents;
        this.#cashSalesRevenueCents = cashSalesRevenueCents;
        this.#platformExpensesCents = platformExpensesCents;
        this.#profitCents = profitCents;
    }

    public static empty(): EventRevenueStatistics {
        return new EventRevenueStatistics(0, 0, 0, 0);
    }
}
