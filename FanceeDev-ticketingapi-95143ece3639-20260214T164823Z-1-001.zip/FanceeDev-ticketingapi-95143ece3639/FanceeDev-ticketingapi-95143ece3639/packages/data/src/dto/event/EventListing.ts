import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { EventShopLinkListItem, Organization } from '@/dto';

@Dto
export class EventListing {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get seatsIoEventId(): string | null {
        return this.#seatsIoEventId;
    }

    set seatsIoEventId(value: string | null) {
        this.#seatsIoEventId = value;
    }

    get organization(): Organization {
        return this.#organization;
    }

    set organization(value: Organization) {
        this.#organization = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get date(): DateTime {
        return this.#date;
    }

    set date(value: DateTime) {
        this.#date = value;
    }

    get shopLinkListItems(): EventShopLinkListItem[] {
        return this.#shopLinkListItems;
    }

    set shopLinkListItems(value: EventShopLinkListItem[]) {
        this.#shopLinkListItems = value;
    }

    get type(): string {
        return this.#type;
    }

    set type(value: string) {
        this.#type = value;
    }

    get status(): string {
        return this.#status;
    }

    set status(value: string) {
        this.#status = value;
    }

    get deletable(): boolean {
        return this.#deletable;
    }

    set deletable(value: boolean) {
        this.#deletable = value;
    }

    #id: string;
    #seatsIoEventId: string | null;
    #organization: Organization;
    #name: string;
    #date: DateTime;
    #shopLinkListItems: EventShopLinkListItem[];
    #type: string;
    #status: string;
    #deletable: boolean;

    constructor(id: string, seatsIoEventId: string | null, organization: Organization, name: string, date: DateTime, shopLinkListItems: EventShopLinkListItem[], type: string, status: string, deletable: boolean) {
        this.#id = id;
        this.#seatsIoEventId = seatsIoEventId;
        this.#organization = organization;
        this.#name = name;
        this.#date = date;
        this.#shopLinkListItems = shopLinkListItems;
        this.#type = type;
        this.#status = status;
        this.#deletable = deletable;
    }
}
