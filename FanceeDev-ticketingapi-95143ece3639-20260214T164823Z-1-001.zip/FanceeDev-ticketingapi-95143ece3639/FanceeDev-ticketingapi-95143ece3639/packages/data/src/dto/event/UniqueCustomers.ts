import { Dto } from '@fancee/client';

@Dto
export class UniqueCustomers {
    get uniqueMaleCustomers(): number {
        return this.#uniqueMaleCustomers;
    }

    set uniqueMaleCustomers(value: number) {
        this.#uniqueMaleCustomers = value;
    }

    get uniqueFemaleCustomers(): number {
        return this.#uniqueFemaleCustomers;
    }

    set uniqueFemaleCustomers(value: number) {
        this.#uniqueFemaleCustomers = value;
    }

    get uniqueNeutralCustomers(): number {
        return this.#uniqueNeutralCustomers;
    }

    set uniqueNeutralCustomers(value: number) {
        this.#uniqueNeutralCustomers = value;
    }

    get uniqueUnknownCustomers(): number {
        return this.#uniqueUnknownCustomers;
    }

    set uniqueUnknownCustomers(value: number) {
        this.#uniqueUnknownCustomers = value;
    }

    #uniqueMaleCustomers: number;
    #uniqueFemaleCustomers: number;
    #uniqueNeutralCustomers: number;
    #uniqueUnknownCustomers: number;

    constructor(uniqueMaleCustomers: number, uniqueFemaleCustomers: number, uniqueNeutralCustomers: number, uniqueUnknownCustomers: number) {
        this.#uniqueMaleCustomers = uniqueMaleCustomers;
        this.#uniqueFemaleCustomers = uniqueFemaleCustomers;
        this.#uniqueNeutralCustomers = uniqueNeutralCustomers;
        this.#uniqueUnknownCustomers = uniqueUnknownCustomers;
    }
}
