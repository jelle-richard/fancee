import { Dto } from '@fancee/client';
import { AverageGenderAges, UniqueCustomers } from '@/dto';

@Dto
export class GlobalEventStatistics {
    get productsSoldAmount(): number {
        return this.#productsSoldAmount;
    }

    set productsSoldAmount(value: number) {
        this.#productsSoldAmount = value;
    }

    get ordersPlacedAmount(): number {
        return this.#ordersPlacedAmount;
    }

    set ordersPlacedAmount(value: number) {
        this.#ordersPlacedAmount = value;
    }

    get ticketsScannedAmount(): number {
        return this.#ticketsScannedAmount;
    }

    set ticketsScannedAmount(value: number) {
        this.#ticketsScannedAmount = value;
    }

    get pendingRefundsAmount(): number {
        return this.#pendingRefundsAmount;
    }

    set pendingRefundsAmount(value: number) {
        this.#pendingRefundsAmount = value;
    }

    get averageAges(): AverageGenderAges {
        return this.#averageAges;
    }

    set averageAges(value: AverageGenderAges) {
        this.#averageAges = value;
    }

    get uniqueCustomers(): UniqueCustomers {
        return this.#uniqueCustomers;
    }

    set uniqueCustomers(value: UniqueCustomers) {
        this.#uniqueCustomers = value;
    }

    #productsSoldAmount: number;
    #ordersPlacedAmount: number;
    #ticketsScannedAmount: number;
    #pendingRefundsAmount: number;
    #averageAges: AverageGenderAges;
    #uniqueCustomers: UniqueCustomers;

    constructor(productsSoldAmount: number, ordersPlacedAmount: number, ticketsScannedAmount: number, pendingRefundsAmount: number, averageAges: AverageGenderAges, uniqueCustomers: UniqueCustomers) {
        this.#productsSoldAmount = productsSoldAmount;
        this.#ordersPlacedAmount = ordersPlacedAmount;
        this.#ticketsScannedAmount = ticketsScannedAmount;
        this.#pendingRefundsAmount = pendingRefundsAmount;
        this.#averageAges = averageAges;
        this.#uniqueCustomers = uniqueCustomers;
    }
}
