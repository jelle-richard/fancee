import { Dto } from '@fancee/client';
import { TicketDesignElement } from '@/dto';
import { TicketDesignElementKind } from '@/enum';

@Dto
export class TicketDesignMediaElement extends TicketDesignElement {
    get fileId(): string | null {
        return this.#fileId;
    }

    set fileId(value: string | null) {
        this.#fileId = value;
    }

    get fileUrl(): string | null {
        return this.#fileUrl;
    }

    set fileUrl(value: string | null) {
        this.#fileUrl = value;
    }

    #fileId: string | null;
    #fileUrl: string | null;

    constructor(fileId: string | null, fileUrl: string | null, column: number = 1, columnSpan: number = 1, row: number = 1, rowSpan: number = 1) {
        super(TicketDesignElementKind.Media, column, columnSpan, row, rowSpan);
        this.#fileId = fileId;
        this.#fileUrl = fileUrl;
    }
}
