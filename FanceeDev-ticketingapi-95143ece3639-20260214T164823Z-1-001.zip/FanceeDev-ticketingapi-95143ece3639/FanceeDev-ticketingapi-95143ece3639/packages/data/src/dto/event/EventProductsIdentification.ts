import { Dto } from '@fancee/client';
import { TypedProductIdentification } from '@/dto';
import { EventType } from '@/enum';

class DateTime {
}

@Dto
export class EventProductsIdentification {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    set startDate(value: DateTime) {
        this.#startDate = value;
    }

    get type(): EventType {
        return this.#type;
    }

    set type(value: EventType) {
        this.#type = value;
    }

    get products(): TypedProductIdentification[] {
        return this.#products;
    }

    set products(value: TypedProductIdentification[]) {
        this.#products = value;
    }

    #id: string;
    #name: string;
    #startDate: DateTime;
    #type: EventType;
    #products: TypedProductIdentification[];

    constructor(id: string, name: string, startDate: DateTime, type: EventType, products: TypedProductIdentification[]) {
        this.#id = id;
        this.#name = name;
        this.#startDate = startDate;
        this.#type = type;
        this.#products = products;
    }
}
