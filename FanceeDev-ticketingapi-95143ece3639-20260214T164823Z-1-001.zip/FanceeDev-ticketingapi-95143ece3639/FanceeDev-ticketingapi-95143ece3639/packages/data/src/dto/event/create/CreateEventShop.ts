import { Dto } from '@fancee/client';
import { CreateEventShopElement, DateTimeSpan, ShopAnalytics, ShopDesign, ShopFieldRequirement } from '@/dto';
import { ShopField } from '@/enum';
import { generateUuidV4 } from '@/util';
import { DateTime } from 'luxon';

@Dto
export class CreateEventShop {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get elements(): CreateEventShopElement[] {
        return this.#elements;
    }

    set elements(value: CreateEventShopElement[]) {
        this.#elements = value;
    }

    get dateTimeSpan(): DateTimeSpan {
        return this.#dateTimeSpan;
    }

    set dateTimeSpan(value: DateTimeSpan) {
        this.#dateTimeSpan = value;
    }

    get isActive(): boolean {
        return this.#isActive;
    }

    set isActive(value: boolean) {
        this.#isActive = value;
    }

    get isSecuredUntil(): DateTime | null {
        return this.#isSecuredUntil;
    }

    set isSecuredUntil(value: DateTime | null) {
        this.#isSecuredUntil = value;
    }

    get design(): ShopDesign {
        return this.#design;
    }

    set design(value: ShopDesign) {
        this.#design = value;
    }

    get fields(): ShopFieldRequirement[] {
        return this.#fields;
    }

    set fields(value: ShopFieldRequirement[]) {
        this.#fields = value;
    }

    get analytics(): ShopAnalytics {
        return this.#analytics;
    }

    set analytics(value: ShopAnalytics) {
        this.#analytics = value;
    }

    #code: string | null;
    #name: string;
    #elements: CreateEventShopElement[];
    #dateTimeSpan: DateTimeSpan;
    #isActive: boolean;
    #isSecuredUntil: DateTime | null;
    #design: ShopDesign;
    #fields: ShopFieldRequirement[];
    #analytics: ShopAnalytics;

    constructor(code: string | null, name: string, elements: CreateEventShopElement[], dateTimeSpan: DateTimeSpan, isActive: boolean, isSecuredUntil: DateTime | null, design: ShopDesign, fields: ShopFieldRequirement[], analytics: ShopAnalytics) {
        this.#code = code;
        this.#name = name;
        this.#elements = elements;
        this.#dateTimeSpan = dateTimeSpan;
        this.#isActive = isActive;
        this.#isSecuredUntil = isSecuredUntil;
        this.#design = design;
        this.#fields = fields;
        this.#analytics = analytics;
    }

    static default(): CreateEventShop {
        return new CreateEventShop(
            generateUuidV4(),
            '',
            [],
            DateTimeSpan.default(),
            true,
            null,
            ShopDesign.default(),
            [
                new ShopFieldRequirement(ShopField.Email, true, true)
            ],
            ShopAnalytics.default()
        );
    }
}
