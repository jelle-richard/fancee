import { CreateEventShopAccordionElement, CreateEventShopDividerElement, CreateEventShopExternalLinkElement, CreateEventShopNoticeElement, CreateEventShopProductElement, CreateEventShopSeatingMapElement, CreateEventShopTextBlockElement } from '@/dto';
import { ShopElementKind } from '@/enum';
import { generateUuidV4 } from '@/util';

export abstract class CreateEventShopElement {
    get internalId(): string {
        return this.#internalId;
    }

    get kind(): ShopElementKind {
        return this.#kind;
    }

    readonly #internalId: string;
    readonly #kind: ShopElementKind;

    protected constructor(kind: ShopElementKind) {
        this.#internalId = generateUuidV4();
        this.#kind = kind;
    }

    public static isAccordion(element: CreateEventShopElement): element is CreateEventShopAccordionElement {
        return element && element.kind === ShopElementKind.Accordion;
    }

    public static isDivider(element: CreateEventShopElement): element is CreateEventShopDividerElement {
        return element && element.kind === ShopElementKind.Divider;
    }

    public static isExternalLink(element: CreateEventShopElement): element is CreateEventShopExternalLinkElement {
        return element && element.kind === ShopElementKind.ExternalLink;
    }

    public static isNotice(element: CreateEventShopElement): element is CreateEventShopNoticeElement {
        return element && element.kind === ShopElementKind.Notice;
    }

    public static isProduct(element: CreateEventShopElement): element is CreateEventShopProductElement {
        return element && element.kind === ShopElementKind.Product;
    }

    public static isSeatingMap(element: CreateEventShopElement): element is CreateEventShopSeatingMapElement {
        return element && element.kind === ShopElementKind.SeatingMap;
    }

    public static isTextBlock(element: CreateEventShopElement): element is CreateEventShopTextBlockElement {
        return element && element.kind === ShopElementKind.TextBlock;
    }
}
