import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { EventBalance } from '@/dto';

@Dto
export class EventBalanceListing {
    get eventId(): string {
        return this.#eventId;
    }

    get eventName(): string {
        return this.#eventName;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    get endDate(): DateTime {
        return this.#endDate;
    }

    get status(): string {
        return this.#status;
    }

    get userId(): string {
        return this.#userId;
    }

    get userEmail(): string {
        return this.#userEmail;
    }

    get countryCode(): string {
        return this.#countryCode;
    }

    get organizationCurrencyEventBalanceCentsReceivedResponse(): EventBalance {
        return this.#organizationCurrencyEventBalanceCentsReceivedResponse;
    }

    get platformCurrencyEventBalanceCentsReceivedResponse(): EventBalance {
        return this.#platformCurrencyEventBalanceCentsReceivedResponse;
    }

    get totalAmountOfIssuedTickets(): number {
        return this.#totalAmountOfIssuedTickets;
    }

    get totalAmountOfScannedTickets(): number {
        return this.#totalAmountOfScannedTickets;
    }

    readonly #eventId: string;
    readonly #eventName: string;
    readonly #startDate: DateTime;
    readonly #endDate: DateTime;
    readonly #status: string;
    readonly #userId: string;
    readonly #userEmail: string;
    readonly #countryCode: string;
    readonly #organizationCurrencyEventBalanceCentsReceivedResponse: EventBalance;
    readonly #platformCurrencyEventBalanceCentsReceivedResponse: EventBalance;
    readonly #totalAmountOfIssuedTickets: number;
    readonly #totalAmountOfScannedTickets: number;

    constructor(eventId: string, eventName: string, startDate: DateTime, endDate: DateTime, status: string, userId: string, userEmail: string, countryCode: string, organizationCurrencyEventBalanceCentsReceivedResponse: EventBalance, platformCurrencyEventBalanceCentsReceivedResponse: EventBalance, totalAmountOfIssuedTickets: number, totalAmountOfScannedTickets: number) {
        this.#eventId = eventId;
        this.#eventName = eventName;
        this.#startDate = startDate;
        this.#endDate = endDate;
        this.#status = status;
        this.#userId = userId;
        this.#userEmail = userEmail;
        this.#countryCode = countryCode;
        this.#organizationCurrencyEventBalanceCentsReceivedResponse = organizationCurrencyEventBalanceCentsReceivedResponse;
        this.#platformCurrencyEventBalanceCentsReceivedResponse = platformCurrencyEventBalanceCentsReceivedResponse;
        this.#totalAmountOfIssuedTickets = totalAmountOfIssuedTickets;
        this.#totalAmountOfScannedTickets = totalAmountOfScannedTickets;
    }
}
