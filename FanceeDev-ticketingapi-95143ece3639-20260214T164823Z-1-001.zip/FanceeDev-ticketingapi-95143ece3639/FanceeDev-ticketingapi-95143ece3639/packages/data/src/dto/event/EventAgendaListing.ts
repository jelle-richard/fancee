import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { Organization, EventShopLinkListItem } from '@/dto';

@Dto
export class EventAgendaListing {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get organization(): Organization {
        return this.#organization;
    }

    set organization(value: Organization) {
        this.#organization = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    set startDate(value: DateTime) {
        this.#startDate = value;
    }

    get endDate(): DateTime {
        return this.#endDate;
    }

    set endDate(value: DateTime) {
        this.#endDate = value;
    }

    get shopLinkCodes(): EventShopLinkListItem[] {
        return this.#shopLinkCodes;
    }

    set shopLinkCodes(value: EventShopLinkListItem[]) {
        this.#shopLinkCodes = value;
    }

    get type(): string {
        return this.#type;
    }

    set type(value: string) {
        this.#type = value;
    }

    get status(): string {
        return this.#status;
    }

    set status(value: string) {
        this.#status = value;
    }

    #id: string;
    #organization: Organization;
    #name: string;
    #startDate: DateTime;
    #endDate: DateTime;
    #shopLinkCodes: EventShopLinkListItem[];
    #type: string;
    #status: string;

    constructor(id: string, organization: Organization, name: string, startDate: DateTime, endDate: DateTime, shopLinkCodes: EventShopLinkListItem[], type: string, status: string) {
        this.#id = id;
        this.#organization = organization;
        this.#name = name;
        this.#startDate = startDate;
        this.#endDate = endDate;
        this.#shopLinkCodes = shopLinkCodes;
        this.#type = type;
        this.#status = status;
    }
}
