import { Dto } from '@fancee/client';
import { Address, Currency, PaymentMethod } from '@/dto';
import { EventStatus, EventType } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class ShopEvent {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get seatsIoEventId(): string | null {
        return this.#seatsIoEventId;
    }

    set seatsIoEventId(value: string | null) {
        this.#seatsIoEventId = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get organization(): string {
        return this.#organization;
    }

    set organization(value: string) {
        this.#organization = value;
    }

    get type(): EventType {
        return this.#type;
    }

    set type(value: EventType) {
        this.#type = value;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    set startDate(value: DateTime) {
        this.#startDate = value;
    }

    get endDate(): DateTime {
        return this.#endDate;
    }

    set endDate(value: DateTime) {
        this.#endDate = value;
    }

    get status(): EventStatus {
        return this.#status;
    }

    set status(value: EventStatus) {
        this.#status = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get address(): Address | null {
        return this.#address;
    }

    set address(value: Address | null) {
        this.#address = value;
    }

    get currency(): Currency {
        return this.#currency;
    }

    set currency(value: Currency) {
        this.#currency = value;
    }

    get paymentMethods(): PaymentMethod[] {
        return this.#paymentMethods;
    }

    set paymentMethods(value: PaymentMethod[]) {
        this.#paymentMethods = value;
    }

    get minimumAge(): number {
        return this.#minimumAge;
    }

    set minimumAge(value: number) {
        this.#minimumAge = value;
    }

    #id: string;
    #seatsIoEventId: string | null;
    #name: string;
    #organization: string;
    #type: EventType;
    #startDate: DateTime;
    #endDate: DateTime;
    #status: EventStatus;
    #description: string;
    #address: Address | null;
    #currency: Currency;
    #paymentMethods: PaymentMethod[];
    #minimumAge: number;

    constructor(id: string, seatsIoEventId: string | null, name: string, organization: string, type: EventType, startDate: DateTime, endDate: DateTime, status: EventStatus, description: string, address: Address | null, currency: Currency, paymentMethods: PaymentMethod[], minimumAge: number) {
        this.#id = id;
        this.#seatsIoEventId = seatsIoEventId;
        this.#name = name;
        this.#organization = organization;
        this.#type = type;
        this.#startDate = startDate;
        this.#endDate = endDate;
        this.#status = status;
        this.#description = description;
        this.#address = address;
        this.#currency = currency;
        this.#paymentMethods = paymentMethods;
        this.#minimumAge = minimumAge;
    }
}
