import { Dto } from '@fancee/client';

@Dto
export class EventValidationResponse {
    get hasPaymentMethods(): boolean {
        return this.#hasPaymentMethods;
    }

    get hasSellableProducts(): boolean {
        return this.#hasSellableProducts;
    }

    get hasShops(): boolean {
        return this.#hasShops;
    }

    get isPublishable(): boolean {
        return this.#hasShops && this.#hasSellableProducts && this.#hasPaymentMethods;
    }

    readonly #hasPaymentMethods: boolean;
    readonly #hasSellableProducts: boolean;
    readonly #hasShops: boolean;

    constructor(hasPaymentMethods: boolean, hasSellableProducts: boolean, hasShops: boolean) {
        this.#hasPaymentMethods = hasPaymentMethods;
        this.#hasSellableProducts = hasSellableProducts;
        this.#hasShops = hasShops;
    }
}
