import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { Address, DateTimeSpan, Media } from '@/dto';
import { EventStatus, EventType } from '@/enum';

@Dto
export class EventDetails {
    get categories(): string[] {
        return this.#categories;
    }

    set categories(value: string[]) {
        this.#categories = value;
    }

    get dateTimeSpan(): DateTimeSpan {
        return this.#dateTimeSpan;
    }

    set dateTimeSpan(value: DateTimeSpan) {
        this.#dateTimeSpan = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get headerMedia(): Media[] {
        return this.#headerMedia;
    }

    set headerMedia(value: Media[]) {
        this.#headerMedia = value;
    }

    get location(): Address {
        return this.#location;
    }

    set location(value: Address) {
        this.#location = value;
    }

    get minimalAge(): number | null {
        return this.#minimalAge;
    }

    set minimalAge(value: number | null) {
        this.#minimalAge = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get status(): EventStatus {
        return this.#status;
    }

    set status(value: EventStatus) {
        this.#status = value;
    }

    get type(): EventType {
        return this.#type;
    }

    set type(value: EventType) {
        this.#type = value;
    }

    get timezoneIdentification(): string | null {
        return this.#timezoneIdentification;
    }

    set timezoneIdentification(value: string | null) {
        this.#timezoneIdentification = value;
    }

    get seatsIoEventId(): string | null {
        return this.#seatsIoEventId;
    }

    set seatsIoEventId(value: string | null) {
        this.#seatsIoEventId = value;
    }

    get isSealed(): boolean {
        return this.#isSealed;
    }

    set isSealed(value: boolean) {
        this.#isSealed = value;
    }

    #categories: string[];
    #dateTimeSpan: DateTimeSpan;
    #description: string;
    #headerMedia: Media[];
    #location: Address;
    #minimalAge: number | null;
    #name: string;
    #status: EventStatus;
    #type: EventType;
    #timezoneIdentification: string | null;
    #seatsIoEventId: string | null;
    #isSealed: boolean;

    constructor(categories: string[], dateTimeSpan: DateTimeSpan, description: string, headerMedia: Media[], location: Address, minimalAge: number | null, name: string, status: EventStatus, type: EventType, timezoneIdentification: string | null, seatsIoEventId: string | null, isSealed: boolean) {
        this.#categories = categories;
        this.#dateTimeSpan = dateTimeSpan;
        this.#description = description;
        this.#headerMedia = headerMedia;
        this.#location = location;
        this.#minimalAge = minimalAge;
        this.#name = name;
        this.#status = status;
        this.#type = type;
        this.#timezoneIdentification = timezoneIdentification;
        this.#seatsIoEventId = seatsIoEventId;
        this.#isSealed = isSealed;
    }

    static default(): EventDetails {
        const eventDate = DateTime.now().plus({days: 25}).set({hour: 23, minute: 0, second: 0});

        return new EventDetails(
            [],
            new DateTimeSpan(
                eventDate,
                eventDate.plus({hours: 7})
            ),
            '',
            [],
            Address.empty(),
            null,
            '',
            EventStatus.Concept,
            EventType.Normal,
            null,
            null,
            false
        );
    }
}
