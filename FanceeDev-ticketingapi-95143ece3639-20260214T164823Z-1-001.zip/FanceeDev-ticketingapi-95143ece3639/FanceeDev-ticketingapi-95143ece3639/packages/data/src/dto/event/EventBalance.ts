import { Dto } from '@fancee/client';
import { Currency } from '@/dto';

@Dto
export class EventBalance {
    get totalAmountOfTicketFeeCentsReceived(): number {
        return this.#totalAmountOfTicketFeeCentsReceived;
    }

    get totalAmountOfSeatedTicketFeeCentsReceived(): number {
        return this.#totalAmountOfSeatedTicketFeeCentsReceived;
    }

    get totalAmountOfPaymentFeeCentsReceived(): number {
        return this.#totalAmountOfPaymentFeeCentsReceived;
    }

    get totalAmountOfGuestListFeeCentsReceived(): number {
        return this.#totalAmountOfGuestListFeeCentsReceived;
    }

    get totalAmountOfOrderTotalCostsCentsReceived(): number {
        return this.#totalAmountOfOrderTotalCostsCentsReceived;
    }

    get totalAmountOfTicketPlusCostsCentsReceived(): number {
        return this.#totalAmountOfTicketPlusCostsCentsReceived;
    }

    get currency(): Currency {
        return this.#currency;
    }

    readonly #totalAmountOfTicketFeeCentsReceived: number;
    readonly #totalAmountOfSeatedTicketFeeCentsReceived: number;
    readonly #totalAmountOfPaymentFeeCentsReceived: number;
    readonly #totalAmountOfGuestListFeeCentsReceived: number;
    readonly #totalAmountOfOrderTotalCostsCentsReceived: number;
    readonly #totalAmountOfTicketPlusCostsCentsReceived: number;
    readonly #currency: Currency;

    constructor(totalAmountOfTicketFeeCentsReceived: number, totalAmountOfSeatedTicketFeeCentsReceived: number, totalAmountOfPaymentFeeCentsReceived: number, totalAmountOfGuestListFeeCentsReceived: number, totalAmountOfOrderTotalCostsCentsReceived: number, totalAmountOfTicketPlusCostsCentsReceived: number, currency: Currency) {
        this.#totalAmountOfTicketFeeCentsReceived = totalAmountOfTicketFeeCentsReceived;
        this.#totalAmountOfSeatedTicketFeeCentsReceived = totalAmountOfSeatedTicketFeeCentsReceived;
        this.#totalAmountOfPaymentFeeCentsReceived = totalAmountOfPaymentFeeCentsReceived;
        this.#totalAmountOfGuestListFeeCentsReceived = totalAmountOfGuestListFeeCentsReceived;
        this.#totalAmountOfOrderTotalCostsCentsReceived = totalAmountOfOrderTotalCostsCentsReceived;
        this.#totalAmountOfTicketPlusCostsCentsReceived = totalAmountOfTicketPlusCostsCentsReceived;
        this.#currency = currency;
    }
}
