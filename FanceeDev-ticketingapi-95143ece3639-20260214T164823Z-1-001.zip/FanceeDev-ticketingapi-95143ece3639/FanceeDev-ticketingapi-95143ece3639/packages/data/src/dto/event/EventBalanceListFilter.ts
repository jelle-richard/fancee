import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { Filter } from '@/dto';
import { EventStatus } from '@/enum';

@Dto
export class EventBalanceListFilter extends Filter<EventBalanceListFilter> {
    get dateSpan(): [DateTime, DateTime] | null {
        return this.#dateSpan;
    }

    set dateSpan(value: [DateTime, DateTime] | null) {
        this.#dateSpan = value;
    }

    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    get states(): EventStatus[] {
        return this.#states;
    }

    set states(value: EventStatus[]) {
        this.#states = value;
    }

    #searchQuery: string;
    #states: EventStatus[];
    #dateSpan: [DateTime, DateTime] | null;

    constructor(searchQuery: string, states: EventStatus[], dateSpan: [DateTime, DateTime] | null) {
        super();
        this.#dateSpan = dateSpan;
        this.#searchQuery = searchQuery;
        this.#states = states;
    }

    public static default(): EventBalanceListFilter {
        return new EventBalanceListFilter('', [], [DateTime.now().plus({weeks: -1}), DateTime.now().plus({weeks: 51})]);
    }
}
