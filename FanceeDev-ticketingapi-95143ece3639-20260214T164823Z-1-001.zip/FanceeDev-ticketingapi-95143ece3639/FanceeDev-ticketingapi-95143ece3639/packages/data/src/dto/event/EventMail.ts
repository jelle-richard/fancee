import { Dto } from '@fancee/client';
import { EventMailType } from '@/enum/event/EventMailType';

@Dto
export class EventMail {
    get senderName(): string {
        return this.#senderName;
    }

    set senderName(value: string) {
        this.#senderName = value;
    }

    get subject(): string {
        return this.#subject;
    }

    set subject(value: string) {
        this.#subject = value;
    }

    get content(): string {
        return this.#content;
    }

    set content(value: string) {
        this.#content = value;
    }

    get type(): EventMailType {
        return this.#type;
    }

    set type(value: EventMailType) {
        this.#type = value;
    }

    #senderName: string;
    #subject: string;
    #content: string;
    #type: EventMailType;

    constructor(senderName: string, subject: string, content: string, type: EventMailType) {
        this.#senderName = senderName;
        this.#subject = subject;
        this.#content = content;
        this.#type = type;
    }
}
