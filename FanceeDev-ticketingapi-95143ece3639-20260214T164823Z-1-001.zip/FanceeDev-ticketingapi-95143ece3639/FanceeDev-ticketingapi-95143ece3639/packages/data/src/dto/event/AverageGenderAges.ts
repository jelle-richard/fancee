import { Dto } from '@fancee/client';

@Dto
export class AverageGenderAges {
    get totalAverageAge(): number | null {
        return this.#totalAverageAge;
    }

    set totalAverageAge(value: number | null) {
        this.#totalAverageAge = value;
    }

    get maleAverageAge(): number | null {
        return this.#maleAverageAge;
    }

    set maleAverageAge(value: number | null) {
        this.#maleAverageAge = value;
    }

    get femaleAverageAge(): number | null {
        return this.#femaleAverageAge;
    }

    set femaleAverageAge(value: number | null) {
        this.#femaleAverageAge = value;
    }

    get neutralAverageAge(): number | null {
        return this.#neutralAverageAge;
    }

    set neutralAverageAge(value: number | null) {
        this.#neutralAverageAge = value;
    }

    get unknownAverageAge(): number | null {
        return this.#unknownAverageAge;
    }

    set unknownAverageAge(value: number | null) {
        this.#unknownAverageAge = value;
    }

    #totalAverageAge: number | null;
    #maleAverageAge: number | null;
    #femaleAverageAge: number | null;
    #neutralAverageAge: number | null;
    #unknownAverageAge: number | null;

    constructor(totalAverageAge: number | null, maleAverageAge: number | null, femaleAverageAge: number | null, neutralAverageAge: number | null, unknownAverageAge: number | null) {
        this.#totalAverageAge = totalAverageAge;
        this.#maleAverageAge = maleAverageAge;
        this.#femaleAverageAge = femaleAverageAge;
        this.#neutralAverageAge = neutralAverageAge;
        this.#unknownAverageAge = unknownAverageAge;
    }
}
