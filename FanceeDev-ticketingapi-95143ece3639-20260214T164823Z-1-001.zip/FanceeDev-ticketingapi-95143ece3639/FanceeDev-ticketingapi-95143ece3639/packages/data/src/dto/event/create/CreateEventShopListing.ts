import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class CreateEventShopListing {
    get code(): string {
        return this.#code;
    }

    get headerMedia(): Media[] {
        return this.#headerMedia;
    }

    get inUse(): boolean {
        return this.#inUse;
    }

    get name(): string {
        return this.#name;
    }

    readonly #code: string;
    readonly #headerMedia: Media[];
    readonly #inUse: boolean;
    readonly #name: string;

    constructor(code: string, headerMedia: Media[], inUse: boolean, name: string) {
        this.#code = code;
        this.#headerMedia = headerMedia;
        this.#inUse = inUse;
        this.#name = name;
    }
}
