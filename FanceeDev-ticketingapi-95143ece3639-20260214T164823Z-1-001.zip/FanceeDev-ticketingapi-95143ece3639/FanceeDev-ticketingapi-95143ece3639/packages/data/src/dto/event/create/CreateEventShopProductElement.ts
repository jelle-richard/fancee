import { Dto } from '@fancee/client';
import { CreateEventShopElement } from '@/dto';
import { ShopElementKind } from '@/enum';

@Dto
export class CreateEventShopProductElement extends CreateEventShopElement {
    get productId(): string {
        return this.#productId;
    }

    readonly #productId: string;

    constructor(productId: string) {
        super(ShopElementKind.Product);
        this.#productId = productId;
    }
}
