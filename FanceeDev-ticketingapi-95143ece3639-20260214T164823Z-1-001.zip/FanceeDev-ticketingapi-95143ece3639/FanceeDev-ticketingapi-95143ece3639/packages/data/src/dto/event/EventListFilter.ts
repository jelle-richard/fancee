import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';
import { Filter } from '@/dto';
import { EventStatus } from '@/enum';

@Dto
export class EventListFilter extends Filter<EventListFilter> {
    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    get states(): EventStatus[] {
        return this.#states;
    }

    set states(value: EventStatus[]) {
        this.#states = value;
    }

    get dateSpan(): [DateTime, DateTime] | null {
        return this.#dateSpan;
    }

    set dateSpan(value: [DateTime, DateTime] | null) {
        this.#dateSpan = value;
    }

    #searchQuery: string;
    #states: EventStatus[];
    #dateSpan: [DateTime, DateTime] | null;

    constructor(searchQuery: string, states: EventStatus[], dateSpan: [DateTime, DateTime] | null) {
        super();
        this.#searchQuery = searchQuery;
        this.#states = states;
        this.#dateSpan = dateSpan;
    }

    public static default(): EventListFilter {
        return new EventListFilter('', [], [DateTime.now().plus({weeks: -1}), DateTime.now().plus({years: 1})]);
    }
}
