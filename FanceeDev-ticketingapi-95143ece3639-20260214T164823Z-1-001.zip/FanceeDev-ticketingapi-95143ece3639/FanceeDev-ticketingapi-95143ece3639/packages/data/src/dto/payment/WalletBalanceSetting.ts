import { Dto } from '@fancee/client';
import { WalletBalance } from '@/dto';

@Dto
export class WalletBalanceSetting {
    get platformCurrencyBalance(): WalletBalance {
        return this.#platformCurrencyBalance;
    }

    set platformCurrencyBalance(value: WalletBalance) {
        this.#platformCurrencyBalance = value;
    }

    get organizationCurrencyBalance(): WalletBalance {
        return this.#organizationCurrencyBalance;
    }

    set organizationCurrencyBalance(value: WalletBalance) {
        this.#organizationCurrencyBalance = value;
    }

    #platformCurrencyBalance: WalletBalance;
    #organizationCurrencyBalance: WalletBalance;

    constructor(platformCurrencyBalance: WalletBalance, organizationCurrencyBalance: WalletBalance) {
        this.#platformCurrencyBalance = platformCurrencyBalance;
        this.#organizationCurrencyBalance = organizationCurrencyBalance;
    }
}
