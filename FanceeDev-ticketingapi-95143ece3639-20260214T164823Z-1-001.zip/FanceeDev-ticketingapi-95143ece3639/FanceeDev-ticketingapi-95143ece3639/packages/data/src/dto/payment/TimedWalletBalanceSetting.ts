import { Dto } from '@fancee/client';
import { WalletBalance } from '@/dto';

@Dto
export class TimedWalletBalanceSetting {
    get dateTime(): string {
        return this.#dateTime;
    }

    set dateTime(value: string) {
        this.#dateTime = value;
    }

    get platformCurrencyBalance(): WalletBalance {
        return this.#platformCurrencyBalance;
    }

    set platformCurrencyBalance(value: WalletBalance) {
        this.#platformCurrencyBalance = value;
    }

    get organizationCurrencyBalance(): WalletBalance {
        return this.#organizationCurrencyBalance;
    }

    set organizationCurrencyBalance(value: WalletBalance) {
        this.#organizationCurrencyBalance = value;
    }

    #dateTime: string;
    #platformCurrencyBalance: WalletBalance;
    #organizationCurrencyBalance: WalletBalance;

    constructor(dateTime: string, platformCurrencyBalance: WalletBalance, organizationCurrencyBalance: WalletBalance) {
        this.#dateTime = dateTime;
        this.#platformCurrencyBalance = platformCurrencyBalance;
        this.#organizationCurrencyBalance = organizationCurrencyBalance;
    }
}
