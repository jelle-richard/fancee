import { Dto } from '@fancee/client';
import { PaidByType } from '@/enum';

@Dto
export class PaymentMethod {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get method(): string {
        return this.#method;
    }

    set method(value: string) {
        this.#method = value;
    }

    get feePercent(): number | null {
        return this.#feePercent;
    }

    set feePercent(value: number | null) {
        this.#feePercent = value;
    }

    get feeStaticCents(): number | null {
        return this.#feeStaticCents;
    }

    set feeStaticCents(value: number | null) {
        this.#feeStaticCents = value;
    }

    get position(): number {
        return this.#position;
    }

    set position(value: number) {
        this.#position = value;
    }

    get paidBy(): PaidByType {
        return this.#paidBy;
    }

    set paidBy(value: PaidByType) {
        this.#paidBy = value;
    }

    get brandCode(): string {
        return this.#brandCode;
    }

    set brandCode(value: string) {
        this.#brandCode = value;
    }

    #id: string;
    #method: string;
    #feePercent: number | null;
    #feeStaticCents: number | null;
    #position: number;
    #paidBy: PaidByType;
    #brandCode: string;

    constructor(id: string, method: string, feePercent: number | null, feeStaticCents: number | null, position: number, paidBy: PaidByType, brandCode: string) {
        this.#id = id;
        this.#method = method;
        this.#feePercent = feePercent;
        this.#feeStaticCents = feeStaticCents;
        this.#position = position;
        this.#paidBy = paidBy;
        this.#brandCode = brandCode;
    }
}
