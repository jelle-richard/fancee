import { Dto } from '@fancee/client';
import { UserType } from '@/enum';

@Dto
export class EventPaymentMethod {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get provider(): string {
        return this.#provider;
    }

    set provider(value: string) {
        this.#provider = value;
    }

    get brandCode(): string {
        return this.#brandCode;
    }

    set brandCode(value: string) {
        this.#brandCode = value;
    }

    get feePercentage(): number | null {
        return this.#feePercentage;
    }

    set feePercentage(value: number | null) {
        this.#feePercentage = value;
    }

    get feeStaticCents(): number | null {
        return this.#feeStaticCents;
    }

    set feeStaticCents(value: number | null) {
        this.#feeStaticCents = value;
    }

    get paidBy(): UserType | null {
        return this.#paidBy;
    }

    set paidBy(value: UserType | null) {
        this.#paidBy = value;
    }

    #id: string;
    #name: string;
    #provider: string;
    #brandCode: string;
    #feePercentage: number | null;
    #feeStaticCents: number | null;
    #paidBy: UserType | null;

    constructor(id: string, name: string, provider: string, brandCode: string, feePercentage: number | null, feeStaticCents: number | null, paidBy: UserType | null) {
        this.#id = id;
        this.#name = name;
        this.#provider = provider;
        this.#brandCode = brandCode;
        this.#feePercentage = feePercentage;
        this.#feeStaticCents = feeStaticCents;
        this.#paidBy = paidBy;
    }
}
