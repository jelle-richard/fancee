import { Dto } from '@fancee/client';
import { Currency } from '@/dto';
import { WalletPaymentType } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class WalletTransaction {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get amountCents(): number {
        return this.#amountCents;
    }

    set amountCents(value: number) {
        this.#amountCents = value;
    }

    get requestedOn(): DateTime {
        return this.#requestedOn;
    }

    set requestedOn(value: DateTime) {
        this.#requestedOn = value;
    }

    get processedOn(): DateTime | null {
        return this.#processedOn;
    }

    set processedOn(value: DateTime | null) {
        this.#processedOn = value;
    }

    get type(): WalletPaymentType {
        return this.#type;
    }

    set type(value: WalletPaymentType) {
        this.#type = value;
    }

    get invoiceId(): number | null {
        return this.#invoiceId;
    }

    set invoiceId(value: number | null) {
        this.#invoiceId = value;
    }

    get fileId(): string | null {
        return this.#fileId;
    }

    set fileId(value: string | null) {
        this.#fileId = value;
    }

    get currency(): Currency {
        return this.#currency;
    }

    set currency(value: Currency) {
        this.#currency = value;
    }

    #id: string;
    #amountCents: number;
    #requestedOn: DateTime;
    #processedOn: DateTime | null;
    #type: WalletPaymentType;
    #invoiceId: number | null;
    #fileId: string | null;
    #currency: Currency;

    constructor(id: string, amountCents: number, requestedOn: DateTime, processedOn: DateTime | null, type: WalletPaymentType, invoiceId: number | null, fileId: string | null, currency: Currency) {
        this.#id = id;
        this.#amountCents = amountCents;
        this.#requestedOn = requestedOn;
        this.#processedOn = processedOn;
        this.#type = type;
        this.#invoiceId = invoiceId;
        this.#fileId = fileId;
        this.#currency = currency;
    }
}
