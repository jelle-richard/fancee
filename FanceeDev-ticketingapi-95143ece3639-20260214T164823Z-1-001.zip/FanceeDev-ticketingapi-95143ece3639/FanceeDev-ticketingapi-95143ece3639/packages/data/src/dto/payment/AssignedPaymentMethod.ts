import { Dto } from '@fancee/client';
import { UserType } from '@/enum';

@Dto
export class AssignedPaymentMethod {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get paidBy(): UserType | null {
        return this.#paidBy;
    }

    set paidBy(value: UserType | null) {
        this.#paidBy = value;
    }

    #id: string;
    #paidBy: UserType | null;

    constructor(id: string, paidBy: UserType | null) {
        this.#id = id;
        this.#paidBy = paidBy;
    }
}
