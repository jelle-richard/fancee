import { Dto } from '@fancee/client';
import { Currency } from '@/dto';

@Dto
export class WalletBalance {
    get currency(): Currency {
        return this.#currency;
    }

    set currency(value: Currency) {
        this.#currency = value;
    }

    get balanceCents(): number {
        return this.#balanceCents;
    }

    set balanceCents(value: number) {
        this.#balanceCents = value;
    }

    get pendingCents(): number {
        return this.#pendingCents;
    }

    set pendingCents(value: number) {
        this.#pendingCents = value;
    }

    get pendingDebitCents(): number {
        return this.#pendingDebitCents;
    }

    set pendingDebitCents(value: number) {
        this.#pendingDebitCents = value;
    }

    get reserveCents(): number {
        return this.#reserveCents;
    }

    set reserveCents(value: number) {
        this.#reserveCents = value;
    }

    #currency: Currency;
    #balanceCents: number;
    #pendingCents: number;
    #pendingDebitCents: number;
    #reserveCents: number;

    constructor(currency: Currency, balanceCents: number, pendingCents: number, pendingDebitCents: number, reserveCents: number) {
        this.#currency = currency;
        this.#balanceCents = balanceCents;
        this.#pendingCents = pendingCents;
        this.#pendingDebitCents = pendingDebitCents;
        this.#reserveCents = reserveCents;
    }
}
