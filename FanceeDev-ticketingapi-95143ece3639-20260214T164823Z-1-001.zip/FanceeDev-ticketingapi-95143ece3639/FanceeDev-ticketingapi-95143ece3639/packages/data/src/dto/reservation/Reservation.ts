import { Dto } from '@fancee/client';

@Dto
export class Reservation {
    get reference(): string {
        return this.#reference;
    }

    set reference(value: string) {
        this.#reference = value;
    }

    get secondsRemaining(): number {
        return this.#secondsRemaining;
    }

    set secondsRemaining(value: number) {
        this.#secondsRemaining = value;
    }

    #reference: string;
    #secondsRemaining: number;

    constructor(reference: string, secondsRemaining: number) {
        this.#reference = reference;
        this.#secondsRemaining = secondsRemaining;
    }
}
