import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class TicketScanStatistics {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get media(): Media {
        return this.#media;
    }

    set media(value: Media) {
        this.#media = value;
    }

    get amountScanned(): number {
        return this.#amountScanned;
    }

    set amountScanned(value: number) {
        this.#amountScanned = value;
    }

    get amountIssued(): number {
        return this.#amountIssued;
    }

    set amountIssued(value: number) {
        this.#amountIssued = value;
    }

    #id: string;
    #name: string;
    #media: Media;
    #amountScanned: number;
    #amountIssued: number;

    constructor(id: string, name: string, media: Media, amountScanned: number, amountIssued: number) {
        this.#id = id;
        this.#name = name;
        this.#media = media;
        this.#amountScanned = amountScanned;
        this.#amountIssued = amountIssued;
    }
}
