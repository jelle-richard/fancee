import { Dto } from '@fancee/client';

@Dto
export class Scan {
    get notification(): string | null {
        return this.#notification;
    }

    set notification(value: string | null) {
        this.#notification = value;
    }

    #notification: string | null;

    constructor(notification: string | null) {
        this.#notification = notification;
    }
}
