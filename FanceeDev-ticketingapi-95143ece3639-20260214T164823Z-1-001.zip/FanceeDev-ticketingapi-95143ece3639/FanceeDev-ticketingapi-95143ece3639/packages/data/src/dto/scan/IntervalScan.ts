import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class IntervalScan {
    get timeInterval(): DateTime {
        return this.#timeInterval;
    }

    set timeInterval(value: DateTime) {
        this.#timeInterval = value;
    }

    get ticketsScanned(): number {
        return this.#ticketsScanned;
    }

    set ticketsScanned(value: number) {
        this.#ticketsScanned = value;
    }

    get ticketsUnscanned(): number {
        return this.#ticketsUnscanned;
    }

    set ticketsUnscanned(value: number) {
        this.#ticketsUnscanned = value;
    }

    #timeInterval: DateTime;
    #ticketsScanned: number;
    #ticketsUnscanned: number;

    constructor(timeInterval: DateTime, ticketsScanned: number, ticketsUnscanned: number) {
        this.#timeInterval = timeInterval;
        this.#ticketsScanned = ticketsScanned;
        this.#ticketsUnscanned = ticketsUnscanned;
    }
}
