import { Dto } from '@fancee/client';
import { IntervalScan } from '@/dto';

@Dto
export class AppTeamScanStatistics {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get intervalScans(): IntervalScan[] {
        return this.#intervalScans;
    }

    set intervalScans(value: IntervalScan[]) {
        this.#intervalScans = value;
    }

    #name: string;
    #intervalScans: IntervalScan[];

    constructor(name: string, intervalScans: IntervalScan[]) {
        this.#name = name;
        this.#intervalScans = intervalScans;
    }
}
