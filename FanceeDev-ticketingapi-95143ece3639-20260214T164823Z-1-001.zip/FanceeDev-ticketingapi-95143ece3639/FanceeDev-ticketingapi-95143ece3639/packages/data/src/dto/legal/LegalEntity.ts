import { Dto } from '@fancee/client';
import { CountryCode } from '@/constant';

@Dto
export class LegalEntity {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get countryCode(): CountryCode | null {
        return this.#countryCode;
    }

    set countryCode(value: CountryCode | null) {
        this.#countryCode = value;
    }

    get chamberOfCommerceIdentifier(): string | null {
        return this.#chamberOfCommerceIdentifier;
    }

    set chamberOfCommerceIdentifier(value: string | null) {
        this.#chamberOfCommerceIdentifier = value;
    }

    get timezoneIdentification(): string | null {
        return this.#timezoneIdentification;
    }

    set timezoneIdentification(value: string | null) {
        this.#timezoneIdentification = value;
    }

    get phoneNumber(): string | null {
        return this.#phoneNumber;
    }

    set phoneNumber(value: string | null) {
        this.#phoneNumber = value;
    }

    #name: string;
    #countryCode: CountryCode | null;
    #chamberOfCommerceIdentifier: string | null;
    #timezoneIdentification: string;
    #phoneNumber: string | null;

    constructor(name: string, countryCode: CountryCode | null, chamberOfCommerceIdentifier: string | null, timezoneIdentification: string, phoneNumber: string | null) {
        this.#name = name;
        this.#countryCode = countryCode;
        this.#chamberOfCommerceIdentifier = chamberOfCommerceIdentifier;
        this.#timezoneIdentification = timezoneIdentification;
        this.#phoneNumber = phoneNumber;
    }

    public static empty(): LegalEntity {
        return new LegalEntity(
            '',
            null,
            null,
            Intl.DateTimeFormat().resolvedOptions().timeZone,
            null
        );
    }
}
