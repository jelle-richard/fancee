import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class RegisterCountryManager {
    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get password(): string {
        return this.#password;
    }

    set password(value: string) {
        this.#password = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    get countryCode(): string {
        return this.#countryCode;
    }

    set countryCode(value: string) {
        this.#countryCode = value;
    }

    get terminatesOn(): DateTime | null {
        return this.#terminatesOn;
    }

    set terminatesOn(value: DateTime | null) {
        this.#terminatesOn = value;
    }

    get claims(): string[] {
        return this.#claims;
    }

    set claims(value: string[]) {
        this.#claims = value;
    }

    #email: string;
    #password: string;
    #firstName: string;
    #lastName: string;
    #countryCode: string;
    #terminatesOn: DateTime | null;
    #claims: string[];

    constructor(email: string, password: string, firstName: string, lastName: string, countryCode: string, terminatesOn: DateTime | null, claims: string[]) {
        this.#email = email;
        this.#password = password;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#countryCode = countryCode;
        this.#terminatesOn = terminatesOn;
        this.#claims = claims;
    }

    public static empty(): RegisterCountryManager {
        return new RegisterCountryManager('', '', '', '', '', null, []);
    }
}
