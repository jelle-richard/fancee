import { Dto } from '@fancee/client';

@Dto
export class RegisterCustomerServiceEmployee {
    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get password(): string {
        return this.#password;
    }

    set password(value: string) {
        this.#password = value;
    }

    get firstName(): string {
        return this.#firstName;
    }

    set firstName(value: string) {
        this.#firstName = value;
    }

    get lastName(): string {
        return this.#lastName;
    }

    set lastName(value: string) {
        this.#lastName = value;
    }

    get countryManagerId(): string {
        return this.#countryManagerId;
    }

    set countryManagerId(value: string) {
        this.#countryManagerId = value;
    }

    get claims(): string[] {
        return this.#claims;
    }

    set claims(value: string[]) {
        this.#claims = value;
    }

    #email: string;
    #password: string;
    #firstName: string;
    #lastName: string;
    #countryManagerId: string;
    #claims: string[];

    constructor(email: string, password: string, firstName: string, lastName: string, countryManagerId: string, claims: string[]) {
        this.#email = email;
        this.#password = password;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#countryManagerId = countryManagerId;
        this.#claims = claims;
    }

    public static empty(): RegisterCustomerServiceEmployee {
        return new RegisterCustomerServiceEmployee('', '', '', '', '', []);
    }
}
