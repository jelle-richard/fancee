import { Dto } from '@fancee/client';
import { CountryManagerListItem } from '@/dto';

@Dto
export class CountryGroupedCountryManagers {
    get countryCode(): string {
        return this.#countryCode;
    }

    set countryCode(value: string) {
        this.#countryCode = value;
    }

    get countryManagers(): CountryManagerListItem[] {
        return this.#countryManagers;
    }

    set countryManagers(value: CountryManagerListItem[]) {
        this.#countryManagers = value;
    }

    #countryCode: string;
    #countryManagers: CountryManagerListItem[];

    constructor(countryCode: string, countryManagers: CountryManagerListItem[]) {
        this.#countryCode = countryCode;
        this.#countryManagers = countryManagers;
    }
}
