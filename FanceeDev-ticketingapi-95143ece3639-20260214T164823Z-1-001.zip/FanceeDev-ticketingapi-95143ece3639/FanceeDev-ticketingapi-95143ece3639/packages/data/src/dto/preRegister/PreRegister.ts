import { Dto } from '@fancee/client';
import { Media } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class PreRegister {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    get expiresOn(): DateTime {
        return this.#expiresOn;
    }

    set expiresOn(value: DateTime) {
        this.#expiresOn = value;
    }

    get headerMedia(): Media | null {
        return this.#headerMedia;
    }

    set headerMedia(value: Media | null) {
        this.#headerMedia = value;
    }

    #code: string;
    #name: string;
    #description: string;
    #expiresOn: DateTime;
    #headerMedia: Media | null;

    constructor(code: string, name: string, description: string, expiresOn: DateTime, headerMedia: Media | null) {
        this.#code = code;
        this.#name = name;
        this.#description = description;
        this.#expiresOn = expiresOn;
        this.#headerMedia = headerMedia;
    }

    public static default(): PreRegister {
        return new PreRegister('', '', '', DateTime.now().plus({month: 1}), null);
    }
}
