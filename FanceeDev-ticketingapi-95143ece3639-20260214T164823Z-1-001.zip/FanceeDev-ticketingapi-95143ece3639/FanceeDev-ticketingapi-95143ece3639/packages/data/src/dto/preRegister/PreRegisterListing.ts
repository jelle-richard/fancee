import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class PreRegisterListing {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get amountRegistered(): number {
        return this.#amountRegistered;
    }

    set amountRegistered(value: number) {
        this.#amountRegistered = value;
    }

    get expiresOn(): DateTime {
        return this.#expiresOn;
    }

    set expiresOn(value: DateTime) {
        this.#expiresOn = value;
    }

    #code: string;
    #name: string;
    #amountRegistered: number;
    #expiresOn: DateTime;

    constructor(code: string, name: string, amountRegistered: number, expiresOn: DateTime) {
        this.#code = code;
        this.#name = name;
        this.#amountRegistered = amountRegistered;
        this.#expiresOn = expiresOn;
    }
}
