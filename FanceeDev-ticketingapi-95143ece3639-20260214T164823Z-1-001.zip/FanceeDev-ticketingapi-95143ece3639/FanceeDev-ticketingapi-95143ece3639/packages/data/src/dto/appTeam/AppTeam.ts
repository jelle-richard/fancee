import { Dto } from '@fancee/client';
import { AppTeamProduct } from '@/dto';

@Dto
export class AppTeam {
    get id(): string | null {
        return this.#id;
    }

    set id(value: string | null) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get scanningEnabled(): boolean {
        return this.#scanningEnabled;
    }

    set scanningEnabled(value: boolean) {
        this.#scanningEnabled = value;
    }

    get salesEnabled(): boolean {
        return this.#salesEnabled;
    }

    set salesEnabled(value: boolean) {
        this.#salesEnabled = value;
    }

    get statisticsEnabled(): boolean {
        return this.#statisticsEnabled;
    }

    set statisticsEnabled(value: boolean) {
        this.#statisticsEnabled = value;
    }

    get cashEnabled(): boolean {
        return this.#cashEnabled;
    }

    set cashEnabled(value: boolean) {
        this.#cashEnabled = value;
    }

    get products(): AppTeamProduct[] {
        return this.#products;
    }

    set products(value: AppTeamProduct[]) {
        this.#products = value;
    }

    get scanGuestlistEnabled(): boolean {
        return this.#scanGuestlistEnabled;
    }

    set scanGuestlistEnabled(value: boolean) {
        this.#scanGuestlistEnabled = value;
    }

    #id: string | null;
    #name: string;
    #scanningEnabled: boolean;
    #salesEnabled: boolean;
    #statisticsEnabled: boolean;
    #cashEnabled: boolean;
    #scanGuestlistEnabled: boolean;
    #products: AppTeamProduct[];

    constructor(id: string | null, name: string, scanningEnabled: boolean, salesEnabled: boolean, statisticsEnabled: boolean, cashEnabled: boolean, scanGuestlistEnabled: boolean, products: AppTeamProduct[]) {
        this.#id = id;
        this.#name = name;
        this.#scanningEnabled = scanningEnabled;
        this.#salesEnabled = salesEnabled;
        this.#statisticsEnabled = statisticsEnabled;
        this.#cashEnabled = cashEnabled;
        this.#scanGuestlistEnabled = scanGuestlistEnabled;
        this.#products = products;
    }

    static empty(): AppTeam {
        return new AppTeam(null, '', false, false, false, false, false, []);
    }
}
