import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class AppTeamProduct {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get media(): Media[] {
        return this.#media;
    }

    set media(value: Media[]) {
        this.#media = value;
    }

    #id: string;
    #name: string;
    #media: Media[];

    constructor(id: string, name: string, media: Media[]) {
        this.#id = id;
        this.#name = name;
        this.#media = media;
    }
}
