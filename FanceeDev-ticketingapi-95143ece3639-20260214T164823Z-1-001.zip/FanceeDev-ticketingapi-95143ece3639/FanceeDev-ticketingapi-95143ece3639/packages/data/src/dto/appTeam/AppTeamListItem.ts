import { Dto } from '@fancee/client';

@Dto
export class AppTeamListItem {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get scanningEnabled(): boolean {
        return this.#scanningEnabled;
    }

    set scanningEnabled(value: boolean) {
        this.#scanningEnabled = value;
    }

    get salesEnabled(): boolean {
        return this.#salesEnabled;
    }

    set salesEnabled(value: boolean) {
        this.#salesEnabled = value;
    }

    get statisticsEnabled(): boolean {
        return this.#statisticsEnabled;
    }

    set statisticsEnabled(value: boolean) {
        this.#statisticsEnabled = value;
    }

    get cashEnabled(): boolean {
        return this.#cashEnabled;
    }

    set cashEnabled(value: boolean) {
        this.#cashEnabled = value;
    }

    #id: string;
    #name: string;
    #scanningEnabled: boolean;
    #salesEnabled: boolean;
    #statisticsEnabled: boolean;
    #cashEnabled: boolean;

    constructor(id: string, name: string, scanningEnabled: boolean, salesEnabled: boolean, statisticsEnabled: boolean, cashEnabled: boolean) {
        this.#id = id;
        this.#name = name;
        this.#scanningEnabled = scanningEnabled;
        this.#salesEnabled = salesEnabled;
        this.#statisticsEnabled = statisticsEnabled;
        this.#cashEnabled = cashEnabled;
    }
}
