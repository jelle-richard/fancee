import { Dto } from '@fancee/client';
import { ConfigurableItem } from '@/dto';

@Dto
export class Configuration {
    get journal(): string {
        return this.#journal;
    }

    set journal(value: string) {
        this.#journal = value;
    }

    get items(): ConfigurableItem[] {
        return this.#items;
    }

    set items(value: ConfigurableItem[]) {
        this.#items = value;
    }

    #journal: string;
    #items: ConfigurableItem[];

    constructor(journal: string, items: ConfigurableItem[]) {
        this.#journal = journal;
        this.#items = items;
    }
}
