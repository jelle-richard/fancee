import { Dto } from '@fancee/client';
import { Filter } from '@/dto';
import { PayOutStatus } from '@/enum';

@Dto
export class PayOutListFilter extends Filter<PayOutListFilter> {
    get status(): PayOutStatus | null {
        return this.#status;
    }

    set status(value: PayOutStatus | null) {
        this.#status = value;
    }

    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    #status: null | PayOutStatus;
    #searchQuery: string;

    constructor(status: PayOutStatus | null, searchQuery: string) {
        super();
        this.#status = status;
        this.#searchQuery = searchQuery;
    }

    public static default(): PayOutListFilter {
        return new PayOutListFilter(null, '');
    }
}
