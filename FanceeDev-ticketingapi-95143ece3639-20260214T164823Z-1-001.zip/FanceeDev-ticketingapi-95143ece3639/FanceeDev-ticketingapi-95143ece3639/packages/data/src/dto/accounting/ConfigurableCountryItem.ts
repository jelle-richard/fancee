import { Dto } from '@fancee/client';

@Dto
export class ConfigurableCountryItem {
    get countryCode(): string | null {
        return this.#countryCode;
    }

    set countryCode(value: string | null) {
        this.#countryCode = value;
    }

    get exactItemCode(): string {
        return this.#exactItemCode;
    }

    set exactItemCode(value: string) {
        this.#exactItemCode = value;
    }

    #countryCode: string | null;
    #exactItemCode: string;

    constructor(countryCode: string | null, exactItemCode: string) {
        this.#countryCode = countryCode;
        this.#exactItemCode = exactItemCode;
    }
}
