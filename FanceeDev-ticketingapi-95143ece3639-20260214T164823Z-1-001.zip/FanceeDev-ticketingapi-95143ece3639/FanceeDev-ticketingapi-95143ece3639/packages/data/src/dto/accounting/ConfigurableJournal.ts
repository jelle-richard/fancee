import { Dto } from '@fancee/client';

@Dto
export class ConfigurableJournal {
    get journal(): string {
        return this.#journal;
    }

    set journal(value: string) {
        this.#journal = value;
    }

    #journal: string;

    constructor(journal: string) {
        this.#journal = journal;
    }
}
