import { Dto } from '@fancee/client';

@Dto
export class Journal {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get currency(): string | null {
        return this.#currency;
    }

    set currency(value: string | null) {
        this.#currency = value;
    }

    get description(): string | null {
        return this.#description;
    }

    set description(value: string | null) {
        this.#description = value;
    }

    #id: string;
    #code: string;
    #currency: string | null;
    #description: string | null;

    constructor(id: string, code: string, currency: string | null, description: string | null) {
        this.#id = id;
        this.#code = code;
        this.#currency = currency;
        this.#description = description;
    }
}

