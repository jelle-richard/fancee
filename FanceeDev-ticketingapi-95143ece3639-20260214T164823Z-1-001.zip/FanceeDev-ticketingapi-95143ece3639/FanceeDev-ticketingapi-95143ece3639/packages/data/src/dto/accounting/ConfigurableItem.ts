import { Dto } from '@fancee/client';
import { ConfigurableCountryItem } from '@/dto';

@Dto
export class ConfigurableItem {
    get platformItem(): string {
        return this.#platformItem;
    }

    set platformItem(value: string) {
        this.#platformItem = value;
    }

    get countryItems(): ConfigurableCountryItem[] {
        return this.#countryItems;
    }

    set countryItems(value: ConfigurableCountryItem[]) {
        this.#countryItems = value;
    }

    #platformItem: string;
    #countryItems: ConfigurableCountryItem[];

    constructor(platformItem: string, countryItems: ConfigurableCountryItem[]) {
        this.#platformItem = platformItem;
        this.#countryItems = countryItems;
    }
}
