import { Dto } from '@fancee/client';
import { ConfigurableItem } from '@/dto';

@Dto
export class ConfigurableItems {
    get items(): ConfigurableItem[] {
        return this.#items;
    }

    set items(value: ConfigurableItem[]) {
        this.#items = value;
    }

    #items: ConfigurableItem[];

    constructor(items: ConfigurableItem[]) {
        this.#items = items;
    }
}
