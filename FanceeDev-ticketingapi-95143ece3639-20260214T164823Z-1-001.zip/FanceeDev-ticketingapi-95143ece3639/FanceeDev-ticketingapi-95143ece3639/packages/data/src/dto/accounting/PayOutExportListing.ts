import { Dto } from '@fancee/client';
import { PayOutStatus } from '@/enum';
import { DateTime } from 'luxon';

@Dto
export class PayOutExportListing {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get status(): PayOutStatus {
        return this.#status;
    }

    set status(value: PayOutStatus) {
        this.#status = value;
    }

    get createdAt(): DateTime {
        return this.#createdAt;
    }

    set createdAt(value: DateTime) {
        this.#createdAt = value;
    }

    #id: string;
    #status: PayOutStatus;
    #createdAt: DateTime;

    constructor(id: string, status: PayOutStatus, createdAt: DateTime) {
        this.#id = id;
        this.#status = status;
        this.#createdAt = createdAt;
    }
}
