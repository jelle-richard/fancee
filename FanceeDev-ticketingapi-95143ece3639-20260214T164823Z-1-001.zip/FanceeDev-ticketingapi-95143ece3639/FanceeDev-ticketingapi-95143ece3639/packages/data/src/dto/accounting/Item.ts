import { Dto } from '@fancee/client';

@Dto
export class Item {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get code(): string | null {
        return this.#code;
    }

    set code(value: string | null) {
        this.#code = value;
    }

    get description(): string | null {
        return this.#description;
    }

    set description(value: string | null) {
        this.#description = value;
    }

    #id: string;
    #code: string | null;
    #description: string | null;

    constructor(id: string, code: string | null, description: string | null) {
        this.#id = id;
        this.#code = code;
        this.#description = description;
    }
}
