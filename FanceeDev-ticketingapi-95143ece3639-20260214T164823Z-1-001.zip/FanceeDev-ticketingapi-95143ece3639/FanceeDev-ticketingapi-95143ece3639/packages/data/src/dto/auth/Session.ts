import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class Session {
    get device(): string {
        return this.#device;
    }

    set device(value: string) {
        this.#device = value;
    }

    get ipAddress(): string {
        return this.#ipAddress;
    }

    set ipAddress(value: string) {
        this.#ipAddress = value;
    }

    get issuedOn(): DateTime {
        return this.#issuedOn;
    }

    set issuedOn(value: DateTime) {
        this.#issuedOn = value;
    }

    get token(): string {
        return this.#token;
    }

    set token(value: string) {
        this.#token = value;
    }

    get validUntil(): DateTime {
        return this.#validUntil;
    }

    set validUntil(value: DateTime) {
        this.#validUntil = value;
    }

    #device: string;
    #ipAddress: string;
    #issuedOn: DateTime;
    #token: string;
    #validUntil: DateTime;

    constructor(device: string, ipAddress: string, issuedOn: DateTime, token: string, validUntil: DateTime) {
        this.#device = device;
        this.#ipAddress = ipAddress;
        this.#issuedOn = issuedOn;
        this.#token = token;
        this.#validUntil = validUntil;
    }
}
