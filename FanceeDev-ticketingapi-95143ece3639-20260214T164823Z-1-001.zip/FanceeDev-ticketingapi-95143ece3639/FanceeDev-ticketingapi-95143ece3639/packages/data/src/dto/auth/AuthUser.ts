import { Dto } from '@fancee/client';
import { Currency, Media } from '@/dto';
import { UserType } from '@/enum';
import { DateTime } from 'luxon';
import { CountryCode } from '@/constant';

@Dto
export class AuthUser {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get email(): string {
        return this.#email;
    }

    set email(value: string) {
        this.#email = value;
    }

    get firstName(): string | null {
        return this.#firstName;
    }

    set firstName(value: string | null) {
        this.#firstName = value;
    }

    get lastName(): string | null {
        return this.#lastName;
    }

    set lastName(value: string | null) {
        this.#lastName = value;
    }

    get type(): UserType | null {
        return this.#type;
    }

    set type(value: UserType | null) {
        this.#type = value;
    }

    get avatarFile(): Media | null {
        return this.#avatarFile;
    }

    set avatarFile(value: Media | null) {
        this.#avatarFile = value;
    }

    get lastLogin(): DateTime | null {
        return this.#lastLogin;
    }

    set lastLogin(value: DateTime | null) {
        this.#lastLogin = value;
    }

    get currency(): Currency | null {
        return this.#currency;
    }

    set currency(value: Currency | null) {
        this.#currency = value;
    }

    get countryCodes(): CountryCode[] {
        return this.#countryCodes;
    }

    set countryCodes(value: CountryCode[]) {
        this.#countryCodes = value;
    }

    get isProfileComplete(): boolean {
        return this.#isProfileComplete;
    }

    set isProfileComplete(value: boolean) {
        this.#isProfileComplete = value;
    }

    get changelogsSinceLastLogin(): number {
        return this.#changelogsSinceLastLogin;
    }

    set changelogsSinceLastLogin(value: number) {
        this.#changelogsSinceLastLogin = value;
    }

    get activeOrganizationId(): string | null {
        return this.#activeOrganizationId;
    }

    set activeOrganizationId(value: string | null) {
        this.#activeOrganizationId = value;
    }

    get publicCode(): string {
        return this.#publicCode;
    }

    set publicCode(value: string) {
        this.#publicCode = value;
    }

    #id: string;
    #email: string;
    #firstName: string | null;
    #lastName: string | null;
    #type: UserType | null;
    #avatarFile: Media | null;
    #lastLogin: DateTime | null;
    #currency: Currency | null;
    #countryCodes: CountryCode[];
    #isProfileComplete: boolean;
    #changelogsSinceLastLogin: number;
    #activeOrganizationId: string | null;
    #publicCode: string;

    constructor(id: string, email: string, firstName: string | null, lastName: string | null, type: UserType | null, avatarFile: Media | null, lastLogin: DateTime | null, currency: Currency | null, countryCodes: CountryCode[], isProfileComplete: boolean, changelogsSinceLastLogin: number, activeOrganizationId: string | null, publicCode: string) {
        this.#id = id;
        this.#email = email;
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#type = type;
        this.#avatarFile = avatarFile;
        this.#lastLogin = lastLogin;
        this.#currency = currency;
        this.#countryCodes = countryCodes;
        this.#isProfileComplete = isProfileComplete;
        this.#changelogsSinceLastLogin = changelogsSinceLastLogin;
        this.#activeOrganizationId = activeOrganizationId;
        this.#publicCode = publicCode;
    }
}
