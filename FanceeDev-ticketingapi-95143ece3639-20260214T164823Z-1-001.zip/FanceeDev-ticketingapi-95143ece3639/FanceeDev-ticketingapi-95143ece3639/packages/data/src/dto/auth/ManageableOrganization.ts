import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class ManageableOrganization {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get avatar(): Media | null {
        return this.#avatar;
    }

    set avatar(value: Media | null) {
        this.#avatar = value;
    }

    get claims(): string[] {
        return this.#claims;
    }

    set claims(value: string[]) {
        this.#claims = value;
    }

    get isOwner(): boolean {
        return this.#isOwner;
    }

    set isOwner(value: boolean) {
        this.#isOwner = value;
    }

    #id: string;
    #name: string;
    #avatar: Media | null;
    #claims: string[];
    #isOwner: boolean;

    constructor(id: string, name: string, avatar: Media | null, claims: string[], isOwner: boolean) {
        this.#id = id;
        this.#name = name;
        this.#avatar = avatar;
        this.#claims = claims;
        this.#isOwner = isOwner;
    }
}
