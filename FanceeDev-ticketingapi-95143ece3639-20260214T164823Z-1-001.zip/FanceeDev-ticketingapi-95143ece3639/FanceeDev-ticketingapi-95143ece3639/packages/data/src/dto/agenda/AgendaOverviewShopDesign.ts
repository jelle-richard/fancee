import { Dto } from '@fancee/client';
import { Media } from '@/dto';

@Dto
export class AgendaOverviewShopDesign {
    get headerImages(): Media[] {
        return this.#headerImages;
    }

    set headerImages(value: Media[]) {
        this.#headerImages = value;
    }

    #headerImages: Media[];

    constructor(headerImages: Media[]) {
        this.#headerImages = headerImages;
    }
}
