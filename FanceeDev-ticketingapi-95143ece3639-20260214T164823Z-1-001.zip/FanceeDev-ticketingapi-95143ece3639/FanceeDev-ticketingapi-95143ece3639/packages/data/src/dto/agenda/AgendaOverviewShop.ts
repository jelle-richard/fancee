import { Dto } from '@fancee/client';
import { AgendaOverviewShopDesign } from '@/dto';

@Dto
export class AgendaOverviewShop {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get headerImageUrl(): string | null {
        return this.#headerImageUrl;
    }

    set headerImageUrl(value: string | null) {
        this.#headerImageUrl = value;
    }

    get design(): AgendaOverviewShopDesign {
        return this.#design;
    }

    set design(value: AgendaOverviewShopDesign) {
        this.#design = value;
    }

    #code: string;
    #name: string;
    #headerImageUrl: string | null;//Todo: Temp fix until Bas sorts out reactivity bug
    #design: AgendaOverviewShopDesign;

    constructor(code: string, name: string, headerImageUrl: string | null, design: AgendaOverviewShopDesign) {
        this.#code = code;
        this.#name = name;
        this.#headerImageUrl = headerImageUrl;
        this.#design = design;
    }
}
