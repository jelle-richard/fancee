import { Dto } from '@fancee/client';
import { AgendaLinkedEvent } from '@/dto';

@Dto
export class AgendaListing {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get showAllActiveEvents(): boolean {
        return this.#showAllActiveEvents;
    }

    set showAllActiveEvents(value: boolean) {
        this.#showAllActiveEvents = value;
    }

    get linkedEvents(): AgendaLinkedEvent[] | null {
        return this.#linkedEvents;
    }

    set linkedEvents(value: AgendaLinkedEvent[] | null) {
        this.#linkedEvents = value;
    }

    #id: string;
    #name: string;
    #showAllActiveEvents: boolean;
    #linkedEvents: AgendaLinkedEvent[] | null;

    constructor(id: string, name: string, showAllActiveEvents: boolean, linkedEvents: AgendaLinkedEvent[] | null) {
        this.#id = id;
        this.#name = name;
        this.#showAllActiveEvents = showAllActiveEvents;
        this.#linkedEvents = linkedEvents;
    }
}
