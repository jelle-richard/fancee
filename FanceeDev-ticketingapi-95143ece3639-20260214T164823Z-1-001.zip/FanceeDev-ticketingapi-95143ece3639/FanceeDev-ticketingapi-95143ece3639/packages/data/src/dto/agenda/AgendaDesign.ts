import { Dto } from '@fancee/client';
import { BRAND_BACKDROP_COLOR, BRAND_BACKGROUND_COLOR, BRAND_PRIMARY_COLOR, BRAND_TEXT_COLOR } from '@/constant';

@Dto
export class AgendaDesign {
    get showHeaders(): true {
        return this.#showHeaders;
    }

    set showHeaders(value: true) {
        this.#showHeaders = value;
    }

    get primaryColor(): string | null {
        return this.#primaryColor;
    }

    set primaryColor(value: string | null) {
        this.#primaryColor = value;
    }

    get textColor(): string | null {
        return this.#textColor;
    }

    set textColor(value: string | null) {
        this.#textColor = value;
    }

    get backdropColor(): string | null {
        return this.#backdropColor;
    }

    set backdropColor(value: string | null) {
        this.#backdropColor = value;
    }

    get backgroundColor(): string | null {
        return this.#backgroundColor;
    }

    set backgroundColor(value: string | null) {
        this.#backgroundColor = value;
    }

    #showHeaders: true;
    #primaryColor: string | null;
    #textColor: string | null;
    #backdropColor: string | null;
    #backgroundColor: string | null;

    constructor(showHeaders: true, primaryColor: string | null, textColor: string | null, backdropColor: string | null, backgroundColor: string | null) {
        this.#showHeaders = showHeaders;
        this.#primaryColor = primaryColor;
        this.#textColor = textColor;
        this.#backdropColor = backdropColor;
        this.#backgroundColor = backgroundColor;
    }

    public static empty(): AgendaDesign {
        return new AgendaDesign(true, BRAND_PRIMARY_COLOR, BRAND_TEXT_COLOR, BRAND_BACKDROP_COLOR, BRAND_BACKGROUND_COLOR);
    }
}
