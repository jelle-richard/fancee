import { Dto } from '@fancee/client';
import { AgendaDesign, AgendaOverviewLinkedEvent } from '@/dto';

@Dto
export class AgendaOverview {
    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get design(): AgendaDesign {
        return this.#design;
    }

    set design(value: AgendaDesign) {
        this.#design = value;
    }

    get linkedEvents(): AgendaOverviewLinkedEvent[] | null {
        return this.#linkedEvents;
    }

    set linkedEvents(value: AgendaOverviewLinkedEvent[] | null) {
        this.#linkedEvents = value;
    }

    get googleAnalyticsId(): string | null {
        return this.#googleAnalyticsId;
    }

    set googleAnalyticsId(value: string | null) {
        this.#googleAnalyticsId = value;
    }

    #id: string;
    #design: AgendaDesign;
    #linkedEvents: AgendaOverviewLinkedEvent[] | null;
    #googleAnalyticsId: string | null;

    constructor(id: string, design: AgendaDesign, linkedEvents: AgendaOverviewLinkedEvent[] | null, googleAnalyticsId: string | null) {
        this.#id = id;
        this.#design = design;
        this.#linkedEvents = linkedEvents;
        this.#googleAnalyticsId = googleAnalyticsId;
    }
}
