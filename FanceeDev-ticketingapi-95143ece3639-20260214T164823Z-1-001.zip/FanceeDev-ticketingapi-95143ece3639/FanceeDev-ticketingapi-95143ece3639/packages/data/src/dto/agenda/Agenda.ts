import { Dto } from '@fancee/client';
import { AgendaDesign } from '@/dto';

@Dto
export class Agenda {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get events(): string[] {
        return this.#events;
    }

    set events(value: string[]) {
        this.#events = value;
    }

    get showAllEvents(): boolean {
        return this.#showAllEvents;
    }

    set showAllEvents(value: boolean) {
        this.#showAllEvents = value;
    }

    get design(): AgendaDesign {
        return this.#design;
    }

    set design(value: AgendaDesign) {
        this.#design = value;
    }

    get active(): boolean {
        return this.#active;
    }

    set active(value: boolean) {
        this.#active = value;
    }

    get googleAnalyticsId(): string | null {
        return this.#googleAnalyticsId;
    }

    set googleAnalyticsId(value: string | null) {
        this.#googleAnalyticsId = value;
    }

    #name: string;
    #events: string[];
    #showAllEvents: boolean;
    #design: AgendaDesign;
    #active: boolean;
    #googleAnalyticsId: string | null;

    constructor(name: string, events: string[], showAllEvents: boolean, design: AgendaDesign, active: boolean, googleAnalyticsId: string | null) {
        this.#name = name;
        this.#events = events;
        this.#showAllEvents = showAllEvents;
        this.#design = design;
        this.#active = active;
        this.#googleAnalyticsId = googleAnalyticsId;
    }

    public static empty(): Agenda {
        return new Agenda(
            '',
            [],
            false,
            AgendaDesign.empty(),
            true,
            null
        );
    }
}
