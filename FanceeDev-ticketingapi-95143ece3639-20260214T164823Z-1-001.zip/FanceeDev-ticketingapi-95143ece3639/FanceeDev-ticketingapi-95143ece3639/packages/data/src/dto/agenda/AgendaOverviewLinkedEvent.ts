import { Dto } from '@fancee/client';
import { Address, AgendaOverviewShop, Media } from '@/dto';
import { DateTime } from 'luxon';

@Dto
export class AgendaOverviewLinkedEvent {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get startDate(): DateTime {
        return this.#startDate;
    }

    set startDate(value: DateTime) {
        this.#startDate = value;
    }

    get endDate(): DateTime {
        return this.#endDate;
    }

    set endDate(value: DateTime) {
        this.#endDate = value;
    }

    get type(): string {
        return this.#type;
    }

    set type(value: string) {
        this.#type = value;
    }

    get id(): string {
        return this.#id;
    }

    set id(value: string) {
        this.#id = value;
    }

    get headerImages(): Media[] {
        return this.#headerImages;
    }

    set headerImages(value: Media[]) {
        this.#headerImages = value;
    }

    get description(): string | null {
        return this.#description;
    }

    set description(value: string | null) {
        this.#description = value;
    }

    get address(): Address | null {
        return this.#address;
    }

    set address(value: Address | null) {
        this.#address = value;
    }

    get shops(): AgendaOverviewShop[] {
        return this.#shops;
    }

    set shops(value: AgendaOverviewShop[]) {
        this.#shops = value;
    }

    #name: string;
    #startDate: DateTime;
    #endDate: DateTime;
    #type: string;
    #id: string;
    #headerImages: Media[];
    #description: string | null;
    #address: Address | null;
    #shops: AgendaOverviewShop[];

    constructor(name: string, startDate: DateTime, endDate: DateTime, type: string, id: string, headerImages: Media[], description: string | null, address: Address | null, shops: AgendaOverviewShop[]) {
        this.#name = name;
        this.#startDate = startDate;
        this.#endDate = endDate;
        this.#type = type;
        this.#id = id;
        this.#headerImages = headerImages;
        this.#description = description;
        this.#address = address;
        this.#shops = shops;
    }
}
