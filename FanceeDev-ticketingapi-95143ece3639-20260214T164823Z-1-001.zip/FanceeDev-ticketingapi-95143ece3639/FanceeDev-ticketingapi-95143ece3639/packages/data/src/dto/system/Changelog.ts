import { Dto } from '@fancee/client';
import { DateTime } from 'luxon';

@Dto
export class Changelog {
    get releaseDate(): DateTime {
        return this.#releaseDate;
    }

    set releaseDate(value: DateTime) {
        this.#releaseDate = value;
    }

    get title(): string {
        return this.#title;
    }

    set title(value: string) {
        this.#title = value;
    }

    get description(): string {
        return this.#description;
    }

    set description(value: string) {
        this.#description = value;
    }

    #releaseDate: DateTime;
    #title: string;
    #description: string;

    constructor(releaseDate: DateTime, title: string, description: string) {
        this.#releaseDate = releaseDate;
        this.#title = title;
        this.#description = description;
    }
}
