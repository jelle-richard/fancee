import { Dto } from '@fancee/client';

@Dto
export class CampaignShop {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    #name: string;
    #code: string;

    constructor(name: string, code: string) {
        this.#name = name;
        this.#code = code;
    }
}
