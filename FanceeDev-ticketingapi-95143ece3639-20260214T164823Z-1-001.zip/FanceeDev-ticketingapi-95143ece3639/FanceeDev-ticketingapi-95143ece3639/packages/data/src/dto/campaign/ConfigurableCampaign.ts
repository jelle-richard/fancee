import { Dto } from '@fancee/client';

@Dto
export class ConfigurableCampaign {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get eventId(): string {
        return this.#eventId;
    }

    set eventId(value: string) {
        this.#eventId = value;
    }

    get shopCodes(): string[] {
        return this.#shopCodes;
    }

    set shopCodes(value: string[]) {
        this.#shopCodes = value;
    }

    #name: string;
    #eventId: string;
    #shopCodes: string[];

    constructor(name: string, eventId: string, shopCodes: string[]) {
        this.#name = name;
        this.#eventId = eventId;
        this.#shopCodes = shopCodes;
    }
}
