import { Dto } from '@fancee/client';
import { CampaignShop } from '@/dto';

@Dto
export class Campaign {
    get code(): string {
        return this.#code;
    }

    set code(value: string) {
        this.#code = value;
    }

    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get eventName(): string {
        return this.#eventName;
    }

    set eventName(value: string) {
        this.#eventName = value;
    }

    get eventId(): string {
        return this.#eventId;
    }

    set eventId(value: string) {
        this.#eventId = value;
    }

    get shops(): CampaignShop[] {
        return this.#shops;
    }

    set shops(value: CampaignShop[]) {
        this.#shops = value;
    }

    get clicks(): number {
        return this.#clicks;
    }

    set clicks(value: number) {
        this.#clicks = value;
    }

    get revenueCents(): number {
        return this.#revenueCents;
    }

    set revenueCents(value: number) {
        this.#revenueCents = value;
    }

    get amountOfSoldTickets(): number {
        return this.#amountOfSoldTickets;
    }

    set amountOfSoldTickets(value: number) {
        this.#amountOfSoldTickets = value;
    }

    get amountOfOrders(): number {
        return this.#amountOfOrders;
    }

    set amountOfOrders(value: number) {
        this.#amountOfOrders = value;
    }

    get amountOfMales(): number {
        return this.#amountOfMales;
    }

    set amountOfMales(value: number) {
        this.#amountOfMales = value;
    }

    get amountOfFemales(): number {
        return this.#amountOfFemales;
    }

    set amountOfFemales(value: number) {
        this.#amountOfFemales = value;
    }

    get amountOfNeutrals(): number {
        return this.#amountOfNeutrals;
    }

    set amountOfNeutrals(value: number) {
        this.#amountOfNeutrals = value;
    }

    get amountOfReservations(): number {
        return this.#amountOfReservations;
    }

    set amountOfReservations(value: number) {
        this.#amountOfReservations = value;
    }

    get averageAge(): number {
        return this.#averageAge;
    }

    set averageAge(value: number) {
        this.#averageAge = value;
    }

    #code: string;
    #name: string;
    #eventName: string;
    #eventId: string;
    #shops: CampaignShop[];
    #clicks: number;
    #revenueCents: number;
    #amountOfSoldTickets: number;
    #amountOfOrders: number;
    #amountOfMales: number;
    #amountOfFemales: number;
    #amountOfNeutrals: number;
    #amountOfReservations: number;
    #averageAge: number;

    constructor(code: string, name: string, eventName: string, eventId: string, shops: CampaignShop[], clicks: number, revenueCents: number, amountOfSoldTickets: number, amountOfOrders: number, amountOfMales: number, amountOfFemales: number, amountOfNeutrals: number, amountOfReservations: number, averageAge: number) {
        this.#code = code;
        this.#name = name;
        this.#eventName = eventName;
        this.#eventId = eventId;
        this.#shops = shops;
        this.#clicks = clicks;
        this.#revenueCents = revenueCents;
        this.#amountOfSoldTickets = amountOfSoldTickets;
        this.#amountOfOrders = amountOfOrders;
        this.#amountOfMales = amountOfMales;
        this.#amountOfFemales = amountOfFemales;
        this.#amountOfNeutrals = amountOfNeutrals;
        this.#amountOfReservations = amountOfReservations;
        this.#averageAge = averageAge;
    }
}
