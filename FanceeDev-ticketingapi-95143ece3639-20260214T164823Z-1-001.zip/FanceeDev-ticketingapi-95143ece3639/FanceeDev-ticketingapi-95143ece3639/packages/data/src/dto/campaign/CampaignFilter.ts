import { Dto } from '@fancee/client';
import { Filter } from '@/dto';

@Dto
export class CampaignFilter extends Filter<CampaignFilter> {
    get searchQuery(): string {
        return this.#searchQuery;
    }

    set searchQuery(value: string) {
        this.#searchQuery = value;
    }

    #searchQuery: string;

    constructor(searchQuery: string) {
        super();
        this.#searchQuery = searchQuery;
    }
}
