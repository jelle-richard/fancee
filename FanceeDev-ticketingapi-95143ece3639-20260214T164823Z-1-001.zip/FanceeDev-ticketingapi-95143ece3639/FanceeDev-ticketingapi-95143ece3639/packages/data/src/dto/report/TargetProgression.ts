import { Dto } from '@fancee/client';

@Dto
export class TargetProgression {
    get target(): number {
        return this.#target;
    }

    set target(value: number) {
        this.#target = value;
    }

    get progress(): number {
        return this.#progress;
    }

    set progress(value: number) {
        this.#progress = value;
    }

    #target: number;
    #progress: number;

    constructor(target: number, progress: number) {
        this.#target = target;
        this.#progress = progress;
    }
}
