import { Dto } from '@fancee/client';

@Dto
export class TicketRevenueIndication {
    get highestDailyTicketSalesAmount(): number {
        return this.#highestDailyTicketSalesAmount;
    }

    set highestDailyTicketSalesAmount(value: number) {
        this.#highestDailyTicketSalesAmount = value;
    }

    get ticketFeeRevenueCentsYesterday(): number {
        return this.#ticketFeeRevenueCentsYesterday;
    }

    set ticketFeeRevenueCentsYesterday(value: number) {
        this.#ticketFeeRevenueCentsYesterday = value;
    }

    get ticketFeeRevenueCentsToday(): number {
        return this.#ticketFeeRevenueCentsToday;
    }

    set ticketFeeRevenueCentsToday(value: number) {
        this.#ticketFeeRevenueCentsToday = value;
    }

    #highestDailyTicketSalesAmount: number;
    #ticketFeeRevenueCentsYesterday: number;
    #ticketFeeRevenueCentsToday: number;

    constructor(highestDailyTicketSalesAmount: number, ticketFeeRevenueCentsYesterday: number, ticketFeeRevenueCentsToday: number) {
        this.#highestDailyTicketSalesAmount = highestDailyTicketSalesAmount;
        this.#ticketFeeRevenueCentsYesterday = ticketFeeRevenueCentsYesterday;
        this.#ticketFeeRevenueCentsToday = ticketFeeRevenueCentsToday;
    }
}
