import { Dto } from '@fancee/client';
import { ClientCost, OrganizationRevenue, PlatformCost, PlatformRevenue, RevenueStatistics } from '@/dto';

@Dto
export class RevenueReportStatistics {
    get clientCost(): ClientCost {
        return this.#clientCost;
    }

    get revenueStatistics(): RevenueStatistics {
        return this.#revenueStatistics;
    }

    get organizationRevenue(): OrganizationRevenue {
        return this.#organizationRevenue;
    }

    get platformRevenue(): PlatformRevenue {
        return this.#platformRevenue;
    }

    get platformCost(): PlatformCost {
        return this.#platformCost;
    }

    readonly #clientCost: ClientCost;
    readonly #revenueStatistics: RevenueStatistics;
    readonly #organizationRevenue: OrganizationRevenue;
    readonly #platformRevenue: PlatformRevenue;
    readonly #platformCost: PlatformCost;

    constructor(clientCost: ClientCost, revenueStatistics: RevenueStatistics, organizationRevenue: OrganizationRevenue, platformRevenue: PlatformRevenue, platformCost: PlatformCost) {
        this.#clientCost = clientCost;
        this.#revenueStatistics = revenueStatistics;
        this.#organizationRevenue = organizationRevenue;
        this.#platformRevenue = platformRevenue;
        this.#platformCost = platformCost;
    }
}
