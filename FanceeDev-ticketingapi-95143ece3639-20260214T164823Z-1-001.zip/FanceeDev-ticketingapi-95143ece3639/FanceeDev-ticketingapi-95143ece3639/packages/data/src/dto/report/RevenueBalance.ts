import { Dto } from '@fancee/client';

@Dto
export class RevenueBalance {
    get month(): number {
        return this.#month;
    }

    set month(value: number) {
        this.#month = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    get seatedTicketFeeCents(): number {
        return this.#seatedTicketFeeCents;
    }

    set seatedTicketFeeCents(value: number) {
        this.#seatedTicketFeeCents = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    get guestListFeeCents(): number {
        return this.#guestListFeeCents;
    }

    set guestListFeeCents(value: number) {
        this.#guestListFeeCents = value;
    }

    get paymentFeeCents(): number {
        return this.#paymentFeeCents;
    }

    set paymentFeeCents(value: number) {
        this.#paymentFeeCents = value;
    }

    get ticketServicePlusCostCents(): number {
        return this.#ticketServicePlusCostCents;
    }

    set ticketServicePlusCostCents(value: number) {
        this.#ticketServicePlusCostCents = value;
    }

    get smsCostCents(): number {
        return this.#smsCostCents;
    }

    set smsCostCents(value: number) {
        this.#smsCostCents = value;
    }

    get chargebackCostCents(): number {
        return this.#chargebackCostCents;
    }

    set chargebackCostCents(value: number) {
        this.#chargebackCostCents = value;
    }

    get refundCostCents(): number {
        return this.#refundCostCents;
    }

    set refundCostCents(value: number) {
        this.#refundCostCents = value;
    }

    get additionalCostCents(): number {
        return this.#additionalCostCents;
    }

    set additionalCostCents(value: number) {
        this.#additionalCostCents = value;
    }

    #month: number;
    #ticketFeeCents: number;
    #seatedTicketFeeCents: number;
    #productFeeCents: number;
    #guestListFeeCents: number;
    #paymentFeeCents: number;
    #ticketServicePlusCostCents: number;
    #smsCostCents: number;
    #chargebackCostCents: number;
    #refundCostCents: number;
    #additionalCostCents: number;

    constructor(month: number, ticketFeeCents: number, seatedTicketFeeCents: number, productFeeCents: number, guestListFeeCents: number, paymentFeeCents: number, ticketServicePlusCostCents: number, smsCostCents: number, chargebackCostCents: number, refundCostCents: number, additionalCostCents: number) {
        this.#month = month;
        this.#ticketFeeCents = ticketFeeCents;
        this.#seatedTicketFeeCents = seatedTicketFeeCents;
        this.#productFeeCents = productFeeCents;
        this.#guestListFeeCents = guestListFeeCents;
        this.#paymentFeeCents = paymentFeeCents;
        this.#ticketServicePlusCostCents = ticketServicePlusCostCents;
        this.#smsCostCents = smsCostCents;
        this.#chargebackCostCents = chargebackCostCents;
        this.#refundCostCents = refundCostCents;
        this.#additionalCostCents = additionalCostCents;
    }

    static emptyTotal(): RevenueBalance {
        return new RevenueBalance(13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
}
