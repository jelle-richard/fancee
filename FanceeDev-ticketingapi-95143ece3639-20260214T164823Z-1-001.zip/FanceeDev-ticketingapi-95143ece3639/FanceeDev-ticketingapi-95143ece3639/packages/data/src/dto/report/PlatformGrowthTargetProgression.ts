import { Dto } from '@fancee/client';
import { TargetProgression } from '@/dto';

@Dto
export class PlatformGrowthTargetProgression {
    get date(): string {
        return this.#date;
    }

    set date(value: string) {
        this.#date = value;
    }

    get tickets(): TargetProgression {
        return this.#tickets;
    }

    set tickets(value: TargetProgression) {
        this.#tickets = value;
    }

    get seatedTickets(): TargetProgression {
        return this.#seatedTickets;
    }

    set seatedTickets(value: TargetProgression) {
        this.#seatedTickets = value;
    }

    get ticketFeeRevenueCents(): TargetProgression {
        return this.#ticketFeeRevenueCents;
    }

    set ticketFeeRevenueCents(value: TargetProgression) {
        this.#ticketFeeRevenueCents = value;
    }

    get seatedTicketFeeRevenueCents(): TargetProgression {
        return this.#seatedTicketFeeRevenueCents;
    }

    set seatedTicketFeeRevenueCents(value: TargetProgression) {
        this.#seatedTicketFeeRevenueCents = value;
    }

    get organizations(): TargetProgression {
        return this.#organizations;
    }

    set organizations(value: TargetProgression) {
        this.#organizations = value;
    }

    get events(): TargetProgression {
        return this.#events;
    }

    set events(value: TargetProgression) {
        this.#events = value;
    }

    get uniqueBuyers(): TargetProgression {
        return this.#uniqueBuyers;
    }

    set uniqueBuyers(value: TargetProgression) {
        this.#uniqueBuyers = value;
    }

    get placedOrders(): TargetProgression {
        return this.#placedOrders;
    }

    set placedOrders(value: TargetProgression) {
        this.#placedOrders = value;
    }

    get fulfilledOrders(): TargetProgression {
        return this.#fulfilledOrders;
    }

    set fulfilledOrders(value: TargetProgression) {
        this.#fulfilledOrders = value;
    }

    #date: string;
    #tickets: TargetProgression;
    #seatedTickets: TargetProgression;
    #ticketFeeRevenueCents: TargetProgression;
    #seatedTicketFeeRevenueCents: TargetProgression;
    #organizations: TargetProgression;
    #events: TargetProgression;
    #uniqueBuyers: TargetProgression;
    #placedOrders: TargetProgression;
    #fulfilledOrders: TargetProgression;

    constructor(date: string, tickets: TargetProgression, seatedTickets: TargetProgression, ticketFeeRevenueCents: TargetProgression, seatedTicketFeeRevenueCents: TargetProgression, organizations: TargetProgression, events: TargetProgression, uniqueBuyers: TargetProgression, placedOrders: TargetProgression, fulfilledOrders: TargetProgression) {
        this.#date = date;
        this.#tickets = tickets;
        this.#seatedTickets = seatedTickets;
        this.#ticketFeeRevenueCents = ticketFeeRevenueCents;
        this.#seatedTicketFeeRevenueCents = seatedTicketFeeRevenueCents;
        this.#organizations = organizations;
        this.#events = events;
        this.#uniqueBuyers = uniqueBuyers;
        this.#placedOrders = placedOrders;
        this.#fulfilledOrders = fulfilledOrders;
    }
}
