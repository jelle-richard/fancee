import { Dto } from '@fancee/client';
import { ReceivedBalance, RevenueBalance } from '@/dto';

@Dto
export class PlatformBalances {
    get receivedBalances(): ReceivedBalance[] {
        return this.#receivedBalances;
    }

    get revenueBalances(): RevenueBalance[] {
        return this.#revenueBalances;
    }

    readonly #receivedBalances: ReceivedBalance[];
    readonly #revenueBalances: RevenueBalance[];

    constructor(receivedBalances: ReceivedBalance[], revenueBalances: RevenueBalance[]) {
        this.#receivedBalances = receivedBalances;
        this.#revenueBalances = revenueBalances;
    }
}
