import { Dto } from '@fancee/client';

@Dto
export class ClientCost {
    get smsFeeCostCents(): number {
        return this.#smsFeeCostCents;
    }

    get ticketServicePlusFeeCostCents(): number {
        return this.#ticketServicePlusFeeCostCents;
    }

    get paymentFeeCostCents(): number {
        return this.#paymentFeeCostCents;
    }

    readonly #smsFeeCostCents: number;
    readonly #ticketServicePlusFeeCostCents: number;
    readonly #paymentFeeCostCents: number;

    constructor(smsFeeCostCents: number, ticketServicePlusFeeCostCents: number, paymentFeeCostCents: number) {
        this.#smsFeeCostCents = smsFeeCostCents;
        this.#ticketServicePlusFeeCostCents = ticketServicePlusFeeCostCents;
        this.#paymentFeeCostCents = paymentFeeCostCents;
    }
}
