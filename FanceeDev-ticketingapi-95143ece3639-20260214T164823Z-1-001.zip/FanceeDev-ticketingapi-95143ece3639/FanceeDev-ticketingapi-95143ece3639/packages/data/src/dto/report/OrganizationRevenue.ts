import { Dto } from '@fancee/client';
import { Revenue } from '@/dto';

@Dto
export class OrganizationRevenue {
    get onlineRevenue(): Revenue {
        return this.#onlineRevenue;
    }

    get cashRevenue(): Revenue {
        return this.#cashRevenue;
    }

    readonly #onlineRevenue: Revenue;
    readonly #cashRevenue: Revenue;

    constructor(onlineRevenue: Revenue, cashRevenue: Revenue) {
        this.#onlineRevenue = onlineRevenue;
        this.#cashRevenue = cashRevenue;
    }
}
