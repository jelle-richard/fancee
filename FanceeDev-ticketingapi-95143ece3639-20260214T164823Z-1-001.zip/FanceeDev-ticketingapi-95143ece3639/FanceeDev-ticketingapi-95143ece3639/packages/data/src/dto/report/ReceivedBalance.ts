import { Dto } from '@fancee/client';
import { IssuedTicketStatistics } from '@/dto';

@Dto
export class ReceivedBalance {
    get month(): number {
        return this.#month;
    }

    set month(value: number) {
        this.#month = value;
    }

    get issuedTickets(): IssuedTicketStatistics {
        return this.#issuedTickets;
    }

    set issuedTickets(value: IssuedTicketStatistics) {
        this.#issuedTickets = value;
    }
    get fulfilledOrders(): number {
        return this.#fulfilledOrders;
    }

    set fulfilledOrders(value: number) {
        this.#fulfilledOrders = value;
    }

    get productIncomeCents(): number {
        return this.#productIncomeCents;
    }

    set productIncomeCents(value: number) {
        this.#productIncomeCents = value;
    }

    get ticketFeeCents(): number {
        return this.#ticketFeeCents;
    }

    set ticketFeeCents(value: number) {
        this.#ticketFeeCents = value;
    }

    get seatedTicketFeeCents(): number {
        return this.#seatedTicketFeeCents;
    }

    set seatedTicketFeeCents(value: number) {
        this.#seatedTicketFeeCents = value;
    }

    get productFeeCents(): number {
        return this.#productFeeCents;
    }

    set productFeeCents(value: number) {
        this.#productFeeCents = value;
    }

    get paymentFeeCents(): number {
        return this.#paymentFeeCents;
    }

    set paymentFeeCents(value: number) {
        this.#paymentFeeCents = value;
    }

    get ticketServicePlusCents(): number {
        return this.#ticketServicePlusCents;
    }

    set ticketServicePlusCents(value: number) {
        this.#ticketServicePlusCents = value;
    }

    get smsCents(): number {
        return this.#smsCents;
    }

    set smsCents(value: number) {
        this.#smsCents = value;
    }

    get refundedCents(): number {
        return this.#refundedCents;
    }

    set refundedCents(value: number) {
        this.#refundedCents = value;
    }

    get chargedBackCents(): number {
        return this.#chargedBackCents;
    }

    set chargedBackCents(value: number) {
        this.#chargedBackCents = value;
    }

    #month: number;
    #issuedTickets: IssuedTicketStatistics;
    #fulfilledOrders: number;
    #productIncomeCents: number;
    #ticketFeeCents: number;
    #seatedTicketFeeCents: number;
    #productFeeCents: number;
    #paymentFeeCents: number;
    #ticketServicePlusCents: number;
    #smsCents: number;
    #refundedCents: number;
    #chargedBackCents: number;

    constructor(month: number, issuedTickets: IssuedTicketStatistics, fulfilledOrders: number, productIncomeCents: number, ticketFeeCents: number, seatedTicketFeeCents: number, productFeeCents: number, paymentFeeCents: number, ticketServicePlusCents: number, smsCents: number, refundedCents: number, chargedBackCents: number) {
        this.#month = month;
        this.#issuedTickets = issuedTickets;
        this.#fulfilledOrders = fulfilledOrders;
        this.#productIncomeCents = productIncomeCents;
        this.#ticketFeeCents = ticketFeeCents;
        this.#seatedTicketFeeCents = seatedTicketFeeCents;
        this.#productFeeCents = productFeeCents;
        this.#paymentFeeCents = paymentFeeCents;
        this.#ticketServicePlusCents = ticketServicePlusCents;
        this.#smsCents = smsCents;
        this.#refundedCents = refundedCents;
        this.#chargedBackCents = chargedBackCents;
    }

    static emptyTotal(): ReceivedBalance {
        return new ReceivedBalance(13, IssuedTicketStatistics.empty(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
}
