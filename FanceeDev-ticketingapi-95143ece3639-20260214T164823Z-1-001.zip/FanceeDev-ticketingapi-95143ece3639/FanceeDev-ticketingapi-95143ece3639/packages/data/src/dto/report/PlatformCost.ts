import { Dto } from '@fancee/client';

@Dto
export class PlatformCost {
    get ticketFeeCostCents(): number {
        return this.#ticketFeeCostCents;
    }

    get seatedTicketFeeCostCents(): number {
        return this.#seatedTicketFeeCostCents;
    }

    get productFeeCostCents(): number {
        return this.#productFeeCostCents;
    }

    get guestListFeeCostCents(): number {
        return this.#guestListFeeCostCents;
    }

    get additionalCostCents(): number {
        return this.#additionalCostCents;
    }

    get paymentFeeCostCents(): number {
        return this.#paymentFeeCostCents;
    }

    readonly #ticketFeeCostCents: number;
    readonly #seatedTicketFeeCostCents: number;
    readonly #productFeeCostCents: number;
    readonly #guestListFeeCostCents: number;
    readonly #additionalCostCents: number;
    readonly #paymentFeeCostCents: number;

    constructor(ticketFeeCostCents: number, seatedTicketFeeCostCents: number, productFeeCostCents: number, guestListFeeCostCents: number, additionalCostCents: number, paymentFeeCostCents: number) {
        this.#ticketFeeCostCents = ticketFeeCostCents;
        this.#seatedTicketFeeCostCents = seatedTicketFeeCostCents;
        this.#productFeeCostCents = productFeeCostCents;
        this.#guestListFeeCostCents = guestListFeeCostCents;
        this.#additionalCostCents = additionalCostCents;
        this.#paymentFeeCostCents = paymentFeeCostCents;
    }
}
