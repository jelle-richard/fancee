import { Dto } from '@fancee/client';
import { IssuedTicketStatistics } from '@/dto';

@Dto
export class RevenueStatistics {
    get issuedProducts(): IssuedTicketStatistics {
        return this.#issuedProducts;
    }

    get totalFulfilledOrders(): number {
        return this.#totalFulfilledOrders;
    }

    readonly #issuedProducts: IssuedTicketStatistics;
    readonly #totalFulfilledOrders: number;

    constructor(issuedProducts: IssuedTicketStatistics, totalFulfilledOrders: number) {
        this.#issuedProducts = issuedProducts;
        this.#totalFulfilledOrders = totalFulfilledOrders;
    }
}
