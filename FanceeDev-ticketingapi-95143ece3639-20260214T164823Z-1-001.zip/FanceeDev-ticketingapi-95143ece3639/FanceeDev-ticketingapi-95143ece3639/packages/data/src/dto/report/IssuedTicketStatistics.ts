import { Dto } from '@fancee/client';

@Dto
export class IssuedTicketStatistics {
    get platformShopProducts(): number {
        return this.#platformShopProducts;
    }

    set platformShopProducts(value: number) {
        this.#platformShopProducts = value;
    }

    get platformAppProducts(): number {
        return this.#platformAppProducts;
    }

    set platformAppProducts(value: number) {
        this.#platformAppProducts = value;
    }

    get platformImportedProducts(): number {
        return this.#platformImportedProducts;
    }

    set platformImportedProducts(value: number) {
        this.#platformImportedProducts = value;
    }

    get platformGuestlistProducts(): number {
        return this.#platformGuestlistProducts;
    }

    set platformGuestlistProducts(value: number) {
        this.#platformGuestlistProducts = value;
    }

    get platformGeneratedProducts(): number {
        return this.#platformGeneratedProducts;
    }

    set platformGeneratedProducts(value: number) {
        this.#platformGeneratedProducts = value;
    }

    get ticketSwapProducts(): number {
        return this.#ticketSwapProducts;
    }

    set ticketSwapProducts(value: number) {
        this.#ticketSwapProducts = value;
    }

    #platformShopProducts: number;
    #platformAppProducts: number;
    #platformImportedProducts: number;
    #platformGuestlistProducts: number;
    #platformGeneratedProducts: number;
    #ticketSwapProducts: number;

    constructor(platformShopProducts: number, platformAppProducts: number, platformImportedProducts: number, platformGuestlistProducts: number, platformGeneratedProducts: number, ticketSwapProducts: number) {
        this.#platformShopProducts = platformShopProducts;
        this.#platformAppProducts = platformAppProducts;
        this.#platformImportedProducts = platformImportedProducts;
        this.#platformGuestlistProducts = platformGuestlistProducts;
        this.#platformGeneratedProducts = platformGeneratedProducts;
        this.#ticketSwapProducts = ticketSwapProducts;
    }

    static empty(): IssuedTicketStatistics {
        return new IssuedTicketStatistics(0, 0, 0, 0, 0, 0);
    }

    public total(): number {
        return this.platformShopProducts + this.platformAppProducts + this.platformImportedProducts + this.platformGuestlistProducts + this.platformGeneratedProducts + this.ticketSwapProducts;
    }

    public add(addableTicketStatistics: IssuedTicketStatistics): IssuedTicketStatistics {
        return new IssuedTicketStatistics(
            this.platformShopProducts + addableTicketStatistics.platformShopProducts,
            this.platformAppProducts + addableTicketStatistics.platformAppProducts,
            this.platformImportedProducts + addableTicketStatistics.platformImportedProducts,
            this.platformGuestlistProducts + addableTicketStatistics.platformGuestlistProducts,
            this.platformGeneratedProducts + addableTicketStatistics.platformGeneratedProducts,
            this.ticketSwapProducts + addableTicketStatistics.ticketSwapProducts
        );
    }
}
