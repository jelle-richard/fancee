import { Dto } from '@fancee/client';

@Dto
export class Revenue {
    get recetteCents(): number {
        return this.#recetteCents;
    }

    get administrationFeeCents(): number {
        return this.#administrationFeeCents;
    }

    get discountCents(): number {
        return this.#discountCents;
    }

    readonly #recetteCents: number;
    readonly #administrationFeeCents: number;
    readonly #discountCents: number;

    constructor(recetteCents: number, administrationFeeCents: number, discountCents: number) {
        this.#recetteCents = recetteCents;
        this.#administrationFeeCents = administrationFeeCents;
        this.#discountCents = discountCents;
    }
}
