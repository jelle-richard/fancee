import { isDto, markDtoClean, PROPERTIES } from '@fancee/client';

const IGNORED_PROPERTIES = ['defaults', 'fields', 'isResettable', 'resettable'];

export abstract class Filter<T extends Filter<T> & object> {
    get defaults(): Record<string, unknown> {
        return this.#defaults;
    }

    get fields(): string[] {
        return this.#fields;
    }

    get isResettable(): boolean {
        return this.resettable.length > 0;
    }

    get resettable(): string[] {
        return this.#fields.filter(field => {
            if (Array.isArray(this[field])) {
                return this[field].some((_: any, index: number) => String(this[field]?.[index]) !== String(this.#defaults[field]?.[index]));
            }

            return this[field] !== this.#defaults[field];
        });
    }

    readonly #defaults: Record<string, unknown>;
    readonly #fields: string[];

    protected constructor() {
        if (!isDto(this)) {
            throw new Error('[@fancee/data] Extending filter class should be a DTO.');
        }

        this.#defaults = {};
        this.#fields = [];

        requestAnimationFrame(() => this.#checkDefaults());
    }

    reset(field?: string): void {
        if (field) {
            this[field] = this.defaults[field];
            return;
        }

        for (const field of this.fields) {
            this[field] = this.defaults[field];
        }

        markDtoClean(this);
    }

    #checkDefaults(): void {
        this.#fields.push(
            ...this[PROPERTIES].filter((property: string) => !IGNORED_PROPERTIES.includes(property))
        );

        for (const field of this.#fields) {
            if (Array.isArray(this[field])) {
                this.#defaults[field] = Array.from(this[field]);
            } else {
                this.#defaults[field] = this[field];
            }
        }
    }
}
