import { Dto } from '@fancee/client';

@Dto
export class Currency {
    get name(): string {
        return this.#name;
    }

    set name(value: string) {
        this.#name = value;
    }

    get character(): string {
        return this.#character;
    }

    set character(value: string) {
        this.#character = value;
    }

    get shortCode(): string {
        return this.#shortCode;
    }

    set shortCode(value: string) {
        this.#shortCode = value;
    }

    get decimals(): number {
        return this.#decimals;
    }

    set decimals(value: number) {
        this.#decimals = value;
    }

    #name: string;
    #character: string;
    #shortCode: string;
    #decimals: number;

    constructor(name: string, character: string, shortCode: string, decimals: number) {
        this.#name = name;
        this.#character = character;
        this.#shortCode = shortCode;
        this.#decimals = decimals;
    }
}
