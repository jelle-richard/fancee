export const DATE_TIME = 'yyyy-MM-dd HH:mm:ss';
export const LUXON_DATE_FORMAT: string = 'yyyy-MM-dd';
export const LUXON_DATE_TIME_FORMAT: string = 'yyyy-MM-dd HH:mm';
