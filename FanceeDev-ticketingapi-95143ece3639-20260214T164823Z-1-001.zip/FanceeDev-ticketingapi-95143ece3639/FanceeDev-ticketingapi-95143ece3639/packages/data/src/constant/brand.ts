export const BRAND_PRIMARY_COLOR = '#6071B5';
export const BRAND_TEXT_COLOR = '#0c0019';
export const BRAND_BACKDROP_COLOR = '#ffffff';
export const BRAND_BACKGROUND_COLOR = '#f1f5f9';
