import { Adapter } from '@fancee/client';
import { DateTimeAdapter, MediaAdapter, ShopAdapter } from '@/adapter';
import { ShopElement, ShopElementAccordion, ShopElementDivider, ShopElementExternalLink, ShopElementNotice, ShopElementProduct, ShopElementSeatingMap, ShopElementTextBlock } from '@/dto';
import { ShopElementKind } from '@/enum';

@Adapter
export class ShopElementAdapter {
    public static parseFromObject(elements: object[]): ShopElement[] {
        return elements
            .map(element => {
                switch (element['kind']) {
                    case ShopElementKind.Accordion:
                        return new ShopElementAccordion(
                            ShopElementAdapter.parseFromObject(element['elements']),
                            element['icon'],
                            element['opened'],
                            element['title']
                        );

                    case ShopElementKind.Divider:
                        return new ShopElementDivider(element['name']);

                    case ShopElementKind.ExternalLink:
                        return new ShopElementExternalLink(
                            element['link'],
                            element['name']
                        );

                    case ShopElementKind.Notice:
                        return new ShopElementNotice(
                            element['content'],
                            element['variant'].toLowerCase()
                        );

                    case ShopElementKind.Product:
                        return new ShopElementProduct(
                            element['id'],
                            element['description'],
                            element['media'].map(MediaAdapter.parseMediaFromObject),
                            element['name'],
                            element['packQuantity'],
                            element['priceCents'],
                            element['feeCents'],
                            element['reservableQuantity'],
                            ShopAdapter.parseProductType(element['type']),
                            DateTimeAdapter.parseStartEndDateToDateTimeSpan(element['saleStart'], element['saleEnd']),
                            element['hasPendingReservations']
                        );

                    case ShopElementKind.SeatingMap:
                        return new ShopElementSeatingMap();

                    case ShopElementKind.TextBlock:
                        return new ShopElementTextBlock(
                            element['text'],
                            element['title']
                        );

                    default:
                        return null;
                }
            })
            .filter(element => !!element);
    }
}
