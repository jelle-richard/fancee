import { Adapter } from '@fancee/client';
import { CombinedShop, CombinedShopListing, CombinedShopItem, SharedShopListing, ShopsSharedWithMeListing } from '@/dto';
import { ColorAdapter, MediaAdapter, ShopAdapter } from '@/adapter';
import { BRAND_BACKDROP_COLOR, BRAND_BACKGROUND_COLOR, BRAND_PRIMARY_COLOR, BRAND_TEXT_COLOR } from '@/constant';

@Adapter
export class CombinedShopAdapter {
    public static parseCombinedShopListingFromObject(combinedShopListing: object): CombinedShopListing {
        return new CombinedShopListing(
            combinedShopListing['code'],
            combinedShopListing['name'],
            combinedShopListing['isActive'],
            combinedShopListing['shopsAmount']
        );
    }

    public static parseSharedShopListingFromObject(sharedShopListing: object): SharedShopListing {
        return new SharedShopListing(
            sharedShopListing['eventName'],
            sharedShopListing['eventStartDate'],
            sharedShopListing['shopName'],
            sharedShopListing['organizationName'],
            sharedShopListing['sharedOn']
        );
    }

    public static parseCombinedShopToApi(shop: CombinedShop): object {
        return {
            title: shop.title,
            description: shop.description,
            active: shop.active,
            analytics: ShopAdapter.parseShopAnalyticsToApi(shop.analytics),
            shopCodes: shop.shopCodes,
            primaryColor: (shop.primaryColor == null ? BRAND_PRIMARY_COLOR : shop.primaryColor).replaceAll('#', ''),
            textColor: (shop.textColor == null ? BRAND_TEXT_COLOR : shop.textColor).replaceAll('#', ''),
            backdropColor: (shop.backdropColor == null ? BRAND_BACKDROP_COLOR : shop.backdropColor).replaceAll('#', ''),
            backgroundColor: (shop.backgroundColor == null ? BRAND_BACKGROUND_COLOR : shop.backgroundColor).replaceAll('#', '')
        };
    }

    public static parseCombinedShopFromObject(shop: object): CombinedShop {
        return new CombinedShop(
            shop['title'],
            shop['description'],
            shop['active'],
            ShopAdapter.parseShopAnalyticsFromObject(shop['analytics']),
            shop['shopCodes'],
            shop['headerMedia'].map(MediaAdapter.parseMediaFromObject),
            shop['primaryColor'] == null ? BRAND_PRIMARY_COLOR : ColorAdapter.parseColor(shop['primaryColor']),
            shop['textColor'] == null ? BRAND_TEXT_COLOR : ColorAdapter.parseColor(shop['textColor']),
            shop['backdropColor'] == null ? BRAND_BACKDROP_COLOR : ColorAdapter.parseColor(shop['backdropColor']),
            shop['backgroundColor'] == null ? BRAND_BACKGROUND_COLOR : ColorAdapter.parseColor(shop['backgroundColor'])
        );
    }

    public static parseSharedWithMeListingFromObject(shopSharedWithMeListing: object): ShopsSharedWithMeListing {
        return new ShopsSharedWithMeListing(
            shopSharedWithMeListing['shopName'],
            shopSharedWithMeListing['organizationId'],
            shopSharedWithMeListing['organizationName'],
            shopSharedWithMeListing['combinedShops'].map(CombinedShopAdapter.parseCombinedShopsFromObject)
        );
    }

    public static parseCombinedShopsFromObject(combinedShop: object): CombinedShopItem {
        return new CombinedShopItem(
            combinedShop['code'],
            combinedShop['name'],
            combinedShop['active']
        );
    }
}
