export { CombinedShopAdapter } from './CombinedShopAdapter';
