import { Adapter } from '@fancee/client';
import { DateTimeAdapter } from '@/adapter';
import { SecureCode, SecureCodeListing } from '@/dto';

@Adapter
export class SecureCodeAdapter {
    public static parseSecureCodeToObject(secureCode: SecureCode): object {
        return {
            secureCode: secureCode.code,
            maximumUses: secureCode.maximumUses,
            active: secureCode.active
        };
    }

    public static parseSecureCodeListingFromObject(secureCode: object): SecureCodeListing {
        return new SecureCodeListing(
            secureCode['secureCode'],
            secureCode['active'],
            secureCode['maximumUses'],
            secureCode['usedAmount'],
            secureCode['pendingAmount'],
            DateTimeAdapter.parseDateTimeStringToLocal(secureCode['createdOn'])
        );
    }
}
