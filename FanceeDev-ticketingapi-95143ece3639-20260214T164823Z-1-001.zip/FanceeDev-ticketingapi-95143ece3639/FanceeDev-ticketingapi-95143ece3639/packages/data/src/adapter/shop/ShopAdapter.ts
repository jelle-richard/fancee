import { Adapter } from '@fancee/client';
import { ColorAdapter, EventAdapter, MediaAdapter, ShopElementAdapter } from '@/adapter';
import { BRAND_BACKDROP_COLOR, BRAND_BACKGROUND_COLOR, BRAND_PRIMARY_COLOR, BRAND_TEXT_COLOR } from '@/constant';
import { ReservedProduct, SeatedProduct, ShopAnalytics, ShopDesign, ShopDetails, ShopFieldRequirement } from '@/dto';
import { ProductOrigin, ProductType, ShopField } from '@/enum';

@Adapter
export class ShopAdapter {
    public static parseFromObject(shop: object): ShopDetails {
        return new ShopDetails(
            EventAdapter.parseShopEventFromObject(shop['event']),
            ShopElementAdapter.parseFromObject(shop['elements']),
            ShopAdapter.parseShopDesignFromObject(shop['design']),
            shop['secured'],
            shop['platformSmsCostCents'],
            shop['platformTicketServicePlusCostCents'],
            shop['shopFields'].map(ShopAdapter.parseShopFieldRequirementFromObject),
            ShopAdapter.parseShopAnalyticsFromObject(shop),
            shop['seatedProducts'] !== null ? shop['seatedProducts'].map(ShopAdapter.parseShopSeatedProductFromObject) : null
        );
    }

    public static parseShopAnalyticsFromObject(shopAnalytics: object): ShopAnalytics {
        return new ShopAnalytics(
            shopAnalytics['googleAnalyticsId'],
            shopAnalytics['googleTagManagerId'],
            shopAnalytics['tiktokPixelId'],
            shopAnalytics['facebookPixelId'],
            shopAnalytics['facebookAccessCode']
        );
    }

    public static parseShopSeatedProductFromObject(product: object): SeatedProduct {
        return new SeatedProduct(
            product['productId'],
            product['seatsIoCategoryId'],
            product['name'],
            product['description'],
            product['reservableQuantity'],
            product['feeCents'],
            product['priceCents']
        );
    }

    public static parseShopFieldRequirementFromObject(shopFieldRequirement: object): ShopFieldRequirement {
        return new ShopFieldRequirement(
            ShopAdapter.parseShopFieldFromString(shopFieldRequirement['field']),
            shopFieldRequirement['enabled'],
            shopFieldRequirement['required']
        );
    }

    public static parseShopFieldFromString(shopField: string): ShopField {
        switch (shopField.toLowerCase()) {
            case 'email':
                return ShopField.Email;

            case 'gender':
                return ShopField.Gender;

            case 'firstname':
                return ShopField.FirstName;

            case 'lastname':
                return ShopField.LastName;

            case 'street':
                return ShopField.Street;

            case 'city':
                return ShopField.City;

            case 'country':
                return ShopField.Country;

            case 'phone':
                return ShopField.Phone;

            case 'birthdate':
                return ShopField.Birthdate;

            case 'address':
                return ShopField.Address;
        }
    }

    public static parseShopDesignFromObject(design: object): ShopDesign {
        return new ShopDesign(
            design['headerMedia'].map(MediaAdapter.parseMediaFromObject),
            design['primaryColor'] === null ? null : ColorAdapter.parseColor(design['primaryColor']),
            design['textColor'] === null ? null : ColorAdapter.parseColor(design['textColor']),
            design['backdropColor'] === null ? null : ColorAdapter.parseColor(design['backdropColor']),
            design['backgroundColor'] === null ? null : ColorAdapter.parseColor(design['backgroundColor'])
        );
    }

    public static parseShopAnalyticsToApi(shopAnalytics: ShopAnalytics): object {
        return {
            googleAnalyticsId: shopAnalytics.googleAnalyticsId,
            googleTagManagerId: shopAnalytics.googleTagManagerId,
            tiktokPixelId: shopAnalytics.tiktokPixelId,
            facebookPixelId: shopAnalytics.facebookPixelId,
            facebookAccessCode: shopAnalytics.facebookAccessCode
        };
    }

    public static parseShopFieldToApi(shopField: ShopFieldRequirement): object {
        return {
            field: shopField.field,
            enabled: shopField.enabled,
            required: shopField.required
        };
    }

    public static parseShopDesignToApi(design: ShopDesign): object {
        return {
            primaryColor: (design.primaryColor ?? BRAND_PRIMARY_COLOR).replaceAll('#', ''),
            textColor: (design.textColor ?? BRAND_TEXT_COLOR).replaceAll('#', ''),
            backdropColor: (design.backdropColor ?? BRAND_BACKDROP_COLOR).replaceAll('#', ''),
            backgroundColor: (design.backgroundColor ?? BRAND_BACKGROUND_COLOR).replaceAll('#', '')
        };
    }

    public static parseProductOrigin(origin: string): ProductOrigin {
        switch (origin.toLowerCase()) {
            case 'platformapp':
                return ProductOrigin.PlatformApp;

            case 'platformgenerated':
                return ProductOrigin.PlatformGenerated;

            case 'platformimported':
                return ProductOrigin.PlatformImported;

            case 'platformguestlist':
                return ProductOrigin.PlatformGuestList;

            case 'twentyfourandmoreapp':
                return ProductOrigin.TwentyFourAndMoreApp;

            case 'ticketswap':
                return ProductOrigin.TicketSwap;

            case 'platformshop':
            default:
                return ProductOrigin.PlatformShop;
        }
    }

    public static parseProductType(type: string): ProductType {
        switch (type.toLowerCase()) {
            case 'product':
                return ProductType.Product;

            case 'ticket':
            default:
                return ProductType.Ticket;
        }
    }

    public static parseReservedProductToApi(product: ReservedProduct): object {
        if (product.seatLabels.length > 0) {
            return {
                productId: product.productId,
                quantity: product.quantity,
                seatsIoObjectIds: product.seatLabels
            };
        }

        return {
            productId: product.productId,
            quantity: product.quantity
        };
    }
}
