import { Adapter } from '@fancee/client';
import { DateTimeAdapter } from '@/adapter';
import { ApplicableDiscount, Discount, DiscountListItem } from '@/dto';

@Adapter
export class DiscountAdapter {
    public static parseDiscountFromObject(discount: object): Discount {
        return new Discount(
            discount['code'],
            discount['stock'],
            discount['used'],
            discount['amountPercentual'],
            discount['amountStaticCents'],
            discount['assignedShopCodes'],
            discount['assignedProductIds'],
            DateTimeAdapter.parseDateTimeStringToLocal(discount['createdOn']),
            DateTimeAdapter.parseDateTimeStringToLocal(discount['expiresOn'])
        );
    }

    public static parseDiscountListItemFromObject(discountListItem: object): DiscountListItem {
        return new DiscountListItem(
            discountListItem['id'],
            discountListItem['code'],
            discountListItem['stock'],
            discountListItem['used'],
            discountListItem['amountPercentual'],
            discountListItem['amountStaticCents'],
            DateTimeAdapter.parseDateTimeStringToLocal(discountListItem['createdOn']),
            DateTimeAdapter.parseDateTimeStringToLocal(discountListItem['expiresOn'])
        );
    }

    public static toDiscountRequest(discount: Discount): object {
        return {
            code: discount.code,
            stock: discount.stock,
            amountPercentual: discount.amountPercentual,
            amountStaticCents: discount.amountStaticCents === 0 ? null : discount.amountStaticCents,
            assignedShopCodes: discount.assignedShopCodes,
            assignedProductIds: discount.assignedProductIds,
            expiresOn: DateTimeAdapter.parseDateTimeToApi(discount.expiresOn)
        };
    }

    public static applicableDiscountFromObject(discount: object): ApplicableDiscount {
        return new ApplicableDiscount(
            discount['discountCode'],
            discount['amountPercentual'],
            discount['amountStaticCents'],
            discount['isApplicableToShop'],
            discount['matchingProductIds']
        );
    }
}
