export { DiscountAdapter } from './DiscountAdapter';
