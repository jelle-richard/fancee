import { Adapter, FanceeClient } from '@fancee/client';
import { DateTime } from 'luxon';
import { DATE_TIME } from '@/constant';
import { DateTimeSpan } from '@/dto';

@Adapter
export class DateTimeAdapter {
    public static now(): DateTime {
        return DateTime
            .now()
            .setZone(FanceeClient.instance.timezone);
    }

    public static parseDateTimeStringToLocal(dateTime: string): DateTime {
        return DateTime
            .fromSQL(dateTime, {zone: 'UTC'})
            .setZone(FanceeClient.instance.timezone);
    }

    public static parseDateTimeToApi(dateTime: DateTime): string {
        return dateTime
            .setZone('UTC')
            .toFormat(DATE_TIME);
    }

    public static parseStartEndDateToDateTimeSpan(start: DateTime | string | null, end: DateTime | string | null): DateTimeSpan {
        if (typeof start === 'string' && !DateTime.isDateTime(start)) {
            start = DateTimeAdapter.parseDateTimeStringToLocal(start);
        }

        if (typeof end === 'string' && !DateTime.isDateTime(end)) {
            end = DateTimeAdapter.parseDateTimeStringToLocal(end);
        }

        return new DateTimeSpan(start, end);
    }
}
