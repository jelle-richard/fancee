import { Adapter } from '@fancee/client';
import { Reservation } from '@/dto';

@Adapter
export class ReservationAdapter {
    public static parseReservationFromObject(reservation: object): Reservation {
        return new Reservation(
            reservation['reference'],
            reservation['secondsRemaining']
        );
    }
}
