export { PreRegisterAdapter } from './PreRegisterAdapter';
