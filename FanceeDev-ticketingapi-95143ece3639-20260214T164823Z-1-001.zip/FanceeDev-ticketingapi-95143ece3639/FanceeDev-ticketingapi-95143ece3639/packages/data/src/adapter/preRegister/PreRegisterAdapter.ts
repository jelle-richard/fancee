import { Adapter } from '@fancee/client';
import { DateTimeAdapter, MediaAdapter } from '@/adapter';
import { PreRegister, PreRegisterListing, PreRegisterSignUp } from '@/dto';

@Adapter
export class PreRegisterAdapter {
    public static parsePreRegister(preRegister: object): PreRegister {
        return new PreRegister(
            preRegister['code'],
            preRegister['name'],
            preRegister['description'],
            preRegister['expiresOn'] === null ? DateTimeAdapter.now() : DateTimeAdapter.parseDateTimeStringToLocal(preRegister['expiresOn']),
            MediaAdapter.parseMediaFromObject(preRegister['headerMedia'])
        );
    }

    public static parsePreRegisterListFromObject(preRegister: object): PreRegisterListing {
        return new PreRegisterListing(
            preRegister['code'],
            preRegister['name'],
            preRegister['amountRegistered'],
            DateTimeAdapter.parseDateTimeStringToLocal(preRegister['expiresOn'])
        );
    }

    public static parsePreRegisterToApiScheme(preRegister: PreRegister): object {
        return {
            name: preRegister.name,
            expiresOn: preRegister.expiresOn === null ? null : DateTimeAdapter.parseDateTimeToApi((preRegister.expiresOn)),
            description: preRegister.description
        };
    }

    public static parseSignUpToApiScheme(code: string, signUp: PreRegisterSignUp): object {
        return {
            code: code,
            email: signUp.email,
            firstName: signUp.firstName,
            lastName: signUp.lastName
        };
    }
}
