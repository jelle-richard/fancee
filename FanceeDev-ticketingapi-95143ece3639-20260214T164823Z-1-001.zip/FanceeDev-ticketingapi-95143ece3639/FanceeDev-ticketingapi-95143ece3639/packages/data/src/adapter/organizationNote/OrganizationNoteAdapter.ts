import { Adapter } from '@fancee/client';
import { DateTimeAdapter, MediaAdapter } from '@/adapter';
import { OrganizationNote, OrganizationNoteRequest } from '@/dto';

@Adapter
export class OrganizationNoteAdapter {
    public static parseOrganizationNoteFromObject(note: object): OrganizationNote {
        return new OrganizationNote(
            note['id'],
            note['adminEmail'],
            note['adminFirstName'],
            note['adminLastName'],
            note['description'],
            DateTimeAdapter.parseDateTimeStringToLocal(note['placedOn']),
            note['files'].map(MediaAdapter.parseMediaFromObject)
        );
    }

    public static parseFormDataFromNoteRequest(request: OrganizationNoteRequest): FormData {
        const form = new FormData();

        form.append('description', request.description);
        request.media.forEach(m => form.append('media', m));

        return form;
    }
}
