export { OrganizationNoteAdapter } from './OrganizationNoteAdapter';
