import { Adapter } from '@fancee/client';
import { AddressAdapter, CurrencyAdapter, DateTimeAdapter, LegalAdapter, MediaAdapter } from '@/adapter';
import { ManagedBy, Organization, OrganizationAccount, OrganizationContact, OrganizationContract, OrganizationContractAddendum, OrganizationContractAlter, OrganizationFinanceDetails, OrganizationHolder, OrganizationListing, OrganizationProfile } from '@/dto';
import { ContactType } from '@/enum';

@Adapter
export class OrganizationAdapter {
    public static parseOrganizationHolderFromObject(holder: object): OrganizationHolder {
        return new OrganizationHolder(
            holder['email'],
            holder['firstName'],
            holder['lastName']
        );
    }

    public static parseOrganizationFromObject(organization: object): Organization {
        return new Organization(
            organization['name'],
            organization['avatar']
        );
    }

    public static parseOrganizationContactFromObject(contact: object): OrganizationContact {
        return new OrganizationContact(
            contact['id'],
            contact['email'],
            contact['firstName'],
            contact['lastName'],
            contact['phoneNumber'],
            OrganizationAdapter.parseOrganizationContactRole(contact['role'])
        );
    }

    public static parseOrganizationContactToApi(contact: OrganizationContact): object {
        return {
            email: contact.email,
            firstName: contact.firstName,
            lastName: contact.lastName,
            phoneNumber: contact.phoneNumber,
            role: OrganizationAdapter.parseOrganizationContactRoleToApi(contact.contactRoleType)
        };
    }

    public static parseOrganizationContractFromObject(contract: object): OrganizationContract {
        return new OrganizationContract(
            DateTimeAdapter.parseDateTimeStringToLocal(contract['start']),
            DateTimeAdapter.parseDateTimeStringToLocal(contract['end']),
            contract['packageType'],
            contract['productFeeCents'],
            contract['productFeePercentage'],
            contract['ticketFeeCents'],
            contract['ticketFeePercentage'],
            contract['seatedTicketFeeCents'],
            contract['seatedTicketFeePercentage'],
            contract['guestListFeeCents'],
            contract['signed'],
            contract['timezoneIdentification']
        );
    }

    public static parseOrganizationFinanceDetailsFromObject(finance: object): OrganizationFinanceDetails {
        return new OrganizationFinanceDetails(
            finance['iban'],
            finance['bankAccountNumber'],
            finance['bic'],
            finance['vatCode'],
            finance['approximatedAnnualSalesAmount'],
            finance['currency'] === null ? null : CurrencyAdapter.parseFromObject(finance['currency'])
        );
    }

    public static parseOrganizationListingFromObject(organization: object): OrganizationListing {
        return new OrganizationListing(
            organization['id'],
            organization['name'],
            organization['email'],
            organization['countryCode'],
            organization['approximatedAnnualSalesAmount'],
            organization['isImportant'],
            organization['isVerified'],
            organization['isProfileComplete'],
            organization['lastLogin'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(organization['lastLogin']),
            organization['isBlocked'],
            organization['phoneNumber']
        );
    }

    public static parseOrganizationProfileFromObject(profile: object): OrganizationProfile {
        return new OrganizationProfile(
            OrganizationAdapter.parseOrganizationHolderFromObject(profile['holder']),
            LegalAdapter.parseLegalEntityFromObject(profile['legalEntity']),
            OrganizationAdapter.parseOrganizationFinanceDetailsFromObject(profile['finance']),
            profile['address'] === null ? null : AddressAdapter.parseAddressFromObject(profile['address']),
            profile['contacts'].map(OrganizationAdapter.parseOrganizationContactFromObject),
            profile['twoFactorEnabled']
        );
    }

    public static parseOrganizationProfileToApi(profile: OrganizationProfile): object {
        return {
            holder: {
                email: profile.holder.email,
                firstName: profile.holder.firstName,
                lastName: profile.holder.lastName
            },
            finance: {
                iban: profile.finance.bankAccountIban,
                bic: profile.finance.bankAccountBic,
                vatCode: profile.finance.vatIdentifier,
                approximatedAnnualSalesAmount: profile.finance.approximatedAnnualSalesAmount,
                currency: profile.finance.currency
            },
            legalEntity: {
                name: profile.legalEntity.name,
                countryCode: profile.legalEntity.countryCode,
                chamberOfCommerceIdentifier: profile.legalEntity.chamberOfCommerceIdentifier,
                timezoneIdentification: profile.legalEntity.timezoneIdentification
            },
            address: {
                venue: profile.address.venue,
                countryCode: profile.address.countryCode,
                city: profile.address.city,
                postalCode: profile.address.postalCode,
                street: profile.address.street,
                houseNumber: profile.address.houseNumber,
                latitude: profile.address.latitude,
                longitude: profile.address.longitude
            }
        };
    }

    public static parseOrganizationContactRole(contactType: string): ContactType {
        switch (contactType.toLowerCase()) {
            case 'finance':
                return ContactType.Finance;

            case 'marketing':
                return ContactType.Marketing;

            case 'customersupport':
                return ContactType.CustomerSupport;

            default:
                return ContactType.Organization;
        }
    }

    public static parseOrganizationContactRoleToApi(contactType: ContactType): string {
        switch (contactType) {
            case ContactType.Finance:
                return 'Finance';

            case ContactType.Marketing:
                return 'Marketing';

            case ContactType.CustomerSupport:
                return 'CustomerSupport';

            default:
                return 'Organization';
        }
    }

    public static parseOrganizationAccountFromObject(organization: object): OrganizationAccount {
        return new OrganizationAccount(
            organization['avatar'] === null ? null : MediaAdapter.parseMediaFromObject(organization['avatar']),
            organization['email'],
            organization['firstName'] || null,
            organization['lastName'] || null,
            organization['phoneNumber'] || null,
            organization['organization'] || null,
            organization['isVerified'],
            organization['isProfileComplete'],
            organization['isImportant'],
            organization['address'] == null ? null : AddressAdapter.parseAddressFromObject(organization['address']),
            organization['lastLogin'] == null ? null : DateTimeAdapter.parseDateTimeStringToLocal(organization['lastLogin']),
            DateTimeAdapter.parseDateTimeStringToLocal(organization['createdOn']),
            organization['approximatedAnnualSalesAmount'],
            organization['contractSpecification'] === null ? null : OrganizationAdapter.parseOrganizationContractFromObject(organization['contractSpecification']),
            organization['currency'] === null ? null : CurrencyAdapter.parseFromObject(organization['currency']),
            organization['chamberOfCommerceIdentifier'] || null,
            organization['contacts'].map(OrganizationAdapter.parseOrganizationContactFromObject),
            OrganizationAdapter.parseManagedBy(organization['managedBy']),
            organization['isBlocked']
        );
    }

    public static parseManagedBy(managedBy: object[]): ManagedBy[] {
        return managedBy.map(mb => new ManagedBy(
            mb['id'],
            mb['email'],
            mb['firstName'],
            mb['lastName'],
            mb['avatar'] === null ? null : MediaAdapter.parseMediaFromObject(mb['avatar'])
        ));
    }

    public static parseOrganizationContractAddendumToApi(addendum: OrganizationContractAddendum): object {
        return {
            text: addendum.content,
            dateRange: {
                start: DateTimeAdapter.parseDateTimeToApi(addendum.startDate),
                end: DateTimeAdapter.parseDateTimeToApi(addendum.endDate)
            },
            ticketFeeCents: addendum.ticketFeeCents,
            ticketFeePercentage: addendum.ticketFeePercentage,
            seatedTicketFeeCents: addendum.seatedTicketFeeCents,
            seatedTicketFeePercentage: addendum.seatedTicketFeePercentage,
            productFeeCents: addendum.productFeeCents,
            productFeePercentage: addendum.productFeePercentage,
            guestListFeeCents: addendum.guestListFeeCents
        };
    }

    public static parseOrganizationContractAlterToApi(contract: OrganizationContractAlter): object {
        return {
            guestListFeeCents: contract.guestListFeeCents,
            productFeeCents: contract.productFeeCents,
            productFeePercentage: contract.productFeePercentage,
            ticketFeeCents: contract.ticketFeeCents,
            ticketFeePercentage: contract.ticketFeePercentage,
            seatedTicketFeeCents: contract.seatedTicketFeeCents,
            seatedTicketFeePercentage: contract.seatedTicketFeePercentage,
            endDate: DateTimeAdapter.parseDateTimeToApi(contract.endDate)
        };
    }
}
