import { Adapter } from '@fancee/client';
import { ShopColorPalette } from '@/dto';
import { ColorAdapter } from '@/adapter';
import { BRAND_PRIMARY_COLOR, BRAND_BACKDROP_COLOR, BRAND_BACKGROUND_COLOR, BRAND_TEXT_COLOR } from '@/constant';

@Adapter
export class OrganizationDefaultsAdapter {
    public static parseShopColorPalletFromObject(palette: object): ShopColorPalette {
        return new ShopColorPalette(
            palette['primaryColor'] == null ? BRAND_PRIMARY_COLOR : ColorAdapter.parseColor(palette['primaryColor']),
            palette['textColor'] == null ? BRAND_TEXT_COLOR : ColorAdapter.parseColor(palette['textColor']),
            palette['backdropColor'] == null ? BRAND_BACKDROP_COLOR : ColorAdapter.parseColor(palette['backdropColor']),
            palette['backgroundColor'] == null ? BRAND_BACKGROUND_COLOR : ColorAdapter.parseColor(palette['backgroundColor'])
        );
    }

    public static parseShopColorPaletteToApi(palette: ShopColorPalette): object {
        return {
            organizationShopPalette: {
                primaryColor: (palette.primaryColor ?? BRAND_PRIMARY_COLOR).replaceAll('#', ''),
                textColor: (palette.textColor ?? BRAND_TEXT_COLOR).replaceAll('#', ''),
                backdropColor: (palette.backdropColor ?? BRAND_BACKDROP_COLOR).replaceAll('#', ''),
                backgroundColor: (palette.backgroundColor ?? BRAND_BACKGROUND_COLOR).replaceAll('#', '')
            }
        };
    }
}
