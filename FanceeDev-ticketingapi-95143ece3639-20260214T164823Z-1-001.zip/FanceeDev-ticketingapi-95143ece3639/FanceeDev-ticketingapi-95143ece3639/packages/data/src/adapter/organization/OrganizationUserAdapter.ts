import { Adapter } from '@fancee/client';
import { MediaAdapter } from '@/adapter';
import { OrganizationUser, OrganizationUserAssignment, OrganizationUserAssignmentUpdate } from '@/dto';

@Adapter
export class OrganizationUserAdapter {
    public static parseOrganizationUserFromObject(organizationUser: object): OrganizationUser {
        return new OrganizationUser(
            organizationUser['id'],
            organizationUser['email'],
            organizationUser['firstName'],
            organizationUser['lastName'],
            organizationUser['avatar'] === null ? null : MediaAdapter.parseMediaFromObject(organizationUser['avatar']),
            organizationUser['claims'],
            organizationUser['description']
        );
    }

    public static parseOrganizationUserAssignmentToObject(user: OrganizationUserAssignment): object {
        return {
            email: user.email,
            claims: user.claims,
            description: user.description
        };
    }

    public static parseOrganizationUserAssignmentUpdateToObject(updatedUser: OrganizationUserAssignmentUpdate): object {
        return {
            userId: updatedUser.userId,
            claims: updatedUser.claims,
            description: updatedUser.description
        };
    }
}
