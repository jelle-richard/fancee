export { PaymentAdapter } from './PaymentAdapter';
