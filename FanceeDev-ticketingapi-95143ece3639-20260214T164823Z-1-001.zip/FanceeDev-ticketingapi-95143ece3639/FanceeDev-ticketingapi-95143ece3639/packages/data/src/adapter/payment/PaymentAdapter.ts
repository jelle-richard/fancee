import { Adapter } from '@fancee/client';
import { AuthAdapter, CurrencyAdapter, DateTimeAdapter } from '@/adapter';
import { AssignedPaymentMethod, EventPaymentMethod, PaymentMethod, TimedWalletBalanceSetting, WalletBalance, WalletBalanceSetting, WalletTransaction } from '@/dto';
import { PaymentStatus, UserType, WalletPaymentType } from '@/enum';

@Adapter
export class PaymentAdapter {
    public static parsePaymentMethodFromObject(paymentMethod: object): PaymentMethod {
        return new PaymentMethod(
            paymentMethod['id'],
            paymentMethod['method'],
            paymentMethod['feePercent'],
            paymentMethod['feeStaticCents'],
            paymentMethod['position'],
            paymentMethod['paidBy'],
            paymentMethod['brandCode']
        );
    }

    public static parseAssignedPaymentMethodToApi(paymentMethod: AssignedPaymentMethod): object {
        return {
            id: paymentMethod.id,
            paidBy: paymentMethod.paidBy === UserType.Organization ? 'Organization' : paymentMethod.paidBy
        };
    }

    public static parseEventPaymentMethodFromObject(paymentMethod: object): EventPaymentMethod {
        return new EventPaymentMethod(
            paymentMethod['id'],
            paymentMethod['name'],
            paymentMethod['provider'],
            paymentMethod['brandCode'],
            paymentMethod['feePercentage'],
            paymentMethod['feeStaticCents'],
            !paymentMethod['paidBy'] ? null : AuthAdapter.parseUserType(paymentMethod['paidBy'])
        );
    }

    public static parseTimedWalletBalanceSettingFromObject(timedBalanceSetting: object): TimedWalletBalanceSetting {
        return new TimedWalletBalanceSetting(
            timedBalanceSetting['dateTime'],
            PaymentAdapter.parseWalletBalanceFromObject(timedBalanceSetting['platformCurrencyBalance']),
            PaymentAdapter.parseWalletBalanceFromObject(timedBalanceSetting['organizationCurrencyBalance'])
        );
    }

    public static parseWalletBalanceSettingFromObject(balanceSetting: object): WalletBalanceSetting {
        return new WalletBalanceSetting(
            PaymentAdapter.parseWalletBalanceFromObject(balanceSetting['platformCurrencyBalance']),
            PaymentAdapter.parseWalletBalanceFromObject(balanceSetting['organizationCurrencyBalance'])
        );
    }

    public static parseWalletBalanceFromObject(balance: object): WalletBalance {
        return new WalletBalance(
            CurrencyAdapter.parseFromObject(balance['currency']),
            balance['balanceCents'],
            balance['pendingCents'],
            balance['pendingDebitCents'],
            balance['reserveCents']
        );
    }

    public static parsePaymentStatus(paymentStatus: string): PaymentStatus {
        switch (paymentStatus) {
            case 'AuthenticationFinished':
                return PaymentStatus.AuthenticationFinished;

            case 'AuthenticationNotRequired':
                return PaymentStatus.AuthenticationNotRequired;

            case 'Authorised':
                return PaymentStatus.Authorised;

            case 'Blocked':
                return PaymentStatus.Blocked;

            case 'Cancelled':
                return PaymentStatus.Cancelled;

            case 'ChallengeShopper':
                return PaymentStatus.ChallengeShopper;

            case 'Chargeback':
                return PaymentStatus.Chargeback;

            case 'Error':
                return PaymentStatus.Error;

            case 'Expired':
                return PaymentStatus.Expired;

            case 'IdentifyShopper':
                return PaymentStatus.IdentifyShopper;

            case 'PartiallyAuthorised':
                return PaymentStatus.PartiallyAuthorised;

            case 'PartialRefund':
                return PaymentStatus.PartialRefund;

            case 'Pending':
                return PaymentStatus.Pending;

            case 'PresentToShopper':
                return PaymentStatus.PresentToShopper;

            case 'Received':
                return PaymentStatus.Received;

            case 'RedirectShopper':
                return PaymentStatus.RedirectShopper;

            case 'Refund':
                return PaymentStatus.Refund;

            case 'PendingRefund':
                return PaymentStatus.PendingRefund;

            case 'Refused':
                return PaymentStatus.Refused;

            default:
                return PaymentStatus.Unknown;
        }
    }

    public static parseWalletTransactionFromObject(transaction: object): WalletTransaction {
        return new WalletTransaction(
            transaction['id'],
            transaction['amountCents'],
            DateTimeAdapter.parseDateTimeStringToLocal(transaction['requestedOn']),
            transaction['processedOn'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(transaction['processedOn']),
            PaymentAdapter.parseWalletPaymentTypeFromString(transaction['type']),
            transaction['invoiceId'],
            transaction['fileId'],
            CurrencyAdapter.parseFromObject(transaction['currency'])
        );
    }

    public static parseWalletPaymentTypeFromString(walletPaymentType: string): WalletPaymentType {
        switch (walletPaymentType.toLowerCase()) {
            case 'debit':
                return WalletPaymentType.Debit;
            case 'credit':
            default:
                return WalletPaymentType.Credit;
        }
    }
}
