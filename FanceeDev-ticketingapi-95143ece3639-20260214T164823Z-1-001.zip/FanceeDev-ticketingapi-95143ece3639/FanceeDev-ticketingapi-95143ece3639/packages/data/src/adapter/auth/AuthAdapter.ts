import { Adapter } from '@fancee/client';
import { CurrencyAdapter, DateTimeAdapter, MediaAdapter } from '@/adapter';
import { AuthUser, ManageableOrganization, Session } from '@/dto';
import { UserType } from '@/enum';

@Adapter
export class AuthAdapter {
    public static parseAuthUserFromObject(user: object): AuthUser {
        return new AuthUser(
            user['id'],
            user['email'],
            user['firstName'],
            user['lastName'],
            AuthAdapter.parseUserType(user['type']),
            !user['avatarFile'] ? null : MediaAdapter.parseMediaFromObject(user['avatarFile']),
            !user['lastLogin'] ? null : DateTimeAdapter.parseDateTimeStringToLocal(user['lastLogin']),
            !user['currency'] ? null : CurrencyAdapter.parseFromObject(user['currency']),
            user['countryCodes'],
            user['isProfileComplete'],
            user['changelogsSinceLastLogin'],
            user['activeOrganizationId'],
            user['publicCode']
        );
    }

    public static parseSessionFromObject(session: object): Session {
        return new Session(
            session['device'],
            session['ipAddress'],
            DateTimeAdapter.parseDateTimeStringToLocal(session['issuedOn']),
            session['token'],
            DateTimeAdapter.parseDateTimeStringToLocal(session['validUntil'])
        );
    }

    public static parseManageableOrganizationFromObject(organization: object): ManageableOrganization {
        return new ManageableOrganization(
            organization['id'],
            organization['name'],
            MediaAdapter.parseMediaFromObject(organization['avatar']),
            organization['claims'],
            organization['isOwner']
        );
    }

    public static parseUserType(type: string): UserType {
        switch (type.toLowerCase()) {
            case 'admin':
                return UserType.Admin;

            case 'ambassador':
                return UserType.Ambassador;

            case 'buyer':
            case 'client':
                return UserType.Client;

            default:
                return UserType.Organization;
        }
    }
}
