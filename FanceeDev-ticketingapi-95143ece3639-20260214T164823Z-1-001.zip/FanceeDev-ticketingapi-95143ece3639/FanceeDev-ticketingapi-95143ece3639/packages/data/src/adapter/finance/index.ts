export { CurrencyAdapter } from './CurrencyAdapter';
