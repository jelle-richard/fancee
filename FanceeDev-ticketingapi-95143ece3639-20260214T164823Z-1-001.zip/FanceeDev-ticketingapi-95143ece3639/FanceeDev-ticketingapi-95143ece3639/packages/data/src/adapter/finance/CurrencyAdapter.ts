import { Adapter } from '@fancee/client';
import { Currency } from '@/dto';

@Adapter
export class CurrencyAdapter {
    public static parseFromObject(currency: object): Currency {
        return new Currency(
            currency['name'],
            currency['character'],
            currency['shortCode'],
            currency['decimals']
        );
    }
}
