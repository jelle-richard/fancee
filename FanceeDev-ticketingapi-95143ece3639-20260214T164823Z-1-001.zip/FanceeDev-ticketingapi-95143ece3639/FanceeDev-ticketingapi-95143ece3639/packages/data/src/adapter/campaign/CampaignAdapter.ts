import { Adapter } from '@fancee/client';
import { Campaign, CampaignShop, ConfigurableCampaign } from '@/dto';

@Adapter
export class CampaignAdapter {
    public static parseConfigurableCampaignToObject(campaign: ConfigurableCampaign): object {
        return {
            campaignName: campaign.name,
            eventId: campaign.eventId,
            shopCodes: campaign.shopCodes
        };
    }

    public static parseCampaignFromObject(campaign: object): Campaign {
        return new Campaign(
            campaign['code'],
            campaign['name'],
            campaign['eventName'],
            campaign['eventId'],
            campaign['shops'].map(CampaignAdapter.parseCampaignShopFromObject),
            campaign['clicks'],
            campaign['revenueCents'],
            campaign['amountOfSoldTickets'],
            campaign['amountOfOrders'],
            campaign['amountOfMales'],
            campaign['amountOfFemales'],
            campaign['amountOfNeutrals'],
            campaign['amountOfReservations'],
            campaign['averageAge']
        );
    }

    private static parseCampaignShopFromObject(campaignShop: object): CampaignShop {
        return new CampaignShop(
            campaignShop['name'],
            campaignShop['code']
        );
    }
}
