export { CampaignAdapter } from './CampaignAdapter';
