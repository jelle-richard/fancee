import { Adapter } from '@fancee/client';
import { IssuedTicketStatistics, PlatformBalances, PlatformGrowthTargetProgression, ReceivedBalance, RevenueBalance, TargetProgression, TicketRevenueIndication } from '@/dto';
import { RevenueAdapter } from '@/adapter';

@Adapter
export class ReportAdapter {
    public static parsePlatformGrowthTargetProgression(platformGrowthTargetProgression: object): PlatformGrowthTargetProgression {
        return new PlatformGrowthTargetProgression(
            platformGrowthTargetProgression['date'],
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['tickets']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['seatedTickets']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['ticketFeeRevenueCents']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['seatedTicketFeeRevenueCents']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['organizations']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['events']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['uniqueBuyers']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['placedOrders']),
            ReportAdapter.parseTargetProgressionFromObject(platformGrowthTargetProgression['fulfilledOrders'])
        );
    }

    private static parseTargetProgressionFromObject(targetProgression: object): TargetProgression {
        return new TargetProgression(
            targetProgression['target'],
            targetProgression['progress']
        );
    }

    public static parseTicketRevenueIndicationFromObject(ticketRevenueIndication: object): TicketRevenueIndication {
        return new TicketRevenueIndication(
            ticketRevenueIndication['highestDailyTicketSalesAmount'],
            ticketRevenueIndication['ticketFeeRevenueCentsYesterday'],
            ticketRevenueIndication['ticketFeeRevenueCentsToday']
        );
    }

    public static parseMonthlyBalancesForYearFromObject(balance: object): PlatformBalances {
        return new PlatformBalances(
            ReportAdapter.parseReceivedBalancesFromObject(balance['receivedBalance']),
            ReportAdapter.parseRevenueBalancesFromObject(balance['revenueBalance'])
        );
    }

    public static parseReceivedBalancesFromObject(receivedBalances: object[]): ReceivedBalance[] {
        return receivedBalances.map(ReportAdapter.parseReceivedBalanceFromObject);
    }

    public static parseReceivedBalanceFromObject(receivedBalance: object): ReceivedBalance {
        return new ReceivedBalance(
            receivedBalance['month'],
            receivedBalance['issuedTickets'] === null
                ? IssuedTicketStatistics.empty()
                : RevenueAdapter.parseIssuedTicketsFromObject(receivedBalance['issuedTickets']),
            receivedBalance['fulfilledOrders'],
            receivedBalance['productIncomeCents'],
            receivedBalance['ticketFeeCents'],
            receivedBalance['seatedTicketFeeCents'],
            receivedBalance['productFeeCents'],
            receivedBalance['paymentFeeCents'],
            receivedBalance['ticketServicePlusCents'],
            receivedBalance['smsCents'],
            receivedBalance['refundedCents'],
            receivedBalance['chargedBackCents']
        );
    }

    public static parseRevenueBalancesFromObject(revenueBalances: object[]): RevenueBalance[] {
        return revenueBalances.map(ReportAdapter.parseRevenueBalanceFromObject);
    }

    public static parseRevenueBalanceFromObject(revenueBalances: object[]): RevenueBalance {
        return new RevenueBalance(
            revenueBalances['month'],
            revenueBalances['ticketFeeCents'],
            revenueBalances['seatedTicketFeeCents'],
            revenueBalances['productFeeCents'],
            revenueBalances['guestListFeeCents'],
            revenueBalances['paymentFeeCents'],
            revenueBalances['ticketServicePlusCostCents'],
            revenueBalances['smsCostCents'],
            revenueBalances['chargebackCostCents'],
            revenueBalances['refundCostCents'],
            revenueBalances['additionalCostCents']
        );
    }
}
