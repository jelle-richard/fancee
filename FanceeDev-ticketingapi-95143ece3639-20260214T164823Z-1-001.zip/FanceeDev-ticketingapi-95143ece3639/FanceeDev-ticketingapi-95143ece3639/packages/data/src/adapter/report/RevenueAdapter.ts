import { Adapter } from '@fancee/client';
import { ClientCost, IssuedTicketStatistics, OrganizationRevenue, PlatformCost, PlatformRevenue, Revenue, RevenueReportStatistics, RevenueStatistics } from '@/dto';

@Adapter
export class RevenueAdapter {
    public static parseRevenueReportFromObject(revenueReport: object): RevenueReportStatistics {
        return new RevenueReportStatistics(
            RevenueAdapter.parseClientCostFromObject(revenueReport['clientCost']),
            RevenueAdapter.parseRevenueStatisticsFromObject(revenueReport['revenueStatistics']),
            RevenueAdapter.parseOrganizationRevenueFromObject(revenueReport['organizationRevenue']),
            RevenueAdapter.parsePlatformRevenueFromObject(revenueReport['platformRevenue']),
            RevenueAdapter.parsePlatformCostFromObject(revenueReport['platformCost'])
        );
    }

    public static parseClientCostFromObject(clientCost: object): ClientCost {
        return new ClientCost(
            clientCost['smsFeeCostCents'],
            clientCost['ticketServicePlusFeeCostCents'],
            clientCost['paymentFeeCostCents']
        );
    }

    public static parseRevenueStatisticsFromObject(revenueStatistics: object): RevenueStatistics {
        return new RevenueStatistics(
            RevenueAdapter.parseTicketsFromObject(revenueStatistics['issuedProducts']),
            revenueStatistics['totalFulfilledOrders']
        );
    }

    public static parseIssuedTicketsFromObject(issuedTickets: object): IssuedTicketStatistics {
        return new IssuedTicketStatistics(
            issuedTickets['issuedPlatformShopProducts'],
            issuedTickets['issuedPlatformAppProducts'],
            issuedTickets['issuedPlatformImportedProducts'],
            issuedTickets['issuedPlatformGuestlistProducts'],
            issuedTickets['issuedPlatformGeneratedProducts'],
            issuedTickets['issuedTicketSwapProducts']
        );
    }

    public static parseTicketsFromObject(issuedTickets: object): IssuedTicketStatistics {
        return new IssuedTicketStatistics(
            issuedTickets['platformShopProducts'],
            issuedTickets['platformAppProducts'],
            issuedTickets['platformImportedProducts'],
            issuedTickets['platformGuestListProducts'],
            issuedTickets['platformGeneratedProducts'],
            issuedTickets['ticketSwapProducts']
        );
    }

    public static parseOrganizationRevenueFromObject(revenues: object): OrganizationRevenue {
        return new OrganizationRevenue(
            RevenueAdapter.parseRevenueFromObject(revenues['onlineRevenue']),
            RevenueAdapter.parseRevenueFromObject(revenues['cashRevenue'])
        );
    }

    public static parseRevenueFromObject(revenue: object): Revenue {
        return new Revenue(
            revenue['recetteCents'],
            revenue['administrationFeeCents'],
            revenue['discountCents']
        );
    }

    public static parsePlatformRevenueFromObject(revenue: object): PlatformRevenue {
        return new PlatformRevenue(
            revenue['smsFeeCostCents'],
            revenue['ticketServicePlusFeeCostCents'],
            revenue['paymentFeeCostCents']
        );
    }

    public static parsePlatformCostFromObject(cost: object): PlatformCost {
        return new PlatformCost(
            cost['ticketFeeCostCents'],
            cost['seatedTicketFeeCostCents'],
            cost['productFeeCostCents'],
            cost['guestListFeeCostCents'],
            cost['additionalCostCents'],
            cost['paymentFeeCostCents']
        );
    }
}
