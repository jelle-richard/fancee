import { Adapter } from '@fancee/client';
import { DateTimeAdapter } from '@/adapter';
import { Changelog } from '@/dto';

@Adapter
export class SystemAdapter {
    public static parseChangelogFromObject(changelog: object): Changelog {
        return new Changelog(
            DateTimeAdapter.parseDateTimeStringToLocal(changelog['releaseDate']),
            changelog['title'],
            changelog['description']
        );
    }
}
