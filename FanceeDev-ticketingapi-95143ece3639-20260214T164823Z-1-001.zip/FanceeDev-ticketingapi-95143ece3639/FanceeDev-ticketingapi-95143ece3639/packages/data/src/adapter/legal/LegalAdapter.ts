import { Adapter } from '@fancee/client';
import { LegalEntity } from '@/dto';

@Adapter
export class LegalAdapter {
    public static parseLegalEntityFromObject(legalEntity: object): LegalEntity {
        return new LegalEntity(
            legalEntity['name'],
            legalEntity['countryCode'],
            legalEntity['chamberOfCommerceIdentifier'],
            legalEntity['timezoneIdentification'],
            legalEntity['phoneNumber']
        );
    }
}
