export { LegalAdapter } from './LegalAdapter';
