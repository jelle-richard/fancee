import { Adapter } from '@fancee/client';
import { Agenda, AgendaOverview, AgendaLinkedEvent, AgendaDesign, AgendaListing, AgendaOverviewShop, AgendaOverviewShopDesign, AgendaOverviewLinkedEvent } from '@/dto';
import { AddressAdapter, DateTimeAdapter, MediaAdapter } from '@/adapter';
import { BRAND_BACKDROP_COLOR, BRAND_BACKGROUND_COLOR, BRAND_PRIMARY_COLOR, BRAND_TEXT_COLOR } from '@/constant';

@Adapter
export class AgendaAdapter {
    public static parseAgendaListingFromObject(agenda: object): AgendaListing {
        return new AgendaListing(
            agenda['id'],
            agenda['name'],
            agenda['showAllActiveEvents'],
            agenda['linkedEvents'] === null ? null : AgendaAdapter.parseAgendaLinkedEventsFromObject(agenda['linkedEvents'])
        );
    }

    public static parseAgendaLinkedEventsFromObject(events: object[]): AgendaLinkedEvent[] {
        return events.map(AgendaAdapter.parseAgendaLinkedEventFromObject);
    }

    public static parseAgendaLinkedEventFromObject(event: object): AgendaLinkedEvent {
        return new AgendaLinkedEvent(
            event['name'],
            DateTimeAdapter.parseDateTimeStringToLocal(event['startDate']),
            DateTimeAdapter.parseDateTimeStringToLocal(event['endDate']),
            event['type']
        );
    }

    public static parseAgendaOverviewFromObject(agenda: object): AgendaOverview {
        return new AgendaOverview(
            agenda['id'],
            AgendaAdapter.parseAgendaDesignFromObject(agenda['design']),
            agenda['linkedEvents'] === null ? null : AgendaAdapter.parseAgendaOverviewLinkedEventsFromObject(agenda['linkedEvents']),
            agenda['googleAnalyticsId']
        );
    }

    public static parseAgendaFromObject(agenda: object): Agenda {
        return new Agenda(
            agenda['name'],
            AgendaAdapter.parseAgendaEventsToEventIds(agenda['linkedEvents']),
            agenda['showAllEvents'],
            agenda['design'] === null ? null : AgendaAdapter.parseAgendaDesignFromObject(agenda['design']),
            agenda['active'],
            agenda['googleAnalyticsId']
        );
    }

    public static parseAgendaDesignFromObject(design: object): AgendaDesign {
        return new AgendaDesign(
            design['showHeaders'],
            `#${design['primaryColor']}`,
            `#${design['textColor']}`,
            `#${design['backdropColor']}`,
            `#${design['backgroundColor']}`
        );
    }

    public static parseAgendaOverviewLinkedEventsFromObject(events: object[]): AgendaOverviewLinkedEvent[] {
        return events.map(AgendaAdapter.parseAgendaOverviewLinkedEventFromObject);
    }

    public static parseAgendaOverviewLinkedEventFromObject(event: object): AgendaOverviewLinkedEvent {
        return new AgendaOverviewLinkedEvent(
            event['name'],
            DateTimeAdapter.parseDateTimeStringToLocal(event['startDate']),
            DateTimeAdapter.parseDateTimeStringToLocal(event['endDate']),
            event['type'],
            event['id'],
            event['headerImages'].map(MediaAdapter.parseMediaFromObject),
            event['description'],
            event['address'] === null ? null : AddressAdapter.parseAddressFromObject(event['address']),
            event['shops'] === null ? null : AgendaAdapter.parseAgendaOverviewShopsFromObject(event['shops'])
        );
    }

    public static parseAgendaOverviewShopsFromObject(shops: object[]): AgendaOverviewShop[] {
        return shops.map(AgendaAdapter.parseAgendaOverviewShopFromObject);
    }

    public static parseAgendaOverviewShopFromObject(shops: object): AgendaOverviewShop {
        return new AgendaOverviewShop(
            shops['code'],
            shops['name'],
            shops['design']['headerImages'].length === 0
                ? null
                : shops['design']['headerImages'][0]['url'],
            shops['design'] === null ? null : AgendaAdapter.parseAgendaOverviewShopDesignFromObject(shops['design'])
        );
    }

    public static parseAgendaOverviewShopDesignFromObject(shopDesign: object): AgendaOverviewShopDesign {
        return new AgendaOverviewShopDesign(
            shopDesign['headerImages'].map(MediaAdapter.parseMediaFromObject)
        );
    }

    public static parseAgendaToApi(agenda: Agenda): object {
        return {
            name: agenda.name,
            events: agenda.events,
            design: AgendaAdapter.parseAgendaDesignToApi(agenda.design),
            active: agenda.active,
            googleAnalyticsId: agenda.googleAnalyticsId
        };
    }

    public static parseAgendaDesignToApi(design: AgendaDesign): object {
        return {
            showHeaders: design.showHeaders,
            primaryColor: (design.primaryColor ?? BRAND_PRIMARY_COLOR).replaceAll('#', ''),
            textColor: (design.textColor ?? BRAND_TEXT_COLOR).replaceAll('#', ''),
            backdropColor: (design.backdropColor ?? BRAND_BACKDROP_COLOR).replaceAll('#', ''),
            backgroundColor: (design.backgroundColor ?? BRAND_BACKGROUND_COLOR).replaceAll('#', '')
        };
    }

    public static parseAgendaEventsToEventIds(events: AgendaOverviewLinkedEvent[]): string[] {
        return events.map(a => a.id);
    }
}
