import { Adapter } from '@fancee/client';
import { UIVariantColor } from '@/enum';

@Adapter
export class UIAdapter {
    public static parseVariantColor(variant: string): UIVariantColor {
        switch (variant.toLowerCase()) {
            case 'secondary':
                return UIVariantColor.Secondary;

            case 'success':
                return UIVariantColor.Success;

            case 'warning':
                return UIVariantColor.Warning;

            case 'danger':
                return UIVariantColor.Danger;

            case 'info':
                return UIVariantColor.Info;

            case 'primary':
            default:
                return UIVariantColor.Primary;
        }
    }
}
