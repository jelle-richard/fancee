import { Adapter } from '@fancee/client';
import { SelectOption } from '@/dto';
import { DateTime } from 'luxon';
import { LUXON_DATE_TIME_FORMAT } from '@/constant';

@Adapter
export class SelectAdapter {
    public static parseSelectOptionFromApi(so: object): SelectOption {
        return new SelectOption(
            so['id'],
            so['label'],
            so['header'] ?? null,
            so['note'] = DateTime.fromSQL(so['note'] ?? '').isValid
                ? DateTime.fromSQL(so['note']).toFormat(LUXON_DATE_TIME_FORMAT)
                : so['note'] ?? null
        );
    }
}
