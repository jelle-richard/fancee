import { Adapter } from '@fancee/client';
import { ConfigurableCountryItem, ConfigurableItem, Configuration } from '@/dto';

@Adapter
export class ConfigurationAdapter {
    public static parseConfigurationFromObject(configuration: object): Configuration {
        return new Configuration(
            configuration['journal'],
            configuration['items'].map(i =>
                new ConfigurableItem(
                    i['platformItem'],
                    i['countryItems'].map(ci =>
                        new ConfigurableCountryItem(ci['countryCode'], ci['exactItemCode'])
                    )
                )
            )
        );
    }
}
