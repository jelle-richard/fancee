import { Adapter } from '@fancee/client';
import { DateTimeAdapter } from '@/adapter';
import { PayOutExportListing } from '@/dto';
import { PayOutStatus } from '@/enum';

@Adapter
export class PayOutAdapter {
    public static parsePayOutExportListItemFromObject(payOutExport: object): PayOutExportListing {
        return new PayOutExportListing(
            payOutExport['id'],
            PayOutAdapter.parsePayOutStatusFromString(payOutExport['status']),
            DateTimeAdapter.parseDateTimeStringToLocal(payOutExport['createdAt'])
        );
    }

    public static parsePayOutStatusFromString(payOutStatus: string): PayOutStatus | null {
        if (payOutStatus === 'Created')
            return PayOutStatus.Created;
        else if (payOutStatus === 'Processed')
            return PayOutStatus.Processed;
        else
            return null;
    }
}
