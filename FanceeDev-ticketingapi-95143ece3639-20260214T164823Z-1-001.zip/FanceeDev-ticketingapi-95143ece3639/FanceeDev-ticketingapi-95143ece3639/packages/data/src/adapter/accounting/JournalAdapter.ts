import { Adapter } from '@fancee/client';
import { Journal } from '@/dto';

@Adapter
export class JournalAdapter {
    public static parseJournalFromObject(journal: object): Journal {
        return new Journal(
            journal['id'],
            journal['code'],
            journal['currency'] || null,
            journal['description'] || null
        );
    }
}
