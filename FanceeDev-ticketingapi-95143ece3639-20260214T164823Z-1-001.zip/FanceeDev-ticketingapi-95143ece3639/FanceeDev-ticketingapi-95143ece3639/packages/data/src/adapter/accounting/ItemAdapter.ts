import { Adapter } from '@fancee/client';
import { Item } from '@/dto';

@Adapter
export class ItemAdapter {
    public static parseItemFromObject(item: object): Item {
        return new Item(
            item['id'],
            item['code'] || null,
            item['description'] || null
        );
    }
}

