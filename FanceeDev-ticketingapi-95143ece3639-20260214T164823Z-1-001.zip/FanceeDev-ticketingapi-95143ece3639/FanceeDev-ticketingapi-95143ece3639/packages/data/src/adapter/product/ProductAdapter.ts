import { Adapter } from '@fancee/client';
import { MediaAdapter, ShopAdapter } from '@/adapter';
import { BestSellingProduct, IssuedProduct, IssuedTicket, Media, ProductIdentification, IssuedProductStatistics, TypedProductIdentification, EventProducts, IssuedNormalProduct } from '@/dto';
import { ProductType } from '@/enum';

@Adapter
export class ProductAdapter {
    public static parseBestSellingProductFromObject(product: object): BestSellingProduct {
        let media: Media[] = [];
        product['media'].forEach(m => media.push(MediaAdapter.parseMediaFromObject(m)));

        return new BestSellingProduct(
            product['productId'],
            product['productName'],
            product['eventName'],
            media,
            product['amountSold'],
            product['amountStock']
        );
    }

    public static parseBestSellingProductsFromObjects(products: object[]): BestSellingProduct[] {
        let bestSellers: BestSellingProduct[] = [];

        products.forEach(p => bestSellers.push(ProductAdapter.parseBestSellingProductFromObject(p)));

        return bestSellers;
    }

    public static parseIssuedProductFromObject(issuedProduct: object): IssuedProduct {
        return new IssuedNormalProduct(
            issuedProduct['id'],
            issuedProduct['productId'],
            issuedProduct['orderId'],
            ShopAdapter.parseProductType(issuedProduct['type']),
            issuedProduct['quantity'],
            issuedProduct['name'],
            issuedProduct['media'] === null ? null : MediaAdapter.parseMediaFromObject(issuedProduct['media']),
            issuedProduct['productFeeCents'],
            issuedProduct['costCents']
        );
    }

    public static parseIssuedTicketFromObject(issuedTicket: object): IssuedTicket {
        return new IssuedTicket(
            issuedTicket['id'],
            issuedTicket['productId'],
            issuedTicket['orderId'],
            ShopAdapter.parseProductType(issuedTicket['type']),
            issuedTicket['quantity'],
            issuedTicket['name'],
            issuedTicket['media'] === null ? null : MediaAdapter.parseMediaFromObject(issuedTicket['media']),
            issuedTicket['productFeeCents'],
            issuedTicket['costCents'],
            issuedTicket['maxAttendees'],
            issuedTicket['ticketFeeCents']
        );
    }

    public static parseProductIdentificationFromObject(product: object): ProductIdentification {
        return new ProductIdentification(
            product['id'],
            product['name']
        );
    }

    public static parseProductTypeFromString(type: string): ProductType {
        if (type.toLowerCase() === 'product')
            return ProductType.Product;

        return ProductType.Ticket;
    }

    public static parseTypedProductIdentificationFromObject(product: object): TypedProductIdentification {
        return new TypedProductIdentification(
            product['id'],
            product['name'],
            ProductAdapter.parseProductTypeFromString(product['type'])
        );
    }

    public static parseIssuedProductStatisticsFromObject(saleStatistics: object): IssuedProductStatistics {
        return new IssuedProductStatistics(
            saleStatistics['id'],
            saleStatistics['name'],
            saleStatistics['priceCents'],
            saleStatistics['stock'],
            saleStatistics['pendingReservationsAmount'],
            saleStatistics['pendingPaymentsAmount'],
            saleStatistics['refundAmount'],
            saleStatistics['guestAmount']['notDeductedAmount'],
            saleStatistics['guestAmount']['deductedAmount'],
            saleStatistics['soldAmount'],
            saleStatistics['packQuantity'],
            true
        );
    }

    public static parseEventProductsFromObject(eventProducts: object): EventProducts {
        return new EventProducts(
            eventProducts['eventName'],
            eventProducts['products'].map(ProductAdapter.parseProductIdentificationFromObject)
        );
    }
}
