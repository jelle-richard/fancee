export { ProductAdapter } from './ProductAdapter';
