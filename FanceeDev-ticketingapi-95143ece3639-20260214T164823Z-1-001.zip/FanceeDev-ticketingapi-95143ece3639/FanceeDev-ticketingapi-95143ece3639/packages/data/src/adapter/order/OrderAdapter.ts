import { Adapter } from '@fancee/client';
import { AddressAdapter, CurrencyAdapter, DateTimeAdapter, EventAdapter, GenderAdapter, MediaAdapter, PaymentAdapter, ProductAdapter, TicketAdapter } from '@/adapter';
import { Client, ClientOrder, ClientOrderItem, ClientProductOrder, DailyOrder, Media, Order, OrderClient, OrderComplete, OrderCost, OrderCostDiscount, OrderCostProductDiscount, OrderedTicket, OrderPaymentHistory, OrderProduct, OrganizationOrderItem, PlatformOrderItem, Refund, RefundableProduct, ShopOrder, TicketOrder } from '@/dto';

@Adapter
export class OrderAdapter {
    public static parseClientOrderFromObject(clientOrder: object): ClientOrder {
        return new ClientOrder(
            clientOrder['address'] === null ? null : AddressAdapter.parseAddressFromObject(clientOrder['address']),
            clientOrder['firstName'],
            clientOrder['lastName'],
            clientOrder['phoneNumber'],
            clientOrder['email'],
            clientOrder['gender'] === null ? null : GenderAdapter.parseGender(clientOrder['gender']),
            clientOrder['birthdate'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(clientOrder['birthdate']),
            clientOrder['receiveViaSmsCostCents'],
            clientOrder['ticketServicePlusCostCents'],
            clientOrder['optInPromotionalEmail'],
            clientOrder['optInPromotionalSms']
        );
    }

    public static parseClientProductOrderFromObject(clientOrder: object): ClientProductOrder {
        return new ClientProductOrder(
            clientOrder['address'] === null ? null : AddressAdapter.parseAddressFromObject(clientOrder['address']),
            clientOrder['firstName'],
            clientOrder['lastName'],
            clientOrder['phoneNumber'],
            clientOrder['email'],
            clientOrder['gender'] === null ? null : GenderAdapter.parseGender(clientOrder['gender']),
            clientOrder['age'],
            clientOrder['receiveViaSms'],
            clientOrder['optInPromotionalSms'],
            clientOrder['optInPromotionalEmail'],
            clientOrder['enabledTicketServicePlus']
        );
    }

    public static parseClientOrderListingFromObject(clientOrder: object): ClientOrderItem {
        return new ClientOrderItem(
            clientOrder['id'],
            clientOrder['eventName'],
            DateTimeAdapter.parseDateTimeStringToLocal(clientOrder['creationDate']),
            clientOrder['costCents'],
            clientOrder['currency'] === null ? null : CurrencyAdapter.parseFromObject(clientOrder['currency']),
            PaymentAdapter.parsePaymentStatus(clientOrder['status']),
            clientOrder['pspReference']
        );
    }

    public static parseOrderedTicketFromObject(ticket: object, eventStartDate: string | null): OrderedTicket {
        return new OrderedTicket(
            ticket['code'],
            ticket['name'],
            ticket['label'],
            DateTimeAdapter.parseDateTimeStringToLocal(eventStartDate),
            ticket['maximumPreArrivalTimeMinutes'],
            ticket['partialAccessStart'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(ticket['partialAccessStart']),
            ticket['partialAccessEnd'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(ticket['partialAccessEnd']),
            TicketAdapter.parseTicketHolderFromObject(ticket['holder']),
            ticket['isSwappable']
        );
    }

    public static parseShopOrderToApi(shopOrder: ShopOrder): object {
        return {
            reservationReference: shopOrder.reservationReference,
            orderClient: {
                email: shopOrder.orderClient.email,
                firstName: shopOrder.orderClient.firstName,
                lastName: shopOrder.orderClient.lastName,
                phoneNumber: shopOrder.orderClient.phoneNumber,
                gender: shopOrder.orderClient.gender,
                birthdate: shopOrder.orderClient.birthDate === null ? null : DateTimeAdapter.parseDateTimeToApi(shopOrder.orderClient.birthDate),
                address: {
                    countryCode: shopOrder.orderClient.address.countryCode,
                    postalCode: shopOrder.orderClient.address.postalCode,
                    street: shopOrder.orderClient.address.street,
                    city: shopOrder.orderClient.address.city,
                    houseNumber: shopOrder.orderClient.address.houseNumber,
                    venue: shopOrder.orderClient.address.venue,
                    latitude: shopOrder.orderClient.address.latitude,
                    longitude: shopOrder.orderClient.address.longitude
                }
            },
            paymentMethodId: shopOrder.paymentMethodId,
            receiveViaSms: shopOrder.receiveViaSms,
            optInPromotionalSms: shopOrder.optInPromotionalSms,
            optInPromotionalEmail: shopOrder.optInPromotionalEmail,
            enabledTicketServicePlus: shopOrder.enabledTicketServicePlus,
            discountCode: shopOrder.discountCode
        };
    }

    public static parseTicketOrderFromObject(order: object): TicketOrder {
        return new TicketOrder(
            order['orderId'],
            order['name'],
            DateTimeAdapter.parseDateTimeStringToLocal(order['startDate']),
            order['tickets'].map(t => OrderAdapter.parseOrderedTicketFromObject(t, order['startDate']))
        );
    }

    public static parseOrganizationListingFromObject(orderListing: object): OrganizationOrderItem {
        return new OrganizationOrderItem(
            orderListing['id'],
            orderListing['eventName'],
            DateTimeAdapter.parseDateTimeStringToLocal(orderListing['creationDate']),
            orderListing['costCents'],
            PaymentAdapter.parsePaymentStatus(orderListing['status']),
            orderListing['currency'] === null ? null : CurrencyAdapter.parseFromObject(orderListing['currency']),
            orderListing['pspReference']
        );
    }

    public static parsePlatFormOrderListingFromObject(orderListing: object): PlatformOrderItem {
        return new PlatformOrderItem(
            orderListing['id'],
            orderListing['eventName'],
            DateTimeAdapter.parseDateTimeStringToLocal(orderListing['creationDate']),
            orderListing['costCents'],
            PaymentAdapter.parsePaymentStatus(orderListing['status']),
            orderListing['currency'] === null ? null : CurrencyAdapter.parseFromObject(orderListing['currency']),
            orderListing['pspReference']
        );
    }

    public static parseOrderProductFromObject(product: object): OrderProduct {
        let media: Media[] = [];
        product['media'].forEach(m => media.push(MediaAdapter.parseMediaFromObject(m)));

        return new OrderProduct(
            product['id'],
            product['name'],
            product['priceCents'],
            product['feeCents'],
            media,
            ProductAdapter.parseProductTypeFromString(product['type']),
            product['issuedTickets'].map(TicketAdapter.parseIssuedOrderTicketFromObject),
            product['quantity']
        );
    }

    public static parseOrderFromObject(order: object): Order {
        let products: OrderProduct[] = [];
        order['products'].forEach(p => products.push(OrderAdapter.parseOrderProductFromObject(p)));

        return new Order(
            order['id'],
            order['costCents'],
            PaymentAdapter.parsePaymentStatus(order['transactionStatus']),
            order['paymentMethod'],
            DateTimeAdapter.parseDateTimeStringToLocal(order['placedOn']),
            DateTimeAdapter.parseDateTimeStringToLocal(order['lastAlteration']),
            order['pspReference'],
            order['reservationReference'],
            order['paymentMethodId'],
            OrderAdapter.parseClientOrderFromObject(order['client']),
            EventAdapter.parseOrderEventFromObject(order['event']),
            products,
            order['currency'] === null ? null : CurrencyAdapter.parseFromObject(order['currency']),
            order['paymentHistory'].map(OrderAdapter.parseOrderPaymentHistoryFromObject).reverse()
        );
    }

    public static parseOrderPaymentHistoryFromObject(paymentHistory: object): OrderPaymentHistory {
        return new OrderPaymentHistory(
            DateTimeAdapter.parseDateTimeStringToLocal(paymentHistory['createdOn']),
            paymentHistory['amountCents'],
            paymentHistory['pspReference'],
            PaymentAdapter.parsePaymentStatus(paymentHistory['paymentStatus'])
        );
    }

    public static parseDailyOrdersFromObjects(orders: object[]): DailyOrder[] {
        return orders.map(o => new DailyOrder(
            DateTimeAdapter.parseDateTimeStringToLocal(o['date']),
            o['totalOrders'],
            o['totalProductsSold'],
            o['cashSalesRevenueCents'],
            o['onlineSalesRevenueCents']
        ));
    }

    public static parseOrderCompleteFromObject(orderComplete: object): OrderComplete {
        return new OrderComplete(
            orderComplete['orderId'],
            orderComplete['clientId'],
            orderComplete['redirectUrl']
        );
    }

    public static parseClientToOrderClient(client: Client): OrderClient {
        return new OrderClient(
            client.email,
            client.firstname,
            client.lastname,
            client.phoneNumber,
            client.gender === null ? null : GenderAdapter.parseGender(client.gender),
            client.birthdate,
            client.address === null ? null : AddressAdapter.parseClientAddressToAddress(client.address)
        );
    }

    public static parseOrderCostFromObject(orderCost: object): OrderCost {
        return new OrderCost(
            !orderCost['discount'] ? null : OrderAdapter.parseOrderCostDiscountFromObject(orderCost['discount']),
            orderCost['paymentFeeCents'],
            orderCost['productFeeCents'],
            orderCost['ticketFeeCents'],
            orderCost['seatedTicketFeeCents'],
            orderCost['ticketServicePlusCents'],
            orderCost['totalOrderCostCents']
        );
    }

    public static parseOrderCostDiscountFromObject(orderCostDiscount: object): OrderCostDiscount {
        return new OrderCostDiscount(
            orderCostDiscount['productDiscounts']?.map(OrderAdapter.parseOrderCostProductDiscountFromObject) ?? [],
            orderCostDiscount['shopDiscountCents'],
            orderCostDiscount['totalDiscountCents']
        );
    }

    public static parseOrderCostProductDiscountFromObject(orderCostProductDiscount: object): OrderCostProductDiscount {
        return new OrderCostProductDiscount(
            orderCostProductDiscount['id'],
            orderCostProductDiscount['discountCents'],
            orderCostProductDiscount['discountCentsTotal'],
            orderCostProductDiscount['discountedPriceCents'],
            orderCostProductDiscount['discountedPriceCentsTotal'],
            orderCostProductDiscount['quantity']
        );
    }

    public static parseRefundToObject(refund: Refund): object {
        return {
            returnToStock: refund.returnToStock,
            invalidateTicket: refund.invalidateTickets,
            description: refund.description,
            products: refund.products.map(OrderAdapter.parseRefundableProductToObject)
        };
    }

    public static parseRefundableProductToObject(refundableProduct: RefundableProduct): object {
        return {
            id: refundableProduct.id,
            quantity: refundableProduct.quantity
        };
    }
}
