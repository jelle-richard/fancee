import { Adapter } from '@fancee/client';
import { AddressAdapter, DateTimeAdapter, MediaAdapter, ShopAdapter } from '@/adapter';
import { Address, CreateEventShop, CreateEventShopAccordionElement, CreateEventShopDividerElement, CreateEventShopElement, CreateEventShopExternalLinkElement, CreateEventShopListing, CreateEventShopNoticeElement, CreateEventShopProductElement, CreateEventShopSeatingMapElement, CreateEventShopTextBlockElement, EventDetails, EventValidationResponse } from '@/dto';
import { ShopElementKind } from '@/enum';

@Adapter
export class CreateEventAdapter {
    public static parseDetailsFromObject(event: object): EventDetails {
        return new EventDetails(
            event['categories'],
            DateTimeAdapter.parseStartEndDateToDateTimeSpan(
                event['startDate'],
                event['endDate']
            ),
            event['description'],
            event['headerMedia'].map(MediaAdapter.parseMediaFromObject),
            event['address'] === null ? Address.empty() : AddressAdapter.parseAddressFromObject(event['address']),
            event['minAge'] === null ? null : event['minAge'],
            event['name'],
            event['status'],
            event['type'],
            event['timezoneIdentification'],
            event['seatsIoEventId'],
            event['isSealed']
        );
    }

    public static parseDetailsToApi(details: EventDetails): object {
        return {
            name: details.name,
            type: details.type,
            minAge: details.minimalAge,
            startDate: DateTimeAdapter.parseDateTimeToApi(details.dateTimeSpan.start),
            endDate: DateTimeAdapter.parseDateTimeToApi(details.dateTimeSpan.end),
            categories: details.categories,
            description: details.description,
            timezoneIdentification: details.timezoneIdentification,
            seatsIoEventId: details.seatsIoEventId,
            address: {
                venue: details.location?.venue,
                countryCode: details.location?.countryCode,
                city: details.location?.city,
                postalCode: details.location?.postalCode,
                street: details.location?.street,
                houseNumber: details.location?.houseNumber
            },
            isSealed: details.isSealed
        };
    }

    public static parseShopFromObject(shop: object): CreateEventShop {
        return new CreateEventShop(
            shop['code'],
            shop['name'],
            CreateEventAdapter.parseShopElementsFromObject(shop['elements']),
            DateTimeAdapter.parseStartEndDateToDateTimeSpan(shop['startDate'], shop['endDate']),
            shop['active'],
            shop['securedUntil'] === null
                ? null
                : DateTimeAdapter.parseDateTimeStringToLocal(shop['securedUntil']),
            ShopAdapter.parseShopDesignFromObject(shop['design']),
            shop['shopFields'].map(ShopAdapter.parseShopFieldRequirementFromObject),
            ShopAdapter.parseShopAnalyticsFromObject(shop['analytics'])
        );
    }

    public static parseShopToApi(shop: CreateEventShop): object {
        return {
            name: shop.name,
            active: shop.isActive,
            startDate: DateTimeAdapter.parseDateTimeToApi(shop.dateTimeSpan.start),
            endDate: DateTimeAdapter.parseDateTimeToApi(shop.dateTimeSpan.end),
            design: ShopAdapter.parseShopDesignToApi(shop.design),
            layout: 'Ticketshop',
            shopFields: shop.fields.map(ShopAdapter.parseShopFieldToApi),
            analytics: ShopAdapter.parseShopAnalyticsToApi(shop.analytics)
        };
    }

    public static parseShopListingFromObject(shop: object): CreateEventShopListing {
        return new CreateEventShopListing(
            shop['code'],
            shop['headerMedia'].map(MediaAdapter.parseMediaFromObject),
            shop['inUse'],
            shop['name']
        );
    }

    public static parseShopElementsFromObject(elements: object[]): CreateEventShopElement[] {
        return elements
            .map(element => {
                switch (element['kind']) {
                    case ShopElementKind.Accordion:
                        return new CreateEventShopAccordionElement(
                            CreateEventAdapter.parseShopElementsFromObject(element['elements']),
                            element['icon'],
                            element['opened'],
                            element['title']
                        );

                    case ShopElementKind.Divider:
                        return new CreateEventShopDividerElement(
                            element['name']
                        );

                    case ShopElementKind.ExternalLink:
                        return new CreateEventShopExternalLinkElement(
                            element['link'],
                            element['name']
                        );

                    case ShopElementKind.Notice:
                        return new CreateEventShopNoticeElement(
                            element['content'],
                            element['variant'].toLowerCase()
                        );

                    case ShopElementKind.Product:
                        return new CreateEventShopProductElement(
                            element['id']
                        );

                    case ShopElementKind.SeatingMap:
                        return new CreateEventShopSeatingMapElement();

                    case ShopElementKind.TextBlock:
                        return new CreateEventShopTextBlockElement(
                            element['text'],
                            element['title']
                        );

                    default:
                        return null;
                }
            })
            .filter(element => !!element);
    }

    public static parseShopElementsToApi(elements: CreateEventShopElement[]): object[] {
        return elements
            .map(CreateEventAdapter.parseShopElementToApi)
            .filter(e => !!e);
    }

    public static parseShopElementToApi(element: CreateEventShopElement): object | null {
        if (CreateEventShopElement.isAccordion(element)) return {
            kind: ShopElementKind.Accordion,
            elements: CreateEventAdapter.parseShopElementsToApi(element.elements),
            icon: element.icon,
            opened: element.opened,
            title: element.title
        };

        if (CreateEventShopElement.isDivider(element)) return {
            kind: ShopElementKind.Divider,
            name: element.name
        };

        if (CreateEventShopElement.isExternalLink(element)) return {
            kind: ShopElementKind.ExternalLink,
            name: element.name,
            link: element.link
        };

        if (CreateEventShopElement.isNotice(element)) return {
            kind: ShopElementKind.Notice,
            content: element.content,
            variant: element.variant
        };

        if (CreateEventShopElement.isProduct(element)) return {
            kind: ShopElementKind.Product,
            id: element.productId
        };

        if (CreateEventShopElement.isTextBlock(element)) return {
            kind: ShopElementKind.TextBlock,
            text: element.text,
            title: element.title
        };

        if (CreateEventShopElement.isSeatingMap(element)) return {
            kind: ShopElementKind.SeatingMap
        };

        return null;
    }

    public static parseValidationFromObject(result: object): EventValidationResponse {
        return new EventValidationResponse(
            result['hasPaymentMethod'],
            result['hasSellableProducts'],
            result['hasShops']
        );
    }
}
