import { Adapter } from '@fancee/client';
import { DateTimeAdapter, MediaAdapter, TicketAdapter } from '@/adapter';
import { EventNormalProduct, EventProduct, EventProductSummary, EventTicketProduct, TicketDesign, TicketDesignElement, TicketDesignMediaElement, TicketDesignQrElement, TicketDesignUpcomingEventsElement } from '@/dto';
import { ProductType, SalesFlow, TicketDesignElementKind } from '@/enum';

@Adapter
export class EventProductAdapter {
    public static parseEventProductFromObject(product: object): EventProduct {
        switch (product['type']) {
            case ProductType.Product:
                return new EventNormalProduct(
                    product['id'],
                    product['name'],
                    product['description'],
                    product['isSharedCapacityEligible'],
                    product['markSoldOutOnSaleWindowExpired'],
                    product['maximumPurchasePerCustomer'],
                    product['maximumPurchasePerOrder'],
                    product['media'],
                    product['packQuantity'],
                    product['priceCents'],
                    product['feeCents'],
                    product['waveLinkedProductId'] ? SalesFlow.WaveLink : SalesFlow.DateTime,
                    DateTimeAdapter.parseStartEndDateToDateTimeSpan(product['saleStart'], product['saleEnd']),
                    product['stock'],
                    product['type'],
                    product['waveLinkedProductId'],
                    product['deletable'],
                    product['hasReservationsOrSales']
                );

            case ProductType.Ticket:
                return new EventTicketProduct(
                    product['id'],
                    product['name'],
                    product['description'],
                    product['isSharedCapacityEligible'],
                    product['markSoldOutOnSaleWindowExpired'],
                    product['maximumPurchasePerCustomer'],
                    product['maximumPurchasePerOrder'],
                    product['media'],
                    product['packQuantity'],
                    product['priceCents'],
                    product['feeCents'],
                    product['waveLinkedProductId'] ? SalesFlow.WaveLink : SalesFlow.DateTime,
                    DateTimeAdapter.parseStartEndDateToDateTimeSpan(product['saleStart'], product['saleEnd']),
                    product['stock'],
                    product['type'],
                    product['waveLinkedProductId'],
                    product['deletable'],
                    product['hasReservationsOrSales'],
                    TicketAdapter.parseTicketOptionsFromObject(product['ticketOptions'])
                );

            case ProductType.SeatedTicket:
                return new EventTicketProduct(
                    product['id'],
                    product['name'],
                    product['description'],
                    product['isSharedCapacityEligible'],
                    product['markSoldOutOnSaleWindowExpired'],
                    product['maximumPurchasePerCustomer'],
                    product['maximumPurchasePerOrder'],
                    product['media'],
                    product['packQuantity'],
                    product['priceCents'],
                    product['feeCents'],
                    SalesFlow.DateTime,
                    DateTimeAdapter.parseStartEndDateToDateTimeSpan(product['saleStart'], product['saleEnd']),
                    product['stock'],
                    product['type'],
                    null,
                    product['deletable'],
                    product['hasReservationsOrSales'],
                    TicketAdapter.parseTicketOptionsFromObject(product['ticketOptions'])
                );
        }
    }

    public static parseEventProductToApi(product: EventProduct): object {
        return {
            id: product.id,
            name: product.name,
            stock: product.stock,
            priceCents: Math.floor(product.priceCents),
            feeCents: product.feeCents,
            description: product.description,
            saleStart: product.saleSpan.start ? DateTimeAdapter.parseDateTimeToApi(product.saleSpan.start) : null,
            saleEnd: product.saleSpan.end ? DateTimeAdapter.parseDateTimeToApi(product.saleSpan.end) : null,
            maximumPurchasePerOrder: product.maximumPurchasePerOrder,
            maximumPurchasePerCustomer: product.maximumPurchasePerCustomer,
            isSharedCapacityEligible: product.isSharedCapacityEligible,
            waveLinkedProductId: product.waveLinkedProductId,
            markSoldOutOnSaleWindowExpired: product.markSoldOutWhenSaleSpanExpired,
            packQuantity: product.packQuantity,
            media: null,
            type: product.type,
            ticketOptions: (EventProduct.isTicket(product) || EventProduct.isSeatedTicket(product)) ? TicketAdapter.parseTicketOptionsToApi(product.ticketOptions) : null
        };
    }

    public static parseEventProductSummaryFromObject(product: object): EventProductSummary {
        return new EventProductSummary(
            product['id'],
            product['name'],
            MediaAdapter.parseMediaFromObject(product['media']),
            product['shops']
        );
    }

    public static parseTicketDesignFromObject(design: object): TicketDesign {
        return new TicketDesign(
            design['elements'].map(EventProductAdapter.parseTicketDesignElementFromObject),
            design['ticketIds']
        );
    }

    public static parseTicketDesignToApi(design: TicketDesign): object {
        return {
            elements: design.elements.map(EventProductAdapter.parseTicketDesignElementToApi),
            ticketIds: design.ticketIds
        };
    }

    public static parseTicketDesignElementFromObject(element: object): TicketDesignElement {
        const kind = EventProductAdapter.parseTicketDesignElementKind(element['kind']);

        const column: number = element['position']['column'];
        const columnSpan: number = element['size']['columnSpan'];
        const row: number = element['position']['row'];
        const rowSpan: number = element['size']['rowSpan'];

        switch (kind) {
            case TicketDesignElementKind.Media:
                return new TicketDesignMediaElement(
                    element['fileId'],
                    element['fileUrl'],
                    column,
                    columnSpan,
                    row,
                    rowSpan
                );

            case TicketDesignElementKind.Qr:
                return new TicketDesignQrElement(
                    element['fileId'],
                    element['fileUrl'],
                    column,
                    columnSpan,
                    row,
                    rowSpan
                );

            case TicketDesignElementKind.UpcomingEvents:
                return new TicketDesignUpcomingEventsElement(
                    element['amount'],
                    column,
                    columnSpan,
                    row,
                    rowSpan
                );
        }
    }

    public static parseTicketDesignElementToApi(element: TicketDesignElement): object {
        const result: Record<string, unknown> = {
            kind: element.kind,
            position: {
                column: element.column,
                row: element.row
            },
            size: {
                columnSpan: element.columnSpan,
                rowSpan: element.rowSpan
            }
        };

        if (TicketDesignElement.isMedia(element) || TicketDesignElement.isQr(element)) {
            result.fileId = element.fileId;
        }

        if (TicketDesignElement.isUpcomingEvents(element)) {
            result.amount = element.amount;
        }

        return result;
    }

    public static parseTicketDesignElementKind(kind: string): TicketDesignElementKind {
        switch (kind.toLowerCase()) {
            case 'media':
                return TicketDesignElementKind.Media;

            case 'qr':
                return TicketDesignElementKind.Qr;

            case 'upcomingevents':
                return TicketDesignElementKind.UpcomingEvents;
        }
    }
}
