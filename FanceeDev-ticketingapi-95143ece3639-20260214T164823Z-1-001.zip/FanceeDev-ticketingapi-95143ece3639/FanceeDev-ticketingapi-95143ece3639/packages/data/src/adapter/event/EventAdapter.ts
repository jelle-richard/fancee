import { Adapter } from '@fancee/client';
import { AddressAdapter, CurrencyAdapter, DateTimeAdapter, MediaAdapter, OrganizationAdapter, PaymentAdapter, ProductAdapter } from '@/adapter';
import { AverageGenderAges, Event, EventAgendaListing, EventBalance, EventBalanceListing, EventListing, EventMail, EventProductsIdentification, EventRevenueStatistics, EventShopLinkListItem, GlobalEventStatistics, Media, OrderEvent, OrderEventOrganization, ShopEvent, UniqueCustomers } from '@/dto';
import { EventStatus } from '@/enum';

@Adapter
export class EventAdapter {
    public static parseFromObject(event: object): Event {
        return new Event(
            event['id'],
            event['seatsIoEventId'],
            event['name'],
            event['organization'],
            event['type'],
            DateTimeAdapter.parseDateTimeStringToLocal(event['startDate']),
            DateTimeAdapter.parseDateTimeStringToLocal(event['endDate']),
            event['status'],
            event['description'],
            event['address'] === null ? null : AddressAdapter.parseAddressFromObject(event['address']),
            CurrencyAdapter.parseFromObject(event['currency']),
            event['paymentMethods'].map(PaymentAdapter.parsePaymentMethodFromObject),
            event['minimumAge']
        );
    }

    public static parseShopEventFromObject(event: object): ShopEvent {
        return new ShopEvent(
            event['id'],
            event['seatsIoEventId'],
            event['name'],
            event['organization'],
            event['type'],
            DateTimeAdapter.parseDateTimeStringToLocal(event['startDate']),
            DateTimeAdapter.parseDateTimeStringToLocal(event['endDate']),
            event['status'],
            event['description'],
            event['address'] === null ? null : AddressAdapter.parseAddressFromObject(event['address']),
            CurrencyAdapter.parseFromObject(event['currency']),
            event['paymentMethods'].map(PaymentAdapter.parsePaymentMethodFromObject),
            event['minimumAge']
        );
    }

    public static parseEventListingFromObject(event: object): EventListing {
        let shops: EventShopLinkListItem[] = [];
        event['shops'].forEach(s => shops.push(EventAdapter.parseEventShopLinkListItemFromObject(s)));

        return new EventListing(
            event['id'],
            event['seatsIoEventId'],
            OrganizationAdapter.parseOrganizationFromObject(event['organization']),
            event['name'],
            DateTimeAdapter.parseDateTimeStringToLocal(event['date']),
            shops,
            event['type'],
            event['status'],
            event['deletable']
        );
    }

    public static parseEventShopLinkListItemFromObject(shop: object): EventShopLinkListItem {
        let media: Media[] = [];
        shop['headerMedia'].forEach(m => media.push(MediaAdapter.parseMediaFromObject(m)));

        return new EventShopLinkListItem(
            shop['active'],
            shop['code'],
            shop['name'],
            media,
            shop['isSecuredUntil'] = shop['isSecuredUntil'] === null
                ? null
                : DateTimeAdapter.parseDateTimeStringToLocal(shop['isSecuredUntil']),
            shop['securable']
        );
    }

    public static parseGlobalStatisticsFromObject(statistics: object): GlobalEventStatistics {
        return new GlobalEventStatistics(
            statistics['productsSoldAmount'],
            statistics['ordersPlacedAmount'],
            statistics['ticketsScannedAmount'],
            statistics['pendingRefundsAmount'],
            EventAdapter.parseAverageAgesFromObject(statistics['averageAges']),
            EventAdapter.parseUniqueCustomersFromObject(statistics['uniqueCustomers'])
        );
    }

    public static parseAverageAgesFromObject(averageAges: object): AverageGenderAges {
        return new AverageGenderAges(
            averageAges['totalAverageAge'],
            averageAges['maleAverageAge'],
            averageAges['femaleAverageAge'],
            averageAges['neutralAverageAge'],
            averageAges['unknownAverageAge']
        );
    }

    public static parseUniqueCustomersFromObject(uniqueCustomers: object): UniqueCustomers {
        return new UniqueCustomers(
            uniqueCustomers['uniqueMaleCustomers'],
            uniqueCustomers['uniqueFemaleCustomers'],
            uniqueCustomers['uniqueNeutralCustomers'],
            uniqueCustomers['uniqueUnknownCustomers']
        );
    }

    public static parseRevenueStatisticsFromObject(revenueStatistics: object): EventRevenueStatistics {
        return new EventRevenueStatistics(
            revenueStatistics['onlineSalesRevenueCents'],
            revenueStatistics['cashSalesRevenueCents'],
            revenueStatistics['platformExpensesCents'],
            revenueStatistics['profitCents']
        );
    }

    public static parseOrderEventFromObject(event: Object): OrderEvent {
        return new OrderEvent(
            event['name'],
            DateTimeAdapter.parseDateTimeStringToLocal(event['startDate']),
            EventAdapter.parseOrderEventOrganizationFromObject(event['organization'])
        );
    }

    public static parseOrderEventOrganizationFromObject(organization: object): OrderEventOrganization {
        return new OrderEventOrganization(
            organization['name'],
            organization['ticketFeeCents'],
            organization['productFeeCents']
        );
    }

    public static parseUpcomingEventsWithProductsFromObject(eventProducts: object[]): EventProductsIdentification[] {
        return eventProducts.map(EventAdapter.parseUpcomingEventProductsFromObject).flat();
    }

    public static parseUpcomingEventProductsFromObject(eventProducts: object): EventProductsIdentification {
        return new EventProductsIdentification(
            eventProducts['id'],
            eventProducts['name'],
            DateTimeAdapter.parseDateTimeStringToLocal(eventProducts['startDate']),
            eventProducts['type'],
            eventProducts['products'].map(ProductAdapter.parseTypedProductIdentificationFromObject).flat()
        );
    }

    public static parseEventToAgendaListingFromObject(event: object): EventAgendaListing {
        return new EventAgendaListing(
            event['id'],
            OrganizationAdapter.parseOrganizationFromObject(event['organization']),
            event['name'],
            DateTimeAdapter.parseDateTimeStringToLocal(event['startDate']),
            DateTimeAdapter.parseDateTimeStringToLocal(event['endDate']),
            Object.entries(event['shopCodes']).map(([shopName, shopCode]) => new EventShopLinkListItem(false, shopCode as string, shopName, [], null, false)),
            event['type'],
            event['status']
        );
    }

    public static parseEventStates(eventStates: EventStatus[]): string[] {
        return eventStates.map(es => EventStatus[es]);
    }

    public static parseEventMailFromObject(mail: object): EventMail {
        return new EventMail(
            mail['senderName'],
            mail['subject'],
            mail['content'],
            mail['type']
        );
    }

    public static parseEventsBalanceFromObject(balance: object): EventBalanceListing {
        return new EventBalanceListing(
            balance['eventId'],
            balance['eventName'],
            DateTimeAdapter.parseDateTimeStringToLocal(balance['startDate']),
            DateTimeAdapter.parseDateTimeStringToLocal(balance['endDate']),
            balance['status'],
            balance['userId'],
            balance['userEmail'],
            balance['countryCode'],
            EventAdapter.parseEventBalanceFromObject(balance['organizationCurrencyEventBalanceCentsReceivedResponse']),
            EventAdapter.parseEventBalanceFromObject(balance['platformCurrencyEventBalanceCentsReceivedResponse']),
            balance['totalAmountOfIssuedTickets'],
            balance['totalAmountOfScannedTickets']
        );
    }

    public static parseEventBalanceFromObject(eventBalance: object): EventBalance {
        return new EventBalance(
            eventBalance['totalAmountOfTicketFeeCentsReceived'],
            eventBalance['totalAmountOfSeatedTicketFeeCentsReceived'],
            eventBalance['totalAmountOfPaymentFeeCentsReceived'],
            eventBalance['totalAmountOfGuestListFeeCentsReceived'],
            eventBalance['totalAmountOfOrderTotalCostsCentsReceived'],
            eventBalance['totalAmountOfTicketPlusCostsCentsReceived'],
            CurrencyAdapter.parseFromObject(eventBalance['currency'])
        );
    }
}
