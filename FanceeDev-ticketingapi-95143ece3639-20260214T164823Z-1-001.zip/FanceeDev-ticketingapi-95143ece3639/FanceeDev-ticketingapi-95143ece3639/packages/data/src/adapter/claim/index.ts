export { ClaimAdapter } from './ClaimAdapter';
