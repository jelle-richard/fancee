import { Adapter } from '@fancee/client';
import { ClaimHierarchy, ClaimHierarchyCategory } from '@/dto';

@Adapter
export class ClaimAdapter {
    public static parseClaimHierarchyCategoryFromObject(claimHierarchyCategory: object): ClaimHierarchyCategory {
        return new ClaimHierarchyCategory(
            claimHierarchyCategory['category'],
            claimHierarchyCategory['claims'].map(ClaimAdapter.parseClaimHierarchyFromObject)
        );
    }

    public static parseClaimHierarchyFromObject(claimHierarchy: object): ClaimHierarchy {
        return new ClaimHierarchy(
            claimHierarchy['description'],
            claimHierarchy['value'],
            claimHierarchy['dependsOnClaimValue']
        );
    }
}
