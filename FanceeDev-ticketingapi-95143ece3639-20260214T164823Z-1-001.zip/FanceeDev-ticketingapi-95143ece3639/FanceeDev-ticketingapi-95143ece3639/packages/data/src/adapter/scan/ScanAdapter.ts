import { Adapter } from '@fancee/client';
import { DateTimeAdapter, MediaAdapter } from '@/adapter';
import { AppTeamScanStatistics, IntervalScan, TicketScanStatistics } from '@/dto';

@Adapter
export class ScanAdapter {
    public static parseTicketsStatisticsFromObject(ticketStatistics: object[]): TicketScanStatistics[] {
        return ticketStatistics.map(ScanAdapter.parseTicketStatisticsFromObject);
    }

    public static parseTicketStatisticsFromObject(ticketStatistics: object): TicketScanStatistics {
        return new TicketScanStatistics(
            ticketStatistics['id'],
            ticketStatistics['name'],
            MediaAdapter.parseMediaFromObject(ticketStatistics['media']),
            ticketStatistics['amountScanned'],
            ticketStatistics['amountIssued']
        );
    }

    public static parseAppTeamStatisticsFromObject(appTeamStatistics: object[]): AppTeamScanStatistics[] {
        return appTeamStatistics.map(ScanAdapter.parseAppTeamStatisticFromObject);
    }

    public static parseAppTeamStatisticFromObject(appTeamStatistic: object): AppTeamScanStatistics {
        return new AppTeamScanStatistics(
            appTeamStatistic['name'],
            ScanAdapter.parseIntervalScansFromObject(appTeamStatistic['intervalScans'])
        );
    }

    public static parseIntervalScansFromObject(intervalScans: object[]): IntervalScan[] {
        return intervalScans.map(ScanAdapter.parseIntervalScanFromObject);
    }

    public static parseIntervalScanFromObject(intervalScan: object): IntervalScan {
        return new IntervalScan(
            DateTimeAdapter.parseDateTimeStringToLocal(intervalScan['timeInterval']),
            intervalScan['ticketsScanned'],
            intervalScan['ticketsUnscanned']
        );
    }
}
