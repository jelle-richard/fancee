export { ScanAdapter } from './ScanAdapter';
