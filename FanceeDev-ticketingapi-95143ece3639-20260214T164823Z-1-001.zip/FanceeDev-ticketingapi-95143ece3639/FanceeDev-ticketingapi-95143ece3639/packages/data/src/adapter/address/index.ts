export { AddressAdapter } from './AddressAdapter';
