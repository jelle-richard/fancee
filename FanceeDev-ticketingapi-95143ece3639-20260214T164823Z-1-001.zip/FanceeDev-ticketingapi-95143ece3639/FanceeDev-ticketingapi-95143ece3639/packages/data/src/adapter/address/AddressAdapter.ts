import { Adapter } from '@fancee/client';
import { countries, CountryCode } from '@/constant';
import { Address, ClientAddress } from '@/dto';

@Adapter
export class AddressAdapter {
    public static parseAddressFromObject(address: object): Address {
        return new Address(
            address['venue'],
            address['countryCode'],
            address['city'],
            address['postalCode'],
            address['street'],
            address['houseNumber'],
            address['latitude'],
            address['longitude']
        );
    }

    public static parseClientAddressToAddress(address: ClientAddress): Address {
        return new Address(
            null,
            address.countryCode,
            address.province,
            address.zipcode,
            address.street,
            address.houseNumber,
            null,
            null
        );
    }

    public static parseCountryCodeToDisplay(countryCode: CountryCode): string {
        const [english, native] = countries[countryCode];
        return `${native} (${english})`;
    }

    public static parseCountryCodeToEnglish(countryCode: CountryCode): string {
        return countries[countryCode][0];
    }

    public static parseCountryCodeToNative(countryCode: CountryCode): string {
        return countries[countryCode][1];
    }
}
