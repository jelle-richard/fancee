import { Adapter } from '@fancee/client';
import { RegisterCountryManager, RegisterCustomerServiceEmployee } from '@/dto';

@Adapter
export class AdminRegisterAdapter {
    public static parseRegisterCountryManagerToApiScheme(countryManager: RegisterCountryManager): object {
        return {
            email: countryManager.email,
            password: countryManager.password,
            firstName: countryManager.firstName,
            lastName: countryManager.lastName,
            countryCode: countryManager.countryCode,
            terminatesOn: countryManager.terminatesOn,
            claims: countryManager.claims
        };
    }

    public static parseRegisterCustomerServiceEmployeeToApiScheme(customerServiceEmployee: RegisterCustomerServiceEmployee): object {
        return {
            email: customerServiceEmployee.email,
            password: customerServiceEmployee.password,
            firstName: customerServiceEmployee.firstName,
            lastName: customerServiceEmployee.lastName,
            countryManagerId: customerServiceEmployee.countryManagerId,
            claims: customerServiceEmployee.claims
        };
    }
}
