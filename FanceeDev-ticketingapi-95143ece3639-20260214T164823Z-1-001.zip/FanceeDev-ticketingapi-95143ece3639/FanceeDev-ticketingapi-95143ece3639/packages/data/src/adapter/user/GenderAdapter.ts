import { Adapter } from '@fancee/client';
import { Gender } from '@/enum';

@Adapter
export class GenderAdapter {
    public static parseGender(gender: string): Gender {
        switch (gender.toLowerCase()) {
            case 'male':
                return Gender.Male;
            case 'female':
                return Gender.Female;
            case 'neutral':
            default:
                return Gender.Neutral;
        }
    }
}
