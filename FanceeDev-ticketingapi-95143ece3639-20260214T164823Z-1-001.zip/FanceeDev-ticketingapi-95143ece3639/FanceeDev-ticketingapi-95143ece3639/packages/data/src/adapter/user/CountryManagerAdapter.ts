import { Adapter } from '@fancee/client';
import { CountryGroupedCountryManagers, CountryManagerListItem } from '@/dto';

@Adapter
export class CountryManagerAdapter {
    public static parseCountryGroupedCountryManagersFromObject(countryGroupedCountryManagers: object): CountryGroupedCountryManagers {
        return new CountryGroupedCountryManagers(
            countryGroupedCountryManagers['countryCode'],
            countryGroupedCountryManagers['countryManagers'].map(CountryManagerAdapter.parseCountryManagerListItemFromObject)
        );
    }

    public static parseCountryManagerListItemFromObject(countryManager: object): CountryManagerListItem {
        return new CountryManagerListItem(
            countryManager['id'],
            countryManager['email'],
            countryManager['firstName'],
            countryManager['lastName']
        );
    }
}
