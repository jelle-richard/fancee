export { AppTeamAdapter } from './AppTeamAdapter';
