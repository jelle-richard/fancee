import { Adapter } from '@fancee/client';
import { AppTeam, AppTeamListItem, AppTeamProduct } from '@/dto';
import { MediaAdapter } from '@/adapter';

@Adapter
export class AppTeamAdapter {
    public static parseAppTeamListItemFromObject(appTeam: object): AppTeamListItem {
        return new AppTeamListItem(
            appTeam['id'],
            appTeam['name'],
            appTeam['scanningEnabled'],
            appTeam['salesEnabled'],
            appTeam['statisticsEnabled'],
            appTeam['cashEnabled']
        );
    }

    public static parseAppTeamFromObject(appTeam: object, appTeamId: string): AppTeam {
        return new AppTeam(
            appTeamId,
            appTeam['name'],
            appTeam['scanningEnabled'],
            appTeam['salesEnabled'],
            appTeam['statisticsEnabled'],
            appTeam['cashEnabled'],
            appTeam['scanGuestlistEnabled'],
            AppTeamAdapter.parseAppTeamProductsFromObjects(appTeam['products'])
        );
    }

    public static parseAppTeamProductsFromObjects(products: object[]): AppTeamProduct[] {
        return products.map(s => new AppTeamProduct(
            s['id'],
            s['name'],
            s['media'].map(MediaAdapter.parseMediaFromObject)
        ));
    }

    public static parseAppTeamToApi(appTeam: AppTeam): object {
        return {
            name: appTeam.name,
            scanningEnabled: appTeam.scanningEnabled,
            salesEnabled: appTeam.salesEnabled,
            statisticsEnabled: appTeam.statisticsEnabled,
            cashEnabled: appTeam.cashEnabled,
            scanGuestlistEnabled: appTeam.scanGuestlistEnabled,
            assignedProducts: appTeam.products.map(p => p.id)
        };
    }
}
