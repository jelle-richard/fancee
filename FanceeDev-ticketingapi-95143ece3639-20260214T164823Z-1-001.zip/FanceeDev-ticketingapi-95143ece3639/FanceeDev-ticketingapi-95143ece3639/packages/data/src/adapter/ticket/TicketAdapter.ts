import { Adapter } from '@fancee/client';
import { DateTimeAdapter, GenderAdapter, OrderAdapter, ShopAdapter } from '@/adapter';
import { IssuedOrderTicket, TicketHolder, TicketInformation, TicketListing, TicketOptions } from '@/dto';
import { ScanState } from '@/enum';

@Adapter
export class TicketAdapter {
    public static parseTicketInformationFromObject(ticketInformation: object): TicketInformation {
        return new TicketInformation(
            ticketInformation['shopName'],
            ticketInformation['eventName'],
            DateTimeAdapter.parseDateTimeStringToLocal(ticketInformation['eventStartDate']),
            ticketInformation['ticketName'],
            ticketInformation['code'],
            ticketInformation['label'],
            ticketInformation['scanState'] === null ? null : TicketAdapter.parseScanState(ticketInformation['scanState']),
            ticketInformation['scanTime'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(ticketInformation['scanTime']),
            ShopAdapter.parseProductOrigin(ticketInformation['origin']),
            ticketInformation['holder'] === null ? null : TicketAdapter.parseTicketHolderFromObject(ticketInformation['holder']),
            ticketInformation['client'] === null ? null : OrderAdapter.parseClientProductOrderFromObject(ticketInformation['client']),
            ticketInformation['orderId'],
            ticketInformation['ticketState']
        );
    }

    public static parseTicketHolderFromObject(holder: object): TicketHolder {
        return new TicketHolder(
            holder['firstName'],
            holder['lastName'],
            holder['email'],
            holder['gender'] === null ? null : GenderAdapter.parseGender(holder['gender']),
            holder['phoneNumber'],
            holder['birthdate'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(holder['birthdate']),
            null
        );
    }

    public static parseTicketListingFromObject(ticketListItem: object): TicketListing {
        return new TicketListing(
            ticketListItem['code'],
            ticketListItem['label'],
            ticketListItem['eventName'],
            ShopAdapter.parseProductOrigin(ticketListItem['origin']),
            ticketListItem['scanTime'] === null ? null : DateTimeAdapter.parseDateTimeStringToLocal(ticketListItem['scanTime']),
            ticketListItem['scanState'] !== null ? TicketAdapter.parseScanState(ticketListItem['scanState']) : null,
            ticketListItem['shopName'],
            ticketListItem['ticketName'],
            ticketListItem['email'],
            ticketListItem['name'],
            ticketListItem['ticketState']
        );
    }

    public static parseTicketOptionsFromObject(ticketOptions: object): TicketOptions {
        return new TicketOptions(
            ticketOptions['usableForGuestList'],
            ticketOptions['swappable'],
            DateTimeAdapter.parseStartEndDateToDateTimeSpan(ticketOptions['partialAccessStart'], ticketOptions['partialAccessEnd']),
            ticketOptions['scanNotification'],
            ticketOptions['maximumPreArrivalTimeMinutes']
        );
    }

    public static parseTicketOptionsToApi(ticketOptions: TicketOptions): object {
        return {
            usableForGuestList: ticketOptions.isUsableForGuestList,
            swappable: ticketOptions.swappable,
            partialAccessStart: ticketOptions.partialAccess?.start === null ? null : DateTimeAdapter.parseDateTimeToApi(ticketOptions.partialAccess.start),
            partialAccessEnd: ticketOptions.partialAccess?.end === null ? null : DateTimeAdapter.parseDateTimeToApi(ticketOptions.partialAccess.end),
            scanNotification: ticketOptions.scanNotification,
            maximumPreArrivalTimeMinutes: ticketOptions.maximumPreArrivalMinutes
        };
    }

    public static parseScanState(state: string): ScanState | null {
        switch (state.toLowerCase()) {
            case 'scanned':
                return ScanState.Scanned;

            case 'unscanned':
                return ScanState.Unscanned;

            case 'notscanned':
                return ScanState.NotScanned;

            default:
                return null;
        }
    }

    public static parseIssuedOrderTicketFromObject(issuedTicket: object): IssuedOrderTicket {
        return new IssuedOrderTicket(
            issuedTicket['code'],
            TicketAdapter.parseTicketHolderFromObject(issuedTicket['holder'])
        );
    }
}
