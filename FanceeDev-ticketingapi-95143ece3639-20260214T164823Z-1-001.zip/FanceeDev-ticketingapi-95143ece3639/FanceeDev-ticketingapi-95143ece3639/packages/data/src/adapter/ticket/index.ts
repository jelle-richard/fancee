export { TicketAdapter } from './TicketAdapter';
