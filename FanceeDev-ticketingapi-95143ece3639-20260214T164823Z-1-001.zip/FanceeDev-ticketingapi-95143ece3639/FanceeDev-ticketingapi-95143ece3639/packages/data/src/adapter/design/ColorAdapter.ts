import { Adapter } from '@fancee/client';

@Adapter
export class ColorAdapter {
    public static parseColor(hex: string): string {
        if (hex.startsWith('#')) {
            return hex;
        }

        return `#${hex}`;
    }
}
