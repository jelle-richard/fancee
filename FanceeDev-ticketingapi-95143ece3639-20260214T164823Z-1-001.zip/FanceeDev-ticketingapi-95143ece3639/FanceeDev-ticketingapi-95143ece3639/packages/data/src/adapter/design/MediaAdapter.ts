import { Adapter } from '@fancee/client';
import { FocalPoint, Media } from '@/dto';

@Adapter
export class MediaAdapter {
    static parseMediaFromObject(media: object | null): Media | null {
        if (media === null) {
            return null;
        }

        return new Media(
            media['id'],
            media['url'],
            media['originalFileName'],
            media['mimeType'],
            MediaAdapter.parseFocalPointFromObject(media)
        );
    }

    static parseFocalPointFromObject(focalPoint: object): FocalPoint | null {
        if ('focalPointWidthPercentage' in focalPoint && 'focalPointHeightPercentage' in focalPoint) {
            const x = focalPoint.focalPointWidthPercentage as number | null;
            const y = focalPoint.focalPointHeightPercentage as number | null;

            if (x !== null && y !== null) {
                return new FocalPoint(x, y);
            }
        }

        return null;
    }

    static parseFocalPointToApi(focalPoint: FocalPoint): object {
        return {
            focalPointWidthPercentage: focalPoint.x,
            focalPointHeightPercentage: focalPoint.y
        };
    }
}
