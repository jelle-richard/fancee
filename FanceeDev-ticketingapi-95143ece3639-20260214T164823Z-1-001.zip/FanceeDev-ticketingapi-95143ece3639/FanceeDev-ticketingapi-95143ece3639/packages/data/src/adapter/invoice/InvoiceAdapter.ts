import { Adapter } from '@fancee/client';
import { DateTimeAdapter } from '@/adapter';
import { InvoiceListItem } from '@/dto';

@Adapter
export class InvoiceAdapter {
    public static parseInvoiceListItemFromObject(invoice: object): InvoiceListItem {
        return new InvoiceListItem(
            invoice['invoiceNumber'],
            invoice['organization'],
            DateTimeAdapter.parseDateTimeStringToLocal(invoice['createdAt']),
            invoice['hasFile']
        );
    }
}
