export type ColorType = 'primary' | 'danger' | 'info' | 'success' | 'warning';
