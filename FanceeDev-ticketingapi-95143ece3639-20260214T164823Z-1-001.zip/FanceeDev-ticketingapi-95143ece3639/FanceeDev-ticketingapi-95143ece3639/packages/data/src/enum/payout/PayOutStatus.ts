export enum PayOutStatus {
    Created = 'Created',
    Processed = 'Processed'
}
