export enum PackageType {
    Light = 'Light',
    Medium = 'Medium',
    Custom = 'Custom'
}
