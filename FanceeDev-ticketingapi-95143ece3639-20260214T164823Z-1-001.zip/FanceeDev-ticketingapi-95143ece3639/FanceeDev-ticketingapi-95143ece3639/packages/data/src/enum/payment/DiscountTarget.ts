export enum DiscountTarget {
    Order = 'order',
    Product = 'product'
}
