export enum PurchaseLocation {
    Webshop = 'Webshop',
    App = 'App',
    TicketSwap = 'TicketSwap'
}
