export enum PaidByType {
    Client = 'Client',
    Organization = 'Organization'
}
