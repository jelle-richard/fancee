export enum WalletPaymentType {
    Debit = 'Debit',
    Credit = 'Credit'
}
