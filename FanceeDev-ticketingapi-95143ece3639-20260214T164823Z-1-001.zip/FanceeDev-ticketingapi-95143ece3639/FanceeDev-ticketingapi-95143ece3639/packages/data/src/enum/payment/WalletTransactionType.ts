export enum WalletTransactionType {
    Withdrawal = 'withdrawal',
    Deposit = 'deposit',
    AdditionalCosts = 'additional_costs',
    Unknown = 'unknown'
}
