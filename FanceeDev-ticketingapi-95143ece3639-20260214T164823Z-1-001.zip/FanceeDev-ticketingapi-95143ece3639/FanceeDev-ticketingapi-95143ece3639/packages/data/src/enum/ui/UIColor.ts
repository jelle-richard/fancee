export enum UIColor {
    Primary = 'Primary',
    Link = 'Link',
    Text = 'Text',
    Backdrop = 'Backdrop',
    Background = 'Background'
}
