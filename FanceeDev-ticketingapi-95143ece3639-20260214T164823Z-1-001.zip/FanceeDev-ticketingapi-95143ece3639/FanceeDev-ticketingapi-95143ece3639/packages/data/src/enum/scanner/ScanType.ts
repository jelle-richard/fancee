export enum ScanType {
    Platform = 'Platform',
    GuestList = 'GuestList'
}
