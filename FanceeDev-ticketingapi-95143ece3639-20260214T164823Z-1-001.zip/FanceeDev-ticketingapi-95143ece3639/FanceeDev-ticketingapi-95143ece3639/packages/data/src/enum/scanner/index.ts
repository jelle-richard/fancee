export { ScanType } from './ScanType';
