export enum CsvDelimiter {
    Comma = 'comma',
    Semicolon = 'semicolon'
}
