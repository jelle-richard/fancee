export enum ScanState {
    Scanned = 'Scanned',
    Unscanned = 'Unscanned',
    NotScanned = 'NotScanned'
}
