export enum ProductOrigin {
    PlatformShop = 'PlatformShop',
    PlatformApp = 'PlatformApp',
    PlatformGenerated = 'PlatformGenerated',
    PlatformImported = 'PlatformImported',
    PlatformGuestList = 'PlatformGuestList',
    TwentyFourAndMoreApp = 'TwentyFourAndMoreApp',
    TicketSwap = 'TicketSwap'
}
