export enum TicketState {
    Active = 'Active',
    Refunded = 'Refunded',
    Swapped = 'Swapped',
    FraudBlocked = 'FraudBlocked',
    AdminBlocked = 'AdminBlocked',
    Invalidated = 'Invalidated'
}
