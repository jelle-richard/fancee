export enum ProductType {
    Ticket = 'Ticket',
    SeatedTicket = 'SeatedTicket',
    Product = 'Product'
}
