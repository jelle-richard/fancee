export enum ShopField {
    Email = 'email',
    Gender = 'gender',
    FirstName = 'firstname',
    LastName = 'lastname',
    Address = 'address',
    Street = 'street',
    City = 'city',
    Country = 'country',
    Phone = 'phone',
    Birthdate = 'birthdate'
}
