export enum ShopElementKind {
    Accordion = 'Accordion',
    Divider = 'Divider',
    ExternalLink = 'ExternalLink',
    Notice = 'Notice',
    Product = 'Product',
    SeatingMap = 'SeatingMap',
    TextBlock = 'TextBlock'
}
