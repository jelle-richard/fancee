export enum SalesFlow {
    DateTime = 'datetime',
    WaveLink = 'wavelink'
}
