export enum TicketDesignElementKind {
    Media = 'Media',
    Qr = 'Qr',
    UpcomingEvents = 'UpcomingEvents'
}
