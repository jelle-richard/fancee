export enum EventCancellationRefundOption {
    FullRefund = 'FullRefund'
}
