export enum EventMailType {
    GuestList = 'GuestList',
    DefaultShopMail = 'DefaultShopMail',
    SealedTicketsMail = 'SealedTicketsMail'
}
