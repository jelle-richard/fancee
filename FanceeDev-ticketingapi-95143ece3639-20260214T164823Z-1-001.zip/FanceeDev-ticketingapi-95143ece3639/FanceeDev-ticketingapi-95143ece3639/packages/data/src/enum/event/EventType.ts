export enum EventType {
    Normal = 'Normal',
    Seating = 'Seating',
    Timeslotted = 'Timeslotted'
}
