export enum ChangeableEventStatus {
    Unpublished = 'Unpublished',
    Active = 'Active',
    Cancelled = 'Cancelled'
}
