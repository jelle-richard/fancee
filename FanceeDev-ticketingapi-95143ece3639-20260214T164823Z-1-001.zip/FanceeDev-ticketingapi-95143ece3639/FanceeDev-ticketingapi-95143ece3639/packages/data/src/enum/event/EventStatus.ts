export enum EventStatus {
    Unpublished = 'Unpublished',
    Active = 'Active',
    Cancelled = 'Cancelled',
    SoldOut = 'SoldOut',
    Concluded = 'Concluded',
    Concept = 'Concept'
}
