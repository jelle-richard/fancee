export enum Gender {
    Male = 'Male',
    Female = 'Female',
    Neutral = 'Neutral'
}
