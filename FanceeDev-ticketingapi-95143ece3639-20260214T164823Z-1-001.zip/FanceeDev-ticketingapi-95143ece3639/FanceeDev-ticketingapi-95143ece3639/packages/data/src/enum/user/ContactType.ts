export enum ContactType {
    Finance = 'finance',
    CustomerSupport = 'customer_support',
    Organization = 'organization',
    Marketing = 'marketing'
}
