export enum UserType {
    Organization = 'Organization',
    Ambassador = 'Ambassador',
    Client = 'Client',
    Admin = 'Admin',
    Host = 'Host'
}
