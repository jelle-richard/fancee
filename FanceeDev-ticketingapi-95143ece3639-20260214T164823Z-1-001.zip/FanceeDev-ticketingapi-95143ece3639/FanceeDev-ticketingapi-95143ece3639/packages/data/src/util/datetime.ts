import { DateTime } from 'luxon';
import { DATE_TIME } from '@/constant';

export function normalizeDateTime(datetime: string): string {
    return DateTime.fromSQL(datetime).toFormat(DATE_TIME);
}
