export function hexToRgb(hex: string): [number, number, number] {
    const num = parseInt(hex.replace('#', ''), 16);

    return [
        (num >> 16) & 255,
        (num >> 8) & 255,
        num & 255
    ];
}

export function rgbToHex(r: number, g: number, b: number): string {
    return [r, g, b]
        .map(x => x.toString(16))
        .map(x => x.length === 1 ? `0${x}` : x)
        .join('')
        .padStart(7, '#');
}

export function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
    r /= 255;
    g /= 255;
    b /= 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const chroma = max - min;
    let h, s, l = (max + min) / 2;

    if (max === min) {
        h = s = 0;
    } else {
        h = 0;

        if (max === r) {
            h = fmod((g - b) / chroma, 6);

            if (h < 0) {
                h = 6 - fmod(Math.abs(h), 6);
            }
        } else if (max === g) {
            h = (b - r) / chroma + 2;
        } else if (max === b) {
            h = (r - g) / chroma + 4;
        }

        h /= 6;
        s = chroma / (1 - Math.abs(2 * l - 1));
    }

    return [
        round(h, 3),
        round(s, 3),
        round(l, 3)
    ];
}

function fmod(a: number, b: number): number {
    return Number((a - (Math.floor(a / b) * b)).toPrecision(8));
}

function round(a: number, p: number): number {
    const x = Math.pow(10, p);

    return Math.round(a * x) / x;
}
