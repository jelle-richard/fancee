export function commaCommaAnd(items: string[], and: string = '&'): string {
    return items.join(', ').replace(/(.*),/g, `$1 ${and}`);
}

export function slugify(text: string): string {
    return text
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '')
        .replace(/--+/g, '-')
        .replace(/-$/g, '');
}

export function toKebabCase(text: string): string {
    return text.replace(/[A-Z]+(?![a-z])|[A-Z]/g, ($, ofs) => (ofs ? '-' : '') + $.toLowerCase());
}

export function toSnakeCase(text: string): string {
    return text.replace(/[A-Z]+(?![a-z])|[A-Z]/g, ($, ofs) => (ofs ? '_' : '') + $.toLowerCase());
}

export function truncateString(text: string, maxLength: number, ending: string = '...'): string {
    text = normalize(text);

    const length = text.length;
    const diff = length - maxLength;
    const endingLength = ending.length;

    if (length > maxLength && diff > endingLength) {
        return `${text.substring(0, maxLength)}${ending}`;
    }

    return text;
}

export function truncateText(text: string, maxWords: number, ending: string = '...'): string {
    let excerpt = normalize(text);
    const words = excerpt.split(' ', maxWords + 1);

    if (words.length > maxWords) {
        words.pop();

        excerpt = words.join(' ');
        excerpt += ending;
    }

    return excerpt;
}

function normalize(text: string): string {
    return text.replace(/\s+/g, ' ').trim();
}
