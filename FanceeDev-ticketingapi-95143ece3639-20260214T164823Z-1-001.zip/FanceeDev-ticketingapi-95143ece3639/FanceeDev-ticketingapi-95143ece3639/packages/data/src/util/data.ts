export {
    v1 as generateUuidV1,
    v3 as generateUuidV3,
    v4 as generateUuidV4,
    v5 as generateUuidV5,
    validate as validateUuid,
    version as uuidVersion
} from 'uuid';
