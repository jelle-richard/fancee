import { ARGS, DTO_CLASS_MAP, DtoInstance, isDto, NAME } from '@fancee/client';
import { DateTime } from 'luxon';
import { default as objectHash } from 'object-hash';
import { toRaw } from 'vue';

enum SpecialCase {
    Dto = 0xBF1,
    DateTime = 0xBF2
}

type SerializedDateTime = [SpecialCase.DateTime, string];
type SerializedDto = [SpecialCase.Dto, string, string, Record<string, unknown>, any[]];
type Serialized = boolean | number | string | Record<string, unknown> | SerializedDateTime | SerializedDto | Serialized[];

const ENABLE_LOGGING = false;
const INSTANTIATED_OBJECT_CACHE: Record<string, unknown> = {};

export function deserialize(serialized: string): unknown {
    return deserializeUnknown(JSON.parse(serialized));
}

export function serialize(obj: unknown): string {
    return JSON.stringify(serializeUnknown(obj));
}

function deserializeUnknown(obj: unknown): unknown {
    if (obj === null) {
        return null;
    }

    if (Array.isArray(obj)) {
        if (isSerializedDateTime(obj)) {
            return deserializeDateTime(obj);
        }

        if (isSerializedDto(obj)) {
            return deserializeDto(obj);
        }

        return deserializeArray(obj);
    }

    if (typeof obj === 'object') {
        return deserializeObject(obj);
    }

    return obj;
}

function deserializeArray(obj: unknown[]): unknown[] {
    return obj.map(deserializeUnknown);
}

function deserializeDateTime(obj: SerializedDateTime): DateTime {
    return DateTime.fromISO(obj[1]);
}

function deserializeDto([, id, name, state, args]: SerializedDto): DtoInstance<unknown> {
    if (!(name in DTO_CLASS_MAP)) {
        throw new Error(`Cannot restore Dto. Dto class "${name}" was not found.`);
    }

    if (id in INSTANTIATED_OBJECT_CACHE) {
        return INSTANTIATED_OBJECT_CACHE[id] as DtoInstance<unknown>;
    }

    ENABLE_LOGGING && console.group('⭐️', name, id);
    const Dto = DTO_CLASS_MAP[name];
    const instance = new Dto(...deserializeArray(args));
    instance.fill(deserializeObject(state));
    ENABLE_LOGGING && console.groupEnd();

    INSTANTIATED_OBJECT_CACHE[id] = instance;

    return instance;
}

function deserializeObject(obj: object): Record<string, unknown> {
    return Object.fromEntries(
        Object.entries(obj)
            .map(([key, value]) => [key, deserializeUnknown(value)])
            .filter(([, value]) => value !== undefined)
    );
}

function serializeUnknown(obj: unknown): Serialized | undefined {
    if (obj === null) {
        return null;
    }

    if (Array.isArray(obj)) {
        return serializeArray(obj);
    }

    if (isDto(obj)) {
        return serializeDto(obj);
    }

    if (DateTime.isDateTime(obj)) {
        return serializeDateTime(obj);
    }

    if (typeof obj === 'object') {
        return serializeObject(obj);
    }

    if (typeof obj === 'boolean' || typeof obj === 'number' || typeof obj === 'string') {
        return obj;
    }

    return undefined;
}

function serializeArray(obj: unknown[]): Serialized[] {
    if (obj.every(isDto)) {
        return obj.map(serializeDto);
    }

    if (obj.every(DateTime.isDateTime)) {
        return obj.map(serializeDateTime);
    }

    return obj.map(serializeUnknown);
}

function serializeDateTime(obj: DateTime): SerializedDateTime {
    return [SpecialCase.DateTime, obj.toISO({
        includeOffset: true,
        extendedZone: true
    })];
}

function serializeDto(dto: DtoInstance<unknown>): SerializedDto {
    dto = toRaw(dto);

    return [
        SpecialCase.Dto,
        objectHash(dto.toJSON()),
        dto[NAME],
        serializeObject(dto.toJSON()),
        serializeArray(dto[ARGS])
    ];
}

function serializeObject(obj: object): Record<string, unknown> {
    return Object.fromEntries(
        Object.entries(obj)
            .map(([key, value]) => [key, serializeUnknown(value)])
            .filter(([, value]) => value !== undefined)
    );
}

function isSerializedDateTime(obj: unknown): obj is SerializedDateTime {
    return Array.isArray(obj) && obj[0] === SpecialCase.DateTime;
}

function isSerializedDto(obj: unknown): obj is SerializedDto {
    return Array.isArray(obj) && obj[0] === SpecialCase.Dto;
}
