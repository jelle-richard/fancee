# FanceeSoftware Ticketing API

This repository contains the implementation of the backend rest api that is used in the frontend
respository. The node package name for the frontend is ``@fancee/api``.

## Installation requirements & guide

- Install Node.js ^16.
- Install pnpm using ``npm i -g pnpm``.
- Install dependencies ``pnpm install``.
- Use ``pnpm dev`` to start a development build.
- Use ``pnpm build`` to create a production build.

## Git usage

Commit messages and branches will be in English.

### Branches

The repository works via the following structure:

###### Main branch

Contains the latest stable release and is the exact code that is running on the live environment.

###### Develop branch

This branch contains the latest stable release marked for the next deployment and is the exact code that is running on
the staging environment.

###### Feature branches

Any new feature should have its own feature branch. Once complete, the feature branch should be merged to the develop
branch and the feature branch should be deleted.

###### Bugfix branches

If a bug is found, it should be fixed within a bugfix branch. Once complete, the bugfix branch should be merged to the
branch it originated from and the bugfix branch should be deleted.

### Commit messages

All commit messages should follow the following template: `<type>{(<jira-issue>)}: <subject>`
Parts between `{ }` are optional.

The following types are allowed:

| Type     | Description                                                                                                                                        |
|----------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| feat     | for when a new feature has been added                                                                                                              |
| fix      | for when a bugfix has been made                                                                                                                    |
| docs     | for when documentation has changed                                                                                                                 |
| style    | for when formatting has been changed (for example: missing semicolon, removed/added brackets etc. - no actual code functionality has been changed) |
| refactor | for when the changed code is a refactor of some kind                                                                                               |
| test     | for when adding (unit) tests                                                                                                                       |
| chore    | for all other type of commits                                                                                                                      |

## Coding style

Everything related to code, HTML, styling classes etc. will be in English.

### Typescript / javascript

- Do **NOT** extend classes decorated with `@Dto`. This will not work with Vue's reactivity system.
- Do **NOT** use `myVar.constructor.name === MyClass.name` for type checking; this will break in production builds. Use `myVar instanceof MyClass` instead.
- Use `camelCase` for variable and function names.
- Use `PascalCase` for class names.
- Use `camelCase` of class members and methods.
- Use `PascalCase` for interface names.
- Use `camelCase` for interface members.
- Use `PascalCase` for type names.
- Use `camelCase` for type members.
- Use `PascalCase` for namespace names.
- Use `PascalCase` for enums.
- Use `PascalCase` for enum members.
- Use `camelCase` for file names.
- Use types wheresoever possible to denote the structure.
- Don’t ever use the types `Number`, `String`, `Boolean`, `Symbol`, or `Object` These types refer to non-primitive boxed objects that are almost never used appropriately in JavaScript code.
- Do use the types `number`, `string`, `boolean`, and `symbol`.
- Prefer using union types over overload implementations that only differ in argument position.
- Don’t ever have a generic type which doesn't use its type parameter.
- Prefer using single quotes ``'`` for string unless escaping.
- Try not to use the `any` type, this often just begs for its content to be extracted to a DTO.
- Sort overloads by putting the more specified signatures on top.
- Use single quotes ``'`` for imports and requires.
- Use 4 spaces, not tabs.
- Notate arrays as `Foo[]` instead of `Array<Foo>`.
- Define typed variables as ``const/let myVar: MyType = ...;`` and prevent casting.
- Use the standard code indentation present in Webstorm when pressing ``ctrl + alt + l``.
- Classes should adhere to the following structure: getters & setters > properties > constructor.
- Classes should adhere to the following access modifier order: public > protected > private.
- Methods with nullable parameters should prioritise to have said parameter at the end of the method signature.
- Functionality for uploading files (e.g. product images, profile pictures or shop content) should not be uploaded to a public folder.
- Code and or assets for development should be removed from production builds.
- Keep imports organized as follows:
  - External dependencies, with dependencies from `@fancee` always at the top, in alphabetical order.
  - Local modules, in alphabetical order.

## Definition of Done

- The deliverable adheres to all the requirements of the Coding style.
- The deliverable follows the provided GIT branching structure.
- The deliverable branch is up-to-date with its origin/parent branch.
- The deliverable should be production ready and not contain: (console logs, todo comments and/or other development related code).
- The deliverable branch should be attached to a corresponding Jira issue and only contain the needed changes as stated in said issue.
- The deliverable has no type errors in the build.
- The deliverable has a PR in BitBucket which is connected to a Jira issue.
- The deliverable PR has at least 1 approve of either:
  - [Bas Milius](mailto:bas@wearefancee.com)
  - [Jorden Willemsen](mailto:jorden@wearefancee.com)
  - [Martijn Woolschot](mailto:martijn@wearefancee.com)
  - [Timo Roos](mailto:timo@wearefancee.com)
- The deliverable PR passed all merge checks.
- The deliverable branch should be deleted after the PR is merged.
