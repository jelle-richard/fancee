pnpm run -C packages/client build && pnpm run -C packages/data build && pnpm run -C packages/api build && echo Done
