#!/bin/bash

pnpm --filter "@fancee/*" --parallel -r esbuild
pnpm --filter "@fancee/*" -r gentypes
