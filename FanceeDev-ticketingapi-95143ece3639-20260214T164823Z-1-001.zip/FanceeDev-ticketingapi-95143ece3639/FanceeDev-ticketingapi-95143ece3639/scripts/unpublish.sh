#!/bin/bash

pnpm --filter "@fancee/*" -r exec npm unpublish --force
