#!/bin/bash

pnpm --filter "@fancee/*" --parallel -r esbuild
pnpm --filter "@fancee/*" -r gentypes
pnpm --filter "@fancee/*" -r publish --access restricted --no-git-checks
